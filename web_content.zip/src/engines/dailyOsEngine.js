/**
 * WHITE ROOM OS — Daily OS & Daily Mission Engine
 * Generates adaptive daily operational plans with Primary, Secondary, Maintenance, and Recovery missions.
 * Strictly avoids dumping all skills into a single day; adapts to College Schedule & Energy level;
 * never selects LOCKED skills.
 */

export class DailyOsEngine {
  constructor(db, timeEngine) {
    this.db = db;
    this.timeEngine = timeEngine;
  }

  async getDailyPlan(dateStr, energyLevel = 7) {
    const schedule = await this.timeEngine.getScheduleConfig();
    const budget = this.timeEngine.calculateDayBudget(schedule, dateStr, energyLevel);
    const tasks = await this.db.queryByField('tasks', 'date', dateStr);
    const existingPlan = await this.db.get('daily_plans', `plan_${dateStr}`);

    return {
      id: `plan_${dateStr}`,
      date: dateStr,
      energyLevel: existingPlan?.energyLevel ?? energyLevel,
      budget,
      tasks: tasks.sort((a, b) => a.priority - b.priority),
      generatedAt: existingPlan?.generatedAt || null,
    };
  }

  async generateAdaptiveMissions(dateStr, energyLevel = 7, forceRegenerate = false) {
    const schedule = await this.timeEngine.getScheduleConfig();
    const budget = this.timeEngine.calculateDayBudget(schedule, dateStr, energyLevel);
    const existingTasks = await this.db.queryByField('tasks', 'date', dateStr);

    if (existingTasks.length > 0 && !forceRegenerate) {
      return this.getDailyPlan(dateStr, energyLevel);
    }

    if (forceRegenerate && existingTasks.length > 0) {
      for (const t of existingTasks) {
        if (['pending', 'planned', 'ready', 'deferred'].includes(t.status)) {
          await this.db.delete('tasks', t.id);
        }
      }
    }

    const allSkills = await this.db.getAll('skills');
    // Only select unlocked skills (never schedule LOCKED skills)
    const skills = allSkills.filter((s) => s.status !== 'LOCKED');

    const sortedSkills = [...skills].sort((a, b) => {
      const gapB = b.targetLevel - b.currentLevel;
      const gapA = a.targetLevel - a.currentLevel;
      if (gapB !== gapA) return gapB - gapA;
      return String(a.metrics?.lastPracticedDate || '').localeCompare(
        String(b.metrics?.lastPracticedDate || '')
      );
    });

    const primarySkill = sortedSkills[0] || { id: 'skill-python-algo', nameAr: 'بايثون وهياكل البيانات' };
    const secondarySkill = sortedSkills[1] || { id: 'skill-math-discrete', nameAr: 'المنطق والرياضيات المتقطعة' };
    const maintenanceSkill =
      sortedSkills.find((s) => s.id.includes('lang') || s.id.includes('chess')) ||
      sortedSkills[2] ||
      primarySkill;
    const recoverySkill =
      sortedSkills.find((s) => s.id.includes('phys')) ||
      sortedSkills[sortedSkills.length - 1] ||
      primarySkill;

    const isCollege = budget.isCollegeDay;
    const isLowEnergy = energyLevel <= 4;

    const primaryDuration = isCollege ? (isLowEnergy ? 35 : 50) : isLowEnergy ? 50 : 90;
    const secondaryDuration = isCollege ? (isLowEnergy ? 20 : 30) : isLowEnergy ? 35 : 60;
    const maintenanceDuration = isCollege ? 15 : 25;
    const recoveryDuration = isCollege ? 20 : 40;

    const generatedTasks = [
      {
        id: `task_${dateStr}_primary`,
        title: `[Primary] تدريب عميق وحل مسائل: ${primarySkill.nameAr || primarySkill.name}`,
        date: dateStr,
        category: 'Primary',
        status: 'pending',
        plannedDurationMin: primaryDuration,
        priority: 1,
        skillId: primarySkill.id,
        notes: isCollege
          ? 'يوم كلية: جلسة تركيز مركزة عالية الكثافة بدون تشتت'
          : 'يوم تركيز كامل: جلسة عمل عميق (Deep Work) مع تطبيق عملي واختبار ذاتي',
      },
      {
        id: `task_${dateStr}_secondary`,
        title: `[Secondary] تطبيق عملي وتدريب: ${secondarySkill.nameAr || secondarySkill.name}`,
        date: dateStr,
        category: 'Secondary',
        status: 'pending',
        plannedDurationMin: secondaryDuration,
        priority: 2,
        skillId: secondarySkill.id,
        notes: 'تطبيق مفاهيم وممارسة متعمدة (Deliberate Practice)',
      },
      {
        id: `task_${dateStr}_maintenance`,
        title: `[Maintenance] استرجاع نشط ومراجعة متباعدة: ${maintenanceSkill.nameAr || maintenanceSkill.name}`,
        date: dateStr,
        category: 'Maintenance',
        status: 'pending',
        plannedDurationMin: maintenanceDuration,
        priority: 3,
        skillId: maintenanceSkill.id,
        notes: 'Active Recall & Error Review للحفاظ على الإتقان ومنع النسيان',
      },
      {
        id: `task_${dateStr}_recovery`,
        title: `[Recovery] لياقة بدنية / ملاكمة واستشفاء حركي: ${recoverySkill.nameAr || recoverySkill.name}`,
        date: dateStr,
        category: 'Recovery',
        status: 'pending',
        plannedDurationMin: recoveryDuration,
        priority: 4,
        skillId: recoverySkill.id,
        notes: isCollege
          ? 'تمارين مرونة (Mobility) وتنفس واستشفاء بعد يوم الكلية الطويل'
          : 'تمرين قوة وملاكمة (Shadowboxing & Conditioning) متبوعاً بإطالات',
      },
    ];

    await this.db.bulkPut('tasks', generatedTasks);
    await this.db.put('daily_plans', {
      id: `plan_${dateStr}`,
      date: dateStr,
      energyLevel,
      isCollegeDay: isCollege,
      generatedAt: new Date().toISOString(),
    });

    return this.getDailyPlan(dateStr, energyLevel);
  }

  async createCustomTask(taskInput) {
    const newTask = {
      id: taskInput.id || `task_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: taskInput.title,
      date: taskInput.date,
      category: taskInput.category || 'Secondary',
      status: 'pending',
      plannedDurationMin: Number(taskInput.plannedDurationMin || 30),
      priority: Number(taskInput.priority || 2),
      skillId: taskInput.skillId || null,
      notes: taskInput.notes || '',
    };
    return this.db.put('tasks', newTask);
  }
}
