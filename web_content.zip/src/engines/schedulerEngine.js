/**
 * WHITE ROOM OS — Phase 4 Adaptive Scheduling & Daily Execution Engine
 * Answers:
 *  - What should I do today?
 *  - Why is this task important & why was it selected over alternatives?
 *  - When should I do it & how long should it take?
 *  - What prerequisites must be satisfied?
 *  - What happens if I fail or skip it?
 *  - What should change tomorrow based on today's results?
 *
 * Integrates Goal, Capability, Skill, Mastery, Error, Remediation, Maintenance, and Learning Engines.
 */

import {
  DEFAULT_PRIORITY_WEIGHTS,
  checkCandidateEligibility,
  calculatePriorityScore,
  calculateAvailableTimeAndBuffers,
  detectTimeBlockConflicts,
  selectAndDeferTasks,
  validateWorkloadAndRecovery,
  diagnoseTaskIssueAndRecommendAdjustment,
  timeStringToMinutes,
  minutesToTimeString,
  addDaysToDate,
} from './priorityEngine.js';

export class AdaptiveSchedulerEngine {
  constructor(db, engines = {}) {
    this.db = db;
    this.timeEngine = engines.timeEngine;
    this.skillEngine = engines.skillEngine;
    this.learningEngine = engines.learningEngine;
    this.performanceEngine = engines.performanceEngine;
    this.timerEngine = engines.timerEngine;
    this.customWeights = { ...DEFAULT_PRIORITY_WEIGHTS };
  }

  setPriorityWeights(newWeights = {}) {
    this.customWeights = { ...this.customWeights, ...newWeights };
    return this.customWeights;
  }

  async _loadSchedulingContext(dateStr, energyLevel = 7) {
    if (this.learningEngine) {
      await this.learningEngine.reconcileObjectiveStates();
    } else if (this.skillEngine) {
      await this.skillEngine.reconcilePrerequisiteLocks();
    }

    const [
      scheduleConfig,
      goals,
      skills,
      subskills,
      objectives,
      learningPaths,
      errors,
      remediations,
      flashcards,
      reviews,
      existingDayTasks,
      dayBlocks,
    ] = await Promise.all([
      this.timeEngine.getScheduleConfig(),
      this.db.getAll('goals'),
      this.db.getAll('skills'),
      this.db.getAll('subskills'),
      this.db.getAll('learning_objectives'),
      this.db.getAll('learning_paths'),
      this.db.getAll('errors'),
      this.db.getAll('remediations'),
      this.db.getAll('flashcards'),
      this.db.getAll('reviews'),
      this.db.queryByField('tasks', 'date', dateStr),
      this.db.queryByField('time_blocks', 'date', dateStr),
    ]);

    const skillsMap = {};
    for (const s of skills) skillsMap[s.id] = s;
    const subskillsMap = {};
    for (const sub of subskills) subskillsMap[sub.id] = sub;
    const objectivesMap = {};
    for (const o of objectives) objectivesMap[o.id] = o;
    const goalsMap = {};
    for (const g of goals) goalsMap[g.id] = g;
    const errorsMap = {};
    for (const e of errors) errorsMap[e.id] = e;

    const timeBudget = calculateAvailableTimeAndBuffers(
      scheduleConfig,
      dateStr,
      energyLevel,
      dayBlocks
    );

    return {
      currentDate: dateStr,
      energyLevel: Number(energyLevel),
      scheduleConfig,
      timeBudget,
      goals,
      goalsMap,
      allSkills: skills,
      skillsMap,
      allSubskills: subskills,
      subskillsMap,
      allObjectives: objectives,
      objectivesMap,
      learningPaths,
      errors,
      errorsMap,
      remediations,
      flashcards,
      reviews,
      existingDayTasks,
      dayBlocks,
      availableNetMin: timeBudget.schedulableWorkMin,
    };
  }

  /**
   * Gathers all candidate tasks from across the engines (including blocked ones so we can explicitly test & report prerequisite exclusion!).
   */
  async gatherCandidatePool(dateStr, context) {
    const candidates = [];
    const {
      allSkills,
      allObjectives,
      errors,
      remediations,
      flashcards,
      existingDayTasks,
      timeBudget,
    } = context;

    // 1. Preserve already completed/in_progress/partially_completed/skipped tasks on this date
    const activeExisting = existingDayTasks.filter(
      (t) => !['deferred', 'cancelled'].includes(t.status)
    );
    for (const t of activeExisting) {
      candidates.push({ ...t, isExistingTask: true });
    }

    // 2. Unresolved Errors -> Remediation Corrective Tasks or Ready Retests
    for (const err of errors.filter((e) => e.status !== 'resolved')) {
      const rem = remediations.find((r) => r.errorId === err.id);
      if (rem && rem.retestAllowed) {
        candidates.push({
          id: `cand_${dateStr}_retest_${err.id}`,
          title: `[Retest] إعادة الاختبار لإغلاق الخطأ: ${err.description}`,
          date: dateStr,
          category: 'Tests',
          status: 'planned',
          executionState: 'planned',
          plannedDurationMin: 25,
          priority: 1,
          skillId: err.skillId,
          subskillId: err.subskillId || null,
          objectiveId: err.objectiveId || null,
          errorId: err.id,
          isRetestReady: true,
          difficulty: 6,
          energyDemand: 7,
        });
      } else {
        candidates.push({
          id: `cand_${dateStr}_remed_${err.id}`,
          title: `[Remediation] معالجة الخطأ الحرج: ${err.description}`,
          date: dateStr,
          category: 'Remediation',
          status: 'planned',
          executionState: 'planned',
          plannedDurationMin: 35,
          priority: 1,
          skillId: err.skillId,
          subskillId: err.subskillId || null,
          objectiveId: err.objectiveId || null,
          errorId: err.id,
          isCorrective: true,
          difficulty: 6,
          energyDemand: 7,
        });
      }
    }

    // 3. Overdue Spaced-Repetition Flashcards
    const dueCards = flashcards.filter(
      (fc) => !fc.nextReviewDate || String(fc.nextReviewDate) <= String(dateStr)
    );
    if (dueCards.length > 0) {
      const oldestDue = dueCards[0].nextReviewDate || dateStr;
      const daysOverdue = Math.max(
        1,
        Math.round((Date.parse(dateStr) - Date.parse(oldestDue)) / 86400000) + 1
      );
      candidates.push({
        id: `cand_${dateStr}_reviews_fc`,
        title: `[Reviews] مراجعة ${dueCards.length} بطاقة استرجاع متباعد مستحقة (Spaced Repetition)`,
        date: dateStr,
        category: 'Reviews',
        status: 'planned',
        executionState: 'planned',
        plannedDurationMin: Math.min(30, Math.max(15, dueCards.length * 5)),
        priority: 2,
        skillId: dueCards[0].skillId,
        subskillId: dueCards[0].subskillId || null,
        objectiveId: dueCards[0].objectiveId || null,
        isOverdueReview: true,
        daysOverdue,
        difficulty: 4,
        energyDemand: 5,
      });
    }

    // 4. Learning Objectives (both unlocked AND locked so eligibility filter is genuinely exercised)
    for (const obj of allObjectives) {
      if (obj.status === 'MASTERED' || obj.status === 'MAINTENANCE') {
        if (obj.nextReviewDate && String(obj.nextReviewDate) <= String(dateStr)) {
          candidates.push({
            id: `cand_${dateStr}_obj_ret_${obj.id}`,
            title: `[Maintenance] مراجعة احتفاظ للهدف المتقن: ${obj.title}`,
            date: dateStr,
            category: 'Maintenance',
            status: 'planned',
            executionState: 'planned',
            plannedDurationMin: 25,
            priority: 2,
            skillId: obj.skillId,
            subskillId: obj.subskillId || null,
            objectiveId: obj.id,
            isOverdueReview: true,
            daysOverdue: 2,
            difficulty: obj.difficulty || 5,
            energyDemand: 5,
          });
        }
        continue;
      }

      const cat =
        obj.status === 'READY_FOR_TEST'
          ? 'Tests'
          : obj.status === 'PRACTICING' || obj.status === 'EXPOSED' || obj.status === 'LEARNING'
          ? 'Practice'
          : 'Primary';

      const dur = timeBudget.isCollegeDay ? 35 : Math.min(60, obj.estimatedEffortMin || 45);

      candidates.push({
        id: `cand_${dateStr}_obj_${obj.id}`,
        title: `[${cat}] ${obj.title}`,
        date: dateStr,
        category: cat,
        status: 'planned',
        executionState: 'planned',
        plannedDurationMin: dur,
        priority: 1,
        skillId: obj.skillId,
        subskillId: obj.subskillId || null,
        objectiveId: obj.id,
        difficulty: obj.difficulty || 5,
        energyDemand: Math.min(9, (obj.difficulty || 5) + 1),
      });
    }

    // 5. Foundational Skills (including locked skills to test exclusion, and active/maintenance skills)
    for (const sk of allSkills) {
      if (sk.status === 'MAINTENANCE') {
        candidates.push({
          id: `cand_${dateStr}_maint_${sk.id}`,
          title: `[Maintenance] جلسة صيانة واستبقاء: ${sk.nameAr || sk.name}`,
          date: dateStr,
          category: 'Maintenance',
          status: 'planned',
          executionState: 'planned',
          plannedDurationMin: 20,
          priority: 3,
          skillId: sk.id,
          difficulty: 4,
          energyDemand: 4,
        });
      } else if (sk.id.includes('phys')) {
        candidates.push({
          id: `cand_${dateStr}_recovery_${sk.id}`,
          title: `[Recovery] لياقة بدنية / ملاكمة واستشفاء حركي: ${sk.nameAr || sk.name}`,
          date: dateStr,
          category: 'Recovery',
          status: 'planned',
          executionState: 'planned',
          plannedDurationMin: timeBudget.isCollegeDay ? 20 : 35,
          priority: 3,
          skillId: sk.id,
          difficulty: 4,
          energyDemand: 5,
        });
      } else {
        candidates.push({
          id: `cand_${dateStr}_skill_${sk.id}`,
          title: `[Secondary] تدريب موجه وتطبيق عملي: ${sk.nameAr || sk.name}`,
          date: dateStr,
          category: 'Secondary',
          status: 'planned',
          executionState: 'planned',
          plannedDurationMin: timeBudget.isCollegeDay ? 25 : 40,
          priority: sk.priority || 2,
          skillId: sk.id,
          difficulty: 5,
          energyDemand: 6,
        });
      }
    }

    return candidates;
  }

  /**
   * Generates or updates the Day's Fixed Commitment Time Blocks + Assigned Task Time Blocks without conflicts.
   */
  async _buildDayTimeBlocks(dateStr, selectedTasks, context, preserveManualBlocks = true) {
    const { scheduleConfig, timeBudget } = context;
    const existingBlocks = await this.db.queryByField('time_blocks', 'date', dateStr);

    const manualBlocks = preserveManualBlocks
      ? existingBlocks.filter((b) => b.isManual)
      : [];

    // Delete auto-generated blocks for this date before rebuilding
    for (const b of existingBlocks) {
      if (!b.isManual) {
        await this.db.delete('time_blocks', b.id);
      }
    }

    const blocksToSave = [...manualBlocks];

    // 1. Fixed Sleep Block (00:00 -> 06:00)
    blocksToSave.push({
      id: `blk_${dateStr}_sleep`,
      date: dateStr,
      title: '😴 النوم والاستشفاء العصبي (Fixed Sleep)',
      startTime: '00:00',
      endTime: '06:00',
      blockType: 'sleep',
      isFixed: true,
      isManual: false,
      taskId: null,
    });

    // 2. Fixed College Block if College Day
    if (timeBudget.isCollegeDay) {
      blocksToSave.push({
        id: `blk_${dateStr}_college`,
        date: dateStr,
        title: `🏛️ التزام الكلية الثابت (${scheduleConfig.collegeStart}–${scheduleConfig.collegeEnd})`,
        startTime: scheduleConfig.collegeStart || '06:00',
        endTime: scheduleConfig.collegeEnd || '18:00',
        blockType: 'college',
        isFixed: true,
        isManual: false,
        taskId: null,
      });
    } else {
      // Midday Meals & Prayer block on non-college day
      blocksToSave.push({
        id: `blk_${dateStr}_meals`,
        date: dateStr,
        title: '🍽️ وجبات وصلاة وراحة (Meals & Prayer)',
        startTime: '12:00',
        endTime: '13:30',
        blockType: 'meals_prayer',
        isFixed: true,
        isManual: false,
        taskId: null,
      });
    }

    // Helper to find the next conflict-free start minute of length `durationMin`
    const findNextFreeSlot = (startAfterMin, durationMin) => {
      let cursor = startAfterMin;
      const latestEnd = 22 * 60 + 30; // Stop scheduling by 22:30 for sleep protection
      while (cursor + durationMin <= latestEnd) {
        const candStart = cursor;
        const candEnd = cursor + durationMin;
        const overlaps = blocksToSave.some((b) => {
          const bS = timeStringToMinutes(b.startTime);
          const bE = timeStringToMinutes(b.endTime);
          return candStart < bE && bS < candEnd;
        });
        if (!overlaps) {
          return {
            startTime: minutesToTimeString(candStart),
            endTime: minutesToTimeString(candEnd),
            nextCursor: candEnd + 10, // 10-minute micro-break buffer between blocks
          };
        }
        cursor += 15;
      }
      return null;
    };

    let cursorMin = timeBudget.isCollegeDay
      ? Math.max(timeStringToMinutes(scheduleConfig.collegeEnd || '18:00') + 30, 18 * 60 + 30)
      : 7 * 60 + 30;

    for (const task of selectedTasks) {
      const dur = Number(task.plannedDurationMin || 30);
      const slot = findNextFreeSlot(cursorMin, dur);
      if (!slot) continue;

      const blockId = `blk_${dateStr}_task_${task.id}`;
      blocksToSave.push({
        id: blockId,
        date: dateStr,
        title: task.title,
        startTime: slot.startTime,
        endTime: slot.endTime,
        blockType: 'task_block',
        isFixed: false,
        isManual: false,
        taskId: task.id,
        category: task.category,
      });

      task.timeBlockId = blockId;
      task.scheduledWindow = `${slot.startTime}–${slot.endTime}`;
      cursorMin = slot.nextCursor;
    }

    // Add an explicit Buffer Block if space permits
    const bufSlot = findNextFreeSlot(cursorMin, Math.min(30, timeBudget.bufferMin));
    if (bufSlot) {
      blocksToSave.push({
        id: `blk_${dateStr}_buffer`,
        date: dateStr,
        title: '🛡️ وقت احتياطي مرن (Buffer & Transition)',
        startTime: bufSlot.startTime,
        endTime: bufSlot.endTime,
        blockType: 'buffer',
        isFixed: false,
        isManual: false,
        taskId: null,
      });
    }

    await this.db.bulkPut('time_blocks', blocksToSave);
    return blocksToSave.sort(
      (a, b) => timeStringToMinutes(a.startTime) - timeStringToMinutes(b.startTime)
    );
  }

  /**
   * 4. GENERATE SMART DAILY EXECUTION PLAN
   */
  async generateSmartDailyPlan(dateStr, energyLevel = 7, options = { forceRegenerate: false }) {
    const context = await this._loadSchedulingContext(dateStr, energyLevel);
    const { existingDayTasks, timeBudget, scheduleConfig } = context;

    // If forceRegenerate is true, remove only unstarted ('pending' / 'planned' / 'ready' / 'deferred') auto tasks,
    // NEVER deleting 'completed', 'partially_completed', 'in_progress', or 'skipped' historical tasks!
    if (options.forceRegenerate && existingDayTasks.length > 0) {
      for (const t of existingDayTasks) {
        if (['pending', 'planned', 'ready', 'deferred'].includes(t.status) && !t.preserveOnRegen) {
          await this.db.delete('tasks', t.id);
        }
      }
      context.existingDayTasks = await this.db.queryByField('tasks', 'date', dateStr);
    }

    const candidatePool = await this.gatherCandidatePool(dateStr, context);

    const eligibleScored = [];
    const excludedBlockedTasks = [];

    for (const cand of candidatePool) {
      const elig = checkCandidateEligibility(cand, context);
      if (!elig.eligible) {
        excludedBlockedTasks.push({
          id: cand.id,
          title: cand.title,
          skillId: cand.skillId,
          subskillId: cand.subskillId || null,
          objectiveId: cand.objectiveId || null,
          prerequisiteStatus: 'BLOCKED',
          blockingIds: elig.blockingIds,
          reason: elig.reason,
        });
        continue;
      }

      const scoreInfo = calculatePriorityScore(cand, context, this.customWeights);
      eligibleScored.push({
        ...cand,
        status:
          cand.status === 'completed' ||
          cand.status === 'in_progress' ||
          cand.status === 'partially_completed' ||
          cand.status === 'skipped'
            ? cand.status
            : 'ready',
        executionState:
          cand.status === 'completed' ||
          cand.status === 'in_progress' ||
          cand.status === 'partially_completed' ||
          cand.status === 'skipped'
            ? cand.status
            : 'ready',
        priority: scoreInfo.priorityRank,
        priorityScore: scoreInfo.priorityScore,
        priorityBreakdown: scoreInfo.factors,
        selectionExplanation: scoreInfo.explanation,
        consequenceIfSkipped: scoreInfo.consequenceIfSkipped,
        prerequisiteStatus: 'SATISFIED',
        notes: scoreInfo.explanation,
      });
    }

    const selection = selectAndDeferTasks(eligibleScored, timeBudget);
    const timeBlocks = await this._buildDayTimeBlocks(
      dateStr,
      selection.selectedTasks,
      context,
      true
    );

    // Save selected tasks to DB
    if (selection.selectedTasks.length > 0) {
      await this.db.bulkPut('tasks', selection.selectedTasks);
    }

    const overloadCheck = validateWorkloadAndRecovery(
      selection.selectedTasks,
      timeBudget,
      scheduleConfig
    );

    const mainObjectiveTask =
      selection.selectedTasks.find((t) =>
        ['Primary', 'Remediation', 'Tests', 'Practice'].includes(t.category)
      ) || selection.selectedTasks[0] || null;

    const conflictCheck = detectTimeBlockConflicts(timeBlocks);

    const planRecord = {
      id: `plan_${dateStr}`,
      date: dateStr,
      energyLevel: Number(energyLevel),
      isCollegeDay: timeBudget.isCollegeDay,
      mainObjective: mainObjectiveTask
        ? mainObjectiveTask.title
        : 'استكمال خطة التطوير اليومية ضمن الميزانية المتاحة',
      budget: timeBudget,
      plannedWorkloadMin: selection.plannedWorkloadMin,
      remainingAvailableMin: selection.remainingAvailableMin,
      bufferPreservedMin: selection.bufferPreservedMin,
      limitingConstraint:
        selection.deferredTasks.length > 0
          ? selection.deferredTasks[0].limitingConstraint
          : 'NONE_WITHIN_SAFE_BUDGET',
      deferredTasks: selection.deferredTasks,
      excludedBlockedTasks,
      overloadCheck,
      conflictCheck,
      generatedAt: new Date().toISOString(),
    };

    await this.db.put('daily_plans', planRecord);

    return this.getDailyExecutionView(dateStr, energyLevel, true);
  }

  async getDailyExecutionView(dateStr, energyLevel = 7, _fromGenerate = false) {
    let existingPlan = await this.db.get('daily_plans', `plan_${dateStr}`);
    let dayTasks = await this.db.queryByField('tasks', 'date', dateStr);

    if ((!existingPlan || dayTasks.length === 0) && !_fromGenerate) {
      return this.generateSmartDailyPlan(dateStr, energyLevel, { forceRegenerate: false });
    }

    const context = await this._loadSchedulingContext(dateStr, energyLevel);
    const timeBlocks = (await this.db.queryByField('time_blocks', 'date', dateStr)).sort(
      (a, b) => timeStringToMinutes(a.startTime) - timeStringToMinutes(b.startTime)
    );
    const conflictCheck = detectTimeBlockConflicts(timeBlocks);

    const activeTasks = dayTasks
      .filter((t) => t.status !== 'deferred' && t.status !== 'cancelled')
      .sort((a, b) => (b.priorityScore || 0) - (a.priorityScore || 0));

    const unscheduledTasks = activeTasks.filter((t) => !t.timeBlockId);
    const completedMin = activeTasks
      .filter((t) => t.status === 'completed' || t.status === 'partially_completed')
      .reduce((s, t) => s + Number(t.actualDurationMin || t.plannedDurationMin || 0), 0);
    const remainingPlannedMin = activeTasks
      .filter((t) => ['pending', 'planned', 'ready', 'in_progress'].includes(t.status))
      .reduce((s, t) => s + Number(t.plannedDurationMin || 0), 0);

    const nextRecommendedTask =
      activeTasks.find((t) => t.status === 'in_progress') ||
      activeTasks.find((t) => t.status === 'ready' || t.status === 'planned' || t.status === 'pending') ||
      null;

    const overloadCheck = validateWorkloadAndRecovery(
      activeTasks,
      context.timeBudget,
      context.scheduleConfig
    );

    const history = await this.db.queryByField('execution_history', 'date', dateStr);

    return {
      ...existingPlan,
      budget: context.timeBudget,
      tasks: activeTasks,
      unscheduledTasks,
      deferredTasks: existingPlan.deferredTasks || [],
      excludedBlockedTasks: existingPlan.excludedBlockedTasks || [],
      timeBlocks,
      conflictCheck,
      overloadCheck,
      completedMinutesToday: completedMin,
      remainingPlannedMinutesToday: remainingPlannedMin,
      remainingAvailableMin: Math.max(
        0,
        context.timeBudget.schedulableWorkMin - (completedMin + remainingPlannedMin)
      ),
      nextRecommendedTask,
      executionHistory: history,
    };
  }

  // =========================================================================
  // 5. INTERNAL CALENDAR & TIME-BLOCK MANAGEMENT (SECTION 10)
  // =========================================================================

  async createOrUpdateTimeBlock(blockInput) {
    const dateStr = blockInput.date || '2026-10-14';
    const existingBlocks = await this.db.queryByField('time_blocks', 'date', dateStr);

    const newBlock = {
      id: blockInput.id || `blk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      date: dateStr,
      title: blockInput.title,
      startTime: blockInput.startTime,
      endTime: blockInput.endTime,
      blockType: blockInput.blockType || 'fixed_commitment',
      isFixed: Boolean(blockInput.isFixed),
      isManual: blockInput.isManual !== undefined ? Boolean(blockInput.isManual) : true,
      taskId: blockInput.taskId || null,
    };

    const otherBlocks = existingBlocks.filter((b) => b.id !== newBlock.id);
    const conflictCheck = detectTimeBlockConflicts([...otherBlocks, newBlock]);

    if (conflictCheck.hasConflicts && !blockInput.allowConflict) {
      // If a new Fixed Commitment conflicts with a movable Task Block, automatically shift the movable task block!
      if (newBlock.isFixed) {
        for (const c of conflictCheck.conflicts) {
          const conflictingId = c.blockAId === newBlock.id ? c.blockBId : c.blockAId;
          const conflictingBlock = otherBlocks.find((b) => b.id === conflictingId);
          if (conflictingBlock && !conflictingBlock.isFixed) {
            const dur =
              timeStringToMinutes(conflictingBlock.endTime) -
              timeStringToMinutes(conflictingBlock.startTime);
            const shiftedStart = timeStringToMinutes(newBlock.endTime) + 10;
            if (shiftedStart + dur <= 23 * 60) {
              conflictingBlock.startTime = minutesToTimeString(shiftedStart);
              conflictingBlock.endTime = minutesToTimeString(shiftedStart + dur);
              await this.db.put('time_blocks', conflictingBlock);
              if (conflictingBlock.taskId) {
                const linkedTask = await this.db.get('tasks', conflictingBlock.taskId);
                if (linkedTask) {
                  await this.db.put('tasks', {
                    ...linkedTask,
                    scheduledWindow: `${conflictingBlock.startTime}–${conflictingBlock.endTime}`,
                  });
                }
              }
            }
          }
        }
      }
    }

    const saved = await this.db.put('time_blocks', newBlock);
    const updatedBlocks = await this.db.queryByField('time_blocks', 'date', dateStr);
    return {
      block: saved,
      conflictCheck: detectTimeBlockConflicts(updatedBlocks),
    };
  }

  async assignTaskToTimeBlock(taskId, blockId) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Task not found: ${taskId}`);
    const block = await this.db.get('time_blocks', blockId);
    if (!block) throw new Error(`TimeBlock not found: ${blockId}`);
    if (block.isFixed && block.blockType !== 'study_window' && block.blockType !== 'task_block') {
      throw new Error(`Cannot assign task to fixed commitment block "${block.title}"`);
    }

    const updatedBlock = await this.db.put('time_blocks', {
      ...block,
      blockType: 'task_block',
      title: task.title,
      taskId: task.id,
    });

    const updatedTask = await this.db.put('tasks', {
      ...task,
      timeBlockId: updatedBlock.id,
      scheduledWindow: `${updatedBlock.startTime}–${updatedBlock.endTime}`,
    });

    return { task: updatedTask, block: updatedBlock };
  }

  // =========================================================================
  // 6. COMPLETE TASK EXECUTION LIFECYCLE & ADAPTIVE RESCHEDULING (SECTIONS 6 & 7)
  // Planned -> Ready -> In Progress -> Completed / Partially Completed / Skipped
  // =========================================================================

  async _logExecutionEvent(task, eventType, details = {}) {
    return this.db.put('execution_history', {
      id: `exec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      taskId: task.id,
      taskTitle: task.title,
      date: task.date,
      skillId: task.skillId || null,
      subskillId: task.subskillId || null,
      objectiveId: task.objectiveId || null,
      eventType,
      actualDurationMin: Number(details.actualDurationMin ?? task.actualDurationMin ?? 0),
      completionPct: Number(details.completionPct ?? task.partialCompletionPct ?? 0),
      energy: Number(details.energy ?? 7),
      difficulty: Number(details.difficulty ?? task.difficulty ?? 5),
      outcome: details.outcome || '',
      evidenceId: details.evidenceId || null,
      blockers: Array.isArray(details.blockers) ? details.blockers : [],
      skipReason: details.skipReason || null,
      diagnosis: details.diagnosis || null,
      rescheduledToTaskId: details.rescheduledToTaskId || null,
      timestamp: new Date().toISOString(),
    });
  }

  async startTaskExecution(taskId, nowEpochMs = Date.now()) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Task not found: ${taskId}`);

    const context = await this._loadSchedulingContext(task.date, 7);
    const elig = checkCandidateEligibility(task, context);
    if (!elig.eligible) {
      throw new Error(`Cannot start prerequisite-blocked task: ${elig.reason}`);
    }

    const updatedTask = await this.db.put('tasks', {
      ...task,
      status: 'in_progress',
      executionState: 'in_progress',
      startedAtIso: new Date(nowEpochMs).toISOString(),
    });

    if (this.timerEngine) {
      await this.timerEngine.start(updatedTask, nowEpochMs);
    }

    await this._logExecutionEvent(updatedTask, 'IN_PROGRESS', {
      outcome: 'Started task execution and timer',
    });

    return updatedTask;
  }

  async completeTaskExecution(taskId, payload = {}) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Task not found: ${taskId}`);

    const actualDurationMin = Number(
      payload.actualDurationMin ?? task.plannedDurationMin ?? 35
    );
    const energy = Number(payload.energy ?? 8);
    const difficulty = Number(payload.difficulty ?? task.difficulty ?? 5);
    const confidence = Number(payload.confidence ?? 8);
    const outcome = String(payload.outcome || payload.whatLearned || 'تم إنجاز المهمة بالكامل').trim();
    const mistakes = String(payload.mistakes || '').trim();
    const blockers = Array.isArray(payload.blockers) ? payload.blockers : [];

    if (this.timerEngine) {
      const tState = await this.timerEngine.getState();
      if (tState.taskId === taskId && (tState.status === 'running' || tState.status === 'paused')) {
        await this.timerEngine.finish();
      }
    }

    const updatedTask = await this.db.put('tasks', {
      ...task,
      status: 'completed',
      executionState: 'completed',
      partialCompletionPct: 100,
      actualDurationMin,
      difficulty,
      blockers,
      lastLoggedAt: new Date().toISOString(),
    });

    // Record performance log & evidence/errors through existing engines
    let perfRes = null;
    if (this.performanceEngine) {
      perfRes = await this.performanceEngine.recordPerformanceLog({
        taskId: updatedTask.id,
        taskTitle: updatedTask.title,
        skillId: updatedTask.skillId,
        subskillId: updatedTask.subskillId,
        date: updatedTask.date,
        plannedDurationSec: (updatedTask.plannedDurationMin || 30) * 60,
        actualDurationSec: actualDurationMin * 60,
        completionPct: 100,
        energy,
        difficulty,
        confidence,
        whatLearned: outcome,
        mistakes,
      });
    }

    if (updatedTask.isPracticeTask && updatedTask.objectiveId && this.learningEngine) {
      await this.learningEngine.completePracticeTask(updatedTask.id, {
        durationMinutes: actualDurationMin,
        outputSubmitted: outcome,
      });
    }

    const historyEntry = await this._logExecutionEvent(updatedTask, 'COMPLETED', {
      actualDurationMin,
      completionPct: 100,
      energy,
      difficulty,
      outcome,
      evidenceId: perfRes?.createdEvidence?.id || null,
      blockers,
    });

    // If actual duration significantly exceeded planned duration, adapt remaining day plan!
    const overrunMin = Math.max(0, actualDurationMin - (task.plannedDurationMin || 30));
    let deferredDueToOverrun = [];
    if (overrunMin >= 20) {
      deferredDueToOverrun = await this._rebalanceRemainingDayAfterOverrun(
        task.date,
        overrunMin
      );
    }

    return {
      task: updatedTask,
      performanceResult: perfRes,
      historyEntry,
      deferredDueToOverrun,
    };
  }

  async partiallyCompleteTaskExecution(taskId, payload = {}) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Task not found: ${taskId}`);

    const completionPct = Math.max(10, Math.min(95, Number(payload.completionPct ?? 50)));
    const actualDurationMin = Number(
      payload.actualDurationMin ?? Math.round((task.plannedDurationMin || 40) * (completionPct / 100))
    );
    const energy = Number(payload.energy ?? 5);
    const difficulty = Number(payload.difficulty ?? task.difficulty ?? 7);
    const blockers = Array.isArray(payload.blockers)
      ? payload.blockers
      : payload.blocker
      ? [payload.blocker]
      : [];

    const context = await this._loadSchedulingContext(task.date, energy);
    const diagnosis = diagnoseTaskIssueAndRecommendAdjustment(
      task,
      {
        eventType: 'PARTIALLY_COMPLETED',
        completionPct,
        actualDurationMin,
        energy,
        difficulty,
      },
      context.timeBudget
    );

    const updatedTask = await this.db.put('tasks', {
      ...task,
      status: 'partially_completed',
      executionState: 'partially_completed',
      partialCompletionPct: completionPct,
      actualDurationMin,
      difficulty,
      blockers,
      diagnosis,
      lastLoggedAt: new Date().toISOString(),
    });

    // Schedule continuation task for tomorrow with only the remaining duration (no punitive doubling!)
    const tomorrowDate = addDaysToDate(task.date, 1);
    const continuationTask = await this.db.put('tasks', {
      id: `task_cont_${ tomorrowDate }_${task.id.slice(-6)}`,
      title: `[استكمال ${100 - completionPct}%] ${task.title}`,
      date: tomorrowDate,
      category: task.category,
      status: 'ready',
      executionState: 'ready',
      plannedDurationMin: diagnosis.recommendedNextDurationMin,
      priority: task.priority,
      priorityScore: task.priorityScore,
      skillId: task.skillId,
      subskillId: task.subskillId || null,
      objectiveId: task.objectiveId || null,
      difficulty: diagnosis.recommendedDifficulty,
      rescheduledFromDate: task.date,
      rescheduledFromTaskId: task.id,
      preserveOnRegen: true,
      selectionExplanation: `استكمال الجزء المتبقي (${100 - completionPct}%) بعد إنجاز جزئي في ${task.date}`,
    });

    const historyEntry = await this._logExecutionEvent(updatedTask, 'PARTIALLY_COMPLETED', {
      actualDurationMin,
      completionPct,
      energy,
      difficulty,
      outcome: payload.outcome || `إنجاز جزئي (${completionPct}%) وترحيل الباقي ليوم ${tomorrowDate}`,
      blockers,
      diagnosis,
      rescheduledToTaskId: continuationTask.id,
    });

    return {
      task: updatedTask,
      continuationTask,
      diagnosis,
      historyEntry,
    };
  }

  async skipTaskExecution(taskId, payload = {}) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Task not found: ${taskId}`);

    const skipReason = String(payload.skipReason || 'ظرف طارئ أو ضيق الوقت').trim();
    const blockers = Array.isArray(payload.blockers)
      ? payload.blockers
      : payload.blocker
      ? [payload.blocker]
      : [];
    const energy = Number(payload.energy ?? 5);
    const difficulty = Number(payload.difficulty ?? task.difficulty ?? 6);

    const context = await this._loadSchedulingContext(task.date, energy);
    const diagnosis = diagnoseTaskIssueAndRecommendAdjustment(
      task,
      {
        eventType: 'SKIPPED',
        skipReason,
        energy,
        difficulty,
      },
      context.timeBudget
    );

    const updatedTask = await this.db.put('tasks', {
      ...task,
      status: 'skipped',
      executionState: 'skipped',
      skipCount: diagnosis.skipCount,
      skipReason,
      blockers,
      diagnosis,
      lastLoggedAt: new Date().toISOString(),
    });

    // Reschedule for tomorrow with adapted duration/difficulty (never punitive workload doubling!)
    let rescheduledTask = null;
    if (payload.reschedule !== false) {
      const tomorrowDate = addDaysToDate(task.date, 1);
      rescheduledTask = await this.db.put('tasks', {
        id: `task_resched_${tomorrowDate}_${task.id.slice(-6)}`,
        title:
          diagnosis.skipCount >= 2
            ? `[Micro-Session تكيفية] ${task.title}`
            : task.title,
        date: tomorrowDate,
        category: task.category,
        status: 'ready',
        executionState: 'ready',
        plannedDurationMin: diagnosis.recommendedNextDurationMin,
        priority: task.priority,
        priorityScore: Math.min(100, (task.priorityScore || 70) + 5),
        skillId: task.skillId,
        subskillId: task.subskillId || null,
        objectiveId: task.objectiveId || null,
        errorId: task.errorId || null,
        difficulty: diagnosis.recommendedDifficulty,
        skipCount: diagnosis.skipCount,
        rescheduledFromDate: task.date,
        rescheduledFromTaskId: task.id,
        preserveOnRegen: true,
        selectionExplanation: `أعيدت جدولتها بتكييف ذكي بعد تخطيها في ${task.date}: ${diagnosis.summaryText}`,
      });
    }

    const historyEntry = await this._logExecutionEvent(updatedTask, 'SKIPPED', {
      actualDurationMin: 0,
      completionPct: 0,
      energy,
      difficulty,
      skipReason,
      blockers,
      diagnosis,
      rescheduledToTaskId: rescheduledTask?.id || null,
    });

    return {
      task: updatedTask,
      rescheduledTask,
      diagnosis,
      historyEntry,
    };
  }

  async _rebalanceRemainingDayAfterOverrun(dateStr, overrunMin) {
    const dayTasks = await this.db.queryByField('tasks', 'date', dateStr);
    const pendingLowPriority = dayTasks
      .filter((t) => ['ready', 'planned', 'pending'].includes(t.status) && t.category !== 'Remediation')
      .sort((a, b) => (a.priorityScore || 50) - (b.priorityScore || 50));

    const deferred = [];
    let reclaimedMin = 0;
    for (const t of pendingLowPriority) {
      if (reclaimedMin >= overrunMin) break;
      const updated = await this.db.put('tasks', {
        ...t,
        status: 'deferred',
        executionState: 'deferred',
        deferralReason: `تم تأجيلها تلقائياً لتعويض تجاوز وقت المهمة السابقة (+${overrunMin} د) وحماية وقت النوم والاحتياطي`,
      });
      deferred.push(updated);
      reclaimedMin += Number(t.plannedDurationMin || 25);
    }
    return deferred;
  }

  // =========================================================================
  // 7. WEEKLY PLANNING & DISTRIBUTION (SECTION 11)
  // Distributes work across 7 days without copying the same overloaded day 7 times.
  // =========================================================================

  async generateWeeklyPlan(weekStartDate = '2026-10-14', options = { preserveCompleted: true }) {
    const existingWeekly = await this.db.get('weekly_plans', `week_${weekStartDate}`);
    const days = [];
    let totalWeekPlannedMin = 0;
    let collegeDaysCount = 0;
    let focusDaysCount = 0;

    const allSkills = (await this.db.getAll('skills')).filter((s) => s.status !== 'LOCKED');

    for (let offset = 0; offset < 7; offset++) {
      const dateStr = addDaysToDate(weekStartDate, offset);
      const context = await this._loadSchedulingContext(dateStr, 7);
      const isCollege = context.timeBudget.isCollegeDay;
      if (isCollege) collegeDaysCount++;
      else focusDaysCount++;

      // Rotate focus skill across the week so the same overloaded day is NEVER copied 7 times!
      const focusSkill = allSkills[offset % Math.max(1, allSkills.length)];
      const secondarySkill = allSkills[(offset + 1) % Math.max(1, allSkills.length)];

      const existingTasks = await this.db.queryByField('tasks', 'date', dateStr);
      const completedTasks = existingTasks.filter(
        (t) => t.status === 'completed' || t.status === 'partially_completed'
      );

      const dayTheme = isCollege
        ? `يوم كلية (${context.timeBudget.collegeWindow}) — صيانة مركزة واستشفاء`
        : offset % 2 === 0
        ? `تركيز عميق (Deep Work): ${focusSkill?.nameAr || 'مهارة أساسية'}`
        : `تطبيق واختبار ومراجعة: ${secondarySkill?.nameAr || 'مهارة مساندة'}`;

      const targetWorkloadMin = isCollege
        ? Math.min(90, context.timeBudget.schedulableWorkMin)
        : Math.min(210, context.timeBudget.schedulableWorkMin);

      totalWeekPlannedMin += targetWorkloadMin;

      days.push({
        date: dateStr,
        dayName: context.timeBudget.dayName,
        isCollegeDay: isCollege,
        dayTheme,
        primarySkillId: focusSkill?.id || null,
        primarySkillName: focusSkill?.nameAr || focusSkill?.name || '',
        secondarySkillId: secondarySkill?.id || null,
        secondarySkillName: secondarySkill?.nameAr || secondarySkill?.name || '',
        availableNetMin: context.timeBudget.schedulableWorkMin,
        bufferMin: context.timeBudget.bufferMin,
        plannedWorkloadMin: targetWorkloadMin,
        completedTasksCount: completedTasks.length,
        includesMaintenance: offset % 2 === 1 || isCollege,
        includesRecovery: true,
      });
    }

    const weeklyRecord = {
      id: `week_${weekStartDate}`,
      weekStartDate,
      weekEndDate: addDaysToDate(weekStartDate, 6),
      collegeDaysCount,
      focusDaysCount,
      totalWeekPlannedMin,
      regeneratedCount: (existingWeekly?.regeneratedCount || 0) + 1,
      days,
      generatedAt: new Date().toISOString(),
    };

    return this.db.put('weekly_plans', weeklyRecord);
  }
}
