/**
 * WHITE ROOM OS — Phase 3 Learning Engine & Resource Engine
 * Converts resources into verified learning processes:
 * Resource -> Learning Objective -> Learning Session -> Active Processing (Recall / Flashcards / Feynman)
 * -> Practice Task -> Evidence -> Learning Test -> Error -> Remediation -> Retest -> Mastery -> Maintenance/Retention.
 *
 * Strictly separates domain logic from UI and integrates directly with Phase 2 SkillEngine.
 */

import {
  normalizeLearningObjectiveRecord,
  normalizeResourceRecord,
  EVIDENCE_TYPES,
} from '../core/schema.js';
import { SpacedRepetitionScheduler } from './spacedRepetition.js';

export function evaluateMetacognitiveCalibration(confidencePct, actualScorePct) {
  const conf = Number(confidencePct ?? 70);
  const actual = Number(actualScorePct ?? 70);
  const delta = Number((conf - actual).toFixed(1));
  const isOverconfident = delta >= 20;
  const isUnderconfident = delta <= -25;
  return {
    confidence: conf,
    actualPerformance: actual,
    calibrationDelta: delta,
    metacognitiveMismatch: isOverconfident || isUnderconfident,
    mismatchType: isOverconfident
      ? 'OVERCONFIDENT_ILLUSION_OF_COMPETENCE'
      : isUnderconfident
      ? 'UNDERCONFIDENT_IMPOSTOR_GAP'
      : 'CALIBRATED',
  };
}

export function scoreRecallAnswer(expectedAnswer, userAnswer) {
  const clean = (s) =>
    String(s || '')
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 2);

  const expectedTokens = clean(expectedAnswer);
  const userTokens = new Set(clean(userAnswer));

  if (expectedTokens.length === 0) {
    return userTokens.size > 0 ? 100 : 0;
  }

  let matched = 0;
  for (const token of expectedTokens) {
    if (userTokens.has(token)) matched++;
  }
  return Math.min(100, Math.round((matched / expectedTokens.length) * 100));
}

export class LearningEngine {
  constructor(db, skillEngine, srScheduler = new SpacedRepetitionScheduler()) {
    this.db = db;
    this.skillEngine = skillEngine;
    this.srScheduler = srScheduler;
  }

  // =========================================================================
  // 1. LEARNING OBJECTIVES & PREREQUISITE GATING
  // =========================================================================

  async checkObjectivePrerequisitesMet(objective) {
    const skill = await this.db.get('skills', objective.skillId);
    if (skill && skill.status === 'LOCKED') {
      return {
        allMet: false,
        unmetIds: [skill.id],
        reason: `Parent Skill "${skill.name}" is LOCKED`,
      };
    }

    if (objective.subskillId) {
      const sub = await this.db.get('subskills', objective.subskillId);
      if (sub && sub.masteryState === 'LOCKED') {
        return {
          allMet: false,
          unmetIds: [sub.id],
          reason: `Linked Subskill "${sub.name}" is LOCKED`,
        };
      }
    }

    const prereqIds = Array.isArray(objective.prerequisites) ? objective.prerequisites : [];
    const unmetIds = [];

    for (const prereqId of prereqIds) {
      const objPrereq = await this.db.get('learning_objectives', prereqId);
      if (objPrereq) {
        if (objPrereq.status !== 'MASTERED' && objPrereq.status !== 'MAINTENANCE') {
          unmetIds.push(prereqId);
        }
        continue;
      }
      const subPrereq = await this.db.get('subskills', prereqId);
      if (subPrereq) {
        if (subPrereq.masteryState !== 'MASTERED' && subPrereq.masteryState !== 'MAINTENANCE') {
          unmetIds.push(prereqId);
        }
        continue;
      }
      const skillPrereq = await this.db.get('skills', prereqId);
      if (skillPrereq) {
        if (skillPrereq.status !== 'MASTERED' && skillPrereq.status !== 'MAINTENANCE') {
          unmetIds.push(prereqId);
        }
      }
    }

    return {
      allMet: unmetIds.length === 0,
      unmetIds,
      reason: unmetIds.length > 0 ? `Unmet prerequisites: ${unmetIds.join(', ')}` : null,
    };
  }

  async createLearningObjective(input) {
    const nowIso = new Date().toISOString();
    const record = normalizeLearningObjectiveRecord({
      id: input.id || `obj_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: input.title,
      description: input.description || input.title,
      goalId: input.goalId || input.linkedGoal || null,
      capabilityId: input.capabilityId || input.linkedCapability || 'cap-04-cs',
      skillId: input.skillId || input.linkedSkill,
      subskillId: input.subskillId || input.linkedSubskill || null,
      targetOutcome:
        input.targetOutcome || `القدرة العملية على تطبيق وإثبات: ${input.title}`,
      whyItMatters:
        input.whyItMatters || `يبني الكفاءة الفعلية القابلة للاختبار في ${input.title}`,
      difficulty: Number(input.difficulty ?? 5),
      estimatedEffortMin: Number(input.estimatedEffortMin ?? 60),
      status: input.status || 'NOT_STARTED',
      masteryRelevance: input.masteryRelevance || 'core',
      prerequisites: Array.isArray(input.prerequisites) ? input.prerequisites : [],
      historicalMasteryAchieved: Boolean(input.historicalMasteryAchieved),
      createdAt: input.createdAt || nowIso,
      updatedAt: nowIso,
    });

    const prereqCheck = await this.checkObjectivePrerequisitesMet(record);
    if (!prereqCheck.allMet) {
      record.status = 'LOCKED';
    } else if (record.status === 'LOCKED') {
      record.status = 'NOT_STARTED';
    }

    return this.db.put('learning_objectives', record);
  }

  async assertObjectiveUnlocked(objectiveId) {
    const obj = await this.db.get('learning_objectives', objectiveId);
    if (!obj) throw new Error(`Learning Objective not found: ${objectiveId}`);
    const check = await this.checkObjectivePrerequisitesMet(obj);
    if (obj.status === 'LOCKED' || !check.allMet) {
      throw new Error(
        `Learning Objective "${obj.title}" is LOCKED. ${check.reason || ''}`
      );
    }
    return obj;
  }

  async reconcileObjectiveStates() {
    await this.skillEngine.reconcilePrerequisiteLocks();
    const allObjectives = await this.db.getAll('learning_objectives');

    for (const obj of allObjectives) {
      const check = await this.checkObjectivePrerequisitesMet(obj);
      let nextStatus = obj.status;
      if (!check.allMet) {
        nextStatus = 'LOCKED';
      } else if (obj.status === 'LOCKED') {
        nextStatus = 'NOT_STARTED';
      }
      if (nextStatus !== obj.status) {
        await this.db.put('learning_objectives', {
          ...obj,
          status: nextStatus,
          updatedAt: new Date().toISOString(),
        });
      }
    }
  }

  // =========================================================================
  // 2. RESOURCE ENGINE INTEGRATION
  // =========================================================================

  async createResource(input) {
    const nowIso = new Date().toISOString();
    const record = normalizeResourceRecord({
      id: input.id || `res_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: input.title,
      type: input.type || 'Custom resource',
      reference: input.reference || input.url || 'local://resource',
      url: input.url || input.reference || 'local://resource',
      author: input.author || input.source || 'Self / Official Docs',
      estimatedTimeMin: Number(input.estimatedTimeMin ?? input.duration ?? 45),
      difficulty: Number(input.difficulty ?? 5),
      domain: input.domain || input.linkedDomain || 'cap-04-cs',
      skillId: input.skillId || input.linkedSkill,
      subskillId: input.subskillId || input.linkedSubskill || null,
      learningObjectives: Array.isArray(input.learningObjectives)
        ? input.learningObjectives
        : input.objectiveId
        ? [input.objectiveId]
        : [],
      status: input.status || 'queued',
      notes: input.notes || '',
      createdAt: input.createdAt || nowIso,
      updatedAt: nowIso,
    });

    return this.db.put('resources', record);
  }

  async linkResourceToObjective(resourceId, objectiveId) {
    const res = await this.db.get('resources', resourceId);
    if (!res) throw new Error(`Resource not found: ${resourceId}`);
    const obj = await this.db.get('learning_objectives', objectiveId);
    if (!obj) throw new Error(`Learning Objective not found: ${objectiveId}`);

    const updatedObjectives = [...new Set([...(res.learningObjectives || []), objectiveId])];
    return this.db.put('resources', {
      ...res,
      learningObjectives: updatedObjectives,
      skillId: res.skillId || obj.skillId,
      subskillId: res.subskillId || obj.subskillId,
      updatedAt: new Date().toISOString(),
    });
  }

  // =========================================================================
  // 3. LEARNING SESSIONS (EXPOSURE != MASTERY)
  // =========================================================================

  async recordLearningSession(input) {
    const obj = await this.assertObjectiveUnlocked(input.objectiveId);
    const nowIso = new Date().toISOString();
    const sessionType = input.sessionType || 'LEARN';
    const completionState = input.completionState || 'completed';
    const plannedDurationMin = Number(input.plannedDurationMin ?? 45);
    const actualDurationMin = Number(input.actualDurationMin ?? plannedDurationMin);
    const confidence = Number(input.confidence ?? 75);
    const actualPerformance =
      input.actualPerformance !== undefined ? Number(input.actualPerformance) : null;

    const calibration =
      actualPerformance !== null
        ? evaluateMetacognitiveCalibration(confidence, actualPerformance)
        : null;

    const sessionRecord = {
      id: input.id || `lsess_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      resourceId: input.resourceId || null,
      objectiveId: obj.id,
      skillId: obj.skillId,
      subskillId: obj.subskillId || null,
      startTime: input.startTime || nowIso,
      endTime: input.endTime || nowIso,
      plannedDurationMin,
      actualDurationMin,
      sessionType,
      completionState,
      notes: input.notes || '',
      recallResult: input.recallResult ?? null,
      practiceResult: input.practiceResult ?? null,
      evidenceIds: Array.isArray(input.evidenceIds) ? input.evidenceIds : [],
      errorIds: Array.isArray(input.errorIds) ? input.errorIds : [],
      confidence,
      actualPerformance,
      metacognitiveGap: calibration ? calibration.calibrationDelta : 0,
      metacognitiveMismatch: calibration ? calibration.metacognitiveMismatch : false,
      qualityRating: Number(input.qualityRating ?? 4),
      createdAt: nowIso,
    };

    const savedSession = await this.db.put('learning_sessions', sessionRecord);

    // Update Resource status if linked (Note: consuming a resource ONLY exposes the learner, never masters!)
    if (sessionRecord.resourceId) {
      const res = await this.db.get('resources', sessionRecord.resourceId);
      if (res) {
        await this.db.put('resources', {
          ...res,
          status: completionState === 'completed' ? 'processed' : 'in_progress',
          updatedAt: nowIso,
        });
      }
    }

    // Update Objective state based on sessionType (Watching/Reading = EXPOSED/LEARNING only, NEVER MASTERED!)
    let nextObjStatus = obj.status;
    if (obj.status !== 'MASTERED' && obj.status !== 'MAINTENANCE') {
      if (sessionType === 'LEARN') {
        nextObjStatus = obj.status === 'NOT_STARTED' ? 'EXPOSED' : 'LEARNING';
      } else if (sessionType === 'RECALL') {
        nextObjStatus = 'RECALLING';
      } else if (sessionType === 'PRACTICE' || sessionType === 'PROJECT') {
        nextObjStatus = 'PRACTICING';
      } else if (sessionType === 'REVIEW') {
        nextObjStatus = 'UNDER_REVIEW';
      } else if (sessionType === 'REMEDIATION') {
        nextObjStatus = 'REMEDIATION';
      }
    }

    await this.db.put('learning_objectives', {
      ...obj,
      status: nextObjStatus,
      updatedAt: nowIso,
    });

    // Update Skill study/practice minutes without falsely marking mastery
    const skill = await this.db.get('skills', obj.skillId);
    if (skill) {
      const isPractice = ['PRACTICE', 'PROJECT', 'REMEDIATION'].includes(sessionType);
      await this.db.put('skills', {
        ...skill,
        status: skill.status === 'AVAILABLE' ? 'IN_PROGRESS' : skill.status,
        metrics: {
          ...skill.metrics,
          totalStudyMinutes:
            (skill.metrics?.totalStudyMinutes || 0) + (isPractice ? 0 : actualDurationMin),
          totalPracticeMinutes:
            (skill.metrics?.totalPracticeMinutes || 0) + (isPractice ? actualDurationMin : 0),
          trainingSessionsCount:
            (skill.metrics?.trainingSessionsCount || 0) + (isPractice ? 1 : 0),
          lastPracticedDate: nowIso.slice(0, 10),
        },
        updatedAt: nowIso,
      });
      await this.skillEngine.calculateSkillProgress(skill.id);
    }

    if (input.notes && String(input.notes).trim().length > 0) {
      await this.addNote({
        targetType: 'session',
        targetId: savedSession.id,
        skillId: obj.skillId,
        title: `ملاحظات جلسة: ${obj.title}`,
        content: String(input.notes).trim(),
      });
    }

    return {
      session: savedSession,
      objective: await this.db.get('learning_objectives', obj.id),
      calibration,
    };
  }

  // =========================================================================
  // 4. ACTIVE RECALL & METACOGNITIVE CALIBRATION
  // =========================================================================

  async recordRecallAttempt(input) {
    const obj = await this.assertObjectiveUnlocked(input.objectiveId);
    const nowIso = input.timestamp || new Date().toISOString();

    const computedScore =
      input.correctness !== undefined
        ? Number(input.correctness)
        : scoreRecallAnswer(input.expectedAnswer, input.userAnswer);

    const confidence = Number(input.confidence ?? 75);
    const calibration = evaluateMetacognitiveCalibration(confidence, computedScore);
    const passed = computedScore >= 70;

    const attempt = await this.db.put('recall_attempts', {
      id: input.id || `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      sessionId: input.sessionId || null,
      objectiveId: obj.id,
      skillId: obj.skillId,
      subskillId: obj.subskillId || null,
      question: input.question,
      expectedAnswer: input.expectedAnswer,
      userAnswer: input.userAnswer,
      correctness: computedScore,
      passed,
      confidence,
      calibrationDelta: calibration.calibrationDelta,
      metacognitiveMismatch: calibration.metacognitiveMismatch,
      mismatchType: calibration.mismatchType,
      timestamp: nowIso,
    });

    await this._recomputeObjectiveProgressState(obj.id);
    await this.skillEngine.calculateSkillProgress(obj.skillId);

    return {
      recallAttempt: attempt,
      passed,
      calibration,
      objective: await this.db.get('learning_objectives', obj.id),
    };
  }

  // =========================================================================
  // 5. FLASHCARDS & SPACED REPETITION
  // =========================================================================

  async createFlashcard(input) {
    const nowIso = new Date().toISOString();
    const todayStr = input.nextReviewDate || nowIso.slice(0, 10);
    const card = {
      id: input.id || `fc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      front: input.front,
      back: input.back,
      explanation: input.explanation || '',
      source: input.source || '',
      objectiveId: input.objectiveId || null,
      skillId: input.skillId,
      subskillId: input.subskillId || null,
      tags: Array.isArray(input.tags) ? input.tags : [],
      difficulty: Number(input.difficulty ?? 5),
      confidence: Number(input.confidence ?? 50),
      interval: 0,
      repetitionCount: 0,
      easeFactor: 2.3,
      reviewHistory: [],
      nextReviewDate: todayStr,
      retentionState: 'NEW',
      createdAt: nowIso,
      updatedAt: nowIso,
    };
    return this.db.put('flashcards', card);
  }

  async reviewFlashcard(input) {
    const {
      flashcardId,
      recallScore,
      confidence = 75,
      difficulty,
      reviewDate = new Date().toISOString().slice(0, 10),
    } = input;

    const card = await this.db.get('flashcards', flashcardId);
    if (!card) throw new Error(`Flashcard not found: ${flashcardId}`);

    const scheduleResult = this.srScheduler.scheduleNextReview({
      recallScore: Number(recallScore),
      confidence: Number(confidence),
      difficulty: Number(difficulty ?? card.difficulty ?? 5),
      previousInterval: card.interval || 0,
      repetitionCount: card.repetitionCount || 0,
      easeFactor: card.easeFactor || 2.3,
      reviewDate,
    });

    const historyEntry = {
      reviewedAt: new Date().toISOString(),
      reviewDate,
      recallScore: Number(recallScore),
      confidence: Number(confidence),
      difficulty: Number(difficulty ?? card.difficulty ?? 5),
      interval: scheduleResult.interval,
      nextReviewDate: scheduleResult.nextReviewDate,
      retentionState: scheduleResult.retentionState,
      metacognitiveMismatch: scheduleResult.metacognitiveMismatch,
    };

    const updatedCard = await this.db.put('flashcards', {
      ...card,
      difficulty: Number(difficulty ?? card.difficulty ?? 5),
      confidence: Number(confidence),
      interval: scheduleResult.interval,
      repetitionCount: scheduleResult.repetitionCount,
      easeFactor: scheduleResult.easeFactor,
      retentionState: scheduleResult.retentionState,
      nextReviewDate: scheduleResult.nextReviewDate,
      reviewHistory: [...(card.reviewHistory || []), historyEntry],
      updatedAt: new Date().toISOString(),
    });

    return {
      flashcard: updatedCard,
      scheduleResult,
    };
  }

  async getDueFlashcards(currentDateStr = new Date().toISOString().slice(0, 10), skillId = null) {
    const all = await this.db.getAll('flashcards');
    return all.filter((c) => {
      if (skillId && c.skillId !== skillId) return false;
      return this.srScheduler.isOverdue(c.nextReviewDate, currentDateStr);
    });
  }

  // =========================================================================
  // 6. FEYNMAN MODE (EXPLANATION -> GAP DETECTION -> REMEDIATION OR EVIDENCE)
  // =========================================================================

  async recordFeynmanExplanation(input) {
    const obj = await this.assertObjectiveUnlocked(input.objectiveId);
    const nowIso = input.timestamp || new Date().toISOString();
    const explanation = String(input.explanation || '').trim();
    const confidence = Number(input.confidence ?? 75);
    const identifiedGaps = Array.isArray(input.identifiedGaps)
      ? input.identifiedGaps.filter((g) => String(g).trim().length > 0)
      : [];

    const wordCount = explanation.split(/\s+/).filter(Boolean).length;
    const baseClarity =
      input.clarityScore !== undefined
        ? Number(input.clarityScore)
        : Math.max(20, Math.min(95, wordCount * 6 - identifiedGaps.length * 25));

    const passed = identifiedGaps.length === 0 && baseClarity >= 75;
    const evaluatorResult = passed ? 'pass' : 'needs_remediation';
    const calibration = evaluateMetacognitiveCalibration(confidence, baseClarity);

    let createdEvidence = null;
    let createdError = null;
    let createdRemediation = null;

    if (passed) {
      createdEvidence = await this.recordLearningEvidence({
        objectiveId: obj.id,
        skillId: obj.skillId,
        subskillId: obj.subskillId,
        type: 'written_explanation',
        title: `شرح فاينمان متقن: ${obj.title}`,
        content: explanation,
        qualityScore: baseClarity,
      });
    } else {
      // Create Error & Remediation Plan in existing Phase 2 engines for identified conceptual gaps!
      const gapDesc =
        identifiedGaps.length > 0
          ? `فجوات مفاهيمية في شرح فاينمان: ${identifiedGaps.join('، ')}`
          : `شرح فاينمان غير مكتمل الوضوح (${baseClarity}%) للهدف: ${obj.title}`;

      createdError = await this.db.put('errors', {
        id: `err_feyn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        skillId: obj.skillId,
        linkedSkill: obj.skillId,
        subskillId: obj.subskillId || null,
        linkedSubskill: obj.subskillId || null,
        objectiveId: obj.id,
        category: 'conceptual',
        severity: identifiedGaps.length >= 2 ? 'high' : 'medium',
        description: gapDesc,
        cause: 'عدم القدرة على صياغة المفهوم بلغة واضحة بدون فجوات أثناء اختبار Feynman',
        date: nowIso.slice(0, 10),
        evidence: explanation,
        remediation: 'مراجعة الفجوات المفاهيمية وإعادة صياغة الشرح مع أمثلة تطبيقية',
        status: 'open',
        retestRequired: true,
      });

      const remBundle = await this.skillEngine.createRemediationPlan({
        errorId: createdError.id,
        title: `علاج فجوات فاينمان: ${obj.title}`,
        tasksSpec: [
          {
            title: `[Feynman Corrective] سد الفجوات المفاهيمية وإعادة الشرح: ${identifiedGaps.join(' + ') || obj.title}`,
            plannedDurationMin: 30,
          },
        ],
      });
      createdRemediation = remBundle.remediation;
    }

    const feynmanEntry = await this.db.put('feynman_entries', {
      id: input.id || `feyn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      objectiveId: obj.id,
      skillId: obj.skillId,
      subskillId: obj.subskillId || null,
      explanation,
      confidence,
      clarityScore: baseClarity,
      evaluatorResult,
      identifiedGaps,
      metacognitiveMismatch: calibration.metacognitiveMismatch,
      producedErrorId: createdError?.id || null,
      producedRemediationId: createdRemediation?.id || null,
      evidenceId: createdEvidence?.id || null,
      timestamp: nowIso,
    });

    await this._recomputeObjectiveProgressState(obj.id);
    await this.skillEngine.calculateSkillProgress(obj.skillId);

    return {
      feynmanEntry,
      passed,
      calibration,
      createdEvidence,
      createdError,
      createdRemediation,
      objective: await this.db.get('learning_objectives', obj.id),
    };
  }

  // =========================================================================
  // 7. PRACTICE TASKS & EVIDENCE VERIFICATION
  // =========================================================================

  async createPracticeTask(input) {
    const obj = await this.assertObjectiveUnlocked(input.objectiveId);
    const dateStr = input.date || new Date().toISOString().slice(0, 10);

    const practiceTask = await this.db.put('tasks', {
      id: input.id || `task_prac_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: input.title || `[Practice] ${obj.title}`,
      date: dateStr,
      category: input.category || 'Primary',
      status: 'pending',
      plannedDurationMin: Number(input.timeEstimateMin ?? input.plannedDurationMin ?? 45),
      priority: Number(input.priority ?? 1),
      skillId: obj.skillId,
      subskillId: obj.subskillId || null,
      objectiveId: obj.id,
      isPracticeTask: true,
      instructions:
        input.instructions || `طبق عملياً المخرج المستهدف: ${obj.targetOutcome}`,
      expectedOutput:
        input.expectedOutput || 'حل كامل موثق قابل للتحقق والاختبار',
      difficulty: Number(input.difficulty ?? obj.difficulty ?? 5),
      evidenceRequirement:
        input.evidenceRequirement || 'solved_problem',
      notes: input.notes || `مهمة تطبيق عملي مرتبطة بالهدف التعلمي: ${obj.title}`,
    });

    if (obj.status === 'NOT_STARTED' || obj.status === 'EXPOSED' || obj.status === 'LEARNING') {
      await this.db.put('learning_objectives', {
        ...obj,
        status: 'PRACTICING',
        updatedAt: new Date().toISOString(),
      });
    }

    return practiceTask;
  }

  async completePracticeTask(taskId, completionPayload = {}) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Practice task not found: ${taskId}`);

    const nowIso = new Date().toISOString();
    const durationMin = Number(completionPayload.durationMinutes ?? task.plannedDurationMin ?? 45);
    const updatedTask = await this.db.put('tasks', {
      ...task,
      status: 'completed',
      actualDurationMin: durationMin,
      lastLoggedAt: nowIso,
    });

    const evType = EVIDENCE_TYPES.includes(completionPayload.evidenceType)
      ? completionPayload.evidenceType
      : EVIDENCE_TYPES.includes(task.evidenceRequirement)
      ? task.evidenceRequirement
      : 'completed_exercise';

    const evidence = await this.recordLearningEvidence({
      objectiveId: task.objectiveId || null,
      skillId: task.skillId,
      subskillId: task.subskillId || null,
      taskId: updatedTask.id,
      type: evType,
      title: completionPayload.evidenceTitle || `إنجاز تطبيقي: ${task.title}`,
      content:
        completionPayload.evidenceContent ||
        completionPayload.outputSubmitted ||
        task.expectedOutput ||
        'تم إتمام التدريب العملي وتوثيق المخرج بنجاح.',
      qualityScore: Number(completionPayload.qualityScore ?? 90),
    });

    // Also update SkillEngine training session metrics
    await this.skillEngine.recordTrainingSession({
      skillId: task.skillId,
      subskillId: task.subskillId || null,
      durationMinutes: durationMin,
    });

    if (task.objectiveId) {
      await this._recomputeObjectiveProgressState(task.objectiveId);
    }

    return {
      task: updatedTask,
      evidence,
      objective: task.objectiveId
        ? await this.db.get('learning_objectives', task.objectiveId)
        : null,
    };
  }

  async recordLearningEvidence(input) {
    // Reject passive consumption as mastery evidence!
    if (
      input.type === 'watched_video' ||
      input.type === 'read_pdf' ||
      input.type === 'resource_consumption'
    ) {
      throw new Error(
        'Resource consumption (watching a video or reading a PDF) does not count as mastery evidence by itself.'
      );
    }

    const type = EVIDENCE_TYPES.includes(input.type)
      ? input.type
      : 'practical_demonstration';

    const nowIso = new Date().toISOString();
    const ev = await this.db.put('evidence', {
      id: input.id || `ev_learn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      objectiveId: input.objectiveId || null,
      skillId: input.skillId,
      subskillId: input.subskillId || null,
      taskId: input.taskId || null,
      testAttemptId: input.testAttemptId || null,
      type,
      title: input.title,
      content: input.content || '',
      qualityScore: Number(input.qualityScore ?? 90),
      createdAt: nowIso,
    });

    if (input.subskillId) {
      const sub = await this.db.get('subskills', input.subskillId);
      if (sub) {
        await this.db.put('subskills', {
          ...sub,
          evidence: [...new Set([...(sub.evidence || []), ev.id])],
          updatedAt: nowIso,
        });
      }
    }

    if (input.objectiveId) {
      await this._recomputeObjectiveProgressState(input.objectiveId);
    }
    await this.skillEngine.calculateSkillProgress(input.skillId);

    return ev;
  }

  // =========================================================================
  // 8. LEARNING TESTS, ERROR/REMEDIATION INTEGRATION & RETENTION REVIEWS
  // =========================================================================

  async createLearningTest(input) {
    const obj = input.objectiveId
      ? await this.db.get('learning_objectives', input.objectiveId)
      : null;

    return this.db.put('tests', {
      id: input.id || `ltest_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      objectiveId: input.objectiveId || null,
      skillId: input.skillId || obj?.skillId,
      subskillId: input.subskillId || obj?.subskillId || null,
      testType: input.testType || 'mastery',
      title: input.title || `اختبار إتقان الهدف: ${obj?.title || ''}`,
      description: input.description || '',
      passingScore: Number(input.passingScore ?? 85),
      minAccuracy: Number(input.minAccuracy ?? 80),
      questionsCount: Number(input.questionsCount ?? 10),
      createdAt: new Date().toISOString(),
    });
  }

  async recordLearningTestAttempt(input) {
    const obj = await this.assertObjectiveUnlocked(input.objectiveId);
    const confidence = Number(input.confidence ?? 80);
    const score = Number(input.score);
    const accuracy = Number(input.accuracy ?? score);
    const testType = input.testType || 'mastery';

    const calibration = evaluateMetacognitiveCalibration(confidence, Math.min(score, accuracy));

    // Delegate core attempt, error creation, and skill gate evaluation to Phase 2 SkillEngine
    const testRes = await this.skillEngine.recordTestAttempt({
      id: input.id,
      testId: input.testId || null,
      skillId: obj.skillId,
      subskillId: obj.subskillId || null,
      score,
      accuracy,
      evidence:
        input.evidence ||
        `[${testType.toUpperCase()} TEST] Objective: ${obj.title} (Score: ${score}%, Accuracy: ${accuracy}%)`,
      isRetest: Boolean(input.isRetest || input.linkedErrorId),
      linkedErrorId: input.linkedErrorId || null,
      errorCategory: input.errorCategory || 'conceptual',
      errorDescription:
        input.errorDescription ||
        `فشل في اختبار الهدف التعلمي "${obj.title}" (الدرجة: ${score}%، الدقة: ${accuracy}%)`,
      errorCause:
        input.errorCause ||
        (calibration.mismatchType === 'OVERCONFIDENT_ILLUSION_OF_COMPETENCE'
          ? `وهم الكفاءة (الثقة ${confidence}% مقابل الدقة الفعلية ${accuracy}%)`
          : 'ثغرة في الفهم التطبيقي أو الاسترجاع تحت الاختبار'),
    });

    // Enrich attempt & created error with objectiveId and metacognitive calibration
    const enrichedAttempt = await this.db.put('test_attempts', {
      ...testRes.attempt,
      objectiveId: obj.id,
      testType,
      confidence,
      calibrationDelta: calibration.calibrationDelta,
      metacognitiveMismatch: calibration.metacognitiveMismatch,
      mismatchType: calibration.mismatchType,
    });

    if (testRes.createdError) {
      await this.db.put('errors', {
        ...testRes.createdError,
        objectiveId: obj.id,
      });
    }

    await this._recomputeObjectiveProgressState(obj.id);
    await this.reconcileObjectiveStates();

    return {
      ...testRes,
      attempt: enrichedAttempt,
      calibration,
      objective: await this.db.get('learning_objectives', obj.id),
    };
  }

  async recordRetentionReview(input) {
    const obj = await this.db.get('learning_objectives', input.objectiveId);
    if (!obj) throw new Error(`Learning Objective not found: ${input.objectiveId}`);

    const reviewDate = input.reviewDate || new Date().toISOString().slice(0, 10);
    const score = Number(input.score);
    const confidence = Number(input.confidence ?? 80);
    const minRetentionScore = Number(input.minRetentionScore ?? 80);
    const passed = score >= minRetentionScore;
    const calibration = evaluateMetacognitiveCalibration(confidence, score);

    const sr = this.srScheduler.scheduleNextReview({
      recallScore: score,
      confidence,
      difficulty: obj.difficulty || 5,
      previousInterval: 14,
      repetitionCount: passed ? 2 : 0,
      reviewDate,
    });

    let retentionEvidence = null;
    let retentionError = null;
    let remediationBundle = null;

    if (passed) {
      retentionEvidence = await this.recordLearningEvidence({
        objectiveId: obj.id,
        skillId: obj.skillId,
        subskillId: obj.subskillId || null,
        type: 'retention',
        title: `مراجعة احتفاظ ناجحة (${score}%): ${obj.title}`,
        content: input.evidence || 'استرجاع وتطبيق كامل للمفهوم بعد فترة التباعد.',
        qualityScore: score,
      });

      await this.db.put('learning_objectives', {
        ...obj,
        status: 'MAINTENANCE',
        historicalMasteryAchieved: true,
        lastRetentionScore: score,
        nextReviewDate: sr.nextReviewDate,
        updatedAt: new Date().toISOString(),
      });

      await this.skillEngine.recordMaintenanceSession({
        skillId: obj.skillId,
        subskillId: obj.subskillId || null,
        reviewDate,
        score,
        retentionEvidence: input.evidence || `Retention review passed for ${obj.title}`,
      });
    } else {
      // RETENTION FAILURE: Preserve historicalMasteryAchieved = true and masteredAt,
      // but reopen learning/remediation path on the objective and create an Error + Corrective Task!
      retentionError = await this.db.put('errors', {
        id: `err_ret_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        skillId: obj.skillId,
        linkedSkill: obj.skillId,
        subskillId: obj.subskillId || null,
        linkedSubskill: obj.subskillId || null,
        objectiveId: obj.id,
        category: 'conceptual',
        severity: score < 50 ? 'high' : 'medium',
        description: `تراجع الاحتفاظ (Retention Decay: ${score}%) في الهدف المتقن سابقاً: ${obj.title}`,
        cause: 'تلاشي الذاكرة مع الوقت والحاجة إلى جلسة تنشيط واسترجاع موجهة',
        date: reviewDate,
        evidence: `Retention score ${score}% < ${minRetentionScore}%`,
        remediation: 'إعادة تنشيط المفهوم وحل تمرين تطبيقي ثم إعادة اختبار الاحتفاظ',
        status: 'open',
        retestRequired: true,
      });

      remediationBundle = await this.skillEngine.createRemediationPlan({
        errorId: retentionError.id,
        title: `خطة استعادة الاحتفاظ (Retention Recovery): ${obj.title}`,
        tasksSpec: [
          {
            title: `[Retention Recovery] تمرين استرجاع وتنشيط للهدف: ${obj.title}`,
            plannedDurationMin: 30,
          },
        ],
      });

      await this.db.put('learning_objectives', {
        ...obj,
        status: 'REMEDIATION',
        // Explicitly preserve historical mastery data!
        historicalMasteryAchieved: Boolean(obj.historicalMasteryAchieved || obj.masteredAt),
        masteredAt: obj.masteredAt || new Date().toISOString(),
        lastRetentionScore: score,
        nextReviewDate: sr.nextReviewDate,
        updatedAt: new Date().toISOString(),
      });
    }

    await this.skillEngine.calculateSkillProgress(obj.skillId);

    return {
      passed,
      score,
      calibration,
      nextReviewDate: sr.nextReviewDate,
      retentionEvidence,
      retentionError,
      remediationBundle,
      objective: await this.db.get('learning_objectives', obj.id),
    };
  }

  // =========================================================================
  // 9. OBJECTIVE STATE EVALUATION & LEARNING PROGRESS
  // =========================================================================

  async _recomputeObjectiveProgressState(objectiveId) {
    const obj = await this.db.get('learning_objectives', objectiveId);
    if (!obj) return null;

    const check = await this.checkObjectivePrerequisitesMet(obj);
    if (!check.allMet) {
      return this.db.put('learning_objectives', {
        ...obj,
        status: 'LOCKED',
        updatedAt: new Date().toISOString(),
      });
    }

    const [sessions, recalls, practiceTasks, evidence, attempts, errors] = await Promise.all([
      this.db.queryByField('learning_sessions', 'objectiveId', objectiveId),
      this.db.queryByField('recall_attempts', 'objectiveId', objectiveId),
      (await this.db.queryByField('tasks', 'skillId', obj.skillId)).filter(
        (t) => t.objectiveId === objectiveId
      ),
      (await this.db.queryByField('evidence', 'skillId', obj.skillId)).filter(
        (e) => e.objectiveId === objectiveId
      ),
      (await this.db.queryByField('test_attempts', 'skillId', obj.skillId)).filter(
        (a) => a.objectiveId === objectiveId
      ),
      (await this.db.queryByField('errors', 'skillId', obj.skillId)).filter(
        (er) => er.objectiveId === objectiveId && er.status !== 'resolved'
      ),
    ]);

    const passedRecalls = recalls.filter((r) => r.passed);
    const failedRecalls = recalls.filter((r) => !r.passed);
    const completedPractice = practiceTasks.filter((t) => t.status === 'completed');
    const verifiedEvidenceCount = evidence.length;
    const passedMasteryTests = attempts.filter(
      (a) => a.passed && (a.testType === 'mastery' || a.isRetest || !a.testType)
    );

    const nowIso = new Date().toISOString();
    let nextStatus = obj.status;

    if (errors.length > 0) {
      nextStatus = errors.some((e) => e.status === 'remediating' || e.status === 'escalated')
        ? 'REMEDIATION'
        : 'WEAK';
    } else if (
      passedMasteryTests.length > 0 &&
      (passedRecalls.length > 0 || completedPractice.length > 0) &&
      verifiedEvidenceCount > 0
    ) {
      nextStatus = obj.status === 'MAINTENANCE' ? 'MAINTENANCE' : 'MASTERED';
    } else if (passedMasteryTests.length > 0) {
      nextStatus = 'TESTED';
    } else if (failedRecalls.length > 0 && passedRecalls.length === 0) {
      nextStatus = 'WEAK';
    } else if (
      passedRecalls.length > 0 &&
      (completedPractice.length > 0 || verifiedEvidenceCount > 0)
    ) {
      nextStatus = 'READY_FOR_TEST';
    } else if (passedRecalls.length > 0) {
      nextStatus = 'RECALLING';
    } else if (completedPractice.length > 0 || practiceTasks.length > 0) {
      nextStatus = 'PRACTICING';
    } else if (sessions.length > 0) {
      nextStatus = sessions.length > 1 ? 'LEARNING' : 'EXPOSED';
    } else {
      nextStatus = 'NOT_STARTED';
    }

    const becameMastered =
      (nextStatus === 'MASTERED' || nextStatus === 'MAINTENANCE') &&
      !obj.historicalMasteryAchieved;

    const updatedObj = await this.db.put('learning_objectives', {
      ...obj,
      status: nextStatus,
      historicalMasteryAchieved: Boolean(obj.historicalMasteryAchieved || becameMastered),
      masteredAt: obj.masteredAt || (becameMastered ? nowIso : null),
      nextReviewDate:
        obj.nextReviewDate ||
        (becameMastered ? this.srScheduler.scheduleNextReview({ recallScore: 90, reviewDate: nowIso.slice(0, 10) }).nextReviewDate : null),
      updatedAt: nowIso,
    });

    if (nextStatus === 'MASTERED' || nextStatus === 'MAINTENANCE') {
      await this.reconcileObjectiveStates();
      await this.skillEngine.tryPromoteMastery(obj.skillId, obj.subskillId);
    }

    return updatedObj;
  }

  // =========================================================================
  // 10. LEARNING PATHS & "WHAT SHOULD I LEARN NEXT?" RECOMMENDATION ENGINE
  // =========================================================================

  async createLearningPath(input) {
    const pathRecord = {
      id: input.id || `lpath_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: input.title,
      description: input.description || '',
      goalId: input.goalId || null,
      capabilityId: input.capabilityId || 'cap-04-cs',
      skillId: input.skillId,
      subskillIds: Array.isArray(input.subskillIds) ? input.subskillIds : [],
      objectiveIds: Array.isArray(input.objectiveIds) ? input.objectiveIds : [],
      createdAt: new Date().toISOString(),
    };
    return this.db.put('learning_paths', pathRecord);
  }

  async getLearningPathStatus(pathId) {
    const pathRecord = await this.db.get('learning_paths', pathId);
    if (!pathRecord) return null;

    await this.reconcileObjectiveStates();
    const objectives = [];
    for (const objId of pathRecord.objectiveIds) {
      const o = await this.db.get('learning_objectives', objId);
      if (o) objectives.push(o);
    }

    const masteredCount = objectives.filter(
      (o) => o.status === 'MASTERED' || o.status === 'MAINTENANCE'
    ).length;
    const progressPct =
      objectives.length > 0 ? Math.round((masteredCount / objectives.length) * 100) : 0;

    const currentActiveObjective =
      objectives.find(
        (o) =>
          o.status !== 'LOCKED' &&
          o.status !== 'MASTERED' &&
          o.status !== 'MAINTENANCE'
      ) || null;

    return {
      ...pathRecord,
      objectives,
      masteredCount,
      totalObjectives: objectives.length,
      progressPct,
      currentActiveObjective,
    };
  }

  async getLearningRecommendations(currentDateStr = new Date().toISOString().slice(0, 10)) {
    await this.reconcileObjectiveStates();
    const [objectives, errors, remediations, flashcards, tasks] = await Promise.all([
      this.db.getAll('learning_objectives'),
      this.db.getAll('errors'),
      this.db.getAll('remediations'),
      this.db.getAll('flashcards'),
      this.db.getAll('tasks'),
    ]);

    const recommendations = [];

    // Priority 1: Open Errors / Active Remediations / Pending Corrective Tasks / Unlocked Retests
    for (const err of errors.filter((e) => e.status !== 'resolved')) {
      const rem = remediations.find((r) => r.errorId === err.id);
      if (rem && rem.retestAllowed) {
        recommendations.push({
          priority: 1,
          type: 'RETEST_READY',
          title: `إعادة الاختبار متاحة الآن لحل الخطأ: ${err.description}`,
          reason: 'أكملت المهام التصحيحية بنجاح — اجتز إعادة الاختبار لإغلاق الخطأ',
          skillId: err.skillId,
          subskillId: err.subskillId,
          objectiveId: err.objectiveId || null,
          errorId: err.id,
        });
      } else {
        const pendingCorrTask = tasks.find(
          (t) => t.errorId === err.id && t.status !== 'completed'
        );
        recommendations.push({
          priority: 1,
          type: 'REMEDIATION_REQUIRED',
          title: pendingCorrTask
            ? `إنجاز المهمة التصحيحية: ${pendingCorrTask.title}`
            : `معالجة الخطأ المفتوح: ${err.description}`,
          reason: 'الأخطاء المفتوحة تمنع الإتقان وتتطلب معالجة فورية',
          skillId: err.skillId,
          subskillId: err.subskillId,
          objectiveId: err.objectiveId || null,
          errorId: err.id,
          taskId: pendingCorrTask?.id || null,
        });
      }
    }

    // Priority 2: Overdue Objective Retention Reviews & Due Flashcards
    for (const obj of objectives) {
      if (
        (obj.status === 'MASTERED' || obj.status === 'MAINTENANCE') &&
        obj.nextReviewDate &&
        this.srScheduler.isOverdue(obj.nextReviewDate, currentDateStr)
      ) {
        recommendations.push({
          priority: 2,
          type: 'RETENTION_REVIEW_DUE',
          title: `مراجعة احتفاظ مستحقة: ${obj.title}`,
          reason: `حل موعد مراجعة الاحتفاظ (${obj.nextReviewDate}) لمنع تلاشي الإتقان`,
          skillId: obj.skillId,
          subskillId: obj.subskillId,
          objectiveId: obj.id,
        });
      }
    }

    const dueCards = flashcards.filter((c) =>
      this.srScheduler.isOverdue(c.nextReviewDate, currentDateStr)
    );
    if (dueCards.length > 0) {
      recommendations.push({
        priority: 2,
        type: 'FLASHCARDS_DUE',
        title: `مراجعة ${dueCards.length} بطاقة استرجاع متباعد (Spaced Repetition Flashcards)`,
        reason: 'بطاقات مستحقة للمراجعة اليوم لتثبيت الذاكرة طويلة المدى',
        skillId: dueCards[0].skillId,
        objectiveId: dueCards[0].objectiveId,
        dueCount: dueCards.length,
      });
    }

    // Priority 3: Weak Objectives needing Active Recall / Feynman / Practice
    for (const obj of objectives.filter((o) => o.status === 'WEAK')) {
      recommendations.push({
        priority: 3,
        type: 'STRENGTHEN_WEAK_OBJECTIVE',
        title: `تقوية الهدف الضعيف عبر Active Recall / Feynman: ${obj.title}`,
        reason: 'أداء الاسترجاع أو الشرح أقل من الحد المطلوب',
        skillId: obj.skillId,
        subskillId: obj.subskillId,
        objectiveId: obj.id,
      });
    }

    // Priority 4: Objectives Ready for Mastery Test
    for (const obj of objectives.filter((o) => o.status === 'READY_FOR_TEST')) {
      recommendations.push({
        priority: 4,
        type: 'TAKE_MASTERY_TEST',
        title: `خوض اختبار الإتقان للهدف الجاهز: ${obj.title}`,
        reason: 'أكملت الاسترجاع النشط والتطبيق العملي والدليل — جاهز لاختبار البوابة',
        skillId: obj.skillId,
        subskillId: obj.subskillId,
        objectiveId: obj.id,
      });
    }

    // Priority 5: Unlocked Active / Not-Started Objectives (NEVER recommend LOCKED objectives!)
    for (const obj of objectives.filter((o) =>
      ['EXPOSED', 'LEARNING', 'PRACTICING', 'RECALLING', 'NOT_STARTED'].includes(o.status)
    )) {
      const nextStepLabel =
        obj.status === 'NOT_STARTED'
          ? 'بدء جلسة تعلم أولية من المصدر'
          : obj.status === 'EXPOSED' || obj.status === 'LEARNING'
          ? 'تنفيذ استرجاع نشط (Active Recall) وتطبيق عملي (Practice)'
          : 'استكمال التطبيق وتوثيق الدليل (Evidence)';
      recommendations.push({
        priority: obj.status === 'NOT_STARTED' ? 6 : 5,
        type: 'ADVANCE_OBJECTIVE',
        title: `${nextStepLabel}: ${obj.title}`,
        reason: `الحالة الحالية (${obj.status}) — المخرج المستهدف: ${obj.targetOutcome}`,
        skillId: obj.skillId,
        subskillId: obj.subskillId,
        objectiveId: obj.id,
      });
    }

    return recommendations.sort((a, b) => a.priority - b.priority);
  }

  // =========================================================================
  // 11. REUSABLE LEARNING NOTES & OBJECTIVE DETAIL BUNDLE
  // =========================================================================

  async addNote(input) {
    const nowIso = new Date().toISOString();
    return this.db.put('learning_notes', {
      id: input.id || `note_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      targetType: input.targetType || 'objective',
      targetId: input.targetId,
      skillId: input.skillId || null,
      title: input.title || 'ملاحظة تعلمية',
      content: input.content,
      tags: Array.isArray(input.tags) ? input.tags : [],
      createdAt: nowIso,
      updatedAt: nowIso,
    });
  }

  async getNotesForTarget(targetType, targetId) {
    const all = await this.db.queryByField('learning_notes', 'targetId', targetId);
    return all.filter((n) => !targetType || n.targetType === targetType);
  }

  async getObjectiveDetailBundle(objectiveId) {
    const objective = await this.db.get('learning_objectives', objectiveId);
    if (!objective) return null;

    const [
      skill,
      subskill,
      prereqCheck,
      allResources,
      sessions,
      recalls,
      flashcards,
      feynmanEntries,
      allTasks,
      allEvidence,
      allTests,
      allAttempts,
      allErrors,
      allRemediations,
      notes,
    ] = await Promise.all([
      this.db.get('skills', objective.skillId),
      objective.subskillId ? this.db.get('subskills', objective.subskillId) : null,
      this.checkObjectivePrerequisitesMet(objective),
      this.db.getAll('resources'),
      this.db.queryByField('learning_sessions', 'objectiveId', objectiveId),
      this.db.queryByField('recall_attempts', 'objectiveId', objectiveId),
      this.db.queryByField('flashcards', 'objectiveId', objectiveId),
      this.db.queryByField('feynman_entries', 'objectiveId', objectiveId),
      this.db.queryByField('tasks', 'skillId', objective.skillId),
      this.db.queryByField('evidence', 'skillId', objective.skillId),
      this.db.queryByField('tests', 'skillId', objective.skillId),
      this.db.queryByField('test_attempts', 'skillId', objective.skillId),
      this.db.queryByField('errors', 'skillId', objective.skillId),
      this.db.queryByField('remediations', 'skillId', objective.skillId),
      this.getNotesForTarget('objective', objectiveId),
    ]);

    const linkedResources = allResources.filter(
      (r) =>
        (r.learningObjectives || []).includes(objectiveId) ||
        (r.subskillId && r.subskillId === objective.subskillId)
    );
    const practiceTasks = allTasks.filter((t) => t.objectiveId === objectiveId);
    const objectiveEvidence = allEvidence.filter((e) => e.objectiveId === objectiveId);
    const objectiveTests = allTests.filter(
      (t) => t.objectiveId === objectiveId || t.subskillId === objective.subskillId
    );
    const objectiveAttempts = allAttempts.filter(
      (a) => a.objectiveId === objectiveId || a.subskillId === objective.subskillId
    );
    const objectiveErrors = allErrors.filter(
      (er) => er.objectiveId === objectiveId || er.subskillId === objective.subskillId
    );
    const objectiveRemediations = allRemediations.filter((rem) =>
      objectiveErrors.some((er) => er.id === rem.errorId)
    );

    return {
      objective,
      skill,
      subskill,
      prereqCheck,
      resources: linkedResources,
      sessions,
      recalls,
      flashcards,
      feynmanEntries,
      practiceTasks,
      evidence: objectiveEvidence,
      tests: objectiveTests,
      attempts: objectiveAttempts,
      errors: objectiveErrors,
      remediations: objectiveRemediations,
      notes,
    };
  }
}
