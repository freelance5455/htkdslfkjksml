/* ==========================================================================
   habit-engine.js — عادت‌ها، اثر هر عادت روی هدف مالی، زنجیره‌ها
   ========================================================================== */

import { uid, todayKey, daysBetween, clamp, round, sum } from '../utils.js';
import { financeMetrics } from './financial-engine.js';
import { skillScore } from './scoring-engine.js';

export const HABIT_PRESETS = [
  { title: 'مطالعه ۲۰ صفحه', cat: 'یادگیری', minutes: 25, targetPerWeek: 6, icon: '📖' },
  { title: 'یادگیری مهارت درآمدزا', cat: 'مهارت', minutes: 60, targetPerWeek: 5, icon: '🎯' },
  { title: 'ورزش', cat: 'انرژی', minutes: 30, targetPerWeek: 4, icon: '🏃' },
  { title: 'پس‌انداز روزانه/هفتگی', cat: 'مالی', minutes: 5, targetPerWeek: 7, icon: '🪣' },
  { title: 'ثبت هزینه‌ها', cat: 'مالی', minutes: 3, targetPerWeek: 7, icon: '🧾' },
  { title: 'اقدام فروش (تماس/پیام)', cat: 'درآمد', minutes: 30, targetPerWeek: 5, icon: '🤝' },
  { title: 'شبکه‌سازی (یک ارتباط تازه)', cat: 'شبکه', minutes: 15, targetPerWeek: 3, icon: '🧑‍🤝‍🧑' },
  { title: 'تولید محتوا', cat: 'برند', minutes: 45, targetPerWeek: 3, icon: '🎥' },
  { title: 'کار روی کسب‌وکار', cat: 'کسب‌وکار', minutes: 60, targetPerWeek: 5, icon: '🏢' },
  { title: 'مرور مالی هفتگی', cat: 'مالی', minutes: 30, targetPerWeek: 1, icon: '📊' },
];

/** اثر هر عادت روی هدف مالی (۰-۱۰۰) */
export function habitImpact(state, habit) {
  const m = financeMetrics(state);
  const path = state.plan.pathId || '';
  const cat = habit.cat || 'مالی';
  let impact = 45;
  const table = {
    'مالی': 20, 'درآمد': 30, 'مهارت': 28, 'کسب‌وکار': 26, 'شبکه': 14, 'برند': 16, 'یادگیری': 18, 'انرژی': 10,
  };
  impact += table[cat] || 10;
  if (m.negativeFlow && cat === 'مالی') impact += 15;
  if (m.savingsRate < 0.1 && cat === 'مالی') impact += 12;
  if (m.incomeStreams < 2 && (cat === 'درآمد' || cat === 'کسب‌وکار')) impact += 12;
  if (skillScore(state) < 55 && cat === 'مهارت') impact += 12;
  if (path === 'freelancing' || path === 'service_business' || path === 'trade_business') { if (cat === 'درآمد' || cat === 'شبکه') impact += 8; }
  if (path === 'high_income_skill' && cat === 'مهارت') impact += 8;
  if (path === 'content_education' && (cat === 'برند' || cat === 'یادگیری')) impact += 10;
  if (path === 'longterm_investing' && cat === 'مالی') impact += 10;
  impact += clamp(((habit.streak || 0) - 7) * 0.6, -6, 8);
  return clamp(Math.round(impact), 5, 100);
}

export function streakOf(habit) {
  const hist = (habit.history || []).slice().sort();
  if (!hist.length) return 0;
  const set = new Set(hist);
  let cursor = todayKey();
  if (!set.has(cursor)) {
    const y = new Date(); y.setDate(y.getDate() - 1);
    cursor = y.getFullYear() + '-' + String(y.getMonth() + 1).padStart(2, '0') + '-' + String(y.getDate()).padStart(2, '0');
    if (!set.has(cursor)) return 0;
  }
  let streak = 0;
  while (set.has(cursor)) {
    streak++;
    const d = new Date(cursor);
    d.setDate(d.getDate() - 1);
    cursor = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  return streak;
}

export function toggleHabitToday(state, id) {
  const h = (state.habits || []).find((x) => x.id === id);
  if (!h) return null;
  const tk = todayKey();
  h.history = h.history || [];
  const i = h.history.indexOf(tk);
  if (i > -1) h.history.splice(i, 1);
  else h.history.push(tk);
  h.streak = streakOf(h);
  h.impact = habitImpact(state, h);
  return { habit: h, done: i === -1 };
}

export function suggestHabits(state) {
  const presets = HABIT_PRESETS.map((p) => ({
    ...p,
    impact: habitImpact(state, { ...p, streak: 0 }),
    exists: (state.habits || []).some((h) => h.title === p.title),
  }));
  return presets.sort((a, b) => b.impact - a.impact);
}

export function weeklyCompletion(state) {
  const habits = state.habits || [];
  const tk = todayKey();
  let hits = 0, target = 0;
  habits.forEach((h) => {
    target += h.targetPerWeek || 5;
    hits += (h.history || []).filter((d) => daysBetween(d, tk) >= 0 && daysBetween(d, tk) < 7).length;
  });
  return target ? round(hits / target, 2) : 0;
}

export function addHabit(state, data) {
  const h = {
    id: uid('h'), title: data.title || 'عادت جدید', cat: data.cat || 'مالی',
    minutes: +data.minutes || 15, targetPerWeek: +data.targetPerWeek || 5,
    icon: data.icon || '✅', history: [], streak: 0, createdAt: todayKey(),
  };
  h.impact = habitImpact(state, h);
  state.habits = state.habits || [];
  state.habits.push(h);
  return h;
}

export function habitTotals(state) {
  const habits = state.habits || [];
  return {
    count: habits.length,
    bestStreak: habits.reduce((a, b) => Math.max(a, b.streak || 0), 0),
    totalChecks: sum(habits, (h) => (h.history || []).length),
    avgImpact: habits.length ? round(sum(habits, (h) => h.impact || 0) / habits.length, 0) : 0,
  };
}
