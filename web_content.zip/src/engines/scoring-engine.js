/* ==========================================================================
   scoring-engine.js — Financial Freedom Score (۰ تا ۱۰۰۰) + عوامل محدودکننده
   ========================================================================== */

import { financeMetrics } from './financial-engine.js';
import { sum, round, clamp, daysBetween, todayKey } from '../utils.js';

export const COMPONENTS = [
  { key: 'income', label: 'درآمد', weight: 1.5 },
  { key: 'incomeGrowth', label: 'رشد درآمد', weight: 1.0 },
  { key: 'savings', label: 'پس‌انداز', weight: 1.2 },
  { key: 'savingsRate', label: 'نرخ پس‌انداز', weight: 1.4 },
  { key: 'assets', label: 'دارایی', weight: 1.2 },
  { key: 'debt', label: 'بدهی', weight: 1.2 },
  { key: 'investing', label: 'سرمایه‌گذاری', weight: 1.1 },
  { key: 'skill', label: 'مهارت', weight: 1.3 },
  { key: 'secondIncome', label: 'درآمد دوم', weight: 0.9 },
  { key: 'business', label: 'کسب‌وکار', weight: 0.9 },
  { key: 'costControl', label: 'مدیریت هزینه', weight: 1.0 },
  { key: 'risk', label: 'ریسک و امنیت', weight: 0.9 },
  { key: 'discipline', label: 'نظم مالی', weight: 1.0 },
  { key: 'habits', label: 'عادت‌ها', weight: 0.8 },
  { key: 'freeTime', label: 'زمان آزاد', weight: 0.7 },
  { key: 'network', label: 'شبکه ارتباطی', weight: 0.7 },
  { key: 'knowledge', label: 'دانش مالی', weight: 0.9 },
];

/** مهارت کاربر (۰-۱۰۰) بر اساس تخصص‌ها، تجربه و سطح مهارت‌های ثبت‌شده */
export function skillScore(state) {
  const p = state.profile;
  const declared = (p.skills || []).length;
  const levels = (state.skills || []);
  const avgLevel = levels.length ? levels.reduce((a, b) => a + (b.level || 0), 0) / levels.length : 0;
  const levelScore = levels.length ? (avgLevel / 5) * 70 : 0;
  const declScore = Math.min(30, declared * 6);
  const expBonus = clamp((+p.experienceYears || 0) * 2, 0, 20);
  return clamp(round(levelScore + declScore + (levels.length ? 0 : 10) + expBonus, 0), 5, 100);
}

export function taskCompletionRate(state, days = 14) {
  let total = 0, done = 0;
  for (let i = 1; i <= days; i++) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const day = (state.plan.days || {})[key];
    if (day && day.tasks && day.tasks.length) {
      total += day.tasks.length;
      done += day.tasks.filter((t) => t.done).length;
    }
  }
  return total ? done / total : 0;
}

export function habitScore(state) {
  const habits = state.habits || [];
  if (!habits.length) return 10;
  const last7 = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(); d.setDate(d.getDate() - i);
    last7.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
  }
  const hits = sum(habits, (h) => last7.filter((k) => (h.history || []).indexOf(k) > -1).length);
  const max = habits.length * 7;
  return clamp(round((hits / max) * 100, 0), 0, 100);
}

export function computeScore(state) {
  const m = financeMetrics(state);
  const annualExpense = Math.max(1, m.annualExpense);
  const sk = skillScore(state);
  const tc = taskCompletionRate(state);
  const hs = habitScore(state);

  const v = {
    income: clamp(round((m.income / Math.max(1, annualExpense / 12)) * 12, 0), 0, 100), // درآمد نسبت به هزینه
    incomeGrowth: clamp(round((m.incomeStreams >= 2 ? 60 : 25) + (state.profile.incomeGoal ? (m.income >= state.profile.incomeGoal ? 40 : 10) : 15), 0), 0, 100),
    savings: clamp(round((m.savings > 0 ? Math.min(100, (m.savings / Math.max(1, m.income)) * 250) : 0), 0), 0, 100),
    savingsRate: clamp(round(m.savingsRate * 250, 0), 0, 100),
    assets: clamp(round((m.netWorthYears > 0 ? Math.min(100, m.netWorthYears * 33) : 0), 0), 0, 100),
    debt: clamp(round(100 - m.debtToIncome * 250, 0), 0, 100),
    investing: clamp(round(m.investRatio * 200 + (m.investable > m.annualExpense ? 35 : 5), 0), 0, 100),
    skill: sk,
    secondIncome: clamp(round(m.incomeStreams >= 2 ? 80 : 15, 0), 0, 100),
    business: clamp(round((state.profile.job === 'business' ? 80 : 20) + (m.incomeStreams >= 3 ? 20 : 0), 0), 0, 100),
    costControl: clamp(round(100 - Math.min(100, (m.discretionary / Math.max(1, m.expense)) * 130), 0), 0, 100),
    risk: clamp(round(Math.min(60, m.runwayMonths * 12) + (m.hasDebt ? 0 : 40), 0), 0, 100),
    discipline: clamp(round((state.finance.transactions || []).length > 10 ? 70 : 30 + tc * 30, 0), 0, 100),
    habits: hs,
    freeTime: clamp(round((+state.profile.freeHours || 0) * 12.5, 0), 0, 100),
    network: clamp(round(Math.min(100, (state.profile.networkActions || 0) * 12 + 20), 0), 0, 100),
    knowledge: clamp(round(Math.min(100, (state.learning.booksRead || 0) * 8 + (state.learning.lessonsDone || 0) * 3 + 20), 0), 0, 100),
  };

  const totalWeight = COMPONENTS.reduce((a, c) => a + c.weight, 0);
  let weighted = 0;
  const components = COMPONENTS.map((c) => {
    const val = clamp(v[c.key] || 0, 0, 100);
    const contribution = (val / 100) * c.weight;
    weighted += contribution;
    return { ...c, value: val, contribution: round(contribution, 2), score: Math.round((val / 100) * 1000 * (c.weight / totalWeight)) };
  });
  const total = Math.round((weighted / totalWeight) * 1000);
  const limiters = topLimiters(state, components, m, tc);
  return {
    total: clamp(total, 0, 1000),
    grade: gradeOf(total),
    components: components.sort((a, b) => a.value - b.value),
    limiters,
    taskCompletion: round(tc * 100, 0),
    metrics: m,
    at: todayKey(),
  };
}

function gradeOf(total) {
  if (total >= 850) return 'Financial Master';
  if (total >= 700) return 'Wealth Builder';
  if (total >= 550) return 'Investor';
  if (total >= 400) return 'Entrepreneur';
  if (total >= 250) return 'Builder';
  if (total >= 120) return 'Explorer';
  return 'Beginner';
}

/** سه عامل اصلی محدودکننده سرعت ثروت‌سازی */
export function topLimiters(state, components, m, tc) {
  const out = [];
  const comp = (k) => components.find((c) => c.key === k) || { value: 0, label: k };

  if (m.negativeFlow) out.push({ key: 'negative_flow', label: 'جریان نقدی منفی', value: comp('costControl').value, why: 'هزینه ماهانه از درآمد بیشتر است؛ در این حالت هیچ مسیری اجرا نمی‌شود.', fix: 'سه هزینه بزرگ را کاهش بده یا درآمد را در ۶۰ روز افزایش بده.' });
  if (m.savingsRate < 0.1 && m.income > 0) out.push({ key: 'saving_system', label: 'نبود سیستم پس‌انداز', value: comp('savingsRate').value, why: 'نرخ پس‌انداز زیر ۱۰٪ است؛ سرعت انباشت بسیار پایین است.', fix: 'انتقال خودکار پس‌انداز در روز دریافت درآمد تنظیم کن.' });
  if (skillScore(state) < 50) out.push({ key: 'skill', label: 'کمیابی مهارت درآمدزا', value: comp('skill').value, why: 'مهارت‌های ثبت‌شده یا سطح آن‌ها برای قیمت‌گذاری بالا کافی نیست.', fix: 'یک مهارت پرتقاضا را ۹۰ روز تمرین و اثبات کن.' });
  if (m.incomeStreams < 2) out.push({ key: 'second_income', label: 'تک‌منبعی بودن درآمد', value: comp('secondIncome').value, why: 'همه درآمد از یک منبع می‌آید و شکننده است.', fix: 'یک منبع درآمد دوم با ۴ ساعت در هفته بساز.' });
  if (m.debtToIncome > 0.3) out.push({ key: 'debt', label: 'سنگینی قسط‌ها', value: comp('debt').value, why: 'بیش از ۳۰٪ درآمد صرف قسط می‌شود؛ سرمایه‌گذاری ممکن نیست.', fix: 'روش بهمن/گلوله برفی را اجرا و نرخ بهره بالا را اول ببند.' });
  if (m.runwayMonths < 3) out.push({ key: 'emergency', label: 'صندوق اضطراری ناکافی', value: comp('risk').value, why: 'کمتر از ۳ ماه هزینه نقد داری؛ هر شوک، برنامه را می‌شکند.', fix: 'اول هدف موقت: هزینه ۳ ماه.' });
  if (m.investable <= m.annualExpense * 0.3) out.push({ key: 'investing', label: 'نبود سرمایه‌گذاری', value: comp('investing').value, why: 'سرمایه درآمدزا تقریباً صفر است؛ تورم ارزش پول را می‌خورد.', fix: 'پس از صندوق اضطراری، پس‌انداز را به دارایی درآمدزا تبدیل کن.' });
  if ((+state.profile.freeHours || 0) < 1) out.push({ key: 'time', label: 'کمبود زمان قابل استفاده', value: comp('freeTime').value, why: 'بدون زمان، هیچ مسیری اجرا نمی‌شود.', fix: 'روزی ۶۰ دقیقه با حذف یک فعالیت کم‌ارزش آزاد کن.' });
  if (tc < 0.5) out.push({ key: 'execution', label: 'ضعف اجرا (نه دانش)', value: 100 - round(tc * 100, 0), why: 'کمتر از نیمی از کارهای برنامه‌ریزی‌شده انجام می‌شود.', fix: 'کارهای روز را به ۳ مورد کاهش بده و یک کار غالب انتخاب کن.' });

  const fallback = components.slice(0, 3).map((c) => ({ key: c.key, label: c.label, value: c.value, why: 'این مؤلفه در وضعیت پایینی است.', fix: 'برنامه مربوط به آن را در «مسیر من» اجرا کن.' }));
  while (out.length < 3 && fallback.length) out.push(fallback.shift());
  return out.slice(0, 3);
}

/** احتمال تحقق هدف (مدل داخلی، نه پیش‌بینی علمی) */
export function goalProbability(state, goal, ctx) {
  const m = ctx && ctx.metrics ? ctx.metrics : financeMetrics(state);
  const months = goal && goal.deadline ? Math.max(1, daysBetween(todayKey(), goal.deadline) / 30) : 24;
  const gap = Math.max(0, (goal.targetAmount || 0) - Math.max(0, m.netWorth));
  const neededMonthly = gap / months;
  const capacity = Math.max(0, m.savings);
  const capacityRatio = neededMonthly > 0 ? capacity / neededMonthly : 2;
  const sk = skillScore(state);
  const exec = taskCompletionRate(state);
  const streak = (state.streak && state.streak.current) || 0;

  let p = 30;
  p += clamp(capacityRatio * 22, -18, 30);
  p += (sk - 50) * 0.22;
  p += (exec - 0.5) * 24;
  p += clamp(streak * 0.5, 0, 8);
  if (m.negativeFlow) p -= 20;
  if (m.debtToIncome > 0.4) p -= 8;
  if ((+state.profile.freeHours || 0) >= 2) p += 4;
  if (goal.custom && goal.custom.monthlyIncomeTarget) {
    const incRatio = m.income / Math.max(1, goal.custom.monthlyIncomeTarget);
    p += clamp((incRatio - 1) * 15, -25, 12);
  }
  return clamp(Math.round(p), 3, 92);
}
