/**
 * WHITE ROOM OS — Time Management & College Schedule Engine
 * Calculates daily time budgets, college commitments, free time, and energy-adjusted deep work capacity.
 */

import { DAYS_OF_WEEK } from '../core/schema.js';
import { DEFAULT_SCHEDULE_CONFIG } from '../data/seed.js';

export function parseTimeHHMM(hhmm) {
  const [h, m] = String(hhmm || '00:00').split(':').map(Number);
  return h + (m || 0) / 60;
}

export function getDayNameFromDateString(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return DAYS_OF_WEEK[dt.getUTCDay()];
}

export class TimeManagementEngine {
  constructor(db) {
    this.db = db;
  }

  async getScheduleConfig() {
    const existing = await this.db.get('schedule_config', 'default_schedule');
    if (existing) return existing;
    await this.db.put('schedule_config', DEFAULT_SCHEDULE_CONFIG);
    return structuredClone(DEFAULT_SCHEDULE_CONFIG);
  }

  async updateScheduleConfig(updates) {
    const current = await this.getScheduleConfig();
    const updated = {
      ...current,
      ...updates,
      id: 'default_schedule',
      updatedAt: new Date().toISOString(),
    };
    return this.db.put('schedule_config', updated);
  }

  calculateDayBudget(scheduleConfig, dateStr, energyLevel = 7) {
    const dayName = getDayNameFromDateString(dateStr);
    const isCollegeDay = scheduleConfig.collegeDays.includes(dayName);

    const startH = parseTimeHHMM(scheduleConfig.collegeStart);
    const endH = parseTimeHHMM(scheduleConfig.collegeEnd);
    const rawCollegeHours = endH >= startH ? endH - startH : 24 - startH + endH;
    const collegeHours = isCollegeDay ? Number(rawCollegeHours.toFixed(2)) : 0;

    const sleepHours = Number(scheduleConfig.sleepHours);
    const mealsAndPrayerHours = Number(scheduleConfig.mealsAndPrayerHours);
    const otherCommitmentsHours = Number(scheduleConfig.otherCommitmentsHours);

    const totalCommittedHours = Number(
      (collegeHours + sleepHours + mealsAndPrayerHours + otherCommitmentsHours).toFixed(2)
    );
    const netFreeHours = Number(Math.max(0, 24 - totalCommittedHours).toFixed(2));

    // Scale deep work capacity by whether it's a college day and current energy (1..10)
    const baseCap = isCollegeDay
      ? Number(scheduleConfig.collegeDayDeepWorkCapHours || Math.min(2.0, netFreeHours * 0.6))
      : Number(scheduleConfig.deepWorkCapacityHours);

    const energyMultiplier = Math.max(0.4, Math.min(1.15, 0.5 + (energyLevel / 10) * 0.6));
    const recommendedDeepWorkHours = Number(
      Math.min(netFreeHours, baseCap * energyMultiplier).toFixed(2)
    );

    const recommendedTotalMissionMin = Math.round(
      Math.min(netFreeHours * 60 * 0.85, recommendedDeepWorkHours * 60 + 60)
    );

    return {
      date: dateStr,
      dayName,
      isCollegeDay,
      collegeWindow: isCollegeDay ? `${scheduleConfig.collegeStart}–${scheduleConfig.collegeEnd}` : 'يوم حر (بدون كلية)',
      collegeHours,
      sleepHours,
      mealsAndPrayerHours,
      otherCommitmentsHours,
      totalCommittedHours,
      netFreeHours,
      energyLevel,
      recommendedDeepWorkHours,
      recommendedTotalMissionMin,
    };
  }
}
