/**
 * WHITE ROOM OS — Phase 2 + Phase 5 Skill, Mastery Gate, Maintenance & 5D Progress Engine
 * Implements the complete operational cycle:
 * Skill -> Subskills -> Prerequisites (LOCKED / AVAILABLE / IN_PROGRESS / MASTERED / MAINTENANCE)
 * -> Curriculum -> Training -> Evidence -> Tests -> Configurable Domain Mastery Gates (with Traceable Explanation)
 * -> Failure -> Error -> Remediation -> Corrective Tasks -> Verified Retest
 * -> Historical Mastery Transition (`mastery_history`) -> Maintenance & Retention -> Distinct 5D Progress (Zero Double-Counting)
 */

import {
  normalizeSkillRecord,
  normalizeSubskillRecord,
  normalizeErrorCategory,
} from '../core/schema.js';

function addDaysToDateStr(dateStr, days) {
  const base = dateStr ? new Date(`${dateStr}T12:00:00Z`) : new Date();
  base.setUTCDate(base.getUTCDate() + Number(days || 14));
  return base.toISOString().slice(0, 10);
}

// Explicit Evidence Partitioning Sets to guarantee ZERO double-counting across the 5 progress metrics
export const LEARNING_EVIDENCE_TYPES = Object.freeze([
  'learning',
  'study',
  'feynman',
  'training',
  'practice',
  'worked_example',
  'summary',
]);

export const COMPETENCE_EVIDENCE_TYPES = Object.freeze([
  'test',
  'retest',
  'practical_demonstration',
  'independent_application',
  'project_artifact',
  'problem_set_solution',
  'tactical_analysis',
  'oral_written_production',
]);

export const RETENTION_EVIDENCE_TYPES = Object.freeze([
  'retention',
  'maintenance_review',
  'delayed_retention_check',
]);

export class SkillEngine {
  constructor(db) {
    this.db = db;
  }

  // =========================================================================
  // 1. SKILL & SUBSKILL CREATION + CURRICULUM
  // =========================================================================

  async createSkill(input) {
    const nowIso = new Date().toISOString();
    const record = normalizeSkillRecord({
      id: input.id || `skill_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: input.name,
      nameAr: input.nameAr || input.name,
      description: input.description || `تطوير وإتقان مهارة ${input.name}`,
      capabilityId: input.capabilityId || input.domain || 'cap-04-cs',
      domain: input.domain || input.capabilityId || 'cap-04-cs',
      goalId: input.goalId || null,
      currentLevel: Number(input.currentLevel ?? 1),
      targetLevel: Number(input.targetLevel ?? 8),
      status: input.status || 'AVAILABLE',
      priority: Number(input.priority ?? 2),
      prerequisites: Array.isArray(input.prerequisites) ? input.prerequisites : [],
      subskills: Array.isArray(input.subskills) ? input.subskills : [],
      masteryCriteria: input.masteryCriteria || {},
      maintenanceCriteria: input.maintenanceCriteria || {},
      historicalMasteryAchieved: Boolean(input.historicalMasteryAchieved),
      firstMasteredAt: input.firstMasteredAt || null,
      currentRetentionStatus: input.currentRetentionStatus || 'UNMASTERED',
      metrics: input.metrics || {},
      createdAt: input.createdAt || nowIso,
      updatedAt: nowIso,
    });

    // Enforce initial prerequisite lock check
    const prereqCheck = await this.checkPrerequisitesMet('skill', record.prerequisites);
    if (!prereqCheck.allMet) {
      record.status = 'LOCKED';
    } else if (record.status === 'LOCKED') {
      record.status = 'AVAILABLE';
    }

    const saved = await this.db.put('skills', record);
    await this.calculateSkillProgress(saved.id);
    return this.db.get('skills', saved.id);
  }

  async createSubskill(input) {
    const skill = await this.db.get('skills', input.skillId);
    if (!skill) {
      throw new Error(`Parent skill not found: ${input.skillId}`);
    }

    const nowIso = new Date().toISOString();
    const record = normalizeSubskillRecord({
      id: input.id || `sub_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      skillId: input.skillId,
      name: input.name,
      description: input.description || `مهارة فرعية ضمن ${skill.name}`,
      level: Number(input.level ?? 1),
      prerequisites: Array.isArray(input.prerequisites) ? input.prerequisites : [],
      training: input.training || {},
      evidence: Array.isArray(input.evidence) ? input.evidence : [],
      tests: Array.isArray(input.tests) ? input.tests : [],
      masteryState: input.masteryState || 'AVAILABLE',
      masteryCriteria: input.masteryCriteria || {},
      historicalMasteryAchieved: Boolean(input.historicalMasteryAchieved),
      firstMasteredAt: input.firstMasteredAt || null,
      currentRetentionStatus: input.currentRetentionStatus || 'UNMASTERED',
      errors: Array.isArray(input.errors) ? input.errors : [],
      remediation: Array.isArray(input.remediation) ? input.remediation : [],
      maintenance: input.maintenance || {},
      createdAt: input.createdAt || nowIso,
      updatedAt: nowIso,
    });

    // If parent skill is LOCKED or subskill prerequisites are not met -> LOCKED
    const prereqCheck = await this.checkPrerequisitesMet('subskill', record.prerequisites);
    if (skill.status === 'LOCKED' || !prereqCheck.allMet) {
      record.masteryState = 'LOCKED';
    } else if (record.masteryState === 'LOCKED') {
      record.masteryState = 'AVAILABLE';
    }

    const savedSub = await this.db.put('subskills', record);

    // Link subskill ID to parent skill if not already linked
    if (!skill.subskills.includes(savedSub.id)) {
      const updatedSkill = {
        ...skill,
        subskills: [...skill.subskills, savedSub.id],
        updatedAt: nowIso,
      };
      await this.db.put('skills', updatedSkill);
    }

    await this.calculateSkillProgress(skill.id);
    return savedSub;
  }

  async addCurriculumUnit(input) {
    const unit = {
      id: input.id || `curr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      skillId: input.skillId,
      subskillId: input.subskillId || null,
      title: input.title,
      order: Number(input.order ?? 1),
      completed: Boolean(input.completed),
    };
    const saved = await this.db.put('curriculum', unit);
    await this.calculateSkillProgress(input.skillId);
    return saved;
  }

  async toggleCurriculumUnit(unitId, completed = true) {
    const unit = await this.db.get('curriculum', unitId);
    if (!unit) throw new Error(`Curriculum unit not found: ${unitId}`);
    const updated = await this.db.put('curriculum', { ...unit, completed: Boolean(completed) });
    await this.calculateSkillProgress(unit.skillId);
    return updated;
  }

  // =========================================================================
  // 2. PREREQUISITES & STATE TRANSITIONS (LOCKED / AVAILABLE / IN_PROGRESS / MASTERED / MAINTENANCE)
  // =========================================================================

  async checkPrerequisitesMet(entityType, prerequisiteIds = []) {
    if (!Array.isArray(prerequisiteIds) || prerequisiteIds.length === 0) {
      return { allMet: true, unmetIds: [], details: [] };
    }

    const storeName = entityType === 'skill' ? 'skills' : 'subskills';
    const unmetIds = [];
    const details = [];

    for (const prereqId of prerequisiteIds) {
      const item = await this.db.get(storeName, prereqId);
      const state = entityType === 'skill' ? item?.status : item?.masteryState;
      const isMet = state === 'MASTERED' || state === 'MAINTENANCE';
      details.push({
        id: prereqId,
        name: item?.nameAr || item?.name || prereqId,
        state: state || 'MISSING',
        isMet,
      });
      if (!isMet) {
        unmetIds.push(prereqId);
      }
    }

    return {
      allMet: unmetIds.length === 0,
      unmetIds,
      details,
    };
  }

  async assertUnlocked(entityType, entityId) {
    if (entityType === 'skill') {
      const skill = await this.db.get('skills', entityId);
      if (!skill) throw new Error(`Skill not found: ${entityId}`);
      const prereq = await this.checkPrerequisitesMet('skill', skill.prerequisites);
      if (skill.status === 'LOCKED' || !prereq.allMet) {
        throw new Error(
          `Skill "${skill.name}" is LOCKED. Unmet prerequisites: ${prereq.unmetIds.join(', ')}`
        );
      }
      return skill;
    }

    const sub = await this.db.get('subskills', entityId);
    if (!sub) throw new Error(`Subskill not found: ${entityId}`);
    const parentSkill = await this.db.get('skills', sub.skillId);
    if (parentSkill) {
      const parentPrereq = await this.checkPrerequisitesMet('skill', parentSkill.prerequisites);
      if (parentSkill.status === 'LOCKED' || !parentPrereq.allMet) {
        throw new Error(`Parent Skill "${parentSkill.name}" is LOCKED.`);
      }
    }
    const subPrereq = await this.checkPrerequisitesMet('subskill', sub.prerequisites);
    if (sub.masteryState === 'LOCKED' || !subPrereq.allMet) {
      throw new Error(
        `Subskill "${sub.name}" is LOCKED. Unmet prerequisites: ${subPrereq.unmetIds.join(', ')}`
      );
    }
    return sub;
  }

  async reconcilePrerequisiteLocks() {
    const skills = await this.db.getAll('skills');
    const subskills = await this.db.getAll('subskills');

    // Reconcile Skills first
    for (const sk of skills) {
      const norm = normalizeSkillRecord(sk);
      const check = await this.checkPrerequisitesMet('skill', norm.prerequisites);
      let nextStatus = norm.status;
      if (!check.allMet) {
        nextStatus = 'LOCKED';
      } else if (norm.status === 'LOCKED') {
        nextStatus = 'AVAILABLE';
      }
      if (nextStatus !== sk.status) {
        await this.db.put('skills', {
          ...norm,
          status: nextStatus,
          updatedAt: new Date().toISOString(),
        });
      }
    }

    const updatedSkillsMap = {};
    for (const s of await this.db.getAll('skills')) {
      updatedSkillsMap[s.id] = s;
    }

    // Reconcile Subskills
    for (const sub of subskills) {
      const normSub = normalizeSubskillRecord(sub);
      const parentSkill = updatedSkillsMap[normSub.skillId];
      const check = await this.checkPrerequisitesMet('subskill', normSub.prerequisites);
      let nextState = normSub.masteryState;

      if (parentSkill?.status === 'LOCKED' || !check.allMet) {
        nextState = 'LOCKED';
      } else if (normSub.masteryState === 'LOCKED') {
        nextState = 'AVAILABLE';
      }

      if (nextState !== sub.masteryState) {
        await this.db.put('subskills', {
          ...normSub,
          masteryState: nextState,
          updatedAt: new Date().toISOString(),
        });
      }
    }
  }

  // =========================================================================
  // 3. TRAINING & EVIDENCE RECORDING
  // =========================================================================

  async recordTrainingSession(payload) {
    const {
      skillId,
      subskillId,
      durationMinutes = 30,
      evidenceTitle,
      evidenceContent,
      evidenceType = 'training',
      independentApplication = false,
      qualityScore = 85,
    } = payload;

    const skill = await this.assertUnlocked('skill', skillId);
    let subskill = null;
    if (subskillId) {
      subskill = await this.assertUnlocked('subskill', subskillId);
    }

    const nowIso = new Date().toISOString();
    let createdEvidence = null;

    if (evidenceTitle) {
      createdEvidence = await this.db.put('evidence', {
        id: payload.evidenceId || `ev_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        skillId,
        subskillId: subskillId || null,
        type: evidenceType,
        independentApplication: Boolean(
          independentApplication ||
            evidenceType === 'independent_application' ||
            evidenceType === 'practical_demonstration'
        ),
        title: evidenceTitle,
        content: evidenceContent || '',
        qualityScore: Number(qualityScore),
        createdAt: nowIso,
      });
    }

    if (subskill) {
      const nextSubState =
        subskill.masteryState === 'AVAILABLE' ? 'IN_PROGRESS' : subskill.masteryState;
      const updatedSub = {
        ...subskill,
        masteryState: nextSubState,
        training: {
          ...subskill.training,
          completedSessions: (subskill.training?.completedSessions || 0) + 1,
          totalMinutes: (subskill.training?.totalMinutes || 0) + Number(durationMinutes),
        },
        evidence: createdEvidence
          ? [...new Set([...(subskill.evidence || []), createdEvidence.id])]
          : subskill.evidence,
        updatedAt: nowIso,
      };
      await this.db.put('subskills', updatedSub);
    }

    const nextSkillStatus =
      skill.status === 'AVAILABLE' ? 'IN_PROGRESS' : skill.status;
    const allSkillEv = await this.db.queryByField('evidence', 'skillId', skillId);

    const updatedSkill = {
      ...skill,
      status: nextSkillStatus,
      metrics: {
        ...skill.metrics,
        totalPracticeMinutes: (skill.metrics?.totalPracticeMinutes || 0) + Number(durationMinutes),
        trainingSessionsCount: (skill.metrics?.trainingSessionsCount || 0) + 1,
        evidenceCount: allSkillEv.length,
        lastPracticedDate: nowIso.slice(0, 10),
      },
      updatedAt: nowIso,
    };
    await this.db.put('skills', updatedSkill);
    await this.calculateSkillProgress(skillId);

    return {
      skill: await this.db.get('skills', skillId),
      subskill: subskillId ? await this.db.get('subskills', subskillId) : null,
      evidence: createdEvidence,
    };
  }

  // =========================================================================
  // 4. CONFIGURABLE DOMAIN MASTERY GATES & HISTORICAL MASTERY PRESERVATION
  // =========================================================================

  async _recordMasteryHistoryEvent(eventPayload) {
    const stores = await this.db.listStores();
    if (!stores.includes('mastery_history')) return null;

    const record = {
      id:
        eventPayload.id ||
        `mh_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      entityType: eventPayload.entityType || 'skill',
      entityId: eventPayload.entityId,
      skillId: eventPayload.skillId,
      subskillId: eventPayload.subskillId || null,
      eventType: eventPayload.eventType || 'MASTERY_ACHIEVED',
      previousState: eventPayload.previousState || 'IN_PROGRESS',
      newState: eventPayload.newState || 'MASTERED',
      historicalMasteryPreserved: eventPayload.historicalMasteryPreserved !== false,
      currentRetentionStatus: eventPayload.currentRetentionStatus || 'ACTIVE_MASTERY',
      gateSnapshot: eventPayload.gateSnapshot || {},
      supportingEvidenceIds: Array.isArray(eventPayload.supportingEvidenceIds)
        ? eventPayload.supportingEvidenceIds
        : [],
      decisionExplanation: eventPayload.decisionExplanation || '',
      timestamp: eventPayload.timestamp || new Date().toISOString(),
    };
    return this.db.put('mastery_history', record);
  }

  async evaluateMasteryGate(entityType, entityId) {
    if (entityType === 'subskill') {
      const rawSub = await this.db.get('subskills', entityId);
      if (!rawSub) throw new Error(`Subskill not found: ${entityId}`);
      const sub = normalizeSubskillRecord(rawSub);
      const criteria = sub.masteryCriteria;

      const prereqCheck = await this.checkPrerequisitesMet('subskill', sub.prerequisites);
      const attempts = (await this.db.queryByField('test_attempts', 'subskillId', sub.id)).sort(
        (a, b) => String(a.timestamp).localeCompare(String(b.timestamp))
      );
      const passedAttempts = attempts.filter((a) => a.passed);
      const bestScore = attempts.reduce((max, a) => Math.max(max, a.score || 0), 0);
      const bestAccuracy = attempts.reduce((max, a) => Math.max(max, a.accuracy || 0), 0);

      const evRecords = await this.db.queryByField('evidence', 'subskillId', sub.id);
      const evidenceCount = Math.max(sub.evidence.length, evRecords.length);
      const recordedEvidenceTypes = [...new Set(evRecords.map((e) => e.type).filter(Boolean))];
      const consistencyCount = sub.training?.completedSessions || 0;

      const subErrors = await this.db.queryByField('errors', 'subskillId', sub.id);
      const unresolvedErrors = subErrors.filter((e) => e.status !== 'resolved');

      // Domain-specific evidence types check (if configured)
      const reqTypes = Array.isArray(criteria.requiredEvidenceTypes)
        ? criteria.requiredEvidenceTypes
        : [];
      const missingEvidenceTypes = reqTypes.filter((t) => !recordedEvidenceTypes.includes(t));
      const domainEvidenceTypesMet = missingEvidenceTypes.length === 0;

      // Independent application check (if configured)
      const hasIndependentApp =
        evRecords.some(
          (e) =>
            e.independentApplication ||
            e.type === 'independent_application' ||
            e.type === 'practical_demonstration'
        ) ||
        passedAttempts.some(
          (a) =>
            a.verificationMode === 'independent_performance' ||
            a.verificationMode === 'practical_demonstration' ||
            a.independentApplication === true
        );
      const independentApplicationMet = criteria.requireIndependentApplication
        ? hasIndependentApp
        : true;

      const checks = {
        prerequisiteMastery: criteria.prerequisiteMastery ? prereqCheck.allMet : true,
        minTestScore: bestScore >= criteria.minTestScore,
        minAccuracy: bestAccuracy >= criteria.minAccuracy,
        minSuccessfulAttempts: passedAttempts.length >= criteria.minSuccessfulAttempts,
        consistency: consistencyCount >= criteria.consistency,
        requiredEvidence: evidenceCount >= criteria.requiredEvidenceCount,
        domainEvidenceTypes: domainEvidenceTypesMet,
        independentApplication: independentApplicationMet,
        noUnresolvedErrors: unresolvedErrors.length === 0,
      };

      const blockingReasons = [];
      if (!checks.prerequisiteMastery) blockingReasons.push('المتطلبات السابقة غير مكتملة');
      if (!checks.minTestScore)
        blockingReasons.push(
          `أعلى درجة اختبار (${bestScore}%) أقل من الشرط (${criteria.minTestScore}%)`
        );
      if (!checks.minAccuracy)
        blockingReasons.push(
          `الدقة (${bestAccuracy}%) أقل من الشرط (${criteria.minAccuracy}%)`
        );
      if (!checks.minSuccessfulAttempts)
        blockingReasons.push(
          `عدد المحاولات الناجحة (${passedAttempts.length}) أقل من (${criteria.minSuccessfulAttempts})`
        );
      if (!checks.consistency)
        blockingReasons.push(
          `جلسات التدريب (${consistencyCount}) أقل من شرط الاستمرارية (${criteria.consistency})`
        );
      if (!checks.requiredEvidence)
        blockingReasons.push(
          `الأدلة الموثقة (${evidenceCount}) أقل من (${criteria.requiredEvidenceCount})`
        );
      if (!checks.domainEvidenceTypes)
        blockingReasons.push(
          `ينقص نوع دليل تخصصي مطلوب للمجال: (${missingEvidenceTypes.join(', ')})`
        );
      if (!checks.independentApplication)
        blockingReasons.push(
          'يتطلب إثبات تطبيق مستقل (Independent Application / Practical Demonstration)'
        );
      if (!checks.noUnresolvedErrors)
        blockingReasons.push(
          `يوجد (${unresolvedErrors.length}) خطأ غير معالج يتطلب Remediation & Retest`
        );

      const passed = Object.values(checks).every(Boolean);

      const criteriaBreakdown = [
        {
          criterion: 'prerequisiteMastery',
          label: 'إتقان المتطلبات السابقة',
          required: criteria.prerequisiteMastery ? 'جميع المتطلبات متقنة' : 'غير مطلوب',
          actual: prereqCheck.allMet ? 'مستوفى' : `غير مكتمل (${prereqCheck.unmetIds.join(', ')})`,
          passed: checks.prerequisiteMastery,
        },
        {
          criterion: 'minTestScore',
          label: 'الحد الأدنى لدرجة الاختبار',
          required: `${criteria.minTestScore}%`,
          actual: `${bestScore}%`,
          passed: checks.minTestScore,
        },
        {
          criterion: 'minAccuracy',
          label: 'الحد الأدنى للدقة',
          required: `${criteria.minAccuracy}%`,
          actual: `${bestAccuracy}%`,
          passed: checks.minAccuracy,
        },
        {
          criterion: 'minSuccessfulAttempts',
          label: 'عدد المحاولات الناجحة',
          required: criteria.minSuccessfulAttempts,
          actual: passedAttempts.length,
          passed: checks.minSuccessfulAttempts,
        },
        {
          criterion: 'consistency',
          label: 'الاستمرارية عبر الجلسات',
          required: criteria.consistency,
          actual: consistencyCount,
          passed: checks.consistency,
        },
        {
          criterion: 'requiredEvidence',
          label: 'عدد الأدلة التطبيقية',
          required: criteria.requiredEvidenceCount,
          actual: evidenceCount,
          passed: checks.requiredEvidence,
        },
        {
          criterion: 'domainEvidenceTypes',
          label: 'أنواع الأدلة التخصصية للمجال',
          required: reqTypes.length > 0 ? reqTypes.join(', ') : 'أي دليل تطبيقي',
          actual: recordedEvidenceTypes.length > 0 ? recordedEvidenceTypes.join(', ') : 'لا يوجد',
          passed: checks.domainEvidenceTypes,
        },
        {
          criterion: 'independentApplication',
          label: 'التطبيق المستقل (Independent Application)',
          required: criteria.requireIndependentApplication ? 'مطلوب' : 'اختياري',
          actual: hasIndependentApp ? 'محقق' : 'غير محقق',
          passed: checks.independentApplication,
        },
        {
          criterion: 'noUnresolvedErrors',
          label: 'خلو السجل من أخطاء مفتوحة',
          required: 0,
          actual: unresolvedErrors.length,
          passed: checks.noUnresolvedErrors,
        },
      ];

      const decisionExplanation = passed
        ? `اجتازت المهارة الفرعية "${sub.name}" بوابة الإتقان بنجاح: الدرجة (${bestScore}% ≥ ${criteria.minTestScore}%)، الدقة (${bestAccuracy}% ≥ ${criteria.minAccuracy}%)، المحاولات الناجحة (${passedAttempts.length}/${criteria.minSuccessfulAttempts})، الاستمرارية (${consistencyCount}/${criteria.consistency})، والأدلة (${evidenceCount}/${criteria.requiredEvidenceCount}) بدون أخطاء معلقة.`
        : `لم تجتز المهارة الفرعية "${sub.name}" بوابة الإتقان للأسباب التالية: ${blockingReasons.join(' | ')}`;

      return {
        entityType: 'subskill',
        entityId: sub.id,
        passed,
        criteria,
        actual: {
          bestScore,
          bestAccuracy,
          successfulAttempts: passedAttempts.length,
          consistencyCount,
          evidenceCount,
          recordedEvidenceTypes,
          missingEvidenceTypes,
          hasIndependentApp,
          unresolvedErrorsCount: unresolvedErrors.length,
        },
        checks,
        blockingReasons,
        criteriaBreakdown,
        decisionExplanation,
      };
    }

    // Evaluate Parent Skill Mastery Gate
    const rawSkill = await this.db.get('skills', entityId);
    if (!rawSkill) throw new Error(`Skill not found: ${entityId}`);
    const skill = normalizeSkillRecord(rawSkill);
    const criteria = skill.masteryCriteria;

    const prereqCheck = await this.checkPrerequisitesMet('skill', skill.prerequisites);
    const attempts = await this.db.queryByField('test_attempts', 'skillId', skill.id);
    const passedAttempts = attempts.filter((a) => a.passed);
    const bestScore = attempts.reduce((max, a) => Math.max(max, a.score || 0), 0);
    const bestAccuracy = attempts.reduce((max, a) => Math.max(max, a.accuracy || 0), 0);

    const evRecords = await this.db.queryByField('evidence', 'skillId', skill.id);
    const evidenceCount = Math.max(skill.metrics?.evidenceCount || 0, evRecords.length);
    const recordedEvidenceTypes = [...new Set(evRecords.map((e) => e.type).filter(Boolean))];
    const consistencyCount = skill.metrics?.trainingSessionsCount || 0;

    const skillErrors = await this.db.queryByField('errors', 'skillId', skill.id);
    const unresolvedErrors = skillErrors.filter((e) => e.status !== 'resolved');

    const childSubskills = await this.db.queryByField('subskills', 'skillId', skill.id);
    const allSubskillsMastered =
      childSubskills.length === 0 ||
      childSubskills.every(
        (s) => s.masteryState === 'MASTERED' || s.masteryState === 'MAINTENANCE'
      );

    // Domain-specific evidence types check
    const reqTypes = Array.isArray(criteria.requiredEvidenceTypes)
      ? criteria.requiredEvidenceTypes
      : [];
    const missingEvidenceTypes = reqTypes.filter((t) => !recordedEvidenceTypes.includes(t));
    const domainEvidenceTypesMet = missingEvidenceTypes.length === 0;

    // Independent application check
    const hasIndependentApp =
      evRecords.some(
        (e) =>
          e.independentApplication ||
          e.type === 'independent_application' ||
          e.type === 'practical_demonstration'
      ) ||
      passedAttempts.some(
        (a) =>
          a.verificationMode === 'independent_performance' ||
          a.verificationMode === 'practical_demonstration' ||
          a.independentApplication === true
      );
    const independentApplicationMet = criteria.requireIndependentApplication
      ? hasIndependentApp
      : true;

    const checks = {
      prerequisiteMastery: criteria.prerequisiteMastery ? prereqCheck.allMet : true,
      minTestScore: bestScore >= criteria.minTestScore,
      minAccuracy: bestAccuracy >= criteria.minAccuracy,
      minSuccessfulAttempts: passedAttempts.length >= criteria.minSuccessfulAttempts,
      consistency: consistencyCount >= criteria.consistency,
      requiredEvidence: evidenceCount >= criteria.requiredEvidenceCount,
      domainEvidenceTypes: domainEvidenceTypesMet,
      independentApplication: independentApplicationMet,
      noUnresolvedErrors: unresolvedErrors.length === 0,
      subskillsMastered: criteria.requireAllSubskillsMastered ? allSubskillsMastered : true,
    };

    const blockingReasons = [];
    if (!checks.prerequisiteMastery) blockingReasons.push('المهارات المتطلبة السابقة غير متقنة');
    if (!checks.subskillsMastered)
      blockingReasons.push('لم يتم إتقان جميع المهارات الفرعية (Subskills) التابعة بعد');
    if (!checks.minTestScore)
      blockingReasons.push(`درجة الاختبار (${bestScore}%) أقل من (${criteria.minTestScore}%)`);
    if (!checks.minAccuracy)
      blockingReasons.push(`نسبة الدقة (${bestAccuracy}%) أقل من (${criteria.minAccuracy}%)`);
    if (!checks.minSuccessfulAttempts)
      blockingReasons.push(
        `المحاولات الناجحة (${passedAttempts.length}) أقل من (${criteria.minSuccessfulAttempts})`
      );
    if (!checks.consistency)
      blockingReasons.push(`الاستمرارية (${consistencyCount}) أقل من (${criteria.consistency})`);
    if (!checks.requiredEvidence)
      blockingReasons.push(`الأدلة (${evidenceCount}) أقل من (${criteria.requiredEvidenceCount})`);
    if (!checks.domainEvidenceTypes)
      blockingReasons.push(
        `ينقص نوع دليل تخصصي مطلوب للمجال: (${missingEvidenceTypes.join(', ')})`
      );
    if (!checks.independentApplication)
      blockingReasons.push(
        'يتطلب إثبات تطبيق مستقل (Independent Application / Practical Demonstration)'
      );
    if (!checks.noUnresolvedErrors)
      blockingReasons.push(`يوجد (${unresolvedErrors.length}) خطأ مفتوح لم يُحل بعد`);

    const passed = Object.values(checks).every(Boolean);

    const masteredSubskillsCount = childSubskills.filter(
      (s) => s.masteryState === 'MASTERED' || s.masteryState === 'MAINTENANCE'
    ).length;

    const criteriaBreakdown = [
      {
        criterion: 'prerequisiteMastery',
        label: 'إتقان المهارات المتطلبة السابقة',
        required: criteria.prerequisiteMastery ? 'جميع المتطلبات متقنة' : 'غير مطلوب',
        actual: prereqCheck.allMet ? 'مستوفى' : `غير مكتمل (${prereqCheck.unmetIds.join(', ')})`,
        passed: checks.prerequisiteMastery,
      },
      {
        criterion: 'subskillsMastered',
        label: 'إتقان المهارات الفرعية التابعة',
        required: criteria.requireAllSubskillsMastered
          ? `${childSubskills.length}/${childSubskills.length}`
          : 'اختياري',
        actual: `${masteredSubskillsCount}/${childSubskills.length}`,
        passed: checks.subskillsMastered,
      },
      {
        criterion: 'minTestScore',
        label: 'الحد الأدنى لدرجة الاختبار',
        required: `${criteria.minTestScore}%`,
        actual: `${bestScore}%`,
        passed: checks.minTestScore,
      },
      {
        criterion: 'minAccuracy',
        label: 'الحد الأدنى للدقة',
        required: `${criteria.minAccuracy}%`,
        actual: `${bestAccuracy}%`,
        passed: checks.minAccuracy,
      },
      {
        criterion: 'minSuccessfulAttempts',
        label: 'عدد المحاولات الناجحة',
        required: criteria.minSuccessfulAttempts,
        actual: passedAttempts.length,
        passed: checks.minSuccessfulAttempts,
      },
      {
        criterion: 'consistency',
        label: 'الاستمرارية عبر الجلسات',
        required: criteria.consistency,
        actual: consistencyCount,
        passed: checks.consistency,
      },
      {
        criterion: 'requiredEvidence',
        label: 'عدد الأدلة الموثقة',
        required: criteria.requiredEvidenceCount,
        actual: evidenceCount,
        passed: checks.requiredEvidence,
      },
      {
        criterion: 'domainEvidenceTypes',
        label: 'أنواع الأدلة التخصصية للمجال',
        required: reqTypes.length > 0 ? reqTypes.join(', ') : 'أي دليل تطبيقي',
        actual: recordedEvidenceTypes.length > 0 ? recordedEvidenceTypes.join(', ') : 'لا يوجد',
        passed: checks.domainEvidenceTypes,
      },
      {
        criterion: 'independentApplication',
        label: 'التطبيق المستقل (Independent Application)',
        required: criteria.requireIndependentApplication ? 'مطلوب' : 'اختياري',
        actual: hasIndependentApp ? 'محقق' : 'غير محقق',
        passed: checks.independentApplication,
      },
      {
        criterion: 'noUnresolvedErrors',
        label: 'خلو السجل من أخطاء مفتوحة',
        required: 0,
        actual: unresolvedErrors.length,
        passed: checks.noUnresolvedErrors,
      },
    ];

    const decisionExplanation = passed
      ? `اجتازت المهارة "${skill.nameAr || skill.name}" بوابة الإتقان بنجاح: الدرجة (${bestScore}% ≥ ${criteria.minTestScore}%)، الدقة (${bestAccuracy}% ≥ ${criteria.minAccuracy}%)، المحاولات (${passedAttempts.length}/${criteria.minSuccessfulAttempts})، الاستمرارية (${consistencyCount}/${criteria.consistency})، والأدلة (${evidenceCount}/${criteria.requiredEvidenceCount}) بدون أخطاء معلقة.`
      : `لم تجتز المهارة "${skill.nameAr || skill.name}" بوابة الإتقان للأسباب التالية: ${blockingReasons.join(' | ')}`;

    return {
      entityType: 'skill',
      entityId: skill.id,
      passed,
      criteria,
      actual: {
        bestScore,
        bestAccuracy,
        successfulAttempts: passedAttempts.length,
        consistencyCount,
        evidenceCount,
        recordedEvidenceTypes,
        missingEvidenceTypes,
        hasIndependentApp,
        unresolvedErrorsCount: unresolvedErrors.length,
        masteredSubskillsCount,
        totalSubskillsCount: childSubskills.length,
      },
      checks,
      blockingReasons,
      criteriaBreakdown,
      decisionExplanation,
    };
  }

  async tryPromoteMastery(skillId, subskillId = null) {
    const nowIso = new Date().toISOString();
    let subskillGate = null;

    if (subskillId) {
      subskillGate = await this.evaluateMasteryGate('subskill', subskillId);
      if (subskillGate.passed) {
        const sub = await this.db.get('subskills', subskillId);
        if (sub && sub.masteryState !== 'MASTERED' && sub.masteryState !== 'MAINTENANCE') {
          const prevState = sub.masteryState;
          const isReactivation = Boolean(sub.historicalMasteryAchieved);
          await this.db.put('subskills', {
            ...sub,
            masteryState: 'MASTERED',
            historicalMasteryAchieved: true,
            firstMasteredAt: sub.firstMasteredAt || nowIso,
            lastMasteredAt: nowIso,
            currentRetentionStatus: 'ACTIVE_MASTERY',
            updatedAt: nowIso,
          });
          await this._recordMasteryHistoryEvent({
            entityType: 'subskill',
            entityId: sub.id,
            skillId,
            subskillId: sub.id,
            eventType: isReactivation ? 'MASTERY_REACTIVATED' : 'MASTERY_ACHIEVED',
            previousState: prevState,
            newState: 'MASTERED',
            historicalMasteryPreserved: true,
            currentRetentionStatus: 'ACTIVE_MASTERY',
            gateSnapshot: subskillGate.actual,
            supportingEvidenceIds: sub.evidence || [],
            decisionExplanation: subskillGate.decisionExplanation,
            timestamp: nowIso,
          });
        }
      }
    }

    // Reconcile locks so newly mastered subskill unlocks sibling subskills
    await this.reconcilePrerequisiteLocks();

    const skillGate = await this.evaluateMasteryGate('skill', skillId);
    if (skillGate.passed) {
      const skill = await this.db.get('skills', skillId);
      if (skill && skill.status !== 'MASTERED' && skill.status !== 'MAINTENANCE') {
        const prevStatus = skill.status;
        const isReactivation = Boolean(skill.historicalMasteryAchieved);
        const evRecords = await this.db.queryByField('evidence', 'skillId', skillId);
        await this.db.put('skills', {
          ...skill,
          status: 'MASTERED',
          currentLevel: Math.max(skill.currentLevel, skill.targetLevel),
          historicalMasteryAchieved: true,
          firstMasteredAt: skill.firstMasteredAt || nowIso,
          lastMasteredAt: nowIso,
          currentRetentionStatus: 'ACTIVE_MASTERY',
          masteryCriteria: {
            ...skill.masteryCriteria,
            gatePassed: true,
          },
          updatedAt: nowIso,
        });
        await this._recordMasteryHistoryEvent({
          entityType: 'skill',
          entityId: skill.id,
          skillId: skill.id,
          subskillId: null,
          eventType: isReactivation ? 'MASTERY_REACTIVATED' : 'MASTERY_ACHIEVED',
          previousState: prevStatus,
          newState: 'MASTERED',
          historicalMasteryPreserved: true,
          currentRetentionStatus: 'ACTIVE_MASTERY',
          gateSnapshot: skillGate.actual,
          supportingEvidenceIds: evRecords.map((e) => e.id),
          decisionExplanation: skillGate.decisionExplanation,
          timestamp: nowIso,
        });
      }
      // Unlock any downstream skills waiting on this skill!
      await this.reconcilePrerequisiteLocks();
    }

    await this.calculateSkillProgress(skillId);
    return {
      subskillGate,
      skillGate,
    };
  }

  // =========================================================================
  // 5. TESTING, FAILURE -> ERROR CREATION, REMEDIATION, CORRECTIVE TASKS & RETEST
  // =========================================================================

  async createTest(input) {
    const testRecord = {
      id: input.id || `test_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      skillId: input.skillId,
      subskillId: input.subskillId || null,
      title: input.title,
      description: input.description || '',
      passingScore: Number(input.passingScore ?? 85),
      minAccuracy: Number(input.minAccuracy ?? 80),
      questionsCount: Number(input.questionsCount ?? 10),
      createdAt: new Date().toISOString(),
    };
    return this.db.put('tests', testRecord);
  }

  async recordTestAttempt(payload) {
    const {
      testId,
      skillId,
      subskillId = null,
      objectiveId = null,
      sessionId = null,
      score,
      accuracy,
      evidence = '',
      evidenceType = 'test',
      independentApplication = false,
      verificationMode = null,
      originalAssessmentId = null,
      isRetest = false,
      linkedErrorId = null,
      errorCategory = 'conceptual_misunderstanding',
      errorDescription = '',
      errorCause = '',
    } = payload;

    // Enforce Prerequisite Lock
    const skill = await this.assertUnlocked('skill', skillId);
    let subskill = null;
    if (subskillId) {
      subskill = await this.assertUnlocked('subskill', subskillId);
    }

    // If this is a Retest, verify the linked Error and its Remediation Plan
    let linkedError = null;
    let linkedRemediation = null;
    if (isRetest || linkedErrorId) {
      if (!linkedErrorId) {
        throw new Error('Retest requires a linkedErrorId');
      }
      linkedError = await this.db.get('errors', linkedErrorId);
      if (!linkedError) {
        throw new Error(`Linked error not found: ${linkedErrorId}`);
      }
      if (linkedError.remediationId) {
        linkedRemediation = await this.db.get('remediations', linkedError.remediationId);
        if (linkedRemediation && !linkedRemediation.retestAllowed) {
          throw new Error(
            `Cannot execute Retest for error "${linkedError.id}" before completing all Corrective Tasks in remediation plan "${linkedRemediation.id}".`
          );
        }
      }
    }

    const testDef = testId ? await this.db.get('tests', testId) : null;
    const minScore =
      testDef?.passingScore ??
      subskill?.masteryCriteria?.minTestScore ??
      skill.masteryCriteria?.minTestScore ??
      85;
    const minAcc =
      testDef?.minAccuracy ??
      subskill?.masteryCriteria?.minAccuracy ??
      skill.masteryCriteria?.minAccuracy ??
      80;

    const numScore = Number(score);
    const numAccuracy = Number(accuracy ?? score);
    const passed = numScore >= minScore && numAccuracy >= minAcc;
    const nowIso = payload.timestamp || new Date().toISOString();

    let createdEvidence = null;
    if (evidence && String(evidence).trim().length > 0) {
      createdEvidence = await this.db.put('evidence', {
        id: `ev_test_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        skillId,
        subskillId,
        objectiveId,
        type: isRetest ? 'retest' : evidenceType || 'test',
        independentApplication: Boolean(
          independentApplication ||
            verificationMode === 'independent_performance' ||
            verificationMode === 'practical_demonstration'
        ),
        title: `دليل ${isRetest ? 'إعادة اختبار' : 'اختبار'} (${passed ? 'ناجح' : 'غير مجتاز'} - ${numScore}%)`,
        content: String(evidence).trim(),
        qualityScore: numScore,
        createdAt: nowIso,
      });
    }

    // Append-only test_attempts store: never delete failed attempts!
    const attempt = await this.db.put('test_attempts', {
      id: payload.id || `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      testId: testId || null,
      skillId,
      subskillId,
      objectiveId,
      sessionId,
      score: numScore,
      accuracy: numAccuracy,
      passed,
      evidence: String(evidence || ''),
      evidenceId: createdEvidence?.id || null,
      isRetest: Boolean(isRetest || linkedErrorId),
      verificationMode:
        verificationMode || (isRetest || linkedErrorId ? 'equivalent_questions' : 'standard_test'),
      independentApplication: Boolean(
        independentApplication ||
          verificationMode === 'independent_performance' ||
          verificationMode === 'practical_demonstration'
      ),
      originalAssessmentId:
        originalAssessmentId || linkedError?.linkedTestAttemptId || linkedError?.diagnosticAssessmentId || null,
      linkedErrorId: linkedErrorId || null,
      remediationId: linkedRemediation?.id || null,
      timestamp: nowIso,
    });

    let createdError = null;
    let updatedError = null;
    let spawnedEscalationTask = null;

    if (!passed) {
      if (linkedError) {
        // Failed Retest -> Preserve history and escalate Error & Remediation!
        const nextFailureCount = (linkedError.failureCount || 1) + 1;
        updatedError = await this.db.put('errors', {
          ...linkedError,
          status: 'escalated',
          severity: nextFailureCount >= 3 ? 'critical' : 'high',
          failureCount: nextFailureCount,
          retestRequired: true,
          retestAttemptIds: [...new Set([...(linkedError.retestAttemptIds || []), attempt.id])],
          lastFailedRetestAt: nowIso,
        });

        if (linkedRemediation) {
          const drillTask = await this.db.put('tasks', {
            id: `task_remed_drill_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            title: `[Corrective Drill L${(linkedRemediation.remediationLevel || 1) + 1}] تدريب علاجي مكثف بعد تعثر إعادة الاختبار: ${subskill?.name || skill.nameAr}`,
            date: nowIso.slice(0, 10),
            category: 'Remediation',
            status: 'pending',
            executionState: 'planned',
            plannedDurationMin: 40,
            priority: 1,
            skillId,
            subskillId,
            objectiveId,
            errorId: linkedError.id,
            remediationId: linkedRemediation.id,
            isCorrective: true,
            notes: 'تم خفض حجم الخطوة التدريبية وزيادة التمارين الموجهة لمعالجة السبب الجذري للخطأ.',
          });
          spawnedEscalationTask = drillTask;

          await this.db.put('remediations', {
            ...linkedRemediation,
            remediationLevel: (linkedRemediation.remediationLevel || 1) + 1,
            difficultyAdjustment: 'step_down_granularity_and_add_guided_drills',
            correctiveTaskIds: [...linkedRemediation.correctiveTaskIds, drillTask.id],
            retestAllowed: false,
            status: 'escalated',
            updatedAt: nowIso,
          });
        }
      } else {
        // Initial Test Failure -> Automatically Create Linked ErrorRecord with normalized taxonomy
        const normalizedCat = normalizeErrorCategory(errorCategory);
        const severity = numScore < 50 ? 'critical' : numScore < 70 ? 'high' : 'medium';
        createdError = await this.db.put('errors', {
          id: `err_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          goalId: skill.goalId || null,
          capabilityId: skill.capabilityId || skill.domain || null,
          skillId,
          linkedSkill: skillId,
          subskillId,
          linkedSubskill: subskillId,
          subskill: subskill?.name || 'Skill Assessment',
          objectiveId,
          sessionId,
          testId: testId || null,
          linkedTestAttemptId: attempt.id,
          category: normalizedCat,
          classificationState:
            normalizedCat === 'unknown_unclassified' ? 'unclassified' : 'hypothesized',
          severity,
          description:
            errorDescription ||
            `عدم اجتياز اختبار ${subskill?.name || skill.name} (الدرجة: ${numScore}% / المطلوب: ${minScore}%، الدقة: ${numAccuracy}%)`,
          cause:
            errorCause ||
            'فرضية أولية: فجوة في الاسترجاع التطبيقي أو الدقة تحت ضغط الاختبار (تتطلب تحققاً تشخيصياً)',
          observedFacts: [
            `Test Attempt ${attempt.id}: Score ${numScore}% (Required ${minScore}%), Accuracy ${numAccuracy}% (Required ${minAcc}%)`,
          ],
          hypotheses: [
            {
              category: normalizedCat,
              explanation:
                errorCause ||
                'احتمال وجود فجوة في استيعاب المفهوم أو إجراءات الحل التطبيقي بناءً على درجة الاختبار',
              supportingEvidence: [
                `Test Attempt ${attempt.id} (${numScore}% / Accuracy ${numAccuracy}%)`,
              ],
              confidenceLevel: 'moderate',
              uncertaintyNote:
                'هذه الفرضية مبنية على نتيجة اختبار واحد وتحتاج إلى تمرين تصحيحي وإعادة اختبار للتحقق.',
              verificationMethod:
                'تنفيذ مهمة تصحيحية موجهة ثم إجراء إعادة اختبار بأسئلة مكافئة أو أمثلة جديدة (Equivalent Questions / New Examples).',
            },
          ],
          date: nowIso.slice(0, 10),
          evidence: `Test Attempt ${attempt.id} (${numScore}% / Accuracy ${numAccuracy}%)`,
          remediation:
            'يتطلب إنشاء خطة علاجية (Remediation Plan) وإنجاز مهام تصحيحية قبل إعادة الاختبار (Retest).',
          remediationId: null,
          retestAttemptIds: [],
          failureCount: 1,
          retestRequired: true,
          status: 'open',
        });
      }
    } else if (passed && linkedError) {
      // Successful Retest -> Resolve Original Error & Complete Remediation!
      updatedError = await this.db.put('errors', {
        ...linkedError,
        status: 'resolved',
        classificationState: 'verified',
        retestRequired: false,
        resolvedAt: nowIso,
        resolvedByAttemptId: attempt.id,
        verificationMode:
          verificationMode || 'equivalent_questions',
        retestAttemptIds: [...new Set([...(linkedError.retestAttemptIds || []), attempt.id])],
      });

      if (linkedRemediation) {
        await this.db.put('remediations', {
          ...linkedRemediation,
          status: 'completed',
          verifiedByAttemptId: attempt.id,
          verificationMode: verificationMode || 'equivalent_questions',
          updatedAt: nowIso,
        });
      }
    }

    // Update Subskill test & error links
    if (subskill) {
      const freshSub = await this.db.get('subskills', subskillId);
      const nextSubState =
        freshSub.masteryState === 'AVAILABLE' ? 'IN_PROGRESS' : freshSub.masteryState;
      await this.db.put('subskills', {
        ...freshSub,
        masteryState: nextSubState,
        tests: [...new Set([...(freshSub.tests || []), attempt.id])],
        evidence: createdEvidence
          ? [...new Set([...(freshSub.evidence || []), createdEvidence.id])]
          : freshSub.evidence,
        errors: createdError
          ? [...new Set([...(freshSub.errors || []), createdError.id])]
          : freshSub.errors,
        updatedAt: nowIso,
      });
    }

    // Recompute Skill test & error metrics
    const allAttempts = await this.db.queryByField('test_attempts', 'skillId', skillId);
    const allSkillErrors = await this.db.queryByField('errors', 'skillId', skillId);
    const allSkillEvidence = await this.db.queryByField('evidence', 'skillId', skillId);

    const avgScore =
      allAttempts.length > 0
        ? Math.round(allAttempts.reduce((s, a) => s + a.score, 0) / allAttempts.length)
        : 0;
    const avgAcc =
      allAttempts.length > 0
        ? Math.round(allAttempts.reduce((s, a) => s + a.accuracy, 0) / allAttempts.length)
        : 0;

    const freshSkill = await this.db.get('skills', skillId);
    await this.db.put('skills', {
      ...freshSkill,
      status: freshSkill.status === 'AVAILABLE' ? 'IN_PROGRESS' : freshSkill.status,
      metrics: {
        ...freshSkill.metrics,
        testsCompleted: allAttempts.length,
        successfulAttempts: allAttempts.filter((a) => a.passed).length,
        avgTestScore: avgScore,
        avgAccuracy: avgAcc,
        evidenceCount: Math.max(freshSkill.metrics?.evidenceCount || 0, allSkillEvidence.length),
        errorCount: allSkillErrors.length,
        openErrorCount: allSkillErrors.filter((e) => e.status !== 'resolved').length,
      },
      updatedAt: nowIso,
    });

    // Evaluate Mastery Gate promotion if test passed
    const masteryPromotion = passed
      ? await this.tryPromoteMastery(skillId, subskillId)
      : await this.calculateSkillProgress(skillId);

    return {
      attempt,
      passed,
      createdError,
      updatedError,
      spawnedEscalationTask,
      masteryPromotion,
    };
  }

  async createRemediationPlan(payload) {
    const { errorId, title, strategy, remediationType, tasksSpec } = payload;
    const error = await this.db.get('errors', errorId);
    if (!error) {
      throw new Error(`Error record not found: ${errorId}`);
    }

    const nowIso = new Date().toISOString();
    const remId = payload.id || `rem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const dateStr = payload.date || nowIso.slice(0, 10);

    const specs =
      Array.isArray(tasksSpec) && tasksSpec.length > 0
        ? tasksSpec
        : [
            {
              title: `[Corrective Task] تحليل السبب الجذري وإعادة التدرب: ${error.description}`,
              plannedDurationMin: 35,
            },
          ];

    const createdTasks = [];
    for (const sp of specs) {
      const t = await this.db.put('tasks', {
        id: sp.id || `task_corr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        title: sp.title,
        date: sp.date || dateStr,
        category: sp.category || 'Primary',
        status: 'pending',
        executionState: 'planned',
        plannedDurationMin: Number(sp.plannedDurationMin || 35),
        priority: 1,
        skillId: error.skillId,
        subskillId: error.subskillId || null,
        objectiveId: sp.objectiveId || error.objectiveId || null,
        errorId: error.id,
        remediationId: remId,
        isCorrective: true,
        remediationType: sp.remediationType || remediationType || error.category || 'general',
        notes: sp.notes || `مهمة تصحيحية لمعالجة الخطأ: ${error.id}`,
      });
      createdTasks.push(t);
    }

    const remediation = await this.db.put('remediations', {
      id: remId,
      errorId: error.id,
      skillId: error.skillId,
      subskillId: error.subskillId || null,
      objectiveId: error.objectiveId || null,
      diagnosticAssessmentId: error.diagnosticAssessmentId || null,
      remediationType: remediationType || error.category || 'general',
      title: title || `خطة علاجية للخطأ: ${error.description}`,
      strategy: strategy || 'تفكيك المفهوم + تدريبات موجهة + توثيق الدليل قبل إعادة الاختبار',
      difficultyAdjustment: payload.difficultyAdjustment || 'focused_remediation',
      correctiveTaskIds: createdTasks.map((t) => t.id),
      remediationLevel: 1,
      retestAllowed: false,
      status: 'active',
      createdAt: nowIso,
      updatedAt: nowIso,
    });

    await this.db.put('errors', {
      ...error,
      status: 'remediating',
      remediationId: remediation.id,
    });

    if (error.subskillId) {
      const sub = await this.db.get('subskills', error.subskillId);
      if (sub) {
        await this.db.put('subskills', {
          ...sub,
          remediation: [...new Set([...(sub.remediation || []), remediation.id])],
          updatedAt: nowIso,
        });
      }
    }

    await this.calculateSkillProgress(error.skillId);
    return {
      remediation,
      correctiveTasks: createdTasks,
    };
  }

  async completeCorrectiveTask(taskId, options = {}) {
    const task = await this.db.get('tasks', taskId);
    if (!task) throw new Error(`Corrective task not found: ${taskId}`);

    const nowIso = new Date().toISOString();
    const updatedTask = await this.db.put('tasks', {
      ...task,
      status: 'completed',
      executionState: 'completed',
      actualDurationMin: Number(options.durationMinutes || task.plannedDurationMin || 30),
      lastLoggedAt: nowIso,
    });

    // Record training session & evidence on the skill/subskill
    const sessionRes = await this.recordTrainingSession({
      skillId: task.skillId,
      subskillId: task.subskillId || null,
      durationMinutes: updatedTask.actualDurationMin,
      evidenceType: options.evidenceType || 'practice',
      independentApplication: Boolean(options.independentApplication),
      evidenceTitle: options.evidenceTitle || `إنجاز المهمة التصحيحية: ${task.title}`,
      evidenceContent:
        options.evidenceContent || 'تم إتمام التمرين التصحيحي بنجاح استعداداً لإعادة الاختبار.',
      qualityScore: Number(options.qualityScore ?? 90),
    });

    let updatedRemediation = null;
    if (task.remediationId) {
      const rem = await this.db.get('remediations', task.remediationId);
      if (rem) {
        const linkedTasks = await Promise.all(
          rem.correctiveTaskIds.map((id) => this.db.get('tasks', id))
        );
        const allCompleted = linkedTasks.every((t) => t && t.status === 'completed');
        updatedRemediation = await this.db.put('remediations', {
          ...rem,
          retestAllowed: allCompleted,
          status: allCompleted ? 'ready_for_retest' : rem.status,
          remediationEvidenceIds: sessionRes.evidence
            ? [...new Set([...(rem.remediationEvidenceIds || []), sessionRes.evidence.id])]
            : rem.remediationEvidenceIds || [],
          updatedAt: nowIso,
        });
      }
    }

    await this.calculateSkillProgress(task.skillId);
    return {
      task: updatedTask,
      remediation: updatedRemediation,
      evidence: sessionRes.evidence,
    };
  }

  async recordRetestAttempt(payload) {
    return this.recordTestAttempt({
      ...payload,
      isRetest: true,
    });
  }

  // =========================================================================
  // 6. MAINTENANCE ENGINE (POST-MASTERY RETENTION & REVIEWS)
  // =========================================================================

  async transitionToMaintenance(entityType, entityId, reviewDateStr = '2026-10-14') {
    const nowIso = new Date().toISOString();

    if (entityType === 'subskill') {
      const sub = await this.db.get('subskills', entityId);
      if (!sub) throw new Error(`Subskill not found: ${entityId}`);
      if (sub.masteryState !== 'MASTERED' && sub.masteryState !== 'MAINTENANCE') {
        throw new Error(
          `Subskill "${sub.name}" must be MASTERED before entering MAINTENANCE (current: ${sub.masteryState})`
        );
      }
      const intervalDays = sub.maintenance?.intervalDays || 14;
      const nextReviewDate = addDaysToDateStr(reviewDateStr, intervalDays);
      const updated = await this.db.put('subskills', {
        ...sub,
        masteryState: 'MAINTENANCE',
        historicalMasteryAchieved: true,
        firstMasteredAt: sub.firstMasteredAt || nowIso,
        currentRetentionStatus: 'RETAINED',
        maintenance: {
          ...sub.maintenance,
          intervalDays,
          lastReviewDate: reviewDateStr,
          nextReviewDate,
        },
        updatedAt: nowIso,
      });
      await this._recordMasteryHistoryEvent({
        entityType: 'subskill',
        entityId: sub.id,
        skillId: sub.skillId,
        subskillId: sub.id,
        eventType: 'ENTERED_MAINTENANCE',
        previousState: sub.masteryState,
        newState: 'MAINTENANCE',
        historicalMasteryPreserved: true,
        currentRetentionStatus: 'RETAINED',
        decisionExplanation: `انتقال المهارة الفرعية "${sub.name}" إلى طور الصيانة الدورية (Next Review: ${nextReviewDate}).`,
        timestamp: nowIso,
      });
      await this.calculateSkillProgress(sub.skillId);
      return updated;
    }

    const skill = await this.db.get('skills', entityId);
    if (!skill) throw new Error(`Skill not found: ${entityId}`);
    if (skill.status !== 'MASTERED' && skill.status !== 'MAINTENANCE') {
      throw new Error(
        `Skill "${skill.name}" must be MASTERED before entering MAINTENANCE (current: ${skill.status})`
      );
    }
    const intervalDays = skill.maintenanceCriteria?.intervalDays || 14;
    const nextReviewDate = addDaysToDateStr(reviewDateStr, intervalDays);
    const updatedSkill = await this.db.put('skills', {
      ...skill,
      status: 'MAINTENANCE',
      historicalMasteryAchieved: true,
      firstMasteredAt: skill.firstMasteredAt || nowIso,
      currentRetentionStatus: 'RETAINED',
      maintenanceCriteria: {
        ...skill.maintenanceCriteria,
        intervalDays,
        lastReviewDate: reviewDateStr,
        nextReviewDate,
      },
      updatedAt: nowIso,
    });
    await this._recordMasteryHistoryEvent({
      entityType: 'skill',
      entityId: skill.id,
      skillId: skill.id,
      subskillId: null,
      eventType: 'ENTERED_MAINTENANCE',
      previousState: skill.status,
      newState: 'MAINTENANCE',
      historicalMasteryPreserved: true,
      currentRetentionStatus: 'RETAINED',
      decisionExplanation: `انتقال المهارة "${skill.nameAr || skill.name}" إلى طور الصيانة الدورية (Next Review: ${nextReviewDate}).`,
      timestamp: nowIso,
    });
    await this.calculateSkillProgress(skill.id);
    return updatedSkill;
  }

  async recordMaintenanceSession(payload) {
    const {
      skillId,
      subskillId = null,
      reviewDate = new Date().toISOString().slice(0, 10),
      score,
      retentionEvidence = '',
      performanceVerified = true,
      notes = '',
    } = payload;

    // Rule 10: Do NOT treat opening a flashcard or completing a review session as proof of retention unless performance evidence is recorded!
    if (
      performanceVerified === false ||
      score === undefined ||
      score === null ||
      Number.isNaN(Number(score)) ||
      String(retentionEvidence || '').trim().length === 0
    ) {
      throw new Error(
        'Retention check requires recorded performance evidence (score and retentionEvidence). Passive review or opening a session is not proof of retention.'
      );
    }

    const skill = await this.db.get('skills', skillId);
    if (!skill) throw new Error(`Skill not found: ${skillId}`);

    if (skill.status === 'MASTERED') {
      await this.transitionToMaintenance('skill', skillId, reviewDate);
    }
    if (subskillId) {
      const sub = await this.db.get('subskills', subskillId);
      if (sub && sub.masteryState === 'MASTERED') {
        await this.transitionToMaintenance('subskill', subskillId, reviewDate);
      }
    }

    const nowIso = new Date().toISOString();
    const numScore = Number(score);
    const minRetention = skill.maintenanceCriteria?.minRetentionScore || 80;
    const passed = numScore >= minRetention;

    const ev = await this.db.put('evidence', {
      id: `ev_maint_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      skillId,
      subskillId,
      type: 'retention',
      title: `فحص استبقاء وصيانة (${passed ? 'ناجح' : 'تراجع في الاحتفاظ'} - ${numScore}%)`,
      content: retentionEvidence,
      qualityScore: numScore,
      createdAt: nowIso,
    });

    const currentInterval = skill.maintenanceCriteria?.intervalDays || 14;
    const nextInterval = passed
      ? Math.min(90, Math.round(currentInterval * 1.5))
      : Math.max(3, Math.floor(currentInterval * 0.5));
    const nextReviewDate = addDaysToDateStr(reviewDate, nextInterval);

    const reviewRecord = await this.db.put('reviews', {
      id: payload.id || `rev_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      skillId,
      subskillId,
      reviewDate,
      nextReviewDate,
      reviewType: 'maintenance_retention',
      score: numScore,
      retentionRate: numScore,
      retentionEvidence,
      evidenceId: ev.id,
      passed,
      notes,
    });

    let retentionFailureError = null;
    let relearningRemediation = null;

    if (!passed) {
      // Retention failure creates an appropriate corrective/relearning path WITHOUT destroying prior mastery history!
      retentionFailureError = await this.db.put('errors', {
        id: `err_ret_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        goalId: skill.goalId || null,
        capabilityId: skill.capabilityId || skill.domain || null,
        skillId,
        linkedSkill: skillId,
        subskillId,
        linkedSubskill: subskillId,
        subskill: subskillId || 'Retention Check',
        category: 'recall_failure',
        classificationState: 'verified',
        severity: numScore < 60 ? 'high' : 'medium',
        description: `تراجع في فحص الاحتفاظ (Retention Check: ${numScore}% < ${minRetention}%) للمهارة المتقنة تاريخياً: ${skill.nameAr || skill.name}`,
        cause: 'تلاشي الاسترجاع عبر الزمن يتطلب مسار إعادة تنشيط (Relearning & Spaced Retrieval)',
        observedFacts: [
          `Retention Check ${reviewRecord.id} scored ${numScore}% (Required ${minRetention}%) on ${reviewDate}`,
        ],
        hypotheses: [
          {
            category: 'recall_failure',
            explanation: 'تراجع طبيعي في منحنى النسيان بعد فترة انقطاع عن التطبيق المستقل',
            supportingEvidence: [`Review ${reviewRecord.id}: ${retentionEvidence} (${numScore}%)`],
            confidenceLevel: 'high',
            uncertaintyNote: 'يتطلب جلسة استرجاع نشط وإعادة اختبار لإعادة تنشيط الإتقان.',
            verificationMethod: 'إكمال مهام إعادة التعلم (Relearning) واجتياز فحص احتفاظ تأكيدي.',
          },
        ],
        date: reviewDate,
        evidence: `Review ${reviewRecord.id} (${numScore}%)`,
        remediation: 'مسار إعادة تعلم وتنشيط استرجاع (Relearning Path) دون مسح الإتقان التاريخي.',
        remediationId: null,
        failureCount: 1,
        retestRequired: true,
        status: 'open',
      });

      relearningRemediation = await this.createRemediationPlan({
        errorId: retentionFailureError.id,
        date: reviewDate,
        remediationType: 'retention_relearning',
        title: `مسار إعادة تعلم وتنشيط الاحتفاظ (Relearning): ${skill.nameAr || skill.name}`,
        strategy: 'استرجاع نشط مكثف (Retrieval Practice) + تطبيق عملي سريع لإعادة تنشيط المهارة المتقنة سابقاً',
        tasksSpec: [
          {
            title: `[Relearning] استرجاع نشط وتنشيط المفهوم الأساسي: ${skill.nameAr || skill.name}`,
            plannedDurationMin: 25,
            category: 'Remediation',
            remediationType: 'retention_relearning',
          },
          {
            title: `[Relearning Verification] تمرين تطبيقي مستقل لاستعادة الجاهزية: ${skill.nameAr || skill.name}`,
            plannedDurationMin: 30,
            category: 'Remediation',
            remediationType: 'retention_relearning',
          },
        ],
      });
    }

    if (subskillId) {
      const freshSub = await this.db.get('subskills', subskillId);
      if (freshSub) {
        const prevSubState = freshSub.masteryState;
        const nextSubState = passed ? 'MAINTENANCE' : 'IN_PROGRESS';
        const nextRetStatus = passed ? 'RETAINED' : 'RETENTION_DECAY_RELEARNING';
        await this.db.put('subskills', {
          ...freshSub,
          masteryState: nextSubState,
          historicalMasteryAchieved: true,
          firstMasteredAt: freshSub.firstMasteredAt || nowIso,
          currentRetentionStatus: nextRetStatus,
          maintenance: {
            ...freshSub.maintenance,
            intervalDays: nextInterval,
            lastReviewDate: reviewDate,
            nextReviewDate,
            retentionScore: numScore,
            sessionsCount: (freshSub.maintenance?.sessionsCount || 0) + 1,
          },
          updatedAt: nowIso,
        });
        await this._recordMasteryHistoryEvent({
          entityType: 'subskill',
          entityId: freshSub.id,
          skillId,
          subskillId: freshSub.id,
          eventType: passed ? 'RETENTION_VERIFIED' : 'RETENTION_FAILED_RELEARNING',
          previousState: prevSubState,
          newState: nextSubState,
          historicalMasteryPreserved: true,
          currentRetentionStatus: nextRetStatus,
          supportingEvidenceIds: [ev.id],
          decisionExplanation: passed
            ? `اجتياز فحص الاحتفاظ للمهارة الفرعية (${numScore}% ≥ ${minRetention}%).`
            : `تراجع الاحتفاظ (${numScore}% < ${minRetention}%)؛ تم الاحتفاظ بسجل الإتقان التاريخي وفتح مسار إعادة تعلم.`,
          timestamp: nowIso,
        });
      }
    }

    const allReviews = await this.db.queryByField('reviews', 'skillId', skillId);
    const avgRetention =
      allReviews.length > 0
        ? Math.round(allReviews.reduce((s, r) => s + r.score, 0) / allReviews.length)
        : numScore;

    const freshSkill = await this.db.get('skills', skillId);
    const prevSkillStatus = freshSkill.status;
    const nextSkillStatus = passed ? 'MAINTENANCE' : 'IN_PROGRESS';
    const nextSkillRetentionStatus = passed ? 'RETAINED' : 'RETENTION_DECAY_RELEARNING';

    await this.db.put('skills', {
      ...freshSkill,
      status: nextSkillStatus,
      historicalMasteryAchieved: true,
      firstMasteredAt: freshSkill.firstMasteredAt || freshSkill.updatedAt || nowIso,
      currentRetentionStatus: nextSkillRetentionStatus,
      maintenanceCriteria: {
        ...freshSkill.maintenanceCriteria,
        intervalDays: nextInterval,
        lastReviewDate: reviewDate,
        nextReviewDate,
        retentionRate: avgRetention,
      },
      metrics: {
        ...freshSkill.metrics,
        maintenanceSessionsCount: allReviews.length,
        lastPracticedDate: reviewDate,
      },
      updatedAt: nowIso,
    });

    await this._recordMasteryHistoryEvent({
      entityType: 'skill',
      entityId: freshSkill.id,
      skillId: freshSkill.id,
      subskillId: null,
      eventType: passed ? 'RETENTION_VERIFIED' : 'RETENTION_FAILED_RELEARNING',
      previousState: prevSkillStatus,
      newState: nextSkillStatus,
      historicalMasteryPreserved: true,
      currentRetentionStatus: nextSkillRetentionStatus,
      supportingEvidenceIds: [ev.id],
      decisionExplanation: passed
        ? `اجتياز فحص الاحتفاظ للمهارة "${freshSkill.nameAr || freshSkill.name}" (${numScore}% ≥ ${minRetention}%). المراجعة القادمة: ${nextReviewDate}.`
        : `تراجع الاحتفاظ للمهارة "${freshSkill.nameAr || freshSkill.name}" (${numScore}% < ${minRetention}%). تم الحفاظ على الإتقان التاريخي (historicalMasteryAchieved = true) وتوليد مسار إعادة تعلم (Relearning).`,
      timestamp: nowIso,
    });

    await this.calculateSkillProgress(skillId);

    return {
      review: reviewRecord,
      evidence: ev,
      nextReviewDate,
      passed,
      historicalMasteryPreserved: true,
      currentRetentionStatus: nextSkillRetentionStatus,
      retentionFailureError,
      relearningRemediation,
    };
  }

  // =========================================================================
  // 7. 5-DIMENSIONAL PROGRESS CALCULATION (ZERO DOUBLE-COUNTING) & WEAKNESS INDICATORS
  // =========================================================================

  /**
   * Documented 5-Dimensional Progress Calculation (No Double-Counting):
   *  1. Activity (0-100): Exclusively measures task execution & time investment (`tasks` + `performance_logs` / practice minutes).
   *  2. Learning (0-100): Exclusively measures curriculum units + acquisition/study/practice evidence (`LEARNING_EVIDENCE_TYPES`).
   *  3. Competence (0-100): Exclusively measures test/retest attempts (`test_attempts`) + independent application evidence (`COMPETENCE_EVIDENCE_TYPES`), minus open error penalty.
   *  4. Mastery (0-100): Exclusively measures Mastery Gate criteria satisfaction ratio + subskill mastery state.
   *  5. Retention (0-100): Exclusively measures post-mastery `reviews` & `RETENTION_EVIDENCE_TYPES` + review schedule currency.
   */
  async calculateSkillProgress(skillId, referenceDate = '2026-10-14') {
    const rawSkill = await this.db.get('skills', skillId);
    if (!rawSkill) return null;
    const skill = normalizeSkillRecord(rawSkill);

    const [subskills, curriculum, tasks, evidence, attempts, errors, reviews] = await Promise.all([
      this.db.queryByField('subskills', 'skillId', skillId),
      this.db.queryByField('curriculum', 'skillId', skillId),
      this.db.queryByField('tasks', 'skillId', skillId),
      this.db.queryByField('evidence', 'skillId', skillId),
      this.db.queryByField('test_attempts', 'skillId', skillId),
      this.db.queryByField('errors', 'skillId', skillId),
      this.db.queryByField('reviews', 'skillId', skillId),
    ]);

    // Strictly partition evidence records into disjoint buckets so NO evidence record is counted in more than one metric
    const learningEvidence = [];
    const competenceEvidence = [];
    const retentionEvidence = [];

    for (const ev of evidence) {
      const evType = String(ev.type || 'training').toLowerCase();
      if (RETENTION_EVIDENCE_TYPES.includes(evType)) {
        retentionEvidence.push(ev);
      } else if (COMPETENCE_EVIDENCE_TYPES.includes(evType) || ev.independentApplication) {
        competenceEvidence.push(ev);
      } else {
        learningEvidence.push(ev);
      }
    }

    // 1. Activity Progress (0-100): completed tasks & practice volume vs target (NO evidence, NO test scores, NO reviews)
    const completedTasks = tasks.filter((t) => t.status === 'completed').length;
    const taskRatio = tasks.length > 0 ? completedTasks / tasks.length : 0;
    const targetMinutes = Math.max(60, (skill.masteryCriteria?.minPracticeHours || 10) * 60);
    const actualMinutes =
      (skill.metrics?.totalStudyMinutes || 0) + (skill.metrics?.totalPracticeMinutes || 0);
    const volumeRatio = Math.min(1, actualMinutes / targetMinutes);
    const activityProgress = Math.min(100, Math.round((taskRatio * 0.5 + volumeRatio * 0.5) * 100));

    // 2. Learning Progress (0-100): curriculum completion + learning/acquisition evidence + subskill training sessions
    const completedCurr = curriculum.filter((c) => c.completed).length;
    const currRatio = curriculum.length > 0 ? completedCurr / curriculum.length : 0.5;
    const reqEv = Math.max(1, skill.masteryCriteria?.requiredEvidenceCount || 1);
    const learningEvRatio = Math.min(1, learningEvidence.length / reqEv);
    const trainedSubs = subskills.filter((s) => (s.training?.completedSessions || 0) > 0).length;
    const subTrainRatio = subskills.length > 0 ? trainedSubs / subskills.length : learningEvRatio;
    const learningProgress = Math.min(
      100,
      Math.round((currRatio * 0.35 + learningEvRatio * 0.35 + subTrainRatio * 0.3) * 100)
    );

    // 3. Competence (0-100): test_attempts scores & accuracy + competenceEvidence bonus minus penalty for unresolved errors
    const bestScore = attempts.reduce((max, a) => Math.max(max, a.score || 0), 0);
    const bestAccuracy = attempts.reduce((max, a) => Math.max(max, a.accuracy || 0), 0);
    const openErrors = errors.filter((e) => e.status !== 'resolved');
    const compEvQuality =
      competenceEvidence.length > 0
        ? competenceEvidence.reduce((s, e) => s + Number(e.qualityScore || 80), 0) /
          competenceEvidence.length
        : 0;
    const rawCompetence =
      attempts.length > 0
        ? bestScore * 0.6 + bestAccuracy * 0.4
        : compEvQuality * 0.5;
    const competence = Math.max(
      0,
      Math.min(100, Math.round(rawCompetence - openErrors.length * 10))
    );

    // 4. Mastery (0-100): Mastery Gate criteria satisfaction + mastered subskills ratio
    const gate = await this.evaluateMasteryGate('skill', skillId);
    const checkValues = Object.values(gate.checks);
    const passedChecksCount = checkValues.filter(Boolean).length;
    const gateRatio = checkValues.length > 0 ? passedChecksCount / checkValues.length : 0;
    const masteredSubs = subskills.filter(
      (s) => s.masteryState === 'MASTERED' || s.masteryState === 'MAINTENANCE'
    ).length;
    const subMasteryRatio = subskills.length > 0 ? masteredSubs / subskills.length : gateRatio;
    const mastery =
      skill.status === 'MASTERED' || skill.status === 'MAINTENANCE'
        ? 100
        : Math.min(99, Math.round((gateRatio * 0.6 + subMasteryRatio * 0.4) * 100));

    // 5. Retention (0-100): Post-mastery maintenance reviews & retentionEvidence (independent of initial tests)
    let retention = 0;
    if (reviews.length > 0) {
      const latestReview = [...reviews].sort((a, b) =>
        String(b.reviewDate || '').localeCompare(String(a.reviewDate || ''))
      )[0];
      const avgRevScore = Math.round(
        reviews.reduce((s, r) => s + r.score, 0) / reviews.length
      );
      retention = latestReview.passed === false ? Math.min(avgRevScore, latestReview.score) : avgRevScore;
    } else if (retentionEvidence.length > 0) {
      retention = Math.round(
        retentionEvidence.reduce((s, e) => s + Number(e.qualityScore || 80), 0) /
          retentionEvidence.length
      );
    } else if (skill.status === 'MASTERED' || skill.status === 'MAINTENANCE') {
      retention = skill.maintenanceCriteria?.retentionRate ?? 100;
    }

    // Overdue maintenance check
    const nextRevDate = skill.maintenanceCriteria?.nextReviewDate;
    const isOverdueMaintenance = Boolean(
      (skill.status === 'MAINTENANCE' || skill.status === 'MASTERED') &&
        nextRevDate &&
        String(nextRevDate) < String(referenceDate)
    );

    const weakSubskills = subskills.filter((sub) => {
      const subHasOpenErr = errors.some(
        (e) => e.subskillId === sub.id && e.status !== 'resolved'
      );
      return (
        subHasOpenErr ||
        sub.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING' ||
        (sub.masteryState === 'IN_PROGRESS' && (sub.training?.completedSessions || 0) === 0)
      );
    });

    const isWeak =
      openErrors.length > 0 ||
      skill.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING' ||
      (attempts.length > 0 && bestScore < (skill.masteryCriteria?.minTestScore || 85));

    const weaknessIndicators = {
      isWeak,
      unresolvedErrorsCount: openErrors.length,
      criticalErrorsCount: openErrors.filter((e) => e.severity === 'critical' || e.severity === 'high').length,
      weakSubskillsCount: weakSubskills.length,
      weakSubskillIds: weakSubskills.map((s) => s.id),
      isOverdueMaintenance,
      inRetentionRelearning: skill.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING',
      historicalMasteryAchieved: Boolean(
        skill.historicalMasteryAchieved ||
          skill.status === 'MASTERED' ||
          skill.status === 'MAINTENANCE'
      ),
      currentRetentionStatus:
        skill.currentRetentionStatus ||
        (skill.status === 'MAINTENANCE'
          ? 'RETAINED'
          : skill.status === 'MASTERED'
          ? 'ACTIVE_MASTERY'
          : 'UNMASTERED'),
    };

    const evidencePartition = {
      learningEvidenceIds: learningEvidence.map((e) => e.id),
      competenceEvidenceIds: competenceEvidence.map((e) => e.id),
      retentionEvidenceIds: retentionEvidence.map((e) => e.id),
      totalEvidenceCount: evidence.length,
      partitionedSum:
        learningEvidence.length + competenceEvidence.length + retentionEvidence.length,
      zeroDoubleCountingVerified:
        learningEvidence.length + competenceEvidence.length + retentionEvidence.length ===
        evidence.length,
    };

    const progress = {
      activityProgress,
      learningProgress,
      competence,
      mastery,
      retention,
      weaknessIndicators,
      evidencePartition,
    };

    await this.db.put('skills', {
      ...skill,
      historicalMasteryAchieved: weaknessIndicators.historicalMasteryAchieved,
      currentRetentionStatus: weaknessIndicators.currentRetentionStatus,
      progress,
      updatedAt: new Date().toISOString(),
    });

    // Propagate progress to linked Goal if any
    if (skill.goalId) {
      const goal = await this.db.get('goals', skill.goalId);
      if (goal) {
        const allSkillsForGoal = (await this.db.getAll('skills')).filter(
          (s) => s.goalId === skill.goalId || s.capabilityId === goal.capabilityId
        );
        if (allSkillsForGoal.length > 0) {
          const avgGoalProg = Math.round(
            allSkillsForGoal.reduce((sum, s) => {
              const p = s.id === skillId ? progress : s.progress || {};
              return (
                sum +
                ((p.mastery || 0) * 0.5 +
                  (p.competence || 0) * 0.3 +
                  (p.learningProgress || 0) * 0.2)
              );
            }, 0) / allSkillsForGoal.length
          );
          await this.db.put('goals', {
            ...goal,
            progressPct: Math.max(goal.progressPct || 0, Math.min(100, avgGoalProg)),
          });
        }
      }
    }

    return progress;
  }

  async getSkillDetailBundle(skillId) {
    const skill = await this.db.get('skills', skillId);
    if (!skill) return null;

    const stores = await this.db.listStores();
    const hasDiagStore = stores.includes('diagnostic_assessments');
    const hasMastHistStore = stores.includes('mastery_history');

    const [
      subskills,
      curriculum,
      evidence,
      tests,
      attempts,
      errors,
      remediations,
      reviews,
      tasks,
      skillGate,
      diagnosticAssessments,
      masteryHistory,
    ] = await Promise.all([
      this.db.queryByField('subskills', 'skillId', skillId),
      this.db.queryByField('curriculum', 'skillId', skillId),
      this.db.queryByField('evidence', 'skillId', skillId),
      this.db.queryByField('tests', 'skillId', skillId),
      this.db.queryByField('test_attempts', 'skillId', skillId),
      this.db.queryByField('errors', 'skillId', skillId),
      this.db.queryByField('remediations', 'skillId', skillId),
      this.db.queryByField('reviews', 'skillId', skillId),
      this.db.queryByField('tasks', 'skillId', skillId),
      this.evaluateMasteryGate('skill', skillId),
      hasDiagStore ? this.db.queryByField('diagnostic_assessments', 'skillId', skillId) : [],
      hasMastHistStore ? this.db.queryByField('mastery_history', 'skillId', skillId) : [],
    ]);

    const subskillGates = {};
    for (const sub of subskills) {
      subskillGates[sub.id] = await this.evaluateMasteryGate('subskill', sub.id);
    }

    const prereqStatus = await this.checkPrerequisitesMet('skill', skill.prerequisites);

    return {
      skill,
      prereqStatus,
      skillGate,
      subskills,
      subskillGates,
      curriculum,
      evidence,
      tests,
      attempts,
      errors,
      remediations,
      reviews,
      correctiveTasks: tasks.filter((t) => t.isCorrective),
      diagnosticAssessments,
      masteryHistory: masteryHistory.sort((a, b) =>
        String(b.timestamp || '').localeCompare(String(a.timestamp || ''))
      ),
    };
  }
}
