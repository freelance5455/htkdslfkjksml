/**
 * WHITE ROOM OS — Phase 5 Integrated Diagnostics, Error Classification, Root-Cause Hypotheses,
 * Targeted Remediation, Verified Retesting, Mastery Traceability & Retention Engine
 *
 * Implements the full Phase 5 evidence-driven pipeline:
 * Assessment → Diagnosis → Error → Remediation → Corrective Practice → Retest
 * → Verification → Mastery Evaluation → Maintenance → Retention Check
 *
 * Reuses and integrates with existing SkillEngine, LearningEngine, PerformanceEngine, and AdaptiveSchedulerEngine.
 */

import {
  ERROR_TAXONOMY_CATEGORIES,
  RETEST_VERIFICATION_MODES,
  normalizeErrorCategory,
} from '../core/schema.js';

export const DEFAULT_ERROR_TAXONOMY_METADATA = Object.freeze({
  conceptual_misunderstanding: {
    code: 'conceptual_misunderstanding',
    labelAr: 'سوء فهم مفاهيمي (Conceptual Misunderstanding)',
    labelEn: 'Conceptual misunderstanding',
    defaultRemediationType: 'explanation_and_teach_back',
    defaultStrategy: 'شرح موجه للمفهوم الأساسي متبوعاً بجلسة شرح ذاتي (Feynman Teach-Back)',
  },
  missing_prerequisite: {
    code: 'missing_prerequisite',
    labelAr: 'نقص في متطلب سابق (Missing Prerequisite)',
    labelEn: 'Missing prerequisite',
    defaultRemediationType: 'prerequisite_review_and_test',
    defaultStrategy: 'مراجعة المتطلب السابق المفقود واجتياز فحص جاهزية قبل المتابعة',
  },
  procedural_error: {
    code: 'procedural_error',
    labelAr: 'خطأ في خطوات الإجراء (Procedural Error)',
    labelEn: 'Procedural error',
    defaultRemediationType: 'worked_example_and_independent_practice',
    defaultStrategy: 'دراسة مثال محلول خطوة بخطوة (Worked Example) متبوعاً بتطبيق مستقل',
  },
  calculation_execution_error: {
    code: 'calculation_execution_error',
    labelAr: 'خطأ حسابي أو تنفيذي (Calculation / Execution Error)',
    labelEn: 'Calculation or execution error',
    defaultRemediationType: 'execution_accuracy_drill',
    defaultStrategy: 'تدريب دقة تنفيذي متدرج مع قائمة تحقق ذاتي لكل خطوة حسابية/برمجية',
  },
  recall_failure: {
    code: 'recall_failure',
    labelAr: 'إخفاق في الاسترجاع من الذاكرة (Recall Failure)',
    labelEn: 'Recall failure',
    defaultRemediationType: 'retrieval_practice_and_scheduled_review',
    defaultStrategy: 'ممارسة استرجاع نشط (Retrieval Practice) وجدولة مراجعة متباعدة',
  },
  misapplication: {
    code: 'misapplication',
    labelAr: 'سوء تطبيق في سياق جديد (Misapplication)',
    labelEn: 'Misapplication',
    defaultRemediationType: 'varied_problems_and_transfer_practice',
    defaultStrategy: 'حل مسائل متنوعة في سياقات مختلفة (Varied Contexts & Transfer Practice)',
  },
  attention_careless_error: {
    code: 'attention_careless_error',
    labelAr: 'خطأ انتباه أو تسرع (Attention / Careless Error)',
    labelEn: 'Attention or careless error',
    defaultRemediationType: 'verification_checklist_practice',
    defaultStrategy: 'تطبيق قائمة فحص ومراجعة ذاتية إلزامية قبل تسليم الحل',
  },
  strategy_selection_error: {
    code: 'strategy_selection_error',
    labelAr: 'خطأ في اختيار الاستراتيجية (Strategy Selection Error)',
    labelEn: 'Strategy selection error',
    defaultRemediationType: 'strategy_discrimination_practice',
    defaultStrategy: 'مقارنة شروط استخدام الاستراتيجيات وتمييز الأنماط قبل البدء بالحل',
  },
  time_management_issue: {
    code: 'time_management_issue',
    labelAr: 'مشكلة في إدارة الوقت أو إكمال المهمة (Time-Management Issue)',
    labelEn: 'Time-management issue',
    defaultRemediationType: 'timed_paced_practice',
    defaultStrategy: 'تقسيم المهمة إلى وحدات زمنية قصيرة (Chunked Timed Drills) وتوزيع الجهد',
  },
  incomplete_evidence: {
    code: 'incomplete_evidence',
    labelAr: 'نقص في الأدلة التطبيقية أو العملية (Incomplete Evidence)',
    labelEn: 'Incomplete evidence',
    defaultRemediationType: 'practical_demonstration',
    defaultStrategy: 'تقديم عرض عملي تطبيقي موثق (Practical Demonstration) يثبت الكفاءة الفعلية',
  },
  unknown_unclassified: {
    code: 'unknown_unclassified',
    labelAr: 'سبب غير محدد / قيد الاستقصاء التشخيصي (Unknown / Unclassified)',
    labelEn: 'Unknown cause',
    defaultRemediationType: 'diagnostic_isolation_probe',
    defaultStrategy: 'جلسة تشخيص تفصيلي (Diagnostic Isolation Probe) لعزل موضع التعثر دون افتراض مسبق',
  },
});

export class DiagnosticsAndMasteryEngine {
  constructor(db, engines = {}) {
    this.db = db;
    this.skillEngine = engines.skillEngine;
    this.learningEngine = engines.learningEngine;
    this.performanceEngine = engines.performanceEngine;
    this.schedulerEngine = engines.schedulerEngine;
    this.customTaxonomy = { ...DEFAULT_ERROR_TAXONOMY_METADATA };
  }

  // =========================================================================
  // 1. CONFIGURABLE ERROR TAXONOMY
  // =========================================================================

  getErrorTaxonomy() {
    return { ...this.customTaxonomy };
  }

  configureErrorTaxonomy(domainCategories = {}) {
    for (const [code, meta] of Object.entries(domainCategories)) {
      if (!code) continue;
      this.customTaxonomy[code] = {
        code,
        labelAr: meta.labelAr || meta.labelEn || code,
        labelEn: meta.labelEn || code,
        defaultRemediationType: meta.defaultRemediationType || 'focused_remediation',
        defaultStrategy:
          meta.defaultStrategy || 'خطة علاجية مخصصة للمجال مع تحقق تطبيقي مستقل',
      };
    }
    return this.getErrorTaxonomy();
  }

  resolveCategoryCode(rawCategory) {
    if (!rawCategory) return 'unknown_unclassified';
    const str = String(rawCategory).trim();
    if (this.customTaxonomy[str]) return str;
    return normalizeErrorCategory(str);
  }

  // =========================================================================
  // 2. DIAGNOSTIC ENGINE (OBSERVED FACTS VS. INFERRED HYPOTHESES)
  // =========================================================================

  /**
   * Conducts an evidence-driven Diagnostic Assessment on a Skill / Subskill / Objective.
   * Collects actual persisted records and optional new assessment inputs, separates observed facts
   * from inferred root-cause hypotheses, never claims certainty when evidence only supports a hypothesis,
   * and never uses derogatory labels.
   */
  async runDiagnosticAssessment(payload = {}) {
    const {
      skillId,
      subskillId = null,
      objectiveId = null,
      sessionId = null,
      testId = null,
      attemptId = null,
      assessmentTitle = '',
      score = null,
      accuracy = null,
      incorrectAnswersCount = 0,
      failedRecallCount = 0,
      incompletePracticalCount = 0,
      abandonedTaskCount = 0,
      reportedCategory = null,
      observedNotes = '',
      createErrorIfWeak = true,
      date = new Date().toISOString().slice(0, 10),
    } = payload;

    const skill = await this.db.get('skills', skillId);
    if (!skill) {
      throw new Error(`Skill not found for diagnostic assessment: ${skillId}`);
    }
    const subskill = subskillId ? await this.db.get('subskills', subskillId) : null;
    const objective = objectiveId
      ? await this.db.get('learning_objectives', objectiveId)
      : null;

    // Gather persisted evidence signals for this skill / subskill
    const [
      skillPrereqCheck,
      subPrereqCheck,
      allAttempts,
      allErrors,
      allRecallAttempts,
      allReviews,
      allTasks,
      allEvidence,
      allFeynman,
    ] = await Promise.all([
      this.skillEngine.checkPrerequisitesMet('skill', skill.prerequisites || []),
      subskill
        ? this.skillEngine.checkPrerequisitesMet('subskill', subskill.prerequisites || [])
        : Promise.resolve({ allMet: true, unmetIds: [], details: [] }),
      this.db.queryByField('test_attempts', 'skillId', skillId),
      this.db.queryByField('errors', 'skillId', skillId),
      this.db.queryByField('recall_attempts', 'skillId', skillId),
      this.db.queryByField('reviews', 'skillId', skillId),
      this.db.queryByField('tasks', 'skillId', skillId),
      this.db.queryByField('evidence', 'skillId', skillId),
      this.db.queryByField('feynman_entries', 'skillId', skillId),
    ]);

    const scopedAttempts = subskillId
      ? allAttempts.filter((a) => a.subskillId === subskillId)
      : allAttempts;
    const scopedErrors = subskillId
      ? allErrors.filter((e) => e.subskillId === subskillId)
      : allErrors;
    const scopedRecalls = subskillId
      ? allRecallAttempts.filter((r) => r.subskillId === subskillId)
      : allRecallAttempts;
    const scopedReviews = subskillId
      ? allReviews.filter((r) => r.subskillId === subskillId)
      : allReviews;
    const scopedTasks = subskillId
      ? allTasks.filter((t) => t.subskillId === subskillId)
      : allTasks;
    const scopedEvidence = subskillId
      ? allEvidence.filter((e) => e.subskillId === subskillId)
      : allEvidence;

    // Build Observed Facts strictly from recorded data & explicit assessment metrics
    const observedFacts = [];
    const evidenceSignals = {
      incorrectAnswers: Number(incorrectAnswersCount || 0),
      repeatedErrors: 0,
      lowAccuracy: false,
      failedTests: 0,
      failedRecall: Number(failedRecallCount || 0),
      failedRetentionChecks: 0,
      incompletePracticalTasks: Number(incompletePracticalCount || 0),
      missingPrerequisites: [],
      repeatedTaskAbandonment: Number(abandonedTaskCount || 0),
    };

    // 1. Missing prerequisites
    const unmetPrereqs = [
      ...(skillPrereqCheck.unmetIds || []),
      ...(subPrereqCheck.unmetIds || []),
    ];
    if (unmetPrereqs.length > 0) {
      evidenceSignals.missingPrerequisites = unmetPrereqs;
      observedFacts.push(
        `متطلبات سابقة غير مكتملة (Missing Prerequisites): ${unmetPrereqs.join(', ')}`
      );
    }

    // 2. Failed tests & Low accuracy
    const failedTestRecords = scopedAttempts.filter((a) => !a.passed);
    evidenceSignals.failedTests =
      failedTestRecords.length + (score !== null && Number(score) < 85 ? 1 : 0);
    if (failedTestRecords.length > 0) {
      observedFacts.push(
        `سجل الاختبارات يظهر (${failedTestRecords.length}) محاولة اختبار غير مجتازة (آخر درجة: ${
          failedTestRecords[failedTestRecords.length - 1].score
        }%)`
      );
    }
    if (score !== null) {
      observedFacts.push(`درجة التقييم التشخيصي المسجلة: ${Number(score)}%`);
    }

    const minAccTarget =
      subskill?.masteryCriteria?.minAccuracy || skill.masteryCriteria?.minAccuracy || 80;
    const latestAcc =
      accuracy !== null
        ? Number(accuracy)
        : scopedAttempts.length > 0
        ? Number(scopedAttempts[scopedAttempts.length - 1].accuracy)
        : null;
    if (latestAcc !== null && latestAcc < minAccTarget) {
      evidenceSignals.lowAccuracy = true;
      observedFacts.push(
        `انخفاض الدقة الملاحظة (${latestAcc}%) عن المعيار المطلوب (${minAccTarget}%)`
      );
    }

    // 3. Incorrect answers
    if (evidenceSignals.incorrectAnswers > 0) {
      observedFacts.push(
        `تم رصد (${evidenceSignals.incorrectAnswers}) إجابات غير صحيحة في بنود التقييم`
      );
    }

    // 4. Repeated errors
    const openErrors = scopedErrors.filter((e) => e.status !== 'resolved');
    const maxFailureCount = scopedErrors.reduce(
      (max, e) => Math.max(max, Number(e.failureCount || 1)),
      0
    );
    if (openErrors.length >= 2 || maxFailureCount >= 2) {
      evidenceSignals.repeatedErrors = Math.max(openErrors.length, maxFailureCount);
      observedFacts.push(
        `تكرار الأخطاء المسجلة (${evidenceSignals.repeatedErrors} مرات / أخطاء مفتوحة: ${openErrors.length})`
      );
    } else if (openErrors.length === 1) {
      observedFacts.push(`يوجد خطأ مفتوح قيد المعالجة (${openErrors[0].id}: ${openErrors[0].description})`);
    }

    // 5. Failed recall & overconfident illusions
    const failedRecalls = scopedRecalls.filter(
      (r) => Number(r.accuracyScore || 0) < 70 || r.calibrationState === 'OVERCONFIDENT_ILLUSION'
    );
    evidenceSignals.failedRecall += failedRecalls.length;
    if (evidenceSignals.failedRecall > 0) {
      observedFacts.push(
        `إخفاق في الاسترجاع النشط (Failed Recall: ${evidenceSignals.failedRecall} محاولات استرجاع دون الحد المطلوب)`
      );
    }

    // 6. Failed retention checks
    const failedReviews = scopedReviews.filter((r) => r.passed === false || Number(r.score || 100) < 80);
    evidenceSignals.failedRetentionChecks = failedReviews.length;
    if (failedReviews.length > 0) {
      observedFacts.push(
        `تراجع في فحوصات الاحتفاظ الدورية (Failed Retention Checks: ${failedReviews.length})`
      );
    }

    // 7. Incomplete practical tasks & missing required evidence types
    const partialTasks = scopedTasks.filter((t) => t.status === 'partially_completed');
    evidenceSignals.incompletePracticalTasks += partialTasks.length;
    const reqEvCount =
      subskill?.masteryCriteria?.requiredEvidenceCount ||
      skill.masteryCriteria?.requiredEvidenceCount ||
      1;
    if (evidenceSignals.incompletePracticalTasks > 0 || scopedEvidence.length < reqEvCount) {
      observedFacts.push(
        `نقص في المهام التطبيقية المكتملة أو الأدلة العملية الموثقة (${scopedEvidence.length}/${reqEvCount} دليل، مهام جزئية: ${evidenceSignals.incompletePracticalTasks})`
      );
    }

    // 8. Repeated task abandonment / skipping
    const abandonedTasks = scopedTasks.filter(
      (t) => t.status === 'skipped' || Number(t.skipCount || 0) >= 2
    );
    evidenceSignals.repeatedTaskAbandonment += abandonedTasks.length;
    if (evidenceSignals.repeatedTaskAbandonment > 0) {
      observedFacts.push(
        `تكرار تخطي أو عدم إكمال المهام المجدولة (Repeated Task Abandonment: ${evidenceSignals.repeatedTaskAbandonment} مهام)`
      );
    }

    if (observedNotes && String(observedNotes).trim().length > 0) {
      observedFacts.push(`ملاحظة رصد مباشر: ${String(observedNotes).trim()}`);
    }

    // Generate Inferred Root-Cause Hypotheses strictly grounded in observedFacts
    const hypotheses = this._buildRootCauseHypotheses({
      evidenceSignals,
      observedFacts,
      reportedCategory,
      scopedFeynman: allFeynman,
      scopedRecalls,
      scopedAttempts,
    });

    const primaryCategory =
      reportedCategory
        ? this.resolveCategoryCode(reportedCategory)
        : hypotheses.length > 0
        ? hypotheses[0].category
        : 'unknown_unclassified';

    const isWeak =
      evidenceSignals.missingPrerequisites.length > 0 ||
      evidenceSignals.failedTests > 0 ||
      evidenceSignals.lowAccuracy ||
      evidenceSignals.incorrectAnswers > 0 ||
      evidenceSignals.repeatedErrors > 0 ||
      evidenceSignals.failedRecall > 0 ||
      evidenceSignals.failedRetentionChecks > 0 ||
      evidenceSignals.repeatedTaskAbandonment > 0 ||
      openErrors.length > 0;

    const nowIso = new Date().toISOString();
    const diagId =
      payload.id || `diag_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    let linkedError = null;
    if (createErrorIfWeak && isWeak) {
      const severity =
        evidenceSignals.repeatedErrors >= 2 ||
        evidenceSignals.missingPrerequisites.length > 0 ||
        (score !== null && Number(score) < 50)
          ? 'critical'
          : evidenceSignals.failedTests > 0 || evidenceSignals.lowAccuracy
          ? 'high'
          : 'medium';

      const taxonomyMeta =
        this.customTaxonomy[primaryCategory] ||
        DEFAULT_ERROR_TAXONOMY_METADATA.unknown_unclassified;

      linkedError = await this.db.put('errors', {
        id: payload.errorId || `err_diag_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        goalId: skill.goalId || objective?.goalId || null,
        capabilityId: skill.capabilityId || skill.domain || null,
        skillId,
        linkedSkill: skillId,
        subskillId,
        linkedSubskill: subskillId,
        subskill: subskill?.name || 'Diagnostic Assessment',
        objectiveId: objectiveId || null,
        sessionId: sessionId || null,
        testId: testId || null,
        linkedTestAttemptId: attemptId || null,
        diagnosticAssessmentId: diagId,
        category: primaryCategory,
        classificationState:
          primaryCategory === 'unknown_unclassified' ? 'unclassified' : 'hypothesized',
        severity,
        description:
          payload.errorDescription ||
          `تشخيص فجوة كفاءة في ${subskill?.name || skill.nameAr || skill.name} (${taxonomyMeta.labelAr})`,
        cause:
          hypotheses[0]?.explanation ||
          'فرضية أولية قيد التحقق بناءً على الأدلة المرصودة',
        observedFacts,
        hypotheses,
        uncertaintyNote:
          hypotheses[0]?.uncertaintyNote ||
          'الأسباب المقترحة تمثل فرضيات عمل مبنية على الأدلة المتاحة وليست أحكاماً قطعية؛ يتم التحقق منها عبر التمرين التصحيحي وإعادة الاختبار.',
        verificationMethod:
          hypotheses[0]?.verificationMethod ||
          'تنفيذ خطة علاجية موجهة متبوعة بإعادة اختبار في سياق مكافئ أو جديد.',
        date,
        evidence: observedFacts.join(' | '),
        remediation: taxonomyMeta.defaultStrategy,
        remediationId: null,
        retestAttemptIds: [],
        failureCount: Math.max(1, evidenceSignals.repeatedErrors || 1),
        retestRequired: true,
        status: 'open',
      });

      if (subskill) {
        await this.db.put('subskills', {
          ...subskill,
          errors: [...new Set([...(subskill.errors || []), linkedError.id])],
          updatedAt: nowIso,
        });
      }
    }

    const diagnosticRecord = await this.db.put('diagnostic_assessments', {
      id: diagId,
      title:
        assessmentTitle ||
        `تقييم تشخيصي متكامل: ${subskill?.name || skill.nameAr || skill.name}`,
      goalId: skill.goalId || objective?.goalId || null,
      capabilityId: skill.capabilityId || skill.domain || null,
      skillId,
      subskillId,
      objectiveId,
      sessionId,
      testId,
      attemptId,
      date,
      score: score !== null && score !== undefined ? Number(score) : null,
      accuracy: accuracy !== null && accuracy !== undefined ? Number(accuracy) : null,
      isWeak,
      primaryCategory,
      classificationState:
        primaryCategory === 'unknown_unclassified' ? 'unclassified' : 'hypothesized',
      evidenceSignals,
      observedFacts,
      hypotheses,
      linkedErrorId: linkedError?.id || null,
      recommendedAction: isWeak
        ? this.customTaxonomy[primaryCategory]?.defaultStrategy ||
          DEFAULT_ERROR_TAXONOMY_METADATA.unknown_unclassified.defaultStrategy
        : 'المهارة مستقرة حالياً؛ الاستمرار في التدريب التطبيقي أو الصيانة الدورية.',
      createdAt: nowIso,
    });

    await this.skillEngine.calculateSkillProgress(skillId, date);

    return {
      diagnostic: diagnosticRecord,
      isWeak,
      observedFacts,
      hypotheses,
      createdError: linkedError,
    };
  }

  _buildRootCauseHypotheses({
    evidenceSignals,
    observedFacts,
    reportedCategory,
    scopedFeynman = [],
    scopedRecalls = [],
  }) {
    const hypotheses = [];

    if (evidenceSignals.missingPrerequisites.length > 0) {
      hypotheses.push({
        category: 'missing_prerequisite',
        explanation:
          'فرضية: التعثر ناتج عن عدم إتقان المتطلبات التأسيسية السابقة اللازمة لبناء هذه المهارة.',
        supportingEvidence: observedFacts.filter((f) => f.includes('متطلبات سابقة')),
        confidenceScore: 0.85,
        confidenceLevel: 'high',
        uncertaintyNote:
          'رغم وضوح نقص المتطلب السابق في السجل، يجب التحقق مما إذا كان هو العائق الوحيد بعد مراجعته.',
        verificationMethod:
          'إتمام مراجعة المتطلب السابق واجتياز اختبار جاهزية قصير ثم إعادة محاولة المهارة الحالية.',
      });
    }

    const hasOverconfidentRecall = scopedRecalls.some(
      (r) => r.calibrationState === 'OVERCONFIDENT_ILLUSION'
    );
    const hasWeakFeynman = scopedFeynman.some((f) => (f.detectedGaps || []).length > 0);
    if (
      reportedCategory === 'conceptual_misunderstanding' ||
      hasOverconfidentRecall ||
      hasWeakFeynman
    ) {
      const sup = observedFacts.filter(
        (f) =>
          f.includes('اختبار') ||
          f.includes('استرجاع') ||
          f.includes('إجابات غير صحيحة') ||
          f.includes('ملاحظة')
      );
      hypotheses.push({
        category: 'conceptual_misunderstanding',
        explanation:
          'فرضية: وجود التباس في النموذج الذهني للمفهوم الأساسي (وليس مجرد نسيان عابر).',
        supportingEvidence: sup.length > 0 ? sup : [observedFacts[0] || 'بيانات التقييم المسجلة'],
        confidenceScore: 0.72,
        confidenceLevel: 'moderate',
        uncertaintyNote:
          'الأدلة تشير إلى صعوبة في التفسير المفاهيمي، لكن لا يمكن الجزم دون اختبار الشرح الذاتي (Teach-Back).',
        verificationMethod:
          'تكليف المتعلم بشرح المفهوم بأسلوبه (Feynman Teach-Back) وحل سؤال مفاهيمي مكافئ.',
      });
    }

    if (
      reportedCategory === 'procedural_error' ||
      reportedCategory === 'calculation_execution_error' ||
      (evidenceSignals.lowAccuracy && evidenceSignals.failedRecall === 0)
    ) {
      const cat =
        reportedCategory === 'calculation_execution_error'
          ? 'calculation_execution_error'
          : 'procedural_error';
      hypotheses.push({
        category: cat,
        explanation:
          'فرضية: المفهوم العام مفهوم، لكن يحدث خلل أثناء تسلسل خطوات التنفيذ أو الحساب التطبيقي.',
        supportingEvidence: observedFacts.filter(
          (f) => f.includes('الدقة') || f.includes('إجابات') || f.includes('اختبار')
        ),
        confidenceScore: 0.68,
        confidenceLevel: 'moderate',
        uncertaintyNote:
          'انخفاض الدقة قد ينتج عن خطأ إجرائي متكرر أو تسرع؛ يلزم فحص خطوات الحل خطوة بخطوة.',
        verificationMethod:
          'مقارنة خطوات الحل بمثال محلول (Worked Example) ثم تنفيذ تمرين مستقل تحت الملاحظة.',
      });
    }

    if (
      reportedCategory === 'recall_failure' ||
      evidenceSignals.failedRecall > 0 ||
      evidenceSignals.failedRetentionChecks > 0
    ) {
      hypotheses.push({
        category: 'recall_failure',
        explanation:
          'فرضية: صعوبة في استدعاء المعلومة أو القاعدة من الذاكرة طويلة المدى عند الحاجة إليها بدون تلميحات.',
        supportingEvidence: observedFacts.filter(
          (f) => f.includes('الاسترجاع') || f.includes('الاحتفاظ') || f.includes('اختبار')
        ),
        confidenceScore: 0.78,
        confidenceLevel: 'moderate',
        uncertaintyNote:
          'قد يكون الإخفاق ناتجاً عن طول فترة الانقطاع وليس غياب الفهم الأصلي.',
        verificationMethod:
          'جلسة استرجاع نشط (Active Recall) متبوعة بفحص احتفاظ مؤجل (Delayed Retention Check).',
      });
    }

    if (
      reportedCategory === 'misapplication' ||
      reportedCategory === 'strategy_selection_error' ||
      evidenceSignals.repeatedErrors >= 2
    ) {
      const cat =
        reportedCategory === 'strategy_selection_error'
          ? 'strategy_selection_error'
          : 'misapplication';
      hypotheses.push({
        category: cat,
        explanation:
          'فرضية: صعوبة في نقل القاعدة أو اختيار الاستراتيجية المناسبة عند تغير سياق المسألة.',
        supportingEvidence: observedFacts.filter(
          (f) => f.includes('تكرار') || f.includes('اختبار') || f.includes('إجابات')
        ),
        confidenceScore: 0.65,
        confidenceLevel: 'moderate',
        uncertaintyNote:
          'تكرار الخطأ يرجح وجود فجوة في نقل الأثر (Transfer)، ويتطلب التحقق عبر مسائل متنوعة السياق.',
        verificationMethod:
          'اختبار الأداء في سياقات ومسائل متنوعة غير مألوفة (Varied Problem Contexts).',
      });
    }

    if (
      reportedCategory === 'time_management_issue' ||
      evidenceSignals.repeatedTaskAbandonment > 0
    ) {
      hypotheses.push({
        category: 'time_management_issue',
        explanation:
          'فرضية: حجم المهمة أو توقيتها يفوق نافذة التركيز المتاحة مما يؤدي إلى التخطي أو عدم الإكمال.',
        supportingEvidence: observedFacts.filter(
          (f) => f.includes('تخطي') || f.includes('مهام')
        ),
        confidenceScore: 0.74,
        confidenceLevel: 'moderate',
        uncertaintyNote:
          'عدم إكمال المهام مؤشر تنظيمي/زمني ولا يعكس نقصاً في القدرة الذهنية؛ يتم التحقق بتقليص حجم الجلسة.',
        verificationMethod:
          'تقسيم المهمة إلى جلسة قصيرة (25 دقيقة) في بداية فترة النشاط ومراقبة معدل الإنجاز.',
      });
    }

    if (
      reportedCategory === 'incomplete_evidence' ||
      evidenceSignals.incompletePracticalTasks > 0
    ) {
      hypotheses.push({
        category: 'incomplete_evidence',
        explanation:
          'فرضية: الدراسة النظرية لم تُدعم بعد بتطبيق عملي مكتمل وموثق يثبت الكفاءة.',
        supportingEvidence: observedFacts.filter(
          (f) => f.includes('الأدلة') || f.includes('المهام التطبيقية')
        ),
        confidenceScore: 0.8,
        confidenceLevel: 'high',
        uncertaintyNote:
          'غياب الدليل التطبيقي لا يعني بالضرورة عدم الفهم، لكنه يمنع التحقق الموضوعي من الإتقان.',
        verificationMethod:
          'تقديم عرض عملي تطبيقي مستقل (Practical Demonstration) وتوثيق مخرجاته.',
      });
    }

    if (reportedCategory === 'attention_careless_error') {
      hypotheses.push({
        category: 'attention_careless_error',
        explanation:
          'فرضية: القواعد الأساسية مفهومة ولكن حدثت هفوة غير مقصودة أثناء قراءة المعطيات أو كتابة الناتج.',
        supportingEvidence:
          observedFacts.length > 0 ? [observedFacts[0]] : ['ملاحظة خطأ غير متكرر في خطوة فرعية'],
        confidenceScore: 0.55,
        confidenceLevel: 'low',
        uncertaintyNote:
          'لا ينبغي افتراض أن الخطأ مجرد "تسرع" إلا بعد التأكد من عدم وجود سوء فهم مفاهيمي خفي.',
        verificationMethod:
          'حل مسألة مكافئة مع تطبيق قائمة مراجعة ذاتية قبل تسليم الإجابة.',
      });
    }

    // If no specific hypothesis matched or category was explicitly unknown_unclassified
    if (hypotheses.length === 0 || reportedCategory === 'unknown_unclassified') {
      hypotheses.unshift({
        category: 'unknown_unclassified',
        explanation:
          'السبب الدقيق غير مصنف بعد: الأدلة المتاحة حالياً ترصد التعثر ولكنها غير كافية للجزم بسبب جذري محدد.',
        supportingEvidence:
          observedFacts.length > 0
            ? observedFacts
            : ['بيانات أولية غير كافية للتصنيف القاطع'],
        confidenceScore: 0.35,
        confidenceLevel: 'low',
        uncertaintyNote:
          'يمتنع النظام عن تخمين سبب غير مدعوم بالأدلة؛ تم وضع الخطأ في حالة (Unknown / Unclassified) لحين إجراء فحص تشخيصي موجه.',
        verificationMethod:
          'إجراء تمرين تشخيصي تجزئي (Diagnostic Isolation Probe) لفصل الفهم المفاهيمي عن خطوات التنفيذ.',
      });
    }

    return hypotheses;
  }

  /**
   * Scans all skills and subskills in the database to identify weak areas, unresolved errors,
   * retention decay, and overdue maintenance reviews.
   */
  async scanWeakSkillsAndSubskills(referenceDate = '2026-10-14') {
    const [skills, subskills, errors, reviews, flashcards] = await Promise.all([
      this.db.getAll('skills'),
      this.db.getAll('subskills'),
      this.db.getAll('errors'),
      this.db.getAll('reviews'),
      this.db.getAll('flashcards'),
    ]);

    const openErrors = errors.filter((e) => e.status !== 'resolved');
    const weakSkills = [];
    const weakSubskills = [];
    const overdueMaintenanceSkills = [];

    for (const sk of skills) {
      const skErrors = openErrors.filter((e) => e.skillId === sk.id);
      const nextRev = sk.maintenanceCriteria?.nextReviewDate;
      const isOverdue = Boolean(
        (sk.status === 'MAINTENANCE' || sk.status === 'MASTERED') &&
          nextRev &&
          String(nextRev) <= String(referenceDate)
      );
      if (isOverdue) {
        overdueMaintenanceSkills.push({
          skillId: sk.id,
          name: sk.nameAr || sk.name,
          nextReviewDate: nextRev,
          status: sk.status,
          currentRetentionStatus: sk.currentRetentionStatus || 'DUE_FOR_REVIEW',
        });
      }

      const comp = sk.progress?.competence ?? 0;
      const isRetentionDecay =
        sk.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING';

      if (skErrors.length > 0 || isRetentionDecay || (sk.status === 'IN_PROGRESS' && comp < 70)) {
        weakSkills.push({
          skillId: sk.id,
          name: sk.nameAr || sk.name,
          status: sk.status,
          competence: comp,
          mastery: sk.progress?.mastery ?? 0,
          retention: sk.progress?.retention ?? 0,
          openErrorsCount: skErrors.length,
          inRetentionRelearning: isRetentionDecay,
          historicalMasteryAchieved: Boolean(sk.historicalMasteryAchieved),
          primaryReasons: [
            ...(skErrors.length > 0 ? [`${skErrors.length} أخطاء غير محلولة`] : []),
            ...(isRetentionDecay ? ['تراجع في الاحتفاظ يتطلب إعادة تعلم (Relearning)'] : []),
            ...(comp < 70 && sk.status === 'IN_PROGRESS' ? [`كفاءة حالية منخفضة (${comp}%)`] : []),
          ],
        });
      }
    }

    for (const sub of subskills) {
      const subErrors = openErrors.filter((e) => e.subskillId === sub.id);
      const isRetentionDecay =
        sub.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING';
      if (
        subErrors.length > 0 ||
        isRetentionDecay ||
        (sub.masteryState === 'IN_PROGRESS' && (sub.training?.completedSessions || 0) === 0)
      ) {
        weakSubskills.push({
          subskillId: sub.id,
          skillId: sub.skillId,
          name: sub.name,
          masteryState: sub.masteryState,
          openErrorsCount: subErrors.length,
          inRetentionRelearning: isRetentionDecay,
          historicalMasteryAchieved: Boolean(sub.historicalMasteryAchieved),
        });
      }
    }

    const dueFlashcards = flashcards.filter(
      (fc) => !fc.nextReviewDate || String(fc.nextReviewDate) <= String(referenceDate)
    );

    return {
      referenceDate,
      weakSkills,
      weakSubskills,
      unresolvedErrors: openErrors,
      overdueMaintenanceSkills,
      dueFlashcardsCount: dueFlashcards.length,
      totalReviewsCount: reviews.length,
    };
  }

  // =========================================================================
  // 3. TARGETED REMEDIATION GENERATION (REUSING SKILLENGINE.CREATEREMEDIATIONPLAN)
  // =========================================================================

  /**
   * Reuses SkillEngine.createRemediationPlan to generate corrective actions specifically
   * matched to the diagnosed error category.
   */
  async generateTargetedRemediation(errorId, options = {}) {
    const error = await this.db.get('errors', errorId);
    if (!error) {
      throw new Error(`Error not found for remediation: ${errorId}`);
    }

    const category = this.resolveCategoryCode(options.category || error.category);
    const meta =
      this.customTaxonomy[category] ||
      DEFAULT_ERROR_TAXONOMY_METADATA.unknown_unclassified;

    const skill = await this.db.get('skills', error.skillId);
    const subskill = error.subskillId
      ? await this.db.get('subskills', error.subskillId)
      : null;
    const targetName = subskill?.name || skill?.nameAr || skill?.name || error.skillId;
    const dateStr = options.date || error.date || new Date().toISOString().slice(0, 10);

    // Map each error category to its domain-appropriate corrective action blueprint
    const categoryTaskBlueprints = {
      missing_prerequisite: [
        {
          title: `[Prerequisite Review] مراجعة المتطلب السابق المفقود لـ: ${targetName}`,
          plannedDurationMin: 30,
          category: 'Remediation',
          remediationType: 'prerequisite_review_and_test',
          notes: 'مراجعة مركزة للمهارة التأسيسية السابقة وسد الفجوة قبل العودة للمهارة الحالية.',
        },
        {
          title: `[Prerequisite Check] فحص تحقق سريع للمتطلب السابق لـ: ${targetName}`,
          plannedDurationMin: 20,
          category: 'Remediation',
          remediationType: 'prerequisite_review_and_test',
          notes: 'التأكد من جاهزية المتطلب السابق عملياً.',
        },
      ],
      conceptual_misunderstanding: [
        {
          title: `[Targeted Explanation] تفكيك المفهوم وتصحيح النموذج الذهني: ${targetName}`,
          plannedDurationMin: 30,
          category: 'Remediation',
          remediationType: 'explanation_and_teach_back',
          notes: 'دراسة الشرح المستهدف وتحديد موضع الالتباس المفاهيمي بدقة.',
        },
        {
          title: `[Teach-Back / Feynman] شرح المفهوم ذاتياً بأسلوب مبسط مع أمثلة: ${targetName}`,
          plannedDurationMin: 25,
          category: 'Remediation',
          remediationType: 'explanation_and_teach_back',
          notes: 'كتابة شرح Feynman واضح بدون فجوات منطقية كدليل على استيعاب المفهوم.',
        },
      ],
      procedural_error: [
        {
          title: `[Worked Example] تحليل مثال محلول خطوة بخطوة: ${targetName}`,
          plannedDurationMin: 25,
          category: 'Remediation',
          remediationType: 'worked_example_and_independent_practice',
          notes: 'تتبع تسلسل الخطوات الصحيحة وتحديد الخطوة التي حدث فيها الانحراف الإجرائي.',
        },
        {
          title: `[Independent Practice] تطبيق مستقل بدون الاستعانة بالحل: ${targetName}`,
          plannedDurationMin: 35,
          category: 'Remediation',
          remediationType: 'worked_example_and_independent_practice',
          notes: 'حل مسألة كاملة بشكل مستقل للتحقق من سلامة الإجراء.',
        },
      ],
      calculation_execution_error: [
        {
          title: `[Execution Drill] تمرين دقة تنفيذي وحسابي متدرج: ${targetName}`,
          plannedDurationMin: 30,
          category: 'Remediation',
          remediationType: 'execution_accuracy_drill',
          notes: 'التدرب على الدقة التنفيذية ومراجعة كل خطوة فرعية قبل الانتقال للتالية.',
        },
      ],
      recall_failure: [
        {
          title: `[Retrieval Practice] جلسة استرجاع نشط من الذاكرة بدون ملاحظات: ${targetName}`,
          plannedDurationMin: 25,
          category: 'Remediation',
          remediationType: 'retrieval_practice_and_scheduled_review',
          notes: 'استدعاء القواعد والمفاهيم غيباً وتحديث بطاقات المراجعة المتباعدة.',
        },
      ],
      misapplication: [
        {
          title: `[Varied Problems] حل مسائل متنوعة في سياقات جديدة (Transfer Practice): ${targetName}`,
          plannedDurationMin: 40,
          category: 'Remediation',
          remediationType: 'varied_problems_and_transfer_practice',
          notes: 'تطبيق المهارة على 3 سياقات مختلفة لمنع الحفظ الآلي وبناء مرونة التطبيق.',
        },
      ],
      strategy_selection_error: [
        {
          title: `[Strategy Selection] تدريب تمييز الأنماط واختيار الاستراتيجية الأنسب: ${targetName}`,
          plannedDurationMin: 35,
          category: 'Remediation',
          remediationType: 'strategy_discrimination_practice',
          notes: 'مقارنة مسألتين متشابهتين ظاهرياً وتبرير سبب اختيار الاستراتيجية الصحيحة لكل منهما.',
        },
      ],
      time_management_issue: [
        {
          title: `[Paced Micro-Drill] تمرين مجزأ وموقوت (25 دقيقة) لكسر حاجز الوقت: ${targetName}`,
          plannedDurationMin: 25,
          category: 'Remediation',
          remediationType: 'timed_paced_practice',
          notes: 'تنفيذ جزء محدد وواضح ضمن نافذة زمنية قصيرة دون إرهاق.',
        },
      ],
      attention_careless_error: [
        {
          title: `[Self-Audit Checklist] تمرين تطبيقي مع قائمة فحص ومراجعة ذاتية: ${targetName}`,
          plannedDurationMin: 25,
          category: 'Remediation',
          remediationType: 'verification_checklist_practice',
          notes: 'تطبيق قائمة فحص الأخطاء الشائعة قبل اعتماد الإجابة النهائية.',
        },
      ],
      incomplete_evidence: [
        {
          title: `[Practical Demonstration] تنفيذ وتوثيق عرض عملي تطبيقي مكتمل: ${targetName}`,
          plannedDurationMin: 40,
          category: 'Remediation',
          remediationType: 'practical_demonstration',
          notes: 'إنتاج دليل تطبيقي ملموس (كود، إثبات، تحليل، أو تسجيل أداء) يثبت الكفاءة.',
        },
      ],
      unknown_unclassified: [
        {
          title: `[Diagnostic Probe] جلسة تشخيص تفصيلي لعزل موضع التعثر بدقة: ${targetName}`,
          plannedDurationMin: 25,
          category: 'Remediation',
          remediationType: 'diagnostic_isolation_probe',
          notes: 'اختبار الفهم المفاهيمي ثم الخطوات الإجرائية بشكل منفصل لتحديد السبب الجذري الحقيقي.',
        },
      ],
    };

    const tasksSpec =
      Array.isArray(options.tasksSpec) && options.tasksSpec.length > 0
        ? options.tasksSpec
        : categoryTaskBlueprints[category] || categoryTaskBlueprints.unknown_unclassified;

    // Delegate to existing SkillEngine.createRemediationPlan
    return this.skillEngine.createRemediationPlan({
      errorId: error.id,
      date: dateStr,
      remediationType: meta.defaultRemediationType,
      title: options.title || `خطة علاجية موجهة (${meta.labelAr}): ${targetName}`,
      strategy: options.strategy || meta.defaultStrategy,
      difficultyAdjustment:
        category === 'time_management_issue' || category === 'missing_prerequisite'
          ? 'step_down_granularity'
          : 'focused_remediation',
      tasksSpec,
    });
  }

  // =========================================================================
  // 4. VERIFIED RETESTING (ANTI-VERBATIM REPEAT + FULL LINEAGE)
  // =========================================================================

  /**
   * Executes a verified Retest linked to the originating assessment, error, and remediation.
   * Rejects retests that merely repeat the same memorized answer (`isVerbatimRepeat === true`)
   * or omit a valid `verificationMode`.
   */
  async executeVerifiedRetest(payload = {}) {
    const {
      linkedErrorId,
      verificationMode = 'equivalent_questions',
      isVerbatimRepeat = false,
      evidence = '',
    } = payload;

    if (!linkedErrorId) {
      throw new Error('Verified retest requires a linkedErrorId.');
    }

    if (isVerbatimRepeat === true) {
      throw new Error(
        'Retest rejected: Retests must verify target competence using equivalent questions, new examples, varied context, or independent performance rather than repeating the exact same memorized answer.'
      );
    }

    if (!RETEST_VERIFICATION_MODES.includes(verificationMode)) {
      throw new Error(
        `Invalid verificationMode "${verificationMode}". Must be one of: ${RETEST_VERIFICATION_MODES.join(', ')}`
      );
    }

    if (!evidence || String(evidence).trim().length < 5) {
      throw new Error(
        'Verified retest requires explicit performance evidence demonstrating how the target competence was verified.'
      );
    }

    const error = await this.db.get('errors', linkedErrorId);
    if (!error) {
      throw new Error(`Linked error not found: ${linkedErrorId}`);
    }

    const result = await this.skillEngine.recordTestAttempt({
      ...payload,
      skillId: payload.skillId || error.skillId,
      subskillId: payload.subskillId !== undefined ? payload.subskillId : error.subskillId,
      objectiveId: payload.objectiveId !== undefined ? payload.objectiveId : error.objectiveId,
      isRetest: true,
      linkedErrorId,
      verificationMode,
      originalAssessmentId:
        payload.originalAssessmentId ||
        error.diagnosticAssessmentId ||
        error.linkedTestAttemptId ||
        null,
      independentApplication:
        Boolean(payload.independentApplication) ||
        verificationMode === 'independent_performance' ||
        verificationMode === 'practical_demonstration',
    });

    return {
      ...result,
      lineage: {
        originalAssessmentId:
          payload.originalAssessmentId ||
          error.diagnosticAssessmentId ||
          error.linkedTestAttemptId ||
          null,
        errorId: error.id,
        remediationId: error.remediationId || null,
        retestAttemptId: result.attempt.id,
        verificationMode,
      },
    };
  }

  // =========================================================================
  // 5. MAINTENANCE, RETENTION & RELEARNING REACTIVATION
  // =========================================================================

  /**
   * Reactivates mastery after a skill that previously achieved mastery experienced a retention failure,
   * completed its relearning remediation tasks, and passed its re-verification retest/retention check.
   */
  async reactivateMasteryAfterRelearning(skillId, subskillId = null, verificationDate = '2026-10-14') {
    const skill = await this.db.get('skills', skillId);
    if (!skill) throw new Error(`Skill not found: ${skillId}`);

    // Verify all open errors on this skill/subskill are resolved
    const errors = await this.db.queryByField('errors', 'skillId', skillId);
    const scopedOpenErrors = errors.filter(
      (e) =>
        e.status !== 'resolved' &&
        (!subskillId || e.subskillId === subskillId)
    );
    if (scopedOpenErrors.length > 0) {
      throw new Error(
        `Cannot reactivate mastery while (${scopedOpenErrors.length}) relearning/remediation error(s) remain unresolved.`
      );
    }

    const promotion = await this.skillEngine.tryPromoteMastery(skillId, subskillId);
    const updatedSkill = await this. skillEngine.transitionToMaintenance(
      'skill',
      skillId,
      verificationDate
    );

    let updatedSubskill = null;
    if (subskillId) {
      const sub = await this.db.get('subskills', subskillId);
      if (sub && (sub.masteryState === 'MASTERED' || sub.masteryState === 'MAINTENANCE')) {
        updatedSubskill = await this.skillEngine.transitionToMaintenance(
          'subskill',
          subskillId,
          verificationDate
        );
      }
    }

    return {
      skill: updatedSkill,
      subskill: updatedSubskill,
      promotion,
    };
  }
}
