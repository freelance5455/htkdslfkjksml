/* ==========================================================================
   financial-engine.js — محاسبات مالی، پیش‌بینی، شبیه‌ساز، استقلال مالی، بدهی
   ========================================================================== */

import { sum, round, clamp, currentMonthKey, prevMonthKey, addMonthsKey, monthKeyOf } from '../utils.js';

/* ----------------------------------------------------------- متریک‌های اصلی */
export function financeMetrics(state) {
  const f = state.finance || {};
  const incomes = f.incomes || [], expenses = f.expenses || [], assets = f.assets || [], debts = f.debts || [];

  const income = sum(incomes, (i) => i.amount);
  const fixedIncome = sum(incomes.filter((i) => i.type === 'fixed'), (i) => i.amount);
  const variableIncome = income - fixedIncome;
  const expense = sum(expenses, (e) => e.amount);

  const catMap = {};
  expenses.forEach((e) => { catMap[e.category || 'سایر'] = (catMap[e.category || 'سایر'] || 0) + (+e.amount || 0); });
  const expenseByCat = Object.keys(catMap).map((k) => ({ category: k, amount: catMap[k] })).sort((a, b) => b.amount - a.amount);
  const essentialCats = ['مسکن', 'غذا', 'حمل‌ونقل', 'درمان', 'اقساط', 'آموزش', 'خانواده'];
  const essential = expenseByCat.filter((c) => essentialCats.indexOf(c.category) > -1).reduce((a, b) => a + b.amount, 0);
  const discretionary = expense - essential;

  const assetsTotal = sum(assets, (a) => a.amount);
  const liquid = sum(assets.filter((a) => a.liquid), (a) => a.amount);
  const investable = sum(assets.filter((a) => ['نقد', 'سپرده', 'سهام', 'طلا', 'ارز'].indexOf(a.category) > -1), (a) => a.amount);
  const productive = sum(assets.filter((a) => ['کسب‌وکار', 'تجهیزات', 'ملک'].indexOf(a.category) > -1), (a) => a.amount);
  const debtTotal = sum(debts, (d) => d.amount);
  const netWorth = assetsTotal - debtTotal;

  const monthlyDebtPayment = sum(debts, (d) => d.monthlyPayment || estimateInstallment(d.amount, d.rate, d.term || 12));
  const savings = income - expense;
  const savingsRate = income > 0 ? clamp(savings / income, -3, 1) : 0;
  const debtToIncome = income > 0 ? monthlyDebtPayment / income : 0;
  const debtToAsset = assetsTotal > 0 ? debtTotal / assetsTotal : (debtTotal > 0 ? 1.5 : 0);
  const runwayMonths = expense > 0 ? round(liquid / expense, 1) : (liquid > 0 ? 24 : 0);
  const netWorthYears = expense > 0 ? round(netWorth / (expense * 12), 2) : 0;
  const annualExpense = expense * 12;
  const annualIncome = income * 12;
  const investRatio = income > 0 ? clamp(sum(incomes.filter((i) => i.kind === 'investment'), (i) => i.amount) / income, 0, 1) : 0;
  const incomeStreams = new Set(incomes.map((i) => i.kind || 'salary')).size;

  return {
    income, fixedIncome, variableIncome, expense, savings, savingsRate,
    assetsTotal, liquid, investable, productive, debtTotal, netWorth,
    monthlyDebtPayment, debtToIncome, debtToAsset, runwayMonths, netWorthYears,
    annualExpense, annualIncome, expenseByCat, essential, discretionary,
    incomeStreams, investRatio, hasDebt: debtTotal > 0, negativeFlow: expense >= income && income > 0,
  };
}

export function estimateInstallment(amount, annualRatePct, months) {
  const a = Math.max(0, +amount || 0), m = Math.max(1, +months || 12), r = (+annualRatePct || 0) / 100 / 12;
  if (r <= 0) return a / m;
  return (a * r * Math.pow(1 + r, m)) / (Math.pow(1 + r, m) - 1);
}

/* ----------------------------------------------------------- پیش‌بینی ثروت */
export function projectWealth(opts) {
  const {
    startCapital = 0, monthlySaving = 0, income = 0, savingsRatePct = 0,
    incomeGrowthPct = 0, returnPct = 0, inflationPct = 0, years = 10,
  } = opts;
  let capital = +startCapital || 0, inc = +income || 0;
  const monthlyReturn = Math.pow(1 + (+returnPct || 0) / 100, 1 / 12) - 1;
  const series = [];
  for (let y = 1; y <= years; y++) {
    for (let m = 0; m < 12; m++) {
      let save = monthlySaving;
      if (inc > 0 && savingsRatePct > 0) save = (inc * (+savingsRatePct || 0)) / 100;
      capital = capital * (1 + monthlyReturn) + Math.max(0, save);
    }
    inc = inc * (1 + (+incomeGrowthPct || 0) / 100);
    const realValue = capital / Math.pow(1 + (+inflationPct || 0) / 100, y);
    series.push({ year: y, capital: round(capital, 0), real: round(realValue, 0) });
  }
  return series;
}

/** سه سناریو: محافظه‌کارانه / متعادل / تهاجمی */
export function simulateScenarios(state, params) {
  const m = financeMetrics(state);
  const base = {
    startCapital: params.startCapital != null ? params.startCapital : m.investable,
    income: params.income != null ? params.income : m.income,
    savingsRatePct: params.savingsRatePct != null ? params.savingsRatePct : Math.max(0, round(m.savingsRate * 100, 0)),
    incomeGrowthPct: params.incomeGrowthPct != null ? params.incomeGrowthPct : 15,
    inflationPct: params.inflationPct != null ? params.inflationPct : 30,
    years: params.years || 20,
  };
  const presets = [
    { key: 'conservative', fa: 'محافظه‌کارانه', returnPct: (base.inflationPct || 30) * 0.6, growth: 5, rateAdj: -0.6, note: 'رشد درآمد کم، بازده پایین، ریسک کم' },
    { key: 'balanced', fa: 'متعادل', returnPct: (base.inflationPct || 30) * 1.0, growth: 15, rateAdj: 0, note: 'فرض‌های میانی و واقع‌گرایانه' },
    { key: 'aggressive', fa: 'تهاجمی', returnPct: (base.inflationPct || 30) * 1.6, growth: 30, rateAdj: 0.6, note: 'رشد درآمد بالا، ریسک و نوسان بالا' },
  ];
  const scenarios = presets.map((p) => {
    const series = projectWealth({
      ...base,
      returnPct: p.returnPct,
      incomeGrowthPct: p.growth,
      savingsRatePct: clamp(base.savingsRatePct + (p.key === 'aggressive' ? 8 : p.key === 'conservative' ? -3 : 0), 0, 80),
      years: base.years,
    });
    return { ...p, series, final: series[series.length - 1], finalReal: series[series.length - 1].real };
  });
  return { scenarios, base, metrics: m };
}

/* ------------------------------------------------------ ماشین‌حساب استقلال */
export function freedomCalc(state, p = {}) {
  const m = financeMetrics(state);
  const swr = clamp(p.swr != null ? p.swr : 3.5, 2, 8);
  const monthlyExpense = p.expense != null ? p.expense : m.expense;
  const annualExpense = monthlyExpense * 12;
  const requiredCapital = annualExpense * (100 / swr);
  const currentCapital = p.capital != null ? p.capital : m.investable;
  const monthlySaving = p.saving != null ? p.saving : Math.max(0, m.savings);
  const annualReturn = p.return != null ? p.return : Math.max(0, (p.inflation || 0) + 2);
  const monthlyReturn = Math.pow(1 + annualReturn / 100, 1 / 12) - 1;
  const inflation = p.inflation != null ? p.inflation : 0;

  let capital = currentCapital, months = 0;
  const needed = requiredCapital;
  while (capital < needed && months < 12 * 60) {
    capital = capital * (1 + monthlyReturn) + monthlySaving;
    months++;
  }
  const passiveIncome = (currentCapital * swr) / 100 / 12;
  const passiveIncomeTarget = (needed * swr) / 100 / 12;
  const gap = Math.max(0, needed - currentCapital);
  const progress = clamp(currentCapital / needed, 0, 1);
  return {
    swr, monthlyExpense, annualExpense, requiredCapital, currentCapital, monthlySaving,
    annualReturn, inflation, years: round(months / 12, 1), months,
    passiveIncome, passiveIncomeTarget, gap, progress,
    reachable: months < 12 * 60,
  };
}

/* --------------------------------------------------------------- بدهی‌ها */
export function debtPlan(state, extraMonthly = 0) {
  const debts = (state.finance.debts || []).filter((d) => (+d.amount || 0) > 0).map((d, i) => ({
    ...d,
    idx: i,
    amount: +d.amount || 0,
    rate: +d.rate || 0,
    pay: +d.monthlyPayment || estimateInstallment(d.amount, d.rate, d.term || 12),
  }));
  if (!debts.length) return { hasDebt: false, extraMonthly: 0 };

  function run(orderKey) {
    const list = debts.map((d) => ({ ...d, balance: d.amount, paid: 0, interest: 0, months: 0, cleared: 0 }));
    let budget = list.reduce((a, b) => a + b.pay, 0) + (+extraMonthly || 0);
    let month = 0, totalInterest = 0;
    const order = list.slice().sort(orderKey);
    const timeline = [];
    while (list.some((d) => d.balance > 0.5) && month < 600) {
      month++;
      // بهره ماهانه
      list.forEach((d) => {
        if (d.balance <= 0) return;
        const i = d.balance * (d.rate / 100 / 12);
        d.balance += i; d.interest += i; totalInterest += i;
      });
      let pool = budget;
      const active = order.filter((d) => d.balance > 0);
      // اقساط حداقلی
      active.forEach((d) => {
        const pay = Math.min(d.pay, d.balance, pool);
        d.balance -= pay; pool -= pay; d.paid += pay;
      });
      // مبلغ اضافی روی اولویت اول
      const focus = active.filter((d) => d.balance > 0)[0];
      if (focus && pool > 0) {
        const pay = Math.min(pool, focus.balance);
        focus.balance -= pay; pool -= pay; focus.paid += pay;
      }
      list.forEach((d) => { if (d.balance <= 0.5 && !d.cleared) d.cleared = month; });
      timeline.push({ month, remaining: round(list.reduce((a, b) => a + Math.max(0, b.balance), 0), 0) });
    }
    return { months: month, totalInterest: round(totalInterest, 0), orderNames: order.map((d) => d.label || 'بدهی'), timeline, finalBudget: budget };
  }

  const avalanche = run((a, b) => b.rate - a.rate);
  const snowball = run((a, b) => a.amount - b.amount);
  const m = financeMetrics(state);
  const highRate = debts.filter((d) => d.rate >= 25).length > 0;
  const recommended = highRate ? 'avalanche' : (debts.length > 1 ? 'snowball' : 'avalanche');
  const why = highRate
    ? 'بدهی با بهره بالا داری؛ روش بهمن (بالاترین نرخ بهره) در مجموع سود کمتری می‌دهد.'
    : debts.length > 1
      ? 'تعداد بدهی‌ها زیاد است؛ روش گلوله برفی با بستن سریع بدهی‌های کوچک، انگیزه و کنترل بیشتری می‌دهد.'
      : 'یک بدهی فعال داری؛ تفاوت روش‌ها کم است. اولویت با افزایش مبلغ پرداخت ماهانه است.';
  return {
    hasDebt: true, debts, avalanche, snowball, recommended, why, extraMonthly: +extraMonthly || 0,
    savingByMethod: round(Math.abs(avalanche.totalInterest - snowball.totalInterest), 0),
    dti: m.debtToIncome, payoffYears: round(recommended === 'avalanche' ? avalanche.months : snowball.months, 0) / 12,
  };
}

/* -------------------------------------- «اگر هیچ چیز را تغییر ندهم» مقابل برنامه */
export function doNothingVsPlan(state, yearsList = [1, 3, 5, 10, 20]) {
  const m = financeMetrics(state);
  const savingsRatePct = Math.max(0, round(m.savingsRate * 100, 0));
  const inflation = state.profile.assumptions ? state.profile.assumptions.inflation : 30;
  const noChange = projectWealth({
    startCapital: m.investable, income: m.income, savingsRatePct: Math.max(0, savingsRatePct),
    incomeGrowthPct: inflation > 0 ? Math.max(0, inflation - 8) : 8, returnPct: inflation > 0 ? inflation : 20,
    inflationPct: inflation, years: Math.max(...yearsList),
  });
  const withPlan = projectWealth({
    startCapital: m.investable, income: m.income, savingsRatePct: clamp(savingsRatePct + 20, 10, 70),
    incomeGrowthPct: inflation > 0 ? inflation + 12 : 25, returnPct: inflation > 0 ? inflation + 6 : 30,
    inflationPct: inflation, years: Math.max(...yearsList),
  });
  const rows = yearsList.map((y) => {
    const a = noChange[Math.min(y, noChange.length) - 1];
    const b = withPlan[Math.min(y, withPlan.length) - 1];
    return { year: y, noChange: a ? a.real : 0, withPlan: b ? b.real : 0, diff: (b ? b.real : 0) - (a ? a.real : 0) };
  });
  return { rows, metrics: m, inflation };
}

/* ---------------------------------------------------- سری‌های زمانی نمودارها */
export function monthSeries(state, count = 6) {
  const tx = state.finance.transactions || [];
  const out = [];
  let mk = currentMonthKey();
  const list = [];
  for (let i = count - 1; i >= 0; i--) list.push(addMonthsKey(currentMonthKey(), -i));
  list.forEach((k) => {
    const rows = tx.filter((t) => monthKeyOf(t.date) === k);
    const inc = sum(rows.filter((r) => r.type === 'income'), (r) => r.amount);
    const exp = sum(rows.filter((r) => r.type === 'expense'), (r) => r.amount);
    out.push({ month: k, income: inc, expense: exp, saving: inc - exp, savingRate: inc > 0 ? (inc - exp) / inc : 0, count: rows.length });
  });
  return out;
}

export function monthActuals(state, mk) {
  const tx = (state.finance.transactions || []).filter((t) => monthKeyOf(t.date) === mk);
  const prev = prevMonthKey(mk);
  const ptx = (state.finance.transactions || []).filter((t) => monthKeyOf(t.date) === prev);
  const cur = {
    income: sum(tx.filter((t) => t.type === 'income'), (t) => t.amount),
    expense: sum(tx.filter((t) => t.type === 'expense'), (t) => t.amount),
  };
  const old = {
    income: sum(ptx.filter((t) => t.type === 'income'), (t) => t.amount),
    expense: sum(ptx.filter((t) => t.type === 'expense'), (t) => t.amount),
  };
  const planned = financeMetrics(state);
  return {
    month: mk, prev: prevMonthKey(mk), current: cur, previous: old,
    savings: cur.income - cur.expense,
    savingsRate: cur.income > 0 ? (cur.income - cur.expense) / cur.income : 0,
    planned: { income: planned.income, expense: planned.expense },
    delta: {
      income: old.income ? (cur.income - old.income) / old.income : 0,
      expense: old.expense ? (cur.expense - old.expense) / old.expense : 0,
      savings: old.income - old.expense ? ((cur.income - cur.expense) - (old.income - old.expense)) / Math.abs(old.income - old.expense) : 0,
    },
    txCount: tx.length,
  };
}
