/**
 * WHITE ROOM OS — Performance Log, Error Seeding & 5D Progress Engine (Phase 1–5 Integrated)
 * Records session performance metrics, updates Task & Skill progress, seeds Evidence & Errors,
 * unlocks Remediation Retests when Corrective Tasks are completed, and computes system-wide
 * 5-Dimensional Progress (Activity, Learning, Competence, Mastery, Retention) with zero double-counting.
 */

import {
  LEARNING_EVIDENCE_TYPES,
  COMPETENCE_EVIDENCE_TYPES,
  RETENTION_EVIDENCE_TYPES,
} from './skillEngine.js';
import { normalizeErrorCategory } from '../core/schema.js';

export class PerformanceEngine {
  constructor(db, skillEngine = null) {
    this.db = db;
    this.skillEngine = skillEngine;
  }

  async recordPerformanceLog(payload) {
    const task = await this.db.get('tasks', payload.taskId);
    const dateStr =
      payload.date || task?.date || new Date().toISOString().slice(0, 10);

    const logRecord = {
      id: payload.id || `perf_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      taskId: payload.taskId,
      taskTitle: payload.taskTitle || task?.title || 'مهمة تدريبية',
      skillId: payload.skillId || task?.skillId || null,
      subskillId: payload.subskillId || task?.subskillId || null,
      date: dateStr,
      startedAtIso: payload.startedAtIso || new Date().toISOString(),
      finishedAtIso: payload.finishedAtIso || new Date().toISOString(),
      plannedDurationSec: Number(
        payload.plannedDurationSec ?? (task ? task.plannedDurationMin * 60 : 1800)
      ),
      actualDurationSec: Number(payload.actualDurationSec ?? 1800),
      pauseDurationSec: Number(payload.pauseDurationSec ?? 0),
      completionPct: Number(payload.completionPct ?? 100),
      energy: Number(payload.energy ?? 7),
      difficulty: Number(payload.difficulty ?? 5),
      confidence: Number(payload.confidence ?? 7),
      whatLearned: String(payload.whatLearned || '').trim(),
      mistakes: String(payload.mistakes || '').trim(),
      notes: String(payload.notes || '').trim(),
    };

    const savedLog = await this.db.put('performance_logs', logRecord);

    // Update Task status
    if (task) {
      const updatedTask = {
        ...task,
        status: logRecord.completionPct >= 100 ? 'completed' : 'in_progress',
        executionState: logRecord.completionPct >= 100 ? 'completed' : 'in_progress',
        actualDurationMin: Math.round(logRecord.actualDurationSec / 60),
        lastLoggedAt: logRecord.finishedAtIso,
      };
      await this.db.put('tasks', updatedTask);

      // If this was a Corrective Task in a Remediation Plan, check if Retest is now unlocked
      if (updatedTask.status === 'completed' && task.remediationId) {
        const rem = await this.db.get('remediations', task.remediationId);
        if (rem) {
          const linkedTasks = await Promise.all(
            rem.correctiveTaskIds.map((id) => this.db.get('tasks', id))
          );
          const allCompleted = linkedTasks.every((t) => t && t.status === 'completed');
          await this.db.put('remediations', {
            ...rem,
            retestAllowed: allCompleted,
            status: allCompleted ? 'ready_for_retest' : rem.status,
            updatedAt: new Date().toISOString(),
          });
        }
      }
    }

    // Create Training Evidence if whatLearned was documented
    const skillId = logRecord.skillId;
    const subskillId = logRecord.subskillId;
    let createdEvidence = null;
    if (skillId && logRecord.whatLearned.length > 0) {
      createdEvidence = await this.db.put('evidence', {
        id: `ev_perf_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        skillId,
        subskillId: subskillId || null,
        type: 'training',
        title: `توثيق جلسة: ${logRecord.taskTitle}`,
        content: logRecord.whatLearned,
        qualityScore: Math.min(100, logRecord.confidence * 10),
        createdAt: logRecord.finishedAtIso,
      });
    }

    // Update Skill metrics if linked
    if (skillId) {
      const skill = await this.db.get('skills', skillId);
      if (skill) {
        const addedMinutes = Math.max(1, Math.round(logRecord.actualDurationSec / 60));
        const hasMistake = logRecord.mistakes.length > 0;
        const allEv = await this.db.queryByField('evidence', 'skillId', skillId);
        const updatedSkill = {
          ...skill,
          status: skill.status === 'AVAILABLE' ? 'IN_PROGRESS' : skill.status,
          metrics: {
            ...skill.metrics,
            totalPracticeMinutes: (skill.metrics?.totalPracticeMinutes || 0) + addedMinutes,
            trainingSessionsCount: (skill.metrics?.trainingSessionsCount || 0) + 1,
            evidenceCount: Math.max(skill.metrics?.evidenceCount || 0, allEv.length),
            errorCount: (skill.metrics?.errorCount || 0) + (hasMistake ? 1 : 0),
            lastPracticedDate: dateStr,
          },
        };
        await this.db.put('skills', updatedSkill);
      }
    }

    // Automatically seed a structured ErrorRecord if mistakes were logged
    let createdError = null;
    if (logRecord.mistakes.length > 0 && skillId) {
      const severity =
        logRecord.difficulty >= 8 || logRecord.confidence <= 4 ? 'high' : 'medium';
      const normalizedCat = normalizeErrorCategory(
        payload.errorCategory || 'calculation_execution_error'
      );
      const errorRecord = {
        id: `err_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        skillId,
        linkedSkill: skillId,
        subskillId: subskillId || null,
        linkedSubskill: subskillId || null,
        subskill: subskillId || 'General Practice',
        linkedTestAttemptId: null,
        category: normalizedCat,
        classificationState:
          normalizedCat === 'unknown_unclassified' ? 'unclassified' : 'hypothesized',
        description: logRecord.mistakes,
        cause:
          payload.errorCause || 'فرضية أولية: نقص في الاسترجاع أو خطأ تطبيقي أثناء الجلسة',
        observedFacts: [
          `Performance Log ${logRecord.id}: ${logRecord.mistakes} (Confidence ${logRecord.confidence}/10)`,
        ],
        hypotheses: [
          {
            category: normalizedCat,
            explanation:
              payload.errorCause || 'نقص في الاسترجاع أو خطأ تطبيقي أثناء الجلسة التدريبية',
            supportingEvidence: [
              `Performance Log: ${logRecord.taskTitle} (Confidence ${logRecord.confidence}/10)`,
            ],
            confidenceLevel: 'moderate',
            uncertaintyNote: 'ملاحظة مسجلة أثناء التدريب تتطلب تحققاً عبر تمرين تصحيحي.',
            verificationMethod: 'حل مسألة مكافئة بشكل مستقل بعد مراجعة الخطوات.',
          },
        ],
        severity,
        date: dateStr,
        evidence: `Performance Log: ${logRecord.taskTitle} (Confidence ${logRecord.confidence}/10)`,
        remediation:
          payload.remediation || 'إعادة حل مسائل مشابهة مع تفعيل Active Recall قبل الجلسة القادمة',
        remediationId: null,
        failureCount: 1,
        retestRequired: true,
        status: 'open',
      };
      createdError = await this.db.put('errors', errorRecord);
    }

    if (skillId && this.skillEngine) {
      await this.skillEngine.calculateSkillProgress(skillId);
    }

    return {
      log: savedLog,
      createdEvidence,
      createdError,
    };
  }

  /**
   * Computes system-wide 5-Dimensional Progress (Activity, Learning, Competence, Mastery, Retention)
   * strictly from persisted database records, with documented formulas and zero double-counting of evidence.
   */
  async computeSystemProgress(referenceDate = '2026-10-14') {
    const [tasks, logs, skills, subskills, errors, goals, evidence, reviews, flashcards] =
      await Promise.all([
        this.db.getAll('tasks'),
        this.db.getAll('performance_logs'),
        this.db.getAll('skills'),
        this.db.getAll('subskills'),
        this.db.getAll('errors'),
        this.db.getAll('goals'),
        this.db.getAll('evidence'),
        this.db.getAll('reviews'),
        this.db.getAll('flashcards'),
      ]);

    const completedTasks = tasks.filter((t) => t.status === 'completed').length;
    const taskCompletionRate =
      tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

    const totalLoggedSec = logs.reduce((acc, l) => acc + (l.actualDurationSec || 0), 0);
    const totalSkillPracticeMin = skills.reduce(
      (acc, s) =>
        acc + (s.metrics?.totalPracticeMinutes || 0) + (s.metrics?.totalStudyMinutes || 0),
      0
    );

    const avgEnergy =
      logs.length > 0
        ? Number((logs.reduce((acc, l) => acc + l.energy, 0) / logs.length).toFixed(1))
        : 0;
    const avgConfidence =
      logs.length > 0
        ? Number((logs.reduce((acc, l) => acc + l.confidence, 0) / logs.length).toFixed(1))
        : 0;
    const avgDifficulty =
      logs.length > 0
        ? Number((logs.reduce((acc, l) => acc + l.difficulty, 0) / logs.length).toFixed(1))
        : 0;

    const openErrors = errors.filter((e) => e.status !== 'resolved');

    const errorCountsBySkill = {};
    for (const err of openErrors) {
      errorCountsBySkill[err.skillId] = (errorCountsBySkill[err.skillId] || 0) + 1;
    }
    let bottleneckSkillId = null;
    let maxErrors = 0;
    for (const [sId, count] of Object.entries(errorCountsBySkill)) {
      if (count > maxErrors) {
        maxErrors = count;
        bottleneckSkillId = sId;
      }
    }

    const masteredSkillsCount = skills.filter(
      (s) => s.status === 'MASTERED' || s.status === 'MAINTENANCE'
    ).length;

    const historicallyMasteredSkillsCount = skills.filter(
      (s) =>
        s.historicalMasteryAchieved ||
        s.status === 'MASTERED' ||
        s.status === 'MAINTENANCE'
    ).length;

    // Partition all evidence records across the entire system into 3 disjoint sets (Zero Double-Counting)
    const learningEvIds = [];
    const competenceEvIds = [];
    const retentionEvIds = [];
    for (const ev of evidence) {
      const t = String(ev.type || 'training').toLowerCase();
      if (RETENTION_EVIDENCE_TYPES.includes(t)) {
        retentionEvIds.push(ev.id);
      } else if (COMPETENCE_EVIDENCE_TYPES.includes(t) || ev.independentApplication) {
        competenceEvIds.push(ev.id);
      } else {
        learningEvIds.push(ev.id);
      }
    }

    // Aggregate the 5 distinct dimensions across all skills
    const count = Math.max(1, skills.length);
    const systemActivityProgress = Math.round(
      skills.reduce((s, sk) => s + (sk.progress?.activityProgress || 0), 0) / count
    );
    const systemLearningProgress = Math.round(
      skills.reduce((s, sk) => s + (sk.progress?.learningProgress || 0), 0) / count
    );
    const systemCompetence = Math.round(
      skills.reduce((s, sk) => s + (sk.progress?.competence || 0), 0) / count
    );
    const systemMastery = Math.round(
      skills.reduce((s, sk) => s + (sk.progress?.mastery || 0), 0) / count
    );
    const masteredOrMaintSkills = skills.filter(
      (sk) =>
        sk.status === 'MASTERED' ||
        sk.status === 'MAINTENANCE' ||
        sk.historicalMasteryAchieved
    );
    const systemRetention =
      masteredOrMaintSkills.length > 0
        ? Math.round(
            masteredOrMaintSkills.reduce(
              (s, sk) => s + (sk.progress?.retention || 0),
              0
            ) / masteredOrMaintSkills.length
          )
        : 0;

    // Weakness indicators & overdue reviews
    const weakSkills = skills.filter(
      (sk) =>
        sk.progress?.weaknessIndicators?.isWeak ||
        openErrors.some((e) => e.skillId === sk.id) ||
        sk.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING'
    );
    const weakSubskills = subskills.filter(
      (sub) =>
        openErrors.some((e) => e.subskillId === sub.id) ||
        sub.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING'
    );
    const overdueMaintenanceCount = skills.filter((sk) => {
      const nextRev = sk.maintenanceCriteria?.nextReviewDate;
      return (
        (sk.status === 'MAINTENANCE' || sk.status === 'MASTERED') &&
        nextRev &&
        String(nextRev) <= String(referenceDate)
      );
    }).length;
    const dueFlashcardsCount = flashcards.filter(
      (fc) => !fc.nextReviewDate || String(fc.nextReviewDate) <= String(referenceDate)
    ).length;

    return {
      totalTasks: tasks.length,
      completedTasks,
      taskCompletionRate,
      totalSessionsLogged: logs.length,
      totalLoggedMinutes: Math.round(totalLoggedSec / 60),
      totalHistoricalStudyPracticeMinutes: totalSkillPracticeMin,
      avgEnergy,
      avgConfidence,
      avgDifficulty,
      openErrorsCount: openErrors.length,
      bottleneckSkillId,
      masteredSkillsCount,
      historicallyMasteredSkillsCount,
      totalSkillsCount: skills.length,
      activeGoalsCount: goals.filter((g) => g.status === 'active').length,
      dimensions: {
        activity: systemActivityProgress,
        learning: systemLearningProgress,
        competence: systemCompetence,
        mastery: systemMastery,
        retention: systemRetention,
      },
      metricDefinitions: {
        activity:
          'Activity (0-100%): يقيس تنفيذ المهام اليومية وحجم دقائق التدريب الفعلي فقط (Tasks + Performance Logs) دون احتساب الأدلة أو الاختبارات.',
        learning:
          'Learning (0-100%): يقيس إكمال وحدات المنهج وأدلة الفهم/الشرح الذاتي (Curriculum + Learning/Feynman Evidence) دون احتساب درجات الاختبارات أو فحوصات الاحتفاظ.',
        competence:
          'Competence (0-100%): يقيس درجات ودقة الاختبارات والتطبيق المستقل (Test Attempts + Competence Evidence) مطروحاً منها أثر الأخطاء المفتوحة.',
        mastery:
          'Mastery (0-100%): يقيس نسبة استيفاء شروط بوابة الإتقان القابلة للتكوين وإتقان المهارات الفرعية (Mastery Gate Criteria).',
        retention:
          'Retention (0-100%): يقيس حصرياً أداء فحوصات الاحتفاظ والصيانة بعد الإتقان (Post-Mastery Reviews & Retention Evidence).',
      },
      evidencePartitionAudit: {
        totalEvidenceRecords: evidence.length,
        learningEvidenceCount: learningEvIds.length,
        competenceEvidenceCount: competenceEvIds.length,
        retentionEvidenceCount: retentionEvIds.length,
        zeroDoubleCountingVerified:
          learningEvIds.length + competenceEvIds.length + retentionEvIds.length ===
          evidence.length,
      },
      weaknessSummary: {
        weakSkillsCount: weakSkills.length,
        weakSkillIds: weakSkills.map((s) => s.id),
        weakSubskillsCount: weakSubskills.length,
        weakSubskillIds: weakSubskills.map((s) => s.id),
        unresolvedErrorsCount: openErrors.length,
        overdueReviewsCount: overdueMaintenanceCount + dueFlashcardsCount,
        retentionDecayCount: skills.filter(
          (s) => s.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING'
        ).length,
        totalMaintenanceReviewsLogged: reviews.length,
      },
    };
  }
}
