/* ==========================================================================
   roadmap-engine.js — کشف مسیر ثروت، انتخاب بهترین مسیر، نقشه راه، برنامه معکوس
   ========================================================================== */

import { financeMetrics } from './financial-engine.js';
import { skillScore, taskCompletionRate } from './scoring-engine.js';
import { skillScore as sk2 } from './scoring-engine.js';
import { clamp, round, todayKey, daysBetween, addDays, uid, faDate } from '../utils.js';
void sk2;

/* ------------------------------------------------------------- تعریف مسیرها */
export const PATHS = [
  {
    id: 'career_upgrade', fa: 'ارتقای شغلی', icon: '🧭', cat: 'career',
    risk: 20, capitalNeed: 'خیلی کم', capitalBase: 0, timeToIncome: 3, potential: 'متوسط',
    tags: ['کارمند', 'کارگر', 'تکنسین', 'مهندس', 'مدیر'],
    why: 'سریع‌ترین راه افزایش درآمد برای کسی که شغل دارد، بدون ریسک سرمایه‌ای است.',
    firstSteps: ['سه دستاورد کمیتی از کار فعلی بنویس.', 'محدوده پرداخت بازار برای نقش بالاتر را تحقیق کن.', 'با مدیر جلسه بازخورد بگذار.', 'یک مهارت کلیدی نقش بعدی را ۹۰ روز تمرین کن.', 'درخواست ارتقا یا تغییر واحد را زمان‌بندی کن.'],
  },
  {
    id: 'high_income_skill', fa: 'تخصص پردرآمد', icon: '🎯', cat: 'career',
    risk: 25, capitalNeed: 'کم', capitalBase: 0, timeToIncome: 6, potential: 'بالا',
    tags: ['برنامه‌نویسی', 'هوش مصنوعی', 'طراحی', 'مالی', 'بازاریابی'],
    why: 'مهارت نادر، بیشترین اهرم افزایش درآمد بدون سرمایه را می‌دهد.',
    firstSteps: ['یک مهارت پرتقاضا را انتخاب کن.', 'برنامه ۹۰ روزه یادگیری با خروجی قابل نمایش بنویس.', 'سه نمونه‌کار بساز.', 'در پلتفرم‌های پروژه‌ای پروفایل بساز.', 'اولین پروژه را با قیمت پایین برای اثبات بگیر.'],
  },
  {
    id: 'freelancing', fa: 'فریلنسری و خدمات پروژه‌ای', icon: '💻', cat: 'passive',
    risk: 30, capitalNeed: 'کم', capitalBase: 0, timeToIncome: 2, potential: 'بالا',
    tags: ['برنامه‌نویسی', 'طراحی', 'محتوا', 'تعمیرات', 'خدمات', 'آموزش'],
    why: 'با مهارت موجود و کمترین سرمایه، درآمد دوم در چند هفته ساخته می‌شود.',
    firstSteps: ['یک خدمت مشخص با قیمت مشخص تعریف کن.', 'سه نمونه‌کار یا نمونه اجرا آماده کن.', '۲۰ مشتری احتمالی لیست کن.', 'روزی ۵ تماس/پیام بزن.', 'اولین سفارش را با قیمت آغازین ببند.'],
  },
  {
    id: 'service_business', fa: 'کسب‌وکار خدماتی', icon: '🛠️', cat: 'business',
    risk: 45, capitalNeed: 'متوسط', capitalBase: 0.15, timeToIncome: 4, potential: 'بالا',
    tags: ['تعمیرات', 'برق صنعتی', 'مکانیک', 'خدمات', 'ساختمان', 'آموزش'],
    why: 'کسب‌وکار خدماتی با مهارت فعلی، سریع‌ترین جریان نقدی را می‌سازد.',
    firstSteps: ['مشتری هدف و مسئله دردناک را بنویس.', 'قیمت سه سطحی تعیین کن.', 'MVP را در ۷ روز اجرا کن.', 'یک کانال جذب مشتری برای ۳۰ روز انتخاب کن.', 'برنامه جذب اولین مشتری را اجرا کن.'],
  },
  {
    id: 'product_business', fa: 'کسب‌وکار محصولی', icon: '📦', cat: 'business',
    risk: 60, capitalNeed: 'زیاد', capitalBase: 0.5, timeToIncome: 8, potential: 'خیلی بالا',
    tags: ['تولید', 'تجارت', 'کشاورزی', 'معدن', 'محتوا'],
    why: 'مقیاس‌پذیر است اما سرمایه در گردش و ریسک فروش دارد.',
    firstSteps: ['تأمین و قیمت تمام‌شده را محاسبه کن.', 'حداقل سفارش آزمایشی کوچک بگیر.', 'کانال فروش را آزمایش کن.', 'سرمایه در گردش ۲ ماهه را تأمین کن.', 'نقطه سربه‌سر را حساب کن.'],
  },
  {
    id: 'longterm_investing', fa: 'سرمایه‌گذاری بلندمدت', icon: '📈', cat: 'investing',
    risk: 35, capitalNeed: 'متوسط', capitalBase: 0.8, timeToIncome: 12, potential: 'متوسط',
    tags: ['سرمایه‌گذاری', 'مالی'],
    why: 'برای سرمایه موجود، این مسیر کم‌زحمت‌ترین راه رشد مرکب است.',
    firstSteps: ['صندوق اضطراری ۳ ماهه را کامل کن.', 'تخصیص دارایی بنویس (نقد/درآمدزا/رشد).', 'قانون بازبینی ماهانه تعیین کن.', 'هزینه و مالیات هر دارایی را بسنج.', 'با مبلغ کم شروع کن و قانون را ثابت نگه دار.'],
  },
  {
    id: 'hybrid', fa: 'ترکیب تخصص + کسب‌وکار + سرمایه‌گذاری', icon: '🚀', cat: 'wealth',
    risk: 50, capitalNeed: 'متوسط', capitalBase: 0.3, timeToIncome: 5, potential: 'خیلی بالا',
    tags: ['مدیریت', 'فروش', 'سرمایه‌گذاری', 'برنامه‌نویسی', 'بازاریابی'],
    why: 'سه منبع درآمد، مقاوم‌ترین ساختار ثروت را می‌سازد؛ نیازمند نظم و زمان است.',
    firstSteps: ['درآمد اصلی را پایدار کن.', 'یک خدمت جانبی با قیمت مشخص بساز.', '۱۰٪ پس‌انداز را خودکار کن.', 'سه ماه بعد، خدمت جانبی را به سیستم تبدیل کن.', 'سپس سرمایه‌گذاری منظم شروع کن.'],
  },
  {
    id: 'debt_elimination', fa: 'خروج از بدهی و بازسازی پایه', icon: '🛟', cat: 'moneymgmt',
    risk: 10, capitalNeed: 'خیلی کم', capitalBase: 0, timeToIncome: 1, potential: 'متوسط',
    tags: [],
    why: 'تا وقتی بدهی سنگین و جریان نقدی منفی است، هر سرمایه‌گذاری روی پای لرزان است.',
    firstSteps: ['فهرست بدهی‌ها با نرخ بهره بساز.', 'صندوق اضطراری کوچک (۱ ماه هزینه) بساز.', 'روش بهمن یا گلوله برفی را انتخاب کن.', 'یک هزینه ثابت را حذف کن.', 'یک درآمد جانبی کوچک برای پرداخت اضافه بساز.'],
  },
  {
    id: 'trade_business', fa: 'تجارت و خریدوفروش', icon: '🔁', cat: 'business',
    risk: 55, capitalNeed: 'متوسط', capitalBase: 0.4, timeToIncome: 3, potential: 'بالا',
    tags: ['تجارت', 'فروش', 'تولید'],
    why: 'اگر شبکه ارتباطی فروش داری، گردش سرمایه سریع نقدینگی می‌سازد.',
    firstSteps: ['یک کالا با تقاضای ثابت انتخاب کن.', 'قیمت خرید، حمل و حاشیه سود را حساب کن.', 'با یک فروشنده و یک خریدار قرارداد آزمایشی ببند.', 'گردش سرمایه را اندازه بگیر.', 'مقیاس را فقط بعد از سود آزمایشی بالا ببر.'],
  },
  {
    id: 'content_education', fa: 'محتوا و آموزش تخصص', icon: '🎥', cat: 'passive',
    risk: 40, capitalNeed: 'کم', capitalBase: 0.05, timeToIncome: 7, potential: 'بالا',
    tags: ['محتوا', 'آموزش', 'طراحی', 'هوش مصنوعی'],
    why: 'اهرم رسانه‌ای: یک بار ساختن، چند بار فروش؛ اما زمان تا درآمد بیشتر است.',
    firstSteps: ['یک موضوع تخصصی مشخص انتخاب کن.', 'هفته‌ای دو محتوا برای ۸ هفته منتشر کن.', 'لیست مخاطب (کانال/خبرنامه) بساز.', 'یک محصول کوچک قابل فروش طراحی کن.', 'اولین ۱۰ مشتری را با قیمت آغازین بگیر.'],
  },
];

function skillMatch(path, state) {
  const skills = (state.profile.skills || []).map((s) => String(s));
  const tags = path.tags || [];
  if (!tags.length) return 55;
  const hits = tags.filter((t) => skills.indexOf(t) > -1).length;
  const jobHit = tags.indexOf(state.profile.job) > -1 ? 12 : 0;
  return clamp(38 + hits * 18 + jobHit, 15, 100);
}

/** کشف مسیرهای احتمالی با امتیاز شخصی‌سازی‌شده */
export function discoverPaths(state) {
  const m = financeMetrics(state);
  const sk = skillScore(state);
  const risk = +state.profile.riskTolerance || 50;
  const freeHours = +state.profile.freeHours || 1;
  const age = +state.profile.age || 30;
  const liquidRatio = m.income > 0 ? m.investable / Math.max(1, m.expense * 3) : 0;

  const paths = PATHS.map((p) => {
    const fit = skillMatch(p, state);
    let score = fit * 0.42;
    score += (100 - p.risk) * 0.12 * (risk / 55);
    score += (100 - Math.min(100, p.capitalBase * 100)) * 0.14 * clamp(liquidRatio + 0.4, 0, 1.3);
    score += clamp(100 - p.timeToIncome * 9, 0, 100) * 0.14;
    score += (p.potential === 'خیلی بالا' ? 95 : p.potential === 'بالا' ? 80 : p.potential === 'متوسط' ? 55 : 35) * 0.18;
    if (m.negativeFlow && ['debt_elimination', 'freelancing', 'career_upgrade'].indexOf(p.id) > -1) score += 12;
    if (m.debtToIncome > 0.3 && p.id === 'debt_elimination') score += 18;
    if (m.debtToIncome > 0.3 && p.risk > 55) score -= 14;
    if (m.hasDebt === false && m.investable > m.annualExpense * 0.5 && p.id === 'longterm_investing') score += 12;
    if (freeHours >= 3 && p.id === 'hybrid') score += 8;
    if (freeHours < 1.5 && p.id === 'hybrid') score -= 12;
    if (age <= 27 && ['high_income_skill', 'content_education'].indexOf(p.id) > -1) score += 8;
    if (age >= 40 && ['longterm_investing', 'career_upgrade'].indexOf(p.id) > -1) score += 6;
    if (state.profile.job === 'student' && ['high_income_skill', 'freelancing'].indexOf(p.id) > -1) score += 10;
    if (m.income < m.expense && p.id === 'high_income_skill') score += 6;

    const capitalNeeded = Math.max(0, Math.round(p.capitalBase * Math.max(m.expense * 3, m.income * 2)));
    return {
      ...p,
      fitPercent: clamp(Math.round(fit), 5, 98),
      riskLevel: p.risk < 30 ? 'کم' : p.risk < 55 ? 'متوسط' : 'بالا',
      capitalNeeded,
      capitalLabel: p.capitalNeed,
      timeToIncomeMonths: p.timeToIncome,
      potentialLabel: p.potential,
      score: clamp(Math.round(score), 5, 98),
      monthlyIncomePotential: Math.round(m.income * (p.potential === 'خیلی بالا' ? 2.6 : p.potential === 'بالا' ? 1.9 : 1.35)),
      reasons: buildReasons(p, state, m, sk, freeHours),
    };
  });
  return paths.sort((a, b) => b.score - a.score);
}

function buildReasons(p, state, m, sk, freeHours) {
  const r = [];
  const skills = state.profile.skills || [];
  if ((p.tags || []).some((t) => skills.indexOf(t) > -1)) r.push('تخصص ثبت‌شده تو با این مسیر هم‌راستاست.');
  if (m.negativeFlow) r.push('چون جریان نقدی منفی است، اول باید درآمد یا هزینه اصلاح شود.');
  if (m.debtToIncome > 0.3) r.push('قسط‌ها بیش از ۳۰٪ درآمد است؛ ریسک سنگین فعلاً منطقی نیست.');
  if (freeHours >= 2) r.push(toFa(freeHours) + ' ساعت زمان آزاد روزانه داری و می‌توانی موازی اجرا کنی.');
  if (m.investable > m.annualExpense) r.push('سرمایه مازاد بر هزینه یک سال داری؛ اهرم سرمایه‌گذاری فعال است.');
  if (r.length < 2) r.push(p.why);
  return r.slice(0, 3);
}
function toFa(n) { return String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]); }

/** مقایسه مسیرها و انتخاب بهترین نقطه شروع */
export function chooseBest(state, paths) {
  const list = paths || discoverPaths(state);
  if (!list.length) return null;
  const best = list[0];
  const second = list[1];
  const m = financeMetrics(state);
  const comparison = list.slice(0, 4).map((p) => ({
    id: p.id, fa: p.fa, score: p.score, risk: p.risk, capitalNeeded: p.capitalNeeded,
    timeToIncome: p.timeToIncomeMonths, potential: p.potentialLabel, fit: p.fitPercent,
  }));
  const text = 'با توجه به شرایط فعلی تو (درآمد ' + Math.round(m.income) + '، نرخ پس‌انداز ' + Math.round(m.savingsRate * 100) +
    '٪، بدهی ' + Math.round(m.debtTotal) + '، زمان آزاد ' + (state.profile.freeHours || 0) + ' ساعت) مسیر «' + best.fa +
    '» بهترین نقطه شروع است' + (second ? ' و مسیر «' + second.fa + '» به‌عنوان مسیر دوم بعد از پایدار شدن اولی پیشنهاد می‌شود.' : '.');
  return { best, second, comparison, text };
}

/* ------------------------------------------------------------- نقشه راه */
const MONTH_TEMPLATES = {
  start: [
    { title: 'شناخت کامل وضعیت مالی', focus: 'اعداد واقعی را ثبت کن: درآمد، هزینه، دارایی، بدهی.', tasks: ['ثبت همه منابع درآمد ماهانه', 'ثبت همه هزینه‌های ماهانه', 'ثبت دارایی‌ها و بدهی‌ها', 'محاسبه خالص ثروت و نرخ پس‌انداز', 'تعیین مأموریت شخصی «چرا؟»'] },
    { title: 'کنترل هزینه‌ها', focus: 'حذف نشتی‌ها، نه کیفیت زندگی.', tasks: ['دسته‌بندی هزینه‌ها و پیدا کردن سه هزینه بزرگ', 'حذف یک هزینه غیرضروری ماهانه', 'قانون ۲۴ ساعت برای خریدهای غیرضروری', 'تعیین بودجه هفتگی', 'ثبت روزانه هزینه‌ها'] },
    { title: 'ساخت سیستم پس‌انداز', focus: 'پرداخت اول به خود، خودکار.', tasks: ['تعیین درصد پس‌انداز خودکار', 'جدا کردن حساب پس‌انداز', 'انتقال خودکار در روز دریافت درآمد', 'هدف موقت: هزینه یک ماه', 'بازبینی هفتگی اعداد'] },
  ],
  income: [
    { title: 'انتخاب مهارت درآمدزا', focus: 'یک مهارت، ۹۰ روز، خروجی قابل نمایش.', tasks: ['انتخاب مهارت با بالاترین ROI', 'برنامه ۹۰ روزه یادگیری', 'ثبت ۶۰ دقیقه تمرین روزانه', 'ساخت نمونه‌کار اول', 'تحقیق قیمت بازار این مهارت'] },
    { title: 'اولین درآمد جانبی', focus: 'کوچک اما واقعی.', tasks: ['تعریف خدمت مشخص با قیمت مشخص', 'لیست ۲۰ مشتری احتمالی', '۵ تماس/پیام روزانه', 'ساخت صفحه معرفی خدمت', 'بستن اولین سفارش'] },
    { title: 'افزایش درآمد اصلی', focus: 'مذاکره یا ارتقا.', tasks: ['ثبت سه دستاورد کمیتی', 'تحقیق محدوده پرداخت بازار', 'تمرین گفت‌وگوی مذاکره', 'درخواست جلسه با تصمیم‌گیر', 'تعیین هدف درآمد ۶ ماهه'] },
  ],
  build: [
    { title: 'ساخت سیستم فروش', focus: 'قیف فروش تکرارپذیر.', tasks: ['نوشتن سه اعتراض رایج و پاسخ‌ها', 'ساخت فرایند پیگیری سه‌مرحله‌ای', 'تعیین تعداد تماس روزانه', 'ثبت نرخ تبدیل هفتگی', 'درخواست معرفی از مشتری راضی'] },
    { title: 'مستندسازی و مقیاس', focus: 'کسب‌وکار بدون تو.', tasks: ['مستند کردن فرایند اجرا', 'آموزش یک نفر برای بخش اجرا', 'تعیین شاخص‌های کلیدی هفتگی', 'کاهش هزینه ثابت', 'بازبینی قیمت‌گذاری'] },
    { title: 'تبدیل درآمد به سرمایه', focus: 'پس‌انداز → دارایی درآمدزا.', tasks: ['تخصیص دارایی را بنویس', 'انتقال ماهانه به سرمایه‌گذاری', 'بررسی هزینه و مالیات دارایی‌ها', 'تعیین سقف ریسک', 'بازبینی ماهانه سبد'] },
  ],
  invest: [
    { title: 'صندوق اضطراری کامل', focus: '۳ تا ۶ ماه هزینه نقد.', tasks: ['محاسبه هزینه یک ماه', 'انتقال به حساب جدا و کم‌ریسک', 'قانون استفاده از صندوق', 'پرکردن تا ۳ ماه', 'ادامه تا ۶ ماه'] },
    { title: 'سبد سرمایه‌گذاری منظم', focus: 'ساده، متنوع، کم‌هزینه.', tasks: ['نوشتن تخصیص دارایی', 'تعیین مبلغ ماهانه ثابت', 'تعیین قانون بازبینی ماهانه', 'بررسی ریسک غیرقابل بازگشت', 'ثبت نقطه خروج'] },
    { title: 'مسیر استقلال مالی', focus: 'سرمایه موردنیاز = هزینه سالانه × ضریب.', tasks: ['محاسبه سرمایه موردنیاز', 'به‌روزرسانی نرخ پس‌انداز', 'بهینه‌سازی هزینه ثابت', 'برنامه افزایش درآمد', 'مرور پیشرفت فصلی'] },
  ],
};

export function buildRoadmap(state, path) {
  const m = financeMetrics(state);
  const chosen = path || (state.plan.pathId ? PATHS.find((p) => p.id === state.plan.pathId) : null) || discoverPaths(state)[0];
  const months = [];
  const push = (tpl, i) => months.push({ n: months.length + 1, ...tpl, from: tpl.title });

  // ماه‌های ۱ تا ۳ بر اساس وضعیت پایه
  if (m.negativeFlow || m.debtToIncome > 0.35) {
    push(MONTH_TEMPLATES.start[0]);
    push(MONTH_TEMPLATES.start[1]);
    push(MONTH_TEMPLATES.income[0]);
  } else if (m.savingsRate < 0.1) {
    push(MONTH_TEMPLATES.start[0]);
    push(MONTH_TEMPLATES.start[2]);
    push(MONTH_TEMPLATES.income[0]);
  } else {
    push(MONTH_TEMPLATES.start[0]);
    push(MONTH_TEMPLATES.income[0]);
    push(MONTH_TEMPLATES.income[1]);
  }

  // ماه‌های ۴ به بعد بر اساس مسیر
  const flow = {
    career_upgrade: ['income', 'income', 'build', 'invest'],
    high_income_skill: ['income', 'income', 'income', 'build'],
    freelancing: ['income', 'build', 'build', 'invest'],
    service_business: ['income', 'build', 'build', 'invest'],
    product_business: ['build', 'build', 'build', 'invest'],
    longterm_investing: ['invest', 'invest', 'invest', 'build'],
    hybrid: ['income', 'build', 'build', 'invest'],
    debt_elimination: ['start', 'income', 'build', 'invest'],
    trade_business: ['income', 'build', 'build', 'invest'],
    content_education: ['income', 'build', 'build', 'invest'],
  }[chosen.id] || ['income', 'build', 'invest'];
  flow.forEach((k) => MONTH_TEMPLATES[k].forEach((t) => push(t, months.length)));

  // تکمیل تا ۱۲ ماه با تکرار چرخه رشد
  let i = 0;
  while (months.length < 12) {
    const cyc = [MONTH_TEMPLATES.income[2], MONTH_TEMPLATES.build[0], MONTH_TEMPLATES.invest[1], MONTH_TEMPLATES.build[2]][i % 4];
    months.push({ n: months.length + 1, ...cyc });
    i++;
  }
  const trimmed = months.slice(0, 12).map((mm, idx) => ({
    n: idx + 1,
    title: mm.title,
    focus: mm.focus,
    tasks: mm.tasks,
    done: false,
    progress: 0,
  }));

  const phases = [
    { index: 0, title: 'پایه: شفافیت و کنترل', from: 1, to: 3 },
    { index: 1, title: 'رشد درآمد', from: 4, to: 6 },
    { index: 2, title: 'ساخت سیستم و دارایی', from: 7, to: 9 },
    { index: 3, title: 'سرمایه‌گذاری و استقلال', from: 10, to: 12 },
  ];
  const roadmap = {
    id: uid('rm'), pathId: chosen.id, pathTitle: chosen.fa, icon: chosen.icon,
    createdAt: todayKey(), startMonth: new Date().toISOString().slice(0, 7),
    months: trimmed, phases,
    goal: state.goals[0] ? state.goals[0].title : 'استقلال مالی',
  };
  return { roadmap, chosen };
}

/* --------------------------------------------------------------- مأموریت‌ها */
export function buildMissions(state) {
  const m = financeMetrics(state);
  const monthlyExpense = Math.max(1, m.expense);
  const list = [
    { id: 'm1', title: 'ساخت صندوق اضطراری', target: monthlyExpense * 3, unit: 'money', current: Math.min(m.liquid, monthlyExpense * 3), why: 'بدون سپر نقدی، هر شوک برنامه را می‌شکند.', level: 1 },
    { id: 'm2', title: 'افزایش درآمد اصلی', target: m.income * 1.3, unit: 'money', current: m.income, why: 'سقف درآمد، سقف سرعت ثروت است.', level: 2 },
    { id: 'm3', title: 'ساخت درآمد دوم', target: Math.max(1, Math.round(m.income * 0.25)), unit: 'money', current: m.variableIncome > 0 ? Math.min(m.variableIncome, Math.round(m.income * 0.25)) : 0, why: 'تک‌منبعی بودن، شکننده است.', level: 3 },
    { id: 'm4', title: 'راه‌اندازی کسب‌وکار کوچک', target: 1, unit: 'count', current: state.profile.job === 'business' ? 1 : (state.plan.businessStarted ? 1 : 0), why: 'مالکیت، اهرم واقعی است.', level: 4 },
    { id: 'm5', title: 'ساخت سبد سرمایه‌گذاری', target: monthlyExpense * 12, unit: 'money', current: Math.min(m.investable, monthlyExpense * 12), why: 'پول باید برایت کار کند.', level: 5 },
    { id: 'm6', title: 'استقلال مالی', target: monthlyExpense * 25 * 12 / 12 * 25, unit: 'money', current: m.investable, why: 'سرمایه لازم برای پوشش هزینه‌ها بدون کار اجباری.', level: 6 },
  ];
  return list.map((x) => ({ ...x, progress: x.target > 0 ? clamp(x.current / x.target, 0, 1) : 0, unlocked: unlockLevel(state) >= x.level }));
}

export function unlockLevel(state) {
  const m = financeMetrics(state);
  let lvl = 1;
  if (m.runwayMonths >= 1) lvl = 2;
  if (m.savingsRate >= 0.1 && m.income > 0) lvl = 3;
  if (m.incomeStreams >= 2 || m.variableIncome > 0) lvl = 4;
  if (state.plan.businessStarted || state.profile.job === 'business') lvl = 5;
  if (m.investable > m.annualExpense * 0.5) lvl = 6;
  return clamp(lvl, 1, 6);
}

export const UNLOCK_LEVELS = [
  { level: 1, fa: 'مدیریت پول', need: 'ثبت کامل درآمد/هزینه/دارایی/بدهی' },
  { level: 2, fa: 'افزایش درآمد', need: 'صندوق اضطراری حداقل ۱ ماه' },
  { level: 3, fa: 'درآمد دوم', need: 'نرخ پس‌انداز بالای ۱۰٪' },
  { level: 4, fa: 'کسب‌وکار', need: 'یک منبع درآمد دوم فعال' },
  { level: 5, fa: 'سرمایه‌گذاری', need: 'راه‌اندازی کسب‌وکار یا منبع سوم' },
  { level: 6, fa: 'ساخت دارایی', need: 'سرمایه بیشتر از ۵۰٪ هزینه سالانه' },
];

/* ------------------------------------------------------ برنامه‌ریزی معکوس */
export function reversePlan(state, goal) {
  const m = financeMetrics(state);
  const target = goal && goal.targetAmount ? +goal.targetAmount : Math.max(0, m.annualExpense * 25 - m.investable);
  const months = goal && goal.deadline ? Math.max(6, Math.round(daysBetween(todayKey(), goal.deadline) / 30)) : 60;
  const gap = Math.max(0, target - Math.max(0, m.investable));
  const neededMonthlySaving = gap / months;
  const rate = clamp(m.savingsRate || 0.2, 0.05, 0.6);
  const neededIncome = neededMonthlySaving / rate;
  const incomeGap = Math.max(0, neededIncome - m.income);
  const skillNeeded = incomeGap > m.income * 0.3 ? 'مهارت نادر/قیمت‌گذاری بالاتر' : 'بهبود قیمت و نرخ تبدیل';
  const vehicleNeeded = incomeGap > m.income * 0.6 ? 'کسب‌وکار یا خدمات مقیاس‌پذیر' : incomeGap > 0 ? 'خدمات جانبی / فریلنسری' : 'سرمایه‌گذاری منظم';
  const weekly = neededMonthlySaving / 4.3;
  const daily = neededMonthlySaving / 30;

  const chain = [
    { level: 'هدف نهایی', value: target, text: 'خالص ثروت/سرمایه هدف' },
    { level: 'سرمایه موردنیاز', value: target, text: 'با فرض نرخ برداشت ایمن' },
    { level: 'درآمد موردنیاز', value: neededIncome, text: 'برای تأمین پس‌انداز ماهانه لازم' },
    { level: 'مهارت موردنیاز', value: null, text: skillNeeded },
    { level: 'وسیله (شغل/کسب‌وکار)', value: null, text: vehicleNeeded },
    { level: 'هدف سالانه', value: gap, text: 'افزایش خالص ثروت در بازه' },
    { level: 'هدف ماهانه', value: neededMonthlySaving, text: 'پس‌انداز ماهانه لازم' },
    { level: 'هدف هفتگی', value: weekly, text: 'پس‌انداز هفتگی معادل' },
    { level: 'هدف روزانه', value: daily, text: 'معادل روزانه (برای تصور ذهنی)' },
  ];
  const todayTask = todayBigMove(state, { neededMonthlySaving, incomeGap, vehicleNeeded, skillNeeded });
  return { target, months, gap, neededMonthlySaving, neededIncome, incomeGap, skillNeeded, vehicleNeeded, weekly, daily, chain, todayTask };
}

export function todayBigMove(state, ctx) {
  const m = ctx && ctx.metrics ? ctx.metrics : financeMetrics(state);
  const p = state.plan || {};
  const day = (p.days || {})[todayKey()];
  if (day && day.bigMove) return day.bigMove;
  if (m.negativeFlow) return { title: 'یک هزینه ثابت ماهانه را حذف یا کم کن و عدد جدید را ثبت کن', cat: 'مالی', minutes: 20, impact: 90 };
  if (m.debtToIncome > 0.35) return { title: 'فهرست بدهی‌ها را با نرخ بهره مرتب کن و بدهی اول را علامت بزن', cat: 'بدهی', minutes: 25, impact: 88 };
  if (m.savingsRate < 0.1) return { title: 'درصد پس‌انداز خودکار را تعیین و یک انتقال آزمایشی انجام بده', cat: 'پس‌انداز', minutes: 20, impact: 86 };
  if (ctx && ctx.incomeGap > m.income * 0.3) return { title: '۶۰ دقیقه روی مهارت درآمدزای انتخابی کار کن و یک نمونه‌کار بساز', cat: 'مهارت', minutes: 60, impact: 92 };
  if (!state.finance.incomes.some((i) => i.kind === 'side')) return { title: 'یک خدمت مشخص با قیمت مشخص بنویس و به ۵ مشتری احتمالی پیام بده', cat: 'درآمد دوم', minutes: 45, impact: 90 };
  return { title: '۵ تماس/پیام با مشتری بالقوه یا یک اقدام فروش انجام بده', cat: 'فروش', minutes: 45, impact: 85 };
}

/* --------------------------------------------------- واقع‌بینی و احتمال هدف */
export function goalRealism(state, goal) {
  const m = financeMetrics(state);
  const rp = reversePlan(state, goal);
  const ratio = rp.neededMonthlySaving / Math.max(1, m.savings > 0 ? m.savings : 1);
  let verdict, message, alternative;
  if (ratio <= 1.05) {
    verdict = 'reachable';
    message = 'با فرضیات فعلی، این هدف در بازه زمانی انتخابی قابل حصول است؛ اگر نرخ پس‌انداز و اجرا حفظ شود.';
    alternative = null;
  } else if (ratio <= 2.2) {
    verdict = 'stretch';
    message = 'این هدف چالشی است: برای رسیدن به آن باید پس‌انداز ماهانه حدود ' + Math.round((ratio - 1) * 100) + '٪ افزایش یابد یا بازه زمانی طولانی‌تر شود.';
    alternative = { type: 'time', months: Math.round(rp.months * ratio) };
  } else {
    verdict = 'unreachable';
    message = 'با فرضیات فعلی، این هدف بسیار دور از دسترس است. ابتدا باید متغیرهای درآمد، سرمایه، مهارت و زمان تغییر کنند.';
    alternative = { type: 'path', pathId: 'high_income_skill', text: 'ابتدا درآمد را در ۱۲ ماه ۲ تا ۳ برابر کن، سپس هدف را دوباره تنظیم کن.' };
  }
  return { verdict, ratio, message, alternative, rp, metrics: m };
}

/* ---------------------------------------------------- بازتنظیم تطبیقی مسیر */
export function recalibrate(state) {
  const m = financeMetrics(state);
  const tc = taskCompletionRate(state, 14);
  const sk = skillScore(state);
  const notes = [];
  let adjust = 'none';

  if (tc < 0.4) { adjust = 'reduce'; notes.push('نرخ انجام کارها پایین است؛ حجم کارهای روزانه ۴۰٪ کم شد تا اجرا ممکن شود.'); }
  else if (tc > 0.85) { adjust = 'increase'; notes.push('عملکرد بالا است؛ حجم و دشواری کارها افزایش یافت.'); }
  else notes.push('حجم کارها مناسب است و بدون تغییر حفظ شد.');

  if (m.negativeFlow) notes.push('چون هزینه از درآمد بیشتر است، اولویت فعلی کنترل هزینه و افزایش درآمد است، نه سرمایه‌گذاری.');
  if (m.debtToIncome > 0.3) notes.push('قسط‌ها سنگین است؛ بخشی از پس‌انداز به بازپرداخت بدهی اختصاص یافت.');
  if (m.savingsRate >= 0.2 && sk >= 60) notes.push('پس‌انداز و مهارت خوب است؛ می‌توانی منبع درآمد دوم را جدی‌تر اجرا کنی.');
  if ((+state.profile.freeHours || 0) < 1) notes.push('زمان آزاد کم است؛ فقط یک کار غالب روزانه در برنامه قرار گرفت.');

  return { adjust, tc: Math.round(tc * 100), notes, at: todayKey() };
}

export function roadmapProgress(state) {
  const rm = state.plan.roadmap;
  if (!rm || !rm.months || !rm.months.length) return { percent: 0, currentMonth: 0, monthsDone: 0 };
  const started = rm.createdAt ? Math.max(1, Math.floor(daysBetween(rm.createdAt, todayKey()) / 30) + 1) : 1;
  const monthsDone = rm.months.filter((mm) => mm.done).length;
  const percent = clamp(Math.round((monthsDone / rm.months.length) * 100), 0, 100);
  return { percent, currentMonth: clamp(started, 1, rm.months.length), monthsDone };
}

export function currentMonthPlan(state) {
  const rm = state.plan.roadmap;
  if (!rm) return null;
  const p = roadmapProgress(state);
  return rm.months[p.currentMonth - 1] || rm.months[0];
}

export function deadlineInfo(state) {
  const g = (state.goals || []).find((x) => !x.done) || null;
  if (!g || !g.deadline) return null;
  const left = daysBetween(todayKey(), g.deadline);
  return { goal: g, left, deadlineFa: faDate(g.deadline), overdue: left < 0, addDays: (n) => addDays(todayKey(), n) };
}
