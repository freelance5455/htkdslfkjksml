import { PlayerProgress, StageProgress } from '../types/crossword';

const DB_NAME = 'ArabicCrosswordDB';
const DB_VERSION = 1;
const STORE_NAME = 'player_progress';
const PROGRESS_KEY = 'main_progress';

const DEFAULT_PROGRESS: PlayerProgress = {
  unlockedStageId: 1,
  currentStageId: 1,
  stageProgresses: {},
  settings: {
    sound: true,
    effects: true,
    vibration: true,
  },
};

export class ProgressRepository {
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  constructor() {
    this.initIndexedDB();
  }

  private initIndexedDB(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        resolve(null);
        return;
      }

      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME);
          }
        };

        request.onsuccess = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          resolve(db);
        };

        request.onerror = () => {
          console.warn('IndexedDB failed to open, falling back to localStorage');
          resolve(null);
        };
      } catch (err) {
        console.warn('IndexedDB error, falling back to localStorage', err);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  public async getProgress(): Promise<PlayerProgress> {
    const db = await this.initIndexedDB();

    if (db) {
      try {
        return await new Promise<PlayerProgress>((resolve) => {
          const tx = db.transaction(STORE_NAME, 'readonly');
          const store = tx.objectStore(STORE_NAME);
          const request = store.get(PROGRESS_KEY);

          request.onsuccess = () => {
            if (request.result) {
              resolve({ ...DEFAULT_PROGRESS, ...request.result });
            } else {
              resolve(DEFAULT_PROGRESS);
            }
          };

          request.onerror = () => {
            resolve(this.getFallbackLocalStorage());
          };
        });
      } catch {
        return this.getFallbackLocalStorage();
      }
    } else {
      return this.getFallbackLocalStorage();
    }
  }

  public async saveProgress(progress: PlayerProgress): Promise<void> {
    const db = await this.initIndexedDB();

    // Always mirror in localStorage for redundancy
    this.saveFallbackLocalStorage(progress);

    if (db) {
      try {
        await new Promise<void>((resolve, reject) => {
          const tx = db.transaction(STORE_NAME, 'readwrite');
          const store = tx.objectStore(STORE_NAME);
          const request = store.put(progress, PROGRESS_KEY);

          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        });
      } catch (err) {
        console.warn('Failed saving to IndexedDB', err);
      }
    }
  }

  public async saveStageAnswers(
    stageId: number,
    userAnswers: { [cellKey: string]: string },
    completedQuestionIds: string[],
    isCompleted: boolean,
    hintsUsed: number = 0
  ): Promise<PlayerProgress> {
    const progress = await this.getProgress();

    const previousProg = progress.stageProgresses[stageId];
    const previousBestStars = previousProg?.bestStars !== undefined ? previousProg.bestStars : undefined;

    // Calculate stars for current performance: 3 - hintsUsed (minimum 0, max 3)
    const currentRunStars = Math.max(0, 3 - Math.min(3, hintsUsed));

    let updatedBestStars = previousBestStars;
    if (isCompleted) {
      if (previousBestStars !== undefined) {
        updatedBestStars = Math.max(previousBestStars, currentRunStars);
      } else {
        updatedBestStars = currentRunStars;
      }
    }

    const stageProg: StageProgress = {
      stageId,
      completed: isCompleted || (previousProg?.completed ?? false),
      userAnswers,
      completedQuestionIds,
      lastPlayedTimestamp: Date.now(),
      hintsUsed,
      bestStars: updatedBestStars,
    };

    progress.stageProgresses[stageId] = stageProg;
    progress.currentStageId = stageId;

    if (isCompleted && progress.unlockedStageId <= stageId && stageId < 50) {
      progress.unlockedStageId = stageId + 1;
    }

    await this.saveProgress(progress);
    return progress;
  }

  public async resetStageProgress(stageId: number): Promise<PlayerProgress> {
    const progress = await this.getProgress();
    if (progress.stageProgresses[stageId]) {
      const prevBestStars = progress.stageProgresses[stageId].bestStars;
      const prevCompleted = progress.stageProgresses[stageId].completed;
      
      // When resetting for a new play attempt, keep previous bestStars and completed state so prior achievements are never lost
      progress.stageProgresses[stageId] = {
        stageId,
        completed: prevCompleted,
        userAnswers: {},
        completedQuestionIds: [],
        lastPlayedTimestamp: Date.now(),
        hintsUsed: 0,
        bestStars: prevBestStars,
      };
    }
    await this.saveProgress(progress);
    return progress;
  }

  public async resetAllProgress(): Promise<PlayerProgress> {
    const resetState: PlayerProgress = {
      ...DEFAULT_PROGRESS,
      stageProgresses: {},
      unlockedStageId: 1,
      currentStageId: 1,
    };
    await this.saveProgress(resetState);
    return resetState;
  }

  private getFallbackLocalStorage(): PlayerProgress {
    try {
      const data = localStorage.getItem(PROGRESS_KEY);
      if (data) {
        return { ...DEFAULT_PROGRESS, ...JSON.parse(data) };
      }
    } catch (e) {
      console.warn('LocalStorage read error', e);
    }
    return DEFAULT_PROGRESS;
  }

  private saveFallbackLocalStorage(progress: PlayerProgress): void {
    try {
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
    } catch (e) {
      console.warn('LocalStorage write error', e);
    }
  }
}

export const progressRepo = new ProgressRepository();
