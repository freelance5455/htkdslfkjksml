import type { BankId, KitPreset, SidebarPosition, SidebarRotation, StoredSound } from '../types/octapad';

const DB_NAME = 'octapad_pro_studio_db';
const DB_VERSION = 1;
const STORE_SOUNDS = 'sounds';
const STORE_KITS = 'kits';
const STORE_SETTINGS = 'settings';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_SOUNDS)) {
        db.createObjectStore(STORE_SOUNDS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_KITS)) {
        db.createObjectStore(STORE_KITS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveCustomSound(sound: StoredSound): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SOUNDS, 'readwrite');
    tx.objectStore(STORE_SOUNDS).put(sound);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAllCustomSounds(): Promise<StoredSound[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SOUNDS, 'readonly');
    const req = tx.objectStore(STORE_SOUNDS).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function deleteCustomSound(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SOUNDS, 'readwrite');
    tx.objectStore(STORE_SOUNDS).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveKitToDb(kit: KitPreset): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_KITS, 'readwrite');
    tx.objectStore(STORE_KITS).put({ ...kit, updatedAt: Date.now() });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAllSavedKits(): Promise<KitPreset[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_KITS, 'readonly');
    const req = tx.objectStore(STORE_KITS).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function deleteKitFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_KITS, 'readwrite');
    tx.objectStore(STORE_KITS).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export interface AppSettings {
  activeKitId: string;
  activeBank: BankId;
  bpm: number;
  sidebarPosition?: SidebarPosition;
  sidebarRotation?: SidebarRotation;
}

export async function saveAppSettings(settings: AppSettings): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SETTINGS, 'readwrite');
    tx.objectStore(STORE_SETTINGS).put({ key: 'app_state', ...settings });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadAppSettings(): Promise<AppSettings | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SETTINGS, 'readonly');
    const req = tx.objectStore(STORE_SETTINGS).get('app_state');
    req.onsuccess = () => {
      if (!req.result) resolve(null);
      else {
        resolve({
          activeKitId: req.result.activeKitId,
          activeBank: req.result.activeBank,
          bpm: req.result.bpm ?? 120,
          sidebarPosition: req.result.sidebarPosition ?? 'right',
          sidebarRotation: req.result.sidebarRotation ?? 0,
        });
      }
    };
    req.onerror = () => reject(req.error);
  });
}
