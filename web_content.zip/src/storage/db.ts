/**
 * xvBOARD IndexedDB Persistence Engine
 * Complete local-first storage for boards, canvas objects, viewports, thumbnails, and app settings.
 */

import { Board, AppSettings, CanvasElement } from '../canvas/types';

const DB_NAME = 'xvboard_database';
const DB_VERSION = 1;
const STORE_BOARDS = 'boards';
const STORE_SETTINGS = 'settings';

const DEFAULT_SETTINGS: AppSettings = {
  themeMode: 'preset',
  presetKey: 'ocean-blue',
  customSeedHex: '#1E88E5',
  colorSchemePreference: 'system',
  stylusSettings: {
    palmRejectionSensitivity: 'high',
    penOnlyInking: false,
    pressureSensitivity: true,
    showHoverCursor: true,
    minBrushWidthRatio: 0.35,
    maxBrushWidthRatio: 1.65,
  },
  gridSnap: false,
  shapeRecognition: false,
};

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this environment'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_BOARDS)) {
        const boardStore = db.createObjectStore(STORE_BOARDS, { keyPath: 'id' });
        boardStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        boardStore.createIndex('isFavorite', 'isFavorite', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Retrieve all boards ordered by updatedAt descending
 */
export async function getAllBoards(): Promise<Board[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BOARDS, 'readwrite');
    const store = tx.objectStore(STORE_BOARDS);
    const request = store.getAll();

    request.onsuccess = () => {
      let results: Board[] = request.result || [];
      // Clean up legacy seed demo boards if present in storage
      const demoIds = ['seed-board-architecture', 'seed-board-stylus-art'];
      const hadDemos = results.some(b => demoIds.includes(b.id));
      if (hadDemos) {
        demoIds.forEach(id => store.delete(id));
        results = results.filter(b => !demoIds.includes(b.id));
      }

      // Sort by updatedAt descending
      results.sort((a, b) => b.updatedAt - a.updatedAt);
      resolve(results);
    };

    request.onerror = () => reject(request.error);
  });
}

/**
 * Get single board by ID
 */
export async function getBoard(id: string): Promise<Board | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BOARDS, 'readonly');
    const store = tx.objectStore(STORE_BOARDS);
    const request = store.get(id);

    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Save or update board
 */
export async function saveBoard(board: Board): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BOARDS, 'readwrite');
    const store = tx.objectStore(STORE_BOARDS);
    const request = store.put(board);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Delete board
 */
export async function deleteBoard(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BOARDS, 'readwrite');
    const store = tx.objectStore(STORE_BOARDS);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Duplicate an existing board
 */
export async function duplicateBoard(id: string): Promise<Board> {
  const original = await getBoard(id);
  if (!original) throw new Error('Board not found');

  const now = Date.now();
  const duplicate: Board = {
    ...original,
    id: `board-${now}-${Math.random().toString(36).substring(2, 7)}`,
    title: `${original.title} (Copy)`,
    createdAt: now,
    updatedAt: now,
    isFavorite: false,
    elements: JSON.parse(JSON.stringify(original.elements)),
  };

  await saveBoard(duplicate);
  return duplicate;
}

/**
 * Toggle favorite status
 */
export async function toggleFavorite(id: string): Promise<boolean> {
  const board = await getBoard(id);
  if (!board) throw new Error('Board not found');

  board.isFavorite = !board.isFavorite;
  board.updatedAt = Date.now();
  await saveBoard(board);
  return board.isFavorite;
}

/**
 * Create a brand new empty board
 */
export async function createNewBoard(title = 'Untitled Board'): Promise<Board> {
  const now = Date.now();
  const board: Board = {
    id: `board-${now}-${Math.random().toString(36).substring(2, 7)}`,
    title,
    createdAt: now,
    updatedAt: now,
    isFavorite: false,
    bgType: 'dots',
    bgColor: '#121418',
    viewport: { x: 0, y: 0, zoom: 1.0 },
    elements: [],
  };

  await saveBoard(board);
  return board;
}

/**
 * Get Application Settings
 */
export async function getSettings(): Promise<AppSettings> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SETTINGS, 'readonly');
    const store = tx.objectStore(STORE_SETTINGS);
    const request = store.get('app_settings');

    request.onsuccess = () => {
      resolve(request.result ? { ...DEFAULT_SETTINGS, ...request.result.data } : DEFAULT_SETTINGS);
    };
    request.onerror = () => reject(request.error);
  });
}

/**
 * Save Application Settings
 */
export async function saveSettings(settings: AppSettings): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_SETTINGS, 'readwrite');
    const store = tx.objectStore(STORE_SETTINGS);
    const request = store.put({ id: 'app_settings', data: settings });

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Export all boards and settings for backup
 */
export async function exportFullBackup(): Promise<string> {
  const boards = await getAllBoards();
  const settings = await getSettings();

  const backupData = {
    app: 'xvBOARD',
    version: '1.0.0',
    exportedAt: new Date().toISOString(),
    settings,
    boards,
  };

  return JSON.stringify(backupData, null, 2);
}

/**
 * Import backup with safety validation
 */
export async function importFullBackup(jsonContent: string): Promise<{ boardsCount: number }> {
  const parsed = JSON.parse(jsonContent);
  if (!parsed || !Array.isArray(parsed.boards)) {
    throw new Error('Invalid xvBOARD backup format: missing boards array');
  }

  const db = await openDB();
  const tx = db.transaction([STORE_BOARDS, STORE_SETTINGS], 'readwrite');
  const boardStore = tx.objectStore(STORE_BOARDS);

  for (const b of parsed.boards) {
    if (b.id && b.title && Array.isArray(b.elements)) {
      boardStore.put(b);
    }
  }

  if (parsed.settings) {
    const settingsStore = tx.objectStore(STORE_SETTINGS);
    settingsStore.put({ id: 'app_settings', data: parsed.settings });
  }

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve({ boardsCount: parsed.boards.length });
    tx.onerror = () => reject(tx.error);
  });
}
