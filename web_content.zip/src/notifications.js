/* ==========================================================================
   notifications.js — هشدارهای داخلی + Notification محلی (در صورت پشتیبانی)
   ========================================================================== */

import { State } from './store.js';
import { faDate, todayKey, toFaDigits, currentMonthKey, daysBetween } from './utils.js';

export const NOTIF_KEY = 'bp_notify_permission';

export function notifSupported() { return typeof Notification !== 'undefined'; }
export function notifPermission() {
  if (!notifSupported()) return 'unsupported';
  try { return Notification.permission; } catch (e) { return 'unsupported'; }
}
export async function requestNotifPermission() {
  if (!notifSupported()) return 'unsupported';
  try { return await Notification.requestPermission(); } catch (e) { return 'denied'; }
}
export function pushLocal(title, body) {
  if (notifPermission() !== 'granted') return false;
  try { new Notification(title, { body, icon: './assets/icons/icon.svg', tag: 'billionaire-path' }); return true; }
  catch (e) { return false; }
}

/** تولید هشدارهای هوشمند بر اساس وضعیت فعلی کاربر */
export function buildAlerts(state) {
  const out = [];
  const fin = state.finance;
  const income = fin.incomes.reduce((a, b) => a + (+b.amount || 0), 0);
  const expenses = fin.expenses.reduce((a, b) => a + (+b.amount || 0), 0);
  const mk = currentMonthKey();

  // ۱) کارهای عقب‌افتاده
  const overdue = [];
  Object.keys(state.plan.days || {}).forEach((k) => {
    if (k >= todayKey()) return;
    (state.plan.days[k].tasks || []).forEach((tk) => { if (!tk.done) overdue.push({ day: k, task: tk }); });
  });
  if (overdue.length) {
    out.push({
      id: 'overdue', level: 'warn', icon: '⏳',
      title: toFaDigits(overdue.length) + ' کار عقب‌افتاده داری',
      body: 'برنامه را طوری اصلاح می‌کنم که بدون فشار جبران شود. امروز فقط «یک» کار عقب‌افتاده را بردار.',
      action: { screen: 'plan', label: 'بازآرایی برنامه' },
    });
  }

  // ۲) هزینه بیشتر از درآمد
  if (income > 0 && expenses >= income) {
    out.push({
      id: 'negative_flow', level: 'danger', icon: '🚨',
      title: 'جریان نقدی منفی است',
      body: 'هزینه‌های ماهانه از درآمد بیشتر است. تا وقتی این جریان اصلاح نشود هیچ مسیری جواب نمی‌دهد.',
      action: { screen: 'wealth', label: 'مرور هزینه‌ها' },
    });
  }

  // ۳) افت نرخ پس‌انداز
  const rate = income > 0 ? (income - expenses) / income : 0;
  if (income > 0 && rate > 0 && rate < 0.1) {
    out.push({
      id: 'low_saving', level: 'warn', icon: '🪣',
      title: 'نرخ پس‌انداز پایین (' + toFaDigits(Math.round(rate * 100)) + '٪)',
      body: 'قانون ۲۴ ساعت برای خریدهای غیرضروری + انتقال خودکار پس‌انداز در روز دریافت درآمد.',
      action: { screen: 'intelligence', label: 'راهکار پس‌انداز' },
    });
  }

  // ۴) نزدیک شدن موعد هدف
  (state.goals || []).forEach((g) => {
    if (!g.deadline || g.done) return;
    const left = daysBetween(todayKey(), g.deadline);
    if (left >= 0 && left <= 45) {
      out.push({
        id: 'deadline_' + g.id, level: 'warn', icon: '🎯',
        title: 'موعد هدف «' + g.title + '» نزدیک است',
        body: toFaDigits(left) + ' روز باقی مانده. اگر سرعت فعلی حفظ شود به هدف نمی‌رسیم؛ باید متغیری تغییر کند.',
        action: { screen: 'path', label: 'بازتنظیم مسیر' },
      });
    }
  });

  // ۵) پرداخت بدهی
  (fin.debts || []).forEach((d) => {
    if ((+d.amount || 0) <= 0) return;
    out.push({
      id: 'debt_' + d.id, level: 'info', icon: '📉',
      title: 'بدهی فعال: ' + (d.label || 'بدهی'),
      body: 'با روش پیشنهادی برنامه، اولویت پرداخت روی بدهی با بالاترین نرخ بهره است.',
      action: { screen: 'debt', label: 'بررسی روش پرداخت' },
    });
  });

  // ۶) بررسی ماهانه
  const lastReview = (state.plan.monthlyReviews || []).slice(-1)[0];
  if (!lastReview || lastReview.month !== mk) {
    out.push({
      id: 'monthly_review', level: 'info', icon: '🧾',
      title: 'مرور ماهانه در انتظار تو است',
      body: 'پنج سؤال کوتاه پاسخ بده تا نقشه راه بر اساس واقعیت این ماه بازمحاسبه شود.',
      action: { screen: 'reports', label: 'شروع مرور ماه' },
    });
  }

  // ۷) شکستن زنجیره
  if (state.streak && state.streak.lastActiveDay && daysBetween(state.streak.lastActiveDay, todayKey()) >= 2) {
    out.push({
      id: 'streak_broken', level: 'warn', icon: '🔥',
      title: 'زنجیره‌ات قطع شده است',
      body: 'مشکل، کمبود اطلاعات نیست؛ تبدیل اطلاعات به اقدام است. امروز فقط یک کار انجام بده.',
      action: { screen: 'today', label: 'ماموریت امروز' },
    });
  }
  return out;
}

/** بررسی و ارسال اعلان محلی برای هشدارهای بحرانی (اجازه کاربر لازم است) */
export function maybeNotify() {
  const s = State.get();
  if (!s.settings.notifications) return;
  const alerts = buildAlerts(s).filter((a) => a.level === 'danger');
  if (alerts.length) pushLocal('مسیر میلیاردری — هشدار مالی', alerts[0].title + ' — ' + alerts[0].body);
}

export function alertText(a) { return a.title + ' — ' + faDate(todayKey()); }
