/**
 * GODEX Phase 6 - Multi-Agent Orchestration & Engineering Control Plane Types
 * Strongly typed contracts for DAG Task Graphs, Autonomous Agents, Policy Validation,
 * Artifact Exchanges, Resource Conflict Locks, and Verification Coordination.
 */

import { ContextPack } from '../intelligence/contextTypes';
import { ExecutionEvidence, ExecutionResult } from '../execution/executionTypes';
import { FailureEvent, RepairPlan, BeforeAfterComparison } from '../debugger/debuggerTypes';
import { FileEditOperation } from '../coding/agentTypes';

export type TaskStatus =
  | 'QUEUED'
  | 'PLANNING'
  | 'READY'
  | 'RUNNING'
  | 'WAITING'
  | 'BLOCKED'
  | 'PASSED'
  | 'VERIFIED'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export type TaskPriority = 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type AgentRoleType =
  | 'ARCHITECT'
  | 'RESEARCHER'
  | 'CODER'
  | 'DEBUGGER'
  | 'TESTER'
  | 'UI_UX'
  | 'SECURITY'
  | 'REVIEWER'
  | 'VERIFIER';

export type AgentStatusType =
  | 'IDLE'
  | 'AVAILABLE'
  | 'ASSIGNED'
  | 'RUNNING'
  | 'WAITING'
  | 'BLOCKED'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export type AgentCapabilityType =
  | 'READ_PROJECT'
  | 'SEARCH_SYMBOLS'
  | 'READ_ARCHITECTURE'
  | 'CREATE_PLAN'
  | 'ANALYZE_DEPENDENCIES'
  | 'CREATE_PATCH'
  | 'APPLY_PATCH'
  | 'RUN_VALIDATION'
  | 'ANALYZE_FAILURE'
  | 'CREATE_REPAIR'
  | 'APPLY_REPAIR'
  | 'RUN_TESTS'
  | 'ANALYZE_TEST_FAILURE'
  | 'REVIEW_DIFF'
  | 'ANALYZE_ARCHITECTURE'
  | 'VERIFY_EVIDENCE';

export type PolicyDecision = 'ALLOWED' | 'REVIEW_REQUIRED' | 'BLOCKED';

export type ArtifactType =
  | 'ARCHITECTURE_PLAN'
  | 'RESEARCH_REPORT'
  | 'PATCH_PROPOSAL'
  | 'EXECUTION_EVIDENCE'
  | 'FAILURE_ANALYSIS'
  | 'REPAIR_PLAN'
  | 'REVIEW_REPORT'
  | 'VERIFICATION_REPORT';

export interface AgentArtifact {
  id: string;
  type: ArtifactType;
  title: string;
  createdBy: AgentRoleType;
  agentId: string;
  taskId: string;
  timestamp: number;
  content: string;
  structuredData?: Record<string, any>;
  targetFiles?: string[];
  evidence?: {
    exitCode?: number;
    testSummary?: string;
    diffSummary?: string;
    verified?: boolean;
  };
  status: 'PROPOSED' | 'APPROVED' | 'REJECTED' | 'VERIFIED';
}

export interface TaskDependency {
  taskId: string;
  type: 'HARD' | 'SOFT'; // HARD: must complete successfully; SOFT: must just finish
}

export interface OrchestrationTask {
  id: string;
  title: string;
  description: string;
  role: AgentRoleType;
  priority: TaskPriority;
  risk: RiskLevel;
  status: TaskStatus;
  dependencies: TaskDependency[];
  targetFiles: string[];
  assignedAgentId?: string;
  contextPack?: ContextPack;
  artifactsProduced: string[]; // Artifact IDs
  attemptCount: number;
  maxRetries: number;
  executionEvidence?: ExecutionEvidence;
  statusMessage?: string;
  error?: string;
  approvalRequired?: boolean;
  approvalReason?: string;
  approved?: boolean;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
}

export interface TaskGraphNode {
  task: OrchestrationTask;
  children: string[]; // Task IDs that depend on this
  parents: string[];  // Task IDs this depends on
}

export interface TaskGraph {
  nodes: Record<string, TaskGraphNode>;
  rootTaskIds: string[];
  leafTaskIds: string[];
  totalTasks: number;
  completedTasks: number;
  isCyclic: boolean;
}

export interface AgentDefinition {
  id: string;
  name: string;
  role: AgentRoleType;
  title: string;
  description: string;
  capabilities: AgentCapabilityType[];
  status: AgentStatusType;
  currentTaskId?: string;
  assignedFileLocks: string[];
  startTime?: number;
  lastActiveTime: number;
  color: string;
  icon: string;
  model: string;
}

export interface ResourceLock {
  resourceId: string; // e.g. file path or symbol
  type: 'FILE' | 'SYMBOL';
  ownedByTaskId: string;
  ownedByAgentId: string;
  acquiredAt: number;
  fingerprintAtLock: string;
}

export interface AgentConflict {
  id: string;
  type: 'FILE_MUTATION' | 'SYMBOL_OVERLAP' | 'STALE_FINGERPRINT' | 'DEPENDENCY_CYCLE';
  resourceId: string;
  conflictingTaskIds: string[];
  conflictingAgentRoles: AgentRoleType[];
  description: string;
  detectedAt: number;
  resolution?: 'WAIT' | 'REASSIGN' | 'CANCEL_TASK' | 'SERIALIZE';
  resolved: boolean;
}

export type MessageType =
  | 'TASK_ASSIGNED'
  | 'CONTEXT_READY'
  | 'ARTIFACT_CREATED'
  | 'TASK_BLOCKED'
  | 'REVIEW_REQUESTED'
  | 'VERIFICATION_REQUESTED'
  | 'CONFLICT_DETECTED'
  | 'APPROVAL_REQUESTED'
  | 'APPROVAL_GRANTED'
  | 'APPROVAL_REJECTED'
  | 'TASK_COMPLETED'
  | 'TASK_FAILED'
  | 'DEBUGGER_HANDOFF';

export interface AgentMessage {
  id: string;
  type: MessageType;
  senderRole: AgentRoleType | 'ORCHESTRATOR' | 'HUMAN';
  recipientRole: AgentRoleType | 'ORCHESTRATOR' | 'ALL';
  taskId?: string;
  artifactId?: string;
  timestamp: number;
  summary: string;
  payload?: Record<string, any>;
}

export type VerificationState =
  | 'VERIFIED'
  | 'PARTIALLY_VERIFIED'
  | 'FAILED'
  | 'REGRESSED'
  | 'UNKNOWN';

export interface VerificationCoordinatorReport {
  sessionId: string;
  finalState: VerificationState;
  userObjective: string;
  totalTasks: number;
  completedTasks: number;
  testsPassed: boolean;
  typecheckPassed: boolean;
  buildPassed: boolean;
  securityViolations: string[];
  evidenceSummary: string;
  artifactsVerified: string[];
  verifiedAt: number;
}

export interface OrchestrationSession {
  id: string;
  userObjective: string;
  status: 'IDLE' | 'PLANNING' | 'EXECUTING' | 'AWAITING_APPROVAL' | 'VERIFYING' | 'COMPLETED' | 'FAILED' | 'BLOCKED';
  taskGraph: TaskGraph;
  activeAgents: Record<string, AgentDefinition>;
  artifacts: Record<string, AgentArtifact>;
  conflicts: AgentConflict[];
  messages: AgentMessage[];
  maxConcurrentAgents: number;
  verificationReport?: VerificationCoordinatorReport;
  createdAt: number;
  updatedAt: number;
}
