/**
 * GODEX Phase 6 - Verification Coordinator
 * Aggregates Phase 4 Execution Evidence, Phase 5 Regression Results,
 * Reviewer reports, and objective acceptance criteria into a verified final report.
 */

import {
  VerificationCoordinatorReport,
  VerificationState,
  AgentArtifact,
  OrchestrationTask
} from './orchestrationTypes';
import { ExecutionEvidence } from '../execution/executionTypes';
import { BeforeAfterComparison } from '../debugger/debuggerTypes';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';

export class VerificationCoordinator {
  /**
   * Evaluates all task artifacts, execution evidence, and reviews to synthesize a truthful report.
   */
  public static coordinate(
    sessionId: string,
    userObjective: string,
    tasks: OrchestrationTask[],
    artifacts: AgentArtifact[],
    executionEvidences: ExecutionEvidence[] = [],
    regressionResults: BeforeAfterComparison[] = []
  ): VerificationCoordinatorReport {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'COMPLETED').length;

    // 1. Gather all reviews
    const reviewArtifacts = artifacts.filter(a => a.type === 'REVIEW_REPORT');
    const hasApprovedReviews = reviewArtifacts.length > 0 && reviewArtifacts.every(r => r.status === 'APPROVED');
    const hasRejectedReviews = reviewArtifacts.some(r => r.status === 'REJECTED');

    // 2. Check Execution Evidence from Phase 4
    let testsPassed = true;
    let typecheckPassed = true;
    let buildPassed = true;
    const securityViolations: string[] = [];

    executionEvidences.forEach(ev => {
      if (ev.resolvedScript === 'TEST' && (ev.exitCode !== 0 || ev.status === 'FAILED')) {
        testsPassed = false;
      }
      if (ev.resolvedScript === 'TYPECHECK' && (ev.exitCode !== 0 || ev.status === 'FAILED')) {
        typecheckPassed = false;
      }
      if (ev.resolvedScript === 'BUILD' && (ev.exitCode !== 0 || ev.status === 'FAILED')) {
        buildPassed = false;
      }
    });

    // 3. Inspect Phase 5 Regression Comparisons
    const hasRegressions = regressionResults.some(r => r.outcome === 'REGRESSED');

    // 4. Determine final Truthful State
    let finalState: VerificationState = 'UNKNOWN';
    const evidenceSnippets: string[] = [];

    if (hasRegressions) {
      finalState = 'REGRESSED';
      evidenceSnippets.push('Phase 5 Regression detected: New errors or test failures were introduced.');
    } else if (hasRejectedReviews) {
      finalState = 'FAILED';
      evidenceSnippets.push('Reviewer rejected proposed implementation due to architectural/security defects.');
    } else if (!typecheckPassed || !buildPassed || !testsPassed) {
      finalState = 'FAILED';
      evidenceSnippets.push(
        `Execution checks failed: Typecheck=${typecheckPassed ? 'PASS' : 'FAIL'}, Build=${buildPassed ? 'PASS' : 'FAIL'}, Tests=${testsPassed ? 'PASS' : 'FAIL'}`
      );
    } else if (completedTasks === totalTasks && totalTasks > 0) {
      if (hasApprovedReviews) {
        finalState = 'VERIFIED';
        evidenceSnippets.push('All DAG tasks executed successfully. Clean typecheck, passing test assertions, and approved reviews.');
      } else {
        finalState = 'FAILED';
        evidenceSnippets.push('Independent review report approval required before full verification.');
      }
    } else if (completedTasks > 0) {
      finalState = 'PARTIALLY_VERIFIED';
      evidenceSnippets.push(`${completedTasks}/${totalTasks} tasks completed. Remaining tasks pending execution.`);
    } else {
      finalState = 'UNKNOWN';
      evidenceSnippets.push('No concrete execution evidence available to verify claims.');
    }

    const report: VerificationCoordinatorReport = {
      sessionId,
      finalState,
      userObjective,
      totalTasks,
      completedTasks,
      testsPassed,
      typecheckPassed,
      buildPassed,
      securityViolations,
      evidenceSummary: evidenceSnippets.join(' '),
      artifactsVerified: artifacts.map(a => a.id),
      verifiedAt: Date.now()
    };

    // Record Verification into Phase 7 Engineering Memory if concrete evidence exists
    try {
      if (finalState === 'VERIFIED' || finalState === 'FAILED' || finalState === 'REGRESSED') {
        const allFiles = Array.from(new Set(tasks.flatMap(t => t.targetFiles)));
        EngineeringMemoryEngine.getInstance().recordVerification({
          verificationType: 'EXECUTION',
          passed: finalState === 'VERIFIED',
          exitCode: finalState === 'VERIFIED' ? 0 : 1,
          evidenceId: `orch-ver-${sessionId}`,
          summary: report.evidenceSummary,
          relatedFiles: allFiles,
          relatedTasks: tasks.map(t => t.id),
          source: 'VERIFIER'
        });
      }
    } catch (err) {
      console.warn('Could not record verification memory:', err);
    }

    return report;
  }
}
