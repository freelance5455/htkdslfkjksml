/**
 * GODEX Phase 6 - Orchestration Telemetry
 * Emits structured events into the GODEX Technical Activity Stream for real-time observability.
 */

import { AgentRoleType } from './orchestrationTypes';
import { ActivityLogItem } from '../types';

export type OrchestrationTelemetryEventType =
  | 'ORCHESTRATION_STARTED'
  | 'TASK_CREATED'
  | 'TASK_ASSIGNED'
  | 'AGENT_STARTED'
  | 'AGENT_WAITING'
  | 'AGENT_COMPLETED'
  | 'AGENT_FAILED'
  | 'ARTIFACT_CREATED'
  | 'TASK_UNBLOCKED'
  | 'RESOURCE_CONFLICT'
  | 'APPROVAL_REQUIRED'
  | 'APPROVAL_GRANTED'
  | 'APPROVAL_REJECTED'
  | 'VERIFICATION_STARTED'
  | 'VERIFICATION_COMPLETED'
  | 'ORCHESTRATION_COMPLETED'
  | 'ORCHESTRATION_FAILED';

export class OrchestrationTelemetry {
  private static listeners: Array<(event: ActivityLogItem) => void> = [];

  public static subscribe(listener: (event: ActivityLogItem) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  public static emit(
    type: OrchestrationTelemetryEventType,
    role: AgentRoleType | 'ORCHESTRATOR',
    action: string,
    details?: string,
    status: 'pending' | 'success' | 'error' | 'warning' | 'info' = 'info',
    toolCall?: any
  ): void {
    const item: ActivityLogItem = {
      id: `orch-log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      role: role === 'ORCHESTRATOR' ? 'Planner' : role === 'ARCHITECT' ? 'Architect' : role === 'CODER' ? 'Coding Agent' : role === 'DEBUGGER' ? 'Debugger' : role === 'TESTER' ? 'Verification Agent' : role === 'REVIEWER' ? 'Reviewer' : 'Verification Agent',
      state: status === 'error' ? 'FAILED' : status === 'pending' ? 'RUNNING' : status === 'success' ? 'COMPLETED' : 'ANALYZING',
      action: `[${type}] ${action}`,
      details,
      status,
      toolCall
    };

    this.listeners.forEach(listener => {
      try {
        listener(item);
      } catch (err) {
        console.error('[OrchestrationTelemetry] Listener error:', err);
      }
    });
  }
}
