/**
 * GODEX Phase 6 - Agent Registry
 * Manages the state, active assignments, locks, and status of specialized agents
 * in the multi-agent control plane.
 */

import {
  AgentDefinition,
  AgentRoleType,
  AgentStatusType
} from './orchestrationTypes';
import { AgentPolicyEngine } from './agentPolicy';

export class AgentRegistry {
  private agents: Map<string, AgentDefinition> = new Map();

  constructor() {
    this.initializeDefaultAgents();
  }

  /**
   * Initializes the 7 built-in specialized GODEX agents
   */
  public initializeDefaultAgents(): void {
    this.agents.clear();

    const definitions: Array<{
      id: string;
      name: string;
      role: AgentRoleType;
      title: string;
      description: string;
      color: string;
      icon: string;
    }> = [
      {
        id: 'agent-architect',
        name: 'Architect Agent',
        role: 'ARCHITECT',
        title: 'System & Decomposition Architect',
        description: 'Analyzes project architecture, decomposes requirements into DAG tasks, identifies risk boundaries.',
        color: 'border-cyan-500/40 text-cyan-300 bg-cyan-950/30',
        icon: 'layers'
      },
      {
        id: 'agent-researcher',
        name: 'Researcher Agent',
        role: 'RESEARCHER',
        title: 'Code & Dependency Investigator',
        description: 'Investigates existing implementations, dependencies, call paths, and relevant test coverage without mutating files.',
        color: 'border-blue-500/40 text-blue-300 bg-blue-950/30',
        icon: 'search'
      },
      {
        id: 'agent-coder',
        name: 'Coder Agent',
        role: 'CODER',
        title: 'Safe Edit Implementer',
        description: 'Implements approved changes using Phase 2 ContextPacks and Phase 3 Safe Edit Engine with atomic rollback protection.',
        color: 'border-indigo-500/40 text-indigo-300 bg-indigo-950/30',
        icon: 'code'
      },
      {
        id: 'agent-debugger',
        name: 'Debugger Agent',
        role: 'DEBUGGER',
        title: 'Self-Healing Diagnostic Agent',
        description: 'Coordinates with Phase 5 Self-Healing Engine to normalize failures, pinpoint root causes, and propose bounded repairs.',
        color: 'border-rose-500/40 text-rose-300 bg-rose-950/30',
        icon: 'wrench'
      },
      {
        id: 'agent-tester',
        name: 'Tester Agent',
        role: 'TESTER',
        title: 'Test & Coverage Inspector',
        description: 'Identifies unit and integration test suites, runs test validation, and ensures non-regression.',
        color: 'border-amber-500/40 text-amber-300 bg-amber-950/30',
        icon: 'test-tube'
      },
      {
        id: 'agent-ui-ux',
        name: 'UI/UX Visual QA Agent',
        role: 'UI_UX',
        title: 'Visual QA & Responsive Inspector',
        description: 'Performs multi-viewport DOM, typography, color contrast, and layout audits (390px, 768px, 1280px).',
        color: 'border-pink-500/40 text-pink-300 bg-pink-950/30',
        icon: 'eye'
      },
      {
        id: 'agent-security',
        name: 'Security Reviewer Agent',
        role: 'SECURITY',
        title: 'Security & Secret Auditor',
        description: 'Audits code against credential leaks, unsafe eval, unescaped inputs, and iframe escape vulnerabilities.',
        color: 'border-red-500/40 text-red-300 bg-red-950/30',
        icon: 'lock'
      },
      {
        id: 'agent-reviewer',
        name: 'Reviewer Agent',
        role: 'REVIEWER',
        title: 'Independent Code & Diff Reviewer',
        description: 'Inspects proposed diffs independently from the Coder, detecting architectural violations and regressions.',
        color: 'border-purple-500/40 text-purple-300 bg-purple-950/30',
        icon: 'shield-alert'
      },
      {
        id: 'agent-verifier',
        name: 'Verifier Agent',
        role: 'VERIFIER',
        title: 'Evidence-Grounded Verifier',
        description: 'Inspects compiler outputs, test execution evidence, and objective criteria to produce final verification reports.',
        color: 'border-emerald-500/40 text-emerald-300 bg-emerald-950/30',
        icon: 'check-circle'
      }
    ];

    definitions.forEach(def => {
      const capabilities = AgentPolicyEngine.getCapabilitiesForRole(def.role);
      this.agents.set(def.id, {
        id: def.id,
        name: def.name,
        role: def.role,
        title: def.title,
        description: def.description,
        capabilities,
        status: 'IDLE',
        assignedFileLocks: [],
        lastActiveTime: Date.now(),
        color: def.color,
        icon: def.icon,
        model: 'gemini-3.7-flash'
      });
    });
  }

  public getAgent(id: string): AgentDefinition | undefined {
    return this.agents.get(id);
  }

  public getAgentByRole(role: AgentRoleType): AgentDefinition | undefined {
    return Array.from(this.agents.values()).find(a => a.role === role);
  }

  public getAllAgents(): AgentDefinition[] {
    return Array.from(this.agents.values());
  }

  public updateStatus(id: string, status: AgentStatusType, currentTaskId?: string): void {
    const agent = this.agents.get(id);
    if (!agent) return;

    agent.status = status;
    agent.currentTaskId = currentTaskId;
    agent.lastActiveTime = Date.now();
    if (status === 'RUNNING' && !agent.startTime) {
      agent.startTime = Date.now();
    }
  }

  public assignLock(agentId: string, resourceId: string): void {
    const agent = this.agents.get(agentId);
    if (agent && !agent.assignedFileLocks.includes(resourceId)) {
      agent.assignedFileLocks.push(resourceId);
    }
  }

  public releaseLocks(agentId: string): void {
    const agent = this.agents.get(agentId);
    if (agent) {
      agent.assignedFileLocks = [];
    }
  }
}
