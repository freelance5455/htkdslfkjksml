/**
 * GODEX Phase 6 - Task Graph & DAG Engine
 * Implements cycle-safe Directed Acyclic Graph scheduling, dependency resolution,
 * and topological sequencing for multi-agent task execution.
 */

import { OrchestrationTask, TaskGraph, TaskGraphNode, TaskDependency } from './orchestrationTypes';

export class TaskGraphEngine {
  /**
   * Builds and validates a TaskGraph from a list of tasks.
   * Runs cycle detection before returning.
   */
  public static createGraph(tasks: OrchestrationTask[]): TaskGraph {
    const nodes: Record<string, TaskGraphNode> = {};
    const taskMap = new Map<string, OrchestrationTask>();

    tasks.forEach(t => {
      taskMap.set(t.id, t);
      nodes[t.id] = {
        task: t,
        children: [],
        parents: []
      };
    });

    // Populate children and parents
    tasks.forEach(t => {
      t.dependencies.forEach(dep => {
        if (nodes[dep.taskId]) {
          nodes[dep.taskId].children.push(t.id);
          nodes[t.id].parents.push(dep.taskId);
        }
      });
    });

    const isCyclic = this.hasCycle(nodes);
    const rootTaskIds = Object.keys(nodes).filter(id => nodes[id].parents.length === 0);
    const leafTaskIds = Object.keys(nodes).filter(id => nodes[id].children.length === 0);

    return {
      nodes,
      rootTaskIds,
      leafTaskIds,
      totalTasks: tasks.length,
      completedTasks: tasks.filter(t => t.status === 'COMPLETED').length,
      isCyclic
    };
  }

  /**
   * Cycle Detection using 3-color DFS (WHITE=0, GREY=1, BLACK=2)
   */
  public static hasCycle(nodes: Record<string, TaskGraphNode>): boolean {
    const visited: Record<string, number> = {}; // 0 = unvisited, 1 = visiting, 2 = visited

    const dfs = (taskId: string): boolean => {
      visited[taskId] = 1; // Mark as currently visiting (in recursion stack)

      const children = nodes[taskId]?.children || [];
      for (const childId of children) {
        if (visited[childId] === 1) {
          // Cycle found: back-edge to an active ancestor
          return true;
        }
        if (!visited[childId] && dfs(childId)) {
          return true;
        }
      }

      visited[taskId] = 2; // Mark as completely visited
      return false;
    };

    for (const taskId of Object.keys(nodes)) {
      if (!visited[taskId]) {
        if (dfs(taskId)) return true;
      }
    }

    return false;
  }

  /**
   * Returns all tasks that are currently READY to run
   * (Status is QUEUED or READY, and all parent dependencies are COMPLETED)
   */
  public static getReadyTasks(graph: TaskGraph): OrchestrationTask[] {
    if (graph.isCyclic) return [];

    const ready: OrchestrationTask[] = [];

    for (const node of Object.values(graph.nodes)) {
      const task = node.task;
      if (task.status === 'QUEUED' || task.status === 'READY') {
        // Check if all parent dependencies are fulfilled
        const allParentsSatisfied = node.parents.every(parentId => {
          const parentNode = graph.nodes[parentId];
          if (!parentNode) return false;
          return parentNode.task.status === 'COMPLETED';
        });

        if (allParentsSatisfied) {
          ready.push(task);
        }
      }
    }

    // Sort by priority (CRITICAL > HIGH > NORMAL > LOW)
    const priorityWeights: Record<string, number> = {
      CRITICAL: 4,
      HIGH: 3,
      NORMAL: 2,
      LOW: 1
    };

    return ready.sort((a, b) => priorityWeights[b.priority] - priorityWeights[a.priority]);
  }

  /**
   * Topological sort of tasks in execution sequence order
   */
  public static getTopologicalOrder(graph: TaskGraph): string[] {
    if (graph.isCyclic) return [];

    const inDegree: Record<string, number> = {};
    const queue: string[] = [];
    const order: string[] = [];

    Object.keys(graph.nodes).forEach(id => {
      inDegree[id] = graph.nodes[id].parents.length;
      if (inDegree[id] === 0) {
        queue.push(id);
      }
    });

    while (queue.length > 0) {
      const currentId = queue.shift()!;
      order.push(currentId);

      const children = graph.nodes[currentId]?.children || [];
      for (const childId of children) {
        inDegree[childId]--;
        if (inDegree[childId] === 0) {
          queue.push(childId);
        }
      }
    }

    return order;
  }

  /**
   * Updates task status in graph and recalculates completed tasks count
   */
  public static updateTaskStatus(
    graph: TaskGraph,
    taskId: string,
    status: OrchestrationTask['status'],
    message?: string
  ): TaskGraph {
    if (!graph.nodes[taskId]) return graph;

    graph.nodes[taskId].task.status = status;
    if (message) {
      graph.nodes[taskId].task.statusMessage = message;
    }

    if (status === 'RUNNING' && !graph.nodes[taskId].task.startedAt) {
      graph.nodes[taskId].task.startedAt = Date.now();
    }
    if (status === 'COMPLETED' || status === 'FAILED' || status === 'CANCELLED') {
      graph.nodes[taskId].task.completedAt = Date.now();
    }

    graph.completedTasks = Object.values(graph.nodes).filter(
      n => n.task.status === 'COMPLETED'
    ).length;

    return graph;
  }
}
