/**
 * GODEX Phase 6 - Artifact Registry
 * Immutable registry for structured artifacts produced across multi-agent workflows.
 * Agents communicate through verifiable artifacts rather than unstructured chat.
 */

import { AgentArtifact, ArtifactType, AgentRoleType } from './orchestrationTypes';

export class ArtifactRegistry {
  private artifacts: Map<string, AgentArtifact> = new Map();

  /**
   * Registers a new artifact with immutable storage
   */
  public registerArtifact(artifact: Omit<AgentArtifact, 'id' | 'timestamp'> & { id?: string }): AgentArtifact {
    const id = artifact.id || `art-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const fullArtifact: AgentArtifact = {
      ...artifact,
      id,
      timestamp: Date.now()
    };

    this.artifacts.set(id, fullArtifact);
    return fullArtifact;
  }

  public getArtifact(id: string): AgentArtifact | undefined {
    return this.artifacts.get(id);
  }

  public getArtifactsByTask(taskId: string): AgentArtifact[] {
    return Array.from(this.artifacts.values()).filter(a => a.taskId === taskId);
  }

  public getArtifactsByType(type: ArtifactType): AgentArtifact[] {
    return Array.from(this.artifacts.values()).filter(a => a.type === type);
  }

  public getArtifactsByRole(role: AgentRoleType): AgentArtifact[] {
    return Array.from(this.artifacts.values()).filter(a => a.createdBy === role);
  }

  public getAllArtifacts(): AgentArtifact[] {
    return Array.from(this.artifacts.values()).sort((a, b) => b.timestamp - a.timestamp);
  }

  public updateStatus(id: string, status: AgentArtifact['status']): void {
    const art = this.artifacts.get(id);
    if (art) {
      art.status = status;
    }
  }

  public clear(): void {
    this.artifacts.clear();
  }
}
