/**
 * GODEX Phase 6 - Task Scheduler
 * Schedules DAG tasks with bounded concurrency, priority queueing,
 * agent availability checking, retry limits, and human approval pauses.
 */

import {
  OrchestrationTask,
  TaskGraph,
  AgentDefinition,
  OrchestrationSession
} from './orchestrationTypes';
import { TaskGraphEngine } from './taskGraph';
import { AgentRegistry } from './agentRegistry';
import { AgentRuntime } from './agentRuntime';
import { OrchestrationTelemetry } from './orchestrationTelemetry';
import { AgentMessageBus } from './agentMessageBus';

export class TaskScheduler {
  private maxConcurrency: number = 4;
  private isRunning: boolean = false;

  constructor(
    private agentRegistry: AgentRegistry,
    private agentRuntime: AgentRuntime,
    private messageBus: AgentMessageBus
  ) {}

  public setMaxConcurrency(limit: number): void {
    this.maxConcurrency = Math.max(1, limit);
  }

  public getMaxConcurrency(): number {
    return this.maxConcurrency;
  }

  /**
   * Executes the next batch of ready tasks in the graph adhering to concurrency limits.
   */
  public async scheduleNext(
    session: OrchestrationSession,
    projectFiles: Record<string, string>,
    onFileMutated?: (files: Record<string, string>) => void
  ): Promise<{ executedCount: number; hasBlocked: boolean }> {
    if (this.isRunning) return { executedCount: 0, hasBlocked: false };
    this.isRunning = true;

    try {
      // 1. Check currently active agents
      const runningAgents = this.agentRegistry.getAllAgents().filter(a => a.status === 'RUNNING');
      const availableSlots = Math.max(0, this.maxConcurrency - runningAgents.length);

      if (availableSlots <= 0) {
        return { executedCount: 0, hasBlocked: false };
      }

      // 2. Find READY tasks from DAG
      const readyTasks = TaskGraphEngine.getReadyTasks(session.taskGraph);
      if (readyTasks.length === 0) {
        return { executedCount: 0, hasBlocked: false };
      }

      let executedCount = 0;
      let hasBlocked = false;

      // 3. Process ready tasks up to availableSlots
      for (const task of readyTasks.slice(0, availableSlots)) {
        // Find suitable agent for task role
        const agent = this.agentRegistry.getAgentByRole(task.role);
        if (!agent || agent.status === 'RUNNING') {
          // Agent currently busy
          continue;
        }

        // Check if task needs human approval
        if (task.approvalRequired && !task.approved) {
          hasBlocked = true;
          session.status = 'AWAITING_APPROVAL';
          OrchestrationTelemetry.emit('APPROVAL_REQUIRED', task.role, `Task '${task.title}' awaiting human approval`, task.approvalReason, 'warning');
          continue;
        }

        // Assign task to agent
        task.assignedAgentId = agent.id;
        task.status = 'RUNNING';
        task.startedAt = Date.now();
        this.agentRegistry.updateStatus(agent.id, 'RUNNING', task.id);

        this.messageBus.publish({
          type: 'TASK_ASSIGNED',
          senderRole: 'ORCHESTRATOR',
          recipientRole: agent.role,
          taskId: task.id,
          summary: `Assigned task '${task.title}' to ${agent.name}`
        });

        // Execute task via governed AgentRuntime
        const execResult = await this.agentRuntime.executeTask(
          task,
          agent,
          projectFiles,
          session.userObjective,
          onFileMutated
        );

        if (execResult.approvalRequired) {
          task.status = 'BLOCKED';
          session.status = 'AWAITING_APPROVAL';
          this.agentRegistry.updateStatus(agent.id, 'BLOCKED', task.id);
          hasBlocked = true;
        } else if (execResult.success) {
          task.status = 'COMPLETED';
          task.completedAt = Date.now();
          task.statusMessage = execResult.statusMessage;
          this.agentRegistry.updateStatus(agent.id, 'COMPLETED');
          executedCount++;

          this.messageBus.publish({
            type: 'TASK_COMPLETED',
            senderRole: agent.role,
            recipientRole: 'ORCHESTRATOR',
            taskId: task.id,
            summary: `Task '${task.title}' completed successfully`
          });

          OrchestrationTelemetry.emit('TASK_UNBLOCKED', agent.role, `Task '${task.title}' completed`, undefined, 'success');
        } else {
          // Failure handling with bounded retries
          task.attemptCount++;
          if (task.attemptCount < task.maxRetries) {
            task.status = 'READY'; // Retry
            task.statusMessage = `Attempt ${task.attemptCount} failed: ${execResult.error}. Retrying...`;
            this.agentRegistry.updateStatus(agent.id, 'AVAILABLE');
            OrchestrationTelemetry.emit('AGENT_FAILED', agent.role, `Task '${task.title}' failed attempt ${task.attemptCount}, retrying`, execResult.error, 'warning');
          } else {
            task.status = 'FAILED';
            task.statusMessage = `Task failed after ${task.attemptCount} attempts: ${execResult.error}`;
            task.completedAt = Date.now();
            this.agentRegistry.updateStatus(agent.id, 'FAILED');
            OrchestrationTelemetry.emit('AGENT_FAILED', agent.role, `Task '${task.title}' permanently failed`, execResult.error, 'error');
          }
        }

        // Update task graph node
        TaskGraphEngine.updateTaskStatus(session.taskGraph, task.id, task.status, task.statusMessage);
      }

      return { executedCount, hasBlocked };
    } finally {
      this.isRunning = false;
    }
  }
}
