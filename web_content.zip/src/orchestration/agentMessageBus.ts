/**
 * GODEX Phase 6 - Agent Message Bus
 * Structured message bus for routing lifecycle events, artifact notifications,
 * reviews, conflict notices, and debugger handoffs across specialized agents.
 */

import { AgentMessage, MessageType, AgentRoleType } from './orchestrationTypes';

export type MessageHandler = (message: AgentMessage) => void;

export class AgentMessageBus {
  private messages: AgentMessage[] = [];
  private subscribers: Map<string, MessageHandler[]> = new Map();
  private globalSubscribers: MessageHandler[] = [];

  /**
   * Publish a structured agent message
   */
  public publish(msg: Omit<AgentMessage, 'id' | 'timestamp'> & { id?: string }): AgentMessage {
    const fullMessage: AgentMessage = {
      ...msg,
      id: msg.id || `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now()
    };

    this.messages.push(fullMessage);

    // Notify specific type subscribers
    const handlers = this.subscribers.get(fullMessage.type) || [];
    handlers.forEach(h => {
      try {
        h(fullMessage);
      } catch (err) {
        console.error('[AgentMessageBus] Handler error:', err);
      }
    });

    // Notify global subscribers
    this.globalSubscribers.forEach(h => {
      try {
        h(fullMessage);
      } catch (err) {
        console.error('[AgentMessageBus] Global handler error:', err);
      }
    });

    return fullMessage;
  }

  /**
   * Subscribe to specific message types
   */
  public subscribe(type: MessageType, handler: MessageHandler): () => void {
    if (!this.subscribers.has(type)) {
      this.subscribers.set(type, []);
    }
    this.subscribers.get(type)!.push(handler);

    return () => {
      const list = this.subscribers.get(type);
      if (list) {
        this.subscribers.set(type, list.filter(h => h !== handler));
      }
    };
  }

  /**
   * Subscribe to all messages
   */
  public subscribeAll(handler: MessageHandler): () => void {
    this.globalSubscribers.push(handler);
    return () => {
      this.globalSubscribers = this.globalSubscribers.filter(h => h !== handler);
    };
  }

  public getHistory(): AgentMessage[] {
    return [...this.messages];
  }

  public clear(): void {
    this.messages = [];
  }
}
