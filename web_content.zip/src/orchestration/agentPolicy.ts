/**
 * GODEX Phase 6 - Agent Policy & Security Boundary Enforcement
 * Evaluates capability permissions, role boundaries, sensitive target files,
 * and risk levels to return ALLOWED, REVIEW_REQUIRED, or BLOCKED decisions.
 */

import {
  AgentRoleType,
  AgentCapabilityType,
  RiskLevel,
  PolicyDecision
} from './orchestrationTypes';

export interface PolicyEvaluationRequest {
  agentRole: AgentRoleType;
  requestedCapability: AgentCapabilityType;
  targetFiles?: string[];
  operationType: 'READ' | 'MUTATION' | 'EXECUTION' | 'REVIEW' | 'VERIFY';
  risk?: RiskLevel;
}

export interface PolicyEvaluationResult {
  decision: PolicyDecision;
  reason: string;
  allowedCapabilities: AgentCapabilityType[];
  isSecuritySensitive: boolean;
}

export class AgentPolicyEngine {
  private static readonly ROLE_CAPABILITIES: Record<AgentRoleType, AgentCapabilityType[]> = {
    ARCHITECT: [
      'READ_PROJECT',
      'SEARCH_SYMBOLS',
      'READ_ARCHITECTURE',
      'CREATE_PLAN'
    ],
    RESEARCHER: [
      'READ_PROJECT',
      'SEARCH_SYMBOLS',
      'ANALYZE_DEPENDENCIES'
    ],
    CODER: [
      'READ_PROJECT',
      'CREATE_PATCH',
      'APPLY_PATCH',
      'RUN_VALIDATION'
    ],
    DEBUGGER: [
      'READ_PROJECT',
      'ANALYZE_FAILURE',
      'CREATE_REPAIR',
      'APPLY_REPAIR',
      'RUN_VALIDATION'
    ],
    TESTER: [
      'READ_PROJECT',
      'RUN_TESTS',
      'ANALYZE_TEST_FAILURE'
    ],
    UI_UX: [
      'READ_PROJECT',
      'RUN_VALIDATION',
      'REVIEW_DIFF'
    ],
    SECURITY: [
      'READ_PROJECT',
      'SEARCH_SYMBOLS',
      'REVIEW_DIFF',
      'ANALYZE_ARCHITECTURE'
    ],
    REVIEWER: [
      'READ_PROJECT',
      'REVIEW_DIFF',
      'ANALYZE_ARCHITECTURE'
    ],
    VERIFIER: [
      'READ_PROJECT',
      'RUN_VALIDATION',
      'VERIFY_EVIDENCE'
    ]
  };

  private static readonly SENSITIVE_PATTERNS = [
    /\.env/i,
    /secret/i,
    /credential/i,
    /jwt/i,
    /auth\//i,
    /security/i,
    /package\.json$/i,
    /tsconfig\.json$/i,
    /firestore\.rules$/i,
    /schema\.sql$/i,
    /\.drizzle/i
  ];

  /**
   * Evaluates whether an agent is authorized to perform a specific action.
   */
  public static evaluate(request: PolicyEvaluationRequest): PolicyEvaluationResult {
    const allowedCaps = this.ROLE_CAPABILITIES[request.agentRole] || [];

    // 1. Check if the capability belongs to the role
    if (!allowedCaps.includes(request.requestedCapability)) {
      return {
        decision: 'BLOCKED',
        reason: `Agent role '${request.agentRole}' does not hold capability '${request.requestedCapability}'.`,
        allowedCapabilities: allowedCaps,
        isSecuritySensitive: false
      };
    }

    // 2. Check if a non-mutating agent tries to mutate files
    if (request.operationType === 'MUTATION' && request.agentRole !== 'CODER' && request.agentRole !== 'DEBUGGER') {
      return {
        decision: 'BLOCKED',
        reason: `Agent role '${request.agentRole}' is strictly forbidden from direct file mutations.`,
        allowedCapabilities: allowedCaps,
        isSecuritySensitive: false
      };
    }

    // 3. Inspect target files for security-sensitive paths
    let isSecuritySensitive = false;
    if (request.targetFiles && request.targetFiles.length > 0) {
      isSecuritySensitive = request.targetFiles.some(file =>
        this.SENSITIVE_PATTERNS.some(pat => pat.test(file))
      );
    }

    // 4. Check risk level and sensitive paths for human approval requirement
    if (isSecuritySensitive || request.risk === 'CRITICAL' || request.risk === 'HIGH') {
      if (request.operationType === 'MUTATION') {
        return {
          decision: 'REVIEW_REQUIRED',
          reason: `Operation modifies security-sensitive files or carries ${request.risk || 'HIGH'} risk. Human review required.`,
          allowedCapabilities: allowedCaps,
          isSecuritySensitive: true
        };
      }
    }

    return {
      decision: 'ALLOWED',
      reason: `Operation permitted under ${request.agentRole} standard capability profile.`,
      allowedCapabilities: allowedCaps,
      isSecuritySensitive
    };
  }

  /**
   * Get configured capabilities for a role
   */
  public static getCapabilitiesForRole(role: AgentRoleType): AgentCapabilityType[] {
    return this.ROLE_CAPABILITIES[role] || [];
  }
}
