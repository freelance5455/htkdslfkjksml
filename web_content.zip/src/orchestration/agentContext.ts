/**
 * GODEX Phase 6 - Agent Scoped Context Builder
 * Reuses Phase 2 ContextPack infrastructure to build scoped, grounded context
 * for individual tasks without sending the entire repository.
 */

import { ContextPack, ContextBudgetConfig } from '../intelligence/contextTypes';
import { ContextPackBuilder } from '../intelligence/contextPackBuilder';
import { IntentClassifier } from '../intelligence/intentClassifier';
import { TaskExtractor } from '../intelligence/taskExtractor';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';
import { ContextCache } from '../intelligence/contextCache';
import { DEFAULT_CONTEXT_BUDGET } from '../intelligence/contextBudget';
import { OrchestrationTask } from './orchestrationTypes';

export class AgentContextEngine {
  /**
   * Builds a scoped ContextPack for an individual orchestration task.
   */
  public static async buildScopedContext(
    task: OrchestrationTask,
    projectFiles: Record<string, string>,
    userObjective: string,
    previousArtifactSummaries: string[] = []
  ): Promise<ContextPack> {
    const objectiveQuery = `${task.title} ${task.description} ${task.targetFiles.join(' ')} ${userObjective}`;

    // 1. Check cache first
    const cacheKey = `task-${task.id}-${task.targetFiles.sort().join(',')}-${objectiveQuery.length}`;
    const cached = ContextCache.getContextPack(cacheKey);
    if (cached) {
      return cached;
    }

    // 2. Classify intent & extract task representation
    const intelState = ProjectIntelligence.getState();
    const classification = IntentClassifier.classify(objectiveQuery);
    const allFilePaths = Object.keys(projectFiles);
    const allSymbols = Object.values(intelState.files).flatMap(f => f.symbols?.map(s => s.name) || []);
    const taskExtraction = TaskExtractor.extract(objectiveQuery, allFilePaths, allSymbols);

    // 3. Configure focused budget
    const budgetConfig: ContextBudgetConfig = {
      ...DEFAULT_CONTEXT_BUDGET,
      maxTokens: task.role === 'CODER' ? 8000 : 6000,
      maxFiles: task.role === 'CODER' ? 4 : 6
    };

    // 4. Assemble Grounded Context Pack via Phase 2
    const contextPack = ContextPackBuilder.build(
      objectiveQuery,
      classification.intent,
      taskExtraction,
      intelState,
      projectFiles,
      budgetConfig,
      task.targetFiles
    );

    // 5. Inject previous artifact summaries into context metadata
    if (previousArtifactSummaries.length > 0) {
      (contextPack as any).previousEvidence = previousArtifactSummaries.join('\n---\n');
    }

    // 6. Cache and return
    ContextCache.setContextPack(cacheKey, contextPack);

    return contextPack;
  }
}
