/**
 * GODEX Phase 6 - Conflict Manager & Resource Locker
 * Prevents simultaneous conflicting mutations, enforces resource locks,
 * detects stale fingerprints, and safely arbitrates multi-agent access.
 */

import {
  ResourceLock,
  AgentConflict,
  AgentRoleType
} from './orchestrationTypes';

export class ConflictManager {
  private static instance: ConflictManager | null = null;
  private activeLocks: Map<string, ResourceLock> = new Map(); // resourceId (file path / symbol) -> ResourceLock
  private conflicts: AgentConflict[] = [];

  public static getInstance(): ConflictManager {
    if (!this.instance) {
      this.instance = new ConflictManager();
    }
    return this.instance;
  }

  /**
   * Attempts to acquire exclusive mutation lock on a file or symbol
   */
  public acquireLock(
    resourceId: string,
    type: 'FILE' | 'SYMBOL',
    taskId: string,
    agentId: string,
    agentRole: AgentRoleType,
    currentFingerprint: string
  ): { success: boolean; conflict?: AgentConflict } {
    const existingLock = this.activeLocks.get(resourceId);

    // If locked by another active task, conflict detected!
    if (existingLock && existingLock.ownedByTaskId !== taskId) {
      const conflict: AgentConflict = {
        id: `conf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        type: type === 'FILE' ? 'FILE_MUTATION' : 'SYMBOL_OVERLAP',
        resourceId,
        conflictingTaskIds: [existingLock.ownedByTaskId, taskId],
        conflictingAgentRoles: [agentRole],
        description: `Resource '${resourceId}' is already locked by Task '${existingLock.ownedByTaskId}'. Simultaneous mutation blocked.`,
        detectedAt: Date.now(),
        resolution: 'WAIT',
        resolved: false
      };

      this.conflicts.push(conflict);
      return { success: false, conflict };
    }

    // Acquire lock
    const lock: ResourceLock = {
      resourceId,
      type,
      ownedByTaskId: taskId,
      ownedByAgentId: agentId,
      acquiredAt: Date.now(),
      fingerprintAtLock: currentFingerprint
    };

    this.activeLocks.set(resourceId, lock);
    return { success: true };
  }

  /**
   * Release lock upon task completion or cancellation
   */
  public releaseLock(resourceId: string, taskId: string): boolean {
    const lock = this.activeLocks.get(resourceId);
    if (lock && lock.ownedByTaskId === taskId) {
      this.activeLocks.delete(resourceId);
      return true;
    }
    return false;
  }

  /**
   * Release all locks for a task
   */
  public releaseAllForTask(taskId: string): void {
    for (const [resId, lock] of Array.from(this.activeLocks.entries())) {
      if (lock.ownedByTaskId === taskId) {
        this.activeLocks.delete(resId);
      }
    }
  }

  /**
   * Verifies if two task sets of target files are completely disjoint (safe for parallel coding)
   */
  public static areFileSetsDisjoint(setA: string[], setB: string[]): boolean {
    const a = new Set(setA);
    for (const file of setB) {
      if (a.has(file)) return false;
    }
    return true;
  }

  /**
   * Verifies that the file fingerprint has not changed since context pack creation
   */
  public verifyFingerprint(
    resourceId: string,
    currentActualFingerprint: string
  ): { valid: boolean; conflict?: AgentConflict } {
    const lock = this.activeLocks.get(resourceId);
    if (lock && lock.fingerprintAtLock !== currentActualFingerprint) {
      const conflict: AgentConflict = {
        id: `conf-stale-${Date.now()}`,
        type: 'STALE_FINGERPRINT',
        resourceId,
        conflictingTaskIds: [lock.ownedByTaskId],
        conflictingAgentRoles: [],
        description: `File '${resourceId}' content has mutated externally since context was captured. Stale edit blocked.`,
        detectedAt: Date.now(),
        resolution: 'SERIALIZE',
        resolved: false
      };

      this.conflicts.push(conflict);
      return { valid: false, conflict };
    }

    return { valid: true };
  }

  public getActiveLocks(): ResourceLock[] {
    return Array.from(this.activeLocks.values());
  }

  public getConflicts(): AgentConflict[] {
    return [...this.conflicts];
  }

  public resolveConflict(conflictId: string, resolution: AgentConflict['resolution']): void {
    const conf = this.conflicts.find(c => c.id === conflictId);
    if (conf) {
      conf.resolution = resolution;
      conf.resolved = true;
    }
  }

  public clear(): void {
    this.activeLocks.clear();
    this.conflicts = [];
  }

  /**
   * P4.0 convenience mutex methods for media engine slots
   */
  public requestResourceLock(resourceId: string, taskId: string): boolean {
    const res = this.acquireLock(resourceId, 'FILE', taskId, taskId, 'ARCHITECT', 'lock-fingerprint');
    return res.success;
  }

  public releaseResourceLock(resourceId: string, taskId: string): boolean {
    return this.releaseLock(resourceId, taskId);
  }
}
