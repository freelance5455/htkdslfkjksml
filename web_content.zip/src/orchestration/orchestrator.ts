/**
 * GODEX Phase 6 - Central Multi-Agent Orchestrator
 * The engineering control plane orchestrator that receives objectives,
 * constructs DAG task graphs, dispatches specialized agents, enforces safety policies,
 * detects conflicts, and coordinates evidence-grounded verification.
 */

import {
  OrchestrationSession,
  OrchestrationTask,
  TaskGraph,
  AgentDefinition,
  AgentArtifact,
  AgentConflict,
  AgentMessage,
  VerificationCoordinatorReport
} from './orchestrationTypes';
import { TaskGraphEngine } from './taskGraph';
import { AgentRegistry } from './agentRegistry';
import { ArtifactRegistry } from './artifactRegistry';
import { AgentMessageBus } from './agentMessageBus';
import { ConflictManager } from './conflictManager';
import { AgentRuntime } from './agentRuntime';
import { TaskScheduler } from './taskScheduler';
import { VerificationCoordinator } from './verificationCoordinator';
import { OrchestrationTelemetry } from './orchestrationTelemetry';
import { ProjectDetector } from '../intelligence/projectDetector';

export type OrchestrationSessionListener = (session: OrchestrationSession) => void;

export class GodexOrchestrator {
  private static instance: GodexOrchestrator | null = null;

  public agentRegistry: AgentRegistry;
  public artifactRegistry: ArtifactRegistry;
  public messageBus: AgentMessageBus;
  public conflictManager: ConflictManager;
  public agentRuntime: AgentRuntime;
  public scheduler: TaskScheduler;

  private currentSession: OrchestrationSession | null = null;
  private listeners: OrchestrationSessionListener[] = [];

  private constructor() {
    this.agentRegistry = new AgentRegistry();
    this.artifactRegistry = new ArtifactRegistry();
    this.messageBus = new AgentMessageBus();
    this.conflictManager = new ConflictManager();
    this.agentRuntime = new AgentRuntime(this.artifactRegistry, this.conflictManager);
    this.scheduler = new TaskScheduler(this.agentRegistry, this.agentRuntime, this.messageBus);
  }

  public static getInstance(): GodexOrchestrator {
    if (!GodexOrchestrator.instance) {
      GodexOrchestrator.instance = new GodexOrchestrator();
    }
    return GodexOrchestrator.instance;
  }

  public subscribe(listener: OrchestrationSessionListener): () => void {
    this.listeners.push(listener);
    if (this.currentSession) {
      listener(this.currentSession);
    }
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(): void {
    if (!this.currentSession) return;
    this.listeners.forEach(l => {
      try {
        l(this.currentSession!);
      } catch (err) {
        console.error('[GodexOrchestrator] Listener error:', err);
      }
    });
  }

  public getActiveSession(): OrchestrationSession | null {
    return this.currentSession;
  }

  /**
   * Initializes and starts a multi-agent orchestration session for a user objective.
   */
  public async startSession(
    userObjective: string,
    projectFiles: Record<string, string>,
    onFileMutated?: (files: Record<string, string>) => void
  ): Promise<OrchestrationSession> {
    const sessionId = `orch-session-${Date.now()}`;
    OrchestrationTelemetry.emit('ORCHESTRATION_STARTED', 'ORCHESTRATOR', `Orchestrating objective: '${userObjective}'`, undefined, 'pending');

    // 1. Reset state
    this.artifactRegistry.clear();
    this.conflictManager.clear();
    this.agentRegistry.initializeDefaultAgents();

    // 2. Classify architecture to identify target files
    const metadata = ProjectDetector.analyzeProjectMetadata(projectFiles);
    const candidateFiles = Object.keys(projectFiles).filter(
      f => !f.includes('node_modules') && !f.endsWith('.lock') && (f.endsWith('.ts') || f.endsWith('.tsx') || f.endsWith('.json'))
    );

    // 3. Decompose Objective into standard DAG Tasks
    const isSecuritySensitive = /auth|password|token|secret|credential|database|permission/i.test(userObjective);
    const risk = isSecuritySensitive ? 'HIGH' : 'NORMAL';

    const tasks: OrchestrationTask[] = [
      {
        id: 'task-1-architect',
        title: 'Architect System Strategy',
        description: `Formulate architectural plan for objective: ${userObjective}`,
        role: 'ARCHITECT',
        priority: 'CRITICAL',
        risk: 'LOW',
        status: 'READY',
        dependencies: [],
        targetFiles: candidateFiles.slice(0, 3),
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        createdAt: Date.now()
      },
      {
        id: 'task-2-research',
        title: 'Investigate Symbols & Call Graphs',
        description: 'Examine existing symbols, types, and dependencies',
        role: 'RESEARCHER',
        priority: 'HIGH',
        risk: 'LOW',
        status: 'READY',
        dependencies: [], // Can run in parallel with Architect
        targetFiles: candidateFiles.slice(0, 5),
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        createdAt: Date.now()
      },
      {
        id: 'task-3-coder',
        title: 'Implement Safe Mutations',
        description: `Implement required changes for: ${userObjective}`,
        role: 'CODER',
        priority: 'CRITICAL',
        risk: risk as any,
        status: 'QUEUED',
        dependencies: [
          { taskId: 'task-1-architect', type: 'HARD' },
          { taskId: 'task-2-research', type: 'HARD' }
        ],
        targetFiles: candidateFiles.slice(0, 2),
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        approvalRequired: isSecuritySensitive,
        approvalReason: isSecuritySensitive ? 'Security-sensitive objective requires explicit developer review' : undefined,
        createdAt: Date.now()
      },
      {
        id: 'task-4-tester',
        title: 'Execute Test & Discovery Validation',
        description: 'Run test verification and detect potential breakage',
        role: 'TESTER',
        priority: 'HIGH',
        risk: 'LOW',
        status: 'QUEUED',
        dependencies: [{ taskId: 'task-3-coder', type: 'HARD' }],
        targetFiles: candidateFiles.filter(f => f.includes('test') || f.includes('spec')),
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        createdAt: Date.now()
      },
      {
        id: 'task-5-reviewer',
        title: 'Independent Code & Security Review',
        description: 'Review proposed diffs independently before verification',
        role: 'REVIEWER',
        priority: 'HIGH',
        risk: 'LOW',
        status: 'QUEUED',
        dependencies: [
          { taskId: 'task-3-coder', type: 'HARD' },
          { taskId: 'task-4-tester', type: 'HARD' }
        ],
        targetFiles: candidateFiles.slice(0, 2),
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        createdAt: Date.now()
      },
      {
        id: 'task-6-verifier',
        title: 'Final Evidence-Grounded Verification',
        description: 'Aggregate execution results, test assertions, and reviews',
        role: 'VERIFIER',
        priority: 'CRITICAL',
        risk: 'LOW',
        status: 'QUEUED',
        dependencies: [{ taskId: 'task-5-reviewer', type: 'HARD' }],
        targetFiles: [],
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        createdAt: Date.now()
      }
    ];

    // Build TaskGraph with cycle verification
    const taskGraph = TaskGraphEngine.createGraph(tasks);

    const activeAgentsMap: Record<string, AgentDefinition> = {};
    this.agentRegistry.getAllAgents().forEach(a => {
      activeAgentsMap[a.id] = a;
    });

    this.currentSession = {
      id: sessionId,
      userObjective,
      status: 'EXECUTING',
      taskGraph,
      activeAgents: activeAgentsMap,
      artifacts: {},
      conflicts: [],
      messages: [],
      maxConcurrentAgents: this.scheduler.getMaxConcurrency(),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    this.notifyListeners();

    // 4. Run Execution Loop until all tasks finish or an approval is required
    await this.runExecutionLoop(projectFiles, onFileMutated);

    return this.currentSession;
  }

  /**
   * Continuous scheduler execution loop
   */
  public async runExecutionLoop(
    projectFiles: Record<string, string>,
    onFileMutated?: (files: Record<string, string>) => void
  ): Promise<void> {
    if (!this.currentSession) return;

    let iterations = 0;
    const maxIterations = 20;

    while (iterations < maxIterations) {
      iterations++;

      // Check if all tasks are complete
      const allCompleted = Object.values(this.currentSession.taskGraph.nodes).every(
        n => n.task.status === 'COMPLETED'
      );
      if (allCompleted) {
        this.finalizeSession();
        break;
      }

      // Check if any task failed permanently
      const anyFailed = Object.values(this.currentSession.taskGraph.nodes).some(
        n => n.task.status === 'FAILED'
      );
      if (anyFailed) {
        this.currentSession.status = 'FAILED';
        OrchestrationTelemetry.emit('ORCHESTRATION_FAILED', 'ORCHESTRATOR', 'Orchestration session failed due to unrecoverable task failure', undefined, 'error');
        this.notifyListeners();
        break;
      }

      // Execute next available batch of tasks
      const { executedCount, hasBlocked } = await this.scheduler.scheduleNext(
        this.currentSession,
        projectFiles,
        onFileMutated
      );

      // Update artifacts map in session
      this.currentSession.artifacts = {};
      this.artifactRegistry.getAllArtifacts().forEach(art => {
        this.currentSession!.artifacts[art.id] = art;
      });

      this.currentSession.conflicts = this.conflictManager.getConflicts();
      this.currentSession.messages = this.messageBus.getHistory();
      this.currentSession.updatedAt = Date.now();
      this.notifyListeners();

      if (hasBlocked || this.currentSession.status === 'AWAITING_APPROVAL') {
        break;
      }

      if (executedCount === 0) {
        // No tasks ready right now
        break;
      }
    }
  }

  /**
   * User approves a blocked task
   */
  public async approveTask(
    taskId: string,
    projectFiles: Record<string, string>,
    onFileMutated?: (files: Record<string, string>) => void
  ): Promise<void> {
    if (!this.currentSession) return;
    const node = this.currentSession.taskGraph.nodes[taskId];
    if (!node) return;

    node.task.approved = true;
    node.task.approvalRequired = false;
    node.task.status = 'READY';
    this.currentSession.status = 'EXECUTING';

    this.messageBus.publish({
      type: 'APPROVAL_GRANTED',
      senderRole: 'HUMAN',
      recipientRole: node.task.role,
      taskId,
      summary: `Human approved task '${node.task.title}'`
    });

    OrchestrationTelemetry.emit('APPROVAL_GRANTED', node.task.role, `Task '${node.task.title}' approved by user`, undefined, 'success');
    this.notifyListeners();

    // Resume execution loop
    await this.runExecutionLoop(projectFiles, onFileMutated);
  }

  /**
   * User rejects a blocked task
   */
  public rejectTask(taskId: string): void {
    if (!this.currentSession) return;
    const node = this.currentSession.taskGraph.nodes[taskId];
    if (!node) return;

    node.task.status = 'CANCELLED';
    node.task.statusMessage = 'Rejected by developer during human review gate';
    this.currentSession.status = 'BLOCKED';

    this.messageBus.publish({
      type: 'APPROVAL_REJECTED',
      senderRole: 'HUMAN',
      recipientRole: node.task.role,
      taskId,
      summary: `Human rejected task '${node.task.title}'`
    });

    OrchestrationTelemetry.emit('APPROVAL_REJECTED', node.task.role, `Task '${node.task.title}' rejected by user`, undefined, 'error');
    this.notifyListeners();
  }

  /**
   * Finalizes the orchestration session with truth-grounded verification
   */
  private finalizeSession(): void {
    if (!this.currentSession) return;

    const tasks = Object.values(this.currentSession.taskGraph.nodes).map(n => n.task);
    const artifacts = this.artifactRegistry.getAllArtifacts();

    const report = VerificationCoordinator.coordinate(
      this.currentSession.id,
      this.currentSession.userObjective,
      tasks,
      artifacts
    );

    this.currentSession.verificationReport = report;
    this.currentSession.status = report.finalState === 'VERIFIED' ? 'COMPLETED' : 'FAILED';
    this.currentSession.updatedAt = Date.now();

    OrchestrationTelemetry.emit(
      'ORCHESTRATION_COMPLETED',
      'ORCHESTRATOR',
      `Orchestration finalized: ${report.finalState}`,
      report.evidenceSummary,
      report.finalState === 'VERIFIED' ? 'success' : 'error'
    );

    this.notifyListeners();
  }
}
