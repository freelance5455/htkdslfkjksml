/**
 * GODEX Phase 9 - Mission Failure Recovery & Loop Protection
 * Governs bounded recovery loops, memory-informed repair strategies,
 * and detects task oscillations / infinite failure loops.
 */

import { Mission, MissionFailureCategory, MissionTimelineEvent, TaskFailure } from './missionTypes';
import { OrchestrationTask, AgentRoleType } from '../orchestration/orchestrationTypes';
import { MissionMemoryConnector, RepairAdvisoryContext } from './missionMemory';
import { CandidateRepair } from '../memory/repairMemory';

export type RecoveryStrategy =
  | 'RETRY'
  | 'REPLAN'
  | 'DELEGATE'
  | 'REQUEST_APPROVAL'
  | 'REQUEST_USER_INPUT'
  | 'BLOCK'
  | 'CANCEL';

export interface RecoveryDecision {
  strategy: RecoveryStrategy;
  category: MissionFailureCategory;
  reason: string;
  recommendedRole?: AgentRoleType;
  replanScope?: string[];
  invalidatedTaskIds?: string[];
  loopDetected?: boolean;
  oscillationDetected?: boolean;
  historicalRepairFound?: boolean;
  suggestedPatchHint?: string;
  advisoryRepairs?: CandidateRepair[];
  advisoryWarning?: string;
}

export class MissionRecoveryEngine {
  /**
   * Classifies an execution error into a deterministic failure category based on real diagnostics.
   * Never fabricates results and never classifies an error as success.
   */
  public static classifyFailure(errorMessage: string, task?: OrchestrationTask): MissionFailureCategory {
    if (!errorMessage || typeof errorMessage !== 'string') {
      return 'UNKNOWN';
    }

    const msg = errorMessage.toLowerCase();

    // 1. Security violations
    if (/security violation|secret detected|token found|unauthorized|api_key|private key|credential/i.test(msg)) {
      return 'SECURITY';
    }

    // 2. Lock & Concurrency Conflicts
    if (/conflict|lock.*held|fingerprint mismatch|cannot acquire lock|stale snapshot|concurrent mutation|already locked/i.test(msg)) {
      return 'CONFLICT';
    }

    // 3. AST / Syntax errors
    if (/syntax ?error|unexpected token|parsing failed|parse error|ast validation error|unterminated/i.test(msg)) {
      return 'SYNTAX';
    }

    // 4. Static TypeScript type errors
    if (/type ?error|cannot find name|is not assignable to|property .* does not exist on type|ts\(\d+\)|not callable/i.test(msg)) {
      return 'TYPECHECK';
    }

    // 5. Test suite / assertion failures
    if (/test failed|assertion ?error|expect\(|expected.*to be|suite failed|test run failed|assertion failed/i.test(msg)) {
      return 'TEST';
    }

    // 6. Build & Bundling errors
    if (/build failed|vite.*error|esbuild.*error|bundle error|rollup error|compilation error/i.test(msg)) {
      return 'BUILD';
    }

    // 7. Timeouts
    if (/time ?out|timed out|execution limit reached|deadline exceeded/i.test(msg)) {
      return 'TIMEOUT';
    }

    // 8. Runtime execution errors
    if (/runtime ?error|cannot read propert|is not defined|reference ?error|command failed|process exit/i.test(msg)) {
      return 'EXECUTION';
    }

    return 'UNKNOWN';
  }

  /**
   * Computes all downstream task IDs that depend directly or transitively on the failed task.
   */
  public static getDownstreamDependentTaskIds(mission: Mission, failedTaskId: string): string[] {
    const dependentIds = new Set<string>();
    const toProcess = [failedTaskId];

    while (toProcess.length > 0) {
      const currentId = toProcess.shift()!;
      for (const task of mission.tasks) {
        if (!dependentIds.has(task.id) && task.id !== failedTaskId) {
          const dependsOnCurrent = task.dependencies.some(d => d.taskId === currentId);
          if (dependsOnCurrent) {
            dependentIds.add(task.id);
            toProcess.push(task.id);
          }
        }
      }
    }

    return Array.from(dependentIds);
  }

  /**
   * Invalidates downstream tasks that depend on the failed task, while strictly preserving
   * all completed upstream and independent work.
   */
  public static invalidateDownstreamTasks(mission: Mission, failedTaskId: string): string[] {
    const downstreamIds = this.getDownstreamDependentTaskIds(mission, failedTaskId);
    const completedSet = new Set(mission.completedTasks);
    const invalidated: string[] = [];

    for (const taskId of downstreamIds) {
      // Never invalidate completed independent tasks
      if (!completedSet.has(taskId)) {
        const task = mission.tasks.find(t => t.id === taskId);
        if (task && task.status !== 'COMPLETED') {
          task.status = 'BLOCKED';
          task.error = `Invalidated due to failure in upstream dependency "${failedTaskId}"`;
          invalidated.push(taskId);
        }
      }
    }

    mission.invalidatedTaskIds = invalidated;
    return invalidated;
  }

  /**
   * Evaluates task failure and decides the safest adaptive recovery path without uncontrolled loops.
   */
  public static evaluateFailure(
    mission: Mission,
    task: OrchestrationTask,
    errorMessage: string
  ): RecoveryDecision {
    const category = this.classifyFailure(errorMessage, task);
    const downstreamInvalidated = this.getDownstreamDependentTaskIds(mission, task.id);

    // 1. Update loop protection counters
    mission.loopProtection.consecutiveFailures++;
    mission.budget.currentRetries++;
    
    const taskKey = task.id;
    mission.loopProtection.repeatedTasks[taskKey] = (mission.loopProtection.repeatedTasks[taskKey] || 0) + 1;

    const rawKey = errorMessage.slice(0, 100).trim();
    const failureSignature = `${category}:${rawKey}`;
    mission.loopProtection.repeatedFailures[failureSignature] = 
      (mission.loopProtection.repeatedFailures[failureSignature] || 0) + 1;
    if (rawKey !== failureSignature) {
      mission.loopProtection.repeatedFailures[rawKey] = 
        (mission.loopProtection.repeatedFailures[rawKey] || 0) + 1;
    }

    // Track touched files for oscillation detection
    if (task.targetFiles && task.targetFiles.length > 0) {
      for (const tf of task.targetFiles) {
        if (!mission.loopProtection.oscillatingFiles.includes(tf)) {
          mission.loopProtection.oscillatingFiles.push(tf);
        }
      }
    }

    // 2. Loop & Oscillation Protection Checks
    // Check 2a: Repeated identical failure signature >= 3 times
    const repeatedCount = Math.max(
      mission.loopProtection.repeatedFailures[failureSignature] || 0,
      mission.loopProtection.repeatedFailures[rawKey] || 0
    );
    if (repeatedCount >= 3) {
      return {
        strategy: 'REPLAN',
        category,
        reason: `Loop Protection: Same failure occurred 3 times ("${rawKey}"). Halting direct retry to dynamically replan DAG.`,
        loopDetected: true,
        invalidatedTaskIds: downstreamInvalidated
      };
    }

    // Check 2b: Oscillation across multiple alternating files/errors with high failure count
    if (mission.loopProtection.oscillatingFiles.length >= 3 && mission.loopProtection.consecutiveFailures >= 4) {
      return {
        strategy: 'BLOCK',
        category,
        reason: `Oscillation Protection: Alternating mutations across ${mission.loopProtection.oscillatingFiles.length} files detected. Halting autonomous repair to protect workspace integrity.`,
        loopDetected: true,
        oscillationDetected: true,
        invalidatedTaskIds: downstreamInvalidated
      };
    }

    // Check 2c: Excessive consecutive failures across mission
    if (mission.loopProtection.consecutiveFailures > 4) {
      return {
        strategy: 'BLOCK',
        category,
        reason: `Loop Protection: 4 consecutive failures across tasks. Mission paused to prevent destabilizing workspace.`,
        loopDetected: true,
        invalidatedTaskIds: downstreamInvalidated
      };
    }

    // Check 2d: Task repeat limit exceeded
    const taskLimit = task.maxRetries || mission.budget.maxRetries;
    if (mission.loopProtection.repeatedTasks[taskKey] > taskLimit) {
      return {
        strategy: 'REPLAN',
        category,
        reason: `Task "${task.title}" exceeded maximum retry allowance (${taskLimit}). Escalating to replanner.`,
        loopDetected: true,
        invalidatedTaskIds: downstreamInvalidated
      };
    }

    // 3. Memory-informed diagnosis (Advisory only — never overrides current AST/tests/ConflictManager)
    let historicalRepairFound = false;
    let patchHint: string | undefined = undefined;
    let advisoryRepairs: CandidateRepair[] | undefined = undefined;
    let advisoryWarning: string | undefined = undefined;

    try {
      const taskFailureObj: TaskFailure = {
        taskId: task.id,
        category,
        errorMessage,
        timestamp: Date.now(),
        retryCount: task.attemptCount,
        loopDetected: false
      };

      const repairContext: RepairAdvisoryContext = MissionMemoryConnector.retrieveRepairContext(
        taskFailureObj,
        task.targetFiles,
        task.dependencies.map(d => d.taskId)
      );

      if (repairContext.foundCandidates && repairContext.candidates.length > 0) {
        historicalRepairFound = true;
        advisoryRepairs = repairContext.candidates;
        advisoryWarning = repairContext.advisoryWarning;
        const topCandidate = repairContext.candidates[0];
        patchHint = `Advisory Memory Hint [${topCandidate.strategy}]: ${topCandidate.explanation} (Trust: ${topCandidate.historicalOutcome === 'SUCCESS' ? 'VERIFIED' : 'ADVISORY'})`;
      }
    } catch {
      // Memory failure safe fallback
    }

    // 4. Missing file or structural discrepancy -> REPLAN immediately
    if (category === 'UNKNOWN' && /not found|no such file|cannot find module|module not found|does not exist/i.test(errorMessage)) {
      return {
        strategy: 'REPLAN',
        category: 'BUILD',
        reason: `Structural discrepancy: referenced target file or symbol is missing. Context must be refreshed.`,
        invalidatedTaskIds: downstreamInvalidated,
        historicalRepairFound,
        suggestedPatchHint: patchHint
      };
    }

    // 5. Security violation -> REQUEST_APPROVAL or BLOCK
    if (category === 'SECURITY') {
      return {
        strategy: 'REQUEST_APPROVAL',
        category,
        reason: `Security constraint encountered: ${errorMessage}`,
        invalidatedTaskIds: downstreamInvalidated,
        historicalRepairFound: false
      };
    }

    // 6. Lock Conflict -> Never blindly retry mutation; wait or replan
    if (category === 'CONFLICT') {
      return {
        strategy: 'REQUEST_APPROVAL',
        category,
        reason: `Resource concurrency conflict: ${errorMessage}. Re-evaluating lock hierarchy.`,
        invalidatedTaskIds: downstreamInvalidated,
        historicalRepairFound: false
      };
    }

    // 7. VERIFIER or REVIEWER failure (syntax/build/security gate) -> BLOCK or REPLAN
    if (task.role === 'VERIFIER' || task.role === 'REVIEWER') {
      return {
        strategy: 'BLOCK',
        category,
        reason: `Verification Gate Failure (${category}): ${errorMessage}`,
        invalidatedTaskIds: downstreamInvalidated,
        historicalRepairFound: false
      };
    }

    // 8. Check if retries / attempts are exhausted -> REPLAN
    if (task.attemptCount >= taskLimit) {
      return {
        strategy: 'REPLAN',
        category,
        reason: `Retries exhausted for task "${task.title}" (${task.attemptCount}/${taskLimit}). Requesting mission replanner.`,
        invalidatedTaskIds: downstreamInvalidated,
        historicalRepairFound,
        suggestedPatchHint: patchHint,
        advisoryRepairs,
        advisoryWarning
      };
    }

    // 9. Test, Typecheck, or Runtime failure during implementation -> Hand off to DEBUGGER role for surgical repair
    if (task.role !== 'DEBUGGER' && (category === 'TEST' || category === 'TYPECHECK' || category === 'SYNTAX' || category === 'EXECUTION')) {
      return {
        strategy: 'DELEGATE',
        category,
        reason: `Handing off ${category} failure to specialized DEBUGGER agent for root-cause diagnosis.`,
        recommendedRole: 'DEBUGGER',
        invalidatedTaskIds: downstreamInvalidated,
        historicalRepairFound,
        suggestedPatchHint: patchHint,
        advisoryRepairs,
        advisoryWarning
      };
    }

    // 10. Standard bounded retry if retry budget remains and failure is safe to retry
    return {
      strategy: 'RETRY',
      category,
      reason: `Bounded attempt ${task.attemptCount + 1}/${taskLimit} scheduled for task "${task.title}" [Category: ${category}].`,
      invalidatedTaskIds: downstreamInvalidated,
      historicalRepairFound,
      suggestedPatchHint: patchHint,
      advisoryRepairs,
      advisoryWarning
    };
  }

  /**
   * Resets consecutive failure counter upon successful task completion.
   */
  public static recordSuccess(mission: Mission): void {
    mission.loopProtection.consecutiveFailures = 0;
  }
}
