/**
 * GODEX Phase 9 - Mission State Machine
 * Enforces explicit, deterministic lifecycle transitions for Autonomous Engineering Missions.
 * Prevents arbitrary or out-of-order state mutations.
 */

import { MissionStatus, Mission } from './missionTypes';

export class MissionStateMachine {
  private static readonly VALID_TRANSITIONS: Record<MissionStatus, MissionStatus[]> = {
    DRAFT: ['ANALYZING', 'CANCELLED'],
    ANALYZING: ['PLANNING', 'WAITING_FOR_INPUT', 'BLOCKED', 'FAILED', 'CANCELLED'],
    PLANNING: ['READY', 'WAITING_FOR_INPUT', 'BLOCKED', 'FAILED', 'CANCELLED', 'EXECUTING'],
    READY: ['EXECUTING', 'VERIFYING', 'WAITING_FOR_APPROVAL', 'PAUSED', 'CANCELLED', 'PLANNING'],
    EXECUTING: [
      'WAITING_FOR_APPROVAL',
      'WAITING_FOR_INPUT',
      'RECOVERING',
      'REPLANNING',
      'VERIFYING',
      'COMPLETED',
      'FAILED',
      'BLOCKED',
      'PAUSED',
      'CANCELLED'
    ],
    WAITING_FOR_APPROVAL: ['EXECUTING', 'REPLANNING', 'BLOCKED', 'CANCELLED', 'PAUSED'],
    WAITING_FOR_INPUT: ['ANALYZING', 'PLANNING', 'EXECUTING', 'BLOCKED', 'CANCELLED'],
    RECOVERING: ['EXECUTING', 'REPLANNING', 'BLOCKED', 'FAILED', 'WAITING_FOR_APPROVAL', 'PAUSED'],
    REPLANNING: ['READY', 'EXECUTING', 'BLOCKED', 'FAILED', 'WAITING_FOR_APPROVAL', 'PAUSED'],
    VERIFYING: ['COMPLETED', 'RECOVERING', 'REPLANNING', 'FAILED', 'BLOCKED', 'PAUSED'],
    PAUSED: ['EXECUTING', 'READY', 'PLANNING', 'CANCELLED'],
    BLOCKED: ['READY', 'EXECUTING', 'REPLANNING', 'CANCELLED'],
    COMPLETED: ['REPLANNING'], // Can replan or extend on request
    FAILED: ['REPLANNING', 'RECOVERING'], // Can attempt deliberate recovery
    CANCELLED: [] // Terminal
  };

  /**
   * Asserts whether a transition from fromStatus to toStatus is permitted.
   */
  public static canTransition(fromStatus: MissionStatus, toStatus: MissionStatus): boolean {
    if (fromStatus === toStatus) return true;
    const allowed = this.VALID_TRANSITIONS[fromStatus] || [];
    return allowed.includes(toStatus);
  }

  /**
   * Performs transition on a mission, mutating status and updatedAt, or throwing an error.
   */
  public static transition(mission: Mission, toStatus: MissionStatus, reason?: string): void {
    if (!this.canTransition(mission.status, toStatus)) {
      throw new Error(
        `[MissionStateMachine] Invalid state transition from "${mission.status}" to "${toStatus}". Reason: ${reason || 'Unspecified'}`
      );
    }
    mission.status = toStatus;
    mission.updatedAt = Date.now();
  }

  /**
   * Helper to check if mission is in an active non-terminal state.
   */
  public static isActive(status: MissionStatus): boolean {
    return !['COMPLETED', 'FAILED', 'CANCELLED', 'PAUSED', 'BLOCKED'].includes(status);
  }

  /**
   * Helper to check if mission has reached an end state.
   */
  public static isTerminal(status: MissionStatus): boolean {
    return ['COMPLETED', 'FAILED', 'CANCELLED'].includes(status);
  }
}
