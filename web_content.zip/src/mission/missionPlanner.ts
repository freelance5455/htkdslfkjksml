/**
 * GODEX Phase 9 - Autonomous Mission Planner
 * Transforms natural language engineering objectives into structured,
 * evidence-grounded missions decomposed into Phase 6 DAG TaskGraphs.
 * 
 * Inspects real project files before planning. Zero blind assumptions.
 */

import { 
  Mission, 
  MissionSuccessCriteria, 
  MissionBudget, 
  AutonomyLevel, 
  MissionTimelineEvent,
  MissionFailureCategory
} from './missionTypes';
import { OrchestrationTask, AgentRoleType, RiskLevel } from '../orchestration/orchestrationTypes';
import { TaskGraphEngine } from '../orchestration/taskGraph';
import { ProjectDetector } from '../intelligence/projectDetector';
import { MissionProgressEngine } from './missionProgress';
import { MissionMemoryConnector } from './missionMemory';
import { ContextPackBuilder } from '../intelligence/contextPackBuilder';
import { MissionRecoveryEngine } from './missionRecovery';

export class MissionPlanner {
  /**
   * Plans a new autonomous engineering mission by inspecting project state and memory.
   */
  public static async planMission(
    userIntent: string,
    projectFiles: Record<string, string>,
    autonomyLevel: AutonomyLevel = 'CONTROLLED'
  ): Promise<Mission> {
    const missionId = `mission-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const cleanIntent = userIntent.trim();

    // 1. Inspect project files to find actual candidates
    const projectMetadata = ProjectDetector.analyzeProjectMetadata(projectFiles);
    const candidateFiles = Object.keys(projectFiles).filter(
      f => !f.includes('node_modules') && !f.endsWith('.lock') && (f.endsWith('.ts') || f.endsWith('.tsx') || f.endsWith('.json') || f.endsWith('.js'))
    );

    // 2. Identify target files based on intent
    const relevantFiles = this.identifyRelevantFiles(cleanIntent, candidateFiles);

    // 3. Retrieve engineering memory
    const memoryContext = MissionMemoryConnector.retrievePlanningContext(cleanIntent, relevantFiles);

    // 4. Generate structured title & objective
    const title = this.deriveMissionTitle(cleanIntent);

    // 5. Evaluate security sensitivity & risk
    const isSecuritySensitive = /auth|password|token|secret|credential|database|permission|jwt|crypto/i.test(cleanIntent);
    const riskLevel: RiskLevel = isSecuritySensitive ? 'HIGH' : relevantFiles.length > 5 ? 'MEDIUM' : 'LOW';

    // 6. Decompose into Phase 6 Orchestration Tasks
    const tasks = this.decomposeTasks(missionId, cleanIntent, relevantFiles, candidateFiles, isSecuritySensitive);

    // 7. Create DAG TaskGraph (reusing Phase 6 TaskGraphEngine)
    const taskGraph = TaskGraphEngine.createGraph(tasks);

    // 8. Define explicit success criteria
    const successCriteria: MissionSuccessCriteria = {
      typecheckPassed: false,
      testsPassed: false,
      buildPassed: false,
      securityPassed: false,
      noRegressions: true,
      gitStateExpected: true,
      customCriteria: [
        {
          id: 'crit-arch',
          description: 'Architectural consistency maintained across modified files',
          verified: false
        },
        {
          id: 'crit-task-dag',
          description: 'All decomposed DAG tasks completed successfully',
          verified: false
        }
      ]
    };

    // 9. Set mission budgets
    const budget: MissionBudget = {
      maxTasks: 20,
      maxRetries: 3,
      maxFileMutations: 30,
      maxExecutionTimeMs: 600000, // 10 minutes
      maxAgentIterations: 40,
      maxRepairAttempts: 5,
      currentTasksCreated: tasks.length,
      currentRetries: 0,
      currentFileMutations: 0,
      currentExecutionTimeMs: 0,
      currentAgentIterations: 0,
      currentRepairAttempts: 0
    };

    const initialTimeline: MissionTimelineEvent[] = [
      {
        id: `ev-init-${Date.now()}`,
        timestamp: Date.now(),
        stage: 'REQUEST',
        title: 'Mission Created',
        description: `Mission "${title}" initialized from user objective.`,
        status: 'info'
      },
      {
        id: `ev-plan-${Date.now()}`,
        timestamp: Date.now(),
        stage: 'PLAN',
        title: 'Task Decomposition Complete',
        description: `Decomposed into ${tasks.length} DAG tasks with ${memoryContext.decisions.length} memory records referenced.`,
        status: 'success'
      }
    ];

    const mission: Mission = {
      id: missionId,
      missionId,
      title,
      objective: cleanIntent,
      userIntent: cleanIntent,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      status: 'READY',
      priority: isSecuritySensitive ? 'HIGH' : 'NORMAL',
      autonomyLevel,
      constraints: [
        'Must pass static TypeScript validation',
        'Must not introduce exposed security tokens or secrets',
        'Must preserve reversibility via checkpoints'
      ],
      successCriteria,
      tasks,
      taskGraph,
      completedTasks: [],
      failedTasks: [],
      blockedTasks: [],
      verificationStatus: 'UNVERIFIED',
      riskLevel,
      progress: {
        totalTasksCount: tasks.length,
        completedTasksCount: 0,
        verifiedTasksCount: 0,
        percentage: 0,
        passedGatesCount: 0,
        totalGatesCount: 6,
        summary: `Planned ${tasks.length} tasks ready for execution.`
      },
      checkpoints: [],
      memoryReferences: memoryContext.decisions.map(d => d.record.id),
      budget,
      timeline: initialTimeline,
      loopProtection: {
        consecutiveFailures: 0,
        repeatedTasks: {},
        repeatedFailures: {},
        oscillatingFiles: [],
        lastPatchHashes: []
      }
    };

    // Calculate initial progress
    mission.progress = MissionProgressEngine.calculateProgress(mission);

    return mission;
  }

  /**
   * Decomposes user objective into structured Phase 6 DAG tasks.
   */
  private static decomposeTasks(
    missionId: string,
    objective: string,
    targetFiles: string[],
    allFiles: string[],
    isSecuritySensitive: boolean
  ): OrchestrationTask[] {
    const testFiles = allFiles.filter(f => f.includes('test') || f.includes('spec') || f.includes('simulation'));

    const task1: OrchestrationTask = {
      id: `${missionId}-t1-arch`,
      title: 'Inspect & Architect Strategy',
      description: `Analyze project architecture and formulate concrete design for: ${objective}`,
      role: 'ARCHITECT',
      priority: 'CRITICAL',
      risk: 'LOW',
      status: 'READY',
      dependencies: [],
      targetFiles: targetFiles.slice(0, 3),
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };

    const task2: OrchestrationTask = {
      id: `${missionId}-t2-research`,
      title: 'Analyze Symbols & Call Graphs',
      description: `Research exported symbols, AST types, and dependencies for ${targetFiles.slice(0, 3).join(', ') || 'target modules'}`,
      role: 'RESEARCHER',
      priority: 'HIGH',
      risk: 'LOW',
      status: 'READY',
      dependencies: [], // Parallel with Architect
      targetFiles: targetFiles.slice(0, 5),
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };

    const task3: OrchestrationTask = {
      id: `${missionId}-t3-coder`,
      title: 'Implement Core Mutations',
      description: `Execute safe mutations and feature implementation for: ${objective}`,
      role: 'CODER',
      priority: 'CRITICAL',
      risk: isSecuritySensitive ? 'HIGH' : 'NORMAL' as any,
      status: 'QUEUED',
      dependencies: [
        { taskId: task1.id, type: 'HARD' },
        { taskId: task2.id, type: 'HARD' }
      ],
      targetFiles: targetFiles.length > 0 ? targetFiles.slice(0, 3) : ['src/App.tsx'],
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      approvalRequired: isSecuritySensitive,
      approvalReason: isSecuritySensitive ? 'Security-sensitive modification requires verification' : undefined,
      createdAt: Date.now()
    };

    const task4: OrchestrationTask = {
      id: `${missionId}-t4-tester`,
      title: 'Execute Verification Suite & Tests',
      description: 'Run static validation, unit assertions, and detect regressions',
      role: 'TESTER',
      priority: 'HIGH',
      risk: 'LOW',
      status: 'QUEUED',
      dependencies: [{ taskId: task3.id, type: 'HARD' }],
      targetFiles: testFiles.length > 0 ? testFiles.slice(0, 2) : targetFiles.slice(0, 2),
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };

    const task5: OrchestrationTask = {
      id: `${missionId}-t5-reviewer`,
      title: 'Security & Quality Review',
      description: 'Perform independent code review, security sanitizer scan, and Git diff inspection',
      role: 'REVIEWER',
      priority: 'HIGH',
      risk: 'LOW',
      status: 'QUEUED',
      dependencies: [
        { taskId: task3.id, type: 'HARD' },
        { taskId: task4.id, type: 'HARD' }
      ],
      targetFiles: targetFiles.slice(0, 3),
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };

    const task6: OrchestrationTask = {
      id: `${missionId}-t6-verifier`,
      title: 'Final Evidence-Grounded Verification',
      description: 'Compile mission evidence dossier, verify gates, and prepare release readiness',
      role: 'VERIFIER',
      priority: 'CRITICAL',
      risk: 'LOW',
      status: 'QUEUED',
      dependencies: [{ taskId: task5.id, type: 'HARD' }],
      targetFiles: [],
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };

    return [task1, task2, task3, task4, task5, task6];
  }

  /**
   * Dynamically replans a mission when execution reveals obstacles or failures.
   * Strictly preserves completed valid tasks while replacing invalidated downstream DAG nodes
   * with root-cause targeted remediation tasks.
   */
  public static replanMission(
    mission: Mission,
    projectFiles: Record<string, string>,
    reason: string,
    failedTaskId?: string,
    failureCategory?: MissionFailureCategory,
    suggestedHint?: string
  ): Mission {
    mission.status = 'REPLANNING';
    mission.updatedAt = Date.now();

    // 1. Inspect current workspace files
    const candidateFiles = Object.keys(projectFiles).filter(
      f => !f.includes('node_modules') && !f.endsWith('.lock') && (f.endsWith('.ts') || f.endsWith('.tsx'))
    );
    const relevantFiles = this.identifyRelevantFiles(mission.objective, candidateFiles);

    // 2. Identify completed task IDs to strictly preserve them
    const completedIds = new Set(mission.completedTasks);

    // 3. Compute downstream invalidated task IDs if failedTaskId provided
    const invalidatedIds = failedTaskId 
      ? new Set(MissionRecoveryEngine.getDownstreamDependentTaskIds(mission, failedTaskId))
      : new Set<string>();

    if (failedTaskId) {
      invalidatedIds.add(failedTaskId);
    }

    mission.invalidatedTaskIds = Array.from(invalidatedIds).filter(id => !completedIds.has(id));

    // 4. Preserve completed tasks and unaffected independent tasks
    const replannedTasks: OrchestrationTask[] = [];

    for (const t of mission.tasks) {
      if (completedIds.has(t.id)) {
        replannedTasks.push(t);
      } else if (!invalidatedIds.has(t.id)) {
        // Unaffected incomplete task: adjust dependencies if needed
        const updatedDeps = t.dependencies.filter(d => !invalidatedIds.has(d.taskId));
        replannedTasks.push({
          ...t,
          dependencies: updatedDeps
        });
      }
    }

    // 5. Generate root-cause aware replacement remediation tasks
    const cat = failureCategory || MissionRecoveryEngine.classifyFailure(reason);
    const repairTaskId = `${mission.id}-replan-repair-${Date.now()}`;
    
    let repairTitle = `Adaptive Remediation: ${reason.slice(0, 45)}`;
    let repairDesc = `Re-architect and adjust implementation based on obstacle: ${reason}`;
    let repairRole: AgentRoleType = 'DEBUGGER';

    if (cat === 'TYPECHECK') {
      repairTitle = `Typecheck Fix: ${reason.slice(0, 40)}`;
      repairDesc = `Repair static TypeScript type errors in target files.${suggestedHint ? ` [${suggestedHint}]` : ''}`;
      repairRole = 'DEBUGGER';
    } else if (cat === 'SYNTAX') {
      repairTitle = `Syntax AST Repair: ${reason.slice(0, 40)}`;
      repairDesc = `Repair malformed syntax in source files to satisfy AST validator.`;
      repairRole = 'DEBUGGER';
    } else if (cat === 'TEST') {
      repairTitle = `Test Remediation: ${reason.slice(0, 40)}`;
      repairDesc = `Fix assertion discrepancy in test suite or implementation logic.`;
      repairRole = 'DEBUGGER';
    } else if (cat === 'SECURITY') {
      repairTitle = `Security Sanitization: ${reason.slice(0, 40)}`;
      repairDesc = `Remove detected secrets and sanitize sensitive tokens from workspace.`;
      repairRole = 'REVIEWER';
    } else if (cat === 'CONFLICT') {
      repairTitle = `Conflict Resolution: ${reason.slice(0, 40)}`;
      repairDesc = `Re-synchronize file state and re-acquire locks cleanly.`;
      repairRole = 'ARCHITECT';
    }

    // Last completed task id as dependency if any
    const lastCompletedId = mission.completedTasks[mission.completedTasks.length - 1];
    const repairDeps = lastCompletedId ? [{ taskId: lastCompletedId, type: 'HARD' as const }] : [];

    const replanTask: OrchestrationTask = {
      id: repairTaskId,
      title: repairTitle,
      description: repairDesc,
      role: repairRole,
      priority: 'CRITICAL',
      risk: 'MEDIUM',
      status: 'READY',
      dependencies: repairDeps,
      targetFiles: relevantFiles.slice(0, 3),
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };
    replannedTasks.push(replanTask);

    // If it was a test failure, add a TESTER task
    let lastFollowUpId = repairTaskId;
    if (cat === 'TEST') {
      const testerTaskId = `${mission.id}-replan-test-${Date.now()}`;
      const testerTask: OrchestrationTask = {
        id: testerTaskId,
        title: 'Execute Automated Test Suite',
        description: 'Verify all unit and integration test assertions pass after repair',
        role: 'TESTER',
        priority: 'HIGH',
        risk: 'LOW',
        status: 'QUEUED',
        dependencies: [{ taskId: repairTaskId, type: 'HARD' }],
        targetFiles: relevantFiles.filter(f => f.includes('.test.') || f.includes('.spec.')),
        artifactsProduced: [],
        attemptCount: 0,
        maxRetries: 2,
        createdAt: Date.now()
      };
      replannedTasks.push(testerTask);
      lastFollowUpId = testerTaskId;
    }

    // Add follow-up verification task
    const verifTaskId = `${mission.id}-replan-verify-${Date.now()}`;
    const followUpVerifTask: OrchestrationTask = {
      id: verifTaskId,
      title: 'Replanned Verification Gate',
      description: 'Verify remediation passes full typechecking, building, and security assertions',
      role: 'VERIFIER',
      priority: 'HIGH',
      risk: 'LOW',
      status: 'QUEUED',
      dependencies: [{ taskId: lastFollowUpId, type: 'HARD' }],
      targetFiles: [],
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    };
    replannedTasks.push(followUpVerifTask);

    // Rebuild TaskGraph
    mission.tasks = replannedTasks;
    mission.taskGraph = TaskGraphEngine.createGraph(replannedTasks);
    mission.activeTaskId = repairTaskId;
    mission.status = 'READY';

    // Record timeline event
    mission.timeline.push({
      id: `ev-replan-${Date.now()}`,
      timestamp: Date.now(),
      stage: 'REPLAN',
      title: `Dynamic Replan (${cat})`,
      description: `Replanned DAG preserving ${mission.completedTasks.length} completed tasks. Reason: ${reason}`,
      status: 'warning',
      metadata: {
        category: cat,
        invalidatedTasksCount: mission.invalidatedTaskIds.length,
        preservedTasksCount: mission.completedTasks.length
      }
    });

    mission.progress = MissionProgressEngine.calculateProgress(mission);

    return mission;
  }

  private static identifyRelevantFiles(objective: string, candidateFiles: string[]): string[] {
    const words = objective.toLowerCase().split(/\W+/).filter(w => w.length > 3);
    const matched: string[] = [];

    for (const file of candidateFiles) {
      const lower = file.toLowerCase();
      for (const word of words) {
        if (lower.includes(word)) {
          matched.push(file);
          break;
        }
      }
    }

    if (matched.length > 0) return matched;
    // Fallback: choose top source files
    return candidateFiles.filter(f => f.startsWith('src/')).slice(0, 4);
  }

  private static deriveMissionTitle(intent: string): string {
    const cleaned = intent.replace(/^(please|can you|i want to|build a|create a|implement a|add a)\s+/i, '');
    const title = cleaned.charAt(0).toUpperCase() + cleaned.slice(1, 40);
    return title.length < cleaned.length ? `${title}...` : title;
  }
}
