/**
 * GODEX Phase 9 - Mission Autonomy Policy
 * Governs the permissions and approval gates across autonomy levels:
 * - ASSISTED: Asks human approval for significant changes or high risk steps.
 * - CONTROLLED: Automatically executes safe, low/medium risk work; pauses for high-risk, security, or destructive actions.
 * - AUTONOMOUS: Executes maximum permitted engineering autonomy within safe sandbox and policy boundaries.
 * 
 * CRITICAL RULE: Autonomous mode NEVER bypasses security sanitization, protected branch policies,
 * or validation gates.
 */

import { AutonomyLevel, Mission, MissionApprovalGate } from './missionTypes';
import { OrchestrationTask, RiskLevel, AgentRoleType } from '../orchestration/orchestrationTypes';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export interface AutonomyCheckResult {
  allowed: boolean;
  requiresApproval: boolean;
  approvalReason?: string;
  blockedReason?: string;
  riskLevel: RiskLevel;
}

export class MissionAutonomyPolicy {
  /**
   * Evaluates if a given task execution requires human approval under the active autonomy level.
   */
  public static evaluateTaskExecution(
    mission: Mission,
    task: OrchestrationTask
  ): AutonomyCheckResult {
    const level = mission.autonomyLevel;
    const isSecurityRelated = /auth|security|secret|token|credential|jwt|permission|database|payment/i.test(
      `${task.title} ${task.description} ${task.targetFiles.join(' ')}`
    );

    const hasCriticalTargetFiles = task.targetFiles.some(f => 
      f.includes('package.json') || f.includes('.env') || f.includes('schema') || f.includes('config')
    );

    let effectiveRisk: RiskLevel = task.risk || 'LOW';
    if (isSecurityRelated || hasCriticalTargetFiles) {
      if (effectiveRisk === 'LOW') effectiveRisk = 'MEDIUM';
      if (effectiveRisk === 'MEDIUM' && isSecurityRelated && hasCriticalTargetFiles) effectiveRisk = 'HIGH';
    }

    // 1. ASSISTED: Any Coder/Mutating task or Medium+ risk requires approval
    if (level === 'ASSISTED') {
      if (task.role === 'CODER' || effectiveRisk === 'HIGH' || effectiveRisk === 'CRITICAL' || hasCriticalTargetFiles) {
        return {
          allowed: false,
          requiresApproval: true,
          approvalReason: `Assisted mode: task "${task.title}" involves code modification or sensitive target files.`,
          riskLevel: effectiveRisk
        };
      }
      return { allowed: true, requiresApproval: false, riskLevel: effectiveRisk };
    }

    // 2. CONTROLLED: Low and non-critical Medium are automated; High/Critical or Security requires approval
    if (level === 'CONTROLLED') {
      if (effectiveRisk === 'CRITICAL' || (effectiveRisk === 'HIGH' && isSecurityRelated)) {
        return {
          allowed: false,
          requiresApproval: true,
          approvalReason: `Controlled mode: high-risk security task "${task.title}" requires human authorization.`,
          riskLevel: effectiveRisk
        };
      }
      return { allowed: true, requiresApproval: false, riskLevel: effectiveRisk };
    }

    // 3. AUTONOMOUS: Executes autonomously unless it involves hard-coded security secrets or destructive bypass
    if (level === 'AUTONOMOUS') {
      if (effectiveRisk === 'CRITICAL') {
        return {
          allowed: false,
          requiresApproval: true,
          approvalReason: `Critical risk threshold reached for task "${task.title}". Human verification required.`,
          riskLevel: 'CRITICAL'
        };
      }
      return { allowed: true, requiresApproval: false, riskLevel: effectiveRisk };
    }

    return { allowed: true, requiresApproval: false, riskLevel: 'LOW' };
  }

  /**
   * Evaluates if a file mutation or content contains security violations
   */
  public static evaluateContentSafety(filePath: string, content: string): AutonomyCheckResult {
    const hasSecrets = SecuritySanitizer.detectSecrets(content);
    if (hasSecrets) {
      return {
        allowed: false,
        requiresApproval: false,
        blockedReason: `Security violation: content for "${filePath}" contains detected secrets or unmasked credentials.`,
        riskLevel: 'CRITICAL'
      };
    }
    return { allowed: true, requiresApproval: false, riskLevel: 'LOW' };
  }

  /**
   * Evaluates if a Git operation requires approval
   */
  public static evaluateGitOperation(
    level: AutonomyLevel,
    operationType: 'COMMIT' | 'BRANCH' | 'MERGE' | 'RELEASE_AUDIT',
    targetBranch: string
  ): AutonomyCheckResult {
    const isProtected = ['main', 'master', 'production', 'release'].includes(targetBranch);

    if (operationType === 'MERGE' && isProtected) {
      return {
        allowed: false,
        requiresApproval: true,
        approvalReason: `Merge into protected branch "${targetBranch}" requires explicit human approval.`,
        riskLevel: 'HIGH'
      };
    }

    if (level === 'ASSISTED' && (operationType === 'COMMIT' || operationType === 'MERGE')) {
      return {
        allowed: false,
        requiresApproval: true,
        approvalReason: `Assisted mode: Git ${operationType} requires confirmation.`,
        riskLevel: 'MEDIUM'
      };
    }

    return { allowed: true, requiresApproval: false, riskLevel: isProtected ? 'MEDIUM' : 'LOW' };
  }
}
