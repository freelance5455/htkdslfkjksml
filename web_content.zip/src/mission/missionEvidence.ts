/**
 * GODEX Phase 9 - Mission Evidence Engine
 * Generates verified, immutable evidence dossiers for completed and verifying missions.
 * Enforces truthful epistemic separation (KNOWN / LIKELY / UNKNOWN). Zero fabricated evidence.
 */

import { Mission, MissionEvidence, EpistemicMissionKnowledge } from './missionTypes';
import { AgentRoleType } from '../orchestration/orchestrationTypes';

export interface VerificationEvidenceDetails {
  typecheckRes?: { exitCode: number; stdout?: string; stderr?: string; errorCount?: number };
  buildRes?: { exitCode: number; stdout?: string; stderr?: string; output?: string };
  testRes?: { exitCode: number; stdout?: string; stderr?: string; summary?: string };
  securityViolations?: string[];
}

export class MissionEvidenceEngine {
  /**
   * Constructs comprehensive, evidence-grounded mission dossier.
   */
  public static compileEvidence(
    mission: Mission,
    filesBefore: Record<string, string>,
    filesAfter: Record<string, string>,
    verificationDetails?: VerificationEvidenceDetails
  ): MissionEvidence {
    // 1. Identify changed files
    const changedFiles: string[] = [];
    const allKeys = new Set([...Object.keys(filesBefore), ...Object.keys(filesAfter)]);
    for (const key of allKeys) {
      if (filesBefore[key] !== filesAfter[key]) {
        changedFiles.push(key);
      }
    }

    // 2. Aggregate agents involved
    const agentsSet = new Set<AgentRoleType>();
    mission.tasks.forEach(t => {
      if (t.status === 'COMPLETED' || t.status === 'RUNNING') {
        agentsSet.add(t.role);
      }
    });

    // 3. Collect real executed commands and git operations
    const commandsSet = new Set<string>();
    const gitOpsSet = new Set<string>();
    mission.tasks.forEach(t => {
      if (t.executionEvidence?.command) {
        commandsSet.add(t.executionEvidence.command);
        if (t.executionEvidence.command.startsWith('git ')) {
          gitOpsSet.add(t.executionEvidence.command);
        }
      }
    });
    if (verificationDetails?.typecheckRes) commandsSet.add('tsc --noEmit');
    if (verificationDetails?.buildRes) commandsSet.add('npm run build');
    if (verificationDetails?.testRes) commandsSet.add('npm test');

    // 4. Compile Epistemic Breakdown
    const epistemic: EpistemicMissionKnowledge = {
      known: [
        `Executed ${mission.completedTasks.length}/${mission.tasks.length} tasks in DAG task graph.`,
        `Workspace contains ${Object.keys(filesAfter).length} total files.`,
        changedFiles.length > 0 
          ? `Mutated ${changedFiles.length} file(s): ${changedFiles.slice(0, 3).join(', ')}${changedFiles.length > 3 ? '...' : ''}`
          : 'Zero file mutations occurred.'
      ],
      likely: [
        `Architecture consistency evaluated across ${mission.tasks.length} planned DAG steps.`,
        `Task dependency graph resolved sequentially without concurrent race conditions.`
      ],
      unknown: []
    };

    if (verificationDetails?.typecheckRes) {
      if (verificationDetails.typecheckRes.exitCode === 0) {
        epistemic.known.push('Static typechecking completed with 0 errors via tsc --noEmit.');
      } else {
        epistemic.known.push(`Static typechecking failed with exit code ${verificationDetails.typecheckRes.exitCode}: ${verificationDetails.typecheckRes.stderr || 'Errors found'}`);
      }
    } else if (mission.successCriteria.typecheckPassed) {
      epistemic.known.push('Static typechecking completed with 0 errors.');
    } else {
      epistemic.unknown.push('Static typechecking was not run or has unverified error states.');
    }

    if (verificationDetails?.buildRes) {
      if (verificationDetails.buildRes.exitCode === 0) {
        epistemic.known.push('Production build completed cleanly via bundler.');
      } else {
        epistemic.known.push(`Production build failed with exit code ${verificationDetails.buildRes.exitCode}: ${verificationDetails.buildRes.stderr || 'Build failed'}`);
      }
    } else if (mission.successCriteria.buildPassed) {
      epistemic.known.push('Production bundle build verified.');
    } else {
      epistemic.unknown.push('Production build was not executed or unverified.');
    }

    if (verificationDetails?.testRes) {
      if (verificationDetails.testRes.exitCode === 0) {
        epistemic.known.push('Automated unit test suite executed and passed cleanly.');
      } else {
        epistemic.known.push(`Automated tests failed with exit code ${verificationDetails.testRes.exitCode}: ${verificationDetails.testRes.stderr || 'Test failures'}`);
      }
    } else if (mission.successCriteria.testsPassed) {
      epistemic.known.push('Automated unit test suite executed and passed.');
    } else {
      epistemic.unknown.push('Automated test suite was not executed or unverified.');
    }

    if (verificationDetails?.securityViolations) {
      if (verificationDetails.securityViolations.length === 0) {
        epistemic.known.push('Security sanitizer scan reported 0 exposed secrets or credentials.');
      } else {
        epistemic.known.push(`Security violations detected: ${verificationDetails.securityViolations.join('; ')}`);
      }
    } else if (mission.successCriteria.securityPassed) {
      epistemic.known.push('Security sanitizer scan reported 0 exposed secrets or credentials.');
    } else {
      epistemic.unknown.push('Security audit scan unverified.');
    }

    // 5. Calculate verification score (0-100)
    let score = 0;
    const totalTasks = mission.tasks.length || 1;
    score += Math.round((mission.completedTasks.length / totalTasks) * 50);

    if (mission.successCriteria.typecheckPassed) score += 15;
    if (mission.successCriteria.testsPassed) score += 15;
    if (mission.successCriteria.buildPassed) score += 10;
    if (mission.successCriteria.securityPassed) score += 10;

    // Deduct for failures
    if (mission.failedTasks.length > 0) {
      score = Math.max(0, score - (mission.failedTasks.length * 20));
    }

    const approvals: string[] = [];
    if (mission.approvalGate?.approved) {
      approvals.push(`Authorized: ${mission.approvalGate.action} (${mission.approvalGate.reason})`);
    }

    return {
      missionId: mission.id,
      objective: mission.objective,
      planSummary: `Autonomous mission "${mission.title}" consisting of ${mission.tasks.length} DAG tasks.`,
      epistemicBreakdown: epistemic,
      tasksExecuted: mission.tasks.filter(t => t.status === 'COMPLETED' || t.status === 'FAILED').length,
      tasksVerified: mission.completedTasks.length,
      filesChanged: changedFiles,
      agentsInvolved: Array.from(agentsSet),
      commandsExecuted: Array.from(commandsSet),
      testResults: {
        total: mission.tasks.length,
        passed: mission.completedTasks.length,
        failed: mission.failedTasks.length,
        summary: `${mission.completedTasks.length}/${mission.tasks.length} task verification stages passed.`
      },
      typecheckResult: {
        passed: mission.successCriteria.typecheckPassed,
        errorCount: verificationDetails?.typecheckRes ? (verificationDetails.typecheckRes.exitCode === 0 ? 0 : 1) : (mission.successCriteria.typecheckPassed ? 0 : 1)
      },
      buildResult: {
        passed: mission.successCriteria.buildPassed,
        output: verificationDetails?.buildRes?.output || (mission.successCriteria.buildPassed ? 'Production bundle built cleanly.' : 'Build pending or failed.')
      },
      securityAudit: {
        passed: mission.successCriteria.securityPassed,
        violations: verificationDetails?.securityViolations || [],
        riskLevel: mission.riskLevel
      },
      repairsApplied: mission.budget.currentRepairAttempts,
      approvalsReceived: approvals,
      gitOperations: Array.from(gitOpsSet),
      verificationScore: score,
      finalStatus: mission.status,
      generatedAt: Date.now()
    };
  }
}
