/**
 * GODEX Phase 9 - Autonomous Engineering Mission System Types
 * Defines comprehensive data structures and contracts for long-running,
 * evidence-grounded, policy-governed autonomous engineering missions.
 */

import type { 
  OrchestrationTask, 
  TaskGraph, 
  AgentRoleType, 
  RiskLevel, 
  TaskStatus, 
  AgentArtifact 
} from '../orchestration/orchestrationTypes';
import { ContextPack } from '../intelligence/contextTypes';

export type { OrchestrationTask, TaskGraph, AgentRoleType, RiskLevel, TaskStatus, AgentArtifact };

export type MissionStatus =
  | 'DRAFT'
  | 'ANALYZING'
  | 'PLANNING'
  | 'READY'
  | 'EXECUTING'
  | 'WAITING_FOR_APPROVAL'
  | 'WAITING_FOR_INPUT'
  | 'RECOVERING'
  | 'REPLANNING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'BLOCKED'
  | 'CANCELLED'
  | 'PAUSED';

export type AutonomyLevel = 'ASSISTED' | 'CONTROLLED' | 'AUTONOMOUS';

export type MissionPriority = 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';

export type MissionFailureCategory =
  | 'SYNTAX'
  | 'TYPECHECK'
  | 'TEST'
  | 'BUILD'
  | 'SECURITY'
  | 'CONFLICT'
  | 'EXECUTION'
  | 'TIMEOUT'
  | 'UNKNOWN';

export interface TaskFailure {
  taskId: string;
  category?: MissionFailureCategory;
  errorMessage: string;
  timestamp: number;
  retryCount: number;
  loopDetected?: boolean;
  errorCode?: string;
  location?: string;
  symbol?: string;
}

export type MissionLifecycleStage =
  | 'REQUEST'
  | 'UNDERSTAND'
  | 'INSPECT'
  | 'PLAN'
  | 'DECOMPOSE'
  | 'SCHEDULE'
  | 'EXECUTE'
  | 'VERIFY'
  | 'RECOVER'
  | 'REPLAN'
  | 'FINAL_VERIFY'
  | 'COMPLETE'
  | 'FAILED'
  | 'BLOCKED'
  | 'PAUSED'
  | 'APPROVAL';

export interface CustomSuccessCriterion {
  id: string;
  description: string;
  verified: boolean;
  evidence?: string;
}

export interface MissionSuccessCriteria {
  typecheckPassed: boolean;
  testsPassed: boolean;
  buildPassed: boolean;
  securityPassed: boolean;
  noRegressions: boolean;
  gitStateExpected: boolean;
  customCriteria: CustomSuccessCriterion[];
}

export interface MissionBudget {
  maxTasks: number;
  maxRetries: number;
  maxFileMutations: number;
  maxExecutionTimeMs: number;
  maxAgentIterations: number;
  maxRepairAttempts: number;
  currentTasksCreated: number;
  currentRetries: number;
  currentFileMutations: number;
  currentExecutionTimeMs: number;
  currentAgentIterations: number;
  currentRepairAttempts: number;
}

export interface MissionProgress {
  verifiedTasksCount: number;
  completedTasksCount: number;
  totalTasksCount: number;
  percentage: number;
  currentTaskTitle?: string;
  currentTaskRole?: AgentRoleType;
  passedGatesCount: number;
  totalGatesCount: number;
  summary: string;
}

export interface EpistemicMissionKnowledge {
  known: string[];     // Confirmed from code, AST, tests
  likely: string[];    // High confidence inferences
  unknown: string[];   // Unverified external conditions or gaps
}

export interface MissionEvidence {
  missionId: string;
  objective: string;
  planSummary: string;
  epistemicBreakdown: EpistemicMissionKnowledge;
  tasksExecuted: number;
  tasksVerified: number;
  filesChanged: string[];
  agentsInvolved: AgentRoleType[];
  commandsExecuted: string[];
  testResults: {
    total: number;
    passed: number;
    failed: number;
    summary: string;
  };
  typecheckResult: {
    passed: boolean;
    errorCount: number;
  };
  buildResult: {
    passed: boolean;
    output?: string;
  };
  securityAudit: {
    passed: boolean;
    violations: string[];
    riskLevel: RiskLevel;
  };
  repairsApplied: number;
  approvalsReceived: string[];
  gitOperations: string[];
  verificationScore: number; // 0 to 100
  finalStatus: MissionStatus;
  generatedAt: number;
}

export interface MissionTimelineEvent {
  id: string;
  timestamp: number;
  stage: MissionLifecycleStage;
  agentRole?: AgentRoleType | 'ORCHESTRATOR' | 'SYSTEM' | 'HUMAN';
  title: string;
  description: string;
  status: 'info' | 'success' | 'warning' | 'error' | 'pending';
  evidenceRef?: string;
  metadata?: Record<string, any>;
}

export interface MissionApprovalGate {
  id: string;
  required: boolean;
  action: string;
  reason: string;
  riskLevel: RiskLevel;
  evidence: string;
  proposedDiff?: string;
  requestedAt: number;
  approved?: boolean;
  rejected?: boolean;
  decisionNotes?: string;
}

export interface MissionClarification {
  id: string;
  question: string;
  options?: string[];
  askedAt: number;
  answeredAt?: number;
  answer?: string;
}

export interface MissionFailureSummary {
  whyFailed: string;
  category?: MissionFailureCategory;
  whatCompleted: string[];
  whatFailed: string[];
  whatRolledBack: string[];
  whatRemains: string[];
  invalidatedTasks?: string[];
  recoveryStrategy?: string;
  suggestedPatchHint?: string;
}

export interface MissionLoopProtectionState {
  consecutiveFailures: number;
  repeatedTasks: Record<string, number>;
  repeatedFailures: Record<string, number>;
  oscillatingFiles: string[];
  lastPatchHashes: string[];
}

export interface Mission {
  id: string;
  missionId: string; // Alias for id
  title: string;
  objective: string;
  userIntent: string;
  createdAt: number;
  updatedAt: number;
  status: MissionStatus;
  priority: MissionPriority;
  autonomyLevel: AutonomyLevel;
  constraints: string[];
  successCriteria: MissionSuccessCriteria;
  tasks: OrchestrationTask[];
  taskGraph: TaskGraph;
  activeTaskId?: string;
  completedTasks: string[];
  failedTasks: string[];
  blockedTasks: string[];
  invalidatedTaskIds?: string[];
  lastFailureCategory?: MissionFailureCategory;
  lastRecoveryStrategy?: string;
  verificationStatus: 'UNVERIFIED' | 'VERIFYING' | 'VERIFIED' | 'FAILED';
  riskLevel: RiskLevel;
  progress: MissionProgress;
  evidence?: MissionEvidence;
  checkpoints: string[]; // Checkpoint IDs
  memoryReferences: string[]; // Memory entry IDs
  budget: MissionBudget;
  timeline: MissionTimelineEvent[];
  approvalGate?: MissionApprovalGate;
  clarification?: MissionClarification;
  failureSummary?: MissionFailureSummary;
  loopProtection: MissionLoopProtectionState;
  contextPackRef?: ContextPack;
}

export type MissionEventListener = (mission: Mission, event?: MissionTimelineEvent) => void;
