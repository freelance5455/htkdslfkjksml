/**
 * GODEX P1.4 — Mission Persistence Engine
 * Provides durable local persistence for Autonomous Engineering Missions.
 * Uses local storage / in-memory storage fallback with schema validation and integrity verification.
 * Zero external database or network dependencies.
 */

import { Mission, MissionStatus } from './missionTypes';
import { MissionStateMachine } from './missionState';

export interface MissionHistorySummary {
  id: string;
  title: string;
  objective: string;
  status: MissionStatus;
  createdAt: number;
  updatedAt: number;
  completedTasksCount: number;
  totalTasksCount: number;
  failedTasksCount: number;
  verificationScore: number;
  checkpointCount: number;
  resumable: boolean;
  lastFailureCategory?: string;
  lastRecoveryStrategy?: string;
  riskLevel: string;
}

export interface PersistencePayload {
  version: string;
  activeMissionId?: string;
  activeMission?: Mission;
  missionHistory: Mission[];
  savedAt: number;
}

export class MissionPersistenceEngine {
  private static readonly STORAGE_KEY = 'GODEX_MISSION_PERSISTENCE_V1';
  private static readonly SCHEMA_VERSION = '1.4.0';

  private static inMemoryStore: PersistencePayload = {
    version: MissionPersistenceEngine.SCHEMA_VERSION,
    missionHistory: [],
    savedAt: Date.now()
  };

  /**
   * Checks if browser localStorage is available safely.
   */
  private static isLocalStorageAvailable(): boolean {
    try {
      if (typeof window === 'undefined' || !window.localStorage) {
        return false;
      }
      const testKey = '__godex_storage_test__';
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Persists active mission and full mission history.
   */
  public static saveState(activeMission: Mission | null, history: Mission[]): void {
    const payload: PersistencePayload = {
      version: this.SCHEMA_VERSION,
      activeMissionId: activeMission?.id,
      activeMission: activeMission ? this.sanitizeForPersistence(activeMission) : undefined,
      missionHistory: history.map(m => this.sanitizeForPersistence(m)),
      savedAt: Date.now()
    };

    // Update in-memory fallback
    this.inMemoryStore = payload;

    // Persist to localStorage if available
    if (this.isLocalStorageAvailable()) {
      try {
        window.localStorage.setItem(this.STORAGE_KEY, JSON.stringify(payload));
      } catch (err) {
        console.warn('[MissionPersistenceEngine] Failed to write to localStorage:', err);
      }
    }
  }

  /**
   * Loads persisted state from localStorage or in-memory fallback.
   */
  public static loadState(): { activeMission: Mission | null; history: Mission[] } {
    let payload: PersistencePayload = this.inMemoryStore;

    if (this.isLocalStorageAvailable()) {
      try {
        const raw = window.localStorage.getItem(this.STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object' && parsed.version) {
            payload = parsed;
            this.inMemoryStore = parsed;
          }
        }
      } catch (err) {
        console.warn('[MissionPersistenceEngine] Failed to read from localStorage:', err);
      }
    }

    const validatedHistory: Mission[] = [];
    for (const m of payload.missionHistory || []) {
      const integrity = this.validateMissionIntegrity(m);
      if (integrity.valid && integrity.sanitizedMission) {
        validatedHistory.push(integrity.sanitizedMission);
      }
    }

    let activeMission: Mission | null = null;
    if (payload.activeMission) {
      const integrity = this.validateMissionIntegrity(payload.activeMission);
      if (integrity.valid && integrity.sanitizedMission) {
        activeMission = integrity.sanitizedMission;
      }
    }

    return {
      activeMission,
      history: validatedHistory
    };
  }

  /**
   * Saves a single mission into history and active state if applicable.
   */
  public static saveMission(mission: Mission, isActive = true): void {
    const { history } = this.loadState();
    const existingIndex = history.findIndex(h => h.id === mission.id);
    const sanitized = this.sanitizeForPersistence(mission);

    let updatedHistory: Mission[];
    if (existingIndex >= 0) {
      updatedHistory = [...history];
      updatedHistory[existingIndex] = sanitized;
    } else {
      updatedHistory = [sanitized, ...history];
    }

    this.saveState(isActive ? sanitized : null, updatedHistory);
  }

  /**
   * Loads a specific mission by ID from persistence.
   */
  public static loadMissionById(missionId: string): Mission | null {
    const { activeMission, history } = this.loadState();
    if (activeMission && activeMission.id === missionId) {
      return activeMission;
    }
    return history.find(m => m.id === missionId) || null;
  }

  /**
   * Clears persisted missions.
   */
  public static clearPersistence(): void {
    this.inMemoryStore = {
      version: this.SCHEMA_VERSION,
      missionHistory: [],
      savedAt: Date.now()
    };

    if (this.isLocalStorageAvailable()) {
      try {
        window.localStorage.removeItem(this.STORAGE_KEY);
      } catch (err) {
        console.warn('[MissionPersistenceEngine] Failed to remove storage key:', err);
      }
    }
  }

  /**
   * Validates structural and DAG integrity of a persisted mission.
   * Catches corrupted states, cycle errors, orphaned tasks, or broken transitions.
   */
  public static validateMissionIntegrity(mission: any): {
    valid: boolean;
    errors: string[];
    sanitizedMission?: Mission;
  } {
    const errors: string[] = [];

    if (!mission || typeof mission !== 'object') {
      return { valid: false, errors: ['Mission is not a valid object'] };
    }

    if (!mission.id || typeof mission.id !== 'string') {
      errors.push('Mission missing valid string id');
    }

    if (!mission.status || typeof mission.status !== 'string') {
      errors.push('Mission missing valid status');
    }

    if (!Array.isArray(mission.tasks)) {
      errors.push('Mission tasks must be an array');
    }

    if (errors.length > 0) {
      return { valid: false, errors };
    }

    // Validate tasks & DAG consistency
    const taskIds = new Set<string>();
    for (const task of mission.tasks) {
      if (!task.id || typeof task.id !== 'string') {
        errors.push('Task found with missing id');
        continue;
      }
      taskIds.add(task.id);
    }

    // Check task dependencies
    for (const task of mission.tasks) {
      if (Array.isArray(task.dependencies)) {
        for (const dep of task.dependencies) {
          const depId = typeof dep === 'string' ? dep : dep?.taskId;
          if (!depId || !taskIds.has(depId)) {
            errors.push(`Task "${task.id}" has invalid dependency on non-existent task "${depId}"`);
          }
        }
      }
    }

    // Check completedTasks consistency
    const completedSet = new Set<string>(Array.isArray(mission.completedTasks) ? mission.completedTasks.map((x: any) => String(x)) : []);
    for (const completedId of completedSet) {
      if (!taskIds.has(completedId)) {
        errors.push(`Completed task "${completedId}" does not exist in mission tasks`);
      }
    }

    // Sanitize missing arrays/objects to prevent null pointer exceptions
    const sanitized: Mission = {
      id: mission.id,
      missionId: mission.missionId || mission.id,
      title: mission.title || 'Untitled Mission',
      objective: mission.objective || '',
      userIntent: mission.userIntent || mission.objective || '',
      createdAt: typeof mission.createdAt === 'number' ? mission.createdAt : Date.now(),
      updatedAt: typeof mission.updatedAt === 'number' ? mission.updatedAt : Date.now(),
      status: mission.status,
      priority: mission.priority || 'NORMAL',
      autonomyLevel: mission.autonomyLevel || 'CONTROLLED',
      constraints: Array.isArray(mission.constraints) ? mission.constraints : [],
      successCriteria: mission.successCriteria || {
        typecheckPassed: false,
        testsPassed: false,
        buildPassed: false,
        securityPassed: false,
        noRegressions: true,
        gitStateExpected: true,
        customCriteria: []
      },
      tasks: mission.tasks.map((t: any) => ({
        id: t.id,
        title: t.title || 'Untitled Task',
        description: t.description || '',
        role: t.role || 'CODER',
        priority: t.priority || 'NORMAL',
        risk: t.risk || 'LOW',
        status: t.status || 'QUEUED',
        dependencies: Array.isArray(t.dependencies) ? t.dependencies : [],
        targetFiles: Array.isArray(t.targetFiles) ? t.targetFiles : [],
        artifactsProduced: Array.isArray(t.artifactsProduced) ? t.artifactsProduced : [],
        attemptCount: typeof t.attemptCount === 'number' ? t.attemptCount : 0,
        maxRetries: typeof t.maxRetries === 'number' ? t.maxRetries : 2,
        createdAt: typeof t.createdAt === 'number' ? t.createdAt : Date.now(),
        startedAt: t.startedAt,
        completedAt: t.completedAt,
        error: t.error,
        statusMessage: t.statusMessage,
        executionEvidence: t.executionEvidence,
        approved: t.approved
      })),
      taskGraph: mission.taskGraph || { tasks: mission.tasks, dependencies: [] },
      activeTaskId: mission.activeTaskId,
      completedTasks: Array.from(completedSet),
      failedTasks: Array.isArray(mission.failedTasks) ? mission.failedTasks.map((x: any) => String(x)) : [],
      blockedTasks: Array.isArray(mission.blockedTasks) ? mission.blockedTasks.map((x: any) => String(x)) : [],
      invalidatedTaskIds: Array.isArray(mission.invalidatedTaskIds) ? mission.invalidatedTaskIds.map((x: any) => String(x)) : [],
      lastFailureCategory: mission.lastFailureCategory,
      lastRecoveryStrategy: mission.lastRecoveryStrategy,
      verificationStatus: mission.verificationStatus || 'UNVERIFIED',
      riskLevel: mission.riskLevel || 'LOW',
      progress: mission.progress || {
        verifiedTasksCount: 0,
        completedTasksCount: completedSet.size,
        totalTasksCount: mission.tasks.length,
        percentage: 0,
        passedGatesCount: 0,
        totalGatesCount: 0,
        summary: 'Mission state loaded from persistence'
      },
      evidence: mission.evidence,
      checkpoints: Array.isArray(mission.checkpoints) ? mission.checkpoints : [],
      memoryReferences: Array.isArray(mission.memoryReferences) ? mission.memoryReferences : [],
      budget: mission.budget || {
        maxTasks: 30,
        maxRetries: 3,
        maxFileMutations: 20,
        maxExecutionTimeMs: 600000,
        maxAgentIterations: 50,
        maxRepairAttempts: 5,
        currentTasksCreated: mission.tasks.length,
        currentRetries: 0,
        currentFileMutations: 0,
        currentExecutionTimeMs: 0,
        currentAgentIterations: 0,
        currentRepairAttempts: 0
      },
      timeline: Array.isArray(mission.timeline) ? mission.timeline : [],
      approvalGate: mission.approvalGate,
      clarification: mission.clarification,
      failureSummary: mission.failureSummary,
      loopProtection: mission.loopProtection || {
        consecutiveFailures: 0,
        repeatedTasks: {},
        repeatedFailures: {},
        oscillatingFiles: [],
        lastPatchHashes: []
      }
    };

    return {
      valid: errors.length === 0,
      errors,
      sanitizedMission: sanitized
    };
  }

  /**
   * Generates lightweight summary objects for historical mission browsing.
   */
  public static getHistorySummaries(): MissionHistorySummary[] {
    const { history } = this.loadState();
    return history.map(m => {
      const isResumable = ['PAUSED', 'READY', 'WAITING_FOR_APPROVAL', 'REPLANNING', 'BLOCKED'].includes(m.status);
      const score = m.evidence?.verificationScore ?? (
        m.status === 'COMPLETED' ? 100 : Math.round((m.completedTasks.length / (m.tasks.length || 1)) * 50)
      );

      return {
        id: m.id,
        title: m.title,
        objective: m.objective,
        status: m.status,
        createdAt: m.createdAt,
        updatedAt: m.updatedAt,
        completedTasksCount: m.completedTasks.length,
        totalTasksCount: m.tasks.length,
        failedTasksCount: m.failedTasks.length,
        verificationScore: score,
        checkpointCount: m.checkpoints.length,
        resumable: isResumable,
        lastFailureCategory: m.lastFailureCategory,
        lastRecoveryStrategy: m.lastRecoveryStrategy,
        riskLevel: m.riskLevel
      };
    });
  }

  /**
   * Strips deep non-serializable objects or excessive temporary structures.
   */
  private static sanitizeForPersistence(mission: Mission): Mission {
    return JSON.parse(JSON.stringify(mission));
  }
}
