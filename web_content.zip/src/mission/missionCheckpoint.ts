/**
 * GODEX Phase 9 - Mission Checkpoint Coordinator
 * Reuses Phase 3 RollbackManager to capture pre-mutation and pre-operation snapshots
 * for entire mission milestones, high-risk refactors, and Git merges.
 */

import { RollbackManager, TaskCheckpoint } from '../coding/rollbackManager';
import { Mission } from './missionTypes';

export interface MissionCheckpointMetadata {
  id: string;
  missionId: string;
  taskId?: string;
  title: string;
  reason: string;
  timestamp: number;
  filesCount: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export class MissionCheckpointCoordinator {
  private static missionCheckpoints: Map<string, MissionCheckpointMetadata[]> = new Map();

  /**
   * Captures a mission milestone checkpoint using RollbackManager.
   */
  public static captureCheckpoint(
    mission: Mission,
    title: string,
    reason: string,
    files: Record<string, string>,
    taskId?: string
  ): MissionCheckpointMetadata {
    const internalTaskId = taskId || `mission-${mission.id}-${Date.now()}`;
    const cp = RollbackManager.createCheckpoint(internalTaskId, `[Mission: ${mission.title}] ${title} - ${reason}`, files);

    const meta: MissionCheckpointMetadata = {
      id: cp.id,
      missionId: mission.id,
      taskId: internalTaskId,
      title,
      reason,
      timestamp: Date.now(),
      filesCount: Object.keys(files).length,
      riskLevel: mission.riskLevel
    };

    if (!this.missionCheckpoints.has(mission.id)) {
      this.missionCheckpoints.set(mission.id, []);
    }
    const list = this.missionCheckpoints.get(mission.id)!;
    list.unshift(meta);

    if (!mission.checkpoints.includes(cp.id)) {
      mission.checkpoints.unshift(cp.id);
    }

    return meta;
  }

  /**
   * Rolls back a mission checkpoint.
   */
  public static rollbackCheckpoint(
    checkpointId: string,
    currentFiles: Record<string, string>
  ): { success: boolean; restoredFiles: Record<string, string>; message: string } {
    const rawCheckpoints = RollbackManager.getCheckpoints();
    const target = rawCheckpoints.find(c => c.id === checkpointId);
    if (!target) {
      return {
        success: false,
        restoredFiles: currentFiles,
        message: `Checkpoint ${checkpointId} not found in RollbackManager.`
      };
    }

    return RollbackManager.rollbackTask(target.taskId, currentFiles);
  }

  /**
   * Gets all checkpoints for a mission.
   */
  public static getCheckpointsForMission(missionId: string): MissionCheckpointMetadata[] {
    return this.missionCheckpoints.get(missionId) || [];
  }
}
