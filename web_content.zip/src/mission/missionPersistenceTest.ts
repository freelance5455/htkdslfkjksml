/**
 * GODEX Phase 1.4 — Mission Persistence, Safe Resume & Release Verifier Verification Suite
 * Tests durable persistence, crash-safe resume, duplicate mutation prevention,
 * schema migration/integrity, and 7-pillar release readiness.
 */

import { MissionPersistenceEngine } from './missionPersistence';
import { MissionResumeEngine } from './missionResumeValidator';
import { MissionReleaseVerifier } from './missionReleaseVerifier';
import { Mission, OrchestrationTask } from './missionTypes';
import { ConflictManager } from '../orchestration/conflictManager';

export async function runPersistenceAndResumeTests(): Promise<{ passed: number; failed: number; results: Array<{ name: string; passed: boolean; error?: string }> }> {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  let passed = 0;
  let failed = 0;

  function assert(name: string, condition: boolean, errorDetail?: string) {
    if (condition) {
      passed++;
      results.push({ name, passed: true });
    } else {
      failed++;
      results.push({ name, passed: false, error: errorDetail || 'Assertion failed' });
    }
  }

  // Helper: create mock mission
  function createTestMission(id: string, status: any = 'EXECUTING'): Mission {
    const task1: OrchestrationTask = {
      id: `task-1-${id}`,
      title: 'Initialize Module',
      description: 'Setup files',
      role: 'ARCHITECT',
      priority: 'NORMAL',
      risk: 'LOW',
      status: 'COMPLETED',
      dependencies: [],
      targetFiles: ['src/app.ts'],
      artifactsProduced: [],
      attemptCount: 1,
      maxRetries: 3,
      createdAt: Date.now() - 10000,
      completedAt: Date.now() - 8000
    };

    const task2: OrchestrationTask = {
      id: `task-2-${id}`,
      title: 'Implement Feature',
      description: 'Write logic',
      role: 'CODER',
      priority: 'NORMAL',
      risk: 'LOW',
      status: 'RUNNING', // In-flight when crash happened
      dependencies: [{ taskId: `task-1-${id}`, type: 'HARD' }],
      targetFiles: ['src/feature.ts'],
      artifactsProduced: [],
      attemptCount: 1,
      maxRetries: 3,
      createdAt: Date.now() - 8000,
      startedAt: Date.now() - 7000
    };

    const task3: OrchestrationTask = {
      id: `task-3-${id}`,
      title: 'Run Tests',
      description: 'Verify tests',
      role: 'TESTER',
      priority: 'NORMAL',
      risk: 'LOW',
      status: 'QUEUED',
      dependencies: [{ taskId: `task-2-${id}`, type: 'HARD' }],
      targetFiles: ['src/feature.test.ts'],
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 3,
      createdAt: Date.now() - 8000
    };

    return {
      id,
      missionId: id,
      title: 'Test Engineering Mission',
      objective: 'Build scalable feature',
      userIntent: 'Build scalable feature',
      priority: 'NORMAL',
      autonomyLevel: 'CONTROLLED',
      constraints: [],
      status,
      tasks: [task1, task2, task3],
      taskGraph: {
        nodes: {
          [task1.id]: { task: task1, children: [task2.id], parents: [] },
          [task2.id]: { task: task2, children: [task3.id], parents: [task1.id] },
          [task3.id]: { task: task3, children: [], parents: [task2.id] }
        },
        rootTaskIds: [task1.id],
        leafTaskIds: [task3.id],
        totalTasks: 3,
        completedTasks: 1,
        isCyclic: false
      },
      completedTasks: [`task-1-${id}`],
      failedTasks: [],
      blockedTasks: [],
      invalidatedTaskIds: [],
      activeTaskId: `task-2-${id}`,
      verificationStatus: 'UNVERIFIED',
      createdAt: Date.now() - 10000,
      updatedAt: Date.now(),
      progress: {
        percentage: 33,
        completedTasksCount: 1,
        totalTasksCount: 3,
        verifiedTasksCount: 1,
        passedGatesCount: 0,
        totalGatesCount: 0,
        summary: 'Progress initialized'
      },
      budget: {
        maxExecutionTimeMs: 120000,
        currentExecutionTimeMs: 5000,
        maxRetries: 3,
        currentRetries: 0,
        maxTasks: 10,
        maxFileMutations: 10,
        maxAgentIterations: 10,
        maxRepairAttempts: 3,
        currentTasksCreated: 3,
        currentFileMutations: 0,
        currentAgentIterations: 0,
        currentRepairAttempts: 0
      },
      checkpoints: [],
      timeline: [],
      memoryReferences: [],
      riskLevel: 'LOW',
      loopProtection: {
        consecutiveFailures: 0,
        repeatedTasks: {},
        repeatedFailures: {},
        oscillatingFiles: [],
        lastPatchHashes: []
      },
      successCriteria: {
        typecheckPassed: false,
        buildPassed: false,
        testsPassed: false,
        securityPassed: true,
        noRegressions: true,
        gitStateExpected: true,
        customCriteria: []
      }
    };
  }

  // --- Test 1: Persistence Save and Load ---
  try {
    MissionPersistenceEngine.clearPersistence();
    const testMission = createTestMission('m-pers-1');
    MissionPersistenceEngine.saveMission(testMission, true);

    const loaded = MissionPersistenceEngine.loadState();
    assert(
      'P1.4.1 - MissionPersistenceEngine saves and loads active mission',
      loaded.activeMission?.id === 'm-pers-1' && loaded.history.length === 1,
      `Expected active mission m-pers-1, got ${loaded.activeMission?.id}`
    );
  } catch (err: any) {
    assert('P1.4.1 - MissionPersistenceEngine save/load', false, err.message);
  }

  // --- Test 2: Integrity Validation Rejects Corrupted Payloads ---
  try {
    const invalidMission: any = { id: 'bad-mission' }; // missing required fields
    const integrity = MissionPersistenceEngine.validateMissionIntegrity(invalidMission);
    assert(
      'P1.4.2 - validateMissionIntegrity correctly flags structurally invalid missions',
      integrity.valid === false,
      'Expected invalid mission to be rejected'
    );
  } catch (err: any) {
    assert('P1.4.2 - validateMissionIntegrity', false, err.message);
  }

  // --- Test 3: Safe Resume Engine Sanitizes Interrupted Missions ---
  try {
    const interruptedMission = createTestMission('m-interrupted-1', 'EXECUTING');
    // Lock a file in ConflictManager to simulate an in-flight mutation
    const cm = new ConflictManager();
    cm.acquireLock('src/feature.ts', 'FILE', 'task-2-m-interrupted-1', 'coder-agent', 'CODER', 'fp1');

    const resumeResult = MissionResumeEngine.validateAndPrepareForResume(interruptedMission, {
      'src/app.ts': 'export const a = 1;',
      'src/feature.ts': 'export const b = 2;'
    });

    const sanitized = resumeResult.sanitizedMission;
    const task2 = sanitized.tasks.find(t => t.id === 'task-2-m-interrupted-1');

    assert(
      'P1.4.3 - MissionResumeEngine transitions EXECUTING to PAUSED on resume check',
      sanitized.status === 'PAUSED',
      `Expected PAUSED status, got ${sanitized.status}`
    );

    assert(
      'P1.4.4 - MissionResumeEngine resets interrupted RUNNING tasks to READY',
      task2?.status === 'READY',
      `Expected task2 to be READY, got ${task2?.status}`
    );

    assert(
      'P1.4.5 - MissionResumeEngine strictly preserves completed tasks',
      sanitized.completedTasks.includes('task-1-m-interrupted-1') &&
      sanitized.tasks.find(t => t.id === 'task-1-m-interrupted-1')?.status === 'COMPLETED',
      'Completed tasks were mutated'
    );

    assert(
      'P1.4.6 - MissionResumeEngine validates safe resume capability',
      resumeResult.canResume === true,
      'Safe resume check failed'
    );
  } catch (err: any) {
    assert('P1.4.3-P1.4.6 - Safe Resume Sanitization', false, err.message);
  }

  // --- Test 4: Duplicate Task Execution Protection ---
  try {
    const mission = createTestMission('m-dup-test');
    const isDup = !MissionResumeEngine.verifyTaskNotDuplicate(mission, 'task-1-m-dup-test');
    const notDup = MissionResumeEngine.verifyTaskNotDuplicate(mission, 'task-2-m-dup-test');

    assert(
      'P1.4.7 - verifyTaskNotDuplicate blocks duplicate execution of already-completed tasks',
      isDup === true && notDup === true,
      'Duplicate task execution check failed'
    );
  } catch (err: any) {
    assert('P1.4.7 - Duplicate task protection', false, err.message);
  }

  // --- Test 5: History Summaries and Resumability Flag ---
  try {
    const pausedMission = createTestMission('m-paused', 'PAUSED');
    const completedMission = createTestMission('m-completed', 'COMPLETED');
    MissionPersistenceEngine.saveMission(pausedMission);
    MissionPersistenceEngine.saveMission(completedMission);

    const summaries = MissionPersistenceEngine.getHistorySummaries();
    const pausedSummary = summaries.find(s => s.id === 'm-paused');
    const completedSummary = summaries.find(s => s.id === 'm-completed');

    assert(
      'P1.4.8 - getHistorySummaries marks PAUSED/BLOCKED as resumable and COMPLETED as non-resumable',
      pausedSummary?.resumable === true && completedSummary?.resumable === false,
      'Resumability flags in history summaries were incorrect'
    );
  } catch (err: any) {
    assert('P1.4.8 - History summaries', false, err.message);
  }

  // --- Test 6: 7-Pillars Release Verifier ---
  try {
    const mission = createTestMission('m-release-test');
    const files = {
      'src/index.ts': 'export const msg: string = "hello";',
      'src/math.ts': 'export function add(a: number, b: number): number { return a + b; }'
    };

    const report = await MissionReleaseVerifier.verifyReleaseReadiness(mission, files);
    
    assert(
      'P1.4.9 - MissionReleaseVerifier audits all 7 verification pillars',
      Object.keys(report.pillarResults).length === 7,
      `Expected 7 pillars, got ${Object.keys(report.pillarResults).length}`
    );

    assert(
      'P1.4.10 - MissionReleaseVerifier verifies AST integrity across workspace files',
      report.pillarResults.astIntegrity.passed === true,
      'AST integrity pillar check failed'
    );

    assert(
      'P1.4.11 - MissionReleaseVerifier enforces Epistemic Honesty (no fake score fabrication)',
      report.overallScore >= 0 && report.overallScore <= 100,
      'Epistemic verification score out of bounds'
    );
  } catch (err: any) {
    assert('P1.4.9-P1.4.11 - Release Verifier', false, err.message);
  }

  return { passed, failed, results };
}

// Standalone execution if run directly via tsx
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('missionPersistenceTest')) {
  runPersistenceAndResumeTests().then(({ passed, failed, results }) => {
    console.log(`\n=== GODEX P1.4 PERSISTENCE & RESUME SUITE RESULTS: ${passed}/${passed + failed} PASSED ===\n`);
    results.forEach(r => {
      console.log(`[${r.passed ? 'PASS' : 'FAIL'}] ${r.name} ${r.error ? `(${r.error})` : ''}`);
    });
    if (failed > 0) process.exit(1);
  });
}
