/**
 * GODEX Phase 9 - Mission Memory Connector
 * Reuses Phase 7 EngineeringMemoryEngine to ground mission planning in durable historical knowledge,
 * and records verified architectural decisions, repairs, and verification evidence upon mission completion.
 * 
 * CORE PRINCIPLE: HISTORY ≠ TRUTH. Current source and AST always take precedence.
 */

import { Mission, TaskFailure } from './missionTypes';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';
import { EngineeringMemoryEntry, MemoryTrustLevel } from '../memory/memoryTypes';
import { CandidateRepair } from '../memory/repairMemory';
import { MemoryInvalidationEngine } from '../memory/memoryInvalidation';

export interface RetrievedMissionMemoryItem {
  record: EngineeringMemoryEntry;
  whyThisMemory: string;
  trustLevel: MemoryTrustLevel;
  advisoryNote: string;
}

export interface RetrievedMissionMemory {
  decisions: RetrievedMissionMemoryItem[];
  verifiedSuccesses: RetrievedMissionMemoryItem[];
  failures: RetrievedMissionMemoryItem[];
  repairs: RetrievedMissionMemoryItem[];
  securityEvents: RetrievedMissionMemoryItem[];
  advisorySummary: string;
}

export interface RepairAdvisoryContext {
  foundCandidates: boolean;
  candidates: CandidateRepair[];
  rationale: string;
  advisoryWarning: string;
}

export class MissionMemoryConnector {
  /**
   * Retrieves relevant historical memory to inform mission planning.
   * STRICT INVARIANT: Memory is strictly ADVISORY. Current workspace evidence always takes precedence.
   */
  public static retrievePlanningContext(
    objective: string, 
    targetFiles: string[] = [],
    affectedSymbols: string[] = []
  ): RetrievedMissionMemory {
    const result: RetrievedMissionMemory = {
      decisions: [],
      verifiedSuccesses: [],
      failures: [],
      repairs: [],
      securityEvents: [],
      advisorySummary: 'Historical memory is strictly advisory. Current workspace AST, types, and tests take absolute priority.'
    };

    try {
      const memory = EngineeringMemoryEngine.getInstance();
      
      // 1. Query Decisions & Architectural Decisions
      const decisionResults = memory.queryContextPackMemories({
        objective,
        targetFiles,
        affectedSymbols,
        role: 'ARCHITECT',
        maxResults: 6
      }).filter(r => r.memory.type === 'DECISION' || r.memory.type === 'ARCHITECTURAL_DECISION' || r.memory.type === 'ARCHITECTURE');

      decisionResults.slice(0, 3).forEach(d => {
        result.decisions.push({
          record: d.memory,
          whyThisMemory: d.whyIncluded || `Prior decision "${d.memory.content}" relates to active objective/files.`,
          trustLevel: d.memory.trustLevel || 'ADVISORY',
          advisoryNote: 'Advisory guidance. Re-verify with active codebase.'
        });
      });

      // 2. Query Verified Successes
      const successResults = memory.queryContextPackMemories({
        objective,
        targetFiles,
        affectedSymbols,
        role: 'CODER',
        maxResults: 5
      }).filter(r => r.memory.type === 'VERIFIED_SUCCESS' || r.memory.type === 'MISSION_OUTCOME');

      successResults.slice(0, 3).forEach(s => {
        result.verifiedSuccesses.push({
          record: s.memory,
          whyThisMemory: s.whyIncluded || `Prior verified success for "${s.memory.content}".`,
          trustLevel: s.memory.trustLevel || 'VERIFIED',
          advisoryNote: 'Verified historical outcome. Validate against current file signatures.'
        });
      });

      // 3. Query Failures
      const failureResults = memory.queryContextPackMemories({
        objective,
        targetFiles,
        affectedSymbols,
        role: 'DEBUGGER',
        maxResults: 5
      }).filter(r => r.memory.type === 'FAILURE');

      failureResults.slice(0, 3).forEach(f => {
        result.failures.push({
          record: f.memory,
          whyThisMemory: f.whyIncluded || `Historical failure "${f.memory.failureDetails?.errorMessage || f.memory.content}" could recur.`,
          trustLevel: f.memory.trustLevel || 'ADVISORY',
          advisoryNote: 'Watch out for this historical failure pattern.'
        });
      });

      // 4. Query Repairs
      const repairResults = memory.queryContextPackMemories({
        targetFiles,
        affectedSymbols,
        role: 'DEBUGGER',
        maxResults: 5
      }).filter(r => r.memory.type === 'REPAIR');

      repairResults.slice(0, 3).forEach(r => {
        result.repairs.push({
          record: r.memory,
          whyThisMemory: r.whyIncluded || `Historical repair #${r.memory.id} touched similar files/symbols.`,
          trustLevel: r.memory.trustLevel || 'ADVISORY',
          advisoryNote: 'Candidate repair pattern. Must be independently re-verified.'
        });
      });

      // 5. Query Security Events
      const securityResults = memory.search({
        types: ['SECURITY_EVENT'],
        query: objective
      });
      securityResults.slice(0, 2).forEach(s => {
        result.securityEvents.push({
          record: s.memory,
          whyThisMemory: `Security boundary: ${s.memory.content}`,
          trustLevel: s.memory.trustLevel || 'VERIFIED',
          advisoryNote: 'Mandatory security constraint.'
        });
      });

    } catch (err) {
      console.warn('[MissionMemoryConnector] Safe fallback on retrieval:', err);
    }

    return result;
  }

  /**
   * Retrieves historical candidate repairs for an active failure.
   */
  public static retrieveRepairContext(
    failure: TaskFailure,
    targetFiles: string[] = [],
    affectedSymbols: string[] = []
  ): RepairAdvisoryContext {
    try {
      const memory = EngineeringMemoryEngine.getInstance();
      const rawCandidates = memory.findCandidateRepairs(
        failure.errorCode,
        targetFiles[0],
        affectedSymbols[0]
      );

      if (rawCandidates.length > 0) {
        return {
          foundCandidates: true,
          candidates: rawCandidates.slice(0, 3),
          rationale: `Found ${rawCandidates.length} historical repair pattern(s) matching error ${failure.errorCode || 'signature'}.`,
          advisoryWarning: 'Historical repairs are strictly advisory. Any proposed fix must pass live compiler, typecheck, and test gates.'
        };
      }
    } catch {
      // Safe fallback
    }

    return {
      foundCandidates: false,
      candidates: [],
      rationale: 'No previous historical repair found for this error signature.',
      advisoryWarning: 'Proceeding with first-principles autonomous diagnostic and repair.'
    };
  }

  /**
   * Records a verified successful task or mission outcome with cryptographic fingerprints.
   */
  public static persistVerifiedSuccess(params: {
    missionId: string;
    taskId?: string;
    title: string;
    files: string[];
    fileContents?: Record<string, string>;
    symbols?: string[];
    evidence: string[];
    confidence?: number;
  }): EngineeringMemoryEntry | null {
    // Invariant: Never store verified without concrete evidence
    if (!params.evidence || params.evidence.length === 0) {
      console.warn('[MissionMemoryConnector] Invariant rejection: Cannot persist verified success without evidence.');
      return null;
    }

    try {
      const memory = EngineeringMemoryEngine.getInstance();
      const fingerprints: Record<string, string> = {};
      if (params.fileContents) {
        Object.entries(params.fileContents).forEach(([path, code]) => {
          fingerprints[path] = MemoryInvalidationEngine.hashContent(code);
        });
      }

      const entry = memory.recordDecision({
        title: `[Verified Success] ${params.title}`,
        decision: `Successfully executed and verified task within mission ${params.missionId}.`,
        reason: 'Passed all verification gates and assertions.',
        evidence: params.evidence,
        relatedFiles: params.files,
        relatedSymbols: params.symbols || [],
        epistemicStatus: 'KNOWN',
        confidence: params.confidence ?? 1.0,
        metadata: {
          sourceMissionId: params.missionId,
          sourceTaskId: params.taskId,
          verificationStatus: 'VERIFIED',
          trustLevel: 'VERIFIED',
          fileFingerprints: fingerprints
        }
      });

      // Update trustLevel and fingerprints on the entry directly
      memory.getStore().updateEntry(entry.id, {
        trustLevel: 'VERIFIED',
        verificationStatus: 'VERIFIED',
        sourceMissionId: params.missionId,
        sourceTaskId: params.taskId,
        fileFingerprints: fingerprints
      });

      return memory.getStore().getEntry(entry.id);
    } catch (err) {
      console.warn('[MissionMemoryConnector] Error persisting verified success:', err);
      return null;
    }
  }

  /**
   * Persists a task or mission failure for historical memory grounding.
   */
  public static persistFailure(params: {
    missionId: string;
    taskId?: string;
    errorCode?: string;
    errorMessage: string;
    category?: string;
    files: string[];
    symbols?: string[];
    rootCause?: string;
  }): EngineeringMemoryEntry | null {
    try {
      const memory = EngineeringMemoryEngine.getInstance();
      const entry = memory.recordFailure({
        errorCode: params.errorCode || 'ERR_TASK_FAILURE',
        errorMessage: params.errorMessage,
        relatedFiles: params.files,
        symbol: params.symbols?.[0],
        category: params.category || 'EXECUTION_FAILURE',
        rootCause: params.rootCause,
        task: params.taskId,
        metadata: {
          sourceMissionId: params.missionId,
          sourceTaskId: params.taskId,
          failureSignature: `${params.errorCode || 'ERR'}:${params.errorMessage.slice(0, 60)}`
        }
      });

      memory.getStore().updateEntry(entry.id, {
        sourceMissionId: params.missionId,
        sourceTaskId: params.taskId,
        failureCategory: params.category,
        failureSignature: `${params.errorCode || 'ERR'}:${params.errorMessage.slice(0, 60)}`,
        trustLevel: 'ADVISORY'
      });

      return memory.getStore().getEntry(entry.id);
    } catch (err) {
      console.warn('[MissionMemoryConnector] Error persisting failure:', err);
      return null;
    }
  }

  /**
   * Selectively persists durable engineering decisions and verification outcomes into memory.
   */
  public static persistMissionOutcomes(
    mission: Mission, 
    fileContents?: Record<string, string>
  ): string[] {
    const memory = EngineeringMemoryEngine.getInstance();
    const createdMemoryIds: string[] = [];

    try {
      const fingerprints: Record<string, string> = {};
      if (fileContents && mission.evidence?.filesChanged) {
        mission.evidence.filesChanged.forEach(f => {
          if (fileContents[f]) {
            fingerprints[f] = MemoryInvalidationEngine.hashContent(fileContents[f]);
          }
        });
      }

      // 1. Record architectural decision / outcome if mission was completed successfully
      if (mission.status === 'COMPLETED') {
        const decisionEntry = memory.recordDecision({
          title: `Mission Completed: ${mission.title}`,
          decision: `Completed engineering mission with ${mission.completedTasks.length} tasks and ${mission.progress.passedGatesCount} verification gates passed.`,
          reason: mission.objective,
          evidence: [mission.id, `score:${mission.evidence?.verificationScore || 100}`, `gates:${mission.progress.passedGatesCount}`],
          relatedFiles: mission.evidence?.filesChanged || [],
          relatedSymbols: [],
          epistemicStatus: 'KNOWN',
          confidence: 0.98
        });

        memory.getStore().updateEntry(decisionEntry.id, {
          trustLevel: 'VERIFIED',
          sourceMissionId: mission.id,
          fileFingerprints: fingerprints,
          verificationStatus: 'VERIFIED'
        });

        createdMemoryIds.push(decisionEntry.id);
      }

      // 2. Record verification entry
      if (mission.evidence) {
        const verifEntry = memory.recordVerification({
          verificationType: 'EXECUTION',
          passed: mission.status === 'COMPLETED',
          exitCode: mission.status === 'COMPLETED' ? 0 : 1,
          evidenceId: mission.id,
          durationMs: mission.budget.currentExecutionTimeMs,
          summary: `Mission "${mission.title}" verification score: ${mission.evidence.verificationScore}/100 with ${mission.progress.passedGatesCount} passed gates`,
          metadata: {
            sourceMissionId: mission.id,
            tasksExecuted: mission.evidence.tasksExecuted,
            verificationScore: mission.evidence.verificationScore
          }
        });

        memory.getStore().updateEntry(verifEntry.id, {
          trustLevel: mission.status === 'COMPLETED' ? 'VERIFIED' : 'ADVISORY',
          sourceMissionId: mission.id,
          verificationStatus: mission.status === 'COMPLETED' ? 'VERIFIED' : 'FAILED'
        });

        createdMemoryIds.push(verifEntry.id);
      }
    } catch (err) {
      console.warn('[MissionMemoryConnector] Memory persistence warning:', err);
    }

    return createdMemoryIds;
  }
}
