/**
 * GODEX Phase 9 - Mission Progress & Risk Calculation Engine
 * Strictly derives progress and risk from real task states, test results,
 * execution evidence, and verification gates. Never fabricates progress.
 */

import { Mission, MissionProgress, MissionSuccessCriteria } from './missionTypes';
import { RiskLevel } from '../orchestration/orchestrationTypes';

export class MissionProgressEngine {
  /**
   * Recalculates truthful progress metrics for a mission.
   */
  public static calculateProgress(mission: Mission): MissionProgress {
    const totalTasks = mission.tasks.length;
    const completedTasks = mission.completedTasks.length;
    
    // Calculate verified tasks (completed + passed evidence)
    const verifiedTasks = mission.tasks.filter(t => 
      t.status === 'COMPLETED' && (t.executionEvidence?.exitCode === 0 || t.artifactsProduced.length > 0)
    ).length;

    // Calculate verification gates
    const gates = mission.successCriteria;
    let totalGates = 5 + (gates.customCriteria ? gates.customCriteria.length : 0);
    let passedGates = 0;

    if (gates.typecheckPassed) passedGates++;
    if (gates.testsPassed) passedGates++;
    if (gates.buildPassed) passedGates++;
    if (gates.securityPassed) passedGates++;
    if (gates.noRegressions) passedGates++;
    if (gates.gitStateExpected) {
      totalGates++;
      passedGates++;
    }

    if (gates.customCriteria) {
      gates.customCriteria.forEach(c => {
        if (c.verified) passedGates++;
      });
    }

    // Weight tasks 70% and verification gates 30%
    let percentage = 0;
    if (totalTasks > 0) {
      const taskFraction = completedTasks / totalTasks;
      const gateFraction = totalGates > 0 ? passedGates / totalGates : 1;
      
      if (mission.status === 'COMPLETED') {
        percentage = 100;
      } else if (completedTasks === 0) {
        percentage = 0;
      } else {
        percentage = Math.min(99, Math.round((taskFraction * 70) + (gateFraction * 30)));
      }
    }

    const activeTask = mission.tasks.find(t => t.id === mission.activeTaskId);

    const summary = mission.status === 'COMPLETED'
      ? `Mission completed: all ${totalTasks} tasks executed and ${passedGates}/${totalGates} gates verified.`
      : mission.status === 'FAILED'
      ? `Mission failed during task execution. ${completedTasks}/${totalTasks} tasks completed.`
      : mission.status === 'BLOCKED'
      ? `Mission blocked waiting for required dependency or authorization.`
      : `${completedTasks} of ${totalTasks} tasks completed (${passedGates}/${totalGates} gates passed).`;

    return {
      totalTasksCount: totalTasks,
      completedTasksCount: completedTasks,
      verifiedTasksCount: verifiedTasks,
      percentage,
      currentTaskTitle: activeTask?.title,
      currentTaskRole: activeTask?.role,
      passedGatesCount: passedGates,
      totalGatesCount: totalGates,
      summary
    };
  }

  /**
   * Evaluates overall dynamic risk level of the mission based on file touch patterns,
   * security boundaries, failures, and dependencies.
   */
  public static calculateMissionRisk(mission: Mission): RiskLevel {
    let riskScore = 0;

    // Check failed tasks
    if (mission.failedTasks.length > 0) riskScore += 3;
    if (mission.loopProtection.consecutiveFailures > 1) riskScore += 3;

    // Check target files
    const allTargetFiles = new Set<string>();
    mission.tasks.forEach(t => t.targetFiles.forEach(f => allTargetFiles.add(f)));

    const fileCount = allTargetFiles.size;
    if (fileCount > 8) riskScore += 2;
    if (fileCount > 15) riskScore += 3;

    // Check for sensitive files
    for (const f of allTargetFiles) {
      if (/package\.json|\.env|config|secret|schema|auth|security/i.test(f)) {
        riskScore += 2;
        break;
      }
    }

    // Check user intent keywords
    if (/refactor|rewrite|auth|database|payment|migrate|delete/i.test(mission.objective)) {
      riskScore += 2;
    }

    if (riskScore >= 7) return 'CRITICAL';
    if (riskScore >= 4) return 'HIGH';
    if (riskScore >= 2) return 'MEDIUM';
    return 'LOW';
  }
}
