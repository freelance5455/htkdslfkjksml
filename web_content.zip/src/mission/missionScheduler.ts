/**
 * GODEX Phase 9 - Autonomous Mission Scheduler
 * Manages DAG task scheduling, concurrency controls, and task dependency resolution for missions.
 */

import { Mission } from './missionTypes';
import { OrchestrationTask, TaskStatus } from '../orchestration/orchestrationTypes';

export class MissionScheduler {
  /**
   * Finds all tasks that are ready to execute based on DAG dependencies.
   */
  public static getReadyTasks(mission: Mission): OrchestrationTask[] {
    const completedSet = new Set(mission.completedTasks);
    const readyTasks: OrchestrationTask[] = [];

    for (const task of mission.tasks) {
      if (task.status === 'QUEUED' || task.status === 'READY') {
        // Check if all HARD dependencies are completed
        const depsSatisfied = task.dependencies.every(dep => {
          if (dep.type === 'HARD') {
            return completedSet.has(dep.taskId);
          }
          // SOFT dependency: either completed or failed
          return completedSet.has(dep.taskId) || mission.failedTasks.includes(dep.taskId);
        });

        if (depsSatisfied) {
          readyTasks.push(task);
        }
      }
    }

    return readyTasks;
  }

  /**
   * Evaluates if all tasks in the mission have completed successfully.
   */
  public static isMissionComplete(mission: Mission): boolean {
    return mission.tasks.length > 0 && mission.completedTasks.length === mission.tasks.length;
  }

  /**
   * Evaluates if the mission has reached an unrecoverable blocked or failed state.
   */
  public static isMissionFailedOrBlocked(mission: Mission): boolean {
    if (mission.status === 'FAILED' || mission.status === 'BLOCKED' || mission.status === 'CANCELLED') {
      return true;
    }
    // If no tasks are running and no tasks are ready but some remain incomplete
    const hasRunning = mission.tasks.some(t => t.status === 'RUNNING');
    const readyTasks = this.getReadyTasks(mission);
    return !hasRunning && readyTasks.length === 0 && !this.isMissionComplete(mission);
  }
}
