const nights = [
  {
    emailFrom:'Big Cousin', subject:'First shift — keep the terminal on', clue:'The killer was seen driving a cream delivery van and works the late supply route near the river.',
    records:[
      {name:'Mina Kuroda',plate:'RS-014',vehicle:'cream delivery van',job:'night supply courier',killer:true,cam:'FRONT ROAD'},
      {name:'Toma Ishii',plate:'RS-209',vehicle:'white hatchback',job:'restaurant cook',killer:false,cam:'SERVICE LANE'},
      {name:'Natsumi Hara',plate:'RS-773',vehicle:'blue taxi',job:'hospital nurse',killer:false,cam:'FRONT ROAD'},
      {name:'Yoko Nishida',plate:'RS-640',vehicle:'gray minivan',job:'flower market clerk',killer:false,cam:'ALLEY CAM'}
    ]
  },
  {
    emailFrom:'Unknown Sender', subject:'Night 2 — a familiar route', clue:'The killer drives a dark green wagon and claims to repair vending machines around the station.',
    records:[
      {name:'Daichi Sato',plate:'RS-118',vehicle:'dark green wagon',job:'vending machine repair',killer:true,cam:'FRONT ROAD'},
      {name:'Emi Watanabe',plate:'RS-402',vehicle:'silver scooter',job:'flower shop owner',killer:false,cam:'SERVICE LANE'},
      {name:'Ren Aoki',plate:'RS-880',vehicle:'orange mini truck',job:'fish market vendor',killer:false,cam:'ALLEY CAM'},
      {name:'Mai Kobayashi',plate:'RS-056',vehicle:'red sedan',job:'station cleaner',killer:false,cam:'FRONT ROAD'},
      {name:'Shota Inoue',plate:'RS-914',vehicle:'black coupe',job:'taxi dispatcher',killer:false,cam:'SERVICE LANE'}
    ]
  },
  {
    emailFrom:'Big Cousin', subject:'Night 3 — do not ask about the old shop', clue:'The killer arrived in a black taxi and says they work nights at the west-side motel.',
    records:[
      {name:'Yui Tanaka',plate:'RS-331',vehicle:'black taxi',job:'motel night clerk',killer:true,cam:'SERVICE LANE'},
      {name:'Kenta Mori',plate:'RS-075',vehicle:'yellow compact',job:'delivery driver',killer:false,cam:'FRONT ROAD'},
      {name:'Sora Fujita',plate:'RS-620',vehicle:'white van',job:'electrician',killer:false,cam:'ALLEY CAM'},
      {name:'Hiroko Abe',plate:'RS-288',vehicle:'blue wagon',job:'pharmacy assistant',killer:false,cam:'FRONT ROAD'}
    ]
  },
  {
    emailFrom:'Unknown Sender', subject:'Night 4 — check the old records', clue:'The killer drives a rust-red pickup and has a job at the harbor warehouse.',
    records:[
      {name:'Akira Endo',plate:'RS-504',vehicle:'rust-red pickup',job:'harbor warehouse guard',killer:true,cam:'ALLEY CAM'},
      {name:'Mio Sakamoto',plate:'RS-216',vehicle:'green compact',job:'school teacher',killer:false,cam:'FRONT ROAD'},
      {name:'Jun Takeda',plate:'RS-935',vehicle:'blue delivery van',job:'bakery owner',killer:false,cam:'SERVICE LANE'},
      {name:'Nao Kishi',plate:'RS-143',vehicle:'white station wagon',job:'dock accountant',killer:false,cam:'ALLEY CAM'},
      {name:'Eri Matsuda',plate:'RS-761',vehicle:'silver hatchback',job:'night pharmacist',killer:false,cam:'FRONT ROAD'}
    ]
  },
  {
    emailFrom:'Big Cousin', subject:'Night 5 — I should have told you', clue:'The killer drives a white courier van and says they deliver packages before dawn.',
    records:[
      {name:'Riku Yamane',plate:'RS-660',vehicle:'white courier van',job:'overnight parcel courier',killer:true,cam:'FRONT ROAD'},
      {name:'Hana Kato',plate:'RS-102',vehicle:'black sedan',job:'accountant',killer:false,cam:'SERVICE LANE'},
      {name:'Shin Okada',plate:'RS-447',vehicle:'cream minivan',job:'bus mechanic',killer:false,cam:'ALLEY CAM'},
      {name:'Miki Arai',plate:'RS-833',vehicle:'green scooter',job:'convenience store clerk',killer:false,cam:'SERVICE LANE'}
    ]
  },
  {
    emailFrom:'Unknown Sender', subject:'Night 6 — the cousin is in the file', clue:'The killer drives a yellow taxi and used to work at the ramen stand before it closed the first time.',
    records:[
      {name:'Kei Nakamura',plate:'RS-817',vehicle:'yellow taxi',job:'former ramen cook',killer:true,cam:'SERVICE LANE'},
      {name:'Aya Shimizu',plate:'RS-308',vehicle:'silver hatchback',job:'librarian',killer:false,cam:'FRONT ROAD'},
      {name:'Hiro Wada',plate:'RS-591',vehicle:'green work van',job:'plumber',killer:false,cam:'ALLEY CAM'},
      {name:'Tetsu Ono',plate:'RS-248',vehicle:'blue compact',job:'night security guard',killer:false,cam:'SERVICE LANE'},
      {name:'Masa Ito',plate:'RS-972',vehicle:'gray pickup',job:'fish delivery driver',killer:false,cam:'FRONT ROAD'}
    ]
  },
  {
    emailFrom:'Big Cousin', subject:'Night 7 — please come home after this', clue:'The killer arrived in a charcoal family car and knows the private name our family used for this stand.',
    records:[
      {name:'Masato Kuroda',plate:'RS-001',vehicle:'charcoal family sedan',job:'former stand manager',killer:true,cam:'FRONT ROAD'},
      {name:'Rina Ishikawa',plate:'RS-722',vehicle:'red compact',job:'pharmacist',killer:false,cam:'SERVICE LANE'},
      {name:'Toru Abe',plate:'RS-415',vehicle:'white work truck',job:'road crew supervisor',killer:false,cam:'ALLEY CAM'},
      {name:'Chie Morita',plate:'RS-657',vehicle:'blue taxi',job:'retired bus driver',killer:false,cam:'SERVICE LANE'},
      {name:'Satoshi Kanda',plate:'RS-390',vehicle:'green delivery van',job:'restaurant supplier',killer:false,cam:'FRONT ROAD'}
    ]
  }
];
export function getNight(day){return nights[Math.max(1,Math.min(7,day))-1];}

export const recipeBook=[
  {dish:'Shoyu ramen',type:'ramen',broth:'soy broth',topping:'chashu, green onion, and nori',ingredients:['1 portion wheat noodles','350 ml soy-seasoned stock','2 slices chashu pork','1 tbsp green onion','1 nori sheet'],method:'Boil the noodles, add soy broth, then top with chashu, green onion, and nori.',price:11,unlockDay:1},
  {dish:'Miso ramen',type:'ramen',broth:'miso broth',topping:'sweet corn and soft egg',ingredients:['1 portion wheat noodles','350 ml miso stock','2 tbsp sweet corn','1 soft-boiled egg','1 tsp butter'],method:'Boil the noodles, add miso broth, then finish with corn, egg, and butter.',price:12,unlockDay:2},
  {dish:'Tonkotsu ramen',type:'ramen',broth:'pork bone broth',topping:'chashu and soft egg',ingredients:['1 portion wheat noodles','350 ml creamy pork broth','3 slices chashu pork','1 soft-boiled egg','1 tbsp scallion'],method:'Boil the noodles, pour the rich pork broth, then add chashu, egg, and scallion.',price:14,unlockDay:3},
  {dish:'Spicy ramen',type:'ramen',broth:'chili broth',topping:'chili oil and pork',ingredients:['1 portion wheat noodles','350 ml spiced stock','2 tsp chili oil','2 slices chashu pork','1 handful bean sprouts'],method:'Boil the noodles, ladle in spicy broth, then add chili oil, pork, and sprouts.',price:13,unlockDay:4},
  {dish:'Salmon nigiri',type:'sushi',broth:'seasoned sushi rice',topping:'fresh salmon and wasabi',ingredients:['1/2 cup cooked sushi rice','1 tsp rice vinegar','4 slices salmon','1 tsp wasabi'],method:'Shape vinegar-seasoned rice into small ovals and lay fresh salmon over each one.',price:12,unlockDay:5},
  {dish:'Tuna cucumber maki',type:'sushi',broth:'seasoned sushi rice',topping:'tuna and cucumber',ingredients:['1/2 cup cooked sushi rice','1 nori sheet','50 g tuna','1/4 cucumber','1 tsp rice vinegar'],method:'Spread seasoned rice on nori, add tuna and cucumber, roll tightly, then slice.',price:13,unlockDay:6},
  {dish:'California roll',type:'sushi',broth:'seasoned sushi rice',topping:'crab, avocado, and cucumber',ingredients:['1/2 cup cooked sushi rice','1 nori sheet','2 crab sticks','1/4 avocado','1/4 cucumber','1 tsp sesame'],method:'Roll crab, avocado, and cucumber in nori and rice, then coat lightly with sesame.',price:14,unlockDay:7}
];
const customerRemarks=[
  'The highway was empty all the way from the river.',
  'I have one more delivery before the sun comes up.',
  'The streetlight outside keeps flickering, doesn’t it?',
  'I used to come here with my family when I was younger.'
];
export function getRecipes(day){return recipeBook.map(recipe=>({...recipe,unlocked:day>=recipe.unlockDay}));}
export function getOrder(day,index){const unlocked=recipeBook.filter(recipe=>day>=recipe.unlockDay);return unlocked[((day-1+index)%unlocked.length)];}
export function getCustomerRemark(day,index){return customerRemarks[((day+index-2)%customerRemarks.length+customerRemarks.length)%customerRemarks.length];}
