const nights = [
  {
    emailFrom:'Big Cousin', subject:'First shift — keep the terminal on', clue:'The killer was seen driving a cream delivery van and works the late supply route near the river.',
    records:[
      {name:'Mina Kuroda',plate:'RS-014',vehicle:'cream delivery van',job:'night supply courier',killer:true,cam:'FRONT ROAD'},
      {name:'Toma Ishii',plate:'RS-209',vehicle:'white hatchback',job:'restaurant cook',killer:false,cam:'SERVICE LANE'},
      {name:'Natsumi Hara',plate:'RS-773',vehicle:'blue taxi',job:'hospital nurse',killer:false,cam:'FRONT ROAD'}
    ]
  },
  {
    emailFrom:'Unknown Sender', subject:'Night 2 — a familiar route', clue:'The killer drives a dark green wagon and claims to repair vending machines around the station.',
    records:[
      {name:'Daichi Sato',plate:'RS-118',vehicle:'dark green wagon',job:'vending machine repair',killer:true,cam:'FRONT ROAD'},
      {name:'Emi Watanabe',plate:'RS-402',vehicle:'silver scooter',job:'flower shop owner',killer:false,cam:'SERVICE LANE'},
      {name:'Ren Aoki',plate:'RS-880',vehicle:'orange mini truck',job:'fish market vendor',killer:false,cam:'ALLEY CAM'}
    ]
  },
  {
    emailFrom:'Big Cousin', subject:'Night 3 — do not ask about the old shop', clue:'The killer arrived in a black taxi and says they work nights at the west-side motel.',
    records:[
      {name:'Yui Tanaka',plate:'RS-331',vehicle:'black taxi',job:'motel night clerk',killer:true,cam:'SERVICE LANE'},
      {name:'Kenta Mori',plate:'RS-075',vehicle:'yellow compact',job:'delivery driver',killer:false,cam:'FRONT ROAD'},
      {name:'Sora Fujita',plate:'RS-620',vehicle:'white van',job:'electrician',killer:false,cam:'ALLEY CAM'}
    ]
  },
  {
    emailFrom:'Unknown Sender', subject:'Night 4 — check the old records', clue:'The killer drives a rust-red pickup and has a job at the harbor warehouse.',
    records:[
      {name:'Akira Endo',plate:'RS-504',vehicle:'rust-red pickup',job:'harbor warehouse guard',killer:true,cam:'ALLEY CAM'},
      {name:'Mio Sakamoto',plate:'RS-216',vehicle:'green compact',job:'school teacher',killer:false,cam:'FRONT ROAD'},
      {name:'Jun Takeda',plate:'RS-935',vehicle:'blue delivery van',job:'bakery owner',killer:false,cam:'SERVICE LANE'}
    ]
  },
  {
    emailFrom:'Big Cousin', subject:'Night 5 — I should have told you', clue:'The killer drives a white courier van and says they deliver packages before dawn.',
    records:[
      {name:'Riku Yamane',plate:'RS-660',vehicle:'white courier van',job:'overnight parcel courier',killer:true,cam:'FRONT ROAD'},
      {name:'Hana Kato',plate:'RS-102',vehicle:'black sedan',job:'accountant',killer:false,cam:'SERVICE LANE'},
      {name:'Shin Okada',plate:'RS-447',vehicle:'cream minivan',job:'bus mechanic',killer:false,cam:'ALLEY CAM'}
    ]
  },
  {
    emailFrom:'Unknown Sender', subject:'Night 6 — the cousin is in the file', clue:'The killer drives a yellow taxi and used to work at the ramen stand before it closed the first time.',
    records:[
      {name:'Kei Nakamura',plate:'RS-817',vehicle:'yellow taxi',job:'former ramen cook',killer:true,cam:'SERVICE LANE'},
      {name:'Aya Shimizu',plate:'RS-308',vehicle:'silver hatchback',job:'librarian',killer:false,cam:'FRONT ROAD'},
      {name:'Hiro Wada',plate:'RS-591',vehicle:'green work van',job:'plumber',killer:false,cam:'ALLEY CAM'}
    ]
  },
  {
    emailFrom:'Big Cousin', subject:'Night 7 — please come home after this', clue:'The killer arrived in a charcoal family car and knows the private name our family used for this stand.',
    records:[
      {name:'Masato Kuroda',plate:'RS-001',vehicle:'charcoal family sedan',job:'former stand manager',killer:true,cam:'FRONT ROAD'},
      {name:'Rina Ishikawa',plate:'RS-722',vehicle:'red compact',job:'pharmacist',killer:false,cam:'SERVICE LANE'},
      {name:'Toru Abe',plate:'RS-415',vehicle:'white work truck',job:'road crew supervisor',killer:false,cam:'ALLEY CAM'}
    ]
  }
];
export function getNight(day){return nights[Math.max(1,Math.min(7,day))-1];}
