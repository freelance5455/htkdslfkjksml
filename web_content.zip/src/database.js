/* ==========================================================================
   database.js — دیتابیس داخلی: IndexedDB با Fallback کامل به localStorage
   استفاده: لاگ رویدادها، یادداشت‌ها، مکالمات، اسنپ‌شات‌های ماهانه
   ========================================================================== */

import { readLS, writeLS } from './storage.js';

const DB_NAME = 'billionaire_path';
const DB_VERSION = 1;
const STORE = 'records';
let dbPromise = null;

function hasIDB() { return typeof indexedDB !== 'undefined' && indexedDB !== null; }

function openDB() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          const os = db.createObjectStore(STORE, { keyPath: 'id' });
          os.createIndex('type', 'type', { unique: false });
          os.createIndex('ts', 'ts', { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}

function lsCollection(type) {
  const all = readLS('bp_v1_idb_fallback_' + type, []);
  return Array.isArray(all) ? all : [];
}
function lsWrite(type, rows) { writeLS('bp_v1_idb_fallback_' + type, rows); }

export const DB = {
  available: hasIDB(),

  async put(record) {
    const rec = { ts: Date.now(), ...record };
    if (!hasIDB()) {
      const rows = lsCollection(rec.type).filter((r) => r.id !== rec.id);
      rows.push(rec); lsWrite(rec.type, rows);
      return rec.id;
    }
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(rec);
      tx.oncomplete = () => resolve(rec.id);
      tx.onerror = () => reject(tx.error);
    });
  },

  async bulkPut(records) {
    for (const r of records) { await DB.put(r); }
    return records.length;
  },

  async get(id) {
    if (!hasIDB()) {
      const rows = lsCollection('all');
      return rows.find((r) => r.id === id) || null;
    }
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const rq = tx.objectStore(STORE).get(id);
      rq.onsuccess = () => resolve(rq.result || null);
      rq.onerror = () => reject(rq.error);
    });
  },

  async byType(type, limit = 500) {
    if (!hasIDB()) return lsCollection(type).slice(-limit);
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const out = [];
      const tx = db.transaction(STORE, 'readonly');
      const idx = tx.objectStore(STORE).index('type');
      const cursorReq = idx.openCursor(IDBKeyRange.only(type));
      cursorReq.onsuccess = (e) => {
        const cursor = e.target.result;
        if (cursor) { out.push(cursor.value); cursor.continue(); }
        else resolve(out.slice(-limit));
      };
      cursorReq.onerror = () => reject(cursorReq.error);
    });
  },

  async del(id) {
    if (!hasIDB()) {
      const rows = lsCollection('all').filter((r) => r.id !== id);
      lsWrite('all', rows);
      return;
    }
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  },

  async clear() {
    if (!hasIDB()) {
      ['log', 'note', 'chat', 'snapshot', 'review'].forEach((t) => lsWrite(t, []));
      return true;
    }
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).clear();
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  },
};

/** لاگ رویداد — برای حافظه آفلاین و تحلیل رفتار کاربر */
export async function logEvent(type, text, extra = {}) {
  const rec = { id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6), type, text, ...extra };
  try { await DB.put(rec); } catch (e) { void e; }
  return rec;
}
