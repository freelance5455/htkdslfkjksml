/** Exécute une journée de carrière sur une copie isolée et ne publie l'état
 * qu'après validation de toutes les étapes (calendrier, rencontres, gestion).
 */
export function runCareerDayTransaction(state, { preflight, advanceDay, processDaily = [], processEvent, validate, persist } = {}) {
  const nextDay = Number(state.calendar?.currentDay || state.day || 1) + 1;
  const blocked = preflight?.(state, nextDay);
  if (blocked) return { committed: false, blocked, day: nextDay };

  const draft = JSON.parse(JSON.stringify(state));
  const tick = advanceDay(draft);
  const dailyResults = [];
  for (const task of processDaily) dailyResults.push(task(draft, tick));
  const eventResult = processEvent?.(draft, tick) ?? null;
  if (eventResult && (eventResult.blockedByIncompleteSeasonSetup || eventResult.blockedByMissingFederationDates || eventResult.blockedByUnimplementedCompetition || eventResult.blockedByInsufficientEligibleClubs)) {
    return { committed: false, blocked: { message: eventResult.message || 'Le calendrier ne permet pas encore cet événement.' }, day: nextDay, eventResult };
  }
  validate?.(draft);
  // Persistance avant publication : en cas d'erreur de stockage, l'état vivant reste intact.
  persist?.(draft);
  for (const key of Object.keys(state)) delete state[key];
  Object.assign(state, draft);
  return { committed: true, tick, dailyResults, eventResult, day: nextDay };
}
