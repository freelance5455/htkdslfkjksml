import { ITTSProvider } from './ttsProvider';
import { TTSEngineType, TTSGenerateRequest, TTSGenerateResult, TTSVoice } from '../types/tts';
import { TELUGU_VOICES } from '../data/voicesAndStyles';

export class EdgeNeuralTTSProvider implements ITTSProvider {
  name = 'Realistic Neural Studio';
  engine: TTSEngineType = 'edge-neural';
  description = 'Studio-grade, hyper-realistic human Telugu neural speech with crystal-clear pronunciation and emotion.';

  async isAvailable(): Promise<boolean> {
    return true;
  }

  async getVoices(): Promise<TTSVoice[]> {
    return TELUGU_VOICES.filter((v) => v.engine === 'edge-neural' || v.isRealistic);
  }

  async generateSpeech(request: TTSGenerateRequest): Promise<TTSGenerateResult> {
    const res = await fetch('/api/tts/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...request,
        engine: 'edge-neural',
      }),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.error || `Realistic Neural TTS failed with status ${res.status}`);
    }

    const data = await res.json();

    const binary = atob(data.audioBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const mimeType = data.format === 'mp3' ? 'audio/mp3' : 'audio/wav';
    const blob = new Blob([bytes], { type: mimeType });
    const audioUrl = URL.createObjectURL(blob);

    return {
      audioUrl,
      audioBlob: blob,
      audioBase64: data.audioBase64,
      format: data.format || 'mp3',
      durationSec: data.durationSec || 0,
      filename: data.filename,
      voiceUsed: data.voiceUsed,
      engineUsed: 'edge-neural',
      narrationStyleUsed: data.narrationStyleUsed,
      processedText: data.processedText,
      fallbackNote: data.fallbackNote,
      generatedAt: data.generatedAt,
    };
  }
}
