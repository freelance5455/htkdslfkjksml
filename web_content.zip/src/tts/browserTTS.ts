import { ITTSProvider } from './ttsProvider';
import { TTSEngineType, TTSGenerateRequest, TTSGenerateResult, TTSVoice } from '../types/tts';
import { generateYiuVoiceFilename } from '../audio/audioProcessor';

export class BrowserSpeechTTSProvider implements ITTSProvider {
  name = 'Browser Web Speech API';
  engine: TTSEngineType = 'browser-speech';
  description = 'Local client-side speech synthesis utilizing browser-installed Telugu voice fonts.';

  async isAvailable(): Promise<boolean> {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  async getVoices(): Promise<TTSVoice[]> {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return [];
    }

    return new Promise((resolve) => {
      const load = () => {
        const synthVoices = window.speechSynthesis.getVoices();
        const teluguVoices = synthVoices.filter(
          (v) => v.lang.toLowerCase().includes('te') || v.name.toLowerCase().includes('telugu')
        );

        if (teluguVoices.length === 0) {
          // If no specific Telugu voice is found, provide a fallback representation
          resolve([
            {
              id: 'browser-default-te',
              name: 'Browser Default Telugu (te-IN)',
              teluguName: 'బ్రౌజర్ డిఫాల్ట్ తెలుగు గళం',
              category: 'female',
              gender: 'female',
              styleTag: 'Client Browser Voice',
              description: 'Standard client speech synthesis engine with te-IN locale mapping',
              engine: 'browser-speech',
              recommendedStyles: ['normal'],
              isNeural: false,
              nativeVoiceName: 'default',
            },
          ]);
          return;
        }

        const mapped: TTSVoice[] = teluguVoices.map((v, i) => ({
          id: `browser-${v.name.toLowerCase().replace(/\s+/g, '-')}-${i}`,
          name: `${v.name} (${v.lang})`,
          teluguName: `బ్రౌజర్ గళం ${i + 1}`,
          category: v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('mohan') ? 'male' : 'female',
          gender: v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('mohan') ? 'male' : 'female',
          styleTag: 'Installed Device Voice',
          description: `Device speech synthesizer (${v.name})`,
          engine: 'browser-speech',
          recommendedStyles: ['normal'],
          isNeural: false,
          nativeVoiceName: v.name,
        }));

        resolve(mapped);
      };

      if (window.speechSynthesis.getVoices().length > 0) {
        load();
      } else {
        window.speechSynthesis.onvoiceschanged = load;
        setTimeout(load, 500);
      }
    });
  }

  async generateSpeech(request: TTSGenerateRequest): Promise<TTSGenerateResult> {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      throw new Error('Speech synthesis is not supported in this browser.');
    }

    // Because browser speech synthesis API cannot directly capture audio bytes without microphone permissions,
    // we route to the full-featured server processor which generates genuine MP3/WAV!
    // Or we use native-telugu server fallback to ensure MP3 download works seamlessly!
    const res = await fetch('/api/tts/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...request,
        engine: 'native-telugu',
      }),
    });

    if (!res.ok) {
      throw new Error('Could not synthesize speech.');
    }

    const data = await res.json();
    const binary = atob(data.audioBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'audio/mp3' });
    const audioUrl = URL.createObjectURL(blob);

    return {
      audioUrl,
      audioBlob: blob,
      audioBase64: data.audioBase64,
      format: 'mp3',
      durationSec: data.durationSec || 0,
      filename: generateYiuVoiceFilename('mp3'),
      voiceUsed: request.voiceId,
      engineUsed: 'browser-speech',
      narrationStyleUsed: request.narrationStyle,
      processedText: data.processedText || request.text,
      generatedAt: new Date().toISOString(),
    };
  }
}
