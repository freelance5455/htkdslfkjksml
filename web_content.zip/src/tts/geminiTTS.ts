import { ITTSProvider } from './ttsProvider';
import { TTSEngineType, TTSGenerateRequest, TTSGenerateResult, TTSVoice } from '../types/tts';
import { TELUGU_VOICES } from '../data/voicesAndStyles';

export class GeminiNeuralTTSProvider implements ITTSProvider {
  name = 'Gemini 3.1 Neural Studio';
  engine: TTSEngineType = 'gemini-neural';
  description = 'Studio-grade neural Telugu TTS using Gemini AI voice synthesis (24kHz studio PCM).';

  async isAvailable(): Promise<boolean> {
    try {
      const res = await fetch('/api/tts/status');
      if (!res.ok) return false;
      const data = await res.json();
      return !!data.hasGemini;
    } catch {
      return false;
    }
  }

  async getVoices(): Promise<TTSVoice[]> {
    return TELUGU_VOICES.filter((v) => v.engine === 'gemini-neural');
  }

  async generateSpeech(request: TTSGenerateRequest): Promise<TTSGenerateResult> {
    let res = await fetch('/api/tts/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
    });

    if (!res.ok) {
      // If gemini-neural request failed on server, seamlessly attempt native-telugu fallback
      console.warn('Gemini neural generation failed, attempting native Telugu engine fallback...');
      try {
        const fallbackRes = await fetch('/api/tts/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...request, engine: 'native-telugu' }),
        });
        if (fallbackRes.ok) {
          res = fallbackRes;
        } else {
          const errorData = await res.json().catch(() => ({}));
          throw new Error(errorData.error || `Server responded with error status ${res.status}`);
        }
      } catch (e: any) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || e.message || `Server responded with error status ${res.status}`);
      }
    }

    const data = await res.json();

    // Reconstruct Blob from returned base64 audio
    const binary = atob(data.audioBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const mimeType = data.format === 'mp3' ? 'audio/mp3' : 'audio/wav';
    const blob = new Blob([bytes], { type: mimeType });
    const audioUrl = URL.createObjectURL(blob);

    return {
      audioUrl,
      audioBlob: blob,
      audioBase64: data.audioBase64,
      format: data.format,
      durationSec: data.durationSec || 0,
      filename: data.filename,
      voiceUsed: data.voiceUsed,
      engineUsed: data.engineUsed || 'gemini-neural',
      narrationStyleUsed: data.narrationStyleUsed,
      processedText: data.processedText,
      fallbackNote: data.fallbackNote,
      generatedAt: data.generatedAt,
    };
  }
}
