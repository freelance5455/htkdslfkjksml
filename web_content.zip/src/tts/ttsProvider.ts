import { TTSEngineType, TTSGenerateRequest, TTSGenerateResult, TTSVoice } from '../types/tts';
import { EdgeNeuralTTSProvider } from './edgeNeuralTTS';
import { GeminiNeuralTTSProvider } from './geminiTTS';
import { NativeTeluguTTSProvider } from './nativeTTS';
import { BrowserSpeechTTSProvider } from './browserTTS';

export interface ITTSProvider {
  name: string;
  engine: TTSEngineType;
  description: string;
  isAvailable(): Promise<boolean>;
  getVoices(): Promise<TTSVoice[]>;
  generateSpeech(request: TTSGenerateRequest): Promise<TTSGenerateResult>;
}

export class TTSProviderRegistry {
  private static providers: Map<TTSEngineType, ITTSProvider> = new Map();
  private static initialized = false;

  private static initDefaults() {
    if (!this.initialized) {
      this.register(new EdgeNeuralTTSProvider());
      this.register(new GeminiNeuralTTSProvider());
      this.register(new NativeTeluguTTSProvider());
      this.register(new BrowserSpeechTTSProvider());
      this.initialized = true;
    }
  }

  static register(provider: ITTSProvider) {
    this.providers.set(provider.engine, provider);
  }

  static get(engine: TTSEngineType): ITTSProvider {
    this.initDefaults();
    const provider = this.providers.get(engine);
    if (!provider) {
      const fallback =
        this.providers.get('edge-neural') ||
        this.providers.get('gemini-neural') ||
        this.providers.values().next().value;
      if (!fallback) {
        throw new Error(`No TTS provider registered for engine: ${engine}`);
      }
      return fallback;
    }
    return provider;
  }

  static getAll(): ITTSProvider[] {
    this.initDefaults();
    return Array.from(this.providers.values());
  }
}

