package com.kaved.browser;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;

public class MainActivity extends Activity {
    static final String HOME = "file:///android_asset/i.html";
    static final String DESK = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";
    static final String[] BLK = {
        "google-analytics.com", "googletagmanager.com", "googlesyndication.com", "googleadservices.com",
        "doubleclick.net", "adservice.google.com", "facebook.net", "hotjar.com", "clarity.ms",
        "scorecardresearch.com", "quantserve.com", "taboola.com", "outbrain.com", "criteo.com",
        "criteo.net", "adnxs.com", "amazon-adsystem.com", "mixpanel.com", "segment.io", "amplitude.com",
        "fullstory.com", "bat.bing.com", "ads-twitter.com", "analytics.twitter.com", "analytics.tiktok.com",
        "ct.pinterest.com", "px.ads.linkedin.com", "mc.yandex.ru", "optimizely.com", "onesignal.com",
        "chartbeat.com", "moatads.com", "adsafeprotected.com", "rubiconproject.com", "pubmatic.com",
        "openx.net", "casalemedia.com", "smartadserver.com", "adform.net"
    };

    WebView w;
    EditText bar;
    View prog;
    LinearLayout col;
    WebChromeClient wc;
    ValueCallback<Uri[]> fileCb;
    View custom;
    WebChromeClient.CustomViewCallback customCb;
    boolean desk;
    volatile int nb;
    String plainHost = "";

    int dp(int x) {
        return (int) (x * getResources().getDisplayMetrics().density + .5f);
    }

    TextView btn(String t, String desc) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(22);
        v.setTextColor(0xFFDDDDDD);
        v.setGravity(Gravity.CENTER);
        v.setMinWidth(dp(40));
        v.setClickable(true);
        v.setContentDescription(desc);
        return v;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(0xFF1B1B1F);
        col.setFitsSystemWindows(true);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView back = btn("\u2039", "Voltar");
        TextView reload = btn("\u21bb", "Recarregar");
        TextView more = btn("\u22ee", "Menu");

        bar = new EditText(this);
        bar.setSingleLine(true);
        bar.setHint("Pesquisar ou digitar endere\u00e7o");
        bar.setHintTextColor(0xFF888888);
        bar.setTextColor(0xFFEEEEEE);
        bar.setTextSize(15);
        bar.setSelectAllOnFocus(true);
        bar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        bar.setImeOptions(EditorInfo.IME_ACTION_GO);
        bar.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF2A2A30);
        bg.setCornerRadius(dp(20));
        bar.setBackground(bg);
        bar.setOnEditorActionListener((v, id, e) -> {
            go(bar.getText().toString());
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(bar.getWindowToken(), 0);
            bar.clearFocus();
            return true;
        });

        row.addView(back);
        row.addView(bar, new LinearLayout.LayoutParams(0, dp(40), 1));
        row.addView(reload);
        row.addView(more);

        prog = new View(this);
        prog.setBackgroundColor(0xFF7CC4FF);

        w = new WebView(this);
        col.addView(row);
        col.addView(prog, new LinearLayout.LayoutParams(0, dp(2)));
        col.addView(w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(col);

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme(), us = u.toString();
                if ("http".equals(sc) || "https".equals(sc)) {
                    String c = clean(us);
                    if ("http".equals(sc) && !String.valueOf(u.getHost()).equals(plainHost)) {
                        c = "https" + c.substring(4);
                    }
                    if (!c.equals(us)) {
                        v.loadUrl(c);
                        return true;
                    }
                    return false;
                }
                if (us.startsWith("file:///android_asset/")) return false;
                if ("tel".equals(sc) || "mailto".equals(sc) || "sms".equals(sc)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (Exception e) {
                    }
                }
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame() && blocked(r.getUrl().getHost())) {
                    nb++;
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                nb = 0;
                show(url);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                show(url);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    v.loadDataWithBaseURL(null,
                            "<meta name=viewport content='width=device-width'><body style='background:#1b1b1f;color:#ddd;font:16px sans-serif;padding:24px'>"
                                    + "<h3>N\u00e3o foi poss\u00edvel abrir</h3>"
                                    + "<p>Se o site s\u00f3 funciona sem https, digite o endere\u00e7o com http:// no come\u00e7o.</p>",
                            "text/html", "utf-8", null);
                }
            }
        });

        wc = new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                ViewGroup.LayoutParams lp = prog.getLayoutParams();
                lp.width = col.getWidth() * p / 100;
                prog.setLayoutParams(lp);
                prog.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (custom != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                custom = view;
                customCb = cb;
                setContentView(view);
            }

            @Override
            public void onHideCustomView() {
                if (custom == null) return;
                custom = null;
                setContentView(col);
                if (customCb != null) customCb.onCustomViewHidden();
                customCb = null;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), 1);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        };
        w.setWebChromeClient(wc);

        w.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request q = new DownloadManager.Request(Uri.parse(url));
                q.setMimeType(mime);
                q.addRequestHeader("User-Agent", ua);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) q.addRequestHeader("Cookie", ck);
                q.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                q.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(q);
                Toast.makeText(this, "Baixando...", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "N\u00e3o foi poss\u00edvel baixar", Toast.LENGTH_SHORT).show();
            }
        });

        back.setOnClickListener(v -> {
            if (w.canGoBack()) w.goBack();
        });
        reload.setOnClickListener(v -> w.reload());
        more.setOnClickListener(v -> menu(v));

        open(getIntent());
    }

    void open(Intent i) {
        Uri d = i == null ? null : i.getData();
        if (d != null) w.loadUrl(d.toString());
        else w.loadUrl(HOME);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.getData() != null) open(i);
    }

    void show(String url) {
        if (bar.hasFocus()) return;
        boolean home = url == null || url.startsWith("file:///android_asset/") || url.startsWith("data:") || url.equals("about:blank");
        bar.setText(home ? "" : url);
    }

    void go(String t) {
        t = t.trim();
        if (t.isEmpty()) return;
        String u;
        if (t.startsWith("@w ")) {
            u = "https://pt.wikipedia.org/w/index.php?search=" + Uri.encode(t.substring(3));
        } else if (t.startsWith("@yt ")) {
            u = "https://www.youtube.com/results?search_query=" + Uri.encode(t.substring(4));
        } else if (t.matches("(?i)https?://\\S+")) {
            u = t;
            if (t.regionMatches(true, 0, "http://", 0, 7)) plainHost = String.valueOf(Uri.parse(t).getHost());
        } else if (!t.contains(" ") && t.contains(".")) {
            u = "https://" + t;
        } else {
            u = "https://duckduckgo.com/?q=" + Uri.encode(t);
        }
        w.loadUrl(u);
    }

    void menu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "In\u00edcio");
        m.add(0, 2, 0, "Avan\u00e7ar");
        m.add(0, 3, 0, "Compartilhar");
        m.add(0, 4, 0, (desk ? "\u2713 " : "") + "Vers\u00e3o para computador");
        m.add(0, 5, 0, "Limpar dados");
        m.add(0, 6, 0, "Bloqueados nesta p\u00e1gina: " + nb);
        m.add(0, 7, 0, "Sair");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1:
                    w.loadUrl(HOME);
                    break;
                case 2:
                    if (w.canGoForward()) w.goForward();
                    break;
                case 3:
                    String cu = w.getUrl();
                    if (cu != null && cu.startsWith("http")) {
                        Intent s = new Intent(Intent.ACTION_SEND);
                        s.setType("text/plain");
                        s.putExtra(Intent.EXTRA_TEXT, cu);
                        startActivity(Intent.createChooser(s, null));
                    }
                    break;
                case 4:
                    desk = !desk;
                    WebSettings ws = w.getSettings();
                    ws.setUserAgentString(desk ? DESK : null);
                    ws.setUseWideViewPort(desk);
                    ws.setLoadWithOverviewMode(desk);
                    w.reload();
                    break;
                case 5:
                    w.clearCache(true);
                    w.clearHistory();
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    Toast.makeText(this, "Dados limpos", Toast.LENGTH_SHORT).show();
                    break;
                case 7:
                    finish();
                    break;
                default:
                    break;
            }
            return true;
        });
        pm.show();
    }

    static boolean blocked(String h) {
        if (h == null) return false;
        for (String b : BLK) {
            if (h.equals(b) || h.endsWith("." + b)) return true;
        }
        return false;
    }

    static String clean(String s) {
        Uri u = Uri.parse(s);
        if (u.getQuery() == null) return s;
        Uri.Builder b = u.buildUpon().clearQuery();
        boolean ch = false;
        for (String k : u.getQueryParameterNames()) {
            if (k.startsWith("utm_") || k.equals("fbclid") || k.equals("gclid") || k.equals("dclid")
                    || k.equals("msclkid") || k.equals("mc_eid") || k.equals("igshid") || k.equals("yclid")
                    || k.equals("twclid") || k.equals("_hsenc") || k.equals("_hsmi")) {
                ch = true;
                continue;
            }
            for (String v : u.getQueryParameters(k)) b.appendQueryParameter(k, v);
        }
        return ch ? b.build().toString() : s;
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 1 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (custom != null) wc.onHideCustomView();
        else if (w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        w.destroy();
        super.onDestroy();
    }
}
