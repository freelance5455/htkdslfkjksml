<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
function out($d,int $c=200): void { http_response_code($c); echo json_encode($d,JSON_UNESCAPED_UNICODE); exit; }
function b64u(string $s): string { return rtrim(strtr(base64_encode($s),'+/','-_'),'='); }
function make_token(int $aid): string { $p=b64u(json_encode(['aid'=>$aid,'exp'=>time()+86400*7])); return $p.'.'.b64u(hash_hmac('sha256',$p,app_key(),true)); }
function api_auth(): int {
 $t=$_SERVER['HTTP_X_AUTH_TOKEN']??''; $parts=explode('.',$t);
 if(count($parts)!==2||!hash_equals(b64u(hash_hmac('sha256',$parts[0],app_key(),true)),$parts[1])) out(['error'=>'unauthorized'],401);
 $d=json_decode(base64_decode(strtr($parts[0],'-_','+/')),true);
 if(!$d||($d['exp']??0)<time()) out(['error'=>'expired'],401);
 return (int)$d['aid'];
}
function router(): \RouterOS\Client {
 $s=db()->query('SELECT setting_key,setting_value FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR);
 if(empty($s['mt_host'])||empty($s['mt_user'])) out(['error'=>'router_not_configured'],409);
 if(!class_exists(\RouterOS\Client::class)) out(['error'=>'run composer install'],500);
 return new \RouterOS\Client(['host'=>$s['mt_host'],'port'=>(int)($s['mt_port']??8728),'user'=>$s['mt_user'],'pass'=>decrypt_secret($s['mt_pass']??''),'timeout'=>6]);
}
