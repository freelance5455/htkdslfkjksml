import { writePsdUint8Array } from "ag-psd";
import type { Layer, Psd } from "ag-psd";

/* ------------------------------------------------------------------ */
/*  Types publics                                                      */
/* ------------------------------------------------------------------ */

export interface Platform {
  createCanvas: (w: number, h: number) => any;
  toPng: (canvas: any) => Promise<Uint8Array>;
}

export interface BuildAssets {
  /** Photo du portrait (remplace le placeholder dans l'objet dynamique) */
  portrait?: any;
  /** Image d'arrière-plan (remplace le placeholder dans l'objet dynamique) */
  background?: any;
}

export interface SpecRow {
  group: string;
  name: string;
  kind: "Groupe" | "Texte" | "Forme vectorielle" | "Objet dynamique" | "Pixel / Effet";
  details: string;
}

export interface BuildResult {
  bytes: Uint8Array;
  preview: any;
  spec: SpecRow[];
  width: number;
  height: number;
}

export const REF_SIZE = 1932; // dimensions mesurées sur le visuel d'origine (carré)

/* ------------------------------------------------------------------ */
/*  Palette extraite du visuel                                         */
/* ------------------------------------------------------------------ */

export const COLORS = {
  vertFondHaut: "#2F7D32",
  vertFondBas: "#0A5A2E",
  vertBandeau: "#0C7A45",
  vertLime: "#8DC63F",
  vertAnneau: "#8CD63A",
  vertBouton: "#6AA22B",
  vertDisque: "#0A5A33",
  vertSombre: "#0B5A2E",
  blanc: "#FFFFFF",
  creme: "#F3EFC4",
};

const FONT_FAMILY = '"Plus Jakarta Sans", "Helvetica Neue", Arial, sans-serif';

const hex = (h: string) => ({
  r: parseInt(h.slice(1, 3), 16),
  g: parseInt(h.slice(3, 5), 16),
  b: parseInt(h.slice(5, 7), 16),
});

const guid = () =>
  "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });

type Pt = [number, number];
interface Knot {
  a: Pt;
  i: Pt;
  o: Pt;
}

const PS_FONTS: Record<string, string> = {
  "400-normal": "PlusJakartaSans-Regular",
  "700-normal": "PlusJakartaSans-Bold",
  "800-normal": "PlusJakartaSans-ExtraBold",
  "800-italic": "PlusJakartaSans-ExtraBoldItalic",
  "300-normal": "PlusJakartaSans-Light",
  "200-normal": "PlusJakartaSans-ExtraLight",
};

interface TextOpts {
  name: string;
  text: string;
  x: number; // bord gauche (coord. 1932)
  baseline: number; // ligne de base de la 1re ligne
  size: number;
  color: string;
  weight?: number;
  italic?: boolean;
  leading?: number;
  tracking?: number; // 1/1000 em (unité Photoshop)
  align?: "left" | "center";
  role: string;
}

/* ------------------------------------------------------------------ */
/*  Génération                                                         */
/* ------------------------------------------------------------------ */

export async function buildPsd(
  platform: Platform,
  outputSize: number,
  assets: BuildAssets = {}
): Promise<BuildResult> {
  const k = outputSize / REF_SIZE;
  const W = outputSize;
  const H = outputSize;
  const spec: SpecRow[] = [];
  const linkedFiles: NonNullable<Psd["linkedFiles"]> = [];
  let currentGroup = "";

  const cv = (w: number, h: number) => platform.createCanvas(Math.max(1, Math.ceil(w)), Math.max(1, Math.ceil(h)));

  /* ---------- Calque pixel générique ---------- */
  const rasterLayer = (
    name: string,
    x: number,
    y: number,
    w: number,
    h: number,
    draw: (ctx: any) => void
  ): Layer => {
    const left = Math.floor(x);
    const top = Math.floor(y);
    const c = cv(Math.ceil(x + w) - left + 1, Math.ceil(y + h) - top + 1);
    const ctx = c.getContext("2d");
    ctx.translate(-left, -top);
    draw(ctx);
    return { name, left, top, canvas: c };
  };

  /* ---------- Texte ---------- */
  const fontString = (size: number, weight: number, italic: boolean) =>
    `${italic ? "italic " : ""}${weight} ${size}px ${FONT_FAMILY}`;

  const measure = (text: string, size: number, weight = 400, italic = false, tracking = 0) => {
    const c = cv(10, 10);
    const ctx = c.getContext("2d");
    ctx.font = fontString(size * k, weight, italic);
    if ("letterSpacing" in ctx) ctx.letterSpacing = `${(tracking / 1000) * size * k}px`;
    return ctx.measureText(text).width / k;
  };

  const textLayer = (o: TextOpts): Layer => {
    const weight = o.weight ?? 400;
    const italic = !!o.italic;
    const size = o.size * k;
    const lines = o.text.split("\n");
    const leading = (o.leading ?? o.size * 1.2) * k;
    const tracking = o.tracking ?? 0;
    const x = o.x * k;
    const baseline = o.baseline * k;

    const m = cv(10, 10).getContext("2d");
    m.font = fontString(size, weight, italic);
    if ("letterSpacing" in m) m.letterSpacing = `${(tracking / 1000) * size}px`;
    const widths = lines.map((l: string) => m.measureText(l).width);
    const maxW = Math.max(...widths);

    const originX = o.align === "center" ? x - maxW / 2 : x;
    const layer = rasterLayer(
      o.name,
      originX - size * 0.1,
      baseline - size * 1.0,
      maxW + size * 0.3,
      size * 1.3 + (lines.length - 1) * leading,
      (ctx) => {
        ctx.font = fontString(size, weight, italic);
        if ("letterSpacing" in ctx) ctx.letterSpacing = `${(tracking / 1000) * size}px`;
        ctx.fillStyle = o.color;
        ctx.textBaseline = "alphabetic";
        ctx.textAlign = "left";
        lines.forEach((l: string, idx: number) => ctx.fillText(l, originX, baseline + idx * leading));
      }
    );

    layer.text = {
      text: o.text.replace(/\n/g, "\r"),
      transform: [1, 0, 0, 1, originX, baseline],
      antiAlias: "smooth",
      style: {
        font: { name: PS_FONTS[`${weight}-${italic ? "italic" : "normal"}`] ?? "PlusJakartaSans-Regular" },
        fontSize: size,
        fillColor: hex(o.color),
        tracking,
        autoLeading: lines.length === 1,
        leading: lines.length > 1 ? leading : undefined,
      },
      paragraphStyle: { justification: o.align === "center" ? "center" : "left" },
    };

    spec.push({
      group: currentGroup,
      name: o.name,
      kind: "Texte",
      details: `« ${o.text.replace(/\n/g, " ⏎ ")} » · ${PS_FONTS[`${weight}-${italic ? "italic" : "normal"}`] ?? "PlusJakartaSans-Regular"} · ${Math.round(
        o.size
      )} px (réf. ${REF_SIZE}) · ${o.color} · aligné ${o.align === "center" ? "au centre" : "à gauche"}${
        lines.length > 1 ? ` · interlignage ${Math.round(o.leading ?? 0)} px` : ""
      }${tracking ? ` · approche ${tracking}` : ""} — ${o.role}`,
    });
    return layer;
  };

  /* ---------- Formes vectorielles ---------- */
  const poly = (pts: Pt[]): Knot[] => pts.map((p) => ({ a: p, i: p, o: p }));
  const KAPPA = 0.5522847498;
  const ellipseKnots = (cx: number, cy: number, rx: number, ry: number): Knot[] => [
    { a: [cx, cy - ry], i: [cx - rx * KAPPA, cy - ry], o: [cx + rx * KAPPA, cy - ry] },
    { a: [cx + rx, cy], i: [cx + rx, cy - ry * KAPPA], o: [cx + rx, cy + ry * KAPPA] },
    { a: [cx, cy + ry], i: [cx + rx * KAPPA, cy + ry], o: [cx - rx * KAPPA, cy + ry] },
    { a: [cx - rx, cy], i: [cx - rx, cy + ry * KAPPA], o: [cx - rx, cy - ry * KAPPA] },
  ];
  const roundRectKnots = (x: number, y: number, w: number, h: number, r: number): Knot[] => {
    const c = r * (1 - KAPPA);
    const x2 = x + w;
    const y2 = y + h;
    const K = (a: Pt, i: Pt, o: Pt): Knot => ({ a, i, o });
    return [
      K([x + r, y], [x + r, y], [x + r, y]),
      K([x2 - r, y], [x2 - r, y], [x2 - c, y]),
      K([x2, y + r], [x2, y + c], [x2, y + r]),
      K([x2, y2 - r], [x2, y2 - r], [x2, y2 - c]),
      K([x2 - r, y2], [x2 - c, y2], [x2 - r, y2]),
      K([x + r, y2], [x + r, y2], [x + c, y2]),
      K([x, y2 - r], [x, y2 - c], [x, y2 - r]),
      K([x, y + r], [x, y + r], [x, y + c]),
    ].map((kn, idx) => (idx === 0 ? { a: kn.a, i: [x + c, y] as Pt, o: kn.o } : kn));
  };

  const shapeLayer = (
    name: string,
    knots: Knot[], // coordonnées 1932
    opts: { fill?: string; stroke?: { color: string; width: number }; opacity?: number; role: string }
  ): Layer => {
    const kn = knots.map((n) => ({
      a: [n.a[0] * k, n.a[1] * k] as Pt,
      i: [n.i[0] * k, n.i[1] * k] as Pt,
      o: [n.o[0] * k, n.o[1] * k] as Pt,
    }));
    const xs = kn.flatMap((n) => [n.a[0], n.i[0], n.o[0]]);
    const ys = kn.flatMap((n) => [n.a[1], n.i[1], n.o[1]]);
    const sw = opts.stroke ? opts.stroke.width * k : 0;
    const minX = Math.min(...xs) - sw;
    const minY = Math.min(...ys) - sw;
    const maxX = Math.max(...xs) + sw;
    const maxY = Math.max(...ys) + sw;

    const layer = rasterLayer(name, minX, minY, maxX - minX, maxY - minY, (ctx) => {
      ctx.beginPath();
      ctx.moveTo(kn[0].a[0], kn[0].a[1]);
      for (let n = 1; n <= kn.length; n++) {
        const prev = kn[n - 1];
        const cur = kn[n % kn.length];
        ctx.bezierCurveTo(prev.o[0], prev.o[1], cur.i[0], cur.i[1], cur.a[0], cur.a[1]);
      }
      ctx.closePath();
      if (opts.fill) {
        ctx.fillStyle = opts.fill;
        ctx.fill();
      }
      if (opts.stroke) {
        ctx.strokeStyle = opts.stroke.color;
        ctx.lineWidth = sw;
        ctx.stroke();
      }
    });

    layer.vectorMask = {
      paths: [
        {
          open: false,
          operation: "combine",
          fillRule: "even-odd",
          knots: kn.map((n) => ({ linked: false, points: [...n.i, ...n.a, ...n.o] })),
        },
      ],
    };
    layer.vectorFill = { type: "color", color: hex(opts.fill ?? opts.stroke?.color ?? "#000000") };
    if (opts.stroke) {
      layer.vectorStroke = {
        strokeEnabled: true,
        fillEnabled: !!opts.fill,
        lineWidth: { value: sw, units: "Pixels" },
        lineAlignment: "center",
        lineCapType: "butt",
        lineJoinType: "miter",
        miterLimit: 100,
        opacity: 1,
        blendMode: "normal",
        content: { type: "color", color: hex(opts.stroke.color) },
        resolution: 300,
      };
    }
    if (opts.opacity !== undefined) layer.opacity = opts.opacity;

    const bw = Math.round((maxX - minX) / k);
    const bh = Math.round((maxY - minY) / k);
    spec.push({
      group: currentGroup,
      name,
      kind: "Forme vectorielle",
      details: `${bw}×${bh} px (réf.) · ${opts.fill ? `remplissage ${opts.fill}` : "sans remplissage"}${
        opts.stroke ? ` · contour ${opts.stroke.color} ${opts.stroke.width}px` : ""
      }${opts.opacity !== undefined ? ` · opacité ${Math.round(opts.opacity * 100)} %` : ""} — ${opts.role}`,
    });
    return layer;
  };

  /* ---------- Objet dynamique ---------- */
  const smartObject = async (
    name: string,
    x: number,
    y: number,
    w: number,
    h: number,
    paintSource: (ctx: any, sw: number, sh: number) => void,
    role: string,
    srcScale = 2,
    sourceImage?: any
  ): Promise<Layer> => {
    const X = x * k;
    const Y = y * k;
    const Wd = w * k;
    const Ht = h * k;
    const srcW = Math.round(w * srcScale);
    const srcH = Math.round(h * srcScale);
    const src = cv(srcW, srcH);
    const sctx = src.getContext("2d");
    if (sourceImage) {
      // recadrage "cover" pour conserver les proportions
      const iw = sourceImage.width;
      const ih = sourceImage.height;
      const s = Math.max(srcW / iw, srcH / ih);
      const dw = iw * s;
      const dh = ih * s;
      sctx.drawImage(sourceImage, (srcW - dw) / 2, (srcH - dh) / 2, dw, dh);
    } else {
      paintSource(sctx, srcW, srcH);
    }
    const png = await platform.toPng(src);
    const id = guid();
    linkedFiles.push({ id, name: `${name}.png`, type: "png", data: png });

    const layer = rasterLayer(name, X, Y, Wd, Ht, (ctx) => {
      ctx.drawImage(src, X, Y, Wd, Ht);
    });
    layer.placedLayer = {
      id,
      placed: id,
      type: "raster",
      transform: [X, Y, X + Wd, Y, X + Wd, Y + Ht, X, Y + Ht],
      width: srcW,
      height: srcH,
      resolution: { value: 300, units: "Density" },
    };
    spec.push({
      group: currentGroup,
      name,
      kind: "Objet dynamique",
      details: `${Math.round(w)}×${Math.round(h)} px (réf.) · contenu intégré ${srcW}×${srcH} px (PNG) · ${
        sourceImage ? "image fournie" : "placeholder à remplacer"
      } — ${role}`,
    });
    return layer;
  };

  const group = (name: string, children: Layer[], note: string): Layer => {
    spec.push({ group: name, name, kind: "Groupe", details: note });
    return { name, children, opened: true };
  };

  /* ================================================================ */
  /*  01 — BACKGROUND                                                  */
  /* ================================================================ */
  currentGroup = "01_BACKGROUND";

  const paintBackground = (ctx: any, sw: number, sh: number) => {
    const g = ctx.createLinearGradient(0, 0, sw * 0.35, sh);
    g.addColorStop(0, COLORS.vertFondHaut);
    g.addColorStop(0.55, "#0F6B38");
    g.addColorStop(1, COLORS.vertFondBas);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, sw, sh);
    // silhouette du pavillon (placeholder)
    ctx.save();
    ctx.scale(sw / REF_SIZE, sh / REF_SIZE);
    ctx.fillStyle = "rgba(200,210,60,0.16)";
    for (let i = 0; i < 8; i++) {
      const cy = 230 + i * 85;
      const rx = 260 + i * 38;
      ctx.beginPath();
      ctx.ellipse(1740, cy, rx, 36 + i * 3, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "rgba(210,220,120,0.22)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(1742, 30);
    ctx.lineTo(1742, 160);
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.05)";
    ctx.beginPath();
    ctx.moveTo(670, 320);
    ctx.lineTo(1010, 560);
    ctx.lineTo(330, 560);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  };

  const imgFond = await smartObject(
    "IMG_Fond_Pavillon_Kigali",
    0,
    0,
    REF_SIZE,
    REF_SIZE,
    paintBackground,
    "Double-clic sur la vignette → remplacer par la photo d'arrière-plan (filtres et masques conservés).",
    1,
    assets.background
  );

  const fxDegrade = rasterLayer("FX_Degrade_Assombri_Bas", 0, 900 * k, W, 782 * k, (ctx) => {
    const g = ctx.createLinearGradient(0, 900 * k, 0, 1682 * k);
    g.addColorStop(0, "rgba(5,70,38,0)");
    g.addColorStop(1, "rgba(5,70,38,0.55)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 900 * k, W, 782 * k);
  });
  spec.push({
    group: currentGroup,
    name: "FX_Degrade_Assombri_Bas",
    kind: "Pixel / Effet",
    details: "Dégradé linéaire vertical #05462600 → #05462680 (de y=900 à y=1682) pour assombrir le bas du fond.",
  });

  const bandeBlanche = shapeLayer("SHAPE_Bande_Blanche_Pied", poly([[0, 1682], [1932, 1682], [1932, 1932], [0, 1932]]), {
    fill: COLORS.blanc,
    role: "Bandeau blanc du pied de page (y 1682 → 1932).",
  });

  const gBackground = group("01_BACKGROUND", [imgFond, fxDegrade, bandeBlanche], "Fond, dégradé et bande blanche du pied de page.");

  /* ================================================================ */
  /*  02 — EN-TÊTE LOGOS                                               */
  /* ================================================================ */
  currentGroup = "02_ENTETE_LOGOS";

  const logoHeroes = await smartObject(
    "IMG_Logo_Africas_Business_Heroes",
    115,
    148,
    402,
    110,
    (ctx, sw) => {
      const s = sw / 402;
      ctx.fillStyle = COLORS.creme;
      ctx.textBaseline = "alphabetic";
      ctx.font = `200 ${118 * s}px ${FONT_FAMILY}`;
      ctx.fillText("Heroes", 0, 104 * s);
      ctx.font = `700 ${31 * s}px ${FONT_FAMILY}`;
      ctx.fillText("Africa's Business", 94 * s, 28 * s);
    },
    "Logo « Africa's Business Heroes » (crème #F3EFC4) — à remplacer par le fichier vectoriel officiel.",
    3
  );

  const logoBiophyto = await smartObject(
    "IMG_Logo_Biophyto",
    552,
    155,
    452,
    142,
    (ctx, sw) => {
      const s = sw / 452;
      ctx.fillStyle = "#FFFFFF";
      ctx.textBaseline = "alphabetic";
      ctx.font = `800 ${92 * s}px ${FONT_FAMILY}`;
      ctx.fillText("biophyto", 10 * s, 84 * s);
      ctx.beginPath();
      ctx.moveTo(0, 138 * s);
      ctx.bezierCurveTo(90 * s, 96 * s, 300 * s, 124 * s, 450 * s, 90 * s);
      ctx.bezierCurveTo(330 * s, 112 * s, 130 * s, 96 * s, 0, 140 * s);
      ctx.fill();
      ctx.fillStyle = COLORS.vertLime;
      ctx.beginPath();
      ctx.arc(94 * s, 6 * s, 9 * s, 0, Math.PI * 2);
      ctx.fill();
    },
    "Logo « biophyto » (blanc #FFFFFF) — à remplacer par le fichier vectoriel officiel.",
    3
  );

  const gLogos = group("02_ENTETE_LOGOS", [logoHeroes, logoBiophyto], "Logos partenaires en objets dynamiques (remplaçables).");

  /* ================================================================ */
  /*  03 — TEXTES PRINCIPAUX                                           */
  /* ================================================================ */
  currentGroup = "03_TEXTES_PRINCIPAUX";

  const bandeau = shapeLayer("SHAPE_Bandeau_Titre", poly([[153, 480], [1262, 480], [1262, 829], [153, 829]]), {
    fill: COLORS.vertBandeau,
    role: "Bandeau vert derrière le titre.",
  });
  const liseret = shapeLayer("SHAPE_Liseret_Incline", poly([[126, 504], [153, 504], [153, 765]]), {
    fill: COLORS.vertLime,
    role: "Liseret vert lime incliné sur le bord gauche du bandeau.",
  });

  const titre = textLayer({
    name: "TXT_Titre_Principal",
    text: "IL EST VENU À LA\nRESCOUSSE DE L'ANANAS\nBIO BÉNINOIS !",
    x: 184,
    baseline: 579,
    size: 82,
    color: COLORS.blanc,
    weight: 800,
    leading: 111,
    tracking: -5,
    role: "Titre principal en capitales, 3 lignes.",
  });

  const l1Y = 978;
  const w3 = measure("3 choses", 76, 800, false, -12);
  const acc1 = textLayer({
    name: "TXT_Accroche_3_choses",
    text: "3 choses",
    x: 185,
    baseline: l1Y,
    size: 76,
    color: COLORS.vertLime,
    weight: 800,
    tracking: -12,
    role: "Début de l'accroche, vert lime gras.",
  });
  const acc2 = textLayer({
    name: "TXT_Accroche_que_vous",
    text: "que vous",
    x: 185 + w3 + 18,
    baseline: l1Y,
    size: 76,
    color: COLORS.blanc,
    weight: 400,
    tracking: -12,
    role: "Suite de l'accroche, blanc régulier.",
  });
  const acc3 = textLayer({
    name: "TXT_Accroche_ignorez_peut_etre",
    text: "ignorez peut-être sur le",
    x: 185,
    baseline: 1078,
    size: 76,
    color: COLORS.blanc,
    weight: 400,
    tracking: -12,
    role: "2e ligne de l'accroche, blanc régulier.",
  });
  const nom = textLayer({
    name: "TXT_Nom_Expert",
    text: "Dr Gildas ZODOME",
    x: 185,
    baseline: 1180,
    size: 76,
    color: COLORS.vertLime,
    weight: 800,
    tracking: -12,
    role: "Nom de l'expert, vert lime extra-gras.",
  });
  const filet = shapeLayer("SHAPE_Filet_Separateur", poly([[210, 1244], [1140, 1244], [1140, 1246], [210, 1246]]), {
    fill: COLORS.vertLime,
    opacity: 0.35,
    role: "Filet fin de séparation (opacité 35 %).",
  });

  const gTextes = group(
    "03_TEXTES_PRINCIPAUX",
    [bandeau, liseret, titre, acc1, acc2, acc3, nom, filet],
    "Bandeau de titre, titre, accroche et nom de l'expert."
  );

  /* ================================================================ */
  /*  04 — VISUELS & PRODUITS                                          */
  /* ================================================================ */
  currentGroup = "04_VISUELS_PRODUITS";
  const cx = 1472;
  const cy = 1033;
  const R = 386;

  const disque = shapeLayer("SHAPE_Disque_Fond_Portrait", ellipseKnots(cx, cy, R, R), {
    fill: COLORS.vertDisque,
    role: "Disque vert foncé — sert de masque d'écrêtage pour le portrait.",
  });

  const portrait = await smartObject(
    "IMG_Portrait_Expert_Detoure",
    cx - R,
    cy - R,
    R * 2,
    R * 2,
    (ctx, sw, sh) => {
      ctx.fillStyle = COLORS.vertDisque;
      ctx.fillRect(0, 0, sw, sh);
      ctx.save();
      ctx.scale(sw / 100, sh / 100);
      // épaules / chemise bleue
      ctx.fillStyle = "#2F6DB8";
      ctx.beginPath();
      ctx.moveTo(8, 100);
      ctx.bezierCurveTo(12, 70, 30, 60, 42, 56);
      ctx.lineTo(60, 56);
      ctx.bezierCurveTo(72, 60, 90, 70, 94, 100);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#8EC1EC";
      for (let i = 0; i < 14; i++) {
        ctx.beginPath();
        ctx.ellipse(18 + ((i * 17) % 70), 66 + ((i * 11) % 30), 6, 3, i, 0, Math.PI * 2);
        ctx.fill();
      }
      // cou + tête
      ctx.fillStyle = "#5B3A2C";
      ctx.fillRect(45, 44, 12, 14);
      ctx.beginPath();
      ctx.ellipse(51, 32, 13, 17, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.font = `700 ${sw * 0.032}px ${FONT_FAMILY}`;
      ctx.textAlign = "center";
      ctx.fillText("PORTRAIT À REMPLACER", sw / 2, sh * 0.2);
    },
    "Portrait de l'expert : double-clic → remplacer l'image. Masque d'écrêtage = disque ci-dessous.",
    2,
    assets.portrait
  );
  portrait.clipping = true;

  const anneau = shapeLayer("SHAPE_Anneau_Vert_Portrait", ellipseKnots(cx, cy, R, R), {
    stroke: { color: COLORS.vertAnneau, width: 8 },
    role: "Cercle de contour vert lime (trait 8 px, sans remplissage).",
  });

  const gVisuels = group("04_VISUELS_PRODUITS", [disque, portrait, anneau], "Portrait circulaire (objet dynamique écrêté) et anneau.");

  /* ================================================================ */
  /*  05 — APPEL À L'ACTION                                            */
  /* ================================================================ */
  currentGroup = "05_APPEL_ACTION";

  const arrowPts = (cX: number, cY: number, s: number): Pt[] =>
    ([[-9, -3], [1, -3], [1, -9], [10, 0], [1, 9], [1, 3], [-9, 3]] as Pt[]).map(([px, py]) => [cX + px * s, cY + py * s] as Pt);

  const wVotez = measure("Votez jusqu'au", 34, 400, false, -5);
  const votez1 = textLayer({
    name: "TXT_Vote_Intro",
    text: "Votez jusqu'au",
    x: 185,
    baseline: 1514,
    size: 34,
    color: COLORS.blanc,
    weight: 400,
    tracking: -5,
    role: "Début de la phrase d'appel au vote.",
  });
  const votez2 = textLayer({
    name: "TXT_Vote_Date",
    text: "1er Décembre 2026",
    x: 185 + wVotez + 9,
    baseline: 1514,
    size: 34,
    color: COLORS.blanc,
    weight: 700,
    role: "Date limite en gras.",
  });
  const btn = shapeLayer("SHAPE_Fond_Bouton_Lien", roundRectKnots(184, 1532, 571, 60, 12), {
    fill: COLORS.vertBouton,
    role: "Bouton vert (rectangle arrondi, rayon 12 px).",
  });
  const pastilleLien = shapeLayer("SHAPE_Pastille_Fleche_Lien", ellipseKnots(222, 1562, 19, 19), {
    fill: COLORS.blanc,
    role: "Pastille blanche de l'icône flèche du bouton.",
  });
  const flecheLien = shapeLayer("SHAPE_Fleche_Lien", poly(arrowPts(222, 1562, 1.05)), {
    fill: COLORS.vertBouton,
    role: "Flèche verte à l'intérieur de la pastille.",
  });
  const lien = textLayer({
    name: "TXT_Lien_Vote",
    text: "https://abh2026top10vote.org",
    x: 256,
    baseline: 1575,
    size: 31,
    color: COLORS.blanc,
    weight: 700,
    role: "URL de vote dans le bouton.",
  });

  const swW = measure("(Swipez pour découvrir)", 41, 400, false, -5);
  const swipe = textLayer({
    name: "TXT_Swipez_Decouvrir",
    text: "(Swipez pour découvrir)",
    x: 1720 - swW,
    baseline: 1572,
    size: 41,
    color: COLORS.blanc,
    weight: 400,
    tracking: -5,
    role: "Invitation au swipe (aligné à droite sur x=1720).",
  });
  const pastilleSwipe = shapeLayer("SHAPE_Pastille_Swipe", ellipseKnots(1761, 1558, 28, 28), {
    fill: COLORS.vertLime,
    role: "Pastille lime du bouton de swipe.",
  });
  const flecheSwipe = shapeLayer("SHAPE_Fleche_Swipe", poly(arrowPts(1761, 1558, 1.7)), {
    fill: COLORS.vertSombre,
    role: "Flèche vert foncé du bouton de swipe.",
  });

  const gCta = group(
    "05_APPEL_ACTION",
    [votez1, votez2, btn, pastilleLien, flecheLien, lien, swipe, pastilleSwipe, flecheSwipe],
    "Appel au vote, bouton de lien et invitation au swipe."
  );

  /* ================================================================ */
  /*  06 — PIED DE PAGE                                                */
  /* ================================================================ */
  currentGroup = "06_PIED_DE_PAGE";

  const slogan = textLayer({
    name: "TXT_Slogan_Pied",
    text: "Le génie béninois à la conquête de l'Afrique !",
    x: 185,
    baseline: 1764,
    size: 46,
    color: COLORS.vertSombre,
    weight: 800,
    italic: true,
    tracking: -5,
    role: "Slogan en italique gras vert foncé.",
  });

  const social: Layer[] = [];
  const icons: Array<[string, number, string, number]> = [
    ["Facebook", 1362, "f", 40],
    ["X", 1425, "𝕏", 30],
    ["LinkedIn", 1490, "in", 30],
  ];
  for (const [label, ix, glyph, gs] of icons) {
    social.push(
      shapeLayer(`SHAPE_Pastille_${label}`, ellipseKnots(ix, 1744, 26, 26), {
        fill: COLORS.vertSombre,
        role: `Pastille ronde vert foncé du réseau ${label}.`,
      })
    );
    social.push(
      textLayer({
        name: `TXT_Icone_${label}`,
        text: label === "X" ? "X" : glyph,
        x: ix,
        baseline: label === "Facebook" ? 1760 : 1754,
        size: gs,
        color: COLORS.blanc,
        weight: 800,
        align: "center",
        role: `Glyphe ${label} (à remplacer par le pictogramme officiel si besoin).`,
      })
    );
  }
  const handle = textLayer({
    name: "TXT_Identifiant_Reseaux",
    text: "@gildaszodome",
    x: 1541,
    baseline: 1757,
    size: 31,
    color: COLORS.vertSombre,
    weight: 400,
    role: "Identifiant des réseaux sociaux.",
  });

  const gPied = group("06_PIED_DE_PAGE", [slogan, ...social, handle], "Slogan, icônes sociales et identifiant.");

  /* ================================================================ */
  /*  Assemblage du document                                           */
  /* ================================================================ */
  const children = [gBackground, gLogos, gTextes, gVisuels, gCta, gPied];

  // Aperçu composite
  const preview = cv(W, H);
  const pctx = preview.getContext("2d");
  const drawLayers = (layers: Layer[]) => {
    let base: Layer | null = null;
    for (const l of layers) {
      if (l.children) {
        drawLayers(l.children);
        continue;
      }
      if (!l.canvas) continue;
      if (l.clipping && base?.canvas) {
        const tmp = cv(W, H);
        const t = tmp.getContext("2d");
        t.drawImage(l.canvas, l.left ?? 0, l.top ?? 0);
        t.globalCompositeOperation = "destination-in";
        t.drawImage(base.canvas, base.left ?? 0, base.top ?? 0);
        pctx.globalAlpha = l.opacity ?? 1;
        pctx.drawImage(tmp, 0, 0);
      } else {
        base = l;
        pctx.globalAlpha = l.opacity ?? 1;
        pctx.drawImage(l.canvas, l.left ?? 0, l.top ?? 0);
      }
    }
    pctx.globalAlpha = 1;
  };
  drawLayers(children);

  const psd: Psd = {
    width: W,
    height: H,
    channels: 3,
    bitsPerChannel: 8,
    colorMode: 3,
    children,
    canvas: preview,
    linkedFiles,
    imageResources: {
      resolutionInfo: {
        horizontalResolution: 300,
        horizontalResolutionUnit: "PPI",
        widthUnit: "Inches",
        verticalResolution: 300,
        verticalResolutionUnit: "PPI",
        heightUnit: "Inches",
      },
    },
  };

  const bytes = writePsdUint8Array(psd, { generateThumbnail: true });
  return { bytes, preview, spec, width: W, height: H };
}
