import { createInitialBoard, legalMoves, applyMove, gameStatus, chooseAIMove, countPieces } from './draughts.js';
import { createTurnClock, startTurnClock, completeTurnClock, remainingTurnMs, expireTurnClock, passTurnClock } from './time-control.js';
import { createMatchClock, advanceMatchClock, registerMatchTurn } from './match-clock.js';
import { getArenaRules, ARENA_OPTIONS, isArenaSquare } from './arena-rules.js';
import { recordPlayedGame } from './season-engine.js';
import { create3DScene } from './scene-3d.js';

let board,turn,selected,gameOver,locked,turnClock,matchClock,clockTicker,arena='terrestrial',selectedArena='terrestrial',activeFixture=null,careerApi=null,noProgressPlies=0,performance,scene3d=null,immersive3D=false;
const $=s=>document.querySelector(s);
const label=p=>p===1?'Pion rouge':p===-1?'Pion bleu':p===2?'Dame rouge':p===-2?'Dame bleue':'Vide';
const counts=()=>countPieces(board);
const now=()=>Date.now();
function setMessage(message){const el=$('#matchMessage');if(el)el.textContent=message;}
function setArenaOptions(){const select=$('#arenaSelect');if(!select)return;select.innerHTML=ARENA_OPTIONS.map(a=>`<option value="${a.id}">${a.name}</option>`).join('');select.value=arena;select.addEventListener('change',()=>{selectedArena=select.value;setMessage(`Arène choisie : ${getArenaRules(selectedArena).name}. Elle sera appliquée à la prochaine partie.`);});}
export function initMatchUI(api={}){
 careerApi=api;const host=$('#matchBoard');if(!host)return{startFixture:()=>false};
 setArenaOptions();$('#startMatch').addEventListener('click',()=>start(null));
 if(clockTicker)clearInterval(clockTicker);clockTicker=setInterval(tickClocks,100);start(null);
 return{startFixture:fixture=>start(fixture),toggle3D:setImmersive3D,getActiveFixture:()=>activeFixture};
}
function start(fixture=null){
 activeFixture=fixture;selectedArena=$('#arenaSelect')?.value||selectedArena;arena=selectedArena;noProgressPlies=0;performance={home:{moves:0,captures:0,promotions:0,kingMoves:0},away:{moves:0,captures:0,promotions:0,kingMoves:0}};board=createInitialBoard();turn=1;selected=null;gameOver=false;locked=false;
 turnClock=createTurnClock(20);startTurnClock(turnClock,now());
 matchClock=createMatchClock(getArenaRules(arena).clock,now());
 const nm=id=>{try{return careerApi?.getState?.().divisions.flatMap(d=>d.clubs).find(c=>c.id===id)?.name||id;}catch{return id;}};const title=fixture?`${nm(fixture.home)} — ${nm(fixture.away)}`:'Partie d’essai';
 $('#activeFixture').textContent=title;
 setMessage(`${getArenaRules(arena).name} · À toi de jouer. 20 secondes par tour.`);
 render();tickClocks();if(immersive3D&&scene3d?.available){scene3d.playPose?.(board,1,'presentation',650);setTimeout(()=>{if(!gameOver&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,-1,'presentation',650);},700);setTimeout(()=>{if(!gameOver&&turn===1&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'thinking',750);},1400);}
}
function piecesBySide(){const c=counts();return{1:c[1],'-1':c[-1]};}
function stopClocks(){if(turnClock){turnClock.running=false;turnClock.deadlineAt=null;}if(matchClock){matchClock.running=false;matchClock.deadlineAt=null;}}
function finish(result,reason='board-result'){
 if(gameOver)return;gameOver=true;locked=false;stopClocks();selected=null;
 const c=counts();const winner=result?.winner??null;
 const lunar=activeFixture?.competitionId==='coupe-lunaire';const international=activeFixture?.competitionId==='intergalactique';const outcome=winner===1?(lunar?'Victoire de ta galaxie.':international?'Victoire de ta sélection.':'Victoire du club dirigé.'):winner===-1?(lunar?'Défaite de ta galaxie.':international?'Défaite de ta sélection.':'Défaite du club dirigé.'):(lunar||international?'Match nul au damier : départage réglementaire appliqué.':'Match nul.');
 setMessage(`${outcome} (${c[1]} pièces rouges – ${c[-1]} pièces bleues). ${reasonLabel(reason)}`);
 if(activeFixture&&careerApi?.getState){
  const state=careerApi.getState();const fixture=state.calendar.fixtures.find(f=>f.id===activeFixture.id);
  if(fixture&&fixture.status!=='played'){
   const recorded=recordPlayedGame(state,fixture.id,winner,{arena,arenaName:getArenaRules(arena).name,reason,pieces:c,turns:{...matchClock.turns},globalPhase:matchClock.phase,performance});
   if(recorded.accepted)careerApi.onFixtureResult?.(fixture);
  }
 }
 render();if(immersive3D&&scene3d?.available&&winner!==null){scene3d.playPose?.(board,winner,'celebrate',1100);setTimeout(()=>{if(immersive3D&&scene3d?.available)scene3d.playPose?.(board,-winner,'defeat',900);},1150);}
}
function reasonLabel(reason){return ({'no-pieces':'Toutes les pièces adverses ont été éliminées.','no-legal-move':'L’adversaire ne possède plus de coup légal.','time-piece-count':'Temps global écoulé : résultat selon le nombre de pièces.','overtime-piece-count':'Prolongation terminée : résultat selon le nombre de pièces.','temporal-turn-limit':'Limite temporelle atteinte : comparaison des pièces.','no-progress-draw':'50 demi-coups sans prise ni déplacement de pion : match nul.'})[reason]||'Rencontre terminée.';}
function resolveGlobalExpiry(){const result=advanceMatchClock(matchClock,now(),piecesBySide());if(result.expired){if(result.result?.reason==='overtime-started'){setMessage('Temps initial écoulé à égalité : prolongation de 3 minutes.');render();}else if(result.result)finish(result.result,result.result.reason);}}
function tickClocks(){if(!turnClock||gameOver)return;resolveGlobalExpiry();if(gameOver)return;const ms=remainingTurnMs(turnClock,now());const el=$('#matchClock');if(el)el.textContent=`${(ms/1000).toFixed(1)} s`;const global=$('#matchGlobalClock');if(global){const left=matchClock.deadlineAt===null?null:Math.max(0,matchClock.deadlineAt-now());global.textContent=left===null?'Sans limite':`${Math.floor(left/60000)}:${String(Math.floor(left/1000)%60).padStart(2,'0')}`;}
 if(ms<=0&&turnClock.running)passHandAfterTimeout();}
function passHandAfterTimeout(){if(gameOver)return;locked=false;const timedOut=turn;expireTurnClock(turnClock);selected=null;turn=-turn;passTurnClock(turnClock);const status=gameStatus(board,turn,{arena});if(status.over){finish(status,status.reason);return;}startTurnClock(turnClock,now());setMessage(timedOut===1?'20 secondes écoulées : tu perds la main. L’adversaire joue.':'20 secondes écoulées : l’adversaire perd la main. À toi de jouer.');render();if(turn===-1)runAI();}
function render(){const host=$('#matchBoard');if(!host)return;const rules=getArenaRules(arena);const moves=gameOver||turn!==1?[]:legalMoves(board,1,{arena});const selectedMoves=selected?moves.filter(m=>m.path[0].from[0]===selected[0]&&m.path[0].from[1]===selected[1]):[];const targets=new Set(selectedMoves.map(m=>m.path.at(-1).to.join(',')));host.querySelectorAll('.square').forEach(node=>node.remove());const choices=$('#moveChoices');if(choices)choices.innerHTML='';for(let r=0;r<10;r++)for(let c=0;c<10;c++){const cell=document.createElement('button');cell.className='square '+((r+c)%2?'dark':'light');if(selected?.[0]===r&&selected?.[1]===c)cell.classList.add('selected');if(targets.has(`${r},${c}`))cell.classList.add('target');if(isArenaSquare(rules.lava,r,c))cell.classList.add('lava-square');if(isArenaSquare(rules.crystals,r,c))cell.classList.add('crystal-square');const p=board[r][c];if(p){cell.textContent=Math.abs(p)===2?'♛':'●';cell.classList.add(p>0?'red-piece':'blue-piece');cell.setAttribute('aria-label',label(p));}else if(isArenaSquare(rules.lava,r,c))cell.textContent='🌋';else if(isArenaSquare(rules.crystals,r,c))cell.textContent='💎';cell.disabled=gameOver||locked||turn!==1;cell.addEventListener('click',()=>clickSquare(r,c));host.appendChild(cell);}
 if(immersive3D&&scene3d?.available){const targetsNow=new Set(selectedMoves.map(m=>m.path.at(-1).to.join(',')));scene3d.draw(board,selected,targetsNow,true);}
 $('#matchTurn').textContent=gameOver?'Partie terminée':turn===1?'À toi — rouge':'IA — bleu';$('#matchClock').textContent=`${(remainingTurnMs(turnClock,now())/1000).toFixed(1)} s`;$('#redCount').textContent=counts()[1];$('#blueCount').textContent=counts()[-1];$('#arenaRule').textContent=rules.name+' : '+arenaDescription(arena);
}
function arenaDescription(id){return ({terrestrial:'règles classiques',neon:'chrono global de 2 minutes',crystalline:'cristaux couronnant les pions',gravitational:'dames limitées à 3 cases hors prise',volcanic:'cases de lave destructrices',oceanic:'prises des pions vers l’avant uniquement',temporal:'40 coups par camp, puis comparaison des pièces',dimensional:'couronnement dès l’avant-dernière rangée',galacticSupreme:'2 min 30, lave et cristaux'})[id];}
function clickSquare(r,c){if(gameOver||locked||turn!==1)return;const moves=legalMoves(board,1,{arena});if(selected){const candidates=moves.filter(m=>m.path[0].from[0]===selected[0]&&m.path[0].from[1]===selected[1]&&m.path.at(-1).to[0]===r&&m.path.at(-1).to[1]===c);if(candidates.length){if(candidates.length>1){const panel=$('#moveChoices');if(panel){panel.innerHTML='<b>Choisis ton chemin de prise :</b>';candidates.forEach((m,i)=>{const button=document.createElement('button');button.textContent=`Chemin ${i+1} · ${m.captures.length} prise(s) · ${m.path.map(step=>`${step.to[0]+1},${step.to[1]+1}`).join(' → ')}`;button.addEventListener('click',()=>play(m,1));panel.appendChild(button);});}setMessage('Plusieurs chemins légaux aboutissent sur cette case. Choisis le trajet exact.');return;}play(candidates[0],1);return;}}
 if(board[r][c]>0&&moves.some(m=>m.path[0].from[0]===r&&m.path[0].from[1]===c)){selected=[r,c];render();}else if(!selected)setMessage('Choisis un pion rouge qui possède au moins un coup légal.');}
function play(move,player){resolveGlobalExpiry();if(gameOver)return;const timed=completeTurnClock(turnClock,now());if(!timed.accepted){passHandAfterTimeout();return;}resolveGlobalExpiry();if(gameOver)return;const movingPiece=board[move.path[0].from[0]][move.path[0].from[1]];const sideStats=player===1?performance.home:performance.away;sideStats.moves++;sideStats.captures+=move.captures?.length||0;if(Math.abs(movingPiece)===2)sideStats.kingMoves++;board=applyMove(board,move,{arena});const[pr,pc]=move.path.at(-1).to;if(Math.abs(movingPiece)===1&&Math.abs(board[pr][pc])===2)sideStats.promotions++;noProgressPlies=(move.captures?.length||Math.abs(movingPiece)===1)?0:noProgressPlies+1;selected=null;const c=piecesBySide();if(arena==='temporal'){registerMatchTurn(matchClock,player,c);if(matchClock.result){finish(matchClock.result,'temporal-turn-limit');return;}}if(noProgressPlies>=50){finish({winner:null},'no-progress-draw');return;}const status=gameStatus(board,-player,{arena});if(status.over){finish(status,status.reason);return;}turn=-player;startTurnClock(turnClock,now());render();if(immersive3D&&scene3d?.available)scene3d.animateMove?.(board,move,board[pr][pc],selected,new Set());if(turn===-1)runAI();else{setMessage('À toi de jouer. Les prises sont obligatoires. Tu disposes de 20 secondes.');if(immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'thinking',650);}}
function runAI(){locked=true;startTurnClock(turnClock,now());setMessage('L’IA réfléchit…');render();if(immersive3D&&scene3d?.available)setTimeout(()=>{if(!gameOver&&turn===-1&&locked&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,-1,'thinking',650);},420);setTimeout(()=>{if(gameOver||turn!==-1||!locked)return;resolveGlobalExpiry();if(gameOver)return;const ai=chooseAIMove(board,-1,{arena});if(!ai){finish({winner:1},'no-legal-move');return;}const timed=completeTurnClock(turnClock,now());if(!timed.accepted){passHandAfterTimeout();return;}resolveGlobalExpiry();if(gameOver)return;const movingPiece=board[ai.path[0].from[0]][ai.path[0].from[1]];const sideStats=performance.away;sideStats.moves++;sideStats.captures+=ai.captures?.length||0;if(Math.abs(movingPiece)===2)sideStats.kingMoves++;board=applyMove(board,ai,{arena});const[pr,pc]=ai.path.at(-1).to;if(Math.abs(movingPiece)===1&&Math.abs(board[pr][pc])===2)sideStats.promotions++;noProgressPlies=(ai.captures?.length||Math.abs(movingPiece)===1)?0:noProgressPlies+1;const c=piecesBySide();if(arena==='temporal'){registerMatchTurn(matchClock,-1,c);if(matchClock.result){finish(matchClock.result,'temporal-turn-limit');return;}}turn=1;locked=false;if(noProgressPlies>=50){finish({winner:null},'no-progress-draw');return;}const end=gameStatus(board,1,{arena});if(end.over){finish(end,end.reason);return;}startTurnClock(turnClock,now());setMessage('À toi de jouer. Les prises sont obligatoires. Tu as 20 secondes.');render();if(immersive3D&&scene3d?.available){scene3d.animateMove?.(board,ai,board[pr][pc],selected,new Set());setTimeout(()=>{if(!gameOver&&turn===1&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'thinking',650);},450);}},850);}


export function setImmersive3D(enabled){
 const host=$('#matchBoard'),button=$('#toggle3dView');if(!host)return false;
 if(enabled){
  if(!scene3d){try{scene3d=create3DScene(host);}catch(error){scene3d=null;setMessage(`Le moteur WebGL n’a pas pu démarrer : ${error.message}`);return false;}}
  if(!scene3d.available){setMessage('Ce navigateur ou cet appareil ne prend pas en charge WebGL. La vue classique reste disponible.');return false;}
  immersive3D=true;host.classList.add('board--webgl');if(button)button.textContent='Désactiver le moteur 3D';setMessage('Vue 3D WebGL activée : damier en volume, pièces modélisées, éclairage et perspective. Les règles et les coups légaux restent inchangés.');render();return true;
 }
 immersive3D=false;host.classList.remove('board--webgl');if(scene3d){scene3d.destroy();scene3d=null;}if(button)button.textContent='Activer le moteur 3D';render();setMessage('Vue classique rétablie.');return true;
}
