import { createInitialBoard, legalMoves, applyMove, gameStatus, chooseAIMove, countPieces } from './draughts.js';
import { createTurnClock, startTurnClock, completeTurnClock, remainingTurnMs, expireTurnClock, passTurnClock } from './time-control.js';
import { createMatchClock, advanceMatchClock, registerMatchTurn } from './match-clock.js';
import { getArenaRules, ARENA_OPTIONS, isArenaSquare } from './arena-rules.js';
import { recordPlayedGame } from './season-engine.js';
import { create3DScene } from './scene-3d.js';
import { buildMatchKitStyle } from './match-kit.js';
import { getFixtureDamiste } from './dame-or.js';
import { createMatchReport, calculateDamisteRating, orientPerformanceForFixture } from './match-report.js';

let board,turn,selected,gameOver,locked,turnClock,matchClock,clockTicker,arena='terrestrial',selectedArena='terrestrial',activeFixture=null,careerApi=null,noProgressPlies=0,performance,scene3d=null,immersive3D=false;
const $=s=>document.querySelector(s);
const label=p=>p===1?'Pion blanc':p===-1?'Pion rouge':p===2?'Dame blanche':p===-2?'Dame rouge':'Vide';
const counts=()=>countPieces(board);
const now=()=>Date.now();
function setMessage(message){const el=$('#matchMessage');if(el)el.textContent=message;}
function setArenaOptions(){const select=$('#arenaSelect');if(!select)return;select.innerHTML=ARENA_OPTIONS.map(a=>`<option value="${a.id}">${a.name}</option>`).join('');select.value=arena;select.addEventListener('change',()=>{selectedArena=select.value;setMessage(`Arène choisie : ${getArenaRules(selectedArena).name}. Elle sera appliquée à la prochaine partie.`);});}
export function initMatchUI(api={}){
 careerApi=api;const host=$('#matchBoard');if(!host)return{startFixture:()=>false};
 const goHome=()=>document.querySelector('[data-screen-link="accueil"]')?.click();
 $('#mkBack')?.addEventListener('click',goHome);$('#mkClose')?.addEventListener('click',goHome);
 $('#mkSave')?.addEventListener('click',()=>{document.querySelector('#manualSave')?.click();setMessage('Partie sauvegardée.');});
 $('#mkLoad')?.addEventListener('click',()=>document.querySelector('#reloadCareer')?.click());
 $('#mkEndAgain')?.addEventListener('click',()=>start(null));
 $('#mkEndDone')?.addEventListener('click',()=>{const endBox=$('#mkEnd');if(endBox)endBox.hidden=true;const n=$('#matchNext');if(n&&!n.hidden)n.click();else goHome();});
 $('#mkHelp')?.addEventListener('click',()=>setMessage('Touche un pion blanc, puis une case en surbrillance pour jouer.'));
 setArenaOptions();$('#startMatch').addEventListener('click',()=>start(null));
 document.querySelectorAll('[data-match-view]').forEach(button=>button.addEventListener('click',()=>setMatchView(button.dataset.matchView)));
 $('#matchActionTactics')?.addEventListener('click',()=>$('#openTactics')?.click());
 $('#matchAction3D')?.addEventListener('click',()=>setImmersive3D(!immersive3D));
 $('#matchActionArena')?.addEventListener('click',()=>{setMatchView('overview');setMessage($('#arenaRule')?.textContent||'Règles de l’arène');});
 if(clockTicker)clearInterval(clockTicker);clockTicker=setInterval(tickClocks,100);start(null);
 return{startFixture:fixture=>start(fixture),toggle3D:setImmersive3D,getActiveFixture:()=>activeFixture};
}
function setMatchView(view){
 const allowed=['overview','notes','stats','actions'];if(!allowed.includes(view))return;
 document.querySelectorAll('[data-match-view]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.matchView===view)));
 document.querySelectorAll('[data-match-panel]').forEach(panel=>panel.hidden=panel.dataset.matchPanel!==view);
 const host=$('#matchViewPanel');if(host)host.dataset.activeView=view;
}
function matchSides(){
 const state=careerApi?.getState?.(),clubs=new Map((state?.divisions||[]).flatMap(d=>(d.clubs||[]).map(c=>[c.id,c])));
 const fixture=activeFixture||{},home=clubs.get(fixture.home),away=clubs.get(fixture.away);
 const playerFor=(club,side)=>{try{return club&&fixture.id?getFixtureDamiste(club,fixture,side):null;}catch{return null;}};
 return [{key:'home',club:home,name:home?.name||'Équipe blanche',player:playerFor(home,'home')},{key:'away',club:away,name:away?.name||'Équipe rouge',player:playerFor(away,'away')}];
}

function matchKitStyle(){const sides=matchSides(),userClubId=careerApi?.getState?.()?.userClubId;return buildMatchKitStyle(sides[0].club,sides[1].club,userClubId);}
function applyMatchKitTo2DBoard(){
 const style=matchKitStyle(),host=$('#matchBoard');if(!host)return;
 host.style.setProperty('--home-kit-primary',style.home.primary);host.style.setProperty('--home-kit-secondary',style.home.secondary);host.style.setProperty('--away-kit-primary',style.away.primary);host.style.setProperty('--away-kit-secondary',style.away.secondary);host.style.setProperty('--home-board-primary',style.board.primary);host.style.setProperty('--home-board-secondary',style.board.secondary);
 host.querySelectorAll('.square').forEach((cell)=>{const isHome=cell.classList.contains('red-piece'),isAway=cell.classList.contains('blue-piece'),isLight=cell.classList.contains('light');if(isHome||isAway){cell.style.background=isHome?style.home.primary:style.away.primary;cell.style.color=isHome?style.home.secondary:style.away.secondary;cell.style.borderColor=isHome?style.home.secondary:style.away.secondary;}else if(!cell.classList.contains('selected')&&!cell.classList.contains('target')){cell.style.background=isLight?style.board.primary:style.board.secondary;cell.style.borderColor=isLight?style.board.secondary:style.board.primary;}});
}

function ratingFor(stats){return calculateDamisteRating(stats);}
function fixtureSidePerformance(sides=sidesForActiveFixture(), raw=performance){
 const userClubId=careerApi?.getState?.()?.userClubId;const userSide=sides.find(side=>side.club?.id===userClubId)?.key||'home';
 return orientPerformanceForFixture(raw,userSide);
}
function sidesForActiveFixture(){return matchSides();}
function renderMatchViews(){
 const sides=matchSides(),sidePerformance=fixtureSidePerformance(sides),home=sidePerformance.home,away=sidePerformance.away;
 const totalMoves=home.moves+away.moves,red=counts()?.[1]??0,blue=counts()?.[-1]??0;
 const status=gameOver?'Terminée':turn===1?'À toi de jouer':'Tour de l’adversaire';
 const overview=$('#matchOverviewText');if(overview)overview.textContent=`${sides[0].name} contre ${sides[1].name} · ${getArenaRules(arena).name} · ${gameOver?'Résultat enregistré':'Rencontre en cours'}.`;
 const set=(id,value)=>{const el=$(id);if(el)el.textContent=value;};
 set('#overviewStatus',status);set('#overviewPieces',`${red} – ${blue}`);set('#overviewMoves',String(totalMoves));
 const notes=$('#matchPlayerNotes');if(notes)notes.innerHTML=sides.map((side,i)=>{const st=i===0?home:away,name=side.player?.name||`Titulaire ${i===0?'blanc':'rouge'}`,rating=ratingFor(st),comment=st.captures?`${st.captures} prise(s) réalisée(s)`:st.promotions?'Promotion obtenue':st.moves?'Participation active à la partie':'Aucune action enregistrée pour le moment';return `<article class="fm-box"><small>${side.name}</small><b>${name}</b><strong>${rating.toFixed(1)}/10</strong><small>${comment}</small><small>${st.moves} coup(s) · ${st.captures} prise(s)</small></article>`;}).join('');
 const stats=$('#matchStats');if(stats)stats.innerHTML=sides.map((side,i)=>{const st=i===0?home:away;return `<article class="fm-box"><small>${side.name}</small><b>${st.moves} coups joués</b><small>Prises : ${st.captures}</small><small>Promotions : ${st.promotions}</small><small>Déplacements de dames : ${st.kingMoves}</small></article>`;}).join('')+`<article class="fm-box"><small>État du damier</small><b>${red+blue} pièces restantes</b><small>${gameOver?'Partie terminée':'Partie en cours'}</small></article>`;
}
function start(fixture=null){
 {const endBox=$('#mkEnd');if(endBox)endBox.hidden=true;}activeFixture=fixture;selectedArena=$('#arenaSelect')?.value||selectedArena;arena=selectedArena;noProgressPlies=0;performance={home:{moves:0,captures:0,promotions:0,kingMoves:0},away:{moves:0,captures:0,promotions:0,kingMoves:0}};board=createInitialBoard();turn=1;selected=null;gameOver=false;locked=false;
 turnClock=createTurnClock(20);startTurnClock(turnClock,now());
 matchClock=createMatchClock(getArenaRules(arena).clock,now());
 const nm=id=>{try{return careerApi?.getState?.().divisions.flatMap(d=>d.clubs).find(c=>c.id===id)?.name||id;}catch{return id;}};const title=fixture?`${nm(fixture.home)} — ${nm(fixture.away)}`:'Partie d’essai';
 $('#activeFixture').textContent=title;
 setMessage(`${getArenaRules(arena).name} · À toi de jouer. 20 secondes par tour.`);
 render();tickClocks();if(immersive3D&&scene3d?.available){scene3d.playPose?.(board,1,'presentation',650);setTimeout(()=>{if(!gameOver&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,-1,'presentation',650);},700);setTimeout(()=>{if(!gameOver&&turn===1&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'thinking',750);},1400);}
}
function piecesBySide(){const c=counts();return{1:c[1],'-1':c[-1]};}
function stopClocks(){if(turnClock){turnClock.running=false;turnClock.deadlineAt=null;}if(matchClock){matchClock.running=false;matchClock.deadlineAt=null;}}
function finish(result,reason='board-result'){
 if(gameOver)return;gameOver=true;locked=false;stopClocks();selected=null;
 const c=counts();const winner=result?.winner??null;
 const lunar=activeFixture?.competitionId==='coupe-lunaire';const international=activeFixture?.competitionId==='intergalactique';const outcome=winner===1?(lunar?'Victoire de ta galaxie.':international?'Victoire de ta sélection.':'Victoire du club dirigé.'):winner===-1?(lunar?'Défaite de ta galaxie.':international?'Défaite de ta sélection.':'Défaite du club dirigé.'):(lunar||international?'Match nul au damier : départage réglementaire appliqué.':'Match nul.');
 setMessage(`${outcome} (${c[1]} pièces blanches – ${c[-1]} pièces rouges). ${reasonLabel(reason)}`);
 if(activeFixture&&careerApi?.getState){
  const state=careerApi.getState();const fixture=state.calendar.fixtures.find(f=>f.id===activeFixture.id);
  if(fixture&&fixture.status!=='played'){
   try{
    const sides=matchSides();const userSide=sides.find(side=>side.club?.id===state.userClubId)?.key||'home';const fixturePerformance=orientPerformanceForFixture(performance,userSide);const report=createMatchReport({fixture,sides,performance:fixturePerformance,arena,arenaName:getArenaRules(arena).name,reason,pieces:c,turns:{...matchClock.turns},globalPhase:matchClock.phase,winnerSide:winner});
    const recorded=recordPlayedGame(state,fixture.id,winner,{arena,arenaName:getArenaRules(arena).name,reason,pieces:c,turns:{...matchClock.turns},globalPhase:matchClock.phase,performance:fixturePerformance,report});
    if(recorded?.accepted){
     careerApi.onFixtureResult?.(fixture);
     setMessage(`${outcome} Résultat enregistré au classement (${recorded.score?.[0]??'?'}–${recorded.score?.[1]??'?'}).`);
    }else{
     setMessage(`${outcome} Le résultat n'a pas pu être inscrit (déjà traité ou refus).`);
    }
   }catch(err){
    setMessage(`${outcome} Erreur d'enregistrement : ${err?.message||err}. Relance via CONTINUER puis Prochain match.`);
    console.warn('recordPlayedGame failed',err);
   }
  }else if(fixture&&fixture.status==='played'){
   setMessage(`${outcome} Cette rencontre était déjà enregistrée.`);
   careerApi.onFixtureResult?.(fixture);
  }
 }
 showMkEnd(winner,c);render();if(immersive3D&&scene3d?.available&&winner!==null){scene3d.playPose?.(board,winner,'celebrate',1100);setTimeout(()=>{if(immersive3D&&scene3d?.available)scene3d.playPose?.(board,-winner,'defeat',900);},1150);}
}
function reasonLabel(reason){return ({'no-pieces':'Toutes les pièces adverses ont été éliminées.','no-legal-move':'L’adversaire ne possède plus de coup légal.','time-piece-count':'Temps global écoulé : résultat selon le nombre de pièces.','overtime-piece-count':'Prolongation terminée : résultat selon le nombre de pièces.','temporal-turn-limit':'Limite temporelle atteinte : comparaison des pièces.','no-progress-draw':'50 demi-coups sans prise ni déplacement de pion : match nul.'})[reason]||'Rencontre terminée.';}
function resolveGlobalExpiry(){const result=advanceMatchClock(matchClock,now(),piecesBySide());if(result.expired){if(result.result?.reason==='overtime-started'){setMessage('Temps initial écoulé à égalité : prolongation de 3 minutes.');render();}else if(result.result)finish(result.result,result.result.reason);}}
function tickClocks(){if(!turnClock||gameOver)return;resolveGlobalExpiry();if(gameOver)return;const ms=remainingTurnMs(turnClock,now());const el=$('#matchClock');if(el)el.textContent=`${(ms/1000).toFixed(1)} s`;const global=$('#matchGlobalClock');if(global){const left=matchClock.deadlineAt===null?null:Math.max(0,matchClock.deadlineAt-now());global.textContent=left===null?'Sans limite':`${Math.floor(left/60000)}:${String(Math.floor(left/1000)%60).padStart(2,'0')}`;}
 if(ms<=0&&turnClock.running)passHandAfterTimeout();}
function passHandAfterTimeout(){if(gameOver)return;locked=false;const timedOut=turn;expireTurnClock(turnClock);selected=null;turn=-turn;passTurnClock(turnClock);const status=gameStatus(board,turn,{arena});if(status.over){finish(status,status.reason);return;}startTurnClock(turnClock,now());setMessage(timedOut===1?'20 secondes écoulées : tu perds la main. L’adversaire joue.':'20 secondes écoulées : l’adversaire perd la main. À toi de jouer.');render();if(turn===-1)runAI();}

const mkEsc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mkHex=(v,f)=>/^#[0-9a-f]{6}$/i.test(v||'')?v:f;
let mkUid=0;
function mkShield(club){const em=club?.visualIdentity?.emblem||{},p=mkHex(em.primary,'#1e56c4'),s=mkHex(em.secondary,'#0d2c6c'),id='mks'+(++mkUid);return `<svg class="mk-shield" viewBox="0 0 100 118" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${p}"/><stop offset="1" stop-color="${s}"/></linearGradient></defs><path d="M50 3 92 17v40c0 30-22 49-42 58C30 106 8 87 8 57V17z" fill="url(#${id})" stroke="#f3c640" stroke-width="5" stroke-linejoin="round"/><text x="50" y="72" text-anchor="middle" font-size="40" fill="#fff" font-family="system-ui,sans-serif">${mkEsc(em.symbol||'★')}</text></svg>`;}
function mkKit(club){const k=club?.visualIdentity?.kit||{},p=mkHex(k.primary,'#1e56c4'),s=mkHex(k.secondary,'#ffffff');return `<svg viewBox="0 0 100 100" aria-hidden="true"><path d="M30 8 10 22 2 44l18 8 4-12v52h52V40l4 12 18-8-8-22L70 8Q50 22 30 8z" fill="${p}" stroke="${s}" stroke-width="3" stroke-linejoin="round"/><rect x="38" y="16" width="7" height="76" fill="${s}" opacity=".35"/><rect x="55" y="16" width="7" height="76" fill="${s}" opacity=".35"/><path d="M36 8Q50 22 64 8" fill="none" stroke="${s}" stroke-width="4"/><text x="50" y="66" text-anchor="middle" font-size="24" font-weight="900" fill="${s}" font-family="Arial,sans-serif">${mkEsc(String(k.number||'').slice(0,2)||'★')}</text></svg>`;}
function renderMkSides(){
 const state=careerApi?.getState?.();if(!state||!$('#mkLeftHead'))return;
 const sides=matchSides(),uid=state.userClubId;
 const left=sides.find(s=>s.club?.id===uid)||sides[0],right=sides.find(s=>s!==left)||sides[1];
 const sideLabel=s=>s.key==='home'?'(Domicile)':'(Extérieur)';
 const mgr=s=>{const c=s.club;if(!c)return '—';if(c.id===uid&&state.career?.manager)return state.career.manager.displayName;return c.manager||(state.world?.clubManagers||[]).find(x=>x.club===c.name)?.name||'—';};
 const pl=(s,dot)=>{const roster=s.club?.damistes||[],t=s.player||roster[0],r=roster.find(p=>p&&t&&p.id!==t.id&&p!==t);return [[t,'Titulaire'],[r,'Remplaçant']].map(([p,role])=>{const name=p?.name||'—',ini=name.split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase();return `<li><span class="ph">${mkEsc(ini)}</span><div><b>${mkEsc(name)}</b><small>${role}${p?.level?' · niv. '+mkEsc(p.level):''}</small></div><span class="dot ${dot}"></span></li>`;}).join('');};
 const form=s=>{const t=s.player||s.club?.damistes?.[0],f=Math.max(1,Math.min(5,Math.round((Number(t?.form??60))/20)));return `<div class="mk-form">Forme ${[1,2,3,4,5].map(i=>`<i class="${i<=f?'on':''}"></i>`).join('')}</div>`;};
 const head=s=>`${mkShield(s.club)}<div><b>${mkEsc(s.name)}</b><small>${sideLabel(s)}</small></div>`;
 const body=s=>`<div class="mk-kit">${mkKit(s.club)}</div><div><small>Manager</small><b>${mkEsc(mgr(s))}</b>${form(s)}</div>`;
 const set=(id,html)=>{const el=$(id);if(el)el.innerHTML=html;};
 set('#mkLeftHead',head(left));set('#mkLeftBody',body(left));set('#mkLeftPlayers',pl(left,'w'));
 set('#mkRightHead',head(right));set('#mkRightBody',body(right));set('#mkRightPlayers',pl(right,'n'));
 set('#mkSbHomeShield',mkShield(left.club));set('#mkSbAwayShield',mkShield(right.club));
 const txt=(id,t)=>{const el=$(id);if(el)el.textContent=t;};
 txt('#mkSbHomeName',left.name);txt('#mkSbHomeSide',sideLabel(left));txt('#mkSbAwayName',right.name);txt('#mkSbAwaySide',sideLabel(right));
}
function showMkEnd(winner,c){
 const box=$('#mkEnd');if(!box)return;
 const title=$('#mkEndTitle');title.textContent=winner===1?'Victoire !':winner===-1?'Défaite':'Match nul';title.dataset.res=winner===1?'win':winner===-1?'loss':'draw';
 $('#mkEndScore').textContent=`${c[1]} pièces blanches – ${c[-1]} pièces rouges`;
 const msg=$('#matchMessage')?.textContent||'';
 $('#mkEndInfo').textContent=activeFixture?(/pas pu|Erreur/.test(msg)?msg:'Résultat enregistré au classement et au calendrier.'):'Partie d’essai : aucun résultat enregistré.';
 const again=$('#mkEndAgain');if(again)again.hidden=!!activeFixture;
 box.hidden=false;
}
function render(){const host=$('#matchBoard');if(!host)return;const rules=getArenaRules(arena);const moves=gameOver||turn!==1?[]:legalMoves(board,1,{arena});const selectedMoves=selected?moves.filter(m=>m.path[0].from[0]===selected[0]&&m.path[0].from[1]===selected[1]):[];const targets=new Set(selectedMoves.map(m=>m.path.at(-1).to.join(',')));host.querySelectorAll('.square').forEach(node=>node.remove());const choices=$('#moveChoices');if(choices)choices.innerHTML='';for(let r=0;r<10;r++)for(let c=0;c<10;c++){const cell=document.createElement('button');cell.className='square '+((r+c)%2?'dark':'light');if(selected?.[0]===r&&selected?.[1]===c)cell.classList.add('selected');if(targets.has(`${r},${c}`))cell.classList.add('target');if(isArenaSquare(rules.lava,r,c))cell.classList.add('lava-square');if(isArenaSquare(rules.crystals,r,c))cell.classList.add('crystal-square');const p=board[r][c];if(p){cell.textContent=Math.abs(p)===2?'♛':'●';cell.classList.add(p>0?'red-piece':'blue-piece');if(Math.abs(p)===2)cell.classList.add('king-piece');cell.setAttribute('aria-label',label(p));}else if(isArenaSquare(rules.lava,r,c))cell.textContent='🌋';else if(isArenaSquare(rules.crystals,r,c))cell.textContent='💎';cell.disabled=gameOver||locked||turn!==1;cell.addEventListener('click',()=>clickSquare(r,c));host.appendChild(cell);}
 applyMatchKitTo2DBoard();
 if(immersive3D&&scene3d?.available){const targetsNow=new Set(selectedMoves.map(m=>m.path.at(-1).to.join(',')));scene3d.draw(board,selected,targetsNow,true,null,null,matchKitStyle());}
 $('#matchTurn').textContent=gameOver?'Partie terminée':turn===1?'À toi — blanc':'IA — rouge';$('#matchClock').textContent=`${(remainingTurnMs(turnClock,now())/1000).toFixed(1)} s`;$('#redCount').textContent=counts()[1];$('#blueCount').textContent=counts()[-1];$('#arenaRule').textContent=rules.name+' : '+arenaDescription(arena);renderMatchViews();renderMkSides();
}
function arenaDescription(id){return ({terrestrial:'règles classiques',neon:'chrono global de 2 minutes',crystalline:'cristaux couronnant les pions',gravitational:'dames limitées à 3 cases hors prise',volcanic:'cases de lave destructrices',oceanic:'prises des pions vers l’avant uniquement',temporal:'40 coups par camp, puis comparaison des pièces',dimensional:'couronnement dès l’avant-dernière rangée',galacticSupreme:'2 min 30, lave et cristaux'})[id];}
function clickSquare(r,c){if(gameOver||locked||turn!==1)return;const moves=legalMoves(board,1,{arena});if(selected){const candidates=moves.filter(m=>m.path[0].from[0]===selected[0]&&m.path[0].from[1]===selected[1]&&m.path.at(-1).to[0]===r&&m.path.at(-1).to[1]===c);if(candidates.length){if(candidates.length>1){const panel=$('#moveChoices');if(panel){panel.innerHTML='<b>Choisis ton chemin de prise :</b>';candidates.forEach((m,i)=>{const button=document.createElement('button');button.textContent=`Chemin ${i+1} · ${m.captures.length} prise(s) · ${m.path.map(step=>`${step.to[0]+1},${step.to[1]+1}`).join(' → ')}`;button.addEventListener('click',()=>play(m,1));panel.appendChild(button);});}setMessage('Plusieurs chemins légaux aboutissent sur cette case. Choisis le trajet exact.');return;}play(candidates[0],1);return;}}
 if(board[r][c]>0&&moves.some(m=>m.path[0].from[0]===r&&m.path[0].from[1]===c)){selected=[r,c];render();}else if(!selected)setMessage('Choisis un pion blanc qui possède au moins un coup légal.');}
function play(move,player){resolveGlobalExpiry();if(gameOver)return;const timed=completeTurnClock(turnClock,now());if(!timed.accepted){passHandAfterTimeout();return;}resolveGlobalExpiry();if(gameOver)return;const movingPiece=board[move.path[0].from[0]][move.path[0].from[1]];const sideStats=player===1?performance.home:performance.away;sideStats.moves++;sideStats.captures+=move.captures?.length||0;if(Math.abs(movingPiece)===2)sideStats.kingMoves++;board=applyMove(board,move,{arena});const[pr,pc]=move.path.at(-1).to;if(Math.abs(movingPiece)===1&&Math.abs(board[pr][pc])===2)sideStats.promotions++;noProgressPlies=(move.captures?.length||Math.abs(movingPiece)===1)?0:noProgressPlies+1;selected=null;const c=piecesBySide();if(arena==='temporal'){registerMatchTurn(matchClock,player,c);if(matchClock.result){finish(matchClock.result,'temporal-turn-limit');return;}}if(noProgressPlies>=50){finish({winner:null},'no-progress-draw');return;}const status=gameStatus(board,-player,{arena});if(status.over){finish(status,status.reason);return;}turn=-player;startTurnClock(turnClock,now());render();if(immersive3D&&scene3d?.available){scene3d.animateMove?.(board,move,board[pr][pc],selected,new Set(),movingPiece);if(move.captures?.length){const capturedSide=-player;setTimeout(()=>{if(!gameOver&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,capturedSide,'disappointed',650);},520);setTimeout(()=>{if(!gameOver&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,player,'applaud',700);},1220);}}if(turn===-1)runAI();else{setMessage('À toi de jouer. Les prises sont obligatoires. Tu disposes de 20 secondes.');if(immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'thinking',650);}}
function runAI(){locked=true;startTurnClock(turnClock,now());setMessage('L’IA réfléchit…');render();if(immersive3D&&scene3d?.available)setTimeout(()=>{if(!gameOver&&turn===-1&&locked&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,-1,'thinking',650);},420);setTimeout(()=>{if(gameOver||turn!==-1||!locked)return;resolveGlobalExpiry();if(gameOver)return;const ai=chooseAIMove(board,-1,{arena});if(!ai){finish({winner:1},'no-legal-move');return;}const timed=completeTurnClock(turnClock,now());if(!timed.accepted){passHandAfterTimeout();return;}resolveGlobalExpiry();if(gameOver)return;const movingPiece=board[ai.path[0].from[0]][ai.path[0].from[1]];const sideStats=performance.away;sideStats.moves++;sideStats.captures+=ai.captures?.length||0;if(Math.abs(movingPiece)===2)sideStats.kingMoves++;board=applyMove(board,ai,{arena});const[pr,pc]=ai.path.at(-1).to;if(Math.abs(movingPiece)===1&&Math.abs(board[pr][pc])===2)sideStats.promotions++;noProgressPlies=(ai.captures?.length||Math.abs(movingPiece)===1)?0:noProgressPlies+1;const c=piecesBySide();if(arena==='temporal'){registerMatchTurn(matchClock,-1,c);if(matchClock.result){finish(matchClock.result,'temporal-turn-limit');return;}}turn=1;locked=false;if(noProgressPlies>=50){finish({winner:null},'no-progress-draw');return;}const end=gameStatus(board,1,{arena});if(end.over){finish(end,end.reason);return;}startTurnClock(turnClock,now());setMessage('À toi de jouer. Les prises sont obligatoires. Tu as 20 secondes.');render();if(immersive3D&&scene3d?.available){scene3d.animateMove?.(board,ai,board[pr][pc],selected,new Set(),movingPiece);if(ai.captures?.length){setTimeout(()=>{if(!gameOver&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'disappointed',650);},520);setTimeout(()=>{if(!gameOver&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,-1,'applaud',700);},1220);}setTimeout(()=>{if(!gameOver&&turn===1&&immersive3D&&scene3d?.available)scene3d.playPose?.(board,1,'thinking',650);},450);}},850);}


export function setImmersive3D(enabled){
 const host=$('#matchBoard'),button=$('#toggle3dView');if(!host)return false;
 if(enabled){
  if(!scene3d){try{scene3d=create3DScene(host);}catch(error){scene3d=null;setMessage(`Le moteur WebGL n’a pas pu démarrer : ${error.message}`);return false;}}
  if(!scene3d.available){setMessage('Ce navigateur ou cet appareil ne prend pas en charge WebGL. La vue classique reste disponible.');return false;}
  immersive3D=true;host.classList.add('board--webgl');if(button)button.textContent='Désactiver le moteur 3D';setMessage('Vue 3D WebGL activée : damier en volume, pièces modélisées, éclairage et perspective. Les règles et les coups légaux restent inchangés.');render();return true;
 }
 immersive3D=false;host.classList.remove('board--webgl');if(scene3d){scene3d.destroy();scene3d=null;}if(button)button.textContent='Activer le moteur 3D';render();setMessage('Vue classique rétablie.');return true;
}
