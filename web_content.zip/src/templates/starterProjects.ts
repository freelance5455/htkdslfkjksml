/**
 * GODEX v0.0.1 - Starter Projects & Templates
 */

import { ProjectTemplate } from '../types';
import { NOVA_SAAS_DASHBOARD_PROJECT } from './novaSaaSDashboardProject';
import { NOVANOTES_PROJECT } from './novaNotesProject';
import { PULSE_PROJECT } from './pulseProject';

export const STARTER_PROJECTS: ProjectTemplate[] = [
  {
    id: 'cineforge-video',
    title: 'CineForge AI - Video Editor Studio',
    description: 'Autonomous multi-track AI video editor with visual timeline, prompt-to-scene generation, layer blending, audio mixer, and live canvas renderer.',
    category: 'Media & Creative AI',
    badge: 'Flagship App',
    iconName: 'Video',
    files: {
      'src/App.tsx': `import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, Plus, Trash2, Sliders, 
  Sparkles, Download, Layers, Volume2, Film, Type, Music, 
  Eye, CheckCircle2, RefreshCw, ZoomIn, ZoomOut, Wand2, Video
} from 'lucide-react';

interface VideoClip {
  id: string;
  title: string;
  duration: number; // in seconds
  startOffset: number; // in seconds
  track: number; // 0 = video, 1 = overlay, 2 = audio
  type: 'video' | 'text' | 'audio';
  color: string;
  filter: string;
  text?: string;
  aiPrompt?: string;
  thumbnailUrl?: string;
}

export default function CineForgeApp() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0.0);
  const [totalDuration, setTotalDuration] = useState(24.0);
  const [selectedClipId, setSelectedClipId] = useState<string | null>('clip-1');
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'clips' | 'ai-gen' | 'effects' | 'export'>('clips');
  const [selectedFilter, setSelectedFilter] = useState('none');
  const [volume, setVolume] = useState(85);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  const [clips, setClips] = useState<VideoClip[]>([
    {
      id: 'clip-1',
      title: '01_Cyberpunk_Cityscape_4K.mp4',
      duration: 8,
      startOffset: 0,
      track: 0,
      type: 'video',
      color: 'bg-cyan-950 border-cyan-500/50 text-cyan-200',
      filter: 'contrast(1.2) hue-rotate(15deg)',
      aiPrompt: 'Cinematic neon cyberpunk street in rain, 4k ultra realistic'
    },
    {
      id: 'clip-2',
      title: '02_AI_Synthetic_Humanoid.mp4',
      duration: 10,
      startOffset: 8,
      track: 0,
      type: 'video',
      color: 'bg-emerald-950 border-emerald-500/50 text-emerald-200',
      filter: 'brightness(1.1) saturate(1.3)',
      aiPrompt: 'Futuristic android awakening in glass pod, hyper detailed'
    },
    {
      id: 'clip-3',
      title: '03_Hyperspace_Warp.mp4',
      duration: 6,
      startOffset: 18,
      track: 0,
      type: 'video',
      color: 'bg-purple-950 border-purple-500/50 text-purple-200',
      filter: 'none',
      aiPrompt: 'Warp speed starfield vortex, prismatic light rays'
    },
    {
      id: 'clip-text-1',
      title: 'TITLE: "PROJECT SYNAPSE 2088"',
      duration: 6,
      startOffset: 1,
      track: 1,
      type: 'text',
      text: 'PROJECT SYNAPSE 2088',
      color: 'bg-amber-950/80 border-amber-500/60 text-amber-300',
      filter: 'drop-shadow(0 0 10px rgba(245,158,11,0.8))'
    },
    {
      id: 'clip-audio-1',
      title: 'Synthwave_Cinematic_Score.mp3',
      duration: 24,
      startOffset: 0,
      track: 2,
      type: 'audio',
      color: 'bg-indigo-950 border-indigo-500/50 text-indigo-200',
      filter: 'none'
    }
  ]);

  // Animation Playhead Loop
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return parseFloat((prev + 0.1).toFixed(1));
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, totalDuration]);

  const activeClip = clips.find(c => c.id === selectedClipId);

  // Active clip based on playhead time
  const currentVideoClip = clips.find(
    c => c.track === 0 && currentTime >= c.startOffset && currentTime < (c.startOffset + c.duration)
  );

  const currentTextClip = clips.find(
    c => c.track === 1 && currentTime >= c.startOffset && currentTime < (c.startOffset + c.duration)
  );

  const handleGenerateAiScene = () => {
    if (!aiPrompt.trim()) return;
    setIsGenerating(true);
    setTimeout(() => {
      const newClip: VideoClip = {
        id: 'clip-' + Date.now(),
        title: \`AI_\${aiPrompt.slice(0, 16).replace(/\\s+/g, '_')}.mp4\`,
        duration: 6,
        startOffset: totalDuration,
        track: 0,
        type: 'video',
        color: 'bg-rose-950 border-rose-500/50 text-rose-200',
        filter: selectedFilter !== 'none' ? selectedFilter : 'contrast(1.15)',
        aiPrompt: aiPrompt
      };
      setClips([...clips, newClip]);
      setTotalDuration(prev => prev + 6);
      setSelectedClipId(newClip.id);
      setIsGenerating(false);
      setAiPrompt('');
      setActiveTab('clips');
    }, 1200);
  };

  const handleAddTextOverlay = () => {
    const newText: VideoClip = {
      id: 'clip-text-' + Date.now(),
      title: 'Overlay Text',
      duration: 5,
      startOffset: currentTime,
      track: 1,
      type: 'text',
      text: 'DIRECTED BY CODEX AI',
      color: 'bg-amber-950/80 border-amber-500/60 text-amber-300',
      filter: 'none'
    };
    setClips([...clips, newText]);
    setSelectedClipId(newText.id);
  };

  const handleDeleteClip = (id: string) => {
    setClips(clips.filter(c => c.id !== id));
    if (selectedClipId === id) setSelectedClipId(null);
  };

  const startExportSimulation = () => {
    setShowExportModal(true);
    setExportProgress(0);
    const interval = setInterval(() => {
      setExportProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          return 100;
        }
        return p + 10;
      });
    }, 200);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-neutral-950 text-neutral-100 font-sans select-none overflow-hidden">
      {/* Top Studio Bar */}
      <header className="h-12 border-b border-neutral-800 bg-neutral-900/90 px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-900/30">
            <Film className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-wider text-white flex items-center gap-2">
              CINEFORGE AI <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-900/50 text-cyan-400 border border-cyan-700/40">v2.4 PRO</span>
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-neutral-950 rounded-md border border-neutral-800 text-xs font-mono text-cyan-400">
            <span className="text-neutral-500">PLAYHEAD:</span>
            <span className="font-bold">{currentTime.toFixed(1)}s</span>
            <span className="text-neutral-600">/</span>
            <span className="text-neutral-400">{totalDuration.toFixed(1)}s</span>
          </div>

          <button 
            id="cineforge-export-btn"
            onClick={startExportSimulation}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-md text-xs font-semibold shadow-md transition-all active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Render 4K Master</span>
          </button>
        </div>
      </header>

      {/* Main Workspace (Preview + Left Panel + Right Inspector) */}
      <div className="flex-1 grid grid-cols-12 overflow-hidden">
        {/* Left Toolkit Sidebar */}
        <div className="col-span-3 border-r border-neutral-800 bg-neutral-900/50 flex flex-col overflow-hidden">
          <div className="flex border-b border-neutral-800 bg-neutral-950/60 p-1">
            {[
              { id: 'clips', label: 'Media Pool', icon: Layers },
              { id: 'ai-gen', label: 'AI Scene Gen', icon: Sparkles },
              { id: 'effects', label: 'Color & FX', icon: Sliders },
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={\`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium rounded transition-colors \${
                    activeTab === tab.id 
                      ? 'bg-neutral-800 text-cyan-300 font-semibold shadow-sm' 
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/40'
                  }\`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {activeTab === 'clips' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
                  <span>ACTIVE TRACKS ({clips.length})</span>
                  <button 
                    onClick={handleAddTextOverlay}
                    className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px]"
                  >
                    <Plus className="w-3 h-3" /> Add Text
                  </button>
                </div>
                {clips.map(clip => (
                  <div 
                    key={clip.id}
                    onClick={() => setSelectedClipId(clip.id)}
                    className={\`p-2.5 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between \${
                      selectedClipId === clip.id 
                        ? 'border-cyan-500 bg-cyan-950/40 shadow-sm shadow-cyan-950' 
                        : 'border-neutral-800 bg-neutral-950/70 hover:border-neutral-700'
                    }\`}
                  >
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      {clip.type === 'video' && <Film className="w-4 h-4 text-cyan-400 shrink-0" />}
                      {clip.type === 'text' && <Type className="w-4 h-4 text-amber-400 shrink-0" />}
                      {clip.type === 'audio' && <Music className="w-4 h-4 text-indigo-400 shrink-0" />}
                      <div className="truncate">
                        <div className="font-medium text-neutral-200 truncate">{clip.title}</div>
                        <div className="text-[10px] text-neutral-400">
                          {clip.duration}s @ {clip.startOffset}s offset
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleDeleteClip(clip.id); }}
                      className="text-neutral-500 hover:text-rose-400 p-1 transition-colors"
                      title="Delete Clip"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'ai-gen' && (
              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400">
                    <Wand2 className="w-4 h-4" />
                    <span>Neural Prompt-to-Scene</span>
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-relaxed">
                    Synthesize photorealistic 4K video scenes directly into the timeline with continuous motion physics.
                  </p>
                  <textarea
                    id="cineforge-prompt-input"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="e.g., Drone sweep across a bioluminescent neon jungle, cinematic 8k, bokeh lights..."
                    className="w-full h-20 bg-neutral-900 border border-neutral-700 rounded-md p-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-cyan-500 resize-none"
                  />
                  <div className="flex gap-1.5 flex-wrap">
                    {['Cyberpunk', 'Solarpunk', 'Sci-Fi Warp', 'Deep Ocean', 'Anime Noir'].map(preset => (
                      <button
                        key={preset}
                        onClick={() => setAiPrompt(\`Cinematic \${preset} landscape with dynamic volumetric lighting and particle effects\`)}
                        className="px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-[10px] text-neutral-300 transition-colors"
                      >
                        +{preset}
                      </button>
                    ))}
                  </div>
                  <button
                    id="cineforge-generate-btn"
                    disabled={isGenerating || !aiPrompt.trim()}
                    onClick={handleGenerateAiScene}
                    className="w-full py-2 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded-md text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all"
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Synthesizing Latent Frames...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Generate & Append Scene</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'effects' && (
              <div className="space-y-3">
                <div className="text-xs font-semibold text-neutral-300">Color Grading Matrix</div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'none', label: 'Neutral Rec.709' },
                    { id: 'contrast(1.3) saturate(1.4)', label: 'Teal & Orange' },
                    { id: 'hue-rotate(180deg) invert(0.1)', label: 'Matrix Cyber' },
                    { id: 'sepia(0.8) contrast(1.1)', label: 'Vintage Kodachrome' },
                    { id: 'grayscale(1) contrast(1.5)', label: 'Noir High-Contrast' },
                  ].map(filter => (
                    <button
                      key={filter.id}
                      onClick={() => {
                        setSelectedFilter(filter.id);
                        if (activeClip) {
                          setClips(clips.map(c => c.id === activeClip.id ? { ...c, filter: filter.id } : c));
                        }
                      }}
                      className={\`p-2 rounded border text-left text-[11px] \${
                        (activeClip?.filter === filter.id || selectedFilter === filter.id)
                          ? 'border-cyan-500 bg-cyan-950/50 text-cyan-200' 
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                      }\`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>

                <div className="pt-2 border-t border-neutral-800 space-y-2">
                  <div className="flex justify-between text-xs text-neutral-400">
                    <span>Master Audio Gain</span>
                    <span>{volume}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume}
                    onChange={(e) => setVolume(Number(e.target.value))}
                    className="w-full accent-cyan-500"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Center Live Canvas Screen */}
        <div className="col-span-9 flex flex-col bg-neutral-950">
          {/* Main Stage Viewport */}
          <div className="flex-1 flex items-center justify-center p-6 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px]">
            <div 
              className="relative w-full max-w-3xl aspect-video bg-black rounded-lg border border-neutral-800 shadow-2xl overflow-hidden flex items-center justify-center group"
              style={{ filter: activeClip?.filter || 'none' }}
            >
              {/* Simulated Visual Render */}
              <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-cyan-950/40 to-indigo-950 flex flex-col items-center justify-center">
                {/* Visual Animated Scene Canvas Simulation */}
                <div className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 opacity-40 mix-blend-screen bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.3)_0%,transparent_70%)] animate-pulse" />
                  
                  {/* Grid Lines */}
                  <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#0891b2_1px,transparent_1px),linear-gradient(to_bottom,#0891b2_1px,transparent_1px)] bg-[size:4rem_4rem]" />

                  {/* Scene Graphic Display */}
                  <div className="z-10 text-center space-y-2 px-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 text-xs font-mono backdrop-blur-sm">
                      <Film className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{currentVideoClip ? currentVideoClip.title : 'END OF TIMELINE'}</span>
                    </div>

                    {currentTextClip && (
                      <div className="text-3xl md:text-4xl font-extrabold tracking-widest text-amber-300 drop-shadow-[0_0_20px_rgba(245,158,11,0.8)] animate-bounce font-mono">
                        {currentTextClip.text}
                      </div>
                    )}

                    {currentVideoClip?.aiPrompt && (
                      <p className="text-xs text-cyan-200/70 max-w-md mx-auto italic font-sans">
                        "{currentVideoClip.aiPrompt}"
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Viewport HUD Overlays */}
              <div className="absolute top-3 left-3 flex items-center gap-2 z-20 pointer-events-none">
                <span className="px-2 py-0.5 rounded bg-black/70 border border-neutral-700 text-[10px] font-mono text-neutral-300">
                  4K UHD 3840×2160 • 60 FPS
                </span>
                {isPlaying && (
                  <span className="px-2 py-0.5 rounded bg-rose-600/80 text-white text-[10px] font-bold tracking-wider animate-pulse">
                    REC / PLAY
                  </span>
                )}
              </div>

              <div className="absolute bottom-3 right-3 flex items-center gap-2 z-20 pointer-events-none">
                <span className="px-2 py-0.5 rounded bg-black/70 border border-neutral-700 text-[10px] font-mono text-cyan-400">
                  AUDIO: {volume}%
                </span>
              </div>
            </div>
          </div>

          {/* Timeline Controls & Scrubber Bar */}
          <div className="h-44 border-t border-neutral-800 bg-neutral-900/90 flex flex-col shrink-0">
            {/* Playback Controls */}
            <div className="h-10 border-b border-neutral-800 px-4 flex items-center justify-between bg-neutral-950/40">
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setCurrentTime(0)} 
                  className="p-1 text-neutral-400 hover:text-white transition-colors"
                  title="Jump to Start"
                >
                  <SkipBack className="w-4 h-4" />
                </button>
                <button 
                  id="cineforge-play-btn"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-7 h-7 rounded-full bg-cyan-500 hover:bg-cyan-400 text-neutral-950 flex items-center justify-center font-bold shadow-md transition-transform active:scale-95"
                  title={isPlaying ? "Pause" : "Play"}
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current ml-0.5" />}
                </button>
                <button 
                  onClick={() => setCurrentTime(totalDuration)} 
                  className="p-1 text-neutral-400 hover:text-white transition-colors"
                  title="Jump to End"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-3 text-xs text-neutral-400">
                <div className="flex items-center gap-1">
                  <ZoomOut className="w-3.5 h-3.5 cursor-pointer hover:text-white" onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.2))} />
                  <span className="font-mono text-[10px]">{(zoomLevel * 100).toFixed(0)}%</span>
                  <ZoomIn className="w-3.5 h-3.5 cursor-pointer hover:text-white" onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.2))} />
                </div>
              </div>
            </div>

            {/* Visual Timeline Tracks Container */}
            <div 
              className="flex-1 overflow-x-auto overflow-y-hidden p-2 relative bg-neutral-950/80 cursor-crosshair"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const newRatio = Math.max(0, Math.min(1, clickX / (rect.width * zoomLevel)));
                setCurrentTime(parseFloat((newRatio * totalDuration).toFixed(1)));
              }}
            >
              {/* Playhead Red Needle */}
              <div 
                className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-30 pointer-events-none transition-all duration-75"
                style={{ left: \`\${(currentTime / totalDuration) * 100 * zoomLevel}%\` }}
              >
                <div className="w-2.5 h-2.5 -ml-1 bg-rose-500 transform rotate-45" />
              </div>

              {/* Tracks Container */}
              <div className="space-y-1.5 h-full flex flex-col justify-center" style={{ width: \`\${zoomLevel * 100}%\` }}>
                {/* Track 1: Text Overlays */}
                <div className="h-6 bg-neutral-900/60 rounded border border-neutral-800/80 relative flex items-center px-1">
                  <span className="text-[9px] text-neutral-500 w-12 font-mono shrink-0">T1: TEXT</span>
                  <div className="flex-1 relative h-full">
                    {clips.filter(c => c.track === 1).map(clip => (
                      <div
                        key={clip.id}
                        onClick={(e) => { e.stopPropagation(); setSelectedClipId(clip.id); }}
                        className={\`absolute top-0.5 bottom-0.5 rounded px-2 text-[10px] font-mono flex items-center truncate border cursor-pointer \${clip.color} \${
                          selectedClipId === clip.id ? 'ring-2 ring-cyan-400' : ''
                        }\`}
                        style={{
                          left: \`\${(clip.startOffset / totalDuration) * 100}%\`,
                          width: \`\${(clip.duration / totalDuration) * 100}%\`,
                        }}
                      >
                        {clip.text || clip.title}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Track 0: Main Video Clips */}
                <div className="h-8 bg-neutral-900/80 rounded border border-neutral-800 relative flex items-center px-1">
                  <span className="text-[9px] text-neutral-400 w-12 font-mono shrink-0">V1: VIDEO</span>
                  <div className="flex-1 relative h-full">
                    {clips.filter(c => c.track === 0).map(clip => (
                      <div
                        key={clip.id}
                        onClick={(e) => { e.stopPropagation(); setSelectedClipId(clip.id); }}
                        className={\`absolute top-0.5 bottom-0.5 rounded px-2 text-[10px] font-mono flex items-center truncate border cursor-pointer shadow-sm transition-all \${clip.color} \${
                          selectedClipId === clip.id ? 'ring-2 ring-cyan-400 font-bold' : ''
                        }\`}
                        style={{
                          left: \`\${(clip.startOffset / totalDuration) * 100}%\`,
                          width: \`\${(clip.duration / totalDuration) * 100}%\`,
                        }}
                      >
                        {clip.title}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Track 2: Audio Stems */}
                <div className="h-6 bg-neutral-900/60 rounded border border-neutral-800/80 relative flex items-center px-1">
                  <span className="text-[9px] text-neutral-500 w-12 font-mono shrink-0">A1: AUDIO</span>
                  <div className="flex-1 relative h-full">
                    {clips.filter(c => c.track === 2).map(clip => (
                      <div
                        key={clip.id}
                        onClick={(e) => { e.stopPropagation(); setSelectedClipId(clip.id); }}
                        className={\`absolute top-0.5 bottom-0.5 rounded px-2 text-[10px] font-mono flex items-center truncate border cursor-pointer \${clip.color} \${
                          selectedClipId === clip.id ? 'ring-2 ring-cyan-400' : ''
                        }\`}
                        style={{
                          left: \`\${(clip.startOffset / totalDuration) * 100}%\`,
                          width: \`\${(clip.duration / totalDuration) * 100}%\`,
                        }}
                      >
                        {clip.title}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export Progress Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Film className="w-4 h-4 text-cyan-400" />
                <span>Exporting 4K Master Render</span>
              </h3>
              <button 
                onClick={() => setShowExportModal(false)}
                className="text-neutral-400 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-neutral-400 font-mono">
                <span>ENCODING PROGRESS (H.265 / ProRes)</span>
                <span className="text-cyan-400 font-bold">{exportProgress}%</span>
              </div>
              <div className="w-full h-2.5 bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-200"
                  style={{ width: \`\${exportProgress}%\` }}
                />
              </div>
            </div>

            {exportProgress === 100 ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-lg flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <div className="text-xs">
                  <div className="font-semibold text-emerald-200">Render Completed!</div>
                  <div className="text-emerald-400/80">3840×2160 ProRes Master ready for download.</div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-neutral-400 italic">
                Stitching audio tracks, rendering neural latent motion, applying {selectedFilter !== 'none' ? 'color grade' : 'standard colors'}...
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200"
              >
                Close
              </button>
              {exportProgress === 100 && (
                <button
                  onClick={() => setShowExportModal(false)}
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-white shadow-lg"
                >
                  Download File
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
`,
      'src/types.ts': `export interface VideoClip {
  id: string;
  title: string;
  duration: number;
  startOffset: number;
  track: number;
  type: 'video' | 'text' | 'audio';
  color: string;
  filter: string;
  text?: string;
  aiPrompt?: string;
}
`,
      'package.json': `{
  "name": "cineforge-ai",
  "version": "2.4.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  }
}`
    }
  },
  NOVA_SAAS_DASHBOARD_PROJECT,
  NOVANOTES_PROJECT,
  PULSE_PROJECT,
  {
    id: 'ai-brain',
    title: 'AI Brain - Neural Cognitive Engine',
    description: 'Real-time multi-agent neural network topology visualizer with token streaming graph, vector memory lookup, and live latency telemetry.',
    category: 'AI Architecture',
    badge: 'Neural Graph',
    iconName: 'Cpu',
    files: {
      'src/App.tsx': `import React, { useState, useEffect } from 'react';
import { 
  Cpu, Activity, Zap, Layers, Network, Database, 
  Terminal, ShieldCheck, Play, RotateCcw, Search, Sparkles
} from 'lucide-react';

interface AgentNode {
  id: string;
  name: string;
  role: string;
  status: 'idle' | 'thinking' | 'streaming' | 'verifying';
  tokensProcessed: number;
  latencyMs: number;
  confidence: number;
  x: number;
  y: number;
}

export default function AIBrainApp() {
  const [activeTab, setActiveTab] = useState<'topology' | 'stream' | 'memory'>('topology');
  const [isSimulating, setIsSimulating] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [totalTokens, setTotalTokens] = useState(148200);

  const [nodes, setNodes] = useState<AgentNode[]>([
    { id: 'orchestrator', name: 'Orchestrator Core', role: 'Executive Dispatch', status: 'streaming', tokensProcessed: 42000, latencyMs: 14, confidence: 99.4, x: 50, y: 20 },
    { id: 'planner', name: 'Strategic Planner', role: 'Decomposition', status: 'thinking', tokensProcessed: 28500, latencyMs: 38, confidence: 97.8, x: 20, y: 50 },
    { id: 'coder', name: 'Coding Engine', role: 'Synthesis & Patching', status: 'streaming', tokensProcessed: 56000, latencyMs: 82, confidence: 96.5, x: 50, y: 50 },
    { id: 'debugger', name: 'Autonomous Debugger', role: 'Stack Trace Repair', status: 'idle', tokensProcessed: 12400, latencyMs: 22, confidence: 98.9, x: 80, y: 50 },
    { id: 'verifier', name: 'Verification Agent', role: 'Browser & Test QA', status: 'verifying', tokensProcessed: 9300, latencyMs: 45, confidence: 99.9, x: 50, y: 80 },
  ]);

  const [liveStreamLogs, setLiveStreamLogs] = useState<string[]>([
    '[Cognitive Engine] Synchronized memory embeddings (Dim: 1536)',
    '[Planner] Decomposed user prompt into 4 sub-agent task vectors',
    '[Coding Agent] Synthesizing surgical TypeScript AST diff for App.tsx',
    '[Verification Agent] Executed 12 headless assertion hooks: 12/12 PASSED',
  ]);

  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setTotalTokens(t => t + Math.floor(Math.random() * 80 + 20));
      setNodes(prev => prev.map(n => ({
        ...n,
        tokensProcessed: n.tokensProcessed + Math.floor(Math.random() * 15),
        latencyMs: Math.max(8, n.latencyMs + Math.floor(Math.random() * 7 - 3)),
        status: Math.random() > 0.4 ? 'streaming' : (Math.random() > 0.5 ? 'thinking' : 'idle')
      })));
    }, 1500);
    return () => clearInterval(interval);
  }, [isSimulating]);

  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-100 font-sans select-none overflow-hidden">
      {/* Header */}
      <header className="h-14 border-b border-slate-800 bg-slate-900/90 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-950/50">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
              AI BRAIN <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-800">NEURAL TOPOLOGY</span>
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
            <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="text-slate-400">Total Tokens:</span>
            <span className="font-mono font-bold text-slate-200">{totalTokens.toLocaleString()}</span>
          </div>

          <button 
            onClick={() => setIsSimulating(!isSimulating)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium shadow transition-all"
          >
            {isSimulating ? <RotateCcw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isSimulating ? 'Pause Engine' : 'Resume Telemetry'}</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 grid grid-cols-12 overflow-hidden">
        {/* Left Neural Node Grid */}
        <div className="col-span-8 p-6 flex flex-col justify-between relative bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px]">
          {/* Node Grid Render */}
          <div className="grid grid-cols-3 gap-4">
            {nodes.map(node => (
              <div 
                key={node.id} 
                className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3 relative overflow-hidden backdrop-blur-sm"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">{node.name}</span>
                  <span className={\`text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold uppercase \${
                    node.status === 'streaming' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    node.status === 'thinking' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                    node.status === 'verifying' ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' :
                    'bg-slate-800 text-slate-400'
                  }\`}>
                    {node.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400">{node.role}</div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[11px] font-mono">
                  <div>
                    <span className="text-slate-500">Latency: </span>
                    <span className="text-indigo-400 font-bold">{node.latencyMs}ms</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Conf: </span>
                    <span className="text-emerald-400 font-bold">{node.confidence}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Real-time Token Activity Graph Bar */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-mono text-slate-400">
              <span>ACTIVE COGNITIVE BANDWIDTH</span>
              <span className="text-emerald-400 font-bold">98.4% EFFICIENCY</span>
            </div>
            <div className="grid grid-cols-24 gap-1 h-8 items-end">
              {Array.from({ length: 24 }).map((_, i) => (
                <div 
                  key={i} 
                  className="bg-indigo-500/80 rounded-t hover:bg-indigo-400 transition-all"
                  style={{ height: \`\${Math.floor(Math.sin(i + totalTokens % 10) * 40 + 55)}%\` }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Right Memory & Streaming Inspector */}
        <div className="col-span-4 border-l border-slate-800 bg-slate-900/60 p-4 flex flex-col space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>Agent Thought & Stream Pipeline</span>
          </div>

          <div className="flex-1 bg-slate-950 rounded-xl border border-slate-800 p-3 font-mono text-xs text-slate-300 space-y-2 overflow-y-auto">
            {liveStreamLogs.map((log, i) => (
              <div key={i} className="leading-relaxed border-l-2 border-indigo-500/50 pl-2">
                <span className="text-slate-500">[{new Date().toLocaleTimeString()}]</span> {log}
              </div>
            ))}
          </div>

          <div className="p-3 bg-indigo-950/40 rounded-xl border border-indigo-800/40 space-y-1">
            <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>Multi-Agent Consensus Verified</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              All agent outputs pass through real-time AST syntax and runtime contract checkers prior to preview compilation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
`,
      'package.json': `{
  "name": "ai-brain-engine",
  "version": "1.0.0",
  "type": "module"
}`
    }
  },
  {
    id: 'fullstack-saas',
    title: 'CloudPulse - DevOps & Metric Monitor',
    description: 'Real-time microservice health dashboard, cluster log streams, container CPU/RAM metrics, and incident simulation.',
    category: 'Cloud & Infrastructure',
    badge: 'Realtime System',
    iconName: 'Server',
    files: {
      'src/App.tsx': `import React, { useState } from 'react';
import { Server, Activity, Shield, AlertTriangle, CheckCircle, RefreshCw, Terminal } from 'lucide-react';

export default function CloudPulseApp() {
  const [services, setServices] = useState([
    { name: 'Auth Gateway (OAuth2/JWT)', status: 'HEALTHY', latency: '12ms', uptime: '99.98%' },
    { name: 'AI Inference Cluster (Gemini)', status: 'HEALTHY', latency: '48ms', uptime: '99.94%' },
    { name: 'PostgreSQL Relational DB', status: 'HEALTHY', latency: '4ms', uptime: '100%' },
    { name: 'Redis Cache Layer', status: 'HEALTHY', latency: '1ms', uptime: '99.99%' },
  ]);

  const [isAlerting, setIsAlerting] = useState(false);

  return (
    <div className="flex flex-col h-screen w-full bg-neutral-950 text-neutral-100 font-sans p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Server className="w-5 h-5 text-emerald-400" />
            <span>CloudPulse Infrastructure Dashboard</span>
          </h1>
          <p className="text-xs text-neutral-400">Real-time microservice telemetry and autonomous health monitor</p>
        </div>
        <button 
          onClick={() => setIsAlerting(!isAlerting)}
          className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold"
        >
          Simulate Incident
        </button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {services.map((svc, i) => (
          <div key={i} className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">{svc.name}</span>
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold font-mono text-emerald-400">{svc.latency}</div>
            <div className="text-[11px] text-neutral-400">Uptime: {svc.uptime}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
`,
      'package.json': `{"name": "cloudpulse-dashboard", "version": "1.0.0"}`
    }
  }
];
