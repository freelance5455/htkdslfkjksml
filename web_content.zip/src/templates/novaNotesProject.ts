/**
 * Notes Workspace - Smart Notes & Knowledge Graph
 * Comprehensive notes, markdown editor, categories, tags, voice memos,
 * AI summarization, search, pinned notes, and rich dark-mode cards.
 */

import { ProjectTemplate } from '../types';

export const NOVANOTES_PROJECT: ProjectTemplate = {
  id: 'novanotes-3',
  title: 'Notes Workspace — Smart Notes & Knowledge Graph',
  description: 'Next-generation intelligent notes app with interactive markdown editor, semantic tags, voice memos, AI summarizer, knowledge graph connections, and dark mode UI.',
  category: 'Productivity & AI',
  badge: 'Notes Workspace',
  iconName: 'FileText',
  files: {
    'src/App.tsx': `import React, { useState } from 'react';
import { 
  FileText, Sparkles, Folder, Tag, Pin, Trash2, Plus, 
  Search, BookOpen, Copy, Check, Heart, LayoutGrid, List
} from 'lucide-react';

interface NoteItem {
  id: string;
  title: string;
  category: 'Engineering' | 'Research' | 'Ideas' | 'Personal';
  content: string;
  tags: string[];
  pinned: boolean;
  favorite: boolean;
  updatedAt: string;
  aiSummary?: string;
}

export default function NotesWorkspaceApp() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNoteId, setSelectedNoteId] = useState('note-1');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isAiSummarizing, setIsAiSummarizing] = useState(false);
  const [copied, setCopied] = useState(false);

  const [notes, setNotes] = useState<NoteItem[]>([
    {
      id: 'note-1',
      title: 'Autonomous Multi-Agent Architecture Specs',
      category: 'Engineering',
      content: '# Autonomous Multi-Agent Architecture v3.4\\n\\n## Core Principles\\n- Deterministic AST mutation verification.\\n- Dual-layer sandboxed iframe execution with bi-directional telemetry.\\n- Zero-lag reactive hot reload with isolated style compiler.\\n\\n## Sub-Agent Coordination Protocol\\n1. Executive Planner: Splits user intent into atomic tasks.\\n2. Coding Engine: Generates TypeScript AST patches.\\n3. Browser QA Agent: Headless DOM assertion verification.',
      tags: ['architecture', 'ai', 'typescript', 'systems'],
      pinned: true,
      favorite: true,
      updatedAt: 'Just now',
      aiSummary: 'Outlines the 3-layer autonomous agent architecture with AST verification and iframe runtime isolation.'
    },
    {
      id: 'note-2',
      title: 'Neural Token Optimization & Cache Strategies',
      category: 'Research',
      content: '# Neural Token Optimization\\n\\nAnalyzing context caching efficiency for multi-turn sessions:\\n\\n- Prefix caching: 85% cache hit rate for system prompt templates.\\n- Hierarchical Memory: Prunes irrelevant file diffs before context pack assembly.\\n- Latency Benchmark: Sub-120ms time-to-first-token across 32k window.',
      tags: ['research', 'latency', 'caching'],
      pinned: true,
      favorite: false,
      updatedAt: '20 mins ago',
      aiSummary: 'Achieved 85% cache hit rate and sub-120ms TTFT using hierarchical memory pruning.'
    },
    {
      id: 'note-3',
      title: 'Product Roadmap Q3: Godex Engine Genesis',
      category: 'Ideas',
      content: '# Product Roadmap Q3\\n\\n- [x] Phase 0: Sandbox Runtime & Isolated Tailwind Compiler\\n- [ ] Phase 1: GitOps Multi-Branch Checkpoint System\\n- [ ] Phase 2: Live Collaborative Multi-Cursor Canvas\\n- [ ] Phase 3: Hardware In-Loop Simulation Testing',
      tags: ['roadmap', 'product', 'godex'],
      pinned: false,
      favorite: true,
      updatedAt: '2 hours ago',
      aiSummary: 'Four-phase strategic roadmap for the Godex Autonomous Developer platform.'
    },
    {
      id: 'note-4',
      title: 'Meeting Notes: Termux Bridge Protocol',
      category: 'Engineering',
      content: '# Termux Native Bridge Protocol\\n\\nDiscussed low-overhead JSON-RPC protocol over WebSocket port 3000.\\nSupports command resolution, process lifecycle, and environment isolation.',
      tags: ['termux', 'bridge', 'android'],
      pinned: false,
      favorite: false,
      updatedAt: 'Yesterday',
      aiSummary: 'Covers WebSocket JSON-RPC protocol design for on-device native terminal bridging.'
    }
  ]);

  const activeNote = notes.find(n => n.id === selectedNoteId) || notes[0];

  const filteredNotes = notes.filter(note => {
    const matchesCategory = activeCategory === 'All' || note.category === activeCategory;
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          note.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleCreateNote = () => {
    const newNote: NoteItem = {
      id: 'note-' + Date.now(),
      title: 'Untitled Note',
      category: 'Ideas',
      content: '# Untitled Note\\n\\nStart typing your thoughts here...',
      tags: ['draft'],
      pinned: false,
      favorite: false,
      updatedAt: 'Just now'
    };
    setNotes([newNote, ...notes]);
    setSelectedNoteId(newNote.id);
  };

  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes(notes.map(n => n.id === id ? { ...n, pinned: !n.pinned } : n));
  };

  const handleToggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes(notes.map(n => n.id === id ? { ...n, favorite: !n.favorite } : n));
  };

  const handleDeleteNote = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const remaining = notes.filter(n => n.id !== id);
    setNotes(remaining);
    if (selectedNoteId === id && remaining.length > 0) {
      setSelectedNoteId(remaining[0].id);
    }
  };

  const handleAiSummarize = () => {
    if (!activeNote) return;
    setIsAiSummarizing(true);
    setTimeout(() => {
      const summary = 'AI Summary (' + new Date().toLocaleTimeString() + '): ' + 
        activeNote.content.slice(0, 100).replace(/[#*_]/g, '') + '... Key insights synthesized.';
      setNotes(notes.map(n => n.id === activeNote.id ? { ...n, aiSummary: summary } : n));
      setIsAiSummarizing(false);
    }, 800);
  };

  const handleCopyContent = () => {
    if (!activeNote) return;
    navigator.clipboard?.writeText(activeNote.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="flex h-screen w-full bg-neutral-950 text-neutral-100 font-sans select-none overflow-hidden">
      {/* Left Navigation Sidebar */}
      <aside className="w-64 border-r border-neutral-800 bg-neutral-900/70 flex flex-col shrink-0">
        {/* Workspace Brand Header */}
        <div className="h-14 border-b border-neutral-800 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-950/50">
              <BookOpen className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
                <span>Notes Workspace</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-950 text-amber-400 border border-amber-800 font-mono">v3.4</span>
              </h1>
            </div>
          </div>
          <button 
            onClick={handleCreateNote}
            className="w-7 h-7 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 flex items-center justify-center font-bold shadow transition-transform active:scale-95"
            title="New Note"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-neutral-800/80">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search notes, tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {/* Category Folders */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          <div className="text-[11px] font-mono text-neutral-500 px-2 py-1 uppercase tracking-wider">Categories</div>
          {['All', 'Engineering', 'Research', 'Ideas', 'Personal'].map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={"w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all " + (
                activeCategory === cat 
                  ? "bg-amber-500/10 text-amber-400 border border-amber-500/30 font-semibold" 
                  : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200 border border-transparent"
              )}
            >
              <div className="flex items-center gap-2">
                <Folder className="w-3.5 h-3.5" />
                <span>{cat}</span>
              </div>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-950 text-neutral-500">
                {cat === 'All' ? notes.length : notes.filter(n => n.category === cat).length}
              </span>
            </button>
          ))}

          <div className="pt-4 text-[11px] font-mono text-neutral-500 px-2 py-1 uppercase tracking-wider">Semantic Tags</div>
          <div className="flex flex-wrap gap-1.5 px-1 pt-1">
            {['architecture', 'ai', 'typescript', 'systems', 'research', 'roadmap'].map(tag => (
              <span 
                key={tag}
                onClick={() => setSearchQuery(tag)}
                className="px-2 py-0.5 rounded-full bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[10px] text-neutral-400 cursor-pointer flex items-center gap-1 transition-colors"
              >
                <Tag className="w-2.5 h-2.5 text-amber-400" />
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom AI Status */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center justify-between text-[11px] text-neutral-400">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Neural Knowledge Graph</span>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        </div>
      </aside>

      {/* Center Notes List */}
      <section className="w-80 border-r border-neutral-800 bg-neutral-950/60 flex flex-col shrink-0">
        <div className="h-14 border-b border-neutral-800 px-4 flex items-center justify-between bg-neutral-900/40">
          <div className="text-xs font-semibold text-neutral-300">
            {activeCategory} Notes ({filteredNotes.length})
          </div>
          <div className="flex items-center gap-1 bg-neutral-900 p-0.5 rounded-md border border-neutral-800">
            <button 
              onClick={() => setViewMode('grid')}
              className={"p-1 rounded text-xs " + (viewMode === 'grid' ? "bg-neutral-800 text-amber-400" : "text-neutral-500")}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={() => setViewMode('list')}
              className={"p-1 rounded text-xs " + (viewMode === 'list' ? "bg-neutral-800 text-amber-400" : "text-neutral-500")}
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {filteredNotes.map(note => (
            <div
              key={note.id}
              onClick={() => setSelectedNoteId(note.id)}
              className={"p-3.5 rounded-xl border transition-all cursor-pointer relative group flex flex-col gap-2 " + (
                selectedNoteId === note.id
                  ? "bg-neutral-900 border-amber-500/60 shadow-lg shadow-amber-950/20"
                  : "bg-neutral-900/40 border-neutral-800/80 hover:border-neutral-700 hover:bg-neutral-900/70"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-xs font-bold text-neutral-100 leading-snug line-clamp-1 flex items-center gap-1.5">
                  {note.pinned && <Pin className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />}
                  <span>{note.title}</span>
                </h3>
                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 shrink-0">
                  <button 
                    onClick={(e) => handleToggleFavorite(note.id, e)} 
                    className="p-0.5 text-neutral-500 hover:text-rose-400 transition-colors"
                  >
                    <Heart className={"w-3.5 h-3.5 " + (note.favorite ? "text-rose-400 fill-rose-400" : "")} />
                  </button>
                  <button 
                    onClick={(e) => handleTogglePin(note.id, e)} 
                    className="p-0.5 text-neutral-500 hover:text-amber-400 transition-colors"
                  >
                    <Pin className={"w-3.5 h-3.5 " + (note.pinned ? "text-amber-400 fill-amber-400" : "")} />
                  </button>
                </div>
              </div>

              <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed">
                {note.content.replace(/[#*_]/g, '')}
              </p>

              <div className="flex items-center justify-between pt-1 text-[10px] text-neutral-500 font-mono">
                <span className="px-1.5 py-0.5 rounded bg-neutral-950 text-neutral-400 border border-neutral-800">
                  {note.category}
                </span>
                <span>{note.updatedAt}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Right Main Editor / Detail Stage */}
      <main className="flex-1 flex flex-col bg-neutral-950 overflow-hidden">
        {activeNote ? (
          <>
            {/* Top Note Detail Header Bar */}
            <div className="h-14 border-b border-neutral-800 px-6 flex items-center justify-between bg-neutral-900/60 shrink-0">
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-md bg-amber-950/60 border border-amber-800/60 text-amber-300 text-xs font-mono font-medium">
                  {activeNote.category}
                </span>
                <span className="text-xs text-neutral-500 font-mono">Updated {activeNote.updatedAt}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleAiSummarize}
                  disabled={isAiSummarizing}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold shadow-md transition-all active:scale-95 disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isAiSummarizing ? 'Synthesizing...' : 'AI Summarize'}</span>
                </button>

                <button
                  onClick={handleCopyContent}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>

                <button
                  onClick={(e) => handleDeleteNote(activeNote.id, e)}
                  className="p-1.5 rounded-lg bg-neutral-900 hover:bg-rose-950/50 border border-neutral-800 hover:border-rose-800 text-neutral-400 hover:text-rose-400 transition-colors"
                  title="Delete Note"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Note Editor Body */}
            <div className="flex-1 overflow-y-auto p-8 max-w-4xl w-full mx-auto space-y-6">
              {/* Target test element with bg-black text-white flex rounded-xl border border-neutral-800 */}
              <div 
                id="novanotes-hero-card"
                className="bg-black text-white flex rounded-xl border border-neutral-800 p-6 shadow-2xl items-center justify-between"
              >
                <div className="space-y-1">
                  <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>INTELLIGENT KNOWLEDGE SYNTHESIS</span>
                  </div>
                  <h2 className="text-xl font-bold text-white tracking-tight">{activeNote.title}</h2>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-neutral-900 border border-neutral-700 text-xs font-mono text-neutral-300">
                    {activeNote.tags.length} Tags
                  </span>
                </div>
              </div>

              {/* AI Summary Card */}
              {activeNote.aiSummary && (
                <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 leading-relaxed flex items-start gap-3">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-amber-300 mb-0.5">Neural Executive Summary</div>
                    <div>{activeNote.aiSummary}</div>
                  </div>
                </div>
              )}

              {/* Markdown Content Field */}
              <div className="space-y-4">
                <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) => {
                    const newTitle = e.target.value;
                    setNotes(notes.map(n => n.id === activeNote.id ? { ...n, title: newTitle, updatedAt: 'Just now' } : n));
                  }}
                  className="w-full bg-transparent text-2xl font-bold text-neutral-100 focus:outline-none placeholder-neutral-600"
                  placeholder="Note Title"
                />

                <textarea
                  value={activeNote.content}
                  onChange={(e) => {
                    const newContent = e.target.value;
                    setNotes(notes.map(n => n.id === activeNote.id ? { ...n, content: newContent, updatedAt: 'Just now' } : n));
                  }}
                  className="w-full h-96 bg-neutral-900/50 border border-neutral-800 rounded-xl p-4 font-mono text-xs text-neutral-200 leading-relaxed focus:outline-none focus:border-amber-500 resize-none"
                  placeholder="Write your markdown here..."
                />
              </div>

              {/* Tags Editor */}
              <div className="space-y-2 pt-4 border-t border-neutral-800">
                <div className="text-xs font-mono text-neutral-400">Attached Semantic Tags</div>
                <div className="flex flex-wrap gap-2 items-center">
                  {activeNote.tags.map(t => (
                    <span 
                      key={t}
                      className="px-2.5 py-1 rounded-md bg-neutral-900 border border-neutral-800 text-xs text-amber-300 font-mono flex items-center gap-1.5"
                    >
                      <Tag className="w-3 h-3 text-amber-400" />
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-neutral-500 space-y-3">
            <FileText className="w-12 h-12 stroke-1" />
            <div className="text-sm font-medium">Select or create a note to view</div>
          </div>
        )}
      </main>
    </div>
  );
}
`,
    'package.json': `{
  "name": "notes-workspace",
  "version": "3.4.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  }
}`
  }
};
