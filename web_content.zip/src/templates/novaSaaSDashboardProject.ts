/**
 * SaaS Analytics Dashboard starter template with clearly identified demo data.
 */

import { ProjectTemplate } from '../types';

export const NOVA_SAAS_DASHBOARD_PROJECT: ProjectTemplate = {
  id: 'nova-saas-dashboard',
  title: 'SaaS Analytics & Workload Dashboard',
  description: 'Sample SaaS analytics dashboard template with responsive layouts, illustrative KPI cards, revenue charts, model-usage views, sample workload status, activity records, and notifications. Metrics are demo data, not connected production telemetry.',
  category: 'Enterprise AI & Analytics',
  badge: 'Sample Template',
  iconName: 'Activity',
  files: {
    'src/App.tsx': `import React, { useState, useEffect } from 'react';
import { 
  Activity, BarChart3, LineChart, PieChart, Users, DollarSign, 
  CreditCard, FileText, Settings, Search, Filter, ArrowUpRight, 
  ArrowDownRight, RefreshCw, Download, Plus, CheckCircle2, 
  AlertCircle, ChevronRight, SlidersHorizontal, Bell, Shield, 
  Key, Database, Layers, TrendingUp, HelpCircle, Menu, X, 
  Calendar, ChevronDown, Check, Eye, EyeOff, ExternalLink,
  Cpu, Sparkles, Zap, Bot, Clock, AlertTriangle, ArrowRight, FolderKanban
} from 'lucide-react';

interface ActivityItem {
  id: string;
  task: string;
  model: string;
  tokens: string;
  cost: string;
  status: 'completed' | 'processing' | 'queued' | 'warning';
  time: string;
}

interface ProjectItem {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'training' | 'optimized' | 'standby';
  uptime: string;
  requests: string;
  health: number;
}

export default function SaaSAnalyticsApp() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analytics' | 'models' | 'projects' | 'activity' | 'settings'>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | '12m'>('7d');
  const [isLiveStreaming, setIsLiveStreaming] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<ActivityItem | null>(null);

  // Simulated demo metrics (not connected to a live service)
  const [metrics, setMetrics] = useState({
    totalRevenue: 148290,
    activeAgents: 1420,
    apiRequests: 4820000,
    avgLatency: 28.4,
    tokenThroughput: 84.6
  });

  const [notifications, setNotifications] = useState([
    { id: 'n-1', title: 'Model Scaling Triggered', text: 'Gemini 3.7 Flash cluster auto-scaled +4 instances.', time: '2m ago', unread: true },
    { id: 'n-2', title: 'Revenue Milestone', text: 'Monthly Recurring Revenue surpassed $148,000 threshold.', time: '14m ago', unread: true },
    { id: 'n-3', title: 'Demo Credential Event', text: 'Illustrative sample event only; no credential was changed.', time: '1h ago', unread: false }
  ]);

  const [activities] = useState<ActivityItem[]>([
    { id: 'ACT-9041', task: 'Neural Semantic Search Indexing', model: 'Gemini 3.7 Flash', tokens: '42,800', cost: '$0.042', status: 'completed', time: 'Just now' },
    { id: 'ACT-9040', task: 'Multi-Modal Vision Analysis', model: 'Gemini 3.1 Pro', tokens: '124,500', cost: '$0.380', status: 'completed', time: '3m ago' },
    { id: 'ACT-9039', task: 'Autonomous Code Review Pipeline', model: 'Gemini 3.7 Flash', tokens: '89,200', cost: '$0.089', status: 'processing', time: '8m ago' },
    { id: 'ACT-9038', task: 'Vector Embedding Generation (1536-dim)', model: 'Text-Embedding-004', tokens: '340,000', cost: '$0.068', status: 'completed', time: '18m ago' },
    { id: 'ACT-9037', task: 'Demo Speech-to-Text Task', model: 'Example Audio API', tokens: '18,400', cost: '$0.055', status: 'warning', time: '42m ago' },
    { id: 'ACT-9036', task: 'Executive Summary Generation', model: 'Gemini 3.7 Flash', tokens: '14,200', cost: '$0.014', status: 'completed', time: '1h ago' }
  ]);

  const [projects] = useState<ProjectItem[]>([
    { id: 'p-1', name: 'Sample Search API', description: 'Real-time hybrid vector search across enterprise knowledge bases.', status: 'active', uptime: '99.98%', requests: '1.8M/day', health: 99 },
    { id: 'p-2', name: 'Autonomous Coding Agent Swarm', description: 'Multi-agent DAG task decomposition and surgical safe-edit engine.', status: 'training', uptime: '99.92%', requests: '840K/day', health: 96 },
    { id: 'p-3', name: 'Ultra-Low Latency Voice Bridge', description: 'Bi-directional WebSocket audio pipeline with real-time TTS.', status: 'optimized', uptime: '100.0%', requests: '420K/day', health: 100 },
    { id: 'p-4', name: 'Document Synthesis Engine', description: 'Automated extraction and structured reasoning on financial PDF filings.', status: 'active', uptime: '99.95%', requests: '610K/day', health: 98 }
  ]);

  // Demo Metrics Simulation Stream
  useEffect(() => {
    if (!isLiveStreaming) return;
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        totalRevenue: Math.round(prev.totalRevenue + Math.max(0, (Math.random() * 30 - 10))),
        apiRequests: prev.apiRequests + Math.floor(Math.random() * 120 + 20),
        avgLatency: Number((28.0 + (Math.random() * 1.5 - 0.7)).toFixed(1))
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, [isLiveStreaming]);

  const filteredActivities = activities.filter(act => {
    const matchesSearch = act.task.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          act.model.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          act.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || act.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <div id="nova-saas-dashboard" className="flex h-screen w-full bg-[#080B12] text-slate-100 font-sans select-none overflow-hidden">
      {/* -------------------------------------------------------------
          DESKTOP & TABLET SIDEBAR NAVIGATION
      ------------------------------------------------------------- */}
      <aside className="hidden md:flex flex-col w-64 lg:w-72 bg-[#0D121F] border-r border-[#1B2438] shrink-0 z-30">
        {/* SaaS Analytics Brand Header */}
        <div className="h-16 px-6 border-b border-[#1B2438] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-cyan-500/25">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-extrabold text-base tracking-wide text-white flex items-center gap-2">
                <span>SaaS Analytics</span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">
                  SAMPLE DEMO
                </span>
              </div>
              <div className="text-[11px] text-slate-400 font-mono">Enterprise Intelligence</div>
            </div>
          </div>
        </div>

        {/* Sidebar Nav Links */}
        <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Activity, badge: 'Demo' },
            { id: 'analytics', label: 'Revenue & Growth', icon: LineChart },
            { id: 'models', label: 'AI Models & Usage', icon: Cpu, badge: 'Active' },
            { id: 'projects', label: 'Project Status', icon: FolderKanban, count: projects.length },
            { id: 'activity', label: 'Recent Activity', icon: Clock, count: activities.length },
            { id: 'settings', label: 'Workspace Settings', icon: Settings }
          ].map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={\`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all min-h-[44px] \${
                  isActive 
                    ? 'bg-gradient-to-r from-cyan-950/90 via-[#101A2F] to-indigo-950/40 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-950/40' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#121829]'
                }\`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={\`w-4 h-4 \${isActive ? 'text-cyan-400' : 'text-slate-400'}\`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 animate-pulse">
                    {item.badge}
                  </span>
                )}
                {item.count !== undefined && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#162035] text-slate-400 border border-[#222E46]">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer Account Node */}
        <div className="p-4 border-t border-[#1B2438] bg-[#0A0E18]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center font-bold text-xs text-white shadow-md">
                N
              </div>
              <div className="text-xs">
                <div className="font-semibold text-slate-200">Sample Cluster</div>
                <div className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>DEMO ENVIRONMENT</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsLiveStreaming(!isLiveStreaming)}
              className="p-2 rounded-lg bg-[#141C2E] hover:bg-[#1C2740] text-slate-300 transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
              title={isLiveStreaming ? 'Pause Demo Simulation' : 'Resume Demo Simulation'}
            >
              <RefreshCw className={\`w-3.5 h-3.5 \${isLiveStreaming ? 'text-cyan-400 animate-spin' : 'text-slate-500'}\`} />
            </button>
          </div>
        </div>
      </aside>

      {/* -------------------------------------------------------------
          MAIN COLUMN (HEADER + CONTENT)
      ------------------------------------------------------------- */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Top Header */}
        <header className="h-16 bg-[#0D121F] border-b border-[#1B2438] px-4 sm:px-6 flex items-center justify-between shrink-0 z-30">
          {/* Mobile brand & toggle */}
          <div className="flex items-center gap-3 md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#141C2E] text-slate-200 min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-md">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-sm tracking-wide text-white">SaaS Analytics</span>
            </div>
          </div>

          {/* Search Input in Top Header */}
          <div className="hidden sm:flex items-center flex-1 max-w-md">
            <div className="relative w-full">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search models, projects, metrics, tasks..."
                className="w-full h-9 pl-9 pr-4 bg-[#141B2D] border border-[#232E4A] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all font-sans"
              />
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            {/* Timeframe selector (desktop) */}
            <div className="hidden lg:flex items-center bg-[#090D17] p-1 rounded-xl border border-[#1B2438]">
              {(['24h', '7d', '30d', '12m'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTimeframe(t)}
                  className={\`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-all \${
                    timeframe === t 
                      ? 'bg-cyan-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-slate-200'
                  }\`}
                >
                  {t.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Notifications Bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 rounded-xl bg-[#141B2D] hover:bg-[#1C263F] border border-[#232E4A] text-slate-300 hover:text-white transition-all relative min-h-[40px] min-w-[40px] flex items-center justify-center"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 text-neutral-950 font-mono text-[9px] font-bold flex items-center justify-center shadow-md">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notifications Popover */}
              {showNotifications && (
                <div className="absolute right-0 top-12 w-80 bg-[#0F1424] border border-[#222E48] rounded-2xl shadow-2xl p-4 space-y-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between border-b border-[#1E293E] pb-2">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Bell className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Analytics Alerts</span>
                    </span>
                    <span className="text-[10px] font-mono text-cyan-400">{unreadCount} unread</span>
                  </div>
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {notifications.map(n => (
                      <div key={n.id} className="p-2.5 rounded-xl bg-[#090C16] border border-[#1B2338] space-y-1">
                        <div className="flex items-center justify-between text-xs font-semibold text-white">
                          <span>{n.title}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{n.time}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-sans">{n.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Action Button */}
            <button
              onClick={() => setActiveTab('projects')}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/20 transition-all active:scale-95 min-h-[40px]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Workload</span>
            </button>
          </div>
        </header>

        {/* Mobile Dropdown Menu Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 right-0 bg-[#0D121F]/98 backdrop-blur-xl border-b border-[#1B2438] p-4 space-y-2 z-40 shadow-2xl">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: Activity },
              { id: 'analytics', label: 'Revenue & Growth', icon: LineChart },
              { id: 'models', label: 'AI Models & Usage', icon: Cpu },
              { id: 'projects', label: 'Project Status', icon: FolderKanban },
              { id: 'activity', label: 'Recent Activity', icon: Clock },
              { id: 'settings', label: 'Workspace Settings', icon: Settings }
            ].map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as any);
                    setMobileMenuOpen(false);
                  }}
                  className={\`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-xs font-semibold min-h-[44px] \${
                    isActive ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' : 'text-slate-300 hover:bg-[#162035]'
                  }\`}
                >
                  <Icon className="w-4 h-4 text-cyan-400" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* -------------------------------------------------------------
            MAIN VIEWPORT CANVAS
        ------------------------------------------------------------- */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Sub-Header Title Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1B2438] pb-4">
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 capitalize">
                <span>{activeTab === 'dashboard' ? 'SaaS Analytics Dashboard' :
                       activeTab === 'analytics' ? 'Financial Telemetry & Revenue Growth' :
                       activeTab === 'models' ? 'AI Model Infrastructure & Inference' :
                       activeTab === 'projects' ? 'Active AI Project Workloads' :
                       activeTab === 'activity' ? 'Recent Execution & Mutation Log' : 'Workspace & Platform Settings'}</span>
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Illustrative demo metrics only; no live telemetry, billing, or model dispatch is connected.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-slate-400 bg-[#0E1322] px-3 py-1.5 rounded-xl border border-[#1E2840] flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>INFERENCE LATENCY: <strong className="text-cyan-300">{metrics.avgLatency}ms</strong></span>
              </span>
            </div>
          </div>

          {/* ========================================================
              VIEW 1: PRIMARY DASHBOARD
          ======================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* 4 KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden group hover:border-cyan-500/40 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">TOTAL REVENUE</span>
                    <div className="p-2.5 rounded-xl bg-cyan-950/70 border border-cyan-800/60 text-cyan-400">
                      <DollarSign className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    \${metrics.totalRevenue.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+18.4% vs last month</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 to-indigo-500" />
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden group hover:border-indigo-500/40 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">ACTIVE AI AGENTS</span>
                    <div className="p-2.5 rounded-xl bg-indigo-950/70 border border-indigo-800/60 text-indigo-400">
                      <Bot className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    {metrics.activeAgents.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+24.2% swarm expansion</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-500" />
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden group hover:border-purple-500/40 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">API REQUESTS</span>
                    <div className="p-2.5 rounded-xl bg-purple-950/70 border border-purple-800/60 text-purple-400">
                      <Zap className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    {(metrics.apiRequests / 1000000).toFixed(2)}M
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+12.6% throughput</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-purple-500" />
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden group hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">AVG INFERENCE</span>
                    <div className="p-2.5 rounded-xl bg-emerald-950/70 border border-emerald-800/60 text-emerald-400">
                      <Cpu className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    {metrics.avgLatency}ms
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowDownRight className="w-3.5 h-3.5" />
                    <span>-14.2% faster TTFT</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500" />
                </div>
              </div>

              {/* Revenue & AI Usage Telemetry Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Revenue Curve Chart (8 Cols) */}
                <div className="lg:col-span-8 p-5 sm:p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h3 className="font-bold text-base text-white flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-cyan-400" />
                        <span>Revenue Growth & Token Consumption</span>
                      </h3>
                      <p className="text-xs text-slate-400">Illustrative financial metrics across sample billing tiers</p>
                    </div>
                    <div className="flex items-center gap-3 text-xs font-mono">
                      <span className="flex items-center gap-1.5 text-cyan-400">
                        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                        <span>Revenue (\$)</span>
                      </span>
                      <span className="flex items-center gap-1.5 text-indigo-400">
                        <span className="w-2.5 h-2.5 rounded-full bg-indigo-400" />
                        <span>Inference Cost</span>
                      </span>
                    </div>
                  </div>

                  {/* SVG Multi-Series Chart */}
                  <div className="h-64 sm:h-72 w-full pt-4">
                    <svg viewBox="0 0 800 240" className="w-full h-full overflow-visible">
                      <defs>
                        <linearGradient id="novaCyanGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.45" />
                          <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                        </linearGradient>
                        <linearGradient id="novaIndigoGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#6366f1" stopOpacity="0.25" />
                          <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>
                      {[40, 90, 140, 190].map(y => (
                        <line key={y} x1="0" y1={y} x2="800" y2={y} stroke="#1B2438" strokeDasharray="3 3" strokeWidth="1" />
                      ))}
                      <path
                        d="M 0 200 Q 100 130, 200 150 T 400 80 T 600 60 T 800 20 L 800 220 L 0 220 Z"
                        fill="url(#novaCyanGrad)"
                      />
                      <path
                        d="M 0 200 Q 100 130, 200 150 T 400 80 T 600 60 T 800 20"
                        fill="none"
                        stroke="#06b6d4"
                        strokeWidth="3.5"
                      />
                      <path
                        d="M 0 210 Q 100 170, 200 180 T 400 130 T 600 120 T 800 90 L 800 220 L 0 220 Z"
                        fill="url(#novaIndigoGrad)"
                      />
                      <path
                        d="M 0 210 Q 100 170, 200 180 T 400 130 T 600 120 T 800 90"
                        fill="none"
                        stroke="#6366f1"
                        strokeWidth="2"
                        strokeDasharray="4 4"
                      />
                      {[[200, 150], [400, 80], [600, 60], [800, 20]].map(([x, y], idx) => (
                        <g key={idx}>
                          <circle cx={x} cy={y} r="5" fill="#06b6d4" />
                          <circle cx={x} cy={y} r="10" fill="#06b6d4" fillOpacity="0.25" className="animate-ping" />
                        </g>
                      ))}
                    </svg>
                  </div>
                </div>

                {/* AI Usage Breakdown (4 Cols) */}
                <div className="lg:col-span-4 p-5 sm:p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <h3 className="font-bold text-base text-white flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-indigo-400" />
                    <span>Model Usage Distribution</span>
                  </h3>
                  <p className="text-xs text-slate-400">Illustrative inference-load distribution across sample model tiers</p>

                  <div className="space-y-4 pt-2">
                    {[
                      { model: 'Gemini 3.7 Flash (Hybrid)', pct: 64, color: 'bg-cyan-500', tokens: '64.2M' },
                      { model: 'Gemini 3.1 Pro (Reasoning)', pct: 24, color: 'bg-indigo-500', tokens: '24.1M' },
                      { model: 'Example Realtime Model (Voice/Vision)', pct: 12, color: 'bg-purple-500', tokens: '12.0M' }
                    ].map((m, idx) => (
                      <div key={idx} className="space-y-1.5 font-mono text-xs">
                        <div className="flex justify-between">
                          <span className="text-slate-300 font-sans font-semibold text-xs">{m.model}</span>
                          <span className="text-cyan-300 font-bold">{m.pct}%</span>
                        </div>
                        <div className="w-full h-2 bg-[#090C16] rounded-full overflow-hidden border border-[#1A2236]">
                          <div className={\`h-full \${m.color} rounded-full\`} style={{ width: \`\${m.pct}%\` }} />
                        </div>
                        <div className="text-[10px] text-slate-500 text-right">{m.tokens} tokens processed</div>
                      </div>
                    ))}
                  </div>

                  <div className="p-3 rounded-xl bg-[#090C16] border border-[#182136] space-y-1 text-xs font-mono">
                    <div className="flex justify-between text-slate-400 text-[11px]">
                      <span>Peak Bandwidth:</span>
                      <span className="text-emerald-400 font-bold">14,200 tok/sec</span>
                    </div>
                    <div className="flex justify-between text-slate-400 text-[11px]">
                      <span>Cache Hit Rate:</span>
                      <span className="text-cyan-300 font-bold">88.4% (Sub-5ms)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Project Status Section */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <FolderKanban className="w-4 h-4 text-cyan-400" />
                    <span>Active AI Project Workloads</span>
                  </h3>
                  <button 
                    onClick={() => setActiveTab('projects')}
                    className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    <span>View All Workloads ({projects.length})</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {projects.map(proj => (
                    <div key={proj.id} className="p-4 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 hover:border-cyan-500/40 transition-colors">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/80 uppercase">
                          {proj.status}
                        </span>
                        <span className="text-xs font-mono text-emerald-400 font-semibold">{proj.uptime}</span>
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-white">{proj.name}</h4>
                        <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">{proj.description}</p>
                      </div>
                      <div className="pt-2 border-t border-[#182136] flex items-center justify-between text-[11px] font-mono text-slate-400">
                        <span>{proj.requests}</span>
                        <span className="text-emerald-400">{proj.health}% Health</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Activity Table */}
              <div className="rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl overflow-hidden space-y-3 p-4 sm:p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-base text-white flex items-center gap-2">
                      <Clock className="w-4 h-4 text-cyan-400" />
                      <span>Recent AI Inference & Task Activity</span>
                    </h3>
                    <p className="text-xs text-slate-400">Detailed transaction trace of neural agent dispatches</p>
                  </div>

                  {/* Filter chips */}
                  <div className="flex items-center gap-1.5 overflow-x-auto">
                    {['all', 'completed', 'processing', 'warning'].map(f => (
                      <button
                        key={f}
                        onClick={() => setStatusFilter(f)}
                        className={\`px-2.5 py-1 rounded-lg text-xs font-mono capitalize transition-all min-h-[32px] \${
                          statusFilter === f 
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 font-bold' 
                            : 'bg-[#121828] text-slate-400 hover:text-white border border-[#1C253C]'
                        }\`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-[#090D17] border-b border-[#1B2438] text-slate-400 uppercase text-[10px]">
                      <tr>
                        <th className="p-3">ID</th>
                        <th className="p-3">Task Objective</th>
                        <th className="p-3">Model</th>
                        <th className="p-3">Tokens</th>
                        <th className="p-3">Cost</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Time</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#182133]">
                      {filteredActivities.map(act => (
                        <tr 
                          key={act.id} 
                          onClick={() => setSelectedActivity(act)}
                          className="hover:bg-[#121828] cursor-pointer transition-colors"
                        >
                          <td className="p-3 text-cyan-400 font-bold">{act.id}</td>
                          <td className="p-3 font-sans font-medium text-white">{act.task}</td>
                          <td className="p-3 text-indigo-300 font-semibold">{act.model}</td>
                          <td className="p-3 text-slate-300">{act.tokens}</td>
                          <td className="p-3 text-emerald-400 font-bold">{act.cost}</td>
                          <td className="p-3">
                            <span className={\`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase \${
                              act.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                              act.status === 'processing' ? 'bg-cyan-950 text-cyan-400 border border-cyan-800 animate-pulse' :
                              'bg-amber-950 text-amber-400 border border-amber-800'
                            }\`}>
                              {act.status}
                            </span>
                          </td>
                          <td className="p-3 text-right text-slate-400">{act.time}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 2: PROJECTS & WORKLOADS
          ======================================================== */}
          {activeTab === 'projects' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {projects.map(proj => (
                  <div key={proj.id} className="p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center font-bold text-white shadow-md">
                          {proj.name.charAt(0)}
                        </div>
                        <div>
                          <h3 className="font-bold text-base text-white">{proj.name}</h3>
                          <div className="text-[11px] text-slate-400 font-mono">Uptime: {proj.uptime}</div>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {proj.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed font-sans">{proj.description}</p>
                    <div className="grid grid-cols-2 gap-2 pt-3 border-t border-[#182136] text-xs font-mono">
                      <div className="p-2 rounded bg-[#090C16]">
                        <span className="text-slate-500">Query Volume:</span>
                        <div className="font-bold text-white mt-0.5">{proj.requests}</div>
                      </div>
                      <div className="p-2 rounded bg-[#090C16]">
                        <span className="text-slate-500">Node Stability:</span>
                        <div className="font-bold text-emerald-400 mt-0.5">{proj.health}% Optimal</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 3: AI MODELS & USAGE
          ======================================================== */}
          {activeTab === 'models' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { name: 'Gemini 3.7 Flash', tier: 'Recommended', tps: '14,200 tok/sec', context: '1,000,000 tokens', latency: '24ms', desc: 'Hybrid reasoning and high throughput.' },
                  { name: 'Gemini 3.1 Pro', tier: 'Deep Reasoning', tps: '4,800 tok/sec', context: '2,000,000 tokens', latency: '65ms', desc: 'Algorithmic planning and formal logic.' },
                  { name: 'Example Audio/Vision Model', tier: 'Demo', tps: 'Illustrative', context: 'Example context', latency: 'Example latency', desc: 'Illustrative sample model metadata; no model is connected by this template.' }
                ].map((mod, i) => (
                  <div key={i} className="p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-base text-white">{mod.name}</h3>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                        {mod.tier}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">{mod.desc}</p>
                    <div className="space-y-2 pt-2 border-t border-[#182136] text-xs font-mono">
                      <div className="flex justify-between text-slate-400">
                        <span>Speed:</span>
                        <span className="text-white font-bold">{mod.tps}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Context:</span>
                        <span className="text-cyan-300 font-bold">{mod.context}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Latency:</span>
                        <span className="text-emerald-400 font-bold">{mod.latency}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 4: SETTINGS & REST KEYS
          ======================================================== */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-5">
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Key className="w-4 h-4 text-cyan-400" />
                  <span>API Integration Setup (Demo)</span>
                </h3>
                <div className="max-w-xl space-y-2 text-xs">
                  <div className="rounded-xl border border-amber-800/60 bg-amber-950/20 p-4 text-amber-200">
                    This starter uses illustrative demo metrics. No API credential is configured, and no live production service is connected.
                  </div>
                  <p className="text-slate-400">To connect a real service, implement a backend integration and store credentials in the deployment environment. Never paste secret keys into a client-side form.</p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Activity Detail Modal */}
      {selectedActivity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm font-sans">
          <div className="w-full max-w-md bg-[#0D121F] border border-[#1B2438] rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#1B2438] pb-3">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Task Execution Details</span>
              </h3>
              <button onClick={() => setSelectedActivity(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Identifier:</span>
                <span className="font-bold text-cyan-400">{selectedActivity.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Objective:</span>
                <span className="text-white font-sans">{selectedActivity.task}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Model Engine:</span>
                <span className="text-indigo-300">{selectedActivity.model}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Tokens Processed:</span>
                <span className="text-slate-200">{selectedActivity.tokens}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Billed Cost:</span>
                <span className="font-bold text-emerald-400">{selectedActivity.cost}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Status:</span>
                <span className="font-bold uppercase text-emerald-400">{selectedActivity.status}</span>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-[#1B2438]">
              <button
                onClick={() => setSelectedActivity(null)}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
`
  }
};
