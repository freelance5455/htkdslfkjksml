/**
 * PULSE - Realtime Analytics & Financial Metrics Platform
 * Comprehensive multi-module SaaS dashboard with live metrics, SVG charts, transactions,
 * customers CRM, financial reports, settings, and full mobile/tablet/desktop responsive layouts.
 */

import { ProjectTemplate } from '../types';

export const PULSE_PROJECT: ProjectTemplate = {
  id: 'pulse-analytics',
  title: 'PULSE - Realtime Analytics & Financial Platform',
  description: 'Enterprise analytics dashboard featuring live revenue telemetry, interactive SVG multi-series charts, customer CRM, transaction ledger, automated financial reports, and workspace settings.',
  category: 'Fintech & Analytics',
  badge: 'Flagship Platform',
  iconName: 'Activity',
  files: {
    'src/App.tsx': `import React, { useState, useEffect } from 'react';
import { 
  Activity, BarChart3, LineChart, PieChart, Users, DollarSign, 
  CreditCard, FileText, Settings, Search, Filter, ArrowUpRight, 
  ArrowDownRight, RefreshCw, Download, Plus, CheckCircle2, 
  AlertCircle, ChevronRight, SlidersHorizontal, Bell, Shield, 
  Key, Database, Layers, TrendingUp, HelpCircle, Menu, X, 
  Calendar, ChevronDown, Check, Eye, EyeOff, Copy, ExternalLink
} from 'lucide-react';

interface Transaction {
  id: string;
  customer: string;
  email: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed' | 'refunded';
  method: 'Stripe' | 'PayPal' | 'Crypto' | 'Wire';
  category: 'Subscription' | 'Usage' | 'Enterprise' | 'Add-on';
  date: string;
}

interface Customer {
  id: string;
  name: string;
  email: string;
  company: string;
  tier: 'Enterprise' | 'Pro' | 'Starter';
  spend: number;
  status: 'active' | 'churn_risk' | 'trial';
  joinDate: string;
}

export default function PulseApp() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analytics' | 'charts' | 'transactions' | 'customers' | 'reports' | 'settings'>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | '12m'>('7d');
  const [isLiveStreaming, setIsLiveStreaming] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [reportGenerating, setReportGenerating] = useState(false);
  const [reportSuccess, setReportSuccess] = useState(false);

  // Live Metrics State
  const [metrics, setMetrics] = useState({
    totalRevenue: 128420,
    mrr: 24850,
    activeUsers: 42850,
    churnRate: 1.24,
    conversionRate: 4.82
  });

  // Simulated Transactions Database
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: 'TX-9821', customer: 'Sarah Jenkins', email: 'sarah@vertex.io', amount: 2400.00, status: 'completed', method: 'Stripe', category: 'Enterprise', date: '2 mins ago' },
    { id: 'TX-9820', customer: 'David Thorne', email: 'd.thorne@acme.corp', amount: 890.00, status: 'completed', method: 'Wire', category: 'Subscription', date: '14 mins ago' },
    { id: 'TX-9819', customer: 'Elena Rostova', email: 'elena@example.com', amount: 149.00, status: 'pending', method: 'PayPal', category: 'Usage', date: '42 mins ago' },
    { id: 'TX-9818', customer: 'Marcus Vance', email: 'mvance@cloudmesh.dev', amount: 4800.00, status: 'completed', method: 'Stripe', category: 'Enterprise', date: '1 hour ago' },
    { id: 'TX-9817', customer: 'Kaito Tanaka', email: 'kaito@tokyolab.jp', amount: 79.00, status: 'failed', method: 'Crypto', category: 'Add-on', date: '2 hours ago' },
    { id: 'TX-9816', customer: 'Amina Al-Mansoor', email: 'amina@dubaiscale.ae', amount: 1250.00, status: 'completed', method: 'Stripe', category: 'Subscription', date: '3 hours ago' },
    { id: 'TX-9815', customer: 'Liam O’Connor', email: 'liam@celticsys.ie', amount: 320.00, status: 'refunded', method: 'PayPal', category: 'Usage', date: '5 hours ago' }
  ]);

  // Simulated Customers CRM Database
  const [customers, setCustomers] = useState<Customer[]>([
    { id: 'CUST-101', name: 'Sarah Jenkins', email: 'sarah@vertex.io', company: 'Vertex Systems', tier: 'Enterprise', spend: 28800, status: 'active', joinDate: 'Jan 2024' },
    { id: 'CUST-102', name: 'David Thorne', email: 'd.thorne@acme.corp', company: 'Acme Corporation', tier: 'Pro', spend: 10680, status: 'active', joinDate: 'Mar 2024' },
    { id: 'CUST-103', name: 'Elena Rostova', email: 'elena@example.com', company: 'Northstar Systems', tier: 'Starter', spend: 1788, status: 'trial', joinDate: 'Aug 2024' },
    { id: 'CUST-104', name: 'Marcus Vance', email: 'mvance@cloudmesh.dev', company: 'CloudMesh Global', tier: 'Enterprise', spend: 57600, status: 'active', joinDate: 'Nov 2023' },
    { id: 'CUST-105', name: 'Kaito Tanaka', email: 'kaito@tokyolab.jp', company: 'Tokyo Quantum Lab', tier: 'Starter', spend: 948, status: 'churn_risk', joinDate: 'Feb 2024' },
    { id: 'CUST-106', name: 'Amina Al-Mansoor', email: 'amina@dubaiscale.ae', company: 'Gulf Scale Ventures', tier: 'Pro', spend: 15000, status: 'active', joinDate: 'May 2024' }
  ]);

  // Realtime Live Stream Simulation
  useEffect(() => {
    if (!isLiveStreaming) return;
    const interval = setInterval(() => {
      const delta = (Math.random() * 40 - 15);
      setMetrics(prev => ({
        ...prev,
        totalRevenue: Math.round(prev.totalRevenue + Math.max(0, delta * 3)),
        activeUsers: prev.activeUsers + (Math.random() > 0.6 ? 1 : -1)
      }));
    }, 2500);
    return () => clearInterval(interval);
  }, [isLiveStreaming]);

  // Filtered Transactions
  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.customer.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tx.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          tx.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || tx.status === statusFilter;
    const matchesMethod = methodFilter === 'all' || tx.method === methodFilter;
    return matchesSearch && matchesStatus && matchesMethod;
  });

  const handleCopyKey = () => {
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleGenerateReport = () => {
    setReportGenerating(true);
    setReportSuccess(false);
    setTimeout(() => {
      setReportGenerating(false);
      setReportSuccess(true);
      setTimeout(() => setReportSuccess(false), 4000);
    }, 1500);
  };

  return (
    <div className="flex h-screen w-full bg-[#080B12] text-slate-100 font-sans select-none overflow-hidden">
      {/* Desktop & Tablet Sidebar */}
      <aside className="hidden md:flex flex-col w-64 lg:w-72 bg-[#0D121F] border-r border-[#1B2438] shrink-0 z-30">
        {/* Brand Header */}
        <div className="h-16 px-6 border-b border-[#1B2438] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-base tracking-wide text-white flex items-center gap-1.5">
                <span>PULSE</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">REALTIME</span>
              </div>
              <div className="text-[11px] text-slate-400">Financial Intelligence</div>
            </div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Activity, badge: 'Live' },
            { id: 'analytics', label: 'Analytics', icon: LineChart },
            { id: 'charts', label: 'Charts & Graphs', icon: BarChart3 },
            { id: 'transactions', label: 'Transactions', icon: DollarSign, count: transactions.length },
            { id: 'customers', label: 'Customers CRM', icon: Users, count: customers.length },
            { id: 'reports', label: 'Financial Reports', icon: FileText },
            { id: 'settings', label: 'Workspace Settings', icon: Settings }
          ].map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={\`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all \${
                  isActive 
                    ? 'bg-gradient-to-r from-cyan-950/80 to-indigo-950/40 text-cyan-300 border border-cyan-500/30 shadow-sm' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#121829]'
                }\`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={\`w-4 h-4 \${isActive ? 'text-cyan-400' : 'text-slate-400'}\`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 animate-pulse">
                    {item.badge}
                  </span>
                )}
                {item.count !== undefined && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#162035] text-slate-400">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer Account */}
        <div className="p-4 border-t border-[#1B2438] bg-[#0A0E18]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-cyan-600/30 border border-cyan-500/50 flex items-center justify-center font-bold text-xs text-cyan-300">
                P
              </div>
              <div className="text-xs">
                <div className="font-semibold text-slate-200">Production Node</div>
                <div className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>US-EAST-1 ACTIVE</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsLiveStreaming(!isLiveStreaming)}
              className="p-1.5 rounded-lg bg-[#141C2E] hover:bg-[#1C2740] text-slate-300 transition-colors"
              title={isLiveStreaming ? 'Pause Live Stream' : 'Resume Live Stream'}
            >
              <RefreshCw className={\`w-3.5 h-3.5 \${isLiveStreaming ? 'text-cyan-400 animate-spin' : 'text-slate-500'}\`} />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Header & Drawer */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Mobile Navigation Bar */}
        <header className="h-14 md:hidden bg-[#0D121F] border-b border-[#1B2438] px-4 flex items-center justify-between shrink-0 z-30">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center">
              <Activity className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-sm tracking-wide text-white">PULSE</span>
            <span className="text-[10px] font-mono px-1 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">REALTIME</span>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsLiveStreaming(!isLiveStreaming)}
              className="p-2 rounded-lg bg-[#141C2E] text-cyan-400"
            >
              <RefreshCw className={\`w-4 h-4 \${isLiveStreaming ? 'animate-spin' : ''}\`} />
            </button>
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#141C2E] text-slate-200"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-14 left-0 right-0 bg-[#0D121F]/95 backdrop-blur-md border-b border-[#1B2438] p-3 space-y-1 z-40 shadow-2xl">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: Activity },
              { id: 'analytics', label: 'Analytics', icon: LineChart },
              { id: 'charts', label: 'Charts & Graphs', icon: BarChart3 },
              { id: 'transactions', label: 'Transactions', icon: DollarSign },
              { id: 'customers', label: 'Customers CRM', icon: Users },
              { id: 'reports', label: 'Financial Reports', icon: FileText },
              { id: 'settings', label: 'Workspace Settings', icon: Settings }
            ].map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as any);
                    setMobileMenuOpen(false);
                  }}
                  className={\`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold \${
                    isActive ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' : 'text-slate-300 hover:bg-[#162035]'
                  }\`}
                >
                  <Icon className="w-4 h-4 text-cyan-400" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Header Controls Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1B2438] pb-5">
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
                <span>{activeTab === 'dashboard' ? 'Executive Financial Overview' : 
                       activeTab === 'analytics' ? 'Advanced Analytics & Conversion' :
                       activeTab === 'charts' ? 'Visual Chart Telemetry' :
                       activeTab === 'transactions' ? 'Transaction Ledger' :
                       activeTab === 'customers' ? 'Customer CRM Directory' :
                       activeTab === 'reports' ? 'Automated Financial Reports' : 'Workspace & API Settings'}</span>
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Autonomous real-time revenue intelligence platform • Connected to multi-region ledger
              </p>
            </div>

            {/* Timeframe Toggles */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="flex items-center bg-[#0D121F] p-1 rounded-xl border border-[#1B2438]">
                {(['24h', '7d', '30d', '12m'] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => setTimeframe(t)}
                    className={\`px-3 py-1 rounded-lg text-xs font-mono font-semibold transition-all \${
                      timeframe === t 
                        ? 'bg-cyan-600 text-white shadow-sm' 
                        : 'text-slate-400 hover:text-slate-200'
                    }\`}
                  >
                    {t.toUpperCase()}
                  </button>
                ))}
              </div>

              <button 
                onClick={handleGenerateReport}
                className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-cyan-600/20 transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export</span>
              </button>
            </div>
          </div>

          {/* ========================================================
              VIEW 1: DASHBOARD
             ======================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* KPI Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-400">TOTAL GROSS REVENUE</span>
                    <div className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-800/60 text-cyan-400">
                      <DollarSign className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    \${metrics.totalRevenue.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+14.8% vs last month</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 to-indigo-500" />
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-400">MONTHLY RECURRING (MRR)</span>
                    <div className="p-2 rounded-xl bg-indigo-950/60 border border-indigo-800/60 text-indigo-400">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    \${metrics.mrr.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+8.4% growth</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-500" />
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-400">ACTIVE PLATFORM USERS</span>
                    <div className="p-2 rounded-xl bg-purple-950/60 border border-purple-800/60 text-purple-400">
                      <Users className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    {metrics.activeUsers.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+22.1% net expansion</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-purple-500" />
                </div>

                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-3 relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-400">CHURN RATE</span>
                    <div className="p-2 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-400">
                      <Shield className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white">
                    {metrics.churnRate}%
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                    <ArrowDownRight className="w-3.5 h-3.5" />
                    <span>-0.3% decrease (Healthy)</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500" />
                </div>
              </div>

              {/* Main SVG Revenue Graph Area */}
              <div className="p-5 sm:p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-base text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-cyan-400" />
                      <span>Real-Time Revenue Telemetry & Volume</span>
                    </h3>
                    <p className="text-xs text-slate-400">Live transaction stream processed via automated websocket node</p>
                  </div>
                  <div className="flex items-center gap-3 text-xs font-mono">
                    <span className="flex items-center gap-1.5 text-cyan-400">
                      <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                      <span>Revenue (\$)</span>
                    </span>
                    <span className="flex items-center gap-1.5 text-indigo-400">
                      <span className="w-2.5 h-2.5 rounded-full bg-indigo-400" />
                      <span>Expenses (\$)</span>
                    </span>
                  </div>
                </div>

                {/* Responsive SVG Area Chart */}
                <div className="h-64 sm:h-72 w-full pt-4">
                  <svg viewBox="0 0 800 240" className="w-full h-full overflow-visible">
                    <defs>
                      <linearGradient id="cyanArea" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
                        <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                      </linearGradient>
                      <linearGradient id="indigoArea" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#6366f1" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Horizontal Grid lines */}
                    {[40, 90, 140, 190].map(y => (
                      <line key={y} x1="0" y1={y} x2="800" y2={y} stroke="#1F293D" strokeDasharray="3 3" strokeWidth="1" />
                    ))}

                    {/* Area 1 (Revenue) */}
                    <path
                      d="M 0 200 Q 100 140, 200 160 T 400 90 T 600 70 T 800 30 L 800 220 L 0 220 Z"
                      fill="url(#cyanArea)"
                    />
                    {/* Line 1 */}
                    <path
                      d="M 0 200 Q 100 140, 200 160 T 400 90 T 600 70 T 800 30"
                      fill="none"
                      stroke="#06b6d4"
                      strokeWidth="3"
                    />

                    {/* Area 2 (Expenses) */}
                    <path
                      d="M 0 210 Q 100 180, 200 190 T 400 150 T 600 130 T 800 110 L 800 220 L 0 220 Z"
                      fill="url(#indigoArea)"
                    />
                    {/* Line 2 */}
                    <path
                      d="M 0 210 Q 100 180, 200 190 T 400 150 T 600 130 T 800 110"
                      fill="none"
                      stroke="#6366f1"
                      strokeWidth="2"
                      strokeDasharray="4 4"
                    />

                    {/* Pulse Points */}
                    {[[200, 160], [400, 90], [600, 70], [800, 30]].map(([x, y], idx) => (
                      <g key={idx}>
                        <circle cx={x} cy={y} r="5" fill="#06b6d4" />
                        <circle cx={x} cy={y} r="9" fill="#06b6d4" fillOpacity="0.3" className="animate-ping" />
                      </g>
                    ))}
                  </svg>
                </div>
              </div>

              {/* Bottom Quick Section: Recent Transactions & System Health */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Recent Transactions List */}
                <div className="lg:col-span-2 p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-white flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-emerald-400" />
                      <span>Live Transaction Feed</span>
                    </h3>
                    <button 
                      onClick={() => setActiveTab('transactions')}
                      className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-mono"
                    >
                      <span>View All ({transactions.length})</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {transactions.slice(0, 4).map(tx => (
                      <div 
                        key={tx.id}
                        onClick={() => setSelectedTransaction(tx)}
                        className="p-3 rounded-xl bg-[#090C14] hover:bg-[#121828] border border-[#1A2337] flex items-center justify-between cursor-pointer transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={\`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs \${
                            tx.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                            tx.status === 'pending' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                            'bg-rose-950 text-rose-400 border border-rose-800'
                          }\`}>
                            {tx.status === 'completed' ? '✓' : tx.status === 'pending' ? '⋯' : '!'}
                          </div>
                          <div>
                            <div className="font-semibold text-xs text-white">{tx.customer}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{tx.email} • {tx.method}</div>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-bold font-mono text-sm text-white">\${tx.amount.toFixed(2)}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{tx.date}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Regional Infrastructure Health */}
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <Shield className="w-4 h-4 text-cyan-400" />
                    <span>Microservice Health</span>
                  </h3>

                  <div className="space-y-3 text-xs font-mono">
                    {[
                      { name: 'Auth Gateway (OAuth2/JWT)', status: 'HEALTHY', latency: '12ms' },
                      { name: 'Stripe Webhook Node', status: 'HEALTHY', latency: '24ms' },
                      { name: 'PostgreSQL Relational DB', status: 'HEALTHY', latency: '4ms' },
                      { name: 'Redis Cache Memory', status: 'HEALTHY', latency: '1ms' },
                    ].map((svc, i) => (
                      <div key={i} className="p-2.5 rounded-lg bg-[#090C14] border border-[#1B2438] flex items-center justify-between">
                        <span className="text-slate-300">{svc.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold">{svc.latency}</span>
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 2: ANALYTICS
             ======================================================== */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              {/* Funnel & Geo Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Conversion Funnel */}
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-cyan-400" />
                    <span>Conversion Funnel Analysis</span>
                  </h3>

                  <div className="space-y-3 pt-2">
                    {[
                      { stage: 'Unique Visitors', count: '148,200', pct: 100, color: 'bg-cyan-500' },
                      { stage: 'Free Trial Signups', count: '32,400', pct: 21.8, color: 'bg-indigo-500' },
                      { stage: 'Active Onboarding', count: '18,900', pct: 12.7, color: 'bg-purple-500' },
                      { stage: 'Paid Subscriptions', count: '7,140', pct: 4.82, color: 'bg-emerald-500' }
                    ].map((step, i) => (
                      <div key={i} className="space-y-1">
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-300">{step.stage}</span>
                          <span className="text-white font-bold">{step.count} ({step.pct}%)</span>
                        </div>
                        <div className="w-full h-2.5 bg-[#090C14] rounded-full overflow-hidden border border-[#1B2438]">
                          <div className={\`h-full \${step.color} rounded-full\`} style={{ width: \`\${step.pct}%\` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Geographic Breakdown */}
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <PieChart className="w-4 h-4 text-purple-400" />
                    <span>Geographic Revenue Distribution</span>
                  </h3>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    {[
                      { region: 'North America (US/CA)', revenue: '\$61,641', share: '48%', color: 'border-cyan-500' },
                      { region: 'European Union (EU)', revenue: '\$35,957', share: '28%', color: 'border-indigo-500' },
                      { region: 'Asia-Pacific (APAC)', revenue: '\$20,547', share: '16%', color: 'border-purple-500' },
                      { region: 'Rest of World (LATAM/MEA)', revenue: '\$10,273', share: '8%', color: 'border-emerald-500' }
                    ].map((geo, i) => (
                      <div key={i} className={\`p-3.5 rounded-xl bg-[#090C14] border \${geo.color} space-y-1\`}>
                        <div className="text-xs text-slate-400">{geo.region}</div>
                        <div className="text-lg font-bold font-mono text-white">{geo.revenue}</div>
                        <div className="text-[11px] font-mono text-cyan-400">{geo.share} of total</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 3: CHARTS & GRAPHS
             ======================================================== */}
          {activeTab === 'charts' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Bar Chart: Monthly MRR Trajectory */}
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-cyan-400" />
                    <span>Monthly Recurring Revenue Trajectory</span>
                  </h3>

                  <div className="h-56 w-full flex items-end justify-between gap-2 pt-6 px-2">
                    {[
                      { month: 'Jan', value: 14000, height: '40%' },
                      { month: 'Feb', value: 16500, height: '48%' },
                      { month: 'Mar', value: 18200, height: '55%' },
                      { month: 'Apr', value: 20400, height: '64%' },
                      { month: 'May', value: 22100, height: '72%' },
                      { month: 'Jun', value: 23800, height: '84%' },
                      { month: 'Jul', value: 24850, height: '95%' },
                    ].map((bar, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                        <div 
                          className="w-full bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-t-md transition-all group-hover:brightness-125"
                          style={{ height: bar.height }}
                        />
                        <span className="text-[10px] font-mono text-slate-400">{bar.month}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Donut Chart: Plan Distribution */}
                <div className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <PieChart className="w-4 h-4 text-indigo-400" />
                    <span>Subscription Tier Breakdown</span>
                  </h3>

                  <div className="space-y-4 pt-2">
                    {[
                      { tier: 'Enterprise Tier ($2,400/mo)', count: '48 accounts', pct: 54, color: 'bg-indigo-500' },
                      { tier: 'Pro Tier ($299/mo)', count: '280 accounts', pct: 32, color: 'bg-cyan-500' },
                      { tier: 'Starter Tier ($49/mo)', count: '740 accounts', pct: 14, color: 'bg-purple-500' }
                    ].map((t, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-300">{t.tier}</span>
                          <span className="text-white font-bold">{t.count} ({t.pct}%)</span>
                        </div>
                        <div className="w-full h-3 bg-[#090C14] rounded-full overflow-hidden border border-[#1B2438]">
                          <div className={\`h-full \${t.color} rounded-full\`} style={{ width: \`\${t.pct}%\` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 4: TRANSACTIONS
             ======================================================== */}
          {activeTab === 'transactions' && (
            <div className="space-y-4">
              {/* Filter Controls Bar */}
              <div className="p-4 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl flex flex-col md:flex-row items-center justify-between gap-3">
                {/* Search Input */}
                <div className="relative w-full md:w-80">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by customer, email, or TX ID..."
                    className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-[#090C14] border border-[#1B2438] text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Dropdown Filters */}
                <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-3 py-1.5 rounded-xl bg-[#090C14] border border-[#1B2438] text-xs text-slate-300 focus:outline-none font-mono"
                  >
                    <option value="all">Status: All</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                    <option value="failed">Failed</option>
                    <option value="refunded">Refunded</option>
                  </select>

                  <select
                    value={methodFilter}
                    onChange={(e) => setMethodFilter(e.target.value)}
                    className="px-3 py-1.5 rounded-xl bg-[#090C14] border border-[#1B2438] text-xs text-slate-300 focus:outline-none font-mono"
                  >
                    <option value="all">Payment: All</option>
                    <option value="Stripe">Stripe</option>
                    <option value="PayPal">PayPal</option>
                    <option value="Crypto">Crypto</option>
                    <option value="Wire">Wire</option>
                  </select>
                </div>
              </div>

              {/* Transactions Table */}
              <div className="rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#090D17] border-b border-[#1B2438] text-slate-400 font-mono uppercase text-[10px]">
                      <tr>
                        <th className="py-3 px-4">Transaction ID</th>
                        <th className="py-3 px-4">Customer</th>
                        <th className="py-3 px-4">Category</th>
                        <th className="py-3 px-4">Method</th>
                        <th className="py-3 px-4">Amount</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#182133] font-mono">
                      {filteredTransactions.map(tx => (
                        <tr 
                          key={tx.id} 
                          onClick={() => setSelectedTransaction(tx)}
                          className="hover:bg-[#121828] transition-colors cursor-pointer"
                        >
                          <td className="py-3 px-4 font-bold text-cyan-400">{tx.id}</td>
                          <td className="py-3 px-4 font-sans font-medium text-white">{tx.customer}</td>
                          <td className="py-3 px-4 text-slate-400">{tx.category}</td>
                          <td className="py-3 px-4 text-slate-300">{tx.method}</td>
                          <td className="py-3 px-4 font-bold text-white">\${tx.amount.toFixed(2)}</td>
                          <td className="py-3 px-4">
                            <span className={\`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase \${
                              tx.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                              tx.status === 'pending' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                              tx.status === 'failed' ? 'bg-rose-950 text-rose-400 border border-rose-800' :
                              'bg-neutral-800 text-neutral-400'
                            }\`}>
                              {tx.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button className="text-cyan-400 hover:text-cyan-300 font-semibold text-xs">
                              Details
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 5: CUSTOMERS CRM
             ======================================================== */}
          {activeTab === 'customers' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {customers.map(c => (
                  <div 
                    key={c.id} 
                    onClick={() => setSelectedCustomer(c)}
                    className="p-5 rounded-2xl bg-[#0D121F] border border-[#1B2438] hover:border-cyan-500/50 shadow-xl space-y-3 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 font-bold text-sm flex items-center justify-center text-white">
                          {c.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-sm text-white">{c.name}</div>
                          <div className="text-[11px] text-slate-400">{c.company}</div>
                        </div>
                      </div>
                      <span className={\`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase \${
                        c.tier === 'Enterprise' ? 'bg-purple-950 text-purple-300 border border-purple-800' :
                        c.tier === 'Pro' ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' :
                        'bg-slate-800 text-slate-300'
                      }\`}>
                        {c.tier}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#1B2438] text-xs font-mono">
                      <div>
                        <span className="text-slate-500">Lifetime Spend:</span>
                        <div className="font-bold text-emerald-400">\${c.spend.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-slate-500">Member Since:</span>
                        <div className="text-slate-300">{c.joinDate}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 6: REPORTS
             ======================================================== */}
          {activeTab === 'reports' && (
            <div className="space-y-6">
              <div className="p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-white">Automated GAAP & P&L Statement Engine</h3>
                    <p className="text-xs text-slate-400">Generate verified financial audit dossiers and tax breakdown reports</p>
                  </div>
                  <button
                    onClick={handleGenerateReport}
                    disabled={reportGenerating}
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-600/20"
                  >
                    <Download className={\`w-4 h-4 \${reportGenerating ? 'animate-bounce' : ''}\`} />
                    <span>{reportGenerating ? 'Compiling Audit...' : 'Generate New PDF / CSV Master'}</span>
                  </button>
                </div>

                {reportSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-600/60 text-emerald-300 text-xs flex items-center gap-2 font-mono">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Master P&L Statement exported successfully (SHA-256 Verified).</span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  <div className="p-4 rounded-xl bg-[#090C14] border border-[#1B2438] space-y-2">
                    <div className="text-xs text-slate-400 font-mono">GROSS PROFIT MARGIN</div>
                    <div className="text-2xl font-bold font-mono text-white">82.4%</div>
                    <div className="text-[11px] text-emerald-400 font-mono">Industry Benchmark: 74%</div>
                  </div>
                  <div className="p-4 rounded-xl bg-[#090C14] border border-[#1B2438] space-y-2">
                    <div className="text-xs text-slate-400 font-mono">CUSTOMER ACQUISITION COST</div>
                    <div className="text-2xl font-bold font-mono text-white">\$142.00</div>
                    <div className="text-[11px] text-emerald-400 font-mono">LTV:CAC Ratio: 5.2x</div>
                  </div>
                  <div className="p-4 rounded-xl bg-[#090C14] border border-[#1B2438] space-y-2">
                    <div className="text-xs text-slate-400 font-mono">ESTIMATED TAX RESERVE</div>
                    <div className="text-2xl font-bold font-mono text-white">\$24,680</div>
                    <div className="text-[11px] text-cyan-400 font-mono">Q3 Pre-allocated</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              VIEW 7: SETTINGS
             ======================================================== */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="p-6 rounded-2xl bg-[#0D121F] border border-[#1B2438] shadow-xl space-y-5">
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Key className="w-4 h-4 text-cyan-400" />
                  <span>API Keys & Autonomous Webhooks</span>
                </h3>

                <div className="space-y-2 font-mono text-xs">
                  <label className="text-slate-400">PRODUCTION REST API KEY</label>
                  <div className="flex items-center gap-2">
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      readOnly
                      value="pk_live_pulse_994821a8f9001b6e4d2"
                      className="flex-1 px-3 py-2 rounded-xl bg-[#090C14] border border-[#1B2438] text-cyan-300 font-mono text-xs"
                    />
                    <button
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="p-2 rounded-xl bg-[#141C2E] hover:bg-[#1C2740] text-slate-300"
                    >
                      {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={handleCopyKey}
                      className="px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold flex items-center gap-1.5"
                    >
                      {copiedKey ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedKey ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Transaction Detail Modal */}
      {selectedTransaction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm font-sans">
          <div className="w-full max-w-md bg-[#0D121F] border border-[#1B2438] rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#1B2438] pb-3">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Transaction Details</span>
              </h3>
              <button 
                onClick={() => setSelectedTransaction(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">TX Identifier:</span>
                <span className="font-bold text-cyan-400">{selectedTransaction.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Customer Name:</span>
                <span className="text-white font-sans">{selectedTransaction.customer}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Customer Email:</span>
                <span className="text-slate-300">{selectedTransaction.email}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Settled Amount:</span>
                <span className="font-bold text-emerald-400 text-sm">\${selectedTransaction.amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#182133]">
                <span className="text-slate-400">Payment Channel:</span>
                <span className="text-slate-200">{selectedTransaction.method}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Status:</span>
                <span className="font-bold uppercase text-emerald-400">{selectedTransaction.status}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-[#1B2438]">
              <button
                onClick={() => setSelectedTransaction(null)}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
`,
    'package.json': `{
  "name": "pulse-analytics-saas",
  "version": "3.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  }
}`
  }
};
