"use client";

import { useEffect, useState } from "react";
import {
  Award, Check, Copy, ShieldCheck, TrendingUp, Users,
} from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { getFallbackTraders } from "@/services/copyTradingEngine";
import { FMT, MasterTrader } from "@/types";

/** Skeleton card shown while master trader profiles initialize. */
function SkeletonCard() {
  return (
    <div className="animate-pulse rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
      <div className="flex items-center gap-2.5">
        <div className="h-10 w-10 rounded-full bg-slate-800" />
        <div className="flex-1 space-y-2">
          <div className="h-3 w-28 rounded bg-slate-800" />
          <div className="h-2 w-40 rounded bg-slate-800/70" />
        </div>
        <div className="h-6 w-16 rounded-lg bg-slate-800" />
      </div>
      <div className="mt-3 grid grid-cols-4 gap-2">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="h-12 rounded-lg bg-slate-800/60" />
        ))}
      </div>
      <div className="mt-3 h-9 rounded-xl bg-slate-800/60" />
    </div>
  );
}

export default function CopyTradingTab() {
  const storeTraders = useTradingStore((s) => s.masterTraders);
  const toggleFollow = useTradingStore((s) => s.toggleFollowTrader);
  const setMasterTraders = useTradingStore((s) => s.setMasterTraders);
  const settings = useTradingStore((s) => s.settings);
  const setSettings = useTradingStore((s) => s.setSettings);
  const positions = useTradingStore((s) => s.positions);
  const [initializing, setInitializing] = useState(true);

  // Defensive: traders is ALWAYS a valid array, never null/undefined.
  const traders: MasterTrader[] = Array.isArray(storeTraders) ? storeTraders : [];

  // Self-heal + brief skeleton phase while the engine seeds profiles.
  useEffect(() => {
    const t = setTimeout(() => {
      const cur = useTradingStore.getState().masterTraders;
      if (!Array.isArray(cur) || cur.length === 0) {
        setMasterTraders(getFallbackTraders());
      }
      setInitializing(false);
    }, 600);
    return () => clearTimeout(t);
  }, [setMasterTraders]);

  const copyPositions = (positions || []).filter((p) => p.source === "COPY");
  const showSkeleton = initializing && traders.length === 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <Users className="h-5 w-5 text-purple-400" />
        <div>
          <h2 className="font-bold text-white">סורק Master Traders — Bybit & Binance</h2>
          <p className="text-[11px] text-slate-400">
            סריקת לוח מובילים רציפה • שכפול אוטומטי לחשבון הדמו כשביטחון העסקה חוצה 78%
          </p>
        </div>
        <label className="mr-auto flex cursor-pointer items-center gap-2 text-xs font-bold text-slate-300">
          שכפול אוטומטי
          <button
            onClick={() => setSettings({ copyTradingEnabled: !settings.copyTradingEnabled })}
            className={`relative h-6 w-11 rounded-full transition ${settings.copyTradingEnabled ? "bg-emerald-500" : "bg-slate-700"}`}
          >
            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${settings.copyTradingEnabled ? "right-0.5" : "right-5"}`} />
          </button>
        </label>
        <span className="num flex items-center gap-1.5 rounded-lg bg-purple-500/15 px-2.5 py-1 text-xs font-bold text-purple-400">
          <Copy className="h-3.5 w-3.5" />
          {copyPositions.length} עסקאות Copy פעילות
        </span>
      </div>

      {showSkeleton ? (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => <SkeletonCard key={i} />)}
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {(traders || []).map((t, rank) => (
            <div
              key={t.id ?? `trader_${rank}`}
              className={`rounded-2xl border p-4 ${t.followed ? "border-purple-500/40 bg-purple-500/[0.05]" : "border-slate-800 bg-slate-900/60"}`}
            >
              <div className="flex items-center gap-2.5">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-800 text-xl">
                  {t.avatar ?? "👤"}
                </span>
                <div>
                  <div className="flex items-center gap-1.5 text-sm font-bold text-white">
                    {t.name ?? "Trader"}
                    {rank === 0 && <Award className="h-3.5 w-3.5 text-yellow-400" />}
                    {rank === 1 && <Award className="h-3.5 w-3.5 text-slate-300" />}
                    {rank === 2 && <Award className="h-3.5 w-3.5 text-amber-600" />}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    <span className={t.exchange === "Bybit" ? "text-amber-400" : "text-yellow-300"}>{t.exchange ?? "Bybit"}</span>
                    {" · "}
                    <span className="num">{(t.followers ?? 0).toLocaleString()} מעתיקים · AUM ${((t.aum ?? 0) / 1e6).toFixed(1)}M</span>
                  </div>
                </div>
                <span className={`num mr-auto rounded-lg px-2 py-1 text-[10px] font-black ${(t.confidence ?? 0) >= 78 ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-800 text-slate-400"}`}>
                  ביטחון {(t.confidence ?? 0).toFixed(0)}%
                </span>
              </div>

              {/* strategy badge */}
              <div className="mt-2 flex items-center gap-1.5">
                <span className="flex items-center gap-1 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2 py-0.5 text-[9px] font-bold text-cyan-300">
                  <TrendingUp className="h-3 w-3" />
                  {t.strategy ?? "Multi-Strategy"}
                </span>
                {(t.drawdown ?? 99) < 8 && (
                  <span className="flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[9px] font-bold text-emerald-300">
                    <ShieldCheck className="h-3 w-3" /> סיכון נמוך
                  </span>
                )}
              </div>

              <div className="num mt-3 grid grid-cols-4 gap-2 text-center">
                <div className="rounded-lg bg-slate-950/60 py-1.5">
                  <div className="text-[9px] text-slate-500">Win Rate</div>
                  <div className={`text-xs font-bold ${(t.winRate ?? 0) >= 75 ? "text-emerald-400" : "text-slate-200"}`}>
                    {(t.winRate ?? 0).toFixed(1)}%
                  </div>
                </div>
                <div className="rounded-lg bg-slate-950/60 py-1.5">
                  <div className="text-[9px] text-slate-500">ROI 30D</div>
                  <div className="text-xs font-bold text-emerald-400">+{(t.roi30d ?? 0).toFixed(1)}%</div>
                </div>
                <div className="rounded-lg bg-slate-950/60 py-1.5">
                  <div className="text-[9px] text-slate-500">Max DD</div>
                  <div className="text-xs font-bold text-red-400">-{(t.drawdown ?? 0).toFixed(1)}%</div>
                </div>
                <div className="rounded-lg bg-slate-950/60 py-1.5">
                  <div className="text-[9px] text-slate-500">PF</div>
                  <div className="text-xs font-bold text-slate-200">{(t.profitFactor ?? 1).toFixed(2)}</div>
                </div>
              </div>

              <button
                onClick={() => toggleFollow(t.id)}
                className={`mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-black transition ${
                  t.followed
                    ? "bg-purple-500 text-white hover:bg-purple-600"
                    : "border border-slate-700 bg-slate-800/60 text-slate-200 hover:border-purple-500/50 hover:text-purple-300"
                }`}
              >
                {t.followed ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {t.followed ? "עוקב ומשכפל — לחץ לביטול" : "עקוב ושכפל"}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* hard fallback: should be unreachable, but guarantees no blank view */}
      {!showSkeleton && traders.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-10 text-center">
          <Users className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-2 text-sm font-bold text-slate-300">טוען פרופילי סוחרים…</p>
          <button
            onClick={() => setMasterTraders(getFallbackTraders())}
            className="mx-auto mt-3 rounded-xl border border-slate-700 bg-slate-800/60 px-4 py-2 text-xs font-bold text-slate-200 hover:text-purple-300"
          >
            טען לוח מובילים
          </button>
        </div>
      )}
    </div>
  );
}
