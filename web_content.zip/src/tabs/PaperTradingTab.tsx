"use client";

import { useState } from "react";
import { FlaskConical, ListOrdered, Wallet, X } from "lucide-react";
import { useTradingStore, getEquity } from "@/services/useTradingStore";
import { multiTimeframeEngine } from "@/services/multiTimeframeEngine";
import { FMT, OrderType, SymbolId, SYMBOLS, SYMBOL_META, TradeSide } from "@/types";

interface BacktestResult {
  trades: number; winRate: number; pnl: number; profitFactor: number; maxDD: number;
}

export default function PaperTradingTab() {
  const st = useTradingStore();
  const symbol = st.selectedSymbol;
  const price = st.prices[symbol];

  const [side, setSide] = useState<TradeSide>("LONG");
  const [type, setType] = useState<OrderType>("MARKET");
  const [amountUsd, setAmountUsd] = useState("500");
  const [leverage, setLeverage] = useState(st.settings.defaultLeverage);
  const [limitPrice, setLimitPrice] = useState("");
  const [stopPrice, setStopPrice] = useState("");
  const [trailPct, setTrailPct] = useState("1.0");
  const [bt, setBt] = useState<BacktestResult | null>(null);
  const [btRunning, setBtRunning] = useState(false);

  const equity = getEquity(st);

  const submit = () => {
    const usd = parseFloat(amountUsd) || 0;
    if (usd <= 0) return;
    const qty = (usd * leverage) / price;
    const snap = st.mtf[symbol];
    const atr = snap?.intervals["5m"]?.atr ?? price * 0.006;
    const dir = side === "LONG" ? 1 : -1;

    if (type === "MARKET") {
      st.openPosition({
        symbol, side, source: "MANUAL",
        strategyId: "manual", strategyName: "Market Order",
        entryPrice: price, qty, leverage,
        stopLoss: price - dir * atr * st.optimizer.atrSlMult,
        takeProfit: price + dir * atr * st.optimizer.atrTpMult,
        atrAtEntry: atr,
        trailingStop: type === ("TRAILING_STOP" as OrderType),
      });
    } else if (type === "TRAILING_STOP") {
      const trail = (parseFloat(trailPct) || 1) / 100;
      st.openPosition({
        symbol, side, source: "MANUAL",
        strategyId: "manual", strategyName: "Trailing Stop Order",
        entryPrice: price, qty, leverage,
        stopLoss: price * (1 - dir * trail),
        takeProfit: price + dir * atr * 4,
        atrAtEntry: atr, trailingStop: true,
      });
    } else {
      st.placePendingOrder({
        symbol, side, type, qty, leverage,
        limitPrice: parseFloat(limitPrice) || undefined,
        stopPrice: parseFloat(stopPrice) || undefined,
      });
      st.addLog("info", `📝 הוראת ${type} נרשמה: ${symbol} ${side} @ ${limitPrice || stopPrice}`);
    }
  };

  const runBacktest = () => {
    setBtRunning(true);
    setTimeout(() => {
      const candles = multiTimeframeEngine.getCandles(symbol, "15m");
      let pos: { side: 1 | -1; entry: number } | null = null;
      let pnl = 0, wins = 0, losses = 0, grossW = 0, grossL = 0, peak = 0, maxDD = 0;
      const closes = candles.map((c) => c.close);
      const ema = (arr: number[], p: number, i: number) => {
        const k = 2 / (p + 1);
        let e = arr[Math.max(0, i - 40)];
        for (let j = Math.max(1, i - 39); j <= i; j++) e = arr[j] * k + e * (1 - k);
        return e;
      };
      for (let i = 50; i < closes.length; i++) {
        const e9 = ema(closes, 9, i), e20 = ema(closes, 20, i);
        const e9p = ema(closes, 9, i - 1), e20p = ema(closes, 20, i - 1);
        if (!pos && e9p <= e20p && e9 > e20) pos = { side: 1, entry: closes[i] };
        else if (!pos && e9p >= e20p && e9 < e20) pos = { side: -1, entry: closes[i] };
        else if (pos && ((pos.side === 1 && e9 < e20) || (pos.side === -1 && e9 > e20))) {
          const r = (closes[i] - pos.entry) * pos.side * (500 / pos.entry) * leverage;
          pnl += r;
          if (r > 0) { wins++; grossW += r; } else { losses++; grossL -= r; }
          peak = Math.max(peak, pnl);
          maxDD = Math.max(maxDD, peak - pnl);
          pos = null;
        }
      }
      const t = wins + losses;
      setBt({
        trades: t,
        winRate: t ? (wins / t) * 100 : 0,
        pnl,
        profitFactor: grossL > 0 ? grossW / grossL : grossW > 0 ? 99 : 0,
        maxDD,
      });
      setBtRunning(false);
    }, 450);
  };

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {/* order form */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <h2 className="mb-3 flex items-center gap-2 font-bold text-white">
          📝 סימולטור מסחר דמו
          <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[9px] font-bold text-amber-400">PAPER</span>
        </h2>

        <div className="mb-3 flex gap-1 rounded-xl bg-slate-950/60 p-1">
          {SYMBOLS.map((s) => (
            <button key={s} onClick={() => st.setSelectedSymbol(s)}
              className={`flex-1 rounded-lg py-1.5 text-[11px] font-bold ${symbol === s ? "bg-slate-700 text-white" : "text-slate-400"}`}>
              {s.replace("USDT", "")}
            </button>
          ))}
        </div>

        <div className="num mb-3 text-center text-xl font-black" style={{ color: SYMBOL_META[symbol].color }}>
          ${FMT.price(price)}
        </div>

        <div className="mb-3 grid grid-cols-2 gap-2">
          <button onClick={() => setSide("LONG")}
            className={`rounded-xl py-2.5 text-sm font-black ${side === "LONG" ? "bg-emerald-500 text-slate-950" : "bg-slate-800 text-slate-400"}`}>
            לונג ▲
          </button>
          <button onClick={() => setSide("SHORT")}
            className={`rounded-xl py-2.5 text-sm font-black ${side === "SHORT" ? "bg-red-500 text-white" : "bg-slate-800 text-slate-400"}`}>
            שורט ▼
          </button>
        </div>

        <div className="mb-3 grid grid-cols-4 gap-1">
          {(["MARKET", "LIMIT", "STOP_LIMIT", "TRAILING_STOP"] as OrderType[]).map((t) => (
            <button key={t} onClick={() => setType(t)}
              className={`rounded-lg px-1 py-1.5 text-[9px] font-bold ${type === t ? "bg-cyan-500/20 text-cyan-300" : "bg-slate-800 text-slate-500"}`}>
              {t === "MARKET" ? "Market" : t === "LIMIT" ? "Limit" : t === "STOP_LIMIT" ? "Stop-Limit" : "Trailing"}
            </button>
          ))}
        </div>

        <label className="mb-1 block text-[10px] text-slate-400">סכום (USDT)</label>
        <input value={amountUsd} onChange={(e) => setAmountUsd(e.target.value)} dir="ltr"
          className="num mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-emerald-500" />

        <label className="mb-1 block text-[10px] text-slate-400">מינוף: <b className="num text-white">x{leverage}</b></label>
        <input type="range" min={1} max={50} value={leverage} onChange={(e) => setLeverage(+e.target.value)}
          className="mb-3 w-full accent-emerald-500" dir="ltr" />

        {type === "LIMIT" && (
          <>
            <label className="mb-1 block text-[10px] text-slate-400">מחיר Limit</label>
            <input value={limitPrice} onChange={(e) => setLimitPrice(e.target.value)} dir="ltr" placeholder={price.toFixed(2)}
              className="num mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-500" />
          </>
        )}
        {type === "STOP_LIMIT" && (
          <>
            <label className="mb-1 block text-[10px] text-slate-400">מחיר Stop (טריגר)</label>
            <input value={stopPrice} onChange={(e) => setStopPrice(e.target.value)} dir="ltr" placeholder={price.toFixed(2)}
              className="num mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-500" />
          </>
        )}
        {type === "TRAILING_STOP" && (
          <>
            <label className="mb-1 block text-[10px] text-slate-400">מרחק Trailing (%)</label>
            <input value={trailPct} onChange={(e) => setTrailPct(e.target.value)} dir="ltr"
              className="num mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-500" />
          </>
        )}

        <button onClick={submit}
          className={`w-full rounded-xl py-3 text-sm font-black transition active:scale-[0.98] ${side === "LONG" ? "bg-emerald-500 text-slate-950 hover:bg-emerald-400" : "bg-red-500 text-white hover:bg-red-400"}`}>
          {type === "MARKET" || type === "TRAILING_STOP" ? "בצע עכשיו" : "הצב הוראה"} — {side === "LONG" ? "קנייה" : "מכירה"} {symbol.replace("USDT", "")}
        </button>

        <div className="num mt-3 flex items-center justify-between rounded-xl bg-slate-950/60 px-3 py-2 text-[11px] text-slate-400">
          <span className="flex items-center gap-1"><Wallet className="h-3.5 w-3.5 text-emerald-400" /> Equity</span>
          <b className="text-white">${FMT.usd(equity)}</b>
        </div>
      </section>

      {/* pending orders + recent fills */}
      <section className="space-y-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <h3 className="mb-2 flex items-center gap-2 text-sm font-bold text-white">
            <ListOrdered className="h-4 w-4 text-cyan-400" /> הוראות ממתינות
          </h3>
          {st.pendingOrders.length === 0 ? (
            <p className="py-3 text-center text-xs text-slate-500">אין הוראות Limit/Stop ממתינות</p>
          ) : (
            <div className="space-y-1.5">
              {st.pendingOrders.map((o) => (
                <div key={o.id} className="flex items-center gap-2 rounded-lg bg-slate-950/60 px-2.5 py-2 text-[11px]">
                  <b className={o.side === "LONG" ? "text-emerald-400" : "text-red-400"}>{o.side === "LONG" ? "▲" : "▼"}</b>
                  <span className="font-bold text-white">{o.symbol.replace("USDT", "")}</span>
                  <span className="text-slate-400">{o.type}</span>
                  <span className="num text-slate-300">@{(o.limitPrice ?? o.stopPrice ?? 0).toFixed(2)}</span>
                  <button onClick={() => st.cancelPendingOrder(o.id)} className="mr-auto text-slate-500 hover:text-red-400">
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <h3 className="mb-2 text-sm font-bold text-white">⏱️ סגירות אחרונות</h3>
          <div className="max-h-64 space-y-1.5 overflow-y-auto">
            {st.closedTrades.slice(0, 12).map((t) => (
              <div key={t.id} className="flex items-center gap-2 rounded-lg bg-slate-950/60 px-2.5 py-1.5 text-[11px]">
                <span className="font-bold text-white">{t.symbol.replace("USDT", "")}</span>
                <span className="text-slate-500">{t.closeReason}</span>
                <b className={`num mr-auto ${t.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {t.pnl >= 0 ? "+" : ""}${t.pnl.toFixed(2)}
                </b>
              </div>
            ))}
            {st.closedTrades.length === 0 && <p className="py-3 text-center text-xs text-slate-500">עדיין אין עסקאות סגורות</p>}
          </div>
        </div>
      </section>

      {/* backtesting */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <h3 className="mb-2 flex items-center gap-2 text-sm font-bold text-white">
          <FlaskConical className="h-4 w-4 text-purple-400" /> Backtesting מהיר — EMA 9/20 Cross (15m)
        </h3>
        <p className="mb-3 text-[11px] text-slate-400">
          הרצת אסטרטגיית הצלבת ממוצעים על 120 הנרות האחרונים של {symbol.replace("USDT", "/USDT")} בהשקעה של $500 במינוף x{leverage}.
        </p>
        <button onClick={runBacktest} disabled={btRunning}
          className="w-full rounded-xl bg-purple-500 py-2.5 text-sm font-black text-white transition hover:bg-purple-400 disabled:opacity-50">
          {btRunning ? "מריץ סימולציה…" : "▶ הרץ Backtest"}
        </button>
        {bt && (
          <div className="mt-3 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-xl bg-slate-950/60 p-3">
              <div className="text-[10px] text-slate-500">עסקאות</div>
              <div className="num text-lg font-black text-white">{bt.trades}</div>
            </div>
            <div className="rounded-xl bg-slate-950/60 p-3">
              <div className="text-[10px] text-slate-500">Win Rate</div>
              <div className={`num text-lg font-black ${bt.winRate >= 50 ? "text-emerald-400" : "text-red-400"}`}>{bt.winRate.toFixed(0)}%</div>
            </div>
            <div className="rounded-xl bg-slate-950/60 p-3">
              <div className="text-[10px] text-slate-500">P&L כולל</div>
              <div className={`num text-lg font-black ${bt.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                {bt.pnl >= 0 ? "+" : ""}${bt.pnl.toFixed(1)}
              </div>
            </div>
            <div className="rounded-xl bg-slate-950/60 p-3">
              <div className="text-[10px] text-slate-500">Profit Factor</div>
              <div className="num text-lg font-black text-white">{bt.profitFactor.toFixed(2)}</div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
