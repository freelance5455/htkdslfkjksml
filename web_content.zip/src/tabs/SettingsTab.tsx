"use client";

import { useState } from "react";
import { Bell, KeyRound, RotateCcw, Satellite, Shield, SlidersHorizontal } from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { notificationService } from "@/services/notificationService";
import { getStoredPin, setStoredPin } from "@/components/PasscodeGatekeeper";
import { ExchangeId } from "@/types";

const FEEDS: (ExchangeId | "AUTO")[] = ["AUTO", "Bybit", "Binance", "OKX", "Kraken", "Coinbase", "KuCoin"];

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`relative h-6 w-11 shrink-0 rounded-full transition ${on ? "bg-emerald-500" : "bg-slate-700"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${on ? "right-0.5" : "right-5"}`} />
    </button>
  );
}

export default function SettingsTab() {
  const settings = useTradingStore((s) => s.settings);
  const setSettings = useTradingStore((s) => s.setSettings);
  const resetDemo = useTradingStore((s) => s.resetDemoAccount);
  const addLog = useTradingStore((s) => s.addLog);

  const [curPin, setCurPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [pinMsg, setPinMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const changePin = () => {
    if (curPin !== getStoredPin()) {
      setPinMsg({ ok: false, text: "הקוד הנוכחי שגוי" });
      return;
    }
    if (!/^\d{4}$/.test(newPin)) {
      setPinMsg({ ok: false, text: "הקוד החדש חייב להיות 4 ספרות" });
      return;
    }
    setStoredPin(newPin);
    setPinMsg({ ok: true, text: "✓ הקוד עודכן ונשמר במכשיר" });
    setCurPin(""); setNewPin("");
  };

  const toggleRealTrading = () => {
    if (!settings.realTradingUnlocked) {
      const ok = window.confirm(
        "⚠️ אזהרת בטיחות!\n\nהפעלת מסחר אמיתי תאפשר לבוט לבצע פקודות בכסף אמיתי.\nבגרסה זו הביצוע נשאר במצב דמו, אך ההגדרה תישמר.\n\nהאם אתה בטוח שברצונך להמשיך?",
      );
      if (!ok) return;
    }
    setSettings({ realTradingUnlocked: !settings.realTradingUnlocked });
    addLog("warn", settings.realTradingUnlocked ? "🔒 מסחר אמיתי ננעל מחדש" : "⚠️ נעילת מסחר אמיתי שוחררה (הביצוע עדיין בדמו)");
  };

  return (
    <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
      {/* security */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <h2 className="mb-3 flex items-center gap-2 font-bold text-white">
          <KeyRound className="h-5 w-5 text-emerald-400" /> אבטחה — שינוי קוד גישה
        </h2>
        <label className="mb-1 block text-[10px] text-slate-400">קוד נוכחי</label>
        <input type="password" inputMode="numeric" maxLength={4} value={curPin} onChange={(e) => setCurPin(e.target.value)} dir="ltr"
          className="num mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-emerald-500" />
        <label className="mb-1 block text-[10px] text-slate-400">קוד חדש (4 ספרות)</label>
        <input type="password" inputMode="numeric" maxLength={4} value={newPin} onChange={(e) => setNewPin(e.target.value)} dir="ltr"
          className="num mb-3 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-emerald-500" />
        <button onClick={changePin} className="w-full rounded-xl bg-emerald-500 py-2.5 text-sm font-black text-slate-950 hover:bg-emerald-400">
          עדכן קוד
        </button>
        {pinMsg && <p className={`mt-2 text-xs font-bold ${pinMsg.ok ? "text-emerald-400" : "text-red-400"}`}>{pinMsg.text}</p>}

        <div className="mt-4 flex items-center justify-between rounded-xl border border-red-500/30 bg-red-500/5 p-3">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-red-400">
              <Shield className="h-4 w-4" /> שחרור נעילת מסחר אמיתי
            </div>
            <p className="mt-0.5 text-[10px] text-slate-500">ברירת מחדל: נעול. הבוט מבצע דמו בלבד.</p>
          </div>
          <Toggle on={settings.realTradingUnlocked} onClick={toggleRealTrading} />
        </div>
      </section>

      {/* notifications + feed */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <h2 className="mb-3 flex items-center gap-2 font-bold text-white">
          <Bell className="h-5 w-5 text-cyan-400" /> התראות מערכת (OS Push)
        </h2>
        <div className="mb-3 flex items-center justify-between rounded-xl bg-slate-950/60 p-3">
          <div>
            <div className="text-xs font-bold text-slate-200">התראות מגש מערכת</div>
            <p className="text-[10px] text-slate-500">באנרים, רטט וצליל — גם כשהאפליקציה ברקע (Service Worker)</p>
          </div>
          <Toggle
            on={settings.notificationsEnabled}
            onClick={async () => {
              if (!settings.notificationsEnabled) await notificationService.requestPermission();
              else setSettings({ notificationsEnabled: false });
            }}
          />
        </div>
        <div className="mb-4 flex items-center justify-between rounded-xl bg-slate-950/60 p-3">
          <div className="text-xs font-bold text-slate-200">🔊 צלילי התראה</div>
          <Toggle on={settings.soundEnabled} onClick={() => setSettings({ soundEnabled: !settings.soundEnabled })} />
        </div>

        <h3 className="mb-2 flex items-center gap-2 text-sm font-bold text-white">
          <Satellite className="h-4 w-4 text-emerald-400" /> עדיפות פיד נתונים
        </h3>
        <div className="grid grid-cols-4 gap-1.5">
          {FEEDS.map((f) => (
            <button key={f} onClick={() => setSettings({ preferredFeed: f })}
              className={`rounded-lg px-1 py-2 text-[10px] font-bold ${settings.preferredFeed === f ? "bg-emerald-500 text-slate-950" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}>
              {f === "AUTO" ? "⚡ אוטו" : f}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[10px] text-slate-500">
          במצב אוטו המערכת מודדת לטנסי כל 2 שניות ומנתבת את הטיקים מהבורסה המהירה ביותר.
        </p>
      </section>

      {/* risk + reset */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <h2 className="mb-3 flex items-center gap-2 font-bold text-white">
          <SlidersHorizontal className="h-5 w-5 text-amber-400" /> ניהול סיכונים לבוט
        </h2>

        <label className="mb-1 block text-[10px] text-slate-400">סיכון קבוע לעסקה: <b className="num text-white">{settings.riskPct}%</b></label>
        <input type="range" min={0.5} max={5} step={0.25} value={settings.riskPct}
          onChange={(e) => setSettings({ riskPct: +e.target.value })} className="mb-3 w-full accent-amber-500" dir="ltr" />

        <label className="mb-1 block text-[10px] text-slate-400">מקסימום עסקאות במקביל: <b className="num text-white">{settings.maxConcurrent}</b></label>
        <input type="range" min={1} max={10} step={1} value={settings.maxConcurrent}
          onChange={(e) => setSettings({ maxConcurrent: +e.target.value })} className="mb-3 w-full accent-amber-500" dir="ltr" />

        <label className="mb-1 block text-[10px] text-slate-400">מעצור הפסד יומי: <b className="num text-white">{settings.dailyLossLimitPct}%</b></label>
        <input type="range" min={2} max={15} step={0.5} value={settings.dailyLossLimitPct}
          onChange={(e) => setSettings({ dailyLossLimitPct: +e.target.value })} className="mb-3 w-full accent-amber-500" dir="ltr" />

        <label className="mb-1 block text-[10px] text-slate-400">מינוף ברירת מחדל: <b className="num text-white">x{settings.defaultLeverage}</b></label>
        <input type="range" min={1} max={25} step={1} value={settings.defaultLeverage}
          onChange={(e) => setSettings({ defaultLeverage: +e.target.value })} className="mb-4 w-full accent-amber-500" dir="ltr" />

        <button
          onClick={() => { if (window.confirm("לאפס את חשבון הדמו ל-$10,000? כל הפוזיציות הפתוחות ייסגרו.")) resetDemo(); }}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/60 py-2.5 text-sm font-bold text-slate-200 hover:border-emerald-500/50 hover:text-emerald-400"
        >
          <RotateCcw className="h-4 w-4" /> איפוס יתרת דמו ל-$10,000
        </button>
      </section>
    </div>
  );
}
