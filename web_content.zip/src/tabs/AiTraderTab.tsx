"use client";

import {
  AlertTriangle, Bot, BrainCircuit, Expand, Gauge, ListTree, RefreshCcw, Siren,
} from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { ALL_INTERVALS, FMT, SYMBOLS, SYMBOL_META } from "@/types";

function scoreColor(score: number) {
  if (score > 0.45) return "bg-emerald-500 text-slate-950";
  if (score > 0.15) return "bg-emerald-500/40 text-emerald-200";
  if (score > -0.15) return "bg-slate-700 text-slate-300";
  if (score > -0.45) return "bg-red-500/40 text-red-200";
  return "bg-red-500 text-white";
}

export default function AiTraderTab() {
  const st = useTradingStore();
  const { isAutoBotActive, botStatus, riskHalted, regime, strategies, optimizer, logs, mtf, settings } = st;

  const badge = riskHalted
    ? { icon: "🔴", text: "מעצור סיכון פעיל | לחץ לאיפוס", cls: "border-red-500/50 bg-red-500/10 text-red-400" }
    : botStatus === "ACTIVE"
      ? { icon: "🟢", text: "בוט פעיל | מציב עסקת דמו בלייב", cls: "border-emerald-500/50 bg-emerald-500/10 text-emerald-400" }
      : botStatus === "SCANNING"
        ? { icon: "🟡", text: "סורק שוק בלייב | ממתין להצלבת אינדיקטורים", cls: "border-amber-500/50 bg-amber-500/10 text-amber-400" }
        : { icon: "⚪", text: "הבוט כבוי — הפעל מהכותרת העליונה", cls: "border-slate-700 bg-slate-800/50 text-slate-400" };

  const winPct = Math.min(100, optimizer.currentWinRate);

  return (
    <div className="grid gap-4 xl:grid-cols-3">
      {/* ─── Bot dashboard ─── */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 xl:col-span-1">
        <div className="mb-3 flex items-center gap-2">
          <Bot className="h-5 w-5 text-emerald-400" />
          <h2 className="font-bold text-white">דשבורד הבוט האוטונומי</h2>
          <span className="mr-auto rounded bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold text-amber-400">DEMO $10K</span>
        </div>

        <button
          onClick={() => riskHalted && st.resetRiskHalt()}
          className={`mb-3 flex w-full items-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-bold ${badge.cls} ${riskHalted ? "cursor-pointer hover:bg-red-500/20" : "cursor-default"}`}
        >
          <span className="text-base">{badge.icon}</span>
          {badge.text}
          {isAutoBotActive && !riskHalted && <span className="mr-auto h-2 w-2 rounded-full bg-current blink" />}
        </button>

        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="rounded-xl bg-slate-800/70 p-2.5">
            <div className="text-[10px] text-slate-400">סיכון קבוע לעסקה</div>
            <div className="num text-sm font-bold text-white">{settings.riskPct}%</div>
          </div>
          <div className="rounded-xl bg-slate-800/70 p-2.5">
            <div className="text-[10px] text-slate-400">מקס׳ עסקאות במקביל</div>
            <div className="num text-sm font-bold text-white">{st.positions.length} / {settings.maxConcurrent}</div>
          </div>
          <div className="rounded-xl bg-slate-800/70 p-2.5">
            <div className="text-[10px] text-slate-400">P&L יומי</div>
            <div className={`num text-sm font-bold ${st.dailyPnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
              {st.dailyPnl >= 0 ? "+" : ""}${FMT.usd(st.dailyPnl)}
            </div>
          </div>
          <div className="rounded-xl bg-slate-800/70 p-2.5">
            <div className="text-[10px] text-slate-400">מעצור הפסד יומי</div>
            <div className="num text-sm font-bold text-amber-400">{settings.dailyLossLimitPct}%</div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            onClick={st.resetRiskHalt}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/60 px-3 py-2 text-xs font-bold text-slate-200 hover:border-emerald-500/50 hover:text-emerald-400"
          >
            <RefreshCcw className="h-3.5 w-3.5" /> איפוס מעצור סיכון
          </button>
          <button
            onClick={st.emergencyStop}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs font-bold text-red-400 hover:bg-red-500/20"
          >
            <Siren className="h-3.5 w-3.5" /> עצירת חירום לבוט
          </button>
        </div>

        {/* Regime classifier */}
        <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/50 p-3">
          <div className="mb-1.5 flex items-center gap-1.5 text-xs font-bold text-cyan-400">
            <Gauge className="h-4 w-4" /> מסווג משטר שוק בזמן אמת
          </div>
          <div className="flex items-center gap-2">
            <span className={`rounded-lg px-2 py-1 text-xs font-black ${
              regime.regime === "TRENDING" ? "bg-emerald-500/20 text-emerald-400"
              : regime.regime === "BREAKOUT" ? "bg-purple-500/20 text-purple-400"
              : "bg-amber-500/20 text-amber-400"
            }`}>
              {regime.regime === "TRENDING" ? "📈 TRENDING" : regime.regime === "BREAKOUT" ? "💥 BREAKOUT" : "↔️ RANGING"}
            </span>
            <span className="text-[11px] text-slate-400">{regime.label}</span>
          </div>
          <div className="num mt-2 grid grid-cols-3 gap-2 text-center text-[10px] text-slate-400">
            <span>ADX: <b className="text-slate-200">{regime.adx.toFixed(0)}</b></span>
            <span>ATR: <b className="text-slate-200">{regime.atrPct.toFixed(2)}%</b></span>
            <span>ביטחון: <b className="text-slate-200">{regime.confidence.toFixed(0)}%</b></span>
          </div>
        </div>

        {/* Learning optimizer */}
        <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/50 p-3">
          <div className="mb-2 flex items-center gap-1.5 text-xs font-bold text-purple-400">
            <BrainCircuit className="h-4 w-4" /> מנוע למידה עצמית — אופטימיזציית Win-Rate
          </div>
          <div className="mb-1 flex justify-between text-[10px] text-slate-400">
            <span>Win-Rate נוכחי (20 אחרונות)</span>
            <span className="num">{optimizer.currentWinRate.toFixed(1)}% / יעד {optimizer.targetWinRate}%</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-700 ${winPct >= optimizer.targetWinRate ? "bg-emerald-500" : "bg-amber-500"}`}
              style={{ width: `${winPct}%` }}
            />
          </div>
          <div className="mt-2 text-[11px] text-emerald-400">🧠 אלגוריתם לומד ומכייל פרמטרים בלייב</div>
          <div className="num mt-2 grid grid-cols-2 gap-1.5 text-[10px] text-slate-400">
            <span>סף הצלבה: <b className="text-slate-200">{optimizer.confluenceThreshold}</b></span>
            <span>כיולים: <b className="text-slate-200">{optimizer.calibrations}</b></span>
            <span>SL: <b className="text-slate-200">ATR x{optimizer.atrSlMult}</b></span>
            <span>TP: <b className="text-slate-200">ATR x{optimizer.atrTpMult}</b></span>
          </div>
          <p className="mt-2 rounded-lg bg-slate-900 p-2 text-[10px] leading-relaxed text-slate-400">
            {optimizer.lastAction}
          </p>
        </div>
      </section>

      {/* ─── Strategy ranking + heatmap ─── */}
      <section className="space-y-4 xl:col-span-2">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="mb-3 flex items-center gap-2">
            <ListTree className="h-5 w-5 text-cyan-400" />
            <h2 className="font-bold text-white">דירוג אסטרטגיות דינמי (Expected Value)</h2>
            <span className="mr-auto text-[10px] text-slate-500">100% סמכות ביצוע לאסטרטגיה המובילה</span>
          </div>
          <div className="space-y-2">
            {strategies.map((s) => (
              <div
                key={s.id}
                className={`flex flex-wrap items-center gap-2 rounded-xl border px-3 py-2 ${
                  s.active
                    ? "border-emerald-500/50 bg-emerald-500/5"
                    : s.paused
                      ? "border-slate-800 bg-slate-950/40 opacity-50"
                      : "border-slate-800 bg-slate-950/40"
                }`}
              >
                <span className="text-lg">{s.icon}</span>
                <div className="min-w-32">
                  <div className="text-xs font-bold text-white">{s.nameHe}</div>
                  <div className="text-[9px] text-slate-500">{s.name}</div>
                </div>
                <div className="num mr-auto flex flex-wrap items-center gap-3 text-[10px] text-slate-400">
                  <span>WR: <b className={s.winRate >= 70 ? "text-emerald-400" : "text-amber-400"}>{s.winRate.toFixed(0)}%</b></span>
                  <span>PF: <b className="text-slate-200">{s.profitFactor.toFixed(2)}</b></span>
                  <span>Sharpe: <b className="text-slate-200">{s.sharpe.toFixed(1)}</b></span>
                  <span>Avg: <b className={s.avgPnl >= 0 ? "text-emerald-400" : "text-red-400"}>${s.avgPnl.toFixed(1)}</b></span>
                  <span>EV: <b className={s.ev > 0 ? "text-emerald-400" : "text-red-400"}>{s.paused ? "—" : `$${s.ev.toFixed(1)}`}</b></span>
                </div>
                {s.active && <span className="rounded bg-emerald-500 px-2 py-0.5 text-[9px] font-black text-slate-950">ACTIVE 100%</span>}
                {s.paused && <span className="rounded bg-slate-700 px-2 py-0.5 text-[9px] font-bold text-slate-300">⏸ מושהה במשטר זה</span>}
              </div>
            ))}
            {strategies.length === 0 && <div className="py-4 text-center text-xs text-slate-500">מאתחל מנוע אסטרטגיות…</div>}
          </div>
        </div>

        {/* MTF heatmap grid */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="mb-3 flex items-center gap-2">
            <h2 className="font-bold text-white">🧭 סורק הצלבות רב-טווחי — כל האינטרוולים 1m → 1w</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] border-separate border-spacing-1 text-center">
              <thead>
                <tr>
                  <th className="text-right text-[10px] text-slate-500">מטבע</th>
                  {ALL_INTERVALS.map((iv) => (
                    <th key={iv} className="num text-[9px] font-bold text-slate-400">{iv}</th>
                  ))}
                  <th className="text-[10px] text-slate-500">הצלבה</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {SYMBOLS.map((sym) => {
                  const snap = mtf[sym];
                  return (
                    <tr key={sym}>
                      <td className="text-right text-[11px] font-bold" style={{ color: SYMBOL_META[sym].color }}>
                        {sym.replace("USDT", "")}
                      </td>
                      {ALL_INTERVALS.map((iv) => {
                        const a = snap?.intervals[iv];
                        return (
                          <td key={iv}>
                            <div
                              className={`num rounded px-0.5 py-1 text-[9px] font-bold ${a ? scoreColor(a.score) : "bg-slate-800 text-slate-600"}`}
                              title={a ? `RSI ${a.rsi.toFixed(0)} | ADX ${a.adx.toFixed(0)}` : ""}
                            >
                              {a ? (a.score > 0 ? "▲" : a.score < 0 ? "▼" : "•") : "…"}
                            </div>
                          </td>
                        );
                      })}
                      <td>
                        <span className={`num rounded px-1.5 py-0.5 text-[10px] font-black ${
                          (snap?.confluence ?? 0) > 20 ? "bg-emerald-500/20 text-emerald-400"
                          : (snap?.confluence ?? 0) < -20 ? "bg-red-500/20 text-red-400"
                          : "bg-slate-800 text-slate-400"
                        }`}>
                          {snap?.confluence ?? 0}
                          {snap?.aligned && " ✓"}
                        </span>
                      </td>
                      <td>
                        <button
                          onClick={() => st.setChartModal({ symbol: sym })}
                          className="rounded bg-slate-800 p-1 text-slate-400 hover:text-emerald-400"
                          title="הרחב גרף"
                        >
                          <Expand className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-[10px] text-slate-500">
            ✓ = יישור Top-Down מלא (מיקרו 1m-15m ↔ מאקרו 4h-1w). הבוט פותח עסקה רק כשההצלבה חוצה את הסף הנלמד ({optimizer.confluenceThreshold}).
          </p>
        </div>

        {/* live log feed */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="mb-2 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white">יומן אופטימיזציה וסיגנלים חי</h2>
          </div>
          <div className="max-h-56 space-y-1 overflow-y-auto">
            {logs.slice(0, 30).map((l) => (
              <div key={l.id} className="slide-in flex gap-2 rounded-lg bg-slate-950/50 px-2.5 py-1.5 text-[11px]">
                <span className="num shrink-0 text-slate-600">
                  {new Date(l.ts).toLocaleTimeString("he-IL")}
                </span>
                <span className={
                  l.kind === "trade" ? "text-emerald-300"
                  : l.kind === "learn" ? "text-purple-300"
                  : l.kind === "warn" ? "text-red-300"
                  : l.kind === "signal" ? "text-cyan-300"
                  : "text-slate-300"
                }>
                  {l.text}
                </span>
              </div>
            ))}
            {logs.length === 0 && <div className="py-4 text-center text-xs text-slate-500">הפעל את הבוט כדי לראות פעילות חיה…</div>}
          </div>
        </div>
      </section>
    </div>
  );
}
