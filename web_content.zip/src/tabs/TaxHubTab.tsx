"use client";

import { useState } from "react";
import { Download, Receipt, Trash2 } from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { FMT } from "@/types";

const USD_ILS = 3.65;

export default function TaxHubTab() {
  const positions = useTradingStore((s) => s.positions);
  const rows = useTradingStore((s) => s.closedTrades);
  const clearClosedTrades = useTradingStore((s) => s.clearClosedTrades);
  const [mode, setMode] = useState<"day" | "capital">("capital");
  const [marginalRate, setMarginalRate] = useState(35);

  const realized = rows.reduce((a, r) => a + r.pnl, 0);
  const unrealized = positions.reduce((a, p) => a + p.pnl, 0);
  const gains = rows.filter((r) => r.pnl > 0).reduce((a, r) => a + r.pnl, 0);
  const losses = rows.filter((r) => r.pnl < 0).reduce((a, r) => a + r.pnl, 0);
  const netTaxableUsd = Math.max(0, realized);
  const netTaxableIls = netTaxableUsd * USD_ILS;
  const rate = mode === "capital" ? 25 : marginalRate;
  const taxIls = netTaxableIls * (rate / 100);

  const exportCsv = () => {
    const header = "Form909,TaxYear," + new Date().getFullYear() + "\nSymbol,Side,Source,Qty,EntryUSD,ExitUSD,PnL_USD,PnL_ILS,Fees_USD,OpenedAt,ClosedAt\n";
    const body = rows
      .map((r) =>
        [r.symbol, r.side, r.source, r.qty.toFixed(6), r.entryPrice.toFixed(2), r.exitPrice.toFixed(2),
         r.pnl.toFixed(2), (r.pnl * USD_ILS).toFixed(2), r.fees.toFixed(2),
         new Date(r.openedAt).toISOString(), new Date(r.closedAt).toISOString()].join(","),
      )
      .join("\n");
    const blob = new Blob(["\uFEFF" + header + body], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `form909_crypto_${new Date().getFullYear()}.csv`;
    a.click();
  };

  const clearLedger = () => {
    if (window.confirm("לנקות את כל יומן העסקאות? הנתונים יימחקו מאחסון הדפדפן.")) {
      clearClosedTrades();
    }
  };

  return (
    <div className="space-y-4">
      {/* summary */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: "P&L ממומש (יומן מקומי)", v: realized, sign: true },
          { label: "P&L לא ממומש (פתוח)", v: unrealized, sign: true },
          { label: "סך רווחים", v: gains, sign: false, color: "text-emerald-400" },
          { label: "סך הפסדים (קיזוז)", v: losses, sign: false, color: "text-red-400" },
        ].map((c) => (
          <div key={c.label} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="text-[10px] text-slate-400">{c.label}</div>
            <div className={`num mt-1 text-xl font-black ${c.color ?? (c.v >= 0 ? "text-emerald-400" : "text-red-400")}`}>
              {c.v >= 0 && c.sign ? "+" : ""}${FMT.usd(c.v)}
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* tax calculator */}
        <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <h2 className="mb-3 flex items-center gap-2 font-bold text-white">
            <Receipt className="h-5 w-5 text-amber-400" /> מחשבון מס ישראלי
          </h2>
          <div className="mb-3 grid grid-cols-2 gap-2">
            <button onClick={() => setMode("capital")}
              className={`rounded-xl px-2 py-2.5 text-xs font-bold ${mode === "capital" ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-400"}`}>
              רווח הון (25%)
            </button>
            <button onClick={() => setMode("day")}
              className={`rounded-xl px-2 py-2.5 text-xs font-bold ${mode === "day" ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-400"}`}>
              מסחר יומי (שולי)
            </button>
          </div>
          {mode === "day" && (
            <div className="mb-3">
              <label className="mb-1 block text-[10px] text-slate-400">מדרגת מס שולית: <b className="num text-white">{marginalRate}%</b></label>
              <input type="range" min={10} max={50} step={1} value={marginalRate}
                onChange={(e) => setMarginalRate(+e.target.value)} className="w-full accent-amber-500" dir="ltr" />
            </div>
          )}
          <div className="num space-y-2 rounded-xl bg-slate-950/60 p-3 text-xs">
            <div className="flex justify-between text-slate-400"><span>רווח חייב (USD)</span><b className="text-white">${FMT.usd(netTaxableUsd)}</b></div>
            <div className="flex justify-between text-slate-400"><span>רווח חייב (₪, שער {USD_ILS})</span><b className="text-white">₪{FMT.usd(netTaxableIls)}</b></div>
            <div className="flex justify-between text-slate-400"><span>שיעור מס</span><b className="text-amber-400">{rate}%</b></div>
            <div className="flex justify-between border-t border-slate-800 pt-2 text-sm"><span className="text-slate-300">מס משוער לתשלום</span><b className="text-amber-400">₪{FMT.usd(taxIls)}</b></div>
          </div>
          <p className="mt-2 text-[9px] leading-relaxed text-slate-500">
            * הערכה בלבד — מסחר יומי תדיר עשוי להיחשב כהכנסה פירותית במס שולי. התייעץ עם רו״ח. הפסדים ניתנים לקיזוז כנגד רווחי הון.
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button onClick={exportCsv}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500 px-3 py-2 text-xs font-black text-slate-950 hover:bg-emerald-400">
              <Download className="h-3.5 w-3.5" /> ייצוא טופס 909
            </button>
            <button onClick={clearLedger}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs font-bold text-red-400 hover:bg-red-500/20">
              <Trash2 className="h-3.5 w-3.5" /> נקה יומן
            </button>
          </div>
        </section>

        {/* ledger */}
        <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 lg:col-span-2">
          <div className="mb-2 flex items-center gap-2">
            <h2 className="font-bold text-white">📒 יומן עסקאות (localStorage)</h2>
            <span className="num rounded bg-slate-800 px-2 py-0.5 text-[10px] text-slate-400">{rows.length} רשומות</span>
            <span className="mr-auto rounded bg-emerald-500/10 px-2 py-0.5 text-[9px] font-bold text-emerald-400">
              💾 נשמר אוטומטית בדפדפן — ללא שרת
            </span>
          </div>
          <div className="max-h-[420px] overflow-y-auto">
            <table className="w-full text-right text-[11px]">
              <thead className="sticky top-0 bg-slate-900 text-[9px] uppercase text-slate-500">
                <tr>
                  <th className="py-1.5">מטבע</th><th>כיוון</th><th>מקור</th>
                  <th>כניסה</th><th>יציאה</th><th>P&L</th><th>סיבה</th><th>נסגר</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t border-slate-800/60">
                    <td className="py-1.5 font-bold text-white">{r.symbol.replace("USDT", "")}</td>
                    <td className={r.side === "LONG" ? "text-emerald-400" : "text-red-400"}>{r.side === "LONG" ? "לונג" : "שורט"}</td>
                    <td className="text-slate-400">{r.source === "BOT" ? "🤖" : r.source === "COPY" ? "👥" : "✍️"}</td>
                    <td className="num text-slate-300">${FMT.price(r.entryPrice)}</td>
                    <td className="num text-slate-300">${FMT.price(r.exitPrice)}</td>
                    <td className={`num font-bold ${r.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                      {r.pnl >= 0 ? "+" : ""}${r.pnl.toFixed(2)}
                    </td>
                    <td className="text-slate-500">{r.closeReason}</td>
                    <td className="num text-slate-500">{new Date(r.closedAt).toLocaleTimeString("he-IL")}</td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr><td colSpan={8} className="py-6 text-center text-slate-500">היומן ריק — עסקאות סגורות יישמרו כאן אוטומטית (localStorage)</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
