"use client";

import { useState } from "react";
import { Expand } from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { multiTimeframeEngine } from "@/services/multiTimeframeEngine";
import CandleChart from "@/components/CandleChart";
import { FMT, Interval, SYMBOLS, SYMBOL_META } from "@/types";

const QUICK_INTERVALS: Interval[] = ["1m", "5m", "15m", "1h", "4h", "1d"];

export default function TerminalTab() {
  const st = useTradingStore();
  const symbol = st.selectedSymbol;
  const price = st.prices[symbol];
  const [interval, setIntervalV] = useState<Interval>("1m");
  const candles = multiTimeframeEngine.getCandles(symbol, interval);
  const { bids, asks } = st.orderBook;
  const maxSize = Math.max(...bids.map((b) => b.size), ...asks.map((a) => a.size), 1);

  return (
    <div className="grid gap-4 xl:grid-cols-4">
      {/* chart */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 xl:col-span-3">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          <div className="flex gap-1 rounded-xl bg-slate-950/60 p-1">
            {SYMBOLS.map((s) => (
              <button key={s} onClick={() => st.setSelectedSymbol(s)}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-bold ${symbol === s ? "bg-slate-700 text-white" : "text-slate-400"}`}>
                {s.replace("USDT", "")}
              </button>
            ))}
          </div>
          <span className="num text-lg font-black" style={{ color: SYMBOL_META[symbol].color }}>${FMT.price(price)}</span>
          <span className={`num text-xs font-bold ${st.change24h[symbol] >= 0 ? "text-emerald-400" : "text-red-400"}`}>
            {FMT.pct(st.change24h[symbol])}
          </span>
          <div className="mr-auto flex gap-1">
            {QUICK_INTERVALS.map((iv) => (
              <button key={iv} onClick={() => setIntervalV(iv)}
                className={`rounded px-2 py-1 text-[10px] font-bold ${interval === iv ? "bg-emerald-500 text-slate-950" : "bg-slate-800 text-slate-400"}`}>
                {iv}
              </button>
            ))}
            <button onClick={() => st.setChartModal({ symbol })} className="rounded bg-slate-800 px-2 py-1 text-slate-400 hover:text-emerald-400">
              <Expand className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
        <CandleChart candles={candles} height={360} livePrice={price} />
        <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-500">
          <span className={`h-1.5 w-1.5 rounded-full ${st.feedMode === "LIVE" ? "bg-emerald-400 blink" : "bg-amber-400 blink"}`} />
          פיד פעיל: {st.bestFeed} · {st.feedMode === "LIVE" ? "WebSocket תת-שנייתי" : "סימולציית שוק (אין רשת חיצונית)"}
        </div>
      </section>

      {/* order book + tape */}
      <section className="space-y-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
          <h3 className="mb-2 text-xs font-bold text-white">📚 ספר פקודות — {symbol.replace("USDT", "/USDT")}</h3>
          <div dir="ltr" className="space-y-px">
            {[...asks].reverse().slice(0, 8).map((a, i) => (
              <div key={`a${i}`} className="relative flex justify-between px-2 py-0.5 text-[10px]">
                <div className="absolute inset-y-0 right-0 bg-red-500/10" style={{ width: `${(a.size / maxSize) * 100}%` }} />
                <span className="num relative text-red-400">{a.price.toFixed(2)}</span>
                <span className="num relative text-slate-400">{a.size.toFixed(3)}</span>
              </div>
            ))}
            <div className="num border-y border-slate-800 py-1 text-center text-sm font-black text-white">
              {FMT.price(price)}
            </div>
            {bids.slice(0, 8).map((b, i) => (
              <div key={`b${i}`} className="relative flex justify-between px-2 py-0.5 text-[10px]">
                <div className="absolute inset-y-0 right-0 bg-emerald-500/10" style={{ width: `${(b.size / maxSize) * 100}%` }} />
                <span className="num relative text-emerald-400">{b.price.toFixed(2)}</span>
                <span className="num relative text-slate-400">{b.size.toFixed(3)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
          <h3 className="mb-2 text-xs font-bold text-white">🎞️ סרט עסקאות חי</h3>
          <div className="max-h-64 space-y-px overflow-y-auto" dir="ltr">
            {st.tape.filter((t) => t.symbol === symbol).slice(0, 25).map((t, i) => (
              <div key={`${t.ts}_${i}`} className="flex justify-between rounded px-2 py-0.5 text-[10px]">
                <span className={`num font-bold ${t.side === "buy" ? "text-emerald-400" : "text-red-400"}`}>
                  {t.side === "buy" ? "▲" : "▼"} {t.price.toFixed(2)}
                </span>
                <span className="num text-slate-500">{t.qty.toFixed(4)}</span>
                <span className="num text-slate-600">{new Date(t.ts).toLocaleTimeString("en-GB")}</span>
              </div>
            ))}
            {st.tape.length === 0 && <p className="py-3 text-center text-[10px] text-slate-500">ממתין לטיקים…</p>}
          </div>
        </div>

        {/* feed latency panel */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
          <h3 className="mb-2 text-xs font-bold text-white">🛰️ חיווי לטנסי רב-בורסתי</h3>
          <div className="space-y-1">
            {st.feeds.map((f) => (
              <div key={f.exchange} className="flex items-center gap-2 text-[10px]">
                <span className={`h-1.5 w-1.5 rounded-full ${f.connected && f.latencyMs !== null ? "bg-emerald-400" : "bg-slate-600"}`} />
                <span className={`font-bold ${f.exchange === st.bestFeed ? "text-emerald-400" : "text-slate-300"}`}>
                  {f.exchange} {f.exchange === st.bestFeed && "⚡"}
                </span>
                <span className="num mr-auto text-slate-400">
                  {f.latencyMs !== null ? `${f.latencyMs}ms` : "offline"} · {f.msgCount.toLocaleString()} msgs
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
