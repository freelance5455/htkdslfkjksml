"use client";

import { useEffect, useState } from "react";
import { useTradingStore } from "@/services/useTradingStore";
import { FMT, HeatmapCoin } from "@/types";

const COINS: Omit<HeatmapCoin, "change24h">[] = [
  { symbol: "BTC", name: "Bitcoin", marketCap: 1920, price: 97400 },
  { symbol: "ETH", name: "Ethereum", marketCap: 411, price: 3420 },
  { symbol: "BNB", name: "BNB", marketCap: 96, price: 660 },
  { symbol: "SOL", name: "Solana", marketCap: 94, price: 198 },
  { symbol: "XRP", name: "XRP", marketCap: 128, price: 2.25 },
  { symbol: "DOGE", name: "Dogecoin", marketCap: 48, price: 0.32 },
  { symbol: "ADA", name: "Cardano", marketCap: 32, price: 0.91 },
  { symbol: "TRX", name: "Tron", marketCap: 26, price: 0.3 },
  { symbol: "AVAX", name: "Avalanche", marketCap: 16, price: 38 },
  { symbol: "LINK", name: "Chainlink", marketCap: 14, price: 22 },
  { symbol: "TON", name: "Toncoin", marketCap: 13, price: 5.2 },
  { symbol: "DOT", name: "Polkadot", marketCap: 10, price: 6.8 },
  { symbol: "MATIC", name: "Polygon", marketCap: 5, price: 0.52 },
  { symbol: "LTC", name: "Litecoin", marketCap: 8, price: 105 },
  { symbol: "NEAR", name: "NEAR", marketCap: 6, price: 5.1 },
  { symbol: "APT", name: "Aptos", marketCap: 5, price: 9.2 },
  { symbol: "ARB", name: "Arbitrum", marketCap: 3, price: 0.78 },
  { symbol: "OP", name: "Optimism", marketCap: 2.5, price: 1.85 },
];

export default function HeatmapTab() {
  const change24h = useTradingStore((s) => s.change24h);
  const [coins, setCoins] = useState<HeatmapCoin[]>(() =>
    COINS.map((c, i) => ({ ...c, change24h: Math.sin(i * 2.7) * 4 })),
  );
  const [fearGreed, setFearGreed] = useState(54);

  useEffect(() => {
    const t = setInterval(() => {
      setCoins((prev) =>
        prev.map((c) => {
          const live =
            c.symbol === "BTC" ? change24h.BTCUSDT
            : c.symbol === "ETH" ? change24h.ETHUSDT
            : c.symbol === "SOL" ? change24h.SOLUSDT
            : c.symbol === "BNB" ? change24h.BNBUSDT
            : null;
          return {
            ...c,
            change24h: live ?? Math.max(-12, Math.min(12, c.change24h + (Math.random() - 0.5) * 0.4)),
          };
        }),
      );
      setFearGreed((f) => {
        const avg = (change24h.BTCUSDT + change24h.ETHUSDT) / 2;
        return Math.round(Math.max(5, Math.min(95, f + avg * 0.1 + (Math.random() - 0.5) * 2)));
      });
    }, 2500);
    return () => clearInterval(t);
  }, [change24h]);

  const total = coins.reduce((a, c) => a + c.marketCap, 0);
  const fgLabel =
    fearGreed >= 75 ? "תאוות בצע קיצונית" : fearGreed >= 55 ? "תאוות בצע" :
    fearGreed >= 45 ? "ניטרלי" : fearGreed >= 25 ? "פחד" : "פחד קיצוני";
  const fgColor = fearGreed >= 55 ? "#22c55e" : fearGreed >= 45 ? "#f59e0b" : "#ef4444";

  return (
    <div className="grid gap-4 lg:grid-cols-4">
      <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 lg:col-span-3">
        <h2 className="mb-3 font-bold text-white">🔥 מפת חום קריפטו — לפי שווי שוק</h2>
        <div className="flex flex-wrap gap-1.5">
          {coins.map((c) => {
            const frac = c.marketCap / total;
            const size = Math.max(9, Math.sqrt(frac) * 62);
            const up = c.change24h >= 0;
            const intensity = Math.min(1, Math.abs(c.change24h) / 6);
            return (
              <div
                key={c.symbol}
                className="flex flex-col items-center justify-center rounded-xl p-2 text-center transition-transform hover:scale-105"
                style={{
                  width: `${size}%`,
                  minHeight: 64 + frac * 320,
                  flexGrow: frac * 100,
                  backgroundColor: up
                    ? `rgba(34, 197, 94, ${0.12 + intensity * 0.5})`
                    : `rgba(239, 68, 68, ${0.12 + intensity * 0.5})`,
                  border: `1px solid ${up ? "rgba(34,197,94,0.35)" : "rgba(239,68,68,0.35)"}`,
                }}
              >
                <div className="text-sm font-black text-white">{c.symbol}</div>
                <div className={`num text-xs font-bold ${up ? "text-emerald-300" : "text-red-300"}`}>
                  {FMT.pct(c.change24h)}
                </div>
                <div className="num text-[9px] text-slate-300/70">${c.marketCap.toFixed(0)}B</div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="space-y-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-center">
          <h3 className="mb-3 text-sm font-bold text-white">😨 מדד פחד ותאוות בצע</h3>
          <div className="relative mx-auto h-36 w-36">
            <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
              <circle cx="50" cy="50" r="42" fill="none" stroke="#1e293b" strokeWidth="10" />
              <circle
                cx="50" cy="50" r="42" fill="none"
                stroke={fgColor} strokeWidth="10" strokeLinecap="round"
                strokeDasharray={`${(fearGreed / 100) * 264} 264`}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="num text-3xl font-black" style={{ color: fgColor }}>{fearGreed}</span>
              <span className="text-[10px] text-slate-400">/ 100</span>
            </div>
          </div>
          <div className="mt-2 text-sm font-bold" style={{ color: fgColor }}>{fgLabel}</div>
          <p className="mt-1 text-[10px] text-slate-500">מחושב ממומנטום שוק חי + תנודתיות</p>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
          <h3 className="mb-2 text-sm font-bold text-white">📊 רוחב שוק</h3>
          {(() => {
            const ups = coins.filter((c) => c.change24h >= 0).length;
            const pct = (ups / coins.length) * 100;
            return (
              <>
                <div className="flex justify-between text-[11px]">
                  <span className="text-emerald-400">{ups} עולים</span>
                  <span className="text-red-400">{coins.length - ups} יורדים</span>
                </div>
                <div className="mt-1.5 flex h-2.5 overflow-hidden rounded-full bg-slate-800" dir="ltr">
                  <div className="bg-emerald-500 transition-all duration-700" style={{ width: `${pct}%` }} />
                  <div className="bg-red-500 transition-all duration-700" style={{ width: `${100 - pct}%` }} />
                </div>
              </>
            );
          })()}
        </div>
      </section>
    </div>
  );
}
