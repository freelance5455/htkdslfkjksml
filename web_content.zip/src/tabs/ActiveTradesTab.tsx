"use client";

import { useState } from "react";
import { Pencil, Scissors, Siren, TrendingDown, TrendingUp, X } from "lucide-react";
import { useTradingStore } from "@/services/useTradingStore";
import { FMT, Position, SYMBOL_META } from "@/types";

function PositionCard({ pos }: { pos: Position }) {
  const closePosition = useTradingStore((s) => s.closePosition);
  const updateRisk = useTradingStore((s) => s.updatePositionRisk);
  const [editing, setEditing] = useState(false);
  const [sl, setSl] = useState(pos.stopLoss.toFixed(2));
  const [tp, setTp] = useState(pos.takeProfit.toFixed(2));

  const up = pos.pnl >= 0;
  const long = pos.side === "LONG";

  return (
    <div className={`slide-in rounded-2xl border p-4 ${up ? "border-emerald-500/30 bg-emerald-500/[0.04]" : "border-red-500/30 bg-red-500/[0.04]"}`}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-black" style={{ color: SYMBOL_META[pos.symbol].color }}>
          {pos.symbol.replace("USDT", "/USDT")}
        </span>
        <span className={`flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-black ${long ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
          {long ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {long ? "לונג" : "שורט"} x{pos.leverage}
        </span>
        {pos.source === "BOT" && <span className="rounded bg-cyan-500/15 px-1.5 py-0.5 text-[10px] font-bold text-cyan-400">🤖 עסקת בוט</span>}
        {pos.source === "COPY" && (
          <span className="rounded bg-purple-500/15 px-1.5 py-0.5 text-[10px] font-bold text-purple-400">
            👥 עסקת Copy-Trading{pos.masterTrader ? ` · ${pos.masterTrader}` : ""}
          </span>
        )}
        {pos.source === "MANUAL" && <span className="rounded bg-slate-700 px-1.5 py-0.5 text-[10px] font-bold text-slate-300">✍️ ידני</span>}
        {pos.tp1Hit && <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-bold text-emerald-400">TP1 ✓ | SL→BE</span>}
        <span className="num mr-auto text-[10px] text-slate-500">
          {new Date(pos.openedAt).toLocaleTimeString("he-IL")}
        </span>
      </div>

      {/* flashing P&L */}
      <div className="mt-3 flex flex-wrap items-end gap-4">
        <div>
          <div className="text-[10px] text-slate-400">P&L צף</div>
          <div
            key={Math.round(pos.pnl * 10)}
            className={`num text-2xl font-black ${up ? "flash-up text-emerald-400" : "flash-down text-red-400"}`}
          >
            {up ? "+" : ""}${FMT.usd(pos.pnl)}
          </div>
          <div className={`num text-xs font-bold ${up ? "text-emerald-500" : "text-red-500"}`}>{FMT.pct(pos.pnlPct)}</div>
        </div>
        <div className="num grid grid-cols-2 gap-x-5 gap-y-1 text-[11px] text-slate-400 sm:grid-cols-4">
          <span>כניסה: <b className="text-slate-200">${FMT.price(pos.entryPrice)}</b></span>
          <span>שוק: <b className="text-slate-200">${FMT.price(pos.markPrice)}</b></span>
          <span>כמות: <b className="text-slate-200">{pos.qty.toFixed(4)}</b></span>
          <span>מרג׳ין: <b className="text-slate-200">${FMT.usd(pos.margin)}</b></span>
          <span className="text-red-400">SL: <b>${FMT.price(pos.stopLoss)}</b></span>
          <span className="text-emerald-400">TP: <b>${FMT.price(pos.takeProfit)}</b></span>
          <span>אסטרטגיה: <b className="text-slate-300">{pos.strategyName}</b></span>
          <span>ATR: <b className="text-slate-300">${pos.atrAtEntry.toFixed(2)}</b></span>
        </div>
      </div>

      {editing && (
        <div className="mt-3 flex flex-wrap items-center gap-2 rounded-xl bg-slate-950/60 p-2">
          <label className="text-[10px] text-red-400">SL:</label>
          <input value={sl} onChange={(e) => setSl(e.target.value)} dir="ltr"
            className="num w-28 rounded-lg border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-white outline-none focus:border-red-500" />
          <label className="text-[10px] text-emerald-400">TP:</label>
          <input value={tp} onChange={(e) => setTp(e.target.value)} dir="ltr"
            className="num w-28 rounded-lg border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-white outline-none focus:border-emerald-500" />
          <button
            onClick={() => { updateRisk(pos.id, parseFloat(sl) || pos.stopLoss, parseFloat(tp) || pos.takeProfit); setEditing(false); }}
            className="rounded-lg bg-emerald-500 px-3 py-1 text-xs font-bold text-slate-950"
          >
            שמור
          </button>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-2">
        <button onClick={() => setEditing(!editing)}
          className="flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800/60 px-2.5 py-1.5 text-[11px] font-bold text-slate-300 hover:text-white">
          <Pencil className="h-3 w-3" /> עריכת SL/TP
        </button>
        <button onClick={() => closePosition(pos.id, pos.markPrice, "סגירה חלקית 50%", 0.5)}
          className="flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800/60 px-2.5 py-1.5 text-[11px] font-bold text-amber-400 hover:bg-amber-500/10">
          <Scissors className="h-3 w-3" /> סגור 50%
        </button>
        <button onClick={() => closePosition(pos.id, pos.markPrice, "סגירה ידנית")}
          className="flex items-center gap-1 rounded-lg border border-red-500/40 bg-red-500/10 px-2.5 py-1.5 text-[11px] font-bold text-red-400 hover:bg-red-500/20">
          <X className="h-3 w-3" /> סגור עסקה
        </button>
      </div>
    </div>
  );
}

export default function ActiveTradesTab() {
  const positions = useTradingStore((s) => s.positions);
  const emergencyStop = useTradingStore((s) => s.emergencyStop);
  const totalPnl = positions.reduce((a, p) => a + p.pnl, 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
        <h2 className="font-bold text-white">📊 עסקאות פעילות — ניטור בזמן אמת</h2>
        <span className="num rounded-lg bg-slate-800 px-2.5 py-1 text-xs text-slate-300">{positions.length} פוזיציות</span>
        <span className={`num rounded-lg px-2.5 py-1 text-xs font-bold ${totalPnl >= 0 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
          P&L מצטבר: {totalPnl >= 0 ? "+" : ""}${FMT.usd(totalPnl)}
        </span>
        <button
          onClick={emergencyStop}
          className="mr-auto flex items-center gap-1.5 rounded-xl border border-red-500/50 bg-red-500/10 px-3 py-2 text-xs font-black text-red-400 hover:bg-red-500/20"
        >
          <Siren className="h-4 w-4" /> עצירת חירום — סגור הכל
        </button>
      </div>

      {positions.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-10 text-center">
          <div className="text-3xl">🛰️</div>
          <p className="mt-2 text-sm font-bold text-slate-300">אין עסקאות פתוחות כרגע</p>
          <p className="mt-1 text-xs text-slate-500">
            הפעל את הבוט האוטונומי בכותרת העליונה — עסקת דמו ראשונה תיפתח תוך שניות, או פתח עסקה ידנית בטאב מסחר דמו.
          </p>
        </div>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {positions.map((p) => <PositionCard key={p.id} pos={p} />)}
        </div>
      )}
    </div>
  );
}
