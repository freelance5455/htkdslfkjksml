import { TACTIC_OPTIONS, getTactics, setTactic, tacticsSummary, zoneColumns } from './tactics.js';

export function initTacticsUI({ getState, onChange }) {
  const boardHost = document.querySelector('#tacticsBoard');
  const options = document.querySelector('#tacticsOptions');
  const summary = document.querySelector('#tacticsSummary');
  if (!boardHost || !options) return { refresh() {} };
  const paint = () => {
    const state = getState();
    const tactics = getTactics(state);
    const zone = zoneColumns(tactics.formation);
    let cells = '';
    for (let r = 0; r < 10; r++) for (let c = 0; c < 10; c++) {
      const dark = (r + c) % 2 === 1;
      const piece = dark && (r < 3 || r > 6) ? (r < 3 ? 'b' : 'r') : '';
      cells += `<i class="${dark ? 'd' : 'l'}${zone.has(c) ? ' z' : ''}">${piece ? `<u class="${piece}"></u>` : ''}</i>`;
    }
    boardHost.innerHTML = cells;
    options.innerHTML = `<h3>Consignes de ton club</h3><small>Touche une option pour la choisir</small>${Object.entries(TACTIC_OPTIONS).map(([key, group]) => `<div class="fm-lab">${group.label}</div><div class="fm-chips">${group.values.map(([id, label]) => `<button type="button" class="fm-chip${tactics[key] === id ? ' on' : ''}" data-tactic="${key}" data-value="${id}" aria-pressed="${tactics[key] === id}">${label}</button>`).join('')}</div>`).join('')}<p class="fm-hint">La position de départ des pions reste fixée par les règles. La formation montre la zone (en doré) que ton club cherche à occuper ; les consignes serviront à la simulation du match.</p>`;
    if (summary) summary.textContent = tacticsSummary(state);
  };
  options.addEventListener('click', event => {
    const button = event.target.closest('[data-tactic]');
    if (!button) return;
    setTactic(getState(), button.dataset.tactic, button.dataset.value);
    onChange?.();
    paint();
  });
  paint();
  return { refresh: paint };
}
