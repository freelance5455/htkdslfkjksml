import { useCallback, useEffect, useRef, useState } from 'react';
import { apiUrl } from '../lib/apiClient';
import type { DetectedLanguage, LanguagePreference } from '../lib/jarvisTypes';
import {
  buildPreferredMicConstraints,
  computeAudioRms,
  DEFAULT_VAD_SENSITIVITY,
  evaluateVadFrame,
  isDuplicateSubmission,
  isListeningActive,
  mapSpeechRecognitionLang,
  shouldAcceptSpeechTranscript,
  shouldSpeakReply,
  type MicPermissionState,
  type VoiceListeningPhase,
} from '../lib/voiceState';
import { speakReply, stopSpeech } from './ttsEngine';

const MIC_PERMISSION_STORAGE_KEY = 'jarvis_mic_permission_v1';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
  confidence?: number;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionErrorEventLike {
  error: string;
}

interface SpeechRecognitionInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstance;

function getSpeechRecognitionCtor(): SpeechRecognitionConstructor | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  };
  return win.SpeechRecognition ?? win.webkitSpeechRecognition ?? null;
}

export interface VoiceCommandResponse {
  text: string;
  language: DetectedLanguage;
}

interface UseJarvisVoiceOptions {
  languagePreference: LanguagePreference;
  vadSensitivity?: number;
  voiceMuted?: boolean;
  onCommandRecognized: (transcript: string) => Promise<VoiceCommandResponse | null>;
}

export function useJarvisVoice({
  languagePreference,
  vadSensitivity = DEFAULT_VAD_SENSITIVITY,
  voiceMuted = false,
  onCommandRecognized,
}: UseJarvisVoiceOptions) {
  const [phase, setPhase] = useState<VoiceListeningPhase>('off');
  const [permission, setPermission] = useState<MicPermissionState>(() => {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      return 'unsupported';
    }
    try {
      const cached = localStorage.getItem(MIC_PERMISSION_STORAGE_KEY);
      if (cached === 'granted' || cached === 'denied') return cached;
    } catch {
      // Ignore storage errors
    }
    return 'prompt';
  });
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const listeningSessionRef = useRef(false);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const vadIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recorderSilenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const restartTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastRecognizedRef = useRef<{ text: string; at: number } | null>(null);
  const languagePrefRef = useRef(languagePreference);
  languagePrefRef.current = languagePreference;
  const vadSensitivityRef = useRef(vadSensitivity);
  vadSensitivityRef.current = vadSensitivity;
  const voiceMutedRef = useRef(voiceMuted);
  voiceMutedRef.current = voiceMuted;
  const onCommandRef = useRef(onCommandRecognized);
  onCommandRef.current = onCommandRecognized;

  const isActive = isListeningActive(phase);

  // Passively observe browser permission state without triggering any mic prompt on mount
  useEffect(() => {
    let active = true;
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setPermission('unsupported');
      return;
    }
    if (navigator.permissions?.query) {
      navigator.permissions
        .query({ name: 'microphone' as PermissionName })
        .then((status) => {
          if (!active) return;
          const mapped: MicPermissionState =
            status.state === 'granted'
              ? 'granted'
              : status.state === 'denied'
                ? 'denied'
                : 'prompt';
          setPermission(mapped);
          try {
            if (mapped === 'granted' || mapped === 'denied') {
              localStorage.setItem(MIC_PERMISSION_STORAGE_KEY, mapped);
            }
          } catch {
            // Ignore
          }
          status.onchange = () => {
            if (!active) return;
            const next: MicPermissionState =
              status.state === 'granted'
                ? 'granted'
                : status.state === 'denied'
                  ? 'denied'
                  : 'prompt';
            setPermission(next);
          };
        })
        .catch(() => {
          // Permissions API for microphone is unsupported on some browsers; keep prompt fallback
        });
    }
    return () => {
      active = false;
    };
  }, []);

  const releaseActiveCapture = useCallback(() => {
    if (restartTimerRef.current) {
      clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recorderSilenceTimerRef.current) {
      clearTimeout(recorderSilenceTimerRef.current);
      recorderSilenceTimerRef.current = null;
    }
    if (vadIntervalRef.current) {
      clearInterval(vadIntervalRef.current);
      vadIntervalRef.current = null;
    }
    if (audioContextRef.current) {
      try {
        void audioContextRef.current.close();
      } catch {
        // Ignore
      }
      audioContextRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onend = null;
        recognitionRef.current.abort();
      } catch {
        // Ignore
      }
      recognitionRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // Ignore
      }
    }
    mediaRecorderRef.current = null;
    if (mediaStreamRef.current) {
      for (const track of mediaStreamRef.current.getTracks()) {
        track.stop();
      }
      mediaStreamRef.current = null;
    }
  }, []);

  const stopListening = useCallback(() => {
    listeningSessionRef.current = false;
    releaseActiveCapture();
    stopSpeech();
    setInterimTranscript('');
    setPhase('off');
  }, [releaseActiveCapture]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && listeningSessionRef.current) {
        // Android / PWA foreground-only mic policy: pause capture & speech when backgrounded
        listeningSessionRef.current = false;
        releaseActiveCapture();
        stopSpeech();
        setInterimTranscript('');
        setPhase('off');
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      listeningSessionRef.current = false;
      releaseActiveCapture();
      stopSpeech();
    };
  }, [releaseActiveCapture]);

  // Immediately silence active TTS when user switches Mute on
  useEffect(() => {
    if (voiceMuted) {
      stopSpeech();
      setPhase((prev) => {
        if (prev !== 'speaking') return prev;
        return listeningSessionRef.current ? 'listening' : 'off';
      });
    }
  }, [voiceMuted]);

  const handleRecognizedPhrase = useCallback(
    async (transcript: string, resumeFn: () => void) => {
      const cleaned = transcript.trim();
      const now = Date.now();
      if (
        !cleaned ||
        !/[\p{L}\p{N}]/u.test(cleaned) ||
        isDuplicateSubmission(lastRecognizedRef.current, cleaned, now, 1200)
      ) {
        if (listeningSessionRef.current) resumeFn();
        return;
      }
      lastRecognizedRef.current = { text: cleaned, at: now };

      setInterimTranscript('');
      setPhase('processing');
      releaseActiveCapture();

      try {
        const reply = await onCommandRef.current(cleaned);
        if (
          listeningSessionRef.current &&
          reply &&
          shouldSpeakReply(voiceMutedRef.current, reply.text)
        ) {
          setPhase('speaking');
          await speakReply({
            text: reply.text,
            language: reply.language,
          });
        }
      } finally {
        if (listeningSessionRef.current) {
          restartTimerRef.current = setTimeout(() => {
            if (listeningSessionRef.current) {
              resumeFn();
            }
          }, 220);
        } else {
          setPhase('off');
        }
      }
    },
    [releaseActiveCapture],
  );

  const startRecorderFallbackCycle = useCallback(async () => {
    if (!listeningSessionRef.current) return;
    releaseActiveCapture();

    try {
      const stream = await navigator.mediaDevices.getUserMedia(buildPreferredMicConstraints());
      if (!listeningSessionRef.current) {
        for (const t of stream.getTracks()) t.stop();
        return;
      }

      mediaStreamRef.current = stream;
      setPhase('listening');
      setInterimTranscript('Listening via built-in mic…');

      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      // Real-time Web Audio VAD gating so ambient noise below sensitivity threshold is ignored
      let speechDetectedInClip = false;
      let vadAvailable = false;
      let lastVoiceAt = 0;
      let activeSpeaking = false;
      const cycleStartedAt = Date.now();

      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          audioContextRef.current = ctx;
          const source = ctx.createMediaStreamSource(stream);
          const analyser = ctx.createAnalyser();
          analyser.fftSize = 1024;
          source.connect(analyser);
          const samples = new Float32Array(analyser.fftSize);
          vadAvailable = true;

          vadIntervalRef.current = setInterval(() => {
            if (!listeningSessionRef.current || recorder.state !== 'recording') return;
            analyser.getFloatTimeDomainData(samples);
            const rms = computeAudioRms(samples);
            const vad = evaluateVadFrame(rms, vadSensitivityRef.current, activeSpeaking);
            activeSpeaking = vad.voiceDetected;

            if (vad.voiceDetected) {
              speechDetectedInClip = true;
              lastVoiceAt = Date.now();
              setInterimTranscript('Voice detected · Listening…');
            } else if (
              speechDetectedInClip &&
              lastVoiceAt > 0 &&
              Date.now() - lastVoiceAt > 1050 &&
              Date.now() - cycleStartedAt > 1200
            ) {
              if (recorder.state === 'recording') {
                recorder.stop();
              }
            }
          }, 60);
        }
      } catch {
        // Fallback to blob-size check if AudioContext is unavailable
        vadAvailable = false;
      }

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };

      recorder.onstop = async () => {
        if (vadIntervalRef.current) {
          clearInterval(vadIntervalRef.current);
          vadIntervalRef.current = null;
        }
        if (audioContextRef.current) {
          try {
            void audioContextRef.current.close();
          } catch {
            // Ignore
          }
          audioContextRef.current = null;
        }
        for (const t of stream.getTracks()) t.stop();
        if (mediaStreamRef.current === stream) {
          mediaStreamRef.current = null;
        }
        if (!listeningSessionRef.current) return;

        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if ((vadAvailable && !speechDetectedInClip) || blob.size < 1200) {
          if (listeningSessionRef.current) startRecorderFallbackCycle();
          return;
        }

        setPhase('processing');
        setInterimTranscript('Transcribing command…');
        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = typeof reader.result === 'string' ? reader.result : '';
              resolve(result.split(',')[1] || '');
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });

          const res = await fetch(apiUrl('/api/voice/transcribe'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64,
              mimeType: blob.type || 'audio/webm',
              languagePreference: languagePrefRef.current,
            }),
          });
          if (!res.ok) throw new Error('Could not transcribe voice clip.');
          const data = await res.json();
          const transcript = String(data.transcript || '').trim();
          await handleRecognizedPhrase(transcript, startRecorderFallbackCycle);
        } catch (err) {
          setVoiceError(err instanceof Error ? err.message : 'Voice transcription failed.');
          stopListening();
        }
      };

      recorder.start();
      // Cap each voice clip window at 5 seconds when Web Speech API is unavailable
      recorderSilenceTimerRef.current = setTimeout(() => {
        if (recorder.state === 'recording') {
          recorder.stop();
        }
      }, 5000);
    } catch (err) {
      setVoiceError(
        err instanceof Error ? err.message : 'Unable to access built-in microphone.',
      );
      listeningSessionRef.current = false;
      setPhase('error');
    }
  }, [handleRecognizedPhrase, releaseActiveCapture, stopListening]);

  const startWebSpeechCycle = useCallback(() => {
    if (!listeningSessionRef.current) return;
    const SpeechRec = getSpeechRecognitionCtor();
    if (!SpeechRec) {
      startRecorderFallbackCycle();
      return;
    }

    releaseActiveCapture();
    setPhase('listening');
    setInterimTranscript('');

    const rec = new SpeechRec();
    rec.lang = mapSpeechRecognitionLang(languagePrefRef.current);
    rec.continuous = false;
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    recognitionRef.current = rec;

    let finalPhrase = '';
    let dispatched = false;

    rec.onresult = (event) => {
      if (!listeningSessionRef.current) return;
      let interim = '';
      let latestFinal = '';
      let latestFinalConfidence: number | undefined;
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const alt = res[0];
        const txt = alt?.transcript ?? '';
        if (res.isFinal) {
          latestFinal += txt + ' ';
          if (typeof alt?.confidence === 'number') {
            latestFinalConfidence = alt.confidence;
          }
        } else {
          interim += txt + ' ';
        }
      }
      if (
        latestFinal.trim() &&
        shouldAcceptSpeechTranscript({
          transcript: latestFinal,
          confidence: latestFinalConfidence,
          vadSensitivity: vadSensitivityRef.current,
        })
      ) {
        finalPhrase = `${finalPhrase} ${latestFinal}`.trim();
      }
      setInterimTranscript((finalPhrase || interim).trim());

      if (finalPhrase && !dispatched) {
        dispatched = true;
        handleRecognizedPhrase(finalPhrase, startWebSpeechCycle);
      }
    };

    rec.onerror = (event) => {
      if (!listeningSessionRef.current) return;
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        setPermission('denied');
        try {
          localStorage.setItem(MIC_PERMISSION_STORAGE_KEY, 'denied');
        } catch {
          // Ignore
        }
        setVoiceError(
          'Microphone permission was denied. Allow microphone access in browser settings to use voice mode.',
        );
        listeningSessionRef.current = false;
        releaseActiveCapture();
        setPhase('error');
        return;
      }
      if (event.error === 'no-speech' || event.error === 'aborted') {
        return;
      }
      if (event.error === 'audio-capture') {
        setVoiceError('No built-in microphone audio input was detected.');
        listeningSessionRef.current = false;
        releaseActiveCapture();
        setPhase('error');
      }
    };

    rec.onend = () => {
      if (!listeningSessionRef.current || dispatched) return;
      if (finalPhrase.trim()) {
        dispatched = true;
        handleRecognizedPhrase(finalPhrase, startWebSpeechCycle);
        return;
      }
      // Keep listening seamlessly while Talk mode remains active
      restartTimerRef.current = setTimeout(() => {
        if (listeningSessionRef.current) {
          startWebSpeechCycle();
        }
      }, 180);
    };

    try {
      rec.start();
    } catch {
      if (listeningSessionRef.current) {
        startRecorderFallbackCycle();
      }
    }
  }, [handleRecognizedPhrase, releaseActiveCapture, startRecorderFallbackCycle]);

  const confirmPermissionAndTalk = useCallback(async () => {
    setVoiceError(null);
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setPermission('unsupported');
      setVoiceError('Microphone capture is not supported in this browser.');
      setPhase('error');
      return;
    }

    setPhase('requesting_permission');
    try {
      // Request built-in phone mic directly on user gesture
      const probeStream = await navigator.mediaDevices.getUserMedia(
        buildPreferredMicConstraints(),
      );
      // Stop probe tracks right away so Android Chrome SpeechRecognition can acquire the mic cleanly
      for (const track of probeStream.getTracks()) {
        track.stop();
      }

      setPermission('granted');
      try {
        localStorage.setItem(MIC_PERMISSION_STORAGE_KEY, 'granted');
      } catch {
        // Ignore
      }

      listeningSessionRef.current = true;
      startWebSpeechCycle();
    } catch (err) {
      const name = err instanceof Error ? err.name : '';
      if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
        setPermission('denied');
        try {
          localStorage.setItem(MIC_PERMISSION_STORAGE_KEY, 'denied');
        } catch {
          // Ignore
        }
        setVoiceError(
          'Microphone access was blocked. Allow microphone permission in your browser site settings, then tap Talk again.',
        );
      } else {
        setVoiceError(
          'Could not access the built-in microphone. Check that no other app is locking the mic and try again.',
        );
      }
      listeningSessionRef.current = false;
      setPhase('error');
    }
  }, [startWebSpeechCycle]);

  const requestTalkStart = useCallback(() => {
    setVoiceError(null);
    if (permission === 'unsupported') {
      setVoiceError('Microphone capture is unavailable in this browser.');
      setPhase('error');
      return;
    }
    if (permission === 'granted') {
      void confirmPermissionAndTalk();
      return;
    }
    // Explain clearly why microphone permission is needed before prompting
    setPhase('permission_prompt');
  }, [confirmPermissionAndTalk, permission]);

  const cancelPermissionPrompt = useCallback(() => {
    setVoiceError(null);
    setPhase('off');
  }, []);

  const dismissVoiceError = useCallback(() => {
    setVoiceError(null);
    setPhase('off');
  }, []);

  /**
   * Speaks any completed text-mode AI response when unmuted.
   * If Talk listening mode is active, pauses microphone capture during TTS and resumes cleanly afterward.
   */
  const speakTextReply = useCallback(
    async (text: string, language: DetectedLanguage) => {
      if (!shouldSpeakReply(voiceMutedRef.current, text)) return;

      const wasListening = listeningSessionRef.current;
      if (wasListening) {
        releaseActiveCapture();
      }
      setPhase('speaking');
      try {
        await speakReply({ text, language });
      } finally {
        if (listeningSessionRef.current) {
          startWebSpeechCycle();
        } else {
          setPhase('off');
        }
      }
    },
    [releaseActiveCapture, startWebSpeechCycle],
  );

  return {
    phase,
    permission,
    isActive,
    interimTranscript,
    voiceError,
    requestTalkStart,
    confirmPermissionAndTalk,
    cancelPermissionPrompt,
    stopListening,
    dismissVoiceError,
    speakTextReply,
    sendVoiceClipNow: () => {
      if (mediaRecorderRef.current?.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
    },
    isFallbackRecorderActive: Boolean(mediaRecorderRef.current),
  };
}
