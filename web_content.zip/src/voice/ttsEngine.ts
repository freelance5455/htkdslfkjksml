import type { DetectedLanguage } from '../lib/jarvisTypes';
import { mapTtsLang, stripMarkdownForSpeech } from '../lib/voiceState';

export interface SpeakOptions {
  text: string;
  language: DetectedLanguage;
  onStart?: () => void;
  onEnd?: () => void;
}

let activeToken = 0;
let activeSafetyTimer: ReturnType<typeof setTimeout> | null = null;

export function isTtsSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function stopSpeech(): void {
  activeToken += 1;
  if (activeSafetyTimer) {
    clearTimeout(activeSafetyTimer);
    activeSafetyTimer = null;
  }
  if (isTtsSupported()) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // Ignore synthesis cancel errors
    }
  }
}

function splitForSpeech(text: string): string[] {
  if (text.length <= 180) return [text];
  const sentences = text.match(/[^.!?।\n]+[.!?।]*/g) ?? [text];
  const chunks: string[] = [];
  let current = '';
  for (const s of sentences) {
    const trimmed = s.trim();
    if (!trimmed) continue;
    if ((current + ' ' + trimmed).trim().length > 180 && current) {
      chunks.push(current.trim());
      current = trimmed;
    } else {
      current = (current + ' ' + trimmed).trim();
    }
  }
  if (current) chunks.push(current);
  return chunks.length > 0 ? chunks : [text];
}

function selectVoice(
  voices: SpeechSynthesisVoice[],
  targetLocale: string,
): SpeechSynthesisVoice | undefined {
  if (!voices.length) return undefined;
  const lower = targetLocale.toLowerCase();
  const langPrefix = lower.split('-')[0];

  return (
    voices.find((v) => v.lang.toLowerCase() === lower) ??
    voices.find((v) => v.lang.toLowerCase().startsWith(langPrefix)) ??
    voices.find((v) => v.lang.toLowerCase().startsWith('en')) ??
    voices[0]
  );
}

export function speakReply(options: SpeakOptions): Promise<void> {
  const spokenText = stripMarkdownForSpeech(options.text);
  if (!spokenText || !isTtsSupported()) {
    options.onStart?.();
    options.onEnd?.();
    return Promise.resolve();
  }

  stopSpeech();
  const token = ++activeToken;
  const targetLang = mapTtsLang(options.language);
  const chunks = splitForSpeech(spokenText);

  return new Promise<void>((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      if (activeSafetyTimer) {
        clearTimeout(activeSafetyTimer);
        activeSafetyTimer = null;
      }
      options.onEnd?.();
      resolve();
    };

    // Safety guard so headless/muted browsers without TTS audio drivers never hang listening loop
    const maxWaitMs = Math.min(28_000, Math.max(4_500, spokenText.length * 100));
    activeSafetyTimer = setTimeout(finish, maxWaitMs);

    const runChunks = (index: number) => {
      if (token !== activeToken || index >= chunks.length) {
        finish();
        return;
      }

      const utterance = new SpeechSynthesisUtterance(chunks[index]);
      utterance.lang = targetLang;
      utterance.rate = 1.02;
      utterance.pitch = 1.0;

      const voices = window.speechSynthesis.getVoices();
      const matched = selectVoice(voices, targetLang);
      if (matched) {
        try {
          utterance.voice = matched;
        } catch {
          // Fall back cleanly to utterance.lang when browser rejects custom voice object
        }
      }

      if (index === 0) {
        utterance.onstart = () => {
          if (token === activeToken) {
            options.onStart?.();
          }
        };
      }
      utterance.onend = () => {
        if (token === activeToken) {
          runChunks(index + 1);
        } else {
          finish();
        }
      };
      utterance.onerror = () => {
        finish();
      };

      try {
        window.speechSynthesis.speak(utterance);
      } catch {
        finish();
      }
    };

    options.onStart?.();
    runChunks(0);
  });
}
