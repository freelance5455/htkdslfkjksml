/**
 * GODEX Phase 3 - Controlled Tool System & Permissions
 * Strict permission tiers: READ (safe), WRITE (controlled), DELETE (approval required).
 * Every tool call is audited with timing and results.
 */

import { 
  ToolDefinition, 
  ToolPermissionTier, 
  ToolExecutionContext, 
  ToolCallAuditRecord 
} from './agentTypes';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';
import { SecuritySanitizer } from './securitySanitizer';
import { ExecutionEngine } from '../execution/executor';
import { ExecutionResult } from '../execution/executionTypes';

export class ToolSystem {
  private static tools: Map<string, ToolDefinition> = new Map();
  private static auditLogs: ToolCallAuditRecord[] = [];
  private static initialized = false;

  public static initialize(): void {
    if (this.initialized) return;

    // 1. READ_FILE
    this.registerTool({
      name: 'READ_FILE',
      description: 'Reads the content of a specific workspace file.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { path: string }, ctx: ToolExecutionContext) => {
        const content = ctx.workspaceFiles[args.path];
        if (content === undefined) {
          throw new Error(`File not found: ${args.path}`);
        }
        return {
          path: args.path,
          content: SecuritySanitizer.redact(content),
          linesCount: content.split('\n').length,
          bytes: content.length
        };
      }
    });

    // 2. SEARCH_FILES
    this.registerTool({
      name: 'SEARCH_FILES',
      description: 'Searches workspace file paths matching a query pattern.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { query: string }, ctx: ToolExecutionContext) => {
        const q = (args.query || '').toLowerCase();
        const matches = Object.keys(ctx.workspaceFiles).filter(p => p.toLowerCase().includes(q));
        return { query: args.query, matches, count: matches.length };
      }
    });

    // 3. SEARCH_SYMBOLS
    this.registerTool({
      name: 'SEARCH_SYMBOLS',
      description: 'Searches indexed AST symbols (functions, classes, interfaces, hooks, types).',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { query: string; kind?: string }) => {
        const symbols = ProjectIntelligence.getSymbolIndex().search(args.query);
        const filtered = args.kind ? symbols.filter(s => s.kind === args.kind) : symbols;
        return {
          query: args.query,
          symbols: filtered.map(s => ({
            name: s.name,
            kind: s.kind,
            filePath: s.filePath,
            line: s.line,
            exported: s.isExported,
            signature: s.signature
          })),
          count: filtered.length
        };
      }
    });

    // 4. GET_PROJECT_CONTEXT
    this.registerTool({
      name: 'GET_PROJECT_CONTEXT',
      description: 'Retrieves high-level architectural summary and active health metrics.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (_args: any, ctx: ToolExecutionContext) => {
        const state = ProjectIntelligence.getState();
        return {
          framework: state.metadata.framework,
          language: state.metadata.primaryLanguage,
          totalFiles: Object.keys(ctx.workspaceFiles).length,
          totalLines: Object.values(ctx.workspaceFiles).reduce((a, b) => a + b.split('\n').length, 0),
          healthScore: state.health.score,
          entryPoints: state.metadata.entryPoints
        };
      }
    });

    // 5. GET_SYMBOL_CONTEXT
    this.registerTool({
      name: 'GET_SYMBOL_CONTEXT',
      description: 'Retrieves detailed AST signature and usage for a specific symbol.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { symbolName: string; filePath?: string }) => {
        const matches = ProjectIntelligence.getSymbolIndex().getSymbolsByName(args.symbolName);
        const symbol = args.filePath ? matches.find(s => s.filePath === args.filePath) : matches[0];
        if (!symbol) {
          throw new Error(`Symbol not found in AST index: "${args.symbolName}"`);
        }
        return {
          name: symbol.name,
          kind: symbol.kind,
          filePath: symbol.filePath,
          line: symbol.line,
          signature: symbol.signature,
          documentation: symbol.docstring || symbol.signature,
          exported: symbol.isExported
        };
      }
    });

    // 6. GET_DEPENDENCY_GRAPH
    this.registerTool({
      name: 'GET_DEPENDENCY_GRAPH',
      description: 'Retrieves import/export dependency connections for a target file.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { filePath: string }, _ctx: ToolExecutionContext) => {
        const graph = ProjectIntelligence.getState().graph;
        const node = graph?.nodes.find(n => n.filePath === args.filePath);
        const importedBy = graph?.edges.filter(e => e.target === args.filePath).map(e => e.source) || [];
        const imports = graph?.edges.filter(e => e.source === args.filePath).map(e => e.target) || [];

        return {
          filePath: args.filePath,
          nodeExists: !!node,
          imports,
          importedBy,
          totalDependencies: imports.length,
          totalDependents: importedBy.length
        };
      }
    });

    // 7. CREATE_FILE
    this.registerTool({
      name: 'CREATE_FILE',
      description: 'Creates a new file in the workspace.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { path: string; content: string }) => {
        return {
          path: args.path,
          operation: 'CREATE_FILE',
          bytes: (args.content || '').length,
          status: 'ready_to_apply'
        };
      }
    });

    // 8. UPDATE_FILE
    this.registerTool({
      name: 'UPDATE_FILE',
      description: 'Updates an existing workspace file.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { path: string; content: string }) => {
        return {
          path: args.path,
          operation: 'UPDATE_FILE',
          bytes: (args.content || '').length,
          status: 'ready_to_apply'
        };
      }
    });

    // 9. DELETE_FILE
    this.registerTool({
      name: 'DELETE_FILE',
      description: 'Deletes a workspace file. ALWAYS requires user approval.',
      tier: 'DELETE',
      requiresApproval: true,
      handler: async (args: { path: string }, ctx: ToolExecutionContext) => {
        if (!ctx.isApproved) {
          throw new Error(`Execution blocked: Deleting "${args.path}" requires explicit user approval.`);
        }
        return {
          path: args.path,
          operation: 'DELETE_FILE',
          status: 'approved_and_ready'
        };
      }
    });

    // 10. RENAME_FILE
    this.registerTool({
      name: 'RENAME_FILE',
      description: 'Renames or moves a workspace file.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { oldPath: string; newPath: string }) => {
        return {
          oldPath: args.oldPath,
          newPath: args.newPath,
          operation: 'RENAME_FILE',
          status: 'ready_to_apply'
        };
      }
    });

    // 11. RUN_PROJECT_COMMAND (Phase 4 Controlled Execution)
    this.registerTool({
      name: 'RUN_PROJECT_COMMAND',
      description: 'Executes a safe project script (TEST, BUILD, LINT, TYPECHECK, or standard command) under controlled execution policy.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { command: string; purpose?: string; workingDirectory?: string; timeoutMs?: number }, ctx: ToolExecutionContext) => {
        const result = await ExecutionEngine.execute({
          id: `agent-exec-${Date.now()}`,
          command: args.command,
          workingDirectory: args.workingDirectory || '/project',
          timeoutMs: args.timeoutMs || 30000,
          requestedBy: 'GODEX_AGENT',
          reason: args.purpose || 'Autonomous Agent Verification',
          createdAt: Date.now()
        }, ctx.workspaceFiles);

        return {
          command: result.command,
          status: result.status,
          exitCode: result.exitCode,
          durationMs: result.durationMs,
          summary: result.evidence.outputSummary,
          stdout: result.stdout,
          stderr: result.stderr,
          epistemic: result.evidence.epistemic
        };
      }
    });

    // 12. ANALYZE_EXECUTION_FAILURE (Phase 5 Debugger)
    this.registerTool({
      name: 'ANALYZE_EXECUTION_FAILURE',
      description: 'Ingests an execution failure, normalizes the diagnostic output, localizes the error in AST/source, and produces RootCauseAnalysis.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { executionId?: string; stdout?: string; stderr?: string; command?: string; exitCode?: number }, ctx: ToolExecutionContext) => {
        const { FailureNormalizer } = await import('../debugger/failureNormalizer');
        const { FailureLocalizer } = await import('../debugger/failureLocalizer');
        const { FailureContextBuilder } = await import('../debugger/failureContextBuilder');
        const { RootCauseAnalyzer } = await import('../debugger/rootCauseAnalyzer');

        const mockResult: ExecutionResult = {
          id: args.executionId || `exec-${Date.now()}`,
          command: args.command || 'npm run build',
          status: 'FAILED',
          exitCode: args.exitCode || 1,
          stdout: args.stdout || '',
          stderr: args.stderr || '',
          durationMs: 100,
          chunks: [],
          policy: {
            allowed: true,
            classification: 'SAFE',
            reasons: [],
            requiresApproval: false,
            normalizedWorkingDirectory: '.',
            sanitizedCommand: args.command || 'npm run build',
            matchedRules: []
          },
          evidence: {
            executionId: args.executionId || `exec-${Date.now()}`,
            command: args.command || 'npm run build',
            status: 'FAILED',
            exitCode: args.exitCode || 1,
            startedAt: Date.now() - 100,
            finishedAt: Date.now(),
            durationMs: 100,
            requestedBy: 'SYSTEM_VALIDATION',
            workingDirectory: '.',
            outputSummary: (args.stderr || args.stdout || '').slice(0, 100),
            totalStdoutLines: 0,
            totalStderrLines: (args.stderr || '').split('\n').length,
            epistemic: { known: [], likely: [], unknown: [] },
            source: 'actual_process_output'
          }
        };

        const failure = FailureNormalizer.normalize(mockResult);
        const localized = FailureLocalizer.localize(failure.location, ctx.workspaceFiles);
        const context = FailureContextBuilder.build(failure, localized, ctx.workspaceFiles);
        const rootCause = RootCauseAnalyzer.analyze(failure, context);

        return {
          failureEvent: failure,
          localizedScope: localized,
          rootCauseAnalysis: rootCause,
          affectedFilesCount: context.affectedFiles.length
        };
      }
    });

    // 13. PROPOSE_REPAIR (Phase 5 Debugger)
    this.registerTool({
      name: 'PROPOSE_REPAIR',
      description: 'Generates a verified, bounded RepairPlan from RootCauseAnalysis and FailureContext with safety policy checks.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { analysis: any; context: any; patch?: any }) => {
        const { RepairPlanner } = await import('../debugger/repairPlanner');
        const plan = RepairPlanner.plan(args.analysis, args.context, args.patch);
        return { plan };
      }
    });

    // 14. EXECUTE_REPAIR_CYCLE (Phase 5 Debugger)
    this.registerTool({
      name: 'EXECUTE_REPAIR_CYCLE',
      description: 'Applies a planned repair patch safely, runs Phase 4 revalidation, and truthfully detects regression vs recovery.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { patch: { path: string; targetContent: string; replacementContent: string; explanation: string } }, ctx: ToolExecutionContext) => {
        const { SelfHealingEngine } = await import('../debugger/selfHealingEngine');
        const engine = SelfHealingEngine.getInstance();
        const session = await engine.executeRepairCycle(
          args.patch,
          ctx.workspaceFiles,
          (path, content) => { ctx.workspaceFiles[path] = content; }
        );
        return { session };
      }
    });

    // 15. GIT_STATUS (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_STATUS',
      description: 'Returns the authoritative Git working tree state, modified files, staged files, active branch, and fingerprints.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { branch?: string }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const state = GitOperationPlanner.getWorkingTreeState(ctx.workspaceFiles, args.branch || 'main');
        return { state };
      }
    });

    // 16. GIT_CREATE_BRANCH (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_CREATE_BRANCH',
      description: 'Plans and creates a new Git branch under controlled safety policy.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { branchName: string }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const { GitOperationExecutor } = await import('../gitops/gitOperationExecutor');
        const proposal = GitOperationPlanner.planOperation({
          type: 'CREATE_BRANCH',
          targetBranch: args.branchName,
          title: `Create branch '${args.branchName}'`
        }, ctx.workspaceFiles);
        const result = await GitOperationExecutor.execute(proposal, {
          workspaceFiles: ctx.workspaceFiles,
          currentBranch: 'main'
        });
        return { proposal, result };
      }
    });

    // 17. GIT_SWITCH_BRANCH (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_SWITCH_BRANCH',
      description: 'Safely switches the active working branch with dirty working tree protection.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { targetBranch: string; allowDirty?: boolean }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const { GitOperationExecutor } = await import('../gitops/gitOperationExecutor');
        const proposal = GitOperationPlanner.planOperation({
          type: 'SWITCH_BRANCH',
          targetBranch: args.targetBranch,
          title: `Switch branch to '${args.targetBranch}'`,
          userExplicitApproval: args.allowDirty
        }, ctx.workspaceFiles);
        const result = await GitOperationExecutor.execute(proposal, {
          workspaceFiles: ctx.workspaceFiles,
          currentBranch: 'main'
        });
        return { proposal, result };
      }
    });

    // 18. GIT_STAGE_FILES (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_STAGE_FILES',
      description: 'Stages specific workspace files for commit.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { files: string[] }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const { GitOperationExecutor } = await import('../gitops/gitOperationExecutor');
        const proposal = GitOperationPlanner.planOperation({
          type: 'STAGE_FILES',
          targetFiles: args.files,
          title: `Stage files: ${args.files.join(', ')}`
        }, ctx.workspaceFiles);
        const result = await GitOperationExecutor.execute(proposal, {
          workspaceFiles: ctx.workspaceFiles,
          currentBranch: 'main'
        });
        return { proposal, result };
      }
    });

    // 19. GIT_PROPOSE_COMMIT (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_PROPOSE_COMMIT',
      description: 'Formulates a verified commit proposal with diff summary, secret scanning, and policy risk classification.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { message: string; files?: string[] }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const proposal = GitOperationPlanner.planOperation({
          type: 'CREATE_COMMIT',
          suggestedCommitMessage: args.message,
          targetFiles: args.files,
          title: `Propose commit: ${args.message}`
        }, ctx.workspaceFiles);
        return { proposal };
      }
    });

    // 20. GIT_CREATE_COMMIT (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_CREATE_COMMIT',
      description: 'Creates a verified commit in repository history with secret checks, rollback snapshots, and Engineering Memory indexing.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { message: string; files?: string[]; approved?: boolean }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const { GitOperationExecutor } = await import('../gitops/gitOperationExecutor');
        const proposal = GitOperationPlanner.planOperation({
          type: 'CREATE_COMMIT',
          suggestedCommitMessage: args.message,
          targetFiles: args.files,
          title: `Commit: ${args.message}`,
          userExplicitApproval: args.approved || ctx.isApproved
        }, ctx.workspaceFiles);
        if (proposal.policyResult?.requiresApproval && (args.approved || ctx.isApproved)) {
          proposal.approvalMode = 'USER_APPROVED';
          proposal.status = 'APPROVED';
        }
        const result = await GitOperationExecutor.execute(proposal, {
          workspaceFiles: ctx.workspaceFiles,
          currentBranch: 'main'
        });
        return { proposal, result };
      }
    });

    // 21. GIT_COMPARE_BRANCHES (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_COMPARE_BRANCHES',
      description: 'Compares two branches to detect divergence, AST conflicts, and breaking changes.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { sourceBranch: string; targetBranch: string; sourceFiles?: Record<string, string>; targetFiles?: Record<string, string> }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const sFiles = args.sourceFiles || ctx.workspaceFiles;
        const tFiles = args.targetFiles || ctx.workspaceFiles;
        const mergePlan = GitOperationPlanner.planMerge(args.sourceBranch, args.targetBranch, sFiles, tFiles);
        return { comparison: mergePlan };
      }
    });

    // 22. GIT_PREPARE_MERGE (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_PREPARE_MERGE',
      description: 'Prepares merge proposal with full 3-way AST conflict detection and breaking changes analysis.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { sourceBranch: string; targetBranch: string; sourceFiles?: Record<string, string>; targetFiles?: Record<string, string> }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const sFiles = args.sourceFiles || ctx.workspaceFiles;
        const tFiles = args.targetFiles || ctx.workspaceFiles;
        const mergePlan = GitOperationPlanner.planMerge(args.sourceBranch, args.targetBranch, sFiles, tFiles);
        return { mergePlan };
      }
    });

    // 23. GIT_MERGE (Phase 8 GitOps)
    this.registerTool({
      name: 'GIT_MERGE',
      description: 'Merges source branch into target branch under strict conflict and approval gates.',
      tier: 'WRITE',
      requiresApproval: true,
      handler: async (args: { sourceBranch: string; targetBranch: string; approved?: boolean }, ctx: ToolExecutionContext) => {
        const { GitOperationPlanner } = await import('../gitops/gitOperationPlanner');
        const { GitOperationExecutor } = await import('../gitops/gitOperationExecutor');
        const proposal = GitOperationPlanner.planOperation({
          type: 'MERGE',
          targetBranch: args.sourceBranch,
          baseBranch: args.targetBranch,
          title: `Merge '${args.sourceBranch}' into '${args.targetBranch}'`,
          userExplicitApproval: args.approved || ctx.isApproved
        }, ctx.workspaceFiles);
        if (args.approved || ctx.isApproved) {
          proposal.approvalMode = 'USER_APPROVED';
          proposal.status = 'APPROVED';
        }
        const result = await GitOperationExecutor.execute(proposal, {
          workspaceFiles: ctx.workspaceFiles,
          currentBranch: args.targetBranch || 'main'
        });
        return { proposal, result };
      }
    });

    // 24. RELEASE_AUDIT (Phase 8 GitOps)
    this.registerTool({
      name: 'RELEASE_AUDIT',
      description: 'Evaluates project readiness for release across 11 quality, security, and verification dimensions.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (args: { projectTitle?: string; targetBranch?: string }, ctx: ToolExecutionContext) => {
        const { ReleasePlanner } = await import('../gitops/releasePlanner');
        const plan = ReleasePlanner.planRelease({
          projectTitle: args.projectTitle || 'Project',
          targetBranch: args.targetBranch || 'main',
          files: ctx.workspaceFiles
        });
        return { releasePlan: plan, audit: plan.audit, score: plan.score };
      }
    });

    // 25. CREATE_MISSION (Phase 9 Mission System)
    this.registerTool({
      name: 'CREATE_MISSION',
      description: 'Creates and initializes an autonomous engineering mission with DAG task decomposition.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { objective: string; autonomyLevel?: 'ASSISTED' | 'CONTROLLED' | 'AUTONOMOUS' }, ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        const manager = MissionManager.getInstance();
        const mission = await manager.startMission(args.objective, ctx.workspaceFiles, args.autonomyLevel || 'CONTROLLED');
        return { missionId: mission.id, title: mission.title, status: mission.status, tasksCount: mission.tasks.length };
      }
    });

    // 26. GET_MISSION_STATUS (Phase 9 Mission System)
    this.registerTool({
      name: 'GET_MISSION_STATUS',
      description: 'Retrieves current execution progress, active task, and state of the active mission.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (_args: {}, _ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        const mission = MissionManager.getInstance().getActiveMission();
        if (!mission) return { active: false, message: 'No active mission currently loaded.' };
        return {
          active: true,
          missionId: mission.id,
          title: mission.title,
          status: mission.status,
          risk: mission.riskLevel,
          progress: mission.progress,
          activeTaskId: mission.activeTaskId,
          completedTasks: mission.completedTasks.length,
          totalTasks: mission.tasks.length
        };
      }
    });

    // 27. PAUSE_MISSION (Phase 9 Mission System)
    this.registerTool({
      name: 'PAUSE_MISSION',
      description: 'Safely pauses active mission execution and preserves checkpoint state.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (_args: {}, _ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        MissionManager.getInstance().pauseMission();
        return { success: true, message: 'Mission execution paused.' };
      }
    });

    // 28. RESUME_MISSION (Phase 9 Mission System)
    this.registerTool({
      name: 'RESUME_MISSION',
      description: 'Resumes a paused mission after validating current workspace state.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (_args: {}, ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        await MissionManager.getInstance().resumeMission(ctx.workspaceFiles);
        return { success: true, message: 'Mission execution resumed.' };
      }
    });

    // 29. CANCEL_MISSION (Phase 9 Mission System)
    this.registerTool({
      name: 'CANCEL_MISSION',
      description: 'Cancels the active mission and releases all agent file locks.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (_args: {}, _ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        MissionManager.getInstance().cancelMission();
        return { success: true, message: 'Mission cancelled.' };
      }
    });

    // 30. REPLAN_MISSION (Phase 9 Mission System)
    this.registerTool({
      name: 'REPLAN_MISSION',
      description: 'Re-evaluates and dynamically replans the active mission given new context or obstacle.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { reason: string }, ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        const updated = MissionManager.getInstance().replanActiveMission(args.reason, ctx.workspaceFiles);
        return { success: !!updated, mission: updated ? { id: updated.id, status: updated.status, tasks: updated.tasks.length } : null };
      }
    });

    // 31. GET_MISSION_EVIDENCE (Phase 9 Mission System)
    this.registerTool({
      name: 'GET_MISSION_EVIDENCE',
      description: 'Retrieves the complete verification evidence dossier and epistemic breakdown for a completed mission.',
      tier: 'READ',
      requiresApproval: false,
      handler: async (_args: {}, _ctx: ToolExecutionContext) => {
        const { MissionManager } = await import('../mission/missionManager');
        const mission = MissionManager.getInstance().getActiveMission();
        if (!mission) return { error: 'No mission active' };
        return {
          missionId: mission.id,
          evidence: mission.evidence || 'Evidence compilation pending mission completion.',
          timeline: mission.timeline
        };
      }
    });

    // 32. IMPORT_PROJECT (Safe Project Import & ZIP Extraction)
    this.registerTool({
      name: 'IMPORT_PROJECT',
      description: 'Safely imports a project archive or file map into the workspace with conflict resolution.',
      tier: 'WRITE',
      requiresApproval: false,
      handler: async (args: { files?: Record<string, string>; strategy?: 'replace' | 'merge_overwrite' | 'merge_keep' | 'subfolder'; subfolderName?: string }) => {
        const { ZipImportService } = await import('../services/zipImportService');
        const filesToImport = args.files || {};
        const res = await ZipImportService.importToWorkspace(
          filesToImport,
          args.strategy || 'replace',
          args.subfolderName
        );
        return {
          success: res.success,
          strategy: res.strategy,
          importedFilesCount: res.importedFilesCount,
          totalWorkspaceFiles: Object.keys(res.files).length,
          framework: res.metadata.framework,
          language: res.metadata.primaryLanguage
        };
      }
    });

    this.initialized = true;
  }

  public static registerTool(tool: ToolDefinition): void {
    this.tools.set(tool.name, tool);
  }

  public static getTool(name: string): ToolDefinition | undefined {
    this.initialize();
    return this.tools.get(name);
  }

  public static getAllTools(): ToolDefinition[] {
    this.initialize();
    return Array.from(this.tools.values());
  }

  /**
   * Executes a tool with tier checking and audit logging
   */
  public static async executeTool(
    name: string,
    args: Record<string, any>,
    context: ToolExecutionContext
  ): Promise<{ success: boolean; data?: any; error?: string }> {
    this.initialize();
    const tool = this.tools.get(name);
    const startTime = Date.now();

    if (!tool) {
      const err = `Tool "${name}" is not registered in GODEX Tool System.`;
      return { success: false, error: err };
    }

    // Permission boundary check
    if (tool.tier === 'DELETE' && !context.isApproved) {
      const err = `Tool execution blocked: "${name}" is classified as ${tool.tier} tier and requires explicit user approval.`;
      this.recordAudit(name, tool.tier, args, { success: false, error: err, durationMs: Date.now() - startTime });
      return { success: false, error: err };
    }

    try {
      const data = await tool.handler(args, context);
      const durationMs = Date.now() - startTime;
      this.recordAudit(name, tool.tier, args, { success: true, data, durationMs });
      return { success: true, data };
    } catch (err: any) {
      const durationMs = Date.now() - startTime;
      const errorMsg = err.message || 'Tool execution error';
      this.recordAudit(name, tool.tier, args, { success: false, error: errorMsg, durationMs });
      return { success: false, error: errorMsg };
    }
  }

  private static recordAudit(
    toolName: string,
    tier: ToolPermissionTier,
    args: Record<string, any>,
    result: { success: boolean; data?: any; error?: string; durationMs: number }
  ): void {
    this.auditLogs.unshift({
      id: 'audit-' + Math.random().toString(36).slice(2, 9),
      timestamp: Date.now(),
      toolName,
      tier,
      args,
      result
    });

    if (this.auditLogs.length > 100) {
      this.auditLogs.pop();
    }
  }

  public static getAuditLogs(): ToolCallAuditRecord[] {
    return [...this.auditLogs];
  }

  public static getAuditLog(): ToolCallAuditRecord[] {
    return [...this.auditLogs];
  }
}
