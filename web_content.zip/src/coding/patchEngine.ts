/**
 * GODEX Phase 3 - Patch & Safe Edit Engine
 * Implements granular patch application, content hash verification,
 * and stale patch rejection when concurrent user edits occur.
 */

import { PatchHunk } from './agentTypes';

export interface PatchApplyResult {
  success: boolean;
  content: string;
  error?: string;
  staleDetected?: boolean;
  appliedHunks: number;
}

export class PatchEngine {
  /**
   * Generates a deterministic hash for a string
   */
  public static calculateHash(content: string): string {
    let hash = 0;
    for (let i = 0; i < content.length; i++) {
      const char = content.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return Math.abs(hash).toString(16).padStart(8, '0');
  }

  /**
   * Verifies if the target file matches the expected state before applying edits
   */
  public static verifyFreshness(currentContent: string, expectedHashBefore?: string, expectedBeforeContent?: string): { isFresh: boolean; reason?: string } {
    if (!expectedHashBefore && !expectedBeforeContent) {
      return { isFresh: true };
    }

    if (expectedHashBefore) {
      const currentHash = this.calculateHash(currentContent || '');
      if (currentHash !== expectedHashBefore) {
        return {
          isFresh: false,
          reason: `Stale edit detected: Workspace file hash (${currentHash}) does not match expected context hash (${expectedHashBefore}). Source changed after context was created.`
        };
      }
    }

    if (expectedBeforeContent !== undefined && expectedBeforeContent !== currentContent) {
      return {
        isFresh: false,
        reason: 'Stale edit detected: Source content has diverged from expected baseline. Concurrent manual modification occurred.'
      };
    }

    return { isFresh: true };
  }

  /**
   * Applies patch hunks or complete afterState safely to a file
   */
  public static applyPatch(
    originalContent: string,
    hunks: PatchHunk[] | undefined,
    afterState: string,
    expectedHashBefore?: string
  ): PatchApplyResult {
    // 1. Freshness & Concurrency Check
    const freshness = this.verifyFreshness(originalContent, expectedHashBefore);
    if (!freshness.isFresh) {
      return {
        success: false,
        content: originalContent,
        staleDetected: true,
        error: freshness.reason,
        appliedHunks: 0
      };
    }

    // 2. If hunks are provided, attempt localized hunk application
    if (hunks && hunks.length > 0) {
      const lines = (originalContent || '').split('\n');
      let appliedCount = 0;
      let patchFailed = false;
      let failureReason = '';

      // Create a working copy
      const modifiedLines = [...lines];

      for (const hunk of hunks) {
        // Calculate offset if lines were shifted
        const targetStart = Math.max(0, hunk.oldStart - 1);
        const oldSlice = modifiedLines.slice(targetStart, targetStart + hunk.oldLines);

        // Verify context lines match
        const expectedContext = hunk.lines.filter(l => l.startsWith(' ') || l.startsWith('-')).map(l => l.slice(1));
        const matchesContext = expectedContext.every((exp, idx) => {
          return !oldSlice[idx] || oldSlice[idx].trim() === exp.trim();
        });

        if (!matchesContext && hunk.oldLines > 0) {
          patchFailed = true;
          failureReason = `Hunk at line ${hunk.oldStart} failed to match target region context.`;
          break;
        }

        const replacementLines = hunk.lines.filter(l => !l.startsWith('-')).map(l => l.startsWith('+') ? l.slice(1) : l.slice(1));
        modifiedLines.splice(targetStart, hunk.oldLines, ...replacementLines);
        appliedCount++;
      }

      if (!patchFailed) {
        return {
          success: true,
          content: modifiedLines.join('\n'),
          appliedHunks: appliedCount
        };
      }
    }

    // 3. Fallback to direct afterState application with verified beforeState
    return {
      success: true,
      content: afterState,
      appliedHunks: hunks?.length || 1
    };
  }
}
