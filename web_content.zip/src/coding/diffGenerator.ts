/**
 * GODEX Phase 3 - Diff Generator
 * Computes unified diffs, additions/deletions, hunk breakdown, and sanitized patch representations.
 */

import { PatchHunk } from './agentTypes';
import { SecuritySanitizer } from './securitySanitizer';

export interface DiffLine {
  type: 'added' | 'removed' | 'unchanged';
  oldLineNumber?: number;
  newLineNumber?: number;
  content: string;
}

export interface DetailedFileDiff {
  filePath: string;
  additions: number;
  deletions: number;
  lines: DiffLine[];
  hunks: PatchHunk[];
  unifiedDiff: string;
  hasChanges: boolean;
}

export class DiffGenerator {
  /**
   * Computes a structured and unified diff between before and after states
   */
  public static compute(filePath: string, beforeContent: string, afterContent: string): DetailedFileDiff {
    const cleanBefore = SecuritySanitizer.redact(beforeContent || '');
    const cleanAfter = SecuritySanitizer.redact(afterContent || '');

    const oldLines = cleanBefore.split('\n');
    const newLines = cleanAfter.split('\n');

    // Handle empty file edge cases
    if (cleanBefore === '' && cleanAfter === '') {
      return {
        filePath,
        additions: 0,
        deletions: 0,
        lines: [],
        hunks: [],
        unifiedDiff: '',
        hasChanges: false
      };
    }

    if (cleanBefore === '') {
      // Entirely new file
      const lines: DiffLine[] = newLines.map((content, idx) => ({
        type: 'added',
        newLineNumber: idx + 1,
        content
      }));

      const unifiedDiff = `--- /dev/null\n+++ b/${filePath}\n@@ -0,0 +1,${newLines.length} @@\n` +
        newLines.map(l => `+${l}`).join('\n');

      return {
        filePath,
        additions: newLines.length,
        deletions: 0,
        lines,
        hunks: [{
          oldStart: 0,
          oldLines: 0,
          newStart: 1,
          newLines: newLines.length,
          lines: newLines.map(l => `+${l}`)
        }],
        unifiedDiff,
        hasChanges: true
      };
    }

    if (cleanAfter === '') {
      // Deleted file
      const lines: DiffLine[] = oldLines.map((content, idx) => ({
        type: 'removed',
        oldLineNumber: idx + 1,
        content
      }));

      const unifiedDiff = `--- a/${filePath}\n+++ /dev/null\n@@ -1,${oldLines.length} +0,0 @@\n` +
        oldLines.map(l => `-${l}`).join('\n');

      return {
        filePath,
        additions: 0,
        deletions: oldLines.length,
        lines,
        hunks: [{
          oldStart: 1,
          oldLines: oldLines.length,
          newStart: 0,
          newLines: 0,
          lines: oldLines.map(l => `-${l}`)
        }],
        unifiedDiff,
        hasChanges: true
      };
    }

    const lines: DiffLine[] = [];
    let additions = 0;
    let deletions = 0;

    let oldIdx = 0;
    let newIdx = 0;

    while (oldIdx < oldLines.length || newIdx < newLines.length) {
      if (oldIdx < oldLines.length && newIdx < newLines.length) {
        if (oldLines[oldIdx] === newLines[newIdx]) {
          lines.push({
            type: 'unchanged',
            oldLineNumber: oldIdx + 1,
            newLineNumber: newIdx + 1,
            content: oldLines[oldIdx]
          });
          oldIdx++;
          newIdx++;
        } else {
          // Look ahead window of 6 lines
          const foundInNew = newLines.slice(newIdx, newIdx + 6).indexOf(oldLines[oldIdx]);
          const foundInOld = oldLines.slice(oldIdx, oldIdx + 6).indexOf(newLines[newIdx]);

          if (foundInNew !== -1 && (foundInOld === -1 || foundInNew <= foundInOld)) {
            // Lines added in new
            for (let i = 0; i < foundInNew; i++) {
              lines.push({
                type: 'added',
                newLineNumber: newIdx + 1,
                content: newLines[newIdx]
              });
              additions++;
              newIdx++;
            }
          } else if (foundInOld !== -1) {
            // Lines removed in old
            for (let i = 0; i < foundInOld; i++) {
              lines.push({
                type: 'removed',
                oldLineNumber: oldIdx + 1,
                content: oldLines[oldIdx]
              });
              deletions++;
              oldIdx++;
            }
          } else {
            // Both lines differ -> treat as replacement
            lines.push({
              type: 'removed',
              oldLineNumber: oldIdx + 1,
              content: oldLines[oldIdx]
            });
            deletions++;
            oldIdx++;

            lines.push({
              type: 'added',
              newLineNumber: newIdx + 1,
              content: newLines[newIdx]
            });
            additions++;
            newIdx++;
          }
        }
      } else if (oldIdx < oldLines.length) {
        lines.push({
          type: 'removed',
          oldLineNumber: oldIdx + 1,
          content: oldLines[oldIdx]
        });
        deletions++;
        oldIdx++;
      } else if (newIdx < newLines.length) {
        lines.push({
          type: 'added',
          newLineNumber: newIdx + 1,
          content: newLines[newIdx]
        });
        additions++;
        newIdx++;
      }
    }

    // Build unified diff format
    const hunks: PatchHunk[] = [];
    const hunkLines: string[] = [];
    let hunkOldStart = 1;
    let hunkNewStart = 1;
    let hunkOldCount = 0;
    let hunkNewCount = 0;
    let inHunk = false;

    lines.forEach((l, idx) => {
      if (l.type !== 'unchanged') {
        if (!inHunk) {
          inHunk = true;
          hunkOldStart = l.oldLineNumber || 1;
          hunkNewStart = l.newLineNumber || 1;
        }
        if (l.type === 'added') {
          hunkLines.push(`+${l.content}`);
          hunkNewCount++;
        } else if (l.type === 'removed') {
          hunkLines.push(`-${l.content}`);
          hunkOldCount++;
        }
      } else if (inHunk) {
        // Keep up to 2 context lines
        hunkLines.push(` ${l.content}`);
        hunkOldCount++;
        hunkNewCount++;
        if (hunkLines.length > 20 || idx === lines.length - 1) {
          hunks.push({
            oldStart: hunkOldStart,
            oldLines: hunkOldCount,
            newStart: hunkNewStart,
            newLines: hunkNewCount,
            lines: [...hunkLines]
          });
          hunkLines.length = 0;
          hunkOldCount = 0;
          hunkNewCount = 0;
          inHunk = false;
        }
      }
    });

    if (hunkLines.length > 0) {
      hunks.push({
        oldStart: hunkOldStart,
        oldLines: hunkOldCount,
        newStart: hunkNewStart,
        newLines: hunkNewCount,
        lines: hunkLines
      });
    }

    const unifiedHeader = `--- a/${filePath}\n+++ b/${filePath}\n`;
    const unifiedBody = hunks.map(h => 
      `@@ -${h.oldStart},${h.oldLines} +${h.newStart},${h.newLines} @@\n` + h.lines.join('\n')
    ).join('\n\n');

    const unifiedDiff = hunks.length > 0 ? (unifiedHeader + unifiedBody) : '';

    return {
      filePath,
      additions,
      deletions,
      lines,
      hunks,
      unifiedDiff,
      hasChanges: additions > 0 || deletions > 0
    };
  }
}
