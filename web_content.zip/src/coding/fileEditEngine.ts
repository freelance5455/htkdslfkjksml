/**
 * GODEX Phase 3 - Controlled File Edit Engine
 * Strict boundary governing all file mutations.
 * Enforces approval for destructive changes, large changesets, and dependency alterations.
 */

import { 
  FileEditOperation, 
  FileEditOperationType, 
  ApprovalMode 
} from './agentTypes';
import { DiffGenerator } from './diffGenerator';
import { PatchEngine } from './patchEngine';
import { SecuritySanitizer } from './securitySanitizer';

export interface FileEditEngineConfig {
  largeChangesetFileThreshold: number; // default: 4 files
  largeChangesetLineThreshold: number; // default: 300 lines
  requireApprovalForDeletions: boolean;
  requireApprovalForDependencies: boolean;
  requireApprovalForConfig: boolean;
}

export const DEFAULT_EDIT_CONFIG: FileEditEngineConfig = {
  largeChangesetFileThreshold: 4,
  largeChangesetLineThreshold: 300,
  requireApprovalForDeletions: true,
  requireApprovalForDependencies: true,
  requireApprovalForConfig: true
};

export class FileEditEngine {
  private static config: FileEditEngineConfig = { ...DEFAULT_EDIT_CONFIG };

  public static setConfig(customConfig: Partial<FileEditEngineConfig>): void {
    this.config = { ...this.config, ...customConfig };
  }

  public static getConfig(): FileEditEngineConfig {
    return { ...this.config };
  }

  /**
   * Checks if an operation is destructive or alters security / dependencies / configuration
   */
  public static assessDestructiveRisk(
    operation: FileEditOperationType,
    targetPath: string,
    beforeContent: string,
    afterContent: string
  ): { isDestructive: boolean; requiresApproval: boolean; reason?: string } {
    // 1. File Deletion is strictly destructive
    if (operation === 'DELETE_FILE') {
      return {
        isDestructive: true,
        requiresApproval: this.config.requireApprovalForDeletions,
        reason: `Destructive operation: Deleting file "${targetPath}".`
      };
    }

    // 2. Sensitive Security Files
    if (SecuritySanitizer.isSensitivePath(targetPath)) {
      return {
        isDestructive: true,
        requiresApproval: true,
        reason: `Security-sensitive target: Modifying credentials or secrets in "${targetPath}".`
      };
    }

    // 3. Package & Dependency Modifications
    if (targetPath === 'package.json') {
      try {
        const pkgBefore = JSON.parse(beforeContent || '{}');
        const pkgAfter = JSON.parse(afterContent || '{}');
        const depsBefore = Object.keys({ ...pkgBefore.dependencies, ...pkgBefore.devDependencies });
        const depsAfter = Object.keys({ ...pkgAfter.dependencies, ...pkgAfter.devDependencies });
        
        const addedDeps = depsAfter.filter(d => !depsBefore.includes(d));
        const removedDeps = depsBefore.filter(d => !depsAfter.includes(d));

        if (addedDeps.length > 0 || removedDeps.length > 0) {
          return {
            isDestructive: false,
            requiresApproval: this.config.requireApprovalForDependencies,
            reason: `Dependency change detected in package.json (${[
              ...addedDeps.map(d => `+ ${d}`),
              ...removedDeps.map(d => `- ${d}`)
            ].join(', ')}).`
          };
        }
      } catch (e) {
        // Syntax issue in package.json
        return {
          isDestructive: true,
          requiresApproval: true,
          reason: 'Modifying package.json with potential formatting change.'
        };
      }
    }

    // 4. Critical Project Configs (tsconfig, vite.config)
    if (targetPath.includes('tsconfig') || targetPath.includes('vite.config') || targetPath.includes('webpack.config')) {
      if (this.config.requireApprovalForConfig) {
        return {
          isDestructive: false,
          requiresApproval: true,
          reason: `Modifying core build/compiler configuration "${targetPath}".`
        };
      }
    }

    // 5. Destructive SQL / Database patterns
    const dbRisk = SecuritySanitizer.detectDangerousDatabaseOperations(afterContent);
    if (dbRisk.dangerous) {
      return {
        isDestructive: true,
        requiresApproval: true,
        reason: dbRisk.reason
      };
    }

    return { isDestructive: false, requiresApproval: false };
  }

  /**
   * Creates a proposed FileEditOperation with diff and risk assessment
   */
  public static proposeOperation(
    operation: FileEditOperationType,
    targetPath: string,
    beforeContent: string,
    afterContent: string,
    reason: string,
    oldPath?: string
  ): FileEditOperation {
    const diff = DiffGenerator.compute(targetPath, beforeContent, afterContent);
    const risk = this.assessDestructiveRisk(operation, targetPath, beforeContent, afterContent);
    const expectedHashBefore = PatchEngine.calculateHash(beforeContent || '');

    return {
      id: 'op-' + Math.random().toString(36).slice(2, 9),
      operation,
      target: targetPath,
      oldPath,
      beforeState: beforeContent,
      afterState: afterContent,
      reason,
      isDestructive: risk.isDestructive,
      approvalRequired: risk.requiresApproval,
      expectedHashBefore,
      additions: diff.additions,
      deletions: diff.deletions,
      patchHunks: diff.hunks,
      unifiedDiff: diff.unifiedDiff,
      status: 'proposed'
    };
  }

  /**
   * Evaluates if a batch of operations exceeds the large changeset threshold
   */
  public static evaluateBatchApproval(operations: FileEditOperation[]): {
    approvalRequired: boolean;
    reason?: string;
    totalFiles: number;
    totalAdditions: number;
    totalDeletions: number;
  } {
    const totalFiles = operations.length;
    let totalAdditions = 0;
    let totalDeletions = 0;
    let hasDestructive = false;
    let destructiveReason = '';

    for (const op of operations) {
      totalAdditions += op.additions;
      totalDeletions += op.deletions;
      if (op.approvalRequired) {
        hasDestructive = true;
        destructiveReason = op.reason;
      }
    }

    if (hasDestructive) {
      return {
        approvalRequired: true,
        reason: destructiveReason,
        totalFiles,
        totalAdditions,
        totalDeletions
      };
    }

    if (totalFiles >= this.config.largeChangesetFileThreshold) {
      return {
        approvalRequired: true,
        reason: `Large changeset: Task modifies ${totalFiles} files (Threshold: ${this.config.largeChangesetFileThreshold} files).`,
        totalFiles,
        totalAdditions,
        totalDeletions
      };
    }

    if (totalAdditions + totalDeletions >= this.config.largeChangesetLineThreshold) {
      return {
        approvalRequired: true,
        reason: `Large changeset: Task introduces ${totalAdditions + totalDeletions} line changes (Threshold: ${this.config.largeChangesetLineThreshold} lines).`,
        totalFiles,
        totalAdditions,
        totalDeletions
      };
    }

    return {
      approvalRequired: false,
      totalFiles,
      totalAdditions,
      totalDeletions
    };
  }

  /**
   * Safely applies an operation to the workspace map
   */
  public static applyOperation(
    op: FileEditOperation,
    workspaceFiles: Record<string, string>
  ): { success: boolean; updatedFiles: Record<string, string>; error?: string } {
    const updatedFiles = { ...workspaceFiles };

    switch (op.operation) {
      case 'CREATE_FILE': {
        // If file already exists and has different content, verify freshness
        if (updatedFiles[op.target] && updatedFiles[op.target] !== op.beforeState) {
          const fresh = PatchEngine.verifyFreshness(updatedFiles[op.target], op.expectedHashBefore);
          if (!fresh.isFresh) {
            op.status = 'failed';
            op.error = fresh.reason;
            return { success: false, updatedFiles, error: fresh.reason };
          }
        }
        updatedFiles[op.target] = op.afterState;
        op.status = 'applied';
        op.appliedAt = Date.now();
        op.actualHashAfter = PatchEngine.calculateHash(op.afterState);
        return { success: true, updatedFiles };
      }

      case 'UPDATE_FILE': {
        const currentContent = updatedFiles[op.target] || '';
        const patchResult = PatchEngine.applyPatch(
          currentContent,
          op.patchHunks,
          op.afterState,
          op.expectedHashBefore
        );

        if (!patchResult.success) {
          op.status = 'failed';
          op.error = patchResult.error;
          return { success: false, updatedFiles, error: patchResult.error };
        }

        updatedFiles[op.target] = patchResult.content;
        op.status = 'applied';
        op.appliedAt = Date.now();
        op.actualHashAfter = PatchEngine.calculateHash(patchResult.content);
        return { success: true, updatedFiles };
      }

      case 'DELETE_FILE': {
        const currentContent = updatedFiles[op.target];
        if (currentContent === undefined) {
          // File already deleted
          op.status = 'applied';
          return { success: true, updatedFiles };
        }
        const fresh = PatchEngine.verifyFreshness(currentContent, op.expectedHashBefore);
        if (!fresh.isFresh) {
          op.status = 'failed';
          op.error = fresh.reason;
          return { success: false, updatedFiles, error: fresh.reason };
        }
        delete updatedFiles[op.target];
        op.status = 'applied';
        op.appliedAt = Date.now();
        return { success: true, updatedFiles };
      }

      case 'RENAME_FILE': {
        if (!op.oldPath || updatedFiles[op.oldPath] === undefined) {
          const err = `Source file for rename not found: "${op.oldPath}"`;
          op.status = 'failed';
          op.error = err;
          return { success: false, updatedFiles, error: err };
        }
        const content = updatedFiles[op.oldPath];
        delete updatedFiles[op.oldPath];
        updatedFiles[op.target] = op.afterState || content;
        op.status = 'applied';
        op.appliedAt = Date.now();
        op.actualHashAfter = PatchEngine.calculateHash(updatedFiles[op.target]);
        return { success: true, updatedFiles };
      }
    }
  }
}
