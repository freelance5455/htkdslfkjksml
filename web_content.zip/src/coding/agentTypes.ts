/**
 * GODEX Phase 3 - Coding Agent & Safe Edit Engine Types
 * Strict safety boundary around PLAN -> INSPECT -> PROPOSE -> EDIT -> DIFF -> VALIDATE -> VERIFY -> COMPLETE
 */

import { ContextPack, SourceReference } from '../intelligence/contextTypes';
import { AgentRole } from '../types';

export type CodingAgentState =
  | 'IDLE'
  | 'ANALYZING'
  | 'PLANNING'
  | 'AWAITING_APPROVAL'
  | 'EDITING'
  | 'DIFF_READY'
  | 'VALIDATING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'BLOCKED'
  | 'CANCELLED';

export type ApprovalMode =
  | 'AUTO_APPROVED'
  | 'USER_APPROVAL_REQUIRED'
  | 'USER_APPROVED'
  | 'USER_REJECTED';

export type FileEditOperationType =
  | 'CREATE_FILE'
  | 'UPDATE_FILE'
  | 'DELETE_FILE'
  | 'RENAME_FILE';

export type PlanStepStatus =
  | 'pending'
  | 'in_progress'
  | 'completed'
  | 'failed';

export interface PlanStep {
  id: string;
  title: string;
  description: string;
  status: PlanStepStatus;
  targetFiles: string[];
  dependencies: string[];
  agent?: AgentRole;
  actionSummary?: string;
  reason?: string;
}

export interface ImplementationPlan {
  id: string;
  taskId: string;
  title: string;
  steps: PlanStep[];
  destructiveOperationsCount: number;
  totalFilesToTouch: string[];
  approvalRequired: boolean;
  approvalReason?: string;
  estimatedComplexity: 'low' | 'medium' | 'high';
  createdAt: number;
}

export interface PatchHunk {
  oldStart: number;
  oldLines: number;
  newStart: number;
  newLines: number;
  lines: string[];
}

export interface FileEditOperation {
  id: string;
  operation: FileEditOperationType;
  target: string;
  oldPath?: string;
  beforeState: string;
  afterState: string;
  reason: string;
  isDestructive: boolean;
  approvalRequired: boolean;
  expectedHashBefore?: string;
  actualHashAfter?: string;
  additions: number;
  deletions: number;
  patchHunks?: PatchHunk[];
  unifiedDiff?: string;
  status: 'proposed' | 'approved' | 'rejected' | 'applied' | 'failed' | 'reverted';
  error?: string;
  appliedAt?: number;
}

export type ValidationType =
  | 'TYPECHECK'
  | 'LINT'
  | 'UNIT_TEST'
  | 'BUILD'
  | 'AST_VALIDATION';

export type ValidationStatus =
  | 'NOT_RUN'
  | 'RUNNING'
  | 'PASSED'
  | 'FAILED'
  | 'BLOCKED';

export interface ValidationErrorItem {
  file?: string;
  line?: number;
  column?: number;
  message: string;
  code?: string;
}

export interface ValidationResult {
  name: string;
  type: ValidationType;
  status: ValidationStatus;
  command?: string;
  durationMs: number;
  stdoutSummary?: string;
  stderrSummary?: string;
  exitCode?: number;
  timestamp: number;
  errors?: ValidationErrorItem[];
}

export interface FailureAnalysis {
  failingFile?: string;
  errorType: string;
  relevantSymbol?: string;
  likelyCause: string;
  epistemic: 'KNOWN' | 'LIKELY' | 'UNKNOWN';
  proposedFixSummary?: string;
  suggestedAction?: string;
}

export interface AgentTask {
  id: string;
  userRequest: string;
  intent: string;
  status: CodingAgentState;
  plan?: ImplementationPlan;
  contextPack?: ContextPack;
  proposedChanges: FileEditOperation[];
  appliedChanges: FileEditOperation[];
  validationResults: ValidationResult[];
  verificationResults?: any;
  failureAnalysis?: FailureAnalysis;
  errors: string[];
  approvalStatus: ApprovalMode;
  rollbackAvailable: boolean;
  createdAt: number;
  updatedAt: number;
  iterationCount: number;
  maxIterations: number;
}

export type ToolPermissionTier = 'READ' | 'WRITE' | 'DELETE' | 'EXECUTE';

export interface ToolDefinition {
  name: string;
  description: string;
  tier: ToolPermissionTier;
  requiresApproval: boolean;
  handler: (args: any, context: ToolExecutionContext) => Promise<any>;
}

export interface ToolExecutionContext {
  workspaceFiles: Record<string, string>;
  taskId?: string;
  staleCheckTimestamp?: number;
  isApproved?: boolean;
}

export interface ToolCallAuditRecord {
  id: string;
  timestamp: number;
  toolName: string;
  tier: ToolPermissionTier;
  args: Record<string, any>;
  result: {
    success: boolean;
    data?: any;
    error?: string;
    durationMs: number;
  };
}
