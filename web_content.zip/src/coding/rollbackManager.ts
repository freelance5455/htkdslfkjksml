/**
 * GODEX Phase 3 - Rollback & Checkpoint Manager
 * Guarantees atomic reversibility for multi-file operations.
 * Allows instant rollback of any task without destroying unrelated user work.
 */

import { FileEditOperation } from './agentTypes';

export interface TaskCheckpoint {
  id: string;
  taskId: string;
  timestamp: number;
  description: string;
  filesBeforeSnapshot: Record<string, string>;
  appliedOperations: FileEditOperation[];
}

export class RollbackManager {
  private static checkpoints: TaskCheckpoint[] = [];
  private static maxCheckpoints = 20;

  /**
   * Captures a pre-execution snapshot before applying modifications
   */
  public static createCheckpoint(taskId: string, description: string, files: Record<string, string>): TaskCheckpoint {
    const checkpoint: TaskCheckpoint = {
      id: 'chk-' + Math.random().toString(36).slice(2, 9),
      taskId,
      timestamp: Date.now(),
      description,
      filesBeforeSnapshot: { ...files },
      appliedOperations: []
    };

    this.checkpoints.unshift(checkpoint);
    if (this.checkpoints.length > this.maxCheckpoints) {
      this.checkpoints.pop();
    }

    return checkpoint;
  }

  /**
   * Records an applied operation to the current checkpoint
   */
  public static recordOperation(taskId: string, operation: FileEditOperation): void {
    const cp = this.checkpoints.find(c => c.taskId === taskId);
    if (cp) {
      cp.appliedOperations.push(operation);
    }
  }

  /**
   * Reverts all changes applied during a specific task
   */
  public static rollbackTask(
    taskId: string,
    currentFiles: Record<string, string>
  ): { success: boolean; restoredFiles: Record<string, string>; message: string; revertedCount: number } {
    const cp = this.checkpoints.find(c => c.taskId === taskId);
    if (!cp) {
      return {
        success: false,
        restoredFiles: currentFiles,
        message: `No checkpoint found for Task ID: ${taskId}`,
        revertedCount: 0
      };
    }

    const workingFiles = { ...currentFiles };
    let revertedCount = 0;

    // Restore each file that was modified/created/deleted in this checkpoint
    for (const op of cp.appliedOperations) {
      const original = cp.filesBeforeSnapshot[op.target];
      if (original !== undefined) {
        // File existed before -> restore original content
        workingFiles[op.target] = original;
        revertedCount++;
      } else {
        // File was newly created -> remove it
        delete workingFiles[op.target];
        revertedCount++;
      }
    }

    return {
      success: true,
      restoredFiles: workingFiles,
      message: `Successfully rolled back Task ${taskId} (${revertedCount} files restored to pre-task state)`,
      revertedCount
    };
  }

  /**
   * Reverts the most recent task changes
   */
  public static undoLastChange(
    currentFiles: Record<string, string>
  ): { success: boolean; restoredFiles: Record<string, string>; message: string; revertedCount: number } {
    if (this.checkpoints.length === 0) {
      return {
        success: false,
        restoredFiles: currentFiles,
        message: 'No recent agent changes available to undo',
        revertedCount: 0
      };
    }

    const latest = this.checkpoints[0];
    return this.rollbackTask(latest.taskId, currentFiles);
  }

  /**
   * Returns list of checkpoints available for rollback
   */
  public static getCheckpoints(): TaskCheckpoint[] {
    return [...this.checkpoints];
  }

  /**
   * Clears all checkpoints (e.g. on workspace reset)
   */
  public static clear(): void {
    this.checkpoints = [];
  }
}
