/**
 * GODEX Phase 3 - Simulation & Comprehensive Test Suite
 * Validates all state transitions, patch safety, stale edit detection,
 * file operations, diff generation, rollback, approval rules, tool permissions, and simulation project.
 */

import { FileEditEngine } from './fileEditEngine';
import { PatchEngine } from './patchEngine';
import { DiffGenerator } from './diffGenerator';
import { RollbackManager } from './rollbackManager';
import { ValidationEngine } from './validationEngine';
import { ToolSystem } from './toolSystem';
import { CodingAgent } from './codingAgent';
import { SecuritySanitizer } from './securitySanitizer';

export interface TestResultItem {
  id: string;
  name: string;
  category: 'state_machine' | 'patch_engine' | 'stale_detection' | 'file_ops' | 'diff' | 'rollback' | 'approvals' | 'tools' | 'validation' | 'simulation';
  passed: boolean;
  message: string;
  details?: string;
  durationMs: number;
}

export interface FullTestSuiteResult {
  passed: boolean;
  total: number;
  passedCount: number;
  failedCount: number;
  results: TestResultItem[];
  timestamp: number;
}

export class SimulationTestSuite {
  public static async runAllTests(): Promise<FullTestSuiteResult> {
    const results: TestResultItem[] = [];

    // Test 1: State Machine & Task Creation
    const t1Start = Date.now();
    try {
      const task = CodingAgent.createTask('Add authentication middleware', 'IMPLEMENT');
      const valid = task.status === 'IDLE' && task.approvalStatus === 'AUTO_APPROVED';
      results.push({
        id: 'test-1-state-machine',
        name: 'State Machine & Task Initialization',
        category: 'state_machine',
        passed: valid,
        message: valid ? 'Initial state correctly established as IDLE with typed task model' : 'Task model state failed',
        durationMs: Date.now() - t1Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-1-state-machine',
        name: 'State Machine & Task Initialization',
        category: 'state_machine',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t1Start
      });
    }

    // Test 2: Patch Validation & Normal Application
    const t2Start = Date.now();
    try {
      const original = 'function greet() {\n  return "hello";\n}';
      const modified = 'function greet() {\n  return "hello world";\n}';
      const diff = DiffGenerator.compute('src/greet.ts', original, modified);
      const applyRes = PatchEngine.applyPatch(original, diff.hunks, modified, PatchEngine.calculateHash(original));

      const passed = applyRes.success && applyRes.content === modified && diff.additions === 1 && diff.deletions === 1;
      results.push({
        id: 'test-2-patch-application',
        name: 'Patch Application & Diff Accuracy',
        category: 'patch_engine',
        passed,
        message: passed ? 'Patch engine accurately computed +1/-1 diff and applied changes' : 'Patch failed',
        durationMs: Date.now() - t2Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-2-patch-application',
        name: 'Patch Application & Diff Accuracy',
        category: 'patch_engine',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t2Start
      });
    }

    // Test 3: Stale Patch & Concurrency Safety Detection
    const t3Start = Date.now();
    try {
      const originalAtContext = 'const count = 10;';
      const oldHash = PatchEngine.calculateHash(originalAtContext);
      const userModifiedConcurrently = 'const count = 20; // user edited';
      
      const patchRes = PatchEngine.applyPatch(
        userModifiedConcurrently,
        undefined,
        'const count = 100;',
        oldHash // Stale expected hash
      );

      const passed = !patchRes.success && patchRes.staleDetected === true;
      results.push({
        id: 'test-3-stale-detection',
        name: 'Stale Edit & Concurrency Conflict Detection',
        category: 'stale_detection',
        passed,
        message: passed ? 'Successfully blocked stale edit when file hash diverged from context baseline' : 'Failed to block stale edit',
        durationMs: Date.now() - t3Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-3-stale-detection',
        name: 'Stale Edit & Concurrency Conflict Detection',
        category: 'stale_detection',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t3Start
      });
    }

    // Test 4: Controlled File Edit Operations (CREATE, UPDATE, DELETE, RENAME)
    const t4Start = Date.now();
    try {
      let workspace: Record<string, string> = { 'src/old.ts': 'export const v = 1;' };

      // CREATE
      const createOp = FileEditEngine.proposeOperation('CREATE_FILE', 'src/new.ts', '', 'export const n = 2;', 'New module');
      const r1 = FileEditEngine.applyOperation(createOp, workspace);
      workspace = r1.updatedFiles;

      // UPDATE
      const updateOp = FileEditEngine.proposeOperation('UPDATE_FILE', 'src/new.ts', 'export const n = 2;', 'export const n = 3;', 'Update value');
      const r2 = FileEditEngine.applyOperation(updateOp, workspace);
      workspace = r2.updatedFiles;

      // RENAME
      const renameOp = FileEditEngine.proposeOperation('RENAME_FILE', 'src/renamed.ts', 'export const v = 1;', 'export const v = 1;', 'Rename file', 'src/old.ts');
      const r3 = FileEditEngine.applyOperation(renameOp, workspace);
      workspace = r3.updatedFiles;

      // DELETE
      const deleteOp = FileEditEngine.proposeOperation('DELETE_FILE', 'src/new.ts', 'export const n = 3;', '', 'Delete temp');
      const r4 = FileEditEngine.applyOperation(deleteOp, workspace);
      workspace = r4.updatedFiles;

      const passed = workspace['src/new.ts'] === undefined && workspace['src/old.ts'] === undefined && workspace['src/renamed.ts'] !== undefined;
      results.push({
        id: 'test-4-file-ops',
        name: 'Controlled File Operations (CREATE, UPDATE, RENAME, DELETE)',
        category: 'file_ops',
        passed,
        message: passed ? 'All 4 file operations executed with complete audit records' : 'File operations error',
        durationMs: Date.now() - t4Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-4-file-ops',
        name: 'Controlled File Operations',
        category: 'file_ops',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t4Start
      });
    }

    // Test 5: Rollback & Checkpoint Manager
    const t5Start = Date.now();
    try {
      const initialWorkspace: Record<string, string> = {
        'src/App.tsx': 'export default function App() { return <div>Original</div>; }',
        'src/index.css': 'body { margin: 0; }'
      };

      const taskId = 'test-task-rollback';
      RollbackManager.createCheckpoint(taskId, 'Before modifying App.tsx', initialWorkspace);

      let modifiedWorkspace = { ...initialWorkspace };
      const op = FileEditEngine.proposeOperation('UPDATE_FILE', 'src/App.tsx', initialWorkspace['src/App.tsx'], 'export default function App() { return <div>MODIFIED</div>; }', 'Change UI');
      const appRes = FileEditEngine.applyOperation(op, modifiedWorkspace);
      modifiedWorkspace = appRes.updatedFiles;
      RollbackManager.recordOperation(taskId, op);

      // Rollback
      const rollbackRes = RollbackManager.rollbackTask(taskId, modifiedWorkspace);
      const passed = rollbackRes.success && rollbackRes.restoredFiles['src/App.tsx'] === initialWorkspace['src/App.tsx'];

      results.push({
        id: 'test-5-rollback',
        name: 'Atomic Rollback & State Restoration',
        category: 'rollback',
        passed,
        message: passed ? 'Rollback safely restored exact pre-task file snapshot' : 'Rollback failed',
        durationMs: Date.now() - t5Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-5-rollback',
        name: 'Atomic Rollback & State Restoration',
        category: 'rollback',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t5Start
      });
    }

    // Test 6: Approval Boundaries & Destructive Risk Protection
    const t6Start = Date.now();
    try {
      // 1. File Deletion risk
      const delOp = FileEditEngine.assessDestructiveRisk('DELETE_FILE', 'src/auth.ts', 'code', '');
      
      // 2. Package.json dependency addition risk
      const pkgBefore = JSON.stringify({ dependencies: { react: '^18.0.0' } });
      const pkgAfter = JSON.stringify({ dependencies: { react: '^18.0.0', zod: '^3.22.0' } });
      const depOp = FileEditEngine.assessDestructiveRisk('UPDATE_FILE', 'package.json', pkgBefore, pkgAfter);

      // 3. Large changeset evaluation (>4 files)
      const fakeOps = [1, 2, 3, 4, 5].map(i => FileEditEngine.proposeOperation('UPDATE_FILE', `src/file${i}.ts`, 'old', 'new', 'edit'));
      const batchEval = FileEditEngine.evaluateBatchApproval(fakeOps);

      const passed = delOp.requiresApproval && depOp.requiresApproval && batchEval.approvalRequired;
      results.push({
        id: 'test-6-approval-boundaries',
        name: 'Approval Rules: Destructive, Dependency & Large Changesets',
        category: 'approvals',
        passed,
        message: passed ? 'All 3 security triggers correctly required user approval' : 'Approval trigger failed',
        durationMs: Date.now() - t6Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-6-approval-boundaries',
        name: 'Approval Rules',
        category: 'approvals',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t6Start
      });
    }

    // Test 7: Tool Permission Tiers & Audit System
    const t7Start = Date.now();
    try {
      const workspace = { 'src/secret.ts': 'export const API_KEY = "sk-1234567890abcdef1234567890abcdef";' };
      
      // READ tool (safe)
      const readRes = await ToolSystem.executeTool('READ_FILE', { path: 'src/secret.ts' }, { workspaceFiles: workspace });
      
      // DELETE tool without approval (must be blocked)
      const delBlocked = await ToolSystem.executeTool('DELETE_FILE', { path: 'src/secret.ts' }, { workspaceFiles: workspace, isApproved: false });

      const passed = readRes.success && !delBlocked.success && delBlocked.error?.includes('approval');
      results.push({
        id: 'test-7-tool-permissions',
        name: 'Tool Permission Boundaries (READ safe vs DELETE blocked)',
        category: 'tools',
        passed,
        message: passed ? 'READ executed safely; unapproved DELETE blocked strictly' : 'Tool boundary check failed',
        durationMs: Date.now() - t7Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-7-tool-permissions',
        name: 'Tool Permission Boundaries',
        category: 'tools',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t7Start
      });
    }

    // Test 8: Secret Sanitization
    const t8Start = Date.now();
    try {
      const secretText = 'const token = "ghp_123456789012345678901234567890123456";\nconst key = "AIzaSyD_FakeGoogleKey123456789012345";';
      const sanitized = SecuritySanitizer.redact(secretText);
      const passed = !sanitized.includes('ghp_123456789012345678901234567890123456') && sanitized.includes('[REDACTED');
      results.push({
        id: 'test-8-security-sanitizer',
        name: 'Security Sanitizer & Token Redaction',
        category: 'approvals',
        passed,
        message: passed ? 'All tokens and API keys redacted before leaving security boundary' : 'Secret leak detected',
        durationMs: Date.now() - t8Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-8-security-sanitizer',
        name: 'Security Sanitizer',
        category: 'approvals',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t8Start
      });
    }

    // Test 9: Validation Engine & Truthful Scripts
    const t9Start = Date.now();
    try {
      const testFiles = {
        'package.json': JSON.stringify({ scripts: { build: 'vite build', lint: 'eslint' } }),
        'src/main.ts': 'export const x: number = 10;'
      };
      const scripts = ValidationEngine.detectProjectScripts(testFiles);
      const astCheck = ValidationEngine.validateASTSyntax(testFiles);

      const passed = scripts.hasBuild && scripts.hasLint && astCheck.status === 'PASSED';
      results.push({
        id: 'test-9-validation-engine',
        name: 'Validation Engine & Project Script Detection',
        category: 'validation',
        passed,
        message: passed ? 'Detected actual package.json scripts and verified AST syntax' : 'Validation check failed',
        durationMs: Date.now() - t9Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-9-validation-engine',
        name: 'Validation Engine',
        category: 'validation',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t9Start
      });
    }

    // Test 10: Complete Deterministic Simulation Project (End-to-End Loop)
    const t10Start = Date.now();
    try {
      const mockProject: Record<string, string> = {
        'package.json': JSON.stringify({
          name: 'auth-demo',
          version: '1.0.0',
          scripts: { build: 'tsc', test: 'vitest' }
        }),
        'src/user.ts': `export interface User {\n  id: string;\n  email: string;\n  name?: string;\n}\n`,
        'src/auth.ts': `import { User } from './user';\n\nexport class AuthManager {\n  private users: User[] = [];\n}\n`,
        'src/auth.test.ts': `import { AuthManager } from './auth';\n// Auth tests\n`
      };

      const simResult = await CodingAgent.startTask(
        'Add a validateUser() function to validate user email and name.',
        mockProject,
        'src/user.ts',
        { autoApproveSafe: true }
      );

      const passed = simResult.success &&
        simResult.task.status === 'COMPLETED' &&
        simResult.task.plan !== undefined &&
        simResult.task.appliedChanges.length > 0 &&
        simResult.updatedFiles['src/user.ts'].includes('validateUser') &&
        simResult.task.validationResults.some(v => v.status === 'PASSED');

      results.push({
        id: 'test-10-simulation-loop',
        name: 'Deterministic End-to-End Simulation Test (Plan -> Edit -> Diff -> Validate -> Complete)',
        category: 'simulation',
        passed,
        message: passed
          ? 'End-to-end coding agent loop verified: Plan generated, patch applied, diff verified, AST validated, response formatted.'
          : `Simulation failed (State: ${simResult.task.status})`,
        durationMs: Date.now() - t10Start
      });
    } catch (e: any) {
      results.push({
        id: 'test-10-simulation-loop',
        name: 'Deterministic End-to-End Simulation Test',
        category: 'simulation',
        passed: false,
        message: e.message,
        durationMs: Date.now() - t10Start
      });
    }

    const passedCount = results.filter(r => r.passed).length;
    const failedCount = results.length - passedCount;

    return {
      passed: failedCount === 0,
      total: results.length,
      passedCount,
      failedCount,
      results,
      timestamp: Date.now()
    };
  }
}
