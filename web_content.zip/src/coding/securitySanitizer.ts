/**
 * GODEX Phase 3 - Security & Secret Protection Sanitizer
 * Masks credentials, .env variables, private keys, and API tokens
 * to ensure sensitive values are never leaked in diffs, logs, or chat.
 */

export class SecuritySanitizer {
  private static SECRET_PATTERNS: RegExp[] = [
    // API keys & Bearer tokens
    /(AIzaSy[a-zA-Z0-9_-]{33})/gi,
    /(sk-[a-zA-Z0-9]{32,})/gi,
    /(Bearer\s+)[a-zA-Z0-9_.\-~+/]+=*/gi,
    /(ghp_[a-zA-Z0-9]{36})/gi,
    /(gho_[a-zA-Z0-9]{36})/gi,
    /(glpat-[a-zA-Z0-9_-]{20,})/gi,
    
    // Key/Secret assignment in env / config
    /(['"]?(?:API_KEY|SECRET|PASSWORD|AUTH_TOKEN|PRIVATE_KEY|TOKEN|ACCESS_TOKEN|CLIENT_SECRET)['"]?\s*[:=]\s*['"])([^'"\n\r]{4,})(['"])/gi,
    
    // Private Key blocks
    /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----[\s\S]+?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/gi
  ];

  /**
   * Redacts sensitive secrets from any text string or diff output
   */
  public static redact(text: string): string {
    if (!text || typeof text !== 'string') return text;

    let sanitized = text;

    // Redact Private Key blocks
    sanitized = sanitized.replace(
      /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----[\s\S]+?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/gi,
      '-----BEGIN PRIVATE KEY-----\n[REDACTED_BY_GODEX_SECURITY]\n-----END PRIVATE KEY-----'
    );

    // Redact assignments
    sanitized = sanitized.replace(
      /(['"]?(?:API_KEY|SECRET|PASSWORD|AUTH_TOKEN|PRIVATE_KEY|TOKEN|ACCESS_TOKEN|CLIENT_SECRET|DATABASE_URL)['"]?\s*[:=]\s*['"])([^'"\n\r]{4,})(['"])/gi,
      (_match, p1, p2, p3) => {
        const masked = p2.length > 8 ? `${p2.slice(0, 3)}...[REDACTED]...${p2.slice(-2)}` : '[REDACTED]';
        return `${p1}${masked}${p3}`;
      }
    );

    // Redact raw tokens
    for (const pattern of this.SECRET_PATTERNS) {
      sanitized = sanitized.replace(pattern, (match) => {
        if (match.startsWith('Bearer ')) {
          return 'Bearer [REDACTED_TOKEN]';
        }
        if (match.length > 10) {
          return `${match.slice(0, 4)}...[REDACTED]...${match.slice(-2)}`;
        }
        return '[REDACTED_SECRET]';
      });
    }

    return sanitized;
  }

  /**
   * Detects if content contains unmasked secrets
   */
  public static detectSecrets(content: string): boolean {
    if (!content || typeof content !== 'string') return false;
    for (const pattern of this.SECRET_PATTERNS) {
      pattern.lastIndex = 0;
      if (pattern.test(content)) return true;
    }
    return false;
  }

  /**
   * Checks if a file path represents a sensitive security target
   */
  public static isSensitivePath(filePath: string): boolean {
    const lower = filePath.toLowerCase();
    return (
      lower === '.env' ||
      lower.startsWith('.env.') ||
      lower.includes('id_rsa') ||
      lower.includes('.pem') ||
      lower.includes('.key') ||
      lower.includes('credentials.json') ||
      lower.includes('service-account')
    );
  }

  /**
   * Checks if content has potentially dangerous SQL destruction
   */
  public static detectDangerousDatabaseOperations(content: string): { dangerous: boolean; reason?: string } {
    const lower = content.toLowerCase();
    if (/\bdrop\s+table\b/i.test(lower)) {
      return { dangerous: true, reason: 'Contains destructive DROP TABLE SQL statement' };
    }
    if (/\bdrop\s+database\b/i.test(lower)) {
      return { dangerous: true, reason: 'Contains destructive DROP DATABASE SQL statement' };
    }
    if (/\btruncate\s+table\b/i.test(lower)) {
      return { dangerous: true, reason: 'Contains TRUNCATE TABLE statement which destroys all rows' };
    }
    if (/\bdelete\s+from\b/i.test(lower) && !/\bwhere\b/i.test(lower)) {
      return { dangerous: true, reason: 'Contains unbounded DELETE FROM without WHERE clause' };
    }
    return { dangerous: false };
  }
}
