/**
 * GODEX Phase 3 - Real Evidence Validation Engine
 * Detects actual package.json scripts and runs AST & syntax validation.
 * Performs failure diagnosis with KNOWN / LIKELY / UNKNOWN epistemic categories.
 */

import { 
  ValidationResult, 
  ValidationType, 
  FailureAnalysis, 
  ValidationErrorItem 
} from './agentTypes';
import { AstParser } from '../intelligence/astParser';
import { ExecutionEngine } from '../execution/executor';

export interface ProjectScripts {
  hasTypecheck: boolean;
  typecheckScript?: string;
  hasLint: boolean;
  lintScript?: string;
  hasBuild: boolean;
  buildScript?: string;
  hasTest: boolean;
  testScript?: string;
}

export class ValidationEngine {
  /**
   * Reads package.json to discover actual declared scripts
   */
  public static detectProjectScripts(workspaceFiles: Record<string, string>): ProjectScripts {
    const pkgContent = workspaceFiles['package.json'];
    if (!pkgContent) {
      return { hasTypecheck: false, hasLint: false, hasBuild: false, hasTest: false };
    }

    try {
      const pkg = JSON.parse(pkgContent);
      const scripts = pkg.scripts || {};

      return {
        hasTypecheck: !!(scripts.typecheck || scripts['check-types'] || scripts.tsc),
        typecheckScript: scripts.typecheck || scripts['check-types'] || scripts.tsc,
        hasLint: !!(scripts.lint || scripts.eslint),
        lintScript: scripts.lint || scripts.eslint,
        hasBuild: !!scripts.build,
        buildScript: scripts.build,
        hasTest: !!(scripts.test || scripts['test:unit']),
        testScript: scripts.test || scripts['test:unit']
      };
    } catch {
      return { hasTypecheck: false, hasLint: false, hasBuild: false, hasTest: false };
    }
  }

  /**
   * Runs local AST & syntax validation across all TypeScript / JavaScript files
   */
  public static validateASTSyntax(workspaceFiles: Record<string, string>): ValidationResult {
    const startTime = Date.now();
    const errors: ValidationErrorItem[] = [];

    for (const [path, content] of Object.entries(workspaceFiles)) {
      if (path.endsWith('.ts') || path.endsWith('.tsx') || path.endsWith('.js') || path.endsWith('.jsx')) {
        const fileErrors = AstParser.validateSyntax(content, path);
        if (fileErrors.length > 0) {
          for (const err of fileErrors) {
            errors.push({
              file: path,
              line: err.line || 1,
              column: err.column || 1,
              message: err.message,
              code: 'AST_SYNTAX_ERROR'
            });
          }
        }
      }
    }

    const durationMs = Date.now() - startTime;
    const passed = errors.length === 0;

    return {
      name: 'AST & Syntax Integrity',
      type: 'AST_VALIDATION',
      status: passed ? 'PASSED' : 'FAILED',
      command: 'internal:ast-parser --all-files',
      durationMs,
      stdoutSummary: passed ? `Parsed ${Object.keys(workspaceFiles).length} files without syntax errors` : undefined,
      stderrSummary: !passed ? `${errors.length} syntax error(s) detected in workspace` : undefined,
      exitCode: passed ? 0 : 1,
      timestamp: Date.now(),
      errors: passed ? undefined : errors
    };
  }

  /**
   * Validates import consistency across the workspace (ensures imported local files actually exist)
   */
  public static validateImports(workspaceFiles: Record<string, string>): ValidationResult {
    const startTime = Date.now();
    const errors: ValidationErrorItem[] = [];
    const filePaths = new Set(Object.keys(workspaceFiles));

    for (const [path, content] of Object.entries(workspaceFiles)) {
      if (!path.endsWith('.ts') && !path.endsWith('.tsx') && !path.endsWith('.js') && !path.endsWith('.jsx')) {
        continue;
      }

      const importMatches = content.matchAll(/(?:import|from)\s+['"](\.[^'"]+)['"]/g);
      for (const m of importMatches) {
        const relativeImport = m[1];
        // Resolve relative path
        const currentDir = path.split('/').slice(0, -1).join('/');
        let resolved = (currentDir ? `${currentDir}/${relativeImport}` : relativeImport).replace(/\/\.\//g, '/');

        // Handle .. segments
        const parts = resolved.split('/');
        const normalizedParts: string[] = [];
        for (const p of parts) {
          if (p === '..') normalizedParts.pop();
          else if (p !== '.') normalizedParts.push(p);
        }
        resolved = normalizedParts.join('/');

        // Check extensions (.ts, .tsx, .js, .jsx, /index.ts, /index.tsx)
        const possibleTargets = [
          resolved,
          `${resolved}.ts`,
          `${resolved}.tsx`,
          `${resolved}.js`,
          `${resolved}.jsx`,
          `${resolved}/index.ts`,
          `${resolved}/index.tsx`
        ];

        const found = possibleTargets.some(t => filePaths.has(t));
        if (!found) {
          errors.push({
            file: path,
            message: `Cannot resolve module '${relativeImport}'. Target file does not exist in workspace.`,
            code: 'TS2307'
          });
        }
      }
    }

    const durationMs = Date.now() - startTime;
    const passed = errors.length === 0;

    return {
      name: 'TypeScript Module Resolution',
      type: 'TYPECHECK',
      status: passed ? 'PASSED' : 'FAILED',
      command: 'internal:module-resolver',
      durationMs,
      stdoutSummary: passed ? 'All relative imports resolved successfully' : undefined,
      stderrSummary: !passed ? `Failed to resolve ${errors.length} import(s)` : undefined,
      exitCode: passed ? 0 : 1,
      timestamp: Date.now(),
      errors: passed ? undefined : errors
    };
  }

  /**
   * Executes the complete suite of available validations
   */
  public static async runAllValidations(
    workspaceFiles: Record<string, string>,
    scripts: ProjectScripts
  ): Promise<{ results: ValidationResult[]; overallPassed: boolean }> {
    const results: ValidationResult[] = [];

    // 1. Local AST validation (Always run)
    const astRes = this.validateASTSyntax(workspaceFiles);
    results.push(astRes);

    // 2. Module Resolution & Import checking
    const importRes = this.validateImports(workspaceFiles);
    results.push(importRes);

    // 3. Controlled Execution Typecheck & Build via ExecutionEngine
    try {
      const typeRes = await ExecutionEngine.executeProjectScript('TYPECHECK', workspaceFiles, {
        requestedBy: 'SYSTEM_VALIDATION',
        reason: 'Pre-flight Typecheck'
      });

      results.push({
        name: 'TypeScript Compiler Check',
        type: 'TYPECHECK',
        status: typeRes.status === 'COMPLETED' ? 'PASSED' : 'FAILED',
        command: typeRes.command,
        durationMs: typeRes.durationMs,
        stdoutSummary: typeRes.stdout ? typeRes.evidence.outputSummary : undefined,
        stderrSummary: typeRes.stderr || undefined,
        exitCode: typeRes.exitCode,
        timestamp: Date.now()
      });

      const buildRes = await ExecutionEngine.executeProjectScript('BUILD', workspaceFiles, {
        requestedBy: 'SYSTEM_VALIDATION',
        reason: 'Pre-flight Build Bundling'
      });

      results.push({
        name: 'Vite Production Bundler',
        type: 'BUILD',
        status: buildRes.status === 'COMPLETED' ? 'PASSED' : 'FAILED',
        command: buildRes.command,
        durationMs: buildRes.durationMs,
        stdoutSummary: buildRes.stdout ? buildRes.evidence.outputSummary : undefined,
        stderrSummary: buildRes.stderr || undefined,
        exitCode: buildRes.exitCode,
        timestamp: Date.now()
      });
    } catch {
      // Fallback in case of execution engine errors
    }

    const overallPassed = results.every(r => r.status === 'PASSED');
    return { results, overallPassed };
  }

  /**
   * Diagnoses root cause from validation errors
   */
  public static diagnoseFailure(results: ValidationResult[]): FailureAnalysis | undefined {
    const failed = results.find(r => r.status === 'FAILED' && r.errors && r.errors.length > 0);
    if (!failed || !failed.errors || failed.errors.length === 0) {
      return undefined;
    }

    const firstErr = failed.errors[0];
    const file = firstErr.file;
    const msg = firstErr.message;

    if (msg.includes('Cannot resolve module') || msg.includes('TS2307')) {
      return {
        failingFile: file,
        errorType: 'MISSING_MODULE_IMPORT',
        likelyCause: `Target module file is missing or has a typo in import path in ${file}.`,
        epistemic: 'KNOWN',
        proposedFixSummary: 'Verify target file exists in workspace and correct the relative import path.'
      };
    }

    if (msg.includes('Unexpected token') || msg.includes('SyntaxError') || msg.includes('Parse error')) {
      return {
        failingFile: file,
        errorType: 'SYNTAX_ERROR',
        likelyCause: `Unclosed bracket, parenthesis, or invalid JSX syntax near line ${firstErr.line || 1}.`,
        epistemic: 'KNOWN',
        proposedFixSummary: 'Check and balance JSX tags and curly braces in the modified region.'
      };
    }

    return {
      failingFile: file,
      errorType: 'TYPE_OR_COMPILATION_ERROR',
      likelyCause: msg,
      epistemic: 'LIKELY',
      proposedFixSummary: 'Check parameter types and exported signatures.'
    };
  }
}
