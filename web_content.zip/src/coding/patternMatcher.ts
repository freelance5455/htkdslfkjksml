/**
 * GODEX Phase 3 - Pattern Matcher & Style Preserver
 * Analyzes existing workspace files to identify and preserve project conventions:
 * - Naming conventions (camelCase, PascalCase)
 * - Import styles (named vs default, double vs single quotes)
 * - Error handling styles (try/catch vs Result objects)
 * - Component patterns (functional with hooks, explicit return types)
 */

export interface ProjectStyleProfile {
  quotes: 'single' | 'double';
  semi: boolean;
  indent: '2 spaces' | '4 spaces' | 'tabs';
  exportStyle: 'named' | 'default' | 'mixed';
  hasLucideIcons: boolean;
  hasTailwind: boolean;
  commonImports: string[];
}

export class PatternMatcher {
  /**
   * Profiles the existing project's conventions
   */
  public static analyzeConventions(workspaceFiles: Record<string, string>): ProjectStyleProfile {
    let singleQuoteCount = 0;
    let doubleQuoteCount = 0;
    let semiCount = 0;
    let noSemiCount = 0;
    let hasLucide = false;
    let hasTailwind = false;
    const importsSet = new Set<string>();

    for (const [path, content] of Object.entries(workspaceFiles)) {
      if (!path.endsWith('.ts') && !path.endsWith('.tsx') && !path.endsWith('.js') && !path.endsWith('.jsx')) {
        continue;
      }

      // Check quotes
      singleQuoteCount += (content.match(/'/g) || []).length;
      doubleQuoteCount += (content.match(/"/g) || []).length;

      // Check semicolons on statement lines
      const lines = content.split('\n');
      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.length > 5 && !trimmed.startsWith('//') && !trimmed.startsWith('/*')) {
          if (trimmed.endsWith(';')) semiCount++;
          else if (trimmed.endsWith('}') || trimmed.endsWith('{') || trimmed.endsWith(',')) {
            // ignore
          } else {
            noSemiCount++;
          }
        }
      }

      if (content.includes('lucide-react')) hasLucide = true;
      if (content.includes('className="') || content.includes("className='")) hasTailwind = true;

      // Collect top imports
      const impMatches = content.matchAll(/from\s+['"]([^'"]+)['"]/g);
      for (const m of impMatches) {
        importsSet.add(m[1]);
      }
    }

    return {
      quotes: singleQuoteCount >= doubleQuoteCount ? 'single' : 'double',
      semi: semiCount >= noSemiCount,
      indent: '2 spaces',
      exportStyle: 'named',
      hasLucideIcons: hasLucide,
      hasTailwind,
      commonImports: Array.from(importsSet).slice(0, 8)
    };
  }

  /**
   * Generates a concise prompt injection describing existing project conventions
   */
  public static generateConventionsGuide(profile: ProjectStyleProfile): string {
    return [
      'PROJECT CODING CONVENTIONS:',
      `- Preferred quotes: ${profile.quotes === 'single' ? "Single quotes ('')" : 'Double quotes ("")'}`,
      `- Semicolons: ${profile.semi ? 'Use semicolons' : 'No semicolons'}`,
      `- Icons: ${profile.hasLucideIcons ? 'Use lucide-react for all iconography' : 'Standard SVG'}`,
      `- Styling: ${profile.hasTailwind ? 'Tailwind CSS utility classes' : 'Standard CSS'}`,
      `- Maintain existing import ordering and TypeScript type annotations.`
    ].join('\n');
  }
}
