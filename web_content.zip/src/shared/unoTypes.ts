export type Side = 'light' | 'dark';

export type LightColor = 'red' | 'blue' | 'green' | 'yellow';
export type DarkColor = 'pink' | 'teal' | 'orange' | 'purple';
export type CardColor = LightColor | DarkColor | 'wild';
export type ActiveColor = LightColor | DarkColor;

export type LightValue =
  | '1'
  | '2'
  | '3'
  | '4'
  | '5'
  | '6'
  | '7'
  | '8'
  | '9'
  | 'draw1'
  | 'skip'
  | 'reverse'
  | 'flip'
  | 'wild'
  | 'wild_draw2';

export type DarkValue =
  | '1'
  | '2'
  | '3'
  | '4'
  | '5'
  | '6'
  | '7'
  | '8'
  | '9'
  | 'draw5'
  | 'skip_all'
  | 'reverse'
  | 'flip'
  | 'wild'
  | 'wild_draw_color';

export interface CardFace {
  color: CardColor;
  value: LightValue | DarkValue;
}

export interface UnoCardData {
  id: string;
  light: CardFace;
  dark: CardFace;
}

export type AvatarId = 'spade' | 'diamond' | 'flame' | 'bolt' | 'crown' | 'prism';

export type RoomPhase = 'LOBBY' | 'PLAYING' | 'ROUND_OVER' | 'GAME_OVER';

export interface RoomSettings {
  targetScore: number; // 0 = single quick round, 500 = championship
  turnSeconds: number; // 0 = untimed, 25 = 25s turn timer
}

export interface PublicPlayer {
  id: string;
  name: string;
  avatar: AvatarId;
  isBot: boolean;
  isHost: boolean;
  connected: boolean;
  cardCount: number;
  score: number;
  calledUno: boolean;
  unoVulnerable: boolean;
}

export interface ActionLogEntry {
  id: string;
  text: string;
  timestamp: number;
  tone: 'neutral' | 'action' | 'flip' | 'uno' | 'penalty' | 'win';
}

export interface EmoteBubble {
  id: string;
  playerId: string;
  playerName: string;
  text: string;
  timestamp: number;
}

export interface RoundSummary {
  roundNumber: number;
  winnerId: string;
  winnerName: string;
  pointsEarned: number;
  playerBreakdowns: Array<{
    playerId: string;
    playerName: string;
    remainingCards: number;
    handPoints: number;
    totalScore: number;
  }>;
}

export type SoundCue =
  | 'play'
  | 'draw'
  | 'flip_dark'
  | 'flip_light'
  | 'action'
  | 'uno'
  | 'penalty'
  | 'win'
  | 'turn';

export interface PublicRoomState {
  code: string;
  phase: RoomPhase;
  settings: RoomSettings;
  roundNumber: number;
  activeSide: Side;
  activeColor: ActiveColor;
  direction: 1 | -1;
  currentTurnIndex: number;
  turnDeadline: number | null;
  drawPileCount: number;
  topCard: UnoCardData | null;
  previousCard: UnoCardData | null;
  players: PublicPlayer[];
  myId: string;
  myHand: UnoCardData[];
  pendingDrawnCardId: string | null;
  pendingFlipColorPickerPlayerId: string | null;
  lastCue: { id: string; cue: SoundCue } | null;
  lastEventText: string;
  actionLog: ActionLogEntry[];
  emotes: EmoteBubble[];
  roundSummary: RoundSummary | null;
  matchWinnerId: string | null;
}

export type ClientMessage =
  | { type: 'create_room'; name: string; avatar: AvatarId; soloWithBots?: boolean }
  | { type: 'join_room'; code: string; name: string; avatar: AvatarId; playerId?: string }
  | { type: 'reconnect_room'; code: string; playerId: string }
  | { type: 'leave_room' }
  | { type: 'add_bot' }
  | { type: 'remove_player'; targetId: string }
  | { type: 'update_settings'; settings: Partial<RoomSettings> }
  | { type: 'start_game' }
  | { type: 'play_card'; cardId: string; chosenColor?: ActiveColor }
  | { type: 'choose_flip_color'; chosenColor: ActiveColor }
  | { type: 'draw_card' }
  | { type: 'play_drawn_card'; chosenColor?: ActiveColor }
  | { type: 'pass_after_draw' }
  | { type: 'call_uno' }
  | { type: 'catch_uno'; targetId: string }
  | { type: 'send_emote'; text: string }
  | { type: 'next_round' }
  | { type: 'play_again' };

export type ServerMessage =
  | { type: 'room_joined'; code: string; playerId: string }
  | { type: 'state_sync'; state: PublicRoomState }
  | { type: 'error'; message: string }
  | { type: 'left_room' };

export const LIGHT_COLORS: LightColor[] = ['red', 'blue', 'green', 'yellow'];
export const DARK_COLORS: DarkColor[] = ['pink', 'teal', 'orange', 'purple'];

export const COLOR_LABELS_ID: Record<ActiveColor, string> = {
  red: 'Merah',
  blue: 'Biru',
  green: 'Hijau',
  yellow: 'Kuning',
  pink: 'Pink',
  teal: 'Teal',
  orange: 'Oranye',
  purple: 'Ungu',
};
