import { UpgradeDetailType } from './cocData';

export interface CocCatalogEntry {
  name: string;
  nameRu: string;
  detailType: UpgradeDetailType;
  categoryGroup: 'townhall' | 'defense' | 'trap' | 'wall' | 'resource_army' | 'hero' | 'troop' | 'spell' | 'pet' | 'siege' | 'equipment';
}

// Home Village Building & Trap & Unit IDs from official Clash of Clans JSON Data Export
export const HOME_EXPORT_CATALOG: Record<number, CocCatalogEntry> = {
  // Town Hall & Key Army/Resource
  1000001: { name: 'Town Hall', nameRu: 'Ратуша', detailType: 'townhall', categoryGroup: 'townhall' },
  1000000: { name: 'Army Camp', nameRu: 'Военный лагерь', detailType: 'building', categoryGroup: 'resource_army' },
  1000002: { name: 'Elixir Collector', nameRu: 'Сборщик эликсира', detailType: 'building', categoryGroup: 'resource_army' },
  1000003: { name: 'Elixir Storage', nameRu: 'Хранилище эликсира', detailType: 'building', categoryGroup: 'resource_army' },
  1000004: { name: 'Gold Mine', nameRu: 'Золотая шахта', detailType: 'building', categoryGroup: 'resource_army' },
  1000005: { name: 'Gold Storage', nameRu: 'Золотохранилище', detailType: 'building', categoryGroup: 'resource_army' },
  1000006: { name: 'Barracks', nameRu: 'Казарма', detailType: 'building', categoryGroup: 'resource_army' },
  1000007: { name: 'Laboratory', nameRu: 'Лаборатория', detailType: 'building', categoryGroup: 'resource_army' },
  1000014: { name: 'Clan Castle', nameRu: 'Крепость клана', detailType: 'building', categoryGroup: 'resource_army' },
  1000020: { name: 'Spell Factory', nameRu: 'Фабрика заклинаний', detailType: 'building', categoryGroup: 'resource_army' },
  1000023: { name: 'Dark Elixir Drill', nameRu: 'Скважина чёрного эликсира', detailType: 'building', categoryGroup: 'resource_army' },
  1000024: { name: 'Dark Elixir Storage', nameRu: 'Хранилище чёрного эликсира', detailType: 'building', categoryGroup: 'resource_army' },
  1000026: { name: 'Dark Barracks', nameRu: 'Тёмная казарма', detailType: 'building', categoryGroup: 'resource_army' },
  1000029: { name: 'Dark Spell Factory', nameRu: 'Фабрика тёмных заклинаний', detailType: 'building', categoryGroup: 'resource_army' },
  1000059: { name: 'Workshop', nameRu: 'Мастерская осадных машин', detailType: 'building', categoryGroup: 'resource_army' },
  1000068: { name: 'Pet House', nameRu: 'Дом питомцев', detailType: 'building', categoryGroup: 'resource_army' },
  1000070: { name: 'Blacksmith', nameRu: 'Кузница', detailType: 'building', categoryGroup: 'resource_army' },
  1000071: { name: 'Hero Hall', nameRu: 'Зал героев', detailType: 'building', categoryGroup: 'resource_army' },

  // Defenses
  1000008: { name: 'Cannon', nameRu: 'Пушка', detailType: 'building', categoryGroup: 'defense' },
  1000009: { name: 'Archer Tower', nameRu: 'Башня лучниц', detailType: 'building', categoryGroup: 'defense' },
  1000010: { name: 'Wall', nameRu: 'Стена', detailType: 'building', categoryGroup: 'wall' },
  1000011: { name: 'Wizard Tower', nameRu: 'Башня волшебника', detailType: 'building', categoryGroup: 'defense' },
  1000012: { name: 'Air Defense', nameRu: 'Воздушная оборона', detailType: 'building', categoryGroup: 'defense' },
  1000013: { name: 'Mortar', nameRu: 'Мортира', detailType: 'building', categoryGroup: 'defense' },
  1000015: { name: "Builder's Hut", nameRu: 'Хижина строителя', detailType: 'building', categoryGroup: 'defense' },
  1000019: { name: 'Hidden Tesla', nameRu: 'Потайная тесла', detailType: 'building', categoryGroup: 'defense' },
  1000021: { name: 'X-Bow', nameRu: 'Арбалет', detailType: 'building', categoryGroup: 'defense' },
  1000027: { name: 'Inferno Tower', nameRu: 'Инферно-башня', detailType: 'building', categoryGroup: 'defense' },
  1000028: { name: 'Air Sweeper', nameRu: 'Воздушный чистильщик', detailType: 'building', categoryGroup: 'defense' },
  1000031: { name: 'Eagle Artillery', nameRu: 'Орлиная артиллерия', detailType: 'building', categoryGroup: 'defense' },
  1000032: { name: 'Bomb Tower', nameRu: 'Башня-бомбёжка', detailType: 'building', categoryGroup: 'defense' },
  1000067: { name: 'Scattershot', nameRu: 'Швырятель', detailType: 'building', categoryGroup: 'defense' },
  1000072: { name: 'Spell Tower', nameRu: 'Башня заклинаний', detailType: 'building', categoryGroup: 'defense' },
  1000077: { name: 'Monolith', nameRu: 'Монолит', detailType: 'building', categoryGroup: 'defense' },
  1000084: { name: 'Multi-Archer Tower', nameRu: 'Мульти-башня лучниц', detailType: 'building', categoryGroup: 'defense' },
  1000085: { name: 'Ricochet Cannon', nameRu: 'Рикошетная пушка', detailType: 'building', categoryGroup: 'defense' },
  1000089: { name: 'Firespitter', nameRu: 'Запускатель огня', detailType: 'building', categoryGroup: 'defense' },
  1000093: { name: 'Multi-Gear Tower', nameRu: 'Мульти-шестерёнчатая башня', detailType: 'building', categoryGroup: 'defense' },

  // Traps
  12000000: { name: 'Bomb', nameRu: 'Бомба', detailType: 'building', categoryGroup: 'trap' },
  12000001: { name: 'Spring Trap', nameRu: 'Пружинная ловушка', detailType: 'building', categoryGroup: 'trap' },
  12000002: { name: 'Air Bomb', nameRu: 'Воздушная бомба', detailType: 'building', categoryGroup: 'trap' },
  12000005: { name: 'Giant Bomb', nameRu: 'Гигантская бомба', detailType: 'building', categoryGroup: 'trap' },
  12000006: { name: 'Seeking Air Mine', nameRu: 'Самоводящаяся воздушная мина', detailType: 'building', categoryGroup: 'trap' },
  12000008: { name: 'Skeleton Trap', nameRu: 'Ловушка со скелетами', detailType: 'building', categoryGroup: 'trap' },
  12000016: { name: 'Tornado Trap', nameRu: 'Торнадо-ловушка', detailType: 'building', categoryGroup: 'trap' },
  12000020: { name: 'Giga Bomb', nameRu: 'Гига-бомба', detailType: 'building', categoryGroup: 'trap' },

  // Heroes (Home)
  28000000: { name: 'Barbarian King', nameRu: 'Король варваров', detailType: 'hero', categoryGroup: 'hero' },
  28000001: { name: 'Archer Queen', nameRu: 'Королева лучниц', detailType: 'hero', categoryGroup: 'hero' },
  28000002: { name: 'Grand Warden', nameRu: 'Хранитель', detailType: 'hero', categoryGroup: 'hero' },
  28000004: { name: 'Royal Champion', nameRu: 'Королевский чемпион', detailType: 'hero', categoryGroup: 'hero' },
  28000006: { name: 'Minion Prince', nameRu: 'Принц миньонов', detailType: 'hero', categoryGroup: 'hero' },

  // Key Troops & Siege
  4000000: { name: 'Barbarian', nameRu: 'Варвар', detailType: 'troop', categoryGroup: 'troop' },
  4000001: { name: 'Archer', nameRu: 'Лучница', detailType: 'troop', categoryGroup: 'troop' },
  4000002: { name: 'Goblin', nameRu: 'Гоблин', detailType: 'troop', categoryGroup: 'troop' },
  4000003: { name: 'Giant', nameRu: 'Гигант', detailType: 'troop', categoryGroup: 'troop' },
  4000004: { name: 'Wall Breaker', nameRu: 'Стенобой', detailType: 'troop', categoryGroup: 'troop' },
  4000005: { name: 'Balloon', nameRu: 'Воздушный шар', detailType: 'troop', categoryGroup: 'troop' },
  4000006: { name: 'Wizard', nameRu: 'Колдун', detailType: 'troop', categoryGroup: 'troop' },
  4000007: { name: 'Healer', nameRu: 'Целительница', detailType: 'troop', categoryGroup: 'troop' },
  4000008: { name: 'Dragon', nameRu: 'Дракон', detailType: 'troop', categoryGroup: 'troop' },
  4000009: { name: 'P.E.K.K.A', nameRu: 'П.Е.К.К.А.', detailType: 'troop', categoryGroup: 'troop' },
  4000010: { name: 'Minion', nameRu: 'Миньон', detailType: 'troop', categoryGroup: 'troop' },
  4000011: { name: 'Hog Rider', nameRu: 'Всадник на кабане', detailType: 'troop', categoryGroup: 'troop' },
  4000012: { name: 'Valkyrie', nameRu: 'Валькирия', detailType: 'troop', categoryGroup: 'troop' },
  4000013: { name: 'Golem', nameRu: 'Голем', detailType: 'troop', categoryGroup: 'troop' },
  4000015: { name: 'Witch', nameRu: 'Ведьма', detailType: 'troop', categoryGroup: 'troop' },
  4000017: { name: 'Lava Hound', nameRu: 'Адская гончая', detailType: 'troop', categoryGroup: 'troop' },
  4000022: { name: 'Bowler', nameRu: 'Вышибала', detailType: 'troop', categoryGroup: 'troop' },
  4000023: { name: 'Baby Dragon', nameRu: 'Дракончик', detailType: 'troop', categoryGroup: 'troop' },
  4000024: { name: 'Miner', nameRu: 'Шахтёр', detailType: 'troop', categoryGroup: 'troop' },
  4000053: { name: 'Yeti', nameRu: 'Йети', detailType: 'troop', categoryGroup: 'troop' },
  4000058: { name: 'Ice Golem', nameRu: 'Ледяной голем', detailType: 'troop', categoryGroup: 'troop' },
  4000059: { name: 'Electro Dragon', nameRu: 'Электродракон', detailType: 'troop', categoryGroup: 'troop' },
  4000065: { name: 'Dragon Rider', nameRu: 'Наездник на драконе', detailType: 'troop', categoryGroup: 'troop' },
  4000082: { name: 'Headhunter', nameRu: 'Охотница за головами', detailType: 'troop', categoryGroup: 'troop' },
  4000095: { name: 'Electro Titan', nameRu: 'Электротитан', detailType: 'troop', categoryGroup: 'troop' },
  4000097: { name: 'Apprentice Warden', nameRu: 'Ученик Хранителя', detailType: 'troop', categoryGroup: 'troop' },
  4000110: { name: 'Root Rider', nameRu: 'Корневой всадник', detailType: 'troop', categoryGroup: 'troop' },
  4000123: { name: 'Druid', nameRu: 'Друид', detailType: 'troop', categoryGroup: 'troop' },
  4000132: { name: 'Thrower', nameRu: 'Метатель', detailType: 'troop', categoryGroup: 'troop' },

  // Siege Machines
  4000051: { name: 'Wall Wrecker', nameRu: 'Стеноразрушитель', detailType: 'siege', categoryGroup: 'siege' },
  4000052: { name: 'Battle Blimp', nameRu: 'Боевой дирижабль', detailType: 'siege', categoryGroup: 'siege' },
  4000062: { name: 'Stone Slammer', nameRu: 'Камнемёт', detailType: 'siege', categoryGroup: 'siege' },
  4000075: { name: 'Siege Barracks', nameRu: 'Осадная казарма', detailType: 'siege', categoryGroup: 'siege' },
  4000087: { name: 'Log Launcher', nameRu: 'Бревномёт', detailType: 'siege', categoryGroup: 'siege' },
  4000091: { name: 'Flame Flinger', nameRu: 'Огнемёт', detailType: 'siege', categoryGroup: 'siege' },
  4000092: { name: 'Battle Drill', nameRu: 'Боевой бур', detailType: 'siege', categoryGroup: 'siege' },
  4000135: { name: 'Troop Launcher', nameRu: 'Катапульта войск', detailType: 'siege', categoryGroup: 'siege' },

  // Spells
  26000000: { name: 'Lightning Spell', nameRu: 'Грозовое заклинание', detailType: 'spell', categoryGroup: 'spell' },
  26000001: { name: 'Healing Spell', nameRu: 'Исцеляющее заклинание', detailType: 'spell', categoryGroup: 'spell' },
  26000002: { name: 'Rage Spell', nameRu: 'Заклинание ярости', detailType: 'spell', categoryGroup: 'spell' },
  26000003: { name: 'Jump Spell', nameRu: 'Прыжковое заклинание', detailType: 'spell', categoryGroup: 'spell' },
  26000005: { name: 'Freeze Spell', nameRu: 'Заморозка', detailType: 'spell', categoryGroup: 'spell' },
  26000009: { name: 'Poison Spell', nameRu: 'Заклинание яда', detailType: 'spell', categoryGroup: 'spell' },
  26000010: { name: 'Earthquake Spell', nameRu: 'Землетрясение', detailType: 'spell', categoryGroup: 'spell' },
  26000011: { name: 'Haste Spell', nameRu: 'Заклинание спешки', detailType: 'spell', categoryGroup: 'spell' },
  26000016: { name: 'Clone Spell', nameRu: 'Клонирующее заклинание', detailType: 'spell', categoryGroup: 'spell' },
  26000017: { name: 'Skeleton Spell', nameRu: 'Заклинание скелетов', detailType: 'spell', categoryGroup: 'spell' },
  26000028: { name: 'Bat Spell', nameRu: 'Заклинание летучих мышей', detailType: 'spell', categoryGroup: 'spell' },
  26000035: { name: 'Invisibility Spell', nameRu: 'Невидимость', detailType: 'spell', categoryGroup: 'spell' },
  26000053: { name: 'Recall Spell', nameRu: 'Заклинание отзыва', detailType: 'spell', categoryGroup: 'spell' },
  26000070: { name: 'Overgrowth Spell', nameRu: 'Заклинание зарослей', detailType: 'spell', categoryGroup: 'spell' },
  26000098: { name: 'Revive Spell', nameRu: 'Заклинание воскрешения', detailType: 'spell', categoryGroup: 'spell' },

  // Pets
  73000000: { name: 'L.A.S.S.I', nameRu: 'Л.А.С.С.И', detailType: 'pet', categoryGroup: 'pet' },
  73000001: { name: 'Electro Owl', nameRu: 'Электросова', detailType: 'pet', categoryGroup: 'pet' },
  73000002: { name: 'Mighty Yak', nameRu: 'Могучий як', detailType: 'pet', categoryGroup: 'pet' },
  73000003: { name: 'Unicorn', nameRu: 'Единорог', detailType: 'pet', categoryGroup: 'pet' },
  73000004: { name: 'Phoenix', nameRu: 'Феникс', detailType: 'pet', categoryGroup: 'pet' },
  73000007: { name: 'Poison Lizard', nameRu: 'Ядовитый ящер', detailType: 'pet', categoryGroup: 'pet' },
  73000008: { name: 'Diggy', nameRu: 'Дигги', detailType: 'pet', categoryGroup: 'pet' },
  73000009: { name: 'Spirit Fox', nameRu: 'Призрачная лиса', detailType: 'pet', categoryGroup: 'pet' },
  73000010: { name: 'Frosty', nameRu: 'Морозник', detailType: 'pet', categoryGroup: 'pet' },
  73000011: { name: 'Angry Jelly', nameRu: 'Злая медуза', detailType: 'pet', categoryGroup: 'pet' },
  73000016: { name: 'Sneezy', nameRu: 'Чихун', detailType: 'pet', categoryGroup: 'pet' },
};

// Builder Base Building, Trap, Troop & Hero IDs (buildings2, traps2, units2, heroes2)
export const BUILDER_BASE_EXPORT_CATALOG: Record<number, CocCatalogEntry> = {
  1000034: { name: 'Builder Hall', nameRu: 'Дом строителя', detailType: 'townhall', categoryGroup: 'townhall' },
  1000033: { name: 'Wall', nameRu: 'Стена (ДС)', detailType: 'building', categoryGroup: 'wall' },
  1000050: { name: 'Wall', nameRu: 'Стена (ДС)', detailType: 'building', categoryGroup: 'wall' },

  // Builder Base Defenses
  1000041: { name: 'Cannon', nameRu: 'Пушка (ДС)', detailType: 'building', categoryGroup: 'defense' },
  1000042: { name: 'Double Cannon', nameRu: 'Двойная пушка', detailType: 'building', categoryGroup: 'defense' },
  1000043: { name: 'Archer Tower', nameRu: 'Башня лучниц (ДС)', detailType: 'building', categoryGroup: 'defense' },
  1000044: { name: 'Hidden Tesla', nameRu: 'Потайная тесла (ДС)', detailType: 'building', categoryGroup: 'defense' },
  1000045: { name: 'Firecrackers', nameRu: 'Фейерверки', detailType: 'building', categoryGroup: 'defense' },
  1000046: { name: 'Guard Post', nameRu: 'Пост охраны', detailType: 'building', categoryGroup: 'defense' },
  1000047: { name: 'Air Bombs', nameRu: 'Воздушные бомбы (ДС)', detailType: 'building', categoryGroup: 'defense' },
  1000048: { name: 'Crusher', nameRu: 'Дробилка', detailType: 'building', categoryGroup: 'defense' },
  1000049: { name: 'Multi Mortar', nameRu: 'Мульти-мортира', detailType: 'building', categoryGroup: 'defense' },
  1000053: { name: 'Roaster', nameRu: 'Жаровня', detailType: 'building', categoryGroup: 'defense' },
  1000054: { name: 'Giant Cannon', nameRu: 'Гигантская пушка', detailType: 'building', categoryGroup: 'defense' },
  1000055: { name: 'Mega Tesla', nameRu: 'Мега-тесла', detailType: 'building', categoryGroup: 'defense' },
  1000058: { name: 'Lava Launcher', nameRu: 'Лавомёт', detailType: 'building', categoryGroup: 'defense' },
  1000078: { name: 'X-Bow', nameRu: 'Арбалет (ДС)', detailType: 'building', categoryGroup: 'defense' },
  1000065: { name: 'O.T.T.O Outpost', nameRu: 'Аванпост О.Т.Т.О.', detailType: 'building', categoryGroup: 'defense' },

  // Builder Base Resources & Army
  1000035: { name: 'Builder Barracks', nameRu: 'Казарма строителя', detailType: 'building', categoryGroup: 'resource_army' },
  1000036: { name: 'Star Laboratory', nameRu: 'Звёздная лаборатория', detailType: 'building', categoryGroup: 'resource_army' },
  1000037: { name: 'Clock Tower', nameRu: 'Часовая башня', detailType: 'building', categoryGroup: 'resource_army' },
  1000038: { name: 'Elixir Collector', nameRu: 'Сборщик эликсира (ДС)', detailType: 'building', categoryGroup: 'resource_army' },
  1000039: { name: 'Gold Storage', nameRu: 'Золотохранилище (ДС)', detailType: 'building', categoryGroup: 'resource_army' },
  1000040: { name: 'Army Camp', nameRu: 'Военный лагерь (ДС)', detailType: 'building', categoryGroup: 'resource_army' },
  1000051: { name: 'Gold Mine', nameRu: 'Золотая шахта (ДС)', detailType: 'building', categoryGroup: 'resource_army' },
  1000052: { name: 'Elixir Storage', nameRu: 'Хранилище эликсира (ДС)', detailType: 'building', categoryGroup: 'resource_army' },
  1000056: { name: 'Gem Mine', nameRu: 'Шахта кристаллов', detailType: 'building', categoryGroup: 'resource_army' },
  1000079: { name: 'Reinforcement Camp', nameRu: 'Лагерь подкрепления', detailType: 'building', categoryGroup: 'resource_army' },
  1000080: { name: 'Healing Hut', nameRu: 'Хижина исцеления', detailType: 'building', categoryGroup: 'resource_army' },
  1000081: { name: 'B.O.B Control', nameRu: 'Пульт Б.О.Б.', detailType: 'building', categoryGroup: 'resource_army' },

  // Builder Base Traps
  12000010: { name: 'Push Trap', nameRu: 'Отталкивающая ловушка', detailType: 'building', categoryGroup: 'trap' },
  12000011: { name: 'Spring Trap', nameRu: 'Пружинная ловушка (ДС)', detailType: 'building', categoryGroup: 'trap' },
  12000012: { name: 'Mine', nameRu: 'Мина (ДС)', detailType: 'building', categoryGroup: 'trap' },
  12000013: { name: 'Mega Mine', nameRu: 'Мега-мина', detailType: 'building', categoryGroup: 'trap' },

  // Builder Base Heroes
  28000003: { name: 'Battle Machine', nameRu: 'Боевая машина', detailType: 'hero', categoryGroup: 'hero' },
  28000005: { name: 'Battle Copter', nameRu: 'Боевой вертолёт', detailType: 'hero', categoryGroup: 'hero' },

  // Builder Base Troops
  4000031: { name: 'Raged Barbarian', nameRu: 'Яростный варвар', detailType: 'troop', categoryGroup: 'troop' },
  4000032: { name: 'Sneaky Archer', nameRu: 'Скрытная лучница', detailType: 'troop', categoryGroup: 'troop' },
  4000033: { name: 'Boxer Giant', nameRu: 'Гигант-боксёр', detailType: 'troop', categoryGroup: 'troop' },
  4000034: { name: 'Beta Minion', nameRu: 'Бета-миньон', detailType: 'troop', categoryGroup: 'troop' },
  4000035: { name: 'Bomber', nameRu: 'Бомбардир', detailType: 'troop', categoryGroup: 'troop' },
  4000036: { name: 'Baby Dragon', nameRu: 'Дракончик (ДС)', detailType: 'troop', categoryGroup: 'troop' },
  4000037: { name: 'Cannon Cart', nameRu: 'Повозка с пушкой', detailType: 'troop', categoryGroup: 'troop' },
  4000038: { name: 'Night Witch', nameRu: 'Ночная ведьма', detailType: 'troop', categoryGroup: 'troop' },
  4000041: { name: 'Drop Ship', nameRu: 'Десантный корабль', detailType: 'troop', categoryGroup: 'troop' },
  4000042: { name: 'Power P.E.K.K.A', nameRu: 'Супер-П.Е.К.К.А.', detailType: 'troop', categoryGroup: 'troop' },
  4000070: { name: 'Hog Glider', nameRu: 'Кабан на планере', detailType: 'troop', categoryGroup: 'troop' },
  4000099: { name: 'Electrofire Wizard', nameRu: 'Маг огня и молнии', detailType: 'troop', categoryGroup: 'troop' },
};

export interface JsonImportedObjectEntry {
  dataId: number;
  name: string;
  nameRu: string;
  detailType: UpgradeDetailType;
  categoryGroup: CocCatalogEntry['categoryGroup'];
  levels: number[]; // sorted desc
  upgradingTimers: Array<{
    fromLevel: number;
    toLevel: number;
    timerSeconds: number;
  }>;
}

export interface ParsedActiveTimerEntry {
  village: 'home' | 'builderBase';
  dataId: number;
  objectName: string;
  objectNameRu: string;
  detailType: UpgradeDetailType;
  fromLevel: number;
  toLevel: number;
  timerSeconds: number;
  instanceIndex: number;
}

export interface FullParsedVillageExport {
  tag: string;
  exportTimestamp?: number;
  exportTimestampIso?: string;
  home: {
    townHallLevel: number;
    buildings: JsonImportedObjectEntry[];
    traps: JsonImportedObjectEntry[];
    wallsByLevel: Record<number, number>;
    wallsTotal: number;
    heroes: JsonImportedObjectEntry[];
    troops: JsonImportedObjectEntry[];
    spells: JsonImportedObjectEntry[];
    pets: JsonImportedObjectEntry[];
    equipment: JsonImportedObjectEntry[];
    siegeMachines: JsonImportedObjectEntry[];
  };
  builderBase: {
    hasData: boolean;
    builderHallLevel: number;
    buildings: JsonImportedObjectEntry[];
    traps: JsonImportedObjectEntry[];
    wallsByLevel: Record<number, number>;
    wallsTotal: number;
    heroes: JsonImportedObjectEntry[];
    troops: JsonImportedObjectEntry[];
  };
  activeTimers: ParsedActiveTimerEntry[];
  missingFields: string[];
  totalObjectsCount: number;
}

interface RawJsonEntry {
  data?: number;
  lvl?: number;
  cnt?: number;
  timer?: number;
  helper_recurrent?: boolean;
  gear_up?: number;
}

function parseEntryList(
  entries: RawJsonEntry[],
  catalog: Record<number, CocCatalogEntry>,
  village: 'home' | 'builderBase',
  defaultDetailType: UpgradeDetailType,
  defaultGroup: CocCatalogEntry['categoryGroup'],
  wallIds: Set<number>,
  activeTimersOut: ParsedActiveTimerEntry[]
): {
  objects: JsonImportedObjectEntry[];
  wallsByLevel: Record<number, number>;
  wallsTotal: number;
} {
  const byId = new Map<number, JsonImportedObjectEntry>();
  const wallsByLevel: Record<number, number> = {};
  let wallsTotal = 0;

  for (const raw of entries) {
    const dataId = Number(raw?.data);
    if (!Number.isFinite(dataId)) continue;
    const lvl = Math.max(0, Number(raw?.lvl) || 0);
    const cnt = Math.max(1, Number(raw?.cnt) || 1);
    const timer = typeof raw?.timer === 'number' && raw.timer > 0 ? Math.round(raw.timer) : 0;

    if (wallIds.has(dataId)) {
      wallsByLevel[lvl] = (wallsByLevel[lvl] ?? 0) + cnt;
      wallsTotal += cnt;
      continue;
    }

    const meta: CocCatalogEntry = catalog[dataId] ?? {
      name: `Object #${dataId}`,
      nameRu: `Объект #${dataId}`,
      detailType: defaultDetailType,
      categoryGroup: defaultGroup,
    };

    let bucket = byId.get(dataId);
    if (!bucket) {
      bucket = {
        dataId,
        name: meta.name,
        nameRu: meta.nameRu,
        detailType: meta.detailType,
        categoryGroup: meta.categoryGroup,
        levels: [],
        upgradingTimers: [],
      };
      byId.set(dataId, bucket);
    }

    const baseIndex = bucket.levels.length;
    for (let i = 0; i < cnt; i++) {
      bucket.levels.push(lvl);
    }

    if (timer > 0) {
      bucket.upgradingTimers.push({
        fromLevel: lvl,
        toLevel: lvl + 1,
        timerSeconds: timer,
      });
      activeTimersOut.push({
        village,
        dataId,
        objectName: meta.name,
        objectNameRu: meta.nameRu,
        detailType: meta.detailType,
        fromLevel: lvl,
        toLevel: lvl + 1,
        timerSeconds: timer,
        instanceIndex: baseIndex,
      });
    }
  }

  const objects = Array.from(byId.values()).map((obj) => ({
    ...obj,
    levels: [...obj.levels].sort((a, b) => b - a),
  }));

  return { objects, wallsByLevel, wallsTotal };
}

export function parseFullSupercellExportJson(rawText: string): FullParsedVillageExport {
  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    throw new Error('Некорректный формат JSON. Вставьте полный текст экспорта из Clash of Clans.');
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('JSON должен быть объектом экспорта Clash of Clans.');
  }

  const tagRaw = typeof parsed.tag === 'string' && parsed.tag.trim() ? parsed.tag.trim().toUpperCase() : '#CUSTOM';
  const tag = tagRaw.startsWith('#') ? tagRaw : `#${tagRaw}`;

  const rawTs = typeof parsed.timestamp === 'number' && parsed.timestamp > 0 ? parsed.timestamp : undefined;
  const exportTimestampIso = rawTs
    ? new Date(rawTs > 1e12 ? rawTs : rawTs * 1000).toISOString()
    : undefined;

  const missingFields: string[] = [];
  if (!rawTs) missingFields.push('timestamp (время создания экспорта)');

  const asArr = (key: string): RawJsonEntry[] =>
    Array.isArray(parsed[key]) ? (parsed[key] as RawJsonEntry[]) : [];

  const homeBuildingsRaw = asArr('buildings');
  const homeTrapsRaw = asArr('traps');
  const homeUnitsRaw = asArr('units');
  const homeSpellsRaw = asArr('spells');
  const homeHeroesRaw = asArr('heroes');
  const homePetsRaw = asArr('pets');
  const homeEquipRaw = asArr('equipment');
  const homeSiegeRaw = asArr('siege_machines');

  const bbBuildingsRaw = asArr('buildings2');
  const bbTrapsRaw = asArr('traps2');
  const bbUnitsRaw = asArr('units2');
  const bbHeroesRaw = asArr('heroes2');

  if (homeBuildingsRaw.length === 0 && bbBuildingsRaw.length === 0 && homeHeroesRaw.length === 0) {
    throw new Error('В JSON не найдены массивы зданий или героев (buildings, buildings2, heroes).');
  }

  if (!Array.isArray(parsed.buildings2)) missingFields.push('buildings2 (здания Деревни строителя)');
  if (!Array.isArray(parsed.traps2)) missingFields.push('traps2 (ловушки Деревни строителя)');
  if (!Array.isArray(parsed.units2)) missingFields.push('units2 (войска Деревни строителя)');
  if (!Array.isArray(parsed.heroes2)) missingFields.push('heroes2 (герои Деревни строителя)');
  if (!Array.isArray(parsed.equipment)) missingFields.push('equipment (оборудование героев)');

  const activeTimers: ParsedActiveTimerEntry[] = [];
  const homeWallIds = new Set<number>([1000010]);
  const bbWallIds = new Set<number>([1000033, 1000050]);

  const homeBldParsed = parseEntryList(
    homeBuildingsRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'building',
    'defense',
    homeWallIds,
    activeTimers
  );
  const homeTrapsParsed = parseEntryList(
    homeTrapsRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'building',
    'trap',
    homeWallIds,
    activeTimers
  );
  const homeUnitsParsed = parseEntryList(
    homeUnitsRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'troop',
    'troop',
    new Set(),
    activeTimers
  );
  const homeSpellsParsed = parseEntryList(
    homeSpellsRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'spell',
    'spell',
    new Set(),
    activeTimers
  );
  const homeHeroesParsed = parseEntryList(
    homeHeroesRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'hero',
    'hero',
    new Set(),
    activeTimers
  );
  const homePetsParsed = parseEntryList(
    homePetsRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'pet',
    'pet',
    new Set(),
    activeTimers
  );
  const homeEquipParsed = parseEntryList(
    homeEquipRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'equipment',
    'equipment',
    new Set(),
    activeTimers
  );
  const homeSiegeParsed = parseEntryList(
    homeSiegeRaw,
    HOME_EXPORT_CATALOG,
    'home',
    'siege',
    'siege',
    new Set(),
    activeTimers
  );

  // Separate siege machines if present inside units
  const separatedSiege: JsonImportedObjectEntry[] = [...homeSiegeParsed.objects];
  const filteredHomeTroops: JsonImportedObjectEntry[] = [];
  for (const u of homeUnitsParsed.objects) {
    if (u.detailType === 'siege') separatedSiege.push(u);
    else filteredHomeTroops.push(u);
  }

  const thEntry = homeBuildingsRaw.find((b) => Number(b.data) === 1000001);
  const townHallLevel = thEntry ? Math.max(1, Math.min(18, Number(thEntry.lvl) || 1)) : 0;

  // Builder Base
  const bbBldParsed = parseEntryList(
    bbBuildingsRaw,
    BUILDER_BASE_EXPORT_CATALOG,
    'builderBase',
    'building',
    'defense',
    bbWallIds,
    activeTimers
  );
  const bbTrapsParsed = parseEntryList(
    bbTrapsRaw,
    BUILDER_BASE_EXPORT_CATALOG,
    'builderBase',
    'building',
    'trap',
    bbWallIds,
    activeTimers
  );
  const bbUnitsParsed = parseEntryList(
    bbUnitsRaw,
    BUILDER_BASE_EXPORT_CATALOG,
    'builderBase',
    'troop',
    'troop',
    new Set(),
    activeTimers
  );
  const bbHeroesParsed = parseEntryList(
    bbHeroesRaw,
    BUILDER_BASE_EXPORT_CATALOG,
    'builderBase',
    'hero',
    'hero',
    new Set(),
    activeTimers
  );

  const bhEntry = bbBuildingsRaw.find((b) => Number(b.data) === 1000034);
  const builderHallLevel = bhEntry ? Math.max(1, Math.min(12, Number(bhEntry.lvl) || 1)) : 0;
  const hasBuilderData =
    bbBuildingsRaw.length > 0 || bbTrapsRaw.length > 0 || bbUnitsRaw.length > 0 || bbHeroesRaw.length > 0;

  if (activeTimers.length === 0) {
    missingFields.push('timer (в данном экспорте нет активных таймеров строительства/исследования или они отсутствуют)');
  }

  const totalObjectsCount =
    homeBldParsed.objects.reduce((s, o) => s + o.levels.length, 0) +
    homeTrapsParsed.objects.reduce((s, o) => s + o.levels.length, 0) +
    homeBldParsed.wallsTotal +
    filteredHomeTroops.length +
    homeSpellsParsed.objects.length +
    homeHeroesParsed.objects.length +
    homePetsParsed.objects.length +
    homeEquipParsed.objects.length +
    separatedSiege.length +
    bbBldParsed.objects.reduce((s, o) => s + o.levels.length, 0) +
    bbTrapsParsed.objects.reduce((s, o) => s + o.levels.length, 0) +
    bbBldParsed.wallsTotal +
    bbUnitsParsed.objects.length +
    bbHeroesParsed.objects.length;

  return {
    tag,
    exportTimestamp: rawTs,
    exportTimestampIso,
    home: {
      townHallLevel,
      buildings: homeBldParsed.objects,
      traps: homeTrapsParsed.objects,
      wallsByLevel: homeBldParsed.wallsByLevel,
      wallsTotal: homeBldParsed.wallsTotal,
      heroes: homeHeroesParsed.objects,
      troops: filteredHomeTroops,
      spells: homeSpellsParsed.objects,
      pets: homePetsParsed.objects,
      equipment: homeEquipParsed.objects,
      siegeMachines: separatedSiege,
    },
    builderBase: {
      hasData: hasBuilderData,
      builderHallLevel,
      buildings: bbBldParsed.objects,
      traps: bbTrapsParsed.objects,
      wallsByLevel: bbBldParsed.wallsByLevel,
      wallsTotal: bbBldParsed.wallsTotal,
      heroes: bbHeroesParsed.objects,
      troops: bbUnitsParsed.objects,
    },
    activeTimers,
    missingFields,
    totalObjectsCount,
  };
}
