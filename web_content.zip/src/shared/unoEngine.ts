import {
  DARK_COLORS,
  LIGHT_COLORS,
  type ActiveColor,
  type CardFace,
  type DarkValue,
  type LightValue,
  type Side,
  type UnoCardData,
} from './unoTypes.ts';

export function shuffleArray<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr;
}

/**
 * Generates an authentic 112-card UNO Flip deck.
 * Light faces and Dark faces are built per official counts (112 each)
 * and independently shuffled before pairing into double-sided cards.
 */
export function createUnoFlipDeck(): UnoCardData[] {
  const lightFaces: CardFace[] = [];
  const darkFaces: CardFace[] = [];

  for (const color of LIGHT_COLORS) {
    for (let num = 1; num <= 9; num++) {
      const val = String(num) as LightValue;
      lightFaces.push({ color, value: val });
      lightFaces.push({ color, value: val });
    }
    const actions: LightValue[] = ['draw1', 'skip', 'reverse', 'flip'];
    for (const action of actions) {
      lightFaces.push({ color, value: action });
      lightFaces.push({ color, value: action });
    }
  }
  for (let i = 0; i < 4; i++) {
    lightFaces.push({ color: 'wild', value: 'wild' });
    lightFaces.push({ color: 'wild', value: 'wild_draw2' });
  }

  for (const color of DARK_COLORS) {
    for (let num = 1; num <= 9; num++) {
      const val = String(num) as DarkValue;
      darkFaces.push({ color, value: val });
      darkFaces.push({ color, value: val });
    }
    const actions: DarkValue[] = ['draw5', 'skip_all', 'reverse', 'flip'];
    for (const action of actions) {
      darkFaces.push({ color, value: action });
      darkFaces.push({ color, value: action });
    }
  }
  for (let i = 0; i < 4; i++) {
    darkFaces.push({ color: 'wild', value: 'wild' });
    darkFaces.push({ color: 'wild', value: 'wild_draw_color' });
  }

  const shuffledLight = shuffleArray(lightFaces);
  const shuffledDark = shuffleArray(darkFaces);

  const deck: UnoCardData[] = [];
  for (let i = 0; i < shuffledLight.length; i++) {
    deck.push({
      id: `card_${i}_${Math.random().toString(36).slice(2, 7)}`,
      light: shuffledLight[i],
      dark: shuffledDark[i],
    });
  }
  return shuffleArray(deck);
}

export function getCardFace(card: UnoCardData, side: Side): CardFace {
  return side === 'light' ? card.light : card.dark;
}

export function isWildFace(face: CardFace): boolean {
  return face.color === 'wild';
}

export function isColorValidForSide(color: ActiveColor, side: Side): boolean {
  if (side === 'light') {
    return (LIGHT_COLORS as string[]).includes(color);
  }
  return (DARK_COLORS as string[]).includes(color);
}

export function getDefaultColorForSide(side: Side): ActiveColor {
  return side === 'light' ? LIGHT_COLORS[0] : DARK_COLORS[0];
}

export function canPlayCard(
  card: UnoCardData,
  topCard: UnoCardData | null,
  activeColor: ActiveColor,
  side: Side
): boolean {
  const face = getCardFace(card, side);
  if (face.color === 'wild') {
    return true;
  }
  if (face.color === activeColor) {
    return true;
  }
  if (!topCard) {
    return true;
  }
  const topFace = getCardFace(topCard, side);
  return face.value === topFace.value;
}

export function getCardPoints(face: CardFace): number {
  const v = face.value;
  if (/^[1-9]$/.test(v)) {
    return Number(v);
  }
  switch (v) {
    case 'draw1':
      return 10;
    case 'draw5':
    case 'skip':
    case 'reverse':
    case 'flip':
      return 20;
    case 'skip_all':
      return 30;
    case 'wild':
      return 40;
    case 'wild_draw2':
      return 50;
    case 'wild_draw_color':
      return 60;
    default:
      return 0;
  }
}

export function calculateHandPoints(hand: UnoCardData[], side: Side): number {
  return hand.reduce((sum, card) => sum + getCardPoints(getCardFace(card, side)), 0);
}

export function formatFaceNameId(face: CardFace): string {
  switch (face.value) {
    case 'draw1':
      return 'Ambil +1';
    case 'draw5':
      return 'Ambil +5';
    case 'skip':
      return 'Skip';
    case 'skip_all':
      return 'Skip Semua';
    case 'reverse':
      return 'Putar Balik';
    case 'flip':
      return 'FLIP!';
    case 'wild':
      return 'Wild';
    case 'wild_draw2':
      return 'Wild +2';
    case 'wild_draw_color':
      return 'Wild +Warna';
    default:
      return `Angka ${face.value}`;
  }
}

export function chooseBestColorForHand(hand: UnoCardData[], side: Side): ActiveColor {
  const palette: ActiveColor[] = side === 'light' ? [...LIGHT_COLORS] : [...DARK_COLORS];
  const counts: Record<string, number> = {};
  for (const c of palette) counts[c] = 0;

  for (const card of hand) {
    const face = getCardFace(card, side);
    if (face.color !== 'wild' && counts[face.color] !== undefined) {
      counts[face.color] += 1;
    }
  }

  let bestColor = palette[0];
  let bestCount = -1;
  for (const c of palette) {
    if (counts[c] > bestCount) {
      bestCount = counts[c];
      bestColor = c;
    }
  }
  return bestColor;
}

export function chooseBotMove(
  hand: UnoCardData[],
  topCard: UnoCardData | null,
  activeColor: ActiveColor,
  side: Side,
  nextPlayerCardCount: number
): { card: UnoCardData; chosenColor?: ActiveColor } | null {
  const playable = hand.filter((c) => canPlayCard(c, topCard, activeColor, side));
  if (playable.length === 0) return null;

  // Score each candidate move heuristically
  const scored = playable.map((card) => {
    const face = getCardFace(card, side);
    let priority = getCardPoints(face);

    // If next player is close to winning, prioritize attack/skip cards!
    if (nextPlayerCardCount <= 2) {
      if (
        face.value === 'draw5' ||
        face.value === 'wild_draw_color' ||
        face.value === 'wild_draw2' ||
        face.value === 'draw1' ||
        face.value === 'skip' ||
        face.value === 'skip_all'
      ) {
        priority += 100;
      }
    }

    // Prefer saving Wilds unless needed or hand is small
    if (face.color === 'wild' && hand.length > 2) {
      priority -= 35;
    }

    // Slight preference to shed higher point cards
    return { card, priority };
  });

  scored.sort((a, b) => b.priority - a.priority);
  const chosenCard = scored[0].card;
  const face = getCardFace(chosenCard, side);

  if (face.color === 'wild') {
    const remaining = hand.filter((c) => c.id !== chosenCard.id);
    const chosenColor = chooseBestColorForHand(remaining, side);
    return { card: chosenCard, chosenColor };
  }

  return { card: chosenCard };
}
