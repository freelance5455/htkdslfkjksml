export type VillageCategory =
  | 'defenses'
  | 'heroes'
  | 'lab'
  | 'traps'
  | 'resources'
  | 'walls';

export type ClanRole = 'leader' | 'coLeader' | 'elder' | 'member';

export interface VillageItemInstance {
  id: string;
  nameRu: string;
  category: VillageCategory;
  levels: number[];
  maxLevelForTh: number;
  expectedCount: number;
  supercellId?: number;
}

export interface WallSummary {
  totalCount: number;
  maxLevelForTh: number;
  byLevel: Record<number, number>;
}

export interface ActiveBuilder {
  id: string;
  itemId: string;
  itemNameRu: string;
  category: VillageCategory;
  instanceIndex: number;
  fromLevel: number;
  toLevel: number;
  startedAt: string;
  finishesAt: string;
}

export interface PlayerProgressSummary {
  overallPct: number;
  defensesPct: number;
  heroesPct: number;
  labPct: number;
  trapsPct: number;
  resourcesPct: number;
  wallsPct: number;
  completedLevels: number;
  totalLevelsForTh: number;
  maxedItemsCount: number;
  totalItemsCount: number;
  rushScore: number;
  statusLabel: 'Фулл' | 'Сбалансирована' | 'В прокачке' | 'Раш';
}

export interface PlayerCombatStats {
  attacksWon: number;
  defensesWon: number;
  warAttacksUsed: number;
  warStarsEarned: number;
  warThreeStars: number;
  warAvgDestruction: number;
  warDefensesFaced: number;
  warStarsConceded: number;
  warDefenseHoldRate: number;
}

export interface OfficialUnitEntry {
  name: string;
  level: number;
  maxLevel: number;
  village: string;
  superTroopIsActive?: boolean;
  equipment?: Array<{
    name: string;
    level: number;
    maxLevel: number;
    village?: string;
  }>;
}

export interface OfficialAchievement {
  name: string;
  stars: number;
  value: number;
  target: number;
  info: string;
  completionInfo?: string | null;
  village: string;
}

export interface LegendSeasonResult {
  id?: string;
  rank?: number;
  trophies?: number;
}

export interface LegendStatistics {
  legendTrophies?: number;
  previousSeason?: LegendSeasonResult;
  bestSeason?: LegendSeasonResult;
  previousBuilderBaseSeason?: LegendSeasonResult;
  bestBuilderBaseSeason?: LegendSeasonResult;
  currentSeason?: LegendSeasonResult;
}

export interface LeagueInfo {
  id?: number;
  name: string;
  iconUrl?: string;
}

export interface PlayerProfile {
  tag: string;
  name: string;
  role: ClanRole;
  townHallLevel: number;
  townHallWeaponLevel?: number;
  builderHallLevel: number;
  expLevel: number;
  trophies: number;
  bestTrophies: number;
  builderBaseTrophies: number;
  bestBuilderBaseTrophies: number;
  warStars: number;
  donations: number;
  donationsReceived: number;
  clanCapitalContributions: number;
  warPreference?: 'in' | 'out';
  clanRank?: number;
  previousClanRank?: number;
  league?: LeagueInfo;
  builderBaseLeague?: LeagueInfo;
  clanRef?: {
    tag: string;
    name: string;
    clanLevel: number;
    badgeUrl?: string;
  };
  apiHeroes: OfficialUnitEntry[];
  apiHeroEquipment: OfficialUnitEntry[];
  apiTroops: OfficialUnitEntry[];
  apiSpells: OfficialUnitEntry[];
  apiSiegeMachines: OfficialUnitEntry[];
  apiPets: OfficialUnitEntry[];
  achievements: OfficialAchievement[];
  labels?: Array<{ id: number; name: string; iconUrl?: string }>;
  legendStatistics?: LegendStatistics;
  lastSyncedAt: string;
  items: VillageItemInstance[];
  walls: WallSummary;
  activeBuilders: ActiveBuilder[];
  progress: PlayerProgressSummary;
  combat: PlayerCombatStats;
  buildingsVerified?: boolean;
  activityUpgrades30d?: number;
  playerDetailsLoaded?: boolean;
  lastJsonImportAt?: string;
  jsonVillage?: PlayerJsonVillageState;
}

export type VillageId = 'home' | 'builderBase' | 'clanCapital';
export type DataSourceType = 'coc_api' | 'json_import' | 'manual' | 'live_builder';
export type TrackedUpgradeStatus = 'in_progress' | 'completed';

export interface JsonObjectSnapshotEntry {
  dataId: number;
  name: string;
  nameRu: string;
  detailType: UpgradeDetailType;
  categoryGroup: string;
  levels: number[];
}

export interface PlayerJsonVillageState {
  importedAt: string;
  exportTimestampIso?: string;
  source: 'json_import';
  homeTownHallLevel: number;
  homeBuildings: JsonObjectSnapshotEntry[];
  homeTraps: JsonObjectSnapshotEntry[];
  homeWallsByLevel: Record<number, number>;
  homeWallsTotal: number;
  builderHallLevel?: number;
  builderBuildings: JsonObjectSnapshotEntry[];
  builderTraps: JsonObjectSnapshotEntry[];
  builderWallsByLevel: Record<number, number>;
  builderWallsTotal: number;
  builderHeroes: JsonObjectSnapshotEntry[];
  builderTroops: JsonObjectSnapshotEntry[];
  activeTimersCount: number;
  missingFields: string[];
}

export interface ActiveUpgradeEntry {
  id: string;
  dedupKey: string;
  village: VillageId;
  playerTag: string;
  playerName: string;
  townHallLevel: number;
  builderHallLevel?: number;
  objectName: string;
  objectNameRu: string;
  detailType: UpgradeDetailType;
  fromLevel: number;
  toLevel: number;
  status: TrackedUpgradeStatus;
  source: DataSourceType;
  detectedAt: string;
  lastConfirmedAt: string;
  timerSecondsInitial?: number;
  exportTimestampIso?: string;
  estimatedFinishesAt?: string;
}

export type UpgradeDetailType =
  | 'townhall'
  | 'hero'
  | 'equipment'
  | 'troop'
  | 'spell'
  | 'siege'
  | 'pet'
  | 'building'
  | 'exp'
  | 'trophies'
  | 'donations'
  | 'capital'
  | 'war_stars';

export interface UpgradeEvent {
  id: string;
  dedupKey?: string;
  timestamp: string;
  previousSnapshotAt?: string;
  previousCheckAt?: string;
  detectedAt?: string;
  lastConfirmedAt?: string;
  playerTag: string;
  playerName: string;
  townHallLevel: number;
  category: VillageCategory | 'townhall';
  detailType?: UpgradeDetailType;
  itemId: string;
  apiName?: string;
  itemNameRu: string;
  village?: VillageId | string;
  isSuperTroop?: boolean;
  instanceNumber?: number;
  fromLevel: number;
  toLevel: number;
  status?: TrackedUpgradeStatus;
  remainingSecondsAtDetection?: number;
  estimatedFinishesAt?: string;
  source: DataSourceType;
}

export interface SyncProgressInfo {
  inProgress: boolean;
  stage: 'idle' | 'fetching_clan' | 'checking_members' | 'finalizing' | 'done' | 'error';
  statusText: string;
  checkedMembers: number;
  totalMembers: number;
  upgradesFound: number;
  errorsCount: number;
  startedAt?: string;
  completedAt?: string;
  lastError?: string | null;
}

export interface SyncRunSummary {
  checkedMembers: number;
  totalMembers: number;
  upgradesFound: number;
  errorsCount: number;
  completedAt: string;
  newUpgrades: UpgradeEvent[];
  errorMessage?: string | null;
}

export type ClanEventType =
  | 'upgrade_townhall'
  | 'upgrade_hero'
  | 'upgrade_equipment'
  | 'upgrade_troop'
  | 'upgrade_spell'
  | 'upgrade_siege'
  | 'upgrade_pet'
  | 'progress_metric'
  | 'donations_change'
  | 'war_result'
  | 'roster_join'
  | 'roster_leave'
  | 'roster_role';

export interface ClanEvent {
  id: string;
  dedupKey: string;
  timestamp: string;
  previousSnapshotAt?: string;
  type: ClanEventType;
  title: string;
  description: string;
  playerTag?: string;
  playerName?: string;
  townHallLevel?: number;
  previousValue?: string | number;
  newValue?: string | number;
  deltaLabel?: string;
  source: 'coc_api' | 'json_import' | 'live_builder' | 'manual';
  read: boolean;
}

export interface HistoryPoint {
  date: string;
  label: string;
  clanAvgPct: number;
  clanDefensesPct: number;
  clanHeroesPct: number;
  clanLabPct: number;
  clanWallsPct: number;
  byTownHall: Record<number, number>;
  byPlayer: Record<string, number>;
  upgradesCount: number;
  upgradesByCategory: Record<VillageCategory | 'townhall', number>;
}

export interface ClanSnapshotPlayerEntry {
  name: string;
  townHallLevel: number;
  trophies: number;
  donations: number;
  donationsReceived: number;
  warStars: number;
  expLevel: number;
  overallPct: number;
  heroesLevelSum?: number;
  heroesMaxSum?: number;
  troopsLevelSum?: number;
  troopsMaxSum?: number;
  spellsLevelSum?: number;
  spellsMaxSum?: number;
  siegeLevelSum?: number;
  petsLevelSum?: number;
  equipmentLevelSum?: number;
  clanCapitalContributions?: number;
  compositeScore?: number;
}

export interface ClanSnapshot {
  id: string;
  timestamp: string;
  memberCount: number;
  clanPoints: number;
  clanBuilderBasePoints: number;
  clanCapitalPoints: number;
  totalTrophies: number;
  totalDonations: number;
  totalDonationsReceived: number;
  warWins: number;
  warLosses: number;
  warTies: number;
  warWinStreak: number;
  avgTownHall: number;
  avgBaseProgressPct: number;
  byPlayer: Record<string, ClanSnapshotPlayerEntry>;
}

export interface ClanWarEntry {
  id: string;
  date: string;
  label: string;
  endTimeIso?: string;
  opponentName: string;
  opponentTag: string;
  opponentLevel?: number;
  opponentBadgeUrl?: string;
  teamSize: number;
  attacksPerMember?: number;
  clanStars: number;
  maxStars: number;
  opponentStars: number;
  clanDestruction: number;
  opponentDestruction: number;
  attacksUsed: number;
  maxAttacks: number;
  threeStarAttacks: number;
  defensesHeld: number;
  totalEnemyAttacks: number;
  result: 'win' | 'loss' | 'draw';
}

export interface WarAttackDetail {
  attackerTag: string;
  attackerName?: string;
  defenderTag: string;
  defenderName?: string;
  defenderTownHall?: number;
  stars: number;
  destructionPercentage: number;
  order: number;
  duration?: number;
}

export interface WarMemberDetail {
  tag: string;
  name: string;
  townHallLevel: number;
  mapPosition: number;
  attacks: WarAttackDetail[];
  opponentAttacks: number;
  bestOpponentAttack?: {
    attackerTag: string;
    stars: number;
    destructionPercentage: number;
  };
}

export interface CurrentWarInfo {
  state: 'notInWar' | 'preparation' | 'inWar' | 'warEnded' | string;
  teamSize: number;
  attacksPerMember: number;
  preparationStartTime?: string;
  startTime?: string;
  endTime?: string;
  clan: {
    tag: string;
    name: string;
    badgeUrl?: string;
    clanLevel: number;
    attacks: number;
    stars: number;
    destructionPercentage: number;
    members: WarMemberDetail[];
  };
  opponent: {
    tag: string;
    name: string;
    badgeUrl?: string;
    clanLevel: number;
    attacks: number;
    stars: number;
    destructionPercentage: number;
    members: WarMemberDetail[];
  };
}

export interface CwlStandingClan {
  tag: string;
  name: string;
  clanLevel: number;
  badgeUrl?: string;
  warsPlayed: number;
  wins: number;
  losses: number;
  ties: number;
  stars: number;
  destructionSum: number;
}

export interface CwlWarSummary {
  warTag: string;
  roundIndex: number;
  state: string;
  teamSize: number;
  startTime?: string;
  endTime?: string;
  clan: {
    tag: string;
    name: string;
    badgeUrl?: string;
    stars: number;
    destructionPercentage: number;
    attacks: number;
    members: WarMemberDetail[];
  };
  opponent: {
    tag: string;
    name: string;
    badgeUrl?: string;
    stars: number;
    destructionPercentage: number;
    attacks: number;
    members: WarMemberDetail[];
  };
}

export interface CwlPlayerRating {
  tag: string;
  name: string;
  townHallLevel: number;
  attacksUsed: number;
  warsParticipated: number;
  stars: number;
  threeStars: number;
  avgDestruction: number;
}

export interface CwlGroupInfo {
  state: string;
  season: string;
  clans: Array<{
    tag: string;
    name: string;
    clanLevel: number;
    badgeUrl?: string;
    membersCount: number;
  }>;
  rounds: Array<{
    roundIndex: number;
    warTags: string[];
  }>;
  wars: CwlWarSummary[];
  standings: CwlStandingClan[];
  playerRatings: CwlPlayerRating[];
  unavailableReason?: string;
}

export interface CapitalRaidMember {
  tag: string;
  name: string;
  attacks: number;
  attackLimit: number;
  bonusAttackLimit: number;
  capitalResourcesLooted: number;
}

export interface CapitalRaidDistrict {
  id: number;
  name: string;
  districtHallLevel: number;
  destructionPercent: number;
  stars: number;
  attackCount: number;
  totalLooted: number;
}

export interface CapitalRaidLogEntry {
  defenderName: string;
  defenderTag: string;
  defenderLevel: number;
  defenderBadgeUrl?: string;
  attackCount: number;
  districtCount: number;
  districtsDestroyed: number;
  districts: CapitalRaidDistrict[];
}

export interface CapitalRaidSeason {
  state: string;
  startTime: string;
  endTime: string;
  capitalTotalLoot: number;
  raidsCompleted: number;
  totalAttacks: number;
  enemyDistrictsDestroyed: number;
  offensiveReward: number;
  defensiveReward: number;
  members: CapitalRaidMember[];
  attackLog: CapitalRaidLogEntry[];
  defenseLogCount: number;
}

export interface ClanAggregateStats {
  totalWarStarsAllTime: number;
  recentWarStarsEarned: number;
  avgStarsPerWar: number;
  totalMultiplayerAttacksWon: number;
  totalMultiplayerDefensesWon: number;
  attackSuccessRatePct: number;
  threeStarRatePct: number;
  avgWarDestructionPct: number;
  defenseHoldRatePct: number;
  avgStarsConcededPerDefense: number;
  avgBaseProgressPct: number;
  avgDefensesPct: number;
  avgHeroesPct: number;
  avgLabPct: number;
  avgWallsPct: number;
  avgTrapsPct: number;
  warWinRatePct: number;
  warsPlayedCount: number;
  warsWonCount: number;
}

export interface ClanDistrictInfo {
  id: number;
  name: string;
  districtHallLevel: number;
}

export interface ClanInfo {
  tag: string;
  name: string;
  description?: string;
  type?: 'open' | 'inviteOnly' | 'closed' | string;
  level: number;
  warLeague: string;
  capitalLeague?: string;
  clanPoints: number;
  clanBuilderBasePoints?: number;
  clanCapitalPoints: number;
  capitalHallLevel?: number;
  capitalDistricts?: ClanDistrictInfo[];
  locationName?: string;
  locationCountryCode?: string;
  chatLanguage?: string;
  requiredTownhallLevel?: number;
  requiredTrophies?: number;
  requiredBuilderBaseTrophies?: number;
  warFrequency?: string;
  warWins: number;
  warLosses?: number;
  warTies?: number;
  warWinStreak: number;
  membersCount: number;
  isWarLogPublic?: boolean;
  isFamilyFriendly?: boolean;
  labels?: Array<{ id: number; name: string; iconUrl?: string }>;
  lastSyncedAt: string;
  badgeUrl?: string;
}

export interface TownHallGroupSummary {
  townHallLevel: number;
  playerCount: number;
  avgOverallPct: number;
  avgDefensesPct: number;
  avgHeroesPct: number;
  avgLabPct: number;
  avgWallsPct: number;
  avgTrapsPct: number;
  activeBuildersCount: number;
  recentUpgradesCount: number;
  keyBuildingAverages: Array<{
    id: string;
    nameRu: string;
    avgLevel: number;
    maxLevel: number;
  }>;
  players: PlayerProfile[];
}

export interface SyncConfig {
  autoSyncEnabled: boolean;
  intervalMinutes: number;
  lastSyncAt: string | null;
  lastSyncStatus: 'idle' | 'ok' | 'error';
  lastSyncError: string | null;
  cacheEntriesCount?: number;
  cacheTtlSeconds?: number;
}

export interface ClanDashboardState {
  clan: ClanInfo | null;
  players: PlayerProfile[];
  events: UpgradeEvent[];
  activeUpgrades: ActiveUpgradeEntry[];
  clanEvents: ClanEvent[];
  history: HistoryPoint[];
  snapshots: ClanSnapshot[];
  wars: ClanWarEntry[];
  currentWar: CurrentWarInfo | null;
  cwl: CwlGroupInfo | null;
  capitalRaids: CapitalRaidSeason[];
  clanStats: ClanAggregateStats;
  thGroups: TownHallGroupSummary[];
  hasApiToken: boolean;
  syncConfig: SyncConfig;
}

export const VILLAGE_LABELS_RU: Record<VillageId, string> = {
  home: 'HOME VILLAGE — Родная деревня',
  builderBase: 'BUILDER BASE — Деревня строителя',
  clanCapital: 'CLAN CAPITAL — Столица клана',
};

export const DATA_SOURCE_LABELS_RU: Record<DataSourceType, string> = {
  coc_api: 'Supercell API',
  json_import: 'Игровой JSON Export',
  manual: 'Ручной ввод',
  live_builder: 'Таймер по экспорту',
};

export const ROLE_LABELS_RU: Record<ClanRole, string> = {
  leader: 'Глава',
  coLeader: 'Соруководитель',
  elder: 'Старейшина',
  member: 'Участник',
};

export const CLAN_TYPE_LABELS_RU: Record<string, string> = {
  open: 'Открытый',
  inviteOnly: 'По приглашению',
  closed: 'Закрытый',
};

export const WAR_FREQUENCY_LABELS_RU: Record<string, string> = {
  always: 'Всегда',
  moreThanOncePerWeek: 'Более 1 раза в неделю',
  oncePerWeek: 'Раз в неделю',
  lessThanOncePerWeek: 'Реже 1 раза в неделю',
  never: 'Никогда',
  unknown: 'Не указано',
};

export const CATEGORY_LABELS_RU: Record<VillageCategory | 'townhall', string> = {
  defenses: 'Оборона',
  heroes: 'Герои',
  lab: 'Лаборатория',
  traps: 'Ловушки',
  resources: 'Ресурсы и армия',
  walls: 'Стены',
  townhall: 'Ратуша',
};

export const DETAIL_TYPE_LABELS_RU: Record<UpgradeDetailType, string> = {
  townhall: 'Ратуша',
  hero: 'Герои',
  equipment: 'Оборудование героев',
  troop: 'Войска',
  spell: 'Заклинания',
  siege: 'Осадные машины',
  pet: 'Питомцы',
  building: 'Постройки базы',
  exp: 'Уровень опыта',
  trophies: 'Трофеи',
  donations: 'Пожертвования',
  capital: 'Вклад в столицу',
  war_stars: 'Звёзды войн',
};

export interface EntityDefinition {
  id: string;
  nameRu: string;
  category: VillageCategory;
  supercellIds: number[];
  maxByTh: Record<number, { maxLevel: number; count: number }>;
}

// Accurate Clash of Clans max levels & counts per Town Hall (TH11..TH17)
export const VILLAGE_ENTITIES: EntityDefinition[] = [
  // DEFENSES
  {
    id: 'cannon',
    nameRu: 'Пушка',
    category: 'defenses',
    supercellIds: [1000008],
    maxByTh: {
      11: { maxLevel: 15, count: 7 },
      12: { maxLevel: 17, count: 7 },
      13: { maxLevel: 19, count: 7 },
      14: { maxLevel: 20, count: 7 },
      15: { maxLevel: 21, count: 7 },
      16: { maxLevel: 21, count: 3 },
      17: { maxLevel: 21, count: 3 },
    },
  },
  {
    id: 'ricochet_cannon',
    nameRu: 'Рикошетная пушка',
    category: 'defenses',
    supercellIds: [1000085],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 0, count: 0 },
      16: { maxLevel: 2, count: 2 },
      17: { maxLevel: 3, count: 3 },
    },
  },
  {
    id: 'archer_tower',
    nameRu: 'Башня лучниц',
    category: 'defenses',
    supercellIds: [1000009],
    maxByTh: {
      11: { maxLevel: 15, count: 8 },
      12: { maxLevel: 17, count: 8 },
      13: { maxLevel: 19, count: 8 },
      14: { maxLevel: 20, count: 8 },
      15: { maxLevel: 21, count: 8 },
      16: { maxLevel: 21, count: 4 },
      17: { maxLevel: 21, count: 2 },
    },
  },
  {
    id: 'multi_archer_tower',
    nameRu: 'Мульти-башня лучниц',
    category: 'defenses',
    supercellIds: [1000084],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 0, count: 0 },
      16: { maxLevel: 2, count: 2 },
      17: { maxLevel: 3, count: 3 },
    },
  },
  {
    id: 'mortar',
    nameRu: 'Мортира',
    category: 'defenses',
    supercellIds: [1000013],
    maxByTh: {
      11: { maxLevel: 10, count: 4 },
      12: { maxLevel: 12, count: 4 },
      13: { maxLevel: 13, count: 4 },
      14: { maxLevel: 14, count: 4 },
      15: { maxLevel: 15, count: 4 },
      16: { maxLevel: 16, count: 4 },
      17: { maxLevel: 17, count: 4 },
    },
  },
  {
    id: 'air_defense',
    nameRu: 'Воздушная оборона',
    category: 'defenses',
    supercellIds: [1000012],
    maxByTh: {
      11: { maxLevel: 9, count: 4 },
      12: { maxLevel: 10, count: 4 },
      13: { maxLevel: 11, count: 4 },
      14: { maxLevel: 12, count: 4 },
      15: { maxLevel: 13, count: 4 },
      16: { maxLevel: 14, count: 4 },
      17: { maxLevel: 15, count: 4 },
    },
  },
  {
    id: 'wizard_tower',
    nameRu: 'Башня колдуна',
    category: 'defenses',
    supercellIds: [1000011],
    maxByTh: {
      11: { maxLevel: 10, count: 5 },
      12: { maxLevel: 11, count: 5 },
      13: { maxLevel: 13, count: 5 },
      14: { maxLevel: 14, count: 5 },
      15: { maxLevel: 15, count: 5 },
      16: { maxLevel: 16, count: 5 },
      17: { maxLevel: 17, count: 5 },
    },
  },
  {
    id: 'air_sweeper',
    nameRu: 'Воздушный чистильщик',
    category: 'defenses',
    supercellIds: [1000028],
    maxByTh: {
      11: { maxLevel: 7, count: 2 },
      12: { maxLevel: 7, count: 2 },
      13: { maxLevel: 7, count: 2 },
      14: { maxLevel: 7, count: 2 },
      15: { maxLevel: 7, count: 2 },
      16: { maxLevel: 7, count: 2 },
      17: { maxLevel: 7, count: 2 },
    },
  },
  {
    id: 'hidden_tesla',
    nameRu: 'Потайная тесла',
    category: 'defenses',
    supercellIds: [1000019],
    maxByTh: {
      11: { maxLevel: 9, count: 4 },
      12: { maxLevel: 10, count: 5 },
      13: { maxLevel: 12, count: 5 },
      14: { maxLevel: 13, count: 5 },
      15: { maxLevel: 14, count: 5 },
      16: { maxLevel: 15, count: 5 },
      17: { maxLevel: 16, count: 5 },
    },
  },
  {
    id: 'bomb_tower',
    nameRu: 'Башня-бомбёжка',
    category: 'defenses',
    supercellIds: [1000032],
    maxByTh: {
      11: { maxLevel: 6, count: 2 },
      12: { maxLevel: 7, count: 2 },
      13: { maxLevel: 8, count: 2 },
      14: { maxLevel: 9, count: 2 },
      15: { maxLevel: 10, count: 2 },
      16: { maxLevel: 11, count: 2 },
      17: { maxLevel: 12, count: 2 },
    },
  },
  {
    id: 'xbow',
    nameRu: 'Арбалет',
    category: 'defenses',
    supercellIds: [1000021],
    maxByTh: {
      11: { maxLevel: 5, count: 4 },
      12: { maxLevel: 6, count: 4 },
      13: { maxLevel: 8, count: 4 },
      14: { maxLevel: 9, count: 4 },
      15: { maxLevel: 10, count: 4 },
      16: { maxLevel: 11, count: 4 },
      17: { maxLevel: 12, count: 4 },
    },
  },
  {
    id: 'inferno_tower',
    nameRu: 'Адская башня',
    category: 'defenses',
    supercellIds: [1000027],
    maxByTh: {
      11: { maxLevel: 5, count: 2 },
      12: { maxLevel: 6, count: 3 },
      13: { maxLevel: 7, count: 3 },
      14: { maxLevel: 8, count: 3 },
      15: { maxLevel: 9, count: 3 },
      16: { maxLevel: 10, count: 3 },
      17: { maxLevel: 11, count: 3 },
    },
  },
  {
    id: 'eagle_artillery',
    nameRu: 'Орлиная артиллерия',
    category: 'defenses',
    supercellIds: [1000031],
    maxByTh: {
      11: { maxLevel: 2, count: 1 },
      12: { maxLevel: 3, count: 1 },
      13: { maxLevel: 4, count: 1 },
      14: { maxLevel: 5, count: 1 },
      15: { maxLevel: 6, count: 1 },
      16: { maxLevel: 7, count: 1 },
      17: { maxLevel: 0, count: 0 }, // merged into TH17
    },
  },
  {
    id: 'scattershot',
    nameRu: 'Швырятель',
    category: 'defenses',
    supercellIds: [1000067],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 2, count: 2 },
      14: { maxLevel: 3, count: 2 },
      15: { maxLevel: 4, count: 2 },
      16: { maxLevel: 5, count: 2 },
      17: { maxLevel: 6, count: 2 },
    },
  },
  {
    id: 'spell_tower',
    nameRu: 'Башня заклинаний',
    category: 'defenses',
    supercellIds: [1000072],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 3, count: 2 },
      16: { maxLevel: 3, count: 2 },
      17: { maxLevel: 3, count: 2 },
    },
  },
  {
    id: 'monolith',
    nameRu: 'Монолит',
    category: 'defenses',
    supercellIds: [1000077],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 2, count: 1 },
      16: { maxLevel: 3, count: 1 },
      17: { maxLevel: 4, count: 1 },
    },
  },
  {
    id: 'firespitter',
    nameRu: 'Запускатель огня',
    category: 'defenses',
    supercellIds: [1000089],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 0, count: 0 },
      16: { maxLevel: 0, count: 0 },
      17: { maxLevel: 2, count: 2 },
    },
  },
  {
    id: 'builder_hut_battle',
    nameRu: 'Боевая хижина строителя',
    category: 'defenses',
    supercellIds: [1000015],
    maxByTh: {
      11: { maxLevel: 1, count: 5 },
      12: { maxLevel: 1, count: 5 },
      13: { maxLevel: 1, count: 5 },
      14: { maxLevel: 4, count: 5 },
      15: { maxLevel: 5, count: 5 },
      16: { maxLevel: 6, count: 5 },
      17: { maxLevel: 7, count: 5 },
    },
  },

  // HEROES
  {
    id: 'barbarian_king',
    nameRu: 'Король варваров',
    category: 'heroes',
    supercellIds: [28000000],
    maxByTh: {
      11: { maxLevel: 50, count: 1 },
      12: { maxLevel: 65, count: 1 },
      13: { maxLevel: 75, count: 1 },
      14: { maxLevel: 80, count: 1 },
      15: { maxLevel: 90, count: 1 },
      16: { maxLevel: 95, count: 1 },
      17: { maxLevel: 100, count: 1 },
    },
  },
  {
    id: 'archer_queen',
    nameRu: 'Королева лучниц',
    category: 'heroes',
    supercellIds: [28000001],
    maxByTh: {
      11: { maxLevel: 50, count: 1 },
      12: { maxLevel: 65, count: 1 },
      13: { maxLevel: 75, count: 1 },
      14: { maxLevel: 80, count: 1 },
      15: { maxLevel: 90, count: 1 },
      16: { maxLevel: 95, count: 1 },
      17: { maxLevel: 100, count: 1 },
    },
  },
  {
    id: 'grand_warden',
    nameRu: 'Хранитель',
    category: 'heroes',
    supercellIds: [28000002],
    maxByTh: {
      11: { maxLevel: 20, count: 1 },
      12: { maxLevel: 40, count: 1 },
      13: { maxLevel: 50, count: 1 },
      14: { maxLevel: 55, count: 1 },
      15: { maxLevel: 65, count: 1 },
      16: { maxLevel: 70, count: 1 },
      17: { maxLevel: 75, count: 1 },
    },
  },
  {
    id: 'royal_champion',
    nameRu: 'Королевский чемпион',
    category: 'heroes',
    supercellIds: [28000004],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 25, count: 1 },
      14: { maxLevel: 30, count: 1 },
      15: { maxLevel: 40, count: 1 },
      16: { maxLevel: 45, count: 1 },
      17: { maxLevel: 50, count: 1 },
    },
  },
  {
    id: 'minion_prince',
    nameRu: 'Принц миньонов',
    category: 'heroes',
    supercellIds: [28000006],
    maxByTh: {
      11: { maxLevel: 30, count: 1 },
      12: { maxLevel: 40, count: 1 },
      13: { maxLevel: 50, count: 1 },
      14: { maxLevel: 60, count: 1 },
      15: { maxLevel: 70, count: 1 },
      16: { maxLevel: 80, count: 1 },
      17: { maxLevel: 90, count: 1 },
    },
  },

  // LAB (Key Troops, Spells & Pets)
  {
    id: 'electro_dragon',
    nameRu: 'Электродракон',
    category: 'lab',
    supercellIds: [4000059],
    maxByTh: {
      11: { maxLevel: 2, count: 1 },
      12: { maxLevel: 3, count: 1 },
      13: { maxLevel: 4, count: 1 },
      14: { maxLevel: 5, count: 1 },
      15: { maxLevel: 6, count: 1 },
      16: { maxLevel: 7, count: 1 },
      17: { maxLevel: 8, count: 1 },
    },
  },
  {
    id: 'root_rider',
    nameRu: 'Корневой всадник',
    category: 'lab',
    supercellIds: [4000110],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 2, count: 1 },
      16: { maxLevel: 3, count: 1 },
      17: { maxLevel: 3, count: 1 },
    },
  },
  {
    id: 'dragon',
    nameRu: 'Дракон',
    category: 'lab',
    supercellIds: [4000008],
    maxByTh: {
      11: { maxLevel: 6, count: 1 },
      12: { maxLevel: 7, count: 1 },
      13: { maxLevel: 8, count: 1 },
      14: { maxLevel: 9, count: 1 },
      15: { maxLevel: 10, count: 1 },
      16: { maxLevel: 11, count: 1 },
      17: { maxLevel: 12, count: 1 },
    },
  },
  {
    id: 'balloon',
    nameRu: 'Воздушный шар',
    category: 'lab',
    supercellIds: [4000005],
    maxByTh: {
      11: { maxLevel: 7, count: 1 },
      12: { maxLevel: 8, count: 1 },
      13: { maxLevel: 9, count: 1 },
      14: { maxLevel: 10, count: 1 },
      15: { maxLevel: 10, count: 1 },
      16: { maxLevel: 11, count: 1 },
      17: { maxLevel: 12, count: 1 },
    },
  },
  {
    id: 'yeti',
    nameRu: 'Йети',
    category: 'lab',
    supercellIds: [4000053],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 2, count: 1 },
      13: { maxLevel: 3, count: 1 },
      14: { maxLevel: 4, count: 1 },
      15: { maxLevel: 5, count: 1 },
      16: { maxLevel: 6, count: 1 },
      17: { maxLevel: 6, count: 1 },
    },
  },
  {
    id: 'healer',
    nameRu: 'Целительница',
    category: 'lab',
    supercellIds: [4000007],
    maxByTh: {
      11: { maxLevel: 5, count: 1 },
      12: { maxLevel: 5, count: 1 },
      13: { maxLevel: 6, count: 1 },
      14: { maxLevel: 7, count: 1 },
      15: { maxLevel: 8, count: 1 },
      16: { maxLevel: 9, count: 1 },
      17: { maxLevel: 10, count: 1 },
    },
  },
  {
    id: 'rage_spell',
    nameRu: 'Заклинание ярости',
    category: 'lab',
    supercellIds: [26000002],
    maxByTh: {
      11: { maxLevel: 5, count: 1 },
      12: { maxLevel: 6, count: 1 },
      13: { maxLevel: 6, count: 1 },
      14: { maxLevel: 6, count: 1 },
      15: { maxLevel: 6, count: 1 },
      16: { maxLevel: 6, count: 1 },
      17: { maxLevel: 6, count: 1 },
    },
  },
  {
    id: 'freeze_spell',
    nameRu: 'Заморозка',
    category: 'lab',
    supercellIds: [26000005],
    maxByTh: {
      11: { maxLevel: 6, count: 1 },
      12: { maxLevel: 7, count: 1 },
      13: { maxLevel: 7, count: 1 },
      14: { maxLevel: 7, count: 1 },
      15: { maxLevel: 7, count: 1 },
      16: { maxLevel: 7, count: 1 },
      17: { maxLevel: 7, count: 1 },
    },
  },
  {
    id: 'spirit_fox',
    nameRu: 'Призрачная лиса (питомец)',
    category: 'lab',
    supercellIds: [73000009],
    maxByTh: {
      11: { maxLevel: 0, count: 0 },
      12: { maxLevel: 0, count: 0 },
      13: { maxLevel: 0, count: 0 },
      14: { maxLevel: 0, count: 0 },
      15: { maxLevel: 0, count: 0 },
      16: { maxLevel: 10, count: 1 },
      17: { maxLevel: 10, count: 1 },
    },
  },

  // TRAPS
  {
    id: 'bomb',
    nameRu: 'Бомба',
    category: 'traps',
    supercellIds: [12000000],
    maxByTh: {
      11: { maxLevel: 7, count: 6 },
      12: { maxLevel: 8, count: 6 },
      13: { maxLevel: 9, count: 7 },
      14: { maxLevel: 10, count: 7 },
      15: { maxLevel: 11, count: 8 },
      16: { maxLevel: 12, count: 8 },
      17: { maxLevel: 13, count: 8 },
    },
  },
  {
    id: 'giant_bomb',
    nameRu: 'Гигантская бомба',
    category: 'traps',
    supercellIds: [12000005],
    maxByTh: {
      11: { maxLevel: 5, count: 5 },
      12: { maxLevel: 5, count: 6 },
      13: { maxLevel: 7, count: 6 },
      14: { maxLevel: 8, count: 7 },
      15: { maxLevel: 9, count: 7 },
      16: { maxLevel: 10, count: 7 },
      17: { maxLevel: 11, count: 8 },
    },
  },
  {
    id: 'seeking_air_mine',
    nameRu: 'Воздушная мина',
    category: 'traps',
    supercellIds: [12000006],
    maxByTh: {
      11: { maxLevel: 3, count: 5 },
      12: { maxLevel: 3, count: 6 },
      13: { maxLevel: 4, count: 7 },
      14: { maxLevel: 4, count: 8 },
      15: { maxLevel: 5, count: 8 },
      16: { maxLevel: 6, count: 8 },
      17: { maxLevel: 7, count: 9 },
    },
  },
  {
    id: 'tornado_trap',
    nameRu: 'Торнадо-ловушка',
    category: 'traps',
    supercellIds: [12000016],
    maxByTh: {
      11: { maxLevel: 2, count: 1 },
      12: { maxLevel: 3, count: 1 },
      13: { maxLevel: 3, count: 1 },
      14: { maxLevel: 3, count: 1 },
      15: { maxLevel: 3, count: 1 },
      16: { maxLevel: 3, count: 1 },
      17: { maxLevel: 3, count: 1 },
    },
  },

  // RESOURCES & ARMY INFRASTRUCTURE
  {
    id: 'clan_castle',
    nameRu: 'Крепость клана',
    category: 'resources',
    supercellIds: [1000014],
    maxByTh: {
      11: { maxLevel: 7, count: 1 },
      12: { maxLevel: 8, count: 1 },
      13: { maxLevel: 9, count: 1 },
      14: { maxLevel: 10, count: 1 },
      15: { maxLevel: 11, count: 1 },
      16: { maxLevel: 12, count: 1 },
      17: { maxLevel: 13, count: 1 },
    },
  },
  {
    id: 'army_camp',
    nameRu: 'Военный лагерь',
    category: 'resources',
    supercellIds: [1000000],
    maxByTh: {
      11: { maxLevel: 9, count: 4 },
      12: { maxLevel: 10, count: 4 },
      13: { maxLevel: 11, count: 4 },
      14: { maxLevel: 11, count: 4 },
      15: { maxLevel: 12, count: 4 },
      16: { maxLevel: 12, count: 4 },
      17: { maxLevel: 13, count: 4 },
    },
  },
  {
    id: 'laboratory',
    nameRu: 'Лаборатория',
    category: 'resources',
    supercellIds: [1000007],
    maxByTh: {
      11: { maxLevel: 9, count: 1 },
      12: { maxLevel: 10, count: 1 },
      13: { maxLevel: 11, count: 1 },
      14: { maxLevel: 12, count: 1 },
      15: { maxLevel: 13, count: 1 },
      16: { maxLevel: 14, count: 1 },
      17: { maxLevel: 15, count: 1 },
    },
  },
  {
    id: 'gold_storage',
    nameRu: 'Золотохранилище',
    category: 'resources',
    supercellIds: [1000003],
    maxByTh: {
      11: { maxLevel: 12, count: 4 },
      12: { maxLevel: 13, count: 4 },
      13: { maxLevel: 14, count: 4 },
      14: { maxLevel: 15, count: 4 },
      15: { maxLevel: 16, count: 4 },
      16: { maxLevel: 17, count: 4 },
      17: { maxLevel: 18, count: 4 },
    },
  },
  {
    id: 'elixir_storage',
    nameRu: 'Эликсирохранилище',
    category: 'resources',
    supercellIds: [1000005],
    maxByTh: {
      11: { maxLevel: 12, count: 4 },
      12: { maxLevel: 13, count: 4 },
      13: { maxLevel: 14, count: 4 },
      14: { maxLevel: 15, count: 4 },
      15: { maxLevel: 16, count: 4 },
      16: { maxLevel: 17, count: 4 },
      17: { maxLevel: 18, count: 4 },
    },
  },
];

export const WALL_CAPS_BY_TH: Record<number, { maxLevel: number; count: number }> = {
  8: { maxLevel: 8, count: 225 },
  9: { maxLevel: 10, count: 250 },
  10: { maxLevel: 11, count: 275 },
  11: { maxLevel: 12, count: 300 },
  12: { maxLevel: 13, count: 300 },
  13: { maxLevel: 14, count: 300 },
  14: { maxLevel: 15, count: 325 },
  15: { maxLevel: 16, count: 325 },
  16: { maxLevel: 17, count: 325 },
  17: { maxLevel: 18, count: 325 },
  18: { maxLevel: 19, count: 325 },
};

export function getCapForTh(
  def: EntityDefinition,
  th: number
): { maxLevel: number; count: number } {
  if (def.maxByTh[th]) return def.maxByTh[th];
  if (th >= 18) {
    const c17 = def.maxByTh[17];
    if (!c17 || c17.maxLevel === 0) return { maxLevel: 0, count: 0 };
    return { maxLevel: c17.maxLevel + 1, count: c17.count };
  }
  const c11 = def.maxByTh[11];
  if (!c11 || c11.maxLevel === 0) return { maxLevel: 0, count: 0 };
  const diff = Math.max(0, 11 - th);
  return {
    maxLevel: Math.max(1, c11.maxLevel - diff * 2),
    count: Math.max(1, c11.count - (c11.count > 2 ? Math.min(2, diff) : 0)),
  };
}

export function getWallCapForTh(th: number): { maxLevel: number; count: number } {
  if (WALL_CAPS_BY_TH[th]) return WALL_CAPS_BY_TH[th];
  if (th >= 18) return WALL_CAPS_BY_TH[18];
  return { maxLevel: Math.max(4, th), count: Math.max(125, th * 25) };
}

export function getEntityDef(id: string): EntityDefinition | undefined {
  return VILLAGE_ENTITIES.find((e) => e.id === id);
}

export function getEntityBySupercellId(scId: number): EntityDefinition | undefined {
  return VILLAGE_ENTITIES.find((e) => e.supercellIds.includes(scId));
}

export function calculatePlayerProgress(
  townHallLevel: number,
  items: VillageItemInstance[],
  walls: WallSummary
): PlayerProgressSummary {
  const th = Math.max(1, Math.min(18, townHallLevel));

  const catTotals: Record<Exclude<VillageCategory, 'walls'>, { cur: number; max: number }> = {
    defenses: { cur: 0, max: 0 },
    heroes: { cur: 0, max: 0 },
    lab: { cur: 0, max: 0 },
    traps: { cur: 0, max: 0 },
    resources: { cur: 0, max: 0 },
  };

  let completedLevels = 0;
  let totalLevelsForTh = 0;
  let maxedItemsCount = 0;
  let totalItemsCount = 0;

  for (const item of items) {
    if (item.category === 'walls') continue;
    const maxLv = item.maxLevelForTh;
    const expected = item.expectedCount;
    if (maxLv <= 0 || expected <= 0) continue;

    const itemMaxTotal = maxLv * expected;
    const itemCurTotal = item.levels.reduce((acc, lv) => acc + Math.min(lv, maxLv), 0);

    catTotals[item.category].cur += itemCurTotal;
    catTotals[item.category].max += itemMaxTotal;

    completedLevels += itemCurTotal;
    totalLevelsForTh += itemMaxTotal;

    for (let i = 0; i < expected; i++) {
      totalItemsCount++;
      if ((item.levels[i] ?? 0) >= maxLv) {
        maxedItemsCount++;
      }
    }
  }

  const wallCap = getWallCapForTh(th);
  let wallCurPoints = 0;
  for (const [lvStr, qty] of Object.entries(walls.byLevel)) {
    const lv = Number(lvStr);
    wallCurPoints += Math.min(lv, wallCap.maxLevel) * qty;
  }
  const wallMaxPoints = wallCap.maxLevel * wallCap.count;
  const hasWallsData = walls.totalCount > 0 && wallMaxPoints > 0;
  const wallsPct = hasWallsData ? Math.min(100, (wallCurPoints / wallMaxPoints) * 100) : 0;

  const pct = (c: { cur: number; max: number }) =>
    c.max > 0 ? Math.min(100, (c.cur / c.max) * 100) : 0;

  const defensesPct = pct(catTotals.defenses);
  const heroesPct = pct(catTotals.heroes);
  const labPct = pct(catTotals.lab);
  const trapsPct = pct(catTotals.traps);
  const resourcesPct = pct(catTotals.resources);

  const hasFullVillageBuildings = catTotals.defenses.max > 0 || hasWallsData;

  let overallPct = 0;
  let coreAvg = 0;
  if (hasFullVillageBuildings) {
    overallPct =
      defensesPct * 0.36 +
      heroesPct * 0.28 +
      labPct * 0.16 +
      resourcesPct * 0.08 +
      trapsPct * 0.06 +
      wallsPct * 0.06;
    coreAvg = defensesPct * 0.55 + heroesPct * 0.45;
  } else if (totalLevelsForTh > 0) {
    // Only Heroes & Lab data from Official Supercell API (no fake building levels)
    overallPct = (completedLevels / totalLevelsForTh) * 100;
    coreAvg = catTotals.heroes.max > 0 ? heroesPct : overallPct;
  }

  const rushScore = totalLevelsForTh > 0 ? Math.max(0, Math.min(100, Math.round(100 - coreAvg))) : 0;

  let statusLabel: PlayerProgressSummary['statusLabel'] = 'В прокачке';
  if (overallPct >= 97.5) statusLabel = 'Фулл';
  else if (coreAvg >= 78) statusLabel = 'Сбалансирована';
  else if (coreAvg < 58 && totalLevelsForTh > 0) statusLabel = 'Раш';

  return {
    overallPct: Number(overallPct.toFixed(1)),
    defensesPct: Number(defensesPct.toFixed(1)),
    heroesPct: Number(heroesPct.toFixed(1)),
    labPct: Number(labPct.toFixed(1)),
    trapsPct: Number(trapsPct.toFixed(1)),
    resourcesPct: Number(resourcesPct.toFixed(1)),
    wallsPct: Number(wallsPct.toFixed(1)),
    completedLevels,
    totalLevelsForTh,
    maxedItemsCount,
    totalItemsCount,
    rushScore,
    statusLabel,
  };
}

export function groupPlayersByTownHall(
  players: PlayerProfile[],
  events: UpgradeEvent[]
): TownHallGroupSummary[] {
  const map = new Map<number, PlayerProfile[]>();
  for (const p of players) {
    const list = map.get(p.townHallLevel) ?? [];
    list.push(p);
    map.set(p.townHallLevel, list);
  }

  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const keyIds = [
    'cannon',
    'ricochet_cannon',
    'archer_tower',
    'xbow',
    'inferno_tower',
    'eagle_artillery',
    'scattershot',
    'monolith',
    'barbarian_king',
    'archer_queen',
  ];

  const groups: TownHallGroupSummary[] = [];
  for (const [th, thPlayers] of Array.from(map.entries()).sort((a, b) => b[0] - a[0])) {
    const n = thPlayers.length;
    const avg = (fn: (p: PlayerProfile) => number) =>
      Number((thPlayers.reduce((s, p) => s + fn(p), 0) / n).toFixed(1));

    const recentUpgradesCount = events.filter(
      (e) => e.townHallLevel === th && new Date(e.timestamp).getTime() >= sevenDaysAgo
    ).length;

    const keyBuildingAverages: TownHallGroupSummary['keyBuildingAverages'] = [];
    for (const id of keyIds) {
      const def = getEntityDef(id);
      if (!def) continue;
      const thCap = def.maxByTh[th];
      if (!thCap || thCap.maxLevel === 0 || thCap.count === 0) continue;

      let levelSum = 0;
      let instanceSum = 0;
      for (const p of thPlayers) {
        const item = p.items.find((i) => i.id === id);
        if (item && item.levels.length > 0) {
          levelSum += item.levels.reduce((a, b) => a + b, 0);
          instanceSum += item.levels.length;
        }
      }
      if (instanceSum > 0) {
        keyBuildingAverages.push({
          id,
          nameRu: def.nameRu,
          avgLevel: Number((levelSum / instanceSum).toFixed(1)),
          maxLevel: thCap.maxLevel,
        });
      }
    }

    groups.push({
      townHallLevel: th,
      playerCount: n,
      avgOverallPct: avg((p) => p.progress.overallPct),
      avgDefensesPct: avg((p) => p.progress.defensesPct),
      avgHeroesPct: avg((p) => p.progress.heroesPct),
      avgLabPct: avg((p) => p.progress.labPct),
      avgWallsPct: avg((p) => p.progress.wallsPct),
      avgTrapsPct: avg((p) => p.progress.trapsPct),
      activeBuildersCount: thPlayers.reduce((s, p) => s + p.activeBuilders.length, 0),
      recentUpgradesCount,
      keyBuildingAverages,
      players: [...thPlayers].sort((a, b) => b.progress.overallPct - a.progress.overallPct),
    });
  }

  return groups;
}

export function computeClanAggregateStats(
  players: PlayerProfile[],
  wars: ClanWarEntry[]
): ClanAggregateStats {
  const n = Math.max(1, players.length);
  const avg = (fn: (p: PlayerProfile) => number) =>
    Number((players.reduce((s, p) => s + fn(p), 0) / n).toFixed(1));

  const totalWarStarsAllTime = players.reduce((s, p) => s + p.warStars, 0);
  const totalMultiplayerAttacksWon = players.reduce((s, p) => s + (p.combat?.attacksWon ?? 0), 0);
  const totalMultiplayerDefensesWon = players.reduce((s, p) => s + (p.combat?.defensesWon ?? 0), 0);

  const totalWarAttacks = wars.reduce((s, w) => s + w.attacksUsed, 0);
  const totalThreeStars = wars.reduce((s, w) => s + w.threeStarAttacks, 0);
  const totalWarStars = wars.reduce((s, w) => s + w.clanStars, 0);
  const totalMaxStars = wars.reduce((s, w) => s + w.maxStars, 0);
  const totalEnemyAttacks = wars.reduce((s, w) => s + w.totalEnemyAttacks, 0);
  const totalDefensesHeld = wars.reduce((s, w) => s + w.defensesHeld, 0);
  const totalEnemyStars = wars.reduce((s, w) => s + w.opponentStars, 0);

  const warsWonCount = wars.filter((w) => w.result === 'win').length;
  const warsPlayedCount = wars.length;

  const avgWarDestructionPct =
    warsPlayedCount > 0
      ? Number((wars.reduce((s, w) => s + w.clanDestruction, 0) / warsPlayedCount).toFixed(1))
      : 0;

  return {
    totalWarStarsAllTime,
    recentWarStarsEarned: totalWarStars,
    avgStarsPerWar: warsPlayedCount > 0 ? Number((totalWarStars / warsPlayedCount).toFixed(1)) : 0,
    totalMultiplayerAttacksWon,
    totalMultiplayerDefensesWon,
    attackSuccessRatePct:
      totalMaxStars > 0 ? Number(((totalWarStars / totalMaxStars) * 100).toFixed(1)) : 0,
    threeStarRatePct:
      totalWarAttacks > 0 ? Number(((totalThreeStars / totalWarAttacks) * 100).toFixed(1)) : 0,
    avgWarDestructionPct,
    defenseHoldRatePct:
      totalEnemyAttacks > 0 ? Number(((totalDefensesHeld / totalEnemyAttacks) * 100).toFixed(1)) : 0,
    avgStarsConcededPerDefense:
      totalEnemyAttacks > 0 ? Number((totalEnemyStars / totalEnemyAttacks).toFixed(2)) : 0,
    avgBaseProgressPct: avg((p) => p.progress.overallPct),
    avgDefensesPct: avg((p) => p.progress.defensesPct),
    avgHeroesPct: avg((p) => p.progress.heroesPct),
    avgLabPct: avg((p) => p.progress.labPct),
    avgWallsPct: avg((p) => p.progress.wallsPct),
    avgTrapsPct: avg((p) => p.progress.trapsPct),
    warWinRatePct: warsPlayedCount > 0 ? Number(((warsWonCount / warsPlayedCount) * 100).toFixed(1)) : 0,
    warsPlayedCount,
    warsWonCount,
  };
}

export interface ParsedVillageExport {
  tag: string;
  townHallLevel: number;
  timestamp?: number;
  items: VillageItemInstance[];
  walls: WallSummary;
  recognizedCount: number;
}

interface RawSupercellEntry {
  data: number;
  lvl: number;
  cnt?: number;
}

/**
 * Parses official Clash of Clans in-game Data Export JSON:
 * Settings -> More Settings -> Data Export -> Copy
 */
export function parseSupercellVillageJson(rawText: string): ParsedVillageExport {
  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    throw new Error('Некорректный формат JSON. Вставьте полный текст экспорта из Clash of Clans.');
  }

  if (!parsed || typeof parsed !== 'object') {
    throw new Error('JSON должен быть объектом деревни Clash of Clans.');
  }

  const tag = typeof parsed.tag === 'string' && parsed.tag.trim() ? parsed.tag.trim().toUpperCase() : '#CUSTOM';
  const buildings = Array.isArray(parsed.buildings) ? (parsed.buildings as RawSupercellEntry[]) : [];
  const traps = Array.isArray(parsed.traps) ? (parsed.traps as RawSupercellEntry[]) : [];
  const units = Array.isArray(parsed.units) ? (parsed.units as RawSupercellEntry[]) : [];
  const spells = Array.isArray(parsed.spells) ? (parsed.spells as RawSupercellEntry[]) : [];
  const heroes = Array.isArray(parsed.heroes) ? (parsed.heroes as RawSupercellEntry[]) : [];
  const pets = Array.isArray(parsed.pets) ? (parsed.pets as RawSupercellEntry[]) : [];

  const allEntries = [...buildings, ...traps, ...units, ...spells, ...heroes, ...pets];
  if (allEntries.length === 0) {
    throw new Error('В JSON не найдены массивы buildings, heroes, units или traps.');
  }

  // Detect Town Hall (data: 1000001)
  const thEntry = buildings.find((b) => b.data === 1000001);
  const townHallLevel = thEntry ? Math.max(1, Math.min(18, Number(thEntry.lvl) || 16)) : 16;

  // Group levels by entity id
  const levelsMap = new Map<string, number[]>();
  const wallByLevel: Record<number, number> = {};
  let wallTotal = 0;
  let recognizedCount = 0;

  for (const entry of allEntries) {
    const dataId = Number(entry.data);
    const lvl = Number(entry.lvl) || 0;
    const cnt = Math.max(1, Number(entry.cnt) || 1);

    if (dataId === 1000010) {
      // Walls
      wallByLevel[lvl] = (wallByLevel[lvl] ?? 0) + cnt;
      wallTotal += cnt;
      recognizedCount += cnt;
      continue;
    }

    const def = getEntityBySupercellId(dataId);
    if (!def) continue;

    recognizedCount += cnt;
    const arr = levelsMap.get(def.id) ?? [];
    for (let i = 0; i < cnt; i++) {
      arr.push(lvl);
    }
    levelsMap.set(def.id, arr);
  }

  // Build normalized items list for this TH
  const items: VillageItemInstance[] = [];
  for (const def of VILLAGE_ENTITIES) {
    const cap = getCapForTh(def, townHallLevel);
    if (cap.maxLevel === 0 || cap.count === 0) continue;

    const detected = (levelsMap.get(def.id) ?? []).sort((a, b) => b - a);
    const levels =
      detected.length > 0
        ? detected.slice(0, Math.max(detected.length, cap.count))
        : Array(cap.count).fill(0);

    items.push({
      id: def.id,
      nameRu: def.nameRu,
      category: def.category,
      levels,
      maxLevelForTh: cap.maxLevel,
      expectedCount: cap.count,
      supercellId: def.supercellIds[0],
    });
  }

  const wallCap = getWallCapForTh(townHallLevel);

  return {
    tag: tag.startsWith('#') ? tag : `#${tag}`,
    townHallLevel,
    timestamp: typeof parsed.timestamp === 'number' ? parsed.timestamp : undefined,
    items,
    walls: {
      totalCount: wallTotal,
      maxLevelForTh: wallCap.maxLevel,
      byLevel: wallByLevel,
    },
    recognizedCount,
  };
}
