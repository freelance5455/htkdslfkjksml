import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { Bell, Check, Flame, Gauge, Play, Settings, Shield, Target, Trophy, Zap } from 'lucide-react'
import './styles.css'

type Mission = { id: number; title: string; xp: number; done: boolean }

const initialMissions: Mission[] = [
  { id: 1, title: '25 min focused study', xp: 80, done: false },
  { id: 2, title: 'Complete one priority task', xp: 60, done: false },
  { id: 3, title: 'Take a 10 min screen break', xp: 40, done: false }
]

function App() {
  const [xp, setXp] = useState(() => Number(localStorage.getItem('ll-xp') || 1240))
  const [streak, setStreak] = useState(() => Number(localStorage.getItem('ll-streak') || 6))
  const [focus, setFocus] = useState(false)
  const [seconds, setSeconds] = useState(25 * 60)
  const [missions, setMissions] = useState<Mission[]>(() => {
    try { return JSON.parse(localStorage.getItem('ll-missions') || 'null') || initialMissions } catch { return initialMissions }
  })
  const [notice, setNotice] = useState('Ready for today.')

  const level = Math.floor(xp / 500) + 1
  const current = xp % 500
  const progress = Math.min(100, Math.round(current / 5))

  useEffect(() => { localStorage.setItem('ll-xp', String(xp)) }, [xp])
  useEffect(() => { localStorage.setItem('ll-streak', String(streak)) }, [streak])
  useEffect(() => { localStorage.setItem('ll-missions', JSON.stringify(missions)) }, [missions])

  useEffect(() => {
    if (!focus) return
    const t = window.setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000)
    return () => window.clearInterval(t)
  }, [focus])

  useEffect(() => {
    if (focus && seconds === 0) {
      setFocus(false); setXp(v => v + 100); setNotice('Focus complete! +100 XP')
      setSeconds(25 * 60)
    }
  }, [seconds, focus])

  const time = useMemo(() => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`, [seconds])

  const completeMission = (id: number) => {
    setMissions(ms => ms.map(m => m.id === id && !m.done ? { ...m, done: true } : m))
    const m = missions.find(x => x.id === id)
    if (m && !m.done) { setXp(v => v + m.xp); setNotice(`${m.title} complete! +${m.xp} XP`) }
  }

  const addStudy = () => { setXp(v => v + 25); setNotice('Study session logged. +25 XP') }
  const reset = () => { setXp(1240); setStreak(6); setMissions(initialMissions); setNotice('Progress reset locally.') }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><img src="./icon.png" /><div><b>LEVEL LIFE</b><span>PLAN • FOCUS • ACHIEVE</span></div></div>
      <button className="icon-btn" onClick={() => setNotice('Settings are saved automatically on this device.')} aria-label="Settings"><Settings size={20}/></button>
    </header>

    <main>
      <section className="hero card">
        <div className="hero-copy"><p className="eyebrow">YOUR DAILY PROGRESS</p><h1>Level {level}</h1><p className="muted">Build your real-life streak, one focused action at a time.</p>
          <div className="xp-row"><span>{current} / 500 XP</span><strong>{xp.toLocaleString()} total XP</strong></div>
          <div className="progress"><i style={{width: `${progress}%`}} /></div>
        </div>
        <div className="level-badge"><Zap size={26}/><strong>{level}</strong><span>LEVEL</span></div>
      </section>

      <section className="stats-grid">
        <div className="card stat"><Flame/><span>STREAK</span><b>{streak} days</b></div>
        <div className="card stat"><Trophy/><span>RANK</span><b>Rising</b></div>
        <div className="card stat"><Gauge/><span>TODAY</span><b>{progress}% XP</b></div>
      </section>

      <section className="card focus-card">
        <div className="section-head"><div><p className="eyebrow">FOCUS MODE</p><h2>{time}</h2></div><div className={focus ? 'live-dot on' : 'live-dot'}>{focus ? 'ACTIVE' : 'READY'}</div></div>
        <p className="muted">Stay on one task. Finish the timer to earn <b>+100 XP</b>.</p>
        <div className="focus-actions"><button className="primary" onClick={() => setFocus(v => !v)}><Play size={18}/>{focus ? 'Pause Focus' : 'Start 25 min'}</button><button className="secondary" onClick={() => {setSeconds(25*60); setFocus(false)}}>Reset</button></div>
      </section>

      <section className="card">
        <div className="section-head"><div><p className="eyebrow">DAILY MISSIONS</p><h2>Win the day</h2></div><Target/></div>
        <div className="missions">{missions.map(m => <button key={m.id} className={`mission ${m.done ? 'done' : ''}`} onClick={() => completeMission(m.id)}><span className="check">{m.done ? <Check size={16}/> : ''}</span><span className="mission-title">{m.title}</span><b>+{m.xp}</b></button>)}</div>
      </section>

      <section className="card safety">
        <Shield/><div><b>Private by design</b><p className="muted">This prototype stores progress only in your browser/device storage. It does not read data from other apps.</p></div>
      </section>

      <div className="bottom-actions"><button onClick={addStudy}><Zap size={16}/> Log +25 XP</button><button onClick={() => setNotice('Daily reminder preference saved.')}><Bell size={16}/> Reminder</button><button onClick={reset}>Reset demo</button></div>
      <p className="notice">{notice}</p>
    </main>
  </div>
}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>)
