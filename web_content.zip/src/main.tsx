import React, { Component, ErrorInfo, ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class GlobalErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('TV Station Tycoon error caught:', error, errorInfo);
  }

  public handleRecover = () => {
    try {
      localStorage.removeItem('rede_brasilis_tycoon_save_v1');
    } catch {
      // ignore
    }
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="w-full h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center select-none text-white">
          {/* SMPTE Rainbow Bars Background */}
          <div className="w-full max-w-lg h-48 rounded-2xl overflow-hidden border-2 border-slate-700 relative shadow-2xl flex flex-col justify-between p-4 mb-6">
            <div className="absolute inset-0 grid grid-cols-7 opacity-85">
              <div className="bg-slate-200" />
              <div className="bg-yellow-400" />
              <div className="bg-cyan-400" />
              <div className="bg-emerald-500" />
              <div className="bg-fuchsia-600" />
              <div className="bg-red-600" />
              <div className="bg-blue-700" />
            </div>
            <div className="relative z-10 bg-black/80 text-amber-400 font-mono text-xs font-bold px-3 py-1 rounded inline-block mx-auto uppercase">
              SINAL INTERROMPIDO · CENTRAL TÉCNICA
            </div>
            <div className="relative z-10 bg-black/80 text-white font-mono text-[11px] px-3 py-1 rounded inline-block mx-auto">
              FALHA TÉCNICA RECUPERÁVEL
            </div>
          </div>

          <h1 className="text-xl font-bold font-display text-white">
            Interrupção na Transmissão
          </h1>
          <p className="text-xs text-slate-400 max-w-md mt-2 mb-6">
            Houve uma oscilação na rede de transmissão. Clique abaixo para restaurar o sinal e retomar o comando da sua emissora.
          </p>

          <button
            onClick={this.handleRecover}
            className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-950/40 cursor-pointer"
          >
            Restaurar Sinal & Reiniciar
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <GlobalErrorBoundary>
    <App />
  </GlobalErrorBoundary>
);
