import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Automatically register PWA Service Worker for Android offline & WebAPK installation
registerSW({ immediate: true });

createRoot(document.getElementById('root')!).render(<App />);
