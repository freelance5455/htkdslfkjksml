import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  (window as unknown as {__deferredInstallPrompt?: Event}).__deferredInstallPrompt = e;
});

registerSW({immediate: true});

createRoot(document.getElementById('root')!).render(<App />);
