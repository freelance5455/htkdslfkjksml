import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
import { runExtractVideoIdTests } from './utils/extractVideoId';

// بيانات عرض تجريبية في وضع التطوير فقط (‎/?demo=1‎) لتسهيل معاينة الواجهات
if (import.meta.env.DEV && new URLSearchParams(window.location.search).has('demo')) {
  const key = 'manara.v1.profile';
  if (!localStorage.getItem(key)) {
    localStorage.setItem(
      key,
      JSON.stringify({
        name: 'سارة',
        governorate: 'دمشق',
        targetAverage: 88,
        examDate: `${new Date().getFullYear() + 1}-06-01`,
        createdAt: new Date().toISOString(),
        teacherBySubject: {},
        onboarded: true,
      }),
    );
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// تسجيل عامل الخدمة للموقع المنشور فقط؛ file:// لا يدعم دورة حياة PWA.
if ('serviceWorker' in navigator && import.meta.env.PROD && import.meta.env.MODE !== 'standalone') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      /* العمل بدون إنترنت ميزة إضافية، وفشلها لا يعطّل التطبيق */
    });
  });
}

// اختبارات سريعة لدالة استخراج معرّف يوتيوب (وضع التطوير فقط)
if (import.meta.env.DEV) {
  const result = runExtractVideoIdTests();
  if (result.failed.length > 0) {
    console.warn('[extractVideoId] فشل', result.failed.length, 'حالات:', result.failed);
  } else {
    console.info(`[extractVideoId] نجحت كل الحالات (${result.passed})`);
  }
}
