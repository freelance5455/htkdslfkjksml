import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Registrazione Service Worker per installazione PWA nativa su Android
if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}

createRoot(document.getElementById('root')!).render(<App />);
