import React, { Suspense } from "react";
import { createRoot } from "react-dom/client";
import "./app/globals.css";
import { App, RootLoadingFallbackHe } from "./App";
import { ErrorBoundary } from "./components/ErrorBoundary";

function mountApplication() {
  if (typeof document === "undefined") return;

  try {
    // Enforce Hebrew RTL directionality on document root
    document.documentElement.setAttribute("lang", "he");
    document.documentElement.setAttribute("dir", "rtl");
    document.documentElement.classList.add("dark");

    let rootElement = document.getElementById("root");
    if (!rootElement) {
      rootElement = document.createElement("div");
      rootElement.id = "root";
      document.body.appendChild(rootElement);
    }

    const root = createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <ErrorBoundary sectionTitleHe="נקודת כניסה ראשית (src/main.tsx)">
          <Suspense
            fallback={
              <div dir="rtl" className="p-6 text-center text-[#F1F5F9]">
                טוען את האפליקציה...
              </div>
            }
          >
            <App />
          </Suspense>
        </ErrorBoundary>
      </React.StrictMode>
    );
  } catch (err) {
    console.error("Critical WebView bootstrap error:", err);
    const fallbackContainer = document.getElementById("root") || document.body;
    fallbackContainer.innerHTML = `
      <div dir="rtl" style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#0B0E14;color:#F1F5F9;padding:24px;text-align:center;font-family:sans-serif;">
        <h2 style="color:#FF3B69;margin-bottom:8px;">שגיאה בטעינת הנתונים - לחץ לנסות שוב</h2>
        <p style="color:#94A3B8;font-size:14px;">האפליקציה נתקלה בשגיאת אתחול בסביבת WebView.</p>
        <button onclick="window.location.reload()" style="margin-top:16px;background:#3B82F6;color:#FFFFFF;border:none;padding:10px 20px;border-radius:8px;font-weight:bold;cursor:pointer;">
          נסה שוב
        </button>
      </div>
    `;
  }
}

mountApplication();
