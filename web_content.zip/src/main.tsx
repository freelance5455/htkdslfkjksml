import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerServiceWorker } from './utils/serviceWorkerSync.ts';

// Initialize Service Worker for offline data sync
registerServiceWorker().catch((err) => {
  console.warn('Service Worker registration skipped:', err);
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
