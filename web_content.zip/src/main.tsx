import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global error logging (do not destroy root on minor unhandled rejections)
window.onerror = function(msg, url, line, col, error) {
  console.warn('[Task Earn Pro] Global error caught:', msg, 'at', url, ':', line, ':', col, error);
  return false;
};

window.onunhandledrejection = function(event) {
  console.warn('[Task Earn Pro] Unhandled promise rejection caught:', event.reason);
};

function renderFatalError(error: any) {
  const rootElement = document.getElementById('root');
  if (rootElement) {
    rootElement.innerHTML = `
      <div style="position:fixed;inset:0;background:#0f172a;color:#ffffff;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:system-ui,-apple-system,sans-serif;padding:24px;text-align:center;z-index:999999;">
        <h1 style="font-size:26px;font-weight:900;margin:0 0 8px 0;color:#38bdf8;">Task Pro Earning</h1>
        <p style="font-size:14px;color:#f87171;margin:0 0 16px 0;font-weight:bold;">Application failed to start</p>
        <p style="font-size:12px;color:#94a3b8;margin:0 0 24px 0;max-width:320px;word-break:break-word;">${String(error)}</p>
        <div style="display:flex;gap:12px;width:100%;max-width:280px;justify-content:center;">
          <button onclick="window.location.reload()" style="flex:1;padding:12px;background:#2563eb;color:#ffffff;border:none;border-radius:12px;font-weight:bold;font-size:13px;cursor:pointer;">Retry</button>
          <button onclick="window.location.reload()" style="flex:1;padding:12px;background:#334155;color:#ffffff;border:none;border-radius:12px;font-weight:bold;font-size:13px;cursor:pointer;">Restart App</button>
        </div>
      </div>
    `;
  }
}

try {
  const rootElement = document.getElementById('root');
  if (!rootElement) {
    throw new Error('Root element #root not found in document.');
  }
  const root = createRoot(rootElement);
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
} catch (error) {
  console.error('[Task Pro Earning] Fatal mount error:', error);
  renderFatalError(error);
}
