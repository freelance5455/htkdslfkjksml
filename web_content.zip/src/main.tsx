import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Safe WebGL shader precision format shim to prevent Three.js WebGLCapabilities crash
// "Uncaught TypeError: Cannot read properties of null (reading 'precision')"
// when running under headless browsers, iframes, software rasterizers, or after context loss
if (typeof window !== 'undefined') {
  const safePrecision = { rangeMin: 1, rangeMax: 1, precision: 23 };

  if (typeof WebGLRenderingContext !== 'undefined' && WebGLRenderingContext.prototype) {
    const origGetFormat1 = WebGLRenderingContext.prototype.getShaderPrecisionFormat;
    WebGLRenderingContext.prototype.getShaderPrecisionFormat = function (
      shaderType: number,
      precisionType: number
    ) {
      try {
        if (origGetFormat1) {
          const res = origGetFormat1.call(this, shaderType, precisionType);
          if (res && typeof res.precision === 'number') {
            return res;
          }
        }
      } catch {
        // Context query failed or lost
      }
      return safePrecision;
    };
  }

  if (typeof WebGL2RenderingContext !== 'undefined' && WebGL2RenderingContext.prototype) {
    const origGetFormat2 = WebGL2RenderingContext.prototype.getShaderPrecisionFormat;
    WebGL2RenderingContext.prototype.getShaderPrecisionFormat = function (
      shaderType: number,
      precisionType: number
    ) {
      try {
        if (origGetFormat2) {
          const res = origGetFormat2.call(this, shaderType, precisionType);
          if (res && typeof res.precision === 'number') {
            return res;
          }
        }
      } catch {
        // Context query failed or lost
      }
      return safePrecision;
    };
  }
}

// In development, ensure any stale service worker is unregistered to prevent
// cached HTML fallbacks or stale chunk interception causing "Unexpected token '<'"
if (typeof window !== 'undefined' && 'serviceWorker' in navigator && import.meta.env.DEV) {
  navigator.serviceWorker.getRegistrations().then((registrations) => {
    for (const registration of registrations) {
      registration.unregister();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
