import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      // Clear out legacy development caches that might contain stale React chunks
      if ('caches' in window) {
        caches.keys().then((keys) => {
          keys.forEach((key) => {
            if (key !== 'juhnkrix-musika-cache-v5') {
              caches.delete(key);
            }
          });
        });
      }

      const registration = await navigator.serviceWorker.register('/sw.js');
      
      // Register Background Sync if supported
      if ('sync' in registration) {
        try {
          await (registration as any).sync.register('juhnkrix-background-sync');
        } catch (e) {
          // Background sync register fallback
        }
      }

      // Online event listener to trigger push of pending JMC mining data, prayers & profile updates
      const triggerPushToCloudflare = () => {
        const payload = {
          source: 'juhnkrix-musika-app',
          syncedAt: new Date().toISOString(),
          jmcLedger: localStorage.getItem('jmc_balance_ledger') || null,
          prayerRequests: localStorage.getItem('juhnkrix_prayer_requests') || null,
          profileUpdates: localStorage.getItem('juhnkrix_offline_profile_v1') || null,
          lastMinedNonce: localStorage.getItem('jm_crypto_miner_nonce') || null
        };

        if (registration.active) {
          registration.active.postMessage({
            type: 'TRIGGER_BACKGROUND_SYNC',
            payload
          });
        }
      };

      window.addEventListener('online', triggerPushToCloudflare);

      // Listen for sync completion messages
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data?.type === 'BACKGROUND_SYNC_COMPLETE') {
          window.dispatchEvent(new CustomEvent('juhnkrix_cloud_sync_success', { detail: event.data }));
        }
      });
    } catch (err) {
      console.warn('Service worker registration failed:', err);
    }
  });
}

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  (window as any).deferredPrompt = e;
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
