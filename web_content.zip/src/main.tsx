import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./app/globals.css";

/**
 * נקודת הכניסה של React (Vite Web Preview).
 * הרכבה בטוחה: יוצר את אלמנט השורש אם חסר, ולעולם לא משאיר מסך ריק.
 */

declare global {
  interface Window {
    __APP_BOOTED__?: boolean;
  }
}

function getRootElement(): HTMLElement {
  const existing = document.getElementById("root");
  if (existing) return existing;
  // הגנה: אם ה-div חסר ב-HTML, נייצר אותו דינמית במקום לקרוס
  const created = document.createElement("div");
  created.id = "root";
  document.body.appendChild(created);
  return created;
}

function renderFatal(container: HTMLElement, message: string) {
  container.innerHTML = `
    <div style="margin:24px;padding:24px;text-align:center;border:1px solid rgba(244,63,94,.4);border-radius:16px;background:rgba(76,5,25,.35);color:#fecdd3;font-family:system-ui,sans-serif">
      <div style="font-size:28px">⚠️</div>
      <h2 style="margin:8px 0;font-size:16px">שגיאה בטעינת הנתונים - לחץ לנסות שוב</h2>
      <p style="font-size:11px;opacity:.7">${message}</p>
      <button type="button" style="margin-top:12px;padding:8px 20px;border:0;border-radius:12px;background:#f43f5e;color:#fff;font-weight:700;cursor:pointer" onclick="window.location.reload()">נסה שוב</button>
    </div>`;
}

function bootstrap() {
  const container = getRootElement();
  try {
    createRoot(container).render(
      <StrictMode>
        <App />
      </StrictMode>,
    );
    if (typeof window !== "undefined") window.__APP_BOOTED__ = true;
  } catch (err) {
    renderFatal(container, err instanceof Error ? err.message : "שגיאה לא ידועה");
  }
}

if (typeof document !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
  } else {
    bootstrap();
  }
}

export default bootstrap;
