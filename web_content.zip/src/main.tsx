import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

const rootElement = document.getElementById('root');

if (rootElement) {
  try {
    const root = createRoot(rootElement);
    root.render(
      <StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </StrictMode>,
    );
  } catch (err: any) {
    console.error('Fatal mount error in main.tsx:', err);
    rootElement.innerHTML = `
      <div style="min-height: 100vh; background-color: #0F0F0F; color: #EAEAEA; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px; font-family: sans-serif; text-align: center; direction: rtl;">
        <div style="max-width: 480px; width: 100%; background-color: #181818; border: 1px solid #C5A267; border-radius: 16px; padding: 24px;">
          <h2 style="color: #C5A267; font-size: 18px; margin-bottom: 8px;">שגיאה באתחול האפליקציה</h2>
          <p style="color: #888; font-size: 12px; margin-bottom: 16px;">${err?.message || 'שגיאת הרצה'}</p>
          <button onclick="localStorage.clear(); sessionStorage.clear(); window.location.reload(true);" style="background-color: #C5A267; color: #0F0F0F; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer;">איפוס וטעינה מחדש</button>
        </div>
      </div>
    `;
  }
}

