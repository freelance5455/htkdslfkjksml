import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register service worker for offline execution
try {
  registerSW({
    immediate: true,
    onNeedRefresh() {
      console.log('Nova atualização do Angola Connect disponível');
    },
    onOfflineReady() {
      console.log('Angola Connect pronto para funcionar 100% offline');
    },
  });
} catch {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(console.error);
  }
}

createRoot(document.getElementById('root')!).render(<App />);
