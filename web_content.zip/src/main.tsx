import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { GameApp } from "./game/App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode><GameApp /></React.StrictMode>,
);
