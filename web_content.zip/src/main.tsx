import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA Service Worker for complete offline support on Android & Mobile
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('App ready to update');
  },
  onOfflineReady() {
    console.log('App ready to work offline on Android / mobile devices');
  },
});

createRoot(document.getElementById('root')!).render(<App />);
