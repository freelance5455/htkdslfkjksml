import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import { ErrorBoundary } from "./components/ErrorBoundary.tsx";
import "./index.css";

// Render UI immediately FIRST without waiting for anything
const rootElement = document.getElementById("root");
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary fallbackTitle="Ceiling Calculation">
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
}

// Asynchronously register Service Worker in the background after initial render
if (typeof window !== "undefined") {
  window.addEventListener("load", () => {
    // Non-blocking deferred service worker registration
    setTimeout(() => {
      try {
        if ("serviceWorker" in navigator) {
          navigator.serviceWorker
            .register("/sw.js", { scope: "/" })
            .then((reg) => {
              console.log("[PWA] Service Worker registered in background:", reg.scope);
            })
            .catch((err) => {
              console.warn("[PWA] Service Worker registration skipped:", err);
            });
        }
      } catch (e) {
        console.warn("[PWA] Non-fatal SW registration notice:", e);
      }
    }, 1000);
  });
}
