import React from "react";
import { createRoot } from "react-dom/client";
import "./app/globals.css";
import { App } from "./App";
import { ErrorBoundary } from "./components/ErrorBoundary";

function mountApplication() {
  if (typeof document === "undefined") return;

  // Enforce Hebrew RTL directionality on document root
  document.documentElement.setAttribute("lang", "he");
  document.documentElement.setAttribute("dir", "rtl");
  document.documentElement.classList.add("dark");

  let rootElement = document.getElementById("root");
  if (!rootElement) {
    rootElement = document.createElement("div");
    rootElement.id = "root";
    document.body.appendChild(rootElement);
  }

  const root = createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <ErrorBoundary sectionTitleHe="נקודת כניסה ראשית (src/main.tsx)">
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );
}

mountApplication();
