import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register Service Worker for offline capability & caching
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('[KBSSN PWA] App update ready.');
  },
  onOfflineReady() {
    console.log('[KBSSN PWA] Offline caching complete. App is fully ready for offline use.');
  },
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
