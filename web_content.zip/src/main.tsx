import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

if (
  !import.meta.env.VITE_NO_PWA &&
  typeof window !== 'undefined' &&
  'serviceWorker' in navigator &&
  (window.location.protocol === 'https:' || window.location.hostname === 'localhost')
) {
  import('virtual:pwa-register')
    .then(({registerSW}) => {
      registerSW({
        immediate: true,
        onRegisterError() {
          // Ignore registration issues inside WebView/APK wrappers
        },
      });
    })
    .catch(() => {
      // Safe fallback when built with NO_PWA=true for APK packaging
    });
}

createRoot(document.getElementById('root')!).render(<App />);
