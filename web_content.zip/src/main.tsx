import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import './styles.css';

const fps = [20,24,25,30,40,50,60,90,120,144];
const resolutions = ['720p','1080p','1440p'];

function App(){
  const [screen,setScreen]=useState<'home'|'new'|'editor'>('home');
  const [project,setProject]=useState({name:'Meu Projeto',fps:60,res:'1080p'});
  if(screen==='home') return <main className="app"><header><b>EDITOR V3.0</b><span>Projetos</span></header><section className="projects"><button className="new" onClick={()=>setScreen('new')}><strong>＋</strong><small>Criar projeto</small></button><article><div className="thumb">▶</div><b>Meu Projeto</b><small>1080p • 60 FPS</small></article></section></main>;
  if(screen==='new') return <main className="app"><header><button onClick={()=>setScreen('home')}>‹</button><b>Novo projeto</b></header><section className="form"><label>Nome<input value={project.name} onChange={e=>setProject({...project,name:e.target.value})}/></label><label>FPS<select value={project.fps} onChange={e=>setProject({...project,fps:Number(e.target.value)})}>{fps.map(x=><option key={x}>{x}</option>)}</select></label><label>Resolução<select value={project.res} onChange={e=>setProject({...project,res:e.target.value})}>{resolutions.map(x=><option key={x}>{x}</option>)}</select></label><button className="primary" onClick={()=>setScreen('editor')}>Criar projeto</button></section></main>;
  return <main className="editor"><header><button onClick={()=>setScreen('home')}>‹</button><b>{project.name}</b><button className="export">Exportar</button></header><div className="preview"><span>Pré-visualização</span></div><nav className="tools">{['Mídia','Texto','Áudio','Efeitos','IA','Ajustes'].map(x=><button key={x}>{x}</button>)}</nav><section className="timeline"><div className="track"><b>Vídeo</b><div className="clip">CLIP 01</div><div className="clip">CLIP 02</div></div><div className="track"><b>Áudio</b><div className="audio">MÚSICA</div></div></section><footer><span>{project.res} • {project.fps} FPS</span><button>＋</button><button>▶</button></footer></main>;
}
createRoot(document.getElementById('root')!).render(<App/>);
