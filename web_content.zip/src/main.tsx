import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { GodexErrorBoundary } from './components/GodexErrorBoundary.tsx';
import './index.css';

// Guard against unhandled cross-origin Script error noise
window.onerror = function(message, source, lineno, colno, error) {
  const msg = String(message || '');
  if (msg === 'Script error.' || msg.includes('Script error')) {
    return true; // Prevents the default browser error logging/bubbling
  }
  return false;
};

window.addEventListener(
  'error',
  (event) => {
    const msg = String(event.message || '');
    if (msg === 'Script error.' || msg.includes('Script error')) {
      event.preventDefault();
      event.stopPropagation();
      return false;
    }
  },
  true
);

window.addEventListener(
  'unhandledrejection',
  (event) => {
    const reasonStr = event.reason ? String(event.reason.message || event.reason) : '';
    if (reasonStr === 'Script error.' || reasonStr.includes('Script error')) {
      event.preventDefault();
      event.stopPropagation();
    }
  },
  true
);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <GodexErrorBoundary fallbackTitle="GODEX Studio Application Recovery">
      <App />
    </GodexErrorBoundary>
  </StrictMode>,
);

