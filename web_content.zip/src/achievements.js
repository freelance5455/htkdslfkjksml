/* ==========================================================================
   achievements.js — Gamification: XP، سطح‌ها، دستاوردها
   ========================================================================== */

import { clamp, uid, todayKey, sum } from './utils.js';
import { financeMetrics } from './engines/financial-engine.js';
import { streakOf } from './engines/habit-engine.js';

export const LEVELS = [
  { min: 0, fa: 'تازه‌کار', en: 'Beginner', icon: '🌱' },
  { min: 150, fa: 'کاوشگر', en: 'Explorer', icon: '🧭' },
  { min: 400, fa: 'سازنده', en: 'Builder', icon: '🧱' },
  { min: 800, fa: 'سرمایه‌گذار', en: 'Investor', icon: '📈' },
  { min: 1400, fa: 'کارآفرین', en: 'Entrepreneur', icon: '🚀' },
  { min: 2200, fa: 'ثروت‌ساز', en: 'Wealth Builder', icon: '💎' },
  { min: 3200, fa: 'استاد مالی', en: 'Financial Master', icon: '👑' },
];

export const XP_RULES = {
  task: 10, habit: 5, learning: 5, expenseLog: 3, incomeLog: 5,
  goalReached: 100, achievement: 25, review: 15, pathChosen: 20, backup: 10,
};

export function levelInfo(xp) {
  const x = +xp || 0;
  let idx = 0;
  LEVELS.forEach((l, i) => { if (x >= l.min) idx = i; });
  const cur = LEVELS[idx];
  const next = LEVELS[idx + 1] || null;
  const span = next ? next.min - cur.min : 1;
  const progress = next ? clamp((x - cur.min) / span, 0, 1) : 1;
  return { index: idx, level: idx + 1, ...cur, next, progress, toNext: next ? next.min - x : 0 };
}

export const ACHIEVEMENTS = [
  { id: 'first_save', icon: '🏆', fa: 'اولین پس‌انداز', desc: 'اولین مبلغ پس‌انداز ثبت شد', check: (s, m) => m.savings > 0 },
  { id: 'streak_7', icon: '🔥', fa: '۷ روز استمرار', desc: 'زنجیره ۷ روزه', check: (s) => (s.streak.best || 0) >= 7 },
  { id: 'streak_30', icon: '🔥', fa: '۳۰ روز استمرار', desc: 'زنجیره ۳۰ روزه', check: (s) => (s.streak.best || 0) >= 30 },
  { id: 'streak_90', icon: '🏅', fa: '۹۰ روز استمرار', desc: 'زنجیره ۹۰ روزه', check: (s) => (s.streak.best || 0) >= 90 },
  { id: 'streak_365', icon: '👑', fa: '۳۶۵ روز استمرار', desc: 'یک سال پیوستگی', check: (s) => (s.streak.best || 0) >= 365 },
  { id: 'first_side_income', icon: '💵', fa: 'اولین درآمد دوم', desc: 'درآمدی خارج از درآمد اصلی ثبت شد', check: (s, m) => m.incomeStreams >= 2 },
  { id: 'first_invest', icon: '📈', fa: 'اولین سرمایه‌گذاری', desc: 'دارایی درآمدزا ثبت شد', check: (s, m) => m.investable > 0 },
  { id: 'first_debt_pay', icon: '📉', fa: 'پرداخت اولین بدهی', desc: 'یک بدهی صفر شد', check: (s) => (s.finance.debts || []).some((d) => (+d.amount || 0) === 0) },
  { id: 'first_goal', icon: '🎯', fa: 'رسیدن به اولین هدف', desc: 'یک هدف تکمیل شد', check: (s) => (s.goals || []).some((g) => g.done) },
  { id: 'habit_master', icon: '🔁', fa: 'استاد عادت', desc: 'یک عادت با زنجیره ۲۱ روزه', check: (s) => (s.habits || []).some((h) => streakOf(h) >= 21 || (h.streak || 0) >= 21) },
  { id: 'reader_5', icon: '📚', fa: '۵ کتاب خوانده شد', desc: 'پنج کتاب در کتابخانه علامت خورده', check: (s) => (s.learning.books || []).length >= 5 },
  { id: 'net_worth_positive', icon: '💚', fa: 'خالص ثروت مثبت', desc: 'دارایی بیشتر از بدهی', check: (s, m) => m.netWorth > 0 },
  { id: 'debt_free', icon: '🕊️', fa: 'بدون بدهی', desc: 'همه بدهی‌ها صفر شد', check: (s, m) => m.debtTotal === 0 && (s.finance.debts || []).length > 0 },
  { id: 'saving_20', icon: '🪣', fa: 'نرخ پس‌انداز ۲۰٪', desc: 'یک پنجم درآمد پس‌انداز می‌شود', check: (s, m) => m.savingsRate >= 0.2 },
  { id: 'emergency_3', icon: '🛟', fa: 'صندوق اضطراری ۳ ماه', desc: 'نقد معادل سه ماه هزینه', check: (s, m) => m.runwayMonths >= 3 },
  { id: 'score_500', icon: '⭐', fa: 'امتیاز ۵۰۰', desc: 'امتیاز آزادی مالی به ۵۰۰ رسید', check: (s, m) => m.scoreProxy >= 500 },
  { id: 'score_700', icon: '🌟', fa: 'امتیاز ۷۰۰', desc: 'امتیاز آزادی مالی به ۷۰۰ رسید', check: (s, m) => m.scoreProxy >= 700 },
  { id: 'business_started', icon: '🏢', fa: 'شروع کسب‌وکار', desc: 'کسب‌وکار یا منبع درآمد مستقل راه افتاد', check: (s) => s.plan.businessStarted || s.profile.job === 'business' },
  { id: 'review_1', icon: '🧾', fa: 'اولین مرور ماهانه', desc: 'یک مرور ماهانه کامل شد', check: (s) => (s.plan.monthlyReviews || []).length >= 1 },
  { id: 'task_100', icon: '✅', fa: '۱۰۰ کار انجام شد', desc: 'صد کار برنامه‌ریزی‌شده انجام شد', check: (s) => (s.gamification.tasksDone || 0) >= 100 },
];

/** بررسی و باز کردن دستاوردهای جدید (داخل State.update استفاده شود) */
export function checkAchievements(state, scoreTotal) {
  const m = financeMetrics(state);
  m.scoreProxy = scoreTotal || 0;
  const have = new Set((state.gamification.achievements || []).map((a) => a.id));
  const unlocked = [];
  ACHIEVEMENTS.forEach((a) => {
    if (have.has(a.id)) return;
    let ok = false;
    try { ok = !!a.check(state, m); } catch (e) { ok = false; }
    if (ok) {
      state.gamification.achievements.push({ id: a.id, icon: a.icon, fa: a.fa, desc: a.desc, at: todayKey() });
      state.gamification.xp += XP_RULES.achievement;
      unlocked.push(a);
    }
  });
  return unlocked;
}

export function addXP(state, kind, amount) {
  const add = amount != null ? amount : (XP_RULES[kind] || 5);
  state.gamification.xp = (+state.gamification.xp || 0) + add;
  return state.gamification.xp;
}

export function achievementsOf(state) {
  const have = new Set((state.gamification.achievements || []).map((a) => a.id));
  return ACHIEVEMENTS.map((a) => ({ ...a, unlocked: have.has(a.id), at: ((state.gamification.achievements || []).find((x) => x.id === a.id) || {}).at || null }));
}

export function xpHistory(state) {
  return (state.gamification.history || []).slice(-10).reverse();
}

export function logXP(state, kind, label) {
  state.gamification.history = state.gamification.history || [];
  state.gamification.history.push({ id: uid('xp'), kind, label, xp: XP_RULES[kind] || 5, at: todayKey() });
  if (state.gamification.history.length > 100) state.gamification.history = state.gamification.history.slice(-100);
}

export function totalAchievementProgress(state) {
  const have = (state.gamification.achievements || []).length;
  return { have, total: ACHIEVEMENTS.length, percent: Math.round((have / ACHIEVEMENTS.length) * 100) };
}

export function sumXPFromHistory(state) { return sum(state.gamification.history || [], (h) => h.xp); }
