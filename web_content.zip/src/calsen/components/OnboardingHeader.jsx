import React from 'react';

export default function OnboardingHeader({ step = 1, totalSteps = 12, onBack, onSkip, title = '' }) {
  const progressPercent = Math.min(100, Math.max(5, (step / totalSteps) * 100));

  return (
    <div className="relative z-20 pt-2 pb-4">
      <div className="flex items-center justify-between mb-3">
        {onBack ? (
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/80 hover:text-white cursor-pointer transition-all active:scale-95"
            aria-label="Back"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
            </svg>
          </button>
        ) : (
          <div className="w-10" />
        )}

        {title ? (
          <span className="text-xs font-semibold text-white/60 uppercase tracking-widest">{title}</span>
        ) : (
          <span className="text-xs font-semibold text-white/50 tracking-wider">
            {step} of {totalSteps}
          </span>
        )}

        {onSkip ? (
          <button
            onClick={onSkip}
            className="text-xs font-medium text-white/50 hover:text-white/90 px-2 py-1 rounded-lg cursor-pointer transition-colors"
          >
            Skip
          </button>
        ) : (
          <div className="w-10" />
        )}
      </div>

      {/* Progress Track */}
      <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-[#FF5C00] to-[#FFA050] rounded-full transition-all duration-300 ease-out shadow-[0_0_8px_rgba(255,92,0,0.6)]"
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </div>
  );
}
