import { useRef, useState } from 'react';

// Base class kept so each screen's logic reads exactly like the original design file.
export class DCLogic {
  constructor() {
    this.props = {};
    this.state = {};
  }
  setState() {}
  renderVals() {
    return {};
  }
}

// Runs a screen's logic class as a React hook: keeps its state and returns its values.
export function useDC(Logic) {
  const [state, setState] = useState({});
  const ref = useRef(null);
  if (!ref.current) ref.current = new Logic();
  const inst = ref.current;
  inst.state = state;
  inst.props = {};
  inst.setState = (patch) =>
    setState((prev) => ({ ...prev, ...(typeof patch === 'function' ? patch(prev) : patch) }));
  return inst.renderVals();
}

// Turns a CSS string ("padding:8px;color:#fff") into a React style object.
export function css(str) {
  const o = {};
  str.split(';').forEach((d) => {
    const i = d.indexOf(':');
    if (i < 0) return;
    const k = d.slice(0, i).trim();
    const v = d.slice(i + 1).trim();
    if (!k || !v) return;
    const key = k.startsWith('--')
      ? k
      : k.replace(/^-(\w)/, (m, c) => c.toUpperCase()).replace(/-([a-z])/g, (m, c) => c.toUpperCase());
    o[key] = v;
  });
  return o;
}
