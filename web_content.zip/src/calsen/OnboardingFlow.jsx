import React, { useState } from 'react';
import {
  Welcome,
  SignIn,
  Signup,
  Sex,
  Birth,
  Height,
  Weight,
  Goal,
  GoalWeight,
  Speed,
  Workouts,
  Stopping,
  Twice,
  Building,
  Plan,
  Create,
  OnTrack,
  Paywall,
  OfferScreen,
} from './screens';

export default function OnboardingFlow({ onComplete, initialScreen = 'welcome', onExitToApp }) {
  const [currentStep, setCurrentStep] = useState(initialScreen);
  const [showScreenPicker, setShowScreenPicker] = useState(false);

  const [formData, setFormData] = useState(() => {
    try {
      return {
        name: localStorage.getItem('calsen-name') || 'Alex',
        email: localStorage.getItem('calsen-email') || '',
        gender: localStorage.getItem('calsen-gender') || 'Male',
        dob: localStorage.getItem('calsen-dob') || '2000-01-01',
        age: Number(localStorage.getItem('calsen-age') || 24),
        height: Number(localStorage.getItem('calsen-height') || 175),
        weight: Number(localStorage.getItem('calsen-weight') || 72),
        goal: localStorage.getItem('calsen-goal') || 'lose',
        goalWeight: Number(localStorage.getItem('calsen-goal-weight') || 65),
        speed: localStorage.getItem('calsen-speed') || 'recommended',
        activity: localStorage.getItem('calsen-activity') || '3-5',
        activityFactor: Number(localStorage.getItem('calsen-activity-factor') || 1.55),
        obstacles: ['cravings', 'consistency'],
        targetCals: Number(localStorage.getItem('calsen-target-cals') || 2150),
      };
    } catch (e) {
      return {
        name: 'Alex',
        gender: 'Male',
        dob: '2000-01-01',
        age: 24,
        height: 175,
        weight: 72,
        goal: 'lose',
        goalWeight: 65,
        speed: 'recommended',
        activity: '3-5',
        activityFactor: 1.55,
        targetCals: 2150,
      };
    }
  });

  const updateData = (patch) => {
    setFormData((prev) => ({ ...prev, ...patch }));
  };

  const handleFinish = (data) => {
    const finalData = { ...formData, ...data };
    try {
      localStorage.setItem('calsen-onboarding-complete', 'true');
      if (finalData.name) localStorage.setItem('calsen-name', finalData.name);
      if (finalData.weight) localStorage.setItem('calsen-weight', String(finalData.weight));
      if (finalData.goalWeight) localStorage.setItem('calsen-goal-weight', String(finalData.goalWeight));
      if (finalData.targetCals) localStorage.setItem('calsen-target-cals', String(finalData.targetCals));
    } catch (e) {}

    if (onComplete) onComplete(finalData);
    else if (onExitToApp) onExitToApp();
  };

  const allScreens = [
    { id: 'welcome', label: '1. Welcome' },
    { id: 'sex', label: '2. Biological Sex' },
    { id: 'workouts', label: '3. Activity Level' },
    { id: 'height', label: '4. Height' },
    { id: 'weight', label: '5. Current Weight' },
    { id: 'birth', label: '6. Date of Birth' },
    { id: 'goal', label: '7. Primary Goal' },
    { id: 'goalWeight', label: '8. Target Weight' },
    { id: 'speed', label: '9. Preferred Pace' },
    { id: 'ontrack', label: '10. On Track' },
    { id: 'twice', label: '11. Tracking Pledge' },
    { id: 'stopping', label: '12. Past Obstacles' },
    { id: 'building', label: '13. Building Plan' },
    { id: 'plan', label: '14. Custom Plan' },
    { id: 'paywall', label: '15. CalSen Pro' },
    { id: 'create', label: '16. Create Account' },
    { id: 'signup', label: '17. Sign Up' },
    { id: 'signin', label: '18. Sign In' },
    { id: 'offer', label: '19. Special Offer' },
  ];

  const handleGo = (scr) => {
    if (!scr) return;
    const clean = String(scr).replace(/^#\/?/, '').trim();
    const key = clean.toLowerCase();
    const found = allScreens.find(
      (s) => s.id.toLowerCase() === key || s.id.toLowerCase() === key.replace(/\s+/g, '')
    );
    if (found) {
      setCurrentStep(found.id);
      return;
    }
    if (key.includes('welcome')) setCurrentStep('welcome');
    else if (key.includes('paywall') || key.includes('pro') || key.includes('price') || key.includes('trial') || key.includes('sub')) setCurrentStep('paywall');
    else if (key.includes('signin')) setCurrentStep('signin');
    else if (key.includes('signup')) setCurrentStep('signup');
    else if (key.includes('sex') || key.includes('gender')) setCurrentStep('sex');
    else if (key.includes('workout') || key.includes('activity')) setCurrentStep('workouts');
    else if (key.includes('height')) setCurrentStep('height');
    else if (key.includes('goalweight') || key.includes('targetweight') || (key.includes('goal') && key.includes('weight'))) setCurrentStep('goalWeight');
    else if (key.includes('weight')) setCurrentStep('weight');
    else if (key.includes('birth') || key.includes('dob')) setCurrentStep('birth');
    else if (key.includes('goal')) setCurrentStep('goal');
    else if (key.includes('speed') || key.includes('pace')) setCurrentStep('speed');
    else if (key.includes('track')) setCurrentStep('ontrack');
    else if (key.includes('twice') || key.includes('pledge')) setCurrentStep('twice');
    else if (key.includes('stopping') || key.includes('obstacle')) setCurrentStep('stopping');
    else if (key.includes('building')) setCurrentStep('building');
    else if (key.includes('plan')) setCurrentStep('plan');
    else if (key.includes('create') || key.includes('save') || key.includes('account')) setCurrentStep('create');
    else if (key.includes('home') || key.includes('dash')) { if (onExitToApp) onExitToApp(); }
    else setCurrentStep(clean);
  };

  return (
    <div className="relative min-h-screen bg-[#0A0506]">
      {/* Floating Screen Switcher for Easy Review */}
      <div className="fixed top-3 right-3 z-50">
        <button
          onClick={() => setShowScreenPicker(!showScreenPicker)}
          className="text-[10px] font-extrabold px-3 py-1.5 rounded-full bg-[#1A1214] border border-[#FF5C00]/40 text-[#FFA050] hover:bg-[#25181C] shadow-lg backdrop-blur-md cursor-pointer transition-all flex items-center gap-1.5"
        >
          <span>Screens ({allScreens.findIndex((s) => s.id === currentStep) + 1}/{allScreens.length})</span>
          <svg className={`w-3 h-3 transition-transform ${showScreenPicker ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {showScreenPicker && (
          <div className="absolute right-0 mt-2 w-52 max-h-96 overflow-y-auto rounded-2xl bg-[#140E10] border border-white/10 shadow-[0_10px_35px_rgba(0,0,0,0.8)] p-2 z-50">
            <div className="text-[10px] font-bold text-white/40 px-2 py-1 uppercase tracking-wider">
              Jump to Screen:
            </div>
            {allScreens.map((sc) => (
              <button
                key={sc.id}
                onClick={() => {
                  setCurrentStep(sc.id);
                  setShowScreenPicker(false);
                }}
                className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                  currentStep === sc.id
                    ? 'bg-[#FF5C00] text-black font-extrabold'
                    : 'text-white/80 hover:bg-white/10'
                }`}
              >
                {sc.label}
              </button>
            ))}
            <div className="pt-2 border-t border-white/10 mt-1">
              <button
                onClick={() => {
                  setShowScreenPicker(false);
                  if (onExitToApp) onExitToApp();
                }}
                className="w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-bold text-[#34B85C] hover:bg-[#34B85C]/10 cursor-pointer"
              >
                → Go to App Dashboard
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Screen Render */}
      {currentStep === 'welcome' && (
        <Welcome
          go={handleGo}
          onStartOnboarding={() => setCurrentStep('sex')}
          onSignIn={() => setCurrentStep('signin')}
          onSkip={onExitToApp}
          onGoogleComplete={(u) => {
            updateData(u);
            handleFinish(u);
          }}
        />
      )}

      {currentStep === 'signin' && (
        <SignIn
          go={handleGo}
          onBack={() => setCurrentStep('welcome')}
          onSignUp={() => setCurrentStep('signup')}
          onComplete={(u) => {
            updateData(u);
            handleFinish(u);
          }}
        />
      )}

      {currentStep === 'signup' && (
        <Signup
          go={handleGo}
          onBack={() => setCurrentStep('welcome')}
          onSignIn={() => setCurrentStep('signin')}
          onComplete={(u) => {
            updateData(u);
            setCurrentStep('sex');
          }}
        />
      )}

      {currentStep === 'sex' && (
        <Sex
          go={handleGo}
          currentVal={formData.gender}
          onBack={() => setCurrentStep('welcome')}
          onSkip={() => setCurrentStep('birth')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('birth');
          }}
        />
      )}

      {currentStep === 'birth' && (
        <Birth
          go={handleGo}
          currentVal={formData.dob}
          onBack={() => setCurrentStep('weight')}
          onSkip={() => setCurrentStep('goal')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('goal');
          }}
        />
      )}

      {currentStep === 'height' && (
        <Height
          go={handleGo}
          currentVal={formData.height}
          onBack={() => setCurrentStep('birth')}
          onSkip={() => setCurrentStep('weight')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('weight');
          }}
        />
      )}

      {currentStep === 'weight' && (
        <Weight
          go={handleGo}
          currentVal={formData.weight}
          onBack={() => setCurrentStep('height')}
          onSkip={() => setCurrentStep('goal')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('goal');
          }}
        />
      )}

      {currentStep === 'goal' && (
        <Goal
          go={handleGo}
          currentVal={formData.goal}
          onBack={() => setCurrentStep('weight')}
          onSkip={() => setCurrentStep('goalWeight')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('goalWeight');
          }}
        />
      )}

      {currentStep === 'goalWeight' && (
        <GoalWeight
          go={handleGo}
          currentWeight={formData.weight}
          goal={formData.goal}
          onBack={() => setCurrentStep('goal')}
          onSkip={() => setCurrentStep('speed')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('speed');
          }}
        />
      )}

      {currentStep === 'speed' && (
        <Speed
          go={handleGo}
          currentWeight={formData.weight}
          goalWeight={formData.goalWeight}
          goal={formData.goal}
          onBack={() => setCurrentStep('goalWeight')}
          onSkip={() => setCurrentStep('workouts')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('workouts');
          }}
        />
      )}

      {currentStep === 'workouts' && (
        <Workouts
          go={handleGo}
          currentVal={formData.activity}
          onBack={() => setCurrentStep('speed')}
          onSkip={() => setCurrentStep('stopping')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('stopping');
          }}
        />
      )}

      {currentStep === 'stopping' && (
        <Stopping
          go={handleGo}
          onBack={() => setCurrentStep('twice')}
          onSkip={() => setCurrentStep('building')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('building');
          }}
        />
      )}

      {currentStep === 'twice' && (
        <Twice
          go={handleGo}
          onBack={() => setCurrentStep('stopping')}
          onSkip={() => setCurrentStep('building')}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('building');
          }}
        />
      )}

      {currentStep === 'building' && (
        <Building
          go={handleGo}
          profileData={formData}
          onNext={() => setCurrentStep('plan')}
        />
      )}

      {currentStep === 'plan' && (
        <Plan
          go={handleGo}
          profileData={formData}
          onNext={(data) => {
            updateData(data);
            setCurrentStep('paywall');
          }}
        />
      )}

      {currentStep === 'paywall' && (
        <Paywall
          go={handleGo}
          onClose={() => setCurrentStep('create')}
          onComplete={() => {
            updateData({ isPro: true });
            handleFinish({ isPro: true });
          }}
          onNavigate={(r) => {
            if (r === 'home') handleFinish({ isPro: true });
            else handleGo(r);
          }}
        />
      )}

      {currentStep === 'offer' && (
        <OfferScreen
          go={handleGo}
          onClose={() => setCurrentStep('create')}
          onClaim={() => {
            updateData({ isPro: true });
            handleFinish({ isPro: true });
          }}
          onNavigate={(r) => {
            if (r === 'home') handleFinish({ isPro: true });
            else handleGo(r);
          }}
        />
      )}

      {currentStep === 'create' && (
        <Create
          go={handleGo}
          profileData={formData}
          onBack={() => setCurrentStep('paywall')}
          onNext={(data) => {
            updateData(data);
            handleFinish(data);
          }}
        />
      )}

      {currentStep === 'ontrack' && (
        <OnTrack
          go={handleGo}
          profileData={formData}
          onComplete={handleFinish}
          onNavigate={(r) => {
            if (r === 'home' && onExitToApp) onExitToApp();
            else setCurrentStep(r);
          }}
        />
      )}
    </div>
  );
}
