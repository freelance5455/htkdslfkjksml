import React from 'react';
import { DCLogic, useDC, css } from '../dc';
import { calculatePlan } from '../../lib/calorieCalculator';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
::-webkit-scrollbar{display:none}
`;

class Component extends DCLogic {
renderVals() {
const cp = calculatePlan();
const rd = (k, d) => { try { const o = JSON.parse(localStorage.getItem(k)); return o && typeof o.v === 'number' ? o : d; } catch (e) { return d; } };
const cvt = (o, u) => o.u === u ? o.v : (u === 'lb' ? o.v * 2.20462 : o.v / 2.20462);
const r1 = (n) => (Math.round(n * 10) / 10).toFixed(1);
const g = rd('cs_g', { u: 'kg', v: cp.goalWeight });
const w0 = rd('cs_w', { u: 'kg', v: cp.weight });
const u = g.u || 'kg';
const sv = cvt(w0, u), ev = g.v;
const df = ev - sv;
const st = this.state || {};
const cal = st.cal ?? cp.targetCalories;
const p = st.p ?? cp.protein;
const c = st.c ?? cp.carbs;
const f = st.f ?? cp.fat;

try {
  localStorage.setItem('calsen-target-cals', String(cal));
  localStorage.setItem('calsen-protein', String(p));
  localStorage.setItem('calsen-carbs', String(c));
  localStorage.setItem('calsen-fat', String(f));
} catch(e) {}

const raw = st.raw ?? '';
const show = (k, v) => st.focus === k ? raw : String(v);
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const focus = (k) => () => this.setState({ focus: k, raw: String({ cal, p, c, f }[k]), base: { cal, p, c, f } });
const edit = (k) => (e) => {
const t = e.target.value; const n = parseFloat(t);
const nx = { focus: k, raw: t };
if (!isNaN(n) && n >= 0) {
if (k === 'cal') {
const b = st.base ?? { cal, p, c, f };
const nc = clamp(Math.round(n), 0, 9000); const r = b.cal > 0 ? nc / b.cal : 1;
nx.cal = nc; nx.p = Math.round(b.p * r); nx.c = Math.round(b.c * r); nx.f = Math.round(b.f * r);
try {
  localStorage.setItem('calsen-target-cals', String(nc));
  localStorage.setItem('calsen-protein', String(nx.p));
  localStorage.setItem('calsen-carbs', String(nx.c));
  localStorage.setItem('calsen-fat', String(nx.f));
} catch(err) {}
} else {
const v = clamp(Math.round(n), 0, 999); const m = { p, c, f }; m[k] = v;
nx[k] = v; nx.cal = 4 * m.p + 4 * m.c + 9 * m.f;
try {
  localStorage.setItem('calsen-target-cals', String(nx.cal));
  localStorage.setItem('calsen-protein', String(m.p));
  localStorage.setItem('calsen-carbs', String(m.c));
  localStorage.setItem('calsen-fat', String(m.f));
} catch(err) {}
}
}
this.setState(nx);
};
return {
title: (df > 0 ? 'Gain ' : df < 0 ? 'Lose ' : 'Maintain ') + r1(Math.abs(df)) + ' ' + u + ' by ' + cp.dateFormatted,
subNote: `Follow this plan to ${cp.goal === 'gain' ? 'gain lean muscle' : cp.goal === 'lose' ? 'burn fat sustainably' : 'maintain your target weight'}.`,
yw: r1(sv) + ' ' + u, yg: r1(ev) + ' ' + u, goalTag: Math.round(ev) + ' ' + u,
calVal: cal, pVal: p, cVal: c, fVal: f,
calShown: show('cal', cal), pShown: show('p', p), cShown: show('c', c), fShown: show('f', f),
fCal: focus('cal'), fP: focus('p'), fC: focus('c'), fF: focus('f'),
iCal: edit('cal'), iP: edit('p'), iC: edit('c'), iF: edit('f'),
bl: () => this.setState({ focus: null })
};
}
}

export default function Plan({ go, onNext, onBack }) {
  const vals = useDC(Component);
  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Stopping" onClick={(e) => { e.preventDefault(); go('Stopping'); }} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 100%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <div style={css(`flex:1;min-height:0;overflow-y:auto;margin:16px -28px 0;padding:0 28px 12px;`)}>
          <div style={css(`text-align:center;`)}>
            <div style={css(`width:64px;height:64px;margin:0 auto;border-radius:50%;background:#ffffff;display:flex;align-items:center;justify-content:center;`)}>
              <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#1b1a21" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 12l5 5l9-10" />
              </svg>
            </div>
            <h1 style={css(`margin:16px 0 0;font-size:28px;line-height:34px;font-weight:800;letter-spacing:-0.5px;`)}>
              {vals.title}
            </h1>
            <p style={css(`margin:6px 0 0;font-size:15px;color:#9a9aa3;`)}>
              {vals.subNote}
            </p>
          </div>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:20px;margin-top:14px;`)}>
            <div style={css(`font-size:17px;font-weight:700;`)}>
              Projected progress
            </div>
            <div style={css(`position:relative;margin-top:10px;`)}>
              <svg viewBox="0 0 300 140" width="100%" role="img" aria-label="Projected weight gain over time" style={css(`display:block;`)}>
                <defs>
                  <linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="#ffffff" stopOpacity="0.18" />
                    <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <line x1="8" y1="30" x2="292" y2="30" stroke="#3a3a40" strokeDasharray="3 4" />
                <line x1="8" y1="76" x2="292" y2="76" stroke="#3a3a40" strokeDasharray="3 4" />
                <line x1="8" y1="122" x2="292" y2="122" stroke="#55555c" />
                <path d="M8 120C90 118 150 110 190 74S250 32 288 30V122H8Z" fill="url(#pg)" />
                <path d="M8 120C90 118 150 110 190 74S250 32 288 30" stroke="#ffffff" strokeWidth="3" fill="none" />
                <circle cx="8" cy="120" r="6" fill="#202024" stroke="#fff" strokeWidth="3" />
                <circle cx="290" cy="30" r="6" fill="#202024" stroke="#fff" strokeWidth="3" />
              </svg>
              <div style={css(`position:absolute;right:11%;top:1%;padding:5px 10px;border-radius:10px;border:2px solid #ffffff;background:#202024;text-align:center;font-size:11px;line-height:14px;font-weight:700;`)}>
                Goal
                <br />
                {vals.goalTag}
              </div>
            </div>
            <div style={css(`display:flex;justify-content:space-between;font-size:13px;font-weight:600;margin-top:6px;`)}>
              <span>
                Now
              </span>
              <span>
                November 26
              </span>
            </div>
          </div>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:20px;margin-top:14px;`)}>
            <div style={css(`font-size:17px;font-weight:700;`)}>
              Your daily recommendation
            </div>
            <div style={css(`font-size:13px;color:#9a9aa3;margin-top:2px;`)}>
              You can edit this anytime
            </div>
            <div style={css(`background:#2a2a2f;border-radius:20px;margin-top:14px;padding:16px;display:flex;align-items:center;gap:14px;`)}>
              <span style={css(`width:52px;height:52px;border-radius:50%;background:#35353b;display:flex;align-items:center;justify-content:center;flex:none;`)}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="#FF8A1F" aria-hidden="true">
                  <path d="M12 2c1 4 6 6 6 12a6 6 0 0 1-12 0c0-3 2-4 3-6c1 1 1 2 2 2c0-3 0-5 1-8z" />
                </svg>
              </span>
              <div style={css(`flex:1;`)}>
                <input type="number" inputMode="numeric" aria-label="Daily calories, tap to edit" value={vals.calShown} onFocus={vals.fCal} onChange={vals.iCal} onBlur={vals.bl} style={css(`width:130px;font-size:32px;font-weight:800;line-height:36px;background:transparent;border:0;border-bottom:2px solid rgba(255,138,31,0.55);border-radius:0;color:#ffffff;padding:0;font-family:inherit;`)} />
                <div style={css(`font-size:13px;color:#9a9aa3;`)}>
                  Calories
                </div>
              </div>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#9a9aa3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 20l4-1l11-11l-3-3L5 16zM14 7l3 3" />
              </svg>
            </div>
            <div style={css(`display:flex;gap:8px;margin-top:10px;`)}>
              <div style={css(`flex:1;background:#2a2a2f;border-radius:20px;padding:12px;`)}>
                <div style={css(`display:flex;justify-content:space-between;align-items:flex-start;`)}>
                  <span style={css(`width:26px;height:26px;border-radius:50%;background:#e8604f;`)}></span>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#9a9aa3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M4 20l4-1l11-11l-3-3L5 16zM14 7l3 3" />
                  </svg>
                </div>
                <div style={css(`display:flex;align-items:baseline;gap:3px;margin-top:10px;`)}>
                  <input type="number" inputMode="numeric" aria-label="Protein in grams, tap to edit" value={vals.pShown} onFocus={vals.fP} onChange={vals.iP} onBlur={vals.bl} style={css(`width:56px;font-size:19px;font-weight:800;background:transparent;border:0;border-bottom:2px solid rgba(255,138,31,0.55);border-radius:0;color:#ffffff;padding:0;font-family:inherit;`)} />
                  <span style={css(`font-size:15px;font-weight:700;color:#9a9aa3;`)}>
                    g
                  </span>
                </div>
                <div style={css(`font-size:12px;color:#9a9aa3;`)}>
                  Protein
                </div>
              </div>
              <div style={css(`flex:1;background:#2a2a2f;border-radius:20px;padding:12px;`)}>
                <div style={css(`display:flex;justify-content:space-between;align-items:flex-start;`)}>
                  <span style={css(`width:26px;height:26px;border-radius:50%;background:#e0914f;`)}></span>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#9a9aa3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M4 20l4-1l11-11l-3-3L5 16zM14 7l3 3" />
                  </svg>
                </div>
                <div style={css(`display:flex;align-items:baseline;gap:3px;margin-top:10px;`)}>
                  <input type="number" inputMode="numeric" aria-label="Carbs in grams, tap to edit" value={vals.cShown} onFocus={vals.fC} onChange={vals.iC} onBlur={vals.bl} style={css(`width:56px;font-size:19px;font-weight:800;background:transparent;border:0;border-bottom:2px solid rgba(255,138,31,0.55);border-radius:0;color:#ffffff;padding:0;font-family:inherit;`)} />
                  <span style={css(`font-size:15px;font-weight:700;color:#9a9aa3;`)}>
                    g
                  </span>
                </div>
                <div style={css(`font-size:12px;color:#9a9aa3;`)}>
                  Carbs
                </div>
              </div>
              <div style={css(`flex:1;background:#2a2a2f;border-radius:20px;padding:12px;`)}>
                <div style={css(`display:flex;justify-content:space-between;align-items:flex-start;`)}>
                  <span style={css(`width:26px;height:26px;border-radius:50%;background:#4f86e8;`)}></span>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#9a9aa3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M4 20l4-1l11-11l-3-3L5 16zM14 7l3 3" />
                  </svg>
                </div>
                <div style={css(`display:flex;align-items:baseline;gap:3px;margin-top:10px;`)}>
                  <input type="number" inputMode="numeric" aria-label="Fats in grams, tap to edit" value={vals.fShown} onFocus={vals.fF} onChange={vals.iF} onBlur={vals.bl} style={css(`width:56px;font-size:19px;font-weight:800;background:transparent;border:0;border-bottom:2px solid rgba(255,138,31,0.55);border-radius:0;color:#ffffff;padding:0;font-family:inherit;`)} />
                  <span style={css(`font-size:15px;font-weight:700;color:#9a9aa3;`)}>
                    g
                  </span>
                </div>
                <div style={css(`font-size:12px;color:#9a9aa3;`)}>
                  Fats
                </div>
              </div>
            </div>
          </div>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:20px;margin-top:14px;`)}>
            <div style={css(`font-size:17px;font-weight:700;`)}>
              Your info
            </div>
            <div style={css(`font-size:13px;color:#9a9aa3;margin-top:2px;`)}>
              This plan is customized for you.
            </div>
            <div style={css(`background:#2a2a2f;border-radius:20px;margin-top:14px;padding:16px;display:flex;flex-direction:column;gap:14px;`)}>
              <div style={css(`font-size:15px;`)}>
                Your weight:{" "}
                {vals.yw}
              </div>
              <div style={css(`font-size:15px;`)}>
                Goal weight:{" "}
                {vals.yg}
              </div>
              <div style={css(`font-size:15px;`)}>
                Activity level: Light
              </div>
              <div style={css(`font-size:15px;`)}>
                Target:{" "}
                {vals.title}
              </div>
            </div>
          </div>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:20px;margin-top:14px;`)}>
            <div style={css(`font-size:17px;font-weight:700;`)}>
              How to reach your goals:
            </div>
            <div style={css(`display:flex;flex-direction:column;gap:10px;margin-top:14px;`)}>
              <div style={css(`background:#2a2a2f;border-radius:20px;display:flex;align-items:center;gap:14px;padding:14px;min-height:56px;box-sizing:border-box;`)}>
                <span style={css(`width:40px;height:40px;border-radius:50%;background:#e0645f;flex:none;`)}></span>
                <span style={css(`font-size:15px;font-weight:600;line-height:21px;`)}>
                  Get your weekly life score and improve your routine.
                </span>
              </div>
              <div style={css(`background:#2a2a2f;border-radius:20px;display:flex;align-items:center;gap:14px;padding:14px;min-height:56px;box-sizing:border-box;`)}>
                <span style={css(`width:40px;height:40px;border-radius:50%;background:#6fae4f;flex:none;`)}></span>
                <span style={css(`font-size:15px;font-weight:600;line-height:21px;`)}>
                  Track your food
                </span>
              </div>
              <div style={css(`background:#2a2a2f;border-radius:20px;display:flex;align-items:center;gap:14px;padding:14px;min-height:56px;box-sizing:border-box;`)}>
                <span style={css(`width:40px;height:40px;border-radius:50%;background:#8c8c96;flex:none;`)}></span>
                <span style={css(`font-size:15px;font-weight:600;line-height:21px;`)}>
                  Follow your daily calorie recommendation
                </span>
              </div>
              <div style={css(`background:#2a2a2f;border-radius:20px;display:flex;align-items:center;gap:14px;padding:14px;min-height:56px;box-sizing:border-box;`)}>
                <span style={css(`width:40px;height:40px;border-radius:50%;background:#e0914f;flex:none;`)}></span>
                <span style={css(`font-size:15px;font-weight:600;line-height:21px;`)}>
                  Balance your carbs, protein, fat
                </span>
              </div>
            </div>
          </div>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:20px;margin-top:14px;`)}>
            <div style={css(`font-size:17px;font-weight:700;`)}>
              Benefits with CalSen:
            </div>
            <div style={css(`background:#2a2a2f;border-radius:20px;margin-top:14px;padding:16px;`)}>
              <div style={css(`font-size:14px;font-weight:700;margin-bottom:12px;`)}>
                Without CalSen
              </div>
              <div style={css(`display:flex;flex-direction:column;gap:10px;`)}>
                <div style={css(`display:flex;align-items:center;gap:12px;font-size:15px;`)}>
                  <span style={css(`color:#e0645f;font-weight:800;`)}>
                    ✕
                  </span>
                  Tedious to track what you eat
                </div>
                <div style={css(`display:flex;align-items:center;gap:12px;font-size:15px;`)}>
                  <span style={css(`color:#e0645f;font-weight:800;`)}>
                    ✕
                  </span>
                  Unclear how to reach your goals
                </div>
                <div style={css(`display:flex;align-items:center;gap:12px;font-size:15px;`)}>
                  <span style={css(`color:#e0645f;font-weight:800;`)}>
                    ✕
                  </span>
                  Hard to stay motivated
                </div>
              </div>
            </div>
            <div style={css(`background:#2a2a2f;border-radius:20px;margin-top:10px;padding:16px;`)}>
              <div style={css(`font-size:14px;font-weight:700;margin-bottom:12px;`)}>
                With CalSen
              </div>
              <div style={css(`display:flex;flex-direction:column;gap:10px;`)}>
                <div style={css(`display:flex;align-items:center;gap:12px;font-size:15px;`)}>
                  <span style={css(`color:#4cd27a;font-weight:800;`)}>
                    ✓
                  </span>
                  Log food in seconds
                </div>
                <div style={css(`display:flex;align-items:center;gap:12px;font-size:15px;`)}>
                  <span style={css(`color:#4cd27a;font-weight:800;`)}>
                    ✓
                  </span>
                  Clear daily targets to follow
                </div>
                <div style={css(`display:flex;align-items:center;gap:12px;font-size:15px;`)}>
                  <span style={css(`color:#4cd27a;font-weight:800;`)}>
                    ✓
                  </span>
                  AI keeps you on track
                </div>
              </div>
            </div>
          </div>
          <div style={css(`margin-top:18px;text-align:center;font-size:14px;color:#9a9aa3;`)}>
            How we make recommendations
          </div>
        </div>
        <a href="#/Paywall" onClick={(e) => { e.preventDefault(); if (onNext) onNext({ targetCals: vals.calVal, protein: vals.pVal, carbs: vals.cVal, fat: vals.fVal }); if (go) go('Paywall'); }} style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none; cursor: pointer;`)}>
          Continue
        </a>
      </div>
    </>
  );
}
