import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
::-webkit-scrollbar{display:none}
`;

class Component extends DCLogic {
  renderVals() {
    const st = this.state || {};
    const s = parseFloat(st.s ?? '0.8');
    const k = s < 0.4 ? 0 : s <= 0.9 ? 1 : 2;
    const m = Math.max(1, Math.round(5 / s / 4.345));
    const notes = [
      'Going slow means a gentler and more sustainable daily calorie goal.',
      'This is the most balanced pace, motivating and ideal for most users.',
      'This pace moves quickly, so staying consistent will be key.'
    ];
    return {
      s: String(s),
      sShow: s.toFixed(1),
      cSlow: k === 0 ? 'color:#FF8A1F;' : 'color:#ffffff;',
      cRec: k === 1 ? 'color:#FF8A1F;' : 'color:#ffffff;',
      cFast: k === 2 ? 'color:#FF8A1F;' : 'color:#ffffff;',
      bSlow: k === 0 ? 'box-shadow:0 0 0 2px #FF8A1F;' : 'box-shadow:0 0 0 1px #3a3a40;',
      bRec: k === 1 ? 'box-shadow:0 0 0 2px #FF8A1F;' : 'box-shadow:0 0 0 1px #3a3a40;',
      bFast: k === 2 ? 'box-shadow:0 0 0 2px #FF8A1F;' : 'box-shadow:0 0 0 1px #3a3a40;',
      months: m === 1 ? '1 month' : m + ' months',
      note: notes[k],
      warn: k === 2 ? 'Fast gain can lead to excess fat or bloating.' : '',
      cal: Math.round(1934 + (s - 0.1) * 1093),
      onS: (e) => this.setState({ s: e.target.value })
    };
  }
}

export default function Speed({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('GoalWeight');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    try {
      localStorage.setItem('calsen-speed', vals.sShow);
      localStorage.setItem('cs_speed', vals.sShow);
      localStorage.setItem('calsen-target-calorie', String(vals.cal));
    } catch (err) {}
    if (go) go('OnTrack');
    else if (onNext) onNext({ speed: vals.sShow, dailyCal: vals.cal });
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a
            href="#/GoalWeight"
            onClick={handleBack}
            aria-label="Back"
            style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 62%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          How fast do you want to reach your goal?
        </h1>
        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;gap:0;`)}>
          <div style={css(`text-align:center;font-size:16px;color:#c9c9d0;`)}>
            Weight gain speed per week
          </div>
          <div style={css(`text-align:center;font-size:44px;font-weight:800;letter-spacing:-1px;margin:6px 0 22px;`)}>
            {vals.sShow}
            {" "}kg
          </div>
          <div style={css(`display:flex;justify-content:space-between;text-align:center;font-size:15px;font-weight:600;`)}>
            <div style={css(`width:100px;display:flex;flex-direction:column;align-items:center;gap:8px;${vals.cSlow}`)}>
              <span style={css(`width:56px;height:56px;border-radius:50%;background:#2a2a2f;display:flex;align-items:center;justify-content:center;${vals.bSlow}`)}>
                <svg width="30" height="30" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M3.5 20a10.5 10.5 0 0 1 21 0" />
                  <path d="M14 19L7.9 13.9" />
                  <circle cx="14" cy="19" r="1.6" fill="currentColor" stroke="none" />
                </svg>
              </span>
              Slow
            </div>
            <div style={css(`width:110px;display:flex;flex-direction:column;align-items:center;gap:8px;${vals.cRec}`)}>
              <span style={css(`width:56px;height:56px;border-radius:50%;background:#2a2a2f;display:flex;align-items:center;justify-content:center;${vals.bRec}`)}>
                <svg width="30" height="30" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M3.5 20a10.5 10.5 0 0 1 21 0" />
                  <path d="M14 19L14 11" />
                  <circle cx="14" cy="19" r="1.6" fill="currentColor" stroke="none" />
                </svg>
              </span>
              Recommended
            </div>
            <div style={css(`width:100px;display:flex;flex-direction:column;align-items:center;gap:8px;${vals.cFast}`)}>
              <span style={css(`width:56px;height:56px;border-radius:50%;background:#2a2a2f;display:flex;align-items:center;justify-content:center;${vals.bFast}`)}>
                <svg width="30" height="30" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M3.5 20a10.5 10.5 0 0 1 21 0" />
                  <path d="M14 19L20.1 13.9" />
                  <circle cx="14" cy="19" r="1.6" fill="currentColor" stroke="none" />
                </svg>
              </span>
              Fast
            </div>
          </div>
          <input
            type="range"
            aria-label="Weight gain speed per week"
            min="0.1"
            max="1"
            step="0.1"
            value={vals.s}
            onChange={vals.onS}
            style={css(`width:100%;height:44px;margin:14px 0 18px;accent-color:#ffffff;cursor:pointer;`)}
          />
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:24px;padding:20px;`)}>
            <div style={css(`font-size:17px;font-weight:700;`)}>
              You will reach your goal in{" "}
              <span style={css(`color:#FF8A1F;`)}>
                {vals.months}
              </span>
            </div>
            <p style={css(`margin:8px 0 0;font-size:14px;line-height:21px;color:#9a9aa3;`)}>
              {vals.note}
            </p>
            <p style={css(`margin:10px 0 0;font-size:14px;color:#9a9aa3;`)}>
              Daily calorie goal:{" "}
              {vals.cal}
              {" "}cal
            </p>
            {vals.warn && (
              <p style={css(`margin:10px 0 0;font-size:13px;color:#ff7b72;`)}>
                {vals.warn}
              </p>
            )}
          </div>
        </div>
        <a
          href="#/OnTrack"
          onClick={handleContinue}
          style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none;`)}
        >
          Continue
        </a>
      </div>
    </>
  );
}
