import React, { useState, useEffect } from 'react';
import { DCLogic, useDC, css } from '../dc';
import { calculatePlan } from '../../lib/calorieCalculator';

const STYLE = `
body{margin:0}
a:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
@property --n{syntax:'<integer>';inherits:false;initial-value:0}
@keyframes cs-count{to{--n:100}}
@keyframes cs-ring{from{stroke-dasharray:0 603}to{stroke-dasharray:603 603}}
@keyframes cs-show{from{opacity:0;visibility:hidden}to{opacity:1;visibility:visible}}
@keyframes cs-m1{0%{opacity:0}5%{opacity:1}24%{opacity:1}28%,100%{opacity:0}}
@keyframes cs-m2{0%,24%{opacity:0}29%{opacity:1}48%{opacity:1}52%,100%{opacity:0}}
@keyframes cs-m3{0%,48%{opacity:0}53%{opacity:1}72%{opacity:1}76%,100%{opacity:0}}
@keyframes cs-m4{0%,76%{opacity:0}82%,100%{opacity:1}}
.cnt{animation:cs-count 6.4s linear forwards;counter-reset:n var(--n)}
.cnt::after{content:counter(n) "%"}
.ring{animation:cs-ring 6.4s linear forwards}
.ck{opacity:0;animation:cs-show .35s ease-out forwards}
.m{opacity:0}
.m1{animation:cs-m1 6.6s forwards}.m2{animation:cs-m2 6.6s forwards}.m3{animation:cs-m3 6.6s forwards}.m4{animation:cs-m4 6.6s forwards}
.go{visibility:hidden;opacity:0;animation:cs-show .35s ease-out 6.5s forwards}
`;

class Component extends DCLogic {
  renderVals() {
    return {};
  }
}

export default function Building({ go, onNext, profileData = {} }) {
  const vals = useDC(Component);
  const [displayCount, setDisplayCount] = useState(0);
  const [useJsCounter, setUseJsCounter] = useState(false);

  useEffect(() => {
    // Calibrate plan from user data
    calculatePlan(profileData);

    // Check if CSS @property is supported
    const supportsProperty = typeof window !== 'undefined' && window.CSS && typeof window.CSS.registerProperty === 'function';
    if (!supportsProperty) {
      setUseJsCounter(true);
    }

    let start = null;
    const duration = 6400;
    let frameId;
    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min(100, Math.floor(((timestamp - start) / duration) * 100));
      setDisplayCount(progress);
      if (progress < 100) {
        frameId = requestAnimationFrame(step);
      }
    };
    frameId = requestAnimationFrame(step);

    return () => {
      if (frameId) cancelAnimationFrame(frameId);
    };
  }, []);

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    if (go) go('Plan');
    else if (onNext) onNext();
  };

  return (
    <>
      <style>{STYLE}</style>
      <div
        style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column; justify-content: space-between;`)}
      >
        {/* Top Header */}
        <div style={css(`text-align: center; margin-top: 16px;`)}>
          <div
            style={css(`display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; border-radius: 999px; background: rgba(255, 138, 31, 0.12); border: 1px solid rgba(255, 138, 31, 0.3); margin-bottom: 16px;`)}
          >
            <div style={css(`width: 8px; height: 8px; border-radius: 50%; background: #FF8A1F;`)}></div>
            <span style={css(`font-size: 13px; font-weight: 600; color: #FF8A1F; letter-spacing: 0.2px;`)}>
              CalSen Metabolic Engine
            </span>
          </div>
          <h1 style={css(`font-size: 28px; line-height: 34px; font-weight: 700; letter-spacing: -0.5px; margin: 0;`)}>
            Building your custom plan
          </h1>
          <p style={css(`font-size: 15px; line-height: 22px; color: #8c8c96; margin: 8px 0 0;`)}>
            We're calibrating your daily targets based on your goals
          </p>
        </div>

        {/* Center Progress Circle and Sequential Animated Messages */}
        <div style={css(`display: flex; flex-direction: column; align-items: center; justify-content: center; margin: auto 0; width: 100%;`)}>
          {/* Animated SVG Ring with Counter */}
          <div style={css(`position: relative; width: 220px; height: 220px; display: flex; align-items: center; justify-content: center;`)}>
            <svg
              width="220"
              height="220"
              viewBox="0 0 220 220"
              style={css(`transform: rotate(-90deg); display: block;`)}
            >
              <circle
                cx="110"
                cy="110"
                r="96"
                fill="none"
                stroke="#2a2a30"
                strokeWidth="10"
              />
              <circle
                cx="110"
                cy="110"
                r="96"
                fill="none"
                stroke="#FF8A1F"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray="603 603"
                className="ring"
              />
            </svg>
            <div style={css(`position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center;`)}>
              {useJsCounter ? (
                <div style={css(`font-size: 46px; font-weight: 800; letter-spacing: -1px; color: #ffffff;`)}>
                  {displayCount}%
                </div>
              ) : (
                <div
                  className="cnt"
                  style={css(`font-size: 46px; font-weight: 800; letter-spacing: -1px; color: #ffffff;`)}
                ></div>
              )}
              <span style={css(`font-size: 13px; font-weight: 600; color: #8c8c96; margin-top: 2px; text-transform: uppercase; letter-spacing: 1px;`)}>
                Processing
              </span>
            </div>
          </div>

          {/* Sequential Animated Status Messages */}
          <div style={css(`position: relative; width: 100%; height: 50px; margin-top: 36px; display: flex; align-items: center; justify-content: center;`)}>
            <div
              className="m m1"
              style={css(`position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 600; color: #ffffff; text-align: center;`)}
            >
              <div style={css(`width: 8px; height: 8px; border-radius: 50%; background: #FF8A1F;`)}></div>
              <span>Analyzing metabolic profile & baseline</span>
            </div>
            <div
              className="m m2"
              style={css(`position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 600; color: #ffffff; text-align: center;`)}
            >
              <div style={css(`width: 8px; height: 8px; border-radius: 50%; background: #FF8A1F;`)}></div>
              <span>Calculating Total Daily Energy Expenditure (TDEE)</span>
            </div>
            <div
              className="m m3"
              style={css(`position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 600; color: #ffffff; text-align: center;`)}
            >
              <div style={css(`width: 8px; height: 8px; border-radius: 50%; background: #FF8A1F;`)}></div>
              <span>Optimizing daily calories & macro distribution</span>
            </div>
            <div
              className="m m4"
              style={css(`position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 600; color: #FF8A1F; text-align: center;`)}
            >
              <div
                className="ck"
                style={css(`width: 22px; height: 22px; border-radius: 50%; background: #FF8A1F; color: #171717; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 900;`)}
              >
                ✓
              </div>
              <span style={css(`color: #ffffff; font-weight: 700;`)}>Your personalized plan is ready!</span>
            </div>
          </div>
        </div>

        {/* Bottom CTA Link (appears smoothly when 100% complete) */}
        <a
          href="#/Plan"
          onClick={handleContinue}
          className="go"
          style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none; cursor: pointer;`)}
        >
          See my plan
        </a>
      </div>
    </>
  );
}
