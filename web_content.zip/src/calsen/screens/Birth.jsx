import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
select::-ms-expand{display:none}
::-webkit-scrollbar{display:none}
`;

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December'
];

class Component extends DCLogic {
  renderVals() {
    const s = this.state || {};
    const month = parseInt(s.month ?? '10', 10);
    const day = parseInt(s.day ?? '15', 10);
    const year = parseInt(s.year ?? '2000', 10);

    const today = new Date();
    let age = today.getFullYear() - year;
    const m = today.getMonth() + 1 - month;
    if (m < 0 || (m === 0 && today.getDate() < day)) {
      age--;
    }
    const safeAge = Math.max(10, Math.min(100, age));
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

    try {
      localStorage.setItem('calsen-dob', dateStr);
      localStorage.setItem('cs_dob', dateStr);
      localStorage.setItem('calsen-age', String(safeAge));
    } catch (e) {}

    return {
      month: String(month),
      day: String(day),
      year: String(year),
      age: safeAge,
      dateStr,
      onMonth: (e) => this.setState({ month: e.target.value }),
      onDay: (e) => this.setState({ day: e.target.value }),
      onYear: (e) => this.setState({ year: e.target.value })
    };
  }
}

export default function Birth({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('Weight');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    try {
      localStorage.setItem('calsen-dob', vals.dateStr);
      localStorage.setItem('cs_dob', vals.dateStr);
      localStorage.setItem('calsen-age', String(vals.age));
    } catch (err) {}
    if (go) go('Goal');
    else if (onNext) onNext({ dob: vals.dateStr, age: vals.age });
  };

  // Generate days 1..31
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  // Generate years from 2012 down to 1930
  const currentYear = 2012;
  const years = Array.from({ length: 83 }, (_, i) => currentYear - i);

  return (
    <>
      <style>{STYLE}</style>
      <div
        style={css(
          `position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`
        )}
      >
        {/* Top Header Navigation */}
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a
            href="#/Weight"
            onClick={handleBack}
            aria-label="Back"
            style={css(
              `width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none; cursor: pointer;`
            )}
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#ffffff"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 50%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>

        {/* Title and Subtitle */}
        <h1
          style={css(
            `margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`
          )}
        >
          When were you born?
        </h1>
        <p
          style={css(
            `margin: 8px 0 0; max-width: 320px; font-size: 15px; line-height: 22px; color: #8c8c96;`
          )}
        >
          This will be used to calibrate your custom plan.
        </p>

        {/* Central Selection: Month, Day, Year side-by-side */}
        <div style={css(`flex: 1; display: flex; flex-direction: column; justify-content: center;`)}>
          <div style={css(`display: grid; grid-template-columns: 1.35fr 1fr 1.15fr; gap: 10px;`)}>
            {/* Month */}
            <div style={css(`display: flex; flex-direction: column; gap: 8px;`)}>
              <label style={css(`font-size: 13px; font-weight: 600; color: #9a9aa3; margin-left: 4px;`)}>
                Month
              </label>
              <div style={css(`position: relative; width: 100%;`)}>
                <select
                  value={vals.month}
                  onChange={vals.onMonth}
                  aria-label="Birth Month"
                  style={css(
                    `width: 100%; height: 58px; border-radius: 20px; background: #202024; border: 1.5px solid #333338; color: #ffffff; font-size: 15px; font-weight: 600; padding: 0 28px 0 14px; appearance: none; -webkit-appearance: none; cursor: pointer; text-overflow: ellipsis; white-space: nowrap; overflow: hidden;`
                  )}
                >
                  {MONTH_NAMES.map((name, index) => (
                    <option key={name} value={String(index + 1)}>
                      {name}
                    </option>
                  ))}
                </select>
                <div
                  style={css(
                    `position: absolute; right: 10px; top: 50%; transform: translateY(-50%); pointer-events: none; color: #7d7d85;`
                  )}
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Day */}
            <div style={css(`display: flex; flex-direction: column; gap: 8px;`)}>
              <label style={css(`font-size: 13px; font-weight: 600; color: #9a9aa3; margin-left: 4px;`)}>
                Day
              </label>
              <div style={css(`position: relative; width: 100%;`)}>
                <select
                  value={vals.day}
                  onChange={vals.onDay}
                  aria-label="Birth Day"
                  style={css(
                    `width: 100%; height: 58px; border-radius: 20px; background: #202024; border: 1.5px solid #333338; color: #ffffff; font-size: 16px; font-weight: 600; padding: 0 24px 0 14px; appearance: none; -webkit-appearance: none; cursor: pointer;`
                  )}
                >
                  {days.map((d) => (
                    <option key={d} value={String(d)}>
                      {d}
                    </option>
                  ))}
                </select>
                <div
                  style={css(
                    `position: absolute; right: 10px; top: 50%; transform: translateY(-50%); pointer-events: none; color: #7d7d85;`
                  )}
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Year */}
            <div style={css(`display: flex; flex-direction: column; gap: 8px;`)}>
              <label style={css(`font-size: 13px; font-weight: 600; color: #9a9aa3; margin-left: 4px;`)}>
                Year
              </label>
              <div style={css(`position: relative; width: 100%;`)}>
                <select
                  value={vals.year}
                  onChange={vals.onYear}
                  aria-label="Birth Year"
                  style={css(
                    `width: 100%; height: 58px; border-radius: 20px; background: #202024; border: 1.5px solid #333338; color: #ffffff; font-size: 16px; font-weight: 600; padding: 0 24px 0 14px; appearance: none; -webkit-appearance: none; cursor: pointer;`
                  )}
                >
                  {years.map((y) => (
                    <option key={y} value={String(y)}>
                      {y}
                    </option>
                  ))}
                </select>
                <div
                  style={css(
                    `position: absolute; right: 10px; top: 50%; transform: translateY(-50%); pointer-events: none; color: #7d7d85;`
                  )}
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Continue Button */}
        <a
          href="#/Goal"
          onClick={handleContinue}
          style={css(
            `margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none; cursor: pointer;`
          )}
        >
          Continue
        </a>
      </div>
    </>
  );
}
