import React from "react";
import bowl from "./bowl.png";

const features = [
  {
    label: ["Instant AI", "Meal Scanning"],
    icon: (
      <>
        <path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2.2l1.3-2h6l1.3 2h2.2A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z" />
        <circle cx="12" cy="13" r="3.6" />
      </>
    ),
  },
  {
    label: ["Detailed Macro", "Analysis"],
    icon: (
      <>
        <rect x="3.5" y="13" width="4" height="7" rx="1" />
        <rect x="9.5" y="8" width="4" height="12" rx="1" />
        <rect x="15.5" y="4" width="4" height="16" rx="1" />
      </>
    ),
  },
  {
    label: ["Personalized", "Calorie Plan"],
    icon: <path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1.1 5.8L12 16.8 6.7 19.6l1.1-5.8L3.5 9.7l5.9-.8z" />,
  },
  {
    label: ["Data Export", "& Reports"],
    icon: (
      <>
        <path d="M6 3h8l5 5v11.5A1.5 1.5 0 0 1 17.5 21h-11A1.5 1.5 0 0 1 5 19.5v-15A1.5 1.5 0 0 1 6.5 3z" />
        <path d="M14 3v5h5" />
        <text x="12" y="17" textAnchor="middle" fontSize="5.6" fontWeight="700" fill="#ee7d1f" stroke="none">
          PDF
        </text>
      </>
    ),
  },
];

export default function OfferScreen({ onClose, onClaim, go, onNavigate }) {
  const handleClose = () => {
    if (onClose) onClose();
    else if (go) go('Home');
    else if (onNavigate) onNavigate('home');
    else if (typeof window !== 'undefined' && window.history) window.history.back();
  };

  const handleClaim = () => {
    try {
      localStorage.setItem('calsen-pro', 'true');
      localStorage.setItem('calsen-is-pro', 'true');
    } catch (e) {}
    if (onClaim) onClaim();
    else if (go) go('Home');
    else if (onNavigate) onNavigate('home');
  };

  return (
    <div className="offer-root">
      <style>{css}</style>

      <div className="offer-sheet">
        <div className="blob blob-a" />
        <div className="blob blob-b" />
        <div className="blob blob-c" />

        <button className="close-btn" aria-label="Close" onClick={handleClose}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
            <path d="M5 5l14 14M19 5L5 19" />
          </svg>
        </button>

        <div className="badge">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ee7d1f" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <circle cx="12" cy="12" r="9.5" />
            <path d="M12 7v5.2l3.2 1.8" />
          </svg>
          <span>Limited Time Offer</span>
        </div>

        <h1 className="headline">
          Get <span className="grad big">80</span>
          <span className="grad">%</span> OFF
        </h1>
        <p className="subhead">Your Nutrition Journey</p>

        <div className="hero">
          <div className="hero-shadow" />
          <svg className="leaf leaf-left" width="52" height="30" viewBox="0 0 62 40" aria-hidden="true">
            <path d="M2 20 C14 2, 46 2, 60 20 C46 38, 14 38, 2 20Z" fill="#74a050" />
            <path d="M4 20 L58 20" stroke="#56803a" strokeWidth="1.4" fill="none" />
          </svg>
          <svg className="leaf leaf-right" width="30" height="56" viewBox="0 0 30 56" aria-hidden="true">
            <path d="M15 2 C30 16, 30 40, 15 54 C0 40, 0 16, 15 2Z" fill="#74a050" />
            <path d="M15 6 L15 52" stroke="#56803a" strokeWidth="1.3" fill="none" />
          </svg>
          <img className="bowl" src={bowl} alt="Healthy grilled chicken and avocado bowl" />
          <p className="hero-text">Unlock premium features and reach your health goals faster.</p>
        </div>

        <div className="price-pill">
          <span className="old-price">$99.99</span>
          <div className="divider" />
          <div className="new-price-wrap">
            <span className="grad new-price">$19.99</span>
            <span className="per-year">/year</span>
          </div>
        </div>

        <div className="month-pill">
          <span>Just $1.66 / Month</span>
        </div>

        <div className="features">
          {features.map((f, i) => (
            <div className={"feature" + (i > 0 ? " feature-sep" : "")} key={i}>
              <div className="feature-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ee7d1f" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  {f.icon}
                </svg>
              </div>
              <div className="feature-label">
                {f.label[0]}
                <br />
                {f.label[1]}
              </div>
            </div>
          ))}
        </div>

        <div className="spacer" />

        <button className="cta" onClick={handleClaim}>
          Start 3-Day Free Trial
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M4 12h16M14 6l6 6-6 6" />
          </svg>
        </button>

        <div className="fineprint">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6e5f55" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M12 3l7.5 2.8v5.9c0 4.6-3.1 8.3-7.5 9.8-4.4-1.5-7.5-5.2-7.5-9.8V5.8z" />
            <path d="M8.8 12.2l2.2 2.2 4.2-4.4" />
          </svg>
          <span>No commitment. Cancel anytime in 1 click.</span>
        </div>
      </div>
    </div>
  );
}

const css = `
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap');

.offer-root, .offer-root * { box-sizing: border-box; }
.offer-root {
  position: fixed; inset: 0; z-index: 9999;
  width: 100%; height: 100%; background: #efeae4;
  font-family: 'Outfit', system-ui, sans-serif; color: #2b1d14;
  display: flex; justify-content: center;
  overflow-y: auto; overflow-x: hidden; -webkit-overflow-scrolling: touch;
  touch-action: pan-y;
}
.offer-sheet {
  position: relative; width: 100%; max-width: 430px; min-height: 100%;
  margin-top: 10px; border-radius: 30px 30px 0 0; overflow-x: hidden;
  background: linear-gradient(180deg, #fbf8f4 0%, #fcf1e5 48%, #fbe6d2 100%);
  padding: 0 24px 28px; display: flex; flex-direction: column;
}
.offer-sheet > * { position: relative; }

.blob { position: absolute !important; border-radius: 50%; }
.blob-a { right: -90px; top: 215px; width: 330px; height: 250px; background: #fdebd8; opacity: .9; }
.blob-b { left: -110px; top: 330px; width: 380px; height: 220px; background: #fdeddc; opacity: .95; }
.blob-c { left: -60px; bottom: -80px; width: 300px; height: 200px; background: #fcdcbd; opacity: .55; }

.close-btn {
  position: absolute !important; right: 20px; top: 20px; z-index: 2;
  width: 28px; height: 28px; padding: 0; border: 0; background: none;
  color: #2b1d14; display: flex; align-items: center; justify-content: center; cursor: pointer;
}

.badge {
  align-self: center; margin-top: 30px; display: flex; align-items: center; gap: 8px;
  height: 34px; padding: 0 18px; border-radius: 999px;
  background: linear-gradient(180deg, rgba(255,255,255,.8), rgba(254,234,212,.75));
  border: 1px solid #f5cfa8; box-shadow: 0 4px 12px rgba(240,140,50,.12);
  font-size: 14.5px; font-weight: 500; color: #ee7d1f;
}

.grad {
  background: linear-gradient(180deg, #ff9a3c 0%, #ee6f12 100%);
  -webkit-background-clip: text; background-clip: text; color: transparent;
}
.headline {
  margin: 12px 0 0; text-align: center; white-space: nowrap;
  font-weight: 600; font-size: 50px; line-height: 1.1; color: #2b1d14;
}
.headline .big { font-size: 62px; font-weight: 700; }
.subhead { margin: 6px 0 0; text-align: center; font-size: 21px; font-weight: 400; color: #6e5f55; letter-spacing: .2px; }

.hero { margin-top: 14px; height: 210px; }
.hero-text { position: absolute; left: 0; top: 0; width: 52%; margin: 0; font-size: 14.5px; line-height: 1.45; color: #6e5f55; }
.bowl { position: absolute; right: -16px; bottom: 14px; width: 68%; height: auto; display: block; border-radius: 50%; object-fit: cover; }
.hero-shadow {
  position: absolute; right: 4px; bottom: 6px; width: 62%; height: 26px; border-radius: 50%;
  background: radial-gradient(ellipse at center, rgba(190,120,60,.28) 0%, rgba(190,120,60,0) 70%);
}
.leaf { position: absolute; }
.leaf-left { left: 14px; top: 116px; transform: rotate(14deg); }
.leaf-right { right: 12px; top: -4px; transform: rotate(-12deg); }

.price-pill {
  display: flex; align-items: center; justify-content: center; gap: 22px; height: 82px;
  border-radius: 999px;
  background: linear-gradient(180deg, rgba(255,255,255,.72), rgba(255,242,228,.55));
  border: 1.5px solid rgba(255,255,255,.95);
  box-shadow: 0 8px 24px rgba(240,150,70,.14), inset 0 1px 0 rgba(255,255,255,.9);
}
.old-price { font-size: 27px; font-weight: 500; color: #6e5f55; text-decoration: line-through; text-decoration-thickness: 2px; }
.divider { width: 1px; height: 42px; background: #e3cfbd; }
.new-price-wrap { display: flex; align-items: baseline; gap: 3px; }
.new-price { font-size: 46px; font-weight: 700; line-height: 1; }
.per-year { font-size: 14px; color: #6e5f55; }

.month-pill {
  align-self: center; margin-top: 8px; height: 37px; padding: 0 30px; display: flex; align-items: center;
  border-radius: 999px; font-size: 15.5px; font-weight: 500; color: #3a2a20;
  background: linear-gradient(180deg, rgba(255,238,220,.95), rgba(253,224,196,.8));
  box-shadow: 0 4px 12px rgba(240,150,70,.12);
}

.features { margin-top: 30px; display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); }
.feature { display: flex; flex-direction: column; align-items: center; gap: 8px; text-align: center; padding: 0 2px; }
.feature-sep { border-left: 1px solid #f0dcc9; }
.feature-icon {
  width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,.65); border: 1px solid rgba(255,255,255,.95);
  box-shadow: 0 4px 12px rgba(240,150,70,.13);
}
.feature-label { font-size: 11px; line-height: 1.25; color: #3a2a20; }

.spacer { flex: 1; min-height: 28px; }

.cta {
  height: 60px; border: 0; border-radius: 999px; cursor: pointer;
  background: linear-gradient(180deg, #ff9a3c 0%, #ee6f12 100%);
  box-shadow: 0 10px 24px rgba(238,111,18,.33), inset 0 1.5px 0 rgba(255,255,255,.35);
  color: #fff; display: flex; align-items: center; justify-content: center; gap: 12px;
  font-family: inherit; font-size: 19px; font-weight: 600;
}
.fineprint { margin-top: 16px; display: flex; align-items: center; justify-content: center; gap: 8px; color: #6e5f55; font-size: 11.5px; }
`;
