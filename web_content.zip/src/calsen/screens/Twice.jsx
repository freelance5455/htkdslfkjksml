import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
`;

class Component extends DCLogic {
  renderVals() {
    return {};
  }
}

export default function Twice({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('OnTrack');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    if (go) go('Stopping');
    else if (onNext) onNext();
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a
            href="#/OnTrack"
            onClick={handleBack}
            aria-label="Back"
            style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 78%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          Reach your goal up to 3x faster with CalSen
        </h1>
        <p style={css(`margin:8px 0 0;font-size:15px;line-height:22px;color:#8c8c96;`)}></p>
        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;`)}>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:32px 24px 28px;`)}>
            <div style={css(`display:flex;gap:16px;justify-content:center;align-items:flex-end;height:340px;`)}>
              <div style={css(`width:120px;display:flex;flex-direction:column;align-items:center;gap:12px;`)}>
                <div style={css(`width:100%;height:70px;background:#3a3a40;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;`)}>
                  1X
                </div>
                <span style={css(`font-size:14px;font-weight:600;color:#9a9aa3;`)}>
                  On your own
                </span>
              </div>
              <div style={css(`width:120px;display:flex;flex-direction:column;align-items:center;gap:12px;`)}>
                <div style={css(`width:100%;height:250px;background:linear-gradient(180deg,#FFB23A,#FF6A00);color:#1a0d00;border-radius:20px;display:flex;align-items:flex-start;justify-content:center;padding-top:20px;box-sizing:border-box;font-size:26px;font-weight:800;`)}>
                  3X
                </div>
                <span style={css(`font-size:14px;font-weight:700;`)}>
                  With CalSen
                </span>
              </div>
            </div>
            <p style={css(`margin:26px 0 0;text-align:center;font-size:16px;line-height:24px;color:#c9c9d0;`)}>
              The development rate may reach up to 3X
            </p>
          </div>
        </div>
        <a
          href="#/Stopping"
          onClick={handleContinue}
          style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none;`)}
        >
          Continue
        </a>
      </div>
    </>
  );
}
