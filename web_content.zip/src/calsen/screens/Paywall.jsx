import React, { useEffect, useRef, useState } from "react";
import { getCurrentLang } from "../../lib/i18n";

/* CalSen — Pro paywall, styled to match the CalSen app (home screen):
   cream/peach light theme and black/orange dark theme, big rounded cards,
   round soft buttons, floating bottom card.
   Tailwind is used for layout/spacing (core classes only). Colors, gradients,
   glass and glow are inline styles, so it renders identically with or without
   a Tailwind compiler. */

const CSS = `@import url('https://fonts.googleapis.com/css2?family=Urbanist:wght@500;600;700;800&display=swap');
#calsen-paywall-screen{scroll-behavior:smooth;-webkit-overflow-scrolling:touch;touch-action:pan-y}
.pw-btn{transition:transform .12s ease,opacity .2s ease;cursor:pointer;font-family:inherit}
.pw-btn:active{transform:scale(.97)}
.pw-btn:focus-visible{outline:2px solid #FF6A1A;outline-offset:3px}
@keyframes pw-spin{to{transform:rotate(360deg)}}
@keyframes pw-pop{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.pw-btn,.pw-anim{transition:none;animation:none}}`;

const GRAD = { backgroundImage: "linear-gradient(135deg,#FF7A24,#F2570F)", color: "#fff" };
const BLUR = { backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)" };

const THEMES = {
  light: {
    page: "#FCF6F0",
    bg: "radial-gradient(ellipse 380px 440px at 100% 330px, rgba(248,200,175,0.95), transparent 70%), radial-gradient(ellipse 380px 460px at 100% 900px, rgba(245,188,182,0.6), transparent 72%)",
    text: "#1F1410", muted: "#7D6F66", faint: "#948479", orange: "#E8590C", divider: "#EBD9CC",
    card: { background: "#FCF7F2", border: "1px solid #F2E3D8", boxShadow: "0 14px 36px rgba(240,120,70,0.10)" },
    round: { background: "#FFF9F4", border: "1px solid rgba(255,255,255,0.9)", boxShadow: "0 8px 22px rgba(240,120,70,0.18)" },
    tile: "#FFE8DA", tag: { background: "rgba(255,106,26,0.14)", color: "#C2410C" },
    pill: { background: "rgba(255,255,255,0.7)", border: "1.5px solid rgba(255,106,26,0.45)", color: "#E8590C" },
    sel: "#FFF1E6", bar: "rgba(252,247,242,0.92)", radio: "#D9C3B5", quote: "#B45309",
  },
  dark: {
    page: "#050505",
    bg: "radial-gradient(ellipse 420px 520px at 100% 360px, rgba(255,106,20,0.75), transparent 70%), radial-gradient(ellipse 520px 440px at 40% 950px, rgba(190,45,20,0.45), transparent 72%)",
    text: "#FFFFFF", muted: "#A1A1AA", faint: "#8A8A8A", orange: "#FF8A1F", divider: "rgba(255,255,255,0.10)",
    card: { background: "#0E0E0E", border: "1px solid rgba(255,255,255,0.07)", boxShadow: "0 16px 40px rgba(0,0,0,0.6)" },
    round: { background: "#121212", border: "1px solid rgba(255,255,255,0.07)", boxShadow: "0 8px 22px rgba(0,0,0,0.5)" },
    tile: "#2B1A0C", tag: { background: "rgba(255,106,26,0.18)", color: "#FFB27A" },
    pill: { background: "rgba(255,106,26,0.10)", border: "1.5px solid rgba(255,138,31,0.5)", color: "#FF8A1F" },
    sel: "#1A0E07", bar: "rgba(14,14,14,0.92)", radio: "#52525B", quote: "rgba(254,215,170,0.8)",
  },
};

const PATHS = {
  x: "M6 6l12 12M18 6L6 18",
  sun: "M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4",
  moon: "M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z",
  bolt: "M13 2L4 14h7l-1 8 9-12h-7z",
  flask: "M9 3h6M10 3v6l-5 9a2 2 0 001.8 3h10.4a2 2 0 001.8-3l-5-9V3M7.5 15h9",
  target: "M12 3a9 9 0 100 18 9 9 0 000-18zM12 8a4 4 0 100 8 4 4 0 000-8zM12 12h.01",
  trend: "M3 17l6-6 4 4 8-8M15 7h6v6",
  bell: "M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0",
  check: "M5 12.5l4.5 4.5L19 7.5",
  clock: "M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2",
  star: "M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8z",
  doc: "M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8zM14 3v5h5M9 13h6M9 17h4",
  arrow: "M5 12h14M13 6l6 6-6 6",
};

function Icon({ n, size = 20, sw = 2, fill = "none" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={PATHS[n]} />
    </svg>
  );
}

const getFeatures = (isAr) => [
  { icon: "bolt", title: isAr ? "مسح غير محدود للوجبات بالذكاء الاصطناعي" : "Unlimited AI Camera Scans", note: isAr ? "نتائج فورية، بدون حدود يومية" : "Instant results, no daily scanning limits" },
  { icon: "flask", title: isAr ? "تحليل عميق للمغذيات الكبرى والدقيقة" : "Deep Macro & Micronutrients Breakdown", note: isAr ? "بروتين، كربوهيدرات، دهون وألياف" : "Protein, carbs, fats and fiber" },
  { icon: "target", title: isAr ? "قاعدة بيانات ذكية وقارئ الباركود" : "Smart Food Database & Barcode Scanner", note: isAr ? "ابحث وسجل أي طعام في ثوانٍ" : "Find and log any food instantly" },
  { icon: "star", title: isAr ? "خطة سعرات مخصصة لهدفك الشخصي" : "Personalized Calorie Plan", note: isAr ? "أهداف يومية مبنية على جسمك ونشاطك" : "Daily targets built around your goal" },
  { icon: "trend", title: isAr ? "توقعات العجز والوصول للوزن المستهدف" : "AI Deficit & Weight Loss Projection", note: isAr ? "اكتشف تاريخ وصولك إلى هدفك بدقة" : "See when you will reach your goal" },
  { icon: "bell", title: isAr ? "تذكيرات ذكية بالوجبات والماء" : "Custom Meal & Macro Reminders", note: isAr ? "حافظ على الالتزام طوال اليوم" : "Stay on target all day" },
  { icon: "doc", title: isAr ? "تصدير البيانات والتقارير PDF" : "Data Export & Reports", note: isAr ? "شارك تقدمك مع مدربك أو طبيبك" : "Export your progress as PDF reports" },
];

export default function CalSenPaywall({ go, onClose, onComplete, onNavigate }) {
  const [dark, setDark] = useState(() => {
    try {
      const v = window.localStorage.getItem('plateful-theme');
      if (v === 'dark') return true;
      if (v === 'light') return false;
      return typeof window !== "undefined" && !!window.matchMedia?.("(prefers-color-scheme: dark)").matches;
    } catch (e) {
      return false;
    }
  });
  const [lang, setLang] = useState(() => getCurrentLang());
  const [plan, setPlan] = useState("annual");
  const [status, setStatus] = useState("idle"); // idle | loading | success
  const [toast, setToast] = useState("");
  const timers = useRef([]);
  const t = THEMES[dark ? "dark" : "light"];
  const annual = plan === "annual";
  const isAr = lang === 'العربية';

  useEffect(() => {
    const handler = (e) => setLang(e.detail || getCurrentLang());
    window.addEventListener('calsen-lang-change', handler);
    return () => {
      window.removeEventListener('calsen-lang-change', handler);
      timers.current.forEach(clearTimeout);
    };
  }, []);
  const later = (fn, ms) => timers.current.push(setTimeout(fn, ms));

  const handleClose = () => {
    if (onClose) onClose();
    else if (go) go('Home');
    else if (onNavigate) onNavigate('home');
    else if (typeof window !== 'undefined' && window.history) window.history.back();
  };

  const subscribe = () => {
    if (status !== "idle") return;
    setStatus("loading");
    later(() => {
      setStatus("success");
      try {
        localStorage.setItem("calsen-pro", "true");
        localStorage.setItem("calsen-is-pro", "true");
      } catch (e) {}
      later(() => {
        if (onComplete) onComplete({ isPro: true });
        else if (go) go('Home');
        else if (onNavigate) onNavigate('home');
      }, 1200);
    }, 1500);
  };

  const restore = () => {
    setToast(isAr ? "جارٍ البحث عن الاشتراكات السابقة…" : "Looking for purchases…");
    later(() => setToast(isAr ? "لم يتم العثور على مشتريات سابقة لهذا الحساب" : "No previous purchases found on this account"), 1100);
    later(() => setToast(""), 3200);
  };

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    try {
      window.localStorage.setItem('plateful-theme', next ? 'dark' : 'light');
    } catch (e) {}
  };

  const circle = { width: 52, height: 52, borderRadius: 26, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: t.text, ...t.round, ...BLUR };
  const tile = { width: 52, height: 52, borderRadius: 20, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: t.tile, color: t.orange };

  const planCard = (selected) => ({
    position: "relative", width: "100%", textAlign: isAr ? "right" : "left", color: t.text, borderRadius: 36, padding: "20px 18px",
    display: "flex", alignItems: "center", gap: 14, fontFamily: "inherit", overflow: "hidden",
    ...(selected
      ? { background: t.sel, border: "2px solid #FF6A1A", boxShadow: "0 0 0 4px rgba(255,106,26,0.14), 0 14px 34px rgba(242,87,15,0.30)" }
      : { ...t.card, border: t.card.border.replace("1px", "2px") }),
  });

  const radio = (selected) => (
    <span style={{ width: 24, height: 24, borderRadius: 12, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", boxSizing: "border-box", ...(selected ? GRAD : { border: `2px solid ${t.radio}` }) }}>
      {selected && <Icon n="check" size={14} sw={3.5} />}
    </span>
  );

  return (
    <div
      id="calsen-paywall-screen"
      dir={isAr ? 'rtl' : 'ltr'}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: "100%",
        height: "100%",
        zIndex: 9999,
        background: t.page,
        color: t.text,
        overflowY: "auto",
        overflowX: "hidden",
        WebkitOverflowScrolling: "touch",
        touchAction: "pan-y",
        overscrollBehaviorY: "contain",
        fontFamily: "Urbanist, system-ui, sans-serif",
        transition: "background .3s, color .3s",
      }}
    >
      <style>{CSS}</style>
      <div
        style={{
          position: "relative",
          margin: "0 auto",
          width: "100%",
          maxWidth: 440,
          minHeight: "100%",
          overflow: "visible",
        }}
      >
        <div style={{ position: "absolute", inset: 0, background: t.bg, pointerEvents: "none" }} />

        {toast && (
          <div role="status" className="pw-anim" style={{ position: "fixed", top: 88, left: "50%", transform: "translateX(-50%)", zIndex: 30, maxWidth: 360, width: "calc(100% - 40px)", textAlign: "center", padding: "14px 18px", borderRadius: 24, fontSize: 14, fontWeight: 700, color: t.text, animation: "pw-pop .25s ease-out", ...t.card, ...BLUR }}>
            {toast}
          </div>
        )}

        <div className="flex flex-col gap-6" style={{ position: "relative", padding: "20px 20px 280px" }}>
          {/* Top bar */}
          <header className="flex items-center justify-between gap-2">
            <button onClick={handleClose} className="pw-btn" style={circle} aria-label="Close"><Icon n="x" size={22} sw={2.4} /></button>
            <div className="flex items-center gap-2">
              <button onClick={restore} className="pw-btn" style={{ background: "transparent", border: "none", color: t.muted, fontSize: 14, fontWeight: 700, minHeight: 44, padding: "0 10px" }}>Restore purchases</button>
              <button onClick={toggleTheme} className="pw-btn" style={circle} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}><Icon n={dark ? "sun" : "moon"} /></button>
            </div>
          </header>

          {/* Offer hero */}
          <section className="flex flex-col items-center" style={{ gap: 12, textAlign: "center" }}>
            <span style={{ ...t.pill, ...BLUR, display: "flex", alignItems: "center", gap: 8, height: 44, padding: "0 20px", borderRadius: 22, fontSize: 15, fontWeight: 700 }}>
              <Icon n="clock" size={18} sw={2.2} /> {isAr ? "عرض لفترة محدودة" : "Limited Time Offer"}
            </span>
            <h1 style={{ margin: 0, fontSize: 46, lineHeight: 1.1, fontWeight: 800, letterSpacing: "-0.02em" }}>
              {isAr ? (
                <>وفر <span style={{ color: t.orange }}>80%</span> الآن</>
              ) : (
                <>Get <span style={{ color: t.orange }}>80%</span> OFF</>
              )}
            </h1>
            <p style={{ margin: 0, fontSize: 19, fontWeight: 600, color: t.muted }}>
              {isAr ? "في رحلتك الغذائية والصحية" : "Your Nutrition Journey"}
            </p>
          </section>

          {/* Value headline */}
          <section className="flex flex-col items-center gap-3" style={{ textAlign: "center", padding: "12px 4px 0" }}>
            <h2 style={{ margin: 0, fontSize: 28, lineHeight: 1.2, fontWeight: 800, letterSpacing: "-0.02em", textWrap: "balance", maxWidth: 360 }}>
              {isAr ? "حقق جسم أحلامك أسرع بثلاث مرات" : "Reach Your Dream Body 3x Faster"}
            </h2>
            <p style={{ margin: 0, fontSize: 15, lineHeight: 1.55, fontWeight: 500, color: t.muted, maxWidth: 360, textWrap: "balance" }}>
              {isAr
                ? "افتح مسح الوجبات اللامحدود بالذكاء الاصطناعي، وتحليل المغذيات الدقيقة وتوقعات نزول الوزن."
                : "Unlock unlimited AI meal scans, deep macro breakdowns, and personalized fat loss predictions."}
            </p>
          </section>

          {/* Features */}
          <section className="flex flex-col gap-4" style={{ ...t.card, borderRadius: 36, padding: 22 }}>
            {getFeatures(isAr).map((f) => (
              <div key={f.title} className="flex items-center gap-4">
                <span style={tile}><Icon n={f.icon} size={24} /></span>
                <div className="flex flex-col" style={{ gap: 2 }}>
                  <span style={{ fontSize: 15.5, fontWeight: 700, lineHeight: 1.25 }}>{f.title}</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: t.muted }}>{f.note}</span>
                </div>
              </div>
            ))}
          </section>

          {/* Quote */}
          <p style={{ margin: 0, textAlign: "center", fontSize: 13, fontWeight: 600, letterSpacing: "0.025em", color: t.quote }}>
            {isAr ? "✨ صحتك هي أفضل استثمار في حياتك" : "✨ Your health is your greatest investment"}
          </p>

          {/* Plans */}
          <section className="flex flex-col gap-4" role="radiogroup" aria-label="Choose your plan" style={{ paddingTop: 6 }}>
            <div style={{ position: "relative" }}>
              <button role="radio" aria-checked={annual} onClick={() => setPlan("annual")} className="pw-btn" style={planCard(annual)}>
                {radio(annual)}
                <div className="flex flex-wrap items-center" style={{ flexGrow: 1, minWidth: 0, gap: "6px 8px" }}>
                  <span style={{ fontSize: 18, fontWeight: 800 }}>{isAr ? "الاشتراك السنوي" : "Annual Plan"}</span>
                  <span style={{ ...t.tag, height: 22, display: "inline-flex", alignItems: "center", padding: "0 10px", borderRadius: 11, fontSize: 11.5, fontWeight: 700, whiteSpace: "nowrap" }}>
                    {isAr ? "يشمل 3 أيام تجربة مجانية" : "Includes 3-Day Free Trial"}
                  </span>
                </div>
                <span style={{ textAlign: isAr ? "left" : "right", whiteSpace: "nowrap", flexShrink: 0 }}>
                  <span>
                    <span style={{ fontSize: 28, fontWeight: 800, lineHeight: 1, color: t.orange }}>$1.66</span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: t.muted }}> {isAr ? "/ شهرياً" : "/mo"}</span>
                  </span>
                  <span style={{ display: "block", marginTop: 4, fontSize: 12, fontWeight: 600, color: t.muted }}>
                    {isAr ? "تجديد سنوي ($19.99/سنة)" : "Billed annually ($19.99/yr)"}
                  </span>
                </span>
              </button>
              <span style={{ ...GRAD, position: "absolute", top: -13, [isAr ? "right" : "left"]: 24, height: 26, display: "flex", alignItems: "center", padding: "0 12px", borderRadius: 13, fontSize: 11.5, fontWeight: 800, letterSpacing: "0.04em", boxShadow: "0 6px 16px rgba(242,87,15,0.4)" }}>
                {isAr ? "الأكثر طلباً • وفر 80%" : "MOST POPULAR • SAVE 80%"}
              </span>
            </div>

            <button role="radio" aria-checked={!annual} onClick={() => setPlan("monthly")} className="pw-btn" style={planCard(!annual)}>
              {radio(!annual)}
              <div className="flex flex-col" style={{ flexGrow: 1, gap: 3 }}>
                <span style={{ fontSize: 18, fontWeight: 800 }}>{isAr ? "الاشتراك الشهري" : "Monthly Plan"}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: t.muted }}>
                  {isAr ? "تجديد شهري • إلغاء في أي وقت" : "Billed monthly • Cancel anytime"}
                </span>
              </div>
              <span style={{ textAlign: isAr ? "left" : "right", whiteSpace: "nowrap" }}>
                <span style={{ fontSize: 22, fontWeight: 800 }}>$4.99</span>
                <span style={{ display: "block", fontSize: 13, fontWeight: 600, color: t.muted }}>
                  {isAr ? "/ شهرياً" : "/ month"}
                </span>
              </span>
            </button>
          </section>

          {/* Trust note (centered, no card) */}
          <section className="flex flex-col items-center" style={{ gap: 4, textAlign: "center", padding: "2px 12px 0" }}>
            <span className="flex items-center gap-2" style={{ fontSize: 16, fontWeight: 800 }}>
              <span style={{ color: t.orange, display: "flex" }}><Icon n="target" size={20} /></span>
              {isAr ? "دقة مسح 98% بالذكاء الاصطناعي" : "98% AI Scanning Accuracy"}
            </span>
            <span style={{ fontSize: 13, fontWeight: 500, lineHeight: 1.45, color: t.muted, maxWidth: 320, textWrap: "balance" }}>
              {isAr ? "مدعوم بقاعدة بيانات USDA • آمن ومضمون 100%" : "Backed by Verified USDA Food Database • 100% Risk-Free"}
            </span>
          </section>
        </div>

        {/* Floating bottom action card (like the app's floating nav) */}
        <div style={{ position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 20, pointerEvents: "none" }}>
          <div style={{ margin: "0 auto", maxWidth: 440, padding: "0 12px 12px", pointerEvents: "auto" }}>
            <div className="flex flex-col gap-3" style={{ ...t.card, background: t.bar, borderRadius: 36, padding: "16px 18px 12px", ...BLUR }}>
              <button
                onClick={subscribe}
                disabled={status !== "idle"}
                className="pw-btn flex items-center justify-center gap-2"
                style={{ ...GRAD, width: "100%", height: 62, borderRadius: 31, border: "none", fontSize: 18, fontWeight: 800, boxShadow: "0 12px 30px rgba(242,87,15,0.45)", opacity: status === "loading" ? 0.85 : 1 }}
              >
                {status === "loading" && (
                  <span className="pw-anim" style={{ width: 20, height: 20, borderRadius: 10, border: "3px solid rgba(255,255,255,0.4)", borderTopColor: "#fff", animation: "pw-spin .8s linear infinite" }} />
                )}
                {status === "idle" && (
                  <>
                    {annual
                      ? (isAr ? "ابدأ تجربة مجانية 3 أيام" : "Start 3-Day Free Trial")
                      : (isAr ? "اشترك بـ 4.99$/شهرياً" : "Subscribe for $4.99/mo")}
                    <Icon n="arrow" size={22} sw={2.6} />
                  </>
                )}
                {status === "loading" && (isAr ? "جارٍ التفعيل…" : "Processing…")}
                {status === "success" && (<><Icon n="check" size={22} sw={3} /> {isAr ? "أهلاً بك في كالسن برو!" : "Welcome to CalSen Pro"}</>)}
              </button>

              {status === "success" ? (
                <p role="status" style={{ margin: 0, textAlign: "center", fontSize: 13, fontWeight: 600, color: t.muted }}>
                  {isAr ? "تم إكمال الاشتراك بنجاح. استمتع بميزات برو!" : "Test checkout complete. Welcome to CalSen Pro!"}
                </p>
              ) : (
                <p style={{ margin: 0, textAlign: "center", fontSize: 12.5, lineHeight: 1.45, fontWeight: 600, color: t.muted }}>
                  {annual && <span style={{ display: "block" }}>{isAr ? "3 أيام مجاناً، ثم 19.99$ سنوياً" : "3 days free, then $19.99/year"}</span>}
                  {isAr ? "إلغاء في أي وقت بنقرة واحدة • بدون أي التزام • آمن 100%" : "Cancel anytime with 1 tap • No commitment • 100% Risk-Free"}
                </p>
              )}

              <div className="flex items-center justify-center gap-3" style={{ fontSize: 12.5, fontWeight: 600 }}>
                <a href="#terms" onClick={(e) => e.preventDefault()} style={{ color: t.faint, textDecoration: "underline", padding: "8px 4px" }}>
                  {isAr ? "شروط الخدمة" : "Terms of Service"}
                </a>
                <span style={{ color: t.faint }} aria-hidden="true">•</span>
                <a href="#privacy" onClick={(e) => e.preventDefault()} style={{ color: t.faint, textDecoration: "underline", padding: "8px 4px" }}>
                  {isAr ? "سياسة الخصوصية" : "Privacy Policy"}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
