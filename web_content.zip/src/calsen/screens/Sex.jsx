import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
input.rd{order:-1;-webkit-appearance:none;appearance:none;width:24px;height:24px;margin:0;flex:none;border-radius:50%;border:2px solid #5a5a62;background:transparent;cursor:pointer}
input.rd:checked{border-color:#ffffff;background:radial-gradient(circle,#ffffff 0 5px,transparent 6px)}
`;

class Component extends DCLogic {
  renderVals() {
    const s = this.state || {};
    const gender = s.gender ?? (localStorage.getItem('calsen-gender') || 'Male');
    try {
      localStorage.setItem('calsen-gender', gender);
      localStorage.setItem('cs_s', gender);
    } catch (e) {}

    return {
      gender,
      isMale: gender === 'Male',
      isFemale: gender === 'Female',
      setMale: () => this.setState({ gender: 'Male' }),
      setFemale: () => this.setState({ gender: 'Female' })
    };
  }
}

export default function Sex({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('Welcome');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    try {
      localStorage.setItem('calsen-gender', vals.gender);
      localStorage.setItem('cs_s', vals.gender);
    } catch (err) {}
    if (onNext) onNext({ gender: vals.gender });
    if (go) go('Workouts');
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Welcome" onClick={handleBack} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 10%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          Choose your sex
        </h1>
        <p style={css(`margin:8px 0 0;font-size:15px;line-height:22px;color:#8c8c96;`)}>
          This helps personalize your daily calorie plan.
        </p>
        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;gap:12px;`)}>
          <label onClick={vals.setMale} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.isMale ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="10" cy="14" r="5" />
                <path d="M14 10l6-6M15 4h5v5" />
              </svg>
            </span>
            <span style={css(`flex:1;display:flex;flex-direction:column;gap:2px;font-size:17px;font-weight:600;`)}>
              Male
            </span>
            <input type="radio" name="sex" checked={vals.isMale} onChange={vals.setMale} aria-label="Male" className="rd" />
          </label>
          <label onClick={vals.setFemale} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.isFemale ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="12" cy="9" r="5" />
                <path d="M12 14v7M9 18h6" />
              </svg>
            </span>
            <span style={css(`flex:1;display:flex;flex-direction:column;gap:2px;font-size:17px;font-weight:600;`)}>
              Female
            </span>
            <input type="radio" name="sex" checked={vals.isFemale} onChange={vals.setFemale} aria-label="Female" className="rd" />
          </label>
        </div>
        <a href="#/Workouts" onClick={handleContinue} style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none; cursor: pointer;`)}>
          Continue
        </a>
      </div>
    </>
  );
}
