import React, { useState } from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
::-webkit-scrollbar{display:none}
input.rd{order:-1;-webkit-appearance:none;appearance:none;width:24px;height:24px;margin:0;flex:none;border-radius:50%;border:2px solid #5a5a62;background:transparent;cursor:pointer}
input.rd:checked{border-color:#ffffff;background:radial-gradient(circle,#ffffff 0 5px,transparent 6px)}
`;

class Component extends DCLogic {
  renderVals() {
    return {};
  }
}

export default function Stopping({ go, onNext, onBack }) {
  const vals = useDC(Component);
  const [selected, setSelected] = useState('Lack of consistency');

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('Twice');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    try {
      localStorage.setItem('calsen-obstacles', JSON.stringify([selected]));
      localStorage.setItem('cs_stopping', selected);
    } catch (err) {}
    if (go) go('Building');
    else if (onNext) onNext({ obstacles: [selected] });
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a
            href="#/Twice"
            onClick={handleBack}
            aria-label="Back"
            style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 86%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          What's stopping you from reaching your goals?
        </h1>
        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;gap:12px;`)}>
          <label className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M20 12a8 8 0 1 1-2.4-5.7" />
                <path d="M20 4v4.5h-4.5" />
                <path d="M9 12.3l2.2 2.2L15.5 10" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Lack of consistency
            </span>
            <input
              type="radio"
              name="s"
              checked={selected === 'Lack of consistency'}
              onChange={() => setSelected('Lack of consistency')}
              aria-label="Lack of consistency"
              className="rd"
            />
          </label>
          <label className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 10.5a8 6.5 0 0 1 16 0z" />
                <path d="M4 14c2 1.6 3 1.6 4 0s3-1.6 4 0 3 1.6 4 0 2-1.6 4 0" />
                <path d="M5 17.2h14a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3z" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Unhealthy eating habits
            </span>
            <input
              type="radio"
              name="s"
              checked={selected === 'Unhealthy eating habits'}
              onChange={() => setSelected('Unhealthy eating habits')}
              aria-label="Unhealthy eating habits"
              className="rd"
            />
          </label>
          <label className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="9" cy="8" r="3.2" />
                <path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5" />
                <circle cx="17.5" cy="9" r="2.6" />
                <path d="M17 14.5c2.6 0 4.5 1.8 4.5 4.5" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Lack of supports
            </span>
            <input
              type="radio"
              name="s"
              checked={selected === 'Lack of supports'}
              onChange={() => setSelected('Lack of supports')}
              aria-label="Lack of supports"
              className="rd"
            />
          </label>
          <label className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect x="3.5" y="5" width="17" height="15" rx="3.5" />
                <path d="M3.5 10h17M8 3v4M16 3v4" />
                <path d="M12 13.2v2.6l1.8 1" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Busy schedule
            </span>
            <input
              type="radio"
              name="s"
              checked={selected === 'Busy schedule'}
              onChange={() => setSelected('Busy schedule')}
              aria-label="Busy schedule"
              className="rd"
            />
          </label>
          <label className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M9 18h6M10 21h4" />
                <path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Lack of meal inspiration
            </span>
            <input
              type="radio"
              name="s"
              checked={selected === 'Lack of meal inspiration'}
              onChange={() => setSelected('Lack of meal inspiration')}
              aria-label="Lack of meal inspiration"
              className="rd"
            />
          </label>
        </div>
        <a
          href="#/Building"
          onClick={handleContinue}
          style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none;`)}
        >
          Continue
        </a>
      </div>
    </>
  );
}
