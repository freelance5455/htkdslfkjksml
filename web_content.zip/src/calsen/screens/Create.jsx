import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
`;

class Component extends DCLogic {
renderVals() {
return {};
}
}

export default function Create({ go }) {
  const vals = useDC(Component);
  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Plan" onClick={(e) => { e.preventDefault(); go('Plan'); }} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 100%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          Create an account
        </h1>
        <div style={css(`margin-top:auto;display:flex;flex-direction:column;gap:14px;padding-bottom:150px;`)}>
          <button type="button" style={css(`height:56px;border:0;border-radius:999px;background:#ffffff;color:#1b1a21;font-family:inherit;font-size:16px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:12px;`)}>
            <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09a6.6 6.6 0 0 1 0-4.18V7.07H2.18a11 11 0 0 0 0 9.86l3.66-2.84z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Sign in with Google
          </button>
          <a href="#/Signup" onClick={(e) => { e.preventDefault(); go('Signup'); }} style={css(`height:56px;box-sizing:border-box;border:1.5px solid #4a4a52;border-radius:999px;color:#ffffff;font-size:16px;font-weight:700;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:12px;`)}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <rect x="3" y="5" width="18" height="14" rx="2" />
              <path d="M3.5 7l8.5 6l8.5-6" />
            </svg>
            Sign in with Email
          </a>
          <label style={css(`display:flex;align-items:flex-start;gap:14px;padding:0 8px;margin-top:12px;font-size:14px;line-height:24px;color:#d8d8de;`)}>
            <input type="checkbox" defaultChecked={true} style={css(`width:22px;height:22px;margin:1px 0 0;accent-color:#ffffff;flex:none;`)} />
            <span>
              By continuing, you agree to CalSen's{" "}
              <a href="#" onClick={(e) => e.preventDefault()} style={css(`color:#ffffff;text-decoration:underline;`)}>
                Terms and Conditions
              </a>
              {" "}and{" "}
              <a href="#" onClick={(e) => e.preventDefault()} style={css(`color:#ffffff;text-decoration:underline;`)}>
                Privacy Policy
              </a>
            </span>
          </label>
          <label style={css(`display:flex;align-items:flex-start;gap:14px;padding:0 8px;font-size:14px;line-height:24px;color:#d8d8de;`)}>
            <input type="checkbox" defaultChecked={true} style={css(`width:22px;height:22px;margin:1px 0 0;accent-color:#ffffff;flex:none;`)} />
            <span>
              Send me tips, new features, and personalized offers from CalSen
            </span>
          </label>
        </div>
      </div>
    </>
  );
}
