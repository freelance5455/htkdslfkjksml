import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
input.rd{order:-1;-webkit-appearance:none;appearance:none;width:24px;height:24px;margin:0;flex:none;border-radius:50%;border:2px solid #5a5a62;background:transparent;cursor:pointer}
input.rd:checked{border-color:#ffffff;background:radial-gradient(circle,#ffffff 0 5px,transparent 6px)}
`;

class Component extends DCLogic {
  renderVals() {
    const s = this.state || {};
    const act = s.act ?? (localStorage.getItem('calsen-activity') || '3-5');
    try {
      localStorage.setItem('calsen-activity', act);
      const factor = act === '6+' ? 1.725 : act === '3-5' ? 1.55 : 1.25;
      localStorage.setItem('calsen-activity-factor', String(factor));
    } catch (e) {}

    return {
      act,
      setAct: (val) => this.setState({ act: val })
    };
  }
}

export default function Workouts({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('Sex');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    try {
      localStorage.setItem('calsen-activity', vals.act);
      const factor = vals.act === '6+' ? 1.725 : vals.act === '3-5' ? 1.55 : 1.25;
      localStorage.setItem('calsen-activity-factor', String(factor));
    } catch (err) {}
    if (onNext) onNext({ activity: vals.act });
    if (go) go('Height');
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a
            href="#/Sex"
            onClick={handleBack}
            aria-label="Back"
            style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 20%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>

        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          How many workouts do you do per week?
        </h1>
        <p style={css(`margin:8px 0 0;font-size:15px;line-height:22px;color:#8c8c96;`)}>
          This will be used to calibrate your custom plan.
        </p>

        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;gap:12px;`)}>
          <label onClick={() => vals.setAct('0-2')} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.act === '0-2' ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="12" cy="12" r="9" />
                <path d="M12 7v5l3 2" />
              </svg>
            </span>
            <span style={css(`flex:1;display:flex;flex-direction:column;gap:2px;font-size:17px;font-weight:600;`)}>
              0 - 2
              <span style={css(`font-size:13px;font-weight:500;color:#9a9aa3;`)}>
                Workouts now and then
              </span>
            </span>
            <input type="radio" name="w" checked={vals.act === '0-2'} onChange={() => vals.setAct('0-2')} aria-label="0 - 2" className="rd" />
          </label>

          <label onClick={() => vals.setAct('3-5')} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.act === '3-5' ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
            </span>
            <span style={css(`flex:1;display:flex;flex-direction:column;gap:2px;font-size:17px;font-weight:600;`)}>
              3 - 5
              <span style={css(`font-size:13px;font-weight:500;color:#9a9aa3;`)}>
                A few workouts per week
              </span>
            </span>
            <input type="radio" name="w" checked={vals.act === '3-5'} onChange={() => vals.setAct('3-5')} aria-label="3 - 5" className="rd" />
          </label>

          <label onClick={() => vals.setAct('6+')} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.act === '6+' ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
                <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
                <path d="M4 22h16" />
                <path d="M10 14.66V17c0 .55-.45 1-1 1H8c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1h8c.55 0 1-.45 1-1v-1c0-.55-.45-1-1-1h-1c-.55 0-1-.45-1-1v-2.34" />
                <path d="M18 2H6v7a6 6 0 0 0 12 0V2z" />
              </svg>
            </span>
            <span style={css(`flex:1;display:flex;flex-direction:column;gap:2px;font-size:17px;font-weight:600;`)}>
              6+
              <span style={css(`font-size:13px;font-weight:500;color:#9a9aa3;`)}>
                Dedicated athlete
              </span>
            </span>
            <input type="radio" name="w" checked={vals.act === '6+'} onChange={() => vals.setAct('6+')} aria-label="6+" className="rd" />
          </label>
        </div>

        <a
          href="#/Height"
          onClick={handleContinue}
          style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none;`)}
        >
          Continue
        </a>
      </div>
    </>
  );
}
