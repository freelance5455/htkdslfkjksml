import React, { useState } from 'react';
import { DCLogic, useDC, css } from '../dc';
import { registerWithFirebase, loginWithGoogle } from '../../lib/firebaseService';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
`;

class Component extends DCLogic {
  renderVals() {
    return {};
  }
}

export default function Signup({ go }) {
  const vals = useDC(Component);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCreate = async () => {
    if (!email) {
      setError('Please enter your email');
      return;
    }
    if (!password || password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    setError('');

    try {
      await registerWithFirebase(email, password, { displayName: name });
    } catch (err) {
      console.warn('Firebase registration notice:', err);
    }

    setLoading(false);
    try {
      if (name) localStorage.setItem('calsen-name', name);
      if (email) localStorage.setItem('calsen-email', email);
    } catch (e) {}

    go('Paywall');
  };

  const handleGoogle = async () => {
    setLoading(true);
    setError('');
    try {
      await loginWithGoogle();
      go('Paywall');
    } catch (err) {
      console.warn('Google sign up error:', err);
      setError('Google sign-in was canceled or failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Create" onClick={(e) => { e.preventDefault(); go('Create'); }} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 100%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          Your information
        </h1>
        <p style={css(`margin:8px 0 0;font-size:15px;line-height:22px;color:#8c8c96;`)}>
          Fill in your details to create your account.
        </p>

        {error && (
          <div style={css(`margin-top:12px;padding:10px 14px;border-radius:12px;background:rgba(220,38,38,0.2);color:#fca5a5;font-size:13px;`)}>
            {error}
          </div>
        )}

        <div style={css(`flex:1;margin-top:24px;display:flex;flex-direction:column;gap:18px;`)}>
          <label style={css(`display:flex;flex-direction:column;gap:8px;font-size:13px;font-weight:600;color:#9a9aa3;`)}>
            Full name
            <input
              type="text"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={css(`height:56px;box-sizing:border-box;border:1.5px solid #333338;border-radius:16px;background:#202024;padding:0 16px;font-family:inherit;font-size:16px;font-weight:500;color:#ffffff;`)}
            />
          </label>
          <label style={css(`display:flex;flex-direction:column;gap:8px;font-size:13px;font-weight:600;color:#9a9aa3;`)}>
            Email
            <input
              type="email"
              placeholder="you@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={css(`height:56px;box-sizing:border-box;border:1.5px solid #333338;border-radius:16px;background:#202024;padding:0 16px;font-family:inherit;font-size:16px;font-weight:500;color:#ffffff;`)}
            />
          </label>
          <label style={css(`display:flex;flex-direction:column;gap:8px;font-size:13px;font-weight:600;color:#9a9aa3;`)}>
            Password
            <input
              type="password"
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={css(`height:56px;box-sizing:border-box;border:1.5px solid #333338;border-radius:16px;background:#202024;padding:0 16px;font-family:inherit;font-size:16px;font-weight:500;color:#ffffff;`)}
            />
          </label>
        </div>

        <button
          type="button"
          onClick={handleCreate}
          disabled={loading}
          style={css(`margin-top:16px;height:58px;border:0;border-radius:999px;background:#ffffff;color:#2a3045;font-family:inherit;font-size:17px;font-weight:700;cursor:pointer;flex:none;opacity:${loading ? 0.7 : 1};`)}
        >
          {loading ? 'Creating account...' : 'Create account'}
        </button>

        {/* Google sign up option */}
        <button
          type="button"
          onClick={handleGoogle}
          disabled={loading}
          style={css(`margin-top:10px;height:52px;border:1px solid rgba(255,255,255,0.15);border-radius:999px;background:rgba(255,255,255,0.06);color:#ffffff;font-family:inherit;font-size:15px;font-weight:600;cursor:pointer;flex:none;display:flex;align-items:center;justify-content:center;gap:10px;`)}
        >
          <svg style={css(`width:18px;height:18px;flex-shrink:0;`)} viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
          </svg>
          <span>Continue with Google</span>
        </button>
      </div>
    </>
  );
}
