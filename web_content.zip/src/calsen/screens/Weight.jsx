import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,button:focus-visible,[role=slider]:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
input[type=number]{-moz-appearance:textfield}
`;

class Component extends DCLogic {
  renderVals() {
    const PX = 7.4;
    const s = this.state || {};
    const unit = s.unit ?? 'kg';
    const MIN = unit === 'kg' ? 30 : 66, MAX = unit === 'kg' ? 250 : 550;
    const clamp = (n) => Math.min(MAX, Math.max(MIN, n));
    const v = clamp(s.v ?? (unit === 'kg' ? 60 : 132));
    try {
      localStorage.setItem('cs_w', JSON.stringify({ u: unit, v: Math.round(v * 10) / 10 }));
    } catch (e) {}
    const k0 = Math.floor(v);
    const ticks = [];
    for (let k = k0 - 27; k <= k0 + 28; k++) {
      if (k < MIN || k > MAX) continue;
      const major = k % 10 === 0, mid = k % 5 === 0;
      const x = (k - v) * PX;
      ticks.push({
        hasLabel: major,
        label: major ? String(k) : '',
        style: 'position:absolute;bottom:0;left:calc(50% + ' + x.toFixed(1) + 'px);margin-left:-1px;width:2px;border-radius:1px;height:' + (major ? 44 : mid ? 36 : 30) + 'px;background:' + (major ? '#b9b9c0' : '#6b6b73') + ';',
        lbl: 'position:absolute;bottom:calc(100% + 10px);left:50%;transform:translateX(-50%);font-size:14px;font-weight:600;color:#9a9aa3;'
      });
    }
    const setV = (n) => this.setState({ v: clamp(n) });
    const conv = (to) => {
      if (to === unit) return;
      this.setState({ unit: to, v: Math.round((to === 'lb' ? v * 2.20462 : v / 2.20462) * 10) / 10, raw: null });
    };
    const on = 'background:#8c8c8c;color:#ffffff;', off = 'background:transparent;color:#b5b5bd;';
    return {
      unitLabel: unit,
      rmin: MIN,
      rmax: MAX,
      ariaNow: Math.round(v),
      segKg: unit === 'kg' ? on : off,
      segLb: unit === 'lb' ? on : off,
      setKg: () => conv('kg'),
      setLb: () => conv('lb'),
      shown: s.raw ?? String(Math.round(v)),
      ticks,
      onTyped: (e) => {
        const t = e.target.value;
        const n = parseFloat(t);
        this.setState(isNaN(n) ? { raw: t } : { raw: t, v: clamp(n) });
      },
      onBlur: () => this.setState({ raw: null }),
      onDown: (e) => {
        this._d = { x: e.clientX, v };
        if (e.currentTarget.setPointerCapture) e.currentTarget.setPointerCapture(e.pointerId);
        this.setState({ raw: null });
      },
      onMove: (e) => {
        if (!this._d) return;
        setV(this._d.v - (e.clientX - this._d.x) / PX);
      },
      onUp: () => {
        if (!this._d) return;
        this._d = null;
        setV(Math.round((this.state || {}).v ?? v));
      },
      onKey: (e) => {
        if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
          setV(Math.round(v) + 1);
          e.preventDefault();
        }
        if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
          setV(Math.round(v) - 1);
          e.preventDefault();
        }
      }
    };
  }
}

export default function Weight({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('Height');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    let savedVal = 60;
    let savedUnit = 'kg';
    try {
      const raw = localStorage.getItem('cs_w');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.v) savedVal = parsed.v;
        if (parsed.u) savedUnit = parsed.u;
      }
    } catch (err) {}
    if (go) go('Birth');
    else if (onNext) onNext({ weight: savedVal, weightUnit: savedUnit });
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a
            href="#/Height"
            onClick={handleBack}
            aria-label="Back"
            style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 40%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
          <span style={css(`font-size: 15px; font-weight: 500; color: #8c8c96;`)}>
            4/10
          </span>
        </div>

        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          What's your weight?
        </h1>
        <p style={css(`margin: 8px 0 0; max-width: 260px; font-size: 15px; line-height: 22px; color: #8c8c96;`)}>
          This will help us give you better health insights.
        </p>

        <div style={css(`flex:1;display:flex;flex-direction:column;min-height:0;`)}>
          <div style={css(`align-self:center;display:flex;padding:4px;border-radius:999px;background:#3a3a3a;margin-top:24px;`)}>
            <button type="button" aria-label="KG" onClick={vals.setKg} style={css(`padding:0 22px;height:36px;border:0;border-radius:999px;font-family:inherit;font-size:13px;font-weight:700;letter-spacing:0.5px;cursor:pointer;${vals.segKg}`)}>
              KG
            </button>
            <button type="button" aria-label="LB" onClick={vals.setLb} style={css(`padding:0 22px;height:36px;border:0;border-radius:999px;font-family:inherit;font-size:13px;font-weight:700;letter-spacing:0.5px;cursor:pointer;${vals.segLb}`)}>
              LB
            </button>
          </div>

          <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;gap:40px;`)}>
            <div style={css(`display:flex;align-items:baseline;justify-content:center;gap:8px;`)}>
              <input
                type="number"
                inputMode="decimal"
                step="0.1"
                aria-label="Weight, tap to type"
                value={vals.shown}
                onChange={vals.onTyped}
                onBlur={vals.onBlur}
                style={css(`width:120px;height:72px;font-size:58px;letter-spacing:-1px;box-sizing:border-box;border:0;border-bottom:2px solid #5a5a62;background:transparent;color:#ffffff;font-family:inherit;font-weight:700;text-align:center;padding:0;border-radius:0;`)}
              />
              <span style={css(`font-size:18px;font-weight:500;color:#8c8c96;`)}>
                {vals.unitLabel}
              </span>
            </div>

            <div>
              <div
                role="slider"
                tabIndex={0}
                aria-label="Weight, slide to adjust"
                aria-valuemin={vals.rmin}
                aria-valuemax={vals.rmax}
                aria-valuenow={vals.ariaNow}
                onPointerDown={vals.onDown}
                onPointerMove={vals.onMove}
                onPointerUp={vals.onUp}
                onPointerCancel={vals.onUp}
                onKeyDown={vals.onKey}
                style={css(`position:relative;height:100px;touch-action:none;cursor:ew-resize;`)}
              >
                <div style={css(`position:absolute;inset:0;-webkit-mask-image:linear-gradient(to right,transparent,#000 12%,#000 88%,transparent);mask-image:linear-gradient(to right,transparent,#000 12%,#000 88%,transparent);`)}>
                  {vals.ticks.map((t, i) => (
                    <React.Fragment key={i}>
                      <div style={css(`${t.style}`)}>
                        {t.hasLabel && (
                          <span style={css(`${t.lbl}`)}>
                            {t.label}
                          </span>
                        )}
                      </div>
                    </React.Fragment>
                  ))}
                </div>
                <div style={css(`position:absolute;left:50%;bottom:0;width:3px;height:54px;margin-left:-1.5px;border-radius:2px;background:#ffffff;`)}></div>
              </div>

              <div style={css(`margin-top:14px;display:flex;flex-direction:column;align-items:center;gap:6px;font-size:12px;color:#9a9aa3;`)}>
                <svg width="10" height="8" viewBox="0 0 10 8" aria-hidden="true">
                  <path d="M5 0l5 7H0z" fill="#cfcfd6" />
                </svg>
                Slide to adjust
              </div>
            </div>
          </div>
        </div>

        <a
          href="#/Birth"
          onClick={handleContinue}
          style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center;`)}
        >
          Continue
        </a>
      </div>
    </>
  );
}
