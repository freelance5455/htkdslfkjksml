import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,button:focus-visible,[role=slider]:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
input[type=number]{-moz-appearance:textfield}
`;

class Component extends DCLogic {
renderVals() {
const PX = 7.4, MIN = 100, MAX = 230;
const s = this.state || {};
const unit = s.unit ?? 'cm';
const clamp = (n) => Math.min(MAX, Math.max(MIN, n));
const cm = clamp(s.cm ?? 170);
const step = unit === 'cm' ? 1 : 2.54;
const pos = cm / step;
const k0 = Math.floor(pos);
const ticks = [];
for (let k = k0 - 27; k <= k0 + 27; k++) {
const v = k * step;
if (v < MIN - 0.01 || v > MAX + 0.01) continue;
const major = unit === 'cm' ? k % 10 === 0 : k % 12 === 0;
const mid = unit === 'cm' ? k % 5 === 0 : k % 6 === 0;
const y = (pos - k) * PX;
ticks.push({
hasLabel: major,
label: major ? (unit === 'cm' ? String(k) : (k / 12) + "'") : '',
style: 'position:absolute;right:0;top:calc(50% + ' + y.toFixed(1) + 'px);margin-top:-1px;height:2px;border-radius:1px;width:' + (major ? 46 : mid ? 38 : 30) + 'px;background:' + (major ? '#b9b9c0' : '#6b6b73') + ';',
lbl: 'position:absolute;right:calc(100% + 8px);top:50%;transform:translateY(-50%);font-size:14px;font-weight:600;color:#9a9aa3;'
});
}
const totalIn = Math.round(cm / 2.54);
const setCm = (n) => this.setState({ cm: clamp(n) });
const unitStyleOn = 'background:#8c8c8c;color:#ffffff;', unitStyleOff = 'background:transparent;color:#b5b5bd;';
return {
isCm: unit === 'cm', isFt: unit === 'ft',
segCm: unit === 'cm' ? unitStyleOn : unitStyleOff, segFt: unit === 'ft' ? unitStyleOn : unitStyleOff,
setCm: () => this.setState({ unit: 'cm' }), setFt: () => this.setState({ unit: 'ft' }),
cmShown: s.raw ?? String(Math.round(cm)),
ftShown: s.rawFt ?? String(Math.floor(totalIn / 12)),
inShown: s.rawIn ?? String(totalIn % 12),
ariaNow: Math.round(cm), ticks,
onCm: (e) => { const t = e.target.value; const n = parseFloat(t); this.setState(isNaN(n) ? { raw: t } : { raw: t, cm: clamp(n) }); },
onFt: (e) => { const t = e.target.value; const f = parseFloat(t); if (isNaN(f)) { this.setState({ rawFt: t }); return; } const i = parseFloat(s.rawIn ?? String(totalIn % 12)) || 0; this.setState({ rawFt: t, cm: clamp((f * 12 + i) * 2.54) }); },
onIn: (e) => { const t = e.target.value; const i = parseFloat(t); if (isNaN(i)) { this.setState({ rawIn: t }); return; } const f = parseFloat(s.rawFt ?? String(Math.floor(totalIn / 12))) || 0; this.setState({ rawIn: t, cm: clamp((f * 12 + i) * 2.54) }); },
onBlur: () => this.setState({ raw: null, rawFt: null, rawIn: null }),
onDown: (e) => { this._d = { y: e.clientY, v: cm }; if (e.currentTarget.setPointerCapture) e.currentTarget.setPointerCapture(e.pointerId); this.setState({ raw: null, rawFt: null, rawIn: null }); },
onMove: (e) => { if (!this._d) return; setCm(this._d.v + ((e.clientY - this._d.y) / PX) * step); },
onUp: () => { if (!this._d) return; this._d = null; setCm(Math.round(((this.state || {}).cm ?? cm) / step) * step); },
onKey: (e) => { if (e.key === 'ArrowUp' || e.key === 'ArrowRight') { setCm(cm + step); e.preventDefault(); } if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') { setCm(cm - step); e.preventDefault(); } }
};
}
}

export default function Height({ go }) {
  const vals = useDC(Component);
  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Workouts" onClick={(e) => { e.preventDefault(); go('Workouts'); }} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 30%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
          <span style={css(`font-size: 15px; font-weight: 500; color: #8c8c96;`)}>
            3/10
          </span>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          What's your height?
        </h1>
        <p style={css(`margin: 8px 0 0; max-width: 260px; font-size: 15px; line-height: 22px; color: #8c8c96;`)}>
          This will help us give you better health insights.
        </p>
        <div style={css(`flex:1;display:flex;flex-direction:column;min-height:0;`)}>
          <div style={css(`align-self:center;display:flex;padding:4px;border-radius:999px;background:#3a3a3a;margin-top:24px;`)}>
            <button type="button" aria-label="CM" onClick={vals.setCm} style={css(`padding:0 22px;height:36px;border:0;border-radius:999px;font-family:inherit;font-size:13px;font-weight:700;letter-spacing:0.5px;cursor:pointer;${vals.segCm}`)}>
              CM
            </button>
            <button type="button" aria-label="FT" onClick={vals.setFt} style={css(`padding:0 22px;height:36px;border:0;border-radius:999px;font-family:inherit;font-size:13px;font-weight:700;letter-spacing:0.5px;cursor:pointer;${vals.segFt}`)}>
              FT
            </button>
          </div>
          <div style={css(`position:relative;flex:1;margin-top:16px;min-height:0;`)}>
            <div style={css(`position:absolute;left:0;top:50%;transform:translateY(-50%);width:134px;`)}>
              {vals.isCm && (
                <>
                  <div style={css(`display:flex;align-items:baseline;gap:6px;`)}>
                    <input type="number" inputMode="numeric" aria-label="Height in centimeters, tap to type" value={vals.cmShown} onChange={vals.onCm} onBlur={vals.onBlur} style={css(`width:92px;height:64px;font-size:50px;letter-spacing:-1px;box-sizing:border-box;border:0;border-bottom:2px solid #5a5a62;background:transparent;color:#ffffff;font-family:inherit;font-weight:700;text-align:center;padding:0;border-radius:0;`)} />
                    <span style={css(`font-size:18px;font-weight:500;color:#8c8c96;`)}>
                      cm
                    </span>
                  </div>
                </>
              )}
              {vals.isFt && (
                <>
                  <div style={css(`display:flex;align-items:baseline;gap:4px;`)}>
                    <input type="number" inputMode="numeric" aria-label="Feet, tap to type" value={vals.ftShown} onChange={vals.onFt} onBlur={vals.onBlur} style={css(`width:40px;height:56px;font-size:40px;box-sizing:border-box;border:0;border-bottom:2px solid #5a5a62;background:transparent;color:#ffffff;font-family:inherit;font-weight:700;text-align:center;padding:0;border-radius:0;`)} />
                    <span style={css(`font-size:18px;font-weight:500;color:#8c8c96;font-size:15px;`)}>
                      ft
                    </span>
                    <input type="number" inputMode="numeric" aria-label="Inches, tap to type" value={vals.inShown} onChange={vals.onIn} onBlur={vals.onBlur} style={css(`width:48px;height:56px;font-size:40px;box-sizing:border-box;border:0;border-bottom:2px solid #5a5a62;background:transparent;color:#ffffff;font-family:inherit;font-weight:700;text-align:center;padding:0;border-radius:0;`)} />
                    <span style={css(`font-size:18px;font-weight:500;color:#8c8c96;font-size:15px;`)}>
                      in
                    </span>
                  </div>
                </>
              )}
            </div>
            <div role="slider" tabIndex="0" aria-label="Height, slide to adjust" aria-valuemin="100" aria-valuemax="230" aria-valuenow={vals.ariaNow} onPointerDown={vals.onDown} onPointerMove={vals.onMove} onPointerUp={vals.onUp} onPointerCancel={vals.onUp} onKeyDown={vals.onKey} style={css(`position:absolute;left:140px;right:0;top:0;bottom:0;touch-action:none;cursor:ns-resize;`)}>
              <div style={css(`position:absolute;left:0;top:0;bottom:0;width:80px;-webkit-mask-image:linear-gradient(transparent,#000 14%,#000 86%,transparent);mask-image:linear-gradient(transparent,#000 14%,#000 86%,transparent);`)}>
                {vals.ticks.map((t, i) => (
                  <React.Fragment key={i}>
                    <div style={css(`${t.style}`)}>
                      {t.hasLabel && (
                        <>
                          <span style={css(`${t.lbl}`)}>
                            {t.label}
                          </span>
                        </>
                      )}
                    </div>
                  </React.Fragment>
                ))}
              </div>
              <div style={css(`position:absolute;left:28px;width:52px;top:50%;height:3px;margin-top:-1.5px;border-radius:2px;background:#ffffff;`)}></div>
              <div style={css(`position:absolute;left:92px;top:50%;transform:translateY(-50%);display:flex;align-items:center;gap:6px;font-size:12px;color:#9a9aa3;white-space:nowrap;`)}>
                <svg width="8" height="10" viewBox="0 0 8 10" aria-hidden="true">
                  <path d="M7 0L0 5l7 5z" fill="#cfcfd6" />
                </svg>
                Slide to adjust
              </div>
            </div>
          </div>
        </div>
        <a href="#/Weight" onClick={(e) => { e.preventDefault(); go('Weight'); }} style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center;`)}>
          Continue
        </a>
      </div>
    </>
  );
}
