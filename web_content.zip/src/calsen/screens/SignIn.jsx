import React, { useState } from 'react';
import bananaImg from '../../assets/calsen-banana.png';
import { loginWithFirebase, loginWithGoogle } from '../../lib/firebaseService';
import { t, getCurrentLang } from '../../lib/i18n';

export default function SignInScreen({ go, onNavigate, onComplete, onSignUp, onBack }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  // Synchronize theme with the rest of the application
  const [dark, setDark] = useState(() => {
    try {
      const v = localStorage.getItem('plateful-theme');
      if (v === 'dark') return true;
      if (v === 'light') return false;
      if (v === 'auto') return window.matchMedia?.('(prefers-color-scheme: dark)').matches || false;
    } catch (e) {}
    return false; // Default to Light mode
  });

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    try {
      localStorage.setItem('plateful-theme', next ? 'dark' : 'light');
    } catch (e) {}
  };

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    if (!email) {
      setError('Please enter your email address');
      return;
    }
    if (!password || password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    setError('');

    try {
      await loginWithFirebase(email, password);
    } catch (fbErr) {
      console.warn('Firebase login notice:', fbErr);
    }

    setLoading(false);
    try {
      localStorage.setItem('calsen-email', email);
      const namePart = email.split('@')[0];
      const currentName = localStorage.getItem('calsen-name');
      if (!currentName || currentName === 'Your name') {
        localStorage.setItem('calsen-name', namePart.charAt(0).toUpperCase() + namePart.slice(1));
      }
    } catch (err) {}

    if (onComplete) onComplete({ email });
    else if (go) go('Sex');
    else if (onNavigate) onNavigate('home');
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    setError('');
    try {
      const user = await loginWithGoogle();
      if (onComplete) onComplete({ email: user.email });
      else if (go) go('Sex');
      else if (onNavigate) onNavigate('home');
    } catch (gErr) {
      console.warn('Google sign-in:', gErr);
      if (gErr?.code === 'auth/popup-blocked') {
        setError('Popup was blocked by the browser. Please allow popups or use email.');
      } else if (gErr?.code === 'auth/cancelled-popup-request') {
        // user closed popup
      } else {
        setError(gErr?.message || 'Google sign-in failed. Please try again.');
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  const isAr = getCurrentLang() === 'العربية';

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className={`app flex flex-col justify-between min-h-screen p-6 relative overflow-hidden transition-colors duration-300 ${
        dark ? 'bg-[#0A0506] text-white' : 'bg-[#FBF3EC] text-[#1A1517]'
      }`}
      data-theme={dark ? 'dark' : 'light'}
    >
      {/* Decorative Glow */}
      <div
        className={`absolute -top-28 -right-28 w-72 h-72 rounded-full blur-3xl pointer-events-none transition-opacity duration-300 ${
          dark ? 'bg-[#FF5C00]/15' : 'bg-[#FF5C00]/10'
        }`}
      />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between pt-2">
        <button
          type="button"
          onClick={() => (go ? go('Welcome') : onBack ? onBack() : onNavigate?.('welcome'))}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
            dark
              ? 'bg-white/5 border border-white/10 text-white/80 hover:text-white'
              : 'bg-white border border-[#F0E4D9] text-[#1A1517] shadow-sm hover:bg-[#FAF2EB]'
          }`}
          aria-label="Back"
        >
          <svg className={`w-5 h-5 ${isAr ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
        </button>

        <div className="flex items-center gap-2">
          <img src={bananaImg} alt="logo" className="w-6 h-6 object-contain" />
          <span className={`font-extrabold text-sm tracking-wider ${dark ? 'text-white/90' : 'text-[#1A1517]'}`}>
            CALSEN
          </span>
        </div>

        {/* Theme Toggle Button */}
        <button
          type="button"
          onClick={toggleTheme}
          aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
            dark
              ? 'bg-white/5 border border-white/10 text-white/80 hover:text-white'
              : 'bg-white border border-[#F0E4D9] text-[#1A1517] shadow-sm hover:bg-[#FAF2EB]'
          }`}
        >
          {dark ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="4" />
              <path strokeLinecap="round" d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
            </svg>
          )}
        </button>
      </div>

      {/* Main Form */}
      <div className="relative z-10 my-auto py-6 max-w-sm w-full mx-auto">
        <div className="text-center mb-6">
          <h1 className={`text-2xl sm:text-3xl font-extrabold tracking-tight mb-2 ${dark ? 'text-white' : 'text-[#1A1517]'}`}>
            {isAr ? 'مرحباً بعودتك' : 'Welcome back'}
          </h1>
          <p className={`text-xs sm:text-sm ${dark ? 'text-white/60' : 'text-[#8F8985]'}`}>
            {isAr ? 'سجّل دخولك لمزامنة وجباتك وسعراتك وأهدافك.' : 'Sign in to sync your meals, macros, and streak.'}
          </p>
        </div>

        {error && (
          <div
            className={`mb-4 p-3 rounded-xl text-xs text-center border ${
              dark
                ? 'bg-red-500/15 border-red-500/30 text-red-300'
                : 'bg-red-50 border-red-200 text-red-700'
            }`}
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className={`block text-xs font-semibold mb-1.5 mx-1 ${dark ? 'text-white/70' : 'text-[#5A524D]'}`}>
              {t('auth.email', 'Email Address')}
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className={`w-full px-4 py-3.5 rounded-2xl transition-all focus:outline-none text-sm ${
                dark
                  ? 'bg-[#140E10] border border-white/10 text-white placeholder:text-white/30 focus:border-[#FF5C00]'
                  : 'bg-white border border-[#F0E4D9] text-[#1A1517] placeholder:text-[#9A806C] shadow-sm focus:border-[#FF5C00] focus:ring-2 focus:ring-[#FF5C00]/20'
              }`}
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5 mx-1">
              <label className={`text-xs font-semibold ${dark ? 'text-white/70' : 'text-[#5A524D]'}`}>
                {t('auth.password', 'Password')}
              </label>
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="text-[11px] text-[#FF5C00] font-bold hover:underline cursor-pointer"
              >
                {showPass ? (isAr ? 'إخفاء' : 'Hide') : (isAr ? 'إظهار' : 'Show')}
              </button>
            </div>
            <input
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className={`w-full px-4 py-3.5 rounded-2xl transition-all focus:outline-none text-sm ${
                dark
                  ? 'bg-[#140E10] border border-white/10 text-white placeholder:text-white/30 focus:border-[#FF5C00]'
                  : 'bg-white border border-[#F0E4D9] text-[#1A1517] placeholder:text-[#9A806C] shadow-sm focus:border-[#FF5C00] focus:ring-2 focus:ring-[#FF5C00]/20'
              }`}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-4 rounded-2xl bg-[#FF5C00] hover:bg-[#FF6D1A] text-black font-extrabold text-sm tracking-wide shadow-[0_6px_20px_rgba(255,92,0,0.35)] transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : (
              t('auth.signin', 'Sign In')
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-3 my-5">
          <div className={`flex-1 h-px ${dark ? 'bg-white/10' : 'bg-[#E5DCD4]'}`} />
          <span className={`text-[10px] font-bold tracking-wider uppercase ${dark ? 'text-white/40' : 'text-[#9A8F87]'}`}>
            {t('auth.or_continue_with', 'or continue with')}
          </span>
          <div className={`flex-1 h-px ${dark ? 'bg-white/10' : 'bg-[#E5DCD4]'}`} />
        </div>

        {/* Google Sign In Button */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={googleLoading}
          className={`w-full py-3.5 px-4 rounded-2xl font-bold text-sm transition-all cursor-pointer flex items-center justify-center gap-3 ${
            dark
              ? 'bg-white/5 border border-white/10 text-white hover:bg-white/10'
              : 'bg-white border border-[#F0E4D9] text-[#1A1517] shadow-sm hover:bg-[#FAF2EB]'
          }`}
        >
          {googleLoading ? (
            <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{t('auth.continue_google', 'Continue with Google')}</span>
            </>
          )}
        </button>
      </div>

      {/* Footer */}
      <div className="relative z-10 text-center pb-2">
        <p className={`text-xs ${dark ? 'text-white/60' : 'text-[#8F8985]'}`}>
          {t('auth.no_account', "Don't have an account?")}{' '}
          <button
            onClick={() => (go ? go('Signup') : onSignUp ? onSignUp() : onNavigate?.('signup'))}
            className="text-[#FF5C00] font-bold hover:underline cursor-pointer mx-1"
          >
            {t('auth.signup', 'Sign up')}
          </button>
        </p>
      </div>
    </div>
  );
}
