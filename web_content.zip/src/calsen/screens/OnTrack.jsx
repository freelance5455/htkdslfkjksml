import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
input::placeholder{color:#7d7d85}
select option{background:#202024;color:#ffffff}
`;

class Component extends DCLogic {
renderVals() {
const rd = (k, d) => { try { const o = JSON.parse(localStorage.getItem(k)); return o && typeof o.v === 'number' ? o : d; } catch (e) { return d; } };
const cvt = (o, u) => o.u === u ? o.v : (u === 'lb' ? o.v * 2.20462 : o.v / 2.20462);
const r1 = (n) => (Math.round(n * 10) / 10).toFixed(1);
const g = rd('cs_g', { u: 'kg', v: 65 });
const w0 = rd('cs_w', { u: 'kg', v: 60 });
const u = g.u;
const sv = cvt(w0, u), ev = g.v;
const gain = ev > sv;
return {
tf: gain ? 'translate(0 146) scale(1 -1)' : '',
sy: gain ? 114 : 32, ey: gain ? 24 : 122,
sLy: gain ? 130 : 20, eLy: gain ? 12 : 140,
startTxt: Math.round(sv) + ' ' + u, endTxt: Math.round(ev) + ' ' + u,
unitNote: 'Weight shown in ' + u
};
}
}

export default function OnTrack({ go }) {
  const vals = useDC(Component);
  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Speed" onClick={(e) => { e.preventDefault(); go('Speed'); }} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 72%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          Designed to help you stay on track
        </h1>
        <p style={css(`margin:8px 0 0;font-size:15px;line-height:22px;color:#8c8c96;`)}></p>
        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;`)}>
          <div style={css(`background:#202024;border:1px solid #333338;border-radius:28px;padding:24px 20px;`)}>
            <div style={css(`display:flex;justify-content:space-between;align-items:baseline;`)}>
              <span style={css(`font-size:22px;font-weight:700;`)}>
                Your weight
              </span>
              <span style={css(`font-size:13px;color:#9a9aa3;`)}>
                {vals.unitNote}
              </span>
            </div>
            <svg viewBox="0 0 300 150" width="100%" role="img" aria-label="CalSen moves steadily toward your goal while a traditional diet bounces back" style={css(`margin-top:12px;display:block;`)}>
              <defs>
                <linearGradient id="ot" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" stopColor="#FF8A1F" stopOpacity="0.28" />
                  <stop offset="1" stopColor="#FF8A1F" stopOpacity="0" />
                </linearGradient>
              </defs>
              <line x1="10" y1="30" x2="290" y2="30" stroke="#3a3a40" strokeDasharray="3 4" />
              <line x1="10" y1="76" x2="290" y2="76" stroke="#3a3a40" strokeDasharray="3 4" />
              <line x1="10" y1="124" x2="290" y2="124" stroke="#55555c" />
              <g transform={vals.tf}>
                <path d="M10 32C90 30 130 50 175 84S245 122 290 122V124H10Z" fill="url(#ot)" />
                <path d="M10 32C90 30 130 50 175 84S245 122 290 122" stroke="#FF8A1F" strokeWidth="3.5" fill="none" strokeLinecap="round" />
                <path d="M10 34C60 38 100 76 128 100C150 114 172 96 195 72S250 26 290 24" stroke="#e0645f" strokeWidth="2.5" strokeDasharray="6 5" fill="none" strokeLinecap="round" />
              </g>
              <circle cx="10" cy={vals.sy} r="6" fill="#202024" stroke="#fff" strokeWidth="3" />
              <circle cx="290" cy={vals.ey} r="6" fill="#202024" stroke="#fff" strokeWidth="3" />
              <text x="10" y={vals.sLy} fontSize="13" fontWeight="700" fill="#ffffff" fontFamily="inherit">
                {vals.startTxt}
              </text>
              <text x="290" y={vals.eLy} textAnchor="end" fontSize="13" fontWeight="700" fill="#FF8A1F" fontFamily="inherit">
                {vals.endTxt}
              </text>
            </svg>
            <div style={css(`display:flex;justify-content:space-between;font-size:14px;font-weight:600;margin-top:8px;`)}>
              <span>
                Month 1
              </span>
              <span>
                Month 6
              </span>
            </div>
            <div style={css(`display:flex;gap:18px;margin-top:14px;font-size:13px;color:#c9c9d0;`)}>
              <span style={css(`display:flex;align-items:center;gap:6px;`)}>
                <span style={css(`width:18px;height:3px;border-radius:2px;background:#FF8A1F;`)}></span>
                With CalSen
              </span>
              <span style={css(`display:flex;align-items:center;gap:6px;`)}>
                <span style={css(`width:18px;height:3px;border-radius:2px;background:#e0645f;`)}></span>
                Traditional diet
              </span>
            </div>
            <p style={css(`margin:20px 0 0;text-align:center;font-size:17px;line-height:25px;color:#c9c9d0;`)}>
              Most CalSen users keep their progress going well past month 6
            </p>
          </div>
        </div>
        <a href="#/Twice" onClick={(e) => { e.preventDefault(); go('Twice'); }} style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none;`)}>
          Continue
        </a>
      </div>
    </>
  );
}
