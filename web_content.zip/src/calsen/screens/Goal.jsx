import React from 'react';
import { DCLogic, useDC, css } from '../dc';

const STYLE = `
body{margin:0}
a:focus-visible,input:focus-visible,button:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
label.opt{border:1.5px solid #333338 !important}
label.opt:has(input:checked){border:2px solid #ffffff !important}
::-webkit-scrollbar{display:none}
input.rd{order:-1;-webkit-appearance:none;appearance:none;width:24px;height:24px;margin:0;flex:none;border-radius:50%;border:2px solid #5a5a62;background:transparent;cursor:pointer}
input.rd:checked{border-color:#ffffff;background:radial-gradient(circle,#ffffff 0 5px,transparent 6px)}
`;

class Component extends DCLogic {
  renderVals() {
    const s = this.state || {};
    const goal = s.goal ?? (localStorage.getItem('calsen-goal') || 'lose');
    try {
      localStorage.setItem('calsen-goal', goal);
      localStorage.setItem('cs_goal', goal);
    } catch (e) {}

    return {
      goal,
      setGoal: (g) => this.setState({ goal: g })
    };
  }
}

export default function Goal({ go, onNext, onBack }) {
  const vals = useDC(Component);

  const handleBack = (e) => {
    if (e) e.preventDefault();
    if (go) go('Birth');
    else if (onBack) onBack();
  };

  const handleContinue = (e) => {
    if (e) e.preventDefault();
    try {
      localStorage.setItem('calsen-goal', vals.goal);
      localStorage.setItem('cs_goal', vals.goal);
    } catch (err) {}
    if (onNext) onNext({ goal: vals.goal });
    if (go) go('GoalWeight');
  };

  return (
    <>
      <style>{STYLE}</style>
      <div style={css(`position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 28px 44px; display: flex; flex-direction: column;`)}>
        <div style={css(`display: flex; align-items: center; gap: 14px;`)}>
          <a href="#/Birth" onClick={handleBack} aria-label="Back" style={css(`width: 44px; height: 44px; border-radius: 50%; background: #3a3a3a; display: flex; align-items: center; justify-content: center; flex: none; text-decoration: none;`)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 6l-6 6l6 6" />
            </svg>
          </a>
          <div style={css(`flex: 1; height: 4px; border-radius: 2px; background: #3a3a3a;`)}>
            <div style={css(`width: 54%; height: 4px; border-radius: 2px; background: #ffffff;`)}></div>
          </div>
        </div>
        <h1 style={css(`margin: 36px 0 0; font-size: 30px; line-height: 36px; font-weight: 700; letter-spacing: -0.6px;`)}>
          What is your goal?
        </h1>
        <p style={css(`margin:8px 0 0;font-size:15px;line-height:22px;color:#8c8c96;`)}>
          This helps us generate a plan for your calorie intake.
        </p>
        <div style={css(`flex:1;display:flex;flex-direction:column;justify-content:center;gap:12px;`)}>
          <label onClick={() => vals.setGoal('lose')} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.goal === 'lose' ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 5v14M6 13l6 6l6-6" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Lose Weight
            </span>
            <input type="radio" name="g" checked={vals.goal === 'lose'} onChange={() => vals.setGoal('lose')} aria-label="Lose Weight" className="rd" />
          </label>
          <label onClick={() => vals.setGoal('maintain')} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.goal === 'maintain' ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 12h14" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Maintain
            </span>
            <input type="radio" name="g" checked={vals.goal === 'maintain'} onChange={() => vals.setGoal('maintain')} aria-label="Maintain" className="rd" />
          </label>
          <label onClick={() => vals.setGoal('gain')} className="opt" style={css(`display:flex;align-items:center;gap:14px;min-height:68px;box-sizing:border-box;padding:12px 18px 12px 14px;border-radius:20px;background:#202024;cursor:pointer;${vals.goal === 'gain' ? 'border:2px solid #ffffff !important;' : ''}`)}>
            <span style={css(`width:44px;height:44px;border-radius:50%;background:rgba(255,138,31,0.14);display:flex;align-items:center;justify-content:center;flex:none;`)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#FFB23A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 19V5M6 11l6-6l6 6" />
              </svg>
            </span>
            <span style={css(`flex:1;font-size:17px;font-weight:600;`)}>
              Gain Weight
            </span>
            <input type="radio" name="g" checked={vals.goal === 'gain'} onChange={() => vals.setGoal('gain')} aria-label="Gain Weight" className="rd" />
          </label>
        </div>
        <a href="#/GoalWeight" onClick={handleContinue} style={css(`margin: 16px 6px 0; height: 58px; border-radius: 999px; background: #ffffff; color: #2a3045; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; flex: none; cursor: pointer;`)}>
          Continue
        </a>
      </div>
    </>
  );
}
