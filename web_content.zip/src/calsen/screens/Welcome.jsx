import React, { useState } from 'react';
import { DCLogic, useDC, css } from '../dc';
import { loginWithGoogle } from '../../lib/firebaseService';
import { getCurrentLang, setLanguage } from '../../lib/i18n';

const STYLE = `
body{margin:0}
button:focus-visible,a:focus-visible{outline:2px solid #ffffff;outline-offset:3px}
a{color:#ffffff}
@keyframes cs-fade{0%{opacity:0}6%{opacity:1}30%{opacity:1}36%{opacity:0}100%{opacity:0}}
@keyframes cs-tilt{0%,100%{transform:rotate(-7deg) translateY(0)}50%{transform:rotate(-2deg) translateY(-10px)}}
@keyframes cs-spin{to{transform:rotate(360deg)}}
.cs-screen{opacity:0;animation:cs-fade 9s infinite}
.cs-phone{animation:cs-tilt 6s ease-in-out infinite}
@media (prefers-reduced-motion: reduce){.cs-phone{animation:none}}
`;

class Component extends DCLogic {
  renderVals() {
    const s = this.state || {};
    const curLang = getCurrentLang();
    const defaultK = curLang === 'العربية' ? 'ar' : curLang === 'Français' ? 'fr' : curLang === 'Español' ? 'es' : 'en';
    const k = s.lang ?? defaultK;
    const L = {
      en: { dir: 'ltr', head: 'Calorie tracking made easy', cta: 'Get Started', have: 'Already have an account?', signin: 'Sign in', google: 'Continue with Google' },
      ar: { dir: 'rtl', head: 'تتبّع السعرات بسهولة وبذكاء', cta: 'ابدأ الآن', have: 'لديك حساب بالفعل؟', signin: 'تسجيل الدخول', google: 'المتابعة باستخدام Google' },
      es: { dir: 'ltr', head: 'Cuenta tus calorías sin esfuerzo', cta: 'Empezar', have: '¿Ya tienes una cuenta?', signin: 'Iniciar sesión', google: 'Continuar con Google' },
      fr: { dir: 'ltr', head: 'Le suivi des calories, simplifié', cta: 'Commencer', have: 'Vous avez déjà un compte ?', signin: 'Se connecter', google: 'Continuer avec Google' }
    };
    const t = L[k] || L.en;
    const on = 'background:rgba(255,138,31,0.16);color:#FFB23A;';
    const pick = (l) => () => {
      const map = { ar: 'العربية', en: 'English', fr: 'Français', es: 'Español' };
      setLanguage(map[l] || 'English');
      this.setState({ lang: l, open: false });
    };
    return {
      code: k.toUpperCase(),
      open: !!s.open,
      dir: t.dir,
      head: t.head,
      cta: t.cta,
      have: t.have,
      signin: t.signin,
      google: t.google,
      toggle: () => this.setState({ open: !s.open }),
      pickEn: pick('en'),
      pickAr: pick('ar'),
      pickEs: pick('es'),
      pickFr: pick('fr'),
      aEn: k === 'en' ? on : '',
      aAr: k === 'ar' ? on : '',
      aEs: k === 'es' ? on : '',
      aFr: k === 'fr' ? on : ''
    };
  }
}

export default function Welcome({ go, onStartOnboarding, onSignIn, onSkip, onGoogleComplete }) {
  const vals = useDC(Component);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [googleError, setGoogleError] = useState('');

  const handleStart = () => {
    if (go) go('Sex');
    else if (onStartOnboarding) onStartOnboarding();
  };

  const handleSignIn = (e) => {
    if (e) e.preventDefault();
    if (go) go('SignIn');
    else if (onSignIn) onSignIn();
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    setGoogleError('');
    try {
      const user = await loginWithGoogle();
      if (onGoogleComplete) {
        onGoogleComplete(user);
      } else if (onSkip) {
        onSkip();
      } else if (go) {
        go('Sex');
      }
    } catch (err) {
      console.warn('Google sign-in error:', err);
      if (err?.code === 'auth/popup-blocked') {
        setGoogleError('Popup was blocked by the browser. Please allow popups.');
      } else if (err?.code !== 'auth/cancelled-popup-request') {
        setGoogleError(err?.message || 'Google sign-in failed. Please try again.');
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <>
      <style>{STYLE}</style>
      <div
        dir={vals.dir}
        style={css(
          `position: relative; width: 100%; max-width: 390px; height: 100dvh; min-height: 700px; margin: 0 auto; box-sizing: border-box; overflow: hidden; background: radial-gradient(circle at 50% 35%, #232323, #171717 75%); font-family: 'Plus Jakarta Sans', system-ui, sans-serif; color: #ffffff; padding: 56px 20px 44px; display: flex; flex-direction: column; justify-content: space-between;`
        )}
      >
        {/* Language selector & Skip button */}
        <div style={css(`position: relative; display: flex; justify-content: space-between; align-items: center; z-index: 20;`)}>
          {onSkip ? (
            <button
              type="button"
              onClick={onSkip}
              style={css(
                `height: 36px; padding: 0 14px; border: 0; border-radius: 999px; background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.7); font-family: inherit; font-size: 12px; font-weight: 600; cursor: pointer;`
              )}
            >
              Skip →
            </button>
          ) : (
            <div />
          )}

          <div style={css(`position: relative;`)}>
            <button
              type="button"
              aria-label="Change language"
              aria-haspopup="true"
              onClick={vals.toggle}
              style={css(
                `height: 44px; padding: 0 16px; border: 0; border-radius: 999px; background: rgba(255,255,255,0.08); color: #ffffff; font-family: inherit; font-size: 13px; font-weight: 700; display: flex; align-items: center; gap: 8px; cursor: pointer;`
              )}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="12" cy="12" r="9" />
                <path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" />
              </svg>
              {vals.code}
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#b5b5bd" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M6 9l6 6l6-6" />
              </svg>
            </button>
            {vals.open && (
              <div
                role="menu"
                style={css(
                  `position:absolute;right:0;top:52px;z-index:30;min-width:176px;background:#26262b;border:1px solid #3a3a40;border-radius:18px;padding:6px;box-shadow:0 12px 30px rgba(0,0,0,0.5);display:flex;flex-direction:column;`
                )}
              >
                <button
                  type="button"
                  role="menuitem"
                  onClick={vals.pickEn}
                  style={css(
                    `height:44px;padding:0 14px;border:0;border-radius:12px;background:transparent;color:#ffffff;font-family:inherit;font-size:15px;font-weight:600;text-align:start;cursor:pointer;${vals.aEn}`
                  )}
                >
                  English
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={vals.pickAr}
                  style={css(
                    `height:44px;padding:0 14px;border:0;border-radius:12px;background:transparent;color:#ffffff;font-family:inherit;font-size:15px;font-weight:600;text-align:start;cursor:pointer;${vals.aAr}`
                  )}
                >
                  العربية
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={vals.pickEs}
                  style={css(
                    `height:44px;padding:0 14px;border:0;border-radius:12px;background:transparent;color:#ffffff;font-family:inherit;font-size:15px;font-weight:600;text-align:start;cursor:pointer;${vals.aEs}`
                  )}
                >
                  Español
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={vals.pickFr}
                  style={css(
                    `height:44px;padding:0 14px;border:0;border-radius:12px;background:transparent;color:#ffffff;font-family:inherit;font-size:15px;font-weight:600;text-align:start;cursor:pointer;${vals.aFr}`
                  )}
                >
                  Français
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Center: Animated Phone Mockup */}
        <div style={css(`flex:1;display:flex;align-items:center;justify-content:center;margin: 16px 0;`)}>
          <div
            className="cs-phone"
            style={css(
              `width:220px;height:440px;box-sizing:border-box;border-radius:40px;background:#050506;border:5px solid #2a2930;position:relative;box-shadow:0 24px 60px rgba(0,0,0,0.5);`
            )}
          >
            {/* Screen 1: Scan Frame (0s delay) */}
            <div
              className="cs-screen"
              style={css(`position:absolute;inset:0;border-radius:33px;overflow:hidden;background:#050506;animation-delay:0s;`)}
            >
              <div style={css(`position:absolute;left:34px;top:84px;width:22px;height:22px;border-left:3px solid #e6dfd6;border-top:3px solid #e6dfd6;border-top-left-radius:8px;`)}></div>
              <div style={css(`position:absolute;right:34px;top:84px;width:22px;height:22px;border-right:3px solid #e6dfd6;border-top:3px solid #e6dfd6;border-top-right-radius:8px;`)}></div>
              <div style={css(`position:absolute;left:34px;top:260px;width:22px;height:22px;border-left:3px solid #e6dfd6;border-bottom:3px solid #e6dfd6;border-bottom-left-radius:8px;`)}></div>
              <div style={css(`position:absolute;right:34px;top:260px;width:22px;height:22px;border-right:3px solid #e6dfd6;border-bottom:3px solid #e6dfd6;border-bottom-right-radius:8px;`)}></div>
              <div style={css(`position:absolute;left:12px;top:14px;width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,0.2);`)}></div>
              <div style={css(`position:absolute;right:12px;top:14px;width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,0.2);`)}></div>
              <div style={css(`position:absolute;left:12px;right:12px;top:318px;display:flex;gap:6px;`)}>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:#f4f4f4;`)}></div>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:rgba(255,255,255,0.28);`)}></div>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:rgba(255,255,255,0.28);`)}></div>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:rgba(255,255,255,0.28);`)}></div>
              </div>
              <div style={css(`position:absolute;left:50%;top:366px;width:44px;height:44px;margin-left:-22px;border-radius:50%;background:#ffffff;border:3px solid #050506;box-shadow:0 0 0 2px #d9d4cf;`)}></div>
            </div>

            {/* Screen 2: Food Plate Recognition (3s delay) */}
            <div
              className="cs-screen"
              style={css(`position:absolute;inset:0;border-radius:33px;overflow:hidden;background:#3a2a1c;animation-delay:3s;`)}
            >
              <div style={css(`position:absolute;left:50%;top:150px;width:150px;height:150px;margin-left:-75px;border-radius:50%;background:#ecdfc6;box-shadow:0 8px 20px rgba(0,0,0,0.4);`)}></div>
              <div style={css(`position:absolute;left:50%;top:190px;width:110px;height:70px;margin-left:-55px;`)}>
                <div style={css(`height:22px;border-radius:14px 14px 4px 4px;background:#d9a85f;`)}></div>
                <div style={css(`height:8px;margin:0 -4px;border-radius:4px;background:#6fae4f;`)}></div>
                <div style={css(`height:12px;background:#e9c79a;`)}></div>
                <div style={css(`height:22px;border-radius:4px 4px 14px 14px;background:#d9a85f;`)}></div>
              </div>
              <div style={css(`position:absolute;left:34px;top:84px;width:22px;height:22px;border-left:3px solid #e6dfd6;border-top:3px solid #e6dfd6;border-top-left-radius:8px;`)}></div>
              <div style={css(`position:absolute;right:34px;top:84px;width:22px;height:22px;border-right:3px solid #e6dfd6;border-top:3px solid #e6dfd6;border-top-right-radius:8px;`)}></div>
              <div style={css(`position:absolute;left:34px;top:260px;width:22px;height:22px;border-left:3px solid #e6dfd6;border-bottom:3px solid #e6dfd6;border-bottom-left-radius:8px;`)}></div>
              <div style={css(`position:absolute;right:34px;top:260px;width:22px;height:22px;border-right:3px solid #e6dfd6;border-bottom:3px solid #e6dfd6;border-bottom-right-radius:8px;`)}></div>
              <div style={css(`position:absolute;left:12px;top:14px;width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,0.2);`)}></div>
              <div style={css(`position:absolute;right:12px;top:14px;width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,0.2);`)}></div>
              <div style={css(`position:absolute;left:12px;right:12px;top:318px;display:flex;gap:6px;`)}>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:#f4f4f4;`)}></div>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:rgba(255,255,255,0.28);`)}></div>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:rgba(255,255,255,0.28);`)}></div>
                <div style={css(`flex:1;height:34px;border-radius:10px;background:rgba(255,255,255,0.28);`)}></div>
              </div>
              <div style={css(`position:absolute;left:50%;top:366px;width:44px;height:44px;margin-left:-22px;border-radius:50%;background:#ffffff;border:3px solid #050506;box-shadow:0 0 0 2px #d9d4cf;`)}></div>
            </div>

            {/* Screen 3: Instant Calorie Count (6s delay) */}
            <div
              className="cs-screen"
              style={css(`position:absolute;inset:0;border-radius:33px;overflow:hidden;background:#18181b;animation-delay:6s;padding:24px 16px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;align-items:center;`)}
            >
              <div style={css(`width:88px;height:88px;border-radius:50%;background:radial-gradient(circle, #FF8A1F 0%, #E04E00 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(255,138,31,0.4);margin-bottom:18px;`)}>
                <span style={css(`font-size:22px;font-weight:800;color:#fff;line-height:1;`)}>540</span>
                <span style={css(`font-size:10px;font-weight:600;color:rgba(255,255,255,0.85);margin-top:2px;`)}>kcal</span>
              </div>
              <div style={css(`width:100%;background:rgba(255,255,255,0.06);border-radius:14px;padding:12px;box-sizing:border-box;display:flex;justify-content:space-between;text-align:center;`)}>
                <div>
                  <div style={css(`font-size:11px;color:#9ca3af;`)}>Protein</div>
                  <div style={css(`font-size:13px;font-weight:700;color:#fff;`)}>36g</div>
                </div>
                <div>
                  <div style={css(`font-size:11px;color:#9ca3af;`)}>Carbs</div>
                  <div style={css(`font-size:13px;font-weight:700;color:#fff;`)}>48g</div>
                </div>
                <div>
                  <div style={css(`font-size:11px;color:#9ca3af;`)}>Fat</div>
                  <div style={css(`font-size:13px;font-weight:700;color:#fff;`)}>18g</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Headline, CTA button, Google button, Sign in link */}
        <div style={css(`display: flex; flex-direction: column; align-items: center; text-align: center; gap: 12px;`)}>
          <h1 style={css(`margin: 0; font-size: 26px; line-height: 1.25; font-weight: 800; color: #ffffff; letter-spacing: -0.02em;`)}>
            {vals.head}
          </h1>

          {googleError && (
            <div style={css(`width: 100%; box-sizing: border-box; padding: 10px 14px; border-radius: 14px; background: rgba(220,38,38,0.22); color: #fca5a5; font-size: 13px;`)}>
              {googleError}
            </div>
          )}

          <button
            type="button"
            onClick={handleStart}
            style={css(
              `width: 100%; height: 54px; border: 0; border-radius: 999px; background: #FF8A1F; color: #000000; font-family: inherit; font-size: 16px; font-weight: 800; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 24px rgba(255,138,31,0.35); transition: transform 0.15s ease;`
            )}
          >
            {vals.cta}
          </button>

          <button
            type="button"
            onClick={handleGoogle}
            disabled={googleLoading}
            style={css(`width: 100%; height: 50px; border: 1.5px solid rgba(255,255,255,0.2); border-radius: 999px; background: rgba(255,255,255,0.08); color: #ffffff; font-family: inherit; font-size: 15px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.15s ease;`)}
          >
            {googleLoading ? (
              <span style={css(`display: inline-block; width: 18px; height: 18px; border: 2px solid #ffffff; border-top-color: transparent; border-radius: 50%; animation: cs-spin 0.8s linear infinite;`)} />
            ) : (
              <>
                <svg style={css(`width: 18px; height: 18px; flex-shrink: 0;`)} viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>{vals.google}</span>
              </>
            )}
          </button>

          <p style={css(`margin: 0; font-size: 14px; color: rgba(255, 255, 255, 0.7);`)}>
            {vals.have}{' '}
            <a
              href="#signin"
              onClick={handleSignIn}
              style={css(`color: #ffffff; font-weight: 700; text-decoration: underline; cursor: pointer;`)}
            >
              {vals.signin}
            </a>
          </p>
        </div>
      </div>
    </>
  );
}
