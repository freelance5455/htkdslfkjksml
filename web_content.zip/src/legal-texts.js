/* AccoNova legal texts. Template wording — must be reviewed by a qualified lawyer in your jurisdiction before publishing.
   Placeholders: {owner} {email} {jurisdiction} {refund} {version} {effective}. Each section is [heading, paragraph, paragraph…]. */
(function (root) {
  "use strict";
  var L = { fa: {}, en: {} };

  L.en.terms = {
    title: "Terms of Use",
    intro: "Version {version}, effective {effective}. Please read these terms carefully. They are an agreement between you and {owner} (“we”, “us”).",
    sections: [
      ["1. Acceptance", "By creating a company or otherwise using AccoNova (the “Software”) you agree to these Terms and to the Privacy Policy. If you do not agree, do not use the Software. If you use it on behalf of an organisation, you confirm that you are authorised to bind that organisation."],
      ["2. What the Software is", "AccoNova is bookkeeping and accounting software. This edition runs entirely in your own browser. We do not host, receive, monitor or back up your accounting data."],
      ["3. Not professional advice", "Reports, tax summaries and calculations are tools to help you. They are not accounting, tax, legal or audit advice. You are responsible for checking every figure, for the accuracy of what you enter, and for filing returns and complying with the laws that apply to you. Consult a qualified professional where needed."],
      ["4. Your data and backups", "Your data belongs to you. You alone are responsible for keeping backups. Clearing browser data, losing or replacing your device, using the erase functions, or forgetting a password can delete data permanently, and we cannot recover it. The optional password is only a local lock on your device and does not encrypt your data."],
      ["5. Plans, subscriptions and payment", "The Software has a free plan and paid plans that unlock additional sections and limits, as shown on the Subscription screen. Paid plans are billed monthly in advance at the price shown when you subscribe, and renew automatically each month until you cancel. You can cancel at any time; cancellation takes effect at the end of the period already paid. After a downgrade or expiry your existing data stays readable, but paid features are locked. Prices may change with at least 30 days’ notice and apply from your next renewal. Taxes may be added where required. Refunds: {refund}. Where online payment is not yet enabled in your edition, the subscription screen is a simulation and no money is charged."],
      ["6. Acceptable use", "You must not use the Software to break the law, to commit or hide fraud, tax evasion or money laundering, to create false or misleading records, to infringe the rights of others, or to distribute malware. You must not circumvent plan limits or licensing, reverse engineer the Software except where the law allows, or resell or sublicense it without our written permission."],
      ["7. Intellectual property", "The Software, its design, name and logo belong to {owner} or its licensors. We grant you a limited, non-exclusive, non-transferable, revocable licence to use the Software for your own internal business purposes. You keep all rights in your data."],
      ["8. Availability and changes", "We may improve, change or remove features, and may change prices as described above. We do not promise that the Software will be uninterrupted or error-free."],
      ["9. No warranty", "To the maximum extent permitted by law, the Software is provided “as is” and “as available”, without warranties of any kind, whether express or implied, including accuracy, fitness for a particular purpose and non-infringement."],
      ["10. Limitation of liability", "To the maximum extent permitted by law, we are not liable for indirect, incidental or consequential loss, loss of profit, loss of data, or fines and penalties imposed by any authority. Our total liability for any claim is limited to the amount you paid us in the twelve months before the event giving rise to the claim. Nothing in these Terms excludes liability that cannot be excluded by law, and your mandatory consumer rights are not affected."],
      ["11. Your responsibility to us", "You agree to compensate us for losses and claims by third parties that arise from your unlawful use of the Software or from the content you enter."],
      ["12. Termination", "You may stop using the Software at any time. We may suspend or end your access if you materially breach these Terms. Clauses that by their nature should continue (for example 3, 4, 9, 10 and 13) survive termination."],
      ["13. Governing law and disputes", "These Terms are governed by the laws of {jurisdiction}, and the courts of {jurisdiction} have jurisdiction, subject to any mandatory rules that protect consumers where you live. Please contact us first so we can try to resolve a dispute informally."],
      ["14. Changes to these Terms", "We may update these Terms. When the version changes, the Software will ask you to accept the new version before you continue. If you do not accept, stop using the Software."],
      ["15. Contact", "{owner} — {email}"]
    ]
  };

  L.en.privacy = {
    title: "Privacy Policy",
    intro: "Version {version}, effective {effective}. This policy explains what happens to information when you use AccoNova. The operator is {owner}.",
    sections: [
      ["1. Where your data lives", "Everything you enter — companies, contacts, invoices, journal entries, settings — is stored only in your browser on your device. It is not sent to us or to anyone else. This edition makes no network requests; the page is built so that the browser blocks them."],
      ["2. What we do not do", "We do not run analytics, advertising or tracking, we do not use third-party scripts or fonts, and we do not sell or share data, because we do not receive it."],
      ["3. Preferences", "Your language, selected tab, time zone and terms acceptance (version and date) are saved locally so the app can remember them."],
      ["4. Personal data of your contacts", "You may enter personal data about your customers, suppliers or staff. You are responsible for having a lawful basis, informing those people, keeping the data accurate and deleting it when no longer needed. The Software provides export (JSON, CSV) and erase tools to help."],
      ["5. Payments", "If an online payment provider is enabled in a future or hosted edition, card and payment details are handled by that provider, not by this Software, and we will tell you before any data leaves your device."],
      ["6. Security", "Protect your device and browser profile. The optional password is a local lock, not encryption. For stronger protection of backups use the encrypted backup feature and keep the passphrase safe; it cannot be recovered."],
      ["7. Retention and deletion", "Data stays on your device until you delete it with the per-section erase, delete the company, or clear your browser data. We cannot delete it for you because we do not hold a copy."],
      ["8. Your rights", "Because we hold no copy of your data, you exercise access, portability and erasure directly in the Software. For questions about this policy contact {email}."],
      ["9. Children", "The Software is intended for business use by adults and is not directed at children."],
      ["10. Changes", "If this policy changes, the version number changes and you will be asked to accept it again."]
    ]
  };

  L.fa.terms = {
    title: "شرایط استفاده از برنامه",
    intro: "نسخهٔ {version}، تاریخ اجرا {effective}. لطفاً این شرایط را با دقت بخوانید. این متن یک توافق میان شما و {owner} («ما») است.",
    sections: [
      ["۱. پذیرش شرایط", "با ساختن شرکت یا هر نوع استفاده از AccoNova («نرم‌افزار») این شرایط و سیاست حریم خصوصی را می‌پذیرید. اگر موافق نیستید از نرم‌افزار استفاده نکنید. اگر از طرف یک سازمان استفاده می‌کنید، تأیید می‌کنید که اختیار الزام‌آور کردن آن سازمان را دارید."],
      ["۲. نرم‌افزار چیست", "AccoNova نرم‌افزار دفترداری و حسابداری است. این نسخه کاملاً درون مرورگر خودتان اجرا می‌شود. ما داده‌های حسابداری شما را نگه‌داری، دریافت، پایش یا بکاپ‌گیری نمی‌کنیم."],
      ["۳. مشاورهٔ حرفه‌ای نیست", "گزارش‌ها، خلاصهٔ مالیات و محاسبات فقط ابزار کمکی هستند و مشاورهٔ حسابداری، مالیاتی، حقوقی یا حسابرسی محسوب نمی‌شوند. بررسی همهٔ ارقام، درستی داده‌های واردشده، تسلیم اظهارنامه و رعایت قوانین مربوط به شما بر عهدهٔ خود شماست. در صورت نیاز با متخصص مجاز مشورت کنید."],
      ["۴. داده‌ها و بکاپ", "داده‌ها متعلق به شماست و نگه‌داری بکاپ تنها بر عهدهٔ شماست. پاک‌کردن داده‌های مرورگر، گم‌شدن یا تعویض دستگاه، استفاده از قابلیت‌های حذف یا فراموشی رمز می‌تواند داده‌ها را برای همیشه از بین ببرد و ما قادر به بازیابی نیستیم. رمز عبور اختیاری فقط یک قفل محلی روی دستگاه شماست و داده‌ها را رمزگذاری نمی‌کند."],
      ["۵. طرح‌ها، اشتراک و پرداخت", "نرم‌افزار یک طرح رایگان و طرح‌های پولی دارد که بخش‌ها و سقف‌های بیشتری را باز می‌کنند؛ جزئیات در صفحهٔ اشتراک آمده است. طرح‌های پولی به‌صورت ماهانه و پیش‌پرداخت، به قیمت نمایش‌داده‌شده هنگام اشتراک محاسبه می‌شوند و هر ماه تا زمان لغو خودکار تمدید می‌شوند. هر زمان می‌توانید لغو کنید و لغو در پایان دورهٔ پرداخت‌شده اعمال می‌شود. پس از کاهش طرح یا پایان اشتراک، داده‌های موجود قابل مشاهده می‌مانند ولی امکانات پولی قفل می‌شوند. قیمت‌ها با دست‌کم ۳۰ روز اطلاع قبلی قابل تغییرند و از تمدید بعدی اعمال می‌شوند. در صورت الزام قانونی مالیات اضافه می‌شود. بازپرداخت: {refund}. تا زمانی که پرداخت آنلاین در نسخهٔ شما فعال نشده، صفحهٔ اشتراک فقط شبیه‌سازی است و هیچ مبلغی کسر نمی‌شود."],
      ["۶. استفادهٔ مجاز", "استفاده از نرم‌افزار برای نقض قانون، ارتکاب یا پنهان‌کردن تقلب، فرار مالیاتی یا پولشویی، ساخت سوابق نادرست یا گمراه‌کننده، تجاوز به حقوق دیگران یا پخش بدافزار ممنوع است. دور زدن سقف‌های طرح یا مجوز، مهندسی معکوس (جز در حدی که قانون اجازه می‌دهد) و فروش یا واگذاری مجدد بدون اجازهٔ کتبی ما ممنوع است."],
      ["۷. مالکیت فکری", "نرم‌افزار و طراحی، نام و آرم آن متعلق به {owner} یا دارندگان مجوز آن است. ما به شما مجوزی محدود، غیرانحصاری، غیرقابل انتقال و قابل فسخ برای استفاده در امور داخلی کسب‌وکار خودتان می‌دهیم. همهٔ حقوق مربوط به داده‌های شما نزد شما می‌ماند."],
      ["۸. در دسترس بودن و تغییرات", "ما ممکن است امکانات را بهبود دهیم، تغییر دهیم یا حذف کنیم و قیمت‌ها را به شیوهٔ بالا تغییر دهیم. تضمین نمی‌کنیم که نرم‌افزار بدون وقفه یا بدون خطا باشد."],
      ["۹. نبود ضمانت", "تا حداکثر حد مجاز قانون، نرم‌افزار «همان‌گونه که هست» و «در حد موجود» ارائه می‌شود و هیچ ضمانت صریح یا ضمنی، از جمله درستی، تناسب برای هدف خاص و عدم نقض حقوق دیگران، ارائه نمی‌شود."],
      ["۱۰. محدودیت مسئولیت", "تا حداکثر حد مجاز قانون، ما مسئول خسارت غیرمستقیم، تبعی یا اتفاقی، از دست رفتن سود، از دست رفتن داده یا جرائم و مجازات‌های هر مرجع نیستیم. مسئولیت کل ما در هر ادعا به مبلغی که در دوازده ماه پیش از رویداد منشأ ادعا به ما پرداخته‌اید محدود است. هیچ بند این شرایط مسئولیتی را که قانوناً قابل رفع نیست حذف نمی‌کند و حقوق آمرهٔ مصرف‌کننده بی‌تأثیر می‌ماند."],
      ["۱۱. مسئولیت شما در برابر ما", "متعهد می‌شوید خسارت‌ها و ادعاهای اشخاص ثالث را که ناشی از استفادهٔ غیرقانونی شما از نرم‌افزار یا محتوایی است که وارد می‌کنید جبران کنید."],
      ["۱۲. پایان همکاری", "هر زمان می‌توانید استفاده را متوقف کنید. در صورت نقض اساسی این شرایط ممکن است دسترسی شما را تعلیق یا قطع کنیم. بندهایی که ماهیتاً باید ادامه یابند (مانند ۳، ۴، ۹، ۱۰ و ۱۳) پس از پایان نیز معتبرند."],
      ["۱۳. قانون حاکم و حل اختلاف", "این شرایط تابع قوانین {jurisdiction} است و مراجع {jurisdiction} صلاحیت رسیدگی دارند، مشروط به قواعد آمرهٔ حمایت از مصرف‌کننده در محل اقامت شما. لطفاً ابتدا با ما تماس بگیرید تا اختلاف به‌صورت دوستانه حل شود."],
      ["۱۴. تغییر شرایط", "ممکن است این شرایط را به‌روزرسانی کنیم. با تغییر نسخه، نرم‌افزار پیش از ادامه از شما می‌خواهد نسخهٔ جدید را بپذیرید. در صورت نپذیرفتن، استفاده را متوقف کنید."],
      ["۱۵. تماس", "{owner} — {email}"]
    ]
  };

  L.fa.privacy = {
    title: "سیاست حریم خصوصی",
    intro: "نسخهٔ {version}، تاریخ اجرا {effective}. این سیاست توضیح می‌دهد هنگام استفاده از AccoNova چه بر سر اطلاعات می‌آید. اپراتور {owner} است.",
    sections: [
      ["۱. داده‌های شما کجا هستند", "هر چه وارد می‌کنید — شرکت‌ها، طرف‌حساب‌ها، فاکتورها، اسناد و تنظیمات — فقط در مرورگر و روی دستگاه خودتان ذخیره می‌شود و برای ما یا هیچ‌کس دیگر ارسال نمی‌شود. این نسخه هیچ درخواست شبکه‌ای نمی‌فرستد و صفحه طوری ساخته شده که مرورگر آن را مسدود می‌کند."],
      ["۲. آنچه انجام نمی‌دهیم", "ما تحلیل آماری، تبلیغات یا ردیابی نداریم، از اسکریپت یا فونت شخص ثالث استفاده نمی‌کنیم و داده‌ای نمی‌فروشیم یا به اشتراک نمی‌گذاریم، چون اصلاً داده‌ای دریافت نمی‌کنیم."],
      ["۳. ترجیحات", "زبان، تب انتخابی، منطقهٔ زمانی و پذیرش شرایط (نسخه و تاریخ) به‌صورت محلی ذخیره می‌شوند تا برنامه به یاد بسپارد."],
      ["۴. اطلاعات شخصی طرف‌حساب‌ها", "ممکن است اطلاعات شخصی مشتریان، تأمین‌کنندگان یا کارکنان را وارد کنید. داشتن مبنای قانونی، اطلاع‌رسانی به آن افراد، درستی داده و حذف آن در زمان بی‌نیازی بر عهدهٔ شماست. نرم‌افزار ابزار خروجی (JSON، CSV) و حذف را برای کمک ارائه می‌دهد."],
      ["۵. پرداخت‌ها", "اگر در نسخه‌ای آینده یا میزبانی‌شده درگاه پرداخت آنلاین فعال شود، اطلاعات کارت و پرداخت را همان ارائه‌دهنده مدیریت می‌کند، نه این نرم‌افزار، و پیش از خروج هر داده از دستگاه شما به شما اطلاع می‌دهیم."],
      ["۶. امنیت", "از دستگاه و نمایهٔ مرورگر خود محافظت کنید. رمز عبور اختیاری قفل محلی است و رمزگذاری نیست. برای محافظت قوی‌تر از بکاپ از بکاپ رمزگذاری‌شده استفاده کنید و رمز آن را حفظ کنید؛ قابل بازیابی نیست."],
      ["۷. نگه‌داری و حذف", "داده‌ها تا وقتی با حذف جداگانهٔ بخش، حذف شرکت یا پاک‌کردن داده‌های مرورگر پاکشان نکنید روی دستگاه شما می‌مانند. ما نمی‌توانیم به‌جای شما حذف کنیم چون نسخه‌ای نزد ما نیست."],
      ["۸. حقوق شما", "چون نسخه‌ای از داده‌های شما نزد ما نیست، حق دسترسی، انتقال و حذف را مستقیماً در خود نرم‌افزار اعمال می‌کنید. برای پرسش دربارهٔ این سیاست با {email} تماس بگیرید."],
      ["۹. کودکان", "نرم‌افزار برای استفادهٔ تجاری بزرگسالان است و مخاطب آن کودکان نیستند."],
      ["۱۰. تغییرات", "اگر این سیاست تغییر کند، شمارهٔ نسخه تغییر می‌کند و از شما خواسته می‌شود دوباره بپذیرید."]
    ]
  };

  root.AN_LEGAL = L;
})(typeof globalThis !== "undefined" ? globalThis : this);
