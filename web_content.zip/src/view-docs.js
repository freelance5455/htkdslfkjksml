/* Documents: sales invoices, purchase bills, payments & receipts. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, F = UI.fmt, J = root.AN_J, AN = root.AN;

  function contactName(co, id) { var c = co.contacts[id]; return c ? c.name : "—"; }
  function statusBadge(co, inv) { var s = UI.store.invoiceStatus(co, inv); return UI.badge(t("st_" + s), s === "paid" ? "ok" : s === "overdue" ? "bad" : s === "void" ? "" : s === "draft" ? "" : "warn"); }
  function mapStatusKey(s) { return s; }

  /* ───────────── invoice lists ───────────── */
  function listView(kind) {
    return function (box) {
      var co = UI.co(), key = "inv_" + kind, st = UI.sub[key] = UI.sub[key] || { f: "all", q: "" };
      var list = h("div"), q = h("input", { class: "inp", type: "search", placeholder: t("searchDocs"), value: st.q, oninput: function () { st.q = q.value; draw(); } });
      var f = UI.select(["all", "draft", "open", "partial", "overdue", "paid", "void"].map(function (x) { return { value: x, label: x === "all" ? t("all") : t("st_" + x) }; }), st.f, function () { st.f = f.value; draw(); });
      var bar = h("div", { class: "toolbar" }, q, f, h("span", { class: "grow" }));
      var paidLocked = kind === "purchase" && !UI.store.planOf(co).purchases;
      if (UI.can("doc.manage") && !paidLocked) bar.appendChild(h("button", { class: "btn", type: "button", onclick: function () { invoiceForm(kind); } }, UI.icon("plus"), kind === "sale" ? t("newSale") : t("newBill")));
      var u = UI.store.usage(co), lim = u.limits.invoicesPerMonth;
      var info = lim !== Infinity ? h("p", { class: "muted small", text: t("invoiceQuota", { n: F.int(u.invoicesThisMonth), max: F.int(lim) }) }) : null;
      function draw() {
        var needle = st.q.trim().toLowerCase();
        var rows = Object.keys(co.invoices).map(function (k) { return co.invoices[k]; }).filter(function (i) { return i.kind === kind; }).filter(function (i) {
          var s = UI.store.invoiceStatus(co, i); if (st.f !== "all" && s !== st.f) return false;
          return !needle || (i.number + " " + contactName(co, i.contactId)).toLowerCase().indexOf(needle) > -1;
        }).sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : (a.createdAt < b.createdAt ? 1 : -1); });
        UI.clear(list);
        if (!rows.length) { list.appendChild(UI.empty(kind === "sale" ? t("noSales") : t("noBills"))); return; }
        list.appendChild(UI.table([{ label: t("number") }, { label: t("contact") }, { label: t("date") }, { label: t("due") }, { label: t("total"), cls: "end" }, { label: t("remaining"), cls: "end" }, { label: t("status") }, { label: "" }], rows.map(function (i) {
          var pi = i.status === "posted" ? UI.store.paidInfo(co, i) : null;
          return { attrs: { class: i.status === "void" ? "dim" : "" }, cells: [i.number || t("st_draft"), contactName(co, i.contactId), F.date(i.date), F.date(i.dueDate), UI.amount(i.total, i.currency), pi ? UI.amount(pi.remaining, i.currency) : "", statusBadge(co, i), h("button", { class: "link", type: "button", onclick: function () { invoiceView(i.id); } }, t("view"))] };
        })));
      }
      box.appendChild(h("section", { class: "card" }, h("h2", { text: kind === "sale" ? t("tabSales") : t("tabPurchases") }), paidLocked ? UI.upgradeNote("purchasesLocked") : null, bar, info, list)); draw();
      if (UI.pending === "new") { UI.pending = null; invoiceForm(kind); }
    };
  }
  UI.views.sales = listView("sale"); UI.views.purchases = listView("purchase");

  /* ───────────── invoice view ───────────── */
  function invoiceView(id, noReopen) {
    var co = UI.co(), inv = co.invoices[id]; if (!inv) return;
    var m, isSale = inv.kind === "sale", pi = inv.status === "posted" ? UI.store.paidInfo(co, inv) : null;
    var meta = h("dl", { class: "meta" }, h("dt", { text: t("number") }), h("dd", { text: inv.number || t("st_draft") }), h("dt", { text: t("contact") }), h("dd", { text: contactName(co, inv.contactId) }),
      h("dt", { text: t("date") }), h("dd", { text: F.date(inv.date) }), h("dt", { text: t("due") }), h("dd", { text: F.date(inv.dueDate) }),
      h("dt", { text: t("status") }), h("dd", {}, statusBadge(co, inv)),
      inv.currency !== co.baseCurrency ? [h("dt", { text: t("currency") }), h("dd", { text: inv.currency + " @ " + F.num(inv.rate / 1e6, { maximumFractionDigits: 6 }) })] : null,
      inv.entryId ? [h("dt", { text: t("journalEntry") }), h("dd", {}, h("button", { class: "link", type: "button", onclick: function () { m.close(); UI.entryView(inv.entryId); } }, inv.entryId))] : null);
    var rows = inv.lines.map(function (l) { var tc = co.taxCodes[l.taxCodeId]; return [l.desc, F.qty(l.qty), UI.amount(l.unitPrice, inv.currency), tc ? (UI.taxName(tc) + " (" + F.pct(tc.bps) + ")") : "", UI.amount(l.net, inv.currency)]; });
    var foot = h("tfoot", {}, h("tr", {}, h("td", { colspan: 4, class: "end", text: t("subtotal") }), h("td", { class: "end" }, UI.amount(inv.subtotal, inv.currency))), h("tr", {}, h("td", { colspan: 4, class: "end", text: t("tax") }), h("td", { class: "end" }, UI.amount(inv.taxTotal, inv.currency))), h("tr", { class: "grand" }, h("td", { colspan: 4, class: "end", text: t("total") }), h("td", { class: "end" }, UI.amount(inv.total, inv.currency))));
    var pays = Object.keys(co.payments).map(function (k) { return co.payments[k]; }).filter(function (p) { return p.allocations.some(function (a) { return a.invoiceId === inv.id; }); });
    var payBlock = pays.length ? h("div", {}, h("h3", { text: t("tabPayments") }), UI.table([{ label: t("number") }, { label: t("date") }, { label: t("amount"), cls: "end" }, { label: t("status") }], pays.map(function (p) { var a = p.allocations.filter(function (x) { return x.invoiceId === inv.id; })[0]; return [p.number, F.date(p.date), UI.amount(a.amount, p.currency), UI.badge(t("st_" + (p.status === "void" ? "void" : "paid")), p.status === "void" ? "" : "ok")]; }))) : null;
    var buttons = [h("button", { class: "btn sec", type: "button", onclick: function () { UI.printNode(); } }, UI.icon("print"), t("print"))];
    if (UI.can("doc.manage")) {
      if (inv.status === "draft") {
        buttons.push(h("button", { class: "btn danger", type: "button", onclick: function () { UI.confirm(t("deleteDraft"), t("deleteDraftQ"), t("delete"), true).then(function (ok) { if (!ok) return; try { UI.store.deleteDraft(UI.ctx, inv.id); m.close(); UI.toast(t("deleted")); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } }); } }, t("delete")));
        buttons.push(h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); invoiceForm(inv.kind, inv); } }, t("edit")));
        var idem = UI.newIdemKey(), pbtn = h("button", { class: "btn", type: "button", onclick: function () { UI.busy(pbtn, function () { try { var r = UI.store.postInvoice(UI.ctx, inv.id, { idemKey: idem }); m.close(); UI.toast(t("postedOk", { id: r.invoice.number })); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } }); } }, t("postInvoice"));
        buttons.push(pbtn);
      } else if (inv.status === "posted") {
        if (pi.paid === 0) buttons.push(h("button", { class: "btn danger", type: "button", onclick: function () { m.close(); voidForm(inv); } }, t("voidDoc")));
        if (pi.remaining > 0) buttons.push(h("button", { class: "btn", type: "button", onclick: function () { m.close(); paymentForm({ kind: isSale ? "receipt" : "payout", contactId: inv.contactId, invoiceId: inv.id }); } }, isSale ? t("recordReceipt") : t("recordPayout")));
      }
    }
    m = UI.modal({ title: (isSale ? t("sale") : t("bill")) + " " + (inv.number || ""), wide: true, body: h("div", { class: "print-area" }, h("h3", { class: "print-title", text: co.name }), meta, UI.table([{ label: t("description") }, { label: t("qty"), cls: "end" }, { label: t("unitPrice"), cls: "end" }, { label: t("tax") }, { label: t("net"), cls: "end" }], rows, { foot: foot }), inv.notes ? h("p", { class: "muted", text: inv.notes }) : null, payBlock), footer: buttons });
  }
  UI.invoiceView = invoiceView;
  function voidForm(inv) {
    var date = UI.dateInput(inv.date), m;
    var go = h("button", { class: "btn danger", type: "button", onclick: function () { UI.busy(go, function () { var d = date.get(); if (!d) { m.error(t("badDate")); return; } try { UI.store.voidInvoice(UI.ctx, inv.id, { date: d }); m.close(); UI.toast(t("voidedOk")); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } }); } }, t("voidDoc"));
    m = UI.modal({ title: t("voidDoc") + " " + inv.number, body: h("div", { class: "form" }, h("p", { class: "muted", text: t("voidExplain") }), UI.field(t("date"), date.el)), footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), go] });
  }

  /* ───────────── invoice form ───────────── */
  function invoiceForm(kind, draft) {
    var co = UI.co(), plan = UI.store.planOf(co), isSale = kind === "sale", cur = draft ? draft.currency : co.baseCurrency, rows = [], m, idemDraft = null;
    var multi = plan.multiCurrency && Object.keys(co.currencies).length > 1;
    var contacts = Object.keys(co.contacts).map(function (k) { return co.contacts[k]; }).filter(function (c) { return !c.archived && (c.type === "both" || c.type === (isSale ? "customer" : "supplier")); }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
    if (!contacts.length) { UI.modal({ title: isSale ? t("newSale") : t("newBill"), body: h("div", {}, h("p", { text: t("needContactFirst") }), UI.can("contact.manage") ? h("button", { class: "btn", type: "button", onclick: function () { document.querySelectorAll("dialog").forEach(function (d) { d.close(); d.remove(); }); UI.contactForm({ type: isSale ? "customer" : "supplier" }); } }, t("addContact")) : null) }); return; }
    function dec() { return co.currencies[cur].decimals; }
    var contact = UI.select(contacts.map(function (c) { return { value: c.id, label: c.name }; }), draft ? draft.contactId : contacts[0].id);
    var due, date = UI.dateInput(draft ? draft.date : UI.store.today(), function () { if (due && !dueTouched) { var d = date.get(); if (d) due.set(J.addDaysIso(d, 30)); } autoRate(); }), dueTouched = !!draft;
    due = UI.dateInput(draft ? draft.dueDate : J.addDaysIso(UI.store.today(), 30), function () { dueTouched = true; });
    var rate = UI.rateInput(), rateWrap = h("div", { class: "field", hidden: cur === co.baseCurrency ? "" : null }, h("label", { text: t("rate") }), rate.el, h("div", { class: "hint", text: t("rateHint") }));
    if (draft && draft.currency !== co.baseCurrency) rate.set(draft.rate);
    var curSel = multi ? UI.currencySelect(co, cur, function () { cur = curSel.value; rateWrap.hidden = cur === co.baseCurrency; autoRate(); rows.forEach(function (r) { r.price.set(r.price.get()); }); recalc(); }) : null;
    function autoRate() { if (cur !== co.baseCurrency) { var d = date.get(), r = d && UI.store.rateFor(co, cur, d); if (r) rate.set(r); } }
    var notes = h("textarea", { class: "inp", rows: 2, maxlength: 500 }); if (draft) notes.value = draft.notes || "";
    var taxOpts = Object.keys(co.taxCodes).map(function (k) { var x = co.taxCodes[k]; return { value: x.id, label: UI.taxName(x) + " (" + F.pct(x.bps) + ")" }; });
    var accTypes = isSale ? ["revenue"] : ["expense", "asset"], defAcc = isSale ? co.sys.REVENUE : co.sys.EXPENSE;
    var tbody = h("tbody"), totals = h("div", { class: "totals" });
    function addRow(pre) {
      var r = { desc: h("input", { class: "inp", maxlength: 200, value: pre ? pre.desc : "" }), qty: UI.moneyInput(function () { return 3; }, pre ? pre.qty : 1000, recalc), price: UI.moneyInput(dec, pre ? pre.unitPrice : null, recalc), tax: UI.select(taxOpts, pre ? pre.taxCodeId : "T0", recalc), acc: UI.accountSelect(co, accTypes, pre ? pre.accountId : defAcc), tot: h("span", { class: "amt", dir: "ltr" }) };
      r.tr = h("tr", {}, h("td", { "data-label": t("description") }, r.desc), h("td", { "data-label": t("qty") }, r.qty.el), h("td", { "data-label": t("unitPrice") }, r.price.el), h("td", { "data-label": t("tax") }, r.tax), h("td", { "data-label": t("account") }, r.acc), h("td", { class: "end", "data-label": t("total") }, r.tot),
        h("td", {}, h("button", { class: "icon-btn", type: "button", "aria-label": t("remove"), onclick: function () { if (rows.length > 1) { rows.splice(rows.indexOf(r), 1); tbody.removeChild(r.tr); recalc(); } } }, UI.icon("x"))));
      rows.push(r); tbody.appendChild(r.tr);
    }
    function calc() {
      var sub = 0, tax = 0, bad = false, lines = [];
      rows.forEach(function (r) {
        var q = r.qty.get(), p = r.price.get(), desc = r.desc.value.trim(), tc = co.taxCodes[r.tax.value];
        if (!desc && p == null) { r.tot.textContent = ""; return; }
        if (!desc || !(q > 0) || p == null || p < 0 || !r.acc.value) { bad = true; r.tot.textContent = ""; return; }
        var net = AN.mulDivRound(q, p, 1000), tx = AN.mulDivRound(net, tc.bps, 10000); sub += net; tax += tx; r.tot.textContent = F.money(net + tx, cur);
        lines.push({ desc: desc, qty: q, unitPrice: p, taxCodeId: tc.id, accountId: r.acc.value });
      });
      return { sub: sub, tax: tax, total: sub + tax, lines: lines, bad: bad };
    }
    var btnDraft = h("button", { class: "btn sec", type: "button" }, t("saveDraft")), btnPost = h("button", { class: "btn", type: "button" }, t("saveAndPost"));
    function recalc() {
      var c = calc(); UI.clear(totals);
      [[t("subtotal"), c.sub], [t("tax"), c.tax], [t("total"), c.total]].forEach(function (x, i) { totals.appendChild(h("div", { class: "tot-row" + (i === 2 ? " grand" : "") }, h("span", { text: x[0] }), UI.amount(x[1], cur))); });
      var ok = !c.bad && c.lines.length > 0 && c.total > 0; btnDraft.disabled = !ok; btnPost.disabled = !ok;
    }
    function buildInput() {
      var c = calc(), d = date.get(), dd = due.get(); if (!d || !dd) throw { code: "BAD_DATE" };
      var input = { id: draft && draft.id, kind: kind, contactId: contact.value, date: d, dueDate: dd, currency: cur, lines: c.lines, notes: notes.value };
      if (cur !== co.baseCurrency) { var r = rate.get(); if (!r) throw { code: "NO_RATE" }; input.rate = r; }
      return input;
    }
    function submit(post) {
      return function () {
        var btn = post ? btnPost : btnDraft;
        UI.busy(btn, function () {
          var saved;
          try { saved = UI.store.saveInvoiceDraft(UI.ctx, buildInput()); draft = saved; } catch (e) { m.error(UI.errMsg(e)); return; }
          if (!post) { m.close(); UI.toast(t("saved")); UI.render(); return; }
          idemDraft = idemDraft || UI.newIdemKey();
          try { var r = UI.store.postInvoice(UI.ctx, saved.id, { idemKey: idemDraft }); m.close(); UI.toast(t("postedOk", { id: r.invoice.number })); UI.render(); }
          catch (e) { m.error(UI.errMsg(e) + " — " + t("draftKept")); UI.render && 0; }
        });
      };
    }
    btnDraft.addEventListener("click", submit(false)); btnPost.addEventListener("click", submit(true));
    if (!UI.can("doc.manage")) { btnPost.hidden = true; btnDraft.hidden = true; }
    var body = h("div", { class: "form" }, h("div", { class: "grid-fields" }, UI.field(t("contact"), contact), UI.field(t("date"), date.el), UI.field(t("due"), due.el), curSel ? UI.field(t("currency"), curSel) : null, rateWrap),
      h("div", { class: "tw" }, h("table", { class: "tbl lines" }, h("thead", {}, h("tr", {}, [t("description"), t("qty"), t("unitPrice"), t("tax"), t("account"), t("total"), ""].map(function (x, i) { return h("th", { class: i === 5 ? "end" : "", text: x }); }))), tbody)),
      h("button", { class: "mini", type: "button", onclick: function () { addRow(); recalc(); } }, UI.icon("plus"), t("addLine")), totals, UI.field(t("notes"), notes));
    if (draft && draft.lines) draft.lines.forEach(addRow); else addRow();
    recalc();
    m = UI.modal({ title: (draft ? t("edit") + " · " : "") + (isSale ? t("newSale") : t("newBill")), wide: true, body: body, footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), btnDraft, btnPost] });
  }
  UI.invoiceForm = invoiceForm;

  /* ───────────── payments ───────────── */
  UI.views.payments = function (box) {
    var co = UI.co(), list = h("div");
    var bar = h("div", { class: "toolbar" }, h("h2", { text: t("tabPayments") }), h("span", { class: "grow" }));
    if (UI.can("doc.manage")) bar.appendChild(h("button", { class: "btn", type: "button", onclick: function () { paymentForm({}); } }, UI.icon("plus"), t("newPayment")));
    var rows = Object.keys(co.payments).map(function (k) { return co.payments[k]; }).sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : (a.createdAt < b.createdAt ? 1 : -1); });
    if (!rows.length) list.appendChild(UI.empty(t("noPayments")));
    else list.appendChild(UI.table([{ label: t("number") }, { label: t("date") }, { label: t("contact") }, { label: t("type") }, { label: t("amount"), cls: "end" }, { label: t("appliedTo") }, { label: t("status") }, { label: "" }], rows.map(function (p) {
      var nums = p.allocations.map(function (a) { var i = co.invoices[a.invoiceId]; return i ? i.number : "?"; }).join(", ");
      return { attrs: { class: p.status === "void" ? "dim" : "" }, cells: [p.number, F.date(p.date), contactName(co, p.contactId), p.kind === "receipt" ? t("receipt") : t("payout"), UI.amount(p.amount, p.currency), UI.num(nums), UI.badge(p.status === "void" ? t("st_void") : t("posted"), p.status === "void" ? "" : "ok"),
        p.status === "posted" && UI.can("doc.manage") ? h("button", { class: "link", type: "button", onclick: function () { voidPayment(p); } }, t("voidDoc")) : ""] };
    })));
    box.appendChild(h("section", { class: "card" }, bar, list));
    if (UI.pending === "new") { UI.pending = null; paymentForm({}); }
  };
  function voidPayment(p) {
    var date = UI.dateInput(p.date), m;
    var go = h("button", { class: "btn danger", type: "button", onclick: function () { UI.busy(go, function () { var d = date.get(); if (!d) { m.error(t("badDate")); return; } try { UI.store.voidPayment(UI.ctx, p.id, { date: d }); m.close(); UI.toast(t("voidedOk")); UI.render(); } catch (e) { m.error(UI.errMsg(e)); } }); } }, t("voidDoc"));
    m = UI.modal({ title: t("voidDoc") + " " + p.number, body: h("div", { class: "form" }, h("p", { class: "muted", text: t("voidPayExplain") }), UI.field(t("date"), date.el)), footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), go] });
  }
  function paymentForm(pre) {
    var co = UI.co(), plan = UI.store.planOf(co), kind = pre.kind || "receipt", cur = co.baseCurrency, idem = UI.newIdemKey(), m, alloc = [];
    var multi = plan.multiCurrency && Object.keys(co.currencies).length > 1;
    if (pre.invoiceId && co.invoices[pre.invoiceId]) cur = co.invoices[pre.invoiceId].currency;
    if (!plan.purchases) kind = "receipt";
    var kindSel = UI.select(plan.purchases ? [{ value: "receipt", label: t("receiptLong") }, { value: "payout", label: t("payoutLong") }] : [{ value: "receipt", label: t("receiptLong") }], kind, function () { kind = kindSel.value; fillContacts(); loadOpen(); });
    var contactSel = UI.select([], null, function () { loadOpen(); });
    function fillContacts() {
      var want = kind === "receipt" ? "customer" : "supplier", cs = Object.keys(co.contacts).map(function (k) { return co.contacts[k]; }).filter(function (c) { return !c.archived && (c.type === "both" || c.type === want); }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
      var keep = contactSel.value; UI.clear(contactSel); cs.forEach(function (c) { contactSel.appendChild(h("option", { value: c.id, text: c.name })); }); if (pre.contactId && cs.some(function (c) { return c.id === pre.contactId; })) contactSel.value = pre.contactId; else if (keep && cs.some(function (c) { return c.id === keep; })) contactSel.value = keep;
    }
    var date = UI.dateInput(UI.store.today(), function () { autoRate(); });
    var bankSel = h("select", { class: "inp" }); UI.activeAccounts(co, ["asset"]).filter(function (a) { return a.system !== "AR" && a.system !== "TAXIN"; }).forEach(function (a) { bankSel.appendChild(h("option", { value: a.id, text: UI.accountLabel(a) })); }); bankSel.value = co.sys.BANK;
    var curSel = multi ? UI.currencySelect(co, cur, function () { cur = curSel.value; rateWrap.hidden = cur === co.baseCurrency; autoRate(); loadOpen(); }) : null;
    var rate = UI.rateInput(), rateWrap = h("div", { class: "field", hidden: cur === co.baseCurrency ? "" : null }, h("label", { text: t("rate") }), rate.el, h("div", { class: "hint", text: t("rateHint") }));
    function autoRate() { if (cur !== co.baseCurrency) { var d = date.get(), r = d && UI.store.rateFor(co, cur, d); if (r) rate.set(r); } }
    var ref = h("input", { class: "inp", maxlength: 100 }), allocBox = h("div"), totalBox = h("div", { class: "totals" }), save = h("button", { class: "btn", type: "button" }, t("post"));
    function dec() { return co.currencies[cur].decimals; }
    function loadOpen() {
      alloc = []; UI.clear(allocBox);
      var want = kind === "receipt" ? "sale" : "purchase";
      var invs = Object.keys(co.invoices).map(function (k) { return co.invoices[k]; }).filter(function (i) { return i.kind === want && i.status === "posted" && i.contactId === contactSel.value && i.currency === cur && UI.store.paidInfo(co, i).remaining > 0; }).sort(function (a, b) { return a.dueDate < b.dueDate ? -1 : 1; });
      if (!invs.length) { allocBox.appendChild(UI.empty(t("noOpenForContact"))); recalc(); return; }
      var tb = h("tbody");
      invs.forEach(function (i) {
        var rem = UI.store.paidInfo(co, i).remaining, a = { inv: i, rem: rem, inp: UI.moneyInput(dec, pre.invoiceId === i.id ? rem : null, recalc) };
        var full = h("button", { class: "mini", type: "button", onclick: function () { a.inp.set(rem); recalc(); } }, t("full"));
        tb.appendChild(h("tr", {}, h("td", { "data-label": t("number") }, i.number), h("td", { "data-label": t("due") }, F.date(i.dueDate)), h("td", { class: "end", "data-label": t("remaining") }, UI.amount(rem, cur)), h("td", { "data-label": t("allocate") }, h("div", { class: "alloc-cell" }, a.inp.el, full))));
        alloc.push(a);
      });
      allocBox.appendChild(h("div", { class: "tw" }, h("table", { class: "tbl lines" }, h("thead", {}, h("tr", {}, [t("number"), t("due"), t("remaining"), t("allocate")].map(function (x, i) { return h("th", { class: i === 2 ? "end" : "", text: x }); }))), tb)));
      recalc();
    }
    function sums() { var s = 0, bad = false, list = []; alloc.forEach(function (a) { var v = a.inp.get(); if (a.inp.raw() && (v == null || v <= 0 || v > a.rem)) { bad = true; return; } if (v > 0) { s += v; list.push({ invoiceId: a.inv.id, amount: v }); } }); return { total: s, bad: bad, list: list }; }
    function recalc() { var s = sums(); UI.clear(totalBox); totalBox.appendChild(h("div", { class: "tot-row grand" }, h("span", { text: t("amount") }), UI.amount(s.total, cur))); save.disabled = s.bad || s.total <= 0; }
    save.addEventListener("click", function () {
      UI.busy(save, function () {
        var s = sums(), d = date.get(); if (!d) { m.error(t("badDate")); return; } if (s.bad || s.total <= 0) return;
        var input = { kind: kind, contactId: contactSel.value, date: d, currency: cur, amount: s.total, bankAccountId: bankSel.value, ref: ref.value, allocations: s.list };
        if (cur !== co.baseCurrency) { var r = rate.get(); if (!r) { m.error(t("e_NO_RATE")); return; } input.rate = r; }
        UI.curOfForm = cur;
        try { var res = UI.store.postPayment(UI.ctx, input, { idemKey: idem }); m.close(); UI.toast(res.duplicate ? t("duplicateIgnored") : t("postedOk", { id: res.payment.number })); UI.render(); } catch (e) { m.error(UI.errMsg(e)); }
      });
    });
    fillContacts();
    var body = h("div", { class: "form" }, h("div", { class: "grid-fields" }, UI.field(t("type"), kindSel), UI.field(t("contact"), contactSel), UI.field(t("date"), date.el), UI.field(t("bankAccount"), bankSel), curSel ? UI.field(t("currency"), curSel) : null, rateWrap, UI.field(t("reference"), ref)), h("h3", { text: t("allocations") }), allocBox, totalBox);
    loadOpen();
    m = UI.modal({ title: t("newPayment"), wide: true, body: body, footer: [h("button", { class: "btn sec", type: "button", onclick: function () { m.close(); } }, t("cancel")), save] });
  }
  UI.paymentForm = paymentForm;
})(typeof globalThis !== "undefined" ? globalThis : this);
