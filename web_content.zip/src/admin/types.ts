export type Video = {
  name?: string;
  image_url?: string;
  download_link?: string;
  category?: string;
  ad_watches_required?: number;
  duration?: string | number;
  duration_sec?: number;
  view_count?: number;
  created_at?: number;
};

export type Filter = {
  id?: string;
  name?: string;
};

export type LinkItem = {
  title?: string;
  url?: string;
};

export type User = {
  id?: string | number;
  first_name?: string;
  unlock_credits?: number;
  total_refers?: number;
  total_unlocked?: number;
};

export type Settings = {
  admin_password?: string;
  bengal_ads_app_id?: string;
  bengal_ads_format_id?: string;
  ads_limit?: number;
  bot_app_link?: string;
  tutorial_id?: string;
  [key: string]: unknown;
};

export type PageId = "home" | "videos" | "links" | "users" | "settings";
