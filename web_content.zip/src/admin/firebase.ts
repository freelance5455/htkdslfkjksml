import { initializeApp, type FirebaseApp } from "firebase/app";
import {
  getDatabase,
  ref,
  onValue,
  get,
  set,
  update,
  remove,
  push,
  type Database,
} from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyAXQOOwUInl8H6ZHvu5kFW1lmEMaSGStBM",
  authDomain: "money-zone-76cad.firebaseapp.com",
  databaseURL: "https://money-zone-76cad-default-rtdb.firebaseio.com",
  projectId: "money-zone-76cad",
  storageBucket: "money-zone-76cad.firebasestorage.app",
  messagingSenderId: "963068060615",
  appId: "1:963068060615:web:8812a83c3f71e89824afe2",
  measurementId: "G-11B7D50J6Y",
};

let app: FirebaseApp | null = null;
let db: Database | null = null;

export function getDb(): Database {
  if (typeof window === "undefined") {
    throw new Error("Firebase is browser-only");
  }
  if (!app) app = initializeApp(firebaseConfig);
  if (!db) db = getDatabase(app);
  return db;
}

export { ref, onValue, get, set, update, remove, push };

export const AUTH_KEY = "vz_admin_auth_v1";
export const DEFAULT_PASS = "admin123";
export const IMGBB_API_KEY = "a1d04ab683bb57945ac6c98999b8b6ba";
export const IMGBB_UPLOAD_URL = "https://api.imgbb.com/1/upload";

export function isLoggedIn() {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(AUTH_KEY) === "1";
  } catch {
    return false;
  }
}

export function setLoggedIn(v: boolean) {
  try {
    if (v) window.localStorage.setItem(AUTH_KEY, "1");
    else window.localStorage.removeItem(AUTH_KEY);
  } catch {
    /* ignore quota / private mode */
  }
}
