import {
  BarChart3,
  Film,
  FolderOpen,
  Link2,
  Users,
  Settings,
  LogOut,
  Plus,
  RefreshCw,
  Pencil,
  Trash2,
  Upload,
  Shield,
  Search,
  LayoutDashboard,
} from "lucide-react";
import type { FormEvent, ReactNode } from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast, Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn, formatNum } from "@/lib/utils";
import {
  DEFAULT_PASS,
  IMGBB_API_KEY,
  IMGBB_UPLOAD_URL,
  get,
  getDb,
  isLoggedIn,
  onValue,
  push,
  ref,
  remove,
  set,
  setLoggedIn,
  update,
} from "./firebase";
import type {
  Filter,
  LinkItem,
  PageId,
  Settings as AppSettings,
  User,
  Video,
} from "./types";

const NAV: { id: PageId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "home", label: "হোম", icon: LayoutDashboard },
  { id: "videos", label: "ভিডিও", icon: Film },
  { id: "links", label: "লিংক", icon: Link2 },
  { id: "users", label: "ইউজার", icon: Users },
  { id: "settings", label: "সেটিংস", icon: Settings },
];

const TITLES: Record<PageId, { title: string; sub: string }> = {
  home: { title: "ড্যাশবোর্ড", sub: "লাইভ স্ট্যাটাস" },
  videos: { title: "ভিডিও", sub: "কন্টেন্ট ও ক্যাটাগরি" },
  links: { title: "লিংক / টাস্ক", sub: "আনলক লিংক ম্যানেজ" },
  users: { title: "ইউজার", sub: "ক্রেডিট ও রেফার" },
  settings: { title: "সেটিংস", sub: "অ্যাডস, পাসওয়ার্ড, অ্যাপ" },
};

export function AdminApp() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);

  useEffect(() => {
    setAuthed(isLoggedIn());
    setReady(true);
  }, []);

  if (!ready) return <Splash />;
  if (!authed) return <LoginScreen onOk={() => setAuthed(true)} />;
  return (
    <Shell
      onLogout={() => {
        setLoggedIn(false);
        setAuthed(false);
      }}
    />
  );
}

function Splash() {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-bg">
      <div className="flex flex-col items-center gap-3">
        <Mark />
        <p className="text-sm text-muted">Viral Zone</p>
      </div>
    </div>
  );
}

function Mark({ size = "md" }: { size?: "sm" | "md" }) {
  return (
    <div
      className={cn(
        "flex items-center justify-center rounded-2xl bg-accent font-display font-semibold text-accent-fg",
        size === "md" ? "size-14 text-xl" : "size-9 text-sm rounded-xl",
      )}
    >
      VZ
    </div>
  );
}

function LoginScreen({ onOk }: { onOk: () => void }) {
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      const snap = await get(ref(getDb(), "settings"));
      const settings = (snap.val() || {}) as AppSettings;
      const real = settings.admin_password || DEFAULT_PASS;
      if (pass === real) {
        setLoggedIn(true);
        onOk();
      } else setErr("পাসওয়ার্ড ভুল।");
    } catch {
      setErr("সার্ভারে কানেক্ট করা যায়নি।");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-dvh items-center justify-center bg-bg px-5">
      <form
        onSubmit={submit}
        className="w-full max-w-[400px] rounded-3xl border border-border bg-surface p-7"
      >
        <div className="mb-6 flex flex-col items-center text-center">
          <Mark />
          <h1 className="mt-4 font-display text-xl font-semibold tracking-tight">
            Viral Zone
          </h1>
          <p className="mt-1 text-sm text-muted">অ্যাডমিন প্যানেল</p>
        </div>
        <p className="mb-4 rounded-2xl bg-elevated px-3.5 py-3 text-xs leading-relaxed text-muted">
          একবার লগইন করলে এই ফোনে সেভ থাকবে। ফোন লক করলেও অ্যাপ আবার পাসওয়ার্ড
          চাইবে না।
        </p>
        {err ? <p className="mb-3 text-sm text-danger">{err}</p> : null}
        <Label htmlFor="adminPass">অ্যাডমিন পাসওয়ার্ড</Label>
        <Input
          id="adminPass"
          type="password"
          autoComplete="current-password"
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          className="mt-1.5"
          placeholder="পাসওয়ার্ড লিখুন"
        />
        <Button type="submit" className="mt-4 w-full" disabled={busy}>
          {busy ? "চেক হচ্ছে…" : "লগইন"}
        </Button>
        <p className="mt-4 text-center text-xs text-subtle">
          ডিফল্ট পাসওয়ার্ড <span className="text-muted">admin123</span>
        </p>
      </form>
    </div>
  );
}

function Shell({ onLogout }: { onLogout: () => void }) {
  const [page, setPage] = useState<PageId>("home");
  const [videoTab, setVideoTab] = useState<"list" | "cats">("list");
  const [settings, setSettings] = useState<AppSettings>({});
  const [videos, setVideos] = useState<Record<string, Video>>({});
  const [filters, setFilters] = useState<Record<string, Filter>>({});
  const [links, setLinks] = useState<Record<string, LinkItem>>({});
  const [users, setUsers] = useState<Record<string, User>>({});
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const db = getDb();
    const unsubs = [
      onValue(ref(db, "settings"), (s) => {
        setSettings((s.val() || {}) as AppSettings);
        setConnected(true);
      }),
      onValue(ref(db, "videos"), (s) => setVideos((s.val() || {}) as Record<string, Video>)),
      onValue(ref(db, "filters"), (s) => setFilters((s.val() || {}) as Record<string, Filter>)),
      onValue(ref(db, "links"), (s) => setLinks((s.val() || {}) as Record<string, LinkItem>)),
      onValue(ref(db, "users"), (s) => setUsers((s.val() || {}) as Record<string, User>)),
    ];
    return () => unsubs.forEach((u) => u());
  }, []);

  const meta = TITLES[page];

  return (
    <div className="flex min-h-dvh bg-bg">
      <aside className="hidden w-[220px] shrink-0 flex-col border-r border-border bg-surface md:flex">
        <div className="flex items-center gap-2.5 px-4 py-5">
          <Mark size="sm" />
          <div>
            <div className="font-display text-sm font-semibold leading-none">Viral Zone</div>
            <div className="mt-1 text-[11px] text-muted">Admin</div>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-0.5 px-2">
          {NAV.map((item) => (
            <NavBtn
              key={item.id}
              item={item}
              active={page === item.id}
              onClick={() => setPage(item.id)}
            />
          ))}
        </nav>
        <div className="border-t border-border p-2">
          <button
            type="button"
            onClick={onLogout}
            className="flex h-11 w-full items-center gap-2.5 rounded-xl px-3 text-sm text-muted hover:bg-hover hover:text-fg"
          >
            <LogOut className="size-4" />
            লগআউট
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 backdrop-blur-sm md:h-16 md:px-6">
          <div className="min-w-0">
            <h1 className="truncate font-display text-base font-semibold tracking-tight md:text-lg">
              {meta.title}
            </h1>
            <p className="hidden text-xs text-muted md:block">{meta.sub}</p>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className={cn(
                "hidden rounded-full px-2 py-0.5 text-[10px] font-medium md:inline",
                connected ? "bg-ok-soft text-ok" : "bg-hover text-muted",
              )}
            >
              {connected ? "লাইভ" : "কানেক্ট…"}
            </span>
            <Button
              variant="ghost"
              size="icon-sm"
              aria-label="রিফ্রেশ"
              onClick={() => toast("ডেটা আপডেট হচ্ছে")}
            >
              <RefreshCw className="size-4" />
            </Button>
          </div>
        </header>

        <main className="flex-1 px-4 pb-[calc(5.5rem+env(safe-area-inset-bottom))] pt-5 md:px-6 md:pb-10">
          {page === "home" && (
            <Dashboard
              videos={videos}
              users={users}
              filters={filters}
              links={links}
              settings={settings}
              go={setPage}
            />
          )}
          {page === "videos" && (
            <VideosPage
              tab={videoTab}
              setTab={setVideoTab}
              videos={videos}
              filters={filters}
            />
          )}
          {page === "links" && <LinksPage links={links} />}
          {page === "users" && <UsersPage users={users} />}
          {page === "settings" && (
            <SettingsPage settings={settings} onLogout={onLogout} />
          )}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm md:hidden">
        <div className="grid grid-cols-5">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = page === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setPage(item.id)}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium",
                  active ? "text-accent" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
      <Toaster
        theme="dark"
        position="bottom-center"
        toastOptions={{
          className: "!bg-elevated !text-fg !border-border !font-[Hind_Siliguri]",
        }}
      />
    </div>
  );
}

function NavBtn({
  item,
  active,
  onClick,
}: {
  item: (typeof NAV)[number];
  active: boolean;
  onClick: () => void;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-11 items-center gap-2.5 rounded-xl px-3 text-sm font-medium",
        active ? "bg-accent text-accent-fg" : "text-muted hover:bg-hover hover:text-fg",
      )}
    >
      <Icon className="size-4" />
      {item.label}
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-4">
      <div className="text-xs font-medium text-muted">{label}</div>
      <div className="mt-1 font-display text-2xl font-semibold tabular-nums tracking-tight">
        {value}
      </div>
    </div>
  );
}

function Dashboard({
  videos,
  users,
  filters,
  links,
  settings,
  go,
}: {
  videos: Record<string, Video>;
  users: Record<string, User>;
  filters: Record<string, Filter>;
  links: Record<string, LinkItem>;
  settings: AppSettings;
  go: (p: PageId) => void;
}) {
  const vidList = Object.entries(videos);
  const userList = Object.entries(users);
  const totalViews = vidList.reduce((a, [, v]) => a + (Number(v.view_count) || 0), 0);
  const totalRefers = userList.reduce((a, [, u]) => a + (Number(u.total_refers) || 0), 0);
  const appId = String(settings.bengal_ads_app_id || "");
  const fmtId = String(settings.bengal_ads_format_id || "");
  const adsOk = /^tma_[a-f0-9]{40}$/.test(appId) && /^int_[a-f0-9]{40}$/.test(fmtId);
  const top = vidList
    .map(([id, v]) => ({ id, ...v }))
    .sort((a, b) => (Number(b.view_count) || 0) - (Number(a.view_count) || 0))
    .slice(0, 6);

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Stat label="ভিডিও" value={vidList.length} />
        <Stat label="ইউজার" value={userList.length} />
        <Stat label="ক্যাটাগরি" value={Object.keys(filters).length} />
        <Stat label="লিংক" value={Object.keys(links).length} />
        <Stat label="মোট ভিউ" value={formatNum(totalViews)} />
        <Stat label="রেফার" value={formatNum(totalRefers)} />
      </div>

      <section className="rounded-2xl border border-border bg-surface p-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold">BengalAds</h2>
          <Button variant="ghost" size="sm" onClick={() => go("settings")}>
            সেটিংস
          </Button>
        </div>
        {adsOk ? (
          <p className="text-sm text-ok">কনফিগারড · অ্যাপ ও ফরম্যাট আইডি সেট আছে</p>
        ) : (
          <p className="text-sm text-danger">এখনো সেট করা হয়নি</p>
        )}
      </section>

      <section className="rounded-2xl border border-border bg-surface p-4">
        <div className="mb-3 flex items-center gap-2">
          <BarChart3 className="size-4 text-muted" />
          <h2 className="text-sm font-semibold">টপ ভিউড</h2>
        </div>
        {top.length === 0 ? (
          <Empty text="কোনো ভিডিও নেই" />
        ) : (
          <ul className="divide-y divide-border">
            {top.map((v, i) => (
              <li key={v.id} className="flex items-center gap-3 py-2.5">
                <span className="w-6 text-xs tabular-nums text-subtle">{i + 1}</span>
                <span className="min-w-0 flex-1 truncate text-sm">{v.name || v.id}</span>
                <span className="text-xs tabular-nums text-muted">
                  {formatNum(v.view_count || 0)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <p className="py-10 text-center text-sm text-muted">{text}</p>
  );
}

function VideosPage({
  tab,
  setTab,
  videos,
  filters,
}: {
  tab: "list" | "cats";
  setTab: (t: "list" | "cats") => void;
  videos: Record<string, Video>;
  filters: Record<string, Filter>;
}) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [catOpen, setCatOpen] = useState(false);
  const [catEdit, setCatEdit] = useState<string | null>(null);

  const list = useMemo(() => {
    const qq = q.toLowerCase();
    return Object.entries(videos)
      .map(([id, v]) => ({ id, ...v }))
      .filter((v) => !qq || String(v.name || "").toLowerCase().includes(qq))
      .sort((a, b) => (Number(b.created_at) || 0) - (Number(a.created_at) || 0));
  }, [videos, q]);

  const catName = useCallback(
    (cid?: string) => {
      if (!cid) return "—";
      const f = Object.values(filters).find((x) => (x.id || "") === cid);
      return f?.name || cid;
    },
    [filters],
  );

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-4 flex items-center gap-1 rounded-2xl bg-elevated p-1">
        <button
          type="button"
          onClick={() => setTab("list")}
          className={cn(
            "h-9 flex-1 rounded-xl text-sm font-medium",
            tab === "list" ? "bg-surface text-fg shadow-sm" : "text-muted",
          )}
        >
          ভিডিও
        </button>
        <button
          type="button"
          onClick={() => setTab("cats")}
          className={cn(
            "h-9 flex-1 rounded-xl text-sm font-medium",
            tab === "cats" ? "bg-surface text-fg shadow-sm" : "text-muted",
          )}
        >
          ক্যাটাগরি
        </button>
      </div>

      {tab === "list" ? (
        <>
          <div className="mb-4 flex gap-2">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="ভিডিও সার্চ…"
                className="pl-9"
              />
            </div>
            <Button
              onClick={() => {
                setEditId(null);
                setOpen(true);
              }}
            >
              <Plus className="size-4" />
              নতুন
            </Button>
          </div>
          {list.length === 0 ? (
            <Empty text="কোনো ভিডিও নেই" />
          ) : (
            <ul className="space-y-2">
              {list.map((v) => (
                <li
                  key={v.id}
                  className="flex items-center gap-3 rounded-2xl border border-border bg-surface p-3"
                >
                  {v.image_url ? (
                    <img
                      src={v.image_url}
                      alt=""
                      className="size-14 rounded-xl object-cover"
                    />
                  ) : (
                    <div className="flex size-14 items-center justify-center rounded-xl bg-elevated text-subtle">
                      <Film className="size-5" />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{v.name}</div>
                    <div className="mt-0.5 flex flex-wrap gap-2 text-[11px] text-muted">
                      <span>{catName(v.category)}</span>
                      <span>· {v.ad_watches_required || 1} ধাপ</span>
                      <span className="tabular-nums">· {formatNum(v.view_count || 0)} ভিউ</span>
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label="এডিট"
                      onClick={() => {
                        setEditId(v.id);
                        setOpen(true);
                      }}
                    >
                      <Pencil className="size-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label="ডিলিট"
                      onClick={async () => {
                        if (!window.confirm("এই ভিডিও ডিলিট করবেন?")) return;
                        try {
                          await remove(ref(getDb(), "videos/" + v.id));
                          toast("ডিলিট হয়েছে");
                        } catch {
                          toast.error("ডিলিট ব্যর্থ");
                        }
                      }}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <VideoDialog
            open={open}
            onOpenChange={setOpen}
            editId={editId}
            videos={videos}
            filters={filters}
          />
        </>
      ) : (
        <>
          <div className="mb-4 flex justify-end">
            <Button
              onClick={() => {
                setCatEdit(null);
                setCatOpen(true);
              }}
            >
              <Plus className="size-4" />
              ক্যাটাগরি
            </Button>
          </div>
          {Object.keys(filters).length === 0 ? (
            <Empty text="কোনো ক্যাটাগরি নেই" />
          ) : (
            <ul className="space-y-2">
              {Object.entries(filters).map(([key, f]) => {
                const fid = f.id || key;
                const count = Object.values(videos).filter((v) => v.category === fid).length;
                return (
                  <li
                    key={key}
                    className="flex items-center gap-3 rounded-2xl border border-border bg-surface px-4 py-3"
                  >
                    <FolderOpen className="size-4 text-muted" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium">{f.name}</div>
                      <div className="text-[11px] text-muted">
                        {fid} · {count} ভিডিও
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => {
                        setCatEdit(key);
                        setCatOpen(true);
                      }}
                    >
                      <Pencil className="size-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={async () => {
                        if (!window.confirm("ক্যাটাগরি ডিলিট?")) return;
                        try {
                          await remove(ref(getDb(), "filters/" + key));
                          toast("ডিলিট");
                        } catch {
                          toast.error("ব্যর্থ");
                        }
                      }}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
          <CategoryDialog
            open={catOpen}
            onOpenChange={setCatOpen}
            editKey={catEdit}
            filters={filters}
          />
        </>
      )}
    </div>
  );
}

function VideoDialog({
  open,
  onOpenChange,
  editId,
  videos,
  filters,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editId: string | null;
  videos: Record<string, Video>;
  filters: Record<string, Filter>;
}) {
  const [name, setName] = useState("");
  const [image, setImage] = useState("");
  const [download, setDownload] = useState("");
  const [category, setCategory] = useState("");
  const [adReq, setAdReq] = useState("1");
  const [duration, setDuration] = useState("");
  const [views, setViews] = useState("0");
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!open) return;
    const v = editId ? videos[editId] : undefined;
    setName(v?.name || "");
    setImage(v?.image_url || "");
    setDownload(v?.download_link || "");
    setCategory(v?.category || "");
    setAdReq(String(v?.ad_watches_required || 1));
    setDuration(String(v?.duration ?? v?.duration_sec ?? ""));
    setViews(String(v?.view_count || 0));
  }, [open, editId, videos]);

  async function onFile(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("শুধু ইমেজ");
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("key", IMGBB_API_KEY);
      fd.append("image", file);
      const res = await fetch(IMGBB_UPLOAD_URL, { method: "POST", body: fd });
      const json = await res.json();
      if (json.success && json.data?.url) {
        setImage(json.data.url);
        toast("থাম্বনেইল আপলোড হয়েছে");
      } else throw new Error(json.error?.message || "fail");
    } catch {
      toast.error("আপলোড ব্যর্থ");
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    if (!name.trim() || !image.trim() || !download.trim()) {
      toast.error("নাম, ইমেজ ও ডাউনলোড লিংক আবশ্যক");
      return;
    }
    const data: Video = {
      name: name.trim(),
      image_url: image.trim(),
      download_link: download.trim(),
      category: category || "",
      ad_watches_required: Math.max(1, parseInt(adReq, 10) || 1),
      duration: duration.trim(),
      view_count: Math.max(0, parseInt(views, 10) || 0),
    };
    try {
      if (editId) {
        const prev = videos[editId] || {};
        await update(ref(getDb(), "videos/" + editId), {
          ...data,
          created_at: prev.created_at || Date.now(),
        });
        toast("ভিডিও আপডেট হয়েছে");
      } else {
        await push(ref(getDb(), "videos"), { ...data, created_at: Date.now() });
        toast("নতুন ভিডিও যোগ হয়েছে");
      }
      onOpenChange(false);
    } catch {
      toast.error("সেভ ব্যর্থ");
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{editId ? "ভিডিও এডিট" : "নতুন ভিডিও"}</DialogTitle>
          <DialogDescription>থাম্বনেইল আপলোড বা URL দিন।</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <Field label="নাম">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="থাম্বনেইল URL">
            <Input value={image} onChange={(e) => setImage(e.target.value)} />
          </Field>
          {image ? (
            <img src={image} alt="" className="h-28 w-full rounded-xl object-cover" />
          ) : null}
          <label className="flex h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-border bg-elevated text-sm text-muted">
            <Upload className="size-4" />
            {uploading ? "আপলোড হচ্ছে…" : "ছবি আপলোড"}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => onFile(e.target.files?.[0])}
            />
          </label>
          <Field label="ডাউনলোড লিংক">
            <Input value={download} onChange={(e) => setDownload(e.target.value)} />
          </Field>
          <Field label="ক্যাটাগরি">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="flex h-11 w-full rounded-xl border border-border bg-elevated px-3.5 text-sm text-fg"
            >
              <option value="">— সিলেক্ট —</option>
              {Object.entries(filters).map(([key, f]) => (
                <option key={key} value={f.id || key}>
                  {f.name || f.id || key}
                </option>
              ))}
            </select>
          </Field>
          <div className="grid grid-cols-3 gap-2">
            <Field label="ধাপ">
              <Input type="number" min={1} max={20} value={adReq} onChange={(e) => setAdReq(e.target.value)} />
            </Field>
            <Field label="দৈর্ঘ্য">
              <Input value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="3:45" />
            </Field>
            <Field label="ভিউ">
              <Input type="number" min={0} value={views} onChange={(e) => setViews(e.target.value)} />
            </Field>
          </div>
          <Button onClick={save} className="mt-1">
            সেভ করুন
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CategoryDialog({
  open,
  onOpenChange,
  editKey,
  filters,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editKey: string | null;
  filters: Record<string, Filter>;
}) {
  const [id, setId] = useState("");
  const [name, setName] = useState("");

  useEffect(() => {
    if (!open) return;
    const f = editKey ? filters[editKey] : undefined;
    setId(f?.id || editKey || "");
    setName(f?.name || "");
  }, [open, editKey, filters]);

  async function save() {
    const nid = id.trim().replace(/\s+/g, "_").toLowerCase();
    const nname = name.trim();
    if (!nid || !nname) {
      toast.error("আইডি ও নাম আবশ্যক");
      return;
    }
    try {
      if (editKey) await update(ref(getDb(), "filters/" + editKey), { id: nid, name: nname });
      else await push(ref(getDb(), "filters"), { id: nid, name: nname });
      toast("সেভ হয়েছে");
      onOpenChange(false);
    } catch {
      toast.error("সেভ ব্যর্থ");
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{editKey ? "ক্যাটাগরি এডিট" : "নতুন ক্যাটাগরি"}</DialogTitle>
        </DialogHeader>
        <Field label="আইডি">
          <Input value={id} onChange={(e) => setId(e.target.value)} disabled={!!editKey} />
        </Field>
        <Field label="ডিসপ্লে নাম">
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Button onClick={save}>সেভ</Button>
      </DialogContent>
    </Dialog>
  );
}

function LinksPage({ links }: { links: Record<string, LinkItem> }) {
  const [open, setOpen] = useState(false);
  const [editKey, setEditKey] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");

  function start(key: string | null) {
    const l = key ? links[key] : undefined;
    setEditKey(key);
    setTitle(l?.title || "");
    setUrl(l?.url || "");
    setOpen(true);
  }

  async function save() {
    if (!title.trim() || !url.trim()) {
      toast.error("টাইটেল ও URL আবশ্যক");
      return;
    }
    try {
      if (editKey) await update(ref(getDb(), "links/" + editKey), { title: title.trim(), url: url.trim() });
      else await push(ref(getDb(), "links"), { title: title.trim(), url: url.trim() });
      toast("সেভ হয়েছে");
      setOpen(false);
    } catch {
      toast.error("সেভ ব্যর্থ");
    }
  }

  const list = Object.entries(links);

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-4 flex justify-end">
        <Button onClick={() => start(null)}>
          <Plus className="size-4" />
          নতুন লিংক
        </Button>
      </div>
      {list.length === 0 ? (
        <Empty text="কোনো লিংক নেই" />
      ) : (
        <ul className="space-y-2">
          {list.map(([key, l]) => (
            <li
              key={key}
              className="flex items-center gap-3 rounded-2xl border border-border bg-surface px-4 py-3"
            >
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium">{l.title}</div>
                <div className="truncate font-mono text-[11px] text-muted">{l.url}</div>
              </div>
              <Button variant="ghost" size="icon-sm" onClick={() => start(key)}>
                <Pencil className="size-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={async () => {
                  if (!window.confirm("লিংক ডিলিট?")) return;
                  try {
                    await remove(ref(getDb(), "links/" + key));
                    toast("ডিলিট");
                  } catch {
                    toast.error("ব্যর্থ");
                  }
                }}
              >
                <Trash2 className="size-4" />
              </Button>
            </li>
          ))}
        </ul>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editKey ? "লিংক এডিট" : "নতুন লিংক"}</DialogTitle>
          </DialogHeader>
          <Field label="টাইটেল">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} />
          </Field>
          <Field label="URL">
            <Input value={url} onChange={(e) => setUrl(e.target.value)} />
          </Field>
          <Button onClick={save}>সেভ</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function UsersPage({ users }: { users: Record<string, User> }) {
  const [q, setQ] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [credits, setCredits] = useState("0");

  const list = useMemo(() => {
    const qq = q.toLowerCase();
    return Object.entries(users)
      .map(([id, u]) => ({ id, ...u }))
      .filter(
        (u) =>
          !qq ||
          String(u.first_name || "").toLowerCase().includes(qq) ||
          String(u.id).includes(qq),
      )
      .sort((a, b) => (Number(b.total_refers) || 0) - (Number(a.total_refers) || 0))
      .slice(0, 200);
  }, [users, q]);

  async function saveCredits() {
    if (!editId) return;
    const n = parseInt(credits, 10);
    if (isNaN(n) || n < 0) {
      toast.error("সঠিক সংখ্যা দিন");
      return;
    }
    try {
      await update(ref(getDb(), "users/" + editId), { unlock_credits: n });
      toast("ক্রেডিট আপডেট: " + n);
      setEditId(null);
    } catch {
      toast.error("ব্যর্থ");
    }
  }

  return (
    <div className="mx-auto max-w-5xl">
      <div className="relative mb-4">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="নাম বা ID…"
          className="pl-9"
        />
      </div>
      {list.length === 0 ? (
        <Empty text="কোনো ইউজার নেই" />
      ) : (
        <ul className="space-y-2">
          {list.map((u) => (
            <li
              key={u.id}
              className="flex items-center gap-3 rounded-2xl border border-border bg-surface px-4 py-3"
            >
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium">{u.first_name || "User"}</div>
                <div className="truncate font-mono text-[11px] text-muted">{u.id}</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold tabular-nums text-accent">
                  {Number(u.unlock_credits) || 0}
                </div>
                <div className="text-[11px] text-muted">
                  {Number(u.total_refers) || 0} রেফার · {Number(u.total_unlocked) || 0} আনলক
                </div>
              </div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  setEditId(String(u.id));
                  setCredits(String(Number(u.unlock_credits) || 0));
                }}
              >
                ক্রেডিট
              </Button>
            </li>
          ))}
        </ul>
      )}
      <Dialog open={!!editId} onOpenChange={(v) => !v && setEditId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ক্রেডিট আপডেট</DialogTitle>
            <DialogDescription className="font-mono">{editId}</DialogDescription>
          </DialogHeader>
          <Field label="নতুন ক্রেডিট">
            <Input type="number" min={0} value={credits} onChange={(e) => setCredits(e.target.value)} />
          </Field>
          <Button onClick={saveCredits}>সেভ</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SettingsPage({
  settings,
  onLogout,
}: {
  settings: AppSettings;
  onLogout: () => void;
}) {
  const [appId, setAppId] = useState("");
  const [formatId, setFormatId] = useState("");
  const [adsLimit, setAdsLimit] = useState("20");
  const [bot, setBot] = useState("");
  const [tutorial, setTutorial] = useState("");
  const [p1, setP1] = useState("");
  const [p2, setP2] = useState("");

  useEffect(() => {
    setAppId(String(settings.bengal_ads_app_id || ""));
    setFormatId(String(settings.bengal_ads_format_id || ""));
    setAdsLimit(String(settings.ads_limit ?? 20));
    setBot(String(settings.bot_app_link || ""));
    setTutorial(String(settings.tutorial_id || ""));
  }, [settings]);

  async function save() {
    if (appId && !/^tma_[a-f0-9]{40}$/.test(appId)) {
      toast.error("App ID ফরম্যাট ভুল");
      return;
    }
    if (formatId && !/^int_[a-f0-9]{40}$/.test(formatId)) {
      toast.error("Format ID ফরম্যাট ভুল");
      return;
    }
    if (p1 || p2) {
      if (p1 !== p2) {
        toast.error("পাসওয়ার্ড মিলছে না");
        return;
      }
      if (p1.length < 4) {
        toast.error("কমপক্ষে ৪ অক্ষর");
        return;
      }
    }
    const payload: AppSettings = {
      ...settings,
      bengal_ads_app_id: appId.trim(),
      bengal_ads_format_id: formatId.trim(),
      ads_limit: Math.max(1, parseInt(adsLimit, 10) || 20),
      bot_app_link: bot.trim(),
      tutorial_id: tutorial.trim(),
    };
    if (p1) payload.admin_password = p1;
    try {
      await set(ref(getDb(), "settings"), payload);
      await set(ref(getDb(), "ads_config"), {
        bengal_ads_app_id: appId.trim(),
        bengal_ads_format_id: formatId.trim(),
      });
      toast("সেটিংস সেভ হয়েছে");
      setP1("");
      setP2("");
    } catch {
      toast.error("সেভ ব্যর্থ");
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <section className="rounded-2xl border border-border bg-surface p-4">
        <div className="mb-3 flex items-center gap-2">
          <Shield className="size-4 text-muted" />
          <h2 className="text-sm font-semibold">সেশন</h2>
        </div>
        <p className="text-sm leading-relaxed text-muted">
          লগইন এই ফোনে সেভ থাকে। ফোন লক বা অ্যাপ বন্ধ করে আবার খুললে পাসওয়ার্ড
          চাইবে না — শুধু লগআউট করলেই নতুন করে লগইন লাগবে।
        </p>
      </section>

      <section className="rounded-2xl border border-border bg-surface p-4 space-y-3">
        <h2 className="text-sm font-semibold">BengalAds</h2>
        <Field label="bengal_ads_app_id">
          <Input value={appId} onChange={(e) => setAppId(e.target.value)} className="font-mono text-xs" />
        </Field>
        <Field label="bengal_ads_format_id">
          <Input value={formatId} onChange={(e) => setFormatId(e.target.value)} className="font-mono text-xs" />
        </Field>
      </section>

      <section className="rounded-2xl border border-border bg-surface p-4 space-y-3">
        <h2 className="text-sm font-semibold">অ্যাপ</h2>
        <Field label="দৈনিক অ্যাড লিমিট">
          <Input type="number" min={1} max={200} value={adsLimit} onChange={(e) => setAdsLimit(e.target.value)} />
        </Field>
        <Field label="বট অ্যাপ লিংক">
          <Input value={bot} onChange={(e) => setBot(e.target.value)} />
        </Field>
        <Field label="টিউটোরিয়াল Embed URL">
          <Input value={tutorial} onChange={(e) => setTutorial(e.target.value)} />
        </Field>
      </section>

      <section className="rounded-2xl border border-border bg-surface p-4 space-y-3">
        <h2 className="text-sm font-semibold">অ্যাডমিন পাসওয়ার্ড</h2>
        <Field label="নতুন পাসওয়ার্ড">
          <Input type="password" value={p1} onChange={(e) => setP1(e.target.value)} />
        </Field>
        <Field label="কনফার্ম">
          <Input type="password" value={p2} onChange={(e) => setP2(e.target.value)} />
        </Field>
      </section>

      <Button onClick={save} className="w-full">
        সব সেটিংস সেভ
      </Button>
      <Button variant="danger" className="w-full" onClick={onLogout}>
        <LogOut className="size-4" />
        লগআউট
      </Button>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid gap-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}


