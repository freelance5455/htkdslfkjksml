import { NextResponse, type NextRequest } from "next/server";

const SESSION_COOKIE = "marvel_squad_session";
const TWO_YEARS = 60 * 60 * 24 * 365 * 2;

/**
 * Allunga la scadenza della sessione a ogni richiesta: finché l'utente usa
 * l'app non viene mai disconnesso.
 */
export function middleware(request: NextRequest) {
  const response = NextResponse.next();
  const current = request.cookies.get(SESSION_COOKIE)?.value;

  if (!current) {
    const legacy = request.cookies.get("marvel_squad_id")?.value;
    if (legacy && /^\d+$/.test(legacy)) {
      response.cookies.set(SESSION_COOKIE, legacy, {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        maxAge: TWO_YEARS,
      });
      return response;
    }
  }

  if (current) {
    response.cookies.set(SESSION_COOKIE, current, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: TWO_YEARS,
    });
  }

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|images|favicon.ico|.*\\.(?:png|jpg|jpeg|svg|webp|ico)$).*)"],
};
