import { recordResult } from './calendar.js';
import { CLUB_CUP_SCHEDULE_RULE, getClubCupThursday, scheduleCompetitionCalendar } from './competition-calendar.js';

export const CLUB_CUP_ID = 'coupe-des-clubs';
export const CLUB_CUP_NAME = 'Coupe des Clubs';

/** Règlement : tous les clubs des 5 divisions, élimination directe type FA Cup. */
const ROUND_LABELS = [
  '1er tour',
  '2e tour',
  '3e tour',
  'Huitièmes de finale',
  'Quarts de finale',
  'Demi-finales',
  'Finale'
];

function hash(s) {
  let h = 2166136261;
  for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function order(ids, seed) {
  return [...ids].sort((a, b) => hash(`${seed}|${a}`) - hash(`${seed}|${b}`) || a.localeCompare(b));
}
function allActiveClubIds(state) {
  return state.divisions.filter(d => d.status === 'active').flatMap(d => d.clubs.map(c => c.id));
}
function fixture(state, round, home, away, i) {
  const scheduledDate = getClubCupThursday(state, round);
  return {
    id: `S${state.season}:${CLUB_CUP_ID}:R${round}:${i}:${home}:${away}`,
    season: state.season,
    divisionId: null,
    competitionId: CLUB_CUP_ID,
    competitionName: CLUB_CUP_NAME,
    round,
    roundLabel: ROUND_LABELS[Math.min(round - 1, ROUND_LABELS.length - 1)],
    scheduleRule: CLUB_CUP_SCHEDULE_RULE,
    scheduledWeekday: 'jeudi',
    scheduledDate,
    dateStatus: scheduledDate ? 'official-date-assigned' : 'awaiting-official-lunar-calendar',
    home,
    away,
    venueType: 'home-away',
    status: 'scheduled',
    score: null,
    playedAt: null,
    arenaId: 'terrestrial'
  };
}

export function createClubCupSeason(state) {
  const cup = state.competitions.find(c => c.id === CLUB_CUP_ID);
  if (!cup) throw new Error('Coupe des Clubs absente du registre');
  if (cup.season === state.season && cup.status !== 'pending') return [];
  const entrants = allActiveClubIds(state);
  if (entrants.length < 2) throw new Error('La Coupe des Clubs exige au moins deux clubs actifs');
  cup.season = state.season;
  cup.status = 'in-progress';
  cup.format = {
    type: 'knockout-all-clubs',
    entrants: entrants.length,
    legs: 1,
    extraTime: true,
    penalties: true,
    schedule: CLUB_CUP_SCHEDULE_RULE,
    source: 'reglement-officiel-tous-les-clubs'
  };
  cup.championId = null;
  cup.rounds = [];
  cup.fixtures = [];
  return createRound(state, cup, entrants, 1);
}

function createRound(state, cup, qualified, round) {
  let entrants = order([...qualified], `CGD|${state.season}|${CLUB_CUP_ID}|R${round}`);
  const byes = [];
  // Avec un nombre impair, un club reçoit un bye
  if (entrants.length % 2) byes.push(entrants.pop());
  const fixtures = [];
  for (let i = 0; i < entrants.length; i += 2) {
    let home = entrants[i], away = entrants[i + 1];
    if (hash(`${state.season}|${round}|${home}|${away}`) % 2) [home, away] = [away, home];
    fixtures.push(fixture(state, round, home, away, i / 2 + 1));
  }
  const label = ROUND_LABELS[Math.min(round - 1, ROUND_LABELS.length - 1)];
  const r = {
    number: round,
    label,
    participants: [...qualified],
    byes,
    fixtureIds: fixtures.map(f => f.id),
    completed: false,
    advancedClubIds: []
  };
  cup.rounds.push(r);
  cup.fixtures.push(...fixtures.map(f => f.id));
  state.calendar.fixtures.push(...fixtures);
  scheduleCompetitionCalendar(state);
  return fixtures;
}

export function recordClubCupResult(state, id, homeScore, awayScore, { winnerId = null, penalties = null, matchDetails = {} } = {}) {
  const f = state.calendar.fixtures.find(x => x.id === id && x.competitionId === CLUB_CUP_ID);
  if (!f) throw new Error('Rencontre de Coupe des Clubs introuvable');
  if (f.status === 'played') return { accepted: false, nextFixtures: [] };
  if (![homeScore, awayScore].every(n => Number.isInteger(n) && n >= 0)) throw new Error('Score invalide');
  if (homeScore === awayScore && !winnerId) throw new Error('Une égalité doit être départagée après prolongation puis aux tirs au but');
  winnerId ??= homeScore > awayScore ? f.home : f.away;
  if (![f.home, f.away].includes(winnerId)) throw new Error('Vainqueur absent de la rencontre');
  if (homeScore === awayScore && !penalties) throw new Error('Résultat des tirs au but manquant');
  if (!recordResult(state, id, homeScore, awayScore, matchDetails)) return { accepted: false, nextFixtures: [] };
  f.winnerId = winnerId;
  f.penalties = penalties;
  f.matchDetails = { ...matchDetails, winnerId, extraTime: true, penalties };
  const cup = state.competitions.find(c => c.id === CLUB_CUP_ID);
  const r = cup.rounds.find(x => x.fixtureIds.includes(id));
  r.advancedClubIds = [...r.byes, ...r.fixtureIds.map(fid => state.calendar.fixtures.find(x => x.id === fid)?.winnerId).filter(Boolean)];
  if (!r.fixtureIds.every(fid => state.calendar.fixtures.find(x => x.id === fid)?.status === 'played')) {
    return { accepted: true, nextFixtures: [] };
  }
  r.completed = true;
  if (r.advancedClubIds.length === 1) {
    cup.status = 'completed';
    cup.championId = r.advancedClubIds[0];
    cup.completedAtSeason = state.season;
    return { accepted: true, nextFixtures: [] };
  }
  return { accepted: true, nextFixtures: createRound(state, cup, r.advancedClubIds, r.number + 1) };
}

export function getClubCupStatus(state) {
  const cup = state.competitions.find(c => c.id === CLUB_CUP_ID);
  if (!cup) return null;
  const r = cup.rounds?.find(x => !x.completed) || cup.rounds?.at(-1);
  return {
    name: CLUB_CUP_NAME,
    status: cup.status,
    participantCount: cup.format?.entrants ?? 0,
    round: r?.number ?? 0,
    roundLabel: r?.label ?? 'À venir',
    pendingFixtures: r?.fixtureIds?.filter(id => state.calendar.fixtures.find(f => f.id === id)?.status !== 'played').length ?? 0,
    championId: cup.championId ?? null
  };
}

export function validateClubCup(state) {
  const cup = state.competitions.find(c => c.id === CLUB_CUP_ID);
  if (!cup) throw new Error('Coupe des Clubs manquante');
  if (cup.status === 'in-progress' || cup.status === 'completed') {
    if (!cup.rounds?.length) throw new Error('Tableau de Coupe des Clubs incomplet');
    if (new Set(cup.fixtures).size !== cup.fixtures.length) throw new Error('Rencontre dupliquée dans la Coupe des Clubs');
    for (const id of cup.fixtures) {
      if (!state.calendar.fixtures.some(f => f.id === id && f.competitionId === CLUB_CUP_ID)) {
        throw new Error(`Rencontre absente du calendrier central : ${id}`);
      }
    }
  }
  return true;
}
