import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Navbar } from '../components/Navbar.js';
import { Footer } from '../components/Footer.js';
import { Logo } from '../components/Logo.js';
import { SupportTicket, SystemNotification } from '../types.js';
import {
  ShieldAlert,
  KeyRound,
  Lock,
  Users,
  MessageSquare,
  HelpCircle,
  Bell,
  Send,
  CheckCircle2,
  Clock,
  Search,
  RefreshCw,
  LogOut,
  Mail,
  User as UserIcon,
  MessageCircle,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface AdminUserRecord {
  id: string;
  name: string;
  email: string;
  emailVerified: boolean;
  createdAt: string;
  conversationCount: number;
  messageCount: number;
  photoURL?: string;
}

export const AdminPanelPage: React.FC = () => {
  const { setCurrentPage } = useAuth();
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('aipc_admin_auth') === 'true';
  });
  const [loginError, setLoginError] = useState<string | null>(null);

  // Admin Data State
  const [activeTab, setActiveTab] = useState<'feedback' | 'users' | 'notifications'>('feedback');
  const [users, setUsers] = useState<AdminUserRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Filters & Search
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [ticketFilter, setTicketFilter] = useState<'all' | 'pending' | 'replied'>('all');

  // Reply state
  const [replyInputs, setReplyInputs] = useState<Record<string, string>>({});
  const [sendingReplyTicketId, setSendingReplyTicketId] = useState<string | null>(null);

  // Notification broadcast form
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifTargetUserId, setNotifTargetUserId] = useState('');
  const [sendingNotif, setSendingNotif] = useState(false);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasswordInput.trim() === 'ALIOWNERHA') {
      setIsAdminAuthenticated(true);
      localStorage.setItem('aipc_admin_auth', 'true');
      setLoginError(null);
    } else {
      setLoginError('Incorrect Admin Password. Please try again.');
    }
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('aipc_admin_auth');
    setAdminPasswordInput('');
  };

  const fetchAdminData = async () => {
    if (!isAdminAuthenticated) return;
    setLoadingData(true);
    try {
      // Fetch Users
      const resUsers = await fetch('/api/admin/users', {
        headers: { 'X-Admin-Password': 'ALIOWNERHA' },
      });
      if (resUsers.ok) {
        const dataUsers = await resUsers.json();
        setUsers(dataUsers.users || []);
      }

      // Fetch Support Tickets
      const resTickets = await fetch('/api/admin/feedback', {
        headers: { 'X-Admin-Password': 'ALIOWNERHA' },
      });
      if (resTickets.ok) {
        const dataTickets = await resTickets.json();
        setTickets(dataTickets.tickets || []);
      }

      // Fetch Notifications
      const resNotifs = await fetch('/api/admin/notifications', {
        headers: { 'X-Admin-Password': 'ALIOWNERHA' },
      });
      if (resNotifs.ok) {
        const dataNotifs = await resNotifs.json();
        setNotifications(dataNotifs.notifications || []);
      }
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    if (isAdminAuthenticated) {
      fetchAdminData();
    }
  }, [isAdminAuthenticated]);

  const handleSendReply = async (ticketId: string) => {
    const replyMsg = replyInputs[ticketId];
    if (!replyMsg || !replyMsg.trim()) return;

    setSendingReplyTicketId(ticketId);
    try {
      const res = await fetch('/api/admin/feedback/reply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Password': 'ALIOWNERHA',
        },
        body: JSON.stringify({ ticketId, replyMessage: replyMsg.trim() }),
      });

      if (res.ok) {
        const data = await res.json();
        setActionSuccess(`Reply sent to ${data.ticket?.userName || 'user'}!`);
        setReplyInputs(prev => ({ ...prev, [ticketId]: '' }));
        // Refresh tickets
        fetchAdminData();
        setTimeout(() => setActionSuccess(null), 4000);
      } else {
        const err = await res.json();
        alert(err.error || 'Failed to send reply.');
      }
    } catch (err) {
      console.error('Reply error:', err);
      alert('Network error sending reply.');
    } finally {
      setSendingReplyTicketId(null);
    }
  };

  const handleBroadcastNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifMessage.trim()) return;

    setSendingNotif(true);
    try {
      const res = await fetch('/api/admin/notifications/broadcast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Password': 'ALIOWNERHA',
        },
        body: JSON.stringify({
          title: notifTitle.trim(),
          message: notifMessage.trim(),
          targetUserId: notifTargetUserId.trim() || undefined,
        }),
      });

      if (res.ok) {
        setActionSuccess('Notification dispatched successfully!');
        setNotifTitle('');
        setNotifMessage('');
        setNotifTargetUserId('');
        fetchAdminData();
        setTimeout(() => setActionSuccess(null), 4000);
      }
    } catch (err) {
      console.error('Notif broadcast error:', err);
    } finally {
      setSendingNotif(false);
    }
  };

  // 1. Password Lock View
  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col justify-between bg-slate-950 text-white select-none">
        <Navbar />

        <main className="flex-1 flex items-center justify-center p-4">
          <div className="w-full max-w-md p-6 sm:p-8 rounded-3xl border border-slate-800 bg-slate-900 shadow-2xl space-y-6 text-center animate-in fade-in zoom-in-95">
            <div className="w-16 h-16 rounded-2xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center mx-auto shadow-inner">
              <ShieldAlert className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h1 className="text-2xl font-extrabold text-white">Admin Panel Access</h1>
              <p className="text-xs text-slate-400">
                Please enter the master admin password to access owner dashboard controls.
              </p>
            </div>

            {loginError && (
              <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-900 text-rose-300 text-xs flex items-center gap-2 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Master Password</span>
                </label>
                <input
                  type="password"
                  value={adminPasswordInput}
                  onChange={e => setAdminPasswordInput(e.target.value)}
                  placeholder="Enter admin password..."
                  required
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl border border-slate-700 bg-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition flex items-center justify-center gap-2"
              >
                <Lock className="w-4 h-4" />
                <span>Unlock Owner Admin Panel</span>
              </button>
            </form>

            <div className="pt-2 text-[11px] text-slate-500 font-semibold border-t border-slate-800">
              OWNER NAME: Ali ABDULLAH • BY :- aipocketchat.support@gmail.com
            </div>
          </div>
        </main>

        <Footer compact />
      </div>
    );
  }

  // 2. Authenticated Admin Dashboard View
  const filteredUsers = users.filter(
    u =>
      u.name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearchQuery.toLowerCase())
  );

  const filteredTickets = tickets.filter(t => {
    if (ticketFilter === 'pending') return t.status === 'pending';
    if (ticketFilter === 'replied') return t.status === 'replied';
    return true;
  });

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Navbar />

      <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                Owner Dashboard
              </span>
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Ali ABDULLAH
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              AI Pocket Chat Admin Panel
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Manage accounts, help & support feedback, and broadcast user notifications.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchAdminData}
              disabled={loadingData}
              className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-600 dark:text-slate-300 text-xs font-semibold transition flex items-center gap-1.5"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${loadingData ? 'animate-spin text-indigo-500' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>

            <button
              onClick={handleAdminLogout}
              className="px-4 py-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 text-rose-600 dark:text-rose-300 text-xs font-semibold transition flex items-center gap-1.5"
            >
              <LogOut className="w-4 h-4" />
              <span>Lock Admin</span>
            </button>
          </div>
        </div>

        {actionSuccess && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
            <span className="font-semibold">{actionSuccess}</span>
          </div>
        )}

        {/* Dashboard Stats Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-black text-slate-900 dark:text-white">{users.length}</p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Registered Users</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-black text-slate-900 dark:text-white">
                {tickets.filter(t => t.status === 'pending').length}
              </p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Pending Support Inquiries</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-black text-slate-900 dark:text-white">
                {tickets.filter(t => t.status === 'replied').length}
              </p>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Replied Feedback Tickets</p>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('feedback')}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition shrink-0 ${
              activeTab === 'feedback'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Help, Support & Feedback ({tickets.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition shrink-0 ${
              activeTab === 'users'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>User Accounts ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition shrink-0 ${
              activeTab === 'notifications'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Send Notifications</span>
          </button>
        </div>

        {/* Tab 1: Help & Support Feedback & Reply Option */}
        {activeTab === 'feedback' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  User Support Inquiries & Feedback
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Read user messages and send direct replies. Users will receive your reply immediately.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setTicketFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    ticketFilter === 'all'
                      ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  All ({tickets.length})
                </button>
                <button
                  onClick={() => setTicketFilter('pending')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    ticketFilter === 'pending'
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Pending ({tickets.filter(t => t.status === 'pending').length})
                </button>
                <button
                  onClick={() => setTicketFilter('replied')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    ticketFilter === 'replied'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Replied ({tickets.filter(t => t.status === 'replied').length})
                </button>
              </div>
            </div>

            {filteredTickets.length === 0 ? (
              <div className="p-12 text-center rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
                <HelpCircle className="w-10 h-10 mx-auto text-slate-400 opacity-40" />
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  No support inquiries found in this category.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTickets.map(tkt => (
                  <div
                    key={tkt.id}
                    className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              tkt.status === 'replied'
                                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                            }`}
                          >
                            {tkt.status}
                          </span>
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {tkt.subject}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                          <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                          <span className="font-semibold text-slate-700 dark:text-slate-200">{tkt.userName}</span>
                          <span>•</span>
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          <span className="font-mono text-indigo-600 dark:text-indigo-400">{tkt.userEmail}</span>
                        </p>
                      </div>

                      <span className="text-[11px] text-slate-400 flex items-center gap-1 shrink-0">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{new Date(tkt.createdAt).toLocaleString()}</span>
                      </span>
                    </div>

                    {/* User Message Content */}
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                      <span className="block font-bold text-[10px] uppercase text-slate-400 mb-1">
                        User Message:
                      </span>
                      {tkt.message}
                    </div>

                    {/* Existing Admin Replies */}
                    {tkt.replies && tkt.replies.length > 0 && (
                      <div className="space-y-2 pt-2">
                        <span className="block font-bold text-[11px] uppercase text-emerald-600 dark:text-emerald-400">
                          Previous Admin Replies:
                        </span>
                        {tkt.replies.map(rpl => (
                          <div
                            key={rpl.id}
                            className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/60 dark:border-indigo-900/60 text-xs text-slate-800 dark:text-slate-200 space-y-1"
                          >
                            <div className="flex items-center justify-between text-[10px] font-semibold text-indigo-600 dark:text-indigo-400">
                              <span>Admin Reply (Ali ABDULLAH)</span>
                              <span>{new Date(rpl.createdAt).toLocaleString()}</span>
                            </div>
                            <p className="whitespace-pre-wrap">{rpl.message}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Admin Reply Form */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <Send className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Reply to {tkt.userName}:</span>
                      </label>
                      <textarea
                        rows={3}
                        value={replyInputs[tkt.id] || ''}
                        onChange={e =>
                          setReplyInputs({ ...replyInputs, [tkt.id]: e.target.value })
                        }
                        placeholder="Type your response to this user inquiry..."
                        className="w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                      />
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => handleSendReply(tkt.id)}
                          disabled={!replyInputs[tkt.id]?.trim() || sendingReplyTicketId === tkt.id}
                          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-xs transition flex items-center gap-1.5 shadow-sm"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>{sendingReplyTicketId === tkt.id ? 'Sending...' : 'OK & Reply'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Registered User Accounts */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Registered Accounts</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  View all registered user profiles and activity statistics.
                </p>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={userSearchQuery}
                  onChange={e => setUserSearchQuery(e.target.value)}
                  placeholder="Search user by name or email..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-850 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px] font-bold">
                    <tr>
                      <th className="py-3.5 px-4">User</th>
                      <th className="py-3.5 px-4">Email</th>
                      <th className="py-3.5 px-4">Account ID</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4">Joined</th>
                      <th className="py-3.5 px-4 text-right">Chats / Msgs</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredUsers.map(u => (
                      <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-850/50 transition">
                        <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 font-bold text-xs flex items-center justify-center shrink-0">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                          <span>{u.name}</span>
                        </td>
                        <td className="py-3.5 px-4 font-mono text-slate-600 dark:text-slate-300">{u.email}</td>
                        <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">{u.id}</td>
                        <td className="py-3.5 px-4">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                            Verified
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                        <td className="py-3.5 px-4 text-right font-semibold text-slate-900 dark:text-white">
                          {u.conversationCount} chats ({u.messageCount} msgs)
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Broadcast Notifications */}
        {activeTab === 'notifications' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-4">
              <div className="space-y-1">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Broadcast System Notification</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Send a broadcast update to all active users or target a specific user account.
                </p>
              </div>

              <form onSubmit={handleBroadcastNotification} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Notification Title
                  </label>
                  <input
                    type="text"
                    value={notifTitle}
                    onChange={e => setNotifTitle(e.target.value)}
                    required
                    placeholder="e.g. New Feature Release or Announcement"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Notification Message
                  </label>
                  <textarea
                    rows={4}
                    value={notifMessage}
                    onChange={e => setNotifMessage(e.target.value)}
                    required
                    placeholder="Type the message content..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Target User ID (Optional)
                  </label>
                  <input
                    type="text"
                    value={notifTargetUserId}
                    onChange={e => setNotifTargetUserId(e.target.value)}
                    placeholder="Leave blank for ALL users, or enter user ID"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={sendingNotif}
                  className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md transition flex items-center justify-center gap-2"
                >
                  <Bell className="w-4 h-4" />
                  <span>{sendingNotif ? 'Sending...' : 'Dispatch Notification'}</span>
                </button>
              </form>
            </div>

            <div className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-4">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Notification History</h2>

              {notifications.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">No notifications dispatched yet.</div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                  {notifications.map(n => (
                    <div
                      key={n.id}
                      className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-800 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                        <span>{n.title}</span>
                        <span className="text-[10px] font-normal text-slate-400">
                          {new Date(n.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 text-xs leading-relaxed">{n.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};
