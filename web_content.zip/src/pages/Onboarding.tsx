import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { ExamId, StudentProfile } from '@shared/types';
import { EXAM_LIST } from '@shared/exam';
import { subjectsForExam } from '@shared/syllabus';
import { useAuth } from '../lib/auth';
import { api, ApiError } from '../lib/api';
import { cn, todayISO } from '../lib/utils';
import { Banner, Button, Field, Input, Select, Textarea } from '../components/ui';
import { ArrowLeft, ArrowRight, BookOpenCheck, CalendarClock, GraduationCap, Target } from 'lucide-react';

const STEPS = [
  { title: 'Examination', subtitle: 'What are you preparing for?', icon: Target },
  { title: 'Subjects', subtitle: 'Where you are strong, where you need work', icon: BookOpenCheck },
  { title: 'Your week', subtitle: 'Real hours, real constraints', icon: CalendarClock },
  { title: 'Preparation level', subtitle: 'So teaching starts at the right depth', icon: GraduationCap },
];

export default function Onboarding() {
  const { user, profile, refresh } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const [form, setForm] = useState({
    name: profile?.name || user?.name || '',
    exam: (profile?.exam || 'cbse10') as ExamId,
    classLevel: profile?.classLevel || '10',
    board: profile?.board || 'CBSE',
    examDate: profile?.examDate || '',
    targetScore: profile?.targetScore || '',
    subjects: profile?.subjects || [] as string[],
    weakSubjects: profile?.weakSubjects || [] as string[],
    strongSubjects: profile?.strongSubjects || [] as string[],
    dailyHours: profile?.dailyHours ?? 3,
    schoolStart: profile?.schoolStart || '07:30',
    schoolEnd: profile?.schoolEnd || '14:00',
    coachingStart: profile?.coachingStart || '',
    coachingEnd: profile?.coachingEnd || '',
    sleepAt: profile?.sleepAt || '23:00',
    wakeAt: profile?.wakeAt || '06:30',
    preferredStart: profile?.preferredStart || '17:00',
    preferredEnd: profile?.preferredEnd || '21:00',
    commitments: profile?.commitments || '',
    currentPerformance: profile?.currentPerformance || '',
    learningStyle: profile?.learningStyle || 'Step-by-step explanations with worked examples',
  });

  const examSubjects = useMemo(() => subjectsForExam(form.exam, form.classLevel), [form.exam, form.classLevel]);

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }));

  const chooseExam = (exam: ExamId) => {
    const subjects = subjectsForExam(exam, exam === 'cbse12' || exam === 'jee-main' || exam === 'jee-advanced' ? '12' : '10');
    setForm((f) => ({
      ...f,
      exam,
      classLevel: exam === 'cbse10' ? '10' : exam === 'custom' ? f.classLevel : '12',
      subjects,
      weakSubjects: f.weakSubjects.filter((s) => subjects.includes(s)),
      strongSubjects: f.strongSubjects.filter((s) => subjects.includes(s)),
    }));
  };

  const toggleIn = (list: string[], value: string) => (list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);

  const validateStep = (index: number): boolean => {
    const next: Record<string, string> = {};
    if (index === 0) {
      if (form.name.trim().length < 2) next.name = 'Enter your name.';
      if (!form.examDate) next.examDate = 'Set your exam date so the plan can count down to it.';
      if (form.examDate && form.examDate < todayISO()) next.examDate = 'The exam date is in the past — pick the upcoming exam.';
      if (form.targetScore.trim().length < 2) next.targetScore = 'Add a target (percentage, rank or score).';
    }
    if (index === 1) {
      if (!form.subjects.length) next.subjects = 'Select at least one subject.';
    }
    if (index === 2) {
      if (form.dailyHours < 1 || form.dailyHours > 16) next.dailyHours = 'Enter between 1 and 16 hours.';
      if (form.preferredEnd <= form.preferredStart) next.preferredEnd = 'Your study window must end after it starts.';
      const sleep = sleepHours(form.sleepAt, form.wakeAt);
      if (sleep < 6) next.sleepAt = `That leaves only ${sleep.toFixed(1)}h of sleep. EduMentor needs at least 6 hours — we plan around recovery, not through it.`;
    }
    setFieldErrors(next);
    return Object.keys(next).length === 0;
  };

  const nextStep = () => { if (validateStep(step)) setStep((s) => Math.min(STEPS.length - 1, s + 1)); };

  const submit = async () => {
    if (!validateStep(0) || !validateStep(1) || !validateStep(2)) {
      setStep(!form.name || !form.examDate ? 0 : !form.subjects.length ? 1 : 2);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const data = await api.put<{ profile: StudentProfile }>('/api/profile', {
        ...form,
        examLabel: EXAM_LIST.find((e) => e.id === form.exam)?.label,
        coachingStart: form.coachingStart || null,
        coachingEnd: form.coachingEnd || null,
      });
      await refresh();
      navigate('/dashboard', { replace: true });
      void data;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save your profile.');
    } finally {
      setBusy(false);
    }
  };

  const StepIcon = STEPS[step].icon;

  return (
    <div className="min-h-screen px-4 py-8 sm:px-6">
      <div className="mx-auto w-full max-w-3xl">
        <div className="mb-6 flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand text-white"><BookOpenCheck size={19} /></span>
          <div>
            <div className="font-display text-base font-extrabold text-ink">EduMentor AI</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted">Personal setup</div>
          </div>
        </div>

        <div className="mb-5 flex items-center gap-2">
          {STEPS.map((s, i) => (
            <div key={s.title} className="flex flex-1 items-center gap-2">
              <div className={cn('grid h-7 w-7 shrink-0 place-items-center rounded-full text-[11px] font-bold',
                i < step ? 'bg-ok text-black' : i === step ? 'bg-brand text-white' : 'bg-elevated text-muted')}>
                {i + 1}
              </div>
              <div className={cn('h-1 flex-1 rounded-full', i <= step ? 'bg-brand/60' : 'bg-line')} />
            </div>
          ))}
        </div>

        <div className="card p-5 sm:p-7">
          <div className="mb-5 flex items-start gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand/10 text-brand"><StepIcon size={19} /></span>
            <div>
              <h1 className="font-display text-xl font-bold text-ink">{STEPS[step].title}</h1>
              <p className="text-sm text-muted">{STEPS[step].subtitle}</p>
            </div>
          </div>

          {error && <div className="mb-4"><Banner tone="bad">{error}</Banner></div>}

          {step === 0 && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Student name" required error={fieldErrors.name}>
                  <Input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Aarav Sharma" />
                </Field>
                <Field label="School board">
                  <Select value={form.board} onChange={(e) => set('board', e.target.value)}>
                    {['CBSE', 'ICSE', 'State Board', 'IB', 'Other'].map((b) => <option key={b}>{b}</option>)}
                  </Select>
                </Field>
              </div>

              <div>
                <span className="label">Target examination <span className="text-bad">*</span></span>
                <div className="grid gap-2 sm:grid-cols-2">
                  {EXAM_LIST.map((exam) => (
                    <button
                      key={exam.id}
                      onClick={() => chooseExam(exam.id)}
                      className={cn('rounded-xl border p-3 text-left transition',
                        form.exam === exam.id ? 'border-brand bg-brand/10 ring-1 ring-brand/30' : 'border-line bg-elevated/40 hover:border-brand/40')}
                    >
                      <div className="text-sm font-semibold text-ink">{exam.label}</div>
                      <div className="mt-0.5 text-[11px] leading-snug text-muted">{exam.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Exam date" required error={fieldErrors.examDate} hint="Used for the countdown and planner priorities.">
                  <Input type="date" value={form.examDate} min={todayISO()} onChange={(e) => set('examDate', e.target.value)} />
                </Field>
                <Field label="Target percentage / rank / score" required error={fieldErrors.targetScore}>
                  <Input value={form.targetScore} onChange={(e) => set('targetScore', e.target.value)} placeholder="e.g. 92% in boards, or AIR under 5000" />
                </Field>
              </div>
              <Field label="Current class">
                <Select value={form.classLevel} onChange={(e) => set('classLevel', e.target.value)}>
                  {['9', '10', '11', '12', 'Dropper'].map((c) => <option key={c} value={c}>{c === 'Dropper' ? 'Dropper / gap year' : `Class ${c}`}</option>)}
                </Select>
              </Field>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-5">
              {fieldErrors.subjects && <Banner tone="bad">{fieldErrors.subjects}</Banner>}
              <div>
                <span className="label">Subjects in your syllabus</span>
                <div className="grid gap-2 sm:grid-cols-2">
                  {examSubjects.map((subject) => {
                    const active = form.subjects.includes(subject);
                    return (
                      <button
                        key={subject}
                        onClick={() => {
                          const subjects = toggleIn(form.subjects, subject);
                          setForm((f) => ({
                            ...f, subjects,
                            weakSubjects: f.weakSubjects.filter((s) => subjects.includes(s)),
                            strongSubjects: f.strongSubjects.filter((s) => subjects.includes(s)),
                          }));
                        }}
                        className={cn('flex items-center justify-between rounded-xl border px-3.5 py-3 text-sm font-medium transition',
                          active ? 'border-brand bg-brand/10 text-ink' : 'border-line bg-elevated/40 text-muted hover:border-brand/40')}
                      >
                        {subject}
                        <span className={cn('grid h-5 w-5 place-items-center rounded-md border text-[10px]',
                          active ? 'border-brand bg-brand text-white' : 'border-line')}>{active ? '✓' : ''}</span>
                      </button>
                    );
                  })}
                </div>
                <p className="mt-2 text-xs text-muted">You can add or remove chapters later in Profile → Syllabus.</p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <span className="label">Weak subjects</span>
                  <div className="flex flex-wrap gap-2">
                    {form.subjects.map((subject) => (
                      <button key={subject}
                        onClick={() => setForm((f) => ({ ...f, weakSubjects: toggleIn(f.weakSubjects, subject), strongSubjects: f.strongSubjects.filter((s) => s !== subject) }))}
                        className={cn('chip', form.weakSubjects.includes(subject) && 'border-bad/50 bg-bad/10 text-bad')}>
                        {subject}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="label">Strong subjects</span>
                  <div className="flex flex-wrap gap-2">
                    {form.subjects.map((subject) => (
                      <button key={subject}
                        onClick={() => setForm((f) => ({ ...f, strongSubjects: toggleIn(f.strongSubjects, subject), weakSubjects: f.weakSubjects.filter((s) => s !== subject) }))}
                        className={cn('chip', form.strongSubjects.includes(subject) && 'border-ok/50 bg-ok/10 text-ok')}>
                        {subject}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Daily study hours you can honestly give" error={fieldErrors.dailyHours} hint="Excluding school and coaching. Be realistic — the plan will use this.">
                  <Input type="number" min={1} max={16} step={0.5} value={form.dailyHours} onChange={(e) => set('dailyHours', Number(e.target.value))} />
                </Field>
                <Field label="Preferred study window" error={fieldErrors.preferredEnd}>
                  <div className="flex items-center gap-2">
                    <Input type="time" value={form.preferredStart} onChange={(e) => set('preferredStart', e.target.value)} />
                    <span className="text-xs text-muted">to</span>
                    <Input type="time" value={form.preferredEnd} onChange={(e) => set('preferredEnd', e.target.value)} />
                  </div>
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="School timings">
                  <div className="flex items-center gap-2">
                    <Input type="time" value={form.schoolStart} onChange={(e) => set('schoolStart', e.target.value)} />
                    <span className="text-xs text-muted">to</span>
                    <Input type="time" value={form.schoolEnd} onChange={(e) => set('schoolEnd', e.target.value)} />
                  </div>
                </Field>
                <Field label="Coaching timings (optional)">
                  <div className="flex items-center gap-2">
                    <Input type="time" value={form.coachingStart} onChange={(e) => set('coachingStart', e.target.value)} />
                    <span className="text-xs text-muted">to</span>
                    <Input type="time" value={form.coachingEnd} onChange={(e) => set('coachingEnd', e.target.value)} />
                  </div>
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Sleep at" error={fieldErrors.sleepAt}>
                  <Input type="time" value={form.sleepAt} onChange={(e) => set('sleepAt', e.target.value)} />
                </Field>
                <Field label="Wake at">
                  <Input type="time" value={form.wakeAt} onChange={(e) => set('wakeAt', e.target.value)} />
                </Field>
              </div>
              <Field label="Other daily commitments" hint="Sports, tuition, family duties, travel — anything that blocks time.">
                <Textarea value={form.commitments} onChange={(e) => set('commitments', e.target.value)} placeholder="Football practice 6–7 pm on weekdays; Sunday family time." />
              </Field>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <Field label="Where do you stand right now?" hint="Recent test scores, chapter comfort, or what teachers say. This shapes teaching depth and plan priorities.">
                <Textarea value={form.currentPerformance} onChange={(e) => set('currentPerformance', e.target.value)} placeholder="Scoring around 65% in school tests; calculus is weak, mechanics is strong." />
              </Field>
              <Field label="How do you learn best?">
                <Select value={form.learningStyle} onChange={(e) => set('learningStyle', e.target.value)}>
                  {[
                    'Step-by-step explanations with worked examples',
                    'Visual intuition first, then formal derivation',
                    'Practice questions with hints, minimal theory',
                    'Story and analogy driven explanations',
                    'Formula-first, application-focused revision',
                  ].map((s) => <option key={s}>{s}</option>)}
                </Select>
              </Field>
              <Banner tone="info" title="What happens next">
                EduMentor builds your syllabus tracker, studies your weak chapters, and can generate your first adaptive timetable straight away.
                Upload a textbook PDF in My Resources to unlock grounded, page-cited answers.
              </Banner>
            </div>
          )}

          <div className="mt-6 flex items-center justify-between gap-2 border-t border-line pt-4">
            <Button variant="ghost" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>
              <ArrowLeft size={16} /> Back
            </Button>
            <div className="text-xs text-muted">Step {step + 1} of {STEPS.length}</div>
            {step < STEPS.length - 1 ? (
              <Button onClick={nextStep}>Continue <ArrowRight size={16} /></Button>
            ) : (
              <Button onClick={submit} loading={busy}>Create my profile <ArrowRight size={16} /></Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function sleepHours(sleepAt: string, wakeAt: string): number {
  const [sh, sm] = sleepAt.split(':').map(Number);
  const [wh, wm] = wakeAt.split(':').map(Number);
  const start = sh * 60 + sm;
  const end = wh * 60 + wm;
  return (end >= start ? end - start : 1440 - start + end) / 60;
}
