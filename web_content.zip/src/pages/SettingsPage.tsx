import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { getCreatorMemory, saveCreatorMemory } from "@/lib/storage";
import type { CreatorMemory, Language, Platform, OutputFormat, Tone } from "@/types";
import { LANGUAGES, PLATFORMS, OUTPUT_FORMATS } from "@/constants";
import { Settings2, Save, Check, User, Globe, Tv2, Zap, Shield, Sliders } from "lucide-react";
import AIProvidersManagerView from "@/components/features/core4/AIProvidersManagerView";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<"general" | "providers">("providers");
  const [memory, setMemory] = useState<CreatorMemory>(getCreatorMemory);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    saveCreatorMemory(memory);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <AppLayout title="Configurações & Provedores de IA" subtitle="Gerenciamento dos 9 motores e preferências">
      <div className="p-6 max-w-5xl space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-studio-border pb-3">
          <button
            onClick={() => setActiveTab("providers")}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors flex items-center gap-2 ${
              activeTab === "providers"
                ? "bg-studio-blue text-white shadow-sm"
                : "text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            Motores de IA & Saúde (9 Subsistemas)
          </button>
          <button
            onClick={() => setActiveTab("general")}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors flex items-center gap-2 ${
              activeTab === "general"
                ? "bg-studio-blue text-white shadow-sm"
                : "text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            Preferências Gerais & Memória
          </button>
        </div>

        {activeTab === "providers" ? (
          <AIProvidersManagerView />
        ) : (
          <div className="space-y-6">
            {/* Profile */}
            <div className="studio-card p-5">
              <h3 className="text-sm font-bold text-studio-text font-display mb-4 flex items-center gap-2">
                <User className="w-4 h-4 text-studio-blue" />
                Perfil do Criador
              </h3>
              <div className="flex items-center gap-4 p-4 rounded-xl bg-studio-panel border border-studio-border">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-studio-gold to-studio-orange flex items-center justify-center text-xl font-bold text-black">
                  S
                </div>
                <div>
                  <p className="text-base font-bold text-studio-text font-display">Sadraque Ngola</p>
                  <p className="text-sm text-studio-text-muted">sadraquengola83@gmail.com</p>
                  <span className="task-badge text-xs bg-studio-gold/10 text-studio-gold border border-studio-gold/20 mt-1">
                    Proprietário · AI Creator Studio
                  </span>
                </div>
              </div>
            </div>

            {/* Creator Memory */}
            <div className="studio-card p-5">
              <h3 className="text-sm font-bold text-studio-text font-display mb-4 flex items-center gap-2">
                <Zap className="w-4 h-4 text-studio-purple" />
                Creator Memory
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-studio-text-muted mb-1.5">Idioma Padrão</label>
                  <select
                    value={memory.language}
                    onChange={(e) => setMemory({ ...memory, language: e.target.value as Language })}
                    className="studio-input text-sm"
                  >
                    {LANGUAGES.map((l) => (
                      <option key={l.value} value={l.value}>{l.flag} {l.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-studio-text-muted mb-1.5">Plataforma Padrão</label>
                  <select
                    value={memory.defaultPlatform}
                    onChange={(e) => setMemory({ ...memory, defaultPlatform: e.target.value as Platform })}
                    className="studio-input text-sm"
                  >
                    {PLATFORMS.map((p) => (
                      <option key={p.value} value={p.value}>{p.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-studio-text-muted mb-1.5">Formato de Saída Padrão</label>
                  <select
                    value={memory.defaultOutputFormat}
                    onChange={(e) => setMemory({ ...memory, defaultOutputFormat: e.target.value as OutputFormat })}
                    className="studio-input text-sm"
                  >
                    {OUTPUT_FORMATS.map((f) => (
                      <option key={f.value} value={f.value}>{f.label} ({f.aspectRatio})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-studio-text-muted mb-1.5">Tom Preferido</label>
                  <select
                    value={memory.preferredTone}
                    onChange={(e) => setMemory({ ...memory, preferredTone: e.target.value as Tone })}
                    className="studio-input text-sm"
                  >
                    {["HAPPY","SERIOUS","EDUCATIONAL","DRAMATIC","CALM","ENERGETIC","EMOTIONAL"].map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs text-studio-text-muted mb-1.5">Estilo Visual Preferido</label>
                  <input
                    value={memory.preferredStyle}
                    onChange={(e) => setMemory({ ...memory, preferredStyle: e.target.value })}
                    className="studio-input text-sm"
                    placeholder="Ex: Dinâmico e moderno, Clean minimalista..."
                  />
                </div>
              </div>
            </div>

            {/* Security & Access */}
            <div className="studio-card p-5">
              <h3 className="text-sm font-bold text-studio-text font-display mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4 text-studio-gold" />
                Acesso Direto e Segurança
              </h3>
              <div className="p-4 rounded-xl bg-studio-blue/5 border border-studio-blue/20 space-y-2">
                <p className="text-sm text-studio-text">
                  <strong>Segurança e Isolamento Ativos:</strong> As chaves de API são armazenadas exclusivamente no backend criptografado e rate limiting ativo na API.
                </p>
                <p className="text-xs text-studio-text-muted">
                  Criador titular: <span className="text-studio-text font-medium">Sadraque Ngola</span> (sadraquengola83@gmail.com).
                </p>
              </div>
            </div>

            <button onClick={handleSave} className={saved ? "btn-secondary" : "btn-primary"}>
              {saved ? <><Check className="w-4 h-4" /> Configurações Salvas!</> : <><Save className="w-4 h-4" /> Salvar Configurações</>}
            </button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
