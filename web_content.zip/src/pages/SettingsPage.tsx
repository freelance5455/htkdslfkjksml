import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Settings,
  Volume2,
  VolumeX,
  Vibrate,
  Sliders,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Layers,
  Database
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const {
    settings,
    updateSettings,
    showToast,
    playSound,
    triggerHaptic,
    resetAppData
  } = useApp();

  const handleToggleSound = () => {
    const next = !settings.soundEnabled;
    updateSettings({ soundEnabled: next });
    if (next) playSound('button');
    showToast(next ? 'Sound effects enabled' : 'Sound effects muted');
  };

  const handleToggleHaptic = () => {
    const next = !settings.hapticEnabled;
    updateSettings({ hapticEnabled: next });
    if (next) triggerHaptic('medium');
    showToast(next ? 'Haptic feedback enabled' : 'Haptic feedback disabled');
  };

  const handleToggleStepByStep = () => {
    const next = !settings.showStepByStep;
    updateSettings({ showStepByStep: next });
    playSound('button');
    showToast(next ? 'Step-by-step solutions enabled' : 'Step-by-step solutions hidden');
  };

  const handleToggleAutoSave = () => {
    const next = !settings.autoSaveHistory;
    updateSettings({ autoSaveHistory: next });
    playSound('button');
    showToast(next ? 'Auto-save history enabled' : 'Auto-save history disabled');
  };

  const handleToggleScientificNotation = () => {
    const next = !settings.scientificNotation;
    updateSettings({ scientificNotation: next });
    playSound('button');
    showToast(next ? 'Scientific notation mode enabled' : 'Standard decimal mode enabled');
  };

  const handleReset = () => {
    resetAppData();
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-16">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Settings className="w-5 h-5 text-[#D65A1F]" />
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            Preferences & Settings
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-[#A9A39C]">
          Customize computation behavior, sensory audio cues, and offline storage.
        </p>
      </div>

      <div className="space-y-6">
        {/* Audio & Haptic Feedback */}
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-6 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 pb-2 border-b border-[#303030]">
            <Volume2 className="w-4 h-4 text-[#D65A1F]" />
            <h3 className="text-sm font-bold text-[#F5F2ED] uppercase tracking-wider font-mono">
              Sensory Feedback
            </h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151515] border border-[#303030]">
              <div>
                <h4 className="text-sm font-bold text-[#F5F2ED]">Synthetic Audio Clicks</h4>
                <p className="text-xs text-[#A9A39C] mt-0.5">
                  Subtle micro-harmonic sounds synthesized via Web Audio API on taps and calculations.
                </p>
              </div>
              <button
                onClick={handleToggleSound}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                  settings.soundEnabled
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                    : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030]'
                }`}
              >
                {settings.soundEnabled ? 'Enabled' : 'Muted'}
              </button>
            </div>

            <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151515] border border-[#303030]">
              <div>
                <h4 className="text-sm font-bold text-[#F5F2ED]">Haptic Vibration</h4>
                <p className="text-xs text-[#A9A39C] mt-0.5">
                  Tactile feedback vibration on compatible mobile devices.
                </p>
              </div>
              <button
                onClick={handleToggleHaptic}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                  settings.hapticEnabled
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                    : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030]'
                }`}
              >
                {settings.hapticEnabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>
          </div>
        </div>

        {/* Calculation Preferences */}
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-6 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 pb-2 border-b border-[#303030]">
            <Sliders className="w-4 h-4 text-[#D65A1F]" />
            <h3 className="text-sm font-bold text-[#F5F2ED] uppercase tracking-wider font-mono">
              Engine Computation Preferences
            </h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151515] border border-[#303030]">
              <div>
                <h4 className="text-sm font-bold text-[#F5F2ED]">Auto-Save to Calculation History</h4>
                <p className="text-xs text-[#A9A39C] mt-0.5">
                  Automatically preserve computed variables and answers to local device storage.
                </p>
              </div>
              <button
                onClick={handleToggleAutoSave}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                  settings.autoSaveHistory
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                    : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030]'
                }`}
              >
                {settings.autoSaveHistory ? 'ON' : 'OFF'}
              </button>
            </div>

            <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151515] border border-[#303030]">
              <div>
                <h4 className="text-sm font-bold text-[#F5F2ED]">Step-by-Step Proof Breakdown</h4>
                <p className="text-xs text-[#A9A39C] mt-0.5">
                  Display substitution and algebraic steps immediately beneath calculation results.
                </p>
              </div>
              <button
                onClick={handleToggleStepByStep}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                  settings.showStepByStep
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                    : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030]'
                }`}
              >
                {settings.showStepByStep ? 'ON' : 'OFF'}
              </button>
            </div>

            <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151515] border border-[#303030]">
              <div>
                <h4 className="text-sm font-bold text-[#F5F2ED]">Scientific Notation Display</h4>
                <p className="text-xs text-[#A9A39C] mt-0.5">
                  Force numbers into exponential notation (e.g. 1.350e+3) for extreme scales.
                </p>
              </div>
              <button
                onClick={handleToggleScientificNotation}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
                  settings.scientificNotation
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                    : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030]'
                }`}
              >
                {settings.scientificNotation ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>
        </div>

        {/* Local Storage & Reset */}
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-6 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 pb-2 border-b border-[#303030]">
            <Database className="w-4 h-4 text-[#D65A1F]" />
            <h3 className="text-sm font-bold text-[#F5F2ED] uppercase tracking-wider font-mono">
              Local Storage Management
            </h3>
          </div>

          <div className="p-4 rounded-2xl bg-[#151515] border border-[#303030] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="text-sm font-bold text-[#F5F2ED]">Reset Local Application Data</h4>
              <p className="text-xs text-[#A9A39C] mt-0.5">
                Clears calculation history, saved favorites, practice scores, and resets preferences to default.
              </p>
            </div>
            <button
              onClick={handleReset}
              className="px-4 py-2 rounded-xl bg-[#232323] hover:bg-[#C84A3A]/20 border border-[#303030] hover:border-[#C84A3A] text-xs font-bold text-[#C84A3A] transition-colors shrink-0 flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All Data</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
