/**
 * MindPage.js — Study / Anki / Notes / Past Qs tabs.
 * (MBBS deadline tab removed.) Existing Study + Anki statistics are kept and improved.
 */
import { isExamMode } from '../modules/mind/subjects/subjectsService.js';
import { renderSubjectsSection, subjectChipRow } from '../modules/mind/subjects/subjectsUI.js';
import {
  el, card, sectionHeader, button, textInput, textareaInput, emptyState, tabs,
  statGrid, barList, trendBadge, fieldLabel,
} from '../components/ui.js';
import { chartCanvas, renderBarChart, renderLineChart } from '../components/charts/canvasChart.js';
import { TIMETABLE_BLOCKS, EXAM_TIMETABLE, logStudySession, getRecentSessions, weeklyStudyHours } from '../modules/mind/study/studyService.js';
import { logAnkiReview, ankiStreak, ankiSeries, todayCardsReviewed } from '../modules/mind/anki/ankiService.js';
import {
  createNote, getNotesByType, updateNote, deleteNote, tagCounts, searchEverything,
} from '../modules/mind/notes/notesService.js';
import {
  addCard, reviewCard, deleteCard, dueCards, deckNames, previewInterval, importCards,
  exportCardsText, cardStats, getAllCards,
} from '../modules/mind/flashcards/flashcardService.js';
import {
  addQuestion, setStatus, deleteQuestion, listQuestions, subjectsInBank, bankStats,
} from '../modules/mind/pastQuestions/pastQuestionsService.js';
import { openPomodoro } from '../modules/mind/pomodoro/pomodoroUI.js';
import { todaysPomodoroStats } from '../modules/mind/pomodoro/pomodoroService.js';
import { statsForWeek, thisAndLastWeek, delta, studyBySubject } from '../core/stats/statsService.js';
import { showToast } from '../core/notifications/toast.js';
import { lastNDates, todayISO } from '../core/utils/dateUtils.js';
import { getAll } from '../core/storage/storageService.js';

let activeTab = 'study';
let ankiSub = 'stats';
let notesSubTab = 'cornell';
let notesTag = '';
let editingNote = null;
let reviewState = { queue: null, idx: 0, show: false, deck: '' };
let pq = { subject: '', status: '', practice: null, show: false };

async function rerender(root) {
  root.innerHTML = '';
  await MindPage(root);
}

/* ============================ STUDY ============================ */
async function renderStudyTab(page, root) {
  const hours = await weeklyStudyHours();
  const recent = await getRecentSessions(6);
  const breakdown = await studyBySubject(14);
  const pomo = await todaysPomodoroStats();
  const { cur, prev } = await thisAndLastWeek();

  // --- Focus timer entry (the new Pomodoro clock) ---
  page.append(sectionHeader(`${pomo.count} today · ${pomo.minutes} min`, 'Focus timer'));
  page.append(card([
    el('p', 'text-dim text-xs', 'Pomodoro with a real clock: 25/5, 50/10, 15/3 or your own, cycles, subjects, pause & resume.'),
    el('div', 'mt-3', button('Open Pomodoro', { block: true, onClick: () => openPomodoro() })),
  ]));

  page.append(sectionHeader(`${hours}h this week`, 'Study stats'));
  page.append(statGrid([
    { value: `${cur.studyHours}h`, label: 'This week', hint: `last week ${prev.studyHours}h` },
    { value: cur.studyDays, label: 'Study days', hint: 'out of 7' },
    { value: cur.studyDays ? `${Math.round((cur.studyMin / cur.studyDays) / 6) / 10}h` : '0h', label: 'Avg / study day' },
  ]));
  const d = delta(cur.studyHours, prev.studyHours);
  page.append(el('div', 'mt-2 flex items-center gap-2', [el('span', 'text-xs text-dim', 'Compared with last week:'), trendBadge(d)]));

  const examOn = await isExamMode();
  page.append(sectionHeader(examOn ? 'Exam mode' : null, examOn ? 'Revision timetable' : 'Timetable'));
  page.append(card((examOn ? EXAM_TIMETABLE : TIMETABLE_BLOCKS).map((b) => el('div', 'checklist-item', [
    el('span', 'text-xs text-dim', b.time),
    el('span', 'checklist-item__label', b.label),
  ]))));

  const subjectInput = textInput({ placeholder: 'Subject (tap one below or type)' });
  const durationInput = textInput({ placeholder: 'Minutes', type: 'number' });
  await renderSubjectsSection(page, () => rerender(root));
  page.append(sectionHeader(null, 'Log a session'));
  const chipsRow = await subjectChipRow(subjectInput);
  page.append(card([
    subjectInput, chipsRow ? el('div', 'mt-2', chipsRow) : null, el('div', 'mt-3', durationInput),
    el('div', 'mt-3', button('Save session', { block: true, onClick: async () => {
      const mins = parseInt(durationInput.value, 10) || 0;
      if (!subjectInput.value || mins <= 0) { showToast('Add subject and duration.'); return; }
      await logStudySession({ subject: subjectInput.value, durationMin: mins });
      showToast('Session logged.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, 'Recent sessions'));
  page.append(card(
    recent.length === 0
      ? [emptyState('No sessions yet', 'Log one above or run a Pomodoro.')]
      : recent.map((s) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', `${s.subject} — ${s.durationMin}min${s.type === 'pomodoro' ? ' ⏱' : ''}`),
          el('span', 'text-xs text-dim', s.date),
        ]))
  ));

  if (breakdown.length > 0) {
    page.append(sectionHeader(null, 'Hours per subject (14 days)'));
    page.append(card([barList(breakdown.map(([subject, mins]) => ({ label: subject, value: mins, text: `${Math.round(mins / 6) / 10}h` })))]));
  }
}

/* ============================ ANKI ============================ */
async function renderAnkiTab(page, root) {
  page.append(tabs([{ key: 'stats', label: 'Stats' }, { key: 'review', label: 'Flashcards' }], ankiSub, async (k) => { ankiSub = k; reviewState.queue = null; await rerender(root); }));
  if (ankiSub === 'review') return renderFlashcards(page, root);

  const streak = await ankiStreak();
  const today = await todayCardsReviewed();
  const series14 = await ankiSeries(14);
  const series30 = await ankiSeries(30);
  const logs = await getAll('ankiLogs');
  const total = logs.reduce((a, l) => a + (l.cardsReviewed || 0), 0);
  const matured = logs.reduce((a, l) => a + (l.cardsMatured || 0), 0);
  const week = series14.slice(-7).reduce((a, s) => a + s.value, 0);
  const prevWeek = series14.slice(0, 7).reduce((a, s) => a + s.value, 0);
  const activeDays = series30.filter((s) => s.value > 0).length;
  const best = Math.max(0, ...series30.map((s) => s.value));

  page.append(sectionHeader(`${streak}-day streak`, 'Anki'));
  page.append(card([el('p', null, `${today} cards reviewed today`)]));
  page.append(statGrid([
    { value: week, label: 'Cards this week', hint: `last week ${prevWeek}` },
    { value: Math.round(week / 7), label: 'Daily average' },
    { value: best, label: 'Best day (30d)' },
    { value: `${activeDays}/30`, label: 'Active days' },
    { value: total, label: 'All-time cards' },
    { value: matured, label: 'Matured (logged)' },
  ]));
  page.append(el('div', 'mt-2 flex items-center gap-2', [el('span', 'text-xs text-dim', 'Week vs last week:'), trendBadge(delta(week, prevWeek))]));

  const cardsInput = textInput({ placeholder: 'Cards reviewed', type: 'number' });
  const maturedInput = textInput({ placeholder: 'Cards matured (optional)', type: 'number' });
  page.append(sectionHeader(null, 'Log review'));
  page.append(card([
    cardsInput, el('div', 'mt-3', maturedInput),
    el('div', 'mt-3', button('Save review', { block: true, onClick: async () => {
      const cards = parseInt(cardsInput.value, 10) || 0;
      if (cards <= 0) { showToast('Enter a card count.'); return; }
      await logAnkiReview({ cardsReviewed: cards, cardsMatured: parseInt(maturedInput.value, 10) || 0 });
      showToast('Review logged.');
      await rerender(root);
    } })),
  ]));

  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Cards reviewed (14 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);
  const chart30 = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Trend (30 days)')])]);
  const canvas30 = chartCanvas(100);
  chart30.append(canvas30);
  page.append(chart30);
  requestAnimationFrame(() => {
    renderBarChart(canvas, series14, { color: '#2A4DD0' });
    renderLineChart(canvas30, series30, {});
  });
}

async function renderFlashcards(page, root) {
  const stats = await cardStats();
  const decks = await deckNames();
  page.append(statGrid([
    { value: stats.due, label: 'Due today' }, { value: stats.total, label: 'Total cards' },
    { value: stats.learning, label: 'New' }, { value: stats.mature, label: 'Mature (21d+)' },
  ]));

  if (decks.length) {
    const row = el('div', 'chip-row mt-3');
    [['', 'All decks'], ...decks.map((d) => [d, d])].forEach(([v, l]) => {
      const c = el('button', `chip${reviewState.deck === v ? ' chip--active' : ''}`, l);
      c.addEventListener('click', async () => { reviewState = { queue: null, idx: 0, show: false, deck: v }; await rerender(root); });
      row.append(c);
    });
    page.append(row);
  }

  if (!reviewState.queue) reviewState.queue = (await dueCards(reviewState.deck)).map((c) => c.id);
  const all = await getAllCards();
  const current = reviewState.queue.length ? all.find((c) => c.id === reviewState.queue[reviewState.idx]) : null;

  const study = card([]);
  study.classList.add('card--glass');
  if (!current) {
    study.append(emptyState(all.length ? 'All caught up 🎉' : 'No cards yet', all.length ? 'Nothing due right now. Come back tomorrow.' : 'Add a card or import a list below.'));
  } else {
    study.append(el('div', 'flex justify-between text-xs text-dim', [el('span', null, `Card ${reviewState.idx + 1} of ${reviewState.queue.length}`), el('span', null, current.deck || 'General')]));
    const face = el('div', 'flashcard', reviewState.show
      ? [el('div', 'text-xs text-dim', current.front), el('hr', 'flashcard__rule'), el('div', null, current.back)]
      : [el('div', null, current.front)]);
    face.addEventListener('click', async () => { reviewState.show = true; await rerender(root); });
    study.append(face);
    if (!reviewState.show) study.append(button('Show answer', { block: true, onClick: async () => { reviewState.show = true; await rerender(root); } }));
    else {
      const grid = el('div', 'grade-grid');
      [['Again', 'again', 1], ['Hard', 'hard', 3], ['Good', 'good', 4], ['Easy', 'easy', 5]].forEach(([label, key, q]) => {
        const b = el('button', `btn btn--${key === 'again' ? 'danger' : 'ghost'} grade-btn`, [label, el('small', null, previewInterval(current, q))]);
        b.addEventListener('click', async () => {
          await reviewCard(current, q);
          if (q < 3) reviewState.queue.push(current.id);
          reviewState.idx += 1; reviewState.show = false;
          if (reviewState.idx >= reviewState.queue.length) reviewState.queue = [];
          await rerender(root);
        });
        grid.append(b);
      });
      study.append(grid);
    }
  }
  page.append(sectionHeader(null, 'Review'));
  page.append(study);

  const front = textInput({ placeholder: 'Front / question' });
  const back = textareaInput({ placeholder: 'Back / answer', rows: 2 });
  const deck = textInput({ placeholder: 'Deck (e.g. Anatomy)', value: reviewState.deck || '' });
  page.append(sectionHeader(null, 'Add card'));
  page.append(card([front, el('div', 'mt-3', back), el('div', 'mt-3', deck), el('div', 'mt-3', button('Add card', { block: true, onClick: async () => {
    if (!front.value.trim() || !back.value.trim()) { showToast('Fill front and back.'); return; }
    await addCard({ front: front.value.trim(), back: back.value.trim(), deck: deck.value.trim() });
    reviewState.queue = null; showToast('Card added.'); await rerender(root);
  } }))]));

  const area = textareaInput({ placeholder: 'One card per line:  question | answer | deck (optional)\nTab-separated also works (paste from Excel/Anki).', rows: 4 });
  page.append(sectionHeader(null, 'Import / export'));
  page.append(card([area, el('div', 'mt-3 flex gap-3', [
    button('Import', { onClick: async () => { const n = await importCards(area.value, reviewState.deck || 'General'); reviewState.queue = null; showToast(`${n} cards imported.`); await rerender(root); } }),
    button('Copy all cards', { variant: 'ghost', onClick: async () => { const t = await exportCardsText(); try { await navigator.clipboard.writeText(t); showToast('Copied to clipboard.'); } catch { area.value = t; showToast('Select the text below to copy.'); } } }),
  ])]));

  if (all.length) {
    page.append(sectionHeader(`${all.length}`, 'Manage cards'));
    page.append(card(all.slice(-25).reverse().map((c) => {
      const row = el('div', 'checklist-item', [
        el('span', 'checklist-item__label', c.front),
        el('span', 'text-xs text-dim', `due ${c.dueDate}`),
      ]);
      const del = el('button', 'icon-btn', '✕');
      del.addEventListener('click', async () => { await deleteCard(c.id); reviewState.queue = null; await rerender(root); });
      row.append(del);
      return row;
    })));
  }
}

/* ============================ NOTES ============================ */
async function renderNotesTab(page, root) {
  // universal search (notes + flashcards + past questions)
  const results = el('div');
  const searchBox = textInput({ placeholder: 'Search notes, cards, questions…' });
  let t = null;
  searchBox.addEventListener('input', () => {
    clearTimeout(t);
    t = setTimeout(async () => {
      results.replaceChildren();
      const r = await searchEverything(searchBox.value);
      const total = r.notes.length + r.cards.length + r.questions.length;
      if (searchBox.value.trim().length < 2) return;
      if (!total) { results.append(card([emptyState('Nothing found', 'Try another word or #tag.')])); return; }
      const rows = [];
      r.notes.slice(0, 8).forEach((n) => rows.push(el('div', 'checklist-item', [el('span', 'checklist-item__label', `📝 ${n.title}`), el('span', 'text-xs text-dim', n.type)])));
      r.cards.slice(0, 8).forEach((c) => rows.push(el('div', 'checklist-item', [el('span', 'checklist-item__label', `🧠 ${c.front}`), el('span', 'text-xs text-dim', c.deck || '')])));
      r.questions.slice(0, 8).forEach((q) => rows.push(el('div', 'checklist-item', [el('span', 'checklist-item__label', `❓ ${q.question.slice(0, 70)}`), el('span', 'text-xs text-dim', q.subject)])));
      results.append(card(rows));
    }, 200);
  });
  page.append(searchBox, results);

  const subRow = el('div', 'tab-row mt-3');
  [{ key: 'cornell', label: 'Cornell' }, { key: 'memoryPalace', label: 'Memory Palace' }, { key: 'journal', label: 'Journal' }].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${notesSubTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { notesSubTab = key; notesTag = ''; editingNote = null; await rerender(root); });
    subRow.append(pill);
  });
  page.append(subRow);

  const counts = await tagCounts(notesSubTab);
  if (Object.keys(counts).length) {
    const tagRow = el('div', 'chip-row');
    [['', 'All'], ...Object.keys(counts).map((k) => [k, `#${k} ${counts[k]}`])].forEach(([v, l]) => {
      const c = el('button', `chip${notesTag === v ? ' chip--active' : ''}`, l);
      c.addEventListener('click', async () => { notesTag = v; await rerender(root); });
      tagRow.append(c);
    });
    page.append(tagRow);
  }

  const notes = await getNotesByType(notesSubTab, notesTag);
  const titleInput = textInput({ placeholder: 'Title', value: editingNote?.title || '' });
  const contentInput = textareaInput({
    placeholder: notesSubTab === 'cornell' ? 'Notes / cues / summary — add #tags' : notesSubTab === 'journal' ? 'Write freely…' : 'Pathway → location mapping',
    rows: 4, value: editingNote?.content || '',
  });
  page.append(card([
    el('span', 'text-xs text-dim', editingNote ? 'EDITING NOTE' : 'NEW NOTE'),
    el('div', 'mt-2', titleInput), el('div', 'mt-3', contentInput),
    el('div', 'mt-3 flex gap-3', [
      button(editingNote ? 'Update note' : 'Save note', { block: true, onClick: async () => {
        if (!titleInput.value || !contentInput.value) { showToast('Add a title and content.'); return; }
        if (editingNote) { await updateNote(editingNote, { title: titleInput.value, content: contentInput.value }); editingNote = null; }
        else await createNote({ type: notesSubTab, title: titleInput.value, content: contentInput.value });
        showToast('Note saved.');
        await rerender(root);
      } }),
      editingNote ? button('Cancel', { variant: 'ghost', onClick: async () => { editingNote = null; await rerender(root); } }) : null,
    ]),
  ]));

  page.append(sectionHeader(null, `${notes.length} saved`));
  page.append(card(
    notes.length === 0
      ? [emptyState('No notes yet', 'Add your first note above.')]
      : notes.map((n) => {
          const row = el('div', 'note-row', [
            el('div', 'flex justify-between', [el('span', 'checklist-item__label', n.title), el('span', 'text-xs text-dim', n.date)]),
            el('p', 'text-xs text-dim note-row__body', n.content),
            el('div', 'flex gap-3 mt-2', [
              (() => { const b = el('button', 'link-btn', 'Edit'); b.addEventListener('click', async () => { editingNote = n; window.scrollTo(0, 0); await rerender(root); }); return b; })(),
              (() => { const b = el('button', 'link-btn link-btn--danger', 'Delete'); b.addEventListener('click', async () => { if (window.confirm('Delete this note?')) { await deleteNote(n.id); await rerender(root); } }); return b; })(),
            ]),
          ]);
          return row;
        })
  ));
}

/* ============================ PAST QUESTIONS ============================ */
async function renderPastQTab(page, root) {
  const stats = await bankStats();
  const subjects = await subjectsInBank();
  page.append(statGrid([{ value: stats.total, label: 'Questions' }, { value: stats.weak, label: 'Weak' }, { value: stats.done, label: 'Mastered' }]));

  const filters = el('div', 'chip-row mt-3');
  [['', 'All'], ...subjects.map((s) => [s, s])].forEach(([v, l]) => {
    const c = el('button', `chip${pq.subject === v ? ' chip--active' : ''}`, l);
    c.addEventListener('click', async () => { pq.subject = v; await rerender(root); });
    filters.append(c);
  });
  ['new', 'weak', 'done'].forEach((s) => {
    const c = el('button', `chip${pq.status === s ? ' chip--active' : ''}`, s);
    c.addEventListener('click', async () => { pq.status = pq.status === s ? '' : s; await rerender(root); });
    filters.append(c);
  });
  page.append(filters);

  const list = await listQuestions({ subject: pq.subject, status: pq.status });

  if (pq.practice !== null && list[pq.practice]) {
    const q = list[pq.practice];
    page.append(sectionHeader(`${pq.practice + 1}/${list.length}`, 'Practice'));
    const c = card([
      el('p', 'pq-question', q.question),
      pq.show
        ? el('div', null, [el('hr', 'flashcard__rule'), el('p', 'pq-answer', q.answer || '(no answer saved)'), el('div', 'grade-grid mt-3', [
            (() => { const b = el('button', 'btn btn--ghost', 'Got it ✓'); b.addEventListener('click', async () => { await setStatus(q, 'done'); pq.practice += 1; pq.show = false; await rerender(root); }); return b; })(),
            (() => { const b = el('button', 'btn btn--danger', 'Weak ✗'); b.addEventListener('click', async () => { await setStatus(q, 'weak'); pq.practice += 1; pq.show = false; await rerender(root); }); return b; })(),
          ])])
        : el('div', 'mt-3', button('Reveal answer', { block: true, onClick: async () => { pq.show = true; await rerender(root); } })),
    ]);
    c.classList.add('card--glass');
    page.append(c);
    page.append(el('div', 'mt-3', button('End practice', { variant: 'ghost', block: true, onClick: async () => { pq.practice = null; await rerender(root); } })));
    return;
  }
  if (pq.practice !== null) { pq.practice = null; showToast('Practice finished.'); }

  if (list.length) page.append(el('div', 'mt-3', button(`▶ Practice ${list.length} question${list.length > 1 ? 's' : ''}`, { block: true, onClick: async () => { pq.practice = 0; pq.show = false; await rerender(root); } })));

  const qIn = textareaInput({ placeholder: 'Question', rows: 3 });
  const aIn = textareaInput({ placeholder: 'Answer / explanation', rows: 3 });
  const sIn = textInput({ placeholder: 'Subject', value: pq.subject });
  const srcIn = textInput({ placeholder: 'Source / year (optional)' });
  const pqChips = await subjectChipRow(sIn);
  page.append(sectionHeader(null, 'Add a past question'));
  page.append(card([qIn, el('div', 'mt-3', aIn), el('div', 'mt-3', sIn), pqChips ? el('div', 'mt-2', pqChips) : null, el('div', 'mt-3', srcIn), el('div', 'mt-3', button('Save question', { block: true, onClick: async () => {
    if (!qIn.value.trim()) { showToast('Write the question first.'); return; }
    await addQuestion({ question: qIn.value.trim(), answer: aIn.value.trim(), subject: sIn.value.trim(), source: srcIn.value.trim() });
    showToast('Question saved.'); await rerender(root);
  } }))]));

  page.append(sectionHeader(null, 'Your bank'));
  page.append(card(list.length === 0 ? [emptyState('Empty bank', 'Add your first past question above.')] : list.slice(0, 40).map((q) => {
    const row = el('div', 'note-row', [
      el('div', 'flex justify-between', [el('span', 'text-xs text-dim', `${q.subject}${q.source ? ` · ${q.source}` : ''}`), el('span', `status-pill status-pill--${q.status}`, q.status)]),
      el('p', 'text-xs', q.question.length > 140 ? `${q.question.slice(0, 140)}…` : q.question),
    ]);
    const del = el('button', 'link-btn link-btn--danger', 'Delete');
    del.addEventListener('click', async () => { await deleteQuestion(q.id); await rerender(root); });
    row.append(del);
    return row;
  })));
}

export async function MindPage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Mind'), el('p', 'page-subtitle', 'Study · Anki · Notes · Past Qs'));
  page.append(tabs([
    { key: 'study', label: 'Study' }, { key: 'anki', label: 'Anki' },
    { key: 'notes', label: 'Notes' }, { key: 'pq', label: 'Past Qs' },
  ], activeTab, async (k) => { activeTab = k; await rerender(root); }));

  if (activeTab === 'study') await renderStudyTab(page, root);
  else if (activeTab === 'anki') await renderAnkiTab(page, root);
  else if (activeTab === 'notes') await renderNotesTab(page, root);
  else await renderPastQTab(page, root);

  root.appendChild(page);
}
