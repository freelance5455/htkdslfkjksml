import {
  el, card, sectionHeader, checklistItem, xpBar, button,
  progressRing, emptyState,
} from '../components/ui.js';
import { icon } from '../components/icons.js';
import { chartCanvas, renderLineChart, renderBarChart } from '../components/charts/canvasChart.js';
import { getTotalXP, levelFromTotalXP } from '../core/xp/xpEngine.js';
import {
  computeLifeScore, dailyXPSeries, habitConsistencySeries,
  studyHoursSeries, weeklyProgressSummary,
} from '../core/scoring/scoreEngine.js';
import { getTodayTasks, completeTask } from '../core/tasks/taskEngine.js';
import {
  ensureDefaultHabits, getAllHabits, habitStreak, habitCompletionPct,
  overallDailyStreak, habitsAtRiskToday, createHabit, FREQUENCY,
} from '../modules/discipline/habits/habitsService.js';
import { getDailyAffirmation, getVisionText, setVisionText } from '../core/motivation/quotes.js';
import { getTodaySuggestions } from '../core/intelligence/suggestionEngine.js';
import { getAll, todayISO } from '../core/storage/storageService.js';
import {
  actionStartPomodoro, actionLogStudySession, actionAddWorkout,
  actionLogMeal, actionMoodCheck, actionOpenJournal, actionQuickHydration,
} from '../modules/dashboard/quickActions.js';
import { dayLabel, greetingFor } from '../core/utils/dateUtils.js';
import { getProfile } from '../core/profile/profileService.js';
import { hijriDate, getPrayerConfig } from '../core/prayer/prayerService.js';
import { buildTodaysMasteryCard } from '../modules/mastery/masteryUI.js';
import { buildPrayerCard } from '../components/prayerCard.js';
import { coachMessage } from '../core/motivation/coach.js';
import { backupDue } from '../core/storage/backupService.js';
import { openHabitForm } from '../modules/discipline/habits/habitForm.js';
import { navigate } from '../core/router.js';
import { emit } from '../core/utils/eventBus.js';
import { SECTIONS, getDash, getPriorityDone, setPriorityDone } from '../modules/dashboard/dashPrefs.js';

// Module-level UI state (which habit-frequency tab is active).
// Intentionally simple: this is view state, not app data, so it does not
// belong in IndexedDB.
let habitTabState = FREQUENCY.DAILY;

function getCSSColor(varName) {
  return getComputedStyle(document.documentElement).getPropertyValue(varName).trim() || undefined;
}

async function xpEarnedToday() {
  const ledger = await getAll('xpLedger');
  const today = todayISO();
  return ledger.filter((e) => e.date === today).reduce((sum, e) => sum + e.amount, 0);
}

function scoreTile(label, value) {
  return el('div', 'score-tile', [
    progressRing(value, 44, 4),
    el('span', 'score-tile__label', label),
  ]);
}

async function rerender(root) {
  root.innerHTML = '';
  await Dashboard(root);
}

export async function Dashboard(root) {
  await ensureDefaultHabits();

  // --- Gather all data up front (parallel reads, no waterfalling) ---
  const [
    totalXP, todaysXP, scores, tasks, allHabits, dailyStreak, atRisk,
    xpSeries, consistencySeries, studySeries, weeklySummary, vision, suggestions,
  ] = await Promise.all([
    getTotalXP(),
    xpEarnedToday(),
    computeLifeScore(),
    getTodayTasks(),
    getAllHabits(),
    overallDailyStreak(),
    habitsAtRiskToday(),
    dailyXPSeries(14),
    habitConsistencySeries(14),
    studyHoursSeries(14),
    weeklyProgressSummary(),
    getVisionText(),
    getTodaySuggestions(3),
  ]);

  const [profile, prayerCfg] = await Promise.all([getProfile(), getPrayerConfig()]);
  const coach = await coachMessage((profile.name || 'Abbas').split(' ')[0]);
  const affirmation = getDailyAffirmation();
  const { level, xpIntoLevel, xpForNextLevel } = levelFromTotalXP(totalXP);
  const levelPct = (xpIntoLevel / xpForNextLevel) * 100;

  const page = el('div', 'page');

  // ============================================================
  // 0. GREETING HEADER — "Good Morning, Abbas!" at the top of Home
  // ============================================================
  const first = (profile.name || 'Champ').trim().split(/\s+/)[0];
  const hj = hijriDate(new Date(), prayerCfg.hijriAdjust);
  const avatar = profile.photo
    ? Object.assign(el('img', 'home-avatar'), { src: profile.photo, alt: '' })
    : el('div', 'home-avatar home-avatar--initial', first.slice(0, 1).toUpperCase());
  avatar.addEventListener('click', () => navigate('/about'));
  page.append(el('div', 'home-header', [
    avatar,
    el('div', null, [
      el('h1', 'home-greeting', `${greetingFor()}, ${first}!`),
      el('p', 'home-date', `${new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}${hj ? ` · ${hj.text}` : ''}`),
    ]),
  ]));
  if (backupDue(profile)) {
    const banner = el('div', 'warning-banner warning-banner--tap', [icon('settings'), el('span', null, 'Time to back up your data — tap to open Settings.')]);
    banner.addEventListener('click', () => navigate('/settings'));
    page.append(el('div', 'mb-3', banner));
  }

  // ============================================================
  // SECTIONS — Home is built from this registry (order/visibility come from Settings → Dashboard)
  // ============================================================
  const dash = await getDash();
  let xpCanvas; let consistencyCanvas; let studyCanvas;
  const builders = {
    overview: async (box) => {
  const overviewCard = card([
    el('div', 'flex justify-between items-center', [
      el('div', 'flex items-center gap-2', [icon('flame'), el('span', null, `${dailyStreak}-day streak`)]),
      el('span', 'text-xs text-dim', `LEVEL ${level}`),
    ]),
    el('div', 'mt-4', xpBar(levelPct)),
    el('div', 'flex justify-between mt-4', [
      el('span', 'text-xs text-dim', `+${todaysXP} XP today`),
      el('span', 'text-xs text-dim', `${xpIntoLevel}/${xpForNextLevel} to next level`),
    ]),
  ]);
  overviewCard.classList.add('card--glass');
  box.append(overviewCard);

    },
    priorities: async (box) => {
  const priDone = await getPriorityDone();
  if (!dash.priorities.length) return;
  box.append(sectionHeader(`${priDone.filter((i) => i < dash.priorities.length).length}/${dash.priorities.length} done`, 'My priorities today'));
  box.append(card(dash.priorities.map((text, i) => checklistItem(text, priDone.includes(i), async (checked) => {
    await setPriorityDone(i, checked);
    if (checked) emit('habit:completed', { priority: i });
    await rerender(root);
  }))));
    },
    vitals: async (box) => {
  box.append(sectionHeader('Scores', 'Your five vitals'));
  box.append(
    card([
      el('div', 'flex items-center gap-3', [
        progressRing(scores.life, 64, 6),
        el('div', null, [
          el('div', 'stat-tile__value', 'Life Score'),
          el('p', 'text-dim text-xs mt-1', 'Weighted average of health, study, fitness & confidence.'),
        ]),
      ]),
    ])
  );
  const tileLabel = { health: 'Health', study: 'Study', fitness: 'Fitness', confidence: 'Confidence' };
  const shown = dash.vitals.map((k) => scoreTile(tileLabel[k], scores[k]));
  if (shown.length) box.append(el('div', 'score-grid mt-4', shown));

    },
    suggestions: async (box) => {
  box.append(sectionHeader('Focus', "Today's suggestions"));
  box.append(
    card(
      suggestions.map((s) =>
        el('div', 'suggestion-item', [
          el('span', 'suggestion-item__icon', s.icon),
          el('span', 'suggestion-item__text', s.message),
        ])
      )
    )
  );

  // Streak-protection warning (only shown when a habit is actually at risk)
  if (atRisk.length > 0) {
    box.append(
      el('div', 'mt-4', el('div', 'warning-banner', [
        icon('flame'),
        el('span', null,
          `${atRisk.length} habit${atRisk.length > 1 ? 's' : ''} with a streak on the line today — log ${atRisk.length > 1 ? 'them' : 'it'} before the day ends.`
        ),
      ]))
    );
  }

    },
    prayer: async (box) => {
  // Prayer times (offline) — tap a prayer to mark it done
  const prayerSlot = el('div', 'mt-4');
  box.append(prayerSlot);
  const drawPrayer = async () => { prayerSlot.replaceChildren(await buildPrayerCard({ onChange: () => { drawPrayer(); } })); };
  await drawPrayer();

    },
    mastery: async (box) => {
  // Today's Mastery — only the skills scheduled for today (hidden when none)
  const masterySlot = el('div', 'mt-4');
  box.append(masterySlot);
  const drawMastery = async () => { const c = await buildTodaysMasteryCard(() => drawMastery()); masterySlot.replaceChildren(...(c ? [c] : [])); };
  await drawMastery();

    },
    tasks: async (box) => {
  const doneCount = tasks.filter((t) => t.done).length;
  box.append(sectionHeader(`${doneCount}/${tasks.length} done`, "Today's tasks"));
  box.append(
    card(
      tasks.length === 0
        ? [emptyState('No tasks yet', 'Add a habit below to populate today\'s tasks.')]
        : tasks.map((task) =>
            checklistItem(
              `${task.label}${task.streak > 0 ? ` · ${task.streak}${task.streakUnit || 'd'} streak` : ''}`,
              task.done,
              async (nextChecked) => {
                await completeTask(task, nextChecked);
                await rerender(root);
              }
            )
          )
    )
  );

    },
    habits: async (box) => {
  box.append(sectionHeader(null, 'Habit tracker'));
  const tabRow = el('div', 'tab-row');
  [
    { key: FREQUENCY.DAILY, label: 'Daily' },
    { key: FREQUENCY.WEEKLY, label: 'Weekly' },
    { key: FREQUENCY.CUSTOM, label: 'Custom' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${habitTabState === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => {
      habitTabState = key;
      await rerender(root);
    });
    tabRow.append(pill);
  });
  box.append(tabRow);

  const filteredHabits = allHabits.filter((h) => h.frequency === habitTabState);
  if (filteredHabits.length === 0) {
    box.append(emptyState('No habits in this category yet', 'Use "Add habit" below.'));
  } else {
    for (const h of filteredHabits) {
      const streak = await habitStreak(h);
      const completionPct = await habitCompletionPct(h);
      box.append(
        card([
          el('div', 'flex justify-between items-center', [
            el('span', null, h.name),
            streak > 0 ? el('span', 'streak-pill', [icon('flame'), `${streak}${h.frequency === 'weekly' ? 'w' : ''}`]) : null,
          ]),
          el('div', 'mt-4', xpBar(completionPct)),
          el('div', 'flex justify-between mt-1', [
            el('span', 'text-xs text-dim', `${completionPct}% consistency`),
            el('span', 'text-xs text-dim', 'tap to edit'),
          ]),
        ], { tappable: true, onClick: () => openHabitForm({ habit: h, onDone: () => rerender(root) }) })
      );
    }
  }
  box.append(
    el('div', 'mt-3', button('+ Add your own task / habit', {
      variant: 'ghost',
      block: true,
      onClick: () => openHabitForm({ defaultFrequency: habitTabState, onDone: () => rerender(root) }),
    }))
  );

    },
    progress: async (box) => {
  box.append(sectionHeader(null, 'Progress'));

  const showChart = (k) => dash.charts.includes(k);
  const weeklyDelta = weeklySummary.deltaPct;
  const weeklyPct = weeklySummary.lastWeek === 0
    ? 100
    : Math.min(100, (weeklySummary.thisWeek / Math.max(weeklySummary.lastWeek, 1)) * 100);
  if (showChart('week')) box.append(
    card([
      el('div', 'chart-card__header', [
        el('span', 'chart-card__title', 'This week vs last week'),
        el('span', 'chart-card__meta', weeklyDelta === null ? '—' : `${weeklyDelta > 0 ? '+' : ''}${weeklyDelta}%`),
      ]),
      xpBar(weeklyPct),
      el('p', 'text-xs text-dim mt-1', `${weeklySummary.thisWeek} habit completions this week vs ${weeklySummary.lastWeek} last week`),
    ])
  );

  const chartBox = el('div', 'dash-charts');
  box.append(chartBox);
  const xpChartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'XP growth (14 days)')])]);
  xpCanvas = chartCanvas(100);
  xpChartCard.append(xpCanvas);
  if (showChart('xp')) chartBox.append(xpChartCard);

  const consistencyChartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Habit consistency (14 days)')])]);
  consistencyCanvas = chartCanvas(100);
  consistencyChartCard.append(consistencyCanvas);
  if (showChart('consistency')) chartBox.append(consistencyChartCard);

  const studyChartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Study hours / day (14 days)')])]);
  studyCanvas = chartCanvas(100);
  studyChartCard.append(studyCanvas);
  if (showChart('study')) chartBox.append(studyChartCard);

    },
    motivation: async (box) => {
  box.append(sectionHeader(null, 'Motivation'));
  const coachCard = card([
    el('span', 'text-xs text-dim', 'YOUR COACH TODAY'),
    el('p', 'coach-headline', coach.headline),
    ...coach.extra.map((line) => el('p', 'text-xs text-dim mt-2', line)),
  ]);
  coachCard.classList.add('card--glass');
  box.append(coachCard);
  box.append(el('div', 'mt-3', card([el('p', null, `"${affirmation}"`)])));

  const visionBox = el('div', 'vision-box');
  visionBox.textContent = vision;
  visionBox.contentEditable = 'true';
  visionBox.addEventListener('blur', async () => {
    await setVisionText(visionBox.textContent.trim());
  });
  box.append(
    el('div', 'mt-3', card([
      el('span', 'text-xs text-dim', 'WHY I STARTED'),
      el('div', 'mt-1', visionBox),
    ]))
  );

    },
    quick: async (box) => {
  box.append(sectionHeader(null, 'Quick actions'));
  const quickGrid = el('div', 'quick-actions-grid');
  const quickActions = [
    { label: 'Pomodoro', iconName: 'timer', onClick: actionStartPomodoro },
    { label: 'Study log', iconName: 'book', onClick: actionLogStudySession },
    { label: 'Workout', iconName: 'dumbbell', onClick: actionAddWorkout },
    { label: 'Meal', iconName: 'utensils', onClick: actionLogMeal },
    { label: 'Mood', iconName: 'smile', onClick: actionMoodCheck },
    { label: 'Journal', iconName: 'notebook', onClick: actionOpenJournal },
    { label: 'Hydration', iconName: 'droplet', onClick: async () => { await actionQuickHydration(); await rerender(root); } },
  ];
  quickActions.forEach(({ label, iconName, onClick }) => {
    const btn = el('button', 'quick-action', [icon(iconName), el('span', null, label)]);
    btn.addEventListener('click', onClick);
    quickGrid.append(btn);
  });
  box.append(quickGrid);

    },
  };

  const grid = el('div', `dash-grid dash-grid--${dash.layout}`);
  page.append(grid);
  for (const key of dash.order) {
    if (dash.hidden.includes(key) || !builders[key]) continue;
    const meta = SECTIONS.find((x) => x.key === key);
    const box = el('section', `dash-sec dash-sec--${key} dash-span-${meta.span}`);
    await builders[key](box);
    if (box.childNodes.length) grid.append(box);
  }
  page.append(el('div', 'mt-6', button('🎛️ Customize Home', { variant: 'ghost', block: true, onClick: () => navigate('/settings/dashboard') })));

  root.appendChild(page);

  // Charts render after mount so canvases have real layout width.
  requestAnimationFrame(() => {
    if (xpCanvas?.isConnected) renderLineChart(xpCanvas, xpSeries, { color: getCSSColor('--c-emerald-soft') });
    if (consistencyCanvas?.isConnected) renderBarChart(consistencyCanvas, consistencySeries, { maxOverride: 100, color: getCSSColor('--c-royal') });
    if (studyCanvas?.isConnected) renderLineChart(studyCanvas, studySeries, { color: getCSSColor('--c-gold') });
  });
}
