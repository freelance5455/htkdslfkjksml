/**
 * PresencePage.js — Confidence practice logging + Grooming/wardrobe tracker.
 */
import { el, card, sectionHeader, button, chipSelect, textareaInput, emptyState } from '../components/ui.js';
import {
  PRACTICE_TYPES, logConfidencePractice, getRecentConfidenceLogs, logConfidenceRating, getTodayRating,
} from '../modules/presence/confidence/confidenceService.js';
import { sliderField, statGrid } from '../components/ui.js';
import { chartCanvas, renderLineChart } from '../components/charts/canvasChart.js';
import { dailySeries } from '../core/stats/statsService.js';
import {
  getGroomingData, logBarberVisit, updateWardrobeNotes, daysUntilBarber,
} from '../modules/presence/grooming/groomingService.js';
import { showToast } from '../core/notifications/toast.js';

let activeTab = 'confidence';
let selectedPractice = PRACTICE_TYPES[0];

function tabRow(root) {
  const row = el('div', 'tab-row');
  [{ key: 'confidence', label: 'Confidence' }, { key: 'grooming', label: 'Grooming' }].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${activeTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { activeTab = key; await rerender(root); });
    row.append(pill);
  });
  return row;
}

async function renderConfidenceTab(page, root) {
  const recent = (await getRecentConfidenceLogs(12)).filter((r) => r.practiceType !== 'daily-rating').slice(0, 8);
  const note = textareaInput({ placeholder: 'Notes (optional)' });

  // --- Daily confidence rating (1-10) + 30-day trend ---
  const todayRating = await getTodayRating();
  const rating = sliderField('How confident do you feel today?', { min: 1, max: 10, value: todayRating?.rating || 6 });
  const series = await dailySeries(30, 'confidence');
  const rated = series.filter((x) => x.value > 0);
  page.append(sectionHeader(todayRating ? `Today: ${todayRating.rating}/10` : null, 'Daily rating'));
  page.append(card([
    rating.node,
    el('div', 'mt-3', button(todayRating ? 'Update rating' : 'Save rating', { block: true, onClick: async () => {
      await logConfidenceRating(rating.getValue());
      showToast('Rating saved.');
      await rerender(root);
    } })),
  ]));
  if (rated.length >= 1) {
    const avg = Math.round((rated.reduce((a, x) => a + x.value, 0) / rated.length) * 10) / 10;
    page.append(statGrid([{ value: avg, label: '30-day average' }, { value: rated.length, label: 'Days rated' }]));
    const cc = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Confidence trend (30 days)')])]);
    const canvas = chartCanvas(100);
    cc.append(canvas);
    page.append(el('div', 'mt-3', cc));
    requestAnimationFrame(() => renderLineChart(canvas, series.map((x) => ({ date: x.date, value: x.value })), { maxOverride: 10 }));
  }

  page.append(sectionHeader(null, 'Log a practice'));
  const chips = chipSelect(
    PRACTICE_TYPES.map((p) => ({ label: p, value: p })),
    selectedPractice,
    async (value) => { selectedPractice = value; await rerender(root); }
  );
  page.append(card([
    chips,
    note,
    el('div', 'mt-3', button('Save', { block: true, onClick: async () => {
      await logConfidencePractice({ practiceType: selectedPractice, note: note.value });
      showToast('Practice logged.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, 'Recent logs'));
  page.append(card(
    recent.length === 0
      ? [emptyState('No entries yet', 'Log your first practice above.')]
      : recent.map((r) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', r.practiceType),
          el('span', 'text-xs text-dim', r.date),
        ]))
  ));
}

async function renderGroomingTab(page, root) {
  const data = await getGroomingData();
  const remaining = await daysUntilBarber();

  page.append(sectionHeader(null, 'Barber cycle'));
  page.append(card([
    el('p', null, remaining === null
      ? 'No barber visit logged yet.'
      : remaining >= 0
        ? `${remaining} days until your next recommended visit.`
        : `${Math.abs(remaining)} days overdue for a fresh fade.`),
    el('div', 'mt-3', button('Log barber visit today', { block: true, onClick: async () => {
      await logBarberVisit();
      showToast('Barber visit logged.');
      await rerender(root);
    } })),
  ]));

  page.append(sectionHeader(null, 'Wardrobe & style notes'));
  const notesInput = textareaInput({ placeholder: 'Style notes', value: data.wardrobeNotes, rows: 4 });
  page.append(card([
    notesInput,
    el('div', 'mt-3', button('Save notes', { variant: 'ghost', block: true, onClick: async () => {
      await updateWardrobeNotes(notesInput.value);
      showToast('Notes saved.');
    } })),
  ]));
}

async function rerender(root) {
  root.innerHTML = '';
  await PresencePage(root);
}

export async function PresencePage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Presence'), el('p', 'page-subtitle', 'Confidence · Grooming'));
  page.append(tabRow(root));

  if (activeTab === 'confidence') await renderConfidenceTab(page, root);
  else await renderGroomingTab(page, root);

  root.appendChild(page);
}
