/**
 * settingsPanels.js — the new Settings categories: Appearance, Dashboard, Accessibility, App behaviour.
 * Each panel writes through prefsService / dashPrefs, so changes apply instantly and persist.
 */
import { el, card, button, sectionHeader, textInput, fieldLabel } from '../components/ui.js';
import { showToast } from '../core/notifications/toast.js';
import { updateProfile, applyTheme, getProfile } from '../core/profile/profileService.js';
import { ACCENTS, START_SCREENS, getPrefsSync, savePrefs, resetPrefs } from '../core/profile/prefsService.js';
import { SECTIONS, VITAL_TILES, CHARTS, getDash, saveDash, resetDash, moveSection, toggleSection, toggleInList } from '../modules/dashboard/dashPrefs.js';
import { navigate } from '../core/router.js';

/* ---------- small controls ---------- */
/** A row of chips that updates its highlight in place (no page redraw, so scroll position stays). */
function options(list, current, onPick) {
  const row = el('div', 'chip-row');
  const chips = list.map(({ label, value, hint }) => {
    const c = el('button', `chip${value === current ? ' chip--active' : ''}`, label);
    if (hint) c.title = hint;
    c.addEventListener('click', async () => { chips.forEach((x) => x.el.classList.toggle('chip--active', x.value === value)); await onPick(value); });
    return { el: c, value };
  });
  chips.forEach((c) => row.append(c.el));
  return row;
}

export function switchRow(label, hint, checked, onChange) {
  const input = el('input'); input.type = 'checkbox'; input.checked = checked; input.setAttribute('role', 'switch');
  input.addEventListener('change', () => onChange(input.checked));
  return el('label', 'switch-row', [
    el('span', 'switch-row__text', [el('span', 'switch-row__label', label), hint ? el('span', 'switch-row__hint', hint) : null]),
    el('span', 'switch', [input, el('span', 'switch__track')]),
  ]);
}

const group = (title, hint, ...kids) => card([el('div', 'pref-title', title), hint ? el('p', 'text-xs text-dim', hint) : null, el('div', 'mt-3', kids)]);

const FONTS = [{ label: 'Small', value: 'small' }, { label: 'Default', value: 'default' }, { label: 'Large', value: 'large' }, { label: 'Extra large', value: 'xlarge' }];

/* ============================ APPEARANCE ============================ */
export async function appearancePanel(page) {
  const p = getPrefsSync(); const profile = await getProfile();
  const set = (k) => async (v) => { await savePrefs({ [k]: v }); };

  // live preview — it is the real components, so what you see is what you get
  page.append(card([
    el('div', 'flex justify-between items-center', [el('strong', null, 'Preview'), el('span', 'streak-pill', '🔥 7d')]),
    el('p', 'text-xs text-dim mt-1', 'Every change below shows here and across the whole app.'),
    el('div', 'mt-3', el('div', 'xp-bar', el('div', 'xp-bar__fill'))),
    el('div', 'mt-3 flex gap-3', [button('Primary', {}), button('Secondary', { variant: 'ghost' })]),
  ]));
  page.querySelector('.xp-bar__fill').style.width = '64%';

  page.append(sectionHeader(null, 'Theme'));
  page.append(group('Colour mode', 'Auto follows your phone\'s dark / light setting.', options([{ label: '🌙 Dark', value: 'dark' }, { label: '☀️ Light', value: 'light' }, { label: '🌗 Auto', value: 'auto' }], profile.theme, async (v) => { await updateProfile({ theme: v }); await applyTheme(); })));

  const sw = el('div', 'swatch-row');
  const swatches = ACCENTS.map((a) => {
    const b = el('button', `swatch${a.value === p.accent ? ' swatch--active' : ''}`); b.style.background = a.color; b.title = a.label; b.setAttribute('aria-label', a.label);
    b.addEventListener('click', async () => { swatches.forEach((x) => x.classList.toggle('swatch--active', x === b)); name.textContent = a.label; await savePrefs({ accent: a.value }); });
    return b;
  });
  const name = el('span', 'text-xs text-dim', ACCENTS.find((a) => a.value === p.accent)?.label || 'Emerald');
  swatches.forEach((s) => sw.append(s));
  page.append(group('Accent colour', 'Emerald is the default Life Guide look.', sw, el('div', 'mt-2', name)));

  page.append(sectionHeader(null, 'Text & layout'));
  page.append(group('Font size', null, options(FONTS, p.font, set('font'))));
  page.append(group('Layout density', 'Compact fits more on screen; spacious is calmer.', options([{ label: 'Compact', value: 'compact' }, { label: 'Comfortable', value: 'comfortable' }, { label: 'Spacious', value: 'spacious' }], p.density, set('density'))));

  page.append(sectionHeader(null, 'Cards'));
  page.append(group('Card appearance', null, options([{ label: 'Soft shadow', value: 'soft' }, { label: 'Flat', value: 'flat' }, { label: 'Outlined', value: 'outlined' }, { label: 'Tinted', value: 'glass' }, { label: 'Raised', value: 'elevated' }], p.cardStyle, set('cardStyle'))));
  page.append(group('Corners', null, options([{ label: 'Sharp', value: 'sharp' }, { label: 'Rounded', value: 'rounded' }, { label: 'Extra round', value: 'round' }], p.corners, set('corners'))));

  page.append(sectionHeader(null, 'Motion'));
  page.append(group('Animation intensity', 'Off is best on slow phones and saves battery.', options([{ label: 'Off', value: 'off' }, { label: 'Subtle', value: 'subtle' }, { label: 'Full', value: 'full' }], p.motion, set('motion'))));
  page.append(el('p', 'text-xs text-dim mt-2', 'Reduce-motion (Accessibility) overrides this.'));

  page.append(el('div', 'mt-4', button('Reset appearance to default', { variant: 'ghost', block: true, onClick: async () => {
    if (!window.confirm('Reset accent, font, density, cards and animation to the Life Guide defaults?')) return;
    await resetPrefs(); await updateProfile({ theme: 'dark' }); await applyTheme(); showToast('Appearance reset.'); navigate('/settings'); setTimeout(() => navigate('/settings/appearance'), 30);
  } })));
}

/* ============================ ACCESSIBILITY ============================ */
export async function accessibilityPanel(page) {
  const p = getPrefsSync();
  page.append(group('Font size', 'Also available in Appearance.', options(FONTS, p.font, async (v) => { await savePrefs({ font: v }); })));
  page.append(card([
    switchRow('Reduce motion', 'Turns animations and confetti off, whatever the animation setting.', p.reduceMotion === 'always', (v) => savePrefs({ reduceMotion: v ? 'always' : 'system' })),
    switchRow('Larger touch targets', 'Buttons and rows become at least 48 px tall.', p.touch === 'large', (v) => savePrefs({ touch: v ? 'large' : 'normal' })),
    switchRow('High contrast', 'Stronger text and borders.', p.contrast === 'high', (v) => savePrefs({ contrast: v ? 'high' : 'normal' })),
    switchRow('Vibration feedback', 'Short buzzes for timers, wrong PIN and reminders.', p.vibrate, (v) => savePrefs({ vibrate: v })),
  ]));
  page.append(el('p', 'text-xs text-dim mt-3', 'With "Reduce motion" off, Life Guide still follows your phone\'s own reduce-motion setting automatically.'));
}

/* ============================ APP BEHAVIOUR ============================ */
export async function behaviourPanel(page) {
  const p = getPrefsSync();
  page.append(group('Open on', 'Which tab Life Guide shows when it starts.', options(START_SCREENS, p.startScreen, async (v) => { await savePrefs({ startScreen: v }); })));
  page.append(card([
    switchRow('Welcome greeting', '"Good Morning, Abbas!" screen each time you open the app.', p.greeting, (v) => savePrefs({ greeting: v })),
    switchRow('Celebrations', 'Confetti when you finish habits, workouts and reviews.', p.celebrations, (v) => savePrefs({ celebrations: v })),
  ]));
}

/* ============================ DASHBOARD ============================ */
function layoutChoice(current, onPick) {
  const mk = (key, title, sub, cols) => {
    const b = el('button', `layout-opt${current === key ? ' layout-opt--active' : ''}`);
    const art = el('div', `layout-art layout-art--${cols}`, [el('i'), el('i'), el('i'), el('i')]);
    b.append(art, el('strong', null, title), el('span', 'text-xs text-dim', sub));
    b.addEventListener('click', async () => { row.querySelectorAll('.layout-opt').forEach((x) => x.classList.toggle('layout-opt--active', x === b)); await onPick(key); });
    return b;
  };
  const row = el('div', 'layout-row', [mk('comfortable', 'Comfortable', 'One column', 1), mk('compact', 'Compact', 'Two columns', 2)]);
  return row;
}

export async function dashboardPanel(page) {
  const dash = await getDash();
  page.append(group('Home layout', 'Switch any time — your arrangement is kept.', layoutChoice(dash.layout, (v) => saveDash({ layout: v }))));

  page.append(sectionHeader('Show, hide and reorder', 'Sections'));
  const list = el('div', 'sec-list');
  const draw = async () => {
    const d = await getDash();
    list.replaceChildren(...d.order.map((key, i) => {
      const meta = SECTIONS.find((s) => s.key === key);
      const hidden = d.hidden.includes(key);
      const up = el('button', 'icon-btn', '↑'); up.disabled = i === 0; up.setAttribute('aria-label', `Move ${meta.label} up`);
      const down = el('button', 'icon-btn', '↓'); down.disabled = i === d.order.length - 1; down.setAttribute('aria-label', `Move ${meta.label} down`);
      up.addEventListener('click', async () => { await moveSection(key, -1); await draw(); });
      down.addEventListener('click', async () => { await moveSection(key, 1); await draw(); });
      const vis = el('button', `icon-btn${hidden ? '' : ' icon-btn--on'}`, hidden ? '🚫' : '👁️'); vis.setAttribute('aria-label', `${hidden ? 'Show' : 'Hide'} ${meta.label}`);
      vis.addEventListener('click', async () => { await toggleSection(key); await draw(); });
      return el('div', `sec-row${hidden ? ' sec-row--hidden' : ''}`, [
        el('span', 'sec-row__icon', meta.icon),
        el('span', 'sec-row__text', [el('span', 'sec-row__label', meta.label), el('span', 'sec-row__hint', hidden ? 'Hidden' : meta.hint)]),
        up, down, vis,
      ]);
    }));
  };
  await draw();
  page.append(card([list]));

  page.append(sectionHeader(null, 'Important statistics'));
  const check = (field, items, d) => items.map((it) => switchRow(it.label, null, d[field].includes(it.key), async () => { await toggleInList(field, it.key); }));
  page.append(group('Vitals shown with Life Score', 'Life Score itself always stays.', ...check('vitals', VITAL_TILES, dash)));
  page.append(group('Charts in the Progress section', null, ...check('charts', CHARTS, dash)));

  page.append(sectionHeader(null, 'Daily priorities'));
  const inputs = [0, 1, 2].map((i) => {
    const inp = textInput({ placeholder: `Priority ${i + 1} (e.g. Finish Chem past questions)`, value: dash.priorities[i] || '' });
    inp.maxLength = 80;
    inp.addEventListener('change', async () => {
      const vals = inputs.map((x) => x.value.trim()).filter(Boolean);
      await saveDash({ priorities: vals }); showToast('Priorities saved.');
    });
    return inp;
  });
  page.append(card([
    el('p', 'text-xs text-dim', 'Your own top priorities. They appear on Home as a checklist and reset every day. Leave empty to hide the section.'),
    ...inputs.map((i) => el('div', 'mt-2', i)),
  ]));

  page.append(el('div', 'mt-4 flex gap-3', [
    button('👀 See Home', { onClick: () => navigate('/') }),
    button('Restore default arrangement', { variant: 'ghost', onClick: async () => {
      if (!window.confirm('Restore the default Home arrangement? Your layout, order, hidden sections and priorities will reset.')) return;
      await resetDash(); showToast('Home restored.'); navigate('/settings'); setTimeout(() => navigate('/settings/dashboard'), 30);
    } }),
  ]));
}
