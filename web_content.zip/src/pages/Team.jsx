import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { ArrowRight, Loader2, ShieldCheck } from "lucide-react";
import useReports from "@/hooks/useReports";
import { useAuth } from "@/lib/AuthContext";
import { updateReportStatus } from "@/lib/reportActions";
import { STATUSES, statusMeta, computeStats, reportDate } from "@/lib/reportStats";
import StatusPill from "@/components/StatusPill";
import CategoryChip from "@/components/CategoryChip";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function Team() {
  const { reports, loading } = useReports();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [status, setStatus] = useState("all");
  const [busyId, setBusyId] = useState(null);

  const stats = useMemo(() => computeStats(reports), [reports]);
  const queue = useMemo(() => {
    const active = reports.filter((r) => r.status !== "resolved");
    const scoped = status === "all" ? active : active.filter((r) => r.status === status);
    return scoped.sort((a, b) => {
      const weight = { high: 0, medium: 1, low: 2 };
      const diff = (weight[a.priority] ?? 1) - (weight[b.priority] ?? 1);
      return diff !== 0 ? diff : new Date(reportDate(b) || 0) - new Date(reportDate(a) || 0);
    });
  }, [reports, status]);

  const handleStatus = async (report, next) => {
    setBusyId(report.id);
    try {
      await updateReportStatus(report, next, { authorName: user.full_name || user.email });
      toast({ title: "Board updated", description: `${report.title} → ${statusMeta(next).label}` });
    } catch (err) {
      toast({
        title: "Couldn't update",
        description: err.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-5 py-12 lg:px-8">
      <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-primary">City team</p>
      <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl">
        The work queue
      </h1>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
        Everything still open, most urgent first. Updates you publish here appear on the public
        board straight away.
      </p>

      <div className="mt-7 grid grid-cols-3 gap-3">
        {[
          { label: "Waiting", value: stats.open, color: "#d99a2b" },
          { label: "In progress", value: stats.inProgress, color: "#2f7d95" },
          { label: "Resolved", value: stats.resolved, color: "#16653f" },
        ].map((item) => (
          <div key={item.label} className="rounded-2xl border border-border bg-card p-4">
            <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.1em] text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: item.color }} />
              {item.label}
            </span>
            <p className="mt-2 font-display text-2xl font-semibold tabular-nums">{item.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {[{ value: "all", label: "Everything open" }, ...STATUSES.slice(0, 2)].map((item) => (
          <button
            key={item.value}
            onClick={() => setStatus(item.value)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-xs transition-colors",
              status === item.value
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:text-foreground"
            )}
          >
            {item.label}
          </button>
        ))}
        {!isAdmin && (
          <span className="ml-auto inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            Only the city team can change a status
          </span>
        )}
      </div>

      {loading ? (
        <div className="mt-10 flex justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-border border-t-primary" />
        </div>
      ) : queue.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-border bg-card/60 p-12 text-center">
          <p className="font-display text-lg font-semibold">The queue is clear</p>
          <p className="mt-1 text-sm text-muted-foreground">Nothing open in this view right now.</p>
        </div>
      ) : (
        <ul className="mt-6 divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card">
          {queue.map((report) => (
            <li key={report.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <StatusPill status={report.status} />
                  <CategoryChip category={report.category} />
                  {report.priority === "high" && (
                    <span className="text-[10px] font-medium uppercase tracking-[0.1em] text-[#8E3B24]">
                      Urgent
                    </span>
                  )}
                </div>
                <Link
                  to={`/issues/${report.id}`}
                  className="mt-1.5 block truncate font-display text-[15px] font-semibold hover:text-primary"
                >
                  {report.title}
                </Link>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  {report.area}
                  {reportDate(report)
                    ? ` · raised ${format(new Date(reportDate(report)), "d MMM")}`
                    : ""}
                </p>
              </div>

              {isAdmin ? (
                <div className="flex flex-wrap items-center gap-2">
                  {STATUSES.filter((item) => item.value !== report.status).map((item) => (
                    <button
                      key={item.value}
                      onClick={() => handleStatus(report, item.value)}
                      disabled={busyId === report.id}
                      className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-[11px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground disabled:opacity-50"
                    >
                      {busyId === report.id && <Loader2 className="h-3 w-3 animate-spin" />}
                      {item.label}
                    </button>
                  ))}
                </div>
              ) : (
                <Link
                  to={`/issues/${report.id}`}
                  className="inline-flex items-center gap-1 text-[11px] font-medium text-primary hover:underline"
                >
                  Open report
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}