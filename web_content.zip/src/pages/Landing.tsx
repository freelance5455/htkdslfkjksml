/* ============================================
   plix_ai studio — Landing page
   Engineering-first. No fluff.
   ============================================ */

import { useState } from 'react';
import type { PageId } from '../types';
import {
  IconZap, IconShield, IconPackage, IconCode, IconChevronRight,
  IconTerminal, IconAndroid, IconCheck
} from '../components/Icons';

interface LandingProps {
  onNavigate: (page: PageId) => void;
}

export default function Landing({ onNavigate }: LandingProps) {
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);

  const features = [
    {
      icon: <IconPackage size={22} />,
      title: 'Multi-source import',
      desc: 'ZIP files, HTML sites, live URLs, PWA manifests, or existing APK/AAB files — we handle them all.',
    },
    {
      icon: <IconShield size={22} />,
      title: 'Security-first builds',
      desc: 'Isolated containers, encrypted keystores, never-log-secrets policy, and artifact expiration.',
    },
    {
      icon: <IconZap size={22} />,
      title: 'Full build control',
      desc: 'Signing wizard, permissions checklist, SDK targeting, deep links, and preflight validation.',
    },
    {
      icon: <IconCode size={22} />,
      title: 'Developer integration',
      desc: 'REST API, CLI tools, GitHub Actions CI/CD, and template library for common project types.',
    },
  ];

  const workflowSteps = [
    { num: '01', label: 'Import', desc: 'Drop your source files or enter a URL' },
    { num: '02', label: 'Brand', desc: 'Set app name, icon, colors, and orientation' },
    { num: '03', label: 'Configure', desc: 'SDK targets, signing, permissions, and deep links' },
    { num: '04', label: 'Build', desc: 'Validate → Package → Sign → Download' },
  ];

  return (
    <div className="min-h-screen">
      {/* Nav bar */}
      <header className="fixed top-0 left-0 right-0 z-30 surface-0/80 backdrop-blur-md border-b border-subtle">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-sky-500/15 border border-sky-500/25 flex items-center justify-center">
              <span className="font-mono text-sky-400 font-bold text-xs">P</span>
            </div>
            <span className="text-sm font-semibold text-stone-200">plix_ai studio</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('dashboard')}
              className="btn btn-ghost btn-sm"
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigate('convert')}
              className="btn btn-primary btn-sm"
            >
              Start Building
              <IconChevronRight size={14} />
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-28 pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full surface-2 border border-subtle mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span className="text-xs text-stone-400">Open-source Android converter</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1] mb-5">
            Convert any web project
            <br />
            <span className="text-sky-400">into an Android app</span>
          </h1>

          <p className="text-lg text-stone-400 max-w-2xl mx-auto mb-8 leading-relaxed">
            Package ZIP files, HTML sites, PWAs, and web apps into production-ready
            APK or AAB files. Full signing control, SDK targeting, and CI/CD integration.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12">
            <button
              onClick={() => onNavigate('convert')}
              className="btn btn-primary btn-xl"
            >
              <IconAndroid size={18} />
              Create Android Project
            </button>
            <button
              onClick={() => onNavigate('dashboard')}
              className="btn btn-secondary btn-xl"
            >
              View Projects
            </button>
          </div>

          {/* Mockup terminal */}
          <div className="max-w-2xl mx-auto">
            <div className="surface-1 border border-subtle rounded-xl overflow-hidden shadow-lg text-left">
              <div className="flex items-center gap-2 px-4 py-2.5 border-b border-subtle surface-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                </div>
                <span className="text-xs text-stone-500 ml-2 font-mono">plix build --source ./dist --format apk</span>
              </div>
              <div className="px-4 py-3 font-mono text-xs space-y-1">
                <p className="text-stone-500">{'>'} Validating source structure...</p>
                <p className="text-stone-500">{'>'} Preparing WebView wrapper template...</p>
                <p className="text-stone-500">{'>'} Packaging assets (4.2 MB)...</p>
                <p className="text-stone-500">{'>'} Signing with release keystore...</p>
                <p className="text-emerald-400">{'>'} ✓ Build complete: app-release.apk (SHA-256: a7f3b2...)</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Workflow */}
      <section className="py-16 px-6 border-t border-subtle">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold mb-2">Four-step conversion</h2>
            <p className="text-stone-400">From source to signed APK in minutes, not hours.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {workflowSteps.map((step, i) => (
              <button
                key={i}
                onClick={() => onNavigate('convert')}
                className="card card-interactive text-left group"
              >
                <div className="text-xs font-mono text-sky-500 mb-2">{step.num}</div>
                <h3 className="text-base font-semibold mb-1 group-hover:text-sky-400 transition-colors">{step.label}</h3>
                <p className="text-sm text-stone-400 leading-relaxed">{step.desc}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-6 border-t border-subtle">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold mb-2">Built for developers</h2>
            <p className="text-stone-400">Real engineering tools. Not marketing demos.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((f, i) => (
              <div
                key={i}
                className="card flex gap-4 items-start transition-all duration-200"
                onMouseEnter={() => setHoveredFeature(i)}
                onMouseLeave={() => setHoveredFeature(null)}
                style={{
                  borderColor: hoveredFeature === i ? 'rgba(56,189,248,0.2)' : undefined,
                }}
              >
                <div className="w-10 h-10 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 flex-shrink-0">
                  {f.icon}
                </div>
                <div>
                  <h3 className="font-semibold mb-1">{f.title}</h3>
                  <p className="text-sm text-stone-400 leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security section */}
      <section className="py-16 px-6 border-t border-subtle">
        <div className="max-w-4xl mx-auto">
          <div className="card">
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 flex-shrink-0">
                <IconShield size={24} />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold mb-3">Security & privacy</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    'Isolated build containers per job',
                    'Keystore passwords encrypted with AES-256',
                    'Artifacts auto-expire after 72 hours',
                    'Malware scanning on all uploads',
                    'Never-log-secrets policy enforced',
                    'Full data ownership — delete anytime',
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <IconCheck size={15} className="text-emerald-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-stone-300">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* API preview */}
      <section className="py-16 px-6 border-t border-subtle">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <IconTerminal size={18} className="text-sky-400" />
                <h2 className="text-xl font-bold">API-first architecture</h2>
              </div>
              <p className="text-stone-400 text-sm leading-relaxed mb-4">
                Integrate plix_ai into your CI/CD pipeline. POST a source bundle, poll for status,
                download the signed artifact. Full REST API with webhook support.
              </p>
              <button
                onClick={() => onNavigate('devtools')}
                className="btn btn-secondary btn-sm"
              >
                View API docs
                <IconChevronRight size={14} />
              </button>
            </div>
            <div className="flex-1 w-full">
              <div className="code-block text-xs">
{`POST /api/jobs
Content-Type: multipart/form-data

{
  "source": "@dist.zip",
  "format": "apk",
  "config": {
    "packageId": "com.example.app",
    "appName": "My App",
    "minSdk": 24
  }
}`}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 border-t border-subtle">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to build?</h2>
          <p className="text-stone-400 mb-8">
            No account required. Everything runs locally in your browser.
          </p>
          <button
            onClick={() => onNavigate('convert')}
            className="btn btn-primary btn-xl"
          >
            <IconAndroid size={18} />
            Start Conversion
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-subtle py-6 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-sky-500/15 border border-sky-500/20 flex items-center justify-center">
              <span className="font-mono text-sky-400 text-[9px] font-bold">P</span>
            </div>
            plix_ai studio — Source to Android
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => onNavigate('devtools')} className="hover:text-stone-300 transition-colors">API</button>
            <button onClick={() => onNavigate('settings')} className="hover:text-stone-300 transition-colors">Settings</button>
            <span className="text-stone-600">v0.1.0-alpha</span>
          </div>
        </div>
      </footer>
    </div>
  );
}