import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import { ExternalVideosStudio } from "@/components/features/ExternalVideosStudio";

export default function ExternalVideosPage() {
  return (
    <AppLayout
      title="Vídeos Externos & Galeria"
      subtitle="Importe vídeos da galeria do seu telemóvel, YouTube, TikTok e Instagram com Player Universal"
    >
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <ExternalVideosStudio />
      </div>
    </AppLayout>
  );
}
