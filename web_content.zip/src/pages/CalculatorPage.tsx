import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getFormulas, getFormulaById } from '../firebase/services';
import { Formula } from '../types';
import { DynamicCalculator } from '../components/calculator/DynamicCalculator';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import { Calculator, Search, Sliders, ChevronDown } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CalculatorPage: React.FC = () => {
  const { formulaId } = useParams<{ formulaId?: string }>();
  const { playSound, triggerHaptic } = useApp();
  const navigate = useNavigate();

  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [selectedFormula, setSelectedFormula] = useState<Formula | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectorQuery, setSelectorQuery] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const list = await getFormulas();
        setFormulas(list);

        if (formulaId) {
          const found = list.find((f) => f.id === formulaId || f.slug === formulaId);
          if (found) {
            setSelectedFormula(found);
          } else {
            const fetched = await getFormulaById(formulaId);
            setSelectedFormula(fetched || list[0] || null);
          }
        } else {
          // Default to Newton's second law
          const def = list.find((f) => f.id === 'newtons-second-law') || list[0] || null;
          setSelectedFormula(def);
        }
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [formulaId]);

  const handleFormulaSelect = (formula: Formula) => {
    playSound('tab');
    triggerHaptic('light');
    setSelectedFormula(formula);
    navigate(`/calculator/${formula.id}`, { replace: true });
    setSelectorQuery('');
  };

  const filteredFormulas = formulas.filter(
    (f) =>
      f.title.toLowerCase().includes(selectorQuery.toLowerCase()) ||
      f.formula.toLowerCase().includes(selectorQuery.toLowerCase()) ||
      f.category.toLowerCase().includes(selectorQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Calculator className="w-5 h-5 text-[#D65A1F]" />
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            Dynamic Formula Calculator & Unknown Solver
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-[#A9A39C]">
          Choose an equation to automatically construct verified input parameters, solve for any unknown variable, and compute step-by-step solutions.
        </p>
      </div>

      {/* Formula Selector Bar */}
      <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-5 shadow-xl space-y-3">
        <label className="text-[11px] font-mono font-semibold uppercase tracking-wider text-[#A9A39C] block">
          Select or Search Equation
        </label>

        <div className="relative">
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-[#A9A39C]" />
            <input
              type="text"
              value={selectorQuery}
              onChange={(e) => setSelectorQuery(e.target.value)}
              placeholder="Search equations (e.g. Newton, Ohm, Kinetic, Pressure, Density)..."
              className="w-full pl-10 pr-4 py-3 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] placeholder-[#A9A39C] text-sm focus:outline-none focus:border-[#D65A1F] transition-all"
            />
          </div>

          {/* Dropdown list if searching */}
          {selectorQuery && (
            <div className="absolute top-full left-0 right-0 mt-2 max-h-64 overflow-y-auto rounded-2xl bg-[#1C1C1C] border border-[#303030] shadow-2xl z-30 p-2 space-y-1">
              {filteredFormulas.length === 0 ? (
                <div className="p-3 text-xs text-[#A9A39C] text-center">
                  No matching formulas found
                </div>
              ) : (
                filteredFormulas.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => handleFormulaSelect(f)}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-[#232323] text-left transition-colors"
                  >
                    <div>
                      <div className="text-xs font-bold text-[#F5F2ED]">{f.title}</div>
                      <div className="text-[10px] text-[#A9A39C] font-mono">
                        {f.category} • {f.subcategory}
                      </div>
                    </div>
                    <div className="font-mono text-xs font-bold text-[#D65A1F]">
                      {f.formula}
                    </div>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        {/* Quick formula tags */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 text-xs scrollbar-thin">
          <span className="text-[10px] font-mono text-[#A9A39C] shrink-0 mr-1">
            Presets:
          </span>
          {formulas.slice(0, 8).map((f) => (
            <button
              key={f.id}
              onClick={() => handleFormulaSelect(f)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-mono shrink-0 transition-colors border ${
                selectedFormula?.id === f.id
                  ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] font-bold'
                  : 'bg-[#151515] text-[#A9A39C] hover:text-[#F5F2ED] border-[#303030]'
              }`}
            >
              {f.formula}
            </button>
          ))}
        </div>
      </div>

      {/* Dynamic Calculator Output */}
      {loading ? (
        <CardSkeleton />
      ) : selectedFormula ? (
        <DynamicCalculator formula={selectedFormula} />
      ) : (
        <div className="p-12 text-center text-[#A9A39C] rounded-2xl bg-[#1C1C1C] border border-[#303030]">
          Please select a formula to open the calculator.
        </div>
      )}
    </div>
  );
};
