import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, Navigate, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Bookmark,
  CheckCheck,
  Clock3,
  Coffee,
  FileText,
  Focus,
  Pause,
  Play,
  Pencil,
  Plus,
  Sparkles,
  StickyNote,
  Timer,
  Trash2,
  Trophy,
  X,
} from 'lucide-react';
import type { Lesson as LessonType } from '../types';
import { getLesson, getSubject, resolveVideo } from '../data/content';
import { useProfile } from '../hooks/useProfile';
import { useSettings } from '../hooks/useSettings';
import { useToast } from '../hooks/useToast';
import { KEYS, useStored } from '../services/storage';
import {
  getProgressMap,
  markCompleted,
  nextLessonInUnit,
  previousLessonInUnit,
  unitProgress,
} from '../services/progress';
import {
  addNote,
  bookmarksFor,
  deleteNote,
  exportNotesText,
  notesFor,
  removeBookmark,
  toggleBookmark,
  updateNote,
} from '../services/notes';
import { PageHeader } from '../components/layout/PageHeader';
import { VideoPlayer } from '../components/player/VideoPlayer';
import { LessonRow } from '../components/content/UnitAccordion';
import { Tabs } from '../components/ui/Tabs';
import { Badge, EmptyState, Modal } from '../components/ui/Feedback';
import { Button } from '../components/ui/Button';
import { QuizRunner } from '../components/quiz/QuizRunner';
import { AssistantPanel } from '../components/ai/AssistantPanel';
import { cn, formatDuration } from '../utils/format';

export default function Lesson() {
  const { subjectId = '', lessonId = '' } = useParams();
  const [searchParams] = useSearchParams();
  const requestedTime = searchParams.get('t');
  const navigate = useNavigate();
  const subject = getSubject(subjectId);
  const lesson = getLesson(lessonId);
  const { profile } = useProfile();
  const { settings, update } = useSettings();
  const { toast } = useToast();

  useStored(KEYS.progress, {});
  useStored(KEYS.notes, {});
  useStored(KEYS.bookmarks, {});

  const [tab, setTab] = useState('chapters');
  const [currentTime, setCurrentTime] = useState(0);
  const [seekTo, setSeekTo] = useState<{ time: number; key: number; play?: boolean } | null>(null);
  const [theater, setTheater] = useState(false);
  const [focus, setFocus] = useState(false);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [noteModal, setNoteModal] = useState<{ open: boolean; time: number; text: string; noteId?: string }>({
    open: false,
    time: 0,
    text: '',
  });
  const [celebrate, setCelebrate] = useState<string | null>(null);
  const [noteFilter, setNoteFilter] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
    setTab('chapters');
    setSeekTo(null);
    setFocus(false);
  }, [lessonId]);

  useEffect(() => {
    if (requestedTime === null) return;
    const time = Number(requestedTime);
    if (!Number.isFinite(time) || time < 0) return;
    setSeekTo({ time: Math.floor(time), key: Date.now(), play: false });
    setTab('chapters');
  }, [lessonId, requestedTime]);

  const unit = subject?.units.find((u) => u.lessons.some((l) => l.id === lessonId));
  const teacherId = subject ? profile.teacherBySubject[subject.id] ?? subject.teachers[0]?.id ?? '' : '';
  const notes = lesson ? notesFor(lesson.id) : [];
  const bookmarks = lesson ? bookmarksFor(lesson.id) : [];
  const progress = lesson ? getProgressMap()[lesson.id] : undefined;
  const teacher = subject?.teachers.find((t) => t.id === teacherId);

  const next = lesson ? nextLessonInUnit(lesson.id) : undefined;
  const previous = lesson ? previousLessonInUnit(lesson.id) : undefined;

  const startAt = useMemo(() => {
    if (!progress) return 0;
    if (progress.completed) return 0;
    return progress.position > 5 && progress.duration - progress.position > 15 ? Math.floor(progress.position) : 0;
  }, [progress]);

  if (!subject || !lesson || !unit) return <Navigate to="/subjects" replace />;

  const jump = (time: number) => {
    setSeekTo({ time, key: Date.now() });
    setTab('chapters');
    containerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const complete = () => {
    markCompleted(lesson);
    const wp = unitProgress(unit.lessons);
    if (wp === 100) setCelebrate(unit.title);
    else toast('أُضيف الدرس إلى إنجازاتك', 'success');
  };

  const saveNote = () => {
    if (!noteModal.text.trim()) return;
    let saved = false;
    if (noteModal.noteId) {
      saved = updateNote(lesson.id, noteModal.noteId, noteModal.text);
      toast(saved ? 'حُدّثت الملاحظة' : 'تعذّر حفظ التعديل على هذا الجهاز؛ أفرغ مساحة التخزين وحاول مجدداً.', saved ? 'success' : 'error');
    } else {
      saved = addNote(lesson.id, noteModal.time, noteModal.text);
      toast(saved ? 'حُفظت الملاحظة بختمها الزمني' : 'تعذّر حفظ الملاحظة على هذا الجهاز؛ أفرغ مساحة التخزين وحاول مجدداً.', saved ? 'success' : 'error');
    }
    if (!saved) return;
    setNoteModal({ open: false, time: 0, text: '' });
  };

  const filteredNotes = noteFilter ? notes.filter((n) => n.text.includes(noteFilter)) : notes;

  return (
    <div className="pb-4">
      {!focus ? (
        <PageHeader
          title={lesson.title}
          subtitle={`${subject.name} · ${unit.title}`}
          back={`/subject/${subject.id}`}
          action={
            <button
              type="button"
              onClick={() => setFocus(true)}
              aria-label="وضع التركيز"
              className="focus-ring flex h-9 items-center gap-1 rounded-full border border-[var(--line)] px-2.5 text-[0.68rem] text-[var(--ink-soft)]"
            >
              <Focus size={14} /> تركيز
            </button>
          }
        />
      ) : null}

      {/* المشغّل: يثبت أعلى الشاشة على الموبايل */}
      <div
        ref={containerRef}
        className={cn(
          'z-30 -mx-4 sm:-mx-5 lg:static lg:mx-0',
          focus ? 'sticky top-0 -mx-4 px-0' : 'sticky top-[49px] px-0',
          theater && 'fixed inset-0 z-[70] flex items-center bg-black',
        )}
      >
        <div className={cn('w-full', !theater && 'shadow-[0_18px_40px_-30px_rgba(0,0,0,0.55)] lg:shadow-none')}>
          <VideoPlayer
            key={lesson.id}
            videoId={resolveVideo(lesson, teacherId)}
            startAt={startAt}
            chapters={lesson.chapters}
            lesson={lesson}
            title={lesson.title}
            settings={settings}
            onSettingsChange={update}
            onProgress={(position) => setCurrentTime(position)}
            onEnded={() => {
              markCompleted(lesson);
            }}
            nextLabel={next?.title}
            onNext={next ? () => navigate(`/lesson/${subject.id}/${next.id}`) : undefined}
            previousLabel={previous?.title}
            onPrevious={previous ? () => navigate(`/lesson/${subject.id}/${previous.id}`) : undefined}
            onAddNote={(time) => setNoteModal({ open: true, time, text: '' })}
            onBookmark={(time) => {
              toggleBookmark(lesson.id, time, `عند ${formatDuration(time)}`);
              toast('تم تحديث الإشارة المرجعية', 'info');
            }}
            theater={theater}
            onToggleTheater={() => setTheater((t) => !t)}
            focusMode={focus}
            onToggleFocus={() => setFocus((f) => !f)}
            autoPlayNext={settings.autoplayNext}
            seekTo={seekTo}
          />
        </div>
        {theater ? (
          <button
            type="button"
            onClick={() => setTheater(false)}
            aria-label="إنهاء وضع المسرح"
            className="absolute end-3 top-3 z-50 flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur"
          >
            <X size={18} />
          </button>
        ) : null}
      </div>

      {/* بيانات الدرس */}
      <div className={cn('mt-4', focus && 'hidden')}>
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge tone="neutral">
            <Clock3 size={11} /> {formatDuration(lesson.duration)}
          </Badge>
          <Badge tone="neutral">{lesson.chapters.length} فصلاً</Badge>
          {progress?.completed ? <Badge tone="success">تمت المشاهدة</Badge> : null}
          {teacher ? <Badge tone="gold">{teacher.name}</Badge> : null}
        </div>
        <p className="mt-2 text-[0.82rem] leading-relaxed text-[var(--ink-soft)]">{lesson.description}</p>

        <div className="mt-3 flex flex-wrap gap-2">
          <Button
            size="sm"
            variant={progress?.completed ? 'outline' : 'primary'}
            icon={<CheckCheck size={15} />}
            onClick={complete}
          >
            {progress?.completed ? 'تمت المشاهدة' : 'علّم كمشاهد'}
          </Button>
          <Button
            size="sm"
            variant="soft"
            icon={<StickyNote size={15} />}
            onClick={() => setNoteModal({ open: true, time: currentTime, text: '' })}
          >
            ملاحظة عند {formatDuration(currentTime)}
          </Button>
          <Pomodoro />
        </div>
      </div>

      {!focus ? (
        <>
          <Tabs
            className="mb-3 mt-4"
            value={tab}
            onChange={setTab}
            items={[
              { id: 'chapters', label: 'الفصول', badge: lesson.chapters.length },
              { id: 'notes', label: 'الملاحظات', badge: notes.length },
              { id: 'files', label: 'الملفات', badge: lesson.attachments.length },
              { id: 'quiz', label: 'اختبار الدرس' },
            ]}
          />

          {tab === 'chapters' ? (
            <div className="space-y-3">
              <div className="card divide-y divide-[var(--line)] p-1">
                {lesson.chapters.map((chapter) => {
                  const active =
                    currentTime >= chapter.time &&
                    currentTime < (lesson.chapters[lesson.chapters.indexOf(chapter) + 1]?.time ?? lesson.duration);
                  return (
                    <button
                      key={`${chapter.time}-${chapter.title}`}
                      type="button"
                      onClick={() => jump(chapter.time)}
                      className={cn(
                        'focus-ring flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-start transition-colors hover:bg-[var(--surface-2)]',
                        active && 'bg-[var(--surface-2)]',
                      )}
                    >
                      <span className="w-11 shrink-0 font-mono text-[0.7rem] text-[var(--gold)]">
                        {formatDuration(chapter.time)}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-[0.82rem] text-[var(--ink)]">{chapter.title}</span>
                      <Play size={13} className="shrink-0 text-[var(--ink-soft)]" />
                    </button>
                  );
                })}
              </div>

              {bookmarks.length > 0 ? (
                <div className="card p-3">
                  <p className="mb-2 flex items-center gap-1.5 text-[0.75rem] font-medium text-[var(--ink)]">
                    <Bookmark size={14} /> إشاراتي المرجعية
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {bookmarks.map((b) => (
                      <span key={b.id} className="inline-flex items-center gap-1 rounded-full bg-[var(--surface-2)] pe-1 ps-2 py-1">
                        <button type="button" onClick={() => jump(b.time)} className="text-[0.68rem] text-[var(--ink)]">
                          {formatDuration(b.time)}
                        </button>
                        <button
                          type="button"
                          onClick={() => removeBookmark(lesson.id, b.id)}
                          aria-label="حذف الإشارة"
                          className="text-[var(--ink-soft)]"
                        >
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              ) : null}

              <div className="card p-4">
                <p className="mb-2 font-display text-[0.9rem] text-[var(--ink)]">أهداف الدرس</p>
                <ul className="space-y-1.5">
                  {lesson.objectives.map((objective) => (
                    <li key={objective} className="flex gap-2 text-[0.78rem] leading-relaxed text-[var(--ink-soft)]">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--gold)]" />
                      {objective}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : null}

          {tab === 'notes' ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <input
                  value={noteFilter ?? ''}
                  onChange={(e) => setNoteFilter(e.target.value || null)}
                  placeholder="ابحث في ملاحظاتك…"
                  aria-label="بحث في الملاحظات"
                  className="focus-ring h-10 flex-1 rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-[0.78rem]"
                />
                <Button size="sm" icon={<Plus size={15} />} onClick={() => setNoteModal({ open: true, time: currentTime, text: '' })}>
                  ملاحظة
                </Button>
              </div>

              {notes.length === 0 ? (
                <EmptyState
                  icon={<StickyNote size={18} />}
                  title="لا ملاحظات بعد"
                  description="أضف ملاحظة أثناء المشاهدة، وستُحفظ بالثانية التي كتبتها فيها لتعود إليها بنقرة."
                />
              ) : (
                <div className="space-y-2">
                  {filteredNotes.map((note) => (
                    <div key={note.id} className="card p-3">
                      <div className="flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => jump(note.time)}
                          className="rounded-full bg-[var(--gold-soft)] px-2 py-0.5 font-mono text-[0.66rem] text-[#8a5b06] dark:text-[var(--gold)]"
                        >
                          {formatDuration(note.time)}
                        </button>
                        <div className="flex items-center gap-2.5">
                          <button
                            type="button"
                            onClick={() => setNoteModal({ open: true, time: note.time, text: note.text, noteId: note.id })}
                            aria-label="تعديل الملاحظة"
                            className="text-[var(--ink-soft)] hover:text-[var(--ink)]"
                          >
                            <Pencil size={13} />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const deleted = deleteNote(lesson.id, note.id);
                              toast(deleted ? 'حُذفت الملاحظة' : 'تعذّر حذف الملاحظة من التخزين المحلي.', deleted ? 'info' : 'error');
                            }}
                            aria-label="حذف الملاحظة"
                            className="text-[var(--ink-soft)] hover:text-[var(--danger)]"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                      <p className="mt-1.5 whitespace-pre-wrap text-[0.8rem] leading-relaxed text-[var(--ink)]">{note.text}</p>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    block
                    onClick={() => exportNotesText(lesson.title, notes)}
                  >
                    تصدير الملاحظات (نص)
                  </Button>
                </div>
              )}
            </div>
          ) : null}

          {tab === 'files' ? (
            <div className="space-y-2">
              {lesson.attachments.length === 0 ? (
                <EmptyState icon={<FileText size={18} />} title="لا ملفات مرفقة" />
              ) : (
                lesson.attachments.map((file) => (
                  <Link key={file.id} to={`/library?file=${file.id}`} className="focus-ring card flex items-center gap-3 p-3">
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#fdece2] text-[#a63a12] dark:bg-[#3a1c12] dark:text-[#f5a67f]">
                      <FileText size={16} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[0.82rem] text-[var(--ink)]">{file.title}</span>
                      <span className="text-[0.65rem] text-[var(--ink-soft)]">PDF · {file.size}</span>
                    </span>
                  </Link>
                ))
              )}
            </div>
          ) : null}

          {tab === 'quiz' ? (
            lesson.quiz ? (
              <QuizRunner quiz={lesson.quiz} lesson={lesson} subjectId={subject.id} />
            ) : (
              <EmptyState
                icon={<Sparkles size={18} />}
                title="لا يوجد اختبار لهذا الدرس بعد"
                description="يمكنك تجربة اختبار الوحدة من صفحة الاختبارات، أو الانتقال للدرس التالي."
                action={
                  <Link
                    to="/tests"
                    className="focus-ring inline-flex h-10 items-center rounded-full bg-[var(--brand)] px-4 text-[0.78rem] text-[var(--brand-ink)]"
                  >
                    اختبارات الوحدة
                  </Link>
                }
              />
            )
          ) : null}

          {/* قائمة تشغيل الوحدة */}
          <section className="mt-5">
            <div className="mb-2 flex items-end justify-between">
              <h2 className="font-display text-base text-[var(--ink)]">{unit.title}</h2>
              <span className="text-[0.68rem] text-[var(--ink-soft)]">{unit.lessons.length} دروس</span>
            </div>
            <div className="card space-y-0.5 p-2">
              {unit.lessons.map((item: LessonType, index) => (
                <LessonRow
                  key={item.id}
                  lesson={item}
                  subject={subject}
                  index={index}
                  active={item.id === lesson.id}
                />
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={!previous}
                onClick={() => previous && navigate(`/lesson/${subject.id}/${previous.id}`)}
                className="focus-ring flex h-11 items-center justify-center gap-1.5 rounded-2xl border border-[var(--line)] text-[0.75rem] text-[var(--ink)] disabled:opacity-40"
              >
                الدرس السابق
              </button>
              <button
                type="button"
                disabled={!next}
                onClick={() => next && navigate(`/lesson/${subject.id}/${next.id}`)}
                className="focus-ring flex h-11 items-center justify-center gap-1.5 rounded-2xl bg-[var(--brand)] text-[0.75rem] text-[var(--brand-ink)] disabled:opacity-40"
              >
                الدرس التالي
              </button>
            </div>
          </section>
        </>
      ) : (
        <div className="mt-4 flex justify-center">
          <button
            type="button"
            onClick={() => setFocus(false)}
            className="focus-ring rounded-full border border-[var(--line)] px-4 py-2 text-[0.72rem] text-[var(--ink-soft)]"
          >
            إنهاء وضع التركيز
          </button>
        </div>
      )}

      {/* زر المساعد العائم */}
      {!focus ? (
        <button
          type="button"
          onClick={() => setAssistantOpen(true)}
          className="focus-ring fixed bottom-24 end-4 z-[60] flex h-13 items-center gap-2 rounded-full bg-[var(--gold)] px-4 font-medium text-[#3a2606] shadow-[0_18px_40px_-16px_rgba(0,0,0,0.5)] lg:bottom-8 lg:end-8"
          aria-label="اسأل المساعد"
        >
          <Sparkles size={17} />
          <span className="text-[0.78rem]">اسأل المساعد</span>
        </button>
      ) : null}

      <AssistantPanel
        open={assistantOpen}
        onClose={() => setAssistantOpen(false)}
        lesson={lesson}
        subject={subject}
        unit={unit}
      />

      {/* نافذة ملاحظة جديدة */}
      <Modal
        open={noteModal.open}
        onClose={() => setNoteModal({ open: false, time: 0, text: '' })}
        title={
          noteModal.noteId ? 'تعديل الملاحظة' : `ملاحظة عند ${formatDuration(noteModal.time)}`
        }
        footer={
          <div className="flex gap-2">
            <Button block onClick={saveNote} disabled={!noteModal.text.trim()}>
              {noteModal.noteId ? 'حفظ التعديل' : 'حفظ الملاحظة'}
            </Button>
            <Button variant="outline" onClick={() => setNoteModal({ open: false, time: 0, text: '' })}>
              إلغاء
            </Button>
          </div>
        }
      >
        <textarea
          value={noteModal.text}
          onChange={(e) => setNoteModal((s) => ({ ...s, text: e.target.value }))}
          rows={4}
          autoFocus
          placeholder="اكتب الفكرة التي لا تريد نسيانها…"
          aria-label="نص الملاحظة"
          className="focus-ring w-full resize-none rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3 text-[0.85rem] text-[var(--ink)]"
        />
      </Modal>

      {/* احتفال إنهاء الوحدة */}
      <Modal open={celebrate !== null} onClose={() => setCelebrate(null)} title="أحسنت!">
        <div className="py-2 text-center">
          <motion.div
            initial={{ scale: 0.8, rotate: -6 }}
            animate={{ scale: 1, rotate: 0 }}
            className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-3xl bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]"
          >
            <Trophy size={30} />
          </motion.div>
          <p className="font-display text-lg text-[var(--ink)]">أنهيت وحدة «{celebrate}»</p>
          <p className="mt-1 text-[0.8rem] leading-relaxed text-[var(--ink-soft)]">
            هذه علامة أن خطتك تعمل. خذ استراحة قصيرة، ثم عد للوحدة التالية.
          </p>
        </div>
      </Modal>
    </div>
  );
}

/** مؤقّت بومودورو صغير داخل صفحة الدرس */
function Pomodoro() {
  const { toast } = useToast();
  const [remaining, setRemaining] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');

  useEffect(() => {
    if (!running) return undefined;
    const id = window.setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          const nextMode = mode === 'focus' ? 'break' : 'focus';
          setMode(nextMode);
          setRunning(false);
          toast(
            nextMode === 'break'
              ? 'انتهت جلسة التركيز — قم، تحرّك ٥ دقائق، وأبعد عينيك عن الشاشة.'
              : 'انتهت الاستراحة — عد للدرس بذهن أصفى.',
            'info',
          );
          return nextMode === 'focus' ? 25 * 60 : 5 * 60;
        }
        return r - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [running, mode]);

  const label = `${Math.floor(remaining / 60)}:${`${remaining % 60}`.padStart(2, '0')}`;

  return (
    <div className="inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] px-2 py-1">
      {mode === 'focus' ? <Timer size={14} className="text-[var(--ink-soft)]" /> : <Coffee size={14} className="text-[var(--success)]" />}
      <span className="font-mono text-[0.72rem] text-[var(--ink)]" dir="ltr">
        {label}
      </span>
      <button
        type="button"
        onClick={() => setRunning((r) => !r)}
        aria-label={running ? 'إيقاف المؤقّت' : 'تشغيل المؤقّت'}
        className="focus-ring text-[var(--ink-soft)]"
      >
        {running ? <Pause size={13} /> : <Play size={13} />}
      </button>
      <span className="text-[0.6rem] text-[var(--ink-soft)]">{mode === 'focus' ? 'تركيز' : 'استراحة'}</span>
    </div>
  );
}
