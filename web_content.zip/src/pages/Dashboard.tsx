import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  AudioLines,
  CheckCircle2,
  ChevronLeft,
  CircleAlert,
  Clock3,
  FileJson,
  FileVideo2,
  FlaskConical,
  FolderOpen,
  HardDrive,
  LayoutTemplate,
  ListChecks,
  Loader2,
  Plus,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  Video,
  Wand2,
} from "lucide-react";
import type { ProjectSummary, ViewKey } from "@/types";
import { ASPECT_PRESETS, aspectLabel, formatBytes, formatDuration } from "@/data/defaults";
import { buildTimeline } from "@/lib/timeline";
import { validateProject, issueSummary } from "@/lib/preflight";
import { estimateStorage } from "@/lib/idb";
import { SceneCanvas } from "@/components/PreviewSurface";
import { useStudio as useCtx } from "@/store/StudioContext";
import { Button, ConfirmDialog, Field, Input, Modal, SectionHeader, Segmented, InlineNotice } from "@/components/ui";

function StatCard({ icon: Icon, label, value, hint, tone = "neutral" }: { icon: typeof Clock3; label: string; value: string; hint?: string; tone?: "neutral" | "gold" | "mint" | "red" }) {
  const tones = {
    neutral: "text-[#c9c9d1] border-white/10 bg-white/[0.02]",
    gold: "text-[#e7cf94] border-[#d9b65a]/20 bg-[#d9b65a]/[0.05]",
    mint: "text-[#8cebb5] border-[#57dc96]/20 bg-[#57dc96]/[0.05]",
    red: "text-red-300 border-red-400/20 bg-red-400/[0.05]",
  };
  return (
    <div className="panel flex items-center gap-3 p-3.5 sm:p-4">
      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border ${tones[tone]}`}>
        <Icon size={16} />
      </span>
      <div className="min-w-0">
        <p className="truncate text-[10px] text-[#83838d]">{label}</p>
        <p className="mt-0.5 truncate font-display text-[16px] font-bold text-white">{value}</p>
        {hint ? <p className="truncate text-[9px] text-[#6c6c76]">{hint}</p> : null}
      </div>
    </div>
  );
}

export function Dashboard({ onNavigate, onImportQuestions }: { onNavigate: (view: ViewKey) => void; onImportQuestions: () => void }) {
  const {
    project,
    projects,
    refreshProjects,
    openProject,
    createProject,
    removeProjectById,
    exportProjectZip,
    importProjectZip,
    saveNow,
    missingMedia,
  } = useCtx();
  const timeline = buildTimeline(project);
  const issues = validateProject(project, { availableMedia: new Set(Object.keys(project.media)) });
  const summary = issueSummary(issues);
  const [newOpen, setNewOpen] = useState(false);
  const [name, setName] = useState("");
  const [aspect, setAspect] = useState<"vertical" | "landscape" | "square">("vertical");
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ProjectSummary | null>(null);
  const [storage, setStorage] = useState<{ usage: number; available: number } | null>(null);
  const [busyProject, setBusyProject] = useState<string | null>(null);
  const [sampleHidden, setSampleHidden] = useState(() => sessionStorage.getItem("qs-sample-hidden") === "1");
  const importRef = useRef<HTMLInputElement>(null);
  const projectsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    void refreshProjects();
    void estimateStorage().then((value) => {
      if (value) setStorage({ usage: value.usage, available: value.available });
    });
  }, [refreshProjects]);

  const uniqueAudio = new Set(timeline.scenes.flatMap((scene) => scene.audio.map((clip) => clip.mediaId))).size;
  const answered = project.questions.filter((q) => q.question.trim() && q.options.every((o) => o.trim()) && q.correct >= 0 && q.correct < 4).length;
  const preflightDone = summary.errors === 0 && project.questions.length > 0;

  const startCreate = async () => {
    setCreating(true);
    try {
      await createProject(name, aspect);
      setNewOpen(false);
      setName("");
      onNavigate("questions");
    } finally {
      setCreating(false);
    }
  };

  const handleImport = async (file: File | undefined) => {
    if (!file) return;
    setBusyProject("import");
    try {
      await importProjectZip(file);
      onNavigate("questions");
    } catch {
      /* toast from context */
    } finally {
      setBusyProject(null);
    }
  };

  const workflow = [
    { key: "questions" as ViewKey, title: "الأسئلة والأجوبة", icon: ListChecks, state: `${answered}/${project.questions.length} مكتمل`, ready: preflightDone, detail: summary.errors ? `${summary.errors} عنصر يحتاج تصحيحًا` : "البيانات مكتملة" },
    { key: "audio" as ViewKey, title: "الصوت والتوقيت", icon: AudioLines, state: uniqueAudio ? `${uniqueAudio} ملفات مرتبطة` : "صوت صامت", ready: uniqueAudio > 0, detail: "توقيت مبني على مدة الصوت" },
    { key: "design" as ViewKey, title: "التصميم المرئي", icon: LayoutTemplate, state: project.design.presetName, ready: true, detail: "تخصيص كامل + معاينة" },
    { key: "preview" as ViewKey, title: "المعاينة الحية", icon: Video, state: "جاهزة للمشاهدة", ready: project.questions.length > 0, detail: "نفس محرك التصدير" },
    { key: "export" as ViewKey, title: "تصدير MP4", icon: FileVideo2, state: preflightDone ? "جاهز للتصدير" : "يحتاج مراجعة", ready: preflightDone, detail: "H.264 + AAC" },
  ];

  return (
    <div className="space-y-5">
      <SectionHeader
        eyebrow="لوحة الإنتاج"
        title="استوديو فيديوهات المسابقات"
        description="من الأسئلة إلى MP4 جاهز للنشر — كل شيء داخل متصفحك، دون رفع ملفاتك إلى خادم."
        actions={
          <>
            <Button variant="ghost" onClick={() => importRef.current?.click()} loading={busyProject === "import"}>
              <Upload size={14} /> استيراد مشروع
            </Button>
            <Button variant="primary" onClick={() => setNewOpen(true)}>
              <Plus size={15} /> مشروع جديد
            </Button>
          </>
        }
      />
      <input ref={importRef} type="file" accept=".zip,application/zip" className="hidden" onChange={(event) => void handleImport(event.target.files?.[0])} />

      {project.isSample && !sampleHidden ? (
        <div className="flex flex-col gap-3 rounded-xl border border-[#d9b65a]/20 bg-[#d9b65a]/[0.05] px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2.5">
            <Sparkles size={16} className="mt-0.5 shrink-0 text-[#e7cf94]" />
            <div>
              <p className="text-[12px] font-semibold text-[#f0e2bb]">هذا المشروع نموذج بداية وليس محتواك الشخصي</p>
              <p className="mt-0.5 text-[11px] leading-5 text-[#b5a479]">عدّل الأسئلة الثلاثة أو ابدأ مشروعًا فارغًا واحتفظ بالتصميم الجاهز.</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Button variant="ghost" className="!px-2.5 !py-1.5 text-[11px]" onClick={() => setNewOpen(true)}>
              بداية فارغة
            </Button>
            <Button variant="primary" className="!px-2.5 !py-1.5 text-[11px]" onClick={() => onNavigate("questions")}>
              استبدال المحتوى <ArrowLeft size={12} />
            </Button>
            <button
              type="button"
              className="p-1.5 text-[#9a8b65] hover:text-white"
              aria-label="إخفاء الملاحظة"
              onClick={() => {
                setSampleHidden(true);
                sessionStorage.setItem("qs-sample-hidden", "1");
              }}
            >
              ✕
            </button>
          </div>
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <section className="relative overflow-hidden rounded-2xl border border-white/[0.09] bg-[#0d0d10]">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(600px_320px_at_90%_-10%,rgba(217,182,90,0.17),transparent_65%)]" />
          <div className="pointer-events-none absolute inset-0 grid-noise opacity-[0.55]" />
          <div className="relative grid gap-6 p-5 sm:p-7 lg:grid-cols-[1fr_230px] lg:items-center">
            <div className="min-w-0">
              <div className="chip chip-gold mb-4">
                <span className="h-1.5 w-1.5 rounded-full bg-[#57dc96] shadow-[0_0_8px_rgba(87,220,150,0.7)]" />
                محرك إنتاج محلي · H.264 / AAC
              </div>
              <h2 className="font-display text-[28px] font-extrabold leading-[1.22] text-white sm:text-[36px]">
                حوّل أسئلتك إلى <span className="gold-text">فيديو مسابقة</span>
                <br />
                يوقف التمرير.
              </h2>
              <p className="mt-3 max-w-lg text-[12px] leading-6 text-[#a0a0aa] sm:text-[13px]">
                أسئلة، أصوات، مؤقتات وحركات كشف الإجابة — مصممة بذوق عربي وتُصدَّر MP4 بمقاسات TikTok وYouTube Shorts.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button variant="primary" className="!px-4" onClick={() => onNavigate("questions")}>
                  <Wand2 size={15} /> ابدأ من الأسئلة
                </Button>
                <Button variant="ghost" className="!px-4" onClick={() => onNavigate("export")}>
                  <FileVideo2 size={15} /> إنشاء الفيديو النهائي
                </Button>
                <button type="button" onClick={() => onNavigate("design")} className="group flex items-center gap-1 px-2 py-2 text-[11px] font-medium text-[#b0b0ba] hover:text-white">
                  تخصيص التصميم <ChevronLeft size={13} className="transition group-hover:-translate-x-0.5" />
                </button>
              </div>
              <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-[10px] text-[#7f7f8a]">
                <span className="flex items-center gap-1.5"><ShieldCheck size={12} className="text-[#6fd9a1]" /> لا تُرفع ملفاتك إلى الإنترنت</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 size={12} className="text-[#6fd9a1]" /> حفظ تلقائي محلي</span>
                <span className="flex items-center gap-1.5"><FlaskConical size={12} className="text-[#d9b65a]" /> فحص MP4 قبل التنزيل</span>
              </div>
            </div>

            <div className="relative mx-auto w-full max-w-[224px]">
              <div className="absolute -inset-4 rounded-[34px] bg-[#d9b65a]/10 blur-2xl" />
              <div className="relative rounded-[26px] border border-white/15 bg-[#08080a] p-1.5 shadow-[0_30px_60px_-25px_rgba(0,0,0,1)]">
                <div className="relative overflow-hidden rounded-[21px] bg-black">
                  <SceneCanvas questionIndex={0} stage="reveal" className="!rounded-[21px] border-0" />
                  <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-center pt-1.5">
                    <span className="h-1 w-10 rounded-full bg-white/25" />
                  </div>
                  <div className="pointer-events-none absolute inset-x-2.5 bottom-2.5 flex items-center justify-between rounded-lg border border-white/15 bg-black/65 px-2 py-1.5 backdrop-blur">
                    <span className="flex items-center gap-1.5 text-[8px] text-white">
                      <span className="h-1.5 w-1.5 rounded-full bg-[#57dc96]" /> {project.questions.length} أسئلة
                    </span>
                    <span className="text-[8px] text-[#d9c287]">{formatDuration(timeline.totalDuration)}</span>
                  </div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-center gap-1.5 text-[9px] text-[#85858f]">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#57dc96]" /> معاينة حية من مشروعك
              </div>
            </div>
          </div>
          <div className="relative grid grid-cols-2 gap-px border-t border-white/[0.07] bg-white/[0.06] sm:grid-cols-4">
            {[
              { label: "المدة التقديرية", value: formatDuration(timeline.totalDuration) },
              { label: "عدد الأسئلة", value: `${project.questions.length}` },
              { label: "المقاس", value: aspectLabel(project.exportSettings.width, project.exportSettings.height) },
              { label: "ملفات صوت مرفوعة", value: `${uniqueAudio}` },
            ].map((item) => (
              <div key={item.label} className="bg-[#0d0d10] px-3.5 py-3">
                <p className="text-[9px] text-[#777781]">{item.label}</p>
                <p className="mt-0.5 font-display text-[13px] font-bold text-[#f0efe9]">{item.value}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="panel flex flex-col p-4 sm:p-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-[#767680]">جاهزية المشروع</p>
              <h3 className="mt-1 font-display text-[17px] font-bold text-white">{project.name}</h3>
            </div>
            <span className={summary.errors ? "chip chip-gold" : "chip chip-mint"}>{summary.errors ? `${summary.errors} ملاحظات مانعة` : "جاهز للتصدير"}</span>
          </div>
          <div className="mt-4 space-y-2.5">
            {[
              { label: "نص السؤال وأربعة خيارات", done: answered === project.questions.length && project.questions.length > 0, value: `${answered}/${project.questions.length}` },
              { label: "تحديد إجابة صحيحة واحدة", done: project.questions.length > 0 && project.questions.every((q) => q.correct >= 0 && q.correct < 4), value: "مطلوب" },
              { label: "ملفات الصوت والتوقيت", done: uniqueAudio > 0, value: uniqueAudio ? `${uniqueAudio} ملف` : "صامت" },
              { label: "الملفات المفقودة", done: missingMedia.length === 0, value: missingMedia.length ? `${missingMedia.length} مفقود` : "لا شيء" },
            ].map((row) => (
              <div key={row.label} className="flex items-center justify-between gap-2 rounded-lg border border-white/[0.06] bg-white/[0.018] px-3 py-2">
                <span className="flex items-center gap-2 text-[11px] text-[#c4c4cd]">
                  <span className={`flex h-4 w-4 items-center justify-center rounded-full ${row.done ? "bg-[#57dc96]/15 text-[#7ae7ac]" : "bg-[#d9b65a]/12 text-[#e7cf94]"}`}>
                    {row.done ? <CheckCircle2 size={11} /> : <CircleAlert size={11} />}
                  </span>
                  {row.label}
                </span>
                <span className="text-[10px] text-[#85858f]">{row.value}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-xl border border-white/[0.07] bg-black/25 p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 text-[10px] text-[#93939d]"><HardDrive size={12} /> التخزين المحلي</span>
              <span className="text-[9px] text-[#73737d]">{storage ? `${formatBytes(storage.usage)} مستخدم` : "غير متاح"}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
              <span className="block h-full rounded-full bg-gradient-to-l from-[#d9b65a] to-[#e7cf94]" style={{ width: `${storage ? Math.min(100, (storage.usage / Math.max(storage.usage + storage.available, 1)) * 100) : 2}%` }} />
            </div>
            <p className="mt-1.5 text-[9px] text-[#6f6f79]">الصور والأصوات محفوظة في IndexedDB على هذا الجهاز.</p>
          </div>
          <div className="mt-3 flex gap-1.5">
            <Button variant="ghost" className="flex-1 !py-2 text-[11px]" onClick={() => onNavigate("preview")}>
              <Video size={13} /> معاينة
            </Button>
            <Button variant="primary" className="flex-1 !py-2 text-[11px]" onClick={() => onNavigate("export")}>
              <Sparkles size={13} /> تصدير MP4
            </Button>
          </div>
          {summary.errors ? <p className="mt-2.5 text-[10px] leading-5 text-[#c9a97a]">أول عائق: {issues.find((issue) => issue.level === "error")?.message}</p> : null}
        </section>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={ListChecks} label="اكتمال الأسئلة" value={`${Math.round((answered / Math.max(1, project.questions.length)) * 100)}%`} hint={`${answered} من ${project.questions.length}`} tone="gold" />
        <StatCard icon={Clock3} label="مدة الفيديو" value={formatDuration(timeline.totalDuration)} hint={`${project.exportSettings.fps} إطار/ثانية`} tone="mint" />
        <StatCard icon={AudioLines} label="الموسيقى والمؤثرات" value={project.timing.sfxEnabled ? "مفعّلة" : "معطّلة"} hint={project.timing.backgroundMusicId ? "موسيقى خلفية مرفوعة" : "بدون موسيقى خلفية"} />
        <StatCard icon={CircleAlert} label="ملاحظات الفحص" value={`${summary.errors} أخطاء`} hint={`${summary.warnings} تنبيهات`} tone={summary.errors ? "red" : "mint"} />
      </div>

      <section className="panel p-4 sm:p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="font-display text-[16px] font-bold text-white">مسار الإنتاج</h3>
            <p className="mt-0.5 text-[11px] text-[#85858f]">خمس مراحل مترابطة، وكل تعديل ينعكس فورًا في المعاينة والتصدير.</p>
          </div>
          <Button variant="quiet" className="!px-2.5 !py-1.5 text-[11px]" onClick={() => onNavigate("help")}>
            الدليل
          </Button>
        </div>
        <div className="mobile-hide-scroll grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-5">
          {workflow.map((step, index) => (
            <button
              key={step.key}
              type="button"
              onClick={() => onNavigate(step.key)}
              className="group relative rounded-xl border border-white/[0.07] bg-white/[0.018] p-3 text-right transition hover:border-[#d9b65a]/30 hover:bg-white/[0.035]"
            >
              <div className="flex items-center justify-between">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg border border-white/10 bg-white/[0.035] text-[#dfc27f]">
                  <step.icon size={14} />
                </span>
                <span className="text-[9px] tabular-nums text-[#5f5f69]">0{index + 1}</span>
              </div>
              <p className="mt-2.5 text-[12px] font-semibold text-[#eeeef2]">{step.title}</p>
              <p className={`mt-0.5 flex items-center gap-1 text-[10px] ${step.ready ? "text-[#73dca6]" : "text-[#d9b77a]"}`}>
                {step.ready ? <CheckCircle2 size={10} /> : <CircleAlert size={10} />} {step.state}
              </p>
              <p className="mt-1 text-[9px] leading-4 text-[#6f6f79]">{step.detail}</p>
            </button>
          ))}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.12fr]">
        <section className="panel p-4 sm:p-5" ref={projectsRef} id="saved-projects">
          <div className="mb-3 flex items-center justify-between gap-2">
            <div>
              <h3 className="flex items-center gap-2 font-display text-[16px] font-bold text-white"><FolderOpen size={15} className="text-[#cbb16e]" /> المشاريع المحفوظة</h3>
              <p className="mt-0.5 text-[10px] text-[#7c7c86]">حفظ تلقائي داخل هذا المتصفح · {projects.length} مشروع</p>
            </div>
            <div className="flex gap-1">
              <button type="button" className="rounded-lg border border-white/10 p-1.5 text-[#9c9ca6] hover:text-white" onClick={() => void exportProjectZip()} title="تنزيل حزمة المشروع الحالي" aria-label="تنزيل حزمة المشروع الحالي">
                <FileJson size={14} />
              </button>
              <button type="button" className="rounded-lg border border-white/10 p-1.5 text-[#9c9ca6] hover:text-white" onClick={() => importRef.current?.click()} title="استيراد مشروع ZIP" aria-label="استيراد مشروع">
                <Upload size={14} />
              </button>
            </div>
          </div>
          <div className="space-y-2">
            {projects.slice(0, 4).map((item) => (
              <div key={item.id} className={`flex items-center gap-2.5 rounded-xl border p-2.5 ${item.id === project.id ? "border-[#d9b65a]/25 bg-[#d9b65a]/[0.05]" : "border-white/[0.06] bg-white/[0.015]"}`}>
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-black/30 font-display text-[13px] font-bold text-[#d9b65a]">
                  {item.questionCount}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12px] font-medium text-[#e8e8ee]">{item.name}</p>
                  <p className="text-[9px] text-[#767680]">{new Date(item.updatedAt).toLocaleDateString("ar", { day: "numeric", month: "short" })} · {aspectLabel(item.width, item.height)}</p>
                </div>
                {item.id === project.id ? (
                  <span className="chip chip-gold !px-2 !py-0.5 !text-[9px]">مفتوح</span>
                ) : (
                  <button
                    type="button"
                    disabled={busyProject === item.id}
                    onClick={async () => {
                      setBusyProject(item.id);
                      try {
                        await saveNow();
                        await openProject(item.id);
                      } finally {
                        setBusyProject(null);
                      }
                    }}
                    className="rounded-lg border border-white/10 px-2 py-1 text-[10px] text-[#c9c9d1] transition hover:border-[#d9b65a]/30 hover:text-white"
                  >
                    {busyProject === item.id ? <Loader2 size={12} className="animate-spin" /> : "فتح"}
                  </button>
                )}
                <button type="button" onClick={() => setDeleteTarget(item)} className="rounded-lg p-1.5 text-[#7f7f89] transition hover:bg-red-500/10 hover:text-red-300" aria-label={`حذف ${item.name}`}>
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
            {projects.length === 0 ? <p className="rounded-lg border border-dashed border-white/10 px-3 py-6 text-center text-[11px] text-[#7c7c86]">لا توجد مشاريع محفوظة بعد.</p> : null}
          </div>
          <button type="button" onClick={() => setNewOpen(true)} className="mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-white/10 py-2 text-[11px] text-[#9a9aa4] transition hover:border-[#d9b65a]/30 hover:text-[#e7cf94]">
            <Plus size={13} /> مشروع جديد
          </button>
        </section>

        <section className="panel p-4 sm:p-5">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <h3 className="font-display text-[16px] font-bold text-white">أسئلة المشروع</h3>
              <p className="mt-0.5 text-[10px] text-[#7c7c86]">آخر ما حرّرته · تحقق سريع من الحالة</p>
            </div>
            <Button variant="quiet" className="!px-2 !py-1.5 text-[10px]" onClick={() => onNavigate("questions")}>
              إدارة الكل <ChevronLeft size={12} />
            </Button>
          </div>
          <div className="space-y-2">
            {project.questions.slice(0, 4).map((question, index) => {
              const complete = question.question.trim() && question.options.every((option) => option.trim()) && question.correct >= 0;
              return (
                <button key={question.id} type="button" onClick={() => onNavigate("questions")} className="flex w-full items-center gap-2.5 rounded-xl border border-white/[0.06] bg-white/[0.015] p-2.5 text-right transition hover:border-white/15">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/[0.04] text-[10px] font-semibold text-[#a8a8b2]">{index + 1}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11px] text-[#e4e4ea]">{question.question || "سؤال بدون نص"}</p>
                    <p className="mt-0.5 truncate text-[9px] text-[#73737d]">
                      {question.options[question.correct] ? `الإجابة: ${question.options[question.correct]}` : "لم تُحدد الإجابة الصحيحة"}
                      {question.thinkSec ? ` · تفكير ${question.thinkSec} ث` : ""}
                    </p>
                  </div>
                  <span className={complete ? "chip chip-mint !px-2 !py-0.5 !text-[9px]" : "chip chip-gold !px-2 !py-0.5 !text-[9px]"}>{complete ? "مكتمل" : "يحتاج مراجعة"}</span>
                </button>
              );
            })}
          </div>
          <div className="mt-3 rounded-xl border border-white/[0.06] bg-black/25 p-3">
            <p className="flex items-center gap-1.5 text-[10px] font-medium text-[#b9b9c2]"><ShieldCheck size={12} className="text-[#73dca6]" /> نصائح الإنتاج</p>
            <ul className="mt-1.5 space-y-1 text-[10px] leading-5 text-[#7f7f89]">
              <li>• استخدم أسماء q01_question.mp3 وq01_options.mp3 للمطابقة التلقائية.</li>
              <li>• التصدير على الهاتف يعمل بحد أقصى 6 دقائق في هذه النسخة.</li>
              <li>• استخدم «حفظ كقالب» في صفحة التصميم لتكرار الهوية البصرية بين المشاريع.</li>
            </ul>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-1.5">
            <Button variant="ghost" className="!py-2 text-[11px]" onClick={onImportQuestions}>
              <Upload size={13} /> استيراد الأسئلة
            </Button>
            <Button variant="ghost" className="!py-2 text-[11px]" onClick={() => onNavigate("audio")}>
              <AudioLines size={13} /> استيراد الصوت
            </Button>
          </div>
        </section>
      </div>

      <div className="rounded-xl border border-white/[0.07] bg-white/[0.015] px-4 py-3 text-[10px] leading-6 text-[#7e7e88]">
        <span className="ml-1 font-semibold text-[#b8b8c2]">ملاحظة تقنية:</span>
        التصدير يعتمد على WebCodecs داخل المتصفح. يعمل على Chrome/Edge الحديث وSafari 16.4+. لا يحتاج اتصالًا بالإنترنت بعد تحميل الخطوط، ولا تُرفع الملفات إلى أي خدمة خارجية. اختبر المحرك من صفحة{" "}
        <button type="button" onClick={() => onNavigate("selftest")} className="text-[#e7cf94] underline decoration-[#d9b65a]/40 underline-offset-4">اختبار المحرك</button>.
      </div>

      <Modal
        open={newOpen}
        onClose={() => setNewOpen(false)}
        title="مشروع جديد"
        description="اختر اسمًا ومقاس الفيديو. يمكنك تغيير كل شيء لاحقًا."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setNewOpen(false)}>إلغاء</Button>
            <Button variant="primary" onClick={() => void startCreate()} loading={creating}>
              <Plus size={14} /> إنشاء المشروع
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          <Field label="اسم المشروع" required>
            <Input value={name} onChange={(event) => setName(event.target.value)} placeholder="مثال: مسابقة الثقافة العامة — الحلقة 1" autoFocus />
          </Field>
          <Field label="مقاس الفيديو" hint="يمكن تعديل المقاس بدقة من صفحة التصدير.">
            <Segmented
              value={aspect}
              onChange={(value) => setAspect(value)}
              options={[
                { value: "vertical", label: <span className="flex flex-col items-center gap-1"><span className="block h-7 w-4 rounded-sm border border-current/50" />عمودي ٩:١٦</span> },
                { value: "landscape", label: <span className="flex flex-col items-center gap-1"><span className="block h-4 w-7 rounded-sm border border-current/50" />أفقي ١٦:٩</span> },
                { value: "square", label: <span className="flex flex-col items-center gap-1"><span className="block h-5 w-5 rounded-sm border border-current/50" />مربع ١:١</span> },
              ]}
            />
          </Field>
          <InlineNotice kind="info" title={`المقاس: ${ASPECT_PRESETS[aspect].width}×${ASPECT_PRESETS[aspect].height}`}>
            {ASPECT_PRESETS[aspect].hint} — يبدأ المشروع بسؤال فارغ وتصميم «الذهبي الليلي».
          </InlineNotice>
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        title={`حذف «${deleteTarget?.name ?? ""}»؟`}
        description="سيُحذف المشروع وملفاته من هذا المتصفح. نزّل حزمة ZIP أولًا إذا أردت الاحتفاظ بنسخة."
        confirmLabel="نعم، احذف المشروع"
        danger
        onConfirm={() => {
          const target = deleteTarget;
          setDeleteTarget(null);
          if (target) void removeProjectById(target.id);
        }}
      />
    </div>
  );
}
