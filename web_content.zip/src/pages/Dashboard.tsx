import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight, BookOpen, CheckCircle2, ClipboardList, Clock, Flame, Library, Repeat2, Sparkles, Target, TrendingUp, Zap,
} from 'lucide-react';
import type { DashboardData, ScheduleItem } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn, EXAM_SHORT, formatDate, formatMinutes, relativeDay, todayISO } from '../lib/utils';
import { Banner, Button, Card, EmptyState, ProgressBar, Ring, SectionHeading, Spinner, StatCard, useToast } from '../components/ui';
import { SubjectBars, TrendChart } from '../components/Charts';

const BADGE_ICONS: Record<string, typeof Flame> = {
  file: ClipboardList, flame: Flame, zap: Zap, book: BookOpen, target: Target, clock: Clock, check: CheckCircle2, repeat: Repeat2,
};

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { aiEnabled } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();

  const load = useCallback(async () => {
    try {
      const res = await api.get<DashboardData>('/api/dashboard');
      setData(res);
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your dashboard.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const toggleItem = async (item: ScheduleItem) => {
    const next = item.status === 'done' ? 'pending' : 'done';
    try {
      await api.patch(`/api/planner/items/${item.id}`, { status: next });
      push(next === 'done' ? `Logged ${formatMinutes(minutes(item))} of study.` : 'Session reopened.', next === 'done' ? 'ok' : 'info');
      await load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not update the session.', 'bad');
    }
  };

  if (loading) return <Spinner label="Loading your preparation…" />;
  if (error) return <Banner tone="bad" title="Dashboard unavailable">{error}</Banner>;
  if (!data) return null;

  const { stats, profile, subjects, weakest, strongest, recentTests, trend, today, upcoming, badges, nextExam } = data;
  const doneToday = today.filter((i) => i.status === 'done' && i.kind !== 'break').length;
  const studyToday = today.filter((i) => i.kind !== 'break' && i.kind !== 'school' && i.kind !== 'coaching');
  const earned = badges.filter((b) => b.earned);

  return (
    <div className="space-y-6">
      {!aiEnabled && (
        <Banner tone="warn" title="AI tutor is not connected yet">
          Add <span className="font-mono text-xs">OPENAI_API_KEY</span> under Settings → Secrets to enable teaching, document analysis and AI papers.
          The planner, question bank, tests and analytics already work.
        </Banner>
      )}

      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <Card className="relative overflow-hidden">
          <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-brand/15 blur-3xl" />
          <div className="relative flex flex-wrap items-center gap-6">
            <Ring value={stats.preparation} size={116} label={`${stats.preparation}%`} sub="Prepared" />
            <div className="min-w-[200px] flex-1">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted">Welcome back</p>
              <h2 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-ink">{profile.name.split(' ')[0]}, let's move the needle.</h2>
              <p className="mt-1.5 text-sm text-muted">
                {stats.syllabusCompletion}% syllabus mastery · {stats.chaptersDone}/{stats.chaptersTotal} chapters confident
                {stats.avgAccuracy !== null ? ` · ${stats.avgAccuracy}% test accuracy` : ' · no tests yet'}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button onClick={() => navigate('/teacher')}><Sparkles size={16} /> Continue learning</Button>
                <Button variant="secondary" onClick={() => navigate('/tests')}><ClipboardList size={16} /> Take a test</Button>
              </div>
            </div>
            {nextExam.daysLeft !== null && (
              <div className="rounded-2xl border border-brand/25 bg-brand/5 px-4 py-3 text-center">
                <div className="font-display text-3xl font-extrabold text-brand">{nextExam.daysLeft}</div>
                <div className="text-[10px] font-semibold uppercase tracking-wide text-muted">days to {EXAM_SHORT[profile.exam] ?? 'exam'}</div>
                <div className="mt-1 text-[11px] text-muted">{formatDate(nextExam.date, { day: 'numeric', month: 'short', year: 'numeric' })}</div>
              </div>
            )}
          </div>
        </Card>

        <Card>
          <SectionHeading title="Today" subtitle={todayISO()} />
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted">Sessions completed</span>
            <span className="font-semibold text-ink">{doneToday}/{studyToday.length || 0}</span>
          </div>
          <ProgressBar className="mt-2" value={studyToday.length ? (doneToday / studyToday.length) * 100 : 0} />
          <div className="mt-4 space-y-2">
            {today.length === 0 ? (
              <div className="rounded-xl border border-dashed border-line p-4 text-center text-xs text-muted">
                No sessions scheduled today.{' '}
                <Link to="/planner" className="font-semibold text-brand hover:underline">Generate a plan</Link>
              </div>
            ) : (
              today.slice(0, 4).map((item) => (
                <div key={item.id} className="flex items-center gap-2.5 rounded-lg border border-line/70 bg-elevated/30 px-2.5 py-2">
                  <button
                    onClick={() => void toggleItem(item)}
                    disabled={item.kind === 'break' || item.kind === 'school' || item.kind === 'coaching'}
                    aria-label={item.status === 'done' ? 'Mark not done' : 'Mark complete'}
                    className={cn('grid h-5 w-5 shrink-0 place-items-center rounded-md border transition',
                      item.status === 'done' ? 'border-ok bg-ok/20 text-ok' : 'border-line hover:border-brand',
                      (item.kind === 'break' || item.kind === 'school' || item.kind === 'coaching') && 'opacity-40')}
                  >
                    {item.status === 'done' && <CheckCircle2 size={13} />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className={cn('truncate text-xs font-medium', item.status === 'done' ? 'text-muted line-through' : 'text-ink')}>{item.title}</div>
                    <div className="text-[10px] text-muted">{item.startTime}–{item.endTime}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Study this week" value={formatMinutes(stats.studyMinutes7d)} hint={`${formatMinutes(stats.studyMinutes30d)} in 30 days`} icon={<Clock size={18} />} />
        <StatCard label="Study streak" value={`${stats.streak} day${stats.streak === 1 ? '' : 's'}`} hint={stats.streak >= 3 ? 'Momentum is building' : 'Complete a session today'} icon={<Flame size={18} />} tone="warn" />
        <StatCard label="Tests completed" value={stats.testsTaken} hint={stats.avgAccuracy !== null ? `${stats.avgAccuracy}% average accuracy` : 'Start with a diagnostic'} icon={<ClipboardList size={18} />} tone="ok" />
        <StatCard label="Revision due" value={stats.revisionDue} hint={stats.revisionDue ? 'Clear these first' : 'All caught up'} icon={<Repeat2 size={18} />} tone={stats.revisionDue > 5 ? 'bad' : 'brand'} onClick={() => navigate('/revision')} />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
        <Card>
          <SectionHeading
            title="Performance trend"
            subtitle={trend.length ? 'Accuracy across your submitted tests' : 'Your first test will start this chart'}
            action={<Link to="/analytics" className="text-xs font-semibold text-brand hover:underline">Full analytics</Link>}
          />
          {trend.length ? <TrendChart data={trend} /> : (
            <EmptyState icon={<TrendingUp size={20} />} title="No attempts yet" description="Generate a short diagnostic test — it takes 10 minutes and gives your baseline." action={<Button onClick={() => navigate('/tests')}>Create a diagnostic</Button>} />
          )}
        </Card>

        <Card>
          <SectionHeading title="Subject mastery" subtitle="From your chapter tracker and tests" />
          {subjects.length ? <SubjectBars data={subjects.map((s) => ({ subject: s.subject, mastery: s.mastery }))} height={220} /> : <p className="text-sm text-muted">No subjects yet.</p>}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <SectionHeading title="Needs attention" subtitle="Lowest mastery first" />
          {weakest.length ? (
            <ul className="space-y-2.5">
              {weakest.map((w) => (
                <li key={`${w.subject}-${w.chapter}`}>
                  <Link to={`/teacher?subject=${encodeURIComponent(w.subject)}&chapter=${encodeURIComponent(w.chapter)}`} className="block rounded-xl border border-line/70 bg-elevated/30 p-3 transition hover:border-brand/40">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-medium text-ink">{w.chapter}</span>
                      <span className={cn('text-xs font-bold', w.mastery < 40 ? 'text-bad' : w.mastery < 70 ? 'text-warn' : 'text-ok')}>{w.mastery}%</span>
                    </div>
                    <div className="mt-1.5 flex items-center justify-between gap-3">
                      <span className="text-[11px] text-muted">{w.subject}</span>
                      <span className="text-[10px] uppercase tracking-wide text-muted">{w.status.replace('-', ' ')}</span>
                    </div>
                    <ProgressBar value={w.mastery} tone={w.mastery < 40 ? 'bad' : w.mastery < 70 ? 'warn' : 'ok'} height="h-1" className="mt-1.5" />
                  </Link>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-muted">Start a chapter in the AI Teacher and it will appear here.</p>}
        </Card>

        <Card>
          <SectionHeading title="Recent tests" subtitle="Latest attempts" action={<Link to="/tests" className="text-xs font-semibold text-brand hover:underline">All</Link>} />
          {recentTests.length ? (
            <ul className="space-y-2">
              {recentTests.map((t) => (
                <li key={t.id}>
                  <Link to={`/attempts/${t.id}`} className="flex items-center justify-between gap-3 rounded-xl border border-line/70 bg-elevated/30 px-3 py-2.5 hover:border-brand/40">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-ink">{t.title}</div>
                      <div className="text-[11px] text-muted">{formatDate(t.submittedAt, { day: 'numeric', month: 'short' })} · {EXAM_SHORT[t.exam] ?? t.exam}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-ink">{Math.round(t.score)}/{Math.round(t.max)}</div>
                      <div className="text-[11px] text-muted">{t.accuracy}%</div>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-muted">No completed tests yet.</p>}
        </Card>

        <Card>
          <SectionHeading title="Achievements" subtitle={`${earned.length} of ${badges.length} unlocked`} />
          <div className="grid grid-cols-2 gap-2">
            {badges.map((badge) => {
              const Icon = BADGE_ICONS[badge.icon] ?? Target;
              return (
                <div key={badge.id} className={cn('rounded-xl border p-2.5', badge.earned ? 'border-brand/30 bg-brand/10' : 'border-line/60 bg-elevated/20 opacity-60')} title={badge.description}>
                  <Icon size={16} className={badge.earned ? 'text-brand' : 'text-muted'} />
                  <div className="mt-1.5 text-[11px] font-semibold leading-tight text-ink">{badge.label}</div>
                  <div className="text-[10px] leading-tight text-muted">{badge.description}</div>
                </div>
              );
            })}
          </div>
          <Link to="/profile" className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">
            Study history <ArrowRight size={12} />
          </Link>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <SectionHeading title="Upcoming week" subtitle="Your next scheduled sessions" action={<Link to="/planner" className="text-xs font-semibold text-brand hover:underline">Planner</Link>} />
          {upcoming.length ? (
            <ul className="space-y-2">
              {upcoming.slice(0, 6).map((item) => (
                <li key={item.id} className="flex items-center gap-3 rounded-xl border border-line/60 bg-elevated/25 px-3 py-2">
                  <div className="w-16 shrink-0 text-[11px] font-semibold text-brand">{relativeDay(item.date)}</div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm text-ink">{item.title}</div>
                    <div className="text-[11px] text-muted">{item.startTime}–{item.endTime} · {item.kind}</div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState icon={<Clock size={18} />} title="No upcoming sessions" description="Generate a plan that fits your school and coaching hours." action={<Button variant="secondary" onClick={() => navigate('/planner')}>Open planner</Button>} />
          )}
        </Card>

        <Card>
          <SectionHeading title="Strongest chapters" subtitle="Protect these with light revision" />
          {strongest.length ? (
            <ul className="space-y-2">
              {strongest.map((s) => (
                <li key={`${s.subject}-${s.chapter}`} className="flex items-center justify-between gap-3 rounded-xl border border-line/60 bg-elevated/25 px-3 py-2.5">
                  <div className="min-w-0">
                    <div className="truncate text-sm text-ink">{s.chapter}</div>
                    <div className="text-[11px] text-muted">{s.subject}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={s.mastery} tone="ok" className="w-16" height="h-1.5" />
                    <span className="text-xs font-bold text-ok">{s.mastery}%</span>
                  </div>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-muted">Mark chapters as confident and they will show here.</p>}
          <div className="mt-4 flex flex-wrap gap-2">
            <Link to="/resources" className="chip hover:text-ink"><Library size={12} /> Upload material</Link>
            <Link to="/revision" className="chip hover:text-ink"><Repeat2 size={12} /> Revise due topics</Link>
            <Link to="/bank" className="chip hover:text-ink"><BookOpen size={12} /> Practice questions</Link>
          </div>
        </Card>
      </div>
    </div>
  );
}

function minutes(item: ScheduleItem): number {
  const [sh, sm] = item.startTime.split(':').map(Number);
  const [eh, em] = item.endTime.split(':').map(Number);
  return Math.max(0, eh * 60 + em - (sh * 60 + sm));
}
