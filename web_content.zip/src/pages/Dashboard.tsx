/* ============================================
   plix_ai studio — Projects Dashboard
   ============================================ */

import { useState, useMemo } from 'react';
import type { Project, PageId } from '../types';
import { getProjects, deleteProject, duplicateProject, archiveProject } from '../store';
import {
  IconPlus, IconSearch, IconTrash, IconCopy, IconArchive,
  IconChevronRight, IconClock, IconPackage
} from '../components/Icons';

interface DashboardProps {
  onNavigate: (page: PageId) => void;
  onEditProject?: (id: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [projects, setProjects] = useState<Project[]>(() => getProjects());
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const filtered = useMemo(() => {
    let list = projects;
    if (filterStatus !== 'all') {
      list = list.filter(p => p.status === filterStatus);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.packageId.toLowerCase().includes(q) ||
        p.sourceType.toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => b.updatedAt - a.updatedAt);
  }, [projects, search, filterStatus]);

  function handleDuplicate(id: string) {
    const copy = duplicateProject(id);
    if (copy) setProjects(getProjects());
  }

  function handleDelete(id: string) {
    deleteProject(id);
    setProjects(getProjects());
    setConfirmDelete(null);
  }

  function handleArchive(id: string) {
    archiveProject(id);
    setProjects(getProjects());
  }

  function formatDate(ts: number) {
    return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'completed': return 'badge-success';
      case 'building': return 'badge-brand';
      case 'failed': return 'badge-error';
      case 'archived': return 'badge-neutral';
      default: return 'badge-warning';
    }
  }

  const statusOptions = ['all', 'draft', 'building', 'completed', 'failed', 'archived'];

  // Empty state
  if (projects.length === 0 && !search) {
    return (
      <div className="animate-fade-in">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Projects</h1>
            <p className="text-sm text-stone-400 mt-1">Your Android conversion projects</p>
          </div>
          <button onClick={() => onNavigate('convert')} className="btn btn-primary">
            <IconPlus size={16} />
            New Project
          </button>
        </div>

        <div className="card text-center py-16">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl surface-2 border border-subtle flex items-center justify-center text-stone-500">
            <IconPackage size={28} />
          </div>
          <h3 className="text-lg font-semibold mb-2">No projects yet</h3>
          <p className="text-sm text-stone-400 mb-6 max-w-md mx-auto">
            Create your first Android project by converting a website, ZIP file, or PWA.
            All data is stored locally in your browser.
          </p>
          <div className="flex items-center justify-center gap-3">
            <button onClick={() => onNavigate('convert')} className="btn btn-primary">
              <IconPlus size={16} />
              Create First Project
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Projects</h1>
          <p className="text-sm text-stone-400 mt-1">
            {projects.length} project{projects.length !== 1 ? 's' : ''} total
          </p>
        </div>
        <button onClick={() => onNavigate('convert')} className="btn btn-primary">
          <IconPlus size={16} />
          New Project
        </button>
      </div>

      {/* Search + Filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <IconSearch size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name, package ID, or source type..."
            className="input pl-9"
            aria-label="Search projects"
          />
        </div>
        <div className="flex gap-1 flex-wrap">
          {statusOptions.map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`btn btn-sm capitalize ${filterStatus === s ? 'btn-primary' : 'btn-ghost'}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Project list */}
      {filtered.length === 0 ? (
        <div className="card text-center py-12">
          <p className="text-sm text-stone-400">No projects match your search.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((project, idx) => (
            <div
              key={project.id}
              className="card card-compact card-interactive animate-fade-in-up"
              style={{ animationDelay: `${idx * 40}ms` }}
            >
              <div className="flex items-center gap-4">
                {/* Logo / Icon placeholder */}
                <div
                  className="w-10 h-10 rounded-lg border border-subtle flex items-center justify-center flex-shrink-0"
                  style={{
                    background: project.branding.logoDataUrl
                      ? `url(${project.branding.logoDataUrl}) center/cover`
                      : `linear-gradient(135deg, ${project.branding.primaryColor}22, ${project.branding.accentColor}22)`,
                    borderColor: `${project.branding.primaryColor}33`,
                  }}
                >
                  {!project.branding.logoDataUrl && (
                    <span className="text-xs font-bold" style={{ color: project.branding.primaryColor }}>
                      {project.branding.appName.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <h3 className="font-semibold text-sm truncate">{project.name}</h3>
                    <span className={`badge ${getStatusColor(project.status)}`}>{project.status}</span>
                    <span className="badge badge-neutral">{project.sourceType.toUpperCase()}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-stone-500">
                    <span className="font-mono">{project.packageId}</span>
                    <span className="flex items-center gap-1">
                      <IconClock size={11} />
                      {formatDate(project.updatedAt)}
                    </span>
                    {project.builds.length > 0 && (
                      <span>{project.builds.length} build{project.builds.length !== 1 ? 's' : ''}</span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDuplicate(project.id); }}
                    className="btn btn-ghost btn-sm"
                    data-tooltip="Duplicate"
                    aria-label="Duplicate project"
                  >
                    <IconCopy size={14} />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleArchive(project.id); }}
                    className="btn btn-ghost btn-sm"
                    data-tooltip="Archive"
                    aria-label="Archive project"
                    disabled={project.status === 'archived'}
                  >
                    <IconArchive size={14} />
                  </button>
                  {confirmDelete === project.id ? (
                    <div className="flex items-center gap-1 ml-1">
                      <span className="text-xs text-red-400">Delete?</span>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(project.id); }}
                        className="btn btn-danger btn-sm"
                      >
                        Yes
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); setConfirmDelete(null); }}
                        className="btn btn-ghost btn-sm"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={(e) => { e.stopPropagation(); setConfirmDelete(project.id); }}
                      className="btn btn-ghost btn-sm text-stone-500 hover:text-red-400"
                      data-tooltip="Delete"
                      aria-label="Delete project"
                    >
                      <IconTrash size={14} />
                    </button>
                  )}
                  <button
                    onClick={() => onNavigate('convert')}
                    className="btn btn-ghost btn-sm"
                    aria-label="View project details"
                  >
                    <IconChevronRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Build history section */}
      {projects.some(p => p.builds.length > 0) && (
        <div className="mt-10">
          <h2 className="text-lg font-semibold mb-4">Recent Builds</h2>
          <div className="space-y-1">
            {projects
              .flatMap(p => p.builds.map(b => ({ ...b, projectName: p.name })))
              .sort((a, b) => b.createdAt - a.createdAt)
              .slice(0, 10)
              .map(build => (
                <div key={build.id} className="card card-compact flex items-center gap-3 text-sm">
                  <div className={`w-2 h-2 rounded-full ${
                    build.status === 'completed' ? 'bg-emerald-500' :
                    build.status === 'failed' ? 'bg-red-500' :
                    'bg-amber-500 animate-pulse'
                  }`} />
                  <span className="font-medium">{(build as any).projectName}</span>
                  <span className="badge badge-neutral capitalize">{build.status}</span>
                  <span className="text-xs text-stone-500 ml-auto font-mono">
                    {formatDate(build.createdAt)}
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}