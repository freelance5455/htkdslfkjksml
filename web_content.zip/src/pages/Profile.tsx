import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpenCheck, Check, LogOut, Moon, Search, Sun, User } from 'lucide-react';
import type { ChapterProgress, ExamId, StudentProfile } from '@shared/types';
import { EXAM_LIST, EXAM_PATTERNS } from '@shared/exam';
import { chaptersFor, subjectsForExam } from '@shared/syllabus';
import { api, ApiError } from '../lib/api';
import { useAuth, useTheme } from '../lib/auth';
import { cn, todayISO } from '../lib/utils';
import {
  Badge, Banner, Button, Card, Field, Input, ProgressBar, Select, SectionHeading, Spinner, Textarea, useToast,
} from '../components/ui';

const STATUSES: { value: ChapterProgress['status']; label: string; tone: 'neutral' | 'brand' | 'warn' | 'ok' }[] = [
  { value: 'not-started', label: 'Not started', tone: 'neutral' },
  { value: 'learning', label: 'Learning', tone: 'brand' },
  { value: 'revising', label: 'Revising', tone: 'warn' },
  { value: 'confident', label: 'Confident', tone: 'ok' },
];

export default function Profile() {
  const { profile, user, refresh, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const { push } = useToast();
  const navigate = useNavigate();
  const [progress, setProgress] = useState<ChapterProgress[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [search, setSearch] = useState('');
  const [filterSubject, setFilterSubject] = useState('');
  const [name, setName] = useState(user?.name ?? '');
  const [form, setForm] = useState<StudentProfile | null>(profile);

  const load = useCallback(async () => {
    try {
      const res = await api.get<{ progress: ChapterProgress[] }>('/api/progress');
      setProgress(res.progress);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your syllabus tracker.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (profile) setForm(profile); }, [profile]);

  const set = <K extends keyof StudentProfile>(key: K, value: StudentProfile[K]) =>
    setForm((prev) => (prev ? { ...prev, [key]: value } : prev));

  const saveProfile = async () => {
    if (!form) return;
    setSaving(true);
    setError(null);
    try {
      await api.put('/api/profile', form);
      await refresh();
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      push('Profile updated. Your plan and recommendations now use the new details.', 'ok');
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save your profile.');
    } finally {
      setSaving(false);
    }
  };

  const saveName = async () => {
    try {
      await api.patch('/api/auth/me', { name });
      await refresh();
      push('Name updated.', 'ok');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not update your name.', 'bad');
    }
  };

  const updateChapter = async (chapter: ChapterProgress, status: ChapterProgress['status']) => {
    setProgress((prev) => prev.map((p) => p.id === chapter.id ? { ...p, status } : p));
    try {
      const res = await api.patch<{ progress: Record<string, unknown> }>('/api/progress', {
        subject: chapter.subject, chapter: chapter.chapter, status,
      });
      const updated = res.progress;
      setProgress((prev) => prev.map((p) => p.id === chapter.id
        ? { ...p, status, mastery: Number(updated.mastery ?? p.mastery), nextReview: (updated.next_review as string) ?? p.nextReview }
        : p));
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not update that chapter.', 'bad');
      await load();
    }
  };

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return progress.filter((p) =>
      (!filterSubject || p.subject === filterSubject) &&
      (!term || p.chapter.toLowerCase().includes(term) || p.subject.toLowerCase().includes(term)),
    );
  }, [progress, search, filterSubject]);

  const grouped = useMemo(() => {
    const map = new Map<string, ChapterProgress[]>();
    for (const p of filtered) {
      const list = map.get(p.subject) ?? [];
      list.push(p);
      map.set(p.subject, list);
    }
    return [...map.entries()];
  }, [filtered]);

  if (!form) return <Spinner />;

  const examSubjects = subjectsForExam(form.exam, form.classLevel);
  const total = progress.length;
  const confident = progress.filter((p) => p.status === 'confident').length;
  const revisionDue = progress.filter((p) => p.nextReview && p.nextReview <= todayISO()).length;

  return (
    <div className="space-y-4">
      {error && <Banner tone="bad">{error}</Banner>}
      {saved && <Banner tone="ok">Changes saved.</Banner>}

      <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <Card>
          <SectionHeading title="Academic profile" subtitle="Everything here shapes your teaching depth and plan" action={<Button onClick={() => void saveProfile()} loading={saving}>Save changes</Button>} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name" required>
              <Input value={form.name} onChange={(e) => set('name', e.target.value)} />
            </Field>
            <Field label="Target examination">
              <Select value={form.exam} onChange={(e) => {
                const exam = e.target.value as ExamId;
                const subjects = subjectsForExam(exam, exam === 'cbse10' ? '10' : '12');
                setForm((prev) => prev ? {
                  ...prev, exam, examLabel: EXAM_PATTERNS[exam].label,
                  subjects, weakSubjects: prev.weakSubjects.filter((s) => subjects.includes(s)),
                  strongSubjects: prev.strongSubjects.filter((s) => subjects.includes(s)),
                } : prev);
              }}>
                {EXAM_LIST.map((e) => <option key={e.id} value={e.id}>{e.label}</option>)}
              </Select>
            </Field>
            <Field label="Class">
              <Select value={form.classLevel} onChange={(e) => set('classLevel', e.target.value)}>
                {['9', '10', '11', '12', 'Dropper'].map((c) => <option key={c} value={c}>{c}</option>)}
              </Select>
            </Field>
            <Field label="Board">
              <Select value={form.board} onChange={(e) => set('board', e.target.value)}>
                {['CBSE', 'ICSE', 'State Board', 'IB', 'Other'].map((b) => <option key={b}>{b}</option>)}
              </Select>
            </Field>
            <Field label="Exam date">
              <Input type="date" value={form.examDate ?? ''} onChange={(e) => set('examDate', e.target.value)} />
            </Field>
            <Field label="Target score / rank">
              <Input value={form.targetScore} onChange={(e) => set('targetScore', e.target.value)} />
            </Field>
            <Field label="Daily study hours">
              <Input type="number" min={1} max={16} step={0.5} value={form.dailyHours} onChange={(e) => set('dailyHours', Number(e.target.value))} />
            </Field>
            <Field label="Learning preference">
              <Select value={form.learningStyle} onChange={(e) => set('learningStyle', e.target.value)}>
                {[
                  'Step-by-step explanations with worked examples',
                  'Visual intuition first, then formal derivation',
                  'Practice questions with hints, minimal theory',
                  'Story and analogy driven explanations',
                  'Formula-first, application-focused revision',
                ].map((s) => <option key={s}>{s}</option>)}
              </Select>
            </Field>
          </div>

          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            <Field label="Wake at"><Input type="time" value={form.wakeAt} onChange={(e) => set('wakeAt', e.target.value)} /></Field>
            <Field label="Sleep at"><Input type="time" value={form.sleepAt} onChange={(e) => set('sleepAt', e.target.value)} /></Field>
            <Field label="Study window start"><Input type="time" value={form.preferredStart} onChange={(e) => set('preferredStart', e.target.value)} /></Field>
            <Field label="Study window end"><Input type="time" value={form.preferredEnd} onChange={(e) => set('preferredEnd', e.target.value)} /></Field>
            <Field label="School start"><Input type="time" value={form.schoolStart ?? ''} onChange={(e) => set('schoolStart', e.target.value)} /></Field>
            <Field label="School end"><Input type="time" value={form.schoolEnd ?? ''} onChange={(e) => set('schoolEnd', e.target.value)} /></Field>
          </div>

          <div className="mt-3">
            <Field label="Commitments and constraints">
              <Textarea value={form.commitments} onChange={(e) => set('commitments', e.target.value)} className="min-h-[70px]" />
            </Field>
          </div>

          <div className="mt-3">
            <span className="label">Subjects</span>
            <div className="flex flex-wrap gap-1.5">
              {examSubjects.map((subject) => {
                const active = form.subjects.includes(subject);
                return (
                  <button key={subject} onClick={() => {
                    const subjects = active ? form.subjects.filter((s) => s !== subject) : [...form.subjects, subject];
                    setForm((prev) => prev ? {
                      ...prev, subjects,
                      weakSubjects: prev.weakSubjects.filter((s) => subjects.includes(s)),
                      strongSubjects: prev.strongSubjects.filter((s) => subjects.includes(s)),
                    } : prev);
                  }} className={cn('chip', active && 'border-brand/50 bg-brand/10 text-brand')}>{subject}</button>
                );
              })}
            </div>
          </div>

          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div>
              <span className="label">Weak subjects</span>
              <div className="flex flex-wrap gap-1.5">
                {form.subjects.map((s) => (
                  <button key={s} onClick={() => setForm((prev) => prev ? {
                    ...prev,
                    weakSubjects: prev.weakSubjects.includes(s) ? prev.weakSubjects.filter((x) => x !== s) : [...prev.weakSubjects, s],
                    strongSubjects: prev.strongSubjects.filter((x) => x !== s),
                  } : prev)} className={cn('chip', form.weakSubjects.includes(s) && 'border-bad/50 bg-bad/10 text-bad')}>{s}</button>
                ))}
              </div>
            </div>
            <div>
              <span className="label">Strong subjects</span>
              <div className="flex flex-wrap gap-1.5">
                {form.subjects.map((s) => (
                  <button key={s} onClick={() => setForm((prev) => prev ? {
                    ...prev,
                    strongSubjects: prev.strongSubjects.includes(s) ? prev.strongSubjects.filter((x) => x !== s) : [...prev.strongSubjects, s],
                    weakSubjects: prev.weakSubjects.filter((x) => x !== s),
                  } : prev)} className={cn('chip', form.strongSubjects.includes(s) && 'border-ok/50 bg-ok/10 text-ok')}>{s}</button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <SectionHeading title="Account" />
            <div className="space-y-3">
              <Field label="Display name">
                <div className="flex gap-2">
                  <Input value={name} onChange={(e) => setName(e.target.value)} />
                  <Button variant="secondary" onClick={() => void saveName()} className="shrink-0 px-3 py-2 text-xs">Save</Button>
                </div>
              </Field>
              <div className="flex items-center justify-between rounded-xl border border-line bg-elevated/30 px-3 py-2.5">
                <div className="flex items-center gap-2 text-sm text-ink"><User size={15} /> {user?.email}</div>
              </div>
              <div className="flex items-center justify-between rounded-xl border border-line bg-elevated/30 px-3 py-2.5">
                <div className="flex items-center gap-2 text-sm text-ink">
                  {theme === 'dark' ? <Moon size={15} /> : <Sun size={15} />} {theme === 'dark' ? 'Dark' : 'Light'} theme
                </div>
                <Button variant="secondary" className="px-2.5 py-1.5 text-xs" onClick={toggle}>Switch</Button>
              </div>
              <Button variant="danger" className="w-full" onClick={() => void logout().then(() => navigate('/login'))}>
                <LogOut size={15} /> Sign out
              </Button>
            </div>
          </Card>

          <Card>
            <SectionHeading title="Syllabus health" />
            <div className="space-y-2.5">
              <div className="flex justify-between text-sm"><span className="text-muted">Chapters tracked</span><span className="font-semibold text-ink">{total}</span></div>
              <div className="flex justify-between text-sm"><span className="text-muted">Confident</span><span className="font-semibold text-ok">{confident}</span></div>
              <div className="flex justify-between text-sm"><span className="text-muted">Revision due</span><span className="font-semibold text-warn">{revisionDue}</span></div>
              <ProgressBar value={total ? (confident / total) * 100 : 0} tone="ok" />
            </div>
          </Card>
        </div>
      </div>

      <Card>
        <SectionHeading
          title="Syllabus tracker"
          subtitle="Mark chapters as you learn them — tests and revision update this automatically"
          action={
            <div className="flex flex-wrap gap-2">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find chapter…" className="w-44 pl-8 text-xs" />
              </div>
              <Select value={filterSubject} onChange={(e) => setFilterSubject(e.target.value)} className="w-auto text-xs">
                <option value="">All subjects</option>
                {[...new Set(progress.map((p) => p.subject))].map((s) => <option key={s}>{s}</option>)}
              </Select>
            </div>
          }
        />
        {loading ? <Spinner /> : progress.length === 0 ? (
          <p className="text-sm text-muted">Chapters appear after you complete onboarding.</p>
        ) : (
          <div className="space-y-4">
            {grouped.map(([subject, chapters]) => (
              <div key={subject}>
                <div className="mb-2 flex items-center gap-2">
                  <BookOpenCheck size={15} className="text-brand" />
                  <h3 className="font-display text-sm font-bold text-ink">{subject}</h3>
                  <Badge>{chapters.filter((c) => c.status === 'confident').length}/{chapters.length} confident</Badge>
                </div>
                <div className="grid gap-1.5 lg:grid-cols-2">
                  {chapters.map((chapter) => (
                    <div key={chapter.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-line/70 bg-elevated/25 px-2.5 py-2">
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-medium text-ink">{chapter.chapter}</div>
                        <div className="mt-0.5 text-[10px] text-muted">
                          {Math.round(chapter.mastery * 100)}% mastery
                          {chapter.nextReview ? ` · next review ${chapter.nextReview}` : ''}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        {STATUSES.map((status) => (
                          <button key={status.value} onClick={() => void updateChapter(chapter, status.value)}
                            title={status.label}
                            className={cn('grid h-6 w-6 place-items-center rounded-md border text-[10px] transition',
                              chapter.status === status.value ? 'border-brand bg-brand text-white' : 'border-line text-muted hover:border-brand/50')}>
                            {chapter.status === status.value ? <Check size={11} /> : status.label[0]}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <p className="text-center text-[11px] text-muted">
        Your profile, schedule and attempts are private to this account. Deleting a resource removes its indexed text; generated questions remain in your bank.
      </p>
    </div>
  );
}
