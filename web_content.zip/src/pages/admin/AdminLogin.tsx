import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  ArrowRight, 
  AlertCircle, 
  Globe, 
  ArrowLeft,
  KeyRound
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';

export const AdminLogin: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, role, loginWithEmail, loginWithGoogle, resetPassword, error, clearError, loading } = useAuth();
  const { language, setLanguage } = useApp();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const isBn = language === 'bn';

  const isSuperAdmin = 
    role === 'SUPER_ADMIN' || 
    (currentUser?.email && ['mdsujatali20@gmail.com', 'alimdsujat4@gmail.com', 'admin@shanju.com'].includes(currentUser.email.toLowerCase()));

  // If already authenticated as super admin, redirect to /admin
  useEffect(() => {
    if (!loading && currentUser && isSuperAdmin) {
      const destination = (location.state as any)?.from?.pathname || '/admin';
      navigate(destination, { replace: true });
    }
  }, [currentUser, isSuperAdmin, loading, navigate, location]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setLocalError(null);
    setIsSubmitting(true);

    try {
      if (showForgot) {
        if (!email.trim()) {
          setLocalError(isBn ? 'অনুগ্রহ করে আপনার অ্যাডমিন ইমেইল দিন।' : 'Please enter your admin email.');
          setIsSubmitting(false);
          return;
        }
        await resetPassword(email.trim());
        setResetSent(true);
      } else {
        await loginWithEmail(email.trim(), password);
        // The useEffect will handle navigation once role is verified
      }
    } catch (err: any) {
      // Error is set in AuthContext
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleLogin = async () => {
    clearError();
    setLocalError(null);
    setIsSubmitting(true);
    try {
      await loginWithGoogle();
      // The useEffect will handle navigation once role is verified
    } catch (err: any) {
      // Error handled in AuthContext
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-gradient-to-tr from-emerald-600/15 via-teal-500/10 to-blue-600/10 blur-[130px] rounded-full pointer-events-none"></div>

      {/* Top Bar with Language & Back to Public */}
      <div className="w-full max-w-md flex items-center justify-between mb-8 z-10">
        <Link 
          to="/"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-emerald-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isBn ? 'সাধারণ ওয়েবসাইটে ফিরুন' : 'Back to Public Website'}</span>
        </Link>

        <button
          onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white transition-colors"
        >
          <Globe className="w-3.5 h-3.5 text-emerald-400" />
          <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
        </button>
      </div>

      {/* Admin Login Card */}
      <div className="w-full max-w-md bg-slate-900/90 border border-slate-800 rounded-3xl p-8 shadow-2xl backdrop-blur-xl relative z-10">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/25 border border-emerald-400/30">
            <ShieldCheck className="w-9 h-9" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold tracking-wider uppercase mb-2">
            <Lock className="w-3 h-3" />
            <span>Platform Admin Portal</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            {isBn ? 'সুপার অ্যাডমিন লগইন' : 'Super Admin Sign In'}
          </h1>
          <p className="text-xs text-slate-400 mt-1.5">
            {isBn 
              ? 'প্ল্যাটফর্মের কেন্দ্রীয় কনফিগারেশন ও মার্চেন্ট ব্যবস্থাপনার জন্য প্রবেশ করুন' 
              : 'Sign in to access platform-wide settings and merchant administration'}
          </p>
        </div>

        {/* Logged in as non-admin notice */}
        {currentUser && !isSuperAdmin && !loading && (
          <div className="mb-6 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <p className="font-bold">
                  {isBn ? 'অ্যাডমিন অধিকার নেই' : 'Unauthorized Account'}
                </p>
                <p className="mt-1 text-slate-300">
                  {isBn 
                    ? `আপনি বর্তমানে "${currentUser.email}" হিসেবে লগইন আছেন, যার অ্যাডমিন সুবিধা নেই। অ্যাডমিন ইমেইল দিয়ে লগইন করুন।`
                    : `You are signed in as "${currentUser.email}" which does not have administrative privileges.`}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Global Error Banner */}
        {(error || localError) && (
          <div className="mb-6 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <span className="leading-relaxed">{error || localError}</span>
          </div>
        )}

        {/* Password Reset Confirmation */}
        {resetSent && (
          <div className="mb-6 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>
              {isBn 
                ? 'পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।' 
                : 'Password reset instructions have been sent to your email.'}
            </span>
          </div>
        )}

        {/* Google Admin Sign-in Button */}
        {!showForgot && (
          <div className="mb-6">
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-white font-semibold text-xs border border-slate-700 hover:border-slate-600 transition-all shadow-sm"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>{isBn ? 'গুগল দিয়ে অ্যাডমিন লগইন' : 'Sign in with Google'}</span>
            </button>

            <div className="relative my-5">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-800"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-slate-900 px-3 text-slate-500 font-semibold tracking-wider">
                  {isBn ? 'অথবা ইমেইল দিয়ে' : 'or with email'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Email & Password Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {isBn ? 'অ্যাডমিন ইমেইল' : 'Admin Email'}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@shanju.com"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
              />
            </div>
          </div>

          {!showForgot && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  {isBn ? 'অ্যাডমিন পাসওয়ার্ড' : 'Admin Password'}
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgot(true)}
                  className="text-[11px] text-emerald-400 hover:underline"
                >
                  {isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-2 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
            ) : showForgot ? (
              <>
                <span>{isBn ? 'রিসেট লিংক পাঠান' : 'Send Reset Link'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>{isBn ? 'অ্যাডমিন প্যানেলে প্রবেশ করুন' : 'Enter Admin Panel'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          {showForgot && (
            <button
              type="button"
              onClick={() => setShowForgot(false)}
              className="w-full text-center text-xs text-slate-400 hover:text-white mt-2"
            >
              {isBn ? '← লগইনে ফিরে যান' : '← Back to Sign In'}
            </button>
          )}
        </form>

        {/* Security Note */}
        <div className="mt-8 pt-6 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-500 leading-relaxed">
            {isBn 
              ? 'নিরাপত্তা সতর্কতা: এই পোর্টালটি শুধুমাত্র অনুমোদিত প্ল্যাটফর্ম অ্যাডমিনিস্ট্রেটরদের জন্য।' 
              : 'Security notice: This portal is restricted to authorized platform administrators only.'}
          </p>
        </div>
      </div>
    </div>
  );
};
