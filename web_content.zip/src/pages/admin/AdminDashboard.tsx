import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminPanel } from '../../components/admin/AdminPanel';
import { useApp } from '../../context/AppContext';

export const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const {
    language,
    merchantUsers,
    stores,
    paymentGateways,
    subscriptionPayments,
    handleUpdateUser,
    handleAddUser,
    handleDeleteUser,
    handleUpdateGateway,
    handleToggleGateway,
    setIsExportModalOpen,
    setActiveStoreId
  } = useApp();

  return (
    <div className="w-full">
      <AdminPanel
        language={language}
        users={merchantUsers}
        stores={stores}
        gateways={paymentGateways}
        payments={subscriptionPayments}
        onUpdateUser={handleUpdateUser}
        onAddUser={handleAddUser}
        onDeleteUser={handleDeleteUser}
        onUpdateGateway={handleUpdateGateway}
        onToggleGateway={handleToggleGateway}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onSwitchToMerchantStore={(storeId: string) => {
          setActiveStoreId(storeId);
          navigate('/dashboard');
        }}
        onNavigateToMerchantConsole={() => navigate('/dashboard')}
      />
    </div>
  );
};
