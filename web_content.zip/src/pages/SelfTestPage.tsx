import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, CheckCircle2, Download, FlaskConical, Loader2, Play, ShieldCheck, SquareStack, XCircle, Zap } from "lucide-react";
import type { ExportProgress, ExportResult, Mp4Check } from "@/types";
import type { EngineCapabilities } from "@/lib/exporter";
import { createBlankProject, defaultTiming, formatBytes, formatDuration, newEmptyQuestion, uid } from "@/data/defaults";
import { buildTimeline } from "@/lib/timeline";
import { detectEngineCapabilities, exportMp4, isAbortError } from "@/lib/exporter";
import { downloadBlob, errorMessage, makeToneWav } from "@/lib/media";
import { validateProject, issueSummary } from "@/lib/preflight";
import { Button, SectionHeader, Segmented } from "@/components/ui";
import { cn } from "@/utils/cn";

export const TEST_REPORT_KEY = "quiz-studio-test-report";

export interface TestReport {
  at: number;
  ok: boolean;
  orientation: "vertical" | "landscape";
  width: number;
  height: number;
  duration: number;
  size: number;
  audioCodec: string;
  videoCodec: string;
  checks: Mp4Check[];
  error?: string;
}

function buildTestFixture(orientation: "vertical" | "landscape") {
  const project = createBlankProject("اختبار تقني — Quiz Studio Pro", orientation);
  const questionTone = makeToneWav(2.1);
  const optionsTone = makeToneWav(1.5);
  const questionId = uid("test_question_audio");
  const optionsId = uid("test_options_audio");
  const blobs: Record<string, Blob> = { [questionId]: questionTone, [optionsId]: optionsTone };
  project.isSample = false;
  project.exportSettings = {
    ...project.exportSettings,
    aspect: orientation,
    width: orientation === "vertical" ? 720 : 1280,
    height: orientation === "vertical" ? 1280 : 720,
    fps: 25,
    quality: "economy",
    videoBitrate: 3_000_000,
    audioBitrate: 96_000,
    filename: `quiz-engine-test-${orientation}`,
  };
  project.timing = {
    ...defaultTiming(),
    audioMode: "separate",
    questionHoldMs: 200,
    optionsHoldMs: 250,
    nextHoldMs: 350,
    defaultThinkSec: 2,
    requireAudio: true,
    voiceVolume: 90,
    sfxEnabled: true,
    sfxVolume: 65,
  };
  project.design = {
    ...project.design,
    presetName: "قالب الاختبار التقني",
    background: { ...project.design.background, kind: "gradient", colorA: "#0b0d12", colorB: "#1d1710", glow: true, grid: true, imageId: null },
    typography: { ...project.design.typography, font: "Tajawal", questionSize: 58, optionSize: 34 },
    timer: { ...project.design.timer, visible: true, style: "ring", x: 50, y: 90 },
    content: { ...project.design.content, x: 50, y: 45, width: 87 },
    brand: { ...project.design.brand, show: true, text: "ENGINE TEST", showProgress: true },
    motion: { ...project.design.motion, entrance: "rise", reveal: "glow", transition: "fade", speed: 1 },
  };
  project.media = {
    [questionId]: {
      id: questionId,
      name: "test_q01_question.wav",
      type: "audio/wav",
      size: questionTone.size,
      kind: "audio",
      duration: 2.1,
      createdAt: Date.now(),
    },
    [optionsId]: {
      id: optionsId,
      name: "test_q01_options.wav",
      type: "audio/wav",
      size: optionsTone.size,
      kind: "audio",
      duration: 1.5,
      createdAt: Date.now(),
    },
  };
  project.questions = [
    {
      ...newEmptyQuestion(2),
      question: "ما هي عاصمة المملكة العربية السعودية؟",
      options: ["الرياض", "جدة", "مكة المكرمة", "الدمام"],
      correct: 0,
      questionAudioId: questionId,
      optionsAudioId: optionsId,
      thinkSec: 2,
      revealHoldMs: 1300,
    },
  ];
  return { project, blobs };
}

export function SelfTestPage() {
  const [orientation, setOrientation] = useState<"vertical" | "landscape">("vertical");
  const [caps, setCaps] = useState<EngineCapabilities | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<ExportProgress>({ phase: "idle", percent: 0, label: "جاهز" });
  const [result, setResult] = useState<ExportResult | null>(null);
  const [checks, setChecks] = useState<Mp4Check[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<TestReport | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const resultUrl = useRef<string | null>(null);

  useEffect(() => {
    void detectEngineCapabilities().then(setCaps);
    try {
      const stored = localStorage.getItem(TEST_REPORT_KEY);
      if (stored) setReport(JSON.parse(stored) as TestReport);
    } catch {
      /* ignore */
    }
    return () => {
      abortRef.current?.abort();
      if (resultUrl.current) URL.revokeObjectURL(resultUrl.current);
    };
  }, []);

  const saveReport = (next: TestReport) => {
    setReport(next);
    try {
      localStorage.setItem(TEST_REPORT_KEY, JSON.stringify(next));
    } catch {
      /* التخزين قد يكون ممتلئًا */
    }
  };

  const runTest = async () => {
    if (running) return;
    if (!caps?.videoSupported || !caps?.audioSupported) {
      setError(`لا يمكن تشغيل اختبار الإنتاج: ${caps?.reason ?? "لم يكتمل فحص محرك التصدير."}`);
      return;
    }
    const { project, blobs } = buildTestFixture(orientation);
    const timeline = buildTimeline(project);
    const issues = validateProject(project, { requireAudio: true });
    const summary = issueSummary(issues);
    if (summary.errors) {
      setError(`فشل إعداد مشهد الاختبار: ${issues.find((issue) => issue.level === "error")?.message}`);
      return;
    }
    setRunning(true);
    setResult(null);
    setChecks([]);
    setError(null);
    setProgress({ phase: "preparing", percent: 0, label: "تجهيز مشهد الاختبار" });
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const output = await exportMp4({
        project,
        timeline,
        images: new Map(),
        getBlob: async (id) => blobs[id],
        onProgress: setProgress,
        signal: controller.signal,
      });
      if (resultUrl.current) URL.revokeObjectURL(resultUrl.current);
      const url = URL.createObjectURL(output.blob);
      resultUrl.current = url;
      const exportResult: ExportResult = {
        ...output,
        url,
        filename: `${project.exportSettings.filename}.mp4`,
        size: output.blob.size,
        createdAt: Date.now(),
      };
      setResult(exportResult);
      setChecks(output.checks);
      saveReport({
        at: Date.now(),
        ok: true,
        orientation,
        width: output.width,
        height: output.height,
        duration: output.duration,
        size: exportResult.size,
        audioCodec: output.audioCodec,
        videoCodec: output.videoCodec,
        checks: output.checks,
      });
    } catch (caught) {
      if (isAbortError(caught)) {
        setProgress({ phase: "cancelled", percent: 0, label: "أُلغي الاختبار" });
        setError(null);
      } else {
        const message = errorMessage(caught, "فشل اختبار المحرك.");
        const failedChecks = (caught as { checks?: Mp4Check[] })?.checks;
        if (failedChecks?.length) setChecks(failedChecks);
        setError(message);
        setProgress({ phase: "error", percent: 0, label: "فشل الاختبار", detail: message });
        saveReport({ at: Date.now(), ok: false, orientation, width: 0, height: 0, duration: 0, size: 0, audioCodec: "", videoCodec: "", checks: failedChecks ?? [], error: message });
      }
    } finally {
      abortRef.current = null;
      setRunning(false);
    }
  };

  const previewFixture = useMemo(() => buildTestFixture(orientation), [orientation]);
  const scene = useMemo(() => buildTimeline(previewFixture.project), [previewFixture]);

  return (
    <div>
      <SectionHeader
        icon={<FlaskConical size={18} />}
        eyebrow="التحقق الفني"
        title="اختبار محرك التصدير"
        description="اختبار حقيقي يُنشئ MP4 قصيرًا يحتوي خلفية ونصًا عربيًا وأربعة خيارات وملفًا صوتيًا وتمييز الإجابة الصحيحة بالأخضر وانتقالًا زمنيًا. لا يُعلن النجاح إلا بعد فحص الملف."
        actions={
          <Button variant="primary" onClick={() => void runTest()} loading={running} disabled={!caps?.videoSupported || !caps?.audioSupported}>
            <Zap size={14} /> تشغيل الاختبار الآن
          </Button>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_1.25fr]">
        <div className="space-y-3">
          <div className="panel p-4">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-[15px] font-bold text-white">مكوّنات مشهد الاختبار</h3>
              <span className="chip chip-gold !py-0.5">{orientation === "vertical" ? "720×1280" : "1280×720"}</span>
            </div>
            <div className="mb-3">
              <Segmented size="sm" value={orientation} onChange={(value) => setOrientation(value)} options={[{ value: "vertical", label: "عمودي 9:16" }, { value: "landscape", label: "أفقي 16:9" }]} />
            </div>
            <div className="rounded-xl border border-white/[0.08] bg-[#0d0f16] p-3">
              <p className="mb-2 text-[9px] font-medium uppercase tracking-[0.18em] text-[#8d7a4d]">ENGINE TEST · سؤال</p>
              <p className="text-[15px] font-bold leading-7 text-white">ما هي عاصمة المملكة العربية السعودية؟</p>
              <div className="mt-2.5 space-y-1.5">
                {["الرياض", "جدة", "مكة المكرمة", "الدمام"].map((option, index) => (
                  <div key={option} className={cn("flex items-center gap-2 rounded-lg border px-2.5 py-1.5 text-[11px]", index === 0 ? "border-[#57dc96]/45 bg-[#57dc96]/15 text-[#c6f6db]" : "border-white/10 bg-white/[0.03] text-[#cfcfd6]")}>
                    <span className={cn("flex h-5 w-5 items-center justify-center rounded-full text-[9px]", index === 0 ? "bg-[#57dc96] text-[#04150c]" : "bg-white/10")}>{index === 0 ? "✓" : ["أ", "ب", "ج", "د"][index]}</span>
                    {option}
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-3 space-y-1.5 text-[10px] leading-5 text-[#85858f]">
              {[
                "خلفية تدرج + شبكة وإضاءة",
                "نص عربي بخط Tajawal مع التشكيل",
                "أربعة خيارات وتمييز الأخضر + ✓",
                "صوت سؤال 2.1 ث + صوت خيارات 1.5 ث",
                "مؤقت تفكير ثم انتقال إلى السؤال التالي",
              ].map((item) => <p key={item} className="flex items-center gap-1.5"><CheckCircle2 size={11} className="text-[#6fe0a4]" /> {item}</p>)}
            </div>
            <div className="mt-3 flex items-center justify-between rounded-lg border border-white/[0.06] bg-black/25 px-2.5 py-1.5 text-[9px] text-[#85858f]">
              <span>مدة المشهد: {formatDuration(scene.totalDuration)}</span>
              <span>{Math.ceil(scene.totalDuration * 25)} إطارًا · 25fps</span>
            </div>
          </div>

          <div className="rounded-xl border border-[#d9b65a]/20 bg-[#d9b65a]/[0.04] p-3 text-[10px] leading-5 text-[#b6a37a]">
            <p className="flex items-center gap-1.5 font-semibold text-[#f0dfb4]"><AlertTriangle size={12} /> ماذا يعني هذا الاختبار؟</p>
            الصوت داخل الاختبار نغمة مولّدة آليًا للتأكد من وجود مسار صوتي، وليس تسجيلًا بشريًا. نجاح الاختبار يثبت أن محرك MP4 والرسم والصوت يعملون في متصفحك. ملفاتك الحقيقية تُختبر عند تصدير مشروعك.
          </div>
        </div>

        <div className="space-y-3">
          <div className="panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-display text-[15px] font-bold text-white">حالة المحرك</h3>
              <span className={cn("chip !py-0.5", caps?.videoSupported && caps?.audioSupported ? "chip-mint" : caps ? "chip-red" : "chip-gold")}>
                {caps?.videoSupported && caps?.audioSupported ? "مدعوم" : caps ? "غير مدعوم" : "يفحص…"}
              </span>
            </div>
            <p className="mt-1.5 text-[10px] leading-5 text-[#85858f]">{caps?.reason ?? "جارٍ فحص دعم WebCodecs…"}</p>
            <div className="mt-2 grid grid-cols-2 gap-1.5 text-[10px]">
              {[
                ["WebCodecs", caps?.webCodecs ? "متوفر" : "غير متوفر"],
                ["H.264", caps?.videoCodec ?? "—"],
                ["الصوت", caps?.audioCodec ?? "—"],
                ["اتصال آمن", caps?.secure ? "نعم" : "لا"],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-white/[0.06] bg-white/[0.02] px-2 py-1.5"><p className="text-[9px] text-[#75757f]">{label}</p><p className="mt-0.5 font-medium text-[#e2e2e8]" dir="ltr">{value}</p></div>
              ))}
            </div>
            {running ? (
              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between text-[10px]"><span className="flex items-center gap-1.5 text-[#e7cf94]"><Loader2 size={12} className="animate-spin" /> {progress.label}</span><span className="tabular-nums text-[#c9c9d1]">{Math.round(progress.percent)}%</span></div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-l from-[#e7cf94] to-[#b99044] transition-[width]" style={{ width: `${Math.max(2, progress.percent)}%` }} /></div>
                <button type="button" onClick={() => abortRef.current?.abort()} className="mt-2 text-[10px] text-[#d9a5a5] hover:text-red-200">إلغاء الاختبار</button>
              </div>
            ) : (
              <Button variant="primary" className="mt-3 w-full" onClick={() => void runTest()} disabled={!caps?.videoSupported || !caps?.audioSupported}>
                <Play size={14} /> تشغيل الاختبار الفني
              </Button>
            )}
          </div>

          {error ? (
            <div className="rounded-xl border border-red-400/25 bg-[#1a0f11] p-3.5">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold text-red-100"><XCircle size={14} /> الاختبار لم ينجح</p>
              <p className="mt-1 text-[10px] leading-5 text-[#d3a5a7]">{error}</p>
              <Button variant="ghost" className="mt-2 !px-2.5 !py-1.5 text-[10px]" onClick={() => void runTest()}>إعادة المحاولة</Button>
            </div>
          ) : null}

          {result ? (
            <div className="panel overflow-hidden border-[#57dc96]/20">
              <div className="flex items-center gap-2 border-b border-white/[0.07] bg-[#57dc96]/[0.05] px-3.5 py-2.5">
                <CheckCircle2 size={15} className="text-[#7ce1a9]" />
                <div className="flex-1"><p className="text-[11px] font-semibold text-[#d8f6e5]">نجح الاختبار وتم التحقق من MP4</p><p className="text-[9px] text-[#86bb9f]">{formatBytes(result.size)} · {result.width}×{result.height} · {formatDuration(result.duration)} · {result.audioCodec}</p></div>
                <Button variant="mint" className="!px-2.5 !py-1.5 text-[10px]" onClick={() => { try { downloadBlob(result.blob, result.filename); } catch { /* handled by no-op */ } }}>
                  <Download size={12} /> تنزيل
                </Button>
              </div>
              <div className="p-3">
                <video src={result.url} controls playsInline className="mx-auto max-h-[340px] rounded-lg border border-white/10 bg-black" />
                <div className="mt-2 grid grid-cols-2 gap-1.5">
                  {checks.filter((check) => check.status !== "warn").slice(0, 6).map((check) => (
                    <div key={check.key} className="flex items-center gap-1.5 rounded-md border border-white/[0.06] bg-white/[0.02] px-2 py-1 text-[9px] text-[#a9d9bd]"><CheckCircle2 size={10} className="shrink-0 text-[#6fe0a4]" /><span className="truncate">{check.label}</span></div>
                  ))}
                </div>
                <p className="mt-2 text-[9px] leading-5 text-[#75757f]">نزّل الملف وشغّله في مشغل الجهاز للتأكد من الصوت والصورة. هذا الاختبار لا يغني عن مراجعة مشروعك النهائي.</p>
              </div>
            </div>
          ) : null}

          <div className="panel p-3.5">
            <h3 className="mb-2 flex items-center gap-1.5 font-display text-[14px] font-bold text-white"><ShieldCheck size={14} className="text-[#57dc96]" /> الفحوصات التي يجريها التطبيق</h3>
            <div className="grid gap-1.5 sm:grid-cols-2">
              {[
                "حجم الملف ليس صفرًا",
                "ترويسة ftyp وبُنية moov/mdat",
                "وجود مسار فيديو H.264",
                "وجود مسار صوت مستقل",
                "مدة MP4 قابلة للقراءة",
                "أبعاد الملف مطابقة للطلب",
                "المتصفح يقرأ بيانات الفيديو",
              ].map((item) => <p key={item} className="flex items-start gap-1 text-[9px] leading-5 text-[#8b8b95]"><CheckCircle2 size={10} className="mt-1 shrink-0 text-[#6fe0a4]" /> {item}</p>)}
            </div>
          </div>

          <div className="panel p-3.5">
            <h3 className="mb-2 flex items-center gap-1.5 font-display text-[14px] font-bold text-white"><SquareStack size={14} className="text-[#d9b65a]" /> آخر تقرير محفوظ على هذا الجهاز</h3>
            {report ? (
              <div className="space-y-1.5 text-[10px]">
                <div className="flex items-center justify-between"><span className="text-[#85858f]">الحالة</span><span className={report.ok ? "text-[#8cebb5]" : "text-red-300"}>{report.ok ? "نجح + تم التحقق" : "لم ينجح"}</span></div>
                <div className="flex items-center justify-between"><span className="text-[#85858f]">التاريخ</span><span className="text-[#d5d5dc]">{new Date(report.at).toLocaleString("ar")}</span></div>
                <div className="flex items-center justify-between"><span className="text-[#85858f]">الاتجاه</span><span className="text-[#d5d5dc]">{report.orientation === "vertical" ? "عمودي" : "أفقي"} · {report.width}×{report.height}</span></div>
                {report.error ? <p className="rounded-md border border-red-400/20 bg-red-400/[0.05] px-2 py-1 text-[9px] text-red-200">{report.error}</p> : null}
              </div>
            ) : (
              <p className="text-[10px] leading-5 text-[#85858f]">لا توجد نتيجة اختبار بعد. شغّل الاختبار أعلاه لإنشاء سجل حقيقي.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
