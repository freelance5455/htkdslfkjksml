import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Award,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  ArrowRight,
  Flame,
  Zap,
  Atom,
  Rocket,
  Sigma,
  ChevronRight,
  Layers,
  BookOpen
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface PracticeQuestionItem {
  id: string;
  topic: string;
  title: string;
  scenario: string;
  formulaDisplay: string;
  given: Record<string, { value: number; unit: string }>;
  target: { symbol: string; name: string; unit: string };
  correctAnswer: number;
  tolerancePct: number;
  options: number[];
  hint: string;
  steps: string[];
}

const PRACTICE_QUESTIONS: PracticeQuestionItem[] = [
  {
    id: 'mech-1',
    topic: 'Mechanics',
    title: "Newton's Second Law: Acceleration of a Lunar Rover",
    scenario:
      'A prototype rover of mass 450 kg is accelerated across a horizontal test track with a constant net thrust of 1,350 N. Assuming friction is negligible, calculate its resulting linear acceleration.',
    formulaDisplay: 'F = m × a  ➔  a = F / m',
    given: {
      F: { value: 1350, unit: 'N' },
      m: { value: 450, unit: 'kg' }
    },
    target: { symbol: 'a', name: 'Acceleration', unit: 'm/s²' },
    correctAnswer: 3.0,
    tolerancePct: 2,
    options: [1.5, 3.0, 4.25, 9.8],
    hint: 'Rearrange F = m * a to isolate acceleration: divide the net force by the vehicle mass.',
    steps: [
      'Identify given quantities: Net Force F = 1,350 N, Mass m = 450 kg.',
      "State governing equation: Newton's Second Law, F = m × a.",
      'Rearrange for target variable: a = F / m.',
      'Substitute values: a = 1,350 N / 450 kg.',
      'Compute final result: a = 3.0 m/s².'
    ]
  },
  {
    id: 'elec-1',
    topic: 'Electronics',
    title: "Ohm's Law: Current in a High-Power Resistor",
    scenario:
      'An electronics subassembly operates from a regulated DC power rail of 24.0 V. A precision power resistor with resistance 4.8 Ω is connected across the rail. Determine the current flowing through it.',
    formulaDisplay: 'V = I × R  ➔  I = V / R',
    given: {
      V: { value: 24, unit: 'V' },
      R: { value: 4.8, unit: 'Ω' }
    },
    target: { symbol: 'I', name: 'Current', unit: 'A' },
    correctAnswer: 5.0,
    tolerancePct: 2,
    options: [2.4, 4.0, 5.0, 115.2],
    hint: "Use Ohm's Law (V = I * R). Divide voltage by resistance to solve for current in Amperes.",
    steps: [
      'Given: DC Potential V = 24.0 V, Resistance R = 4.8 Ω.',
      "Ohm's Law relation: V = I × R.",
      'Rearrange for electric current: I = V / R.',
      'Substitute: I = 24.0 V / 4.8 Ω.',
      'Compute: I = 5.0 A.'
    ]
  },
  {
    id: 'mech-2',
    topic: 'Mechanics',
    title: 'Kinetic Energy of a High-Speed Drone',
    scenario:
      'A surveillance drone with a total takeoff mass of 8.0 kg cruises at a constant ground speed of 25.0 m/s. Compute the kinetic energy stored in its translational motion.',
    formulaDisplay: 'KE = ½ × m × v²',
    given: {
      m: { value: 8, unit: 'kg' },
      v: { value: 25, unit: 'm/s' }
    },
    target: { symbol: 'KE', name: 'Kinetic Energy', unit: 'J' },
    correctAnswer: 2500,
    tolerancePct: 2,
    options: [1000, 2000, 2500, 5000],
    hint: 'Square the velocity first (25² = 625), then multiply by half of the mass.',
    steps: [
      'Given: Mass m = 8.0 kg, Velocity v = 25.0 m/s.',
      'Formula: KE = 0.5 × m × v².',
      'Calculate velocity squared: (25.0 m/s)² = 625 m²/s².',
      'Multiply by mass and half: KE = 0.5 × 8.0 kg × 625 m²/s² = 4.0 × 625.',
      'Final answer: KE = 2,500 Joules (2.5 kJ).'
    ]
  },
  {
    id: 'aero-1',
    topic: 'Aerospace',
    title: 'Escape Velocity from Mars',
    scenario:
      'A return ascent vehicle prepares to leave the surface of Mars. Mars has a planetary mass of 6.42 × 10²³ kg and a mean radius of 3.39 × 10⁶ m. Calculate the theoretical escape velocity from the Martian surface.',
    formulaDisplay: 'v_esc = √( (2 × G × M) / R )',
    given: {
      G: { value: 6.674e-11, unit: 'N·m²/kg²' },
      M: { value: 6.42e23, unit: 'kg' },
      R: { value: 3.39e6, unit: 'm' }
    },
    target: { symbol: 'v_esc', name: 'Escape Velocity', unit: 'm/s' },
    correctAnswer: 5028,
    tolerancePct: 3,
    options: [3850, 5028, 7900, 11186],
    hint: 'Calculate 2*G*M, divide by R, and take the square root. Expect around 5.0 km/s.',
    steps: [
      'Given: Gravitational constant G = 6.674e-11, Mars Mass M = 6.42e23 kg, Radius R = 3.39e6 m.',
      'Escape velocity equation: v_esc = √( (2 × G × M) / R ).',
      'Compute 2 × G × M = 2 × 6.674e-11 × 6.42e23 = 8.569e13.',
      'Divide by radius: 8.569e13 / 3.39e6 = 2.528e7.',
      'Take square root: √(2.528e7) ≈ 5,028 m/s (5.03 km/s).'
    ]
  },
  {
    id: 'elec-2',
    topic: 'Electronics',
    title: 'Electrical Power: DC Motor Dissipation',
    scenario:
      'A robotics drive motor draws 12.5 A of current when loaded while maintaining a voltage drop of 36.0 V across its armature terminals. Calculate the electrical power delivered to the motor.',
    formulaDisplay: 'P = V × I',
    given: {
      V: { value: 36, unit: 'V' },
      I: { value: 12.5, unit: 'A' }
    },
    target: { symbol: 'P', name: 'Power', unit: 'W' },
    correctAnswer: 450,
    tolerancePct: 2,
    options: [288, 360, 450, 520],
    hint: 'Electric power in a DC circuit is simply the product of voltage and current: P = V * I.',
    steps: [
      'Given: Voltage V = 36.0 V, Current I = 12.5 A.',
      "Joule's Power Law: P = V × I.",
      'Substitute: P = 36.0 V × 12.5 A.',
      'Answer: P = 450.0 Watts (0.45 kW).'
    ]
  },
  {
    id: 'thermo-1',
    topic: 'Thermodynamics',
    title: 'Ideal Gas Law: Tank Pressure',
    scenario:
      'A 0.05 m³ rigid pressure vessel contains 2.0 moles of Nitrogen gas at a temperature of 300 K. Using the universal gas constant R = 8.314 J/(mol·K), calculate the pressure inside the vessel.',
    formulaDisplay: 'P × V = n × R × T  ➔  P = (n × R × T) / V',
    given: {
      n: { value: 2.0, unit: 'mol' },
      R: { value: 8.314, unit: 'J/(mol·K)' },
      T: { value: 300, unit: 'K' },
      V: { value: 0.05, unit: 'm³' }
    },
    target: { symbol: 'P', name: 'Pressure', unit: 'Pa' },
    correctAnswer: 99768,
    tolerancePct: 3,
    options: [49884, 99768, 150000, 245000],
    hint: 'Multiply moles n by R and temperature T, then divide by volume V in cubic meters.',
    steps: [
      'Given: n = 2.0 mol, R = 8.314 J/(mol·K), T = 300 K, V = 0.05 m³.',
      'Ideal Gas Law: P × V = n × R × T.',
      'Isolate pressure: P = (n × R × T) / V.',
      'Numerator: 2.0 × 8.314 × 300 = 4,988.4 J.',
      'Divide by volume: 4,988.4 / 0.05 = 99,768 Pa (≈ 99.8 kPa or 0.985 atm).'
    ]
  }
];

export const PracticePage: React.FC = () => {
  const { playSound, triggerHaptic, showToast } = useApp();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedTopic, setSelectedTopic] = useState('All');
  const [userAnswer, setUserAnswer] = useState('');
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);

  // Stats from localStorage
  const [stats, setStats] = useState<{
    solved: number;
    streak: number;
    bestStreak: number;
    attempts: number;
  }>(() => {
    try {
      const saved = localStorage.getItem('formulax_practice_scores');
      return saved ? JSON.parse(saved) : { solved: 0, streak: 0, bestStreak: 0, attempts: 0 };
    } catch {
      return { solved: 0, streak: 0, bestStreak: 0, attempts: 0 };
    }
  });

  const availableQuestions = PRACTICE_QUESTIONS.filter(
    (q) => selectedTopic === 'All' || q.topic === selectedTopic
  );

  const currentQ = availableQuestions[currentIndex % availableQuestions.length] || PRACTICE_QUESTIONS[0];

  const handleTopicChange = (topic: string) => {
    playSound('tab');
    setSelectedTopic(topic);
    setCurrentIndex(0);
    resetQuestionState();
  };

  const resetQuestionState = () => {
    setUserAnswer('');
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(false);
    setShowHint(false);
  };

  const handleCheckAnswer = () => {
    if (isAnswered) return;

    let ansNum = selectedOption !== null ? selectedOption : parseFloat(userAnswer);
    if (isNaN(ansNum)) {
      showToast('Please enter or select a valid numeric answer', 'error');
      return;
    }

    const margin = (currentQ.correctAnswer * currentQ.tolerancePct) / 100;
    const correct = Math.abs(ansNum - currentQ.correctAnswer) <= margin;

    setIsAnswered(true);
    setIsCorrect(correct);

    if (correct) {
      playSound('correct');
      triggerHaptic('success');
      showToast('Correct! Great calculation!', 'success');

      setStats((prev) => {
        const nextStreak = prev.streak + 1;
        const nextBest = Math.max(prev.bestStreak, nextStreak);
        const updated = {
          solved: prev.solved + 1,
          streak: nextStreak,
          bestStreak: nextBest,
          attempts: prev.attempts + 1
        };
        localStorage.setItem('formulax_practice_scores', JSON.stringify(updated));
        return updated;
      });
    } else {
      playSound('incorrect');
      triggerHaptic('error');
      showToast('Incorrect. Check the step-by-step breakdown.', 'error');

      setStats((prev) => {
        const updated = {
          ...prev,
          streak: 0,
          attempts: prev.attempts + 1
        };
        localStorage.setItem('formulax_practice_scores', JSON.stringify(updated));
        return updated;
      });
    }
  };

  const handleNextQuestion = () => {
    playSound('button');
    setCurrentIndex((prev) => (prev + 1) % availableQuestions.length);
    resetQuestionState();
  };

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#232323] border border-[#303030] text-[#D65A1F] text-xs font-mono font-medium mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive Engineering Practice</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            Student & Engineering Challenge
          </h1>
          <p className="text-xs sm:text-sm text-[#A9A39C]">
            Test your formula manipulation and physics intuition with step-verified problems.
          </p>
        </div>

        {/* Score & Streak Chips */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#1C1C1C] border border-[#303030]">
            <Award className="w-4 h-4 text-[#D65A1F]" />
            <div>
              <span className="text-[10px] text-[#A9A39C] block uppercase font-mono">Solved</span>
              <span className="text-sm font-bold text-[#F5F2ED] font-mono">{stats.solved}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#1C1C1C] border border-[#303030]">
            <Flame className="w-4 h-4 text-[#E87535]" />
            <div>
              <span className="text-[10px] text-[#A9A39C] block uppercase font-mono">Streak</span>
              <span className="text-sm font-bold text-[#D65A1F] font-mono">{stats.streak}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Topic Filter Chips */}
      <div className="flex flex-wrap gap-2">
        {['All', 'Mechanics', 'Electronics', 'Aerospace', 'Thermodynamics'].map((topic) => (
          <button
            key={topic}
            onClick={() => handleTopicChange(topic)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
              selectedTopic === topic
                ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                : 'bg-[#151515] text-[#A9A39C] border-[#303030] hover:text-[#F5F2ED]'
            }`}
          >
            {topic}
          </button>
        ))}
      </div>

      {/* Main Question Card */}
      <div className="rounded-3xl bg-[#1C1C1C] border border-[#303030] p-6 sm:p-8 space-y-6 shadow-2xl">
        <div className="flex items-center justify-between text-xs">
          <span className="px-2.5 py-1 rounded-md bg-[#232323] border border-[#303030] text-[#D65A1F] font-mono font-bold uppercase">
            {currentQ.topic}
          </span>
          <span className="text-[#A9A39C] font-mono">
            Problem {(currentIndex % availableQuestions.length) + 1} of {availableQuestions.length}
          </span>
        </div>

        <div>
          <h2 className="text-lg sm:text-xl font-bold text-[#F5F2ED] leading-snug">
            {currentQ.title}
          </h2>
          <p className="text-sm text-[#A9A39C] mt-2 leading-relaxed">
            {currentQ.scenario}
          </p>
        </div>

        {/* Given Parameters Card */}
        <div className="p-4 rounded-2xl bg-[#151515] border border-[#303030] space-y-3">
          <span className="text-[10px] font-mono uppercase tracking-wider text-[#A9A39C] block">
            Given Parameters:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {Object.entries(currentQ.given).map(([sym, data]) => (
              <div key={sym} className="p-2.5 rounded-xl bg-[#1C1C1C] border border-[#303030]">
                <span className="text-[10px] font-mono text-[#A9A39C] block">{sym}</span>
                <span className="text-xs font-bold text-[#F5F2ED] font-mono">
                  {data.value} {data.unit}
                </span>
              </div>
            ))}
            <div className="p-2.5 rounded-xl bg-[#232323] border border-[#D65A1F]/40">
              <span className="text-[10px] font-mono text-[#D65A1F] block">Solve for</span>
              <span className="text-xs font-bold text-[#F5F2ED] font-mono">
                {currentQ.target.name} ({currentQ.target.symbol})
              </span>
            </div>
          </div>
        </div>

        {/* Answer Selection or Input */}
        <div className="space-y-4">
          <span className="text-xs font-medium text-[#F5F2ED] block">
            Select or enter the calculated answer in {currentQ.target.unit}:
          </span>

          {/* Multiple choice chips */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {currentQ.options.map((opt) => (
              <button
                key={opt}
                disabled={isAnswered}
                onClick={() => {
                  playSound('button');
                  setSelectedOption(opt);
                  setUserAnswer(String(opt));
                }}
                className={`p-3 rounded-xl border text-center transition-all font-mono font-bold text-sm ${
                  selectedOption === opt
                    ? 'border-[#D65A1F] bg-[#232323] text-[#D65A1F] shadow-md'
                    : 'border-[#303030] bg-[#151515] text-[#A9A39C] hover:text-[#F5F2ED] hover:border-[#A9A39C]'
                }`}
              >
                {opt} <span className="text-xs text-[#A9A39C] font-normal">{currentQ.target.unit}</span>
              </button>
            ))}
          </div>

          {/* Manual numeric input alternative */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="number"
              step="any"
              disabled={isAnswered}
              value={userAnswer}
              onChange={(e) => {
                setUserAnswer(e.target.value);
                setSelectedOption(null);
              }}
              placeholder={`Or type exact numeric value (${currentQ.target.unit})...`}
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs font-mono placeholder-[#A9A39C] focus:outline-none focus:border-[#D65A1F]"
            />
            {!isAnswered ? (
              <button
                onClick={handleCheckAnswer}
                disabled={!userAnswer && selectedOption === null}
                className="px-5 py-2.5 rounded-xl bg-[#D65A1F] text-[#F5F2ED] text-xs font-bold hover:bg-[#B94717] disabled:opacity-40 transition-colors"
              >
                Check Answer
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="px-5 py-2.5 rounded-xl bg-[#232323] border border-[#303030] text-[#F5F2ED] hover:bg-[#D65A1F] hover:border-[#D65A1F] text-xs font-bold transition-colors flex items-center gap-2"
              >
                <span>Next Problem</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Hint toggle */}
        <div>
          <button
            onClick={() => {
              playSound('button');
              setShowHint(!showHint);
            }}
            className="text-xs text-[#D65A1F] hover:underline flex items-center gap-1.5 font-medium"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{showHint ? 'Hide Hint' : 'Need a Hint?'}</span>
          </button>
          {showHint && (
            <div className="mt-2 p-3 rounded-xl bg-[#151515] border border-[#303030] text-xs text-[#A9A39C] animate-in fade-in">
              {currentQ.hint}
            </div>
          )}
        </div>

        {/* Result & Detailed Step Solution (When Answered) */}
        {isAnswered && (
          <div className="pt-4 border-t border-[#303030] space-y-4 animate-in fade-in slide-in-from-top-2">
            <div
              className={`p-4 rounded-2xl border flex items-center gap-3 ${
                isCorrect
                  ? 'bg-[#72A65A]/10 border-[#72A65A]/40 text-[#72A65A]'
                  : 'bg-[#C84A3A]/10 border-[#C84A3A]/40 text-[#C84A3A]'
              }`}
            >
              {isCorrect ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 shrink-0" />
              )}
              <div>
                <span className="font-bold text-sm block">
                  {isCorrect ? 'Correct! Outstanding work.' : 'Not quite right.'}
                </span>
                <span className="text-xs opacity-90 text-[#F5F2ED]">
                  Target answer: {currentQ.correctAnswer} {currentQ.target.unit}
                </span>
              </div>
            </div>

            {/* Step-by-Step Solution Breakdown */}
            <div className="p-4 rounded-2xl bg-[#151515] border border-[#303030] space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[#F5F2ED]">
                <BookOpen className="w-4 h-4 text-[#D65A1F]" />
                <span>Verified Step-by-Step Derivation</span>
              </div>
              <div className="space-y-2 text-xs font-mono text-[#A9A39C]">
                {currentQ.steps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-md bg-[#232323] border border-[#303030] text-[#D65A1F] text-[10px] flex items-center justify-center font-bold shrink-0">
                      {idx + 1}
                    </span>
                    <span className="text-[#F5F2ED] leading-relaxed pt-0.5">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
