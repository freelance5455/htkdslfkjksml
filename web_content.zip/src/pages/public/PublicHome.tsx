import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  ShieldCheck, 
  CreditCard, 
  Truck, 
  Bot, 
  Store, 
  Check, 
  HelpCircle,
  Zap,
  Globe,
  Lock,
  ChevronDown
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { pricingPlans } from '../../data/initialData';
import { PricingPlan } from '../../types';

export const PublicHome: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, loading: authLoading } = useAuth();
  const { language, setIsAuthModalOpen, setAuthModalMode } = useApp();
  const isBn = language === 'bn';

  // Requirement 4: Authenticated user visiting "/" redirects to Merchant Dashboard
  useEffect(() => {
    if (!authLoading && currentUser) {
      navigate('/dashboard', { replace: true });
    }
  }, [authLoading, currentUser, navigate]);

  // Requirement 1: Account required before creating a store
  const handleStartStore = () => {
    if (!currentUser) {
      setAuthModalMode('register');
      setIsAuthModalOpen(true);
    } else {
      navigate('/dashboard');
    }
  };

  // ROI Calculator State
  const [monthlyOrders, setMonthlyOrders] = useState<number>(350);
  const [averageOrderValue, setAverageOrderValue] = useState<number>(1800);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  // Active FAQ accordion state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Calculations
  const estimatedRevenue = monthlyOrders * averageOrderValue;
  const traditionalAgencyCost = 180000; // 1.8 Lakh BDT setup + maintenance
  const shanjuCost = billingCycle === 'monthly' ? 500 * 12 : 5000;
  const savings = traditionalAgencyCost - shanjuCost;

  const faqs = [
    {
      qEn: 'Can I connect my own custom domain (.com, .com.bd)?',
      qBn: 'আমি কি আমার নিজস্ব কাস্টম ডোমেইন (.com, .com.bd) যুক্ত করতে পারব?',
      aEn: 'Yes! While you receive a free branded cloud subdomain immediately, you can link any custom domain (.com, .xyz, .com.bd) with automated zero-touch SSL certificate.',
      aBn: 'হ্যাঁ, অবশ্যই! আপনি সাথে সাথে একটি ফ্রি ক্লাউড সাবডোমেন পাবেন এবং চাইলে যেকোনো নিজস্ব কাস্টম ডোমেইন (.com, .com.bd) ফ্রিতে অটোমেটেড SSL সহ যুক্ত করতে পারবেন।'
    },
    {
      qEn: 'How does automated bKash and Nagad payment work?',
      qBn: 'বিকাশ ও নগদের অটোমেটেড পেমেন্ট কিভাবে কাজ করে?',
      aEn: 'Shanju supports native direct tokenized APIs as well as aggregated multi-gateway systems. Customers complete transactions securely and orders verify instantly.',
      aBn: 'Shanju সরাসরি বিকাশ ও নগদের অটোমেটেড গেটওয়ে সমর্থন করে। গ্রাহকরা যেকোনো ডিভাইস থেকে এক ক্লিকে পেমেন্ট সম্পন্ন করতে পারেন এবং অর্ডার স্বয়ংক্রিয়ভাবে ভেরিফাই হয়ে যায়।'
    },
    {
      qEn: 'How do I deliver orders with couriers like Steadfast or Pathao?',
      qBn: 'পাঠাও বা স্টিডফাস্ট কুরিয়ারে পার্সেল পাঠাব কীভাবে?',
      aEn: 'With built-in Courier API integration, click "Dispatch" on any order to instantly book pickup and print shipping labels without copying and pasting phone numbers.',
      aBn: 'আমাদের ইন্টিগ্রেটেড কুরিয়ার এপিআই ফিচারের মাধ্যমে কোনো ডাটা কপি-পেস্ট ছাড়া এক ক্লিকেই পাঠাও বা স্টিডফাস্টে বুকিং হয়ে যায় এবং থার্মাল শিপিং লেবেল প্রিন্ট করা যায়।'
    },
    {
      qEn: 'Do I need any coding or web development skills?',
      qBn: 'আমার কি কোনো কোডিং বা ওয়েব ডেভেলপমেন্টের জ্ঞান প্রয়োজন?',
      aEn: 'Zero programming knowledge is required. The entire platform is built with intuitive controls designed specifically for business owners.',
      aBn: 'কোনো প্রোগ্রামিং বা কোডিং জানার প্রয়োজন নেই। সম্পূর্ণ সিস্টেমটি সহজ ও ব্যবহারবান্ধবভাবে তৈরি যাতে যেকোনো উদ্যোক্তা মাত্র কয়েক মিনিটে নিজেই পরিচালনা করতে পারেন।'
    }
  ];

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen">
      {/* 1. Public Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 border-b border-slate-800/80">
        {/* Ambient background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-emerald-600/20 via-teal-500/15 to-blue-600/15 blur-[120px] rounded-full pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-6 shadow-sm">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>
                {isBn 
                  ? '🚀 বাংলাদেশের ১ নম্বর আধুনিক মাল্টি-টেন্যান্ট কমার্স ইঞ্জিন' 
                  : '🚀 Next-Gen Multi-Tenant Cloud Commerce OS'}
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
              {isBn ? (
                <>
                  আপনার অনলাইন ই-কমার্স স্টোর চালু করুন <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                    মাত্র ২ মিনিটে, কোডিং ছাড়া
                  </span>
                </>
              ) : (
                <>
                  Build, Sell & Scale Your E-Commerce Brand <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                    With Modern Cloud SaaS
                  </span>
                </>
              )}
            </h1>

            {/* Subtitle */}
            <p className="mt-6 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
              {isBn 
                ? 'বিকাশ, নগদ ও কার্ড পেমেন্ট গেটওয়ে, লাইভ থিম কাস্টমাইজার, পাঠাও/স্টিডফাস্ট কুরিয়ার অটোমেশন এবং এআই কমার্স সহকারীসহ সম্পূর্ণ রেডিমেড সল্যুশন।'
                : 'Complete all-in-one platform featuring ultra-fast storefronts, instant bKash/Nagad/Card checkout, visual theme options, Courier API dispatch, and AI copilot.'}
            </p>

            {/* Public CTA Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
              <button
                id="hero-create-store-wizard-btn"
                onClick={handleStartStore}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/30 transition-all transform hover:-translate-y-0.5 hover:scale-[1.02] cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>{isBn ? '🚀 আপনার ওয়েবসাইট তৈরি করুন (ফ্রি)' : '🚀 Create Your Free Store'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const el = document.getElementById('features');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-sm font-semibold transition-all cursor-pointer"
              >
                <span>{isBn ? 'ফিচারসমূহ দেখুন' : 'Explore Platform Features'}</span>
              </button>
            </div>

            {/* Trust Badges */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'কোন ক্রেডিট কার্ড লাগবে না' : 'No Credit Card Required'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? '০% প্ল্যাটফর্ম ফি (গ্রোথ প্ল্যান)' : '0% Platform Fee on Growth'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'বিকাশ ও নগদ অটোমেটেড পেমেন্ট' : 'Native bKash & Nagad Integration'}</span>
              </div>
            </div>
          </div>

          {/* Platform Live Stats Bar */}
          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">৳৪৫০M+</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'মোট প্রসেসড সেলস' : 'Total GMV Processed'}</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-white">১২,৫০০+</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'সক্রিয় উদ্যোক্তা ও মার্চেন্ট' : 'Active Merchants'}</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-cyan-400">০.৫ সেকেন্ড</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'দ্রুততম মোবাইল পেজ লোড' : 'Sub-Second Edge Load'}</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">৯৯.৯৯%</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'ক্লাউড আপটাইম গ্যারান্টি' : 'Cloud SLA Uptime'}</div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. How It Works Section */}
      <section id="how-it-works" className="py-20 bg-slate-900/70 border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/20 mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isBn ? 'সহজ ৩টি ধাপ' : 'Easy 3 Steps'}</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              {isBn 
                ? 'মাত্র ৩ মিনিটে কীভাবে আপনার স্টোর লাইভ করবেন?' 
                : 'How to Launch Your Store in Under 3 Minutes?'}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed">
              {isBn 
                ? 'কোনো প্রযুক্তিগত জ্ঞান ছাড়াই খুব সহজে আপনার ব্র্যান্ডের ই-কমার্স যাত্রা শুরু করুন।' 
                : 'Launch a fully isolated e-commerce website with dedicated inventory and payment processing.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-xl">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-black text-lg flex items-center justify-center mb-4">
                  ০১
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {isBn ? '১. স্টোরের নাম ও সাবডোমেন দিন' : '1. Store Name & Subdomain'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isBn 
                    ? 'আপনার ব্যবসার নাম লিখলেই সাথে সাথে পেয়ে যাবেন একটি ফ্রি ক্লাউড সাবডোমেন (যেমন: brand.shanju.cloud) এবং ফ্রি SSL সিকিউরিটি।' 
                    : 'Instantly claim your branded cloud subdomain with high-speed CDN and automated SSL.'}
                </p>
              </div>

              <div className="mt-6 p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-emerald-400 flex items-center justify-between">
                <span>brand.shanju.cloud</span>
                <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded">✓ Free SSL</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-xl">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-black text-lg flex items-center justify-center mb-4">
                  ০২
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {isBn ? '২. ব্র্যান্ডের রঙ ও থিম সাজান' : '2. Customize Theme & Style'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isBn 
                    ? 'ব্র্যান্ড কালার, নোটিফিকেশন বার, হিরো ব্যানার ও লোগো যুক্ত করে স্টোরফ্রন্টকে আকর্ষণীয় করে তুলুন।' 
                    : 'Pick brand colors, announcement banners, typography, and responsive hero banners.'}
                </p>
              </div>

              <div className="mt-6 flex items-center gap-2 p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="w-4 h-4 rounded-full bg-emerald-500"></span>
                <span className="w-4 h-4 rounded-full bg-blue-600"></span>
                <span className="w-4 h-4 rounded-full bg-rose-500"></span>
                <span className="w-4 h-4 rounded-full bg-amber-500"></span>
                <span className="text-[11px] text-slate-400 ml-auto font-medium">{isBn ? 'স্মার্ট থিম' : 'Modern themes'}</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-xl">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-purple-400 font-black text-lg flex items-center justify-center mb-4">
                  ০৩
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {isBn ? '৩. পণ্য আপলোড ও পেমেন্ট রিসিভ' : '3. Add Products & Sell'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isBn 
                    ? 'সহজেই পণ্য আপলোড করুন। বিকাশ, নগদ, কার্ড কিংবা ক্যাশ অন ডেলিভারিতে তাৎক্ষণিক পেমেন্ট গ্রহণ করুন।' 
                    : 'Upload products and accept payments via bKash, Nagad, Visa, Mastercard, or COD.'}
                </p>
              </div>

              <div className="mt-6 flex items-center gap-2 text-[10px] font-bold text-slate-300">
                <span className="px-2 py-1 bg-pink-600/30 text-pink-300 border border-pink-500/40 rounded-lg">bKash</span>
                <span className="px-2 py-1 bg-orange-600/30 text-orange-300 border border-orange-500/40 rounded-lg">Nagad</span>
                <span className="px-2 py-1 bg-slate-800 text-slate-300 border border-slate-700 rounded-lg">COD</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Public Features Section */}
      <section id="features" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            {isBn ? 'শক্তিশালী ফিচার যা আপনার ব্যবসাকে বড় করবে' : 'Enterprise Engine Built for Modern D2C Brands'}
          </h2>
          <p className="mt-3 text-sm text-slate-400">
            {isBn 
              ? 'স্টোরফ্রন্ট ডিজাইন থেকে শুরু করে পেমেন্ট রিসিভ ও কুরিয়ার ট্র্যাকিং — সব সমন্বিত।'
              : 'Replace multiple fragmented tools with one robust cloud commerce engine.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Feature 1 */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 hover:border-emerald-500/40 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-4">
              <Store className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">
              {isBn ? 'রেসপনসিভ স্টোরফ্রন্ট' : 'Fast Mobile Storefront'}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn 
                ? 'মোবাইল ফ্রেন্ডলি আল্ট্রা-ফাস্ট ডিজাইন যা যেকোনো ডিভাইসে বিদ্যুৎ গতিতে লোড হয়।' 
                : 'Sub-second page speeds optimized for mobile social media traffic and high conversion.'}
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 hover:border-emerald-500/40 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-4">
              <CreditCard className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">
              {isBn ? 'ইনস্ট্যান্ট বিকাশ ও নগদ' : 'Instant bKash & Nagad'}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn 
                ? 'বিকাশ, নগদ, ভিসা, মাস্টারকার্ড ও ক্যাশ অন ডেলিভারিতে ঝামেলাহীন পেমেন্ট।' 
                : 'Frictionless checkout with 1-click bKash direct payment, Nagad, and Card gateway.'}
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 hover:border-emerald-500/40 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-4">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">
              {isBn ? 'কুরিয়ার অটোমেশন' : 'Courier API Integration'}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn 
                ? 'পাঠাও ও স্টিডফাস্ট কুরিয়ারে এক ক্লিকে পার্সেল বুকিং ও অটো ট্র্যাকিং।' 
                : 'Generate consignments with Pathao Courier and Steadfast with automated label printing.'}
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 hover:border-emerald-500/40 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-4">
              <Bot className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">
              {isBn ? 'এআই প্রোডাক্ট কপাইলট' : 'AI Commerce Assistant'}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn 
                ? 'আকর্ষণীয় প্রোডাক্ট বিবরণী ও সোশ্যাল অ্যাড কপি তৈরি করুন এআই দিয়ে মুহূর্তেই।' 
                : 'Generate persuasive product descriptions and captions in seconds using Gemini AI.'}
            </p>
          </div>
        </div>
      </section>

      {/* 4. ROI Savings Calculator Section */}
      <section id="calculator" className="py-20 bg-slate-900/50 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
                  <TrendingUp className="w-3.5 h-3.5" />
                  {isBn ? 'সাশ্রয় ক্যালকুলেটর' : 'ROI Calculator'}
                </div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                  {isBn ? 'দেখুন Shanju ব্যবহারে আপনার কত টাকা বাঁচবে' : 'Calculate Your Monthly Cost Savings'}
                </h3>
                <p className="mt-2 text-sm text-slate-400">
                  {isBn 
                    ? 'কাস্টম সফটওয়্যার এজেন্সি বা আলাদা প্লাগিনের খরচের চেয়ে ৮০% কম খরচে সবকিছু পাবেন।'
                    : 'Compare traditional agency and plugin maintenance costs versus an all-in-one SaaS.'}
                </p>

                {/* Sliders */}
                <div className="mt-6 space-y-6">
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-300 mb-2">
                      <span>{isBn ? 'মাসিক আনুমানিক অর্ডার সংখ্যা:' : 'Estimated Monthly Orders:'}</span>
                      <span className="text-emerald-400 font-bold text-sm">{monthlyOrders.toLocaleString()} Orders</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="5000"
                      step="50"
                      value={monthlyOrders}
                      onChange={(e) => setMonthlyOrders(Number(e.target.value))}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-300 mb-2">
                      <span>{isBn ? 'গড় অর্ডার মূল্য (AOV):' : 'Average Order Value (AOV):'}</span>
                      <span className="text-emerald-400 font-bold text-sm">৳{averageOrderValue.toLocaleString()}</span>
                    </div>
                    <input
                      type="range"
                      min="500"
                      max="10000"
                      step="100"
                      value={averageOrderValue}
                      onChange={(e) => setAverageOrderValue(Number(e.target.value))}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Calculations Card */}
              <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-2xl p-6">
                <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                  {isBn ? 'মাসিক আনুমানিক বিক্রয়' : 'Projected Monthly Sales'}
                </div>
                <div className="text-3xl font-black text-white mt-1">
                  ৳{estimatedRevenue.toLocaleString()}
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800 space-y-3 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span>{isBn ? 'কাস্টম এজেন্সি/হোস্টিং খরচ:' : 'Custom Agency/Hosting Cost:'}</span>
                    <span className="font-semibold line-through text-slate-500">৳১,৮০,০০০/বছর</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Shanju Growth Plan:</span>
                    <span className="font-bold text-emerald-400">৳{shanjuCost.toLocaleString()}/বছর</span>
                  </div>
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
                    <span className="text-xs font-semibold text-emerald-400 block">
                      {isBn ? 'আপনার আনুমানিক বার্ষিক সাশ্রয়:' : 'Your Estimated Annual Savings:'}
                    </span>
                    <span className="text-2xl font-black text-white">৳{savings.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  onClick={handleStartStore}
                  className="w-full mt-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
                >
                  {isBn ? 'বিনামূল্যে স্টোর তৈরি শুরু করুন' : 'Start Your Free Store'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Public Pricing Section */}
      <section id="pricing" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl font-extrabold text-white">
            {isBn ? 'স্বচ্ছ ও সহজ মূল্য তালিকা' : 'Transparent, Scalable SaaS Plans'}
          </h2>
          <p className="mt-3 text-sm text-slate-400">
            {isBn 
              ? 'কোনো লুকানো চার্জ নেই। যেকোনো সময় আপগ্রেড বা বাতিল করার পূর্ণ স্বাধীনতা।'
              : 'Choose the plan that fits your business. Upgrade seamlessly as your orders surge.'}
          </p>

          {/* Monthly / Yearly Toggle */}
          <div className="mt-6 inline-flex items-center gap-2 p-1 rounded-xl bg-slate-800 border border-slate-700">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                billingCycle === 'monthly' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isBn ? 'মাসিক বিলিং' : 'Monthly'}
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                billingCycle === 'yearly' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>{isBn ? 'বার্ষিক বিলিং' : 'Yearly'}</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-bold">
                {isBn ? '২০% ছাড়' : '20% OFF'}
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {pricingPlans.map((plan: PricingPlan) => {
            const price = billingCycle === 'monthly' ? plan.priceMonthly : Math.round(plan.priceYearly / 12);

            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all ${
                  plan.popular
                    ? 'bg-slate-900 border-2 border-emerald-500 shadow-2xl shadow-emerald-500/10 scale-100 md:-translate-y-2'
                    : 'bg-slate-950 border border-slate-800'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black text-[11px] uppercase tracking-wider shadow">
                    {isBn ? 'সর্বাধিক জনপ্রিয়' : 'Most Popular'}
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white">
                      {isBn ? plan.nameBn : plan.name}
                    </h3>
                    <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                      {plan.limits.stores} {plan.limits.stores === 1 ? 'Store' : 'Stores'}
                    </span>
                  </div>

                  <p className="mt-2 text-xs text-slate-400 min-h-[36px]">
                    {isBn ? plan.taglineBn : plan.tagline}
                  </p>

                  <div className="mt-6 flex items-baseline gap-1.5">
                    <span className="text-4xl font-black text-white">
                      {price === 0 ? (isBn ? 'ফ্রি' : 'Free') : `৳${price.toLocaleString()}`}
                    </span>
                    <span className="text-xs text-slate-400">
                      {price === 0 ? (isBn ? '(১ মাস ফ্রি ট্রায়াল)' : '(1 Mo Trial)') : `/${isBn ? 'মাস' : 'month'}`}
                    </span>
                  </div>

                  <div className="mt-8 pt-6 border-t border-slate-800 space-y-3">
                    {(isBn ? plan.featuresBn : plan.features).map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 pt-4">
                  <button
                    onClick={handleStartStore}
                    className={`w-full py-3 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                      plan.popular
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
                        : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                    }`}
                  >
                    {isBn ? 'এই প্ল্যানে শুরু করুন' : 'Get Started'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. Customer Testimonials Section */}
      <section id="testimonials" className="py-20 bg-slate-900/60 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">
              {isBn ? 'সফল উদ্যোক্তাদের বাস্তব অভিজ্ঞতা' : 'Trusted by Growing D2C Brands'}
            </h2>
            <p className="mt-2 text-sm text-slate-400">
              {isBn ? 'Shanju এর ক্লাউড ইঞ্জিনে প্রতিদিন লাখ লাখ টাকার অর্ডার প্রসেস হচ্ছে।' : 'Hear from merchant founders expanding their online businesses.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1 text-amber-400 mb-3">★★★★★</div>
              <p className="text-xs text-slate-300 italic leading-relaxed">
                &quot;আগে ফেসবুক পেজে মেসেজ নিয়ে অর্ডার করতে গিয়ে অনেক কাস্টমার ড্রপ হত। Shanju এ আসার পর বিকাশ অটোমেটেড চেকআউটের মাধ্যমে আমাদের সেলস ৩ গুণ বৃদ্ধি পেয়েছে!&quot;
              </p>
              <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-xs text-white">
                  আর
                </div>
                <div>
                  <div className="text-xs font-bold text-white">রফিকুল ইসলাম</div>
                  <div className="text-[11px] text-slate-400">Founder, Aura Lifestyle BD</div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1 text-amber-400 mb-3">★★★★★</div>
              <p className="text-xs text-slate-300 italic leading-relaxed">
                &quot;The one-click Courier API dispatch is an absolute lifesaver. We pack 200+ gadget orders a day and generate Steadfast labels in 30 seconds.&quot;
              </p>
              <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center font-bold text-xs text-white">
                  SK
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Siam Khan</div>
                  <div className="text-[11px] text-slate-400">CEO, TechVerse Gadgets</div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1 text-amber-400 mb-3">★★★★★</div>
              <p className="text-xs text-slate-300 italic leading-relaxed">
                &quot;AI ডেসক্রিপশন জেনারেটর দিয়ে আমাদের পণ্যের ফিচার মুহূর্তেই সুন্দর বাংলায় ফুটিয়ে তোলা যায়। কাস্টমারদের আস্থা অনেক বেড়েছে।&quot;
              </p>
              <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-teal-600 flex items-center justify-center font-bold text-xs text-white">
                  এন
                </div>
                <div>
                  <div className="text-xs font-bold text-white">নুসরাত পারভীন</div>
                  <div className="text-[11px] text-slate-400">Co-Founder, Green Basket Organics</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Public FAQ Section */}
      <section id="faq" className="py-20 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{isBn ? 'সাধারণ প্রশ্নোত্তর' : 'Frequently Asked Questions'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            {isBn ? 'আপনার মনে থাকা প্রশ্নের উত্তর' : 'Everything You Need to Know'}
          </h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div 
                key={index} 
                className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : index)}
                  className="w-full p-5 text-left flex items-center justify-between text-sm font-bold text-white hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  <span>{isBn ? faq.qBn : faq.qEn}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-emerald-400' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-slate-300 leading-relaxed border-t border-slate-800/60 pt-3">
                    {isBn ? faq.aBn : faq.aEn}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 8. Public Final Call to Action */}
      <section className="py-16 bg-gradient-to-b from-slate-900 to-slate-950 border-t border-slate-800 text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            {isBn ? 'আপনার স্বপ্নের ই-কমার্স ব্যবসা আজই শুরু করুন' : 'Start Your Dream E-Commerce Business Today'}
          </h2>
          <p className="mt-3 text-sm text-slate-300 max-w-xl mx-auto">
            {isBn 
              ? 'কোনো ক্রেডিট কার্ড লাগবে না। মাত্র ৩টি সহজ ধাপে সম্পূর্ণ লাইভ ওয়েবসাইট পেয়ে যান।'
              : 'Zero setup fees, no technical setup required. Claim your free subdomain and start selling in 3 minutes.'}
          </p>
          <div className="mt-8 flex items-center justify-center">
            <button
              onClick={handleStartStore}
              className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/25 transition-transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>{isBn ? 'ফ্রি ওয়েবসাইট তৈরি করুন 🚀' : 'Create Your Free Website 🚀'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 9. Public Footer */}
      <footer className="bg-slate-950 border-t border-slate-800/80 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-950 font-bold">
                <Store className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-lg text-white">Shanju</span>
              <span className="text-xs text-slate-500">© 2026 SaaS Cloud Commerce</span>
            </div>

            <div className="flex items-center gap-6 text-xs text-slate-400">
              <span>PCI-DSS Compliant</span>
              <span className="text-slate-700">•</span>
              <span>256-Bit SSL Encrypted</span>
              <span className="text-slate-700">•</span>
              <button 
                onClick={() => {
                  setAuthModalMode('login');
                  setIsAuthModalOpen(true);
                }}
                className="hover:text-emerald-400 cursor-pointer"
              >
                {isBn ? 'মার্চেন্ট লগইন' : 'Merchant Sign In'}
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
