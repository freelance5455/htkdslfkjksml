import React from 'react';
import { useNavigate } from 'react-router-dom';
import { LiveStorefront } from '../../components/storefront/LiveStorefront';
import { useApp } from '../../context/AppContext';

export const StorefrontPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    activeStore,
    products,
    language,
    cart,
    isCartOpen,
    setIsCartOpen,
    shippingSettings,
    handleAddToCart,
    handleUpdateCartQuantity,
    handleClearCart,
    handleCreateOrder,
    handleSaveAbandonedCheckout
  } = useApp();

  return (
    <div className="w-full">
      <LiveStorefront
        activeStore={activeStore}
        products={products}
        language={language}
        cart={cart}
        isCartOpen={isCartOpen}
        shippingSettings={shippingSettings}
        onCloseCart={() => setIsCartOpen(false)}
        onAddToCart={handleAddToCart}
        onUpdateCartQuantity={handleUpdateCartQuantity}
        onClearCart={handleClearCart}
        onCreateOrder={handleCreateOrder}
        onSaveAbandonedCheckout={handleSaveAbandonedCheckout}
        onBackToDashboard={() => navigate('/dashboard')}
      />
    </div>
  );
};
