import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Store as StoreIcon, 
  Lock, 
  Sparkles, 
  PlusCircle, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { MerchantDashboard } from '../../components/dashboard/MerchantDashboard';
import { CreateStoreWizardModal } from '../../components/modals/CreateStoreWizardModal';
import { AuthModal } from '../../components/modals/AuthModal';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';

export const MerchantDashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, userProfile, loading: authLoading, logout } = useAuth();
  const {
    stores,
    activeStore,
    setActiveStoreId,
    products,
    orders,
    customers,
    draftOrders,
    abandonedCheckouts,
    returnsRefunds,
    shippingSettings,
    collections,
    language,
    setLanguage,
    paymentGateways,
    isAuthModalOpen,
    setIsAuthModalOpen,
    authModalMode,
    setAuthModalMode,
    isCreateStoreWizardOpen,
    setIsCreateStoreWizardOpen,
    handleWizardStoreCreated,
    handleAddProduct,
    handleUpdateProduct,
    handleDeleteProduct,
    handleAddCollection,
    handleUpdateCollection,
    handleDeleteCollection,
    handleUpdateOrderStatus,
    handleUpdatePaymentStatus,
    handleUpdateOrderNotes,
    handleBulkUpdateOrderStatus,
    handleSaveDraftOrder,
    handleDeleteDraftOrder,
    handleConvertDraftToOrder,
    handleSaveAbandonedCheckout,
    handleUpdateAbandonedCheckoutStatus,
    handleSaveReturnRefund,
    handleUpdateReturnRefundStatus,
    handleSaveShippingSettings,
    handleCreateOrder,
    handleUpdateStoreTheme,
    handleUpdateStorePlan,
    handleAddSubscriptionPayment,
  } = useApp();

  const isBn = language === 'bn';

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  // 1. Loading State: Wait for Firebase Auth to confirm state (Avoid premature redirects)
  if (authLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#f6f6f7] text-slate-800">
        <div className="w-12 h-12 border-4 border-slate-300 border-t-emerald-600 rounded-full animate-spin mb-4" />
        <p className="text-xs text-slate-600 font-bold uppercase tracking-wider animate-pulse">
          {isBn ? 'অথেনটিকেশন যাচাই করা হচ্ছে...' : 'Verifying merchant authentication...'}
        </p>
      </div>
    );
  }

  // 2. Logged-out User: DO NOT show Dashboard. Prompt login/signup flow
  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-[#f6f6f7]">
        <div className="max-w-md w-full bg-white border border-slate-200/90 rounded-3xl p-8 sm:p-10 text-center shadow-xl relative overflow-hidden">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto mb-5 shadow-xs">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 mb-2 tracking-tight">
            {isBn ? 'মার্চেন্ট অ্যাডমিন লগইন' : 'Merchant Admin Sign In'}
          </h2>
          <p className="text-xs text-slate-500 mb-8 leading-relaxed">
            {isBn 
              ? 'ড্যাশবোর্ড অ্যাক্সেস এবং অনলাইন স্টোর পরিচালনার জন্য অনুগ্রহ করে সাইন-ইন করুন অথবা নতুন মার্চেন্ট একাউন্ট তৈরি করুন।' 
              : 'Please sign in or create an account to access the Merchant Console and manage your online business.'}
          </p>

          <div className="flex flex-col gap-3">
            <button
              onClick={() => {
                setAuthModalMode('login');
                setIsAuthModalOpen(true);
              }}
              className="w-full py-3.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer transform hover:scale-[1.01]"
            >
              {isBn ? 'লগইন করুন' : 'Sign In'}
            </button>
            <button
              onClick={() => {
                setAuthModalMode('register');
                setIsAuthModalOpen(true);
              }}
              className="w-full py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-bold transition-all cursor-pointer"
            >
              {isBn ? 'নতুন মার্চেন্ট একাউন্ট তৈরি করুন' : 'Create Merchant Account'}
            </button>
            <Link
              to="/"
              className="mt-3 text-xs font-semibold text-slate-400 hover:text-emerald-600 transition-colors"
            >
              ← {isBn ? 'পাবলিক হোমপেজে ফিরুন' : 'Back to Public Home'}
            </Link>
          </div>
        </div>

        {/* Auth Modal */}
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          language={language}
          initialMode={authModalMode}
          onSuccess={() => {
            setIsAuthModalOpen(false);
          }}
        />
      </div>
    );
  }

  // 3. Authenticated User WITHOUT a Store: Show "Create Store" flow
  const userStores = stores.filter(s => s.ownerId === currentUser.uid);
  const isSuperAdmin = userProfile?.role === 'SUPER_ADMIN';
  const hasStore = userStores.length > 0 || isSuperAdmin;

  if (!hasStore) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-[#f6f6f7]">
        <div className="max-w-lg w-full bg-white border border-slate-200/90 rounded-3xl p-8 sm:p-10 text-center shadow-xl relative overflow-hidden">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center mx-auto mb-6 shadow-md shadow-emerald-500/20">
            <StoreIcon className="w-8 h-8 text-slate-950" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isBn ? 'মার্চেন্ট অনবোর্ডিং' : 'Merchant Onboarding'}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mb-3 tracking-tight">
            {isBn ? 'আপনার প্রথম অনলাইন স্টোর তৈরি করুন' : 'Launch Your First Online Store'}
          </h2>

          <p className="text-xs text-slate-500 mb-8 leading-relaxed max-w-md mx-auto">
            {isBn 
              ? 'স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টে বর্তমানে কোনো সক্রিয় অনলাইন স্টোর নেই। মাত্র ২ মিনিটে আপনার স্টোরের নাম, ক্যাটাগরি এবং থিম নির্ধারণ করে ব্যবসা শুরু করুন।' 
              : 'Welcome! You currently do not have an active online store. Set up your store name, business category, and visual theme in just 2 minutes.'}
          </p>

          <button
            onClick={() => setIsCreateStoreWizardOpen(true)}
            className="w-full flex items-center justify-center gap-2.5 py-4 px-6 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-black text-sm shadow-lg transition-all transform hover:scale-[1.02] cursor-pointer"
          >
            <PlusCircle className="w-5 h-5 text-emerald-400" />
            <span>{isBn ? 'স্টোর তৈরি করুন' : 'Create Store Now'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Store Creation Modal */}
        <CreateStoreWizardModal
          isOpen={isCreateStoreWizardOpen}
          onClose={() => setIsCreateStoreWizardOpen(false)}
          language={language}
          onStoreCreated={handleWizardStoreCreated}
          onViewStorefront={() => {
            setIsCreateStoreWizardOpen(false);
            navigate('/storefront');
          }}
        />
      </div>
    );
  }

  // 4. Authenticated User WITH a Store: Full Modern Redesigned Merchant Dashboard
  return (
    <div className="w-full">
      <MerchantDashboard
        activeStore={activeStore}
        stores={stores}
        onSelectStore={(id) => setActiveStoreId(id)}
        products={products}
        orders={orders}
        customers={customers}
        draftOrders={draftOrders}
        abandonedCheckouts={abandonedCheckouts}
        returnsRefunds={returnsRefunds}
        shippingSettings={shippingSettings}
        language={language}
        gateways={paymentGateways}
        onToggleLanguage={() => setLanguage(language === 'en' ? 'bn' : 'en')}
        onOpenStorefront={() => navigate('/storefront')}
        onAddProduct={handleAddProduct}
        onUpdateProduct={handleUpdateProduct}
        onDeleteProduct={handleDeleteProduct}
        collections={Array.isArray(collections) ? collections : []}
        onAddCollection={handleAddCollection}
        onUpdateCollection={handleUpdateCollection}
        onDeleteCollection={handleDeleteCollection}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        onUpdatePaymentStatus={handleUpdatePaymentStatus}
        onUpdateOrderNotes={handleUpdateOrderNotes}
        onBulkUpdateOrderStatus={handleBulkUpdateOrderStatus}
        onCreateOrder={handleCreateOrder}
        onSaveDraftOrder={handleSaveDraftOrder}
        onDeleteDraftOrder={handleDeleteDraftOrder}
        onConvertDraftToOrder={handleConvertDraftToOrder}
        onSaveAbandonedCheckout={handleSaveAbandonedCheckout}
        onUpdateAbandonedCheckoutStatus={handleUpdateAbandonedCheckoutStatus}
        onSaveReturnRefund={handleSaveReturnRefund}
        onUpdateReturnRefundStatus={handleUpdateReturnRefundStatus}
        onSaveShippingSettings={handleSaveShippingSettings}
        onUpdateStoreTheme={handleUpdateStoreTheme}
        onUpdateStorePlan={handleUpdateStorePlan}
        onAddSubscriptionPayment={handleAddSubscriptionPayment}
        onLogout={handleLogout}
        userEmail={currentUser.email || undefined}
        userName={userProfile?.displayName || currentUser.displayName || undefined}
      />

      {/* Store Creation Wizard Modal */}
      <CreateStoreWizardModal
        isOpen={isCreateStoreWizardOpen}
        onClose={() => setIsCreateStoreWizardOpen(false)}
        language={language}
        onStoreCreated={handleWizardStoreCreated}
        onViewStorefront={() => {
          setIsCreateStoreWizardOpen(false);
          navigate('/storefront');
        }}
      />
    </div>
  );
};
