import React, { useState } from 'react';
import { submitFeedback } from '../firebase/services';
import { useApp } from '../context/AppContext';
import { MessageSquare, Star, Send, CheckCircle2, RotateCcw } from 'lucide-react';

export const FeedbackPage: React.FC = () => {
  const { showToast, playSound, triggerHaptic } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('New Equation Request');
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(5);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
      showToast('Please enter your feedback or equation request', 'error');
      return;
    }

    setSubmitting(true);
    try {
      await submitFeedback({
        name: name.trim() || 'Engineering Student',
        email: email.trim() || 'formula@formulax.pro',
        message: `[${category}] ${message.trim()}`,
        rating
      });
      playSound('correct');
      triggerHaptic('success');
      setSubmitted(true);
      showToast('Thank you! Formula request logged.');
    } catch {
      // Offline fallback: save to localStorage
      try {
        const saved = JSON.parse(localStorage.getItem('formulax_local_feedback') || '[]');
        saved.push({ name, email, category, message, rating, date: Date.now() });
        localStorage.setItem('formulax_local_feedback', JSON.stringify(saved));
      } catch {}
      playSound('correct');
      setSubmitted(true);
      showToast('Saved locally. Thank you for your feedback!');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 pb-16">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <MessageSquare className="w-5 h-5 text-[#D65A1F]" />
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            Formula Requests & Suggestions
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-[#A9A39C]">
          Request equations, report corrections, or suggest improvements to the physics and mathematics engine.
        </p>
      </div>

      {submitted ? (
        <div className="p-8 sm:p-12 rounded-3xl border border-[#303030] bg-[#1C1C1C] text-center space-y-4 shadow-xl">
          <CheckCircle2 className="w-12 h-12 text-[#72A65A] mx-auto" />
          <h3 className="text-xl font-bold text-[#F5F2ED]">Request Received!</h3>
          <p className="text-xs text-[#A9A39C] max-w-md mx-auto leading-relaxed">
            Thank you for contributing to FormulaX Pro. Your suggestion has been recorded into the equations review backlog.
          </p>
          <button
            onClick={() => {
              setMessage('');
              setSubmitted(false);
            }}
            className="px-5 py-2.5 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-xs transition-colors"
          >
            Submit Another Request
          </button>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-6 sm:p-8 space-y-5 shadow-2xl"
        >
          <div className="space-y-1.5">
            <label className="text-xs font-mono font-semibold uppercase tracking-wider text-[#A9A39C] block">
              Topic / Feedback Type
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs font-mono focus:outline-none focus:border-[#D65A1F]"
            >
              <option value="New Equation Request">New Equation Request</option>
              <option value="Formula Correction / Typo">Formula Correction / Typo</option>
              <option value="Calculator Engine Feature">Calculator Engine Feature</option>
              <option value="Unit Converter Suggestion">Unit Converter Suggestion</option>
              <option value="General Feedback">General Feedback</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-semibold uppercase tracking-wider text-[#A9A39C] block">
                Your Name (Optional)
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Alex (Mechanical Engineering)"
                className="w-full px-4 py-2.5 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs placeholder-[#A9A39C] focus:outline-none focus:border-[#D65A1F]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono font-semibold uppercase tracking-wider text-[#A9A39C] block">
                Email Address (Optional)
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="For equation verification updates"
                className="w-full px-4 py-2.5 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs placeholder-[#A9A39C] focus:outline-none focus:border-[#D65A1F]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-mono font-semibold uppercase tracking-wider text-[#A9A39C] block">
              Message or Equation Details *
            </label>
            <textarea
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Specify formula symbols, variables, expected units, or feature feedback..."
              required
              className="w-full px-4 py-3 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs placeholder-[#A9A39C] focus:outline-none focus:border-[#D65A1F] leading-relaxed resize-none"
            />
          </div>

          {/* Rating */}
          <div className="space-y-1.5">
            <label className="text-xs font-mono font-semibold uppercase tracking-wider text-[#A9A39C] block">
              Platform Rating
            </label>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onClick={() => {
                    playSound('button');
                    setRating(star);
                  }}
                  className="p-1 text-[#D65A1F] hover:scale-110 transition-transform"
                >
                  <Star
                    className="w-5 h-5"
                    fill={star <= rating ? '#D65A1F' : 'none'}
                    stroke="#D65A1F"
                  />
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 rounded-2xl bg-[#D65A1F] hover:bg-[#B94717] disabled:opacity-50 text-[#F5F2ED] font-bold text-xs transition-all shadow-md active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{submitting ? 'Submitting...' : 'Send Formula Request'}</span>
          </button>
        </form>
      )}
    </div>
  );
};
