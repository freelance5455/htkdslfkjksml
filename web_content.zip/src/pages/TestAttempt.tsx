import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { GlassCard } from '../components/ui/GlassCard';
import { AnimatedButton } from '../components/ui/AnimatedButton';
import { AnswerGrid } from '../components/ui/AnswerGrid';
import { parseCSV, generateMockCSV } from '../lib/csv';
import { calculateScore } from '../lib/scoring';
import { AnswerOption, TestAttempt } from '../types';
import { Upload, Play, CalendarDays, Sparkles, ChevronLeft } from 'lucide-react';
import { motion } from 'motion/react';

export const TestAttemptPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { folders, addAttempt } = useStore();
  const folder = folders.find(f => f.id === id);

  const [studentAnswers, setStudentAnswers] = useState<Record<number, AnswerOption>>({});
  const [metadata, setMetadata] = useState<{ date: number; dayStr: string; monthStr: string } | null>(null);

  useEffect(() => {
    if (!folder || !folder.hasAnswerKey) {
      navigate('/');
    }
  }, [folder, navigate]);

  if (!folder) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    captureMetadata();
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setStudentAnswers(parseCSV(text));
    };
    reader.readAsText(file);
  };

  const loadMockData = () => {
    captureMetadata();
    const mock = generateMockCSV(Date.now() + 100); // offset seed for student
    setStudentAnswers(parseCSV(mock));
  };

  const captureMetadata = () => {
    const date = new Date();
    setMetadata({
      date: date.getDate(),
      dayStr: date.toLocaleDateString('en-US', { weekday: 'long' }),
      monthStr: date.toLocaleDateString('en-US', { month: 'long' })
    });
  };

  const handleGenerateAnalysis = () => {
    if (!metadata) return;

    const results = calculateScore(studentAnswers, folder.answerKey);
    
    const attemptId = Date.now().toString();
    const newAttempt: TestAttempt = {
      id: attemptId,
      testId: folder.id,
      timestamp: Date.now(),
      dateStr: metadata.date.toString(),
      dayStr: metadata.dayStr,
      monthStr: metadata.monthStr,
      studentAnswers,
      ...results
    };

    addAttempt(newAttempt);
    navigate(`/analysis/${attemptId}`);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <button onClick={() => navigate('/')} className="flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors text-sm font-medium">
        <ChevronLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      <GlassCard className="border-indigo-100 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -mr-20 -mt-20"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h2 className="text-3xl font-bold text-slate-800 tracking-tight">{folder.instituteName} - Test {folder.testNo}</h2>
            <p className="text-slate-500 mt-2 max-w-xl">Upload your OMR CSV file below. We will render it immediately for you to cross-verify against your physical sheet.</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
             <AnimatedButton variant="secondary" icon={Play} onClick={loadMockData}>
                Mock OMR
              </AnimatedButton>
              <div className="relative flex-1 sm:flex-none">
                <input 
                  type="file" 
                  accept=".csv" 
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <AnimatedButton icon={Upload} className="w-full pointer-events-none">
                  Upload CSV
                </AnimatedButton>
              </div>
          </div>
        </div>

        {metadata && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="mt-8 pt-6 border-t border-slate-100 flex items-center gap-4 text-indigo-700"
          >
            <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center border border-indigo-100">
              <CalendarDays className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-indigo-400">Metadata Captured</p>
              <p className="font-medium">{metadata.dayStr}, {metadata.date} {metadata.monthStr}</p>
            </div>
          </motion.div>
        )}
      </GlassCard>

      {Object.keys(studentAnswers).length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <GlassCard className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-100">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-emerald-800 font-medium text-center sm:text-left">
                OMR data loaded successfully. Tap any cell to correct scanning errors.
              </p>
              <AnimatedButton icon={Sparkles} onClick={handleGenerateAnalysis} className="bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 w-full sm:w-auto">
                Generate Analysis
              </AnimatedButton>
            </div>
          </GlassCard>
          
          <GlassCard>
            <AnswerGrid 
              answers={studentAnswers} 
              onChange={(q, ans) => setStudentAnswers(prev => ({ ...prev, [q]: ans }))}
            />
          </GlassCard>
        </motion.div>
      )}
    </div>
  );
};
