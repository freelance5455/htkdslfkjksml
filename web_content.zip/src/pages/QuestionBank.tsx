import { useMemo, useState } from 'react';
import { ArrowUpLeft, BookOpenCheck, Search, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { Chip } from '../components/ui/Card';
import { subjects } from '../data/content';
import { CURRICULUM_COVERAGE, CURRICULUM_SOURCES, CURRICULUM_UNITS } from '../data/curriculum/units';
import { KEYS, useStored } from '../services/storage';
import type { CurriculumPracticeAttempt } from '../types';

export default function QuestionBank() {
  const [subjectId, setSubjectId] = useState('all');
  const [query, setQuery] = useState('');
  const attempts = useStored(KEYS.practiceAttempts, [] as CurriculumPracticeAttempt[]);
  const totalQuestions = CURRICULUM_UNITS.reduce((total, unit) => total + unit.questionCount, 0);
  const questionCountByUnit = useMemo(() => {
    const counts = new Map<string, number>();
    for (const attempt of attempts) counts.set(attempt.unitId, (counts.get(attempt.unitId) ?? 0) + 1);
    return counts;
  }, [attempts]);
  const filteredUnits = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return CURRICULUM_UNITS.filter((unit) => {
      const subject = subjects.find((item) => item.id === unit.subjectId);
      const matchesSubject = subjectId === 'all' || unit.subjectId === subjectId;
      const matchesQuery = !needle || `${unit.title} ${subject?.name ?? ''} ${unit.lessonTitles.join(' ')}`.toLocaleLowerCase().includes(needle);
      return matchesSubject && matchesQuery;
    });
  }, [subjectId, query]);

  return (
    <div>
      <PageHeader
        eyebrow="تدريب مرتبط بكتب المركز الوطني"
        title="بنك أسئلة المنهاج"
        subtitle="أسئلة جديدة موزعة على المواد والوحدات، مع مرجع لكل سؤال. هذه أسئلة تدريبية مستوحاة من الكتاب وليست نصوصاً وزارية منقولة."
      />

      <section className="card mb-4 flex items-center gap-3 bg-[var(--surface)] p-4">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[var(--gold)]"><BookOpenCheck size={20} /></span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-[var(--ink)]">{totalQuestions.toLocaleString('ar-SY')} سؤال جديد موثّق</p>
          <p className="mt-0.5 text-xs leading-relaxed text-[var(--ink-soft)]">تُحمَّل أسئلة الوحدة عند فتحها فقط. {totalQuestions < 5000 ? `يجري تجهيز بقية البنك؛ الهدف ٥٠٠٠ سؤال جديدة. المتاح حالياً: ${totalQuestions.toLocaleString('ar-SY')}.` : 'اكتمل هدف الأسئلة الجديدة.'}</p>
        </div>
        <Badge tone={totalQuestions >= 5000 ? 'success' : 'gold'}>{totalQuestions >= 5000 ? 'اكتمل' : 'قيد الإضافة'}</Badge>
      </section>

      <label className="mb-3 flex min-h-11 items-center gap-2 rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-[var(--ink-soft)]">
        <Search size={17} />
        <span className="sr-only">ابحث عن مادة أو وحدة</span>
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث عن مادة أو وحدة أو درس" className="min-w-0 flex-1 bg-transparent text-sm text-[var(--ink)] outline-none placeholder:text-[var(--ink-soft)]" />
      </label>

      <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
        <Chip active={subjectId === 'all'} onClick={() => setSubjectId('all')}>كل المواد</Chip>
        {subjects.map((subject) => <Chip key={subject.id} active={subjectId === subject.id} onClick={() => setSubjectId(subject.id)}>{subject.shortName}</Chip>)}
      </div>

      {filteredUnits.length === 0 ? (
        <EmptyState icon={<Search size={18} />} title="لا توجد وحدات مطابقة" description="جرّب كلمة بحث أخرى أو اختر مادة مختلفة." />
      ) : (
        <div className="space-y-2">
          {filteredUnits.map((unit) => {
            const subject = subjects.find((item) => item.id === unit.subjectId);
            const coverage = CURRICULUM_COVERAGE.find((item) => item.subjectId === unit.subjectId);
            const source = CURRICULUM_SOURCES.find((item) => unit.sourceIds.includes(item.id));
            const available = unit.questionCount > 0;
            const cardClass = 'card flex items-start gap-3 p-3.5';
            const body = (
              <>
                <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[var(--surface-2)] text-[var(--brand)]"><BookOpenCheck size={18} /></span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2"><h2 className="text-sm font-semibold text-[var(--ink)]">{unit.title}</h2>{subject ? <Badge tone="brand">{subject.shortName}</Badge> : null}</div>
                  <p className="mt-1 text-xs text-[var(--ink-soft)]">{unit.lessonTitles.length ? `${unit.lessonTitles.length.toLocaleString('ar-SY')} دروس/أفكار` : 'فصل من الملحق الرسمي'} · {unit.questionCount.toLocaleString('ar-SY')} سؤال متاح</p>
                  <p className="mt-1 flex items-center gap-1 text-[0.67rem] text-[var(--ink-soft)]"><ShieldCheck size={12} className={coverage?.unitIndexVerified ? 'text-[var(--success)]' : 'text-[var(--gold)]'} />{coverage?.unitIndexVerified ? 'فهرس الوحدة موثق من المصدر المدرج' : 'الفهرس بحاجة إلى تحقق؛ لم تُنشأ أسئلة لهذه المادة بعد'}</p>
                  {source ? <p className="mt-1 text-[0.67rem] text-[var(--brand)]">المصدر الرسمي: {source.title}</p> : null}
                </div>
                <span className="mt-1 text-[var(--ink-soft)]" aria-hidden="true"><ArrowUpLeft size={16} /></span>
              </>
            );
            return available ? (
              <Link key={unit.id} to={`/practice/${unit.subjectId}/${unit.id}`} className={`focus-ring ${cardClass}`}>{body}</Link>
            ) : (
              <article key={unit.id} className={`${cardClass} opacity-80`} aria-disabled="true">{body}</article>
            );
          })}
        </div>
      )}
      <p className="mt-4 text-center text-[0.68rem] text-[var(--ink-soft)]">أجبت عن {attempts.length.toLocaleString('ar-SY')} محاولة في البنك · {questionCountByUnit.size.toLocaleString('ar-SY')} وحدات تدربت عليها</p>
    </div>
  );
}
