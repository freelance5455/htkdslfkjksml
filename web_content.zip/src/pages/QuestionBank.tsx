import { useCallback, useEffect, useMemo, useState } from 'react';
import { Bookmark, BookmarkCheck, CheckCircle2, ChevronDown, Database, FolderPlus, FolderOpen, Sparkles, Trash2, XCircle } from 'lucide-react';
import type { Difficulty, QuestionRow, QuestionType } from '@shared/types';
import { chaptersFor } from '@shared/syllabus';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn, QUESTION_TYPE_OPTIONS } from '../lib/utils';
import {
  Badge, Banner, Button, Card, EmptyState, Field, IconButton, Input, Modal, Select, SetupCard, Spinner, useToast,
} from '../components/ui';
import { Markdown } from '../components/Markdown';

type BankQuestion = QuestionRow & { bookmarked: boolean; lastCorrect: boolean | null; attemptCount: number };

interface Stats {
  solved: number; correct: number; accuracy: number | null;
  subjects: { subject: string; solved: number; correct: number; accuracy: number }[];
}

export default function QuestionBank() {
  const { profile, aiEnabled } = useAuth();
  const { push } = useToast();
  const [questions, setQuestions] = useState<BankQuestion[]>([]);
  const [total, setTotal] = useState(0);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<Record<number, { correct: boolean; message: string; solution: string }>>({});
  const [bookmarkedOnly, setBookmarkedOnly] = useState(false);
  const [subject, setSubject] = useState('');
  const [chapter, setChapter] = useState('');
  const [type, setType] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [source, setSource] = useState('');
  const [attempted, setAttempted] = useState('');
  const [search, setSearch] = useState('');
  const [collections, setCollections] = useState<{ id: number; name: string; count: number }[]>([]);
  const [collectionsOpen, setCollectionsOpen] = useState(false);
  const [newCollection, setNewCollection] = useState('');
  const [saveTarget, setSaveTarget] = useState<BankQuestion | null>(null);
  const [collectionFilter, setCollectionFilter] = useState<{ id: number; name: string } | null>(null);
  const [genOpen, setGenOpen] = useState(false);
  const [genBusy, setGenBusy] = useState(false);
  const [genCount, setGenCount] = useState(6);
  const [genDifficulty, setGenDifficulty] = useState<Difficulty>('medium');

  const chapterOptions = useMemo(() => (profile ? chaptersFor(profile.exam, subject || profile.subjects[0]) : []), [profile, subject]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (subject) params.set('subject', subject);
      if (chapter) params.set('chapter', chapter);
      if (type) params.set('type', type);
      if (difficulty) params.set('difficulty', difficulty);
      if (source) params.set('source', source);
      if (attempted) params.set('attempted', attempted);
      if (search.trim()) params.set('search', search.trim());
      if (bookmarkedOnly) params.set('bookmarked', 'true');
      params.set('limit', '60');
      if (collectionFilter) {
        const collection = await api.get<{ questions: BankQuestion[] }>(`/api/collections/${collectionFilter.id}`);
        setQuestions(collection.questions);
        setTotal(collection.questions.length);
      } else {
        const data = await api.get<{ questions: BankQuestion[]; total: number }>(`/api/bank?${params.toString()}`);
        setQuestions(data.questions);
        setTotal(data.total);
      }
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load the question bank.');
    } finally {
      setLoading(false);
    }
  }, [subject, chapter, type, difficulty, source, attempted, search, bookmarkedOnly, collectionFilter]);

  useEffect(() => {
    const timer = setTimeout(() => { void load(); }, 250);
    return () => clearTimeout(timer);
  }, [load]);

  const loadCollections = useCallback(async () => {
    try {
      const data = await api.get<{ collections: { id: number; name: string; count: number }[] }>('/api/collections');
      setCollections(data.collections);
    } catch {
      /* collections are optional UI */
    }
  }, []);

  useEffect(() => {
    void api.get<Stats>('/api/bank/stats').then(setStats).catch(() => undefined);
    void loadCollections();
  }, [loadCollections]);

  const createCollection = async () => {
    if (newCollection.trim().length < 2) return;
    try {
      const res = await api.post<{ collection: { id: number; name: string; count: number } }>('/api/collections', { name: newCollection.trim() });
      setCollections((prev) => [res.collection, ...prev]);
      setNewCollection('');
      push('Collection created.', 'ok');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not create the collection.', 'bad');
    }
  };

  const addToCollection = async (collectionId: number, questionId: number) => {
    try {
      await api.post(`/api/collections/${collectionId}/items`, { questionId });
      setCollections((prev) => prev.map((c) => c.id === collectionId ? { ...c, count: c.count + 1 } : c));
      setSaveTarget(null);
      push('Question saved to collection.', 'ok');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not save to that collection.', 'bad');
    }
  };

  const deleteCollection = async (id: number) => {
    try {
      await api.del(`/api/collections/${id}`);
      setCollections((prev) => prev.filter((c) => c.id !== id));
      if (collectionFilter?.id === id) setCollectionFilter(null);
      push('Collection deleted.', 'info');
    } catch {
      push('Could not delete that collection.', 'bad');
    }
  };

  const toggleBookmark = async (question: BankQuestion) => {
    try {
      const res = await api.post<{ bookmarked: boolean }>(`/api/bank/${question.id}/bookmark`);
      setQuestions((prev) => prev.map((q) => q.id === question.id ? { ...q, bookmarked: res.bookmarked } : q));
      if (bookmarkedOnly) await load();
    } catch {
      push('Could not update the bookmark.', 'bad');
    }
  };

  const answer = async (question: BankQuestion, response: string[] = [], numeric: string | null = null) => {
    try {
      const res = await api.post<{ correct: boolean; feedback: string; solution: string }>(`/api/bank/${question.id}/attempt`, { response, numeric });
      setFeedback((prev) => ({ ...prev, [question.id]: { correct: res.correct, message: res.feedback, solution: res.solution } }));
      setQuestions((prev) => prev.map((q) => q.id === question.id ? { ...q, attemptCount: q.attemptCount + 1, lastCorrect: res.correct } : q));
      void api.get<Stats>('/api/bank/stats').then(setStats).catch(() => undefined);
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not submit that answer.', 'bad');
    }
  };

  const generateSimilar = async () => {
    if (!subject || !chapter) { push('Pick a subject and chapter first.', 'warn'); return; }
    setGenBusy(true);
    try {
      const res = await api.post<{ questions: BankQuestion[]; saved: number }>('/api/bank/generate', {
        subject, chapter, type: type || 'mcq', difficulty: genDifficulty, count: genCount,
      });
      push(res.saved ? `Added ${res.saved} new AI-generated questions.` : 'The AI returned no usable questions — try again.', res.saved ? 'ok' : 'warn');
      setGenOpen(false);
      await load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Generation failed.', 'bad');
    } finally {
      setGenBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      {!aiEnabled && <SetupCard message="The shared practice bank works without AI. Generating extra questions and re-attempt hints need OPENAI_API_KEY." />}
      {error && <Banner tone="bad">{error}</Banner>}

      <div className="grid gap-3 sm:grid-cols-3">
        <Card className="flex items-center justify-between p-4">
          <div><div className="text-xs uppercase tracking-wide text-muted">Questions solved</div><div className="font-display text-2xl font-bold text-ink">{stats?.solved ?? 0}</div></div>
          <Database size={20} className="text-brand" />
        </Card>
        <Card className="flex items-center justify-between p-4">
          <div><div className="text-xs uppercase tracking-wide text-muted">Your accuracy</div><div className="font-display text-2xl font-bold text-ink">{stats?.accuracy ?? '—'}{stats?.accuracy !== null && stats?.accuracy !== undefined ? '%' : ''}</div></div>
          <CheckCircle2 size={20} className="text-ok" />
        </Card>
        <Card className="flex items-center justify-between p-4">
          <div><div className="text-xs uppercase tracking-wide text-muted">Matching questions</div><div className="font-display text-2xl font-bold text-ink">{total}</div></div>
          <XCircle size={20} className="text-warn" />
        </Card>
      </div>

      <Card>
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-[180px] flex-1">
            <Field label="Search"><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search prompt, chapter or topic…" /></Field>
          </div>
          <Field label="Subject">
            <Select value={subject} onChange={(e) => { setSubject(e.target.value); setChapter(''); }} className="w-auto min-w-[130px]">
              <option value="">All</option>
              {profile?.subjects.map((s) => <option key={s}>{s}</option>)}
            </Select>
          </Field>
          <Field label="Chapter">
            <Select value={chapter} onChange={(e) => setChapter(e.target.value)} className="w-auto min-w-[150px]">
              <option value="">All</option>
              {(subject ? chapterOptions : [...new Set((profile?.subjects ?? []).flatMap((s) => chaptersFor(profile!.exam, s)))]).map((c) => <option key={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="Type">
            <Select value={type} onChange={(e) => setType(e.target.value)} className="w-auto min-w-[130px]">
              <option value="">All</option>
              {QUESTION_TYPE_OPTIONS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </Select>
          </Field>
          <Field label="Difficulty">
            <Select value={difficulty} onChange={(e) => setDifficulty(e.target.value)} className="w-auto">
              <option value="">All</option>
              {['easy', 'medium', 'hard', 'advanced'].map((d) => <option key={d} value={d}>{d}</option>)}
            </Select>
          </Field>
          <Field label="Attempted">
            <Select value={attempted} onChange={(e) => setAttempted(e.target.value)} className="w-auto">
              <option value="">Any</option>
              <option value="incorrect">Answered wrong</option>
              <option value="correct">Answered right</option>
              <option value="unattempted">Never attempted</option>
            </Select>
          </Field>
          <Button variant={bookmarkedOnly ? 'primary' : 'secondary'} onClick={() => setBookmarkedOnly((v) => !v)} className="px-3 py-2.5 text-xs">
            <Bookmark size={14} /> Saved
          </Button>
          <Button variant={collectionsOpen ? 'primary' : 'secondary'} onClick={() => setCollectionsOpen(true)} className="px-3 py-2.5 text-xs">
            <FolderOpen size={14} /> Collections
          </Button>
          <Button variant="secondary" onClick={() => setGenOpen(true)} className="px-3 py-2.5 text-xs" disabled={!subject || !chapter}>
            <Sparkles size={14} /> Generate
          </Button>
        </div>
        <p className="mt-2 text-[11px] text-muted">
          Questions marked <span className="font-semibold text-ink">EduMentor practice</span> are original items written for this app.
          <span className="font-semibold text-ink"> AI-generated</span> items are produced by the model, and only items explicitly imported as previous-year are tagged verified.
        </p>
      </Card>

      {loading ? <Spinner /> : questions.length === 0 ? (
        <Card><EmptyState icon={<Database size={22} />} title="No questions match these filters" description="Widen the filters, or generate extra practice on a chapter you are studying." action={<Button onClick={() => setGenOpen(true)} disabled={!subject || !chapter}>Generate questions</Button>} /></Card>
      ) : (
        <div className="space-y-2.5">
          {questions.map((q) => {
            const open = openId === q.id;
            const result = feedback[q.id];
            return (
              <Card key={q.id} className="p-4">
                <div className="flex items-start gap-2">
                  <button onClick={() => setOpenId(open ? null : q.id)} className="min-w-0 flex-1 text-left">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge tone={q.source === 'ai' ? 'brand' : q.source === 'resource' ? 'ok' : 'neutral'}>
                        {q.source === 'ai' ? 'AI-generated' : q.source === 'resource' ? 'From your document' : 'EduMentor practice'}
                      </Badge>
                      <Badge>{q.subject}</Badge>
                      <Badge>{q.chapter}</Badge>
                      <Badge>{q.difficulty}</Badge>
                      {q.verified && <Badge tone="ok">Verified previous year</Badge>}
                      {q.lastCorrect === false && <Badge tone="bad">Last attempt wrong</Badge>}
                    </div>
                    <p className={cn('mt-2 text-sm text-ink', !open && 'line-clamp-2')}>{q.prompt}</p>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-muted">
                      <span>{QUESTION_TYPE_OPTIONS.find((t) => t.value === q.type)?.label ?? q.type}</span>
                      <span>· {q.marks} mark{q.marks === 1 ? '' : 's'}</span>
                      {q.attemptCount > 0 && <span>· attempted {q.attemptCount}×</span>}
                    </div>
                  </button>
                  <button onClick={() => setSaveTarget(q)} aria-label="Save to collection" className="shrink-0 text-muted transition hover:text-brand">
                    <FolderPlus size={17} />
                  </button>
                  <button onClick={() => void toggleBookmark(q)} aria-label="Bookmark question" className={cn('shrink-0 transition', q.bookmarked ? 'text-brand' : 'text-muted hover:text-ink')}>
                    {q.bookmarked ? <BookmarkCheck size={17} /> : <Bookmark size={17} />}
                  </button>
                  <button onClick={() => setOpenId(open ? null : q.id)} aria-label="Expand question" className="shrink-0 text-muted">
                    <ChevronDown size={17} className={cn('transition', open && 'rotate-180')} />
                  </button>
                </div>

                {open && (
                  <div className="mt-3 space-y-3 border-t border-line pt-3">
                    {(q.type === 'mcq' || q.type === 'multiple-correct' || q.type === 'assertion-reason') && q.options ? (
                      <div className="space-y-1.5">
                        {q.options.map((option) => {
                          const chosen = (result as unknown as { response?: string[] })?.response?.includes(option.key);
                          const isCorrect = q.correct.includes(option.key);
                          return (
                            <button key={option.key} onClick={() => void answer(q, [option.key])}
                              className={cn('flex w-full items-start gap-2 rounded-lg border px-3 py-2 text-left text-xs transition',
                                result ? isCorrect ? 'border-ok/50 bg-ok/10' : 'border-line bg-elevated/30' : 'border-line bg-elevated/30 hover:border-brand/40',
                                chosen && !isCorrect && 'border-bad/50 bg-bad/10')}>
                              <span className="font-bold text-ink">{option.key}</span>
                              <span className="text-ink/90">{option.text}</span>
                            </button>
                          );
                        })}
                      </div>
                    ) : q.type === 'numerical' || q.type === 'integer' ? (
                      <form onSubmit={(e) => {
                        e.preventDefault();
                        const input = (e.currentTarget.elements.namedItem('numeric') as HTMLInputElement);
                        void answer(q, [], input.value);
                      }} className="flex gap-2">
                        <Input name="numeric" type="number" step="any" placeholder="Your numerical answer" className="max-w-[220px] font-mono" />
                        <Button type="submit" className="px-3 py-2 text-xs">Check</Button>
                      </form>
                    ) : (
                      <div>
                        <textarea
                          className="field min-h-[120px] text-xs"
                          placeholder="Write your answer, then compare with the model answer below."
                          onBlur={(e) => { if (e.target.value.trim()) void answer(q, [e.target.value]); }}
                        />
                        <p className="mt-1 text-[10px] text-muted">Descriptive answers are not auto-marked; they are saved with your attempt for comparison.</p>
                      </div>
                    )}

                    {result && (
                      <div className={cn('flex items-start gap-2 rounded-lg border p-2.5 text-xs',
                        result.correct ? 'border-ok/40 bg-ok/10 text-ink' : 'border-bad/40 bg-bad/10 text-ink')}>
                        {result.correct ? <CheckCircle2 size={15} className="mt-0.5 shrink-0 text-ok" /> : <XCircle size={15} className="mt-0.5 shrink-0 text-bad" />}
                        <span>{result.message}</span>
                      </div>
                    )}

                    <div>
                      <div className="mb-1 text-[10px] uppercase tracking-wide text-muted">Solution</div>
                      <div className="rounded-lg border border-line bg-elevated/20 p-3"><Markdown content={q.solution} /></div>
                    </div>
                    {q.resourcePages && <p className="text-[11px] text-muted">Source reference: {q.sourceLabel} · {q.resourcePages}</p>}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {collectionFilter && (
        <Banner tone="info" title={`Viewing collection: ${collectionFilter.name}`} action={<Button variant="ghost" className="px-2 py-1 text-xs" onClick={() => setCollectionFilter(null)}>Clear</Button>}>
          Showing {questions.length} saved questions. Filters are ignored while a collection is open.
        </Banner>
      )}

      <Modal open={collectionsOpen} onClose={() => setCollectionsOpen(false)} title="Question collections" description="Group questions for a specific revision goal — a weak chapter, a mock-paper set, doubts to re-ask.">
        <div className="space-y-3">
          <div className="flex gap-2">
            <Input value={newCollection} onChange={(e) => setNewCollection(e.target.value)} placeholder="New collection name" onKeyDown={(e) => { if (e.key === 'Enter') void createCollection(); }} />
            <Button onClick={() => void createCollection()} disabled={newCollection.trim().length < 2}>Create</Button>
          </div>
          {collections.length === 0 ? (
            <p className="py-4 text-sm text-muted">No collections yet. Create one, then use the folder icon on any question.</p>
          ) : (
            <ul className="space-y-1.5">
              {collections.map((collection) => (
                <li key={collection.id} className="flex items-center gap-2 rounded-xl border border-line bg-elevated/30 p-2.5">
                  <button
                    className="min-w-0 flex-1 text-left"
                    onClick={() => { setCollectionFilter({ id: collection.id, name: collection.name }); setCollectionsOpen(false); }}
                  >
                    <span className="block truncate text-sm font-medium text-ink">{collection.name}</span>
                    <span className="text-[11px] text-muted">{collection.count} question{collection.count === 1 ? '' : 's'}</span>
                  </button>
                  <IconButton label="Delete collection" onClick={() => void deleteCollection(collection.id)}>
                    <Trash2 size={14} />
                  </IconButton>
                </li>
              ))}
            </ul>
          )}
        </div>
      </Modal>

      <Modal
        open={saveTarget !== null}
        onClose={() => setSaveTarget(null)}
        title="Save to a collection"
        description={saveTarget ? saveTarget.prompt.slice(0, 120) : undefined}
        size="sm"
      >
        <div className="space-y-3">
          <div className="flex gap-2">
            <Input value={newCollection} onChange={(e) => setNewCollection(e.target.value)} placeholder="Create a collection" />
            <Button variant="secondary" onClick={() => void createCollection()} disabled={newCollection.trim().length < 2}>Create</Button>
          </div>
          {collections.length === 0 ? (
            <p className="text-sm text-muted">Create your first collection above.</p>
          ) : (
            <ul className="space-y-1.5">
              {collections.map((collection) => (
                <li key={collection.id}>
                  <button
                    onClick={() => saveTarget && void addToCollection(collection.id, saveTarget.id)}
                    className="flex w-full items-center justify-between gap-2 rounded-lg border border-line bg-elevated/30 px-3 py-2 text-left text-sm text-ink hover:border-brand/40"
                  >
                    <span className="truncate">{collection.name}</span>
                    <span className="text-[11px] text-muted">{collection.count}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </Modal>

      <Modal
        open={genOpen}
        onClose={() => setGenOpen(false)}
        title="Generate similar questions"
        description={subject && chapter ? `${subject} · ${chapter}` : 'Pick a subject and chapter first'}
        footer={<><Button variant="secondary" onClick={() => setGenOpen(false)}>Cancel</Button><Button onClick={() => void generateSimilar()} loading={genBusy} disabled={!aiEnabled}>Generate &amp; save</Button></>}
      >
        <div className="space-y-3">
          {!aiEnabled && <SetupCard />}
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="How many?">
              <Input type="number" min={1} max={10} value={genCount} onChange={(e) => setGenCount(Math.max(1, Math.min(10, Number(e.target.value))))} />
            </Field>
            <Field label="Difficulty">
              <Select value={genDifficulty} onChange={(e) => setGenDifficulty(e.target.value as Difficulty)}>
                {['easy', 'medium', 'hard', 'advanced'].map((d) => <option key={d} value={d}>{d}</option>)}
              </Select>
            </Field>
          </div>
          <p className="text-xs text-muted">Generated questions are saved to your bank with a clear “AI-generated” label and a worked solution. Verify anything you are unsure about.</p>
        </div>
      </Modal>
    </div>
  );
}
