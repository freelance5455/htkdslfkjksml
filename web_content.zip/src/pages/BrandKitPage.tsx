import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { getBrandKit, saveBrandKit } from "@/lib/storage";
import type { BrandKit } from "@/types";
import { Palette, Type, Plus, Save, Trash2, Check } from "lucide-react";

export default function BrandKitPage() {
  const [kit, setKit] = useState<BrandKit>(getBrandKit);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    saveBrandKit(kit);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const updateColor = (index: number, field: string, value: string) => {
    const colors = [...kit.colors];
    colors[index] = { ...colors[index], [field]: value };
    setKit({ ...kit, colors });
  };

  const addColor = () => {
    setKit({ ...kit, colors: [...kit.colors, { name: "Nova Cor", value: "#ffffff", role: "accent" }] });
  };

  const removeColor = (index: number) => {
    setKit({ ...kit, colors: kit.colors.filter((_, i) => i !== index) });
  };

  return (
    <AppLayout title="Brand Kit" subtitle="Identidade visual do seu canal">
      <div className="p-6 max-w-4xl space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-studio-text font-display">{kit.name}</h2>
            <p className="text-sm text-studio-text-muted">Gerencie a identidade visual do seu conteúdo</p>
          </div>
          <button onClick={handleSave} className={saved ? "btn-secondary text-sm" : "btn-primary text-sm"}>
            {saved ? <><Check className="w-4 h-4" /> Salvo!</> : <><Save className="w-4 h-4" /> Salvar</>}
          </button>
        </div>

        {/* Brand name */}
        <div className="studio-card p-5">
          <h3 className="text-sm font-bold text-studio-text font-display mb-4 flex items-center gap-2">
            <span className="w-5 h-5 rounded bg-studio-blue/20 flex items-center justify-center text-xs">B</span>
            Nome da Marca
          </h3>
          <input
            value={kit.name}
            onChange={(e) => setKit({ ...kit, name: e.target.value })}
            className="studio-input text-sm max-w-sm"
            placeholder="Nome do canal / marca"
          />
        </div>

        {/* Colors */}
        <div className="studio-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Palette className="w-4 h-4 text-studio-blue" />
              Paleta de Cores
            </h3>
            <button onClick={addColor} className="btn-secondary text-xs py-1.5 px-3">
              <Plus className="w-3 h-3" /> Adicionar
            </button>
          </div>

          <div className="space-y-3">
            {kit.colors.map((color, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-studio-panel border border-studio-border">
                <div
                  className="w-10 h-10 rounded-xl border border-studio-border shrink-0 shadow-inner"
                  style={{ backgroundColor: color.value }}
                />
                <input
                  type="color"
                  value={color.value}
                  onChange={(e) => updateColor(i, "value", e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer bg-transparent border-0 shrink-0"
                />
                <input
                  value={color.name}
                  onChange={(e) => updateColor(i, "name", e.target.value)}
                  className="studio-input text-sm flex-1 py-2"
                  placeholder="Nome da cor"
                />
                <select
                  value={color.role}
                  onChange={(e) => updateColor(i, "role", e.target.value)}
                  className="studio-input text-sm py-2 w-36"
                >
                  {["primary","secondary","accent","background"].map((r) => (
                    <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
                  ))}
                </select>
                <span className="text-xs font-mono text-studio-text-muted w-20 text-center">{color.value}</span>
                <button
                  onClick={() => removeColor(i)}
                  className="p-1.5 rounded hover:bg-studio-red/10 text-studio-text-muted hover:text-studio-red transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Preview */}
          <div className="mt-5 pt-4 border-t border-studio-border">
            <p className="text-xs text-studio-text-muted mb-3">Preview da Paleta</p>
            <div className="flex gap-3">
              {kit.colors.map((c, i) => (
                <div key={i} className="flex flex-col items-center gap-1">
                  <div className="w-12 h-12 rounded-xl border border-studio-border shadow" style={{ backgroundColor: c.value }} />
                  <span className="text-xs text-studio-text-muted">{c.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Fonts */}
        <div className="studio-card p-5">
          <h3 className="text-sm font-bold text-studio-text font-display mb-4 flex items-center gap-2">
            <Type className="w-4 h-4 text-studio-purple" />
            Tipografia
          </h3>
          <div className="space-y-3">
            {kit.fonts.map((font, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-studio-panel border border-studio-border">
                <span className="text-xs text-studio-text-muted w-20 capitalize">{font.role}</span>
                <input
                  value={font.name}
                  onChange={(e) => {
                    const fonts = [...kit.fonts];
                    fonts[i] = { ...fonts[i], name: e.target.value };
                    setKit({ ...kit, fonts });
                  }}
                  className="studio-input text-sm flex-1 py-2"
                  placeholder="Nome da fonte"
                />
                <span className="text-sm text-studio-text-dim" style={{ fontFamily: font.name }}>
                  Aa Bb Cc
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Voice & Music Style */}
        <div className="grid grid-cols-2 gap-5">
          <div className="studio-card p-5">
            <h3 className="text-sm font-bold text-studio-text font-display mb-3">Estilo de Voz</h3>
            <textarea
              value={kit.voiceStyle ?? ""}
              onChange={(e) => setKit({ ...kit, voiceStyle: e.target.value })}
              placeholder="Descreva o estilo de voz preferido: narrador, jovem, energético, calmo..."
              className="studio-input text-sm resize-none h-24"
            />
          </div>
          <div className="studio-card p-5">
            <h3 className="text-sm font-bold text-studio-text font-display mb-3">Estilo Musical</h3>
            <textarea
              value={kit.musicStyle ?? ""}
              onChange={(e) => setKit({ ...kit, musicStyle: e.target.value })}
              placeholder="Descreva o estilo musical: pop, lo-fi, eletrônico, orquestral..."
              className="studio-input text-sm resize-none h-24"
            />
          </div>
        </div>

        {/* Identity notes */}
        <div className="studio-card p-5">
          <h3 className="text-sm font-bold text-studio-text font-display mb-3">Notas de Identidade</h3>
          <textarea
            value={kit.identityNotes ?? ""}
            onChange={(e) => setKit({ ...kit, identityNotes: e.target.value })}
            placeholder="Diretrizes gerais de identidade visual, tom de comunicação, valores da marca..."
            className="studio-input text-sm resize-none h-28"
          />
        </div>
      </div>
    </AppLayout>
  );
}
