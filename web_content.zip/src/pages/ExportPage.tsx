import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Download,
  FileVideo2,
  HardDrive,
  Info,
  Loader2,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Square,
  Timer,
  Video,
  XCircle,
} from "lucide-react";
import type { EngineCapabilities } from "@/lib/exporter";
import type { ExportProgress, ExportResult, Mp4Check, ViewKey } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { ASPECT_PRESETS, QUALITY_BITRATES, QUALITY_LABELS, aspectLabel, formatBytes, formatDuration, sanitizeFilename } from "@/data/defaults";
import { buildTimeline, estimatedFileSize } from "@/lib/timeline";
import { validateProject, issueSummary } from "@/lib/preflight";
import { detectEngineCapabilities, estimateRenderSeconds, exportMp4, isAbortError } from "@/lib/exporter";
import { estimateStorage } from "@/lib/idb";
import { downloadBlob, errorMessage, preloadImages } from "@/lib/media";
import { SceneCanvas } from "@/components/PreviewSurface";
import { Button, Field, Input, SectionHeader, Segmented, Select, Toggle } from "@/components/ui";
import { cn } from "@/utils/cn";

const PHASE_LABELS: Record<string, string> = {
  idle: "جاهز للبدء",
  preparing: "فحص المحرك",
  mixing: "خلط الصوت",
  "encoding-audio": "ترميز الصوت",
  rendering: "تصيير الفيديو",
  finalizing: "إنهاء الحاوية",
  validating: "التحقق من MP4",
  done: "اكتمل",
  error: "خطأ",
  cancelled: "أُلغي",
};

function CheckRow({ check }: { check: Mp4Check }) {
  const Icon = check.status === "pass" ? CheckCircle2 : check.status === "warn" ? AlertTriangle : XCircle;
  return (
    <div className="flex items-start gap-2 rounded-lg border border-white/[0.06] bg-white/[0.015] px-2.5 py-2">
      <Icon size={13} className={cn("mt-0.5 shrink-0", check.status === "pass" ? "text-[#6fe0a4]" : check.status === "warn" ? "text-[#e7cf94]" : "text-red-300")} />
      <div className="min-w-0 flex-1">
        <p className="text-[10px] font-medium text-[#e2e2e8]">{check.label}</p>
        <p className="mt-0.5 text-[9px] leading-4 text-[#82828c]">{check.detail}</p>
      </div>
    </div>
  );
}

export function ExportPage({ onNavigate }: { onNavigate: (view: ViewKey) => void }) {
  const { project, updateProject, mediaUrls, availableMedia, toast } = useStudio();
  const [caps, setCaps] = useState<EngineCapabilities | null>(null);
  const [capsBusy, setCapsBusy] = useState(false);
  const [progress, setProgress] = useState<ExportProgress>({ phase: "idle", percent: 0, label: "لم يبدأ التصدير" });
  const [exporting, setExporting] = useState(false);
  const [result, setResult] = useState<ExportResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [checks, setChecks] = useState<Mp4Check[]>([]);
  const [showAllIssues, setShowAllIssues] = useState(false);
  const [storage, setStorage] = useState<{ available: number; usage: number } | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const resultUrl = useRef<string | null>(null);
  const timeline = buildTimeline(project);
  const settings = project.exportSettings;
  const issues = validateProject(project, { availableMedia });
  const summary = issueSummary(issues);
  const estimatedBytes = estimatedFileSize(project);
  const frames = Math.ceil(timeline.totalDuration * settings.fps);

  useEffect(() => {
    void detectEngineCapabilities().then(setCaps);
    void estimateStorage().then((value) => {
      if (value) setStorage({ available: value.available, usage: value.usage });
    });
  }, []);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      if (resultUrl.current) URL.revokeObjectURL(resultUrl.current);
    };
  }, []);

  useEffect(() => {
    if (!exporting) return;
    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "التصدير قيد التنفيذ. إذا أغلقت الصفحة ستُفقد العملية.";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [exporting]);

  const refreshCaps = async () => {
    setCapsBusy(true);
    try {
      const value = await detectEngineCapabilities(true);
      setCaps(value);
      toast(value.videoSupported && value.audioSupported ? "المحرك يدعم ترميز H.264 والصوت في هذه البيئة." : value.reason, value.videoSupported && value.audioSupported ? "success" : "error");
    } finally {
      setCapsBusy(false);
    }
  };

  const updateSettings = (patch: Partial<typeof settings>) => {
    updateProject((current) => ({ ...current, exportSettings: { ...current.exportSettings, ...patch } }));
  };
  const chooseAspect = (aspect: typeof settings.aspect) => {
    if (aspect === "custom") {
      updateSettings({ aspect });
      return;
    }
    const preset = ASPECT_PRESETS[aspect];
    updateSettings({ aspect, width: preset.width, height: preset.height });
  };

  const startExport = async () => {
    if (exporting) {
      toast("عملية تصدير قيد التنفيذ بالفعل. انتظر اكتمالها أو ألغها أولًا.", "warning");
      return;
    }
    const freshIssues = validateProject(project, { availableMedia });
    const errors = freshIssues.filter((issue) => issue.level === "error");
    if (errors.length) {
      setError(`لا يمكن بدء التصدير: ${errors[0].message} (${errors.length} خطأ مانع)`);
      toast("أوقف الفحص المسبق عملية التصدير. راجع الأخطاء المانعة أولًا.", "error");
      setProgress({ phase: "error", percent: 0, label: "فشل الفحص المسبق", detail: errors[0].message });
      return;
    }
    if (typeCheckCapabilities()) return;
    setResult(null);
    setChecks([]);
    setError(null);
    setExporting(true);
    setProgress({ phase: "preparing", percent: 0, label: "بدء التصدير", detail: "تجهيز المحرك والخطوط" });
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const images = await preloadImages(project, mediaUrls);
      const output = await exportMp4({
        project,
        timeline,
        images,
        signal: controller.signal,
        getBlob: async (mediaId) => {
          const url = mediaUrls[mediaId];
          if (!url) return undefined;
          const response = await fetch(url);
          if (!response.ok) throw new Error("تعذّر قراءة أحد الملفات المحلية. أعد رفع الملف ثم حاول مجددًا.");
          return response.blob();
        },
        onProgress: setProgress,
      });
      if (resultUrl.current) URL.revokeObjectURL(resultUrl.current);
      const url = URL.createObjectURL(output.blob);
      resultUrl.current = url;
      setResult({ ...output, url, size: output.blob.size, createdAt: Date.now(), filename: `${sanitizeFilename(settings.filename)}.mp4` });
      setChecks(output.checks);
      toast("اكتمل الترميز واجتاز الملف فحص البنية والتشغيل. يمكنك التنزيل الآن.", "success");
    } catch (caught) {
      if (isAbortError(caught)) {
        setProgress({ phase: "cancelled", percent: 0, label: "أُلغي التصدير", detail: "لم يُنتج ملف ولا توجد بيانات ناقصة." });
        setError(null);
        toast("أُلغي التصدير بأمان. لم يُنشأ أي ملف.", "info");
      } else {
        const message = errorMessage(caught, "فشل التصدير لسبب غير معروف.");
        const failedChecks = (caught as { checks?: Mp4Check[] })?.checks;
        if (failedChecks?.length) setChecks(failedChecks);
        setError(message);
        setProgress({ phase: "error", percent: 0, label: "فشل التصدير", detail: message });
        toast(`فشل التصدير: ${message}`, "error");
      }
    } finally {
      abortRef.current = null;
      setExporting(false);
    }
  };

  const typeCheckCapabilities = (): boolean => {
    if (!caps) {
      setError("لم يكتمل فحص محرك التصدير بعد. انتظر لحظة ثم أعد المحاولة.");
      return true;
    }
    if (!caps.webCodecs || !caps.videoSupported || !caps.audioSupported) {
      setError(`المتصفح لا يدعم التصدير المطلوب: ${caps.reason}`);
      toast("محرك MP4 غير متاح في هذا المتصفح. استخدم Chrome/Edge حديثًا أو Safari 16.4+.", "error");
      return true;
    }
    return false;
  };

  const cancel = () => {
    abortRef.current?.abort();
    toast("يجري إيقاف التصدير والتحقق من عدم إنتاج ملف جزئي…", "info");
  };

  const download = () => {
    if (!result) {
      toast("لا يوجد ملف ناتج للتنزيل.", "error");
      return;
    }
    if (storage && result.size > storage.available) {
      toast("المساحة المتاحة على هذا الجهاز قد لا تكفي لتنزيل الملف. فرّغ مساحة ثم أعد المحاولة.", "warning");
    }
    try {
      downloadBlob(result.blob, result.filename);
      toast(`بدأ تنزيل ${result.filename} (${formatBytes(result.size)}). تحقق من مجلد التنزيلات.`, "success");
    } catch (caught) {
      toast(errorMessage(caught, "فشل تنزيل الملف. جرّب متصفحًا آخر أو تحقق من المساحة."), "error");
    }
  };

  const visibleIssues = showAllIssues ? issues : issues.slice(0, 5);
  const stepLabels = [
    { key: "preparing", label: "فحص المحرك" },
    { key: "mixing", label: "خلط الصوت" },
    { key: "encoding-audio", label: "ترميز الصوت" },
    { key: "rendering", label: "تصيير وترميز المشاهد" },
    { key: "finalizing", label: "إنهاء MP4" },
    { key: "validating", label: "التحقق قبل النجاح" },
  ];
  const stepIndex: Record<string, number> = { preparing: 0, mixing: 1, "encoding-audio": 2, rendering: 3, finalizing: 4, validating: 5, done: 6 };

  return (
    <div>
      <SectionHeader
        icon={<FileVideo2 size={18} />}
        eyebrow="الإخراج النهائي"
        title="إعدادات التصدير"
        description="ملف MP4 حقيقي بترميز H.264 وصوت AAC، يُبنى داخل جهازك ولا يعتمد على تسجيل الشاشة أو خادم خارجي."
        actions={
          <>
            <Button variant="ghost" onClick={() => void refreshCaps()} loading={capsBusy}>
              <RefreshCw size={14} /> إعادة فحص المحرك
            </Button>
            <Button variant="primary" onClick={() => void startExport()} disabled={exporting || summary.errors > 0} loading={exporting}>
              <Sparkles size={14} /> إنشاء الفيديو
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <div className="space-y-4">
          <section className="panel p-3.5 sm:p-4">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-[15px] font-bold text-white">المقاس والجودة</h3>
              <span className="chip chip-gold !py-0.5">{aspectLabel(settings.width, settings.height)}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {(["vertical", "landscape", "square", "custom"] as const).map((aspect) => {
                const preset = ASPECT_PRESETS[aspect];
                const active = settings.aspect === aspect;
                return (
                  <button
                    key={aspect}
                    type="button"
                    onClick={() => chooseAspect(aspect)}
                    className={cn("rounded-xl border p-2.5 text-right transition", active ? "border-[#d9b65a]/45 bg-[#d9b65a]/[0.07]" : "border-white/[0.07] bg-white/[0.015] hover:border-white/20")}
                  >
                    <div className="mb-2 flex h-8 items-center">
                      <span
                        className="block rounded-sm border border-white/25 bg-white/[0.03]"
                        style={aspect === "vertical" ? { width: 15, height: 27 } : aspect === "landscape" ? { width: 35, height: 20 } : aspect === "square" ? { width: 25, height: 25 } : { width: 22, height: 27 }}
                      />
                    </div>
                    <p className={cn("text-[11px] font-semibold", active ? "text-[#f0dfb4]" : "text-[#d5d5dc]")}>{preset.label}</p>
                    <p className="mt-0.5 text-[9px] text-[#797983]" dir="ltr">{preset.width}×{preset.height}</p>
                    <p className="mt-0.5 text-[8px] text-[#66666f]">{preset.hint}</p>
                  </button>
                );
              })}
            </div>
            {settings.aspect === "custom" ? (
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Field label="العرض (px)" hint="رقم زوجي بين 256 و3840">
                  <Input type="number" min={256} max={3840} step={2} value={settings.width} onChange={(event) => updateSettings({ width: Math.max(256, Math.min(3840, Number(event.target.value) || 1080)) })} />
                </Field>
                <Field label="الارتفاع (px)" hint="رقم زوجي">
                  <Input type="number" min={256} max={3840} step={2} value={settings.height} onChange={(event) => updateSettings({ height: Math.max(256, Math.min(3840, Number(event.target.value) || 1920)) })} />
                </Field>
              </div>
            ) : null}
            {(settings.width % 2 !== 0 || settings.height % 2 !== 0) ? <p className="mt-2 text-[10px] text-red-300">الأبعاد الفردية غير مدعومة في H.264. اجعل العرض والارتفاع زوجيين.</p> : null}

            <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
              <div>
                <span className="label">معدل الإطارات</span>
                <Segmented value={String(settings.fps)} onChange={(value) => updateSettings({ fps: Number(value) as 24 | 25 | 30 })} options={[{ value: "24", label: "24" }, { value: "25", label: "25" }, { value: "30", label: "30" }]} size="sm" />
              </div>
              <div>
                <span className="label">الجودة / معدل البِت</span>
                <Select value={settings.quality} onChange={(event) => {
                  const quality = event.target.value as keyof typeof QUALITY_BITRATES;
                  updateSettings({ quality, videoBitrate: QUALITY_BITRATES[quality] });
                }}>
                  {Object.entries(QUALITY_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                </Select>
              </div>
              <Field label="اسم الملف">
                <div className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-[#0b0b0e] px-3 py-2">
                  <input value={settings.filename} onChange={(event) => updateSettings({ filename: event.target.value.slice(0, 80) })} className="min-w-0 flex-1 bg-transparent text-[12px] text-white outline-none" dir="ltr" aria-label="اسم ملف الفيديو" />
                  <span className="text-[10px] text-[#777781]" dir="ltr">.mp4</span>
                </div>
              </Field>
              <div>
                <span className="label">جودة صوت AAC</span>
                <Select value={String(settings.audioBitrate)} onChange={(event) => updateSettings({ audioBitrate: Number(event.target.value) })}>
                  <option value="96000">96 kbps</option>
                  <option value="128000">128 kbps</option>
                  <option value="192000">192 kbps</option>
                </Select>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <Button variant="ghost" className="!px-2 !py-1.5 text-[10px]" onClick={() => updateSettings({ aspect: "vertical", width: 720, height: 1280, fps: 30, quality: "economy", videoBitrate: QUALITY_BITRATES.economy })}>
                <Video size={11} /> نسخة خفيفة للهاتف · 720×1280
              </Button>
              <Button variant="quiet" className="!px-2 !py-1.5 text-[10px]" onClick={() => updateSettings({ aspect: "vertical", width: 1080, height: 1920, fps: 30, quality: "standard", videoBitrate: QUALITY_BITRATES.standard })}>
                <Square size={11} /> الدقة الكاملة 1080×1920
              </Button>
            </div>
            <div className="mt-3 rounded-lg border border-white/[0.07] bg-black/25 px-3 py-2 text-[10px] leading-5 text-[#86868f]">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="flex items-center gap-1"><Timer size={11} /> المدة: {formatDuration(timeline.totalDuration)}</span>
                <span className="flex items-center gap-1"><Play size={11} /> {frames} إطارًا</span>
                <span className="flex items-center gap-1"><HardDrive size={11} /> الحجم التقديري: {formatBytes(estimatedBytes)}</span>
                <span className="flex items-center gap-1"><Cpu size={11} /> زمن التصيير التقديري: ~{estimateRenderSeconds(project)} ثانية</span>
              </div>
            </div>
          </section>

          <section className="panel p-3.5 sm:p-4">
            <div className="mb-2.5 flex items-center justify-between">
              <h3 className="flex items-center gap-2 font-display text-[15px] font-bold text-white"><ShieldCheck size={15} className="text-[#57dc96]" /> الفحص المسبق</h3>
              <div className="flex gap-1.5">
                {summary.errors ? <span className="chip chip-red !py-0.5">{summary.errors} أخطاء</span> : <span className="chip chip-mint !py-0.5">لا أخطاء</span>}
                {summary.warnings ? <span className="chip chip-gold !py-0.5">{summary.warnings} تنبيه</span> : null}
              </div>
            </div>
            <div className="space-y-1.5">
              {visibleIssues.map((issue, index) => (
                <div key={`${issue.message}-${index}`} className={cn("flex items-start gap-2 rounded-lg border px-2.5 py-2", issue.level === "error" ? "border-red-400/20 bg-red-400/[0.04]" : "border-[#d9b65a]/20 bg-[#d9b65a]/[0.035]")}>
                  {issue.level === "error" ? <XCircle size={12} className="mt-0.5 shrink-0 text-red-300" /> : <AlertTriangle size={12} className="mt-0.5 shrink-0 text-[#e7cf94]" />}
                  <p className="flex-1 text-[10px] leading-5 text-[#c6c6cf]">{issue.message}</p>
                  {issue.questionId ? <button type="button" onClick={() => onNavigate("questions")} className="text-[9px] text-[#d9c187] hover:text-white">إصلاح</button> : null}
                </div>
              ))}
              {issues.length === 0 ? (
                <div className="flex items-center gap-2 rounded-lg border border-[#57dc96]/20 bg-[#57dc96]/[0.04] px-2.5 py-2 text-[10px] text-[#9ef0c1]">
                  <CheckCircle2 size={13} /> الأسئلة والإجابات والأصوات مكتملة. جاهز للتصدير.
                </div>
              ) : null}
            </div>
            {issues.length > 5 ? (
              <button type="button" onClick={() => setShowAllIssues((value) => !value)} className="mt-2 text-[10px] text-[#d9c187] hover:text-white">
                {showAllIssues ? "عرض أقل" : `عرض كل الملاحظات (${issues.length})`}
              </button>
            ) : null}
            <div className="mt-3 flex flex-wrap gap-1.5">
              <Button variant="ghost" className="!px-2.5 !py-1.5 text-[10px]" onClick={() => onNavigate("questions")}>تحرير الأسئلة</Button>
              <Button variant="ghost" className="!px-2.5 !py-1.5 text-[10px]" onClick={() => onNavigate("audio")}>الصوت والتوقيت</Button>
              <Button variant="quiet" className="!px-2.5 !py-1.5 text-[10px]" onClick={() => onNavigate("preview")}>معاينة قبل التصدير</Button>
            </div>
          </section>

          {error ? (
            <div className="rounded-xl border border-red-400/25 bg-[#1a0f11] p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <XCircle size={17} className="mt-0.5 shrink-0 text-red-300" />
                  <div>
                    <p className="text-[12px] font-semibold text-red-100">لم يُنتج ملف الفيديو</p>
                    <p className="mt-1 text-[11px] leading-6 text-[#d3a5a7]">{error}</p>
                  </div>
                </div>
                <Button variant="ghost" className="!px-2 !py-1 text-[10px]" onClick={() => void startExport()} disabled={exporting}>إعادة المحاولة</Button>
              </div>
              <ul className="mt-2 list-inside list-disc space-y-1 text-[10px] leading-5 text-[#a88486]">
                <li>استخدم Chrome/Edge حديثًا على الكمبيوتر، وتأكد من فتح الموقع عبر HTTPS.</li>
                <li>قلل الأبعاد أو المدة أو الجودة عند نفاد ذاكرة الجهاز.</li>
                <li>أعد رفع أي ملف صوتي يظهر كغير متاح، ثم أعد الفحص.</li>
              </ul>
            </div>
          ) : null}

          {result ? (
            <section className="panel overflow-hidden border-[#57dc96]/20">
              <div className="flex items-center justify-between gap-2 border-b border-white/[0.07] bg-[#57dc96]/[0.05] px-4 py-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={17} className="text-[#7ce1a9]" />
                  <div>
                    <p className="text-[12px] font-semibold text-[#d8f6e5]">اكتمل التصدير وتم التحقق من الملف</p>
                    <p className="mt-0.5 text-[10px] text-[#86bb9f]">{result.filename} · {formatBytes(result.size)} · {result.width}×{result.height} · {formatDuration(result.duration)}</p>
                  </div>
                </div>
                <Button variant="mint" onClick={download} className="!px-3 !py-2 text-[11px]"><Download size={14} /> تنزيل MP4</Button>
              </div>
              <div className="grid gap-3 p-3 sm:grid-cols-[220px_1fr]">
                <div className="overflow-hidden rounded-xl border border-white/10 bg-black">
                  <video src={result.url} controls playsInline className="max-h-[360px] w-full object-contain" />
                </div>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                    {[
                      ["الحجم", formatBytes(result.size)],
                      ["المدة", formatDuration(result.duration)],
                      ["الأبعاد", `${result.width}×${result.height}`],
                      ["الإطارات", `${result.frames}`],
                      ["الفيديو", result.videoCodec],
                      ["الصوت", result.audioCodec],
                    ].map(([label, value]) => (
                      <div key={label} className="rounded-lg border border-white/[0.06] bg-white/[0.018] px-2 py-1.5">
                        <p className="text-[9px] text-[#72727c]">{label}</p>
                        <p className="mt-0.5 text-[10px] font-medium text-[#e4e4ea]" dir="auto">{value}</p>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">{checks.slice(0, 4).map((check) => <CheckRow key={check.key} check={check} />)}</div>
                  <p className="text-[9px] leading-5 text-[#75757f]">لم يُعلن النجاح إلا بعد قراءة بنية MP4 ووجود مساري فيديو وصوت. إذا لم يبدأ التنزيل تلقائيًا فاستخدم زر التنزيل أعلاه.</p>
                  {result.audioCodec === "Opus" ? <p className="rounded-md border border-[#d9b65a]/25 bg-[#d9b65a]/[0.06] px-2 py-1.5 text-[9px] leading-5 text-[#f0dfb4]">هذا المتصفح رمّز الصوت بـ Opus بدل AAC. الملف صالح ويحتوي صوتًا (تحققنا بفك ترميزه)، لكن بعض منصات النشر مثل TikTok قد ترفض Opus. للحصول على توافق أوسع صدّر من Chrome/Edge على الكمبيوتر حيث يتوفر AAC.</p> : null}
                </div>
              </div>
            </section>
          ) : null}
        </div>

        <aside className="space-y-3">
          <div className="panel overflow-hidden">
            <div className="border-b border-white/[0.07] p-3.5">
              <div className="flex items-center justify-between gap-2">
                <h3 className="flex items-center gap-1.5 font-display text-[15px] font-bold text-white"><Cpu size={14} className="text-[#d9b65a]" /> محرك التصدير</h3>
                <span className={cn("chip !py-0.5", caps?.videoSupported && caps?.audioSupported ? "chip-mint" : "chip-red")}>
                  <span className={cn("h-1.5 w-1.5 rounded-full", caps?.videoSupported && caps?.audioSupported ? "bg-[#57dc96]" : "bg-red-400")} />
                  {caps?.videoSupported && caps?.audioSupported ? "جاهز" : caps ? "غير مدعوم" : "يفحص…"}
                </span>
              </div>
              <p className="mt-1.5 text-[10px] leading-5 text-[#7f7f89]">{caps?.reason ?? "جارٍ التحقق من دعم WebCodecs وH.264 وAAC في متصفحك…"}</p>
            </div>
            <div className="space-y-2 p-3.5">
              {[
                ["WebCodecs", caps?.webCodecs ? "متوفر" : "غير متوفر", Boolean(caps?.webCodecs)],
                ["اتصال آمن (HTTPS)", caps?.secure ? "متوفر" : "غير متوفر", Boolean(caps?.secure)],
                ["ترميز H.264", caps?.videoSupported ? caps.videoCodec ?? "مدعوم" : "غير مدعوم", Boolean(caps?.videoSupported)],
                ["ترميز الصوت", caps?.audioSupported ? caps.audioCodec === "aac" ? "AAC" : "Opus (احتياطي)" : "غير مدعوم", Boolean(caps?.audioSupported)],
              ].map(([label, value, ok]) => (
                <div key={String(label)} className="flex items-center justify-between gap-2 text-[10px]">
                  <span className="text-[#9a9aa4]">{label}</span>
                  <span className={cn("flex items-center gap-1", ok ? "text-[#8cebb5]" : "text-red-300")}>{ok ? <CheckCircle2 size={10} /> : <XCircle size={10} />} {value}</span>
                </div>
              ))}
              <div className="rounded-lg border border-white/[0.06] bg-black/25 px-2.5 py-2 text-[9px] leading-5 text-[#74747e]">
                لا يُرفع الفيديو أو الصوت إلى خادم. الترميز يجري في جهازك. أول زيارة قد تحتاج إنترنت لتحميل الخطوط العربية فقط.
              </div>
            </div>
          </div>

          <div className="panel p-3.5">
            <h3 className="mb-2 flex items-center gap-1.5 font-display text-[14px] font-bold text-white"><Timer size={14} className="text-[#d9b65a]" /> قبل الضغط على «إنشاء الفيديو»</h3>
            <ul className="space-y-1.5 text-[10px] leading-5 text-[#85858f]">
              <li className="flex gap-1.5"><CheckCircle2 size={11} className="mt-0.5 shrink-0 text-[#6fe0a4]" /> شاهد المعاينة كاملة وتأكد من تزامن الصوت.</li>
              <li className="flex gap-1.5"><CheckCircle2 size={11} className="mt-0.5 shrink-0 text-[#6fe0a4]" /> أغلق التطبيقات الثقيلة على الهاتف؛ التصدير يستهلك المعالج.</li>
              <li className="flex gap-1.5"><CheckCircle2 size={11} className="mt-0.5 shrink-0 text-[#6fe0a4]" /> لا تغلق الصفحة أثناء التصدير. يمكنك الإلغاء بأمان.</li>
              <li className="flex gap-1.5"><CheckCircle2 size={11} className="mt-0.5 shrink-0 text-[#6fe0a4]" /> بعد النجاح نزّل الملف وتأكد من وجود الصوت في مشغل الجهاز.</li>
            </ul>
            <div className="mt-2.5 flex items-center justify-between rounded-lg border border-white/[0.06] bg-black/25 px-2.5 py-1.5 text-[9px]">
              <span className="text-[#7f7f89]">المساحة التخزينية المتاحة</span>
              <span dir="ltr" className="text-[#c6c6cf]">{storage ? formatBytes(storage.available) : "غير معروفة"}</span>
            </div>
            <div className="mt-2">
              <Toggle checked={project.timing.requireAudio} onChange={(value) => updateProject((current) => ({ ...current, timing: { ...current.timing, requireAudio: value } }))} label="اشتراط وجود الصوت" hint="منع التصدير عند غياب صوت أي سؤال." />
            </div>
            {estimatedBytes > (storage?.available ?? Infinity) ? (
              <div className="mt-2 rounded-lg border border-red-400/20 bg-red-400/[0.05] px-2.5 py-2 text-[9px] leading-5 text-red-200">الحجم المتوقع أكبر من المساحة المتاحة. فرّغ مساحة قبل التنزيل.</div>
            ) : null}
          </div>

          <div className="panel p-3.5">
            <h3 className="mb-2 font-display text-[14px] font-bold text-white">نموذج المشهد</h3>
            <SceneCanvas questionIndex={Math.min(1, project.questions.length - 1)} stage="reveal" className="max-w-[190px]" />
            <p className="mt-2 text-center text-[9px] text-[#73737d]">يُصدَّر بنفس هذا المظهر بما فيه الخلفية والحركة.</p>
            <div className="mt-2.5 flex gap-1.5">
              <Button variant="ghost" className="flex-1 !py-1.5 text-[10px]" onClick={() => onNavigate("preview")}><Video size={11} /> معاينة</Button>
              <Button variant="ghost" className="flex-1 !py-1.5 text-[10px]" onClick={() => onNavigate("design")}><Sparkles size={11} /> التصميم</Button>
            </div>
          </div>

          <div className="rounded-xl border border-white/[0.07] bg-white/[0.015] p-3 text-[9px] leading-5 text-[#74747e]">
            <Info size={11} className="ml-1 inline" /> حدود هذه النسخة: تصدير محلي حتى 6 دقائق أو 10800 إطار. لا يوجد ترميز عبر خادم، لذلك الأجهزة التي لا تدعم H.264 لا يمكنها إنتاج MP4 هنا؛ استخدم متصفحًا مدعومًا.
          </div>
        </aside>
      </div>

      {exporting || progress.phase === "done" && !result ? (
        <div className="fixed inset-0 z-[85] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-white/10 bg-[#101014] shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#d9b65a]/10 text-[#e7cf94]"><Loader2 size={16} className="animate-spin" /></span>
                <div>
                  <p className="text-[12px] font-semibold text-white">تصدير الفيديو</p>
                  <p className="text-[9px] text-[#83838d]">{PHASE_LABELS[progress.phase]}</p>
                </div>
              </div>
              <button type="button" onClick={cancel} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-[10px] text-[#b9b9c2] transition hover:border-red-400/30 hover:text-red-200">إلغاء بأمان</button>
            </div>
            <div className="px-4 py-4">
              <div className="mb-1 flex items-end justify-between">
                <p className="text-[12px] font-semibold text-[#eeeef2]">{progress.label}</p>
                <span className="font-display text-[20px] font-bold tabular-nums text-[#e7cf94]">{Math.round(progress.percent)}%</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-gradient-to-l from-[#e7cf94] via-[#d9b65a] to-[#a9853d] transition-[width] duration-300" style={{ width: `${Math.max(1, progress.percent)}%` }} />
              </div>
              {progress.detail ? <p className="mt-1.5 truncate text-[10px] text-[#85858f]">{progress.detail}</p> : null}
              <div className="mt-3 space-y-1.5">
                {stepLabels.map((step, index) => {
                  const current = stepIndex[progress.phase] ?? 0;
                  const done = index < current || progress.phase === "done";
                  const active = index === current;
                  return (
                    <div key={step.key} className="flex items-center gap-2 text-[10px]">
                      <span className={cn("flex h-4 w-4 items-center justify-center rounded-full border", done ? "border-[#57dc96]/40 bg-[#57dc96]/15 text-[#8cebb5]" : active ? "border-[#d9b65a]/50 text-[#e7cf94]" : "border-white/10 text-[#5f5f69]")}>
                        {done ? <CheckCircle2 size={9} /> : active ? <Loader2 size={9} className="animate-spin" /> : <span className="h-1 w-1 rounded-full bg-current" />}
                      </span>
                      <span className={done ? "text-[#a7d9bd]" : active ? "text-[#f0dfb4]" : "text-[#6f6f79]"}>{step.label}</span>
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 flex items-center justify-between rounded-lg border border-white/[0.06] bg-black/25 px-2.5 py-1.5 text-[9px] text-[#7f7f89]">
                <span>{settings.width}×{settings.height} · {settings.fps} إطار/ث</span>
                <span>{progress.etaSeconds ? `متبقٍ ~${progress.etaSeconds} ث` : "جارٍ التنفيذ…"}</span>
              </div>
              <p className="mt-2 text-[9px] leading-5 text-[#6f6f79]">لا تُغلق الصفحة. عند الإلغاء يتوقف الترميز ولا يُنشأ ملف جزئي. سيُعلن النجاح فقط بعد التحقق من مساري الفيديو والصوت.</p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
