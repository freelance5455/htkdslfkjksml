import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { format } from "date-fns";
import { ArrowLeft, CalendarDays, MapPin, ThumbsUp } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import CityMap from "@/components/CityMap";
import StatusPill from "@/components/StatusPill";
import CategoryChip from "@/components/CategoryChip";
import ReportTimeline from "@/components/ReportTimeline";
import StatusUpdateForm from "@/components/StatusUpdateForm";
import { statusMeta, reportDate } from "@/lib/reportStats";

const STEPS = ["reported", "in_progress", "resolved"];

export default function IssueDetail() {
  const { id } = useParams();
  const [report, setReport] = useState(null);
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);

  const load = useCallback(async () => {
    try {
      const record = await base44.entities.IssueReport.get(id);
      setReport(record);
      const page = await base44.entities.IssueUpdate.filter(
        { report_id: id },
        { sort: "created_date", limit: 50 }
      );
      setUpdates(page?.items || []);
    } catch (err) {
      setMissing(true);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-border border-t-primary" />
      </div>
    );
  }

  if (missing || !report) {
    return (
      <div className="mx-auto max-w-xl px-5 py-24 text-center">
        <p className="font-display text-2xl font-semibold">This report isn&apos;t on the board</p>
        <p className="mt-2 text-sm text-muted-foreground">
          It may have been removed. The rest of the board is still there.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to the board
        </Link>
      </div>
    );
  }

  const stepIndex = STEPS.indexOf(report.status);

  return (
    <div className="mx-auto max-w-5xl px-5 py-10 lg:px-8">
      <Link
        to="/"
        className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back to the board
      </Link>

      <div className="mt-5 flex flex-wrap items-center gap-2.5">
        <StatusPill status={report.status} />
        <CategoryChip category={report.category} />
        {report.priority === "high" && (
          <span className="rounded-full border border-[#EDD3CB] bg-[#FBEBE6] px-2.5 py-1 text-[11px] font-medium text-[#8E3B24]">
            Urgent
          </span>
        )}
      </div>

      <h1 className="mt-4 max-w-3xl font-display text-3xl font-semibold leading-tight tracking-tight sm:text-[2.6rem]">
        {report.title}
      </h1>

      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5" />
          {report.address || report.area}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <CalendarDays className="h-3.5 w-3.5" />
          {reportDate(report) ? format(new Date(reportDate(report)), "d MMM yyyy") : ""}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <ThumbsUp className="h-3.5 w-3.5" />
          {report.supports || 0} residents backed this
        </span>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="space-y-6">
          <div className="overflow-hidden rounded-2xl border border-border bg-card">
            {report.photo_url ? (
              <Image
                src={report.photo_url}
                alt={report.title}
                fittingType="fill"
                className="h-72 w-full sm:h-96"
              />
            ) : (
              <div className="flex h-56 items-center justify-center bg-secondary text-sm text-muted-foreground">
                No photo attached
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="font-display text-base font-semibold">What was reported</h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
              {report.description || "No extra detail was added."}
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-2">
            <CityMap reports={[report]} height={280} />
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border border-border bg-card p-6">
            <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
              Progress
            </p>
            <div className="mt-4 space-y-3">
              {STEPS.map((step, index) => {
                const meta = statusMeta(step);
                const done = index <= stepIndex;
                return (
                  <div key={step} className="flex items-center gap-3">
                    <span
                      className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold text-white"
                      style={{ backgroundColor: done ? meta.color : "hsl(var(--muted))" }}
                    >
                      {index + 1}
                    </span>
                    <span
                      className={
                        done ? "text-sm font-medium text-foreground" : "text-sm text-muted-foreground"
                      }
                    >
                      {meta.label}
                    </span>
                  </div>
                );
              })}
            </div>

            {report.assigned_crew && (
              <p className="mt-5 rounded-xl bg-secondary/70 p-3 text-xs text-muted-foreground">
                Crew on site: <span className="font-medium text-foreground">{report.assigned_crew}</span>
              </p>
            )}
            {report.resolution_note && (
              <p className="mt-3 rounded-xl border border-[#C4E3D1] bg-[#E9F5EE] p-3 text-xs leading-relaxed text-[#14603C]">
                {report.resolution_note}
              </p>
            )}
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
              Timeline
            </p>
            <div className="mt-4">
              <ReportTimeline report={report} updates={updates} />
            </div>
          </div>

          <StatusUpdateForm report={report} onUpdated={load} />
        </div>
      </div>
    </div>
  );
}