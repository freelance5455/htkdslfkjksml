import { useState } from "react";
import {
  ArrowLeft,
  Brush,
  Check,
  Eye,
  Image as ImageIcon,
  LayoutTemplate,
  MonitorSmartphone,
  Move,
  Palette,
  RotateCcw,
  Save,
  Sparkles,
  Timer,
  Trash2,
  Type,
  Wand2,
  Zap,
} from "lucide-react";
import type { DesignConfig, FontKey, ViewKey } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { ASPECT_PRESETS, FONT_OPTIONS, defaultDesign } from "@/data/defaults";
import { MediaPicker } from "@/components/MediaPicker";
import { SceneCanvas, type PreviewStage } from "@/components/PreviewSurface";
import { Button, ColorField, ConfirmDialog, Field, Input, InlineNotice, Modal, SectionHeader, Segmented, Select, Toggle } from "@/components/ui";
import { cn } from "@/utils/cn";

type Tab = "background" | "type" | "options" | "timer" | "motion" | "brand";

const TABS: { key: Tab; label: string; icon: typeof Palette }[] = [
  { key: "background", label: "الخلفية", icon: ImageIcon },
  { key: "type", label: "النصوص", icon: Type },
  { key: "options", label: "الخيارات", icon: Palette },
  { key: "timer", label: "المؤقت", icon: Timer },
  { key: "motion", label: "الحركة", icon: Zap },
  { key: "brand", label: "الهوية والحفظ", icon: Sparkles },
];

function SliderInput({ label, value, min, max, step = 1, unit, onChange }: { label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (value: number) => void }) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <span className="text-[11px] text-[#a9a9b3]">{label}</span>
        <div className="flex items-center gap-1">
          <input
            type="number"
            value={Number.isFinite(value) ? value : 0}
            min={min}
            max={max}
            step={step}
            onChange={(event) => onChange(Math.max(min, Math.min(max, Number(event.target.value) || 0)))}
            className="w-16 rounded-md border border-white/10 bg-[#0a0a0d] px-1.5 py-1 text-left text-[10px] text-white outline-none focus:border-[#d9b65a]/50"
            dir="ltr"
            aria-label={`${label} قيمة دقيقة`}
          />
          {unit ? <span className="text-[9px] text-[#74747e]">{unit}</span> : null}
        </div>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} className="range w-full" style={{ "--fill": `${((value - min) / Math.max(0.01, max - min)) * 100}%` } as React.CSSProperties} aria-label={label} />
    </div>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-b border-white/[0.06] pb-3.5 last:border-0 last:pb-0">
      <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#787882]">{title}</p>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

export function DesignStudio({ onNavigate }: { onNavigate: (view: ViewKey) => void }) {
  const { project, updateProject, toast } = useStudio();
  const [tab, setTab] = useState<Tab>("background");
  const [stage, setStage] = useState<PreviewStage>("thinking");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [dragTarget, setDragTarget] = useState<"content" | "timer" | null>(null);
  const [warn, setWarn] = useState<string | null>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [presetOpen, setPresetOpen] = useState(false);
  const [presetName, setPresetName] = useState("");
  const design = project.design;

  const patchDesign = (updater: (design: DesignConfig) => DesignConfig) => {
    updateProject((current) => ({ ...current, design: updater(current.design) }));
  };
  const patchBg = (patch: Partial<DesignConfig["background"]>) => patchDesign((current) => ({ ...current, background: { ...current.background, ...patch } }));
  const patchType = (patch: Partial<DesignConfig["typography"]>) => patchDesign((current) => ({ ...current, typography: { ...current.typography, ...patch } }));
  const patchOptions = (patch: Partial<DesignConfig["options"]>) => patchDesign((current) => ({ ...current, options: { ...current.options, ...patch } }));
  const patchTimer = (patch: Partial<DesignConfig["timer"]>) => patchDesign((current) => ({ ...current, timer: { ...current.timer, ...patch } }));
  const patchContent = (patch: Partial<DesignConfig["content"]>) => patchDesign((current) => ({ ...current, content: { ...current.content, ...patch } }));
  const patchBrand = (patch: Partial<DesignConfig["brand"]>) => patchDesign((current) => ({ ...current, brand: { ...current.brand, ...patch } }));
  const patchMotion = (patch: Partial<DesignConfig["motion"]>) => patchDesign((current) => ({ ...current, motion: { ...current.motion, ...patch } }));

  const changeAspect = (aspect: "vertical" | "landscape" | "square") => {
    const preset = ASPECT_PRESETS[aspect];
    updateProject((current) => ({
      ...current,
      exportSettings: { ...current.exportSettings, aspect, width: preset.width, height: preset.height },
    }));
    setWarn("تغيّر مقاس الفيديو. راجع مواضع المحتوى والمؤقت جيدًا قبل التصدير.");
    toast(`تم تحويل المقاس إلى ${preset.width}×${preset.height}. التصميم يُعاد تخطيطه تلقائيًا، ويمكنك تعديل المواضع.`, "info");
  };

  const applyPreset = (preset: DesignConfig, name: string) => {
    patchDesign(() => ({ ...structuredClone(preset), presetName: name }));
    toast(`طُبّق قالب «${name}».`, "success");
  };

  const savePreset = () => {
    if (!presetName.trim()) return;
    updateProject((current) => ({
      ...current,
      design: { ...current.design, presetName: presetName.trim() },
      designPresets: [
        ...current.designPresets,
        { id: `preset_${Date.now()}`, name: presetName.trim(), design: structuredClone({ ...current.design, presetName: presetName.trim() }) },
      ],
    }));
    setPresetOpen(false);
    setPresetName("");
    toast("حُفظ التصميم كقالب داخل المشروع لإعادة استخدامه.", "success");
  };

  return (
    <div>
      <SectionHeader
        icon={<LayoutTemplate size={18} />}
        eyebrow="الاستوديو البصري"
        title="تصميم فيديو المسابقة"
        description="خصّص كل تفصيل وشاهد النتيجة مباشرة. المواضع تُحفظ كنِسب مئوية لتبقى متسقة بين المقاسات والمتصفحات."
        actions={
          <>
            <Button variant="ghost" onClick={() => setResetOpen(true)}><RotateCcw size={14} /> الافتراضي</Button>
            <Button variant="ghost" onClick={() => setPresetOpen(true)}><Save size={14} /> حفظ كقالب</Button>
            <Button variant="primary" onClick={() => onNavigate("preview")}><Eye size={14} /> معاينة كاملة</Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-[1.1fr_1fr]">
        <section className="panel overflow-hidden xl:sticky xl:top-[76px] xl:self-start">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.07] px-3.5 py-3">
            <div className="flex items-center gap-1.5">
              <span className="flex h-6 w-6 items-center justify-center rounded-md bg-[#d9b65a]/10 text-[#e7cf94]"><MonitorSmartphone size={13} /></span>
              <span className="text-[11px] font-semibold text-[#e5e5ea]">معاينة مباشرة</span>
              <span className="text-[9px] text-[#6f6f79]">{project.exportSettings.width}×{project.exportSettings.height}</span>
            </div>
            <div className="flex items-center gap-1">
              {(["vertical", "landscape", "square"] as const).map((aspect) => (
                <button
                  key={aspect}
                  type="button"
                  onClick={() => changeAspect(aspect)}
                  className={cn("rounded-md border px-1.5 py-1 text-[9px] transition", project.exportSettings.aspect === aspect ? "border-[#d9b65a]/35 bg-[#d9b65a]/10 text-[#e7cf94]" : "border-white/10 text-[#85858f] hover:text-white")}
                >
                  {ASPECT_PRESETS[aspect].label}
                </button>
              ))}
            </div>
          </div>
          <div className="bg-[#070708] p-3 sm:p-5">
            <div className={cn("mx-auto", stage === "reveal" ? "max-w-[300px]" : "max-w-[320px]")}>
              <SceneCanvas
                questionIndex={Math.min(questionIndex, Math.max(0, project.questions.length - 1))}
                stage={stage}
                handles={Boolean(dragTarget)}
                dragTarget={dragTarget}
                onWarn={setWarn}
                onDrag={(x, y) => {
                  if (dragTarget === "content") patchContent({ x, y });
                  else if (dragTarget === "timer") patchTimer({ x, y });
                }}
              />
            </div>
            <div className="mx-auto mt-3 max-w-[420px] space-y-2">
              <Segmented
                size="sm"
                value={stage}
                onChange={(value) => setStage(value)}
                options={[
                  { value: "question", label: "السؤال" },
                  { value: "options", label: "الخيارات" },
                  { value: "thinking", label: "التفكير" },
                  { value: "reveal", label: "الإجابة" },
                ]}
              />
              <div className="flex flex-wrap items-center justify-between gap-1.5">
                <div className="flex items-center gap-1">
                  <button type="button" onClick={() => setQuestionIndex((index) => Math.max(0, index - 1))} disabled={questionIndex <= 0} className="rounded-md border border-white/10 px-2 py-1 text-[10px] text-[#b9b9c2] disabled:opacity-30">السابق</button>
                  <span className="px-1 text-[10px] text-[#8a8a94]">سؤال {questionIndex + 1} / {project.questions.length}</span>
                  <button type="button" onClick={() => setQuestionIndex((index) => Math.min(project.questions.length - 1, index + 1))} disabled={questionIndex >= project.questions.length - 1} className="rounded-md border border-white/10 px-2 py-1 text-[10px] text-[#b9b9c2] disabled:opacity-30">التالي</button>
                </div>
                <div className="flex items-center gap-1">
                  <button type="button" onClick={() => setDragTarget(dragTarget === "content" ? null : "content")} className={cn("flex items-center gap-1 rounded-md border px-2 py-1 text-[10px]", dragTarget === "content" ? "border-[#d9b65a]/40 bg-[#d9b65a]/10 text-[#e7cf94]" : "border-white/10 text-[#9c9ca6]")}>
                    <Move size={11} /> المحتوى
                  </button>
                  <button type="button" onClick={() => setDragTarget(dragTarget === "timer" ? null : "timer")} className={cn("flex items-center gap-1 rounded-md border px-2 py-1 text-[10px]", dragTarget === "timer" ? "border-[#57dc96]/40 bg-[#57dc96]/10 text-[#9ef0c1]" : "border-white/10 text-[#9c9ca6]")}>
                    <Timer size={11} /> المؤقت
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-white/[0.07] bg-white/[0.02] px-2.5 py-1.5 text-[9px] text-[#85858f]">
                <span>المحتوى: <span dir="ltr" className="text-[#c9c9d1]">{Math.round(design.content.x)}%, {Math.round(design.content.y)}%</span></span>
                <span>المؤقت: <span dir="ltr" className="text-[#c9c9d1]">{Math.round(design.timer.x)}%, {Math.round(design.timer.y)}%</span></span>
                <button type="button" onClick={() => { patchContent({ x: 50, y: 47 }); patchTimer({ x: 50, y: 89 }); setWarn(null); }} className="text-[#d9c187] hover:text-white">إعادة الموضع</button>
              </div>
            </div>
          </div>
          {warn ? (
            <div className="border-t border-white/[0.07] px-3.5 py-2.5">
              <InlineNotice kind="warning" title="حدود الفيديو"><span>{warn}</span></InlineNotice>
            </div>
          ) : null}
          <div className="flex items-center justify-between border-t border-white/[0.07] px-3.5 py-2.5">
            <p className="text-[9px] text-[#6f6f79]">المعاينة تستخدم نفس محرك الرسم والخطوط في MP4.</p>
            <div className="flex items-center gap-1.5 text-[9px] text-[#7d7d87]"><span className="h-1.5 w-1.5 rounded-full bg-[#57dc96]" /> يحفظ تلقائيًا</div>
          </div>
        </section>

        <section className="panel overflow-hidden">
          <div className="mobile-hide-scroll flex gap-0.5 overflow-x-auto border-b border-white/[0.07] p-1.5">
            {TABS.map((item) => (
              <button
                key={item.key}
                type="button"
                onClick={() => setTab(item.key)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-[10px] font-medium transition",
                  tab === item.key ? "bg-white/[0.08] text-white" : "text-[#85858f] hover:text-white",
                )}
              >
                <item.icon size={12} /> {item.label}
              </button>
            ))}
          </div>
          <div className="max-h-[calc(100dvh-210px)] overflow-y-auto p-3.5 sm:p-4">
            {tab === "background" ? (
              <div className="space-y-3.5">
                <Group title="نوع الخلفية">
                  <Segmented
                    size="sm"
                    value={design.background.kind}
                    onChange={(value) => patchBg({ kind: value })}
                    options={[{ value: "gradient", label: "تدرج لوني" }, { value: "color", label: "لون ثابت" }]}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <ColorField label="اللون الأول" value={design.background.colorA} onChange={(value) => patchBg({ colorA: value })} />
                    {design.background.kind === "gradient" ? <ColorField label="اللون الثاني" value={design.background.colorB} onChange={(value) => patchBg({ colorB: value })} /> : null}
                  </div>
                  {design.background.kind === "gradient" ? (
                    <SliderInput label="زاوية التدرج" value={design.background.angle} min={0} max={360} unit="°" onChange={(value) => patchBg({ angle: value })} />
                  ) : null}
                </Group>
                <Group title="صورة خلفية عامة">
                  <MediaPicker
                    label="خلفية التصميم"
                    hint="تُستخدم لكل الأسئلة التي لا تحتوي صورة خاصة."
                    kind="image"
                    value={design.background.imageId}
                    onSelect={(id) => patchBg({ imageId: id })}
                    onRemove={() => patchBg({ imageId: null })}
                    compact
                  />
                  <SliderInput label="تعتيم الصورة" value={design.background.overlay} min={10} max={92} unit="%" onChange={(value) => patchBg({ overlay: value })} />
                </Group>
                <Group title="إضاءة وتفاصيل">
                  <Toggle checked={design.background.glow} onChange={(value) => patchBg({ glow: value })} label="إضاءة ذهبية محيطية" hint="توهج ناعم في الزوايا يضيف عمقًا للخلفية." />
                  <Toggle checked={design.background.grid} onChange={(value) => patchBg({ grid: value })} label="شبكة خفيفة" hint="خطوط دقيقة جدًا لا تؤثر على وضوح النص." />
                </Group>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { label: "ليلي ذهبي", a: "#0b0d12", b: "#1b1710" },
                    { label: "زمردي", a: "#06120f", b: "#12241c" },
                    { label: "ملكي", a: "#0d0917", b: "#241238" },
                    { label: "رمادي فاخر", a: "#0c0d10", b: "#22232a" },
                    { label: "عنّابي", a: "#160b0f", b: "#2c1219" },
                    { label: "أزرق هادئ", a: "#08111c", b: "#10283d" },
                  ].map((preset) => (
                    <button key={preset.label} type="button" onClick={() => patchBg({ kind: "gradient", colorA: preset.a, colorB: preset.b })} className="group overflow-hidden rounded-lg border border-white/10 text-right transition hover:border-[#d9b65a]/40">
                      <span className="block h-8 w-full" style={{ background: `linear-gradient(155deg, ${preset.a}, ${preset.b})` }} />
                      <span className="block bg-black/30 px-1.5 py-1 text-[8px] text-[#a9a9b3]">{preset.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : null}

            {tab === "type" ? (
              <div className="space-y-3.5">
                <Group title="الخط العربي">
                  <Field label="عائلة الخط">
                    <Select value={design.typography.font} onChange={(event) => patchType({ font: event.target.value as FontKey })}>
                      {FONT_OPTIONS.map((font) => <option key={font.key} value={font.key}>{font.label}</option>)}
                    </Select>
                  </Field>
                  <div className="rounded-xl border border-white/[0.07] bg-black/25 px-3 py-3 text-center" style={{ fontFamily: `"${design.typography.font}", sans-serif` }}>
                    <p className="text-[18px] text-white">أسئلة عربية واضحة</p>
                    <p className="mt-1 text-[10px] text-[#8e8e98]">أ ب ج د · ٠١٢٣٤٥٦٧٨٩</p>
                  </div>
                </Group>
                <Group title="أحجام وأوزان">
                  <SliderInput label="حجم نص السؤال" value={design.typography.questionSize} min={28} max={96} unit="px" onChange={(value) => patchType({ questionSize: value })} />
                  <SliderInput label="حجم الخيارات" value={design.typography.optionSize} min={18} max={56} unit="px" onChange={(value) => patchType({ optionSize: value })} />
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="label">وزن السؤال</span>
                      <Segmented size="sm" value={String(design.typography.questionWeight)} onChange={(value) => patchType({ questionWeight: Number(value) })} options={[{ value: "500", label: "متوسط" }, { value: "700", label: "عريض" }, { value: "800", label: "أثقل" }]} />
                    </div>
                    <div>
                      <span className="label">وزن الخيارات</span>
                      <Segmented size="sm" value={String(design.typography.optionWeight)} onChange={(value) => patchType({ optionWeight: Number(value) })} options={[{ value: "400", label: "عادي" }, { value: "500", label: "متوسط" }, { value: "700", label: "عريض" }]} />
                    </div>
                  </div>
                  <SliderInput label="تباعد الأسطر" value={design.typography.lineHeight} min={1} max={1.8} step={0.05} onChange={(value) => patchType({ lineHeight: value })} />
                  <Segmented size="sm" value={design.typography.align} onChange={(value) => patchType({ align: value })} options={[{ value: "center", label: "توسيط" }, { value: "right", label: "محاذاة يمين" }]} />
                </Group>
                <Group title="الألوان">
                  <div className="grid grid-cols-2 gap-2">
                    <ColorField label="لون السؤال" value={design.typography.questionColor} onChange={(value) => patchType({ questionColor: value })} />
                    <ColorField label="لون الخيارات" value={design.typography.optionColor} onChange={(value) => patchType({ optionColor: value })} />
                  </div>
                </Group>
              </div>
            ) : null}

            {tab === "options" ? (
              <div className="space-y-3.5">
                <Group title="بطاقات الخيارات">
                  <SliderInput label="المسافة بين الخيارات" value={design.options.gap} min={4} max={48} unit="px" onChange={(value) => patchOptions({ gap: value })} />
                  <SliderInput label="استدارة الحواف" value={design.options.radius} min={0} max={48} unit="px" onChange={(value) => patchOptions({ radius: value })} />
                  <SliderInput label="الحشوة الداخلية" value={design.options.padding} min={8} max={48} unit="px" onChange={(value) => patchOptions({ padding: value })} />
                  <SliderInput label="شفافية التعبئة" value={design.options.fillOpacity} min={0} max={70} unit="%" onChange={(value) => patchOptions({ fillOpacity: value })} />
                  <div className="grid grid-cols-2 gap-2">
                    <ColorField label="لون البطاقة" value={design.options.fill} onChange={(value) => patchOptions({ fill: value })} />
                    <ColorField label="لون الحدود" value={design.options.borderColor} onChange={(value) => patchOptions({ borderColor: value })} />
                  </div>
                  <SliderInput label="سماكة الحدود" value={design.options.borderWidth} min={0} max={4} step={0.5} unit="px" onChange={(value) => patchOptions({ borderWidth: value })} />
                  <Toggle checked={design.options.shadow} onChange={(value) => patchOptions({ shadow: value })} label="ظل ناعم للبطاقات" />
                  <div>
                    <span className="label">أحرف الخيارات</span>
                    <Segmented size="sm" value={design.options.letters} onChange={(value) => patchOptions({ letters: value })} options={[{ value: "arabic", label: "أ ب ج د" }, { value: "latin", label: "A B C D" }, { value: "numbers", label: "1 2 3 4" }, { value: "none", label: "بدون" }]} />
                  </div>
                </Group>
                <Group title="كشف الإجابة الصحيحة">
                  <ColorField label="لون الإجابة الصحيحة" value={design.options.correctColor} onChange={(value) => patchOptions({ correctColor: value })} />
                  <SliderInput label="شفافية الخيارات الأخرى" value={design.options.dimOpacity} min={15} max={100} unit="%" onChange={(value) => patchOptions({ dimOpacity: value })} />
                  <Toggle checked={design.options.showCheck} onChange={(value) => patchOptions({ showCheck: value })} label="علامة ✓ بجانب الإجابة" hint="تحل محل حرف الخيار عند ظهور الحالة الخضراء." />
                  <div className="flex gap-1.5">
                    {["#35D68B", "#7AF0AE", "#2EC27E", "#B7F34C"].map((color) => (
                      <button key={color} type="button" onClick={() => patchOptions({ correctColor: color })} className={cn("h-7 flex-1 rounded-md border-2 transition", design.options.correctColor.toLowerCase() === color.toLowerCase() ? "border-white" : "border-transparent")} style={{ background: color }} aria-label={`لون إجابة ${color}`} />
                    ))}
                  </div>
                </Group>
              </div>
            ) : null}

            {tab === "timer" ? (
              <div className="space-y-3.5">
                <Group title="المؤقت">
                  <Toggle checked={design.timer.visible} onChange={(value) => patchTimer({ visible: value })} label="إظهار المؤقت" hint="يظهر أثناء التفكير ويتحول لعلامة ✓ عند كشف الإجابة." />
                  <Segmented size="sm" value={design.timer.style} onChange={(value) => patchTimer({ style: value })} options={[{ value: "ring", label: "دائري" }, { value: "pill", label: "كبسولة" }, { value: "bar", label: "شريط" }]} />
                  <SliderInput label="حجم المؤقت" value={design.timer.size} min={40} max={180} unit="px" onChange={(value) => patchTimer({ size: value })} />
                  <div className="grid grid-cols-2 gap-2">
                    <ColorField label="لون المؤقت" value={design.timer.color} onChange={(value) => patchTimer({ color: value })} />
                    <ColorField label="لون المسار" value={design.timer.trackColor} onChange={(value) => patchTimer({ trackColor: value })} />
                  </div>
                </Group>
                <Group title="الموضع الدقيق">
                  <SliderInput label="الموضع الأفقي X" value={design.timer.x} min={5} max={95} step={0.5} unit="%" onChange={(value) => patchTimer({ x: value })} />
                  <SliderInput label="الموضع الرأسي Y" value={design.timer.y} min={8} max={92} step={0.5} unit="%" onChange={(value) => patchTimer({ y: value })} />
                  <p className="text-[10px] leading-5 text-[#7c7c86]">يمكنك أيضًا اختيار زر «المؤقت» فوق المعاينة وسحبه بإصبعك. المواضع تبقى ضمن حدود الفيديو.</p>
                </Group>
                <Group title="بطاقة السؤال">
                  <Toggle checked={design.content.showCard} onChange={(value) => patchContent({ showCard: value })} label="خلفية شفافة لنص السؤال" />
                  <Toggle checked={design.content.showQuestionNumber} onChange={(value) => patchContent({ showQuestionNumber: value })} label="إظهار رقم السؤال" />
                  <SliderInput label="عرض المحتوى" value={design.content.width} min={55} max={94} unit="%" onChange={(value) => patchContent({ width: value })} />
                  <SliderInput label="الموضع الأفقي X" value={design.content.x} min={5} max={95} step={0.5} unit="%" onChange={(value) => patchContent({ x: value })} />
                  <SliderInput label="الموضع الرأسي Y" value={design.content.y} min={8} max={92} step={0.5} unit="%" onChange={(value) => patchContent({ y: value })} />
                </Group>
              </div>
            ) : null}

            {tab === "motion" ? (
              <div className="space-y-3.5">
                <Group title="الحركة والانتقال">
                  <div>
                    <span className="label">دخول الخيارات</span>
                    <Segmented size="sm" value={design.motion.entrance} onChange={(value) => patchMotion({ entrance: value })} options={[{ value: "rise", label: "ارتفاع" }, { value: "fade", label: "تلاشي" }, { value: "slide", label: "انزلاق" }, { value: "zoom", label: "تكبير" }]} />
                  </div>
                  <div>
                    <span className="label">حركة كشف الإجابة</span>
                    <Segmented size="sm" value={design.motion.reveal} onChange={(value) => patchMotion({ reveal: value })} options={[{ value: "glow", label: "توهج أخضر" }, { value: "pulse", label: "نبضة" }, { value: "none", label: "بدون" }]} />
                  </div>
                  <div>
                    <span className="label">انتقال المشاهد</span>
                    <Segmented size="sm" value={design.motion.transition} onChange={(value) => patchMotion({ transition: value })} options={[{ value: "fade", label: "تلاشي" }, { value: "slide", label: "انزلاق" }, { value: "zoom", label: "تقريب" }, { value: "none", label: "بدون" }]} />
                  </div>
                  <SliderInput label="سرعة الحركة" value={design.motion.speed} min={0.5} max={2} step={0.1} onChange={(value) => patchMotion({ speed: value })} />
                  <InlineNotice kind="info" title="توقيت الكشف ثابت">الحركة تُطبَّق بصريًا فقط؛ لحظة ظهور اللون الأخضر تبقى مطابقة للخط الزمني في المعاينة والملف.</InlineNotice>
                </Group>
              </div>
            ) : null}

            {tab === "brand" ? (
              <div className="space-y-3.5">
                <Group title="الهوية">
                  <Toggle checked={design.brand.show} onChange={(value) => patchBrand({ show: value })} label="إظهار اسم الاستوديو والترقيم" />
                  <Field label="نص العلامة">
                    <Input value={design.brand.text} onChange={(event) => patchBrand({ text: event.target.value.slice(0, 40) })} placeholder="QUIZ STUDIO" />
                  </Field>
                  <SliderInput label="شفافية العلامة" value={design.brand.opacity} min={20} max={100} unit="%" onChange={(value) => patchBrand({ opacity: value })} />
                  <Toggle checked={design.brand.showProgress} onChange={(value) => patchBrand({ showProgress: value })} label="شريط تقدم أعلى الفيديو" />
                  <MediaPicker label="شعار / علامة مائية" kind="image" value={design.brand.logoId} onSelect={(id) => patchBrand({ logoId: id })} onRemove={() => patchBrand({ logoId: null })} compact />
                </Group>
                <Group title="قوالب المشروع">
                  <div className="space-y-1.5">
                    {project.designPresets.map((preset) => (
                      <div key={preset.id} className="flex items-center gap-2 rounded-lg border border-white/[0.07] bg-white/[0.02] p-2">
                        <span className="h-7 w-7 shrink-0 rounded-md border border-white/10" style={{ background: `linear-gradient(155deg, ${preset.design.background.colorA}, ${preset.design.background.colorB})` }} />
                        <span className="min-w-0 flex-1 truncate text-[10px] text-[#d5d5dc]">{preset.name}</span>
                        <button type="button" onClick={() => applyPreset(preset.design, preset.name)} className="rounded-md border border-white/10 px-2 py-1 text-[9px] text-[#c9c9d1] hover:border-[#d9b65a]/30 hover:text-[#e7cf94]">تطبيق</button>
                        <button
                          type="button"
                          onClick={() => updateProject((current) => ({ ...current, designPresets: current.designPresets.filter((entry) => entry.id !== preset.id) }))}
                          className="rounded-md p-1 text-[#74747e] hover:text-red-300"
                          aria-label={`حذف القالب ${preset.name}`}
                        >
                          <Trash2 size={11} />
                        </button>
                      </div>
                    ))}
                    {project.designPresets.length === 0 ? <p className="rounded-lg border border-dashed border-white/10 px-2 py-3 text-center text-[10px] text-[#7c7c86]">لا توجد قوالب محفوظة.</p> : null}
                  </div>
                  <Button variant="ghost" className="w-full !py-2 text-[11px]" onClick={() => setPresetOpen(true)}><Save size={13} /> حفظ التصميم الحالي كقالب</Button>
                </Group>
                <div className="rounded-lg border border-white/[0.07] bg-black/25 p-2.5">
                  <p className="flex items-center gap-1.5 text-[10px] font-medium text-[#c9c9d1]"><Wand2 size={12} className="text-[#d9b65a]" /> التصميم الحالي: {design.presetName}</p>
                  <p className="mt-1 text-[9px] leading-5 text-[#7c7c86]">كل تغيير يُحفظ تلقائيًا مع المشروع. يبقى التصدير مطابقًا للمعاينة.</p>
                </div>
              </div>
            ) : null}
          </div>
          <div className="flex items-center justify-between gap-2 border-t border-white/[0.07] px-3.5 py-2.5">
            <button type="button" onClick={() => setResetOpen(true)} className="flex items-center gap-1 text-[10px] text-[#8a8a94] hover:text-white"><RotateCcw size={11} /> إعادة الافتراضي</button>
            <div className="flex items-center gap-1.5">
              <Button variant="quiet" className="!px-2 !py-1.5 text-[10px]" onClick={() => setPresetOpen(true)}><Save size={11} /> حفظ</Button>
              <Button variant="primary" className="!px-2.5 !py-1.5 text-[10px]" onClick={() => onNavigate("preview")}><Eye size={11} /> معاينة</Button>
            </div>
          </div>
        </section>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/[0.07] bg-white/[0.015] px-3.5 py-3 text-[10px] text-[#82828c]">
        <span className="flex items-center gap-2"><Brush size={12} className="text-[#d9b65a]" /> التصميم يُطبَّق على جميع الأسئلة، مع إمكانية صورة خلفية لكل سؤال من محرر الأسئلة.</span>
        <button type="button" onClick={() => onNavigate("export")} className="flex items-center gap-1 font-medium text-[#e7cf94] hover:text-white">متابعة إلى التصدير <ArrowLeft size={12} /></button>
      </div>

      <ConfirmDialog
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        title="إعادة التصميم الافتراضي؟"
        description="سيُستبدل التصميم الحالي كاملًا بالإعداد الافتراضي، بما يشمل الصور والشعار والألوان. لن تتأثر الأسئلة والأصوات."
        confirmLabel="إعادة التعيين"
        danger
        onConfirm={() => {
          const fallback = defaultDesign();
          patchDesign(() => fallback);
          setResetOpen(false);
          setWarn(null);
          toast("أُعيد التصميم إلى الإعدادات الافتراضية. احفظ قالبًا قبل التغييرات القادمة إن أردت.", "success");
        }}
      />
      <Modal
        open={presetOpen}
        onClose={() => setPresetOpen(false)}
        title="حفظ التصميم كقالب"
        description="احفظ هذا المظهر وأعد استخدامه في الأسئلة أو المشاريع القادمة."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setPresetOpen(false)}>إلغاء</Button>
            <Button variant="primary" onClick={savePreset} disabled={!presetName.trim()}><Check size={14} /> حفظ القالب</Button>
          </div>
        }
      >
        <Field label="اسم القالب" required>
          <Input value={presetName} onChange={(event) => setPresetName(event.target.value)} placeholder="مثال: الليلي الذهبي — النسخة 2" autoFocus />
        </Field>
      </Modal>
    </div>
  );
}
