import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import { useProjects } from "@/hooks/useProjects";
import { useIdeas } from "@/hooks/useIdeas";
import { cn, formatDate, getStatusColor, getStatusLabel, truncate } from "@/lib/utils";
import { CONTENT_TYPE_LABELS, QUICK_COMMANDS } from "@/constants";
import heroBg from "@/assets/hero-bg.jpg";
import WorkflowStatus from "@/components/features/WorkflowStatus";
import ActivityChartWidget from "@/components/features/ActivityChartWidget";
import CreateContentDropdown from "@/components/features/CreateContentDropdown";
import {
  Sparkles, FolderOpen, Lightbulb, Play, Plus, ArrowRight,
  Zap, TrendingUp, Clock, CheckCircle2, Cpu
} from "lucide-react";

export default function DashboardPage() {
  const navigate = useNavigate();
  const { projects } = useProjects();
  const { ideas } = useIdeas();

  const recentProjects = projects.slice(0, 4);
  const completed = projects.filter((p) => p.status === "COMPLETED").length;
  const inProgress = projects.filter((p) => !["COMPLETED", "FAILED"].includes(p.status)).length;

  const stats = [
    { label: "Projetos Totais", value: projects.length, icon: FolderOpen, color: "text-studio-blue" },
    { label: "Em Produção", value: inProgress, icon: Zap, color: "text-yellow-400" },
    { label: "Concluídos", value: completed, icon: CheckCircle2, color: "text-studio-green" },
    { label: "Ideias Salvas", value: ideas.length, icon: Lightbulb, color: "text-studio-purple" },
  ];

  return (
    <AppLayout title="Dashboard" subtitle="Bem-vindo ao AI Creator Studio">
      <div className="p-6 space-y-6 max-w-7xl">

        {/* Hero Banner */}
        <div className="relative rounded-2xl overflow-hidden min-h-44">
          <img src={heroBg} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-r from-studio-bg via-studio-bg/70 to-transparent" />
          <div className="relative z-10 p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 h-full">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-studio-blue font-semibold uppercase tracking-widest">
                  AI Creator Studio · CORE 4.0
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-studio-gold/20 text-studio-gold font-mono font-bold border border-studio-gold/30">
                  CONTENT FACTORY ATIVA
                </span>
              </div>
              <h2 className="text-2xl font-bold text-studio-text font-display text-gradient-blue mb-1">
                Cria. Produz. Publica.
              </h2>
              <p className="text-studio-text-dim text-sm">Fábrica de conteúdo inteligente e inteligência estratégica avançada.</p>
            </div>
            <div className="flex flex-col items-stretch sm:items-end gap-2.5 shrink-0">
              <CreateContentDropdown
                id="btn-hero-criar-conteudo"
                variant="hero"
                buttonText="+ Criar Conteúdo"
              />
              <button
                id="btn-hero-ai-autopilot"
                onClick={() => navigate("/autopilot")}
                className="btn-secondary text-xs sm:text-sm py-2 px-4 gap-2 shrink-0 border-studio-blue/40 hover:border-studio-blue text-studio-text justify-center bg-studio-bg/75 backdrop-blur-xs w-full sm:w-auto"
              >
                <Cpu className="w-4 h-4 text-studio-blue" />
                AI Autopilot
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="studio-card p-4 flex items-center gap-3">
              <div className={cn("w-10 h-10 rounded-xl bg-studio-panel flex items-center justify-center", stat.color)}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-studio-text font-display">{stat.value}</p>
                <p className="text-xs text-studio-text-muted">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Activity Chart Widget (Recharts) */}
        <ActivityChartWidget projects={projects} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quick Create */}
          <div className="studio-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-studio-text font-display">Criação Rápida</h3>
              <Sparkles className="w-4 h-4 text-studio-blue" />
            </div>
            <div className="space-y-2">
              {QUICK_COMMANDS.slice(0, 5).map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => navigate(`/creator?q=${encodeURIComponent(cmd)}`)}
                  className="w-full text-left p-3 rounded-lg bg-studio-panel hover:bg-studio-border border border-transparent hover:border-studio-blue/20 transition-all group"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-studio-text-dim group-hover:text-studio-text transition-colors line-clamp-1">
                      {cmd}
                    </span>
                    <ArrowRight className="w-3 h-3 text-studio-text-muted group-hover:text-studio-blue shrink-0 transition-colors" />
                  </div>
                </button>
              ))}
            </div>
            <button
              onClick={() => navigate("/creator")}
              className="w-full mt-3 btn-primary text-sm py-2.5 justify-center"
            >
              <Sparkles className="w-4 h-4" />
              Abrir AI Creator
            </button>
          </div>

          {/* Recent Projects */}
          <div className="lg:col-span-2 studio-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-studio-text font-display">Projetos Recentes</h3>
              <button
                onClick={() => navigate("/projects")}
                className="text-xs text-studio-blue hover:underline"
              >
                Ver todos
              </button>
            </div>
            {recentProjects.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-12 h-12 rounded-full bg-studio-panel flex items-center justify-center mb-3">
                  <FolderOpen className="w-6 h-6 text-studio-text-muted" />
                </div>
                <p className="text-sm text-studio-text-muted">Nenhum projeto ainda</p>
                <button
                  onClick={() => navigate("/creator")}
                  className="mt-3 btn-primary text-sm py-2 px-4"
                >
                  Criar Primeiro Projeto
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {recentProjects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => navigate(`/projects/${project.id}`)}
                    className="w-full text-left p-3 rounded-xl bg-studio-panel hover:bg-studio-border border border-studio-border hover:border-studio-blue/20 transition-all group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-sm font-semibold text-studio-text truncate group-hover:text-studio-blue transition-colors">
                            {truncate(project.title, 40)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={cn("task-badge text-xs", getStatusColor(project.status))}>
                            {getStatusLabel(project.status)}
                          </span>
                          <span className="text-xs text-studio-text-muted">
                            {CONTENT_TYPE_LABELS[project.contentType] ?? project.contentType}
                          </span>
                          <span className="text-xs text-studio-text-muted">
                            {formatDate(project.createdAt)}
                          </span>
                        </div>
                        <div className="mt-2">
                          <WorkflowStatus status={project.status} compact />
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-studio-text-muted group-hover:text-studio-blue shrink-0 transition-colors mt-1" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Ideas preview */}
        {ideas.length > 0 && (
          <div className="studio-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-studio-purple" />
                Ideas Lab
              </h3>
              <button onClick={() => navigate("/ideas")} className="text-xs text-studio-blue hover:underline">
                Ver todas
              </button>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {ideas.slice(0, 4).map((idea) => (
                <div
                  key={idea.id}
                  className="p-3 rounded-xl bg-studio-panel border border-studio-border hover:border-studio-purple/30 transition-all cursor-pointer"
                  onClick={() => navigate("/ideas")}
                >
                  <p className="text-xs font-semibold text-studio-text mb-1 line-clamp-2">{idea.title}</p>
                  <p className="text-xs text-studio-text-muted line-clamp-2">{idea.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
