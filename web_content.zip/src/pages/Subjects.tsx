import { Link } from 'react-router-dom';
import { BookOpenCheck } from 'lucide-react';
import { subjects, allLessons } from '../data/content';
import { completedCount, overallProgress } from '../services/progress';
import { useStored, KEYS } from '../services/storage';
import { PageHeader } from '../components/layout/PageHeader';
import { SubjectCard } from '../components/content/SubjectBits';
import { ProgressBar } from '../components/ui/Card';

export default function Subjects() {
  useStored(KEYS.progress, {});
  const overall = overallProgress();
  const done = completedCount();

  return (
    <div>
      <PageHeader
        eyebrow="المنهاج السوري · الفرع العلمي"
        title="موادي"
        subtitle="ثماني مواد، وكل مادة أكثر من مدرّس — اختر شرح من يناسبك."
      />

      <div className="card mb-4 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--ink)]">
              <BookOpenCheck size={17} />
            </span>
            <div>
              <p className="text-[0.8rem] font-medium text-[var(--ink)]">تقدمك الكلي</p>
              <p className="text-[0.68rem] text-[var(--ink-soft)]">
                {done} من {allLessons.length} درساً
              </p>
            </div>
          </div>
          <span className="font-display text-xl text-[var(--ink)]">{overall}%</span>
        </div>
        <ProgressBar value={overall} className="mt-3" />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {subjects.map((subject) => (
          <SubjectCard key={subject.id} subject={subject} />
        ))}
      </div>

      <p className="mt-4 rounded-2xl bg-[var(--surface-2)] p-3 text-center text-[0.7rem] leading-relaxed text-[var(--ink-soft)]">
        المواد وأسماؤها من ملف المحتوى الواحد{' '}
        <Link to="/settings" className="underline underline-offset-4">
          وإعدادات التطبيق
        </Link>
        . لإضافة مادة جديدة عدّل <code className="rounded bg-black/5 px-1 dark:bg-white/10">src/data/content.ts</code>.
      </p>
    </div>
  );
}
