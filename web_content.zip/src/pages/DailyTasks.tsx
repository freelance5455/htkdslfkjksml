import { useEffect, useMemo, useState } from 'react';
import { BookOpenCheck, Check, Circle, Coins, ListChecks, Moon, Plus, Sun, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Card, ProgressBar, SectionHeader } from '../components/ui/Card';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { useToast } from '../hooks/useToast';
import { EMPTY_WALLET } from '../services/economy';
import {
  addDailyTask,
  claimDailyTaskReward,
  ensureDailyTaskDay,
  getDailyTaskStore,
  localDateKey,
  previewDailyTaskDay,
  removeDailyTask,
  renameDailyTask,
  setDailyTaskDone,
  type DailyTaskDay,
} from '../services/dailyTasks';
import { DAILY_ROUTINES, EMPTY_DAILY_ROUTINES, getDailyRoutineDay, setDailyRoutineDone } from '../services/dailyRoutines';
import { isKeyMemoryOnly, KEYS, useStored } from '../services/storage';
import { formatMinutes } from '../utils/format';

const inputClass = 'focus-ring min-h-11 min-w-0 flex-1 rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--ink)]';

function localDateLabel(date: string): string {
  const parsed = new Date(`${date}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? date : parsed.toLocaleDateString('ar-SY', { weekday: 'long', day: 'numeric', month: 'long' });
}

export default function DailyTasks() {
  const { toast } = useToast();
  const store = useStored(KEYS.dailyTasks, getDailyTaskStore());
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  const stats = useStored(KEYS.stats, { days: {} as Record<string, { seconds: number }> });
  const progress = useStored(KEYS.progress, {} as Record<string, { completed?: boolean }>);
  const quizzes = useStored(KEYS.quizzes, [] as Array<{ at: number }>);
  const practiceAttempts = useStored(KEYS.practiceAttempts, [] as Array<{ at: number }>);
  const routineStore = useStored(KEYS.dailyRoutines, EMPTY_DAILY_ROUTINES);
  const [today, setToday] = useState(() => new Date());
  const todayKey = localDateKey(today);
  const day = store.days?.[todayKey] ?? previewDailyTaskDay(today, store);
  const routineDay = getDailyRoutineDay(today, routineStore);
  const completedRoutines = DAILY_ROUTINES.filter((routine) => routineDay.done[routine.id]).length;
  const [draftTitles, setDraftTitles] = useState<Record<string, string>>({});
  const [claiming, setClaiming] = useState(false);

  useEffect(() => {
    void ensureDailyTaskDay(today).then(() => {
      if (isKeyMemoryOnly(KEYS.dailyTasks)) toast('تعذّر الحفظ الدائم لقائمة اليوم؛ أفرغ مساحة الجهاز. التغييرات المؤقتة قد تختفي عند إغلاق التطبيق.', 'error');
    }).catch(() => toast('تعذّر تهيئة قائمة اليوم؛ ما زالت بياناتك محلية.', 'error'));
  }, [todayKey]);

  useEffect(() => {
    const nextMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
    const timer = window.setTimeout(() => setToday(new Date()), Math.max(1_000, nextMidnight.getTime() - Date.now() + 100));
    return () => window.clearTimeout(timer);
  }, [todayKey]);

  const doneCount = day.tasks.filter((task) => task.done).length;
  const complete = day.tasks.length >= 3 && doneCount === day.tasks.length;
  const claimId = `daily-task:${todayKey}`;
  const claimed = Boolean(day.rewardClaimedAt) || wallet.claimedRewardIds.includes(claimId);
  const activeSeconds = stats.days?.[todayKey]?.seconds ?? 0;
  const completedLessons = useMemo(() => Object.values(progress).filter((item) => item?.completed).length, [progress]);
  const attemptsToday = useMemo(() => {
    const isToday = (at: number) => localDateKey(new Date(at)) === todayKey;
    return quizzes.filter((item) => isToday(item.at)).length + practiceAttempts.filter((item) => isToday(item.at)).length;
  }, [practiceAttempts, quizzes, todayKey]);
  const previousDays = Object.values(store.days ?? {})
    .filter((item: DailyTaskDay) => item.date < todayKey)
    .sort((a: DailyTaskDay, b: DailyTaskDay) => b.date.localeCompare(a.date))
    .slice(0, 7);

  const onToggle = async (taskId: string, done: boolean) => {
    await setDailyTaskDone(taskId, done, today);
    if (isKeyMemoryOnly(KEYS.dailyTasks)) toast('لم تُحفظ المهمة دائماً على الجهاز؛ أفرغ مساحة التخزين وحاول مجدداً.', 'error');
  };

  const onToggleRoutine = async (id: (typeof DAILY_ROUTINES)[number]['id'], done: boolean) => {
    await setDailyRoutineDone(id, done, today);
    if (isKeyMemoryOnly(KEYS.dailyRoutines)) toast('لم تُحفظ المتابعة على الجهاز دائماً؛ أفرغ مساحة التخزين وحاول مجدداً.', 'error');
  };

  const onClaim = async () => {
    setClaiming(true);
    try {
      const result = await claimDailyTaskReward(today);
      if (result === 'claimed' && (isKeyMemoryOnly(KEYS.wallet) || isKeyMemoryOnly(KEYS.dailyTasks))) toast('أُضيفت المكافأة مؤقتاً لكن تعذّر حفظها الدائم؛ أفرغ مساحة الجهاز قبل إغلاق التطبيق.', 'error');
      else if (result === 'claimed') toast('أُضيفت ١٠ نقاط مرة واحدة لمهام اليوم.', 'success');
      else if (result === 'already-claimed') toast('استلمت مكافأة اليوم مسبقاً.', 'info');
      else toast('أكمل كل المهام أولاً لاستلام المكافأة.', 'info');
    } catch {
      toast('تعذّر تحديث المحفظة المحلية؛ حاول مجدداً.', 'error');
    } finally {
      setClaiming(false);
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow={localDateLabel(todayKey)}
        title="مهامي اليومية"
        subtitle="قائمة شخصية تتجدد بتاريخ اليوم المحلي. علّم ما أنجزته بنفسك؛ المكافأة مرة واحدة فقط بعد إكمال القائمة."
        back="/"
      />

      <Card className="mb-4 border-[color-mix(in_srgb,var(--gold)_45%,var(--line))] bg-[linear-gradient(115deg,var(--surface),var(--gold-soft))]">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="font-display text-lg text-[var(--ink)]">تقدّم اليوم</p>
            <p className="mt-1 text-sm text-[var(--ink-soft)]">{doneCount} من {day.tasks.length} مهام منجزة · من ٣ إلى ١٥ مهمة</p>
          </div>
          <div className="flex items-center gap-1 rounded-full bg-[var(--surface)] px-3 py-2 text-sm font-semibold text-[var(--ink)]"><Coins size={16} className="text-[var(--gold)]" /> ١٠ نقاط</div>
        </div>
        <ProgressBar className="mt-3" value={day.tasks.length ? (doneCount / day.tasks.length) * 100 : 0} label="إنجاز مهام اليوم" />
        {claimed ? (
          <p className="mt-3 text-sm font-medium text-[var(--success)]" role="status">استلمت مكافأة هذا اليوم بالفعل.</p>
        ) : complete ? (
          <Button className="mt-3" variant="gold" icon={<Coins size={16} />} disabled={claiming} onClick={onClaim}>
            {claiming ? 'جارٍ تسجيل المكافأة…' : 'استلام ١٠ نقاط'}
          </Button>
        ) : (
          <p className="mt-3 text-xs text-[var(--ink-soft)]">أكمل القائمة لتفعيل زر استلام المكافأة.</p>
        )}
      </Card>

      <SectionHeader title="قائمة اليوم" hint="عدّل عناوين المهام متى شئت؛ تغييراتك تُحفظ على هذا الجهاز." />
      <div className="space-y-2">
        {day.tasks.map((task) => (
          <Card key={task.id} className="flex items-center gap-2 p-3">
            <button
              type="button"
              onClick={() => void onToggle(task.id, !task.done)}
              aria-label={task.done ? `إلغاء إنجاز: ${task.title}` : `تعليم منجز: ${task.title}`}
              aria-pressed={task.done}
              className={`focus-ring flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${task.done ? 'bg-[var(--success)] text-white' : 'bg-[var(--surface-2)] text-[var(--ink-soft)]'}`}
            >
              {task.done ? <Check size={20} /> : <Circle size={19} />}
            </button>
            <input
              aria-label="عنوان المهمة"
              maxLength={80}
              value={draftTitles[task.id] ?? task.title}
              onChange={(event) => setDraftTitles((current) => ({ ...current, [task.id]: event.target.value }))}
              onBlur={() => {
                const draft = draftTitles[task.id];
                if (draft !== undefined && draft.trim() && draft.trim() !== task.title) {
                  void renameDailyTask(task.id, draft, today).then(() => {
                    if (isKeyMemoryOnly(KEYS.dailyTasks)) toast('تعذّر حفظ عنوان المهمة دائماً؛ أفرغ مساحة التخزين.', 'error');
                  });
                }
                setDraftTitles((current) => {
                  const next = { ...current };
                  delete next[task.id];
                  return next;
                });
              }}
              className={`${inputClass} ${task.done ? 'text-[var(--ink-soft)] line-through' : ''}`}
            />
            <button
              type="button"
              onClick={() => {
                if (day.tasks.length <= 3) {
                  toast('يجب أن تبقى لديك ٣ مهام على الأقل.', 'info');
                  return;
                }
                void removeDailyTask(task.id, today).then(() => {
                  if (isKeyMemoryOnly(KEYS.dailyTasks)) toast('تعذّر حفظ حذف المهمة دائماً؛ أفرغ مساحة التخزين.', 'error');
                });
              }}
              aria-label={`حذف المهمة: ${task.title}`}
              className="focus-ring flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-[var(--ink-soft)] hover:text-[var(--danger)]"
            >
              <Trash2 size={16} />
            </button>
          </Card>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0 flex-1 rounded-2xl bg-[var(--surface-2)] p-3">
          <p className="text-xs font-semibold text-[var(--ink)]">تمييز واضح بين نوعَي المتابعة</p>
          <p className="mt-1 text-xs leading-relaxed text-[var(--ink-soft)]">قائمة اليوم ذاتية وتعلّمها بنفسك؛ لا تضيف وقت دراسة عند التأشير. أما التحديات الآلية فتُحسب من سجلات الدراسة والاختبارات والمراجعة، ولا تحتاج علامة يدوية.</p>
          <Link to="/challenges" className="focus-ring mt-2 inline-flex min-h-11 items-center rounded-xl border border-[var(--line)] px-3 text-xs text-[var(--ink)]">عرض التحديات المتحققة آلياً</Link>
        </div>
        <Button
          size="sm"
          variant="outline"
          icon={<Plus size={15} />}
          className="min-h-11"
          disabled={day.tasks.length >= 15}
          onClick={() => void addDailyTask(today).then(() => {
            if (isKeyMemoryOnly(KEYS.dailyTasks)) toast('تعذّر حفظ المهمة الجديدة دائماً؛ أفرغ مساحة التخزين.', 'error');
          })}
        >
          إضافة مهمة
        </Button>
      </div>

      <section id="worship-routine" className="scroll-mt-5">
        <SectionHeader className="mt-6" title="عبادات اليوم" hint={`${completedRoutines} من ${DAILY_ROUTINES.length} متابعات · محفوظة محلياً بلا نقاط`} />
        <div className="grid gap-3 sm:grid-cols-2">
          {([
            { id: 'prayer', title: 'الصلوات الخمس', Icon: Sun },
            { id: 'quran', title: 'ورد القرآن', Icon: BookOpenCheck },
            { id: 'adhkar', title: 'أذكار الصباح والمساء', Icon: Moon },
          ] as const).map((group) => {
            const items = DAILY_ROUTINES.filter((routine) => routine.category === group.id);
            return (
              <Card key={group.id} className="p-3.5">
                <h2 className="mb-2 flex items-center gap-2 text-sm font-semibold text-[var(--ink)]"><group.Icon size={17} className="text-[var(--gold)]" />{group.title}</h2>
                <div className="space-y-1">
                  {items.map((routine) => (
                    <button key={routine.id} type="button" onClick={() => void onToggleRoutine(routine.id, !routineDay.done[routine.id])} aria-pressed={routineDay.done[routine.id]} aria-label={`${routineDay.done[routine.id] ? 'إلغاء إنجاز' : 'تعليم منجز'}: ${routine.title}`} className="focus-ring flex min-h-11 w-full items-center gap-2 rounded-xl px-2 text-right text-xs text-[var(--ink)] hover:bg-[var(--surface-2)]">
                      {routineDay.done[routine.id] ? <Check size={17} className="shrink-0 text-[var(--success)]" /> : <Circle size={17} className="shrink-0 text-[var(--ink-soft)]" />}
                      <span className={routineDay.done[routine.id] ? 'text-[var(--ink-soft)] line-through' : ''}>{routine.title}</span>
                    </button>
                  ))}
                </div>
                {group.id === 'quran' ? <Link to="/study-session#study-audio" className="focus-ring mt-2 inline-flex min-h-11 items-center rounded-xl border border-[var(--line)] px-3 text-xs font-medium text-[var(--brand)]">افتح مشغل التلاوات</Link> : null}
              </Card>
            );
          })}
        </div>
        <p className="mt-2 rounded-xl bg-[var(--surface-2)] px-3 py-2 text-[0.68rem] leading-relaxed text-[var(--ink-soft)]">هذه قائمة شخصية اختيارية؛ لا تضيف وقت دراسة أو نقاطاً، ولا تُرفع بياناتها إلى خادم.</p>
      </section>

      <SectionHeader className="mt-6" title="مؤشرات تلقائية من سجلك" hint="قراءة فقط — تُحسب من بيانات التطبيق المحلية ولا تحتاج إلى تعليم يدوي." />
      <div className="grid grid-cols-3 gap-2">
        <Card className="p-3 text-center"><p className="font-display text-lg text-[var(--ink)]">{formatMinutes(Math.floor(activeSeconds / 60))}</p><p className="text-[0.68rem] text-[var(--ink-soft)]">دراسة نشطة اليوم</p></Card>
        <Card className="p-3 text-center"><p className="font-display text-lg text-[var(--ink)]">{completedLessons}</p><p className="text-[0.68rem] text-[var(--ink-soft)]">دروس مكتملة</p></Card>
        <Card className="p-3 text-center"><p className="font-display text-lg text-[var(--ink)]">{attemptsToday}</p><p className="text-[0.68rem] text-[var(--ink-soft)]">محاولات اليوم</p></Card>
      </div>

      <SectionHeader className="mt-6" title="سجل الأيام السابقة" hint="لا تُمحى قائمة الأمس عند بدء يوم جديد." />
      {previousDays.length ? (
        <div className="space-y-2">
          {previousDays.map((past) => {
            const completed = past.tasks.filter((task) => task.done).length;
            return (
              <Card key={past.date} className="flex items-center justify-between gap-3 p-3">
                <span className="text-sm text-[var(--ink)]">{localDateLabel(past.date)}</span>
                <span className="flex items-center gap-2"><Badge tone={completed === past.tasks.length ? 'success' : 'neutral'}>{completed}/{past.tasks.length}</Badge>{past.rewardClaimedAt ? <Badge tone="gold">المكافأة مستلمة</Badge> : null}</span>
              </Card>
            );
          })}
        </div>
      ) : (
        <EmptyState icon={<ListChecks size={18} />} title="سيظهر سجل الأيام هنا" description="قوائمك السابقة تبقى محفوظة على جهازك عند بداية كل يوم جديد." />
      )}
    </div>
  );
}
