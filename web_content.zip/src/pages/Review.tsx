import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Layers, RotateCcw, Sparkles } from 'lucide-react';
import { flashcards, subjects } from '../data/content';
import type { Flashcard } from '../types';
import { dueCards, gradeCard, deckProgress } from '../services/flashcards';
import { useStored, KEYS } from '../services/storage';
import { PageHeader } from '../components/layout/PageHeader';
import { MathText } from '../components/ui/MathText';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { Button } from '../components/ui/Button';
import { Chip, ProgressBar } from '../components/ui/Card';
import { useActiveStudy } from '../hooks/useActiveStudy';

export default function Review() {
  const [subjectId, setSubjectId] = useState<string>('all');
  useStored(KEYS.cards, {});

  const [session, setSession] = useState<{ cards: Flashcard[]; index: number; revealed: boolean; done: number }>({
    cards: [],
    index: 0,
    revealed: false,
    done: 0,
  });
  const [started, setStarted] = useState(false);

  const due = useMemo(() => dueCards(subjectId === 'all' ? undefined : subjectId), [subjectId]);
  const progress = deckProgress(subjectId === 'all' ? undefined : subjectId);

  const start = () => {
    setSession({ cards: due.length > 0 ? due : flashcards.filter((c) => subjectId === 'all' || c.subjectId === subjectId), index: 0, revealed: false, done: 0 });
    setStarted(true);
  };

  const grade = (g: 0 | 1 | 2 | 3) => {
    const card = session.cards[session.index];
    if (!card) return;
    gradeCard(card.id, g);
    const nextIndex = session.index + 1;
    if (nextIndex >= session.cards.length) {
      setStarted(false);
      setSession({ cards: [], index: 0, revealed: false, done: session.cards.length });
    } else if (g === 0) {
      // «لم أتذكر»: تعود البطاقة في نهاية الجلسة نفسها
      setSession((s) => ({
        ...s,
        cards: [...s.cards, card],
        index: nextIndex,
        revealed: false,
        done: s.done + 1,
      }));
    } else {
      setSession((s) => ({ ...s, index: nextIndex, revealed: false, done: s.done + 1 }));
    }
  };

  const card = session.cards[session.index];
  const subjectOfCard = card ? subjects.find((s) => s.id === card.subjectId) : undefined;
  useActiveStudy(started && Boolean(card), card?.subjectId ?? (subjectId !== 'all' ? subjectId : undefined), 'interactive');

  return (
    <div>
      <PageHeader
        eyebrow="تكرار متباعد — يظهر ما تحتاجه الآن فقط"
        title="مركز المراجعة"
        subtitle="بطاقات القوانين والتعاريف. قيّم نفسك بصدق، وسيعيد التطبيق ترتيب مواعيد البطاقات تلقائياً."
      />

      <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
        <Chip active={subjectId === 'all'} onClick={() => setSubjectId('all')}>
          كل المواد
        </Chip>
        {subjects.map((s) => {
          const count = flashcards.filter((c) => c.subjectId === s.id).length;
          if (count === 0) return null;
          return (
            <Chip key={s.id} active={subjectId === s.id} onClick={() => setSubjectId(s.id)}>
              {s.shortName}
            </Chip>
          );
        })}
      </div>

      <div className="card mb-4 p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-[0.78rem] font-medium text-[var(--ink)]">بطاقات مستحقّة اليوم</p>
            <p className="text-[0.68rem] text-[var(--ink-soft)]">
              {due.length} بطاقة · راجعت {progress.reviewed} من {progress.total}
            </p>
          </div>
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]">
            <Layers size={20} />
          </span>
        </div>
        <ProgressBar value={progress.total ? (progress.reviewed / progress.total) * 100 : 0} className="mt-3" />
      </div>

      {!started ? (
        <div className="space-y-3">
          <EmptyState
            icon={<Sparkles size={18} />}
            title={due.length > 0 ? `${due.length} بطاقة جاهزة للمراجعة` : 'لا بطاقات مستحقّة الآن'}
            description={
              due.length > 0
                ? 'جلسة قصيرة (٥ دقائق) أفضل من جلسة طويلة متأخرة. ابدأ حين تكون مرتاحاً.'
                : 'أحسنت — عد غداً. يمكنك أيضاً مراجعة بطاقات مادة معيّنة من دون انتظار استحقاقها.'
            }
            action={
              <Button variant="gold" onClick={start} icon={<RotateCcw size={15} />}>
                {due.length > 0 ? 'ابدأ المراجعة' : 'راجع كل البطاقات'}
              </Button>
            }
          />
          {session.done > 0 ? (
            <p className="text-center text-[0.72rem] text-[var(--success)]">راجعت {session.done} بطاقة في الجلسة الأخيرة.</p>
          ) : null}
        </div>
      ) : (
        <div>
          <div className="mb-2 flex items-center justify-between text-[0.68rem] text-[var(--ink-soft)]">
            <span>
              {session.index + 1} / {session.cards.length}
            </span>
            {subjectOfCard ? <Badge tone="neutral">{subjectOfCard.name}</Badge> : null}
          </div>

          <div className="relative" style={{ perspective: 1200 }}>
            <AnimatePresence mode="wait">
              {card ? (
                <motion.div
                  key={card.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, rotateY: 0 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.22 }}
                  className="card min-h-[15rem] p-5"
                >
                  <p className="text-[0.66rem] uppercase tracking-wide text-[var(--ink-soft)]">{card.tag}</p>
                  <p className="mt-2 font-display text-[1.05rem] leading-relaxed text-[var(--ink)]">{card.front}</p>

                  <AnimatePresence>
                    {session.revealed ? (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-4 border-t border-dashed border-[var(--line)] pt-4"
                      >
                        <MathText text={card.back} />
                      </motion.div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setSession((s) => ({ ...s, revealed: true }))}
                        className="focus-ring mt-5 h-11 w-full rounded-2xl bg-[var(--surface-2)] text-[0.8rem] font-medium text-[var(--ink)]"
                      >
                        أظهر الإجابة
                      </button>
                    )}
                  </AnimatePresence>
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>

          {session.revealed ? (
            <div className="mt-3 grid grid-cols-4 gap-1.5">
              {[
                { g: 0 as const, label: 'لم أتذكر', tone: 'danger' },
                { g: 1 as const, label: 'صعب', tone: 'gold' },
                { g: 2 as const, label: 'جيد', tone: 'neutral' },
                { g: 3 as const, label: 'سهل', tone: 'success' },
              ].map((option) => (
                <button
                  key={option.label}
                  type="button"
                  onClick={() => grade(option.g)}
                  className="focus-ring h-11 rounded-2xl border border-[var(--line)] bg-[var(--surface)] text-[0.72rem] font-medium text-[var(--ink)]"
                >
                  {option.label}
                </button>
              ))}
            </div>
          ) : null}

          <button
            type="button"
            onClick={() => setStarted(false)}
            className="mt-3 w-full text-center text-[0.7rem] text-[var(--ink-soft)] underline-offset-4 hover:underline"
          >
            إنهاء الجلسة
          </button>
        </div>
      )}
    </div>
  );
}
