import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle, BookOpen, CheckCircle2, FileText, Loader2, Search, Sparkles, Trash2, Upload,
} from 'lucide-react';
import type { ResourceChunk, ResourceRow } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn } from '../lib/utils';
import { extractPdfText } from '../lib/pdf';
import {
  Badge, Banner, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, Select, SetupCard, Spinner, Textarea, useToast,
} from '../components/ui';

const KINDS = [
  { value: 'ncert', label: 'NCERT textbook' },
  { value: 'notes', label: 'School / personal notes' },
  { value: 'module', label: 'Coaching module' },
  { value: 'reference', label: 'Reference book' },
  { value: 'previous-year', label: 'Previous-year paper' },
  { value: 'sample-paper', label: 'Sample paper' },
  { value: 'formula-sheet', label: 'Formula sheet' },
  { value: 'other', label: 'Other material' },
];

const ANALYSIS = [
  { kind: 'summary', label: 'Summarise & extract formulas' },
  { kind: 'topics', label: 'Map chapters and topics' },
  { kind: 'questions', label: 'Generate questions from this file' },
];

export default function Resources() {
  const { profile, aiEnabled } = useAuth();
  const { push } = useToast();
  const [resources, setResources] = useState<ResourceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [kind, setKind] = useState('ncert');
  const [subject, setSubject] = useState(profile?.subjects[0] ?? '');
  const [file, setFile] = useState<File | null>(null);
  const [extracting, setExtracting] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [pasteText, setPasteText] = useState('');
  const [pasteName, setPasteName] = useState('');
  const [detail, setDetail] = useState<{ resource: ResourceRow; chunks: ResourceChunk[] } | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const [insight, setInsight] = useState<unknown>(null);
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<ResourceChunk[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [deleting, setDeleting] = useState<ResourceRow | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const data = await api.get<{ resources: ResourceRow[] }>('/api/resources');
      setResources(data.resources);
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load resources.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const upload = async () => {
    if (!file) { setError('Choose a PDF file first.'); return; }
    if (file.size > 25 * 1024 * 1024) { setError('Files must be 25 MB or smaller. Split large textbooks by chapter.'); return; }
    setError(null);
    setWarnings([]);
    setExtracting(true);
    setProgress({ done: 0, total: 1 });
    try {
      const extraction = await extractPdfText(file, (done, total) => setProgress({ done, total }));
      if (!extraction.pages.length) {
        setWarnings([
          `No text layer was found in this PDF (${extraction.totalPages} pages). It is probably a scan or photos of pages — OCR is not available in this version.`,
          'Options: use a text-based PDF from NCERT/your board, or paste the chapter text with “Paste text”.',
        ]);
        setExtracting(false);
        return;
      }

      const created = await api.post<{ resource: ResourceRow }>('/api/resources', {
        name: name.trim() || file.name,
        kind,
        subject: subject || null,
        sizeBytes: file.size,
        pageCount: extraction.totalPages,
        pages: extraction.pages,
      });

      try {
        await api.upload(`/api/resources/${created.resource.id}/file`, file);
      } catch {
        setWarnings((w) => [...w, 'The original file could not be archived, but its text was indexed successfully.']);
      }

      if (extraction.emptyPages.length) {
        setWarnings((w) => [
          ...w,
          `${extraction.emptyPages.length} of ${extraction.totalPages} pages had no extractable text (scanned or image pages): p. ${extraction.emptyPages.slice(0, 12).join(', ')}${extraction.emptyPages.length > 12 ? '…' : ''}. Those pages are not searchable.`,
        ]);
      }
      push(`Indexed ${extraction.pages.length} pages into ${created.resource.chunkCount} searchable chunks.`, 'ok');
      setFile(null);
      setName('');
      if (fileRef.current) fileRef.current.value = '';
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not process this PDF.');
    } finally {
      setExtracting(false);
      setProgress(null);
    }
  };

  const uploadPasted = async () => {
    if (pasteText.trim().length < 200) { setError('Paste at least a couple of paragraphs (200+ characters) so retrieval has something to work with.'); return; }
    setError(null);
    setExtracting(true);
    try {
      const paragraphs = pasteText.trim().split(/\n{2,}/);
      const pages: { page: number; text: string }[] = [];
      let buffer = '';
      let page = 1;
      for (const para of paragraphs) {
        if (buffer.length + para.length > 3000) {
          pages.push({ page, text: buffer });
          buffer = '';
          page += 1;
        }
        buffer += (buffer ? '\n\n' : '') + para;
      }
      if (buffer) pages.push({ page, text: buffer });

      const created = await api.post<{ resource: ResourceRow }>('/api/resources', {
        name: pasteName.trim() || 'Pasted notes',
        kind: 'notes',
        subject: subject || null,
        sizeBytes: new Blob([pasteText]).size,
        pageCount: pages.length,
        pages,
      });
      push(`Saved “${pasteName || 'Pasted notes'}” with ${created.resource.chunkCount} searchable chunks.`, 'ok');
      setPasteOpen(false);
      setPasteText('');
      setPasteName('');
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save the pasted text.');
    } finally {
      setExtracting(false);
    }
  };

  const openDetail = async (resource: ResourceRow) => {
    setDetailLoading(true);
    setDetail(null);
    setInsight(null);
    try {
      const data = await api.get<{ resource: ResourceRow; chunks: ResourceChunk[]; insights: { kind: string; payload: unknown }[] }>(`/api/resources/${resource.id}`);
      setDetail({ resource: data.resource, chunks: data.chunks });
      setInsight(data.insights[0]?.payload ?? null);
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not open this resource.', 'bad');
    } finally {
      setDetailLoading(false);
    }
  };

  const analyze = async (kindWanted: string) => {
    if (!detail) return;
    setAnalyzing(kindWanted);
    try {
      const data = await api.post<{ insight: { payload: unknown } }>(`/api/resources/${detail.resource.id}/analyze`, { kind: kindWanted });
      setInsight(data.insight.payload);
      push('Analysis complete — grounded in the pages of this document.', 'ok');
      await load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Analysis failed.', 'bad');
    } finally {
      setAnalyzing(null);
    }
  };

  const remove = async () => {
    if (!deleting) return;
    try {
      await api.del(`/api/resources/${deleting.id}`);
      setResources((prev) => prev.filter((r) => r.id !== deleting.id));
      push('Resource deleted.', 'info');
    } catch {
      push('Could not delete the resource.', 'bad');
    } finally {
      setDeleting(null);
    }
  };

  const runSearch = async () => {
    if (search.trim().length < 2) return;
    setSearching(true);
    try {
      const data = await api.get<{ chunks: ResourceChunk[] }>(`/api/resources/search?q=${encodeURIComponent(search.trim())}`);
      setResults(data.chunks);
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Search failed.', 'bad');
    } finally {
      setSearching(false);
    }
  };

  const insightData = insight as Record<string, unknown> | null;

  return (
    <div className="space-y-4">
      {!aiEnabled && <SetupCard message="PDF text extraction and retrieval search work now. Summaries, formula extraction and question generation from your documents need OPENAI_API_KEY." />}
      {error && <Banner tone="bad">{error}</Banner>}
      {warnings.map((w, i) => (
        <Banner key={i} tone="warn" title={i === 0 ? 'Heads up' : undefined}>{w}</Banner>
      ))}

      <div className="grid gap-4 lg:grid-cols-[1.15fr_1fr]">
        <Card>
          <h2 className="font-display text-base font-bold text-ink">Add study material</h2>
          <p className="mt-0.5 text-sm text-muted">PDFs are parsed in your browser and indexed on the server. Your file stays in your account.</p>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Field label="Name (optional)">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={file?.name ?? 'e.g. NCERT Physics Ch. 3'} />
            </Field>
            <Field label="Subject">
              <Select value={subject} onChange={(e) => setSubject(e.target.value)}>
                {profile?.subjects.map((s) => <option key={s}>{s}</option>)}
              </Select>
            </Field>
            <Field label="Material type">
              <Select value={kind} onChange={(e) => setKind(e.target.value)}>
                {KINDS.map((k) => <option key={k.value} value={k.value}>{k.label}</option>)}
              </Select>
            </Field>
            <Field label="PDF file (max 25 MB)">
              <input
                ref={fileRef}
                type="file"
                accept="application/pdf,.pdf"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                className="w-full cursor-pointer rounded-xl border border-dashed border-line bg-elevated/40 px-3 py-2 text-xs text-muted file:mr-3 file:rounded-lg file:border-0 file:bg-brand/15 file:px-2.5 file:py-1.5 file:text-xs file:font-semibold file:text-brand"
              />
            </Field>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button onClick={() => void upload()} loading={extracting} disabled={!file}>
              <Upload size={16} /> Extract &amp; index
            </Button>
            <Button variant="secondary" onClick={() => setPasteOpen(true)}><FileText size={16} /> Paste text</Button>
          </div>

          {progress && (
            <div className="mt-3">
              <div className="mb-1 flex justify-between text-xs text-muted">
                <span>Reading pages…</span><span>{progress.done}/{progress.total}</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-line/60">
                <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${Math.min(100, (progress.done / Math.max(1, progress.total)) * 100)}%` }} />
              </div>
            </div>
          )}

          <div className="mt-4 flex items-start gap-2 rounded-xl border border-line bg-elevated/30 p-2.5 text-[11px] text-muted">
            <AlertTriangle size={14} className="mt-0.5 shrink-0 text-warn" />
            Text-based PDFs work best. Image-only scans have no text layer — use “Paste text” for those pages; OCR is not available in this build.
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-base font-bold text-ink">Search your library</h2>
          <p className="mt-0.5 text-sm text-muted">Lexical-semantic retrieval over the indexed chunks, with the exact page cited.</p>
          <div className="mt-3 flex gap-2">
            <Input value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') void runSearch(); }} placeholder="e.g. lens maker formula derivation" />
            <Button variant="secondary" onClick={() => void runSearch()} loading={searching}><Search size={16} /></Button>
          </div>
          <div className="mt-3 space-y-2">
            {results === null ? (
              <p className="text-xs text-muted">Results show the document name, page and passage, so you can verify every answer.</p>
            ) : results.length === 0 ? (
              <p className="text-xs text-muted">No passage matched. Try different words, or upload the chapter that covers this topic.</p>
            ) : (
              results.map((chunk) => (
                <div key={chunk.id} className="rounded-xl border border-line bg-elevated/30 p-2.5">
                  <div className="flex items-center justify-between gap-2 text-[10px] text-muted">
                    <span className="truncate font-semibold text-brand">{chunk.resourceName}</span>
                    <span>p. {chunk.page}</span>
                  </div>
                  <p className="mt-1 line-clamp-4 text-xs leading-relaxed text-ink/90">{chunk.text}</p>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>

      <Card>
        <h2 className="font-display text-base font-bold text-ink">Your library ({resources.length})</h2>
        {loading ? <Spinner /> : resources.length === 0 ? (
          <div className="mt-3"><EmptyState icon={<BookOpen size={22} />} title="No material yet" description="Upload an NCERT chapter, your notes or a sample paper. The tutor will then answer from those pages and cite them." /></div>
        ) : (
          <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {resources.map((resource) => (
              <div key={resource.id} className="rounded-xl border border-line bg-elevated/30 p-3">
                <div className="flex items-start gap-2">
                  <span className={cn('mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg',
                    resource.status === 'ready' ? 'bg-ok/10 text-ok' : resource.status === 'empty' ? 'bg-warn/10 text-warn' : 'bg-bad/10 text-bad')}>
                    {resource.status === 'ready' ? <CheckCircle2 size={16} /> : resource.status === 'empty' ? <AlertTriangle size={16} /> : <FileText size={16} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <button onClick={() => void openDetail(resource)} className="block w-full truncate text-left text-sm font-semibold text-ink hover:text-brand">{resource.name}</button>
                    <div className="mt-0.5 text-[10px] text-muted">
                      {KINDS.find((k) => k.value === resource.kind)?.label ?? resource.kind} · {resource.pageCount} pages · {resource.chunkCount} chunks
                    </div>
                  </div>
                  <button onClick={() => setDeleting(resource)} className="text-muted transition hover:text-bad" aria-label="Delete resource"><Trash2 size={14} /></button>
                </div>
                {resource.chapters.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {resource.chapters.slice(0, 3).map((c) => <Badge key={c}>{c}</Badge>)}
                    {resource.chapters.length > 3 && <Badge>+{resource.chapters.length - 3}</Badge>}
                  </div>
                )}
                {resource.summary && <p className="mt-2 line-clamp-2 text-[11px] text-muted">{resource.summary}</p>}
                {resource.error && <p className="mt-2 text-[11px] text-warn">{resource.error}</p>}
                <div className="mt-2 flex gap-1.5">
                  <button onClick={() => void openDetail(resource)} className="chip hover:border-brand/40 hover:text-ink">Open</button>
                  {resource.status === 'ready' && (
                    <>
                      <a href={`/api/resources/${resource.id}/file`} target="_blank" rel="noreferrer" className="chip hover:text-ink">Original</a>
                      <button onClick={() => void openDetail(resource)} className="chip hover:border-brand/40 hover:text-ink"><Sparkles size={10} /> Analyse</button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Modal open={pasteOpen} onClose={() => setPasteOpen(false)} title="Paste chapter text" description="Use this for scanned pages, handwritten notes you typed out, or text copied from an e-book." size="lg"
        footer={<><Button variant="secondary" onClick={() => setPasteOpen(false)}>Cancel</Button><Button onClick={() => void uploadPasted()} loading={extracting}>Save &amp; index</Button></>}>
        <div className="space-y-3">
          <Field label="Title"><Input value={pasteName} onChange={(e) => setPasteName(e.target.value)} placeholder="Physics — Ray Optics notes" /></Field>
          <Field label="Text"><Textarea value={pasteText} onChange={(e) => setPasteText(e.target.value)} className="min-h-[280px] font-mono text-xs" placeholder="Paste article/chapter text here…" /></Field>
        </div>
      </Modal>

      <Modal open={detail !== null || detailLoading} onClose={() => setDetail(null)} title={detail?.resource.name ?? 'Loading…'} description={detail ? `${detail.resource.pageCount} pages · ${detail.resource.chunkCount} chunks · ${detail.resource.subject ?? 'no subject'}` : undefined} size="lg">
        {detailLoading ? <Spinner /> : detail && (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {ANALYSIS.map((a) => (
                <Button key={a.kind} variant="secondary" className="px-3 py-2 text-xs" disabled={!aiEnabled || Boolean(analyzing)}
                  loading={analyzing === a.kind} onClick={() => void analyze(a.kind)}>
                  <Sparkles size={13} /> {a.label}
                </Button>
              ))}
              {!aiEnabled && <p className="text-[11px] text-muted">Add OPENAI_API_KEY to run document analysis.</p>}
            </div>

            {insightData && (
              <div className="rounded-xl border border-brand/25 bg-brand/5 p-3 text-xs">
                <div className="mb-1.5 font-semibold text-brand">Analysis output</div>
                <pre className="max-h-64 overflow-auto whitespace-pre-wrap font-sans text-[11px] leading-relaxed text-ink/90">{JSON.stringify(insightData, null, 2)}</pre>
              </div>
            )}

            <div>
              <div className="label">Indexed passages (first {detail.chunks.length})</div>
              <div className="max-h-72 space-y-2 overflow-y-auto pr-1 scroll-thin">
                {detail.chunks.map((chunk) => (
                  <div key={chunk.id} className="rounded-lg border border-line bg-elevated/30 p-2.5 text-[11px]">
                    <div className="mb-1 font-semibold text-brand">Page {chunk.page}</div>
                    <p className="line-clamp-5 text-ink/80">{chunk.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={deleting !== null}
        title="Delete this resource?"
        body={`“${deleting?.name ?? ''}” and its ${deleting?.chunkCount ?? 0} indexed passages will be removed. Questions already generated from it stay in your bank.`}
        confirmLabel="Delete resource"
        danger
        onConfirm={() => void remove()}
        onCancel={() => setDeleting(null)}
      />
    </div>
  );
}
