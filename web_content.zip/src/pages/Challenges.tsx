import { useState } from 'react';
import { CalendarCheck, Check, Clock3, Gift, Target, Trophy } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader';
import { Badge } from '../components/ui/Feedback';
import { ProgressBar, SectionHeader } from '../components/ui/Card';
import { claimChallenge, getChallenges, type ChallengeFrequency } from '../services/gamification';
import { EMPTY_WALLET } from '../services/economy';
import { EMPTY_FARM } from '../services/farmModel';
import { KEYS, useStored } from '../services/storage';
import { Link } from 'react-router-dom';

function ChallengeList({ frequency, onClaim }: { frequency: ChallengeFrequency; onClaim: (id: string) => void }) {
  const items = getChallenges().filter((item) => item.frequency === frequency);
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <article key={`${item.id}:${item.periodKey}`} className="card p-4">
          <div className="flex items-start gap-3">
            <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${item.completed ? 'bg-[var(--success)]/10 text-[var(--success)]' : 'bg-[var(--gold-soft)] text-[var(--gold)]'}`}>
              {item.completed ? <Check size={19} /> : item.metric === 'studyMinutes' ? <Clock3 size={19} /> : <Target size={19} />}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2"><h2 className="text-sm font-semibold text-[var(--ink)]">{item.title}</h2>{item.claimed ? <Badge tone="success">استُلمت</Badge> : item.completed ? <Badge tone="gold">مكتمل</Badge> : null}</div>
              <p className="mt-1 text-xs leading-relaxed text-[var(--ink-soft)]">{item.description}</p>
              <p className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">{item.progressLabel}</p>
              <div className="mt-3 flex items-center justify-between text-[0.67rem] text-[var(--ink-soft)]"><span>{item.progress} / {item.goal}</span><span className="flex items-center gap-1 text-[var(--gold)]"><Gift size={13} /> {item.reward} نقاط</span></div>
              <ProgressBar value={(item.progress / item.goal) * 100} className="mt-1.5" height={6} />
              {item.completed && !item.claimed ? <button type="button" onClick={() => onClaim(item.id)} className="focus-ring mt-3 min-h-10 rounded-full bg-[var(--brand)] px-4 text-xs font-semibold text-[var(--brand-ink)]">استلم {item.reward} نقطة</button> : null}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

export default function Challenges() {
  const [notice, setNotice] = useState('');
  useStored(KEYS.wallet, EMPTY_WALLET);
  useStored(KEYS.stats, { days: {} });
  useStored(KEYS.progress, {});
  useStored(KEYS.quizzes, []);
  useStored(KEYS.cards, {});
  useStored(KEYS.studySessions, []);
  useStored(KEYS.farm, EMPTY_FARM);
  useStored(KEYS.practiceAttempts, []);
  useStored(KEYS.writtenAnswers, []);
  const challenges = getChallenges();
  const done = challenges.filter((item) => item.completed).length;
  const claimed = challenges.filter((item) => item.claimed).length;

  const claim = async (id: string) => {
    const ok = await claimChallenge(id);
    setNotice(ok ? 'أضيفت مكافأة التحدي إلى رصيدك.' : 'لم تعد هذه المكافأة متاحة للاستلام.');
  };

  return (
    <div>
      <PageHeader eyebrow="خطوات صغيرة، تقدّم كبير" title="التحديات" subtitle="اخترنا لك ٥ تحديات يومية من مكتبة متجددة، إلى جانب أهداف الأسبوع. استلم كل مكافأة مرة واحدة." />
      <div className="mb-5 flex items-center justify-between rounded-3xl bg-[var(--surface-2)] p-4">
        <div><p className="text-[0.68rem] text-[var(--ink-soft)]">تحديات مكتملة الآن</p><p className="font-display text-2xl text-[var(--ink)]">{done}<span className="mx-1 text-sm text-[var(--ink-soft)]">/ {challenges.length}</span></p></div>
        <div className="text-end"><p className="text-[0.68rem] text-[var(--ink-soft)]">مكافآت مستلمة</p><p className="flex items-center justify-end gap-1 font-semibold text-[var(--gold)]"><Trophy size={15} />{claimed}</p></div>
      </div>
      {notice ? <p role="status" className="mb-3 rounded-2xl bg-[var(--gold-soft)] px-3 py-2 text-xs text-[var(--ink)]">{notice}</p> : null}
      <section className="mb-6"><SectionHeader title="تحديات اليوم" hint="تتجدد عند منتصف الليل حسب توقيت جهازك" /><ChallengeList frequency="daily" onClaim={claim} /></section>
      <section><SectionHeader title="تحديات الأسبوع" hint="تبدأ من يوم الاثنين" /><ChallengeList frequency="weekly" onClaim={claim} /></section>
      <Link to="/shop" className="focus-ring mt-5 flex min-h-12 items-center justify-center gap-2 rounded-2xl border border-[var(--line)] text-sm text-[var(--ink)]"><CalendarCheck size={16} /> إلى متجر النقاط</Link>
    </div>
  );
}
