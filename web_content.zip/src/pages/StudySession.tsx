import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, CheckCircle2, Clock3, Pause, Play, Sprout, Timer } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader';
import { useStudySession } from '../hooks/useStudySession';
import { useSettings } from '../hooks/useSettings';
import { subjects } from '../data/content';
import { StudySoundPanel } from '../components/study/StudySoundPanel';
import { STUDY_RECITATIONS } from '../data/studyAudio';

function clock(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(safe / 60);
  const rest = safe % 60;
  return `${minutes.toString().padStart(2, '0')}:${rest.toString().padStart(2, '0')}`;
}

const timerSkins = [
  { id: 'classic' as const, label: 'رقمي', hint: 'واضح وبسيط' },
  { id: 'ring' as const, label: 'دائري', hint: 'حلقة تقدم' },
  { id: 'focus' as const, label: 'هادئ', hint: 'تركيز بلا زحمة' },
];

function TimerReadout({ skin, elapsed, planned }: { skin: 'classic' | 'ring' | 'focus'; elapsed: number; planned: number }) {
  const progress = planned > 0 ? Math.min(100, Math.round((elapsed / planned) * 100)) : 0;
  const radius = 82;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - progress / 100);

  if (skin === 'ring') {
    return (
      <div className="my-5 flex flex-col items-center text-center">
        <div className="relative h-56 w-56 max-w-full" role="progressbar" aria-label="تقدم جلسة الدراسة" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
          <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90" aria-hidden="true">
            <circle cx="100" cy="100" r={radius} fill="none" stroke="var(--surface-2)" strokeWidth="10" />
            <circle cx="100" cy="100" r={radius} fill="none" stroke="var(--brand)" strokeWidth="10" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={dashOffset} className="transition-[stroke-dashoffset] duration-500" />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-mono text-4xl font-semibold tabular-nums tracking-tight text-[var(--ink)]" dir="ltr" aria-label={`الوقت المنقضي ${clock(elapsed)}`}>{clock(elapsed)}</span>
            <span className="mt-1 text-xs text-[var(--ink-soft)]">من {clock(planned)}</span>
          </div>
        </div>
        <span className="mt-2 text-xs text-[var(--ink-soft)]">أُنجز {progress}٪ من الجلسة</span>
      </div>
    );
  }

  if (skin === 'focus') {
    return (
      <div className="my-6 rounded-[2rem] bg-[var(--brand)] px-4 py-8 text-center text-[var(--brand-ink)]">
        <p className="text-xs opacity-75">وقت تركيزك</p>
        <p className="mt-2 font-mono text-6xl font-semibold tabular-nums tracking-tight" dir="ltr" aria-label={`الوقت المنقضي ${clock(elapsed)}`}>{clock(elapsed)}</p>
        <p className="mt-2 text-sm opacity-80">من أصل {clock(planned)} · {progress}٪</p>
        <div className="mx-auto mt-5 h-1.5 max-w-xs overflow-hidden rounded-full bg-black/15">
          <div className="h-full rounded-full bg-[var(--brand-ink)] transition-[width] duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>
    );
  }

  return (
    <div className="my-7 text-center">
      <p className="font-mono text-5xl font-semibold tabular-nums tracking-tight text-[var(--ink)] sm:text-6xl" dir="ltr" aria-label={`الوقت المنقضي ${clock(elapsed)}`}>{clock(elapsed)}</p>
      <p className="mt-2 text-sm text-[var(--ink-soft)]">من أصل <span className="font-mono tabular-nums" dir="ltr">{clock(planned)}</span></p>
      <div className="mx-auto mt-4 h-2 max-w-sm overflow-hidden rounded-full bg-[var(--surface-2)]" role="progressbar" aria-label="تقدم جلسة الدراسة" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full rounded-full bg-[var(--brand)] transition-[width] duration-500" style={{ width: `${progress}%` }} />
      </div>
    </div>
  );
}

export default function StudySession() {
  const session = useStudySession();
  const { settings, update } = useSettings();
  const [subjectId, setSubjectId] = useState(session.subjectId || subjects[0]?.id || 'math');
  const [durationMinutes, setDurationMinutes] = useState<25 | 50>(25);
  const [notice, setNotice] = useState('');
  const selectedSubject = subjects.find((subject) => subject.id === subjectId) ?? subjects[0];
  const running = session.status === 'running';
  const paused = session.status === 'paused';
  const completed = session.status === 'completed';
  const timerSkin = settings.timerSkin ?? 'classic';

  useEffect(() => {
    if (session.subjectId) setSubjectId(session.subjectId);
  }, [session.subjectId]);

  useEffect(() => {
    if (!window.location.hash.endsWith('#study-audio')) return;
    window.requestAnimationFrame(() => document.getElementById('study-audio')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  }, []);

  const stateLabel = running
    ? 'الجلسة نشطة'
    : paused
      ? session.pauseReason === 'hidden'
        ? 'توقفت لأن التطبيق كان بالخلفية'
        : session.pauseReason === 'idle'
          ? 'توقفت تلقائياً بعد خمس دقائق بلا نشاط'
          : 'الجلسة متوقفة مؤقتاً'
      : completed
        ? 'اكتملت الجلسة'
        : 'جاهز للدراسة';
  const elapsed = session.status === 'idle' ? 0 : session.elapsedSeconds;
  const planned = session.status === 'idle' ? durationMinutes * 60 : session.durationSeconds;

  const chooseSkin = (skin: typeof timerSkins[number]['id']) => {
    setNotice('');
    if (!update({ timerSkin: skin })) setNotice('طُبق شكل المؤقت الآن، لكن المتصفح لم يحفظ تفضيلك على الجهاز.');
  };

  return (
    <div className="space-y-5 pb-6">
      <PageHeader eyebrow="ابدأ بوقت واضح وخطوة واحدة" title="جلسة الدراسة" subtitle="المؤقت ظاهر طوال الجلسة. اختر شكله، ويمكنك الانتقال لأي صفحة من دون إيقافها." />

      <section className="card overflow-hidden p-5 sm:p-7" aria-live="polite">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-sm font-semibold text-[var(--ink)]">
            <span className={`flex h-10 w-10 items-center justify-center rounded-2xl ${running ? 'bg-[var(--success)]/10 text-[var(--success)]' : 'bg-[var(--surface-2)] text-[var(--ink-soft)]'}`}>
              {completed ? <CheckCircle2 size={20} /> : <Timer size={20} />}
            </span>
            {stateLabel}
          </span>
          <span className="rounded-full bg-[var(--surface-2)] px-3 py-1 text-xs text-[var(--ink-soft)]">{selectedSubject?.name ?? 'اختر مادة'}</span>
        </div>

        <TimerReadout skin={timerSkin} elapsed={elapsed} planned={planned} />

        <fieldset className="mb-5">
          <legend className="mb-2 text-xs font-medium text-[var(--ink-soft)]">شكل المؤقت</legend>
          <div className="grid grid-cols-3 gap-2">
            {timerSkins.map((skin) => (
              <button key={skin.id} type="button" aria-pressed={timerSkin === skin.id} onClick={() => chooseSkin(skin.id)} className={`focus-ring min-h-11 rounded-2xl border px-2 py-1 text-center ${timerSkin === skin.id ? 'border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]' : 'border-[var(--line)] text-[var(--ink-soft)]'}`}>
                <span className="block text-xs font-semibold">{skin.label}</span><span className="block text-[0.62rem]">{skin.hint}</span>
              </button>
            ))}
          </div>
          {notice ? <p role="status" className="mt-2 text-xs text-[var(--ink-soft)]">{notice}</p> : null}
        </fieldset>

        {session.status === 'idle' || completed ? (
          <div className="space-y-4">
            {completed ? <p className="rounded-2xl bg-[var(--success)]/10 px-4 py-3 text-sm text-[var(--success)]">أحسنت. أُغلقت الجلسة وحُفظ وقتها النشط على هذا الجهاز.</p> : null}
            <label className="block text-sm font-medium text-[var(--ink)]" htmlFor="study-session-subject">مادة الجلسة
              <select id="study-session-subject" value={subjectId} onChange={(event) => setSubjectId(event.target.value)} className="focus-ring mt-2 min-h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]">
                {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
              </select>
            </label>
            <fieldset>
              <legend className="mb-2 text-sm font-medium text-[var(--ink)]">مدة الجلسة</legend>
              <div className="grid grid-cols-2 gap-2">
                {([25, 50] as const).map((minutes) => (
                  <button key={minutes} type="button" aria-pressed={durationMinutes === minutes} onClick={() => setDurationMinutes(minutes)} className={`focus-ring min-h-11 rounded-2xl border px-4 text-sm font-semibold transition-colors ${durationMinutes === minutes ? 'border-[var(--brand)] bg-[var(--brand)] text-[var(--brand-ink)]' : 'border-[var(--line)] bg-[var(--surface)] text-[var(--ink)]'}`}>
                    {minutes} دقيقة
                  </button>
                ))}
              </div>
            </fieldset>
            <button type="button" disabled={!selectedSubject} onClick={() => selectedSubject && session.start(selectedSubject.id, durationMinutes)} className="focus-ring flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-[var(--brand)] px-4 text-sm font-semibold text-[var(--brand-ink)] disabled:opacity-50">
              <Play size={18} fill="currentColor" /> {completed ? 'ابدأ جلسة جديدة' : 'ابدأ جلسة الدراسة'}
            </button>
          </div>
        ) : (
          <div className="flex flex-wrap justify-center gap-2">
            {running ? (
              <button type="button" onClick={session.pause} className="focus-ring flex min-h-11 min-w-36 items-center justify-center gap-2 rounded-2xl border border-[var(--line)] px-4 text-sm font-medium text-[var(--ink)]"><Pause size={17} /> إيقاف مؤقت</button>
            ) : (
              <button type="button" onClick={session.resume} className="focus-ring flex min-h-11 min-w-36 items-center justify-center gap-2 rounded-2xl bg-[var(--brand)] px-4 text-sm font-semibold text-[var(--brand-ink)]"><Play size={17} fill="currentColor" /> استئناف الجلسة</button>
            )}
            <button type="button" onClick={session.end} className="focus-ring min-h-11 rounded-2xl border border-[var(--line)] px-4 text-sm text-[var(--ink-soft)]">إنهاء الجلسة</button>
          </div>
        )}
      </section>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="card flex items-start gap-3 p-4"><Clock3 size={18} className="mt-0.5 shrink-0 text-[var(--gold)]" /><p className="text-xs leading-relaxed text-[var(--ink-soft)]">يتوقف العداد عند إخفاء التطبيق أو بعد خمس دقائق بلا تفاعل. يمكنك استئنافه يدوياً عند عودتك.</p></div>
        <Link to="/farm" className="focus-ring card flex min-h-16 items-center gap-3 p-4 text-sm font-medium text-[var(--ink)]"><Sprout size={19} className="text-[var(--success)]" /> شاهد نمو مزرعتك مع الدراسة</Link>
      </div>

      <StudySoundPanel recitations={STUDY_RECITATIONS} />
      <Link to={selectedSubject ? `/subject/${selectedSubject.id}` : '/subjects'} className="focus-ring inline-flex min-h-11 items-center gap-2 rounded-xl px-2 text-sm text-[var(--ink-soft)] underline-offset-4 hover:underline"><BookOpen size={16} /> انتقل إلى دروس المادة</Link>
    </div>
  );
}
