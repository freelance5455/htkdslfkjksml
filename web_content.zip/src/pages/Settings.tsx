import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen,
  Download,
  Info,
  Languages,
  Monitor,
  Moon,
  RotateCcw,
  Sun,
  Trash2,
  Upload,
} from 'lucide-react';
import { useSettings } from '../hooks/useSettings';
import { useProfile } from '../hooks/useProfile';
import { useToast } from '../hooks/useToast';
import { downloadBackup, importBackupFile, resetEverything } from '../services/exportImport';
import { clearProgress } from '../services/progress';
import { PageHeader } from '../components/layout/PageHeader';
import { Modal } from '../components/ui/Feedback';
import { Button } from '../components/ui/Button';
import { cn, formatDate } from '../utils/format';

export default function Settings() {
  const { settings, update } = useSettings();
  const { profile } = useProfile();
  const { toast } = useToast();
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [progressResetOpen, setProgressResetOpen] = useState(false);
  const [howOpen, setHowOpen] = useState(false);

  const themes = [
    { id: 'light' as const, label: 'نهاري', icon: Sun },
    { id: 'dark' as const, label: 'ليلي', icon: Moon },
    { id: 'system' as const, label: 'النظام', icon: Monitor },
  ];
  const palettes = [
    { id: 'ocean' as const, label: 'المحيط', color: '#0b2a3f' },
    { id: 'forest' as const, label: 'الغابة', color: '#17654c' },
    { id: 'violet' as const, label: 'البنفسج', color: '#62469c' },
    { id: 'rose' as const, label: 'الورد', color: '#98465f' },
    { id: 'amber' as const, label: 'العنبر', color: '#8a570e' },
  ];
  const timerSkins = [
    { id: 'classic' as const, label: 'رقمي' },
    { id: 'ring' as const, label: 'دائري' },
    { id: 'focus' as const, label: 'هادئ' },
  ];

  const handleImport = async (file: File | undefined) => {
    if (!file) return;
    const result = await importBackupFile(file);
    toast(result.message, result.ok ? 'success' : 'error');
    if (result.ok) window.setTimeout(() => window.location.reload(), 800);
  };

  const handleExport = async () => {
    try {
      await downloadBackup();
      toast('تم تنزيل النسخة الاحتياطية على جهازك.', 'success');
    } catch {
      toast('تعذّر أخذ لقطة آمنة للبيانات؛ لم يُنزّل ملف ناقص.', 'error');
    }
  };

  return (
    <div className="pb-6">
      <PageHeader title="الإعدادات" subtitle="المظهر، الخط، البيانات — كل شيء محلي على جهازك." back="/" />

      <section className="card mb-3 p-4">
        <p className="mb-2 text-[0.78rem] font-medium text-[var(--ink)]">المظهر</p>
        <div className="grid grid-cols-3 gap-2">
          {themes.map((theme) => (
            <button
              key={theme.id}
              type="button"
              onClick={() => {
                const saved = update({ theme: theme.id });
                if (!saved) toast('طُبّق المظهر لهذه الجلسة، لكن المتصفح لم يحفظه على الجهاز. أفرغ مساحة التخزين ثم أعد المحاولة.', 'error');
              }}
              className={cn(
                'focus-ring flex h-16 flex-col items-center justify-center gap-1 rounded-2xl border text-[0.7rem]',
                settings.theme === theme.id
                  ? 'border-[var(--gold)] bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]'
                  : 'border-[var(--line)] text-[var(--ink-soft)]',
              )}
              aria-pressed={settings.theme === theme.id}
            >
              <theme.icon size={17} />
              {theme.label}
            </button>
          ))}
        </div>
        <div className="mt-4">
          <p className="mb-2 text-[0.72rem] font-medium text-[var(--ink)]">لون المنارة</p>
          <div className="grid grid-cols-5 gap-2">
            {palettes.map((palette) => (
              <button key={palette.id} type="button" aria-label={`لون ${palette.label}`} aria-pressed={(settings.palette ?? 'ocean') === palette.id} onClick={() => {
                if (!update({ palette: palette.id })) toast('طُبّق اللون لهذه الجلسة، لكن المتصفح لم يحفظه على الجهاز.', 'error');
              }} className={cn('focus-ring flex min-h-11 flex-col items-center justify-center gap-1 rounded-xl border text-[0.58rem]', (settings.palette ?? 'ocean') === palette.id ? 'border-[var(--ink)] text-[var(--ink)]' : 'border-[var(--line)] text-[var(--ink-soft)]')}>
                <span aria-hidden="true" className="h-4 w-4 rounded-full" style={{ backgroundColor: palette.color }} />{palette.label}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-4">
          <p className="mb-2 text-[0.72rem] font-medium text-[var(--ink)]">شكل مؤقت الدراسة</p>
          <div className="grid grid-cols-3 gap-2">
            {timerSkins.map((skin) => (
              <button key={skin.id} type="button" aria-pressed={(settings.timerSkin ?? 'classic') === skin.id} onClick={() => {
                if (!update({ timerSkin: skin.id })) toast('طُبق شكل المؤقت، لكن المتصفح لم يحفظ التفضيل على الجهاز.', 'error');
              }} className={cn('focus-ring min-h-11 rounded-xl border px-1 text-[0.68rem]', (settings.timerSkin ?? 'classic') === skin.id ? 'border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]' : 'border-[var(--line)] text-[var(--ink-soft)]')}>
                {skin.label}
              </button>
            ))}
          </div>
          <p className="mt-1 text-[0.62rem] text-[var(--ink-soft)]">يمكنك تغيير الشكل أيضاً من صفحة جلسة الدراسة.</p>
        </div>
      </section>

      <section className="card mb-3 p-4">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-[0.78rem] font-medium text-[var(--ink)]">حجم الخط</p>
          <span className="text-[0.7rem] text-[var(--ink-soft)]">{Math.round(settings.fontScale * 100)}%</span>
        </div>
        <input
          type="range"
          min={0.9}
          max={1.3}
          step={0.05}
          value={settings.fontScale}
          onChange={(e) => update({ fontScale: Number(e.target.value) })}
          aria-label="حجم الخط"
          className="h-2 w-full cursor-pointer appearance-none rounded-full bg-[var(--surface-2)] accent-[var(--gold)]"
        />
        <p className="mt-2 text-[0.72rem] leading-relaxed text-[var(--ink-soft)]">
          معاينة: «النهاية موجودة إذا تساوت النهايتان الجانبيتان.»
        </p>
      </section>

      <section className="card mb-3 p-4">
        <div className="mb-2 flex items-center gap-2">
          <Languages size={15} className="text-[var(--ink-soft)]" />
          <p className="text-[0.78rem] font-medium text-[var(--ink)]">لغة الواجهة</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            className="focus-ring h-11 rounded-2xl border border-[var(--gold)] bg-[var(--gold-soft)] text-[0.78rem] text-[#8a5b06] dark:text-[var(--gold)]"
          >
            العربية
          </button>
          <button
            type="button"
            disabled
            className="focus-ring h-11 rounded-2xl border border-[var(--line)] text-[0.78rem] text-[var(--ink-soft)] opacity-60"
          >
            English (قريباً)
          </button>
        </div>
      </section>

      <section className="card mb-3 divide-y divide-[var(--line)] p-1">
        <ToggleRow
          title="توفير البيانات"
          hint="يثبّت أقل جودة متاحة لتخفيف استهلاك الإنترنت."
          checked={settings.dataSaver}
          onChange={(v) => update({ dataSaver: v })}
        />
        <ToggleRow
          title="تشغيل الدرس التالي تلقائياً"
          hint="عدّاد ٥ ثوانٍ بعد نهاية الدرس، ويمكن إلغاؤه."
          checked={settings.autoplayNext}
          onChange={(v) => update({ autoplayNext: v })}
        />
      </section>

      <section className="card mb-3 p-4">
        <p className="mb-1 text-[0.78rem] font-medium text-[var(--ink)]">ملفي</p>
        <p className="text-[0.72rem] leading-relaxed text-[var(--ink-soft)]">
          {profile.name || 'لم يُسجّل اسم بعد'} · {profile.governorate || '—'} · هدف {profile.targetAverage}% ·{' '}
          {formatDate(profile.examDate)}
        </p>
        <Button size="sm" variant="outline" className="mt-2" onClick={() => navigate('/welcome')}>
          تعديل بياناتي
        </Button>
      </section>

      <section className="card mb-3 space-y-2 p-4">
        <p className="text-[0.78rem] font-medium text-[var(--ink)]">البيانات</p>
        <p className="text-[0.68rem] leading-relaxed text-[var(--ink-soft)]">
          نسخة JSON تحتوي تقدمك، ملاحظاتك، نتائجك، وخطتك. مفيدة لنقل بياناتك إلى جهاز آخر.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="soft" icon={<Download size={15} />} onClick={() => void handleExport()}>
            تصدير
          </Button>
          <Button size="sm" variant="soft" icon={<Upload size={15} />} onClick={() => fileRef.current?.click()}>
            استيراد
          </Button>
          <Button size="sm" variant="outline" icon={<RotateCcw size={15} />} onClick={() => setProgressResetOpen(true)}>
            تصفير التقدم
          </Button>
          <Button size="sm" variant="danger" icon={<Trash2 size={15} />} onClick={() => setResetOpen(true)}>
            تصفير كل شيء
          </Button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => void handleImport(e.target.files?.[0])}
        />
      </section>

      <section className="card mb-3 p-4">
        <button
          type="button"
          onClick={() => setHowOpen(true)}
          className="focus-ring flex w-full items-center gap-2 text-start"
        >
          <BookOpen size={16} className="text-[var(--ink-soft)]" />
          <span className="flex-1 text-[0.78rem] font-medium text-[var(--ink)]">كيف أضيف مادة أو درساً أو مدرّساً؟</span>
          <Info size={14} className="text-[var(--ink-soft)]" />
        </button>
      </section>

      <p className="pb-4 text-center text-[0.65rem] leading-relaxed text-[var(--ink-soft)]">
        منارة البكالوريا · نسخة التجربة الأولى (1.0.0)
        <br />
        محتوى تجريبي بأسماء نائبة — استبدله بمحتواك من ملف واحد.
      </p>

      <Modal open={resetOpen} onClose={() => setResetOpen(false)} title="تصفير كل شيء؟">
        <p className="text-[0.8rem] leading-relaxed text-[var(--ink-soft)]">
          سيُحذف ملفك وتقدمك وملاحظاتك ونتائجك وخطتك نهائياً من هذا الجهاز. لا يمكن التراجع. صدّر نسخة احتياطية أولاً إن أردت.
        </p>
        <div className="mt-4 flex gap-2">
          <Button
            block
            variant="danger"
            onClick={async () => {
              const result = await resetEverything();
              if (!result.ok) {
                toast(result.rollbackComplete ? 'لم يكتمل التصفير؛ أُعيدت البيانات السابقة ولم يُحذف شيء.' : 'تعذّر تأكيد استعادة البيانات السابقة. أبقِ التطبيق مفتوحاً وصدّر نسخة عند توفر مساحة.', 'error');
                return;
              }
              if (import.meta.env.MODE === 'standalone') {
                window.location.hash = '#/welcome';
              } else {
                window.location.href = '/welcome';
              }
            }}
          >
            نعم، صفّر كل شيء
          </Button>
          <Button variant="outline" onClick={() => setResetOpen(false)}>
            إلغاء
          </Button>
        </div>
      </Modal>

      <Modal open={progressResetOpen} onClose={() => setProgressResetOpen(false)} title="تصفير التقدم؟">
        <p className="text-[0.8rem] leading-relaxed text-[var(--ink-soft)]">
          سيُحذف موضع كل درس وعلامات «تمت المشاهدة»، وتبقى ملاحظاتك ونتائجك. مفيد إذا أردت إعادة المنهاج من البداية.
        </p>
        <div className="mt-4 flex gap-2">
          <Button
            block
            onClick={() => {
              clearProgress();
              setProgressResetOpen(false);
              toast('صُفّر التقدم', 'info');
            }}
          >
            تصفير التقدم
          </Button>
          <Button variant="outline" onClick={() => setProgressResetOpen(false)}>
            إلغاء
          </Button>
        </div>
      </Modal>

      <Modal open={howOpen} onClose={() => setHowOpen(false)} title="إضافة محتوى" size="lg">
        <div className="space-y-3 text-[0.78rem] leading-relaxed text-[var(--ink-soft)]">
          <p>
            كل المحتوى في ملف واحد: <code className="rounded bg-[var(--surface-2)] px-1">src/data/content.ts</code>. أضف
            المادة الجديدة إلى مصفوفة <code className="rounded bg-[var(--surface-2)] px-1">subjects</code> بنفس شكل
            {' '}
            <code className="rounded bg-[var(--surface-2)] px-1">mathSubject</code>.
          </p>
          <p>
            الدرس يُضاف داخل <code className="rounded bg-[var(--surface-2)] px-1">buildUnit(...)</code> كعنصر في المصفوفة:
            {' '}
            <code className="rounded bg-[var(--surface-2)] px-1">id, title, desc, video, dur, obj, ch, quiz</code>.
          </p>
          <p>
            الفيديو: ضع معرّف يوتيوب (١١ حرفاً) أو الرابط كاملاً — التطبيق يستخرجه تلقائياً. المدرّس الجديد يُضاف إلى
            {' '}
            <code className="rounded bg-[var(--surface-2)] px-1">teachers</code> مع صورة اختيارية
            {' '}
            <code className="rounded bg-[var(--surface-2)] px-1">avatarUrl</code>.
          </p>
        </div>
      </Modal>
    </div>
  );
}

function ToggleRow({
  title,
  hint,
  checked,
  onChange,
}: {
  title: string;
  hint: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-3 p-3">
      <div className="min-w-0">
        <p className="text-[0.78rem] text-[var(--ink)]">{title}</p>
        <p className="mt-0.5 text-[0.66rem] leading-relaxed text-[var(--ink-soft)]">{hint}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={title}
        onClick={() => onChange(!checked)}
        className={cn(
          'focus-ring mt-0.5 flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 transition-colors',
          checked ? 'bg-[var(--gold)]' : 'bg-[var(--surface-2)]',
        )}
      >
        <span
          className={cn(
            'h-5 w-5 rounded-full bg-white shadow transition-transform',
            checked ? '-translate-x-5' : 'translate-x-0',
          )}
        />
      </button>
    </div>
  );
}
