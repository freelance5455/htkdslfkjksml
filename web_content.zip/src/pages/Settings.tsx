/* ============================================
   plix_ai studio — Settings
   Privacy, data controls, preferences
   ============================================ */

import { useState } from 'react';
import type { PageId, AppSettings } from '../types';
import { getSettings, saveSettings, deleteAllData, getStats } from '../store';
import {
  IconShield, IconTrash, IconCheck, IconAlertTriangle,
  IconInfo, IconKey
} from '../components/Icons';

interface SettingsProps {
  onNavigate: (page: PageId) => void;
}

export default function Settings({ onNavigate }: SettingsProps) {
  const [settings, setSettings] = useState<AppSettings>(() => getSettings());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleted, setDeleted] = useState(false);
  const stats = getStats();

  function updateSetting<K extends keyof AppSettings>(key: K, value: AppSettings[K]) {
    const next = { ...settings, [key]: value };
    setSettings(next);
    saveSettings(next);
  }

  function handleDeleteAll() {
    if (deleteConfirmText === 'DELETE') {
      deleteAllData();
      setDeleted(true);
      setShowDeleteConfirm(false);
      setDeleteConfirmText('');
    }
  }

  if (deleted) {
    return (
      <div className="animate-fade-in">
        <div className="card text-center py-16">
          <IconCheck size={32} className="text-emerald-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">All Data Deleted</h2>
          <p className="text-sm text-stone-400 mb-6">
            All projects, builds, keystores, and settings have been removed from this browser.
          </p>
          <button onClick={() => { setDeleted(false); onNavigate('landing'); }} className="btn btn-primary">
            Return Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-stone-400 mt-1">Preferences, privacy controls, and data management.</p>
      </div>

      <div className="max-w-2xl space-y-6">
        {/* Preferences */}
        <div className="card">
          <h2 className="text-base font-semibold mb-4">Preferences</h2>
          <div className="space-y-4">
            <SettingToggle
              label="Auto-save projects"
              description="Automatically save project changes to local storage"
              checked={settings.autoSave}
              onChange={v => updateSetting('autoSave', v)}
            />
            <SettingToggle
              label="Show demo badge"
              description="Display the 'Demo Mode' indicator in the sidebar"
              checked={settings.showDemoBadge}
              onChange={v => updateSetting('showDemoBadge', v)}
            />
            <SettingToggle
              label="Build notifications"
              description="Show browser notifications when builds complete"
              checked={settings.buildNotifications}
              onChange={v => updateSetting('buildNotifications', v)}
            />
          </div>
        </div>

        {/* Defaults */}
        <div className="card">
          <h2 className="text-base font-semibold mb-4">Build Defaults</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="input-label">Default Min SDK</label>
              <select
                value={settings.defaultMinSdk}
                onChange={e => updateSetting('defaultMinSdk', parseInt(e.target.value) as any)}
                className="input"
              >
                <option value={21}>API 21 (Android 5.0)</option>
                <option value={23}>API 23 (Android 6.0)</option>
                <option value={24}>API 24 (Android 7.0)</option>
                <option value={26}>API 26 (Android 8.0)</option>
                <option value={28}>API 28 (Android 9.0)</option>
              </select>
            </div>
            <div>
              <label className="input-label">Default Output Format</label>
              <select
                value={settings.defaultOutputFormat}
                onChange={e => updateSetting('defaultOutputFormat', e.target.value as any)}
                className="input"
              >
                <option value="apk">APK</option>
                <option value="aab">AAB (App Bundle)</option>
              </select>
            </div>
            <div>
              <label className="input-label">Keystore Validity (years)</label>
              <input
                type="number"
                value={settings.defaultKeystoreValidity}
                onChange={e => updateSetting('defaultKeystoreValidity', parseInt(e.target.value) || 25)}
                className="input"
                min={1}
                max={100}
              />
            </div>
          </div>
        </div>

        {/* Privacy & Data */}
        <div className="card">
          <h2 className="text-base font-semibold mb-4 flex items-center gap-2">
            <IconShield size={16} className="text-sky-400" />
            Privacy & Data Ownership
          </h2>

          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-sky-500/5 border border-sky-500/15">
              <div className="flex items-start gap-2">
                <IconInfo size={14} className="text-sky-400 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-sky-300/80 leading-relaxed">
                  <p className="font-medium mb-1">Your data stays in your browser.</p>
                  <p>
                    All projects, build configurations, and keystores are stored in your browser's
                    localStorage. Nothing is sent to any server in this demo. You have full control
                    over your data and can delete it at any time.
                  </p>
                </div>
              </div>
            </div>

            {/* Data stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="text-center p-3 rounded-lg surface-2">
                <div className="text-lg font-bold font-mono">{stats.totalProjects}</div>
                <div className="text-xs text-stone-500">Projects</div>
              </div>
              <div className="text-center p-3 rounded-lg surface-2">
                <div className="text-lg font-bold font-mono">{stats.totalBuilds}</div>
                <div className="text-xs text-stone-500">Total Builds</div>
              </div>
              <div className="text-center p-3 rounded-lg surface-2">
                <div className="text-lg font-bold font-mono text-emerald-400">{stats.successfulBuilds}</div>
                <div className="text-xs text-stone-500">Successful</div>
              </div>
              <div className="text-center p-3 rounded-lg surface-2">
                <div className="text-lg font-bold font-mono text-red-400">{stats.failedBuilds}</div>
                <div className="text-xs text-stone-500">Failed</div>
              </div>
            </div>
          </div>
        </div>

        {/* Keystore safety */}
        <div className="card">
          <h2 className="text-base font-semibold mb-4 flex items-center gap-2">
            <IconKey size={16} className="text-sky-400" />
            Keystore Safety
          </h2>
          <div className="space-y-3 text-sm text-stone-300">
            <div className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5 flex-shrink-0">✓</span>
              <span>In production, all keystore passwords are encrypted with AES-256-GCM at rest.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5 flex-shrink-0">✓</span>
              <span>Passwords are never logged, stored in plaintext, or transmitted without encryption.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-emerald-500 mt-0.5 flex-shrink-0">✓</span>
              <span>Build containers are ephemeral — keystores are destroyed with the container.</span>
            </div>
            <div className="flex items-start gap-2">
              <IconAlertTriangle size={14} className="text-amber-500 mt-0.5 flex-shrink-0" />
              <span className="text-amber-400/80">
                In this demo, keystores are stored unencrypted in localStorage.
                Do not use real production keystores here.
              </span>
            </div>
          </div>
        </div>

        {/* Billing concept */}
        <div className="card">
          <h2 className="text-base font-semibold mb-4">Pricing</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { name: 'Free', price: '$0', features: ['5 builds/month', 'APK output', 'Community support'], active: true },
              { name: 'Pro', price: '$19/mo', features: ['Unlimited builds', 'APK + AAB', 'CI/CD API', 'Priority support'], active: false },
              { name: 'Team', price: '$49/mo', features: ['Everything in Pro', 'Team management', 'Custom templates', 'SLA'], active: false },
            ].map(plan => (
              <div key={plan.name} className={`card card-compact ${plan.active ? 'border-sky-500/30' : 'opacity-60'}`}>
                <div className="text-sm font-semibold mb-1">{plan.name}</div>
                <div className="text-xl font-bold mb-2">{plan.price}</div>
                <ul className="space-y-1">
                  {plan.features.map(f => (
                    <li key={f} className="text-xs text-stone-400 flex items-center gap-1.5">
                      <IconCheck size={10} className="text-emerald-500" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  className={`btn btn-sm w-full mt-3 ${plan.active ? 'btn-primary' : 'btn-secondary'}`}
                  disabled={!plan.active}
                >
                  {plan.active ? 'Current Plan' : 'Demo Only'}
                </button>
              </div>
            ))}
          </div>
          <p className="text-xs text-stone-500 mt-3">
            Pricing shown for reference only. No real payments are processed in this demo.
          </p>
        </div>

        {/* Danger zone */}
        <div className="card border-red-500/20">
          <h2 className="text-base font-semibold mb-4 text-red-400">Danger Zone</h2>

          {!showDeleteConfirm ? (
            <div>
              <p className="text-sm text-stone-400 mb-3">
                Delete all projects, build history, keystores, and settings from this browser.
                This action cannot be undone.
              </p>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="btn btn-danger"
              >
                <IconTrash size={16} />
                Delete All Data
              </button>
            </div>
          ) : (
            <div>
              <div className="p-3 rounded-lg bg-red-500/5 border border-red-500/15 mb-4">
                <div className="flex items-start gap-2">
                  <IconAlertTriangle size={14} className="text-red-400 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-red-400/80">
                    This will permanently delete {stats.totalProjects} project(s) and {stats.totalBuilds} build(s).
                    Type <strong>DELETE</strong> to confirm.
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={deleteConfirmText}
                  onChange={e => setDeleteConfirmText(e.target.value)}
                  placeholder='Type "DELETE" to confirm'
                  className="input flex-1"
                  aria-label="Confirm deletion"
                />
                <button
                  onClick={handleDeleteAll}
                  disabled={deleteConfirmText !== 'DELETE'}
                  className="btn btn-danger"
                >
                  Confirm Delete
                </button>
                <button
                  onClick={() => { setShowDeleteConfirm(false); setDeleteConfirmText(''); }}
                  className="btn btn-ghost"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Version info */}
        <div className="text-center text-xs text-stone-600 py-4">
          plix_ai studio v0.1.0-alpha · Built with React + Vite + Tailwind
        </div>
      </div>
    </div>
  );
}

function SettingToggle({ label, description, checked, onChange }: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div className="relative mt-0.5">
        <input
          type="checkbox"
          checked={checked}
          onChange={e => onChange(e.target.checked)}
          className="sr-only peer"
        />
        <div className="w-9 h-5 bg-stone-700 peer-checked:bg-sky-600 rounded-full transition-colors" />
        <div className="absolute top-0.5 left-0.5 w-4 h-4 bg-stone-300 peer-checked:bg-white rounded-full transition-transform peer-checked:translate-x-4" />
      </div>
      <div>
        <span className="text-sm font-medium group-hover:text-sky-400 transition-colors">{label}</span>
        <p className="text-xs text-stone-500 mt-0.5">{description}</p>
      </div>
    </label>
  );
}