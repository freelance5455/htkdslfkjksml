import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search,
  Sparkles,
  ArrowRight,
  TrendingUp,
  History as HistoryIcon,
  Atom,
  Sigma,
  FlaskConical,
  Cpu,
  Rocket,
  Zap,
  Bot,
  BarChart2,
  Calculator,
  Compass,
  Wrench,
  BookOpen
} from 'lucide-react';
import { Formula, Category, CalculationHistoryItem } from '../types';
import { getFormulas, getCategories } from '../firebase/services';
import { FormulaCard } from '../components/formula/FormulaCard';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import { useApp } from '../context/AppContext';
import { getLocalHistory } from '../services/storage';

const categoryIconMap: Record<string, React.ReactNode> = {
  mathematics: <Sigma className="w-5 h-5 text-[#D65A1F]" />,
  physics: <Atom className="w-5 h-5 text-[#D65A1F]" />,
  chemistry: <FlaskConical className="w-5 h-5 text-[#D65A1F]" />,
  engineering: <Cpu className="w-5 h-5 text-[#D65A1F]" />,
  aerospace: <Rocket className="w-5 h-5 text-[#D65A1F]" />,
  electronics: <Zap className="w-5 h-5 text-[#D65A1F]" />,
  robotics: <Bot className="w-5 h-5 text-[#D65A1F]" />,
  statistics: <BarChart2 className="w-5 h-5 text-[#D65A1F]" />
};

export const HomePage: React.FC = () => {
  const { playSound, t } = useApp();
  const navigate = useNavigate();

  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [historyItems, setHistoryItems] = useState<CalculationHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    async function loadData() {
      try {
        const [fList, cList] = await Promise.all([getFormulas(), getCategories()]);
        setFormulas(fList);
        setCategories(cList);
        const localHist = getLocalHistory();
        setHistoryItems(localHist.slice(0, 4));
      } catch (err) {
        console.error('Error loading homepage data:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      playSound('button');
      navigate(`/formulas?search=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate('/formulas');
    }
  };

  // Find featured formula
  const featuredFormula =
    formulas.find((f) => f.featured) || formulas[0] || null;

  // Top popular formulas
  const popularFormulas = [...formulas]
    .sort((a, b) => b.popularity - a.popularity)
    .slice(0, 6);

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative rounded-3xl border border-[#303030] bg-[#151515] p-6 sm:p-10 lg:p-12 overflow-hidden shadow-2xl">
        {/* Subtle orange glow in top right */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#D65A1F]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#232323] border border-[#303030] text-[#D65A1F] text-xs font-mono font-medium">
            <Sigma className="w-3.5 h-3.5 text-[#D65A1F]" />
            <span>FormulaX Pro • Full Engineering Formula Engine</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#F5F2ED] leading-tight">
            Calculate. Understand.{' '}
            <span className="text-[#D65A1F]">Engineer.</span>
          </h1>

          <p className="text-sm sm:text-base text-[#A9A39C] max-w-2xl mx-auto leading-relaxed">
            The modern formula calculator, unknown variable solver, and engineering toolkit for students, physicists, and engineers. Real step-by-step mathematical proofs with validated SI units.
          </p>

          {/* Large Hero Search Bar */}
          <form onSubmit={handleSearchSubmit} className="relative max-w-2xl mx-auto pt-2">
            <div className="relative flex items-center">
              <Search className="absolute left-4 w-5 h-5 text-[#A9A39C]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search 50+ formulas (e.g. Newton, Ohm, Bernoulli, Rocket, Kinetic)..."
                className="w-full pl-12 pr-28 py-3.5 sm:py-4 rounded-2xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED] placeholder-[#A9A39C] text-sm sm:text-base focus:outline-none focus:border-[#D65A1F] shadow-inner transition-all"
              />
              <button
                type="submit"
                onClick={() => playSound('button')}
                className="absolute right-2 px-4 py-2 sm:py-2.5 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-xs sm:text-sm transition-all shadow-md active:scale-95"
              >
                Search
              </button>
            </div>
            <div className="flex items-center justify-center gap-2 mt-3 text-[11px] font-mono text-[#A9A39C] flex-wrap">
              <span>Quick tags:</span>
              <button
                type="button"
                onClick={() => navigate('/formulas?search=newton')}
                className="hover:text-[#D65A1F] underline decoration-[#303030] hover:decoration-[#D65A1F]"
              >
                Newton's Law
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => navigate('/formulas?search=ohm')}
                className="hover:text-[#D65A1F] underline decoration-[#303030] hover:decoration-[#D65A1F]"
              >
                Ohm's Law
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => navigate('/formulas?search=rocket')}
                className="hover:text-[#D65A1F] underline decoration-[#303030] hover:decoration-[#D65A1F]"
              >
                Rocket Equation
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => navigate('/formulas?search=kinetic')}
                className="hover:text-[#D65A1F] underline decoration-[#303030] hover:decoration-[#D65A1F]"
              >
                Kinetic Energy
              </button>
            </div>
          </form>

          {/* Quick Module Access Chips */}
          <div className="flex items-center justify-center gap-2.5 pt-2 flex-wrap">
            <Link
              to="/calculator"
              onClick={() => playSound('tab')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#232323] hover:bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F] text-xs font-semibold text-[#F5F2ED] transition-colors"
            >
              <Calculator className="w-4 h-4 text-[#D65A1F]" />
              <span>Formula Calculator</span>
            </Link>
            <Link
              to="/tools"
              onClick={() => playSound('tab')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#232323] hover:bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F] text-xs font-semibold text-[#F5F2ED] transition-colors"
            >
              <Wrench className="w-4 h-4 text-[#D65A1F]" />
              <span>Engineering Tools</span>
            </Link>
            <Link
              to="/practice"
              onClick={() => playSound('tab')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#232323] hover:bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F] text-xs font-semibold text-[#F5F2ED] transition-colors"
            >
              <Sparkles className="w-4 h-4 text-[#D65A1F]" />
              <span>Practice Mode</span>
            </Link>
            <Link
              to="/scientific-calculator"
              onClick={() => playSound('tab')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#232323] hover:bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F] text-xs font-semibold text-[#F5F2ED] transition-colors"
            >
              <Sigma className="w-4 h-4 text-[#D65A1F]" />
              <span>Scientific Calc</span>
            </Link>
            <Link
              to="/unit-converter"
              onClick={() => playSound('tab')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#232323] hover:bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F] text-xs font-semibold text-[#F5F2ED] transition-colors"
            >
              <Compass className="w-4 h-4 text-[#D65A1F]" />
              <span>Unit Converter</span>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Formula Banner */}
      {featuredFormula && (
        <section className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-6 sm:p-8 shadow-xl">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-[11px] font-mono px-2.5 py-0.5 rounded-md bg-[#232323] text-[#D65A1F] border border-[#303030] font-semibold">
                  <Sparkles className="w-3 h-3 text-[#D65A1F]" />
                  <span>Featured Equation of the Day</span>
                </span>
                <span className="text-[11px] font-mono uppercase text-[#A9A39C] bg-[#151515] px-2 py-0.5 rounded border border-[#303030]">
                  {featuredFormula.category}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#F5F2ED] tracking-tight">
                {featuredFormula.title}
              </h2>
              <p className="text-xs sm:text-sm text-[#A9A39C] max-w-xl leading-relaxed">
                {featuredFormula.description}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0">
              <div className="px-6 py-4 rounded-2xl bg-[#151515] border border-[#303030] font-mono text-center">
                <div className="text-xl sm:text-2xl font-bold text-[#D65A1F]">
                  {featuredFormula.formula}
                </div>
                <div className="text-[10px] text-[#A9A39C] mt-1">
                  Target: {featuredFormula.resultVariable} ({featuredFormula.resultUnit})
                </div>
              </div>

              <button
                onClick={() => {
                  playSound('button');
                  navigate(`/calculator/${featuredFormula.id}`);
                }}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-xs sm:text-sm transition-all shadow-md active:scale-95"
              >
                <Calculator className="w-4 h-4" />
                <span>Open in Calculator</span>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Quick Categories */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-[#F5F2ED] tracking-tight">
              Subject Categories
            </h2>
            <p className="text-xs text-[#A9A39C]">
              Browse formulas organized by academic and technical domain
            </p>
          </div>
          <Link
            to="/categories"
            onClick={() => playSound('tab')}
            className="text-xs font-semibold text-[#D65A1F] hover:underline flex items-center gap-1 font-mono"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {categories.slice(0, 8).map((cat) => (
            <Link
              key={cat.id}
              to={`/category/${cat.id}`}
              onClick={() => playSound('tab')}
              className="group flex flex-col items-center justify-center p-4 rounded-2xl bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F] hover:bg-[#232323] transition-all text-center shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-[#232323] border border-[#303030] flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                {categoryIconMap[cat.slug] || <Sigma className="w-5 h-5 text-[#D65A1F]" />}
              </div>
              <span className="text-xs font-semibold text-[#F5F2ED] group-hover:text-[#D65A1F] transition-colors">
                {cat.name}
              </span>
              <span className="text-[10px] text-[#A9A39C] font-mono mt-0.5">
                {cat.subcategories.length} topics
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Popular Formulas Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#D65A1F]" />
              <h2 className="text-lg sm:text-xl font-bold text-[#F5F2ED] tracking-tight">
                Frequently Used Formulas
              </h2>
            </div>
            <p className="text-xs text-[#A9A39C]">
              Most frequently calculated formulas in science, physics, and engineering
            </p>
          </div>
          <Link
            to="/formulas"
            onClick={() => playSound('tab')}
            className="text-xs font-semibold text-[#D65A1F] hover:underline flex items-center gap-1 font-mono"
          >
            <span>Formula Library ({formulas.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <CardSkeleton />
            <CardSkeleton />
            <CardSkeleton />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {popularFormulas.map((formula) => (
              <FormulaCard key={formula.id} formula={formula} />
            ))}
          </div>
        )}
      </section>

      {/* Recently Used Calculations */}
      {historyItems.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HistoryIcon className="w-4 h-4 text-[#D65A1F]" />
              <h2 className="text-lg sm:text-xl font-bold text-[#F5F2ED] tracking-tight">
                Recent Calculations
              </h2>
            </div>
            <Link
              to="/history"
              onClick={() => playSound('tab')}
              className="text-xs font-semibold text-[#D65A1F] hover:underline flex items-center gap-1 font-mono"
            >
              <span>Full History Log</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {historyItems.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F]/50 transition-all flex flex-col justify-between shadow-sm"
              >
                <div>
                  <div className="text-[10px] font-mono text-[#A9A39C] truncate mb-1">
                    {new Date(item.timestamp).toLocaleDateString()} • {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <h4 className="text-xs font-bold text-[#F5F2ED] truncate mb-1">
                    {item.formulaTitle}
                  </h4>
                  <p className="text-xs font-mono text-[#D65A1F] font-semibold mb-2">
                    {item.targetSymbol} = {item.result} {item.resultUnit}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#303030] flex items-center justify-between text-xs">
                  <span className="font-mono text-[10px] text-[#A9A39C] truncate max-w-[120px]">
                    {item.formulaExpression}
                  </span>
                  <Link
                    to={`/calculator/${item.formulaId}`}
                    onClick={() => playSound('tab')}
                    className="text-[#D65A1F] hover:underline font-semibold text-[11px]"
                  >
                    Recalculate
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
