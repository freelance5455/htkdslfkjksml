import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import { YouTubeFactoryDashboard } from "@/components/features/youtubeFactory/YouTubeFactoryDashboard";

export default function YouTubeFactoryPage() {
  return (
    <AppLayout
      title="YouTube AI Channel Factory"
      subtitle="Sistema profissional de criação, roteirização estruturada, conformidade e otimização de canais de IA, Dinheiro & Futuro"
    >
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <YouTubeFactoryDashboard />
      </div>
    </AppLayout>
  );
}
