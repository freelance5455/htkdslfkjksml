import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ClipboardList, Play, Sparkles, Trash2, Wand2 } from 'lucide-react';
import type { ExamId, QuestionType, ResourceRow, TestConfig } from '@shared/types';
import { EXAM_LIST, EXAM_PATTERNS } from '@shared/exam';
import { chaptersFor } from '@shared/syllabus';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn, EXAM_SHORT, formatDate } from '../lib/utils';
import {
  Badge, Banner, Button, Card, Checkbox, ConfirmDialog, EmptyState, Field, Input, Modal, Select, SetupCard, Spinner, useToast,
} from '../components/ui';

interface TestListItem {
  id: number;
  title: string;
  exam: string;
  durationMinutes: number;
  totalMarks: number;
  status: string;
  createdAt: string;
  questionCount: number;
  attemptId: number | null;
  config: TestConfig | null;
}

const TYPES_BY_EXAM: Record<string, { value: QuestionType; label: string }[]> = {
  cbse10: [
    { value: 'mcq', label: 'MCQ' },
    { value: 'assertion-reason', label: 'Assertion & Reason' },
    { value: 'short-answer', label: 'Short answer' },
    { value: 'case-based', label: 'Case-based' },
  ],
  cbse12: [
    { value: 'mcq', label: 'MCQ' },
    { value: 'assertion-reason', label: 'Assertion & Reason' },
    { value: 'short-answer', label: 'Short answer' },
    { value: 'case-based', label: 'Case-based' },
    { value: 'long-answer', label: 'Long answer' },
  ],
  'jee-main': [
    { value: 'mcq', label: 'Single correct MCQ' },
    { value: 'numerical', label: 'Numerical value' },
    { value: 'integer', label: 'Integer type' },
  ],
  'jee-advanced': [
    { value: 'mcq', label: 'Single correct' },
    { value: 'multiple-correct', label: 'Multiple correct' },
    { value: 'integer', label: 'Integer type' },
  ],
  custom: [
    { value: 'mcq', label: 'MCQ' },
    { value: 'numerical', label: 'Numerical' },
    { value: 'short-answer', label: 'Short answer' },
  ],
};

export default function TestCentre() {
  const { profile, aiEnabled } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();
  const [tests, setTests] = useState<TestListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [resources, setResources] = useState<ResourceRow[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<TestListItem | null>(null);

  const [exam, setExam] = useState<ExamId>((profile?.exam ?? 'cbse10') as ExamId);
  const [subjects, setSubjects] = useState<string[]>(profile?.subjects.slice(0, 1) ?? []);
  const [chapters, setChapters] = useState<string[]>([]);
  const [types, setTypes] = useState<QuestionType[]>([]);
  const [difficulty, setDifficulty] = useState('medium');
  const [count, setCount] = useState(10);
  const [duration, setDuration] = useState(EXAM_PATTERNS[(profile?.exam ?? 'cbse10') as ExamId].durationMinutes);
  const [negative, setNegative] = useState(EXAM_PATTERNS[(profile?.exam ?? 'cbse10') as ExamId].negativeMarking);
  const [mode, setMode] = useState<'bank' | 'ai'>('bank');
  const [useResources, setUseResources] = useState(false);
  const [resourceIds, setResourceIds] = useState<number[]>([]);

  const pattern = EXAM_PATTERNS[exam];
  const typeOptions = TYPES_BY_EXAM[exam] ?? TYPES_BY_EXAM.custom;
  const examSubjectOptions = pattern.subjects.length ? pattern.subjects : profile?.subjects ?? [];
  const chapterOptions = useMemo(
    () => [...new Set(subjects.flatMap((s) => chaptersFor(exam, s)))],
    [subjects, exam],
  );

  const load = useCallback(async () => {
    try {
      const [testData, resourceData] = await Promise.all([
        api.get<{ tests: TestListItem[] }>('/api/tests'),
        api.get<{ resources: ResourceRow[] }>('/api/resources'),
      ]);
      setTests(testData.tests);
      setResources(resourceData.resources.filter((r) => r.status === 'ready'));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load the test centre.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const changeExam = (next: ExamId) => {
    setExam(next);
    const p = EXAM_PATTERNS[next];
    setSubjects(p.subjects.slice(0, 1));
    setChapters([]);
    setTypes([]);
    setDuration(p.durationMinutes);
    setNegative(p.negativeMarking);
    if (next === 'jee-main' || next === 'jee-advanced') setCount(10);
  };

  const generate = async () => {
    if (!subjects.length) { setError('Select at least one subject.'); return; }
    setGenerating(true);
    setError(null);
    setNote(null);
    try {
      const res = await api.post<{ test: { id: number }; shortfall: number; note: string }>('/api/tests', {
        exam, subjects, chapters, types, difficulty, questionCount: count, durationMinutes: duration,
        negativeMarking: negative, mode, useResources, resourceIds,
      });
      if (res.shortfall > 0) setNote(res.note);
      navigate(`/tests/${res.test.id}/run`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not generate this paper.');
    } finally {
      setGenerating(false);
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    try {
      await api.del(`/api/tests/${deleteTarget.id}`);
      setTests((prev) => prev.filter((t) => t.id !== deleteTarget.id));
      push('Test deleted.', 'info');
    } catch {
      push('Could not delete the test.', 'bad');
    } finally {
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-4">
      {error && <Banner tone="bad">{error}</Banner>}
      {note && <Banner tone="info">{note}</Banner>}
      {!aiEnabled && <SetupCard message="Instant papers from the question bank are available. AI-generated papers and AI evaluation of descriptive answers need OPENAI_API_KEY." />}

      <div className="grid gap-4 lg:grid-cols-[1fr_1.1fr]">
        <Card>
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-base font-bold text-ink">Generate a paper</h2>
              <p className="mt-0.5 text-sm text-muted">Marking follows the published rules of the exam you choose — no invented patterns.</p>
            </div>
            <Badge tone="brand">{EXAM_SHORT[exam]}</Badge>
          </div>

          <div className="mt-3 space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Examination">
                <Select value={exam} onChange={(e) => changeExam(e.target.value as ExamId)}>
                  {EXAM_LIST.map((e) => <option key={e.id} value={e.id}>{e.label}</option>)}
                </Select>
              </Field>
              <Field label="Difficulty">
                <Select value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                  <option value="advanced">Advanced</option>
                </Select>
              </Field>
            </div>

            <div>
              <span className="label">Subjects</span>
              <div className="flex flex-wrap gap-1.5">
                {examSubjectOptions.map((s) => (
                  <button key={s} onClick={() => {
                    setSubjects((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]);
                    setChapters([]);
                  }} className={cn('chip', subjects.includes(s) && 'border-brand/50 bg-brand/10 text-brand')}>{s}</button>
                ))}
              </div>
            </div>

            <div>
              <span className="label">Chapters {chapters.length === 0 && <span className="normal-case text-muted">(all chapters)</span>}</span>
              <div className="max-h-32 overflow-y-auto rounded-xl border border-line bg-elevated/30 p-2 scroll-thin">
                {chapterOptions.length === 0 ? <p className="text-xs text-muted">Select a subject first.</p> : (
                  <div className="flex flex-wrap gap-1.5">
                    {chapterOptions.map((c) => (
                      <button key={c} onClick={() => setChapters((prev) => prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c])}
                        className={cn('chip max-w-full text-left', chapters.includes(c) && 'border-brand/50 bg-brand/10 text-brand')}>
                        <span className="truncate">{c}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div>
              <span className="label">Question types</span>
              <div className="flex flex-wrap gap-1.5">
                {typeOptions.map((t) => (
                  <button key={t.value} onClick={() => setTypes((prev) => prev.includes(t.value) ? prev.filter((x) => x !== t.value) : [...prev, t.value])}
                    className={cn('chip', types.includes(t.value) && 'border-brand/50 bg-brand/10 text-brand')}>{t.label}</button>
                ))}
              </div>
              <p className="mt-1 text-[11px] text-muted">Leave empty to use this exam's default mix.</p>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Questions">
                <Input type="number" min={1} max={60} value={count} onChange={(e) => setCount(Math.max(1, Math.min(60, Number(e.target.value))))} />
              </Field>
              <Field label="Minutes">
                <Input type="number" min={5} max={300} value={duration} onChange={(e) => setDuration(Math.max(5, Math.min(300, Number(e.target.value))))} />
              </Field>
              <div className="flex items-end pb-2.5">
                <Checkbox label="Negative marking" checked={negative} onChange={setNegative} />
              </div>
            </div>

            <div className="rounded-xl border border-line bg-elevated/30 p-3">
              <span className="label">Paper source</span>
              <div className="flex flex-wrap gap-2">
                <button onClick={() => setMode('bank')} className={cn('chip', mode === 'bank' && 'border-brand/50 bg-brand/10 text-brand')}>Question bank (instant)</button>
                <button onClick={() => setMode('ai')} className={cn('chip', mode === 'ai' && 'border-brand/50 bg-brand/10 text-brand')} disabled={!aiEnabled}>
                  <Sparkles size={11} /> AI-generated {!aiEnabled && '(needs key)'}
                </button>
              </div>
              {resources.length > 0 && (
                <div className="mt-3 border-t border-line pt-2.5">
                  <Checkbox label="Use my uploaded documents as the question source" checked={useResources} onChange={setUseResources} />
                  {useResources && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {resources.map((r) => (
                        <button key={r.id} onClick={() => setResourceIds((prev) => prev.includes(r.id) ? prev.filter((id) => id !== r.id) : [...prev, r.id])}
                          className={cn('chip max-w-[200px]', resourceIds.includes(r.id) && 'border-brand/50 bg-brand/10 text-brand')}>
                          <span className="truncate">{r.name}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between gap-3 border-t border-line pt-3">
              <p className="text-[11px] text-muted">
                {pattern.marking.note} {duration} min · {count} questions requested.
              </p>
              <Button onClick={() => void generate()} loading={generating}>
                {mode === 'ai' ? <Wand2 size={16} /> : <Play size={16} />} Generate paper
              </Button>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-ink">Your papers</h2>
            <Badge>{tests.length}</Badge>
          </div>
          {loading ? <Spinner /> : tests.length === 0 ? (
            <div className="mt-3"><EmptyState icon={<ClipboardList size={22} />} title="No papers yet" description="Generate a short diagnostic first — 10 questions is enough to find your starting point." /></div>
          ) : (
            <ul className="mt-3 space-y-2">
              {tests.map((test) => (
                <li key={test.id} className="rounded-xl border border-line bg-elevated/30 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-ink">{test.title}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-muted">
                        <span>{EXAM_SHORT[test.exam] ?? test.exam}</span>
                        <span>· {test.questionCount} Q</span>
                        <span>· {test.totalMarks} marks</span>
                        <span>· {test.durationMinutes} min</span>
                        <span>· {formatDate(test.createdAt, { day: 'numeric', month: 'short' })}</span>
                      </div>
                    </div>
                    <button onClick={() => setDeleteTarget(test)} className="text-muted hover:text-bad" aria-label="Delete test"><Trash2 size={14} /></button>
                  </div>
                  <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                    {test.attemptId ? (
                      <Button variant="secondary" className="px-2.5 py-1.5 text-xs" onClick={() => navigate(`/attempts/${test.attemptId}`)}>View report</Button>
                    ) : (
                      <Button className="px-2.5 py-1.5 text-xs" onClick={() => navigate(`/tests/${test.id}/run`)}><Play size={12} /> {test.status === 'in-progress' ? 'Resume' : 'Start test'}</Button>
                    )}
                    <Badge tone={test.attemptId ? 'ok' : test.status === 'in-progress' ? 'warn' : 'neutral'}>
                      {test.attemptId ? 'Submitted' : test.status === 'in-progress' ? 'In progress' : 'Not started'}
                    </Badge>
                    {test.config?.generatedBy === 'ai' && <Badge tone="brand">AI paper</Badge>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Modal open={deleteTarget !== null} onClose={() => setDeleteTarget(null)} title="Delete this paper?" footer={
        <><Button variant="secondary" onClick={() => setDeleteTarget(null)}>Cancel</Button><Button variant="danger" onClick={() => void remove()}>Delete</Button></>
      }>
        <p className="text-sm text-muted">“{deleteTarget?.title}” and any attempt on it will be removed. This cannot be undone.</p>
      </Modal>
    </div>
  );
}
