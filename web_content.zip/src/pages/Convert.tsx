/* ============================================
   plix_ai studio — Conversion Workflow
   Step 1: Import → Step 2: Branding → Step 3: Config → Step 4: Build
   ============================================ */

import { useState, useCallback, useRef } from 'react';
import type {
  PageId, SourceType, ImportData, BrandingConfig, BuildConfig,
  BuildJob, Permission, Project, OutputFormat, MinSdkVersion
} from '../types';
import { saveProject } from '../store';
import { simulateBuild, validateUrl, runPreflightChecks } from '../utils/mock-api';
import {
  IconUpload, IconGlobe, IconPackage, IconFile, IconChevronRight,
  IconChevronLeft, IconCheck, IconX, IconEye, IconEyeOff,
  IconAlertTriangle, IconDownload, IconLoader, IconAndroid, IconKey,
  IconShield, IconInfo
} from '../components/Icons';

interface ConvertProps {
  onNavigate: (page: PageId) => void;
}

type Step = 0 | 1 | 2 | 3;

const STEPS = [
  { num: 0, label: 'Import', desc: 'Source files' },
  { num: 1, label: 'Branding', desc: 'App identity' },
  { num: 2, label: 'Configure', desc: 'Build settings' },
  { num: 3, label: 'Build', desc: 'Package & sign' },
];

const SOURCE_OPTIONS: { type: SourceType; label: string; icon: React.ReactNode; desc: string; accept?: string }[] = [
  { type: 'zip', label: 'ZIP Archive', icon: <IconUpload size={20} />, desc: 'Upload a ZIP of your web project', accept: '.zip' },
  { type: 'html', label: 'HTML Files', icon: <IconFile size={20} />, desc: 'Upload index.html and assets', accept: '.html,.htm' },
  { type: 'url', label: 'Website URL', icon: <IconGlobe size={20} />, desc: 'Enter a live website URL' },
  { type: 'pwa', label: 'PWA Manifest', icon: <IconPackage size={20} />, desc: 'Import from a web app manifest' },
  { type: 'apk', label: 'APK File', icon: <IconAndroid size={20} />, desc: 'Inspect, re-sign, or repackage', accept: '.apk' },
  { type: 'aab', label: 'AAB Bundle', icon: <IconAndroid size={20} />, desc: 'Android App Bundle for Play Store', accept: '.aab' },
];

const DEFAULT_PERMISSIONS: Permission[] = [
  { id: 'internet', name: 'Internet', description: 'Access network for loading web content', dangerous: false, selected: true, category: 'Network' },
  { id: 'network_state', name: 'Network State', description: 'Check if device is connected to internet', dangerous: false, selected: true, category: 'Network' },
  { id: 'wifi_state', name: 'Wi-Fi State', description: 'View Wi-Fi connection status', dangerous: false, selected: false, category: 'Network' },
  { id: 'camera', name: 'Camera', description: 'Access camera for photo/video capture from web pages', dangerous: true, selected: false, category: 'Hardware' },
  { id: 'microphone', name: 'Microphone', description: 'Record audio from web pages', dangerous: true, selected: false, category: 'Hardware' },
  { id: 'location_fine', name: 'Fine Location (GPS)', description: 'Precise location via GPS', dangerous: true, selected: false, category: 'Location' },
  { id: 'location_coarse', name: 'Coarse Location', description: 'Approximate location via network', dangerous: true, selected: false, category: 'Location' },
  { id: 'storage_read', name: 'Read Storage', description: 'Read files from device storage', dangerous: true, selected: false, category: 'Storage' },
  { id: 'storage_write', name: 'Write Storage', description: 'Save files to device storage', dangerous: true, selected: false, category: 'Storage' },
  { id: 'vibrate', name: 'Vibrate', description: 'Control device vibration feedback', dangerous: false, selected: false, category: 'Hardware' },
  { id: 'wake_lock', name: 'Wake Lock', description: 'Keep screen on while app is active', dangerous: false, selected: false, category: 'System' },
  { id: 'biometric', name: 'Biometric', description: 'Use fingerprint or face authentication', dangerous: false, selected: false, category: 'Security' },
];

export default function Convert({ onNavigate }: ConvertProps) {
  const [step, setStep] = useState<Step>(0);
  const [sourceType, setSourceType] = useState<SourceType>('zip');
  const [importData, setImportData] = useState<ImportData>({
    sourceType: 'zip',
    validated: false,
    errors: [],
  });
  const [urlInput, setUrlInput] = useState('');
  const [urlValidating, setUrlValidating] = useState(false);
  const [urlValid, setUrlValid] = useState<boolean | null>(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState(0);

  const [branding, setBranding] = useState<BrandingConfig>({
    appName: '',
    displayName: '',
    packageId: '',
    versionName: '1.0.0',
    versionCode: 1,
    primaryColor: '#0ea5e9',
    accentColor: '#f59e0b',
    theme: 'dark',
    orientation: 'portrait',
    fullscreen: false,
    statusBarStyle: 'default',
    fontFamily: 'system-ui',
  });

  const [buildConfig, setBuildConfig] = useState<BuildConfig>({
    outputFormat: 'apk',
    minSdk: 24,
    targetSdk: 34,
    keystore: {
      alias: 'release',
      password: '',
      keyPassword: '',
      cn: '',
      org: '',
      locality: '',
      state: '',
      country: '',
      validityYears: 25,
    },
    permissions: DEFAULT_PERMISSIONS,
    deepLinks: [],
    enableJavascript: true,
    allowFileAccess: false,
    allowContentAccess: false,
    domStorageEnabled: true,
    useWideViewport: true,
    loadWithOverviewMode: true,
    supportZoom: false,
    hardwareAccelerated: true,
    mixedContentMode: 'never',
  });

  const [showKeystorePassword, setShowKeystorePassword] = useState(false);
  const [showKeyPassword, setShowKeyPassword] = useState(false);
  const [useExistingKeystore, setUseExistingKeystore] = useState(false);

  const [buildJob, setBuildJob] = useState<BuildJob | null>(null);
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildComplete, setBuildComplete] = useState(false);

  const [legalAccepted, setLegalAccepted] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Step navigation ---
  const canGoNext = () => {
    switch (step) {
      case 0: return importData.validated;
      case 1: return branding.appName.length > 0 && branding.packageId.length > 0;
      case 2: return true;
      case 3: return false;
      default: return false;
    }
  };

  // --- File handling ---
  const handleFileDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [sourceType]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  }, [sourceType]);

  function processFile(file: File) {
    setFileName(file.name);
    setFileSize(file.size);

    // Validate based on source type
    const errors: ImportData['errors'] = [];
    const maxSize = 100 * 1024 * 1024; // 100MB

    if (file.size > maxSize) {
      errors.push({ message: `File too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Max 100MB.`, severity: 'error' });
    }

    if (sourceType === 'zip' && !file.name.endsWith('.zip')) {
      errors.push({ message: 'Expected a .zip file', severity: 'error' });
    }
    if (sourceType === 'html' && !file.name.endsWith('.html') && !file.name.endsWith('.htm')) {
      errors.push({ message: 'Expected an .html or .htm file', severity: 'warning' });
    }
    if (sourceType === 'apk' && !file.name.endsWith('.apk')) {
      errors.push({ message: 'Expected an .apk file', severity: 'error' });
    }
    if (sourceType === 'aab' && !file.name.endsWith('.aab')) {
      errors.push({ message: 'Expected an .aab file', severity: 'error' });
    }

    // Show legal warning for APK/AAB
    if ((sourceType === 'apk' || sourceType === 'aab') && !legalAccepted) {
      errors.push({
        message: 'You must confirm you have the legal right to modify this application.',
        severity: 'warning',
      });
    }

    setImportData({
      sourceType,
      file: { name: file.name, size: file.size, type: file.type, lastModified: file.lastModified },
      validated: errors.filter(e => e.severity === 'error').length === 0,
      errors,
    });
  }

  // --- URL handling ---
  async function handleUrlValidate() {
    if (!urlInput.trim()) return;
    setUrlValidating(true);
    const result = await validateUrl(urlInput);
    setUrlValidating(false);

    if (result.valid) {
      setUrlValid(true);
      setFileName(result.title || urlInput);
      setImportData({
        sourceType: 'url',
        url: urlInput,
        validated: true,
        errors: [],
      });
    } else {
      setUrlValid(false);
      setImportData({
        sourceType: 'url',
        url: urlInput,
        validated: false,
        errors: [{ message: result.error || 'Invalid URL', severity: 'error' }],
      });
    }
  }

  // --- Branding helpers ---
  function generatePackageId(name: string) {
    return 'com.' + name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) + '.app';
  }

  // --- Build ---
  function startBuild() {
    const project: Project = {
      id: crypto.randomUUID(),
      name: branding.appName || 'Untitled',
      packageId: branding.packageId,
      sourceType,
      branding,
      buildConfig,
      importData,
      status: 'building',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      builds: [],
    };

    setIsBuilding(true);
    setBuildComplete(false);

    simulateBuild(project, (job) => {
      setBuildJob({ ...job });

      if (job.status === 'completed') {
        setIsBuilding(false);
        setBuildComplete(true);
        project.status = 'completed';
        project.builds = [job];
        project.lastBuildId = job.id;
        saveProject(project);
      } else if (job.status === 'failed' || job.status === 'cancelled') {
        setIsBuilding(false);
        project.status = 'failed';
        saveProject(project);
      }
    });
  }

  // --- Preflight ---
  const preflightProject: Project = {
    id: 'preflight',
    name: branding.appName,
    packageId: branding.packageId,
    sourceType,
    branding,
    buildConfig,
    importData,
    status: 'draft',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    builds: [],
  };

  const preflightChecks = step === 2 ? runPreflightChecks(preflightProject) : [];

  // --- Render step content ---
  function renderStepContent() {
    switch (step) {
      case 0: return renderImportStep();
      case 1: return renderBrandingStep();
      case 2: return renderConfigStep();
      case 3: return renderBuildStep();
    }
  }

  // ===================== STEP 0: IMPORT =====================
  function renderImportStep() {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-xl font-bold mb-1">Import Source</h2>
          <p className="text-sm text-stone-400">Choose how to bring your project into plix_ai.</p>
        </div>

        {/* Source type selector */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {SOURCE_OPTIONS.map(opt => (
            <button
              key={opt.type}
              onClick={() => {
                setSourceType(opt.type);
                setImportData({ sourceType: opt.type, validated: false, errors: [] });
                setUrlValid(null);
                setFileName('');
              }}
              className={`card card-compact text-left transition-all ${
                sourceType === opt.type
                  ? 'border-sky-500/50 bg-sky-500/5'
                  : 'hover:border-stone-600'
              }`}
            >
              <div className={`mb-2 ${sourceType === opt.type ? 'text-sky-400' : 'text-stone-400'}`}>
                {opt.icon}
              </div>
              <div className="text-sm font-medium">{opt.label}</div>
              <div className="text-xs text-stone-500 mt-0.5">{opt.desc}</div>
            </button>
          ))}
        </div>

        {/* Input area based on type */}
        {(sourceType === 'zip' || sourceType === 'html' || sourceType === 'apk' || sourceType === 'aab') && (
          <div
            className={`drop-zone ${fileName ? 'border-sky-500/50 bg-sky-500/5' : ''}`}
            onDragOver={e => e.preventDefault()}
            onDrop={handleFileDrop}
            onClick={() => fileInputRef.current?.click()}
            role="button"
            tabIndex={0}
            aria-label="Drop file here or click to browse"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept={SOURCE_OPTIONS.find(o => o.type === sourceType)?.accept}
              onChange={handleFileSelect}
              className="hidden"
              aria-hidden="true"
            />
            {fileName ? (
              <div>
                <IconCheck size={24} className="text-emerald-400 mx-auto mb-2" />
                <p className="font-medium text-sm">{fileName}</p>
                <p className="text-xs text-stone-500">{(fileSize / 1024).toFixed(1)} KB</p>
              </div>
            ) : (
              <div>
                <IconUpload size={24} className="text-stone-500 mx-auto mb-2" />
                <p className="text-sm text-stone-300">Drop file here or click to browse</p>
                <p className="text-xs text-stone-500 mt-1">Max 100MB</p>
              </div>
            )}
          </div>
        )}

        {/* URL input */}
        {sourceType === 'url' && (
          <div className="space-y-3">
            <div className="flex gap-2">
              <div className="flex-1">
                <input
                  type="url"
                  value={urlInput}
                  onChange={e => { setUrlInput(e.target.value); setUrlValid(null); }}
                  placeholder="https://example.com"
                  className="input"
                  onKeyDown={e => e.key === 'Enter' && handleUrlValidate()}
                  aria-label="Website URL"
                />
              </div>
              <button
                onClick={handleUrlValidate}
                disabled={urlValidating || !urlInput.trim()}
                className="btn btn-primary"
              >
                {urlValidating ? <IconLoader size={14} /> : <IconGlobe size={14} />}
                {urlValidating ? 'Checking...' : 'Validate'}
              </button>
            </div>
            {urlValid === true && (
              <div className="flex items-center gap-2 text-sm text-emerald-400">
                <IconCheck size={14} /> URL is reachable: {fileName}
              </div>
            )}
          </div>
        )}

        {/* PWA manifest input */}
        {sourceType === 'pwa' && (
          <div className="space-y-3">
            <div className="flex gap-2">
              <div className="flex-1">
                <input
                  type="url"
                  value={urlInput}
                  onChange={e => { setUrlInput(e.target.value); setUrlValid(null); }}
                  placeholder="https://example.com/manifest.json"
                  className="input"
                  onKeyDown={e => e.key === 'Enter' && handleUrlValidate()}
                  aria-label="PWA manifest URL"
                />
              </div>
              <button
                onClick={handleUrlValidate}
                disabled={urlValidating || !urlInput.trim()}
                className="btn btn-primary"
              >
                {urlValidating ? <IconLoader size={14} /> : <IconPackage size={14} />}
                {urlValidating ? 'Fetching...' : 'Import'}
              </button>
            </div>
            {urlValid === true && (
              <div className="flex items-center gap-2 text-sm text-emerald-400">
                <IconCheck size={14} /> Manifest found: {fileName}
              </div>
            )}
          </div>
        )}

        {/* Legal warning for APK/AAB */}
        {(sourceType === 'apk' || sourceType === 'aab') && (
          <div className="card bg-amber-500/5 border-amber-500/20">
            <div className="flex gap-3">
              <IconAlertTriangle size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-amber-400 mb-1">Legal Responsibility Notice</h4>
                <p className="text-xs text-stone-400 leading-relaxed mb-3">
                  Uploading an existing APK/AAB for re-signing, repackaging, or conversion requires that you
                  own the application or have explicit permission from the rights holder. Unauthorized
                  modification of third-party applications may violate copyright law and app store policies.
                </p>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={legalAccepted}
                    onChange={e => {
                      setLegalAccepted(e.target.checked);
                      if (e.target.checked && fileName) {
                        setImportData(prev => ({
                          ...prev,
                          validated: true,
                          errors: prev.errors.filter(err => !err.message.includes('legal')),
                        }));
                      }
                    }}
                    className="rounded"
                  />
                  <span className="text-xs text-stone-300">
                    I confirm I have the legal right to modify this application
                  </span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Validation errors */}
        {importData.errors.length > 0 && (
          <div className="space-y-1">
            {importData.errors.map((err, i) => (
              <div key={i} className={`flex items-start gap-2 text-sm ${err.severity === 'error' ? 'text-red-400' : 'text-amber-400'}`}>
                {err.severity === 'error' ? <IconX size={14} className="mt-0.5" /> : <IconAlertTriangle size={14} className="mt-0.5" />}
                {err.message}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // ===================== STEP 1: BRANDING =====================
  function renderBrandingStep() {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-xl font-bold mb-1">Branding</h2>
          <p className="text-sm text-stone-400">Configure how your app appears on Android.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Form */}
          <div className="space-y-4">
            {/* App name */}
            <div>
              <label className="input-label">App Name *</label>
              <input
                type="text"
                value={branding.appName}
                onChange={e => {
                  const name = e.target.value;
                  setBranding(prev => ({
                    ...prev,
                    appName: name,
                    displayName: prev.displayName || name,
                    packageId: prev.packageId || generatePackageId(name),
                  }));
                }}
                placeholder="My Android App"
                className="input"
                maxLength={30}
              />
              <p className="input-hint">Shown on home screen and app store</p>
            </div>

            {/* Display name */}
            <div>
              <label className="input-label">Display Name</label>
              <input
                type="text"
                value={branding.displayName}
                onChange={e => setBranding(prev => ({ ...prev, displayName: e.target.value }))}
                placeholder="Same as app name"
                className="input"
              />
            </div>

            {/* Package ID */}
            <div>
              <label className="input-label">Package ID *</label>
              <input
                type="text"
                value={branding.packageId}
                onChange={e => setBranding(prev => ({ ...prev, packageId: e.target.value }))}
                placeholder="com.example.myapp"
                className="input font-mono text-sm"
              />
              <p className="input-hint">Reverse-domain notation. Must be unique.</p>
              {branding.packageId && !/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}$/.test(branding.packageId) && (
                <p className="input-error">Must be reverse-domain: com.company.app</p>
              )}
            </div>

            {/* Version */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="input-label">Version Name</label>
                <input
                  type="text"
                  value={branding.versionName}
                  onChange={e => setBranding(prev => ({ ...prev, versionName: e.target.value }))}
                  className="input font-mono"
                  placeholder="1.0.0"
                />
              </div>
              <div>
                <label className="input-label">Version Code</label>
                <input
                  type="number"
                  value={branding.versionCode}
                  onChange={e => setBranding(prev => ({ ...prev, versionCode: parseInt(e.target.value) || 1 }))}
                  className="input font-mono"
                  min={1}
                />
              </div>
            </div>

            {/* Colors */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="input-label">Primary Color</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="color"
                    value={branding.primaryColor}
                    onChange={e => setBranding(prev => ({ ...prev, primaryColor: e.target.value }))}
                    className="w-8 h-8 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={branding.primaryColor}
                    onChange={e => setBranding(prev => ({ ...prev, primaryColor: e.target.value }))}
                    className="input font-mono text-sm flex-1"
                  />
                </div>
              </div>
              <div>
                <label className="input-label">Accent Color</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="color"
                    value={branding.accentColor}
                    onChange={e => setBranding(prev => ({ ...prev, accentColor: e.target.value }))}
                    className="w-8 h-8 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={branding.accentColor}
                    onChange={e => setBranding(prev => ({ ...prev, accentColor: e.target.value }))}
                    className="input font-mono text-sm flex-1"
                  />
                </div>
              </div>
            </div>

            {/* Logo upload */}
            <div>
              <label className="input-label">App Icon / Logo</label>
              <div className="flex items-center gap-4">
                <div
                  className="w-16 h-16 rounded-xl border border-subtle flex items-center justify-center"
                  style={{
                    background: branding.logoDataUrl
                      ? `url(${branding.logoDataUrl}) center/cover`
                      : `linear-gradient(135deg, ${branding.primaryColor}33, ${branding.accentColor}33)`,
                  }}
                >
                  {!branding.logoDataUrl && (
                    <span className="text-xl font-bold" style={{ color: branding.primaryColor }}>
                      {branding.appName.charAt(0).toUpperCase() || '?'}
                    </span>
                  )}
                </div>
                <div>
                  <label className="btn btn-secondary btn-sm cursor-pointer">
                    <IconUpload size={14} />
                    Choose file
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/svg+xml"
                      className="hidden"
                      onChange={e => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = () => {
                            setBranding(prev => ({ ...prev, logoDataUrl: reader.result as string }));
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  <p className="text-xs text-stone-500 mt-1">PNG, JPEG, or SVG. 512×512 recommended.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Preview */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-stone-300">Preview</h3>

            {/* Icon preview */}
            <div className="card">
              <h4 className="text-xs text-stone-500 mb-3 uppercase tracking-wider">App Icon</h4>
              <div className="flex items-center gap-4">
                {/* Full icon */}
                <div
                  className="w-20 h-20 rounded-2xl border border-subtle flex items-center justify-center"
                  style={{
                    background: branding.logoDataUrl
                      ? `url(${branding.logoDataUrl}) center/cover`
                      : `linear-gradient(135deg, ${branding.primaryColor}44, ${branding.accentColor}44)`,
                  }}
                >
                  {!branding.logoDataUrl && (
                    <span className="text-2xl font-bold" style={{ color: branding.primaryColor }}>
                      {branding.appName.charAt(0).toUpperCase() || '?'}
                    </span>
                  )}
                </div>
                {/* Adaptive icon (circle) */}
                <div
                  className="w-20 h-20 rounded-full border border-subtle flex items-center justify-center overflow-hidden"
                  style={{
                    background: branding.logoDataUrl
                      ? `url(${branding.logoDataUrl}) center/cover`
                      : `linear-gradient(135deg, ${branding.primaryColor}44, ${branding.accentColor}44)`,
                  }}
                >
                  {!branding.logoDataUrl && (
                    <span className="text-2xl font-bold" style={{ color: branding.primaryColor }}>
                      {branding.appName.charAt(0).toUpperCase() || '?'}
                    </span>
                  )}
                </div>
                {/* Squircle */}
                <div
                  className="w-20 h-20 border border-subtle flex items-center justify-center"
                  style={{
                    borderRadius: '28%',
                    background: branding.logoDataUrl
                      ? `url(${branding.logoDataUrl}) center/cover`
                      : `linear-gradient(135deg, ${branding.primaryColor}44, ${branding.accentColor}44)`,
                  }}
                >
                  {!branding.logoDataUrl && (
                    <span className="text-2xl font-bold" style={{ color: branding.primaryColor }}>
                      {branding.appName.charAt(0).toUpperCase() || '?'}
                    </span>
                  )}
                </div>
              </div>
              <p className="text-xs text-stone-500 mt-3">Rounded · Circle · Squircle adaptive shapes</p>
            </div>

            {/* Splash preview */}
            <div className="card">
              <h4 className="text-xs text-stone-500 mb-3 uppercase tracking-wider">Splash Screen</h4>
              <div
                className="w-full h-40 rounded-lg flex items-center justify-center"
                style={{
                  background: branding.theme === 'dark'
                    ? '#0c0a09'
                    : branding.theme === 'light'
                    ? '#fafafa'
                    : '#1c1917',
                }}
              >
                <div className="text-center">
                  <div
                    className="w-12 h-12 mx-auto rounded-xl mb-2 flex items-center justify-center"
                    style={{
                      background: branding.logoDataUrl
                        ? `url(${branding.logoDataUrl}) center/cover`
                        : branding.primaryColor,
                    }}
                  >
                    {!branding.logoDataUrl && (
                      <span className="text-lg font-bold text-white">
                        {branding.appName.charAt(0).toUpperCase() || '?'}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold" style={{ color: branding.theme === 'light' ? '#1c1917' : '#fafaf9' }}>
                    {branding.appName || 'App Name'}
                  </p>
                </div>
              </div>
            </div>

            {/* Theme & Orientation */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="input-label">Theme</label>
                <select
                  value={branding.theme}
                  onChange={e => setBranding(prev => ({ ...prev, theme: e.target.value as any }))}
                  className="input"
                >
                  <option value="light">Light</option>
                  <option value="dark">Dark</option>
                  <option value="system">System</option>
                </select>
              </div>
              <div>
                <label className="input-label">Orientation</label>
                <select
                  value={branding.orientation}
                  onChange={e => setBranding(prev => ({ ...prev, orientation: e.target.value as any }))}
                  className="input"
                >
                  <option value="portrait">Portrait</option>
                  <option value="landscape">Landscape</option>
                  <option value="sensor">Sensor</option>
                  <option value="unspecified">Unspecified</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="input-label">Status Bar</label>
                <select
                  value={branding.statusBarStyle}
                  onChange={e => setBranding(prev => ({ ...prev, statusBarStyle: e.target.value as any }))}
                  className="input"
                >
                  <option value="default">Default</option>
                  <option value="light">Light text</option>
                  <option value="dark">Dark text</option>
                  <option value="transparent">Transparent</option>
                </select>
              </div>
              <div>
                <label className="input-label">Typography</label>
                <select
                  value={branding.fontFamily}
                  onChange={e => setBranding(prev => ({ ...prev, fontFamily: e.target.value }))}
                  className="input"
                >
                  <option value="system-ui">System Default</option>
                  <option value="Roboto">Roboto</option>
                  <option value="Inter">Inter</option>
                  <option value="Nunito">Nunito</option>
                  <option value="Source Sans Pro">Source Sans Pro</option>
                </select>
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={branding.fullscreen}
                onChange={e => setBranding(prev => ({ ...prev, fullscreen: e.target.checked }))}
                className="rounded"
              />
              <span className="text-sm text-stone-300">Fullscreen mode (hide system bars)</span>
            </label>
          </div>
        </div>
      </div>
    );
  }

  // ===================== STEP 2: CONFIG =====================
  function renderConfigStep() {
    const permCategories = [...new Set(buildConfig.permissions.map(p => p.category))];

    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-xl font-bold mb-1">Build Configuration</h2>
          <p className="text-sm text-stone-400">SDK targets, signing, permissions, and WebView options.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column: Build settings */}
          <div className="lg:col-span-2 space-y-6">
            {/* Output format & SDK */}
            <div className="card">
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <IconAndroid size={16} className="text-sky-400" />
                Output & SDK
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="input-label">Output Format</label>
                  <div className="flex gap-2">
                    {(['apk', 'aab'] as OutputFormat[]).map(fmt => (
                      <button
                        key={fmt}
                        onClick={() => setBuildConfig(prev => ({ ...prev, outputFormat: fmt }))}
                        className={`btn btn-sm flex-1 uppercase ${buildConfig.outputFormat === fmt ? 'btn-primary' : 'btn-secondary'}`}
                      >
                        {fmt}
                      </button>
                    ))}
                  </div>
                  <p className="input-hint mt-1">
                    {buildConfig.outputFormat === 'apk' ? 'Universal install package' : 'Play Store optimized bundle'}
                  </p>
                </div>
                <div>
                  <label className="input-label">Min SDK</label>
                  <select
                    value={buildConfig.minSdk}
                    onChange={e => setBuildConfig(prev => ({ ...prev, minSdk: parseInt(e.target.value) as MinSdkVersion }))}
                    className="input"
                  >
                    <option value={21}>API 21 (Android 5.0)</option>
                    <option value={23}>API 23 (Android 6.0)</option>
                    <option value={24}>API 24 (Android 7.0)</option>
                    <option value={26}>API 26 (Android 8.0)</option>
                    <option value={28}>API 28 (Android 9.0)</option>
                    <option value={30}>API 30 (Android 11)</option>
                  </select>
                </div>
                <div>
                  <label className="input-label">Target SDK</label>
                  <select
                    value={buildConfig.targetSdk}
                    onChange={e => setBuildConfig(prev => ({ ...prev, targetSdk: parseInt(e.target.value) }))}
                    className="input"
                  >
                    <option value={33}>API 33 (Android 13)</option>
                    <option value={34}>API 34 (Android 14)</option>
                    <option value={35}>API 35 (Android 15)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Signing */}
            <div className="card">
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <IconKey size={16} className="text-sky-400" />
                Signing Configuration
              </h3>

              <div className="flex items-center gap-3 mb-4">
                <button
                  onClick={() => setUseExistingKeystore(false)}
                  className={`btn btn-sm ${!useExistingKeystore ? 'btn-primary' : 'btn-secondary'}`}
                >
                  Generate New
                </button>
                <button
                  onClick={() => setUseExistingKeystore(true)}
                  className={`btn btn-sm ${useExistingKeystore ? 'btn-primary' : 'btn-secondary'}`}
                >
                  Import Existing
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="input-label">Key Alias</label>
                  <input
                    type="text"
                    value={buildConfig.keystore.alias}
                    onChange={e => setBuildConfig(prev => ({
                      ...prev,
                      keystore: { ...prev.keystore, alias: e.target.value }
                    }))}
                    className="input font-mono"
                    placeholder="release"
                  />
                </div>
                <div>
                  <label className="input-label">Validity (years)</label>
                  <input
                    type="number"
                    value={buildConfig.keystore.validityYears}
                    onChange={e => setBuildConfig(prev => ({
                      ...prev,
                      keystore: { ...prev.keystore, validityYears: parseInt(e.target.value) || 25 }
                    }))}
                    className="input"
                    min={1}
                    max={100}
                  />
                </div>
                <div>
                  <label className="input-label">Keystore Password</label>
                  <div className="relative">
                    <input
                      type={showKeystorePassword ? 'text' : 'password'}
                      value={buildConfig.keystore.password}
                      onChange={e => setBuildConfig(prev => ({
                        ...prev,
                        keystore: { ...prev.keystore, password: e.target.value }
                      }))}
                      className="input pr-9 font-mono"
                      placeholder="Min 6 characters"
                    />
                    <button
                      type="button"
                      onClick={() => setShowKeystorePassword(!showKeystorePassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
                      aria-label={showKeystorePassword ? 'Hide password' : 'Show password'}
                    >
                      {showKeystorePassword ? <IconEyeOff size={14} /> : <IconEye size={14} />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="input-label">Key Password</label>
                  <div className="relative">
                    <input
                      type={showKeyPassword ? 'text' : 'password'}
                      value={buildConfig.keystore.keyPassword}
                      onChange={e => setBuildConfig(prev => ({
                        ...prev,
                        keystore: { ...prev.keystore, keyPassword: e.target.value }
                      }))}
                      className="input pr-9 font-mono"
                      placeholder="Min 6 characters"
                    />
                    <button
                      type="button"
                      onClick={() => setShowKeyPassword(!showKeyPassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300"
                      aria-label={showKeyPassword ? 'Hide password' : 'Show password'}
                    >
                      {showKeyPassword ? <IconEyeOff size={14} /> : <IconEye size={14} />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Identity fields */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="input-label">Common Name (CN)</label>
                  <input
                    type="text"
                    value={buildConfig.keystore.cn}
                    onChange={e => setBuildConfig(prev => ({
                      ...prev,
                      keystore: { ...prev.keystore, cn: e.target.value }
                    }))}
                    className="input"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label className="input-label">Organization (O)</label>
                  <input
                    type="text"
                    value={buildConfig.keystore.org}
                    onChange={e => setBuildConfig(prev => ({
                      ...prev,
                      keystore: { ...prev.keystore, org: e.target.value }
                    }))}
                    className="input"
                    placeholder="Company Name"
                  />
                </div>
                <div>
                  <label className="input-label">Country Code</label>
                  <input
                    type="text"
                    value={buildConfig.keystore.country}
                    onChange={e => setBuildConfig(prev => ({
                      ...prev,
                      keystore: { ...prev.keystore, country: e.target.value.toUpperCase().slice(0, 2) }
                    }))}
                    className="input font-mono"
                    placeholder="US"
                    maxLength={2}
                  />
                </div>
                <div>
                  <label className="input-label">State / Province</label>
                  <input
                    type="text"
                    value={buildConfig.keystore.state}
                    onChange={e => setBuildConfig(prev => ({
                      ...prev,
                      keystore: { ...prev.keystore, state: e.target.value }
                    }))}
                    className="input"
                    placeholder="California"
                  />
                </div>
              </div>

              <div className="mt-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/15">
                <div className="flex items-start gap-2">
                  <IconShield size={14} className="text-amber-500 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-amber-400/80">
                    Keystore passwords are used for this session only in demo mode.
                    In production, they are encrypted with AES-256-GCM and never stored in logs.
                  </p>
                </div>
              </div>
            </div>

            {/* Permissions */}
            <div className="card">
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <IconShield size={16} className="text-sky-400" />
                Permissions
              </h3>
              <p className="text-xs text-stone-400 mb-4">
                Select only what your app needs. Dangerous permissions require runtime approval on Android 6+.
              </p>

              {permCategories.map(cat => (
                <div key={cat} className="mb-4 last:mb-0">
                  <h4 className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2">{cat}</h4>
                  <div className="space-y-1">
                    {buildConfig.permissions.filter(p => p.category === cat).map(perm => (
                      <label
                        key={perm.id}
                        className="flex items-start gap-3 p-2 rounded-lg hover:bg-stone-800/50 cursor-pointer transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={perm.selected}
                          onChange={e => {
                            setBuildConfig(prev => ({
                              ...prev,
                              permissions: prev.permissions.map(p =>
                                p.id === perm.id ? { ...p, selected: e.target.checked } : p
                              ),
                            }));
                          }}
                          className="rounded mt-0.5"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">{perm.name}</span>
                            {perm.dangerous && <span className="badge badge-warning">dangerous</span>}
                          </div>
                          <p className="text-xs text-stone-500 mt-0.5">{perm.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Deep Links */}
            <div className="card">
              <h3 className="text-sm font-semibold mb-4">Deep Links</h3>
              <p className="text-xs text-stone-400 mb-3">Configure URL schemes to open your app from browser links.</p>

              {buildConfig.deepLinks.length > 0 && (
                <div className="space-y-2 mb-3">
                  {buildConfig.deepLinks.map((dl, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={dl.scheme}
                        onChange={e => {
                          const links = [...buildConfig.deepLinks];
                          links[i] = { ...links[i], scheme: e.target.value };
                          setBuildConfig(prev => ({ ...prev, deepLinks: links }));
                        }}
                        placeholder="https"
                        className="input font-mono text-sm w-24"
                      />
                      <span className="text-stone-500">://</span>
                      <input
                        type="text"
                        value={dl.host}
                        onChange={e => {
                          const links = [...buildConfig.deepLinks];
                          links[i] = { ...links[i], host: e.target.value };
                          setBuildConfig(prev => ({ ...prev, deepLinks: links }));
                        }}
                        placeholder="example.com"
                        className="input font-mono text-sm flex-1"
                      />
                      <input
                        type="text"
                        value={dl.pathPrefix}
                        onChange={e => {
                          const links = [...buildConfig.deepLinks];
                          links[i] = { ...links[i], pathPrefix: e.target.value };
                          setBuildConfig(prev => ({ ...prev, deepLinks: links }));
                        }}
                        placeholder="/app"
                        className="input font-mono text-sm w-24"
                      />
                      <button
                        onClick={() => setBuildConfig(prev => ({
                          ...prev,
                          deepLinks: prev.deepLinks.filter((_, idx) => idx !== i)
                        }))}
                        className="btn btn-ghost btn-sm text-red-400"
                        aria-label="Remove deep link"
                      >
                        <IconX size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <button
                onClick={() => setBuildConfig(prev => ({
                  ...prev,
                  deepLinks: [...prev.deepLinks, { scheme: 'https', host: '', pathPrefix: '' }]
                }))}
                className="btn btn-secondary btn-sm"
              >
                Add Deep Link
              </button>
            </div>

            {/* WebView Options */}
            <div className="card">
              <h3 className="text-sm font-semibold mb-4">WebView Options</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { key: 'enableJavascript', label: 'Enable JavaScript', desc: 'Required for most web apps' },
                  { key: 'domStorageEnabled', label: 'DOM Storage', desc: 'localStorage and sessionStorage' },
                  { key: 'useWideViewport', label: 'Wide Viewport', desc: 'Use wide viewport meta tag' },
                  { key: 'loadWithOverviewMode', label: 'Overview Mode', desc: 'Load pages zoomed out' },
                  { key: 'supportZoom', label: 'Support Zoom', desc: 'Allow pinch-to-zoom' },
                  { key: 'allowFileAccess', label: 'File Access', desc: 'Allow reading local files' },
                  { key: 'allowContentAccess', label: 'Content Access', desc: 'Allow content:// URLs' },
                  { key: 'hardwareAccelerated', label: 'HW Acceleration', desc: 'Use GPU for rendering' },
                ].map(opt => (
                  <label key={opt.key} className="flex items-start gap-3 p-2 rounded-lg hover:bg-stone-800/50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={(buildConfig as any)[opt.key]}
                      onChange={e => setBuildConfig(prev => ({ ...prev, [opt.key]: e.target.checked }))}
                      className="rounded mt-0.5"
                    />
                    <div>
                      <span className="text-sm font-medium">{opt.label}</span>
                      <p className="text-xs text-stone-500">{opt.desc}</p>
                    </div>
                  </label>
                ))}
              </div>

              <div className="mt-4">
                <label className="input-label">Mixed Content Mode</label>
                <select
                  value={buildConfig.mixedContentMode}
                  onChange={e => setBuildConfig(prev => ({ ...prev, mixedContentMode: e.target.value as any }))}
                  className="input"
                >
                  <option value="never">Never allow (recommended)</option>
                  <option value="always">Always allow</option>
                  <option value="compatibility">Compatibility mode</option>
                </select>
                <p className="input-hint">Controls loading HTTP resources on HTTPS pages</p>
              </div>
            </div>
          </div>

          {/* Right column: Preflight */}
          <div className="space-y-4">
            <div className="card sticky top-4">
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <IconCheck size={16} className="text-sky-400" />
                Preflight Checks
              </h3>

              <div className="space-y-2">
                {preflightChecks.map(check => (
                  <div key={check.id} className="flex items-start gap-2">
                    <span className={`mt-0.5 ${
                      check.status === 'pass' ? 'text-emerald-400' :
                      check.status === 'fail' ? 'text-red-400' :
                      check.status === 'warn' ? 'text-amber-400' :
                      'text-stone-500'
                    }`}>
                      {check.status === 'pass' ? <IconCheck size={14} /> :
                       check.status === 'fail' ? <IconX size={14} /> :
                       <IconAlertTriangle size={14} />}
                    </span>
                    <div>
                      <p className="text-xs font-medium">{check.name}</p>
                      {check.message && (
                        <p className="text-xs text-stone-500">{check.message}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="mt-4 pt-3 border-t border-subtle">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-stone-400">Checks passed</span>
                  <span className="font-mono text-emerald-400">
                    {preflightChecks.filter(c => c.status === 'pass').length}/{preflightChecks.length}
                  </span>
                </div>
                {preflightChecks.some(c => c.status === 'fail') && (
                  <p className="text-xs text-red-400 mt-2">
                    Fix {preflightChecks.filter(c => c.status === 'fail').length} error(s) before building.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ===================== STEP 3: BUILD =====================
  function renderBuildStep() {
    const stages = buildJob?.stages || [];

    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-xl font-bold mb-1">Build & Package</h2>
          <p className="text-sm text-stone-400">
            {buildComplete
              ? 'Build completed successfully.'
              : isBuilding
              ? 'Building your Android package...'
              : 'Ready to start the conversion.'}
          </p>
        </div>

        {!isBuilding && !buildComplete && (
          <div className="card">
            <h3 className="text-sm font-semibold mb-4">Build Summary</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-xs text-stone-500 block">App Name</span>
                <span className="font-medium">{branding.appName || 'Untitled'}</span>
              </div>
              <div>
                <span className="text-xs text-stone-500 block">Package</span>
                <span className="font-mono text-xs">{branding.packageId}</span>
              </div>
              <div>
                <span className="text-xs text-stone-500 block">Format</span>
                <span className="badge badge-brand uppercase">{buildConfig.outputFormat}</span>
              </div>
              <div>
                <span className="text-xs text-stone-500 block">Min SDK</span>
                <span className="font-mono">{buildConfig.minSdk}</span>
              </div>
            </div>

            <div className="mt-6 p-3 rounded-lg bg-sky-500/5 border border-sky-500/15 mb-4">
              <div className="flex items-start gap-2">
                <IconInfo size={14} className="text-sky-400 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-sky-300/80">
                  This is a demo build. All stages are simulated — no actual APK/AAB is generated.
                  Download will produce a placeholder text file with build metadata.
                </p>
              </div>
            </div>

            <button onClick={startBuild} className="btn btn-primary btn-lg w-full">
              <IconAndroid size={18} />
              Start Build
            </button>
          </div>
        )}

        {/* Progress */}
        {(isBuilding || buildComplete) && buildJob && (
          <>
            {/* Overall progress */}
            <div className="card">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {isBuilding ? (
                    <IconLoader size={16} className="text-sky-400" />
                  ) : (
                    <IconCheck size={16} className="text-emerald-400" />
                  )}
                  <span className="text-sm font-semibold capitalize">{buildJob.status}</span>
                </div>
                <span className="font-mono text-sm text-stone-400">{buildJob.progress}%</span>
              </div>
              <div className="progress-bar">
                <div
                  className="progress-bar-fill"
                  style={{
                    width: `${buildJob.progress}%`,
                    background: buildComplete ? 'var(--color-success)' : undefined,
                  }}
                />
              </div>
            </div>

            {/* Stages */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              {stages.map((stage, i) => (
                <div
                  key={i}
                  className={`card card-compact text-center transition-all ${
                    stage.status === 'completed' ? 'border-emerald-500/30 bg-emerald-500/5' :
                    stage.status === 'running' ? 'border-sky-500/30 bg-sky-500/5' :
                    stage.status === 'failed' ? 'border-red-500/30 bg-red-500/5' :
                    'opacity-50'
                  }`}
                >
                  <div className="text-xs font-medium mb-1">{stage.name}</div>
                  <div className="flex items-center justify-center h-5">
                    {stage.status === 'completed' && <IconCheck size={14} className="text-emerald-400" />}
                    {stage.status === 'running' && <IconLoader size={14} className="text-sky-400" />}
                    {stage.status === 'failed' && <IconX size={14} className="text-red-400" />}
                    {stage.status === 'pending' && <span className="text-xs text-stone-600">—</span>}
                  </div>
                </div>
              ))}
            </div>

            {/* Build logs */}
            <div className="card">
              <h3 className="text-sm font-semibold mb-3">Build Log</h3>
              <div className="code-block max-h-64 overflow-y-auto">
                {buildJob.logs.map((log, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-stone-600 select-none flex-shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString('en-US', { hour12: false })}
                    </span>
                    <span className={
                      log.level === 'error' ? 'text-red-400' :
                      log.level === 'warn' ? 'text-amber-400' :
                      log.level === 'info' ? 'text-emerald-400' :
                      'text-stone-400'
                    }>
                      {log.message}
                    </span>
                  </div>
                ))}
                {isBuilding && (
                  <div className="flex items-center gap-2 text-sky-400">
                    <span className="animate-pulse">●</span>
                    Building...
                  </div>
                )}
              </div>
            </div>

            {/* Artifact / Results */}
            {buildComplete && buildJob && (
              <div className="card border-emerald-500/20">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 flex-shrink-0">
                    <IconCheck size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-emerald-400 mb-1">Build Complete</h3>
                    <p className="text-sm text-stone-400 mb-4">
                      Your Android package has been prepared. This is a demo — the download is a placeholder file.
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm mb-4">
                      <div>
                        <span className="text-xs text-stone-500 block">Format</span>
                        <span className="font-mono uppercase">{buildConfig.outputFormat}</span>
                      </div>
                      <div>
                        <span className="text-xs text-stone-500 block">Size</span>
                        <span className="font-mono">{((buildJob.artifactSize || 0) / 1024 / 1024).toFixed(1)} MB</span>
                      </div>
                      <div>
                        <span className="text-xs text-stone-500 block">Duration</span>
                        <span className="font-mono">
                          {buildJob.completedAt && buildJob.startedAt
                            ? `${((buildJob.completedAt - buildJob.startedAt) / 1000).toFixed(1)}s`
                            : '—'}
                        </span>
                      </div>
                      <div>
                        <span className="text-xs text-stone-500 block">Checksum</span>
                        <span className="font-mono text-xs truncate block max-w-[120px]" title={buildJob.checksumSha256}>
                          {buildJob.checksumSha256?.slice(0, 12)}...
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => {
                          // Generate a placeholder file
                          const content = [
                            '=== plix_ai studio — Demo Build Artifact ===',
                            '',
                            `App Name: ${branding.appName}`,
                            `Package ID: ${branding.packageId}`,
                            `Version: ${branding.versionName} (${branding.versionCode})`,
                            `Format: ${buildConfig.outputFormat.toUpperCase()}`,
                            `Min SDK: ${buildConfig.minSdk}`,
                            `Target SDK: ${buildConfig.targetSdk}`,
                            `Size: ${((buildJob.artifactSize || 0) / 1024 / 1024).toFixed(2)} MB`,
                            `SHA-256: ${buildJob.checksumSha256}`,
                            `Build ID: ${buildJob.id}`,
                            `Completed: ${new Date(buildJob.completedAt || 0).toISOString()}`,
                            '',
                            'NOTE: This is a DEMO placeholder file.',
                            'No actual APK/AAB was generated.',
                            'In production, this would be a signed Android package.',
                            '',
                            '--- End of artifact ---',
                          ].join('\n');
                          const blob = new Blob([content], { type: 'text/plain' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `plix-demo-${branding.appName.toLowerCase().replace(/\s+/g, '-')}.txt`;
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                        className="btn btn-primary"
                      >
                        <IconDownload size={16} />
                        Download Placeholder
                      </button>
                      <button
                        onClick={() => {
                          setStep(0);
                          setBuildJob(null);
                          setBuildComplete(false);
                          setIsBuilding(false);
                        }}
                        className="btn btn-secondary"
                      >
                        Build Another
                      </button>
                      <button
                        onClick={() => onNavigate('dashboard')}
                        className="btn btn-ghost"
                      >
                        View Projects
                      </button>
                    </div>

                    {/* QR concept */}
                    <div className="mt-4 pt-4 border-t border-subtle">
                      <div className="flex items-center gap-3">
                        <div className="w-20 h-20 rounded-lg bg-white p-1 flex items-center justify-center">
                          <div className="w-full h-full bg-stone-200 rounded flex items-center justify-center">
                            <span className="text-[8px] text-stone-500 text-center leading-tight">
                              QR Code<br />Demo
                            </span>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Test Install via QR</p>
                          <p className="text-xs text-stone-500">
                            In production, a QR code linking to a signed download URL would appear here.
                            Link expires in 72 hours.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  // ===================== MAIN RENDER =====================
  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <button onClick={() => onNavigate('landing')} className="text-stone-500 hover:text-stone-300 transition-colors text-sm">
            Home
          </button>
          <span className="text-stone-600">/</span>
          <span className="text-sm text-stone-300">New Conversion</span>
        </div>
        <h1 className="text-2xl font-bold">Convert to Android</h1>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-1 mb-8 overflow-x-auto pb-2">
        {STEPS.map((s, i) => (
          <div key={s.num} className="flex items-center">
            <button
              onClick={() => {
                if (s.num <= step || (s.num === step + 1 && canGoNext())) {
                  setStep(s.num as Step);
                }
              }}
              disabled={s.num > step + 1 || isBuilding}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                step === s.num
                  ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
                  : s.num < step
                  ? 'text-emerald-400 hover:bg-stone-800/50 border border-transparent'
                  : 'text-stone-500 border border-transparent cursor-not-allowed'
              }`}
            >
              <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                s.num < step ? 'bg-emerald-500/20 text-emerald-400' :
                step === s.num ? 'bg-sky-500/20 text-sky-400' :
                'bg-stone-800 text-stone-500'
              }`}>
                {s.num < step ? <IconCheck size={12} /> : s.num + 1}
              </span>
              <span className="hide-mobile">{s.label}</span>
            </button>
            {i < STEPS.length - 1 && (
              <div className={`w-8 h-px mx-1 ${s.num < step ? 'bg-emerald-500/30' : 'bg-stone-700'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Step content */}
      {renderStepContent()}

      {/* Navigation buttons */}
      {!isBuilding && !buildComplete && (
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-subtle">
          <button
            onClick={() => setStep(Math.max(0, step - 1) as Step)}
            disabled={step === 0}
            className="btn btn-secondary"
          >
            <IconChevronLeft size={16} />
            Back
          </button>
          {step < 3 && (
            <button
              onClick={() => setStep(Math.min(3, step + 1) as Step)}
              disabled={!canGoNext()}
              className="btn btn-primary"
            >
              Continue
              <IconChevronRight size={16} />
            </button>
          )}
        </div>
      )}
    </div>
  );
}