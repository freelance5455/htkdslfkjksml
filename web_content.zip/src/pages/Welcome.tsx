import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CalendarDays, GraduationCap, MapPin, Target } from 'lucide-react';
import { GOVERNORATES, useProfile } from '../hooks/useProfile';
import { useToast } from '../hooks/useToast';
import { Button } from '../components/ui/Button';
import { ManaraLogo } from '../components/layout/Nav';

export default function Welcome() {
  const { profile, save } = useProfile();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [name, setName] = useState(profile.name);
  const [governorate, setGovernorate] = useState(profile.governorate || 'دمشق');
  const [target, setTarget] = useState(profile.targetAverage || 80);
  const [examDate, setExamDate] = useState(profile.examDate);
  const [error, setError] = useState<string | null>(null);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError('اكتب اسمك كما تحب أن نناديك به (حرفان على الأقل).');
      return;
    }
    if (!examDate) {
      setError('حدّد تاريخ امتحان البكالوريا لنبني العدّاد التنازلي.');
      return;
    }
    setError(null);
    save({
      name: name.trim(),
      governorate,
      targetAverage: target,
      examDate,
      onboarded: true,
      createdAt: profile.createdAt,
    });
    toast('أهلاً بك في منارتك يا ' + name.trim().split(' ')[0], 'success');
    navigate('/');
  };

  return (
    <div className="mx-auto w-full max-w-lg pb-10 md:max-w-4xl md:pb-0">
      <div className="beam mb-6 pt-6 text-center md:mb-8 md:pt-0">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 220, damping: 22 }}
          className="mx-auto mb-4 w-fit md:mb-6 md:scale-125"
        >
          <ManaraLogo size={64} />
        </motion.div>
        <h1 className="font-display text-2xl text-[var(--ink)] md:text-4xl">منارة البكالوريا</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-[var(--ink-soft)] md:max-w-2xl md:text-base">
          دروس الفيديو، الاختبارات، الملخصات، وخطة دراسة تُبنى حول تاريخ امتحانك. ابدأ بثلاث معلومات فقط.
        </p>
      </div>

      <form onSubmit={submit} className="card space-y-5 p-5 md:grid md:grid-cols-2 md:gap-x-7 md:gap-y-6 md:space-y-0 md:p-8">
        <div>
          <label htmlFor="name" className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-[var(--ink)] md:text-base">
            <GraduationCap size={18} /> ما اسمك؟
          </label>
          <input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="مثال: سارة"
            autoComplete="name"
            className="focus-ring h-12 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)] placeholder:text-[var(--ink-soft)]/70 md:h-14 md:px-4 md:text-base"
          />
        </div>

        <div>
          <label htmlFor="gov" className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-[var(--ink)] md:text-base">
            <MapPin size={18} /> محافظتك
          </label>
          <select
            id="gov"
            value={governorate}
            onChange={(e) => setGovernorate(e.target.value)}
            className="focus-ring h-12 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)] md:h-14 md:px-4 md:text-base"
          >
            {GOVERNORATES.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="exam" className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-[var(--ink)] md:text-base">
            <CalendarDays size={18} /> تاريخ أول امتحان
          </label>
          <input
            id="exam"
            type="date"
            value={examDate}
            onChange={(e) => setExamDate(e.target.value)}
            className="focus-ring h-12 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)] md:h-14 md:px-4 md:text-base"
          />
          <p className="mt-1 text-xs text-[var(--ink-soft)] md:text-sm">نستخدمه للعدّاد التنازلي ولتوزيع خطة الدراسة.</p>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <label htmlFor="target" className="flex items-center gap-1.5 text-sm font-medium text-[var(--ink)] md:text-base">
              <Target size={18} /> المعدل المستهدف
            </label>
            <span className="rounded-full bg-[var(--gold-soft)] px-2.5 py-0.5 font-display text-sm text-[#8a5b06] dark:text-[var(--gold)]">
              {target}%
            </span>
          </div>
          <input
            id="target"
            type="range"
            min={50}
            max={100}
            step={1}
            value={target}
            onChange={(e) => setTarget(Number(e.target.value))}
            className="h-3 w-full cursor-pointer appearance-none rounded-full bg-[var(--surface-2)] accent-[var(--gold)] md:h-4"
          />
          <div className="mt-1 flex justify-between text-[0.7rem] text-[var(--ink-soft)] md:text-xs">
            <span>50%</span>
            <span>100%</span>
          </div>
        </div>

        {error ? (
          <p className="rounded-xl bg-[#fdece2] px-3 py-2 text-xs text-[#a63a12] dark:bg-[#3a1c12] dark:text-[#f5a67f] md:col-span-2 md:text-sm">
            {error}
          </p>
        ) : null}

        <Button type="submit" block size="lg" variant="gold" className="md:col-span-2 md:min-h-16 md:text-lg">
          {profile.onboarded ? 'حفظ التعديلات' : 'ابدأ الدراسة'}
        </Button>

        <p className="text-center text-[0.7rem] leading-relaxed text-[var(--ink-soft)] md:col-span-2 md:text-sm">
          بياناتك تُحفظ على جهازك فقط (بدون كلمة مرور في هذه النسخة). يمكنك تصديرها من الإعدادات في أي وقت.
        </p>
      </form>
    </div>
  );
}
