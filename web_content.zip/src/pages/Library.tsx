import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Download, FileText, FolderOpen, Search, X } from 'lucide-react';
import { libraryFiles, subjects } from '../data/content';
import { PageHeader } from '../components/layout/PageHeader';
import { Chip } from '../components/ui/Card';
import { Badge, EmptyState, Modal } from '../components/ui/Feedback';
import { cn } from '../utils/format';
import { createPdfObjectUrl } from '../utils/publicAssets';

const KINDS = [
  { id: 'all', label: 'الكل' },
  { id: 'summary', label: 'ملخصات' },
  { id: 'formula', label: 'قوانين' },
  { id: 'exam', label: 'دورات سابقة' },
  { id: 'pdf', label: 'مرفقات الدروس' },
];

export default function Library() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [kind, setKind] = useState('all');
  const [subjectId, setSubjectId] = useState('all');

  const openId = params.get('file');
  const opened = openId ? libraryFiles.find((f) => f.id === openId) : undefined;
  const [documentUrl, setDocumentUrl] = useState('');

  useEffect(() => {
    if (!opened) {
      setDocumentUrl('');
      return;
    }
    const url = createPdfObjectUrl(opened.url);
    setDocumentUrl(url);
    return () => {
      if (url !== opened.url && url.startsWith('blob:')) {
        URL.revokeObjectURL(url.split('#', 1)[0] || url);
      }
    };
  }, [opened?.url]);

  const filtered = useMemo(() => {
    const q = query.trim();
    return libraryFiles.filter((file) => {
      if (kind !== 'all' && file.kind !== kind) return false;
      if (subjectId !== 'all' && file.subjectId !== subjectId) return false;
      if (q && !file.title.includes(q)) return false;
      return true;
    });
  }, [query, kind, subjectId]);

  const closeViewer = () => {
    const next = new URLSearchParams(params);
    next.delete('file');
    setParams(next, { replace: true });
  };

  return (
    <div>
      <PageHeader
        eyebrow={`${libraryFiles.length} ملفاً`}
        title="المكتبة"
        subtitle="ملخصات، قوانين، دورات سابقة وحلولها — كلها تُفتح داخل التطبيق."
      />

      <div className="relative mb-3">
        <Search size={16} className="absolute end-3 top-1/2 -translate-y-1/2 text-[var(--ink-soft)]" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث باسم الملف…"
          aria-label="بحث في المكتبة"
          className="focus-ring h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] pe-9 ps-3 text-[0.82rem]"
        />
      </div>

      <div className="no-scrollbar -mx-4 mb-2 flex gap-2 overflow-x-auto px-4">
        {KINDS.map((k) => (
          <Chip key={k.id} active={kind === k.id} onClick={() => setKind(k.id)}>
            {k.label}
          </Chip>
        ))}
      </div>
      <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
        <Chip active={subjectId === 'all'} onClick={() => setSubjectId('all')}>
          كل المواد
        </Chip>
        {subjects.map((s) => (
          <Chip key={s.id} active={subjectId === s.id} onClick={() => setSubjectId(s.id)}>
            {s.shortName}
          </Chip>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<FolderOpen size={18} />}
          title="لا نتائج"
          description="جرّب كلمة أبسط أو أزل الفلاتر."
        />
      ) : (
        <div className="space-y-2">
          {filtered.map((file) => {
            const subject = subjects.find((s) => s.id === file.subjectId);
            return (
              <button
                key={file.id}
                type="button"
                onClick={() => {
                  const next = new URLSearchParams(params);
                  next.set('file', file.id);
                  setParams(next);
                }}
                className="focus-ring card flex w-full items-center gap-3 p-3 text-start"
              >
                <span
                  className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-xl')}
                  style={{ background: `${subject?.color ?? '#666'}18`, color: subject?.color ?? 'var(--ink)' }}
                >
                  <FileText size={17} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[0.82rem] text-[var(--ink)]">{file.title}</span>
                  <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[0.64rem] text-[var(--ink-soft)]">
                    {subject?.name}
                    <span>·</span>
                    {file.size}
                    {file.year ? (
                      <>
                        <span>·</span>
                        {file.year}
                      </>
                    ) : null}
                  </span>
                </span>
                {file.kind === 'exam' ? <Badge tone="gold">دورة</Badge> : null}
              </button>
            );
          })}
        </div>
      )}

      <Modal open={Boolean(opened)} onClose={closeViewer} title={opened?.title} size="lg">
        {opened ? (
          <div>
            <div className="mb-2 flex items-center justify-between gap-2">
              <p className="text-[0.68rem] text-[var(--ink-soft)]">
                PDF · {opened.size}
                {opened.pages ? ` · ${opened.pages} صفحات` : ''}
              </p>
              <div className="flex items-center gap-1.5">
                <a
                  href={documentUrl || opened.url}
                  download
                  className="focus-ring inline-flex h-8 items-center gap-1 rounded-full border border-[var(--line)] px-2.5 text-[0.68rem] text-[var(--ink)]"
                >
                  <Download size={13} /> تنزيل
                </a>
                <button
                  type="button"
                  onClick={closeViewer}
                  aria-label="إغلاق العارض"
                  className="focus-ring flex h-8 w-8 items-center justify-center rounded-full bg-[var(--surface-2)] text-[var(--ink-soft)]"
                >
                  <X size={14} />
                </button>
              </div>
            </div>
            <div className="overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--surface-2)]">
              <iframe
                src={documentUrl || opened.url}
                title={opened.title}
                className="h-[62dvh] w-full"
                loading="lazy"
              />
            </div>
            <p className="mt-2 text-center text-[0.65rem] text-[var(--ink-soft)]">
              إن لم يظهر الملف داخل عارض المتصفح، استخدم زر التنزيل.
            </p>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
