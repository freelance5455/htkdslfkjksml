import React from 'react';
import { Link } from 'react-router-dom';
import {
  Wrench,
  Sparkles,
  Calculator,
  Compass,
  Bookmark,
  History,
  Settings,
  Scale,
  MessageSquare,
  ShieldCheck,
  ChevronRight,
  Sigma,
  Volume2,
  VolumeX,
  Smartphone
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const MorePage: React.FC = () => {
  const { settings, updateSettings, playSound, triggerHaptic, favorites } = useApp();

  const toggleSound = () => {
    const next = !settings.soundEnabled;
    updateSettings({ soundEnabled: next });
    if (next) playSound('button');
    triggerHaptic('light');
  };

  const navItems = [
    {
      to: '/tools',
      title: 'Engineering Calculators',
      desc: 'Beam deflection, Reynolds flow, Rocket delta-v, RLC circuits',
      icon: <Wrench className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/practice',
      title: 'Interactive Practice Mode',
      desc: 'Physics, electronics, and aerospace student challenge quizzes',
      icon: <Sparkles className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/scientific-calculator',
      title: 'Scientific Calculator',
      desc: 'Trigonometry, logarithms, roots, constants, and memory tape',
      icon: <Calculator className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/unit-converter',
      title: 'SI Engineering Unit Converter',
      desc: 'Length, pressure, energy, velocity, force, power, and mass',
      icon: <Scale className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/formulas',
      title: 'Complete Formula Library',
      desc: 'Over 50+ peer-verified mathematics and physics equations',
      icon: <Compass className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/favorites',
      title: 'Saved Favorites',
      desc: `${favorites.length} saved equations in local storage`,
      icon: <Bookmark className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/history',
      title: 'Calculation History Log',
      desc: 'Audit trail of executed calculations with parameters',
      icon: <History className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/settings',
      title: 'Preferences & Settings',
      desc: 'Sound haptics, dark theme, and calculation precision',
      icon: <Settings className="w-5 h-5 text-[#D65A1F]" />
    },
    {
      to: '/feedback',
      title: 'Formula Suggestions & Feedback',
      desc: 'Request new engineering equations or submit feedback',
      icon: <MessageSquare className="w-5 h-5 text-[#D65A1F]" />
    }
  ];

  return (
    <div className="space-y-6 pb-20 max-w-2xl mx-auto">
      {/* Brand Header */}
      <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#303030] shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#232323] border border-[#303030] flex items-center justify-center text-[#D65A1F]">
              <Sigma className="w-6 h-6 text-[#D65A1F]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg text-[#F5F2ED]">FormulaX</span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#232323] text-[#D65A1F] border border-[#303030]">
                  PRO
                </span>
              </div>
              <p className="text-xs text-[#A9A39C] font-mono">Calculate. Understand. Engineer.</p>
            </div>
          </div>

          <button
            onClick={toggleSound}
            className={`p-2.5 rounded-xl border transition-colors ${
              settings.soundEnabled
                ? 'bg-[#232323] text-[#D65A1F] border-[#303030]'
                : 'bg-[#151515] text-[#A9A39C] border-[#303030]'
            }`}
            title="Toggle Sound"
          >
            {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-[#303030] text-xs font-mono text-[#A9A39C]">
          <span className="flex items-center gap-1.5 text-[#72A65A]">
            <span className="w-2 h-2 rounded-full bg-[#72A65A]"></span>
            100% Offline Capable
          </span>
          <span>Zero-Auth Architecture</span>
        </div>
      </div>

      {/* Navigation list */}
      <div className="rounded-3xl bg-[#1C1C1C] border border-[#303030] divide-y divide-[#303030] overflow-hidden shadow-xl">
        {navItems.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            onClick={() => playSound('tab')}
            className="flex items-center justify-between p-4 hover:bg-[#232323] transition-colors group"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-9 h-9 rounded-xl bg-[#232323] border border-[#303030] flex items-center justify-center shrink-0 group-hover:border-[#D65A1F]/50 transition-colors">
                {item.icon}
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#F5F2ED] group-hover:text-[#D65A1F] transition-colors">
                  {item.title}
                </h3>
                <p className="text-[11px] text-[#A9A39C] leading-snug">{item.desc}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#A9A39C] group-hover:text-[#F5F2ED] group-hover:translate-x-0.5 transition-all shrink-0" />
          </Link>
        ))}
      </div>

      <div className="text-center pt-2 text-[11px] font-mono text-[#A9A39C]">
        FormulaX Pro v3.0 • Responsive Engineering Formula Engine
      </div>
    </div>
  );
};
