import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import { useProjects } from "@/hooks/useProjects";
import WorkflowStatus from "@/components/features/WorkflowStatus";
import { cn, formatDate, getStatusColor, getStatusLabel, truncate } from "@/lib/utils";
import { CONTENT_TYPE_LABELS, PLATFORMS } from "@/constants";
import type { ProjectStatus, Platform } from "@/types";
import { Plus, Search, FolderOpen, Trash2, ArrowRight, Filter, Play, Film, Image as ImageIcon, Video, Copy } from "lucide-react";
import { UniversalMediaModal } from "@/components/common/UniversalMediaModal";
import { DeleteProjectConfirmModal } from "@/components/common/DeleteProjectConfirmModal";
import CreateContentDropdown from "@/components/features/CreateContentDropdown";

export default function ProjectsPage() {
  const navigate = useNavigate();
  const { projects, deleteProject } = useProjects();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<ProjectStatus | "ALL">("ALL");
  const [filterPlatform, setFilterPlatform] = useState<Platform | "ALL">("ALL");

  // Delete modal state
  const [projectToDelete, setProjectToDelete] = useState<{ id: string; title: string } | null>(null);

  // Media preview modal state
  const [modalMedia, setModalMedia] = useState<{
    isOpen: boolean;
    url: string;
    type: "VIDEO" | "IMAGE";
    title: string;
    prompt?: string;
  }>({
    isOpen: false,
    url: "",
    type: "VIDEO",
    title: "",
  });

  const filtered = projects.filter((p) => {
    const matchSearch = search === "" || p.title.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "ALL" || p.status === filterStatus;
    const matchPlatform = filterPlatform === "ALL" || p.platform === filterPlatform;
    return matchSearch && matchStatus && matchPlatform;
  });

  const handleDeleteClick = (id: string, title: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setProjectToDelete({ id, title });
  };

  const handleConfirmDelete = () => {
    if (projectToDelete) {
      deleteProject(projectToDelete.id);
      setProjectToDelete(null);
    }
  };

  const handleWatchVideo = (e: React.MouseEvent, url: string, title: string, prompt?: string) => {
    e.stopPropagation();
    setModalMedia({
      isOpen: true,
      url,
      type: "VIDEO",
      title,
      prompt,
    });
  };

  const handleViewImage = (e: React.MouseEvent, url: string, title: string, prompt?: string) => {
    e.stopPropagation();
    setModalMedia({
      isOpen: true,
      url,
      type: "IMAGE",
      title,
      prompt,
    });
  };

  return (
    <AppLayout title="Projetos" subtitle={`${projects.length} projeto${projects.length !== 1 ? "s" : ""}`}>
      <div className="p-6 space-y-5 max-w-6xl">

        {/* Toolbar */}
        <div className="flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-studio-text-muted" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar projetos..."
              className="studio-input pl-9 text-sm py-2.5"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-studio-text-muted" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as ProjectStatus | "ALL")}
              className="studio-input text-sm py-2 pr-8 min-w-36"
            >
              <option value="ALL">Todos os status</option>
              {["IDEA","BRIEFING","SCRIPTING","STORYBOARDING","MEDIA_PLANNING","GENERATING","EDITING","REVIEW","RENDERING","COMPLETED"].map((s) => (
                <option key={s} value={s}>{getStatusLabel(s)}</option>
              ))}
            </select>

            <select
              value={filterPlatform}
              onChange={(e) => setFilterPlatform(e.target.value as Platform | "ALL")}
              className="studio-input text-sm py-2 pr-8 min-w-36"
            >
              <option value="ALL">Todas as plataformas</option>
              {PLATFORMS.map((p) => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate("/external-videos")}
              className="px-3 py-2 rounded-xl bg-studio-panel border border-studio-border hover:border-studio-blue/40 text-studio-text hover:text-studio-blue text-xs font-semibold flex items-center gap-1.5 transition-all"
              title="Importar da galeria ou plataformas"
            >
              <Video className="w-3.5 h-3.5 text-studio-blue" />
              <span>Vídeos Externos</span>
            </button>

            <button
              onClick={() => navigate("/clone-studio")}
              className="px-3 py-2 rounded-xl bg-studio-panel border border-studio-border hover:border-studio-gold/40 text-studio-text hover:text-studio-gold text-xs font-semibold flex items-center gap-1.5 transition-all"
              title="Clonar canais, vídeos e músicas"
            >
              <Copy className="w-3.5 h-3.5 text-studio-gold" />
              <span>Clonar Estúdio</span>
            </button>

            <CreateContentDropdown
              id="btn-projects-criar-conteudo"
              variant="compact"
              buttonText="+ Novo Conteúdo"
            />
          </div>
        </div>

        {/* Projects Grid */}
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center studio-card">
            <FolderOpen className="w-12 h-12 text-studio-text-muted mb-4" />
            <h3 className="text-base font-semibold text-studio-text mb-2 font-display">
              {search || filterStatus !== "ALL" ? "Nenhum projeto encontrado" : "Nenhum projeto ainda"}
            </h3>
            <p className="text-sm text-studio-text-muted mb-6">
              {search ? "Tente outro termo de busca" : "Crie seu primeiro projeto com IA"}
            </p>
            {!search && (
              <button onClick={() => navigate("/creator")} className="btn-primary text-sm">
                <Plus className="w-4 h-4" />
                Criar Projeto
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filtered.map((project) => (
              <div
                key={project.id}
                onClick={() => navigate(`/projects/${project.id}`)}
                className="studio-card p-5 cursor-pointer hover:border-studio-blue/30 transition-all group"
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-bold text-studio-text font-display group-hover:text-studio-blue transition-colors line-clamp-1">
                      {project.title}
                    </h3>
                    {project.description && (
                      <p className="text-xs text-studio-text-muted mt-0.5 line-clamp-1">
                        {truncate(project.description, 80)}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      id={`btn-delete-project-${project.id}`}
                      onClick={(e) => handleDeleteClick(project.id, project.title, e)}
                      className="p-2 rounded-lg text-studio-text-muted hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition-all"
                      title="Apagar este projeto"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <ArrowRight className="w-4 h-4 text-studio-text-muted group-hover:text-studio-blue transition-colors" />
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap mb-3">
                  <span className={cn("task-badge text-xs", getStatusColor(project.status))}>
                    {getStatusLabel(project.status)}
                  </span>
                  <span className="text-xs text-studio-text-muted">
                    {CONTENT_TYPE_LABELS[project.contentType]}
                  </span>
                  <span className="text-xs text-studio-text-muted">•</span>
                  <span className="text-xs text-studio-text-muted">{project.platform}</span>
                  <span className="text-xs text-studio-text-muted ml-auto">{formatDate(project.createdAt)}</span>
                </div>

                <WorkflowStatus status={project.status} compact />

                {/* Media Quick-Watch Bar */}
                {(() => {
                  const videoAsset = project.assets?.find((a) => a.type === "VIDEO" && a.url);
                  const sceneWithVideo = project.storyboard?.scenes?.find((s) => s.videoUrl);
                  const videoUrl = videoAsset?.url || sceneWithVideo?.videoUrl;

                  const imageAsset = project.assets?.find(
                    (a) => (a.type === "IMAGE" || a.type === "THUMBNAIL") && a.url
                  );
                  const sceneWithImage = project.storyboard?.scenes?.find((s) => s.imageUrl);
                  const imageUrl = imageAsset?.url || sceneWithImage?.imageUrl;

                  if (!videoUrl && !imageUrl) return null;

                  return (
                    <div className="mt-3 p-2 rounded-xl bg-studio-panel border border-studio-border flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {imageUrl ? (
                          <img
                            src={imageUrl}
                            alt="Preview"
                            className="w-10 h-7 rounded-md object-cover border border-studio-border shrink-0"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-10 h-7 rounded-md bg-black/40 border border-studio-border flex items-center justify-center shrink-0">
                            <Film className="w-3.5 h-3.5 text-studio-gold" />
                          </div>
                        )}
                        <span className="text-xs font-semibold text-studio-text truncate">
                          {videoUrl ? "Vídeo Gerado Pronto" : "Imagem de Cena"}
                        </span>
                      </div>

                      {videoUrl ? (
                        <button
                          onClick={(e) =>
                            handleWatchVideo(e, videoUrl, project.title, project.description)
                          }
                          className="px-3 py-1 rounded-lg bg-studio-gold text-black font-bold text-xs flex items-center gap-1.5 shadow-sm hover:scale-105 transition-all shrink-0"
                        >
                          <Play className="w-3.5 h-3.5 fill-black" />
                          <span>Assistir Vídeo</span>
                        </button>
                      ) : (
                        <button
                          onClick={(e) =>
                            handleViewImage(e, imageUrl, project.title, project.description)
                          }
                          className="px-3 py-1 rounded-lg bg-studio-blue/20 text-studio-blue hover:bg-studio-blue hover:text-white font-bold text-xs flex items-center gap-1.5 transition-all shrink-0"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>Ver Imagem</span>
                        </button>
                      )}
                    </div>
                  );
                })()}

                <div className="flex items-center gap-3 mt-3 pt-3 border-t border-studio-border">
                  <span className="text-xs text-studio-text-muted">
                    {project.tasks.filter((t) => t.status === "COMPLETED").length}/{project.tasks.length} tarefas
                  </span>
                  <span className="text-xs text-studio-text-muted">
                    {project.assets.length} assets
                  </span>
                  {project.brief && <span className="text-xs text-studio-green">✓ Brief</span>}
                  {project.script && <span className="text-xs text-studio-green">✓ Roteiro</span>}
                  {project.storyboard && <span className="text-xs text-studio-green">✓ Storyboard</span>}
                  {project.contentPackage && <span className="text-xs text-studio-blue font-semibold">✓ Pacote SEO</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Universal Media Watch / Preview Modal */}
      <UniversalMediaModal
        isOpen={modalMedia.isOpen}
        onClose={() => setModalMedia((prev) => ({ ...prev, isOpen: false }))}
        mediaUrl={modalMedia.url}
        mediaType={modalMedia.type}
        title={modalMedia.title}
        prompt={modalMedia.prompt}
      />

      {/* Delete Project Confirmation Modal */}
      <DeleteProjectConfirmModal
        isOpen={!!projectToDelete}
        onClose={() => setProjectToDelete(null)}
        onConfirm={handleConfirmDelete}
        projectTitle={projectToDelete?.title || ""}
      />
    </AppLayout>
  );
}
