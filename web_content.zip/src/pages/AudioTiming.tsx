import { useMemo, useRef, useState } from "react";
import { AudioLines, ChevronDown, Clock3, Music2, Play, Upload, Volume2, Waves, AlertTriangle, Link2, FileAudio, Trash2 } from "lucide-react";
import type { MediaMeta, Question, ViewKey } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { buildTimeline, formatClock } from "@/lib/timeline";
import { formatDuration, formatBytes } from "@/data/defaults";
import { isAudioName } from "@/lib/media";
import { MediaPicker, Waveform } from "@/components/MediaPicker";
import { Button, Field, InlineNotice, Input, Modal, RangeField, SectionHeader, Segmented, Toggle } from "@/components/ui";
import { cn } from "@/utils/cn";

type Role = "question" | "options" | "answer" | "combined";
const ROLE_LABEL: Record<Role, string> = { question: "السؤال", options: "الخيارات", answer: "الإجابة", combined: "موحّد" };

interface BulkEntry {
  file: File;
  questionIndex: number;
  role: Role;
}

function parseAudioKey(name: string): { questionIndex: number; role: Role } | null {
  const lower = decodeURIComponent(name).toLowerCase();
  const match = lower.match(/(?:^|[^0-9])(?:q[_\-\s]?)?(\d{1,3})(?:[^0-9]|$)/);
  if (!match) return null;
  const questionIndex = Number(match[1]) - 1;
  let role: Role | null = null;
  if (/(combined|all|موحد|موحّد)/.test(lower)) role = "combined";
  else if (/(answer|correct|reveal|إجابة)/.test(lower)) role = "answer";
  else if (/(option|choice|choices|خيارات)/.test(lower)) role = "options";
  else if (/(question|sawal|سؤال)/.test(lower)) role = "question";
  if (!role) return null;
  return { questionIndex, role };
}

function fieldFor(role: Role): keyof Pick<Question, "questionAudioId" | "optionsAudioId" | "answerAudioId" | "combinedAudioId"> {
  return role === "options" ? "optionsAudioId" : role === "answer" ? "answerAudioId" : role === "combined" ? "combinedAudioId" : "questionAudioId";
}

export function AudioTimingPage({ onNavigate }: { onNavigate: (view: ViewKey) => void }) {
  const { project, updateProject, addMediaFile, removeMedia, mediaUrls, toast } = useStudio();
  const timeline = buildTimeline(project);
  const [expanded, setExpanded] = useState<string | null>(project.questions[0]?.id ?? null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkEntries, setBulkEntries] = useState<BulkEntry[]>([]);
  const [bulkUnmatched, setBulkUnmatched] = useState<string[]>([]);
  const [bulkMissing, setBulkMissing] = useState<string[]>([]);
  const [bulkAllowReplace, setBulkAllowReplace] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const bulkRef = useRef<HTMLInputElement>(null);

  const uniqueAudio = useMemo(() => {
    const set = new Set<string>();
    timeline.scenes.forEach((scene) => scene.audio.forEach((clip) => set.add(clip.mediaId)));
    return [...set];
  }, [timeline]);

  const patchTiming = (patch: Partial<typeof project.timing>) => {
    updateProject((current) => ({ ...current, timing: { ...current.timing, ...patch } }));
  };
  const patchQuestion = (id: string, patch: Partial<Question>) => {
    updateProject((current) => ({
      ...current,
      isSample: false,
      questions: current.questions.map((question) => (question.id === id ? { ...question, ...patch } : question)),
    }));
  };

  const prepareBulk = (files: FileList | null) => {
    if (!files?.length) return;
    const entries: BulkEntry[] = [];
    const unmatched: string[] = [];
    const seen = new Set<string>();
    for (const file of Array.from(files)) {
      if (!isAudioName(file.name, file.type)) {
        unmatched.push(`${file.name} (ليس صوتًا)`);
        continue;
      }
      if (seen.has(file.name.toLowerCase())) continue;
      seen.add(file.name.toLowerCase());
      const parsed = parseAudioKey(file.name);
      if (!parsed || parsed.questionIndex < 0 || parsed.questionIndex >= project.questions.length) {
        unmatched.push(file.name);
        continue;
      }
      entries.push({ file, questionIndex: parsed.questionIndex, role: parsed.role });
    }
    const missing: string[] = [];
    project.questions.forEach((_question, index) => {
      if (!entries.some((entry) => entry.questionIndex === index && entry.role === "question")) missing.push(`السؤال ${index + 1}: صوت السؤال`);
      if (!entries.some((entry) => entry.questionIndex === index && entry.role === "options")) missing.push(`السؤال ${index + 1}: صوت الخيارات`);
    });
    setBulkEntries(entries);
    setBulkUnmatched(unmatched);
    setBulkMissing(missing);
    setBulkAllowReplace(false);
    setBulkOpen(true);
    if (bulkRef.current) bulkRef.current.value = "";
  };

  const applyBulk = async () => {
    setBulkBusy(true);
    const mapping = new Map<string, MediaMeta>();
    const failed: string[] = [];
    for (const entry of bulkEntries) {
      try {
        const meta = await addMediaFile(entry.file, "audio");
        mapping.set(`${entry.questionIndex}:${entry.role}`, meta);
      } catch {
        failed.push(entry.file.name);
      }
    }
    updateProject((current) => ({
      ...current,
      isSample: false,
      questions: current.questions.map((question, index) => {
        const next = { ...question };
        (["question", "options", "answer", "combined"] as Role[]).forEach((role) => {
          const meta = mapping.get(`${index}:${role}`);
          if (meta) next[fieldFor(role)] = meta.id;
        });
        return next;
      }),
    }));
    setBulkBusy(false);
    setBulkOpen(false);
    if (failed.length) toast(`رُبطت ${mapping.size} ملفات، وفشل ${failed.length}: ${failed.slice(0, 2).join("، ")}.`, "warning");
    else toast(`رُبطت ${mapping.size} ملفات صوتية بالأسئلة تلقائيًا.`, "success");
  };

  const conflicts = bulkEntries.filter((entry) => {
    const question = project.questions[entry.questionIndex];
    return Boolean(question?.[fieldFor(entry.role)]);
  });
  const duplicateAudioNames = bulkEntries.filter((entry) =>
    Object.values(project.media).some((meta) => meta.name.toLowerCase() === entry.file.name.toLowerCase()),
  );
  const library = Object.values(project.media).sort((a, b) => b.createdAt - a.createdAt);
  const usageOf = (id: string) => {
    let count = project.questions.filter((question) => [question.questionAudioId, question.optionsAudioId, question.combinedAudioId, question.answerAudioId, question.imageId].includes(id)).length;
    if (project.timing.backgroundMusicId === id) count++;
    if (project.design.background.imageId === id) count++;
    if (project.design.brand.logoId === id) count++;
    return count;
  };

  return (
    <div>
      <SectionHeader
        icon={<AudioLines size={18} />}
        eyebrow="مدير الصوت والتوقيت"
        title="الصوت والتوقيت"
        description="كل مدة محسوبة من طول الملف الصوتي الفعلي. هذا الخط الزمني نفسه يُستخدم في المعاينة وفي ملف MP4 النهائي."
        actions={
          <>
            <Button variant="ghost" onClick={() => bulkRef.current?.click()}><Upload size={14} /> استيراد صوتيات</Button>
            <Button variant="primary" onClick={() => onNavigate("preview")}><Play size={14} /> معاينة التوقيت</Button>
          </>
        }
      />
      <input ref={bulkRef} type="file" accept="audio/*" multiple className="hidden" onChange={(event) => prepareBulk(event.target.files)} />

      <div className="mb-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {[
          { label: "مدة الفيديو", value: formatDuration(timeline.totalDuration), icon: Clock3, tone: "text-[#e7cf94]" },
          { label: "ملفات صوت مرتبطة", value: `${uniqueAudio.length}`, icon: FileAudio, tone: "text-[#9ef0c1]" },
          { label: "موسيقى خلفية", value: project.timing.backgroundMusicId ? "مفعّلة" : "لا", icon: Music2, tone: "text-[#c9c9d1]" },
          { label: "تنبيهات التوقيت", value: `${timeline.warnings.length}`, icon: AlertTriangle, tone: timeline.warnings.length ? "text-[#e7cf94]" : "text-[#9ef0c1]" },
        ].map((item) => (
          <div key={item.label} className="panel flex items-center gap-2.5 px-3 py-2.5">
            <item.icon size={14} className={item.tone} />
            <div><p className="text-[9px] text-[#7d7d87]">{item.label}</p><p className="font-display text-[13px] font-bold text-white">{item.value}</p></div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <section className="space-y-3">
          <div className="panel p-3.5 sm:p-4">
            <div className="mb-2 flex items-center justify-between">
              <div>
                <h3 className="font-display text-[15px] font-bold text-white">أصوات الأسئلة</h3>
                <p className="mt-0.5 text-[10px] text-[#7d7d87]">ارفع الملفات يدويًا أو استورد مجموعة بأسماء منظمة.</p>
              </div>
              <Button variant="quiet" className="!px-2 !py-1.5 text-[10px]" onClick={() => bulkRef.current?.click()}><Upload size={12} /> دفعة واحدة</Button>
            </div>
            <div className="mb-2 rounded-lg border border-white/[0.07] bg-black/20 px-2.5 py-2 text-[9px] leading-5 text-[#797983]" dir="rtl">
              أسماء المطابقة: <span dir="ltr" className="text-[#d9c187]">q01_question.mp3 · q01_options.mp3 · q01_answer.mp3</span>
            </div>
            <div className="space-y-2">
              {project.questions.map((question, index) => {
                const scene = timeline.scenes[index];
                const open = expanded === question.id;
                const audioCount = [question.questionAudioId, question.optionsAudioId, question.combinedAudioId, question.answerAudioId].filter(Boolean).length;
                return (
                  <div key={question.id} className={cn("rounded-xl border transition", open ? "border-white/[0.13] bg-white/[0.02]" : "border-white/[0.06] bg-white/[0.012]")}>
                    <button type="button" onClick={() => setExpanded(open ? null : question.id)} className="flex w-full items-center gap-2.5 p-2.5 text-right">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-black/25 text-[10px] font-semibold text-[#d8c089]">{index + 1}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[11px] font-medium text-[#e5e5ea]">{question.question || "سؤال بدون نص"}</p>
                        <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[9px] text-[#767680]">
                          <span className={audioCount ? "text-[#83dca9]" : "text-[#c5a66b]"}>{audioCount} ملفات صوت</span>
                          <span>·</span>
                          <span>سؤال {formatClock(scene?.timings.start ?? 0)}</span>
                          <span>·</span>
                          <span>تفكير {question.thinkSec} ث</span>
                        </p>
                      </div>
                      <ChevronDown size={14} className={cn("text-[#70707a] transition", open && "rotate-180")} />
                    </button>
                    {open ? (
                      <div className="border-t border-white/[0.06] p-2.5">
                        <div className="mb-2 flex flex-wrap gap-1 text-[9px]">
                          <span className="chip !px-1.5 !py-0.5">سؤال: {formatClock(scene?.timings.start ?? 0)}</span>
                          <span className="chip !px-1.5 !py-0.5">خيارات: {formatClock((scene?.timings.start ?? 0) + (scene?.timings.optionsStart ?? 0))}</span>
                          <span className="chip chip-gold !px-1.5 !py-0.5">تفكير: {formatClock((scene?.timings.start ?? 0) + (scene?.timings.thinkingStart ?? 0))}</span>
                          <span className="chip chip-mint !px-1.5 !py-0.5">إجابة: {formatClock((scene?.timings.start ?? 0) + (scene?.timings.revealStart ?? 0))}</span>
                        </div>
                        <div className="grid gap-2">
                          {project.timing.audioMode === "combined" ? (
                            <MediaPicker
                              label="الصوت الموحّد (سؤال + خيارات)"
                              kind="audio"
                              value={question.combinedAudioId}
                              onSelect={(id) => patchQuestion(question.id, { combinedAudioId: id })}
                              onRemove={() => patchQuestion(question.id, { combinedAudioId: null })}
                              suggestedName={`q${String(index + 1).padStart(2, "0")}_combined.mp3`}
                              compact
                            />
                          ) : (
                            <>
                              <MediaPicker label="قراءة السؤال" kind="audio" value={question.questionAudioId} onSelect={(id) => patchQuestion(question.id, { questionAudioId: id })} onRemove={() => patchQuestion(question.id, { questionAudioId: null })} suggestedName={`q${String(index + 1).padStart(2, "0")}_question.mp3`} compact />
                              <MediaPicker label="قراءة الخيارات" kind="audio" value={question.optionsAudioId} onSelect={(id) => patchQuestion(question.id, { optionsAudioId: id })} onRemove={() => patchQuestion(question.id, { optionsAudioId: null })} suggestedName={`q${String(index + 1).padStart(2, "0")}_options.mp3`} compact />
                            </>
                          )}
                          <MediaPicker label="صوت الإجابة الصحيحة (اختياري)" kind="audio" value={question.answerAudioId} onSelect={(id) => patchQuestion(question.id, { answerAudioId: id })} onRemove={() => patchQuestion(question.id, { answerAudioId: null })} suggestedName={`q${String(index + 1).padStart(2, "0")}_answer.mp3`} compact />
                        </div>
                        <div className="mt-2 grid grid-cols-2 gap-2">
                          <Field label="مدة التفكير (ث)">
                            <Input type="number" min={1} max={120} value={question.thinkSec} onChange={(event) => patchQuestion(question.id, { thinkSec: Math.max(1, Math.min(120, Number(event.target.value) || 1)) })} />
                          </Field>
                          <Field label="مدة كشف الإجابة (ث)">
                            <Input type="number" min={0.6} max={10} step={0.1} value={Math.round((question.revealHoldMs / 1000) * 10) / 10} onChange={(event) => patchQuestion(question.id, { revealHoldMs: Math.max(600, Number(event.target.value) * 1000 || 1800) })} />
                          </Field>
                        </div>
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="panel p-3.5 sm:p-4">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-[15px] font-bold text-white">الخط الزمني الموحّد</h3>
              <span className="text-[10px] text-[#85858f]">{formatDuration(timeline.totalDuration)} · {timeline.scenes.length} مشاهد</span>
            </div>
            <div className="flex h-16 w-full overflow-hidden rounded-lg border border-white/[0.08] bg-black/30" dir="ltr">
              {timeline.scenes.map((scene, index) => {
                const width = (scene.timings.duration / Math.max(0.01, timeline.totalDuration)) * 100;
                return (
                  <div key={scene.questionId} className="relative h-full border-r border-black/40" style={{ width: `${width}%`, background: index % 2 ? "#201d16" : "#252219" }}>
                    <div className="absolute inset-x-0 top-0 flex h-1.5">
                      <span style={{ width: `${(scene.timings.optionsStart / scene.timings.duration) * 100}%` }} className="h-full bg-[#6d5f3a]" />
                      <span style={{ width: `${((scene.timings.thinkingStart - scene.timings.optionsStart) / scene.timings.duration) * 100}%` }} className="h-full bg-[#8c7642]" />
                      <span style={{ width: `${((scene.timings.revealStart - scene.timings.thinkingStart) / scene.timings.duration) * 100}%` }} className="h-full bg-[#b79a52]" />
                      <span className="h-full flex-1 bg-[#57dc96]/60" />
                    </div>
                    <span className="absolute bottom-1 right-1 text-[8px] text-[#d7c390]">س{index + 1}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-2 flex flex-wrap gap-2 text-[9px] text-[#83838d]">
              <span className="flex items-center gap-1"><i className="h-1.5 w-3 rounded bg-[#6d5f3a]" /> قراءة</span>
              <span className="flex items-center gap-1"><i className="h-1.5 w-3 rounded bg-[#8c7642]" /> خيارات</span>
              <span className="flex items-center gap-1"><i className="h-1.5 w-3 rounded bg-[#b79a52]" /> تفكير</span>
              <span className="flex items-center gap-1"><i className="h-1.5 w-3 rounded bg-[#57dc96]/60" /> كشف الإجابة</span>
            </div>
            {timeline.warnings.length ? (
              <div className="mt-3 space-y-1 rounded-lg border border-[#d9b65a]/20 bg-[#d9b65a]/[0.04] p-2.5">
                {timeline.warnings.slice(0, 4).map((warning) => <p key={warning} className="text-[9px] leading-5 text-[#c9b483]">• {warning}</p>)}
              </div>
            ) : null}
          </div>

          <div className="panel p-3.5 sm:p-4">
            <div className="mb-2.5 flex items-center justify-between">
              <div>
                <h3 className="font-display text-[15px] font-bold text-white">مكتبة الوسائط</h3>
                <p className="mt-0.5 text-[10px] text-[#7d7d87]">{library.length} ملفًا محفوظًا في هذا المشروع. احذف ما لا تستخدمه لتحرير مساحة الهاتف.</p>
              </div>
            </div>
            <div className="max-h-[220px] space-y-1.5 overflow-y-auto">
              {library.map((meta) => {
                const used = usageOf(meta.id);
                return (
                  <div key={meta.id} className="flex items-center gap-2 rounded-lg border border-white/[0.06] bg-white/[0.018] px-2.5 py-2">
                    <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-md", meta.kind === "audio" ? "bg-[#d9b65a]/10 text-[#e7cf94]" : "bg-[#57dc96]/10 text-[#9ef0c1]")}>
                      {meta.kind === "audio" ? <FileAudio size={12} /> : <Music2 size={12} />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[10px] text-[#dedee4]" dir="ltr">{meta.name}</p>
                      <p className="text-[9px] text-[#777781]">{meta.kind === "audio" ? formatDuration(meta.duration ?? 0) : `${meta.width ?? "?"}×${meta.height ?? "?"}`} · {formatBytes(meta.size)} · {used} ارتباط</p>
                    </div>
                    {meta.kind === "audio" && mediaUrls[meta.id] ? (
                      <audio controls preload="none" src={mediaUrls[meta.id]} className="hidden sm:block" style={{ height: 30 }} />
                    ) : null}
                    <button
                      type="button"
                      onClick={() => {
                        if (used > 0) toast(`الملف مرتبط بـ ${used} حقل. حذفه سيزيل ارتباطه من الأسئلة والتصميم.`, "warning");
                        void removeMedia(meta.id);
                      }}
                      disabled={used > 0}
                      className="rounded-md p-1.5 text-[#7f7f89] transition hover:bg-red-500/10 hover:text-red-300 disabled:cursor-not-allowed disabled:opacity-30"
                      aria-label={`حذف ${meta.name}`}
                      title={used > 0 ? "أزل ارتباط الملف أولًا من الحقول" : "حذف الملف من التخزين"}
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                );
              })}
              {!library.length ? <p className="rounded-lg border border-dashed border-white/10 px-2 py-5 text-center text-[10px] text-[#7c7c86]">لا توجد ملفات في هذا المشروع بعد.</p> : null}
            </div>
          </div>
        </section>

        <aside className="space-y-3 xl:sticky xl:top-[78px] xl:self-start">
          <div className="panel p-3.5 sm:p-4">
            <h3 className="mb-3 flex items-center gap-1.5 font-display text-[15px] font-bold text-white"><Clock3 size={15} className="text-[#d9b65a]" /> قواعد التوقيت</h3>
            <div className="space-y-3">
              <div>
                <span className="label">بنية الصوت لكل سؤال</span>
                <Segmented
                  value={project.timing.audioMode}
                  onChange={(value) => patchTiming({ audioMode: value })}
                  options={[{ value: "separate", label: "ملفان: سؤال + خيارات" }, { value: "combined", label: "ملف واحد موحّد" }]}
                  size="sm"
                />
              </div>
              {project.timing.audioMode === "combined" ? (
                <RangeField label="بدء ظهور الخيارات داخل الملف" value={project.timing.combinedSplit} min={10} max={95} unit="%" onChange={(value) => patchTiming({ combinedSplit: value })} />
              ) : null}
              <div className="grid grid-cols-2 gap-2">
                <Field label="مهلة بعد السؤال (مللي)">
                  <Input type="number" min={0} max={5000} step={50} value={project.timing.questionHoldMs} onChange={(event) => patchTiming({ questionHoldMs: Math.max(0, Math.min(5000, Number(event.target.value) || 0)) })} />
                </Field>
                <Field label="مهلة بعد الخيارات (مللي)">
                  <Input type="number" min={0} max={5000} step={50} value={project.timing.optionsHoldMs} onChange={(event) => patchTiming({ optionsHoldMs: Math.max(0, Math.min(5000, Number(event.target.value) || 0)) })} />
                </Field>
                <Field label="سؤال بلا صوت (مللي)">
                  <Input type="number" min={800} max={15000} step={100} value={project.timing.questionSilentMs} onChange={(event) => patchTiming({ questionSilentMs: Math.max(800, Math.min(15000, Number(event.target.value) || 3000)) })} />
                </Field>
                <Field label="خيارات بلا صوت (مللي)">
                  <Input type="number" min={800} max={15000} step={100} value={project.timing.optionsSilentMs} onChange={(event) => patchTiming({ optionsSilentMs: Math.max(800, Math.min(15000, Number(event.target.value) || 3200)) })} />
                </Field>
              </div>
              <Toggle checked={project.timing.requireAudio} onChange={(value) => patchTiming({ requireAudio: value })} label="اشترط صوت السؤال والخيارات" hint="عند التعطيل يُسمح بالتصدير بوقت صامت للأسئلة التي لا تحتوي صوتًا." />
              <InlineNotice kind="info" title="كيف يُحسب التوقيت؟">
                يبدأ المؤقت بعد انتهاء صوت الخيارات + المهلة. يظهر اللون الأخضر بعد مدة التفكير. لا توجد تأخيرات عشوائية.
              </InlineNotice>
            </div>
          </div>

          <div className="panel p-3.5 sm:p-4">
            <h3 className="mb-3 flex items-center gap-1.5 font-display text-[15px] font-bold text-white"><Volume2 size={15} className="text-[#57dc96]" /> الصوت والموسيقى</h3>
            <div className="space-y-3">
              <RangeField label="مستوى صوت القارئ" value={project.timing.voiceVolume} min={0} max={100} unit="%" onChange={(value) => patchTiming({ voiceVolume: value })} />
              <RangeField label="الموسيقى الخلفية" value={project.timing.musicVolume} min={0} max={100} unit="%" onChange={(value) => patchTiming({ musicVolume: value })} />
              <RangeField label="مستوى مؤثر الإجابة" value={project.timing.sfxVolume} min={0} max={100} unit="%" onChange={(value) => patchTiming({ sfxVolume: value })} />
              <Toggle checked={project.timing.sfxEnabled} onChange={(value) => patchTiming({ sfxEnabled: value })} label="مؤثر صوتي عند كشف الإجابة" hint="نغمة قصيرة تُضاف داخل الفيديو والمعاينة." />
              <MediaPicker
                label="موسيقى خلفية للمشروع (اختياري)"
                hint="تتكرر تلقائيًا طوال الفيديو بمستوى الصوت المحدد."
                kind="audio"
                value={project.timing.backgroundMusicId}
                onSelect={(id) => patchTiming({ backgroundMusicId: id })}
                onRemove={() => patchTiming({ backgroundMusicId: null })}
                compact
              />
              {project.timing.backgroundMusicId ? (
                <div className="rounded-lg border border-white/[0.07] bg-black/25 p-2">
                  <Waveform peaks={project.media[project.timing.backgroundMusicId]?.peaks} color="#57dc96" />
                  <p className="mt-1 text-[9px] text-[#777781]">{project.media[project.timing.backgroundMusicId]?.name} · {formatBytes(project.media[project.timing.backgroundMusicId]?.size ?? 0)}</p>
                </div>
              ) : null}
            </div>
          </div>

          <div className="rounded-xl border border-white/[0.07] bg-white/[0.018] p-3 text-[10px] leading-5 text-[#7e7e88]">
            <p className="mb-1 flex items-center gap-1.5 font-semibold text-[#bcbcc6]"><Waves size={12} className="text-[#d9b65a]" /> ملاحظة للموبايل</p>
            الملفات تُحلَّل عند رفعها وتُخزَّن محليًا. الملفات الطويلة جدًا قد تستهلك ذاكرة أكبر أثناء التصدير؛ راجع مدة الفيديو قبل البدء.
          </div>
        </aside>
      </div>

      <Modal
        open={bulkOpen}
        onClose={() => (bulkBusy ? undefined : setBulkOpen(false))}
        wide
        title="استيراد صوتيات ومطابقتها"
        description="تُطابق الملفات مع رقم السؤال والدور من الاسم. لن تُستبدل الروابط الحالية دون تأكيدك."
        footer={
          <div className="flex flex-wrap items-center justify-between gap-2">
            <button type="button" onClick={() => bulkRef.current?.click()} className="text-[11px] text-[#d9c187] hover:text-white">إضافة ملفات أخرى</button>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setBulkOpen(false)} disabled={bulkBusy}>إلغاء</Button>
              <Button variant="primary" onClick={() => void applyBulk()} loading={bulkBusy} disabled={!bulkEntries.length || ((conflicts.length > 0 || duplicateAudioNames.length > 0) && !bulkAllowReplace)}>
                <Link2 size={14} /> ربط {bulkEntries.length} ملفًا
              </Button>
            </div>
          </div>
        }
      >
        <div className="space-y-3">
          <div className="max-h-56 space-y-1 overflow-y-auto rounded-xl border border-white/[0.07] bg-[#0b0b0e] p-2">
            {bulkEntries.map((entry) => (
              <div key={`${entry.file.name}-${entry.questionIndex}-${entry.role}`} className="flex items-center gap-2 rounded-lg border border-white/[0.05] bg-white/[0.02] px-2 py-1.5">
                <Link2 size={12} className="text-[#7ce1a9]" />
                <span className="min-w-0 flex-1 truncate text-[10px] text-[#c4c4cd]" dir="ltr">{entry.file.name}</span>
                <span className="shrink-0 text-[9px] text-[#9ef0c1]">س {entry.questionIndex + 1} · {ROLE_LABEL[entry.role]}</span>
              </div>
            ))}
            {!bulkEntries.length ? <p className="px-2 py-5 text-center text-[11px] text-[#8a8a94]">لم يُطابق أي ملف. تأكد من الأسماء مثل q01_question.mp3.</p> : null}
          </div>
          {bulkUnmatched.length ? (
            <div className="rounded-lg border border-[#d9b65a]/20 bg-[#d9b65a]/[0.04] p-2.5">
              <p className="text-[10px] font-semibold text-[#e7cf94]">ملفات غير مطابقة ({bulkUnmatched.length})</p>
              <p className="mt-1 max-h-16 overflow-y-auto text-[9px] leading-5 text-[#a38f66]" dir="ltr">{bulkUnmatched.join(" · ")}</p>
            </div>
          ) : null}
          {bulkMissing.length ? (
            <div className="rounded-lg border border-white/10 bg-white/[0.02] p-2.5">
              <p className="text-[10px] font-semibold text-[#c9c9d1]">أدوار صوتية غير مرفوعة</p>
              <p className="mt-1 text-[9px] leading-5 text-[#8a8a94]">{bulkMissing.slice(0, 5).join(" · ")}{bulkMissing.length > 5 ? " …" : ""}</p>
            </div>
          ) : null}
          {duplicateAudioNames.length ? (
            <div className="rounded-lg border border-red-400/25 bg-red-400/[0.05] p-2.5">
              <p className="flex items-center gap-1 text-[10px] font-semibold text-red-200"><AlertTriangle size={12} /> {duplicateAudioNames.length} ملفًا يحمل نفس اسم ملف محفوظ</p>
              <p className="mt-1 text-[9px] leading-5 text-[#d9a4a4]">لن يُستبدل الملف القديم بصمت. سيُضاف كملف جديد مع الحفاظ على القديم، ولن تتغير ارتباطات أخرى.</p>
            </div>
          ) : null}
          {conflicts.length ? (
            <div className="rounded-lg border border-red-400/25 bg-red-400/[0.05] p-2.5">
              <p className="flex items-center gap-1 text-[10px] font-semibold text-red-200"><AlertTriangle size={12} /> {conflicts.length} حقول مرتبطة بملفات سابقة</p>
              <p className="mt-1 text-[9px] leading-5 text-[#d9a4a4]">سيُستبدل ارتباطها بالملفات الجديدة. الملفات القديمة لن تُحذف من التخزين.</p>
            </div>
          ) : null}
          {conflicts.length || duplicateAudioNames.length ? (
            <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-[#d9b65a]/25 bg-[#d9b65a]/[0.05] px-2.5 py-2 text-[10px] leading-5 text-[#f0dfb4]">
              <input type="checkbox" checked={bulkAllowReplace} onChange={(event) => setBulkAllowReplace(event.target.checked)} className="accent-[#d9b65a]" />
              أؤكد استبدال روابط الصوت المحددة ونسخ الملفات المكررة كنسخ جديدة دون حذف القديم.
            </label>
          ) : null}
        </div>
      </Modal>
    </div>
  );
}
