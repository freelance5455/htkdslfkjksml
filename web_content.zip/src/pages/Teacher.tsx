import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  BookOpen, GraduationCap, Loader2, MessageSquarePlus, Paperclip, Send, Sparkles, Trash2,
} from 'lucide-react';
import type { ChatMessage, ChatThread, ResourceRow, TeachingMode } from '@shared/types';
import { chaptersFor } from '@shared/syllabus';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn } from '../lib/utils';
import { Badge, Banner, Button, Card, EmptyState, IconButton, Select, SetupCard, Spinner, Textarea, useToast } from '../components/ui';
import { Markdown } from '../components/Markdown';

const MODES: { value: TeachingMode; label: string; blurb: string }[] = [
  { value: 'beginner', label: 'Beginner', blurb: 'Build from zero with analogies' },
  { value: 'exam', label: 'Exam', blurb: 'Syllabus, marks and exam wording' },
  { value: 'advanced', label: 'Advanced', blurb: 'JEE-level depth and derivations' },
];

export default function Teacher() {
  const { profile, aiEnabled } = useAuth();
  const { push } = useToast();
  const [params] = useSearchParams();

  const [chats, setChats] = useState<ChatThread[]>([]);
  const [resources, setResources] = useState<ResourceRow[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingChat, setLoadingChat] = useState(false);
  const [sending, setSending] = useState(false);
  const [draft, setDraft] = useState('');
  const [mode, setMode] = useState<TeachingMode>('beginner');
  const [subject, setSubject] = useState(params.get('subject') ?? profile?.subjects[0] ?? '');
  const [chapter, setChapter] = useState(params.get('chapter') ?? '');
  const [selectedResources, setSelectedResources] = useState<number[]>([]);
  const [showResources, setShowResources] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const chapters = useMemo(() => (profile ? chaptersFor(profile.exam, subject) : []), [profile, subject]);

  const loadChats = useCallback(async () => {
    try {
      const data = await api.get<{ chats: ChatThread[] }>('/api/teacher/chats?kind=teach');
      setChats(data.chats);
      return data.chats;
    } catch {
      return [];
    }
  }, []);

  const loadResources = useCallback(async () => {
    try {
      const data = await api.get<{ resources: ResourceRow[] }>('/api/resources');
      setResources(data.resources.filter((r) => r.status === 'ready'));
    } catch {
      /* resources are optional */
    }
  }, []);

  const openChat = useCallback(async (id: number) => {
    setActiveId(id);
    setLoadingChat(true);
    setError(null);
    try {
      const data = await api.get<{ chat: ChatThread; messages: ChatMessage[] }>(`/api/teacher/chats/${id}`);
      setMessages(data.messages);
      setMode(data.chat.mode);
      if (data.chat.subject) setSubject(data.chat.subject);
      if (data.chat.chapter) setChapter(data.chat.chapter);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not open this lesson.');
    } finally {
      setLoadingChat(false);
    }
  }, []);

  useEffect(() => {
    void loadChats();
    void loadResources();
  }, [loadChats, loadResources]);

  useEffect(() => {
    if (activeId === null) return;
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, sending, activeId]);

  const startNew = () => {
    setActiveId(null);
    setMessages([]);
    setDraft('');
    setError(null);
  };

  const send = async () => {
    const content = draft.trim();
    if (content.length < 2 || sending) return;
    setSending(true);
    setError(null);
    const optimistic: ChatMessage = { role: 'user', content };
    setMessages((prev) => [...prev, optimistic]);
    setDraft('');

    try {
      let chatId = activeId;
      if (chatId === null) {
        const created = await api.post<{ chat: ChatThread }>('/api/teacher/chats', {
          mode,
          subject: subject || null,
          chapter: chapter || null,
          kind: 'teach',
          title: content.slice(0, 70),
        });
        chatId = created.chat.id;
        setActiveId(chatId);
        setChats((prev) => [created.chat, ...prev]);
      }

      const data = await api.post<{ userMessage: ChatMessage; assistantMessage: ChatMessage }>(
        `/api/teacher/chats/${chatId}/messages`,
        { content, mode, subject, chapter, resourceIds: selectedResources },
      );
      setMessages((prev) => [...prev.filter((m) => m !== optimistic), data.userMessage, data.assistantMessage]);
      void loadChats();
    } catch (err) {
      setMessages((prev) => prev.filter((m) => m !== optimistic));
      setDraft(content);
      setError(err instanceof ApiError ? err.message : 'The tutor could not reply. Try again.');
    } finally {
      setSending(false);
    }
  };

  const removeChat = async (id: number) => {
    try {
      await api.del(`/api/teacher/chats/${id}`);
      setChats((prev) => prev.filter((c) => c.id !== id));
      if (activeId === id) startNew();
      push('Lesson deleted.', 'info');
    } catch {
      push('Could not delete this lesson.', 'bad');
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
      <div className="space-y-3">
        <Button className="w-full" onClick={startNew}><MessageSquarePlus size={16} /> New lesson</Button>
        <Card className="p-2">
          <div className="max-h-[320px] space-y-1 overflow-y-auto scroll-thin lg:max-h-[520px]">
            {chats.length === 0 && <p className="px-2 py-3 text-xs text-muted">No lessons yet. Ask your first question.</p>}
            {chats.map((chat) => (
              <div key={chat.id} className={cn('group flex items-center gap-1 rounded-lg pr-1 transition',
                activeId === chat.id ? 'bg-brand/15' : 'hover:bg-elevated')}>
                <button onClick={() => void openChat(chat.id)} className="min-w-0 flex-1 px-2.5 py-2 text-left">
                  <div className="truncate text-xs font-medium text-ink">{chat.title}</div>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[10px] text-muted">
                    <span className="capitalize">{chat.mode}</span>
                    {chat.chapter && <span className="truncate">· {chat.chapter}</span>}
                  </div>
                </button>
                <IconButton label="Delete lesson" className="h-7 w-7 opacity-0 group-hover:opacity-100" onClick={() => void removeChat(chat.id)}>
                  <Trash2 size={13} />
                </IconButton>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="space-y-3">
        <Card className="p-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex rounded-xl border border-line bg-elevated/50 p-1">
              {MODES.map((m) => (
                <button
                  key={m.value}
                  onClick={() => setMode(m.value)}
                  title={m.blurb}
                  className={cn('rounded-lg px-2.5 py-1.5 text-xs font-semibold transition',
                    mode === m.value ? 'bg-brand text-white' : 'text-muted hover:text-ink')}
                >
                  {m.label}
                </button>
              ))}
            </div>
            <Select value={subject} onChange={(e) => { setSubject(e.target.value); setChapter(''); }} className="w-auto min-w-[140px] py-2 text-xs">
              {profile?.subjects.map((s) => <option key={s}>{s}</option>)}
            </Select>
            <Select value={chapter} onChange={(e) => setChapter(e.target.value)} className="w-auto min-w-[170px] py-2 text-xs">
              <option value="">Any chapter</option>
              {chapters.map((c) => <option key={c}>{c}</option>)}
            </Select>
            <Button variant="secondary" className="ml-auto px-3 py-2 text-xs" onClick={() => setShowResources((v) => !v)}>
              <Paperclip size={13} /> {selectedResources.length ? `${selectedResources.length} source${selectedResources.length > 1 ? 's' : ''}` : 'Attach sources'}
            </Button>
          </div>
          {showResources && (
            <div className="mt-2 rounded-xl border border-line bg-elevated/40 p-3">
              {resources.length === 0 ? (
                <p className="text-xs text-muted">No processed resources yet. Upload a PDF in My Resources to ground answers in your own book.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {resources.map((r) => {
                    const active = selectedResources.includes(r.id);
                    return (
                      <button
                        key={r.id}
                        onClick={() => setSelectedResources((prev) => active ? prev.filter((id) => id !== r.id) : [...prev, r.id])}
                        className={cn('chip max-w-full', active && 'border-brand/50 bg-brand/10 text-brand')}
                      >
                        <BookOpen size={11} /> <span className="truncate">{r.name}</span>
                      </button>
                    );
                  })}
                </div>
              )}
              <p className="mt-2 text-[11px] text-muted">When sources are attached, the tutor answers from those pages and cites them. If the answer is not in them, it will say so.</p>
            </div>
          )}
        </Card>

        {!aiEnabled && <SetupCard />}
        {error && <Banner tone="bad">{error}</Banner>}

        <Card className="flex min-h-[420px] flex-col p-0">
          <div className="flex-1 space-y-4 overflow-y-auto p-4 scroll-thin" style={{ maxHeight: '58vh' }}>
            {loadingChat ? (
              <Spinner label="Opening lesson…" />
            ) : messages.length === 0 ? (
              <EmptyState
                icon={<GraduationCap size={22} />}
                title={chapter ? `Let's learn ${chapter}` : 'Start with anything you are stuck on'}
                description="Ask a concept question, request a full chapter walkthrough, or paste a problem. The tutor explains, then checks your understanding."
                action={
                  <div className="flex flex-wrap justify-center gap-2">
                    {[
                      chapter ? `Teach me ${chapter} from the beginning` : 'Teach me a chapter from the beginning',
                      'Explain with a real-life analogy',
                      'Give me 3 exam-style questions on this topic',
                    ].map((prompt) => (
                      <button key={prompt} onClick={() => setDraft(prompt)} className="chip hover:border-brand/40 hover:text-ink">{prompt}</button>
                    ))}
                  </div>
                }
              />
            ) : (
              messages.map((m, i) => (
                <div key={m.id ?? i} className={cn('flex gap-3', m.role === 'user' && 'justify-end')}>
                  {m.role === 'assistant' && (
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand/15 text-brand"><Sparkles size={15} /></span>
                  )}
                  <div className={cn('max-w-[85%] rounded-2xl px-4 py-3',
                    m.role === 'user' ? 'bg-brand text-white' : 'border border-line bg-elevated/40')}>
                    {m.role === 'assistant' ? <Markdown content={m.content} /> : <p className="whitespace-pre-wrap text-sm">{m.content}</p>}
                    {m.role === 'assistant' && m.citations && m.citations.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5 border-t border-line pt-2.5">
                        {m.citations.map((c, idx) => (
                          <Badge key={`${c.resourceName}-${c.page}-${idx}`} tone="brand">
                            {c.resourceName} · p. {c.page}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            {sending && (
              <div className="flex items-center gap-2.5 text-xs text-muted">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand/15 text-brand"><Loader2 size={15} className="animate-spin" /></span>
                Thinking through the explanation…
              </div>
            )}
            <div ref={endRef} />
          </div>

          <div className="border-t border-line p-3">
            <div className="flex items-end gap-2">
              <Textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); }
                }}
                placeholder={aiEnabled ? 'Ask a question, paste a problem, or name a chapter… (Enter to send)' : 'Configure the AI key to start teaching'}
                className="min-h-[56px] max-h-40 py-3"
                rows={2}
                disabled={!aiEnabled}
              />
              <Button onClick={() => void send()} loading={sending} disabled={!draft.trim() || !aiEnabled} className="h-[56px] px-4">
                <Send size={17} />
              </Button>
            </div>
            <p className="mt-1.5 text-[10px] text-muted">
              {mode === 'beginner' ? 'Beginner mode builds from first principles.' : mode === 'exam' ? 'Exam mode focuses on marks, patterns and examiner wording.' : 'Advanced mode assumes fundamentals and goes deeper.'}
              {' '}AI can make mistakes — verify important formulas with your textbook.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
