/** AboutPage.js — About the Developer. Photo, story, motto and contact links are editable and stay on-device. */
import { el, card, button, sectionHeader, textareaInput, textInput, fieldLabel } from '../components/ui.js';
import { getProfile, updateProfile, pickImage } from '../core/profile/profileService.js';
import { showToast } from '../core/notifications/toast.js';
import { navigate } from '../core/router.js';
import { openSheet, closeSheet } from '../components/modal.js';
import { APP_VERSION } from './Settings.js';

const cleanPhone = (v) => String(v || '').replace(/[^\d]/g, '');
function contactLinks(c = {}) {
  const out = [];
  if (cleanPhone(c.whatsapp)) out.push({ icon: '💬', label: 'WhatsApp', href: `https://wa.me/${cleanPhone(c.whatsapp)}` });
  if ((c.email || '').includes('@')) out.push({ icon: '✉️', label: 'Email', href: `mailto:${c.email.trim()}` });
  if (c.facebook) out.push({ icon: '📘', label: 'Facebook', href: /^https?:/.test(c.facebook) ? c.facebook : `https://${c.facebook}` });
  if (c.instagram) out.push({ icon: '📸', label: 'Instagram', href: /^https?:/.test(c.instagram) ? c.instagram : `https://instagram.com/${c.instagram.replace('@', '')}` });
  return out;
}

export async function AboutPage(root) {
  const profile = await getProfile();
  const redraw = async () => { root.innerHTML = ''; await AboutPage(root); };

  const avatar = profile.photo
    ? Object.assign(el('img', 'about-avatar'), { src: profile.photo, alt: 'Developer photo' })
    : el('div', 'about-avatar about-avatar--initial', (profile.name || 'A').slice(0, 1).toUpperCase());

  const page = el('div', 'page');
  page.append(button('← Back', { variant: 'ghost', size: 'sm', onClick: () => navigate('/settings') }));
  page.append(el('h1', 'page-title mt-3', 'About the developer'));

  const hero = card([
    el('div', 'about-hero', [
      avatar,
      el('h2', 'about-name', profile.name || 'Abbas'),
      el('p', 'about-role', 'Medical Student · App Developer · Mentor'),
      el('p', 'about-bio', profile.bio),
      el('div', 'chip-row about-chips', ['AH Creative Solutions', 'MedForge Academy', 'SMEA — Student Motivation & Edification Association', 'KASU, Kaduna'].map((t) => el('span', 'chip chip--static', t))),
    ]),
    el('div', 'mt-4 flex gap-3', [
      button('📷 Change photo', { variant: 'ghost', onClick: async () => { const p = await pickImage(520); if (p) { await updateProfile({ photo: p }); showToast('Photo updated.'); await redraw(); } } }),
      button('✎ Edit my story', { variant: 'ghost', onClick: () => openEdit(profile, redraw) }),
    ]),
  ]);
  hero.classList.add('card--glass');
  page.append(hero);

  page.append(sectionHeader(null, 'Why I built Life Guide'));
  page.append(card([el('p', 'about-why', profile.why)]));

  if (profile.motto) {
    page.append(card([el('p', 'about-motto', `“${profile.motto}”`), el('p', 'text-dim text-xs', '— my rule for staying consistent')]));
  }

  const links = contactLinks(profile.contacts);
  if (links.length) {
    page.append(sectionHeader(null, 'Get in touch'));
    page.append(card([el('div', 'chip-row', links.map((l) => {
      const a = el('a', 'chip about-link', `${l.icon} ${l.label}`);
      a.href = l.href; a.target = '_blank'; a.rel = 'noopener noreferrer';
      return a;
    }))]));
  }

  page.append(sectionHeader(null, 'About this app'));
  page.append(card([
    el('p', 'text-dim text-xs', 'Life Guide is private and offline-first. Everything you enter is stored only on this device — no accounts, no servers, no tracking. Back up from Settings to keep your progress safe.'),
    el('p', 'text-dim text-xs mt-3', `Version ${APP_VERSION} · Built by AH Creative Solutions. May Allah make your effort consistent and your intentions sincere. 🤲`),
  ]));
  root.appendChild(page);
}

function openEdit(profile, done) {
  openSheet('Edit my story', (body) => {
    const c = profile.contacts || {};
    const bio = textareaInput({ value: profile.bio, rows: 3 });
    const why = textareaInput({ value: profile.why, rows: 4 });
    const motto = textInput({ value: profile.motto || '', placeholder: 'Your motto' });
    const wa = textInput({ value: c.whatsapp || '', placeholder: 'WhatsApp number with country code, e.g. 23480…' });
    const em = textInput({ value: c.email || '', placeholder: 'Email' });
    const fb = textInput({ value: c.facebook || '', placeholder: 'Facebook link' });
    const ig = textInput({ value: c.instagram || '', placeholder: 'Instagram @name' });
    body.append(
      el('div', 'field', [fieldLabel('Short bio'), bio]),
      el('div', 'field', [fieldLabel('Why I built this'), why]),
      el('div', 'field', [fieldLabel('My motto'), motto]),
      el('p', 'text-xs text-dim', 'Contact links are optional. They show only if you fill them in, and they stay on this phone.'),
      el('div', 'field', [fieldLabel('WhatsApp'), wa]), el('div', 'field', [fieldLabel('Email'), em]),
      el('div', 'field', [fieldLabel('Facebook'), fb]), el('div', 'field', [fieldLabel('Instagram'), ig]),
      el('div', 'bottom-sheet__footer', [button('Save', { block: true, onClick: async () => {
        await updateProfile({ bio: bio.value.trim(), why: why.value.trim(), motto: motto.value.trim(), contacts: { whatsapp: wa.value.trim(), email: em.value.trim(), facebook: fb.value.trim(), instagram: ig.value.trim() } });
        closeSheet(); showToast('Saved.'); await done();
      } })]),
    );
  });
}
