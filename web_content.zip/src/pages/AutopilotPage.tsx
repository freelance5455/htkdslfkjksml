// ============================================================
// AI CREATOR STUDIO — CORE 3.0 AUTOPILOT PAGE
// Complete AI Autopilot & Content Intelligence Hub
// ============================================================

import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import AIAutopilotCommandCenter from "@/components/features/AIAutopilotCommandCenter";
import WorkflowMonitorView from "@/components/features/WorkflowMonitorView";
import StrategyPlannerView from "@/components/features/StrategyPlannerView";
import SeriesManagerView from "@/components/features/SeriesManagerView";
import PerformanceLearningsView from "@/components/features/PerformanceLearningsView";
import DailyBriefModal from "@/components/features/DailyBriefModal";
import BudgetSafetyModal from "@/components/features/BudgetSafetyModal";
import CreatorMemoryModal from "@/components/features/CreatorMemoryModal";
import NotificationCenterModal from "@/components/features/NotificationCenterModal";
import QualityScorerModal from "@/components/features/QualityScorerModal";
import HookOptimizerModal from "@/components/features/HookOptimizerModal";
import { useProjects } from "@/hooks/useProjects";
import { generateStrategicRecommendations } from "@/lib/core3/recommendationEngine";
import {
  Cpu, Sparkles, Layers, Target, Film, BrainCircuit,
  DollarSign, Brain, Bell, Award, Zap, CheckCircle2,
  ArrowRight, ShieldCheck
} from "lucide-react";
import { cn } from "@/lib/utils";

type AutopilotTab = "COMMAND" | "WORKFLOWS" | "STRATEGY" | "SERIES" | "LEARNINGS" | "RECOMMENDATIONS";

export default function AutopilotPage() {
  const [activeTab, setActiveTab] = useState<AutopilotTab>("COMMAND");
  const { projects } = useProjects();

  // Modals state
  const [showDailyBrief, setShowDailyBrief] = useState(false);
  const [showBudget, setShowBudget] = useState(false);
  const [showMemory, setShowMemory] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showQualityScorer, setShowQualityScorer] = useState(false);
  const [showHookOptimizer, setShowHookOptimizer] = useState(false);

  const recommendations = generateStrategicRecommendations();
  const activeProject = projects[0];

  return (
    <AppLayout
      title="AI Autopilot & Inteligência"
      subtitle="Automação ponta a ponta com supervisão humana e aprendizado contínuo (CORE 3.0)"
    >
      <div className="p-6 space-y-6 max-w-7xl">
        {/* Navigation Tabs Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-studio-border pb-3">
          <div className="flex flex-wrap items-center gap-1.5 bg-studio-panel border border-studio-border p-1 rounded-xl">
            <button
              onClick={() => setActiveTab("COMMAND")}
              className={cn(
                "px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all",
                activeTab === "COMMAND"
                  ? "bg-studio-blue text-white shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              <Cpu className="w-4 h-4" />
              Command Center
            </button>

            <button
              onClick={() => setActiveTab("WORKFLOWS")}
              className={cn(
                "px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all",
                activeTab === "WORKFLOWS"
                  ? "bg-studio-blue text-white shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              <Layers className="w-4 h-4" />
              Pipelines Automatizados
            </button>

            <button
              onClick={() => setActiveTab("STRATEGY")}
              className={cn(
                "px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all",
                activeTab === "STRATEGY"
                  ? "bg-studio-blue text-white shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              <Target className="w-4 h-4" />
              Estratégia & Metas
            </button>

            <button
              onClick={() => setActiveTab("SERIES")}
              className={cn(
                "px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all",
                activeTab === "SERIES"
                  ? "bg-studio-blue text-white shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              <Film className="w-4 h-4" />
              Séries Narrativas
            </button>

            <button
              onClick={() => setActiveTab("LEARNINGS")}
              className={cn(
                "px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all",
                activeTab === "LEARNINGS"
                  ? "bg-studio-blue text-white shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              <BrainCircuit className="w-4 h-4" />
              Performance Learning
            </button>

            <button
              onClick={() => setActiveTab("RECOMMENDATIONS")}
              className={cn(
                "px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all",
                activeTab === "RECOMMENDATIONS"
                  ? "bg-studio-blue text-white shadow-xs"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
              )}
            >
              <Sparkles className="w-4 h-4 text-studio-gold" />
              Ações Estratégicas ({recommendations.length})
            </button>
          </div>

          {/* Quick Tools Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowDailyBrief(true)}
              className="btn-secondary text-xs py-2 px-3 gap-1.5"
            >
              <span>📋 Daily Brief</span>
            </button>

            <button
              onClick={() => setShowQualityScorer(true)}
              disabled={!activeProject}
              className="btn-secondary text-xs py-2 px-3 gap-1.5"
              title="Auditar qualidade do projeto ativo"
            >
              <Award className="w-3.5 h-3.5 text-studio-gold" />
              <span>Score Qualidade</span>
            </button>

            <button
              onClick={() => setShowHookOptimizer(true)}
              disabled={!activeProject}
              className="btn-secondary text-xs py-2 px-3 gap-1.5"
              title="Otimizar abertura e gancho"
            >
              <Zap className="w-3.5 h-3.5 text-studio-purple" />
              <span>Hook Optimizer</span>
            </button>
          </div>
        </div>

        {/* Tab Content Display */}
        {activeTab === "COMMAND" && (
          <AIAutopilotCommandCenter
            onOpenDailyBrief={() => setShowDailyBrief(true)}
            onOpenBudget={() => setShowBudget(true)}
            onOpenMemory={() => setShowMemory(true)}
            onOpenStrategy={() => setActiveTab("STRATEGY")}
          />
        )}

        {activeTab === "WORKFLOWS" && <WorkflowMonitorView />}

        {activeTab === "STRATEGY" && <StrategyPlannerView />}

        {activeTab === "SERIES" && <SeriesManagerView />}

        {activeTab === "LEARNINGS" && <PerformanceLearningsView />}

        {activeTab === "RECOMMENDATIONS" && (
          <div className="space-y-4">
            <div className="studio-card p-5 space-y-1">
              <h3 className="text-base font-bold text-studio-text font-display flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-studio-gold" />
                Recomendações Priorizadas de Alto Impacto
              </h3>
              <p className="text-xs text-studio-text-muted">
                Classificadas rigorosamente por Impacto, Nível de Confiança Estatística (%) e Esforço.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.map((rec) => (
                <div
                  key={rec.id}
                  className="studio-card p-5 border border-studio-border space-y-3 hover:border-studio-blue/30 transition-all flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={cn(
                        "text-[10px] uppercase font-bold px-2 py-0.5 rounded-full font-mono",
                        rec.impact === "HIGH" ? "bg-studio-green/20 text-studio-green" : "bg-studio-blue/20 text-studio-blue"
                      )}>
                        Impacto: {rec.impact}
                      </span>
                      <span className="text-xs font-mono font-bold text-teal-400">
                        Confiança: {rec.confidencePercent}%
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-studio-text">{rec.title}</h4>
                    <p className="text-xs text-studio-text-muted leading-relaxed">{rec.description}</p>
                  </div>

                  <div className="pt-3 border-t border-studio-border/60 flex items-center justify-between">
                    <span className="text-[11px] text-studio-text-muted">Esforço: <strong className="text-studio-text">{rec.effort}</strong></span>
                    <button
                      onClick={() => setActiveTab("COMMAND")}
                      className="btn-primary text-xs py-1.5 px-3 gap-1"
                    >
                      <span>Executar com Autopilot</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <DailyBriefModal
        isOpen={showDailyBrief}
        onClose={() => setShowDailyBrief(false)}
        onSelectAction={() => setActiveTab("COMMAND")}
      />

      <BudgetSafetyModal
        isOpen={showBudget}
        onClose={() => setShowBudget(false)}
      />

      <CreatorMemoryModal
        isOpen={showMemory}
        onClose={() => setShowMemory(false)}
      />

      <NotificationCenterModal
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />

      {activeProject && (
        <>
          <QualityScorerModal
            isOpen={showQualityScorer}
            onClose={() => setShowQualityScorer(false)}
            project={activeProject}
            onOptimizeHook={() => setShowHookOptimizer(true)}
          />

          <HookOptimizerModal
            isOpen={showHookOptimizer}
            onClose={() => setShowHookOptimizer(false)}
            project={activeProject}
          />
        </>
      )}
    </AppLayout>
  );
}
