import { useMemo, useState } from 'react';
import { Award, Check, Gift, Sparkles, Trophy } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { Badge } from '../components/ui/Feedback';
import { Chip, ProgressBar, SectionHeader } from '../components/ui/Card';
import { achievementSummary, claimAchievement, getAchievements } from '../services/gamification';
import { EMPTY_WALLET } from '../services/economy';
import { EMPTY_FARM } from '../services/farmModel';
import { KEYS, useStored } from '../services/storage';

function dateLabel(value?: number): string | undefined {
  return value ? new Intl.DateTimeFormat('ar-SY', { dateStyle: 'medium' }).format(new Date(value)) : undefined;
}

export default function Achievements() {
  const [category, setCategory] = useState('all');
  const [notice, setNotice] = useState('');
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  const stats = useStored(KEYS.stats, { days: {} });
  const progress = useStored(KEYS.progress, {});
  const quizzes = useStored(KEYS.quizzes, []);
  const cards = useStored(KEYS.cards, {});
  const farm = useStored(KEYS.farm, EMPTY_FARM);
  const practiceAttempts = useStored(KEYS.practiceAttempts, []);
  const writtenAnswers = useStored(KEYS.writtenAnswers, []);
  const achievements = useMemo(() => getAchievements(), [wallet, stats, progress, quizzes, cards, farm, practiceAttempts, writtenAnswers]);
  const summary = useMemo(() => achievementSummary(), [wallet, stats, progress, quizzes, cards, farm, practiceAttempts, writtenAnswers]);
  const categories = useMemo(() => [...new Set(achievements.map((item) => item.category))], [achievements]);
  const visible = category === 'all' ? achievements : achievements.filter((item) => item.category === category);

  const claim = async (id: string) => {
    const ok = await claimAchievement(id);
    setNotice(ok ? 'أُضيفت مكافأة الإنجاز إلى رصيدك.' : 'هذه المكافأة مستلمة مسبقاً أو لم يكتمل شرطها.');
  };

  return (
    <div>
      <PageHeader eyebrow="كل إنجاز خطوة نحو هدفك" title="إنجازاتي" subtitle={`${summary.total} إنجازاً موزعة بين الدراسة والاستمرارية والمواد والأسئلة التحريرية والمزرعة.`} />
      <div className="mb-4 flex items-center gap-3 rounded-3xl bg-[linear-gradient(125deg,#0b2a3f,#144760)] p-4 text-white">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-[var(--gold)]"><Trophy size={21} /></span>
        <div className="flex-1"><p className="text-xs text-white/65">الإنجازات المفتوحة</p><p className="font-display text-2xl">{summary.unlocked} <span className="text-sm text-white/65">من {summary.total}</span></p></div>
        <p className="text-end text-xs text-white/65">استلمت<br /><strong className="text-sm text-white">{summary.claimed}</strong></p>
      </div>
      <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4"><Chip active={category === 'all'} onClick={() => setCategory('all')}>الكل ({achievements.length})</Chip>{categories.map((item) => <Chip key={item} active={category === item} onClick={() => setCategory(item)}>{item}</Chip>)}</div>
      {notice ? <p role="status" className="mb-3 rounded-2xl bg-[var(--gold-soft)] px-3 py-2 text-xs text-[var(--ink)]">{notice}</p> : null}
      <SectionHeader title="مسارك" hint="كل مكافأة تُضاف مرة واحدة فقط" />
      <div className="space-y-2">
        {visible.map((item) => (
          <article key={item.id} className="card flex items-start gap-3 p-3.5">
            <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${item.unlocked ? 'bg-[var(--gold-soft)] text-[var(--gold)]' : 'bg-[var(--surface-2)] text-[var(--ink-soft)]'}`}>{item.claimed ? <Check size={18} /> : item.unlocked ? <Award size={18} /> : <Sparkles size={18} />}</span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2"><h2 className="text-sm font-semibold text-[var(--ink)]">{item.title}</h2>{item.claimed ? <Badge tone="success">استُلمت</Badge> : item.unlocked ? <Badge tone="gold">مكتسب</Badge> : <Badge tone="neutral">{item.category}</Badge>}</div>
              <p className="mt-0.5 text-xs text-[var(--ink-soft)]">{item.description}</p>
              {item.unlockedAt ? <p className="mt-1 text-[0.62rem] text-[var(--ink-soft)]">سُجّل الإنجاز: {dateLabel(item.unlockedAt)}{item.claimedAt ? ` · استُلمت المكافأة: ${dateLabel(item.claimedAt)}` : ''}</p> : null}
              <div className="mt-2 flex items-center justify-between text-[0.65rem] text-[var(--ink-soft)]"><span>{item.progress} / {item.goal}</span><span className="flex items-center gap-1 text-[var(--gold)]"><Gift size={12} />{item.reward} نقطة</span></div>
              <ProgressBar value={(item.progress / item.goal) * 100} className="mt-1" height={5} />
              {item.unlocked && !item.claimed ? <button type="button" onClick={() => claim(item.id)} className="focus-ring mt-2 min-h-9 rounded-full bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)]">استلم مكافأتي</button> : null}
            </div>
          </article>
        ))}
      </div>
      <Link to="/challenges" className="focus-ring mt-5 flex min-h-12 items-center justify-center gap-2 rounded-2xl border border-[var(--line)] text-sm text-[var(--ink)]"><Trophy size={16} /> اعرض تحدياتك</Link>
    </div>
  );
}
