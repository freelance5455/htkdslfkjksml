import { useState, useEffect, useRef } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { useProjects } from "@/hooks/useProjects";
import { cn } from "@/lib/utils";
import type { MediaType, MediaAsset } from "@/types";
import {
  Image, Video, Music, Mic, Zap, Film, FileText, Layout,
  Library, Play, Download, X, Sparkles, Clock, Eye, HardDrive,
  Upload, Trash2, RefreshCw, CheckCircle2, AlertCircle
} from "lucide-react";

const MEDIA_TABS: { type: MediaType | "ALL"; label: string; icon: React.ElementType }[] = [
  { type: "ALL", label: "Todos", icon: Library },
  { type: "VIDEO", label: "Vídeos", icon: Video },
  { type: "IMAGE", label: "Imagens", icon: Image },
  { type: "VOICE", label: "Narrações", icon: Mic },
  { type: "MUSIC", label: "Músicas", icon: Music },
  { type: "SFX", label: "Efeitos", icon: Zap },
  { type: "THUMBNAIL", label: "Thumbnails", icon: Film },
  { type: "SUBTITLE", label: "Legendas", icon: FileText },
  { type: "RENDER", label: "Renders", icon: Layout },
];

interface StorageStats {
  totalFiles: number;
  totalSizeBytes: number;
  formattedSize: string;
  typeDistribution: Record<string, number>;
  databaseRegisteredAssets: number;
}

export default function LibraryPage() {
  const { projects } = useProjects();
  const [activeType, setActiveType] = useState<MediaType | "ALL">("ALL");
  const [previewAsset, setPreviewAsset] = useState<MediaAsset | null>(null);
  const [storageAssets, setStorageAssets] = useState<MediaAsset[]>([]);
  const [storageStats, setStorageStats] = useState<StorageStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Fetch real storage assets and stats
  const fetchStorageData = async () => {
    try {
      setLoading(true);
      const [assetsRes, statsRes] = await Promise.all([
        fetch("/api/storage/assets"),
        fetch("/api/storage/stats"),
      ]);
      const assetsData = await assetsRes.json();
      const statsData = await statsRes.json();

      if (assetsData.success && Array.isArray(assetsData.data)) {
        // Map storage assets to MediaAsset shape
        const mapped = assetsData.data.map((a: Record<string, unknown>) => ({
          id: String(a.id),
          name: String(a.name || "Arquivo de Mídia"),
          type: (a.type as MediaType) || "IMAGE",
          url: String(a.url || `/api/storage/files/${a.name}`),
          storagePath: a.storagePath as string | undefined,
          size: a.size as number | undefined,
          provider: "Durable Cloud Storage",
          createdAt: String(a.createdAt || new Date().toISOString()),
          status: "COMPLETED" as const,
        }));
        setStorageAssets(mapped);
      }

      if (statsData.success) {
        setStorageStats(statsData);
      }
    } catch (err) {
      console.error("[LibraryPage] Error fetching storage data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStorageData();
  }, []);

  // Combine project assets and storage assets, avoiding duplicates by id or url
  const projectAssets = projects.flatMap((p) =>
    p.assets.map((a) => ({ ...a, projectTitle: p.title, projectId: p.id }))
  );

  const combinedAssetsMap = new Map<string, MediaAsset>();
  for (const a of projectAssets) {
    combinedAssetsMap.set(a.id, a);
  }
  for (const a of storageAssets) {
    if (!combinedAssetsMap.has(a.id)) {
      combinedAssetsMap.set(a.id, a);
    }
  }

  const allAssets = Array.from(combinedAssetsMap.values());
  const filtered = activeType === "ALL" ? allAssets : allAssets.filter((a) => a.type === activeType);

  const typeIcon: Record<string, React.ElementType> = {
    IMAGE: Image, VIDEO: Video, VOICE: Mic, MUSIC: Music,
    SFX: Zap, THUMBNAIL: Film, SUBTITLE: FileText, RENDER: Layout,
  };

  const typeColor: Record<string, string> = {
    IMAGE: "text-studio-blue bg-studio-blue/10",
    VIDEO: "text-studio-purple bg-studio-purple/10",
    VOICE: "text-studio-green bg-studio-green/10",
    MUSIC: "text-studio-gold bg-studio-gold/10",
    SFX: "text-studio-orange bg-studio-orange/10",
    THUMBNAIL: "text-studio-pink bg-studio-pink/10",
    SUBTITLE: "text-studio-text-dim bg-studio-border",
    RENDER: "text-studio-blue bg-studio-blue/20",
  };

  // Upload handler (converts file to base64 and posts to /api/storage/upload)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;

        let detectedType: MediaType = "IMAGE";
        if (file.type.startsWith("video/")) detectedType = "VIDEO";
        else if (file.type.startsWith("audio/")) detectedType = "VOICE";

        const res = await fetch("/api/storage/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            filename: file.name,
            mimeType: file.type,
            dataBase64: base64Data,
            type: detectedType,
          }),
        });

        const data = await res.json();
        if (data.success) {
          await fetchStorageData();
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error("Erro no upload de arquivo:", err);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Delete Asset
  const handleDeleteAsset = async (assetId: string) => {
    try {
      const res = await fetch(`/api/storage/assets/${assetId}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setStorageAssets((prev) => prev.filter((a) => a.id !== assetId));
        if (previewAsset?.id === assetId) {
          setPreviewAsset(null);
        }
        await fetchStorageData();
      }
    } catch (err) {
      console.error("Erro ao deletar asset:", err);
    } finally {
      setDeleteConfirmId(null);
    }
  };

  return (
    <AppLayout title="Biblioteca de Mídia & Cloud Storage" subtitle="Repositório durável de assets locais e streaming HTTP 206">
      <div className="p-6 space-y-6 max-w-6xl">

        {/* Cloud Storage Status Banner */}
        <div className="studio-card p-5 border border-studio-border bg-gradient-to-r from-studio-surface via-studio-panel to-studio-surface">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-studio-panel border border-studio-border flex items-center justify-center text-studio-gold">
                <HardDrive className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-studio-text">Armazenamento Local & Cloud Storage</h3>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    HTTP 206 Partial Content Ativo
                  </span>
                </div>
                <p className="text-xs text-studio-text-muted mt-0.5">
                  {storageStats
                    ? `${storageStats.totalFiles} arquivos físicos salvos (${storageStats.formattedSize}) · ${allAssets.length} assets catalogados`
                    : "Carregando métricas de armazenamento..."}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                accept="image/*,video/*,audio/*"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="btn-gold text-xs py-2 px-3.5 flex items-center gap-1.5 font-bold"
              >
                <Upload className="w-3.5 h-3.5" />
                {uploading ? "Enviando..." : "Upload para Storage"}
              </button>

              <button
                onClick={fetchStorageData}
                disabled={loading}
                className="p-2 rounded-lg border border-studio-border text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-colors"
                title="Atualizar dados"
              >
                <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
              </button>
            </div>
          </div>
        </div>

        {/* Type tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {MEDIA_TABS.map((tab) => (
            <button
              key={tab.type}
              onClick={() => setActiveType(tab.type)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all shrink-0",
                activeType === tab.type
                  ? "bg-studio-blue/10 text-studio-blue border border-studio-blue/20 font-bold"
                  : "text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
              )}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
              {tab.type !== "ALL" && (
                <span className="bg-studio-border text-studio-text-muted px-1.5 rounded text-[10px] font-semibold">
                  {allAssets.filter((a) => a.type === tab.type).length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Assets Grid */}
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 studio-card text-center">
            <Library className="w-12 h-12 text-studio-text-muted mb-4 opacity-50" />
            <h3 className="text-base font-semibold text-studio-text font-display mb-2">Biblioteca vazia</h3>
            <p className="text-sm text-studio-text-muted mb-4">
              Faça upload de mídias ou gere conteúdos através dos motores de IA
            </p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="btn-gold text-xs py-2 px-4 inline-flex items-center gap-1.5 font-bold"
            >
              <Upload className="w-3.5 h-3.5" />
              Fazer Upload de Mídia
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {filtered.map((asset) => {
              const Icon = typeIcon[asset.type] ?? Library;
              const isVideo = asset.type === "VIDEO" || asset.type === "RENDER";
              const isAudio = asset.type === "VOICE" || asset.type === "MUSIC" || asset.type === "SFX";

              return (
                <div
                  key={asset.id}
                  onClick={() => setPreviewAsset(asset)}
                  className="studio-card p-3 group hover:border-studio-blue/40 transition-all cursor-pointer flex flex-col justify-between relative"
                >
                  {/* Preview Media Box */}
                  <div className="w-full aspect-video rounded-lg bg-studio-panel mb-2.5 flex items-center justify-center overflow-hidden relative group">
                    {asset.thumbnailUrl || (asset.url && !isVideo && !isAudio) ? (
                      <img
                        src={asset.thumbnailUrl || asset.url}
                        alt={asset.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          // fallback if direct image fails
                          (e.currentTarget as HTMLImageElement).style.display = "none";
                        }}
                      />
                    ) : (
                      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", typeColor[asset.type])}>
                        <Icon className="w-5 h-5" />
                      </div>
                    )}

                    {isVideo && (
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center group-hover:bg-black/10 transition-colors">
                        <div className="w-7 h-7 rounded-full bg-studio-blue text-white flex items-center justify-center shadow-md">
                          <Play className="w-3.5 h-3.5 ml-0.5" />
                        </div>
                      </div>
                    )}

                    {isAudio && (
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                        <div className="w-7 h-7 rounded-full bg-studio-gold text-black flex items-center justify-center shadow-md">
                          <Mic className="w-3.5 h-3.5" />
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <p className="text-xs font-semibold text-studio-text line-clamp-1 mb-1">{asset.name}</p>
                    <div className="flex items-center justify-between">
                      <span className={cn("task-badge text-[10px]", typeColor[asset.type])}>
                        {asset.type}
                      </span>
                      {asset.provider && (
                        <span className="text-[10px] text-studio-text-muted font-medium truncate max-w-[80px]">
                          {asset.provider}
                        </span>
                      )}
                    </div>
                    {asset.projectTitle && (
                      <p className="text-[11px] text-studio-text-muted mt-1.5 truncate">{asset.projectTitle}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Asset Preview & Media Streaming Modal (Range requests enabled) */}
      {previewAsset && (
        <div
          onClick={() => setPreviewAsset(null)}
          className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-studio-surface border border-studio-border rounded-2xl max-w-2xl w-full p-5 space-y-4 shadow-2xl relative"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-studio-border pb-3">
              <div>
                <h3 className="text-sm font-bold text-studio-text">{previewAsset.name}</h3>
                <p className="text-xs text-studio-text-muted">
                  {previewAsset.projectTitle ? `Projeto: ${previewAsset.projectTitle}` : "Cloud Storage Asset"}
                </p>
              </div>
              <button
                onClick={() => setPreviewAsset(null)}
                className="p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-panel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Media Player / Viewer */}
            <div className="w-full aspect-video rounded-xl bg-black overflow-hidden flex items-center justify-center">
              {previewAsset.type === "VIDEO" || previewAsset.type === "RENDER" ? (
                <video
                  src={previewAsset.url}
                  poster={previewAsset.thumbnailUrl}
                  controls
                  autoPlay
                  className="w-full h-full object-contain"
                />
              ) : previewAsset.type === "VOICE" || previewAsset.type === "MUSIC" || previewAsset.type === "SFX" ? (
                <div className="flex flex-col items-center justify-center p-6 w-full space-y-4">
                  <div className="w-16 h-16 rounded-full bg-studio-gold/20 text-studio-gold flex items-center justify-center">
                    <Music className="w-8 h-8" />
                  </div>
                  <audio controls src={previewAsset.url} autoPlay className="w-full max-w-md" />
                </div>
              ) : previewAsset.url ? (
                <img
                  src={previewAsset.url}
                  alt={previewAsset.name}
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-studio-text-muted text-xs">Pré-visualização não disponível</div>
              )}
            </div>

            {/* Metadata info */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-studio-panel border border-studio-border">
                <span className="text-studio-text-muted block text-[10px]">Tipo</span>
                <span className="font-semibold text-studio-text">{previewAsset.type}</span>
              </div>
              <div className="p-2 rounded-lg bg-studio-panel border border-studio-border">
                <span className="text-studio-text-muted block text-[10px]">Motor / Provedor</span>
                <span className="font-semibold text-studio-text">{previewAsset.provider || "AI Studio Storage"}</span>
              </div>
              <div className="p-2 rounded-lg bg-studio-panel border border-studio-border">
                <span className="text-studio-text-muted block text-[10px]">Duração</span>
                <span className="font-semibold text-studio-text">{previewAsset.duration ? `${previewAsset.duration}s` : "—"}</span>
              </div>
              <div className="p-2 rounded-lg bg-studio-panel border border-studio-border">
                <span className="text-studio-text-muted block text-[10px]">Status</span>
                <span className="font-semibold text-studio-green">Disponível no Storage</span>
              </div>
            </div>

            {previewAsset.prompt && (
              <div className="p-3 rounded-lg bg-studio-panel border border-studio-border text-xs space-y-1">
                <span className="text-studio-text-muted font-semibold block text-[10px] uppercase">
                  Prompt Usado:
                </span>
                <p className="text-studio-text leading-relaxed">{previewAsset.prompt}</p>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-between pt-1 border-t border-studio-border">
              {deleteConfirmId === previewAsset.id ? (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-red-400 font-semibold">Excluir este asset?</span>
                  <button
                    onClick={() => handleDeleteAsset(previewAsset.id)}
                    className="btn text-xs py-1 px-2.5 bg-red-500 text-white font-bold"
                  >
                    Confirmar
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(null)}
                    className="btn text-xs py-1 px-2 border border-studio-border text-studio-text-muted"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setDeleteConfirmId(previewAsset.id)}
                  className="btn text-xs py-1.5 px-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Excluir</span>
                </button>
              )}

              <div className="flex items-center gap-2">
                {previewAsset.url && (
                  <a
                    href={previewAsset.url.includes("?") ? `${previewAsset.url}&download=true` : `${previewAsset.url}?download=true`}
                    download={previewAsset.name}
                    className="btn-primary text-xs py-2 px-4 flex items-center gap-1.5 font-bold"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Baixar Arquivo</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AppLayout>
  );
}

