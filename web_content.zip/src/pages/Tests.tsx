import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ListChecks, Trophy, Sparkles, BookOpen } from 'lucide-react';
import { allQuizzes, subjects } from '../data/content';
import { attemptFor } from '../services/quiz';
import { useStored, KEYS } from '../services/storage';
import { PageHeader } from '../components/layout/PageHeader';
import { Chip } from '../components/ui/Card';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { SubjectGlyph } from '../components/content/SubjectBits';

export default function Tests() {
  const [filter, setFilter] = useState<string>('all');
  useStored(KEYS.quizzes, []);

  const quizzes = useMemo(() => allQuizzes(), []);
  const filtered = filter === 'all' ? quizzes : quizzes.filter((entry) => entry.subjectId === filter);
  const practiceCount = quizzes.filter((entry) => entry.kind === 'practice').length;

  return (
    <div>
      <PageHeader
        eyebrow="تصحيح فوري + شرح لكل إجابة"
        title="الاختبارات"
        subtitle={`اختبارات الدروس وبنك تدريب شامل للمواد الثماني. ${practiceCount} اختبارات تدريبية جديدة على موضوعات المنهاج.`}
      />

      <div className="card mb-4 flex items-start gap-3 bg-[var(--surface)] p-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[var(--gold)]"><Sparkles size={18} /></span>
        <div>
          <p className="text-sm font-semibold text-[var(--ink)]">بنك تدريبي شامل</p>
          <p className="text-xs leading-relaxed text-[var(--ink-soft)]">٨ اختبارات، ١٠ أسئلة لكل مادة. أسئلة تدريبية مرتبطة بموضوعات المحتوى الحالي، وليست أوراقاً وزارية رسمية.</p>
        </div>
      </div>

      <Link to="/question-bank" className="focus-ring card mb-4 flex min-h-16 items-center gap-3 p-4">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[var(--gold)]"><BookOpen size={18} /></span>
        <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-[var(--ink)]">افتح بنك أسئلة المنهاج</span><span className="mt-0.5 block text-xs text-[var(--ink-soft)]">اختر المادة والوحدة، وتدرّب على الأسئلة الموضوعية والتحريرية الموثّقة.</span></span>
        <ChevronLeft size={16} className="shrink-0 text-[var(--ink-soft)]" />
      </Link>

      <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
        <Chip active={filter === 'all'} onClick={() => setFilter('all')}>الكل ({quizzes.length})</Chip>
        {subjects.map((subject) => {
          const count = quizzes.filter((entry) => entry.subjectId === subject.id).length;
          return <Chip key={subject.id} active={filter === subject.id} onClick={() => setFilter(subject.id)}>{subject.shortName} ({count})</Chip>;
        })}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={<ListChecks size={18} />} title="لا اختبارات في هذه المادة بعد" description="سيظهر هنا كل اختبار مرتبط بالمادة." />
      ) : (
        <div className="space-y-2">
          {filtered.map((entry) => {
            const subject = subjects.find((item) => item.id === entry.subjectId);
            const attempt = attemptFor(entry.quiz.id);
            const percent = attempt && attempt.total > 0 ? Math.round((attempt.score / attempt.total) * 100) : null;
            return (
              <Link key={entry.quiz.id} to={`/tests/${entry.quiz.id}`} className="focus-ring card flex items-center gap-3 p-3.5">
                {subject ? <SubjectGlyph subject={subject} size="sm" /> : null}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.85rem] font-medium text-[var(--ink)]">{entry.quiz.title}</p>
                  <p className="mt-0.5 truncate text-[0.66rem] text-[var(--ink-soft)]">{entry.lessonTitle} · {entry.quiz.questions.length} أسئلة</p>
                  {entry.kind === 'practice' ? <Badge tone="gold"><Sparkles size={10} /> تدريب شامل</Badge> : null}
                  {percent !== null ? <div className="mt-1"><Badge tone={percent >= 80 ? 'success' : percent >= 50 ? 'gold' : 'danger'}><Trophy size={10} /> أفضل نتيجة {percent}%</Badge></div> : null}
                </div>
                <ChevronLeft size={16} className="shrink-0 text-[var(--ink-soft)]" />
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
