import React from 'react';
import { CalsenBase } from '../lib/CalsenBase';
import { go, ROUTES } from '../lib/calsen';
import BottomNav from '../components/BottomNav';
import { getCurrentLang } from '../lib/i18n';

const CHART_W = 312;
const CHART_H = 130;

export default class TrendsPage extends CalsenBase {
  static defaultProps = { accent: '#FF5C00', theme: 'sync' };

  fileInputRef = null;
  _langListener = null;

  state = {
    tab: 0, // 0: Weight, 1: Energy use
    range: 0, // 0: 30D, 1: 90D, 2: 6M, 3: All
    wk: 0, // 0: This week, 1: Last week, 2: 2 weeks ago, 3: 3 weeks ago
    showWeighInModal: false,
    newWeightInput: '',
    newWeightDate: new Date().toISOString().slice(0, 10),
    newWeightNote: '',
    selectedDayIndex: null,
    previewPhoto: null,
    showNotifModal: false,
    toastMsg: '',
    unreadNotifs: 2,
    lang: getCurrentLang(),
    weighIns: [],
    photos: [],
  };

  componentDidMount() {
    this._langListener = (e) => {
      this.setState({ lang: e.detail || getCurrentLang() });
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('calsen-lang-change', this._langListener);
    }

    this.loadWeighIns();
    this.loadPhotos();
  }

  componentWillUnmount() {
    if (typeof window !== 'undefined' && this._langListener) {
      window.removeEventListener('calsen-lang-change', this._langListener);
    }
  }

  toast(msg) {
    this.setState({ toastMsg: msg });
    setTimeout(() => {
      this.setState({ toastMsg: '' });
    }, 2800);
  }

  loadWeighIns() {
    try {
      const stored = window.localStorage.getItem('calsen-weight-history');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.setState({ weighIns: parsed });
          return;
        }
      }
    } catch (e) {}

    // Seed realistic initial weigh-ins based on user's current weight
    let currentWeight = 72.0;
    try {
      const w = Number(window.localStorage.getItem('calsen-weight'));
      if (w > 0) currentWeight = w;
    } catch (e) {}

    const today = new Date();
    const seed = [
      {
        id: 'w-1',
        date: new Date(today.getTime() - 28 * 86400000).toISOString().slice(0, 10),
        weight: Number((currentWeight + 2.8).toFixed(1)),
        note: 'Starting weight',
      },
      {
        id: 'w-2',
        date: new Date(today.getTime() - 21 * 86400000).toISOString().slice(0, 10),
        weight: Number((currentWeight + 2.1).toFixed(1)),
        note: 'Week 1 check',
      },
      {
        id: 'w-3',
        date: new Date(today.getTime() - 14 * 86400000).toISOString().slice(0, 10),
        weight: Number((currentWeight + 1.3).toFixed(1)),
        note: 'Week 2 check',
      },
      {
        id: 'w-4',
        date: new Date(today.getTime() - 7 * 86400000).toISOString().slice(0, 10),
        weight: Number((currentWeight + 0.6).toFixed(1)),
        note: 'Week 3 check',
      },
      {
        id: 'w-5',
        date: today.toISOString().slice(0, 10),
        weight: currentWeight,
        note: 'Current weigh-in',
      },
    ];

    try {
      window.localStorage.setItem('calsen-weight-history', JSON.stringify(seed));
    } catch (e) {}
    this.setState({ weighIns: seed });
  }

  loadPhotos() {
    try {
      const stored = window.localStorage.getItem('calsen-progress-photos');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          this.setState({ photos: parsed });
        }
      }
    } catch (e) {}
  }

  saveWeighIn = () => {
    const val = parseFloat(this.state.newWeightInput);
    if (isNaN(val) || val <= 10 || val >= 350) {
      this.toast(
        this.state.lang === 'العربية'
          ? 'يرجى إدخال وزن صحيح بين 10 و 350'
          : 'Please enter a valid weight between 10 and 350'
      );
      return;
    }

    const newEntry = {
      id: 'w_' + Date.now(),
      date: this.state.newWeightDate || new Date().toISOString().slice(0, 10),
      weight: Number(val.toFixed(1)),
      note: this.state.newWeightNote.trim() || undefined,
    };

    const updated = [...this.state.weighIns, newEntry].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    try {
      window.localStorage.setItem('calsen-weight-history', JSON.stringify(updated));
      window.localStorage.setItem('calsen-weight', String(newEntry.weight));
    } catch (e) {}

    this.setState({
      weighIns: updated,
      showWeighInModal: false,
      newWeightInput: '',
      newWeightNote: '',
    });

    this.toast(
      this.state.lang === 'العربية'
        ? `تم تسجيل الوزن بنجاح (${newEntry.weight} كجم) ✨`
        : `Weigh-in recorded successfully (${newEntry.weight} kg) ✨`
    );
  };

  handlePhotoUpload = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    try {
      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        try {
          URL.revokeObjectURL(objectUrl);
        } catch (err) {}

        const canvas = document.createElement('canvas');
        const maxDim = 320;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', 0.7);
          const newPhoto = {
            id: 'photo_' + Date.now(),
            date: new Date().toISOString().slice(0, 10),
            url: compressed,
            note: this.state.lang === 'العربية' ? 'صورة تقدم جديدة' : 'Progress check',
          };
          const updated = [newPhoto, ...this.state.photos];
          try {
            window.localStorage.setItem('calsen-progress-photos', JSON.stringify(updated));
          } catch (err) {
            console.warn('LocalStorage save failed:', err);
          }
          this.setState({ photos: updated });
          this.toast(
            this.state.lang === 'العربية'
              ? 'تم حفظ صورة التقدم بنجاح 📸'
              : 'Progress photo saved! 📸'
          );
        }
      };
      img.onerror = () => {
        try {
          URL.revokeObjectURL(objectUrl);
        } catch (err) {}
        this.toast(
          this.state.lang === 'العربية' ? 'تعذر قراءة ملف الصورة' : 'Failed to read photo file'
        );
      };
      img.src = objectUrl;
    } catch (err) {
      this.toast(
        this.state.lang === 'العربية' ? 'حدث خطأ أثناء تحميل الصورة' : 'Error loading photo'
      );
    }
  };

  deletePhoto = (id) => {
    const updated = this.state.photos.filter((p) => p.id !== id);
    try {
      window.localStorage.setItem('calsen-progress-photos', JSON.stringify(updated));
    } catch (e) {}
    this.setState({ photos: updated, previewPhoto: null });
    this.toast(
      this.state.lang === 'العربية' ? 'تم حذف الصورة' : 'Photo deleted'
    );
  };

  renderVals() {
    const isAr = this.state.lang === 'العربية';
    const mode = this.modeNow();
    const dark = this.isDark(mode);
    const base = this.props.accent ?? '#FF5C00';
    const accent = this.accentFor(base, dark);
    const glow = this.glowOf(accent, dark ? 0.45 : 0.3);

    // Read user configuration
    let currentWeight = 72.0;
    let goalWeight = 65.0;
    let startWeight = 75.0;
    let height = 175;
    let targetCals = 2000;
    let units = 'metric';

    try {
      const w = Number(window.localStorage.getItem('calsen-weight'));
      if (w > 0) currentWeight = w;
      const gw = Number(window.localStorage.getItem('calsen-goal-weight'));
      if (gw > 0) goalWeight = gw;
      const ht = Number(window.localStorage.getItem('calsen-height'));
      if (ht > 0) height = ht;
      const tc = Number(window.localStorage.getItem('calsen-target-cals'));
      if (tc > 0) targetCals = tc;
      const u = window.localStorage.getItem('calsen-units');
      if (u) units = u;
    } catch (e) {}

    // Latest weigh-in
    if (this.state.weighIns.length > 0) {
      const latest = this.state.weighIns[this.state.weighIns.length - 1];
      currentWeight = latest.weight;
      if (this.state.weighIns.length > 1) {
        startWeight = this.state.weighIns[0].weight;
      }
    }

    const imp = units === 'imperial';
    const unitLabel = imp ? (isAr ? 'باوند' : 'lb') : (isAr ? 'كجم' : 'kg');
    const toDispWeight = (kg) =>
      imp ? (kg * 2.20462).toFixed(1) : Number(kg).toFixed(1);

    // Real BMI Calculation
    const heightInMeters = height / 100;
    const bmiVal =
      heightInMeters > 0
        ? Number((currentWeight / (heightInMeters * heightInMeters)).toFixed(2))
        : 22.0;

    let bmiCategory = isAr ? 'وزن مثالي' : 'Healthy range';
    let bmiColor = '#10B981';
    let bmiBg = 'rgba(16, 185, 129, 0.15)';
    if (bmiVal < 18.5) {
      bmiCategory = isAr ? 'نقص في الوزن' : 'Underweight';
      bmiColor = '#3B82F6';
      bmiBg = 'rgba(59, 130, 246, 0.15)';
    } else if (bmiVal >= 25 && bmiVal < 30) {
      bmiCategory = isAr ? 'زيادة في الوزن' : 'Overweight';
      bmiColor = '#F59E0B';
      bmiBg = 'rgba(245, 158, 11, 0.15)';
    } else if (bmiVal >= 30) {
      bmiCategory = isAr ? 'سمنة' : 'Obese';
      bmiColor = '#EF4444';
      bmiBg = 'rgba(239, 68, 68, 0.15)';
    }

    // Weight Goal Progress
    const diffToGoal = Math.abs(currentWeight - goalWeight);
    const totalGoalDiff = Math.abs(startWeight - goalWeight);
    const progressPct =
      totalGoalDiff > 0
        ? Math.min(
            100,
            Math.max(
              0,
              Math.round(
                (Math.abs(startWeight - currentWeight) / totalGoalDiff) * 100
              )
            )
          )
        : currentWeight === goalWeight
        ? 100
        : 50;

    // SVG arc calculation (radius 56, circumference ~ 351.9)
    const maxArc = 263.9;
    const filledArc = Math.max(1, (progressPct / 100) * maxArc);

    // Filter weigh-ins according to active range
    const now = new Date().getTime();
    const daysLimit =
      this.state.range === 0
        ? 30
        : this.state.range === 1
        ? 90
        : this.state.range === 2
        ? 180
        : 9999;
    const filteredWeighIns = this.state.weighIns.filter((w) => {
      const diffDays = (now - new Date(w.date).getTime()) / 86400000;
      return diffDays <= daysLimit;
    });

    // Chart SVG coordinates
    const chartW = 312;
    const chartH = 130;
    const padX = 24;
    const padY = 28;
    const points = filteredWeighIns.length > 0 ? filteredWeighIns : this.state.weighIns;
    const weights = points.map((p) => p.weight);
    const minW = Math.min(...weights, goalWeight) - 1.5;
    const maxW = Math.max(...weights, goalWeight) + 1.5;
    const wSpan = Math.max(1, maxW - minW);

    const getX = (idx, total) => {
      if (total <= 1) return chartW / 2;
      return padX + (idx / (total - 1)) * (chartW - padX * 2);
    };
    const getY = (w) => {
      return chartH - padY - ((w - minW) / wSpan) * (chartH - padY * 2);
    };

    let pathD = '';
    points.forEach((p, idx) => {
      const x = getX(idx, points.length);
      const y = getY(p.weight);
      if (idx === 0) pathD += `M ${x.toFixed(1)} ${y.toFixed(1)}`;
      else pathD += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
    });

    const targetLineY = getY(goalWeight);

    // Intake by Day (Weekly breakdown)
    let loggedScans = [];
    try {
      const v = JSON.parse(window.localStorage.getItem('calsen-log') || '[]');
      if (Array.isArray(v)) loggedScans = v;
    } catch (e) {}

    const dayNamesEn = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const dayNamesAr = ['إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت', 'أحد'];
    const dayNames = isAr ? dayNamesAr : dayNamesEn;

    const wk = this.state.wk;
    const weekDays = dayNames.map((name, i) => {
      const baseVariance = ((i * 137 + wk * 73) % 450) - 150;
      let dayKcal = Math.max(1200, Math.round(targetCals + baseVariance));
      if (wk === 0 && i === 6) {
        dayKcal = loggedScans.length > 0
          ? loggedScans.reduce((acc, m) => acc + (m.kcal || 0), 0)
          : Math.round(targetCals * 0.75);
      }
      const p = Math.round((dayKcal * 0.28) / 4);
      const c = Math.round((dayKcal * 0.44) / 4);
      const f = Math.round((dayKcal * 0.28) / 9);

      const maxH = 100;
      const hP = Math.round(Math.min(maxH * 0.35, (p * 4 / 3000) * maxH));
      const hC = Math.round(Math.min(maxH * 0.45, (c * 4 / 3000) * maxH));
      const hF = Math.round(Math.min(maxH * 0.3, (f * 9 / 3000) * maxH));

      return {
        label: name,
        dayIndex: i,
        kcal: dayKcal,
        p,
        c,
        f,
        hP,
        hC,
        hF,
        hMini: Math.round(Math.min(44, (dayKcal / 2800) * 44)),
        color: dayKcal > targetCals + 100 ? '#F59E0B' : accent,
      };
    });

    const avgKcal = Math.round(
      weekDays.reduce((acc, d) => acc + d.kcal, 0) / weekDays.length
    );
    const avgBurn = Math.round(targetCals + 380);
    const netKcal = avgKcal - avgBurn;

    const markerPercent = Math.max(
      10,
      Math.min(90, 50 + (netKcal / targetCals) * 50)
    );

    const firstWeight = points[0]?.weight ?? currentWeight;
    const diffFromFirst = currentWeight - firstWeight;
    const weightChangeFmt = (d) => {
      const sign = d > 0 ? '+' : '';
      return `${sign}${toDispWeight(d)} ${unitLabel}`;
    };

    const spans = [
      {
        label: isAr ? '3 أيام' : '3 days',
        weightChange: weightChangeFmt(-0.2),
        cals: `${avgKcal} kcal`,
        status: isAr ? 'نزول' : 'Down',
      },
      {
        label: isAr ? '7 أيام' : '7 days',
        weightChange: weightChangeFmt(-0.5),
        cals: `${avgKcal} kcal`,
        status: isAr ? 'نزول' : 'Down',
      },
      {
        label: isAr ? '14 يوماً' : '14 days',
        weightChange: weightChangeFmt(-1.1),
        cals: `${avgKcal} kcal`,
        status: isAr ? 'نزول ممتاز' : 'Great loss',
      },
      {
        label: isAr ? '30 يوماً' : '30 days',
        weightChange: weightChangeFmt(-2.4),
        cals: `${avgKcal} kcal`,
        status: isAr ? 'ثابت وملتزم' : 'On track',
      },
      {
        label: isAr ? '90 يوماً' : '90 days',
        weightChange: weightChangeFmt(diffFromFirst || -4.8),
        cals: `${avgKcal} kcal`,
        status: isAr ? 'تطور رائع' : 'Super progress',
      },
      {
        label: isAr ? 'كامل الفترة' : 'All time',
        weightChange: weightChangeFmt(currentWeight - startWeight),
        cals: `${avgKcal} kcal`,
        status: isAr ? 'إجمالي التقدم' : 'Total shift',
      },
    ];

    const weekLabelsEn = ['This week', 'Last week', '2 weeks ago', '3 weeks ago'];
    const weekLabelsAr = ['هذا الأسبوع', 'الأسبوع الماضي', 'منذ أسبوعين', 'منذ 3 أسابيع'];
    const weekLabels = isAr ? weekLabelsAr : weekLabelsEn;

    return {
      isAr,
      accent,
      glow,
      soft: this.glowOf(accent, 0.12),
      currentWeight,
      goalWeight,
      startWeight,
      toDispWeight,
      unitLabel,
      progressPct,
      filledArc,
      diffToGoal,
      bmiVal,
      bmiCategory,
      bmiColor,
      bmiBg,
      avgKcal,
      avgBurn,
      netKcal,
      markerPercent,
      points,
      pathD,
      targetLineY,
      weekDays,
      weekLabel: weekLabels[wk],
      spans,
      chartW: CHART_W,
      chartH: CHART_H,
      themeKey: dark ? 'dark' : 'light',
    };
  }

  render() {
    const v = this.renderVals();
    const isAr = v.isAr;
    const mode = this.modeNow();
    const dark = this.isDark(mode);

    return (
      <div
        className="app"
        data-theme={v.themeKey}
        dir={isAr ? 'rtl' : 'ltr'}
        style={{
          position: 'relative',
          width: '390px',
          height: '844px',
          boxSizing: 'border-box',
          fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif",
          overflow: 'hidden',
        }}
      >
        {/* Hidden File Input for Photo Upload */}
        <input
          type="file"
          accept="image/*"
          ref={(el) => (this.fileInputRef = el)}
          style={{ display: 'none' }}
          onChange={this.handlePhotoUpload}
        />

        {/* Toast alert */}
        {this.state.toastMsg && (
          <div
            style={{
              position: 'fixed',
              top: '20px',
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 9999,
              background: '#1F2937',
              color: '#FFFFFF',
              padding: '10px 20px',
              borderRadius: '24px',
              boxShadow: '0 10px 25px rgba(0,0,0,0.4)',
              fontSize: '14px',
              fontWeight: '700',
              pointerEvents: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}
          >
            <span>✨</span>
            <span>{this.state.toastMsg}</span>
          </div>
        )}

        <div
          className="scroll"
          style={{
            position: 'absolute',
            left: '0',
            top: '0',
            right: '0',
            bottom: '0',
            overflowY: 'auto',
            overflowX: 'hidden',
            overscrollBehavior: 'contain',
          }}
        >
          <div
            className="stagger"
            style={{
              boxSizing: 'border-box',
              padding: '24px 20px 112px 20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
            }}
          >
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <h1
                style={{
                  margin: '0',
                  fontSize: '28px',
                  lineHeight: '34px',
                  fontWeight: '800',
                  letterSpacing: '-0.03em',
                }}
              >
                {isAr ? 'البيانات والتحليلات' : 'Trends & Analytics'}
              </h1>
              <p
                style={{
                  margin: '2px 0 0',
                  fontSize: '13px',
                  color: 'var(--muted)',
                  fontWeight: '600',
                }}
              >
                {isAr
                  ? 'متابعة حية للوزن، السعرات، وتطور الجسم'
                  : 'Live tracking of weight, calories & physique'}
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {/* Theme toggle */}
              <button
                className="rbtn"
                aria-label={dark ? 'Light mode' : 'Dark mode'}
                onClick={() => this.setMode(dark ? 'light' : 'dark')}
                style={{ cursor: 'pointer' }}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  {dark ? (
                    <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  ) : (
                    <path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  )}
                </svg>
              </button>

              {/* Notifications */}
              <button
                className="rbtn"
                aria-label="Notifications"
                onClick={() => this.setState({ showNotifModal: true, unreadNotifs: 0 })}
                style={{ position: 'relative', cursor: 'pointer' }}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15z"></path>
                  <path d="M10 21a2 2 0 0 0 4 0"></path>
                </svg>
                {this.state.unreadNotifs > 0 && (
                  <span
                    style={{
                      position: 'absolute',
                      top: '10px',
                      right: '11px',
                      boxSizing: 'border-box',
                      width: '10px',
                      height: '10px',
                      borderRadius: '5px',
                      background: v.accent,
                      border: '2px solid var(--glass)',
                    }}
                  ></span>
                )}
              </button>

              {/* Profile Shortcut */}
              <a
                href={ROUTES.profile}
                className="rbtn"
                aria-label="Profile and settings"
                onClick={(e) => {
                  go(e, 'profile', this.props);
                }}
                style={{ cursor: 'pointer' }}
              >
                <svg
                  width="22"
                  height="22"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="8" r="4"></circle>
                  <path d="M4 21c0-4 4-6 8-6s8 2 8 6"></path>
                </svg>
              </a>
            </div>
          </div>

          {/* CARD 1: Weight Goal & Progress Gauge */}
          <div className="glass card" style={{ padding: '20px', borderRadius: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '800' }}>
                {isAr ? 'هدف الوزن والتقدم' : 'Weight Goal'}
              </h2>
              <span
                style={{
                  fontSize: '12px',
                  fontWeight: '800',
                  padding: '4px 10px',
                  borderRadius: '12px',
                  background: 'var(--chip)',
                  color: v.accent,
                }}
              >
                {v.progressPct}% {isAr ? 'مكتمل' : 'Reached'}
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginTop: '14px' }}>
              {/* Radial Arc Gauge */}
              <div
                style={{
                  position: 'relative',
                  width: '132px',
                  height: '132px',
                  flex: 'none',
                }}
              >
                <svg
                  width="132"
                  height="132"
                  viewBox="0 0 132 132"
                  fill="none"
                  role="img"
                  style={{ display: 'block', overflow: 'visible' }}
                >
                  <circle
                    cx="66"
                    cy="66"
                    r="56"
                    style={{ stroke: 'var(--track)' }}
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray="263.9 351.9"
                    transform="rotate(135 66 66)"
                  ></circle>
                  <circle
                    cx="66"
                    cy="66"
                    r="56"
                    stroke={v.accent}
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray={`${v.filledArc} 351.9`}
                    transform="rotate(135 66 66)"
                    style={{ transition: 'stroke-dasharray 0.6s ease' }}
                  ></circle>
                </svg>
                <div
                  style={{
                    position: 'absolute',
                    left: '0',
                    top: '0',
                    width: '132px',
                    height: '132px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <span
                    style={{
                      fontSize: '26px',
                      lineHeight: '30px',
                      fontWeight: '800',
                      letterSpacing: '-0.03em',
                    }}
                  >
                    {v.toDispWeight(v.currentWeight)}
                  </span>
                  <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--muted)' }}>
                    {v.unitLabel} {isAr ? 'الآن' : 'now'}
                  </span>
                </div>
              </div>

              {/* Stats column */}
              <div
                style={{
                  flex: '1',
                  minWidth: '0',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: '600' }}>
                    {isAr ? 'الهدف المطلوب' : 'Target'}
                  </span>
                  <span style={{ fontSize: '17px', lineHeight: '22px', fontWeight: '800' }}>
                    {v.toDispWeight(v.goalWeight)} {v.unitLabel}
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: '600' }}>
                    {isAr ? 'نقطة البداية' : 'Starting point'}
                  </span>
                  <span style={{ fontSize: '17px', lineHeight: '22px', fontWeight: '800' }}>
                    {v.toDispWeight(v.startWeight)} {v.unitLabel}
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: '600' }}>
                    {isAr ? 'المتبقي للوصول' : 'Still to go'}
                  </span>
                  <span
                    style={{
                      fontSize: '17px',
                      lineHeight: '22px',
                      fontWeight: '800',
                      color: v.accent,
                    }}
                  >
                    {v.toDispWeight(v.diffToGoal)} {v.unitLabel}
                  </span>
                </div>
              </div>
            </div>

            {/* Add weigh-in trigger button */}
            <button
              onClick={() =>
                this.setState({
                  showWeighInModal: true,
                  newWeightInput: String(v.currentWeight),
                  newWeightDate: new Date().toISOString().slice(0, 10),
                  newWeightNote: '',
                })
              }
              style={{
                width: '100%',
                height: '48px',
                boxSizing: 'border-box',
                borderRadius: '24px',
                border: '0',
                background: v.accent,
                boxShadow: `0 8px 20px ${v.glow}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                cursor: 'pointer',
                color: '#FFFFFF',
                fontSize: '15px',
                fontWeight: '800',
                marginTop: '16px',
                transition: 'transform 0.15s ease',
              }}
              onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.98)')}
              onMouseUp={(e) => (e.currentTarget.style.transform = 'scale(1)')}
            >
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.4"
                strokeLinecap="round"
              >
                <path d="M12 5v14"></path>
                <path d="M5 12h14"></path>
              </svg>
              {isAr ? 'تسجيل وزن جديد' : 'Add weigh-in'}
            </button>
          </div>

          {/* CARD 2: Two-column grid (BMI gauge & Avg Daily Intake) */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '12px' }}>
            {/* BMI Card */}
            <div
              className="glass"
              style={{
                boxSizing: 'border-box',
                minHeight: '192px',
                borderRadius: '24px',
                padding: '14px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <div
                style={{
                  alignSelf: isAr ? 'flex-end' : 'flex-start',
                  fontSize: '13px',
                  fontWeight: '700',
                  color: 'var(--muted)',
                }}
              >
                {isAr ? 'مؤشر الكتلة (BMI)' : 'BMI Index'}
              </div>

              <div style={{ position: 'relative', width: '139px', height: '80px', marginTop: '6px' }}>
                <svg
                  width="139"
                  height="80"
                  viewBox="0 0 139 84"
                  fill="none"
                  style={{ display: 'block', overflow: 'visible' }}
                >
                  <path d="M11.5 70A58 58 0 0 1 17 45.3" stroke="#3B82F6" strokeWidth="11"></path>
                  <path d="M17 45.3A58 58 0 0 1 51.6 14.8" stroke="#10B981" strokeWidth="11"></path>
                  <path d="M51.6 14.8A58 58 0 0 1 87.4 14.8" stroke="#F59E0B" strokeWidth="11"></path>
                  <path d="M87.4 14.8A58 58 0 0 1 127.5 70" stroke="#EF4444" strokeWidth="11"></path>
                </svg>
                <div
                  style={{
                    position: 'absolute',
                    left: '0',
                    right: '0',
                    bottom: '0',
                    textAlign: 'center',
                    fontSize: '26px',
                    fontWeight: '800',
                    letterSpacing: '-0.02em',
                  }}
                >
                  {v.bmiVal}
                </div>
              </div>

              <span
                style={{
                  padding: '3px 10px',
                  borderRadius: '12px',
                  background: v.bmiBg,
                  color: v.bmiColor,
                  fontSize: '11px',
                  fontWeight: '800',
                  textAlign: 'center',
                }}
              >
                {v.bmiCategory}
              </span>
            </div>

            {/* Avg Daily Intake Card */}
            <div
              className="glass"
              style={{
                boxSizing: 'border-box',
                minHeight: '192px',
                borderRadius: '24px',
                padding: '14px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}
            >
              <div>
                <div
                  style={{
                    fontSize: '13px',
                    fontWeight: '700',
                    color: 'var(--muted)',
                  }}
                >
                  {isAr ? 'متوسط السعرات' : 'Avg daily intake'}
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px', marginTop: '2px' }}>
                  <span
                    style={{
                      fontSize: '30px',
                      fontWeight: '800',
                      letterSpacing: '-0.03em',
                    }}
                  >
                    {v.avgKcal}
                  </span>
                  <span style={{ fontSize: '11px', color: 'var(--muted)', fontWeight: '700' }}>
                    {isAr ? 'سعرة' : 'kcal'}
                  </span>
                </div>
              </div>

              {/* 7-day mini bar graph */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(7, minmax(0, 1fr))',
                  gap: '3px',
                  alignItems: 'end',
                  height: '48px',
                  marginTop: '8px',
                }}
              >
                {v.weekDays.map((d, i) => (
                  <div
                    key={i}
                    title={`${d.label}: ${d.kcal} kcal`}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '4px',
                    }}
                  >
                    <div
                      style={{
                        width: '100%',
                        maxWidth: '12px',
                        height: `${d.hMini}px`,
                        borderRadius: '6px',
                        background: d.color,
                        transition: 'height 0.3s ease',
                      }}
                    ></div>
                    <span style={{ fontSize: '9px', fontWeight: '700', color: 'var(--muted)' }}>
                      {d.label[0]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* CARD 3: Weigh-ins Dynamic Chart & Time Filters */}
          <div className="glass card" style={{ padding: '18px', borderRadius: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '800' }}>
                {isAr ? 'رسم بياني لتطور الوزن' : 'Weigh-ins Chart'}
              </h2>
              <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: '600' }}>
                {v.points.length} {isAr ? 'تسجيلات' : 'entries'}
              </span>
            </div>

            {/* Interactive SVG Chart */}
            <div
              style={{
                position: 'relative',
                width: '100%',
                height: '130px',
                margin: '14px 0 10px',
                background: 'rgba(0,0,0,0.03)',
                borderRadius: '16px',
                overflow: 'hidden',
              }}
            >
              <svg
                width="100%"
                height="130"
                viewBox={`0 0 ${CHART_W} ${CHART_H}`}
                preserveAspectRatio="none"
                style={{ display: 'block' }}
              >
                {/* Target dotted line */}
                <line
                  x1="0"
                  y1={v.targetLineY}
                  x2={CHART_W}
                  y2={v.targetLineY}
                  stroke="var(--muted)"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                  strokeOpacity="0.5"
                />
                <text
                  x={isAr ? CHART_W - 8 : 8}
                  y={Math.max(14, v.targetLineY - 6)}
                  textAnchor={isAr ? 'end' : 'start'}
                  fill="var(--muted)"
                  fontSize="10"
                  fontWeight="700"
                >
                  {isAr ? 'الهدف' : 'Target'}: {v.toDispWeight(v.goalWeight)} {v.unitLabel}
                </text>

                {/* Weigh-in curve path */}
                {v.pathD && (
                  <path
                    d={v.pathD}
                    fill="none"
                    stroke={v.accent}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                )}

                {/* Point nodes */}
                {v.points.map((p, idx) => {
                  const x = (idx / Math.max(1, v.points.length - 1)) * (CHART_W - 48) + 24;
                  const minW = Math.min(...v.points.map((pt) => pt.weight), v.goalWeight) - 1.5;
                  const maxW = Math.max(...v.points.map((pt) => pt.weight), v.goalWeight) + 1.5;
                  const y = CHART_H - 28 - ((p.weight - minW) / (maxW - minW || 1)) * (CHART_H - 56);
                  return (
                    <g key={p.id || idx}>
                      <circle
                        cx={x}
                        cy={y}
                        r="5.5"
                        fill="#FFFFFF"
                        stroke={v.accent}
                        strokeWidth="3"
                        style={{ cursor: 'pointer' }}
                        onClick={() =>
                          this.toast(`${p.date}: ${v.toDispWeight(p.weight)} ${v.unitLabel}`)
                        }
                      />
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Range Filters: 30D, 90D, 6M, All */}
            <div style={{ display: 'flex', gap: '6px' }}>
              {[
                { label: isAr ? '30 يوم' : '30D', val: 0 },
                { label: isAr ? '90 يوم' : '90D', val: 1 },
                { label: isAr ? '6 أشهر' : '6M', val: 2 },
                { label: isAr ? 'الكل' : 'All', val: 3 },
              ].map((r) => {
                const on = this.state.range === r.val;
                return (
                  <button
                    key={r.val}
                    onClick={() => this.setState({ range: r.val })}
                    style={{
                      flex: 1,
                      height: '38px',
                      borderRadius: '19px',
                      border: 0,
                      background: on ? v.accent : 'var(--chip)',
                      color: on ? '#FFFFFF' : 'var(--muted)',
                      fontSize: '12px',
                      fontWeight: '800',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    {r.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* CARD 4: Change log (Weight vs Energy use tabs) */}
          <div className="glass card" style={{ padding: '18px', borderRadius: '24px' }}>
            <h2>{isAr ? 'سجل التغير الزمني' : 'Change Log'}</h2>

            {/* Tabs: Weight vs Energy use */}
            <div
              style={{
                display: 'flex',
                gap: '4px',
                padding: '4px',
                borderRadius: '26px',
                background: 'var(--seg)',
                margin: '12px 0 14px',
              }}
            >
              {[
                { label: isAr ? 'الوزن' : 'Weight', idx: 0 },
                { label: isAr ? 'استهلاك الطاقة' : 'Energy use', idx: 1 },
              ].map((t) => {
                const on = this.state.tab === t.idx;
                return (
                  <button
                    key={t.idx}
                    onClick={() => this.setState({ tab: t.idx })}
                    style={{
                      flex: 1,
                      height: '40px',
                      borderRadius: '20px',
                      border: 0,
                      background: on ? v.accent : 'transparent',
                      color: on ? '#FFFFFF' : 'var(--muted)',
                      fontSize: '13px',
                      fontWeight: on ? '800' : '600',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    {t.label}
                  </button>
                );
              })}
            </div>

            {/* Dynamic Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '8px' }}>
              {v.spans.map((s, i) => (
                <div
                  key={i}
                  className="tile"
                  style={{
                    padding: '12px 8px',
                    borderRadius: '16px',
                    textAlign: 'center',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '2px',
                  }}
                >
                  <span style={{ fontSize: '11px', color: 'var(--muted)', fontWeight: '700' }}>
                    {s.label}
                  </span>
                  <span
                    style={{
                      fontSize: '16px',
                      fontWeight: '800',
                      color: this.state.tab === 0 ? v.accent : 'var(--ink)',
                    }}
                  >
                    {this.state.tab === 0 ? s.weightChange : s.cals}
                  </span>
                  <span style={{ fontSize: '10px', fontWeight: '700', color: 'var(--muted)' }}>
                    {s.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* CARD 5: Intake by Day (Weekly breakdown with switcher) */}
          <div className="glass card" style={{ padding: '18px', borderRadius: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '800' }}>
                  {isAr ? 'الاستهلاك حسب الأيام' : 'Intake by Day'}
                </h2>
                <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: '600' }}>
                  {isAr ? 'توزيع الماكروز اليومي' : 'Daily macronutrient split'}
                </span>
              </div>

              {/* Week switcher arrows */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <button
                  className="ghost"
                  aria-label="Previous week"
                  onClick={() => this.setState({ wk: Math.min(3, this.state.wk + 1) })}
                  disabled={this.state.wk >= 3}
                  style={{
                    opacity: this.state.wk >= 3 ? 0.35 : 1,
                    cursor: this.state.wk >= 3 ? 'default' : 'pointer',
                    padding: '6px',
                    borderRadius: '50%',
                  }}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                    <path d="M15 5l-7 7 7 7" />
                  </svg>
                </button>
                <span style={{ fontSize: '12px', fontWeight: '800', minWidth: '80px', textAlign: 'center' }}>
                  {v.weekLabel}
                </span>
                <button
                  className="ghost"
                  aria-label="Next week"
                  onClick={() => this.setState({ wk: Math.max(0, this.state.wk - 1) })}
                  disabled={this.state.wk <= 0}
                  style={{
                    opacity: this.state.wk <= 0 ? 0.35 : 1,
                    cursor: this.state.wk <= 0 ? 'default' : 'pointer',
                    padding: '6px',
                    borderRadius: '50%',
                  }}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                    <path d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Stacked Macro Bars */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, minmax(0, 1fr))',
                gap: '8px 4px',
                justifyItems: 'center',
                margin: '20px 0 16px',
              }}
            >
              {v.weekDays.map((b, i) => (
                <div
                  key={i}
                  onClick={() => this.setState({ selectedDayIndex: i })}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '6px',
                    cursor: 'pointer',
                    padding: '4px',
                    borderRadius: '12px',
                    background: this.state.selectedDayIndex === i ? 'var(--chip)' : 'transparent',
                    transition: 'background 0.2s ease',
                  }}
                >
                  <div
                    style={{
                      width: '28px',
                      height: '110px',
                      borderRadius: '14px',
                      background: 'var(--track)',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'flex-end',
                    }}
                  >
                    {/* Fat */}
                    <div style={{ height: `${b.hF}px`, background: '#EF4444' }} title={`Fat: ${b.f}g`}></div>
                    {/* Carbs */}
                    <div style={{ height: `${b.hC}px`, background: '#F59E0B' }} title={`Carbs: ${b.c}g`}></div>
                    {/* Protein */}
                    <div style={{ height: `${b.hP}px`, background: '#3B82F6' }} title={`Protein: ${b.p}g`}></div>
                  </div>
                  <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--muted)' }}>
                    {b.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Selected day detail snippet */}
            {this.state.selectedDayIndex !== null && (
              <div
                style={{
                  background: 'var(--chip)',
                  borderRadius: '14px',
                  padding: '10px 14px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '12px',
                }}
              >
                <div>
                  <span style={{ fontWeight: '800', fontSize: '13px' }}>
                    {v.weekDays[this.state.selectedDayIndex].label}:{' '}
                  </span>
                  <span style={{ color: v.accent, fontWeight: '800', fontSize: '13px' }}>
                    {v.weekDays[this.state.selectedDayIndex].kcal} kcal
                  </span>
                </div>
                <div style={{ display: 'flex', gap: '8px', fontSize: '11px', fontWeight: '700' }}>
                  <span style={{ color: '#3B82F6' }}>P: {v.weekDays[this.state.selectedDayIndex].p}g</span>
                  <span style={{ color: '#F59E0B' }}>C: {v.weekDays[this.state.selectedDayIndex].c}g</span>
                  <span style={{ color: '#EF4444' }}>F: {v.weekDays[this.state.selectedDayIndex].f}g</span>
                </div>
              </div>
            )}

            {/* Legend */}
            <div
              style={{
                display: 'flex',
                justifyContent: 'center',
                gap: '18px',
                fontSize: '12px',
                fontWeight: '700',
              }}
            >
              <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{ width: '9px', height: '9px', borderRadius: '50%', background: '#3B82F6' }}></span>
                {isAr ? 'بروتين' : 'Protein'}
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{ width: '9px', height: '9px', borderRadius: '50%', background: '#F59E0B' }}></span>
                {isAr ? 'كارب' : 'Carbs'}
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{ width: '9px', height: '9px', borderRadius: '50%', background: '#EF4444' }}></span>
                {isAr ? 'دهون' : 'Fat'}
              </span>
            </div>
          </div>

          {/* CARD 6: Eaten vs Burned */}
          <div className="glass card" style={{ padding: '18px', borderRadius: '24px' }}>
            <h2>{isAr ? 'المتناول مقابل المحروق' : 'Eaten vs Burned'}</h2>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '8px', margin: '12px 0 14px' }}>
              <div className="tile" style={{ padding: '10px', borderRadius: '16px', textAlign: 'center' }}>
                <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--muted)' }}>
                  {isAr ? 'المتناول' : 'Eaten'}
                </span>
                <span style={{ fontSize: '20px', fontWeight: '800', display: 'block', margin: '2px 0' }}>
                  {v.avgKcal}
                </span>
                <span style={{ fontSize: '10px', color: 'var(--muted)' }}>{isAr ? 'سعرة/يوم' : 'kcal/day'}</span>
              </div>

              <div className="tile" style={{ padding: '10px', borderRadius: '16px', textAlign: 'center' }}>
                <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--muted)' }}>
                  {isAr ? 'المحروق' : 'Burned'}
                </span>
                <span style={{ fontSize: '20px', fontWeight: '800', display: 'block', margin: '2px 0' }}>
                  {v.avgBurn}
                </span>
                <span style={{ fontSize: '10px', color: 'var(--muted)' }}>{isAr ? 'سعرة/يوم' : 'kcal/day'}</span>
              </div>

              <div className="tile" style={{ padding: '10px', borderRadius: '16px', textAlign: 'center' }}>
                <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--muted)' }}>
                  {isAr ? 'الصافي' : 'Net'}
                </span>
                <span
                  style={{
                    fontSize: '20px',
                    fontWeight: '800',
                    display: 'block',
                    margin: '2px 0',
                    color: v.netKcal <= 0 ? '#10B981' : '#F59E0B',
                  }}
                >
                  {v.netKcal > 0 ? `+${v.netKcal}` : v.netKcal}
                </span>
                <span style={{ fontSize: '10px', color: 'var(--muted)' }}>
                  {v.netKcal <= 0 ? (isAr ? 'عجز صحي' : 'Healthy deficit') : (isAr ? 'فائض' : 'Surplus')}
                </span>
              </div>
            </div>

            {/* Dynamic Slider track */}
            <div style={{ position: 'relative', height: '24px', margin: '6px 0' }}>
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  top: '8px',
                  height: '8px',
                  borderRadius: '4px',
                  background: 'var(--track)',
                }}
              ></div>
              <div
                style={{
                  position: 'absolute',
                  left: `${v.markerPercent}%`,
                  top: '3px',
                  width: '18px',
                  height: '18px',
                  marginLeft: '-9px',
                  borderRadius: '50%',
                  background: v.accent,
                  border: '3px solid #FFFFFF',
                  boxShadow: `0 0 10px ${v.glow}`,
                  transition: 'left 0.4s ease',
                }}
              ></div>
            </div>

            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                fontSize: '11px',
                fontWeight: '700',
                color: 'var(--muted)',
              }}
            >
              <span>{isAr ? 'عجز سعرات (خسارة دهون)' : 'Deficit (Fat loss)'}</span>
              <span>{isAr ? 'توازن' : 'Balanced'}</span>
              <span>{isAr ? 'فائض سعرات (بناء عضل)' : 'Surplus (Muscle)'}</span>
            </div>
          </div>

          {/* CARD 7: Photo Timeline (Fully Working with upload & preview) */}
          <div className="glass card" style={{ padding: '18px', borderRadius: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '800' }}>
                  {isAr ? 'سجل الصور وتطور الجسم' : 'Photo Timeline'}
                </h2>
                <span style={{ fontSize: '12px', color: 'var(--muted)', fontWeight: '600' }}>
                  {isAr ? 'التقط صوراً دورية لمقارنة النتيجة' : 'Snap weekly progress to compare'}
                </span>
              </div>
            </div>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
                gap: '10px',
                marginTop: '14px',
              }}
            >
              {/* Trigger Button */}
              <button
                onClick={() => {
                  if (this.fileInputRef) {
                    this.fileInputRef.value = '';
                    this.fileInputRef.click();
                  }
                }}
                aria-label="Add a progress photo"
                style={{
                  boxSizing: 'border-box',
                  aspectRatio: '1 / 1',
                  borderRadius: '20px',
                  border: `2px dashed ${v.accent}`,
                  background: v.soft,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  padding: '0',
                  cursor: 'pointer',
                  color: v.accent,
                  fontSize: '13px',
                  fontWeight: '800',
                }}
              >
                <svg
                  width="26"
                  height="26"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M4 8h3l2-3h6l2 3h3v11H4z"></path>
                  <circle cx="12" cy="13" r="3.5"></circle>
                </svg>
                {isAr ? 'إضافة صورة' : 'Add photo'}
              </button>

              {/* Uploaded Photos */}
              {this.state.photos.map((p) => (
                <div
                  key={p.id}
                  onClick={() => this.setState({ previewPhoto: p })}
                  style={{
                    position: 'relative',
                    aspectRatio: '1 / 1',
                    borderRadius: '20px',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                  }}
                >
                  <img
                    src={p.url}
                    alt={p.note || 'Progress'}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                  <span
                    style={{
                      position: 'absolute',
                      bottom: '4px',
                      left: '4px',
                      right: '4px',
                      background: 'rgba(0,0,0,0.6)',
                      color: '#FFFFFF',
                      fontSize: '9px',
                      fontWeight: '800',
                      padding: '2px 4px',
                      borderRadius: '8px',
                      textAlign: 'center',
                    }}
                  >
                    {p.date}
                  </span>
                </div>
              ))}

              {/* Empty placeholder slot if few photos */}
              {this.state.photos.length === 0 && (
                <div
                  style={{
                    boxSizing: 'border-box',
                    aspectRatio: '1 / 1',
                    borderRadius: '20px',
                    background: 'var(--seg)',
                    color: 'var(--muted)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '4px',
                    fontSize: '11px',
                    fontWeight: '700',
                  }}
                >
                  <span>📷</span>
                  <span>{isAr ? 'لا توجد صور بعد' : 'No photos yet'}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

        {/* MODAL 1: Add Weigh-In Modal */}
        {this.state.showWeighInModal && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0,0,0,0.65)',
              backdropFilter: 'blur(6px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '20px',
            }}
            onClick={() => this.setState({ showWeighInModal: false })}
          >
            <div
              className="glass"
              style={{
                width: '100%',
                maxWidth: '360px',
                borderRadius: '28px',
                padding: '24px',
                background: 'var(--glass-hi)',
                boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
                display: 'flex',
                flexDirection: 'column',
                gap: '16px',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0, fontSize: '20px', fontWeight: '800' }}>
                  {isAr ? 'تسجيل قياس وزن جديد' : 'Log New Weigh-In'}
                </h3>
                <button
                  onClick={() => this.setState({ showWeighInModal: false })}
                  style={{
                    border: 0,
                    background: 'var(--chip)',
                    width: '32px',
                    height: '32px',
                    borderRadius: '16px',
                    cursor: 'pointer',
                    fontWeight: '800',
                  }}
                >
                  ✕
                </button>
              </div>

              {/* Weight stepper & input */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '13px', fontWeight: '700', color: 'var(--muted)' }}>
                  {isAr ? 'الوزن الحالي' : 'Current Weight'} ({v.unitLabel})
                </label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <button
                    onClick={() => {
                      const cur = parseFloat(this.state.newWeightInput) || v.currentWeight;
                      this.setState({ newWeightInput: (cur - 0.2).toFixed(1) });
                    }}
                    style={{
                      width: '44px',
                      height: '44px',
                      borderRadius: '14px',
                      border: 0,
                      background: 'var(--chip)',
                      fontSize: '20px',
                      fontWeight: '800',
                      cursor: 'pointer',
                    }}
                  >
                    -
                  </button>
                  <input
                    type="number"
                    step="0.1"
                    value={this.state.newWeightInput}
                    onChange={(e) => this.setState({ newWeightInput: e.target.value })}
                    style={{
                      flex: 1,
                      height: '48px',
                      borderRadius: '16px',
                      border: `2px solid ${v.accent}`,
                      background: 'var(--bg)',
                      color: 'var(--ink)',
                      fontSize: '22px',
                      fontWeight: '800',
                      textAlign: 'center',
                      outline: 'none',
                    }}
                  />
                  <button
                    onClick={() => {
                      const cur = parseFloat(this.state.newWeightInput) || v.currentWeight;
                      this.setState({ newWeightInput: (cur + 0.2).toFixed(1) });
                    }}
                    style={{
                      width: '44px',
                      height: '44px',
                      borderRadius: '14px',
                      border: 0,
                      background: 'var(--chip)',
                      fontSize: '20px',
                      fontWeight: '800',
                      cursor: 'pointer',
                    }}
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Date */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '13px', fontWeight: '700', color: 'var(--muted)' }}>
                  {isAr ? 'التاريخ' : 'Date'}
                </label>
                <input
                  type="date"
                  value={this.state.newWeightDate}
                  onChange={(e) => this.setState({ newWeightDate: e.target.value })}
                  style={{
                    height: '44px',
                    borderRadius: '14px',
                    border: '1px solid var(--edge)',
                    background: 'var(--chip)',
                    color: 'var(--ink)',
                    padding: '0 12px',
                    fontSize: '14px',
                    fontWeight: '700',
                    outline: 'none',
                  }}
                />
              </div>

              {/* Note */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '13px', fontWeight: '700', color: 'var(--muted)' }}>
                  {isAr ? 'ملاحظة (اختياري)' : 'Note (optional)'}
                </label>
                <input
                  type="text"
                  placeholder={isAr ? 'مثال: وزن الصباح على الريق' : 'e.g. Morning empty stomach'}
                  value={this.state.newWeightNote}
                  onChange={(e) => this.setState({ newWeightNote: e.target.value })}
                  style={{
                    height: '44px',
                    borderRadius: '14px',
                    border: '1px solid var(--edge)',
                    background: 'var(--chip)',
                    color: 'var(--ink)',
                    padding: '0 12px',
                    fontSize: '14px',
                    fontWeight: '600',
                    outline: 'none',
                  }}
                />
              </div>

              {/* Action buttons */}
              <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                <button
                  onClick={() => this.setState({ showWeighInModal: false })}
                  style={{
                    flex: 1,
                    height: '46px',
                    borderRadius: '23px',
                    border: 0,
                    background: 'var(--chip)',
                    color: 'var(--ink)',
                    fontWeight: '700',
                    cursor: 'pointer',
                  }}
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  onClick={this.saveWeighIn}
                  style={{
                    flex: 1.5,
                    height: '46px',
                    borderRadius: '23px',
                    border: 0,
                    background: v.accent,
                    color: '#FFFFFF',
                    fontWeight: '800',
                    cursor: 'pointer',
                    boxShadow: `0 6px 16px ${v.glow}`,
                  }}
                >
                  {isAr ? 'حفظ القياس' : 'Save Weigh-In'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL 2: Progress Photo Preview & Delete */}
        {this.state.previewPhoto && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0,0,0,0.85)',
              backdropFilter: 'blur(8px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '20px',
            }}
            onClick={() => this.setState({ previewPhoto: null })}
          >
            <div
              style={{
                width: '100%',
                maxWidth: '380px',
                borderRadius: '24px',
                overflow: 'hidden',
                background: '#18181B',
                boxShadow: '0 20px 40px rgba(0,0,0,0.6)',
                display: 'flex',
                flexDirection: 'column',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ position: 'relative', width: '100%', maxHeight: '420px', overflow: 'hidden' }}>
                <img
                  src={this.state.previewPhoto.url}
                  alt="Progress Preview"
                  style={{ width: '100%', height: 'auto', display: 'block', maxHeight: '420px', objectFit: 'contain' }}
                />
                <button
                  onClick={() => this.setState({ previewPhoto: null })}
                  style={{
                    position: 'absolute',
                    top: '12px',
                    right: '12px',
                    width: '36px',
                    height: '36px',
                    borderRadius: '18px',
                    background: 'rgba(0,0,0,0.6)',
                    color: '#FFFFFF',
                    border: 0,
                    cursor: 'pointer',
                    fontSize: '16px',
                    fontWeight: '800',
                  }}
                >
                  ✕
                </button>
              </div>

              <div style={{ padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <span style={{ fontSize: '13px', color: '#9CA3AF', fontWeight: '700' }}>
                    {this.state.previewPhoto.date}
                  </span>
                  <div style={{ fontSize: '15px', color: '#FFFFFF', fontWeight: '800', marginTop: '2px' }}>
                    {this.state.previewPhoto.note || (isAr ? 'صورة تقدم' : 'Progress check')}
                  </div>
                </div>

                <button
                  onClick={() => this.deletePhoto(this.state.previewPhoto.id)}
                  style={{
                    padding: '8px 14px',
                    borderRadius: '16px',
                    border: 0,
                    background: 'rgba(239, 68, 68, 0.2)',
                    color: '#EF4444',
                    fontWeight: '800',
                    fontSize: '13px',
                    cursor: 'pointer',
                  }}
                >
                  {isAr ? 'حذف الصورة' : 'Delete photo'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL 3: Notifications Center */}
        {this.state.showNotifModal && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0,0,0,0.65)',
              backdropFilter: 'blur(6px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '20px',
            }}
            onClick={() => this.setState({ showNotifModal: false })}
          >
            <div
              className="glass"
              style={{
                width: '100%',
                maxWidth: '360px',
                borderRadius: '28px',
                padding: '22px',
                background: 'var(--glass-hi)',
                boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0, fontSize: '18px', fontWeight: '800' }}>
                  {isAr ? 'التنبيهات والإشعارات' : 'Notifications'}
                </h3>
                <button
                  onClick={() => this.setState({ showNotifModal: false })}
                  style={{
                    border: 0,
                    background: 'var(--chip)',
                    width: '32px',
                    height: '32px',
                    borderRadius: '16px',
                    cursor: 'pointer',
                    fontWeight: '800',
                  }}
                >
                  ✕
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <div
                  style={{
                    padding: '12px',
                    borderRadius: '16px',
                    background: 'var(--chip)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                >
                  <span style={{ fontSize: '20px' }}>⚖️</span>
                  <div>
                    <div style={{ fontSize: '13px', fontWeight: '800' }}>
                      {isAr ? 'موعد تسجيل الوزن الدوري' : 'Weekly Weigh-in Reminder'}
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '2px' }}>
                      {isAr ? 'سجل وزنك اليوم لمتابعة دقيقة لخطة هدفك' : 'Log your weight today for precise goal tracking'}
                    </div>
                  </div>
                </div>

                <div
                  style={{
                    padding: '12px',
                    borderRadius: '16px',
                    background: 'var(--chip)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                >
                  <span style={{ fontSize: '20px' }}>💧</span>
                  <div>
                    <div style={{ fontSize: '13px', fontWeight: '800' }}>
                      {isAr ? 'تذكير شرب الماء' : 'Hydration Reminder'}
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '2px' }}>
                      {isAr ? 'حافظ على ترطيب جسمك - اشرب كوب ماء الآن' : 'Stay hydrated - drink a glass of water now'}
                    </div>
                  </div>
                </div>

                <div
                  style={{
                    padding: '12px',
                    borderRadius: '16px',
                    background: 'var(--chip)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                  }}
                >
                  <span style={{ fontSize: '20px' }}>🥗</span>
                  <div>
                    <div style={{ fontSize: '13px', fontWeight: '800' }}>
                      {isAr ? 'تسجيل وجبة اليوم' : 'Log your next meal'}
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '2px' }}>
                      {isAr ? 'المتبقي من سعراتك اليوم: 650 سعرة' : 'Remaining calories today: 650 kcal'}
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  this.toast(isAr ? 'تم تعليم جميع الإشعارات كمقروءة' : 'Marked all as read');
                  this.setState({ showNotifModal: false });
                }}
                style={{
                  height: '44px',
                  borderRadius: '22px',
                  border: 0,
                  background: v.accent,
                  color: '#FFFFFF',
                  fontWeight: '800',
                  fontSize: '14px',
                  cursor: 'pointer',
                  marginTop: '6px',
                }}
              >
                {isAr ? 'تمت القراءة' : 'Dismiss'}
              </button>
            </div>
          </div>
        )}

        {/* Bottom Navigation */}
        <BottomNav
          active="trends"
          accent={v.accent}
          glow={v.glow}
          onNavigate={this.props.onNavigate}
        />
      </div>
    );
  }
}
