import { useState } from 'react';
import { BookOpenCheck, ChevronDown, CheckCircle2, ListChecks } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { ProgressBar, SectionHeader } from '../components/ui/Card';
import { subjects } from '../data/content';
import { CURRICULUM_UNITS } from '../data/curriculum/units';
import {
  curriculumSubjectProgress,
  curriculumUnitProgress,
  getCurriculumChecklistItems,
  overallCurriculumProgress,
  setCurriculumItemCompleted,
  type CurriculumCompletionState,
} from '../services/curriculumProgress';
import { KEYS, useStored } from '../services/storage';

export default function CurriculumTracker() {
  const saved = useStored<CurriculumCompletionState>(KEYS.curriculumProgress, {});
  const overall = overallCurriculumProgress(saved);
  const [subjectFilter, setSubjectFilter] = useState('all');
  const visibleSubjects = subjectFilter === 'all'
    ? subjects
    : subjects.filter((subject) => subject.id === subjectFilter);

  return (
    <div>
      <PageHeader
        eyebrow="من وحدات الكتاب إلى إنجاز يومي"
        title="إنجاز المنهاج"
        subtitle="علّم كل درس أو فكرة بعد إنجازها. النسب محسوبة من البنود الرسمية المفهرسة، وتُحفظ تلقائياً على جهازك."
      />

      <section className="card mb-5 overflow-hidden p-4 sm:p-5">
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <p className="text-xs text-[var(--ink-soft)]">التقدم الشامل في المواد الثماني</p>
            <p className="mt-1 text-sm text-[var(--ink)]">
              {overall.completed.toLocaleString('ar-SY')} من {overall.total.toLocaleString('ar-SY')} درساً أو فكرة
            </p>
          </div>
          <strong className="font-display text-3xl text-[var(--gold)]">{overall.percent.toLocaleString('ar-SY')}٪</strong>
        </div>
        <ProgressBar value={overall.percent} height={10} label="التقدم الشامل في المنهاج" />
        <p className="mt-3 text-[0.68rem] leading-relaxed text-[var(--ink-soft)]">
          يُحسب المقياس من البنود المكتملة ÷ مجموع البنود المفهرسة، وليس من متوسط المواد. في الفصول التي لا تتوفر لها عناوين دروس فرعية موثقة، يُتابع إكمال الفصل نفسه دون اختلاق عناوين.
        </p>
      </section>

      <section className="mb-5">
        <SectionHeader title="مقياس كل مادة" hint="اضغط مادة لعرض وحداتها" />
        <div className="grid gap-2 sm:grid-cols-2">
          {subjects.map((subject) => {
            const summary = curriculumSubjectProgress(subject.id, saved);
            const active = subjectFilter === subject.id;
            return (
              <button
                key={subject.id}
                type="button"
                aria-pressed={active}
                onClick={() => setSubjectFilter(active ? 'all' : subject.id)}
                className={`focus-ring card min-h-20 p-3 text-start transition-colors ${active ? 'ring-2 ring-[var(--gold)]' : ''}`}
              >
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="truncate text-xs font-semibold text-[var(--ink)]">{subject.name}</span>
                  <span className="font-display text-sm" style={{ color: subject.color }}>{summary.percent.toLocaleString('ar-SY')}٪</span>
                </div>
                <ProgressBar value={summary.percent} height={5} color={subject.color} label={`إنجاز مادة ${subject.name}`} />
                <span className="mt-1.5 block text-[0.62rem] text-[var(--ink-soft)]">
                  {summary.completed.toLocaleString('ar-SY')} / {summary.total.toLocaleString('ar-SY')} بند
                </span>
              </button>
            );
          })}
        </div>
        {subjectFilter !== 'all' ? (
          <button type="button" onClick={() => setSubjectFilter('all')} className="focus-ring mt-2 min-h-10 rounded-xl px-3 text-xs text-[var(--brand)] underline-offset-4 hover:underline">
            عرض كل المواد
          </button>
        ) : null}
      </section>

      <section>
        <SectionHeader title={subjectFilter === 'all' ? 'الوحدات والدروس والأفكار' : `وحدات ${visibleSubjects[0]?.name ?? ''}`} hint="افتح المادة ثم الوحدة" />
        <div className="space-y-3">
          {visibleSubjects.map((subject) => {
            const units = CURRICULUM_UNITS.filter((unit) => unit.subjectId === subject.id);
            const summary = curriculumSubjectProgress(subject.id, saved);
            return (
              <details key={subject.id} className="card overflow-hidden">
                <summary className="flex min-h-14 cursor-pointer list-none items-center gap-3 p-3.5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl" style={{ backgroundColor: subject.colorSoft, color: subject.color }}>
                    <ListChecks size={17} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold text-[var(--ink)]">{subject.name}</span>
                    <span className="mt-0.5 block text-[0.62rem] text-[var(--ink-soft)]">{summary.completed.toLocaleString('ar-SY')} من {summary.total.toLocaleString('ar-SY')} · {summary.percent.toLocaleString('ar-SY')}٪</span>
                  </span>
                  <ChevronDown size={17} className="shrink-0 text-[var(--ink-soft)]" />
                </summary>
                <div className="space-y-2 border-t border-[var(--line)] p-2.5 sm:p-3">
                  {units.map((unit) => {
                    const items = getCurriculumChecklistItems(unit);
                    const unitSummary = curriculumUnitProgress(unit, saved);
                    return (
                      <details key={unit.id} className="rounded-2xl bg-[var(--surface-2)]">
                        <summary className="flex min-h-14 cursor-pointer list-none items-center gap-3 p-3">
                          <span className="min-w-0 flex-1">
                            <span className="block text-xs font-semibold leading-relaxed text-[var(--ink)]">{unit.title}</span>
                            <span className="mt-0.5 block text-[0.62rem] text-[var(--ink-soft)]">{unitSummary.completed.toLocaleString('ar-SY')} / {unitSummary.total.toLocaleString('ar-SY')} · {unitSummary.percent.toLocaleString('ar-SY')}٪</span>
                          </span>
                          <span className="w-16 shrink-0"><ProgressBar value={unitSummary.percent} height={5} color={subject.color} label={`إنجاز ${unit.title}`} /></span>
                          <ChevronDown size={15} className="shrink-0 text-[var(--ink-soft)]" />
                        </summary>
                        <div className="divide-y divide-[var(--line)] border-t border-[var(--line)] px-2 sm:px-3">
                          {items.map((item) => {
                            const complete = Boolean(saved[item.id]);
                            const testUrl = item.kind === 'lesson' && item.questionCount > 0
                              ? `/practice/${unit.subjectId}/${unit.id}?lessonId=${encodeURIComponent(item.id)}`
                              : undefined;
                            return (
                              <div key={item.id} className="flex min-h-16 items-center gap-2 py-2.5">
                                <label className="flex min-w-0 flex-1 cursor-pointer items-start gap-2.5 py-1">
                                  <input
                                    type="checkbox"
                                    checked={complete}
                                    onChange={(event) => void setCurriculumItemCompleted(item.id, event.target.checked)}
                                    aria-label={`${complete ? 'إلغاء إنجاز' : 'تحديد إنجاز'}: ${item.title}`}
                                    className="mt-0.5 h-5 w-5 shrink-0 cursor-pointer rounded accent-[var(--gold)]"
                                  />
                                  <span className="min-w-0">
                                    <span className={`block text-xs leading-relaxed ${complete ? 'font-semibold text-[var(--ink)]' : 'text-[var(--ink)]'}`}>{item.title}</span>
                                    {item.kind === 'chapter' ? (
                                      <span className="mt-1 block text-[0.6rem] leading-relaxed text-[var(--ink-soft)]">لا تتوفر عناوين دروس فرعية موثقة لهذا الفصل في الفهرس الحالي.</span>
                                    ) : null}
                                  </span>
                                </label>
                                {testUrl ? (
                                  <Link to={testUrl} className="focus-ring flex min-h-10 shrink-0 items-center justify-center gap-1 rounded-xl bg-[var(--brand)] px-2.5 text-[0.65rem] font-semibold text-[var(--brand-ink)]">
                                    <BookOpenCheck size={14} /> اختبار · {item.questionCount.toLocaleString('ar-SY')}
                                  </Link>
                                ) : (
                                  <button type="button" disabled title="لا يوجد اختبار موثق لهذه الفكرة بعد" className="flex min-h-10 shrink-0 items-center justify-center gap-1 rounded-xl border border-[var(--line)] px-2 text-[0.6rem] text-[var(--ink-soft)] opacity-75">
                                    <CheckCircle2 size={13} /> قيد الإعداد
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </details>
                    );
                  })}
                </div>
              </details>
            );
          })}
        </div>
      </section>

      <p className="mt-4 rounded-2xl bg-[var(--surface-2)] p-3 text-[0.65rem] leading-relaxed text-[var(--ink-soft)]">
        عناوين الوحدات والدروس مأخوذة من خريطة المنهاج الرسمية المتاحة. الاختبار يفتح فقط عندما تكون أسئلة الفكرة موثقة ومنشورة؛ لا يُنشأ محتوى غير موثق لملء الفراغ.
      </p>
    </div>
  );
}
