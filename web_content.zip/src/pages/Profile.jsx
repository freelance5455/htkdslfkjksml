import React from 'react';
import { CalsenBase } from '../lib/CalsenBase';
import { go, ROUTES, css } from '../lib/calsen';
import BottomNav from '../components/BottomNav';
import { logoutFirebase, deleteAccountFromFirebase } from '../lib/firebaseService';
import { getCurrentLang, setLanguage, t } from '../lib/i18n';

export default class ProfilePage extends CalsenBase {
  static defaultProps = {"accent": "#FF5C00", "theme": "sync"};
  lighten(hex, t) {
    if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return hex;
    const n = parseInt(hex.slice(1), 16);
    const f = (c) => Math.round(c + (255 - c) * t).toString(16).padStart(2, '0');
    return '#' + f((n >> 16) & 255) + f((n >> 8) & 255) + f(n & 255);
  }
  accentFor(base, dark) {
    if (!dark) return base;
    return base === "#FF5C00" ? "#FF8312" : this.lighten(base, 0.2);
  }
  glowOf(hex, a) {
    if (this.isDark(this.modeNow())) a = (Number(a) * 0.62).toFixed(2);
    if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return 'rgba(255,92,0,' + a + ')';
    const n = parseInt(hex.slice(1), 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  stored() {
    try {
      const v = window.localStorage.getItem('plateful-theme');
      return v === 'light' || v === 'dark' || v === 'auto' ? v : null;
    } catch (e) { return null; }
  }
  modeNow() {
    const st = this.state || {};
    if (st.mode) return st.mode;
    const p = this.props.theme ?? 'sync';
    if (p === 'light' || p === 'dark' || p === 'auto') return p;
    return this.stored() || 'light';
  }
  isDark(m) {
    if (m === 'dark') return true;
    if (m === 'auto') {
      try { return window.matchMedia('(prefers-color-scheme: dark)').matches; } catch (e) { return false; }
    }
    return false;
  }
  setMode(m) {
    try { window.localStorage.setItem('plateful-theme', m); } catch (e) {}
    this.setState({ mode: m });
  }
  componentDidMount() {
    this._langListener = (e) => {
      this.setState({ lang: e.detail || getCurrentLang() });
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('calsen-lang-change', this._langListener);
    }
  }
  componentWillUnmount() {
    if (typeof window !== 'undefined' && this._langListener) {
      window.removeEventListener('calsen-lang-change', this._langListener);
    }
  }
  defs() {
    let savedCur = 72;
    let savedGoal = 65;
    let savedHt = 175;
    let savedGender = 'Male';
    let savedDob = '2000-01-01';
    let savedName = 'Your name';
    let savedCals = 2150;
    let savedLang = getCurrentLang();
    try {
      if (typeof window !== 'undefined') {
        const w = Number(window.localStorage.getItem('calsen-weight'));
        if (w > 0) savedCur = w;
        const gw = Number(window.localStorage.getItem('calsen-goal-weight'));
        if (gw > 0) savedGoal = gw;
        const ht = Number(window.localStorage.getItem('calsen-height'));
        if (ht > 0) savedHt = ht;
        const gen = window.localStorage.getItem('calsen-gender');
        if (gen) savedGender = gen;
        const d = window.localStorage.getItem('calsen-dob');
        if (d) savedDob = d;
        const n = window.localStorage.getItem('calsen-name');
        if (n) savedName = n;
        const c = Number(window.localStorage.getItem('calsen-target-cals'));
        if (c > 0) savedCals = c;
      }
    } catch (e) {}

    return {
      units: 'metric', cur: savedCur, goal: savedGoal, ht: savedHt, steps: 10000, gender: savedGender, dob: savedDob,
      P: 150, C: 200, F: 67, fiber: 38, sugar: 101, sodium: 2300, micro: false,
      rem: [true, true, true, true, true], badges: true, burned: true, rollover: true,
      lang: savedLang, widgetHelp: false, range: '7', from: '', to: '', email: '', sent: false,
      name: savedName, editName: false, nameDraft: '',
      dlg: '', toast: '', copied: false, page: 'menu'
    };
  }
  S() { return Object.assign(this.defs(), this.state || {}); }
  bump(key, delta, min, max, dp) {
    const v = Number(this.S()[key]) + delta;
    const c = Math.min(max, Math.max(min, v));
    const finalVal = Number(c.toFixed(dp));
    this.setState({ [key]: finalVal });
    try {
      if (typeof window !== 'undefined') {
        if (key === 'cur') window.localStorage.setItem('calsen-weight', String(finalVal));
        if (key === 'goal') window.localStorage.setItem('calsen-goal-weight', String(finalVal));
        if (key === 'ht') window.localStorage.setItem('calsen-height', String(finalVal));
        if (key === 'steps') window.localStorage.setItem('calsen-steps', String(finalVal));
      }
    } catch (e) {}
  }
  flip(key) { this.setState({ [key]: !this.S()[key] }); }
  say(msg) {
    this.setState({ toast: msg });
    setTimeout(() => { this.setState({ toast: '' }); }, 2800);
  }
  renderVals() {
    const s = this.S();
    const isAr = getCurrentLang() === 'العربية';
    const mode = this.modeNow();
    const dark = this.isDark(mode);
    const base = this.props.accent ?? '#FF5C00';
    const accent = this.accentFor(base, dark);
    const SUN = 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M12 2v2 M12 20v2 M2 12h2 M20 12h2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4';
    const MOON = 'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z';
    const HALF = 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 3v18';

    const imp = s.units === 'imperial';
    const wFmt = (kg) => (imp ? (kg * 2.20462).toFixed(1) + ' lb' : kg.toFixed(1) + ' kg');
    const hFmt = (cm) => {
      if (!imp) return cm + ' cm';
      const tot = cm / 2.54;
      let ft = Math.floor(tot / 12);
      let inch = Math.round(tot - ft * 12);
      if (inch === 12) { ft += 1; inch = 0; }
      return ft + ' ft ' + inch + ' in';
    };
    const diff = Math.round((s.goal - s.cur) * 10) / 10;
    const diffAbs = Math.abs(diff);
    const diffFmt = imp ? (diffAbs * 2.20462).toFixed(1) + ' lb' : diffAbs.toFixed(1) + ' kg';
    const journey = diff > 0 ? 'Gain ' + diffFmt + ' to reach your goal' : diff < 0 ? 'Lose ' + diffFmt + ' to reach your goal' : 'You are right on your goal';

    const ageOf = (iso) => {
      const parts = String(iso).split('-').map(Number);
      if (parts.length !== 3 || parts.some((x) => isNaN(x))) return '';
      const t = new Date();
      let a = t.getFullYear() - parts[0];
      const m = t.getMonth() + 1 - parts[1];
      if (m < 0 || (m === 0 && t.getDate() < parts[2])) a -= 1;
      return a >= 0 ? a + ' years old' : '';
    };

    const segOf = (opts, cur, pick) => opts.map((o) => {
      const on = o.v === cur;
      return {
        label: o.label,
        icon: o.icon || '',
        pressed: on ? 'true' : 'false',
        bg: on ? 'var(--seg-on)' : 'transparent',
        ink: on ? 'var(--ink)' : 'var(--muted)',
        weight: on ? '800' : '600',
        shadow: on ? '0 2px 8px var(--sh)' : 'none',
        pick: () => pick(o.v)
      };
    });
    const sw = (on) => ({
      on: on,
      trackBg: on ? accent : 'var(--off)',
      knob: on ? 'var(--on-accent)' : 'var(--knob-off)',
      justify: on ? 'flex-end' : 'flex-start'
    });

    const kcalNum = s.P * 4 + s.C * 4 + s.F * 9;
    const kcal = kcalNum.toLocaleString('en-US');
    const macroDefs = [
      { k: 'P', label: 'Protein', color: '#6366F1', mult: 4 },
      { k: 'C', label: 'Carbs', color: '#F59E0B', mult: 4 },
      { k: 'F', label: 'Fat', color: '#10B981', mult: 9 }
    ];
    const macroRows = macroDefs.map((m) => {
      const kc = s[m.k] * m.mult;
      return {
        label: m.label,
        color: m.color,
        value: s[m.k] + ' g',
        sub: kc.toLocaleString('en-US') + ' kcal',
        share: String(Math.max(kc, 1)),
        pct: kcalNum > 0 ? Math.round((kc * 100) / kcalNum) + '%' : '0%',
        decLabel: 'Lower ' + m.label.toLowerCase() + ' target',
        incLabel: 'Raise ' + m.label.toLowerCase() + ' target',
        dec: () => this.bump(m.k, -5, 0, 999, 0),
        inc: () => this.bump(m.k, 5, 0, 999, 0)
      };
    });
    const microDefs = [
      { k: 'fiber', label: 'Fiber', unit: ' g', step: 1, max: 200 },
      { k: 'sugar', label: 'Sugar limit', unit: ' g', step: 1, max: 500 },
      { k: 'sodium', label: 'Sodium limit', unit: ' mg', step: 50, max: 10000 }
    ];
    const microRows = microDefs.map((m) => ({
      label: m.label,
      value: Number(s[m.k]).toLocaleString('en-US') + m.unit,
      decLabel: 'Lower ' + m.label.toLowerCase(),
      incLabel: 'Raise ' + m.label.toLowerCase(),
      dec: () => this.bump(m.k, -m.step, 0, m.max, 0),
      inc: () => this.bump(m.k, m.step, 0, m.max, 0)
    }));

    const bodyRows = [
      { label: 'Current weight', value: wFmt(s.cur), decLabel: 'Lower current weight', incLabel: 'Raise current weight', dec: () => this.bump('cur', -0.1, 20, 300, 1), inc: () => this.bump('cur', 0.1, 20, 300, 1) },
      { label: 'Goal weight', value: wFmt(s.goal), decLabel: 'Lower goal weight', incLabel: 'Raise goal weight', dec: () => this.bump('goal', -0.1, 20, 300, 1), inc: () => this.bump('goal', 0.1, 20, 300, 1) },
      { label: 'Height', value: hFmt(s.ht), decLabel: 'Lower height', incLabel: 'Raise height', dec: () => this.bump('ht', -1, 100, 230, 0), inc: () => this.bump('ht', 1, 100, 230, 0) },
      { label: 'Daily steps', value: Number(s.steps).toLocaleString('en-US'), decLabel: 'Lower step goal', incLabel: 'Raise step goal', dec: () => this.bump('steps', -500, 0, 60000, 0), inc: () => this.bump('steps', 500, 0, 60000, 0) }
    ];

    const remDefs = [['Breakfast', '8:30 AM'], ['Lunch', '12:00 PM'], ['Snack', '3:00 PM'], ['Dinner', '7:00 PM'], ['End of day', '9:00 PM']];
    const reminders = remDefs.map((r, i) => Object.assign({
      name: r[0],
      time: r[1],
      aria: 'Remind me at ' + r[1] + ' for ' + r[0].toLowerCase(),
      hasSub: i === 4,
      sub: 'One reminder a day to log all your meals at once.',
      toggle: () => {
        const arr = this.S().rem.slice();
        arr[i] = !arr[i];
        this.setState({ rem: arr });
      }
    }, sw(s.rem[i])));

    const prefDefs = [
      { k: 'badges', title: 'Badge celebrations', sub: 'Celebrate when you unlock a new badge' },
      { k: 'burned', title: 'Count burned calories', sub: 'Add calories you burn to your daily goal' },
      { k: 'rollover', title: 'Roll over calories', sub: 'Carry up to 200 unused kcal from yesterday into today' }
    ];
    const prefRows = prefDefs.map((p) => Object.assign({
      title: p.title,
      sub: p.sub,
      aria: p.title,
      toggle: () => this.flip(p.k)
    }, sw(s[p.k])));

    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s.email).trim());
    const dlg = s.dlg;
    const saveName = () => {
      const v = String(this.S().nameDraft || '').trim().slice(0, 30);
      const nm = v || 'Your name';
      try { window.localStorage.setItem('calsen-name', nm); } catch (e) {}
      this.setState({ name: nm, editName: false });
      this.say('Name saved');
    };

    const weightRows = bodyRows.slice(0, 2);
    const heightRows = bodyRows.slice(2, 3);
    const stepRows = bodyRows.slice(3, 4);
    const pg = s.page || 'menu';
    const TITLES = {
      menu: t('profile.title', 'Profile'),
      details: t('profile.details', 'Personal details'),
      prefs: t('profile.prefs', 'Preferences'),
      language: t('profile.language', 'Language'),
      targets: t('profile.targets', 'Nutrition goals'),
      weight: t('profile.weight', 'Goal & weight'),
      steps: t('profile.steps', 'Daily step goal'),
      reminders: t('profile.reminders', 'Reminders'),
      history: t('profile.history', 'Weight history'),
      rings: 'Calendar rings',
      widgets: t('profile.widgets', 'Widgets'),
      report: t('profile.report', 'Summary report')
    };
    const go = (k) => () => {
      this.setState({ page: k });
      try { const el = document.querySelector('.scroll'); if (el) el.scrollTop = 0; } catch (e) {}
    };
    const kcalNow = Math.round(4 * s.P + 4 * s.C + 9 * s.F).toLocaleString('en-US');
    const remOn = s.rem.filter(Boolean).length;

    return {
      nameText: s.name || 'Your name',
      nameView: !s.editName,
      nameEdit: !!s.editName,
      nameDraft: s.nameDraft,
      startName: () => {
        this.setState({ editName: true, nameDraft: s.name === 'Your name' ? '' : s.name });
        setTimeout(() => { try { const el = document.getElementById('name-input'); if (el) { el.focus(); el.select(); } } catch (e) {} }, 60);
      },
      onName: (e) => this.setState({ nameDraft: String(e.target.value).slice(0, 30) }),
      onNameKey: (e) => {
        if (e.key === 'Enter') saveName();
        else if (e.key === 'Escape') this.setState({ editName: false });
      },
      saveName: () => saveName(),
      weightRows, heightRows, stepRows,
      titleSize: pg === 'menu' ? '28px' : '22px',
      isMenu: pg === 'menu', inSub: pg !== 'menu', pageTitle: TITLES[pg] || 'Profile',
      isDetails: pg === 'details', isPrefs: pg === 'prefs', isLanguage: pg === 'language', isTargets: pg === 'targets',
      isWeight: pg === 'weight', isSteps: pg === 'steps', isReminders: pg === 'reminders', isHistory: pg === 'history',
      isRings: pg === 'rings', isWidgets: pg === 'widgets', isReport: pg === 'report',
      goMenu: go('menu'),
      open_details: go('details'), open_prefs: go('prefs'), open_language: go('language'), open_targets: go('targets'),
      open_weight: go('weight'), open_steps: go('steps'), open_reminders: go('reminders'), open_history: go('history'),
      open_rings: go('rings'), open_widgets: go('widgets'), open_report: go('report'),
      comingSoon: () => this.say('Preview only: this page is not connected yet.'),
      subDetails: hFmt(s.ht) + ' \u00b7 ' + s.gender + ' \u00b7 ' + ageOf(s.dob),
      subPrefs: (dark ? 'Dark' : 'Light') + ' \u00b7 ' + (s.units === 'metric' ? 'Metric' : 'Imperial'),
      subLanguage: s.lang,
      subTargets: kcalNow + ' kcal a day',
      subWeight: wFmt(s.cur) + ' now \u00b7 goal ' + wFmt(s.goal),
      subSteps: Number(s.steps).toLocaleString('en-US') + ' steps a day',
      subReminders: remOn + ' of 5 on',
      subHistory: 'Last weigh-in: ' + wFmt(s.cur),
      accent,
      glow: this.glowOf(accent, dark ? 0.4 : 0.25),
      bannerShadow: dark ? '0 0 32px ' + this.glowOf(accent, 0.28) : '0 10px 24px ' + this.glowOf(accent, 0.28),
      bannerChip: dark ? 'rgba(11,15,23,.16)' : 'rgba(255,255,255,.24)',
      themeKey: dark ? 'dark' : 'light',
      themeIcon: dark ? SUN : MOON,
      themeAria: dark ? 'Switch to day mode' : 'Switch to night mode',
      toggleTheme: () => this.setMode(dark ? 'light' : 'dark'),

      age: ageOf(s.dob),
      profileHeight: hFmt(s.ht),
      profileWeight: wFmt(s.cur),
      profileGoal: wFmt(s.goal),

      unitSeg: segOf([{ v: 'metric', label: isAr ? 'متري (كجم، سم)' : 'Metric (kg, cm)' }, { v: 'imperial', label: isAr ? 'إمبراطوري (باوند، قدم)' : 'Imperial (lb, ft)' }], s.units, (v) => {
        try { window.localStorage.setItem('calsen-units', v); } catch(e) {}
        this.setState({ units: v });
      }),
      genderSeg: segOf([
        { v: 'Male', label: isAr ? 'ذكر' : 'Male' },
        { v: 'Female', label: isAr ? 'أنثى' : 'Female' },
        { v: 'Other', label: isAr ? 'آخر' : 'Other' }
      ], s.gender, (v) => {
        try { window.localStorage.setItem('calsen-gender', v); } catch(e) {}
        this.setState({ gender: v });
      }),
      nowLabel: wFmt(s.cur),
      goalLabel: wFmt(s.goal),
      journey,
      bodyRows,
      dob: s.dob,
      onDob: (e) => {
        const v = e.target.value;
        try { window.localStorage.setItem('calsen-dob', v); } catch(e) {}
        this.setState({ dob: v });
      },
      isAr,
      saveDetails: () => {
        try {
          const st = this.S();
          window.localStorage.setItem('calsen-name', String(st.name || ''));
          window.localStorage.setItem('calsen-weight', String(st.cur));
          window.localStorage.setItem('calsen-goal-weight', String(st.goal));
          window.localStorage.setItem('calsen-height', String(st.ht));
          window.localStorage.setItem('calsen-steps', String(st.steps));
          window.localStorage.setItem('calsen-gender', String(st.gender));
          window.localStorage.setItem('calsen-dob', String(st.dob));
        } catch(e) {}
        this.say(isAr ? 'تم حفظ وتحديث البيانات بنجاح ✨' : 'Personal details updated successfully ✨');
      },

      kcal,
      macroRows,
      resetTargets: () => this.setState({ P: 150, C: 200, F: 67, fiber: 38, sugar: 101, sodium: 2300 }),
      microOpen: s.micro,
      microExpanded: s.micro ? 'true' : 'false',
      microLabel: s.micro ? 'Hide micronutrient limits' : 'Show micronutrient limits',
      microChevron: s.micro ? 'M6 15l6-6 6 6' : 'M6 9l6 6 6-6',
      toggleMicro: () => this.flip('micro'),
      microRows,

      reminders,

      modeSeg: segOf([{ v: 'light', label: 'Light', icon: SUN }, { v: 'dark', label: 'Dark', icon: MOON }, { v: 'auto', label: 'Auto', icon: HALF }], mode, (v) => this.setMode(v)),
      prefRows,
      lang: s.lang,
      onLang: (e) => {
        const nextLang = e.target.value;
        setLanguage(nextLang);
        this.setState({ lang: nextLang });
        this.say(`${t('toast.lang_updated', 'Language updated')} ${nextLang}`);
      },
      setLangDirect: (nextLang) => {
        setLanguage(nextLang);
        this.setState({ lang: nextLang });
        this.say(`${t('toast.lang_updated', 'Language updated')} ${nextLang}`);
      },

      pLeft: s.P + 'g',
      cLeft: s.C + 'g',
      fLeft: s.F + 'g',
      widgetOpen: s.widgetHelp,
      widgetExpanded: s.widgetHelp ? 'true' : 'false',
      widgetChevron: s.widgetHelp ? 'M6 15l6-6 6 6' : 'M6 9l6 6 6-6',
      toggleWidgetHelp: () => this.flip('widgetHelp'),

      rangeSeg: segOf([{ v: '7', label: '7 days' }, { v: '30', label: '30 days' }, { v: 'all', label: 'All time' }, { v: 'custom', label: 'Custom' }], s.range, (v) => this.setState({ range: v })),
      customOpen: s.range === 'custom',
      from: s.from,
      to: s.to,
      onFrom: (e) => this.setState({ from: e.target.value }),
      onTo: (e) => this.setState({ to: e.target.value }),
      email: s.email,
      onEmail: (e) => this.setState({ email: e.target.value, sent: false }),
      sendOff: !emailOk,
      sendOpacity: emailOk ? '1' : '0.45',
      sentOn: s.sent && emailOk,
      send: () => {
        if (!emailOk) return;
        this.setState({ sent: true });
      },

      openLogout: () => this.setState({ dlg: 'logout' }),
      openDelete: () => this.setState({ dlg: 'delete' }),
      closeDlg: () => this.setState({ dlg: '' }),
      dlgOpen: dlg !== '',
      dlgDanger: dlg === 'delete',
      dlgNormal: dlg !== 'delete',
      dlgTitle: dlg === 'delete' ? t('profile.delete_confirm_title', 'Delete your account permanently?') : t('profile.logout_confirm_title', 'Log out of CalSen?'),
      dlgBody: dlg === 'delete' ? t('profile.delete_confirm_body', 'This permanently removes your account, authentication, and all food records from Firebase. This cannot be undone.') : t('profile.logout_confirm_body', 'You can log back in any time with your email or Google account.'),
      dlgConfirm: dlg === 'delete' ? t('profile.delete_account', 'Delete account') : t('profile.logout', 'Log out'),
      dlgCancel: t('profile.cancel', 'Cancel'),
      confirmDlg: async () => {
        const was = this.S().dlg;
        this.setState({ dlg: '' });
        if (was === 'logout') {
          try {
            await logoutFirebase();
            this.say(t('toast.logged_out', 'Logged out successfully'));
            setTimeout(() => {
              if (this.props.onNavigate) this.props.onNavigate('welcome');
              else if (typeof window !== 'undefined') window.location.reload();
            }, 600);
          } catch (err) {
            console.warn('Logout error:', err);
            this.say('Error logging out');
          }
        } else if (was === 'delete') {
          try {
            await deleteAccountFromFirebase();
            this.say(t('toast.account_deleted', 'Account permanently deleted from Firebase'));
            setTimeout(() => {
              if (this.props.onNavigate) this.props.onNavigate('welcome');
              else if (typeof window !== 'undefined') window.location.reload();
            }, 600);
          } catch (err) {
            console.warn('Delete account error:', err);
            this.say('Error deleting account');
          }
        }
      },
      labelAccountActions: t('profile.account_actions', 'Account actions'),
      labelLogout: t('profile.logout', 'Log out'),
      labelDelete: t('profile.delete_account', 'Delete account'),
      toastOn: s.toast !== '',
      toast: s.toast
    };
  }

  render() {
    const v = this.renderVals();
    return (
      <div
        className="app"
        data-theme={v.themeKey}
        style={{
          position: 'relative',
          width: '390px',
          height: '844px',
          boxSizing: 'border-box',
          fontFamily: '\'Plus Jakarta Sans\', system-ui, sans-serif',
          overflow: 'hidden',
        }}
      >
        <div
          className="scroll"
          style={{
            position: 'absolute',
            left: '0',
            top: '0',
            right: '0',
            bottom: '0',
            overflowY: 'auto',
            overflowX: 'hidden',
            overscrollBehavior: 'contain',
          }}
        >
          <div
            style={{
              boxSizing: 'border-box',
              padding: '24px 20px 4px 20px',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
            }}
          >
            {v.inSub && (
              <>
                <button className="rbtn" aria-label="Back to settings" onClick={v.goMenu}>
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M15 5l-7 7 7 7"></path>
                  </svg>
                </button>
              </>
            )}
            <h1
              style={{
                flex: '1',
                minWidth: '0',
                margin: '0',
                fontSize: v.titleSize,
                lineHeight: '34px',
                fontWeight: '800',
                letterSpacing: '-0.03em',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >{v.pageTitle}</h1>
            <button className="rbtn" aria-label={v.themeAria} onClick={v.toggleTheme}>
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.9"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d={v.themeIcon}></path>
              </svg>
            </button>
          </div>
          <div
            className="stagger"
            style={{
              boxSizing: 'border-box',
              padding: '16px 20px 112px 20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
            }}
          >
            {v.isMenu && (
              <>
                <div
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                    <div
                      aria-hidden="true"
                      style={{
                        width: '64px',
                        height: '64px',
                        borderRadius: '32px',
                        background: v.accent,
                        color: 'var(--on-accent)',
                        boxShadow: `0 8px 20px ${v.glow}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <circle cx="12" cy="8" r="4"></circle>
                        <path d="M4 21c0-4 4-6 8-6s8 2 8 6"></path>
                      </svg>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '2px',
                        minWidth: '0',
                      }}
                    >
                      {v.nameView && (
                        <>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <div
                              style={{
                                fontSize: '20px',
                                lineHeight: '26px',
                                fontWeight: '800',
                                letterSpacing: '-0.02em',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                maxWidth: '170px',
                              }}
                            >{v.nameText}</div>
                            <button
                              aria-label="Edit name"
                              style={{
                                width: '32px',
                                height: '32px',
                                borderRadius: '16px',
                                border: '0',
                                background: 'var(--chip)',
                                color: 'var(--muted)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                padding: '0',
                                cursor: 'pointer',
                                flex: 'none',
                              }}
                              onClick={v.startName}
                            >
                              <svg
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                aria-hidden="true"
                              >
                                <path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3z"></path>
                                <path d="M13.5 7.5l3 3"></path>
                              </svg>
                            </button>
                          </div>
                        </>
                      )}
                      {v.nameEdit && (
                        <>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input
                              id="name-input"
                              type="text"
                              value={v.nameDraft}
                              onChange={v.onName}
                              onKeyDown={v.onNameKey}
                              maxLength="30"
                              placeholder="Your name"
                              aria-label="Your name"
                              autoComplete="off"
                              style={{
                                height: '40px',
                                minWidth: '0',
                                width: '100%',
                                boxSizing: 'border-box',
                                borderRadius: '14px',
                                border: `1.5px solid ${v.accent}`,
                                background: 'var(--chip)',
                                color: 'var(--ink)',
                                padding: '0 12px',
                                fontSize: '17px',
                                fontWeight: '700',
                              }}
                             />
                            <button
                              aria-label="Save name"
                              style={{
                                width: '40px',
                                height: '40px',
                                borderRadius: '20px',
                                border: '0',
                                background: v.accent,
                                color: '#FFFFFF',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                padding: '0',
                                cursor: 'pointer',
                                flex: 'none',
                              }}
                              onClick={v.saveName}
                            >
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.6"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                aria-hidden="true"
                              >
                                <path d="M5 12.5l4.5 4.5L19 7.5"></path>
                              </svg>
                            </button>
                          </div>
                        </>
                      )}
                      <div style={{ fontSize: '14px', color: 'var(--muted)' }}>{v.age}</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    <span
                      style={{
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--chip)',
                        border: '1px solid var(--edge)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >{v.profileHeight}</span>
                    <span
                      style={{
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--chip)',
                        border: '1px solid var(--edge)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >{v.profileWeight} now</span>
                    <span
                      style={{
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >Goal {v.profileGoal}</span>
                  </div>
                </div>
                <a
                  href={ROUTES.referrals}
                  className="press"
                  aria-label="Referral and Rewards Hub"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '14px',
                    borderRadius: '24px',
                    padding: '18px 16px 18px 18px',
                    background: v.accent,
                    color: 'var(--on-accent)',
                    boxShadow: v.bannerShadow,
                    textDecoration: 'none',
                  }}
                  onClick={(e) => { go(e, 'referrals', this.props); }}
                >
                  <span
                    style={{
                      flex: '1',
                      minWidth: '0',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '18px',
                        lineHeight: '24px',
                        fontWeight: '800',
                        letterSpacing: '-0.02em',
                      }}
                    >🎁 Referral &amp; Rewards Hub</span>
                    <span
                      style={{
                        fontSize: '14px',
                        lineHeight: '20px',
                        fontWeight: '600',
                        opacity: '0.88',
                      }}
                    >
                      Invite friends and earn free Premium, up to lifetime access.
                    </span>
                  </span>
                  <span
                    aria-hidden="true"
                    style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '18px',
                      background: v.bannerChip,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flex: 'none',
                    }}
                  >
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M9 5l7 7-7 7"></path>
                    </svg>
                  </span>
                </a>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <h2
                    style={{
                      margin: '0 0 0 4px',
                      fontSize: '15px',
                      lineHeight: '20px',
                      fontWeight: '700',
                      color: 'var(--muted)',
                    }}
                  >Account</h2>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '24px',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_details}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 5h16v14H4z M9 11.5a2 2 0 1 0 0-.01 M6.5 16c.6-1.4 1.6-2 2.5-2s1.9.6 2.5 2 M14 10h3.5 M14 13.5h3.5"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Personal details</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subDetails}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_prefs}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 7h10 M18 7h2 M14 7a2 2 0 1 0 4 0 2 2 0 1 0-4 0z M4 17h2 M10 17h10 M6 17a2 2 0 1 0 4 0 2 2 0 1 0-4 0z"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Preferences</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subPrefs}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_language}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 5h9 M8.5 3v2 M6 5c.5 4 3 7 6 8.5 M11 5c-.5 4-3 7.5-7 9 M13 21l4-10 4 10 M14.4 18h5.2"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Language</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subLanguage}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <h2
                    style={{
                      margin: '0 0 0 4px',
                      fontSize: '15px',
                      lineHeight: '20px',
                      fontWeight: '700',
                      color: 'var(--muted)',
                    }}
                  >Goals &amp; tracking</h2>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '24px',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_targets}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M12 3a9 9 0 1 0 9 9 M12 3v9h9"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Edit nutrition goals</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subTargets}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_weight}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M5 21V4 M5 4h12l-2 4 2 4H5"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Goal &amp; current weight</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subWeight}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_steps}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M14 4.5a1.6 1.6 0 1 0 0-.01 M11 21l2-6-3-3 1-5 3 2 3 1 M8 12l-2 3"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Daily step goal</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subSteps}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_reminders}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15z M10 21a2 2 0 0 0 4 0"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Tracking reminders</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subReminders}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_history}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M3 12a9 9 0 1 0 3-6.7 M3 4v4h4 M12 8v4l3 2"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Weight history</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >{v.subHistory}</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <h2
                    style={{
                      margin: '0 0 0 4px',
                      fontSize: '15px',
                      lineHeight: '20px',
                      fontWeight: '700',
                      color: 'var(--muted)',
                    }}
                  >Tools</h2>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '24px',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_rings}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Calendar rings</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >How the rings around each day work</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_widgets}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Home-screen widgets</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >Check your day without opening the app</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.open_report}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M7 3h7l4 4v14H7z M14 3v4h4 M10 12h5 M10 16h5"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Summary report</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >A PDF you can keep or share</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <h2
                    style={{
                      margin: '0 0 0 4px',
                      fontSize: '15px',
                      lineHeight: '20px',
                      fontWeight: '700',
                      color: 'var(--muted)',
                    }}
                  >Plans &amp; support</h2>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '24px',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.comingSoon}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path
                            d="M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M3 20c0-3.5 3-5.5 6-5.5 M16 11a2.5 2.5 0 1 0 0-5 M21 19c0-3-2-4.7-4.5-5"
                          ></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Family plan</span>
                        <span
                          style={{
                            fontSize: '13px',
                            lineHeight: '18px',
                            fontWeight: '600',
                            color: 'var(--muted)',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >Share one subscription with your household</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.comingSoon}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 10v4h3l7 4V6l-7 4H4z M18 9a4 4 0 0 1 0 6"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Request a feature</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.comingSoon}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M3 6h18v12H3z M3 7l9 7 9-7"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Contact support</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.comingSoon}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M7 3h7l4 4v14H7z M14 3v4h4 M10 12h5 M10 16h5"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Terms and conditions</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.comingSoon}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>Privacy policy</span>
                      </span>
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        style={{ stroke: 'var(--muted)', flex: 'none' }}
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <h2
                    style={{
                      margin: '0 0 0 4px',
                      fontSize: '15px',
                      lineHeight: '20px',
                      fontWeight: '700',
                      color: 'var(--muted)',
                    }}
                  >{v.labelAccountActions}</h2>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '24px',
                      overflow: 'hidden',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--ink)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.openLogout}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--soft-bg)',
                          color: 'var(--soft-ink)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M9 4H5v16h4 M16 8l4 4-4 4 M20 12H9"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>{v.labelLogout}</span>
                      </span>
                    </button>
                    <div aria-hidden="true" style={{ height: '1px', background: 'var(--line)', margin: '0 16px 0 70px' }}></div>
                    <button
                      className="mrow"
                      style={{
                        width: '100%',
                        minHeight: '64px',
                        boxSizing: 'border-box',
                        border: '0',
                        background: 'transparent',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '14px',
                        padding: '8px 16px',
                        cursor: 'pointer',
                        textAlign: 'left',
                        color: 'var(--danger)',
                        fontFamily: 'inherit',
                      }}
                      onClick={v.openDelete}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '14px',
                          background: 'var(--danger-bg)',
                          color: 'var(--danger)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                        }}
                      >
                        <svg
                          width="21"
                          height="21"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M5 7h14 M10 7V4h4v3 M7 7l1 13h8l1-13 M10 11v6 M14 11v6"></path>
                        </svg>
                      </span>
                      <span
                        style={{
                          flex: '1',
                          minWidth: '0',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '1px',
                        }}
                      >
                        <span style={{ fontSize: '16px', lineHeight: '22px', fontWeight: '700' }}>{v.labelDelete}</span>
                      </span>
                    </button>
                  </div>
                </div>
                <div style={{ textAlign: 'center', fontSize: '12px', color: 'var(--muted)' }}>CalSen · version 1.0 preview</div>
              </>
            )}
            {v.isDetails && (
              <>
                <section
                  className="glass rise"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M4 5h16v14H4z M9 11.5a2 2 0 1 0 0-.01 M6.5 16c.6-1.4 1.6-2 2.5-2s1.9.6 2.5 2 M14 10h3.5 M14 13.5h3.5"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >{v.isAr ? 'البيانات الشخصية' : 'Personal details'}</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>
                        {v.isAr ? 'تُستخدم لتخصيص خطتك وحساب السعرات بدقة' : 'Used to personalise your targets & nutrition'}
                      </span>
                    </div>
                  </div>

                  {/* Name field */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      padding: '8px 0',
                    }}
                  >
                    <span style={{ fontSize: '15px', fontWeight: '700' }}>
                      {v.isAr ? 'الاسم بالكامل' : 'Full name'}
                    </span>
                    <input
                      type="text"
                      value={v.nameText}
                      onChange={(e) => {
                        const val = e.target.value.slice(0, 30);
                        try { window.localStorage.setItem('calsen-name', val); } catch (err) {}
                        this.setState({ name: val });
                      }}
                      style={{
                        height: '42px',
                        width: '180px',
                        borderRadius: '12px',
                        border: '1px solid var(--edge)',
                        background: 'var(--chip)',
                        color: 'var(--ink)',
                        padding: '0 10px',
                        fontSize: '14px',
                        fontWeight: '700',
                        textAlign: v.isAr ? 'right' : 'left',
                        outline: 'none',
                      }}
                    />
                  </div>

                  {/* Current Weight, Goal Weight, Height, Steps rows */}
                  <div style={{ display: 'flex', flexDirection: 'column', borderTop: '1px solid var(--line)' }}>
                    {v.bodyRows.map((r, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '10px',
                            minHeight: '56px',
                            borderBottom: i1 < v.bodyRows.length - 1 ? '1px solid var(--line)' : 'none',
                          }}
                        >
                          <span style={{ fontSize: '15px', fontWeight: '600' }}>{r.label}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <button className="step" aria-label={r.decLabel} onClick={r.dec}>
                              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                            <span
                              style={{
                                minWidth: '76px',
                                textAlign: 'center',
                                fontSize: '15px',
                                fontWeight: '800',
                              }}
                            >{r.value}</span>
                            <button className="step" aria-label={r.incLabel} onClick={r.inc}>
                              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
                                <path d="M12 5v14"></path>
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>

                  {/* Gender Selector */}
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px',
                      paddingTop: '12px',
                      borderTop: '1px solid var(--line)',
                    }}
                  >
                    <div style={{ fontSize: '15px', fontWeight: '700' }}>
                      {v.isAr ? 'الجنس البيولوجي' : 'Biological Sex'}
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        gap: '2px',
                        padding: '4px',
                        borderRadius: '24px',
                        background: 'var(--seg)',
                      }}
                    >
                      {v.genderSeg.map((o, i1) => (
                        <React.Fragment key={i1}>
                          <button
                            aria-pressed={o.pressed}
                            style={{
                              flex: '1',
                              height: '42px',
                              border: '0',
                              borderRadius: '20px',
                              background: o.bg,
                              color: o.ink,
                              fontSize: '13px',
                              fontWeight: o.weight,
                              boxShadow: o.shadow,
                              cursor: 'pointer',
                              padding: '0',
                            }}
                            onClick={o.pick}
                          >{o.label}</button>
                        </React.Fragment>
                      ))}
                    </div>
                  </div>

                  {/* Date of Birth */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      paddingTop: '12px',
                      borderTop: '1px solid var(--line)',
                    }}
                  >
                    <label htmlFor="dob-input" style={{ fontSize: '15px', fontWeight: '700' }}>
                      {v.isAr ? 'تاريخ الميلاد' : 'Date of birth'}
                    </label>
                    <input
                      id="dob-input"
                      type="date"
                      value={v.dob}
                      onChange={v.onDob}
                      style={{
                        height: '42px',
                        boxSizing: 'border-box',
                        borderRadius: '14px',
                        border: '1px solid var(--edge)',
                        background: 'var(--chip)',
                        color: 'var(--ink)',
                        padding: '0 12px',
                        fontSize: '14px',
                        fontWeight: '700',
                      }}
                    />
                  </div>

                  {/* Save Changes Button */}
                  <button
                    onClick={v.saveDetails}
                    style={{
                      width: '100%',
                      height: '48px',
                      borderRadius: '24px',
                      border: 0,
                      background: v.accent,
                      color: '#FFFFFF',
                      fontSize: '15px',
                      fontWeight: '800',
                      cursor: 'pointer',
                      boxShadow: `0 8px 20px ${v.glow}`,
                      marginTop: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                    }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M20 6L9 17l-5-5" />
                    </svg>
                    {v.isAr ? 'حفظ التعديلات' : 'Save changes'}
                  </button>
                </section>
              </>
            )}
            {v.isPrefs && (
              <>
                <section
                  className="glass rise"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M4 7h10 M18 7h2 M14 7a2 2 0 1 0 4 0 2 2 0 1 0-4 0z M4 17h2 M10 17h10 M6 17a2 2 0 1 0 4 0 2 2 0 1 0-4 0z"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Preferences</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>Look, feel and how goals are counted</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ fontSize: '15px', fontWeight: '600' }}>Units</div>
                    <div
                      style={{
                        display: 'flex',
                        gap: '2px',
                        padding: '4px',
                        borderRadius: '24px',
                        background: 'var(--seg)',
                      }}
                    >
                      {v.unitSeg.map((o, i1) => (
                        <React.Fragment key={i1}>
                          <button
                            aria-pressed={o.pressed}
                            style={{
                              flex: '1',
                              height: '44px',
                              border: '0',
                              borderRadius: '20px',
                              background: o.bg,
                              color: o.ink,
                              fontSize: '14px',
                              fontWeight: o.weight,
                              boxShadow: o.shadow,
                              cursor: 'pointer',
                              padding: '0',
                            }}
                            onClick={o.pick}
                          >{o.label}</button>
                        </React.Fragment>
                      ))}
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      <div style={{ fontSize: '15px', fontWeight: '600' }}>Appearance</div>
                      <div
                        style={{
                          display: 'flex',
                          gap: '2px',
                          padding: '4px',
                          borderRadius: '24px',
                          background: 'var(--seg)',
                        }}
                      >
                        {v.modeSeg.map((o, i1) => (
                          <React.Fragment key={i1}>
                            <button
                              aria-pressed={o.pressed}
                              style={{
                                flex: '1',
                                height: '44px',
                                border: '0',
                                borderRadius: '20px',
                                background: o.bg,
                                color: o.ink,
                                fontSize: '14px',
                                fontWeight: o.weight,
                                boxShadow: o.shadow,
                                cursor: 'pointer',
                                padding: '0',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '6px',
                              }}
                              onClick={o.pick}
                            >
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                aria-hidden="true"
                              >
                                <path d={o.icon}></path>
                              </svg>
                              {o.label}{' '}
                            </button>
                          </React.Fragment>
                        ))}
                      </div>
                      <div style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>Auto follows your phone's day and night setting.</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    {v.prefRows.map((r, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px',
                            minHeight: '64px',
                            borderTop: '1px solid var(--line)',
                          }}
                        >
                          <div
                            style={{
                              flex: '1',
                              minWidth: '0',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '2px',
                            }}
                          >
                            <span style={{ fontSize: '15px', fontWeight: '700' }}>{r.title}</span>
                            <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>{r.sub}</span>
                          </div>
                          <button
                            role="switch"
                            aria-checked={r.on}
                            aria-label={r.aria}
                            style={{
                              flex: 'none',
                              width: '52px',
                              height: '32px',
                              boxSizing: 'border-box',
                              borderRadius: '16px',
                              border: '0',
                              padding: '3px',
                              background: r.trackBg,
                              display: 'flex',
                              justifyContent: r.justify,
                              alignItems: 'center',
                              cursor: 'pointer',
                            }}
                            onClick={r.toggle}
                          >
                            <span
                              style={{
                                width: '26px',
                                height: '26px',
                                borderRadius: '13px',
                                background: r.knob,
                                boxShadow: '0 2px 6px rgba(0, 0, 0, 0.25)',
                              }}
                            ></span>
                          </button>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </section>
              </>
            )}
            {v.isLanguage && (
              <>
                <section
                  className="glass rise"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M4 5h9 M8.5 3v2 M6 5c.5 4 3 7 6 8.5 M11 5c-.5 4-3 7.5-7 9 M13 21l4-10 4 10 M14.4 18h5.2"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >{t('profile.language', 'Language')}</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>{t('profile.lang_desc', 'Choose the language of the app')}</span>
                    </div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      paddingTop: '4px',
                    }}
                  >
                    <label htmlFor="lang-select" style={{ fontSize: '15px', fontWeight: '600' }}>{t('profile.language', 'Language')}</label>
                    <select
                      id="lang-select"
                      value={v.lang}
                      onChange={v.onLang}
                      style={{
                        height: '44px',
                        boxSizing: 'border-box',
                        borderRadius: '14px',
                        border: '1px solid var(--edge)',
                        background: 'var(--chip)',
                        color: 'var(--ink)',
                        padding: '0 12px',
                        fontSize: '14px',
                        fontWeight: '700',
                      }}
                    >
                      <option value="English">English</option>
                      <option value="العربية">العربية (Arabic)</option>
                      <option value="Français">Français</option>
                      <option value="Español">Español</option>
                    </select>
                  </div>

                  {/* Quick Select Language Cards */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px', marginTop: '8px' }}>
                    {[
                      { code: 'العربية', name: 'العربية', sub: 'Arabic', flag: '🇸🇦' },
                      { code: 'English', name: 'English', sub: 'الإنجليزية', flag: '🇬🇧' },
                      { code: 'Français', name: 'Français', sub: 'الفرنسية', flag: '🇫🇷' },
                      { code: 'Español', name: 'Español', sub: 'الإسبانية', flag: '🇪🇸' },
                    ].map((item) => {
                      const isActive = v.lang === item.code;
                      return (
                        <button
                          key={item.code}
                          type="button"
                          onClick={() => v.setLangDirect(item.code)}
                          style={{
                            padding: '14px 12px',
                            borderRadius: '16px',
                            border: isActive ? `2px solid ${v.accent}` : '1.5px solid var(--edge)',
                            background: isActive ? 'var(--chip)' : 'transparent',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            cursor: 'pointer',
                            color: 'var(--ink)',
                            textAlign: 'start',
                            transition: 'all 0.15s ease',
                          }}
                        >
                          <div>
                            <div style={{ fontSize: '15px', fontWeight: '800' }}>{item.flag} {item.name}</div>
                            <div style={{ fontSize: '12px', color: 'var(--muted)', marginTop: '2px' }}>{item.sub}</div>
                          </div>
                          {isActive && (
                            <span style={{ color: v.accent, fontWeight: '900', fontSize: '16px' }}>✓</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </section>
              </>
            )}
            {v.isTargets && (
              <>
                <section
                  id="targets"
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M12 3c.8 3.2 4.5 5 4.5 9.2a4.5 4.5 0 0 1-9 0c0-1.7.7-3 1.7-4C9.8 9.6 11.5 8 12 3z"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Daily targets</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>Set your macros, calories follow</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px' }}>
                      <span
                        style={{
                          fontSize: '40px',
                          lineHeight: '44px',
                          fontWeight: '800',
                          letterSpacing: '-0.03em',
                        }}
                      >{v.kcal}</span>
                      <span style={{ fontSize: '15px', color: 'var(--muted)' }}>kcal per day</span>
                    </div>
                    <div style={{ fontSize: '13px', lineHeight: '18px', color: 'var(--muted)' }}>
                      Worked out from your macros: 4 kcal per gram of protein and carbs, 9 per gram of fat.
                    </div>
                  </div>
                  <div
                    role="img"
                    aria-label="Share of calories from protein, carbs and fat"
                    style={{
                      display: 'flex',
                      gap: '3px',
                      height: '14px',
                      borderRadius: '7px',
                      overflow: 'hidden',
                    }}
                  >
                    {v.macroRows.map((m, i1) => (
                      <React.Fragment key={i1}>
                        <div style={{ flex: `${m.share} 1 0%`, background: m.color }}></div>
                      </React.Fragment>
                    ))}
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 16px' }}>
                    {v.macroRows.map((m, i1) => (
                      <React.Fragment key={i1}>
                        <span
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '13px',
                            fontWeight: '700',
                          }}
                        >
                          <span
                            style={{
                              width: '10px',
                              height: '10px',
                              borderRadius: '5px',
                              background: m.color,
                            }}
                          ></span>
                          <span>{m.label}</span>
                          <span style={{ color: 'var(--muted)', fontWeight: '600' }}>{m.pct}</span>
                        </span>
                      </React.Fragment>
                    ))}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    {v.macroRows.map((m, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '10px',
                            minHeight: '60px',
                            borderTop: '1px solid var(--line)',
                          }}
                        >
                          <div style={{ display: 'flex', flexDirection: 'column', minWidth: '0' }}>
                            <span style={{ fontSize: '15px', fontWeight: '700' }}>{m.label}</span>
                            <span style={{ fontSize: '12px', color: 'var(--muted)' }}>{m.sub}</span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <button className="step" aria-label={m.decLabel} onClick={m.dec}>
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                aria-hidden="true"
                              >
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                            <span
                              style={{
                                minWidth: '68px',
                                textAlign: 'center',
                                fontSize: '15px',
                                fontWeight: '800',
                              }}
                            >{m.value}</span>
                            <button className="step" aria-label={m.incLabel} onClick={m.inc}>
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                aria-hidden="true"
                              >
                                <path d="M12 5v14"></path>
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                  <button
                    style={{
                      height: '48px',
                      borderRadius: '24px',
                      border: '1.5px solid var(--edge)',
                      background: 'var(--chip)',
                      fontSize: '14px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                    }}
                    onClick={v.resetTargets}
                  >
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M4 12a8 8 0 1 0 2.5-5.8"></path>
                      <path d="M4 4v5h5"></path>
                    </svg>
                    Recalculate suggested targets{' '}
                  </button>
                  <button
                    aria-expanded={v.microExpanded}
                    style={{
                      minHeight: '44px',
                      border: '0',
                      background: 'transparent',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: '700',
                    }}
                    onClick={v.toggleMicro}
                  >
                    <span>{v.microLabel}</span>
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d={v.microChevron}></path>
                    </svg>
                  </button>
                  {v.microOpen && (
                    <>
                      <div className="fadein" style={{ display: 'flex', flexDirection: 'column' }}>
                        {v.microRows.map((m, i1) => (
                          <React.Fragment key={i1}>
                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                gap: '10px',
                                minHeight: '60px',
                                borderTop: '1px solid var(--line)',
                              }}
                            >
                              <span style={{ fontSize: '15px', fontWeight: '700' }}>{m.label}</span>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <button className="step" aria-label={m.decLabel} onClick={m.dec}>
                                  <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2.2"
                                    strokeLinecap="round"
                                    aria-hidden="true"
                                  >
                                    <path d="M5 12h14"></path>
                                  </svg>
                                </button>
                                <span
                                  style={{
                                    minWidth: '68px',
                                    textAlign: 'center',
                                    fontSize: '15px',
                                    fontWeight: '800',
                                  }}
                                >{m.value}</span>
                                <button className="step" aria-label={m.incLabel} onClick={m.inc}>
                                  <svg
                                    width="18"
                                    height="18"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="2.2"
                                    strokeLinecap="round"
                                    aria-hidden="true"
                                  >
                                    <path d="M12 5v14"></path>
                                    <path d="M5 12h14"></path>
                                  </svg>
                                </button>
                              </div>
                            </div>
                          </React.Fragment>
                        ))}
                      </div>
                    </>
                  )}
                </section>
              </>
            )}
            {v.isWeight && (
              <>
                <section
                  className="glass rise"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M5 21V4 M5 4h12l-2 4 2 4H5"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Goal &amp; current weight</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>Used to personalise your targets</span>
                    </div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '10px',
                      padding: '14px',
                      borderRadius: '20px',
                      background: 'var(--tile)',
                      border: '1px solid var(--edge)',
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        fontSize: '13px',
                        color: 'var(--muted)',
                      }}
                    >
                      <span>Now</span>
                      <span>Goal</span>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        fontSize: '22px',
                        lineHeight: '28px',
                        fontWeight: '800',
                        letterSpacing: '-0.02em',
                      }}
                    >
                      <span>{v.nowLabel}</span>
                      <span>{v.goalLabel}</span>
                    </div>
                    <div aria-hidden="true" style={{ position: 'relative', height: '14px' }}>
                      <div
                        style={{
                          position: 'absolute',
                          left: '10px',
                          right: '10px',
                          top: '6px',
                          borderTop: `2px dashed ${v.accent}`,
                          opacity: '0.55',
                        }}
                      ></div>
                      <div
                        style={{
                          position: 'absolute',
                          left: '0',
                          top: '0',
                          width: '14px',
                          height: '14px',
                          borderRadius: '7px',
                          background: v.accent,
                        }}
                      ></div>
                      <div
                        style={{
                          position: 'absolute',
                          right: '0',
                          top: '0',
                          width: '14px',
                          height: '14px',
                          boxSizing: 'border-box',
                          borderRadius: '7px',
                          border: `3px solid ${v.accent}`,
                          background: 'var(--bgc)',
                        }}
                      ></div>
                    </div>
                    <div style={{ fontSize: '14px', fontWeight: '700', color: 'var(--soft-ink)' }}>{v.journey}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    {v.weightRows.map((r, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '10px',
                            minHeight: '60px',
                            borderTop: '0',
                          }}
                        >
                          <span style={{ fontSize: '15px', fontWeight: '600' }}>{r.label}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <button className="step" aria-label={r.decLabel} onClick={r.dec}>
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                aria-hidden="true"
                              >
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                            <span
                              style={{
                                minWidth: '68px',
                                textAlign: 'center',
                                fontSize: '15px',
                                fontWeight: '800',
                              }}
                            >{r.value}</span>
                            <button className="step" aria-label={r.incLabel} onClick={r.inc}>
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                aria-hidden="true"
                              >
                                <path d="M12 5v14"></path>
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </section>
              </>
            )}
            {v.isSteps && (
              <>
                <section
                  className="glass rise"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M14 4.5a1.6 1.6 0 1 0 0-.01 M11 21l2-6-3-3 1-5 3 2 3 1 M8 12l-2 3"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Daily step goal</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>How many steps you aim for each day</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    {v.stepRows.map((r, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '10px',
                            minHeight: '60px',
                            borderTop: '0',
                          }}
                        >
                          <span style={{ fontSize: '15px', fontWeight: '600' }}>{r.label}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <button className="step" aria-label={r.decLabel} onClick={r.dec}>
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                aria-hidden="true"
                              >
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                            <span
                              style={{
                                minWidth: '68px',
                                textAlign: 'center',
                                fontSize: '15px',
                                fontWeight: '800',
                              }}
                            >{r.value}</span>
                            <button className="step" aria-label={r.incLabel} onClick={r.inc}>
                              <svg
                                width="18"
                                height="18"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                aria-hidden="true"
                              >
                                <path d="M12 5v14"></path>
                                <path d="M5 12h14"></path>
                              </svg>
                            </button>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </section>
              </>
            )}
            {v.isReminders && (
              <>
                <section
                  id="reminders"
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15z"></path>
                        <path d="M10 21a2 2 0 0 0 4 0"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Meal reminders</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>A nudge when it is time to log</span>
                    </div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '10px',
                      padding: '12px 14px',
                      borderRadius: '18px',
                      background: 'var(--warn-bg)',
                      color: 'var(--warn-ink)',
                    }}
                  >
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                        style={{ flex: 'none', marginTop: '1px' }}
                      >
                        <path d="M12 4l9 16H3z"></path>
                        <path d="M12 10v4"></path>
                        <path d="M12 17.5h.01"></path>
                      </svg>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '14px', lineHeight: '20px', fontWeight: '800' }}>Reminders cannot reach you yet</span>
                        <span style={{ fontSize: '13px', lineHeight: '18px' }}>
                          Notifications and exact alarms are switched off for CalSen in your phone's system settings.
                        </span>
                      </div>
                    </div>
                    <button
                      style={{
                        alignSelf: 'flex-start',
                        height: '44px',
                        boxSizing: 'border-box',
                        padding: '0 16px',
                        borderRadius: '22px',
                        border: '1.5px solid currentColor',
                        background: 'transparent',
                        fontSize: '14px',
                        fontWeight: '800',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      Open system settings{' '}
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    {v.reminders.map((r, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px',
                            minHeight: '64px',
                            borderTop: '1px solid var(--line)',
                          }}
                        >
                          <span
                            style={{
                              flex: 'none',
                              minWidth: '78px',
                              boxSizing: 'border-box',
                              textAlign: 'center',
                              padding: '7px 10px',
                              borderRadius: '12px',
                              background: 'var(--chip)',
                              border: '1px solid var(--edge)',
                              fontSize: '13px',
                              fontWeight: '800',
                            }}
                          >{r.time}</span>
                          <div
                            style={{
                              flex: '1',
                              minWidth: '0',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '2px',
                            }}
                          >
                            <span style={{ fontSize: '15px', fontWeight: '700' }}>{r.name}</span>
                            {r.hasSub && (
                              <>
                                <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>{r.sub}</span>
                              </>
                            )}
                          </div>
                          <button
                            role="switch"
                            aria-checked={r.on}
                            aria-label={r.aria}
                            style={{
                              flex: 'none',
                              width: '52px',
                              height: '32px',
                              boxSizing: 'border-box',
                              borderRadius: '16px',
                              border: '0',
                              padding: '3px',
                              background: r.trackBg,
                              display: 'flex',
                              justifyContent: r.justify,
                              alignItems: 'center',
                              cursor: 'pointer',
                            }}
                            onClick={r.toggle}
                          >
                            <span
                              style={{
                                width: '26px',
                                height: '26px',
                                borderRadius: '13px',
                                background: r.knob,
                                boxShadow: '0 2px 6px rgba(0, 0, 0, 0.25)',
                              }}
                            ></span>
                          </button>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </section>
              </>
            )}
            {v.isHistory && (
              <>
                <section
                  id="data"
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M5 20V11"></path>
                        <path d="M12 20V4"></path>
                        <path d="M19 20v-6"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Weight history</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>Last weigh-in: 30 Sep 2026</span>
                    </div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      padding: '12px',
                      borderRadius: '20px',
                      background: 'var(--tile)',
                      border: '1px solid var(--edge)',
                    }}
                  >
                    <div
                      aria-hidden="true"
                      style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '14px',
                        background: 'var(--track)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                        color: 'var(--muted)',
                      }}
                    >
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M4 8h3l2-3h6l2 3h3v11H4z"></path>
                        <path d="M12 11a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                      <span style={{ fontSize: '18px', lineHeight: '22px', fontWeight: '800' }}>57.1 kg</span>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>September 30, 2026</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                      style={{
                        flex: '1',
                        height: '48px',
                        borderRadius: '24px',
                        border: '0',
                        background: v.accent,
                        color: 'var(--on-accent)',
                        boxShadow: `0 8px 20px ${v.glow}`,
                        fontSize: '14px',
                        fontWeight: '800',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                      }}
                    >
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.4"
                        strokeLinecap="round"
                        aria-hidden="true"
                      >
                        <path d="M12 5v14"></path>
                        <path d="M5 12h14"></path>
                      </svg>
                      Log weight{' '}
                    </button>
                    <a
                      href={ROUTES.trends}
                      style={{
                        flex: '1',
                        height: '48px',
                        boxSizing: 'border-box',
                        borderRadius: '24px',
                        border: '1.5px solid var(--edge)',
                        background: 'var(--chip)',
                        color: 'var(--ink)',
                        fontSize: '14px',
                        fontWeight: '800',
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                      }}
                      onClick={(e) => { go(e, 'trends', this.props); }}
                    >
                      See trends{' '}
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M9 5l7 7-7 7"></path>
                      </svg>
                    </a>
                  </div>
                </section>
              </>
            )}
            {v.isRings && (
              <>
                <div
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                    <h2
                      style={{
                        margin: '0',
                        fontSize: '18px',
                        lineHeight: '24px',
                        fontWeight: '800',
                        letterSpacing: '-0.01em',
                      }}
                    >Calendar rings</h2>
                    <span style={{ fontSize: '13px', lineHeight: '18px', color: 'var(--muted)' }}>
                      Every past day on the home calendar gets a ring around its number. The ring fills as you get closer to your calorie goal, and its color shows how the day ended.
                    </span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '8px' }}>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '10px',
                        padding: '12px',
                        borderRadius: '18px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                      }}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          flex: 'none',
                          position: 'relative',
                          width: '32px',
                          height: '32px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '12px',
                          fontWeight: '800',
                        }}
                      >
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" style={{ position: 'absolute', left: '0', top: '0' }}>
                          <circle cx="16" cy="16" r="12.5" strokeWidth="3" style={{ stroke: 'var(--track)' }}></circle>
                          <circle
                            cx="16"
                            cy="16"
                            r="12.5"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeDasharray="62.8 78.5"
                            transform="rotate(-90 16 16)"
                            stroke="#10B981"
                          ></circle>
                        </svg>
                        <span style={{ position: 'relative' }}>7</span>
                      </span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '14px', fontWeight: '800' }}>On target</span>
                        <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>Within 100 kcal of your goal, or under</span>
                      </div>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '10px',
                        padding: '12px',
                        borderRadius: '18px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                      }}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          flex: 'none',
                          position: 'relative',
                          width: '32px',
                          height: '32px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '12px',
                          fontWeight: '800',
                        }}
                      >
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" style={{ position: 'absolute', left: '0', top: '0' }}>
                          <circle cx="16" cy="16" r="12.5" strokeWidth="3" style={{ stroke: 'var(--track)' }}></circle>
                          <circle
                            cx="16"
                            cy="16"
                            r="12.5"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeDasharray="78.5 78.5"
                            transform="rotate(-90 16 16)"
                            stroke="#F59E0B"
                          ></circle>
                        </svg>
                        <span style={{ position: 'relative' }}>8</span>
                      </span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '14px', fontWeight: '800' }}>A little over</span>
                        <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>100 to 199 kcal over</span>
                      </div>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '10px',
                        padding: '12px',
                        borderRadius: '18px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                      }}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          flex: 'none',
                          position: 'relative',
                          width: '32px',
                          height: '32px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '12px',
                          fontWeight: '800',
                        }}
                      >
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" style={{ position: 'absolute', left: '0', top: '0' }}>
                          <circle cx="16" cy="16" r="12.5" strokeWidth="3" style={{ stroke: 'var(--track)' }}></circle>
                          <circle
                            cx="16"
                            cy="16"
                            r="12.5"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeDasharray="78.5 78.5"
                            transform="rotate(-90 16 16)"
                            stroke="#EF4444"
                          ></circle>
                        </svg>
                        <span style={{ position: 'relative' }}>6</span>
                      </span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '14px', fontWeight: '800' }}>Well over</span>
                        <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>200 kcal or more over</span>
                      </div>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '10px',
                        padding: '12px',
                        borderRadius: '18px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                      }}
                    >
                      <span
                        aria-hidden="true"
                        style={{
                          flex: 'none',
                          position: 'relative',
                          width: '32px',
                          height: '32px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '12px',
                          fontWeight: '800',
                        }}
                      >
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" style={{ position: 'absolute', left: '0', top: '0' }}>
                          <circle cx="16" cy="16" r="12.5" strokeWidth="3" style={{ stroke: 'var(--track)' }}></circle>
                          <circle
                            cx="16"
                            cy="16"
                            r="12.5"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeDasharray="2.4 3.2"
                            transform="rotate(-90 16 16)"
                            stroke="#94A3B8"
                          ></circle>
                        </svg>
                        <span style={{ position: 'relative' }}>5</span>
                      </span>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '14px', fontWeight: '800' }}>Not used</span>
                        <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>No meals logged that day</span>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
            {v.isWidgets && (
              <>
                <div
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                    <h2
                      style={{
                        margin: '0',
                        fontSize: '18px',
                        lineHeight: '24px',
                        fontWeight: '800',
                        letterSpacing: '-0.01em',
                      }}
                    >Home-screen widgets</h2>
                    <span style={{ fontSize: '13px', lineHeight: '18px', color: 'var(--muted)' }}>Check your day without opening the app.</span>
                  </div>
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'stretch' }}>
                    <div
                      style={{
                        flex: 'none',
                        width: '120px',
                        boxSizing: 'border-box',
                        padding: '12px',
                        borderRadius: '22px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '8px',
                      }}
                    >
                      <div style={{ position: 'relative', width: '72px', height: '72px' }}>
                        <svg width="72" height="72" viewBox="0 0 72 72" fill="none" aria-hidden="true" style={{ display: 'block' }}>
                          <circle cx="36" cy="36" r="30" stroke="var(--track)" strokeWidth="7"></circle>
                        </svg>
                        <div
                          style={{
                            position: 'absolute',
                            left: '0',
                            top: '0',
                            width: '72px',
                            height: '72px',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <span style={{ fontSize: '16px', lineHeight: '18px', fontWeight: '800' }}>{v.kcal}</span>
                          <span style={{ fontSize: '10px', color: 'var(--muted)' }}>kcal left</span>
                        </div>
                      </div>
                      <div
                        style={{
                          height: '32px',
                          boxSizing: 'border-box',
                          padding: '0 12px',
                          borderRadius: '16px',
                          background: v.accent,
                          color: 'var(--on-accent)',
                          display: 'flex',
                          alignItems: 'center',
                          fontSize: '12px',
                          fontWeight: '800',
                        }}
                      >+ Log food</div>
                    </div>
                    <div
                      style={{
                        flex: '1',
                        minWidth: '0',
                        boxSizing: 'border-box',
                        padding: '12px',
                        borderRadius: '22px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                      }}
                    >
                      <div
                        style={{
                          position: 'relative',
                          width: '64px',
                          height: '64px',
                          flex: 'none',
                        }}
                      >
                        <svg width="64" height="64" viewBox="0 0 64 64" fill="none" aria-hidden="true" style={{ display: 'block' }}>
                          <circle cx="32" cy="32" r="26" stroke="var(--track)" strokeWidth="7"></circle>
                        </svg>
                        <div
                          style={{
                            position: 'absolute',
                            left: '0',
                            top: '0',
                            width: '64px',
                            height: '64px',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <span style={{ fontSize: '14px', lineHeight: '16px', fontWeight: '800' }}>{v.kcal}</span>
                          <span style={{ fontSize: '9px', color: 'var(--muted)' }}>left</span>
                        </div>
                      </div>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '6px',
                          minWidth: '0',
                        }}
                      >
                        <span
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '12px',
                            fontWeight: '700',
                          }}
                        >
                          <span
                            style={{
                              width: '8px',
                              height: '8px',
                              borderRadius: '4px',
                              background: '#6366F1',
                            }}
                          ></span>
                          {v.pLeft} protein
                        </span>
                        <span
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '12px',
                            fontWeight: '700',
                          }}
                        >
                          <span
                            style={{
                              width: '8px',
                              height: '8px',
                              borderRadius: '4px',
                              background: '#F59E0B',
                            }}
                          ></span>
                          {v.cLeft} carbs
                        </span>
                        <span
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '12px',
                            fontWeight: '700',
                          }}
                        >
                          <span
                            style={{
                              width: '8px',
                              height: '8px',
                              borderRadius: '4px',
                              background: '#10B981',
                            }}
                          ></span>
                          {v.fLeft} fat
                        </span>
                      </div>
                    </div>
                  </div>
                  <button
                    aria-expanded={v.widgetExpanded}
                    style={{
                      minHeight: '44px',
                      border: '0',
                      background: 'transparent',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: '700',
                    }}
                    onClick={v.toggleWidgetHelp}
                  >
                    <span>How to add a widget</span>
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d={v.widgetChevron}></path>
                    </svg>
                  </button>
                  {v.widgetOpen && (
                    <>
                      <ol
                        className="fadein"
                        style={{
                          margin: '0',
                          paddingLeft: '20px',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '6px',
                          fontSize: '14px',
                          lineHeight: '20px',
                          color: 'var(--muted)',
                        }}
                      >
                        <li>Press and hold an empty spot on your home screen.</li>
                        <li>Tap Widgets and find CalSen.</li>
                        <li>Drag the one you like to where you want it.</li>
                      </ol>
                    </>
                  )}
                </div>
              </>
            )}
            {v.isReport && (
              <>
                <div
                  className="glass"
                  style={{
                    borderRadius: '24px',
                    padding: '18px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '14px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '14px',
                        background: 'var(--soft-bg)',
                        color: 'var(--soft-ink)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="22"
                        height="22"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M12 4v11"></path>
                        <path d="M8 8l4-4 4 4"></path>
                        <path d="M5 14v5h14v-5"></path>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <h2
                        style={{
                          margin: '0',
                          fontSize: '18px',
                          lineHeight: '24px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >Summary report</h2>
                      <span style={{ fontSize: '13px', color: 'var(--muted)' }}>A PDF you can keep or share</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--ok-bg)',
                        color: 'var(--ok-ink)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M5 12.5l4.5 4.5L19 7.500"></path>
                      </svg>
                      Meals
                    </span>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--ok-bg)',
                        color: 'var(--ok-ink)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M5 12.5l4.5 4.5L19 7.500"></path>
                      </svg>
                      Workouts
                    </span>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--ok-bg)',
                        color: 'var(--ok-ink)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M5 12.5l4.5 4.5L19 7.500"></path>
                      </svg>
                      Weight trend
                    </span>
                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '6px 12px',
                        borderRadius: '14px',
                        background: 'var(--ok-bg)',
                        color: 'var(--ok-ink)',
                        fontSize: '13px',
                        fontWeight: '700',
                      }}
                    >
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d="M5 12.5l4.5 4.5L19 7.500"></path>
                      </svg>
                      Calories &amp; macros
                    </span>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ fontSize: '15px', fontWeight: '600' }}>Time range</div>
                    <div
                      style={{
                        display: 'flex',
                        gap: '2px',
                        padding: '4px',
                        borderRadius: '24px',
                        background: 'var(--seg)',
                      }}
                    >
                      {v.rangeSeg.map((o, i1) => (
                        <React.Fragment key={i1}>
                          <button
                            aria-pressed={o.pressed}
                            style={{
                              flex: '1',
                              height: '44px',
                              border: '0',
                              borderRadius: '20px',
                              background: o.bg,
                              color: o.ink,
                              fontSize: '13px',
                              fontWeight: o.weight,
                              boxShadow: o.shadow,
                              cursor: 'pointer',
                              padding: '0',
                            }}
                            onClick={o.pick}
                          >{o.label}</button>
                        </React.Fragment>
                      ))}
                    </div>
                  </div>
                  {v.customOpen && (
                    <>
                      <div className="fadein" style={{ display: 'flex', gap: '10px' }}>
                        <div
                          style={{
                            flex: '1',
                            minWidth: '0',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '6px',
                          }}
                        >
                          <label htmlFor="from-input" style={{ fontSize: '13px', fontWeight: '700', color: 'var(--muted)' }}>From</label>
                          <input
                            id="from-input"
                            type="date"
                            value={v.from}
                            onChange={v.onFrom}
                            style={{
                              width: '100%',
                              height: '44px',
                              boxSizing: 'border-box',
                              borderRadius: '14px',
                              border: '1px solid var(--edge)',
                              background: 'var(--chip)',
                              color: 'var(--ink)',
                              padding: '0 10px',
                              fontSize: '14px',
                              fontWeight: '700',
                            }}
                           />
                        </div>
                        <div
                          style={{
                            flex: '1',
                            minWidth: '0',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '6px',
                          }}
                        >
                          <label htmlFor="to-input" style={{ fontSize: '13px', fontWeight: '700', color: 'var(--muted)' }}>To</label>
                          <input
                            id="to-input"
                            type="date"
                            value={v.to}
                            onChange={v.onTo}
                            style={{
                              width: '100%',
                              height: '44px',
                              boxSizing: 'border-box',
                              borderRadius: '14px',
                              border: '1px solid var(--edge)',
                              background: 'var(--chip)',
                              color: 'var(--ink)',
                              padding: '0 10px',
                              fontSize: '14px',
                              fontWeight: '700',
                            }}
                           />
                        </div>
                      </div>
                    </>
                  )}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <label htmlFor="report-email" style={{ fontSize: '15px', fontWeight: '600' }}>Send it to</label>
                    <input
                      id="report-email"
                      type="email"
                      value={v.email}
                      onChange={v.onEmail}
                      placeholder="name@example.com"
                      autoComplete="email"
                      style={{
                        width: '100%',
                        height: '48px',
                        boxSizing: 'border-box',
                        borderRadius: '16px',
                        border: '1px solid var(--edge)',
                        background: 'var(--chip)',
                        color: 'var(--ink)',
                        padding: '0 14px',
                        fontSize: '15px',
                      }}
                     />
                    <span style={{ fontSize: '12px', lineHeight: '16px', color: 'var(--muted)' }}>Your own address or someone else's, it is up to you.</span>
                  </div>
                  <button
                    disabled={v.sendOff}
                    style={{
                      height: '50px',
                      borderRadius: '25px',
                      border: '0',
                      background: v.accent,
                      color: 'var(--on-accent)',
                      opacity: v.sendOpacity,
                      fontSize: '15px',
                      fontWeight: '800',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                    }}
                    onClick={v.send}
                  >
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M3 6h18v12H3z"></path>
                      <path d="M3 7l9 7 9-7"></path>
                    </svg>
                    Email my report{' '}
                  </button>
                  {v.sentOn && (
                    <>
                      <div
                        className="fadein"
                        role="status"
                        style={{
                          padding: '10px 14px',
                          borderRadius: '16px',
                          background: 'var(--ok-bg)',
                          color: 'var(--ok-ink)',
                          fontSize: '13px',
                          lineHeight: '18px',
                          fontWeight: '700',
                        }}
                      >
                        Report requested for {v.email}. This is a preview, so nothing was actually sent.
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
        <BottomNav active="profile" accent={v.accent} glow={v.glow} onNavigate={this.props.onNavigate} />
        {v.toastOn && (
          <>
            <div
              className="glass fadein"
              role="status"
              aria-live="polite"
              style={{
                position: 'absolute',
                left: '20px',
                right: '20px',
                bottom: '92px',
                zIndex: '8',
                boxSizing: 'border-box',
                padding: '12px 16px',
                borderRadius: '18px',
                background: 'var(--glass-hi)',
                fontSize: '14px',
                lineHeight: '20px',
                fontWeight: '700',
              }}
            >{v.toast}</div>
          </>
        )}
        {v.dlgOpen && (
          <>
            <div
              style={{
                position: 'absolute',
                left: '0',
                top: '0',
                right: '0',
                bottom: '0',
                zIndex: '20',
                boxSizing: 'border-box',
                padding: '0 20px',
                background: 'rgba(8, 10, 24, 0.55)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <div
                className="fadein"
                role="dialog"
                aria-modal="true"
                aria-labelledby="dlg-title"
                style={{
                  width: '100%',
                  boxSizing: 'border-box',
                  borderRadius: '24px',
                  padding: '20px',
                  background: 'var(--dlg)',
                  border: '1px solid var(--edge)',
                  boxShadow: '0 24px 60px rgba(0, 0, 0, 0.4)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    justifyContent: 'space-between',
                    gap: '12px',
                  }}
                >
                  <h2
                    id="dlg-title"
                    style={{
                      margin: '0',
                      fontSize: '20px',
                      lineHeight: '26px',
                      fontWeight: '800',
                      letterSpacing: '-0.02em',
                    }}
                  >{v.dlgTitle}</h2>
                  <button className="step" aria-label="Close" onClick={v.closeDlg}>
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      aria-hidden="true"
                    >
                      <path d="M6 6l12 12"></path>
                      <path d="M18 6L6 18"></path>
                    </svg>
                  </button>
                </div>
                <p
                  style={{
                    margin: '0',
                    fontSize: '15px',
                    lineHeight: '22px',
                    color: 'var(--muted)',
                  }}
                >{v.dlgBody}</p>
                <div style={{ display: 'flex', gap: '10px', paddingTop: '4px' }}>
                  <button
                    style={{
                      flex: '1',
                      height: '50px',
                      borderRadius: '25px',
                      border: '1.5px solid var(--edge)',
                      background: 'var(--chip)',
                      fontSize: '15px',
                      fontWeight: '800',
                      cursor: 'pointer',
                    }}
                    onClick={v.closeDlg}
                  >{v.dlgCancel || 'Cancel'}</button>
                  {v.dlgDanger && (
                    <>
                      <button
                        style={{
                          flex: '1',
                          height: '50px',
                          borderRadius: '25px',
                          border: '0',
                          background: 'var(--danger)',
                          color: 'var(--on-danger)',
                          fontSize: '15px',
                          fontWeight: '800',
                          cursor: 'pointer',
                        }}
                        onClick={v.confirmDlg}
                      >{v.dlgConfirm}</button>
                    </>
                  )}
                  {v.dlgNormal && (
                    <>
                      <button
                        style={{
                          flex: '1',
                          height: '50px',
                          borderRadius: '25px',
                          border: '0',
                          background: v.accent,
                          color: 'var(--on-accent)',
                          fontSize: '15px',
                          fontWeight: '800',
                          cursor: 'pointer',
                        }}
                        onClick={v.confirmDlg}
                      >{v.dlgConfirm}</button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    );
  }
}
