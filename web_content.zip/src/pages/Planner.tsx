import { useCallback, useEffect, useMemo, useState } from 'react';
import { CalendarDays, CheckCircle2, Clock, Pause, Play, RefreshCw, RotateCcw, TimerReset, XCircle } from 'lucide-react';
import type { ScheduleItem } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { addDaysISO, cn, formatMinutes, relativeDay, todayISO, weekday } from '../lib/utils';
import { Banner, Button, Card, EmptyState, Field, Input, Select, Spinner, useToast } from '../components/ui';

interface PlanResponse {
  items: ScheduleItem[];
  plan: { id: number; title: string; startDate: string; endDate: string } | null;
  from: string;
  to: string;
}

interface Goal { id: number; date: string; minutes: number; title: string | null; status: string }

const KIND_STYLE: Record<string, string> = {
  learn: 'border-brand/40 bg-brand/10 text-brand',
  revise: 'border-warn/40 bg-warn/10 text-warn',
  practice: 'border-ok/40 bg-ok/10 text-ok',
  mock: 'border-bad/40 bg-bad/10 text-bad',
  break: 'border-line bg-elevated/40 text-muted',
  school: 'border-line bg-elevated/30 text-muted',
  coaching: 'border-line bg-elevated/30 text-muted',
  other: 'border-line bg-elevated/30 text-muted',
};

export default function Planner() {
  const { profile } = useAuth();
  const { push } = useToast();
  const [data, setData] = useState<PlanResponse | null>(null);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [days, setDays] = useState(7);
  const [startDate, setStartDate] = useState(todayISO());
  const [focus, setFocus] = useState<string[]>([]);
  const [goalTitle, setGoalTitle] = useState('');
  const [goalMinutes, setGoalMinutes] = useState(60);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [plan, goalData] = await Promise.all([
        api.get<PlanResponse>(`/api/planner?from=${addDaysISO(todayISO(), -7)}&to=${addDaysISO(todayISO(), 30)}`),
        api.get<{ goals: Goal[] }>(`/api/planner/goals?date=${todayISO()}`),
      ]);
      setData(plan);
      setGoals(goalData.goals);
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your planner.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const generate = async () => {
    setGenerating(true);
    setError(null);
    try {
      const res = await api.post<{ generated: number; note: string }>('/api/planner/generate', { days, startDate, focusSubjects: focus });
      setNote(res.note);
      push(`Plan generated with ${res.generated} sessions.`, 'ok');
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not generate a plan.');
    } finally {
      setGenerating(false);
    }
  };

  const setStatus = async (item: ScheduleItem, status: 'done' | 'pending') => {
    try {
      await api.patch(`/api/planner/items/${item.id}`, { status });
      setData((prev) => prev ? { ...prev, items: prev.items.map((i) => i.id === item.id ? { ...i, status } : i) } : prev);
      if (status === 'done' && item.kind !== 'break' && item.kind !== 'school' && item.kind !== 'coaching') {
        push('Session logged. Mastery nudged up.', 'ok');
      }
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not update the session.', 'bad');
    }
  };

  const reschedule = async () => {
    try {
      const res = await api.post<{ moved: number; note: string }>('/api/planner/reschedule');
      push(res.note, res.moved ? 'ok' : 'warn');
      await load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not reschedule.', 'bad');
    }
  };

  const addGoal = async () => {
    if (!goalTitle.trim()) return;
    try {
      const res = await api.post<{ goal: Goal }>('/api/planner/goals', { title: goalTitle.trim(), minutes: goalMinutes, date: todayISO() });
      setGoals((prev) => [...prev, res.goal]);
      setGoalTitle('');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not add the goal.', 'bad');
    }
  };

  const completeGoal = async (goal: Goal) => {
    try {
      await api.patch(`/api/planner/goals/${goal.id}`, { status: 'done' });
      setGoals((prev) => prev.map((g) => g.id === goal.id ? { ...g, status: 'done' } : g));
      push('Goal completed and study time logged.', 'ok');
    } catch {
      push('Could not update that goal.', 'bad');
    }
  };

  const grouped = useMemo(() => {
    const map = new Map<string, ScheduleItem[]>();
    for (const item of data?.items ?? []) {
      const list = map.get(item.date) ?? [];
      list.push(item);
      map.set(item.date, list);
    }
    return [...map.entries()].sort(([a], [b]) => a.localeCompare(b));
  }, [data]);

  const today = todayISO();
  const todayItems = grouped.find(([date]) => date === today)?.[1] ?? [];
  const studyToday = todayItems.filter((i) => i.kind !== 'break' && i.kind !== 'school' && i.kind !== 'coaching');
  const doneToday = studyToday.filter((i) => i.status === 'done').length;

  if (loading) return <Spinner label="Loading your planner…" />;

  return (
    <div className="space-y-4">
      {error && <Banner tone="bad">{error}</Banner>}

      <Card>
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex-1">
            <h2 className="font-display text-base font-bold text-ink">Build an adaptive plan</h2>
            <p className="text-sm text-muted">Prioritises weak chapters, spaced-repetition dues and your exam date — inside your real hours, never through sleep.</p>
          </div>
          <Field label="From">
            <Input type="date" value={startDate} min={todayISO()} onChange={(e) => setStartDate(e.target.value)} className="w-auto" />
          </Field>
          <Field label="Length">
            <Select value={days} onChange={(e) => setDays(Number(e.target.value))} className="w-auto">
              <option value={3}>3 days</option>
              <option value={7}>1 week</option>
              <option value={14}>2 weeks</option>
              <option value={21}>3 weeks</option>
              <option value={30}>1 month</option>
            </Select>
          </Field>
          <Button onClick={() => void generate()} loading={generating}><RefreshCw size={16} /> Generate plan</Button>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3">
          <span className="text-xs font-semibold uppercase tracking-wide text-muted">Focus subjects</span>
          {profile?.subjects.map((s) => (
            <button key={s} onClick={() => setFocus((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s])}
              className={cn('chip', focus.includes(s) && 'border-brand/50 bg-brand/10 text-brand')}>{s}</button>
          ))}
          <Button variant="ghost" className="ml-auto px-2 py-1 text-xs" onClick={() => void reschedule()}><RotateCcw size={13} /> Reschedule missed</Button>
        </div>
        {note && <p className="mt-3 text-xs text-muted">{note}</p>}
      </Card>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="space-y-3">
          <Card>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CalendarDays size={17} className="text-brand" />
                <h2 className="font-display text-base font-bold text-ink">Today · {relativeDay(today)}</h2>
              </div>
              <span className="text-xs font-semibold text-muted">{doneToday}/{studyToday.length} done</span>
            </div>
            {todayItems.length === 0 ? (
              <p className="mt-3 text-sm text-muted">No sessions today. Generate a plan above.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {todayItems.map((item) => <SessionRow key={item.id} item={item} onStatus={setStatus} />)}
              </ul>
            )}
          </Card>

          {grouped.filter(([date]) => date !== today).slice(0, 10).map(([date, items]) => (
            <Card key={date}>
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-bold text-ink">{relativeDay(date)} <span className="ml-1 text-xs font-medium text-muted">{weekday(date)}</span></h3>
                <span className="text-[11px] text-muted">{items.filter((i) => i.kind !== 'break').length} blocks</span>
              </div>
              <ul className="mt-2.5 space-y-1.5">
                {items.map((item) => <SessionRow key={item.id} item={item} onStatus={setStatus} compact />)}
              </ul>
            </Card>
          ))}
          {grouped.length === 0 && (
            <Card><EmptyState icon={<CalendarDays size={22} />} title="Your calendar is empty" description="Generate a plan and it will be saved here. Completed sessions feed your study-hours analytics." /></Card>
          )}
        </div>

        <div className="space-y-4">
          <Pomodoro />
          <Card>
            <h2 className="font-display text-base font-bold text-ink">Today's goals</h2>
            <div className="mt-3 space-y-2">
              <Input value={goalTitle} onChange={(e) => setGoalTitle(e.target.value)} placeholder="e.g. Finish Integration practice set" />
              <div className="flex gap-2">
                <Select value={goalMinutes} onChange={(e) => setGoalMinutes(Number(e.target.value))} className="w-32">
                  {[30, 45, 60, 90, 120].map((m) => <option key={m} value={m}>{m} min</option>)}
                </Select>
                <Button onClick={() => void addGoal()} disabled={!goalTitle.trim()} className="flex-1">Add goal</Button>
              </div>
            </div>
            <ul className="mt-3 space-y-1.5">
              {goals.length === 0 && <li className="text-xs text-muted">No goals yet — a small, finishable goal beats a vague plan.</li>}
              {goals.map((goal) => (
                <li key={goal.id} className="flex items-center gap-2 rounded-lg border border-line/70 bg-elevated/30 px-2.5 py-2">
                  <button onClick={() => void completeGoal(goal)} disabled={goal.status === 'done'} className="text-muted hover:text-ok" aria-label="Complete goal">
                    <CheckCircle2 size={16} className={goal.status === 'done' ? 'text-ok' : ''} />
                  </button>
                  <span className={cn('flex-1 text-xs', goal.status === 'done' ? 'text-muted line-through' : 'text-ink')}>{goal.title}</span>
                  <span className="text-[10px] text-muted">{goal.minutes}m</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SessionRow({ item, onStatus, compact }: { item: ScheduleItem; onStatus: (item: ScheduleItem, status: 'done' | 'pending') => void; compact?: boolean }) {
  const locked = item.kind === 'break' || item.kind === 'school' || item.kind === 'coaching';
  return (
    <li className={cn('flex items-center gap-2.5 rounded-xl border px-2.5 py-2',
      item.status === 'done' ? 'border-ok/25 bg-ok/5' : item.status === 'missed' ? 'border-bad/25 bg-bad/5' : 'border-line/70 bg-elevated/25')}>
      <span className={cn('rounded-md border px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide', KIND_STYLE[item.kind] ?? KIND_STYLE.other)}>{item.kind}</span>
      <div className="min-w-0 flex-1">
        <div className={cn('truncate text-xs font-medium', item.status === 'done' ? 'text-muted line-through' : 'text-ink', compact && 'text-[11px]')}>{item.title}</div>
        {!compact && (
          <div className="mt-0.5 flex items-center gap-1.5 text-[10px] text-muted">
            <Clock size={10} /> {item.startTime}–{item.endTime}
            {item.notes && <span className="truncate">· {item.notes}</span>}
          </div>
        )}
      </div>
      {compact && <span className="text-[10px] text-muted">{item.startTime}</span>}
      {!locked && (
        <button
          onClick={() => onStatus(item, item.status === 'done' ? 'pending' : 'done')}
          className={cn('grid h-6 w-6 place-items-center rounded-md border transition',
            item.status === 'done' ? 'border-ok bg-ok/20 text-ok' : 'border-line text-muted hover:border-brand hover:text-brand')}
          aria-label={item.status === 'done' ? 'Mark as pending' : 'Mark as done'}
        >
          {item.status === 'done' ? <CheckCircle2 size={13} /> : item.status === 'missed' ? <XCircle size={13} /> : <CheckCircle2 size={13} className="opacity-40" />}
        </button>
      )}
    </li>
  );
}

function Pomodoro() {
  const { push } = useToast();
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [focusMinutes, setFocusMinutes] = useState(25);
  const [cycleComplete, setCycleComplete] = useState(false);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => {
    if (seconds > 0 || !running) return;
    setRunning(false);
    setCycleComplete(true);
    push('Focus block finished — stand up, look away from the screen for 5 minutes.', 'ok');
    void api.post('/api/study-sessions', { minutes: focusMinutes, source: 'timer' }).catch(() => undefined);
  }, [seconds, running, focusMinutes, push]);

  const reset = (minutes: number) => {
    setRunning(false);
    setFocusMinutes(minutes);
    setSeconds(minutes * 60);
    setCycleComplete(false);
  };

  const total = focusMinutes * 60;
  const progress = total ? ((total - seconds) / total) * 100 : 0;

  return (
    <Card>
      <div className="flex items-center justify-between">
        <h2 className="font-display text-base font-bold text-ink">Focus block</h2>
        <TimerReset size={16} className="text-muted" />
      </div>
      <div className="my-4 text-center">
        <div className="font-mono text-4xl font-bold tracking-tight text-ink">
          {String(Math.floor(seconds / 60)).padStart(2, '0')}:{String(seconds % 60).padStart(2, '0')}
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-line/60">
          <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${progress}%` }} />
        </div>
        <p className="mt-2 text-[11px] text-muted">{cycleComplete ? `Logged ${formatMinutes(focusMinutes)} of focused study.` : 'Phone away. One topic only.'}</p>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2">
        <Button variant={running ? 'secondary' : 'primary'} onClick={() => setRunning((r) => !r)} className="px-3 py-2 text-xs">
          {running ? <><Pause size={14} /> Pause</> : <><Play size={14} /> Start</>}
        </Button>
        {[25, 45, 50].map((m) => (
          <button key={m} onClick={() => reset(m)} className={cn('chip', focusMinutes === m && 'border-brand/40 text-brand')}>{m}m</button>
        ))}
      </div>
    </Card>
  );
}
