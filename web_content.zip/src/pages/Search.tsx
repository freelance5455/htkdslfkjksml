import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, GraduationCap, Search as SearchIcon, BookOpen } from 'lucide-react';
import { searchContent, subjects } from '../data/content';
import { PageHeader } from '../components/layout/PageHeader';
import { EmptyState } from '../components/ui/Feedback';
import { cn } from '../utils/format';

export default function Search() {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const hits = useMemo(() => searchContent(query), [query]);
  const showEmpty = query.trim().length >= 2 && hits.length === 0;

  return (
    <div>
      <PageHeader title="البحث" subtitle="دروس، ملفات، مدرّسون ومواد — اكتب حرفين على الأقل." back="/" />

      <div className="relative mb-4">
        <SearchIcon size={17} className="absolute end-3 top-1/2 -translate-y-1/2 text-[var(--ink-soft)]" />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="مثال: النهايات، الكهرباء الساكنة، التشبيه…"
          aria-label="بحث في المحتوى"
          className="focus-ring h-12 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] pe-10 ps-3 text-[0.85rem]"
        />
      </div>

      {query.trim().length < 2 ? (
        <div className="card p-4">
          <p className="text-[0.78rem] font-medium text-[var(--ink)]">اقتراحات سريعة</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {['النهايات', 'الوراثة', 'المكثفات', 'التشبيه', 'الجمل الشرطية', 'العقيدة', 'قواعد'].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setQuery(s)}
                className="focus-ring rounded-full border border-[var(--line)] px-2.5 py-1.5 text-[0.7rem] text-[var(--ink)]"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {showEmpty ? (
        <EmptyState
          icon={<SearchIcon size={18} />}
          title="لا نتائج مطابقة"
          description="جرّب كلمة واحدة من عنوان الدرس، أو افتح المادة مباشرة."
        />
      ) : null}

      <div className="space-y-2">
        {hits.map((hit) => {
          const subject = subjects.find((s) => s.id === hit.subjectId);
          const Icon = hit.type === 'lesson' ? BookOpen : hit.type === 'teacher' ? GraduationCap : hit.type === 'file' ? FileText : SearchIcon;
          return (
            <Link key={`${hit.type}-${hit.id}`} to={hit.to} className="focus-ring card flex items-center gap-3 p-3">
              <span
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                style={{ background: `${subject?.color ?? '#64748b'}18`, color: subject?.color ?? 'var(--ink-soft)' }}
              >
                <Icon size={16} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.82rem] text-[var(--ink)]">{hit.title}</span>
                <span className="block truncate text-[0.64rem] text-[var(--ink-soft)]">{hit.subtitle}</span>
              </span>
              <span className={cn('shrink-0 text-[0.6rem]', 'text-[var(--ink-soft)]')}>
                {hit.type === 'lesson' ? 'درس' : hit.type === 'teacher' ? 'مدرّس' : hit.type === 'file' ? 'ملف' : 'مادة'}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
