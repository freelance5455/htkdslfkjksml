import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { ManaraLogo } from '../components/layout/Nav';

export default function NotFound() {
  useEffect(() => {
    document.title = 'الصفحة غير موجودة — منارة البكالوريا';
    const meta = document.createElement('meta');
    meta.name = 'robots';
    meta.content = 'noindex';
    document.head.appendChild(meta);
    return () => {
      document.head.removeChild(meta);
    };
  }, []);

  return (
    <div className="flex min-h-[60dvh] flex-col items-center justify-center gap-4 text-center">
      <ManaraLogo size={52} />
      <p className="font-display text-3xl text-[var(--ink)]">٤٠٤</p>
      <p className="max-w-xs text-[0.85rem] leading-relaxed text-[var(--ink-soft)]">
        هذا الرابط لا يقود إلى صفحة في منارة. ربما تغيّر معرّف درس أو انتهت صلاحية رابط قديم.
      </p>
      <Link
        to="/"
        className="focus-ring inline-flex h-11 items-center gap-2 rounded-full bg-[var(--brand)] px-5 text-[0.82rem] text-[var(--brand-ink)]"
      >
        <Compass size={16} /> عُد إلى الرئيسية
      </Link>
    </div>
  );
}
