import { useCallback, useEffect, useMemo, useState } from 'react';
import { BookOpen, Check, ChevronRight, Layers, Plus, RefreshCw, Repeat2, Sparkles, X } from 'lucide-react';
import type { QuestionRow, RevisionCard } from '@shared/types';
import { chaptersFor } from '@shared/syllabus';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn, formatDate, QUESTION_TYPE_OPTIONS } from '../lib/utils';
import {
  Badge, Banner, Button, Card, EmptyState, Field, Input, Modal, Select, SetupCard, Spinner, Tabs, Textarea, useToast,
} from '../components/ui';
import { Markdown } from '../components/Markdown';

interface DueChapter { subject: string; chapter: string; mastery: number; status: string; nextReview: string | null }
interface Formula { name: string; expression: string; whereUsed?: string; source: string }
interface RevisionData {
  cards: RevisionCard[];
  dueCount: number;
  upcomingCount: number;
  totalCards: number;
  reviewedCards: number;
  dueChapters: DueChapter[];
  formulas: Formula[];
  today: string;
}

type QuizQuestion = Pick<QuestionRow, 'id' | 'subject' | 'chapter' | 'type' | 'difficulty' | 'prompt' | 'options' | 'marks' | 'solution' | 'correct' | 'numericAnswer'>;

export default function Revision() {
  const { profile, aiEnabled } = useAuth();
  const { push } = useToast();
  const [tab, setTab] = useState<'due' | 'quiz' | 'formulas'>('due');
  const [data, setData] = useState<RevisionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [cardBusy, setCardBusy] = useState(false);
  const [genOpen, setGenOpen] = useState(false);
  const [genSubject, setGenSubject] = useState(profile?.subjects[0] ?? '');
  const [genChapter, setGenChapter] = useState('');
  const [genCount, setGenCount] = useState(8);
  const [genBusy, setGenBusy] = useState(false);
  const [manualOpen, setManualOpen] = useState(false);
  const [manual, setManual] = useState({ front: '', back: '', subject: profile?.subjects[0] ?? '', chapter: '' });

  const [quizSubject, setQuizSubject] = useState(profile?.subjects[0] ?? '');
  const [quizChapter, setQuizChapter] = useState('');
  const [quiz, setQuiz] = useState<QuizQuestion[] | null>(null);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, { response: string[]; numeric: string; checked: boolean }>>({});

  const load = useCallback(async () => {
    try {
      const res = await api.get<RevisionData>('/api/revision');
      setData(res);
      setError(null);
      setIndex(0);
      setFlipped(false);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load revision data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const cards = data?.cards ?? [];
  const card = cards[index];
  const totalDue = cards.length + (data?.dueChapters.length ?? 0);

  const reviewCard = async (grade: number) => {
    if (!card || cardBusy) return;
    setCardBusy(true);
    try {
      const res = await api.post<{ due: string; intervalDays: number }>(`/api/revision/cards/${card.id}/review`, { grade });
      push(`Next review ${formatDate(res.due)} (${res.intervalDays} day interval).`, 'info');
      setData((prev) => prev ? { ...prev, cards: prev.cards.filter((c) => c.id !== card.id), dueCount: Math.max(0, prev.dueCount - 1) } : prev);
      setFlipped(false);
      setIndex(0);
    } catch {
      push('Could not save that review.', 'bad');
    } finally {
      setCardBusy(false);
    }
  };

  const reviewChapter = async (chapter: DueChapter, grade: number) => {
    try {
      await api.post('/api/revision/chapters', { subject: chapter.subject, chapter: chapter.chapter, grade });
      setData((prev) => prev ? { ...prev, dueChapters: prev.dueChapters.filter((c) => !(c.subject === chapter.subject && c.chapter === chapter.chapter)) } : prev);
      push('Chapter review scheduled.', 'ok');
    } catch {
      push('Could not update that chapter.', 'bad');
    }
  };

  const generate = async () => {
    setGenBusy(true);
    try {
      const res = await api.post<{ saved: number }>('/api/revision/generate', { subject: genSubject, chapter: genChapter, count: genCount });
      push(res.saved ? `${res.saved} flashcards added and scheduled.` : 'No flashcards were generated — try again.', res.saved ? 'ok' : 'warn');
      setGenOpen(false);
      await load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Generation failed.', 'bad');
    } finally {
      setGenBusy(false);
    }
  };

  const addManual = async () => {
    try {
      await api.post('/api/revision/cards', manual);
      setManualOpen(false);
      setManual({ front: '', back: '', subject: profile?.subjects[0] ?? '', chapter: '' });
      push('Flashcard added.', 'ok');
      await load();
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not add the card.', 'bad');
    }
  };

  const startQuiz = async () => {
    setQuizLoading(true);
    try {
      const res = await api.post<{ questions: QuizQuestion[] }>('/api/revision/quiz', {
        subject: quizSubject, chapter: quizChapter, count: 8,
      });
      setQuiz(res.questions);
      setQuizAnswers({});
      if (!res.questions.length) push('No bank questions for that chapter yet — generate some in the Question Bank.', 'warn');
    } catch (err) {
      push(err instanceof ApiError ? err.message : 'Could not build the quiz.', 'bad');
    } finally {
      setQuizLoading(false);
    }
  };

  const toggleQuizOption = (question: QuizQuestion, key: string) => {
    setQuizAnswers((prev) => {
      const existing = prev[question.id] ?? { response: [], numeric: '', checked: false };
      const multi = question.type === 'multiple-correct';
      return {
        ...prev,
        [question.id]: {
          ...existing,
          response: multi ? (existing.response.includes(key) ? existing.response.filter((k) => k !== key) : [...existing.response, key]) : [key],
        },
      };
    });
  };

  const checkQuiz = (question: QuizQuestion) => {
    setQuizAnswers((prev) => ({ ...prev, [question.id]: { ...(prev[question.id] ?? { response: [], numeric: '' }), checked: true } }));
  };

  const quizScore = useMemo(() => {
    if (!quiz) return null;
    let correct = 0;
    let attempted = 0;
    for (const q of quiz) {
      const answer = quizAnswers[q.id];
      if (!answer?.checked) continue;
      attempted++;
      if (q.numericAnswer) {
        if (answer.numeric && Math.abs(Number(answer.numeric) - Number(q.numericAnswer)) <= Math.max(0.01, Math.abs(Number(q.numericAnswer)) * 0.01)) correct++;
      } else if (answer.response.length && answer.response.slice().sort().join(',') === q.correct.slice().sort().join(',')) correct++;
    }
    return { correct, attempted, total: quiz.length };
  }, [quiz, quizAnswers]);

  if (loading) return <Spinner label="Building your revision queue…" />;
  if (error) return <Banner tone="bad">{error}</Banner>;
  if (!data) return null;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-4">
        <Card className="p-4"><div className="text-xs uppercase tracking-wide text-muted">Due now</div><div className="font-display text-2xl font-bold text-ink">{totalDue}</div></Card>
        <Card className="p-4"><div className="text-xs uppercase tracking-wide text-muted">Cards scheduled</div><div className="font-display text-2xl font-bold text-ink">{data.totalCards}</div></Card>
        <Card className="p-4"><div className="text-xs uppercase tracking-wide text-muted">Reviewed</div><div className="font-display text-2xl font-bold text-ink">{data.reviewedCards}</div></Card>
        <Card className="p-4"><div className="text-xs uppercase tracking-wide text-muted">Next 7 days</div><div className="font-display text-2xl font-bold text-ink">{data.upcomingCount}</div></Card>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <Tabs value={tab} onChange={setTab} tabs={[
          { value: 'due', label: 'Due review', count: totalDue },
          { value: 'quiz', label: 'Quick quiz' },
          { value: 'formulas', label: 'Formula sheet', count: data.formulas.length },
        ]} />
        <div className="flex gap-2">
          <Button variant="secondary" className="px-3 py-2 text-xs" onClick={() => setManualOpen(true)}><Plus size={14} /> Card</Button>
          <Button className="px-3 py-2 text-xs" onClick={() => setGenOpen(true)}><Sparkles size={14} /> Generate cards</Button>
        </div>
      </div>

      {tab === 'due' && (
        <div className="grid gap-4 lg:grid-cols-[1.1fr_1fr]">
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-ink">Flashcards</h2>
              {cards.length > 0 && <span className="text-xs text-muted">{index + 1} / {cards.length}</span>}
            </div>
            {!card ? (
              <EmptyState icon={<Layers size={22} />} title="No cards due" description="Cards become due as you learn new chapters and miss questions. Generate chapter cards to get started." action={<Button onClick={() => setGenOpen(true)}>Generate flashcards</Button>} />
            ) : (
              <>
                <button
                  onClick={() => setFlipped((f) => !f)}
                  className="min-h-[210px] w-full rounded-2xl border border-line bg-elevated/40 p-5 text-left transition hover:border-brand/40"
                >
                  <div className="mb-2 flex items-center gap-2">
                    <Badge tone="brand">{card.subject ?? 'General'}</Badge>
                    {card.chapter && <Badge>{card.chapter}</Badge>}
                    <Badge>{card.source === 'question' ? 'from a mistake' : card.source === 'ai' ? 'AI card' : 'manual'}</Badge>
                  </div>
                  {!flipped ? (
                    <>
                      <p className="text-sm font-medium leading-relaxed text-ink">{card.front}</p>
                      <p className="mt-6 text-[11px] text-muted">Tap to reveal the answer</p>
                    </>
                  ) : (
                    <div className="scale-100">
                      <div className="text-[10px] uppercase tracking-wide text-muted">Answer</div>
                      <div className="mt-1.5"><Markdown content={card.back} /></div>
                    </div>
                  )}
                </button>
                <div className="mt-3 flex flex-wrap gap-2">
                  {[
                    { grade: 0, label: 'Again', tone: 'border-bad/40 text-bad hover:bg-bad/10' },
                    { grade: 1, label: 'Hard', tone: 'border-warn/40 text-warn hover:bg-warn/10' },
                    { grade: 2, label: 'Good', tone: 'border-brand/40 text-brand hover:bg-brand/10' },
                    { grade: 3, label: 'Easy', tone: 'border-ok/40 text-ok hover:bg-ok/10' },
                  ].map((g) => (
                    <button key={g.grade} disabled={cardBusy} onClick={() => void reviewCard(g.grade)}
                      className={cn('rounded-lg border px-3 py-2 text-xs font-semibold transition disabled:opacity-50', g.tone)}>
                      {g.label}
                    </button>
                  ))}
                  <span className="ml-auto self-center text-[10px] text-muted">Scheduling decides the next gap, not a fixed one.</span>
                </div>
              </>
            )}
          </Card>

          <Card>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-ink">Chapters due for revision</h2>
              <Badge>{data.dueChapters.length}</Badge>
            </div>
            {data.dueChapters.length === 0 ? (
              <p className="text-sm text-muted">No chapter reviews due. Keep going with practice tests.</p>
            ) : (
              <ul className="space-y-2">
                {data.dueChapters.map((chapter) => (
                  <li key={`${chapter.subject}-${chapter.chapter}`} className="rounded-xl border border-line bg-elevated/30 p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-sm font-medium text-ink">{chapter.chapter}</div>
                        <div className="text-[11px] text-muted">{chapter.subject} · {Math.round(chapter.mastery * 100)}% mastery · {chapter.status}</div>
                      </div>
                      <Badge tone={chapter.mastery < 0.5 ? 'bad' : 'warn'}>{formatDate(chapter.nextReview)}</Badge>
                    </div>
                    <div className="mt-2 flex gap-1.5">
                      <button onClick={() => void reviewChapter(chapter, 0)} className="chip hover:border-bad/40 hover:text-bad"><X size={11} /> Foggy</button>
                      <button onClick={() => void reviewChapter(chapter, 2)} className="chip hover:border-brand/40 hover:text-brand">Recalled</button>
                      <button onClick={() => void reviewChapter(chapter, 3)} className="chip hover:border-ok/40 hover:text-ok"><Check size={11} /> Easy</button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      )}

      {tab === 'quiz' && (
        <div className="space-y-3">
          <Card>
            <div className="flex flex-wrap items-end gap-2">
              <Field label="Subject">
                <Select value={quizSubject} onChange={(e) => { setQuizSubject(e.target.value); setQuizChapter(''); }} className="w-auto min-w-[140px]">
                  {profile?.subjects.map((s) => <option key={s}>{s}</option>)}
                </Select>
              </Field>
              <Field label="Chapter">
                <Select value={quizChapter} onChange={(e) => setQuizChapter(e.target.value)} className="w-auto min-w-[180px]">
                  <option value="">Whole subject</option>
                  {(profile ? chaptersFor(profile.exam, quizSubject) : []).map((c) => <option key={c}>{c}</option>)}
                </Select>
              </Field>
              <Button onClick={() => void startQuiz()} loading={quizLoading}><RefreshCw size={15} /> Build quiz</Button>
              {quizScore && <div className="ml-auto rounded-xl border border-brand/30 bg-brand/10 px-3 py-2 text-xs font-semibold text-brand">{quizScore.correct}/{quizScore.attempted} correct · {quizScore.total} questions</div>}
            </div>
          </Card>

          {!quiz ? (
            <Card><EmptyState icon={<Repeat2 size={22} />} title="Quick recall quiz" description="Eight bank questions from the chapter you pick. Instant marking and solutions — no timer, no pressure." /></Card>
          ) : quiz.length === 0 ? (
            <Card><p className="text-sm text-muted">No objective questions in the bank for that chapter yet.</p></Card>
          ) : (
            quiz.map((q, i) => {
              const answer = quizAnswers[q.id];
              const correct = q.correct.slice().sort().join(',');
              const given = (answer?.response ?? []).slice().sort().join(',');
              const isRight = q.numericAnswer
                ? Math.abs(Number(answer?.numeric) - Number(q.numericAnswer)) <= Math.max(0.01, Math.abs(Number(q.numericAnswer)) * 0.01)
                : given === correct;
              return (
                <Card key={q.id} className="p-4">
                  <div className="mb-2 flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-bold text-brand">Q{i + 1}</span>
                    <Badge>{QUESTION_TYPE_OPTIONS.find((t) => t.value === q.type)?.label ?? q.type}</Badge>
                    <Badge>{q.chapter}</Badge>
                    <Badge tone={q.difficulty === 'hard' ? 'warn' : 'neutral'}>{q.difficulty}</Badge>
                  </div>
                  <p className="text-sm text-ink">{q.prompt}</p>
                  {(q.type === 'mcq' || q.type === 'multiple-correct' || q.type === 'assertion-reason') && q.options ? (
                    <div className="mt-2 space-y-1.5">
                      {q.options.map((option) => (
                        <button key={option.key} onClick={() => !answer?.checked && toggleQuizOption(q, option.key)}
                          className={cn('flex w-full items-start gap-2 rounded-lg border px-2.5 py-1.5 text-left text-xs transition',
                            answer?.checked
                              ? q.correct.includes(option.key) ? 'border-ok/50 bg-ok/10' : answer.response.includes(option.key) ? 'border-bad/50 bg-bad/10' : 'border-line'
                              : answer?.response.includes(option.key) ? 'border-brand/50 bg-brand/10' : 'border-line bg-elevated/30 hover:border-brand/40')}>
                          <span className="font-bold text-ink">{option.key}</span>
                          <span className="text-ink/90">{option.text}</span>
                        </button>
                      ))}
                    </div>
                  ) : q.numericAnswer ? (
                    <Input type="number" step="any" value={answer?.numeric ?? ''} disabled={answer?.checked}
                      onChange={(e) => setQuizAnswers((prev) => ({ ...prev, [q.id]: { response: [], numeric: e.target.value, checked: false } }))}
                      className="mt-2 max-w-[200px] font-mono text-xs" placeholder="Numerical answer" />
                  ) : null}

                  <div className="mt-2 flex items-center gap-2">
                    {!answer?.checked ? (
                      <Button variant="secondary" className="px-2.5 py-1.5 text-xs" onClick={() => checkQuiz(q)}>Check</Button>
                    ) : (
                      <Badge tone={isRight ? 'ok' : 'bad'}>{isRight ? 'Correct' : `Answer: ${q.numericAnswer ?? q.correct.join(', ')}`}</Badge>
                    )}
                  </div>
                  {answer?.checked && (
                    <div className="mt-2 rounded-lg border border-line bg-elevated/20 p-2.5"><Markdown content={q.solution} /></div>
                  )}
                </Card>
              );
            })
          )}
        </div>
      )}

      {tab === 'formulas' && (
        <div className="grid gap-3 sm:grid-cols-2">
          {data.formulas.length === 0 ? (
            <Card className="sm:col-span-2">
              <EmptyState icon={<BookOpen size={22} />} title="No formulas extracted yet" description="Upload a formula sheet or run “Summarise & extract formulas” on a chapter PDF in My Resources — only formulas that literally appear in your document are listed here." />
            </Card>
          ) : (
            data.formulas.map((formula, i) => (
              <Card key={`${formula.name}-${i}`} className="p-4">
                <div className="text-sm font-semibold text-ink">{formula.name}</div>
                <div className="mt-2 rounded-lg border border-line bg-elevated/30 p-2 text-center font-mono text-sm text-brand">{formula.expression}</div>
                {formula.whereUsed && <p className="mt-2 text-xs text-muted">{formula.whereUsed}</p>}
                <p className="mt-2 flex items-center gap-1 text-[10px] text-muted"><BookOpen size={10} /> {formula.source}</p>
              </Card>
            ))
          )}
        </div>
      )}

      <Modal open={genOpen} onClose={() => setGenOpen(false)} title="Generate flashcards" description="Grounded in your uploaded material when available." footer={
        <><Button variant="secondary" onClick={() => setGenOpen(false)}>Cancel</Button><Button onClick={() => void generate()} loading={genBusy} disabled={!aiEnabled || !genChapter}>Generate</Button></>
      }>
        <div className="space-y-3">
          {!aiEnabled && <SetupCard />}
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Subject">
              <Select value={genSubject} onChange={(e) => { setGenSubject(e.target.value); setGenChapter(''); }}>
                {profile?.subjects.map((s) => <option key={s}>{s}</option>)}
              </Select>
            </Field>
            <Field label="Chapter">
              <Select value={genChapter} onChange={(e) => setGenChapter(e.target.value)}>
                <option value="">Choose a chapter</option>
                {(profile ? chaptersFor(profile.exam, genSubject) : []).map((c) => <option key={c}>{c}</option>)}
              </Select>
            </Field>
          </div>
          <Field label="Number of cards"><Input type="number" min={3} max={15} value={genCount} onChange={(e) => setGenCount(Number(e.target.value))} /></Field>
        </div>
      </Modal>

      <Modal open={manualOpen} onClose={() => setManualOpen(false)} title="Add a flashcard" footer={
        <><Button variant="secondary" onClick={() => setManualOpen(false)}>Cancel</Button><Button onClick={() => void addManual()} disabled={manual.front.trim().length < 3 || !manual.back.trim()}>Save card</Button></>
      }>
        <div className="space-y-3">
          <Field label="Front (prompt)"><Textarea value={manual.front} onChange={(e) => setManual({ ...manual, front: e.target.value })} placeholder="What is the condition for resonance in an LCR circuit?" /></Field>
          <Field label="Back (answer)"><Textarea value={manual.back} onChange={(e) => setManual({ ...manual, back: e.target.value })} placeholder="X_L = X_C, i.e. ω = 1/√(LC)." /></Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Subject"><Select value={manual.subject} onChange={(e) => setManual({ ...manual, subject: e.target.value })}>{profile?.subjects.map((s) => <option key={s}>{s}</option>)}</Select></Field>
            <Field label="Chapter"><Input value={manual.chapter} onChange={(e) => setManual({ ...manual, chapter: e.target.value })} placeholder="Optional" /></Field>
          </div>
        </div>
      </Modal>

      <p className="flex items-center justify-center gap-1.5 text-[11px] text-muted">
        <ChevronRight size={12} /> Intervals grow when you recall easily and shrink when you forget — that is the whole point.
      </p>
    </div>
  );
}
