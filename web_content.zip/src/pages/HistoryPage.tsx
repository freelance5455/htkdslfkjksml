import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { CalculationHistoryItem } from '../types';
import {
  getLocalHistory,
  deleteLocalHistoryItem,
  clearLocalHistory
} from '../services/storage';
import { useApp } from '../context/AppContext';
import {
  History as HistoryIcon,
  Trash2,
  Calculator,
  Copy,
  Check,
  RotateCcw,
  Clock,
  Compass,
  ArrowRight
} from 'lucide-react';

export const HistoryPage: React.FC = () => {
  const { showToast, playSound, triggerHaptic } = useApp();
  const navigate = useNavigate();

  const [history, setHistory] = useState<CalculationHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    try {
      const list = getLocalHistory();
      setHistory(list);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleDelete = (id: string) => {
    playSound('button');
    triggerHaptic('light');
    deleteLocalHistoryItem(id);
    setHistory(getLocalHistory());
    showToast('Calculation record removed');
  };

  const handleClearAll = () => {
    playSound('button');
    triggerHaptic('medium');
    clearLocalHistory();
    setHistory([]);
    showToast('All calculation history cleared');
  };

  const copyResult = async (item: CalculationHistoryItem) => {
    try {
      await navigator.clipboard.writeText(
        `${item.formulaTitle}: ${item.targetSymbol || ''} = ${item.result} ${item.resultUnit}`
      );
      playSound('copy');
      triggerHaptic('light');
      setCopiedId(item.id);
      showToast('Result copied to clipboard');
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      showToast('Failed to copy', 'error');
    }
  };

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <HistoryIcon className="w-5 h-5 text-[#D65A1F]" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
              Calculation History
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-[#A9A39C]">
            Audit log of all formulas and engineering values computed on this device.
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={handleClearAll}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#1C1C1C] hover:bg-[#232323] border border-[#303030] text-[#C84A3A] hover:text-[#C84A3A] text-xs font-semibold transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All Records</span>
          </button>
        )}
      </div>

      {/* History List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-[#1C1C1C] rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : history.length === 0 ? (
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-12 text-center space-y-4 shadow-xl">
          <div className="w-14 h-14 rounded-2xl bg-[#232323] border border-[#303030] flex items-center justify-center mx-auto text-[#A9A39C]">
            <Clock className="w-6 h-6 text-[#A9A39C]" />
          </div>
          <h3 className="text-lg font-bold text-[#F5F2ED]">
            No calculation records found
          </h3>
          <p className="text-xs text-[#A9A39C] max-w-md mx-auto leading-relaxed">
            Whenever you run calculations in the Formula Calculator or Engineering Tools, results are automatically cataloged here for reference.
          </p>
          <button
            onClick={() => {
              playSound('button');
              navigate('/calculator');
            }}
            className="px-5 py-2.5 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-xs transition-colors"
          >
            Go to Calculator
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {history.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-2xl bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F]/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm"
            >
              <div className="space-y-1.5 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-[#A9A39C]">
                    {new Date(item.timestamp).toLocaleDateString()} • {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#232323] border border-[#303030] text-[#D65A1F]">
                    {item.formulaExpression}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-[#F5F2ED] truncate">
                  {item.formulaTitle}
                </h3>

                <div className="text-xs font-mono text-[#D65A1F] font-bold">
                  {item.targetSymbol ? `${item.targetSymbol} = ` : ''}
                  {item.result} {item.resultUnit}
                </div>

                {/* Input variables preview */}
                <div className="flex items-center gap-2 flex-wrap text-[11px] font-mono text-[#A9A39C]">
                  <span>Inputs:</span>
                  {Object.entries(item.inputs || {}).map(([sym, val]) => (
                    <span key={sym} className="px-1.5 py-0.5 rounded bg-[#151515] border border-[#303030]">
                      {sym} = {val}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  onClick={() => copyResult(item)}
                  className="p-2 rounded-xl bg-[#232323] hover:bg-[#303030] border border-[#303030] text-[#F5F2ED] text-xs transition-colors"
                  title="Copy result"
                >
                  {copiedId === item.id ? (
                    <Check className="w-3.5 h-3.5 text-[#72A65A]" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>

                <Link
                  to={`/calculator/${item.formulaId}`}
                  onClick={() => playSound('tab')}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#232323] hover:bg-[#D65A1F] hover:border-[#D65A1F] border border-[#303030] text-xs font-semibold text-[#F5F2ED] transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Recalculate</span>
                </Link>

                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-2 rounded-xl bg-[#232323] hover:bg-[#C84A3A]/20 border border-[#303030] text-[#A9A39C] hover:text-[#C84A3A] transition-colors"
                  title="Delete record"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
