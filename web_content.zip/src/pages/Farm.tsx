import { useState } from 'react';
import { Clock3, Coins, LockKeyhole, Pause, Play, Sprout, Store } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader';
import { ProgressBar, SectionHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Feedback';
import { useStudySession } from '../hooks/useStudySession';
import { EMPTY_WALLET } from '../services/economy';
import { buyPlantSeeds, farmFailureText, harvestPlant, plantSeed, unlockFarmPlot } from '../services/farm';
import { EMPTY_FARM, FARM_MATURITY_SECONDS, FARM_PLOT_COSTS, PLANT_CATALOG, normalizeFarm, type PlantId } from '../services/farmModel';
import { KEYS, useStored } from '../services/storage';
import { subjects } from '../data/content';

function clock(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const remainder = total % 60;
  return hours > 0
    ? `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`
    : `${minutes.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
}

const PLANT_EMOJI: Record<PlantId, string> = {
  wheat: '🌾', tomato: '🍅', mint: '🌿', rose: '🌹', lavender: '🪻', olive: '🫒', grape: '🍇', pomegranate: '🍎',
  sunflower: '🌻', jasmine: '🌼', basil: '🌱', 'date-palm': '🌴',
};
const GROWTH_STAGES = ['بذرة مزروعة', 'بادرة ناشئة', 'أوراق جديدة', 'نمو متقدم', 'إزهار أو ثمر', 'نضج وجاهز للحصاد'];

export default function Farm() {
  const storedFarm = useStored(KEYS.farm, EMPTY_FARM);
  const farm = normalizeFarm(storedFarm);
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  const session = useStudySession();
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? 'math');
  const [durationMinutes, setDurationMinutes] = useState<25 | 50>(25);
  const [notice, setNotice] = useState('');
  const activePlants = farm.plots.filter((plot) => plot.plant && plot.plant.activeSeconds < FARM_MATURITY_SECONDS).length;
  const readyPlants = farm.plots.filter((plot) => plot.plant && plot.plant.activeSeconds >= FARM_MATURITY_SECONDS).length;
  const recentHarvests = [...farm.harvestLog].slice(-6).reverse();

  const perform = async (operation: Promise<{ ok: true } | { ok: false; reason: Parameters<typeof farmFailureText>[0] }>, success: string) => {
    const result = await operation;
    setNotice(result.ok ? success : farmFailureText(result.reason));
  };

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="ازرع وقتك، واحصد تقدّمك"
        title="مزرعة المنارة"
        subtitle="تنمو نباتاتك مع وقت الدراسة النشط فقط، لا مع مرور الوقت أو ترك التطبيق مفتوحاً."
      />

      <section className="card overflow-hidden p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs text-[var(--ink-soft)]">حصادك حتى الآن</p>
            <p className="mt-1 font-display text-2xl text-[var(--ink)]">{farm.totalHarvests} <span className="text-sm font-normal text-[var(--ink-soft)]">محصول</span></p>
            <p className="mt-1 flex items-center gap-1 text-xs text-[var(--gold)]"><Coins size={13} /> رصيدك {wallet.balance} نقطة</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge tone="gold">{farm.plots.filter((plot) => plot.unlocked).length} / 6 قطع مفتوحة</Badge>
            <Badge tone="success">{activePlants} تنمو</Badge>
            {readyPlants > 0 ? <Badge tone="success">{readyPlants} جاهزة للبيع</Badge> : null}
          </div>
        </div>
        {notice ? <p role="status" className="mt-4 rounded-2xl bg-[var(--gold-soft)] px-3 py-2 text-xs text-[var(--ink)]">{notice}</p> : null}
      </section>

      <section>
        <SectionHeader title="قطع المزرعة" hint="كل ساعة دراسة نشطة تضيف مرحلة نمو؛ بعد ٥ ساعات نشطة يصبح المحصول جاهزاً." />
        <div className="grid gap-3 sm:grid-cols-2">
          {farm.plots.map((plot) => {
            const plant = plot.plant ? PLANT_CATALOG.find((item) => item.id === plot.plant?.id) : undefined;
            const seconds = plot.plant?.activeSeconds ?? 0;
            const ready = seconds >= FARM_MATURITY_SECONDS;
            const progress = Math.min(100, (seconds / FARM_MATURITY_SECONDS) * 100);
            const stage = Math.min(5, Math.floor(seconds / 3600));
            const seeds = PLANT_CATALOG.filter((item) => (farm.seeds[item.id] ?? 0) > 0);
            const defaultSeed = seeds[0]?.id ?? 'wheat';
            const plotPrice = FARM_PLOT_COSTS[plot.id];
            return (
              <article key={plot.id} className={`card min-h-44 overflow-hidden p-4 ${!plot.unlocked ? 'opacity-90' : ''}`}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-[var(--ink-soft)]">القطعة {plot.id} {plot.id === 1 ? '· مجانية' : ''}</p>
                    <h3 className="mt-1 font-display text-base text-[var(--ink)]">{plant?.name ?? (plot.unlocked ? 'أرض جاهزة' : 'أرض جديدة')}</h3>
                  </div>
                  {plot.plant ? (
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--success)]/10" style={{ color: plant?.color }} aria-label={`${GROWTH_STAGES[stage]}، المرحلة ${stage} من 5`}>
                      <span aria-hidden="true" className="transition-transform duration-300" style={{ transform: `scale(${0.78 + stage * 0.055})`, fontSize: '1.65rem' }}>{PLANT_EMOJI[plot.plant.id]}</span>
                    </div>
                  ) : plot.unlocked ? (
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--surface-2)] text-[var(--success)]"><Sprout size={24} /></div>
                  ) : (
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--surface-2)] text-[var(--ink-soft)]"><LockKeyhole size={20} /></div>
                  )}
                </div>

                {!plot.unlocked ? (
                  <div className="mt-4">
                    <p className="text-xs text-[var(--ink-soft)]">تُفتح هذه القطعة مرة واحدة بالنقاط.</p>
                    <button type="button" onClick={() => void perform(unlockFarmPlot(plot.id), 'أصبحت القطعة متاحة للزراعة.')} className="focus-ring mt-3 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)]">
                      <Coins size={15} /> افتحها مقابل {plotPrice} نقطة
                    </button>
                  </div>
                ) : plot.plant ? (
                  <div className="mt-3">
                    <div className="flex items-center justify-between gap-2 text-[0.68rem] text-[var(--ink-soft)]"><span>{GROWTH_STAGES[stage]}</span><span className="shrink-0">{stage} / 5 ساعات · {clock(Math.max(0, FARM_MATURITY_SECONDS - seconds))} متبقية</span></div>
                    <ProgressBar value={progress} className="mt-2" height={7} />
                    <p className="mt-2 text-[0.67rem] leading-relaxed text-[var(--ink-soft)]">النمو يتوقف عند إيقاف الجلسة أو إخفاء التطبيق. ساعاتك تتراكم عبر جلسات منفصلة.</p>
                    {ready ? (
                      <button type="button" onClick={() => void perform(harvestPlant(plot.id), `بعت ${plant?.name ?? 'المحصول'} وأضيفت نقاطه إلى رصيدك.`)} className="focus-ring mt-3 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[var(--success)] px-3 text-xs font-semibold text-white">
                        <Coins size={15} /> بع المحصول مقابل {plant?.harvestPoints} نقطة
                      </button>
                    ) : null}
                  </div>
                ) : (
                  <div className="mt-3 space-y-2">
                    {seeds.length > 0 ? (
                      <>
                        <label className="block text-[0.68rem] text-[var(--ink-soft)]" htmlFor={`seed-${plot.id}`}>اختر بذرة من مخزونك</label>
                        <div className="flex gap-2">
                          <select id={`seed-${plot.id}`} defaultValue={defaultSeed} className="focus-ring min-h-11 min-w-0 flex-1 rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-xs text-[var(--ink)]">
                            {seeds.map((seed) => <option key={seed.id} value={seed.id}>{seed.name} · متوفر {farm.seeds[seed.id]}</option>)}
                          </select>
                          <button type="button" onClick={(event) => {
                            const select = event.currentTarget.parentElement?.querySelector('select');
                            const id = select?.value as PlantId | undefined;
                            if (id) void perform(plantSeed(plot.id, id), 'زُرعت البذرة؛ ابدأ جلسة دراسة لتنمو.');
                          }} className="focus-ring min-h-11 rounded-xl bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)]">ازرع</button>
                        </div>
                      </>
                    ) : (
                      <p className="rounded-xl bg-[var(--surface-2)] p-3 text-xs text-[var(--ink-soft)]">لا توجد بذور في مخزونك. اشترِ بذرة من سوق النباتات أدناه.</p>
                    )}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </section>

      <section className="card p-4 sm:p-5">
        <SectionHeader title="جلسة دراسة مركّزة" hint="اختر مادة وابدأ ٢٥ أو ٥٠ دقيقة. تتوقف المكافأة والنمو عند الإيقاف أو إخفاء التطبيق." />
        {session.status === 'idle' || session.status === 'completed' ? (
          <div className="space-y-3">
            {session.status === 'completed' ? <p role="status" className="rounded-xl bg-[var(--success)]/10 px-3 py-2 text-xs text-[var(--success)]">أحسنت، انتهت جلستك. أخذ استراحة قصيرة يساعدك على الاستمرار.</p> : null}
            <div className="grid gap-2 sm:grid-cols-[1fr_auto]">
              <label className="text-xs text-[var(--ink-soft)]">المادة
                <select value={subjectId} onChange={(event) => { setSubjectId(event.target.value); if (session.status === 'running') session.setSubject(event.target.value); }} className="focus-ring mt-1 block min-h-11 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]">
                  {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
                </select>
              </label>
              <div className="flex items-end gap-2" aria-label="مدة جلسة الدراسة">
                {([25, 50] as const).map((minutes) => <button type="button" key={minutes} onClick={() => setDurationMinutes(minutes)} aria-pressed={durationMinutes === minutes} className={`focus-ring min-h-11 rounded-xl px-4 text-xs font-semibold ${durationMinutes === minutes ? 'bg-[var(--brand)] text-[var(--brand-ink)]' : 'bg-[var(--surface-2)] text-[var(--ink)]'}`}>{minutes} دقيقة</button>)}
              </div>
            </div>
            <button type="button" onClick={() => session.start(subjectId, durationMinutes)} className="focus-ring flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-[var(--brand)] px-4 text-sm font-semibold text-[var(--brand-ink)]"><Play size={17} /> ابدأ جلسة الدراسة</button>
          </div>
        ) : (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-[var(--surface-2)] p-3">
            <div><p className="text-xs text-[var(--ink-soft)]">{session.status === 'running' ? 'الجلسة نشطة' : session.pauseReason === 'hidden' ? 'توقفت لأن التطبيق كان مخفياً' : session.pauseReason === 'idle' ? 'توقفت تلقائياً بعد خمس دقائق بلا نشاط' : 'الجلسة متوقفة مؤقتاً'} · {subjects.find((item) => item.id === session.subjectId)?.name ?? 'الدراسة'}</p><p className="mt-1 font-display text-xl tabular-nums text-[var(--ink)]">{clock(session.elapsedSeconds)} <span className="text-xs text-[var(--ink-soft)]">/ {clock(session.durationSeconds)}</span></p></div>
            <div className="flex gap-2">
              {session.status === 'running' ? <button type="button" onClick={session.pause} className="focus-ring flex min-h-11 items-center gap-2 rounded-xl border border-[var(--line)] px-3 text-xs text-[var(--ink)]"><Pause size={15} /> أوقف مؤقتاً</button> : <button type="button" onClick={session.resume} className="focus-ring flex min-h-11 items-center gap-2 rounded-xl bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)]"><Play size={15} /> استأنف</button>}
              <button type="button" onClick={session.end} className="focus-ring min-h-11 rounded-xl border border-[var(--line)] px-3 text-xs text-[var(--ink-soft)]">إنهاء</button>
            </div>
          </div>
        )}
        <p className="mt-3 flex items-start gap-2 text-[0.68rem] leading-relaxed text-[var(--ink-soft)]"><Clock3 size={14} className="mt-0.5 shrink-0" />لا تُحسب الدقائق إذا كانت الصفحة في الخلفية. ويستمر احتساب وقت الفيديو والاختبار والمراجعة عبر مؤقتاتها حتى إن لم تكن صفحة المزرعة مفتوحة.</p>
      </section>

      <section>
        <SectionHeader title="سوق النباتات" hint="ابدأ ببذرة القمح المجانية، أو اشتر بذوراً متنوعة لتنويع حصادك." />
        <div className="grid gap-2 sm:grid-cols-2">
          {PLANT_CATALOG.map((plant) => (
            <article key={plant.id} className="card flex items-center gap-3 p-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--surface-2)] text-xl" style={{ color: plant.color }} aria-hidden="true">{PLANT_EMOJI[plant.id]}</span>
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-[var(--ink)]">{plant.name}</p><p className="mt-0.5 text-[0.67rem] text-[var(--ink-soft)]">بذرة {plant.seedPrice} · بيع بعد النضج {plant.harvestPoints} نقطة · لديك {farm.seeds[plant.id] ?? 0}</p></div>
              <button type="button" onClick={() => void perform(buyPlantSeeds(plant.id), 'أضيفت بذرة إلى مخزونك.')} className="focus-ring flex min-h-10 shrink-0 items-center gap-1 rounded-xl border border-[var(--line)] px-2.5 text-[0.68rem] font-semibold text-[var(--ink)]"><Store size={14} /> اشترِ</button>
            </article>
          ))}
        </div>
      </section>

      <section className="card p-4 sm:p-5">
        <SectionHeader title="سجل الحصاد" hint="آخر محاصيلك محفوظة على هذا الجهاز" />
        {recentHarvests.length ? (
          <ol className="divide-y divide-[var(--line)]">
            {recentHarvests.map((entry, index) => {
              const harvestedPlant = PLANT_CATALOG.find((item) => item.id === entry.plantId);
              return (
                <li key={`${entry.plotId}-${entry.at}-${index}`} className="flex min-h-12 items-center gap-3 py-2">
                  <span className="text-xl" aria-hidden="true">{PLANT_EMOJI[entry.plantId]}</span>
                  <span className="min-w-0 flex-1"><span className="block text-xs font-medium text-[var(--ink)]">{harvestedPlant?.name ?? 'محصول'} · القطعة {entry.plotId}</span><span className="text-[0.65rem] text-[var(--ink-soft)]">{new Date(entry.at).toLocaleString('ar-SY', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span></span>
                  <span className="flex items-center gap-1 text-xs font-semibold text-[var(--gold)]"><Coins size={14} />+{entry.points}</span>
                </li>
              );
            })}
          </ol>
        ) : <p className="rounded-xl bg-[var(--surface-2)] p-3 text-xs text-[var(--ink-soft)]">سيظهر هنا اسم المحصول ووقت حصاده والنقاط التي أُضيفت بعد أول بيع.</p>}
      </section>
    </div>
  );
}
