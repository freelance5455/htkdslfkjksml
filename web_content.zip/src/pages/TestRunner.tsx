import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle, ChevronLeft, ChevronRight, Clock, Flag, Save, Send, X,
} from 'lucide-react';
import type { AttemptAnswer, QuestionRow, TestConfig } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { cn, formatClock, QUESTION_TYPE_OPTIONS } from '../lib/utils';
import { Badge, Banner, Button, Modal, Spinner, useToast } from '../components/ui';

interface TestPayload {
  test: { id: number; title: string; exam: string; durationMinutes: number; totalMarks: number; config: TestConfig | null; questionCount: number };
  questions: QuestionRow[];
}

type LocalAnswer = AttemptAnswer;

const emptyAnswer = (): LocalAnswer => ({ questionId: 0, response: [], numeric: null, timeSpentSeconds: 0, marked: false, visited: false });

export default function TestRunner() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { push } = useToast();
  const [payload, setPayload] = useState<TestPayload | null>(null);
  const [attemptId, setAttemptId] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Record<string, LocalAnswer>>({});
  const [current, setCurrent] = useState(0);
  const [remaining, setRemaining] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [confirmSubmit, setConfirmSubmit] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const answersRef = useRef(answers);
  const questionEnteredAt = useRef(Date.now());
  const submittedRef = useRef(false);

  answersRef.current = answers;

  const load = useCallback(async () => {
    try {
      const data = await api.get<TestPayload & { submittedAttemptId: number | null }>(`/api/tests/${id}`);
      if (data.submittedAttemptId) {
        navigate(`/attempts/${data.submittedAttemptId}`, { replace: true });
        return;
      }
      if (!data.questions.length) {
        setError('This paper has no questions.');
        return;
      }
      setPayload({ test: data.test, questions: data.questions });
      const attempt = await api.post<{ attempt: { id: number; startedAt: string; answers: Record<string, LocalAnswer> } }>(`/api/tests/${id}/attempts`);
      setAttemptId(attempt.attempt.id);
      setAnswers(attempt.attempt.answers ?? {});
      const deadline = new Date(attempt.attempt.startedAt).getTime() + data.test.durationMinutes * 60000;
      setRemaining(Math.max(0, Math.round((deadline - Date.now()) / 1000)));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not open this test.');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => { void load(); }, [load]);

  const questions = payload?.questions ?? [];
  const question = questions[current];

  const updateAnswer = useCallback((questionId: number, patch: Partial<LocalAnswer>) => {
    setAnswers((prev) => {
      const existing = prev[String(questionId)] ?? emptyAnswer();
      return { ...prev, [String(questionId)]: { ...existing, ...patch, questionId } };
    });
  }, []);

  const persist = useCallback(async (extraAnswers?: Record<string, LocalAnswer>, final = false) => {
    if (!attemptId) return;
    const payloadAnswers = extraAnswers ?? answersRef.current;
    setSaving(true);
    try {
      await api.patch(`/api/attempts/${attemptId}`, {
        answers: payloadAnswers,
        timeSpentSeconds: payload ? payload.test.durationMinutes * 60 - remaining : 0,
      });
      setSavedAt(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      if (final) return;
    } catch (err) {
      if (!final) push('Auto-save failed — your answers are still on screen. Check your connection.', 'bad');
      throw err;
    } finally {
      setSaving(false);
    }
  }, [attemptId, payload, remaining, push]);

  // countdown
  useEffect(() => {
    if (!payload) return;
    const timer = setInterval(() => {
      setRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [payload]);

  const submit = useCallback(async (auto = false) => {
    if (!attemptId || submittedRef.current) return;
    submittedRef.current = true;
    setSubmitting(true);
    try {
      const res = await api.post<{ attempt: { id: number } }>(`/api/attempts/${attemptId}/submit`, {
        answers: answersRef.current,
        timeSpentSeconds: payload ? payload.test.durationMinutes * 60 - remaining : 0,
      });
      if (auto) push('Time is up — your paper was submitted automatically.', 'warn');
      navigate(`/attempts/${res.attempt.id}`, { replace: true });
    } catch (err) {
      submittedRef.current = false;
      setSubmitting(false);
      setConfirmSubmit(false);
      push(err instanceof ApiError ? err.message : 'Could not submit the paper.', 'bad');
    }
  }, [attemptId, navigate, payload, push, remaining]);

  useEffect(() => {
    if (payload && remaining === 0 && attemptId && !submittedRef.current) void submit(true);
  }, [remaining, payload, attemptId, submit]);

  // autosave every 25 seconds
  useEffect(() => {
    if (!attemptId) return;
    const timer = setInterval(() => { void persist().catch(() => undefined); }, 25000);
    return () => clearInterval(timer);
  }, [attemptId, persist]);

  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!attemptId || submittedRef.current) return;
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [attemptId]);

  const goTo = (index: number) => {
    if (!question) return;
    const spent = Math.round((Date.now() - questionEnteredAt.current) / 1000);
    const existing = answers[String(question.id)] ?? emptyAnswer();
    updateAnswer(question.id, { timeSpentSeconds: (existing.timeSpentSeconds ?? 0) + spent, visited: true });
    questionEnteredAt.current = Date.now();
    setCurrent(Math.max(0, Math.min(questions.length - 1, index)));
  };

  const statusOf = useMemo(() => (q: QuestionRow) => {
    const a = answers[String(q.id)];
    const answered = a && ((a.response?.length ?? 0) > 0 || (a.numeric ?? '').trim().length > 0);
    if (a?.marked) return 'marked';
    if (answered) return 'answered';
    if (a?.visited) return 'seen';
    return 'unseen';
  }, [answers]);

  if (loading) return <div className="grid min-h-screen place-items-center"><Spinner label="Preparing your paper…" /></div>;
  if (error) {
    return (
      <div className="grid min-h-screen place-items-center p-6">
        <div className="max-w-md space-y-3">
          <Banner tone="bad" title="Cannot start this test">{error}</Banner>
          <Button onClick={() => navigate('/tests')}>Back to Test Centre</Button>
        </div>
      </div>
    );
  }
  if (!payload || !question) return null;

  const answeredCount = questions.filter((q) => {
    const a = answers[String(q.id)];
    return a && ((a.response?.length ?? 0) > 0 || (a.numeric ?? '').trim().length > 0);
  }).length;
  const markedCount = questions.filter((q) => answers[String(q.id)]?.marked).length;
  const config = payload.test.config;
  const timeLow = remaining < 300;

  const optionState = (key: string) => {
    const a = answers[String(question.id)];
    return a?.response?.includes(key) ?? false;
  };

  const selectOption = (key: string) => {
    const multi = question.type === 'multiple-correct';
    const currentResponse = answers[String(question.id)]?.response ?? [];
    const next = multi
      ? currentResponse.includes(key) ? currentResponse.filter((k) => k !== key) : [...currentResponse, key]
      : [key];
    updateAnswer(question.id, { response: next, visited: true });
  };

  return (
    <div className="min-h-screen bg-bg">
      <header className="sticky top-0 z-20 border-b border-line bg-surface/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-sm font-bold text-ink sm:text-base">{payload.test.title}</div>
            <div className="flex items-center gap-2 text-[11px] text-muted">
              <span>{payload.test.totalMarks} marks</span>
              <span>·</span>
              <span>{questions.length} questions</span>
              <span className="hidden sm:inline">·</span>
              <span className="hidden sm:inline">{saving ? 'Saving…' : savedAt ? `Saved ${savedAt}` : 'Auto-save on'}</span>
            </div>
          </div>
          <div className={cn('flex items-center gap-2 rounded-xl border px-3 py-2 font-mono text-sm font-bold tabular-nums',
            timeLow ? 'border-bad/50 bg-bad/10 text-bad' : 'border-line bg-elevated/60 text-ink')}>
            <Clock size={15} /> {formatClock(remaining)}
          </div>
          <Button variant="secondary" className="hidden px-3 py-2 text-xs sm:flex" onClick={() => void persist().catch(() => undefined)}>
            <Save size={14} /> Save
          </Button>
          <Button className="px-3 py-2 text-xs" onClick={() => setConfirmSubmit(true)}><Send size={14} /> Submit</Button>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-5 lg:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          <div className="card p-5">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-brand/15 text-xs font-bold text-brand">{current + 1}</span>
                <Badge>{QUESTION_TYPE_OPTIONS.find((t) => t.value === question.type)?.label ?? question.type}</Badge>
                <Badge tone={question.difficulty === 'hard' || question.difficulty === 'advanced' ? 'warn' : 'neutral'}>{question.difficulty}</Badge>
                <Badge tone="brand">{question.marks} mark{question.marks === 1 ? '' : 's'}{question.negative ? ` · −${question.negative}` : ''}</Badge>
              </div>
              <button
                onClick={() => updateAnswer(question.id, { marked: !answers[String(question.id)]?.marked })}
                className={cn('chip', answers[String(question.id)]?.marked && 'border-warn/50 bg-warn/10 text-warn')}
              >
                <Flag size={12} /> {answers[String(question.id)]?.marked ? 'Marked for review' : 'Mark for review'}
              </button>
            </div>

            <div className="text-[15px] leading-relaxed text-ink">
              <p className="whitespace-pre-wrap">{question.prompt}</p>
            </div>

            <div className="mt-4 space-y-2">
              {(question.type === 'mcq' || question.type === 'assertion-reason' || question.type === 'multiple-correct') && question.options ? (
                question.options.map((option) => {
                  const selected = optionState(option.key);
                  return (
                    <button
                      key={option.key}
                      onClick={() => selectOption(option.key)}
                      className={cn('flex w-full items-start gap-3 rounded-xl border px-3.5 py-3 text-left text-sm transition',
                        selected ? 'border-brand bg-brand/10 text-ink ring-1 ring-brand/30' : 'border-line bg-elevated/30 text-ink/90 hover:border-brand/40')}
                    >
                      <span className={cn('mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-md border text-[11px] font-bold',
                        selected ? 'border-brand bg-brand text-white' : 'border-line text-muted',
                        question.type === 'multiple-correct' ? 'rounded' : 'rounded-full')}>
                        {option.key}
                      </span>
                      <span>{option.text}</span>
                    </button>
                  );
                })
              ) : question.type === 'numerical' || question.type === 'integer' ? (
                <div className="max-w-xs">
                  <label className="label">Your answer (numerical value)</label>
                  <input
                    type="number"
                    step="any"
                    value={answers[String(question.id)]?.numeric ?? ''}
                    onChange={(e) => updateAnswer(question.id, { numeric: e.target.value, visited: true })}
                    className="field font-mono"
                    placeholder="e.g. 9.8"
                  />
                  <p className="mt-1 text-[11px] text-muted">Enter only the number. Rounding within 1% is accepted.</p>
                </div>
              ) : (
                <div>
                  <label className="label">Your answer</label>
                  <textarea
                    value={(answers[String(question.id)]?.response ?? []).join('\n')}
                    onChange={(e) => updateAnswer(question.id, { response: [e.target.value], visited: true })}
                    className="field min-h-[180px]"
                    placeholder="Write your answer with clear steps and units…"
                  />
                  <p className="mt-1 text-[11px] text-muted">
                    {config?.exam.startsWith('cbse')
                      ? 'Descriptive answers are graded against the marking scheme when AI grading is configured; otherwise compare with the model answer afterwards.'
                      : 'Descriptive answers are stored with the attempt for review.'}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-line pt-4">
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => goTo(current - 1)} disabled={current === 0}><ChevronLeft size={16} /> Previous</Button>
                <Button variant="secondary" onClick={() => goTo(current + 1)} disabled={current === questions.length - 1}>Next <ChevronRight size={16} /></Button>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => updateAnswer(question.id, { response: [], numeric: null })}>Clear response</Button>
                <Button variant="ghost" className="lg:hidden" onClick={() => setPaletteOpen(true)}>Palette</Button>
              </div>
            </div>
          </div>

          <p className="text-center text-[11px] text-muted">Answers auto-save. Do not close this tab; the timer keeps running.</p>
        </div>

        <aside className="hidden lg:block">
          <div className="card sticky top-24 p-4">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="font-display text-sm font-bold text-ink">Question palette</h3>
              <span className="text-[11px] text-muted">{answeredCount}/{questions.length}</span>
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              {questions.map((q, index) => {
                const status = statusOf(q);
                return (
                  <button
                    key={q.id}
                    onClick={() => goTo(index)}
                    className={cn('grid h-8 w-8 place-items-center rounded-lg border text-[11px] font-bold transition',
                      status === 'answered' && 'border-ok/50 bg-ok/20 text-ok',
                      status === 'marked' && 'border-warn/50 bg-warn/20 text-warn',
                      status === 'seen' && 'border-bad/40 bg-bad/10 text-bad',
                      status === 'unseen' && 'border-line bg-elevated/40 text-muted',
                      index === current && 'ring-2 ring-brand ring-offset-1 ring-offset-surface')}
                  >
                    {index + 1}
                  </button>
                );
              })}
            </div>
            <div className="mt-3 space-y-1.5 border-t border-line pt-2.5 text-[10px] text-muted">
              <Legend color="border-ok/50 bg-ok/20" label={`Answered (${answeredCount})`} />
              <Legend color="border-warn/50 bg-warn/20" label={`Marked for review (${markedCount})`} />
              <Legend color="border-line bg-elevated/40" label="Not visited" />
            </div>
            <Button className="mt-3 w-full" onClick={() => setConfirmSubmit(true)}><Send size={14} /> Submit paper</Button>
          </div>
        </aside>
      </div>

      <Modal open={paletteOpen} onClose={() => setPaletteOpen(false)} title="Question palette">
        <div className="grid grid-cols-5 gap-2">
          {questions.map((q, index) => (
            <button key={q.id} onClick={() => { goTo(index); setPaletteOpen(false); }}
              className={cn('grid h-10 place-items-center rounded-lg border text-xs font-bold',
                statusOf(q) === 'answered' ? 'border-ok/50 bg-ok/20 text-ok' :
                statusOf(q) === 'marked' ? 'border-warn/50 bg-warn/20 text-warn' :
                'border-line bg-elevated/40 text-muted')}>
              {index + 1}
            </button>
          ))}
        </div>
      </Modal>

      <Modal
        open={confirmSubmit}
        onClose={() => setConfirmSubmit(false)}
        title="Submit this paper?"
        description="Your answers will be evaluated immediately and solutions unlocked."
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmSubmit(false)}>Keep working</Button>
            <Button onClick={() => void submit(false)} loading={submitting}>Submit &amp; evaluate</Button>
          </>
        }
      >
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl border border-ok/30 bg-ok/10 p-3"><div className="text-lg font-bold text-ok">{answeredCount}</div><div className="text-[10px] text-muted">Answered</div></div>
            <div className="rounded-xl border border-line bg-elevated/40 p-3"><div className="text-lg font-bold text-ink">{questions.length - answeredCount}</div><div className="text-[10px] text-muted">Unanswered</div></div>
            <div className="rounded-xl border border-warn/30 bg-warn/10 p-3"><div className="text-lg font-bold text-warn">{markedCount}</div><div className="text-[10px] text-muted">Marked</div></div>
          </div>
          {questions.length - answeredCount > 0 && config?.negativeMarking && (
            <Banner tone="warn" title="Negative marking is on">
              Unanswered questions score zero, but guessing without elimination can cost marks. Check your marked questions before submitting.
            </Banner>
          )}
          {questions.length - answeredCount > 0 && !config?.negativeMarking && (
            <Banner tone="info" title={`${questions.length - answeredCount} unanswered`}>
              This paper has no negative marking — it is usually worth attempting every question before submitting.
            </Banner>
          )}
        </div>
      </Modal>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className={cn('h-3 w-3 rounded border', color)} /> {label}
    </div>
  );
}
