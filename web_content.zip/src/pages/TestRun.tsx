import { Link, Navigate, useParams } from 'react-router-dom';
import { ChevronRight, ListChecks } from 'lucide-react';
import { allQuizzes, getSubject } from '../data/content';
import { QuizRunner } from '../components/quiz/QuizRunner';
import { PageHeader } from '../components/layout/PageHeader';

export default function TestRun() {
  const { quizId = '' } = useParams();
  const entry = allQuizzes().find(({ quiz }) => quiz.id === quizId);

  if (!entry) return <Navigate to="/tests" replace />;

  const subject = getSubject(entry.subjectId);
  return (
    <div>
      <PageHeader title={entry.quiz.title} subtitle={`${entry.quiz.questions.length} سؤال · ${entry.lessonTitle}`} back="/tests" />
      {entry.kind === 'practice' ? (
        <div className="mb-3 flex items-center gap-2 rounded-2xl bg-[var(--gold-soft)] px-3 py-2 text-xs text-[var(--ink)]">
          <ListChecks size={15} className="text-[var(--gold)]" /> اختبار تدريب على موضوعات {subject?.name ?? 'المادة'}، وليس امتحاناً وزارياً رسمياً.
        </div>
      ) : null}
      <QuizRunner quiz={entry.quiz} lesson={entry.lesson} subjectId={entry.subjectId} />
      <div className="mt-3 flex gap-2">
        {entry.lesson ? (
          <Link to={`/lesson/${entry.subjectId}/${entry.lesson.id}`} className="focus-ring card flex h-11 flex-1 items-center justify-center gap-1.5 text-[0.78rem] text-[var(--ink)]">
            <ChevronRight size={15} /> عد إلى الدرس
          </Link>
        ) : null}
        <Link to="/tests" className="focus-ring card flex h-11 flex-1 items-center justify-center text-[0.78rem] text-[var(--ink)]">كل الاختبارات</Link>
      </div>
    </div>
  );
}
