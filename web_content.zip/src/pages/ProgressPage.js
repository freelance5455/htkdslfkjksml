/**
 * ProgressPage.js — dedicated cross-domain analytics hub.
 * Reuses scoreEngine.js series (no duplicated calculation logic with
 * Dashboard) but renders them larger, plus an achievement gallery and
 * a 90-day roadmap milestone overlay tied to the original reports.
 */
import { el, card, sectionHeader, progressRing, emptyState, tabs, statGrid, barList, trendBadge } from '../components/ui.js';
import { chartCanvas, renderLineChart, renderBarChart } from '../components/charts/canvasChart.js';
import {
  computeLifeScore, dailyXPSeries, habitConsistencySeries,
  studyHoursSeries, weeklyProgressSummary,
} from '../core/scoring/scoreEngine.js';
import { getUnlockedAchievements } from '../core/xp/achievements.js';
import { getAll } from '../core/storage/storageService.js';
import { dailySeries, studyBySubject, lifetimeStats, thisAndLastWeek, delta } from '../core/stats/statsService.js';

let range = 30; // days shown in the charts (7 / 14 / 30 / 90)

const ROADMAP_90_DAY = [
  { range: 'Days 1–30', label: 'Skin & Hair Reset', detail: 'Daily skincare routine, fresh haircut, 3L+ water tracking established.' },
  { range: 'Days 31–60', label: 'Facial Leaning Phase', detail: 'Diet cleanup, reduced bloating, visible drop in active acne.' },
  { range: 'Days 61–90', label: 'Peak Polish', detail: 'Eyebrow cleanup, body fat optimization, sharper facial structure visible.' },
];

function daysSinceFirstLog(allDates) {
  if (allDates.length === 0) return 0;
  const earliest = allDates.sort()[0];
  const diffMs = Date.now() - new Date(`${earliest}T00:00:00`).getTime();
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

export async function ProgressPage(root) {
  const R = range;
  const [
    scores, xpSeries, consistencySeries, studySeries, weeklySummary,
    achievements, skincareLogs, habitLogs,
  ] = await Promise.all([
    computeLifeScore(),
    dailyXPSeries(R),
    habitConsistencySeries(R),
    studyHoursSeries(R),
    weeklyProgressSummary(),
    getUnlockedAchievements(),
    getAll('skincareLogs'),
    getAll('habitLogs'),
  ]);

  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Progress'), el('p', 'page-subtitle', 'Cross-domain trends & milestones'));
  page.append(tabs([{ key: 7, label: '7d' }, { key: 14, label: '14d' }, { key: 30, label: '30d' }, { key: 90, label: '90d' }], range, async (k) => {
    range = k; root.innerHTML = ''; await ProgressPage(root);
  }));

  // --- Scores overview ---
  page.append(sectionHeader(null, 'Current scores'));
  page.append(card([
    el('div', 'flex items-center gap-3', [
      progressRing(scores.life, 64, 6),
      el('div', null, [el('div', 'stat-tile__value', 'Life Score'), el('p', 'text-xs text-dim mt-1', 'Rolling 7-day composite.')]),
    ]),
  ]));
  const grid = el('div', 'score-grid mt-4', [
    el('div', 'score-tile', [progressRing(scores.health, 44, 4), el('span', 'score-tile__label', 'Health')]),
    el('div', 'score-tile', [progressRing(scores.study, 44, 4), el('span', 'score-tile__label', 'Study')]),
    el('div', 'score-tile', [progressRing(scores.fitness, 44, 4), el('span', 'score-tile__label', 'Fitness')]),
    el('div', 'score-tile', [progressRing(scores.confidence, 44, 4), el('span', 'score-tile__label', 'Confidence')]),
  ]);
  page.append(grid);

  // --- 30-day charts ---
  page.append(sectionHeader(null, `XP growth (${R} days)`));
  const xpCard = card([]);
  const xpCanvas = chartCanvas(140);
  xpCard.append(xpCanvas);
  page.append(xpCard);

  page.append(sectionHeader(null, `Habit consistency (${R} days)`));
  const consCard = card([]);
  const consCanvas = chartCanvas(140);
  consCard.append(consCanvas);
  page.append(consCard);

  page.append(sectionHeader(null, `Study hours / day (${R} days)`));
  const studyCard = card([]);
  const studyCanvas = chartCanvas(140);
  studyCard.append(studyCanvas);
  page.append(studyCard);

  // --- NEW: this week vs last + lifetime totals ---
  const { cur, prev } = await thisAndLastWeek();
  const life = await lifetimeStats();
  page.append(sectionHeader('vs last week', 'This week'));
  page.append(statGrid([
    { value: `${cur.habitPct}%`, label: 'Habits', hint: `was ${prev.habitPct}%` },
    { value: `${cur.studyHours}h`, label: 'Study', hint: `was ${prev.studyHours}h` },
    { value: cur.workouts, label: 'Workouts', hint: `was ${prev.workouts}` },
    { value: cur.ankiCards, label: 'Anki cards', hint: `was ${prev.ankiCards}` },
  ]));
  page.append(el('div', 'mt-2 flex items-center gap-2', [el('span', 'text-xs text-dim', 'Study:'), trendBadge(delta(cur.studyHours, prev.studyHours)), el('span', 'text-xs text-dim', 'Habits:'), trendBadge(delta(cur.habitPct, prev.habitPct))]));

  const subjects = await studyBySubject(R);
  if (subjects.length) {
    page.append(sectionHeader(null, `Study by subject (${R} days)`));
    page.append(card([barList(subjects.slice(0, 8).map(([name, mins]) => ({ label: name, value: mins, text: `${Math.round(mins / 6) / 10}h` })))]));
  }

  const extra = [['anki', 'Anki cards / day', '#2A4DD0', 'bar'], ['workouts', 'Workout days', 'var(--c-emerald-soft)', 'bar'], ['water', 'Water (litres / day)', '#2A9DD0', 'line'], ['prayers', 'Prayers / day', 'var(--c-emerald-soft)', 'bar']];
  const extraCanvases = [];
  for (const [kind, title, color, type] of extra) {
    const series = await dailySeries(R, kind);
    page.append(sectionHeader(null, `${title} (${R} days)`));
    const c = card([]);
    const cv = chartCanvas(110);
    c.append(cv);
    page.append(c);
    extraCanvases.push({ cv, series, color, type, kind });
  }

  page.append(sectionHeader('All time', 'Lifetime totals'));
  page.append(statGrid([
    { value: `${life.studyHours}h`, label: 'Study hours' },
    { value: life.ankiCards, label: 'Anki cards' },
    { value: life.workouts, label: 'Workouts' },
    { value: life.habitTicks, label: 'Habits done' },
    { value: life.prayers, label: 'Prayers logged' },
    { value: life.bestStudyDay ? `${life.bestStudyDay.hours}h` : '–', label: 'Best study day', hint: life.bestStudyDay?.date },
  ]));

  // --- 90-day roadmap milestone overlay ---
  const dayNumber = daysSinceFirstLog([...skincareLogs.map((s) => s.date), ...habitLogs.map((h) => h.date)]);
  page.append(sectionHeader(`Day ${dayNumber}`, '90-Day roadmap'));
  ROADMAP_90_DAY.forEach((phase, i) => {
    const phaseStart = i * 30;
    const isActive = dayNumber >= phaseStart && dayNumber < phaseStart + 30;
    const isDone = dayNumber >= phaseStart + 30;
    page.append(card([
      el('div', 'flex justify-between items-center', [
        el('span', null, `${phase.range} — ${phase.label}`),
        el('span', `text-xs ${isDone ? 'text-dim' : ''}`, isDone ? 'Complete' : isActive ? 'In progress' : 'Upcoming'),
      ]),
      el('p', 'text-xs text-dim mt-1', phase.detail),
    ]));
  });

  // --- Achievements gallery ---
  page.append(sectionHeader(`${achievements.filter((a) => a.unlocked).length}/${achievements.length}`, 'Achievements'));
  page.append(card(
    achievements.map((a) => el('div', 'checklist-item', [
      el('span', `checklist-item__label ${a.unlocked ? '' : 'text-dim'}`, `${a.icon} ${a.title}`),
      el('span', 'text-xs text-dim', a.unlocked ? a.unlockedAt : 'Locked'),
    ]))
  ));

  root.appendChild(page);

  requestAnimationFrame(() => {
    renderLineChart(xpCanvas, xpSeries, {});
    renderBarChart(consCanvas, consistencySeries, { maxOverride: 100, color: '#2A4DD0' });
    renderLineChart(studyCanvas, studySeries, { color: '#E0A93B' });
    extraCanvases.forEach(({ cv, series, color, type, kind }) => {
      const opts = { color, maxOverride: kind === 'prayers' ? 5 : kind === 'workouts' ? 1 : undefined };
      if (type === 'bar') renderBarChart(cv, series, opts); else renderLineChart(cv, series, opts);
    });
  });
}
