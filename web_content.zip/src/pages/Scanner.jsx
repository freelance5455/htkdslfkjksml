import React from 'react';
import { CalsenBase } from '../lib/CalsenBase';
import { go, ROUTES, css } from '../lib/calsen';
import CalSenScanResult from './ScanResult';
import sampleMealImg from '../assets/images/meal_mediterranean_bowl_1791967840332.jpg';

export default class ScannerPage extends CalsenBase {
  static defaultProps = {"accent": "#FF5C00", "theme": "sync"};

  componentDidMount() {
    try {
      const v = window.localStorage.getItem('calsen-meal');
      if (v !== null) { window.localStorage.removeItem('calsen-meal'); const n = parseInt(v, 10); if (n >= 0 && n <= 3) this.setState({ meal: n }); }
    } catch (e) {}
    setTimeout(() => this.startCam(), 80);
  }
  componentWillUnmount() { this.stopCam(); }
  stopCam() {
    try { if (this.stream) { this.stream.getTracks().forEach((t) => t.stop()); this.stream = null; } } catch (e) {}
  }
  startCam() {
    try {
      const v = document.getElementById('cam');
      if (!v || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { this.setState({ camOff: true, camOn: false }); return; }
      navigator.mediaDevices.getUserMedia({ video: { facingMode: this.facing || 'environment' }, audio: false })
        .then((st) => {
          this.stopCam();
          this.stream = st;
          const el = document.getElementById('cam');
          if (el) { el.srcObject = st; if (el.play) el.play().catch(() => {}); }
          this.setState({ camOff: false, camOn: true });
        })
        .catch(() => this.setState({ camOff: true, camOn: false }));
    } catch (e) { this.setState({ camOff: true, camOn: false }); }
  }
  analyze(photo) {
    this.stopCam();
    const pick = String(photo || '').length % 3;
    this.setState({ stage: 'scan', photo, pct: 0, q: {}, off: {}, pick, camOn: false });
    clearInterval(this.timer);
    this.timer = setInterval(() => {
      const p = Math.min(100, ((this.state || {}).pct || 0) + 4);
      if (p >= 100) { clearInterval(this.timer); this.setState({ pct: 100 }); setTimeout(() => this.setState({ stage: 'result' }), 250); }
      else this.setState({ pct: p });
    }, 110);
  }
  retake() {
    clearInterval(this.timer);
    this.setState({ stage: 'cam', photo: null, camOn: false, camOff: false });
    setTimeout(() => this.startCam(), 80);
  }
  renderVals() {
    const s = this.state || {};
    const stage = s.stage || 'cam';
    const mode = this.modeNow();
    const darkUser = this.isDark(mode);
    const dark = stage === 'cam' || stage === 'scan' ? true : darkUser;
    const base = this.props.accent ?? '#FF5C00';
    const accent = this.accentFor(base, dark);
    const glow = this.glowOf(accent, dark ? 0.45 : 0.3);
    const fmt = (n) => Math.round(n).toLocaleString('en-US');
    const MOONI = 'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z';
    const SUNI = 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M12 3v2 M12 19v2 M3 12h2 M19 12h2 M5.6 5.6l1.4 1.4 M17 17l1.4 1.4 M5.6 18.4L7 17 M17 7l1.4-1.4';

    const SETS = [
      { name: 'Grilled chicken bowl', conf: 92, items: [
        { n: 'Grilled chicken breast', g: 150, k: 248, p: 46, c: 0, f: 5 },
        { n: 'Brown rice', g: 195, k: 216, p: 5, c: 45, f: 2 },
        { n: 'Steamed broccoli', g: 90, k: 31, p: 3, c: 6, f: 0 },
        { n: 'Olive oil dressing', g: 14, k: 119, p: 0, c: 0, f: 14 } ] },
      { name: 'Breakfast plate', conf: 88, items: [
        { n: 'Scrambled eggs', g: 120, k: 182, p: 12, c: 2, f: 14 },
        { n: 'Whole-wheat toast', g: 60, k: 150, p: 6, c: 26, f: 2 },
        { n: 'Avocado', g: 100, k: 160, p: 2, c: 9, f: 15 },
        { n: 'Orange juice', g: 200, k: 90, p: 1, c: 21, f: 0 } ] },
      { name: 'Spaghetti bolognese', conf: 90, items: [
        { n: 'Spaghetti', g: 220, k: 348, p: 13, c: 70, f: 2 },
        { n: 'Meat sauce', g: 150, k: 210, p: 14, c: 9, f: 12 },
        { n: 'Parmesan', g: 10, k: 43, p: 4, c: 0, f: 3 },
        { n: 'Side salad', g: 80, k: 25, p: 1, c: 4, f: 0 } ] }
    ];
    const set = SETS[s.pick || 0];
    const q = s.q || {};
    const off = s.off || {};
    const qty = (i) => (q[i] === undefined ? 1 : q[i]);
    let T = { k: 0, p: 0, c: 0, f: 0 };
    const items = set.items.map((it, i) => {
      const x = off[i] ? 0 : qty(i);
      T.k += it.k * x; T.p += it.p * x; T.c += it.c * x; T.f += it.f * x;
      return {
        name: it.n,
        kcal: fmt(it.k * x),
        grams: fmt(it.g * qty(i)),
        opacity: off[i] ? '0.5' : '1',
        minusLabel: 'Smaller portion of ' + it.n,
        plusLabel: 'Larger portion of ' + it.n,
        minus: () => this.setState({ q: Object.assign({}, q, { [i]: Math.max(0.25, qty(i) - 0.25) }) }),
        plus: () => this.setState({ q: Object.assign({}, q, { [i]: Math.min(3, qty(i) + 0.25) }) }),
        toggle: () => this.setState({ off: Object.assign({}, off, { [i]: !off[i] }) }),
        toggleText: off[i] ? 'Add back' : 'Remove',
        toggleBg: off[i] ? 'var(--soft-bg)' : 'var(--chip)',
        toggleInk: off[i] ? 'var(--soft-ink)' : 'var(--muted)'
      };
    });
    const cur = stage === 'result' ? this.tw({ k: T.k, p: T.p, c: T.c, f: T.f }, 420) : (this._tw = null, { k: T.k, p: T.p, c: T.c, f: T.f });
    const mx = Math.max(cur.p, cur.c, cur.f, 1);
    const macros = [
      { label: 'Protein', color: this.macroSet(dark).P.color, g: Math.round(cur.p) },
      { label: 'Carbs', color: this.macroSet(dark).C.color, g: Math.round(cur.c) },
      { label: 'Fat', color: this.macroSet(dark).F.color, g: Math.round(cur.f) }
    ].map((m) => Object.assign(m, { w: Math.max(4, Math.round((m.g / mx) * 100)) + '%' }));

    const MEALS = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'];
    const h = new Date().getHours();
    const defMeal = h < 11 ? 0 : h < 16 ? 1 : h < 21 ? 2 : 3;
    const meal = s.meal === undefined ? defMeal : s.meal;
    const mealOpts = MEALS.map((label, i) => ({
      label,
      pressed: i === meal ? 'true' : 'false',
      bg: i === meal ? accent : 'transparent',
      ink: i === meal ? 'var(--on-accent)' : 'var(--muted)',
      weight: i === meal ? '800' : '600',
      pick: () => this.setState({ meal: i })
    }));
    const steps = ['Finding the foods', 'Estimating portions', 'Calculating calories'];
    const camOff = !!s.camOff;

    return {
      accent, glow,
      darkUser,
      themeKey: dark ? 'dark' : 'light',
      themeIcon: darkUser ? SUNI : MOONI,
      themeAria: darkUser ? 'Switch to light mode' : 'Switch to dark mode',
      toggleTheme: () => this.setMode(darkUser ? 'light' : 'dark'),
      inCamera: stage === 'cam', isScan: stage === 'scan', isResult: stage === 'result', isDone: stage === 'done',
      CORNER: 'width: 34px; height: 34px; border-color: ' + accent + '; border-style: solid; border-width: 0;',
      camTitle: 'Scan your meal',
      showVideo: !camOff,
      camOff,
      camHint: 'The camera is not available here. Tap the camera button to take a photo, or pick one from your gallery.',
      flashOn: s.flash ? 'true' : 'false',
      flashOpacity: s.flash ? '1' : '0.75',
      flashSlash: s.flash ? '' : 'M4 4l16 16',
      toggleFlash: () => {
        const on = !s.flash;
        this.setState({ flash: on });
        try { const t = this.stream && this.stream.getVideoTracks()[0]; if (t && t.applyConstraints) t.applyConstraints({ advanced: [{ torch: on }] }).catch(() => {}); } catch (e) {}
      },
      openGallery: () => { const i = document.getElementById('photo-input'); if (i) { i.removeAttribute('capture'); i.click(); setTimeout(() => i.setAttribute('capture', 'environment'), 400); } },
      capture: () => {
        const v = document.getElementById('cam');
        if (this.stream && v && v.videoWidth) {
          const c = document.createElement('canvas');
          const sc = Math.min(1, 1280 / Math.max(v.videoWidth, v.videoHeight));
          c.width = Math.round(v.videoWidth * sc); c.height = Math.round(v.videoHeight * sc);
          c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
          this.analyze(c.toDataURL('image/jpeg', 0.85));
        } else {
          const i = document.getElementById('photo-input'); if (i) i.click();
        }
      },
      flip: () => { this.facing = this.facing === 'user' ? 'environment' : 'user'; this.startCam(); },
      onFile: (e) => {
        const f = e.target.files && e.target.files[0];
        if (!f) return;
        const r = new FileReader();
        r.onload = () => this.analyze(String(r.result));
        r.readAsDataURL(f);
        try { e.target.value = ''; } catch (err) {}
      },
      photo: s.photo || '',
      scanGlow: this.glowOf(accent, 0.55),
      pct: String(s.pct || 0),
      mealName: set.name,
      conf: set.conf + '% sure',
      total: fmt(Math.round(cur.k)),
      numGlow: dark ? '0 0 22px ' + this.glowOf(accent, 0.4) : 'none',
      macros, items, mealOpts,
      mealLower: MEALS[meal].toLowerCase(),
      addLabel: 'Add to ' + MEALS[meal].toLowerCase() + ' \u00b7 ' + fmt(T.k) + ' kcal',
      addLog: () => {
        const entry = { id: Date.now(), date: '2026-10-09', meal, name: set.name, n: set.items.filter((_, i) => !off[i]).length, kcal: Math.round(T.k), p: Math.round(T.p), c: Math.round(T.c), f: Math.round(T.f), thumb: '' };
        const finish = (thumb) => {
          entry.thumb = thumb;
          try {
            const arr = JSON.parse(window.localStorage.getItem('calsen-log') || '[]');
            arr.push(entry);
            window.localStorage.setItem('calsen-log', JSON.stringify(arr.slice(-30)));
          } catch (e) {}
          this.setState({ stage: 'done' });
        };
        const im = new Image();
        im.onload = () => {
          try {
            const c = document.createElement('canvas');
            const sc = Math.min(1, 220 / Math.max(im.width, im.height));
            c.width = Math.max(1, Math.round(im.width * sc)); c.height = Math.max(1, Math.round(im.height * sc));
            c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
            finish(c.toDataURL('image/jpeg', 0.7));
          } catch (e) { finish(''); }
        };
        im.onerror = () => finish('');
        im.src = s.photo || '';
      },
      retake: () => this.retake()
    };
  }

  render() {
    const v = this.renderVals();
    return (
      <div
        className="app"
        data-theme={v.themeKey}
        style={{
          position: 'relative',
          width: '390px',
          height: '844px',
          boxSizing: 'border-box',
          fontFamily: '\'Plus Jakarta Sans\', system-ui, sans-serif',
          overflow: 'hidden',
        }}
      >
        <input
          id="photo-input"
          type="file"
          accept="image/*"
          capture="environment"
          onChange={v.onFile}
          style={{ display: 'none' }}
          aria-label="Choose or take a photo"
         />
        {v.inCamera && (
          <>
            <div
              className="fade"
              style={{
                position: 'absolute',
                left: '0',
                top: '0',
                right: '0',
                bottom: '0',
                background: '#080405',
                color: '#FFFFFF',
                overflow: 'hidden',
              }}
            >
              <div
                aria-hidden="true"
                style={{
                  position: 'absolute',
                  left: '0',
                  top: '0',
                  right: '0',
                  bottom: '0',
                  background: 'radial-gradient(90% 45% at 50% 30%, #6A3018 0%, rgba(59,85,110,0) 70%), radial-gradient(80% 40% at 50% 85%, #3F1822 0%, rgba(30,45,62,0) 70%), #0B0607',
                }}
              ></div>
              {v.showVideo && (
                <>
                  <video
                    id="cam"
                    autoPlay
                    playsInline
                    muted
                    style={{
                      position: 'absolute',
                      left: '0',
                      top: '0',
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      background: '#0B0607',
                    }}
                  ></video>
                </>
              )}
              <div
                aria-hidden="true"
                style={{
                  position: 'absolute',
                  left: '0',
                  top: '0',
                  right: '0',
                  bottom: '0',
                  background: 'rgba(6,10,18,.32)',
                }}
              ></div>
              <div
                style={{
                  position: 'absolute',
                  left: '20px',
                  right: '20px',
                  top: '28px',
                  height: '44px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <a
                  href={ROUTES.home}
                  className="cbtn"
                  aria-label="Back to home"
                  onClick={(e) => { go(e, 'home', this.props); }}
                >
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M15 5l-7 7 7 7"></path>
                  </svg>
                </a>
                <h1
                  style={{
                    position: 'absolute',
                    left: '0',
                    right: '0',
                    margin: '0',
                    textAlign: 'center',
                    fontSize: '20px',
                    lineHeight: '28px',
                    fontWeight: '700',
                    pointerEvents: 'none',
                  }}
                >Scan</h1>
                <span></span>
                <button className="cbtn" aria-label="Switch camera" onClick={v.flip}>
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.9"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M4 9a8 8 0 0 1 14-3l2 2"></path>
                    <path d="M20 4v4h-4"></path>
                    <path d="M20 15a8 8 0 0 1-14 3l-2-2"></path>
                    <path d="M4 20v-4h4"></path>
                  </svg>
                </button>
              </div>
              <div
                style={{
                  position: 'absolute',
                  left: '0',
                  right: '0',
                  top: '84px',
                  bottom: '206px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '18px',
                  padding: '0 20px',
                  boxSizing: 'border-box',
                }}
              >
                <div
                  style={{
                    position: 'relative',
                    flex: 'none',
                    height: 'min(300px, calc(100% - 128px))',
                    minHeight: '190px',
                    aspectRatio: '1 / 1',
                    borderRadius: '34px',
                    overflow: 'visible',
                  }}
                >
                  <div
                    style={{
                      position: 'absolute',
                      left: '0',
                      top: '0',
                      right: '0',
                      bottom: '0',
                      borderRadius: '34px',
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      className="scanline"
                      aria-hidden="true"
                      style={{
                        position: 'absolute',
                        left: '0',
                        right: '0',
                        top: '0',
                        height: '74px',
                      }}
                    >
                      <div style={{ height: '2px', background: '#FFFFFF', boxShadow: '0 0 14px rgba(255,255,255,.7)' }}></div>
                      <div
                        style={{
                          height: '72px',
                          background: 'linear-gradient(180deg, rgba(255,255,255,.3), rgba(255,255,255,0))',
                        }}
                      ></div>
                    </div>
                  </div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      left: '0',
                      top: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderTopWidth: '3px',
                      borderLeftWidth: '3px',
                      borderTopLeftRadius: '34px',
                    }}
                  ></div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      right: '0',
                      top: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderTopWidth: '3px',
                      borderRightWidth: '3px',
                      borderTopRightRadius: '34px',
                    }}
                  ></div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      left: '0',
                      bottom: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderBottomWidth: '3px',
                      borderLeftWidth: '3px',
                      borderBottomLeftRadius: '34px',
                    }}
                  ></div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      right: '0',
                      bottom: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderBottomWidth: '3px',
                      borderRightWidth: '3px',
                      borderBottomRightRadius: '34px',
                    }}
                  ></div>
                </div>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '10px',
                    textAlign: 'center',
                    maxWidth: '320px',
                  }}
                >
                  <span
                    style={{
                      padding: '5px 12px',
                      borderRadius: '14px',
                      background: 'rgba(255,255,255,.16)',
                      fontSize: '13px',
                      fontWeight: '700',
                    }}
                  >Adding to {v.mealLower}</span>
                  <div style={{ fontSize: '18px', lineHeight: '24px', fontWeight: '500' }}>Place your meal inside the frame</div>
                  {v.camOff && (
                    <>
                      <div style={{ fontSize: '13px', lineHeight: '18px', color: 'rgba(255,255,255,.7)' }}>{v.camHint}</div>
                    </>
                  )}
                </div>
              </div>
              <button
                className="press"
                aria-label="Flash"
                aria-pressed={v.flashOn}
                style={{
                  position: 'absolute',
                  left: '50%',
                  bottom: '150px',
                  marginLeft: '-22px',
                  width: '44px',
                  height: '44px',
                  border: '0',
                  background: 'transparent',
                  color: '#FFFFFF',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '0',
                  cursor: 'pointer',
                  opacity: v.flashOpacity,
                }}
                onClick={v.toggleFlash}
              >
                <svg
                  width="26"
                  height="26"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M13 2L4 14h7l-1 8 9-12h-7z"></path>
                  <path d={v.flashSlash}></path>
                </svg>
              </button>
              <div
                style={{
                  position: 'absolute',
                  left: '50%',
                  bottom: '44px',
                  transform: 'translateX(-50%)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '8px',
                  borderRadius: '44px',
                  background: 'rgba(255,255,255,.16)',
                }}
              >
                <button
                  className="press"
                  aria-label="Choose from gallery"
                  style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '32px',
                    border: '0',
                    background: 'transparent',
                    color: '#FFFFFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '0',
                    cursor: 'pointer',
                  }}
                  onClick={v.openGallery}
                >
                  <svg
                    width="26"
                    height="26"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <rect x="3.5" y="4.5" width="17" height="15" rx="3"></rect>
                    <circle cx="9" cy="10" r="1.6"></circle>
                    <path d="M4 17l5-4.5 4 3 3-2.5 4 3.5"></path>
                  </svg>
                </button>
                <button
                  className="press"
                  aria-label="Take photo"
                  style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '32px',
                    border: '0',
                    background: '#FFFFFF',
                    color: '#080405',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '0',
                    cursor: 'pointer',
                  }}
                  onClick={v.capture}
                >
                  <svg
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.9"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M4 8h3l2-3h6l2 3h3v11H4z"></path>
                    <circle cx="12" cy="13" r="3.4"></circle>
                  </svg>
                </button>
              </div>
            </div>
          </>
        )}
        {v.isScan && (
          <>
            <div
              className="fade"
              style={{
                position: 'absolute',
                left: '0',
                top: '0',
                right: '0',
                bottom: '0',
                background: '#080405',
                color: '#FFFFFF',
                overflow: 'hidden',
              }}
            >
              <img
                src={v.photo}
                alt=""
                aria-hidden="true"
                style={{
                  position: 'absolute',
                  left: '-20px',
                  top: '-20px',
                  width: '430px',
                  height: '884px',
                  objectFit: 'cover',
                  filter: 'blur(22px)',
                }}
               />
              <div
                aria-hidden="true"
                style={{
                  position: 'absolute',
                  left: '0',
                  top: '0',
                  right: '0',
                  bottom: '0',
                  background: 'rgba(6,10,18,.45)',
                }}
              ></div>
              <div
                style={{
                  position: 'absolute',
                  left: '20px',
                  right: '20px',
                  top: '28px',
                  height: '44px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <button className="cbtn" aria-label="Cancel scan" onClick={v.retake}>
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M15 5l-7 7 7 7"></path>
                  </svg>
                </button>
                <h1
                  style={{
                    position: 'absolute',
                    left: '0',
                    right: '0',
                    margin: '0',
                    textAlign: 'center',
                    fontSize: '20px',
                    lineHeight: '28px',
                    fontWeight: '700',
                    pointerEvents: 'none',
                  }}
                >Scan</h1>
                <span></span>
              </div>
              <div
                style={{
                  position: 'absolute',
                  left: '0',
                  right: '0',
                  top: '84px',
                  bottom: '206px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '18px',
                  padding: '0 20px',
                  boxSizing: 'border-box',
                }}
              >
                <div
                  style={{
                    position: 'relative',
                    flex: 'none',
                    height: 'min(300px, calc(100% - 128px))',
                    minHeight: '190px',
                    aspectRatio: '1 / 1',
                    borderRadius: '34px',
                    overflow: 'visible',
                  }}
                >
                  <div
                    style={{
                      position: 'absolute',
                      left: '0',
                      top: '0',
                      right: '0',
                      bottom: '0',
                      borderRadius: '34px',
                      overflow: 'hidden',
                      background: '#0B0607',
                    }}
                  >
                    <img
                      src={v.photo}
                      alt="Your meal photo"
                      style={{
                        position: 'absolute',
                        left: '0',
                        top: '0',
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                      }}
                     />
                    <div
                      className="scanline"
                      aria-hidden="true"
                      style={{
                        position: 'absolute',
                        left: '0',
                        right: '0',
                        top: '0',
                        height: '74px',
                      }}
                    >
                      <div style={{ height: '2px', background: '#FFFFFF', boxShadow: '0 0 14px rgba(255,255,255,.7)' }}></div>
                      <div
                        style={{
                          height: '72px',
                          background: 'linear-gradient(180deg, rgba(255,255,255,.3), rgba(255,255,255,0))',
                        }}
                      ></div>
                    </div>
                  </div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      left: '0',
                      top: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderTopWidth: '3px',
                      borderLeftWidth: '3px',
                      borderTopLeftRadius: '34px',
                    }}
                  ></div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      right: '0',
                      top: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderTopWidth: '3px',
                      borderRightWidth: '3px',
                      borderTopRightRadius: '34px',
                    }}
                  ></div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      left: '0',
                      bottom: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderBottomWidth: '3px',
                      borderLeftWidth: '3px',
                      borderBottomLeftRadius: '34px',
                    }}
                  ></div>
                  <div
                    aria-hidden="true"
                    style={{
                      position: 'absolute',
                      right: '0',
                      bottom: '0',
                      width: '108px',
                      height: '108px',
                      boxSizing: 'border-box',
                      border: '0 solid #FFFFFF',
                      borderBottomWidth: '3px',
                      borderRightWidth: '3px',
                      borderBottomRightRadius: '34px',
                    }}
                  ></div>
                </div>
                <div
                  role="status"
                  style={{
                    textAlign: 'center',
                    fontSize: '18px',
                    lineHeight: '24px',
                    fontWeight: '500',
                  }}
                >Scanning......{v.pct}%</div>
              </div>
            </div>
          </>
        )}
        {v.isResult && (
          <div
            style={{
              position: "absolute",
              left: 0,
              top: 0,
              right: 0,
              bottom: 0,
              overflowY: "auto",
              zIndex: 30,
              background: v.darkUser ? "#0B0B0C" : "#FBF3EC",
            }}
          >
            <CalSenScanResult
              photo={v.photo}
              dark={v.darkUser}
              onToggleDark={v.toggleTheme}
              initialMeal={v.mealLower ? (v.mealLower.charAt(0).toUpperCase() + v.mealLower.slice(1)) : "Lunch"}
              dishName={v.mealName}
              onRetake={() => this.retake()}
              onClose={() => {
                if (this.props.onNavigate) this.props.onNavigate("home");
                else go(null, "home", this.props);
              }}
              onNavigate={(r) => {
                if (this.props.onNavigate) this.props.onNavigate(r);
                else go(null, r, this.props);
              }}
              onLogComplete={() => {
                this.setState({ stage: "done" });
              }}
            />
          </div>
        )}
        {v.isDone && (
          <>
            <div
              className="rise"
              style={{
                position: 'absolute',
                left: '0',
                top: '0',
                right: '0',
                bottom: '0',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '18px',
                padding: '0 28px',
                textAlign: 'center',
              }}
            >
              <div
                aria-hidden="true"
                style={{
                  width: '92px',
                  height: '92px',
                  borderRadius: '46px',
                  background: v.accent,
                  color: 'var(--on-accent)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: `0 0 40px ${v.glow}`,
                }}
              >
                <svg
                  width="44"
                  height="44"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M5 12.5l4.5 4.5L19 7.5"></path>
                </svg>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <h1
                  style={{
                    margin: '0',
                    fontSize: '28px',
                    lineHeight: '34px',
                    fontWeight: '800',
                    letterSpacing: '-0.03em',
                  }}
                >Added to {v.mealLower}</h1>
                <p
                  style={{
                    margin: '0',
                    fontSize: '16px',
                    lineHeight: '22px',
                    color: 'var(--muted)',
                  }}
                >
                  <b style={{ color: 'var(--ink)' }}>{v.total} kcal</b>
                  {' '}from {v.mealName} is now in your log.
                </p>
              </div>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px',
                  width: '100%',
                  marginTop: '8px',
                }}
              >
                <a
                  href={ROUTES.home}
                  className="press"
                  style={{
                    height: '56px',
                    borderRadius: '28px',
                    background: v.accent,
                    color: 'var(--on-accent)',
                    fontSize: '16px',
                    fontWeight: '800',
                    textDecoration: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: `0 8px 20px ${v.glow}`,
                  }}
                  onClick={(e) => { go(e, 'home', this.props); }}
                >Back to home</a>
                <a
                  href={ROUTES.log}
                  className="press"
                  style={{
                    height: '56px',
                    borderRadius: '28px',
                    border: '1px solid var(--edge)',
                    background: 'var(--glass)',
                    color: 'var(--ink)',
                    fontSize: '16px',
                    fontWeight: '800',
                    textDecoration: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  onClick={(e) => { go(e, 'log', this.props); }}
                >View food log</a>
                <button
                  className="press"
                  style={{
                    height: '48px',
                    borderRadius: '24px',
                    border: '0',
                    background: 'transparent',
                    color: 'var(--muted)',
                    fontSize: '15px',
                    fontWeight: '700',
                    cursor: 'pointer',
                  }}
                  onClick={v.retake}
                >Scan another meal</button>
              </div>
            </div>
          </>
        )}
      </div>
    );
  }
}
