import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  Circle,
  CircleHelp,
  Download,
  FileJson,
  FlaskConical,
  Globe2,
  HardDrive,
  ListChecks,
  MonitorSmartphone,
  RefreshCw,
  Server,
  Smartphone,
  Terminal,
  Upload,
  XCircle,
} from "lucide-react";
import type { Mp4Check } from "@/types";
import { downloadBlob } from "@/lib/media";
import { SectionHeader, Segmented } from "@/components/ui";
import { TEST_REPORT_KEY, type TestReport } from "@/pages/SelfTestPage";
import { cn } from "@/utils/cn";

type AcceptanceStatus = "untested" | "pass" | "fail";
interface AcceptanceRow {
  id: number;
  label: string;
  detail: string;
  status: AcceptanceStatus;
  note?: string;
}
const ACCEPTANCE_KEY = "quiz-studio-acceptance-report";

const DEFAULT_ACCEPTANCE: AcceptanceRow[] = [
  { id: 1, label: "إنشاء سؤال بأربعة خيارات وتحديد الإجابة", detail: "محرر الأسئلة مع منع التصدير عند النقص", status: "untested" },
  { id: 2, label: "رفع ملفي صوت وتشغيلهما", detail: "MP3/WAV/M4A مع معاينة داخل البطاقة", status: "untested" },
  { id: 3, label: "ملف صوت قصير وآخر طويل", detail: "يُختبر التوقيت الفعلي لكل ملف", status: "untested" },
  { id: 4, label: "انتهاء الصوت في الوقت الصحيح", detail: "قارن مدة القراءة بنهاية الشريط في المعاينة", status: "untested" },
  { id: 5, label: "ظهور الإجابة في اللحظة المحددة", detail: "التفكير ثم اللون الأخضر ثم الانتقال", status: "untested" },
  { id: 6, label: "إنشاء فيديو بسؤال واحد وتصديره MP4", detail: "استخدم صفحة اختبار المحرك أو مشروعك", status: "untested" },
  { id: 7, label: "تنزيل الفيديو وتشغيله ووجود الصوت والصورة", detail: "بعد التنزيل شغّله في مشغل الجهاز", status: "untested" },
  { id: 8, label: "اختبار العربية والتشكيل", detail: "النصوص والأرقام واتجاه RTL", status: "untested" },
  { id: 9, label: "تصدير عمودي وأفقي", detail: "1080×1920 و1920×1080", status: "untested" },
  { id: 10, label: "مشروع متعدد الأسئلة", detail: "تسلسل المشاهد والانتقالات", status: "untested" },
  { id: 11, label: "حفظ المشروع وإعادة فتحه", detail: "IndexedDB + تحديث الصفحة", status: "untested" },
  { id: 12, label: "الملفات المفقودة والتالفة", detail: "الفحص المسبق ورسائل إعادة الرفع", status: "untested" },
  { id: 13, label: "واجهة الهاتف واللمس", detail: "الشاشات الصغيرة والتمرير والتحريك", status: "untested" },
  { id: 14, label: "عدم وجود شاشة سوداء أو صوت مفقود أو توقف", detail: "راجع الملف الناتج كاملًا قبل النشر", status: "untested" },
];

function loadAcceptance(): AcceptanceRow[] {
  try {
    const raw = localStorage.getItem(ACCEPTANCE_KEY);
    if (!raw) return DEFAULT_ACCEPTANCE;
    const parsed = JSON.parse(raw) as AcceptanceRow[];
    return DEFAULT_ACCEPTANCE.map((row) => {
      const stored = parsed.find((entry) => entry.id === row.id);
      return stored ? { ...row, status: stored.status, note: stored.note } : row;
    });
  } catch {
    return DEFAULT_ACCEPTANCE;
  }
}

export function HelpPage() {
  const [report, setReport] = useState<TestReport | null>(null);
  const [tab, setTab] = useState<"start" | "report" | "export">("start");
  const [acceptance, setAcceptance] = useState<AcceptanceRow[]>(loadAcceptance);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(TEST_REPORT_KEY);
      if (raw) setReport(JSON.parse(raw) as TestReport);
    } catch {
      /* ignore */
    }
  }, []);

  const counts = useMemo(() => {
    return {
      pass: acceptance.filter((row) => row.status === "pass").length,
      fail: acceptance.filter((row) => row.status === "fail").length,
      untested: acceptance.filter((row) => row.status === "untested").length,
    };
  }, [acceptance]);

  const updateAcceptance = (id: number, status: AcceptanceStatus) => {
    const next = acceptance.map((row) => (row.id === id ? { ...row, status } : row));
    setAcceptance(next);
    try {
      localStorage.setItem(ACCEPTANCE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const downloadTemplate = () => {
    const template = {
      instructions: ["correct هو رقم الخيار الصحيح 0..3.", "أسماء الملفات: q01_question.mp3 وq01_options.mp3 وq01_answer.mp3."],
      questions: [
        {
          question: "ما هي عاصمة المملكة العربية السعودية؟",
          options: ["الرياض", "جدة", "مكة المكرمة", "الدمام"],
          correct: 0,
          thinkingSec: 8,
          revealHoldMs: 1800,
          question_audio: "q01_question.mp3",
          options_audio: "q01_options.mp3",
          answer_audio: "q01_answer.mp3",
        },
        {
          question: "أي كوكب يُعرف بالكوكب الأحمر؟",
          options: ["المريخ", "الزهرة", "المشتري", "عطارد"],
          correct: 0,
          thinkingSec: 10,
          question_audio: "q02_question.mp3",
          options_audio: "q02_options.mp3",
        },
      ],
    };
    downloadBlob(new Blob([JSON.stringify(template, null, 2)], { type: "application/json" }), "quiz-studio-sample-questions.json");
  };

  const downloadReport = () => {
    const lines = [
      "تقرير اختبار Quiz Studio Pro",
      `التاريخ: ${new Date().toLocaleString("ar")}`,
      "",
      "نتيجة اختبار محرك MP4:",
      report
        ? `${report.ok ? "نجح" : "فشل"} — ${new Date(report.at).toLocaleString("ar")} — ${report.orientation === "vertical" ? "عمودي" : "أفقي"} — ${report.width}×${report.height} — ${report.audioCodec}`
        : "لم يُشغّل اختبار المحرك على هذا الجهاز بعد.",
      report?.error ? `الخطأ: ${report.error}` : "",
      "",
      "قائمة القبول:",
      ...acceptance.map((row) => `${row.id}. ${row.label} — ${row.status === "pass" ? "نجح" : row.status === "fail" ? "فشل" : "لم يُختبر"} (${row.detail})`),
      "",
      "ملاحظة: هذه القائمة تعكس ما سجّله المستخدم/المشغّل داخل المتصفح، وليست ادعاءً بنجاح اختبارات لم تُنفّذ.",
    ];
    downloadBlob(new Blob([lines.filter(Boolean).join("\n")], { type: "text/plain;charset=utf-8" }), "quiz-studio-test-report.txt");
  };

  return (
    <div>
      <SectionHeader
        icon={<CircleHelp size={18} />}
        eyebrow="الدليل والتشغيل"
        title="الدليل وتقرير الاختبار"
        description="طريقة تشغيل المشروع، إضافة الأصوات، تصدير أول فيديو، وما تم التحقق منه فعليًا على هذا الجهاز — دون ادعاء اختبارات لم تُنفّذ."
        actions={
          <>
            <button type="button" onClick={downloadTemplate} className="btn btn-ghost"><Download size={14} /> نموذج الأسئلة</button>
            <button type="button" onClick={downloadReport} className="btn btn-primary"><Download size={14} /> تنزيل تقرير الاختبار</button>
          </>
        }
      />

      <div className="mb-4 inline-flex w-full max-w-md">
        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { value: "start", label: "البدء والتشغيل" },
            { value: "report", label: "تقرير الاختبار" },
            { value: "export", label: "التصدير والاستضافة" },
          ]}
        />
      </div>

      {tab === "start" ? (
        <div className="grid gap-4 lg:grid-cols-[1.25fr_1fr]">
          <div className="space-y-4">
            <section className="panel p-4">
              <h3 className="mb-3 flex items-center gap-2 font-display text-[16px] font-bold text-white"><BookOpen size={16} className="text-[#d9b65a]" /> أول فيديو في 5 خطوات</h3>
              <ol className="space-y-2.5">
                {[
                  ["أضف الأسئلة", "من صفحة «الأسئلة» اكتب السؤال والخيارات الأربعة، ثم اضغط «حدّد كصحيحة» بجانب إجابة واحدة."],
                  ["ارفع الصوت", "لكل سؤال: ملف صوت السؤال + ملف صوت الخيارات. يمكنك استخدام ملف واحد موحّد من صفحة الصوت. الصوت اختياري لكن يفضّل تسجيله بصوت واضح."],
                  ["اضبط التوقيت", "اختر مدة التفكير. يبدأ المؤقت تلقائيًا بعد انتهاء الصوت. أضف مؤثر الإجابة والموسيقى إن أردت."],
                  ["شاهد المعاينة", "اضغط تشغيل في صفحة المعاينة وتحقق من تزامن الصوت وحركة كشف الإجابة قبل التصدير."],
                  ["صدّر MP4", "من صفحة التصدير اختر 1080×1920 و30 إطارًا، ثم «إنشاء الفيديو». بعد التحقق اضغط «تنزيل MP4»."],
                ].map(([title, text], index) => (
                  <li key={title} className="flex gap-2.5">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[#d9b65a]/25 bg-[#d9b65a]/10 font-display text-[11px] font-bold text-[#e7cf94]">{index + 1}</span>
                    <div><p className="text-[12px] font-semibold text-[#eeeef2]">{title}</p><p className="mt-0.5 text-[11px] leading-6 text-[#8b8b95]">{text}</p></div>
                  </li>
                ))}
              </ol>
            </section>

            <section className="panel p-4">
              <h3 className="mb-3 flex items-center gap-2 font-display text-[16px] font-bold text-white"><Upload size={16} className="text-[#57dc96]" /> تسمية الملفات والاستيراد</h3>
              <div className="rounded-lg border border-white/[0.08] bg-[#0a0a0d] p-3 font-mono text-[10px] leading-6 text-[#d6c188]" dir="ltr">
                q01_question.mp3 → صوت السؤال الأول<br />
                q01_options.mp3 &nbsp;→ صوت خياراته<br />
                q01_answer.mp3 &nbsp;&nbsp;→ صوت الإجابة الصحيحة<br />
                q01.jpg &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;→ خلفية السؤال الأول
              </div>
              <p className="mt-2 text-[11px] leading-6 text-[#8b8b95]">ارفع JSON من صفحة الأسئلة، ثم مجموعة الصوتيات أو ZIP. يراجع التطبيق الملفات المطابقة والمفقودة قبل التطبيق، ويطلب تأكيدك عند وجود أسماء مكررة. الإجابات الصحيحة تُقرأ من الحقل <span dir="ltr" className="text-[#d9c187]">correct</span> من 0 إلى 3.</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button type="button" onClick={downloadTemplate} className="btn btn-ghost !py-1.5 text-[10px]"><FileJson size={12} /> نموذج JSON</button>
              </div>
            </section>

            <section className="panel p-4">
              <h3 className="mb-3 flex items-center gap-2 font-display text-[16px] font-bold text-white"><Terminal size={16} className="text-[#c9c9d1]" /> تشغيل مشروع التطوير</h3>
              <div className="rounded-lg border border-white/[0.08] bg-[#08080a] p-3 text-[10px] leading-7 text-[#b9d7c5]" dir="ltr">
                npm install<br />
                npm run dev<br />
                npm run build<br />
                npm run preview
              </div>
              <p className="mt-2 text-[11px] leading-6 text-[#8b8b95]">افتح الرابط الظاهر من الكمبيوتر. من هاتف على نفس الشبكة استخدم عنوان الشبكة الذي يطبعه Vite. للتصدير يجب أن يعمل الموقع على HTTPS أو localhost.</p>
            </section>
          </div>

          <div className="space-y-4">
            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[15px] font-bold text-white"><MonitorSmartphone size={15} className="text-[#d9b65a]" /> المتصفحات والأجهزة</h3>
              <div className="space-y-2 text-[11px] leading-6 text-[#8b8b95]">
                <p className="flex gap-2"><CheckCircle2 size={13} className="mt-1 shrink-0 text-[#6fe0a4]" /><span><b className="text-[#d8d8de]">Chrome / Edge حديث:</b> أفضل دعم لتصدير MP4 محليًا.</span></p>
                <p className="flex gap-2"><CheckCircle2 size={13} className="mt-1 shrink-0 text-[#6fe0a4]" /><span><b className="text-[#d8d8de]">Safari 16.4+:</b> يدعم WebCodecs، وقد يختلف ترميز الصوت حسب النظام.</span></p>
                <p className="flex gap-2"><AlertTriangle size={13} className="mt-1 shrink-0 text-[#e7cf94]" /><span><b className="text-[#d8d8de]">Firefox:</b> دعم ترميز الفيديو/الصوت عبر WebCodecs محدود، شغّل الاختبار للتأكد من جهازك.</span></p>
                <p className="flex gap-2"><Smartphone size={13} className="mt-1 shrink-0 text-[#c9c9d1]" /><span><b className="text-[#d8d8de]">Android:</b> استخدم Chrome. مدة التصدير حتى 6 دقائق في هذه النسخة؛ اختر الدقة الخفيفة 720×1280 للأجهزة المتوسطة.</span></p>
              </div>
            </section>

            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[15px] font-bold text-white"><HardDrive size={15} className="text-[#57dc96]" /> أين تُحفظ ملفاتي؟</h3>
              <p className="text-[11px] leading-6 text-[#8b8b95]">بيانات المشروع (الأسئلة والتصميم والإعدادات) وملفات الصوت والصور تُحفظ في <b className="text-[#d8d8de]">IndexedDB</b> على هذا المتصفح/الجهاز. لا تُرفع إلى خادم. إذا مسحت بيانات المتصفح أو استخدمت جهازًا آخر فلن تجدها؛ نزّل «حزمة المشروع» ZIP للنسخ الاحتياطي. الملفات المفقودة لا يمكن استعادتها إلا بإعادة رفعها أو استيراد الحزمة.</p>
            </section>

            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[15px] font-bold text-white"><FlaskConical size={15} className="text-[#d9b65a]" /> هل احتاج FFmpeg؟</h3>
              <p className="text-[11px] leading-6 text-[#8b8b95]">لا. هذه النسخة تستخدم WebCodecs + mp4-muxer لبناء MP4 (H.264 + AAC) داخل المتصفح. لا يوجد تسجيل شاشة ولا خادم ولا حاجة لتثبيت FFmpeg. للأجهزة التي لا تدعم الترميز، البديل الفعلي هو تصدير حزمة المشروع وفتحها في متصفح مدعوم (Chrome). خيار خادم FFmpeg غير مضمّن في هذه النسخة لأنه يتطلب بنية خلفية ورفع ملفات وائتمانات تشغيل، وقد أوضحناه بدل الادعاء.</p>
            </section>
          </div>
        </div>
      ) : null}

      {tab === "report" ? (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="panel p-3.5"><p className="text-[10px] text-[#85858f]">حالات نجحت (مسجّلة)</p><p className="mt-1 font-display text-[22px] font-bold text-[#8cebb5]">{counts.pass}</p></div>
            <div className="panel p-3.5"><p className="text-[10px] text-[#85858f]">حالات فشلت</p><p className="mt-1 font-display text-[22px] font-bold text-red-300">{counts.fail}</p></div>
            <div className="panel p-3.5"><p className="text-[10px] text-[#85858f]">لم تُختبر بعد</p><p className="mt-1 font-display text-[22px] font-bold text-[#e7cf94]">{counts.untested}</p></div>
          </div>

          <div className="grid gap-4 lg:grid-cols-[1fr_1.35fr]">
            <div className="space-y-3">
              <div className={cn("panel overflow-hidden", report?.ok && "border-[#57dc96]/25")}>
                <div className="flex items-center justify-between border-b border-white/[0.07] px-3.5 py-2.5">
                  <h3 className="flex items-center gap-1.5 font-display text-[14px] font-bold text-white"><FlaskConical size={14} className="text-[#d9b65a]" /> اختبار محرك MP4</h3>
                  <span className={cn("chip !py-0.5", report ? report.ok ? "chip-mint" : "chip-red" : "")}>{report ? report.ok ? "نجح" : "فشل" : "لم يُنفّذ"}</span>
                </div>
                {report ? (
                  <div className="space-y-1.5 p-3.5 text-[10px]">
                    <div className="flex justify-between"><span className="text-[#85858f]">التاريخ</span><span className="text-[#d5d5dc]">{new Date(report.at).toLocaleString("ar")}</span></div>
                    <div className="flex justify-between"><span className="text-[#85858f]">الاتجاه والأبعاد</span><span className="text-[#d5d5dc]">{report.orientation === "vertical" ? "عمودي" : "أفقي"} · {report.width}×{report.height}</span></div>
                    <div className="flex justify-between"><span className="text-[#85858f]">الصوت/الفيديو</span><span className="text-[#d5d5dc]" dir="ltr">{report.audioCodec || "—"} / {report.videoCodec || "—"}</span></div>
                    <div className="flex justify-between"><span className="text-[#85858f]">المدة</span><span className="text-[#d5d5dc]">{report.duration.toFixed(2)} ث</span></div>
                    {report.checks?.length ? (
                      <div className="mt-2 space-y-1">
                        {report.checks.map((check: Mp4Check) => (
                          <div key={check.key} className="flex items-center gap-1.5 rounded-md border border-white/[0.06] bg-white/[0.02] px-2 py-1 text-[9px]">
                            {check.status === "fail" ? <XCircle size={10} className="text-red-300" /> : <CheckCircle2 size={10} className="text-[#6fe0a4]" />}
                            <span className="text-[#c5c5ce]">{check.label}</span>
                          </div>
                        ))}
                      </div>
                    ) : null}
                    {report.error ? <p className="mt-1 rounded-md border border-red-400/20 bg-red-400/[0.05] px-2 py-1 text-[9px] text-red-200">{report.error}</p> : null}
                  </div>
                ) : (
                  <p className="p-3.5 text-[11px] leading-6 text-[#85858f]">لم يُشغّل اختبار المحرك على هذا المتصفح بعد. افتح صفحة «اختبار المحرك» واضغط تشغيل. لا يمكن لهذه الصفحة ادعاء نجاح اختبار لم يُنفّذ.</p>
                )}
              </div>
              <div className="rounded-xl border border-white/[0.07] bg-white/[0.015] p-3 text-[10px] leading-5 text-[#7e7e88]">
                <p className="mb-1 flex items-center gap-1.5 font-semibold text-[#b9b9c2]"><CircleHelp size={12} /> كيف يُسجّل التقرير؟</p>
                الحالات أدناه يحدّدها المستخدم بعد تجربة فعلية. اختبار المحرك وحده يسجّل تلقائيًا ويفحص بنية MP4 ومساري الصوت والفيديو. أي حالة أخرى تبقى «لم تُختبر» حتى تجربها بنفسك.
              </div>
            </div>

            <div className="panel overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/[0.07] px-3.5 py-2.5">
                <h3 className="flex items-center gap-1.5 font-display text-[14px] font-bold text-white"><ListChecks size={14} className="text-[#57dc96]" /> حالات القبول الـ14</h3>
                <button type="button" onClick={() => { setAcceptance(DEFAULT_ACCEPTANCE); localStorage.removeItem(ACCEPTANCE_KEY); }} className="flex items-center gap-1 text-[9px] text-[#8a8a94] hover:text-white"><RefreshCw size={10} /> تصفير السجل</button>
              </div>
              <div className="max-h-[540px] divide-y divide-white/[0.05] overflow-y-auto">
                {acceptance.map((row) => (
                  <div key={row.id} className="flex items-start gap-2.5 px-3 py-2.5">
                    <span className={cn("mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border text-[9px]", row.status === "pass" ? "border-[#57dc96]/30 bg-[#57dc96]/10 text-[#8cebb5]" : row.status === "fail" ? "border-red-400/30 bg-red-400/10 text-red-300" : "border-white/10 text-[#6f6f79]")}>
                      {row.status === "pass" ? <CheckCircle2 size={10} /> : row.status === "fail" ? <XCircle size={10} /> : <Circle size={10} />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className={cn("text-[11px] font-medium", row.status === "pass" ? "text-[#d6f1e2]" : row.status === "fail" ? "text-red-100" : "text-[#d3d3da]")}>{row.id}. {row.label}</p>
                      <p className="mt-0.5 text-[9px] leading-4 text-[#777781]">{row.detail}</p>
                    </div>
                    <select
                      value={row.status}
                      onChange={(event) => updateAcceptance(row.id, event.target.value as AcceptanceStatus)}
                      className="shrink-0 rounded-md border border-white/10 bg-[#0a0a0d] px-1 py-1 text-[9px] text-[#c9c9d1] outline-none"
                      aria-label={`حالة اختبار ${row.label}`}
                    >
                      <option value="untested">لم يُختبر</option>
                      <option value="pass">نجح</option>
                      <option value="fail">فشل</option>
                    </select>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {tab === "export" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-4">
            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[16px] font-bold text-white"><Server size={16} className="text-[#d9b65a]" /> كيف يعمل التصدير؟</h3>
              <ul className="space-y-2 text-[11px] leading-6 text-[#8b8b95]">
                <li className="flex gap-2"><CheckCircle2 size={12} className="mt-1 shrink-0 text-[#6fe0a4]" /> يفحص الأسئلة والملفات ثم يحسب المدة من الصوت الفعلي.</li>
                <li className="flex gap-2"><CheckCircle2 size={12} className="mt-1 shrink-0 text-[#6fe0a4]" /> يخلط الأصوات في AudioBuffer واحد (قارئ + موسيقى + مؤثر).</li>
                <li className="flex gap-2"><CheckCircle2 size={12} className="mt-1 shrink-0 text-[#6fe0a4]" /> يرسم كل إطار من نفس محرك المعاينة ويشفر H.264 عبر VideoEncoder.</li>
                <li className="flex gap-2"><CheckCircle2 size={12} className="mt-1 shrink-0 text-[#6fe0a4]" /> يطابق الصوت والفيديو بحاوية MP4 ثم يتحقق من ftyp/moov/المسارات قبل النجاح.</li>
                <li className="flex gap-2"><XCircle size={12} className="mt-1 shrink-0 text-red-300" /> لا يوجد تسجيل شاشة، ولا رفع للملفات إلى خادم، ولا ادعاء نجاح قبل نهاية الترميز.</li>
              </ul>
            </section>

            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[16px] font-bold text-white"><Globe2 size={16} className="text-[#57dc96]" /> النشر على استضافة</h3>
              <p className="text-[11px] leading-6 text-[#8b8b95]">المشروع يبنى كملفات ثابتة داخل <span dir="ltr" className="text-[#d9c187]">dist/</span>. شغّل <span dir="ltr" className="text-[#d9c187]">npm run build</span> ثم ارفع محتويات dist إلى Netlify أو Vercel أو Cloudflare Pages أو أي استضافة ثابتة. لا يحتاج خادم تطبيق. يجب تفعيل HTTPS لأن WebCodecs لا يعمل على HTTP. الخطوط تُحمّل من Google Fonts في أول زيارة؛ بعد فشل الشبكة يستخدم المتصفح خطًا احتياطيًا ولن يتوقف الموقع. لا ندّعي تشغيلًا كاملًا دون إنترنت في أول تحميل.</p>
              <div className="mt-2 rounded-lg border border-white/[0.08] bg-black/25 p-2.5 text-[10px] leading-6 text-[#8b8b95]">
                <p className="font-semibold text-[#d8d8de]">Netlify / Vercel</p>
                <p>Build command: <span dir="ltr" className="text-[#d9c187]">npm run build</span></p>
                <p>Publish directory: <span dir="ltr" className="text-[#d9c187]">dist</span></p>
              </div>
            </section>

            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[16px] font-bold text-white"><HardDrive size={16} className="text-[#c9c9d1]" /> حدود وبدائل</h3>
              <ul className="space-y-1.5 text-[11px] leading-6 text-[#8b8b95]">
                <li>• الحد الأقصى الحالي 10800 إطارًا (6 دقائق عند 30 إطارًا).</li>
                <li>• التصدير قد يستغرق وقتًا أطول من الفيديو على الهواتف؛ يظهر التقدم والوقت المتوقع.</li>
                <li>• إذا نفدت ذاكرة الجهاز: قلّل الأبعاد إلى 720p أو صدّر على دفعات.</li>
                <li>• إذا لم يدعم المتصفح H.264: نزّل حزمة المشروع وافتحها على Chrome مدعوم. خادم FFmpeg اختياري ولم يُضمَّن، ولا نقدّمه كبديل جاهز دون إعداد ورفع ملفات.</li>
                <li>• تغيير أو حذف ملفات من التخزين يجعل السؤال بحاجة لإعادة رفع؛ لا تُخزَّن روابط مؤقتة. استخدم ZIP للنسخ الاحتياطي.</li>
              </ul>
            </section>
          </div>

          <div className="space-y-4">
            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[16px] font-bold text-white"><ListChecks size={16} className="text-[#d9b65a]" /> حل المشكلات الشائعة</h3>
              <div className="space-y-2">
                {[
                  ["زر التصدير معطّل", "افتقد نص سؤال أو خيار، أو لم تحدد إجابة، أو ملف مرتبط مفقود. راجع الفحص المسبق أعلى صفحة التصدير."],
                  ["فشل ترميز الصوت أو الفيديو", "المتصفح لا يدعم WebCodecs/H.264. استخدم Chrome أو Safari حديثًا، أو صدّر على الكمبيوتر."],
                  ["صوت لا يظهر في المعاينة", "سياسة المتصفح تمنع التشغيل التلقائي. اضغط زر التشغيل. إذا كان الملف غير متاح أعد رفعه."],
                  ["الصوت في MP4 غير متزامن", "هذه النسخة مبنية على مدة الملف الفعلية، لكن الملفات ذات الترميز المتغير VBR قد تُقرأ بمدة مختلفة. أعد تصديرها CBR MP3/WAV ثم ارفعها."],
                  ["لا يمكن حفظ المشروع", "المساحة ممتلئة أو التصفح الخاص يمنع IndexedDB. احذف مشاريع/ملفات كبيرة أو استخدم وضعًا عاديًا ونزّل ZIP."],
                  ["الملفات اختفت بعد إعادة التحميل", "حُذفت من متصفحك أو بياناته. استورد حزمة المشروع ZIP أو أعد رفع الملفات."],
                  ["الاستيراد لا يجد الملفات", "أعد تسمية الملفات بالشكل q01_question.mp3، وتأكد أن الرقم يناظر ترتيب السؤال."],
                ].map(([title, text]) => (
                  <details key={title} className="group rounded-lg border border-white/[0.07] bg-white/[0.018] px-3 py-2">
                    <summary className="cursor-pointer text-[11px] font-medium text-[#d8d8de]">{title}</summary>
                    <p className="mt-1.5 text-[10px] leading-5 text-[#85858f]">{text}</p>
                  </details>
                ))}
              </div>
            </section>

            <section className="panel p-4">
              <h3 className="mb-2 flex items-center gap-2 font-display text-[16px] font-bold text-white"><Upload size={16} className="text-[#57dc96]" /> نموذج جاهز للأسئلة</h3>
              <p className="text-[11px] leading-6 text-[#8b8b95]">نموذج JSON عربي واضح مع أسماء الملفات المتوقعة. نزّله وعدّل النصوص، ثم استورده من صفحة الأسئلة.</p>
              <button type="button" onClick={downloadTemplate} className="btn btn-primary mt-2 w-full !py-2 text-[11px]"><Download size={13} /> تنزيل نموذج الأسئلة</button>
              <div className="mt-2 rounded-lg border border-[#d9b65a]/20 bg-[#d9b65a]/[0.04] p-2.5 text-[10px] leading-5 text-[#b6a37a]">
                <span className="flex items-center gap-1.5 font-semibold text-[#e7cf94]"><AlertTriangle size={11} /> لا يوجد نموذج محتوى مفروض</span>
                النموذج المرفق للتوضيح فقط. المشروع الحالي يبدأ بأسئلة نموذجية موسومة بوضوح، ويمكنك حذفها أو بدء مشروع فارغ.
              </div>
            </section>
          </div>
        </div>
      ) : null}
    </div>
  );
}
