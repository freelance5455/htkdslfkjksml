import { useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import { useProjects } from "@/hooks/useProjects";
import { getProject, saveProject } from "@/lib/storage";
import WorkflowStatus from "@/components/features/WorkflowStatus";
import TaskPanel from "@/components/features/TaskPanel";
import ProjectChat from "@/components/features/ProjectChat";
import ContentBriefView from "@/components/features/ContentBriefView";
import ScriptEditor from "@/components/features/ScriptEditor";
import StoryboardView from "@/components/features/StoryboardView";
import VideoEngineStudio from "@/components/features/VideoEngineStudio";
import ImageEngineStudio from "@/components/features/ImageEngineStudio";
import AudioEngineStudio from "@/components/features/AudioEngineStudio";
import ContentPackageBuilderView from "@/components/features/ContentPackageBuilderView";
import { YouTubeSEOAgentView } from "@/components/features/YouTubeSEOAgentView";
import { RepurposeStudioView } from "@/components/features/RepurposeStudioView";
import { ThumbnailOptimizerModal } from "@/components/features/ThumbnailOptimizerModal";
import { PrePublishApprovalModal } from "@/components/features/PrePublishApprovalModal";
import TimelineEditor from "@/components/features/TimelineEditor";
import AnalyzerResult from "@/components/features/AnalyzerResult";
import { cn, getStatusColor, getStatusLabel, formatDate } from "@/lib/utils";
import { CONTENT_TYPE_LABELS } from "@/constants";
import type { Project, Script, StoryboardScene } from "@/types";
import {
  ArrowLeft, Sparkles, FileText, Film, Layout,
  MessageSquare, Settings2, BarChart3, ChevronRight, Video, PackageCheck,
  Image as ImageIcon, Mic, TrendingUp, Scissors, Gauge, Send, Trash2
} from "lucide-react";
import { DeleteProjectConfirmModal } from "@/components/common/DeleteProjectConfirmModal";

type TabId = "overview" | "brief" | "script" | "storyboard" | "image" | "audio" | "video" | "seo" | "repurpose" | "package" | "timeline" | "chat";

const TABS: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: "overview", label: "Visão Geral", icon: BarChart3 },
  { id: "brief", label: "Briefing", icon: FileText },
  { id: "script", label: "Roteiro", icon: FileText },
  { id: "storyboard", label: "Storyboard", icon: Film },
  { id: "image", label: "Imagens AI", icon: ImageIcon },
  { id: "audio", label: "Voz & Áudio", icon: Mic },
  { id: "video", label: "Vídeo AI", icon: Video },
  { id: "seo", label: "SEO & Títulos (A-E)", icon: TrendingUp },
  { id: "repurpose", label: "Cortes Verticais", icon: Scissors },
  { id: "package", label: "Pacote Multiplataforma", icon: PackageCheck },
  { id: "timeline", label: "Timeline", icon: Layout },
  { id: "chat", label: "AI Chat", icon: MessageSquare },
];

const WORKFLOW_ORDER = [
  "IDEA", "BRIEFING", "SCRIPTING", "STORYBOARDING",
  "MEDIA_PLANNING", "GENERATING", "EDITING", "REVIEW", "RENDERING", "COMPLETED",
] as const;

export default function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { advanceWorkflow, updateProject, deleteProject, generateProjectMediaFast } = useProjects();
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [targetScene, setTargetScene] = useState<StoryboardScene | undefined>(undefined);
  const [localProject, setLocalProject] = useState<Project | null>(() => (id ? getProject(id) ?? null : null));

  // Modals & Fast Media Generation State
  const [thumbnailModalOpen, setThumbnailModalOpen] = useState(false);
  const [publishModalOpen, setPublishModalOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [fastProgress, setFastProgress] = useState<{ stage: string; percent: number } | undefined>(undefined);

  const handleDeleteProject = useCallback(() => {
    if (localProject) {
      deleteProject(localProject.id);
      setDeleteConfirmOpen(false);
      navigate("/projects");
    }
  }, [localProject, deleteProject, navigate]);

  const handleProjectUpdate = useCallback((updated: Project) => {
    setLocalProject(updated);
    updateProject(updated);
  }, [updateProject]);

  const handleGenerateAllMediaFast = async () => {
    if (!localProject || isGeneratingAll) return;
    setIsGeneratingAll(true);
    setFastProgress({ stage: "Iniciando geração paralela de vídeo, imagens e áudio...", percent: 15 });
    try {
      const updated = await generateProjectMediaFast(
        localProject,
        {},
        (stage, percent) => {
          setFastProgress({ stage, percent });
        }
      );
      setLocalProject(updated);
    } catch (err) {
      console.error("Erro na geração rápida de mídias:", err);
    } finally {
      setIsGeneratingAll(false);
      setFastProgress(undefined);
    }
  };

  if (!localProject) {
    return (
      <AppLayout title="Projeto não encontrado">
        <div className="flex flex-col items-center justify-center h-64">
          <p className="text-studio-text-muted mb-4">Projeto não encontrado</p>
          <button onClick={() => navigate("/projects")} className="btn-secondary">
            <ArrowLeft className="w-4 h-4" /> Voltar
          </button>
        </div>
      </AppLayout>
    );
  }

  const handleAdvance = async () => {
    const currentIdx = WORKFLOW_ORDER.indexOf(localProject.status as typeof WORKFLOW_ORDER[number]);
    if (currentIdx < WORKFLOW_ORDER.length - 1) {
      const nextStatus = WORKFLOW_ORDER[currentIdx + 1];
      await advanceWorkflow(localProject.id, nextStatus);
      const updated = getProject(localProject.id);
      if (updated) setLocalProject(updated);
    }
  };

  const handleBriefApprove = () => {
    if (localProject.brief) {
      const updated = { ...localProject, brief: { ...localProject.brief, status: "APPROVED" as const } };
      handleProjectUpdate(updated);
      handleAdvance();
      setActiveTab("script");
    }
  };

  const handleScriptUpdate = (script: Script) => {
    handleProjectUpdate({ ...localProject, script });
  };

  const canAdvance = localProject.status !== "COMPLETED" && localProject.status !== "FAILED";
  const nextStepLabel = () => {
    const idx = WORKFLOW_ORDER.indexOf(localProject.status as typeof WORKFLOW_ORDER[number]);
    if (idx < 0 || idx >= WORKFLOW_ORDER.length - 1) return null;
    const next = WORKFLOW_ORDER[idx + 1];
    const labels: Record<string, string> = {
      SCRIPTING: "Criar Roteiro", STORYBOARDING: "Criar Storyboard",
      MEDIA_PLANNING: "Planejar Mídia", GENERATING: "Gerar Mídia",
      EDITING: "Editar", REVIEW: "Revisar", RENDERING: "Renderizar", COMPLETED: "Concluir",
    };
    return labels[next] ?? `Avançar para ${next}`;
  };

  return (
    <AppLayout title={localProject.title} subtitle={`${CONTENT_TYPE_LABELS[localProject.contentType]} · ${localProject.platform}`}>
      <div className="flex h-[calc(100vh-56px)]">
        {/* Main content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Project header */}
          <div className="px-6 py-4 border-b border-studio-border bg-studio-surface/50 flex items-center gap-4">
            <button
              onClick={() => navigate("/projects")}
              className="p-2 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className={cn("task-badge text-xs", getStatusColor(localProject.status))}>
                  {getStatusLabel(localProject.status)}
                </span>
                <span className="text-xs text-studio-text-muted">{formatDate(localProject.createdAt)}</span>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                id="btn-delete-project-detail"
                type="button"
                onClick={() => setDeleteConfirmOpen(true)}
                className="px-2.5 py-2 rounded-lg text-studio-text-muted hover:text-rose-400 hover:bg-rose-500/10 border border-studio-border hover:border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all"
                title="Apagar este projeto definitivamente"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">Apagar</span>
              </button>

              <button
                onClick={() => setThumbnailModalOpen(true)}
                className="btn-secondary text-xs py-2 px-3 gap-1.5"
                title="Auditoria e Otimização de Thumbnail"
              >
                <Gauge className="w-3.5 h-3.5 text-studio-gold" />
                <span>Otimizar Capa</span>
              </button>

              <button
                id="btn-open-publish-approval"
                onClick={() => setPublishModalOpen(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-2 px-3.5 rounded-lg flex items-center gap-1.5 shadow-md shadow-emerald-900/20"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Aprovar & Publicar</span>
              </button>

              {canAdvance && nextStepLabel() && (
                <button
                  onClick={handleAdvance}
                  className="btn-primary text-sm py-2 px-4 gap-1.5 shrink-0"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  {nextStepLabel()}
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-0.5 px-4 py-2 border-b border-studio-border overflow-x-auto">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap",
                  activeTab === tab.id
                    ? "bg-studio-blue/10 text-studio-blue border border-studio-blue/20"
                    : "text-studio-text-dim hover:text-studio-text hover:bg-studio-panel"
                )}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === "overview" && (
              <div className="max-w-3xl space-y-6">
                {localProject.analyzedRequest && (
                  <AnalyzerResult result={localProject.analyzedRequest} />
                )}
                <WorkflowStatus status={localProject.status} />
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Plataforma", value: localProject.platform },
                    { label: "Idioma", value: localProject.settings.language },
                    { label: "Formato", value: localProject.settings.outputFormat },
                  ].map((item) => (
                    <div key={item.label} className="studio-card p-4 text-center">
                      <p className="text-xs text-studio-text-muted mb-1">{item.label}</p>
                      <p className="text-sm font-bold text-studio-text font-display">{item.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "brief" && (
              <div className="max-w-3xl">
                {localProject.brief ? (
                  <ContentBriefView
                    brief={localProject.brief}
                    onApprove={handleBriefApprove}
                    onRegenerate={() => {}}
                    onEdit={() => {}}
                  />
                ) : (
                  <div className="text-center py-16 studio-card">
                    <p className="text-studio-text-muted mb-4">Briefing não gerado ainda</p>
                    <button onClick={handleAdvance} className="btn-primary">
                      <Sparkles className="w-4 h-4" /> Gerar Briefing
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeTab === "script" && (
              <div className="max-w-3xl">
                {localProject.script ? (
                  <ScriptEditor script={localProject.script} onUpdate={handleScriptUpdate} />
                ) : (
                  <div className="text-center py-16 studio-card">
                    <p className="text-studio-text-muted mb-4">Roteiro não gerado ainda</p>
                    <button onClick={handleAdvance} className="btn-primary">
                      <Sparkles className="w-4 h-4" /> Gerar Roteiro
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeTab === "storyboard" && (
              <div className="max-w-3xl">
                {localProject.storyboard ? (
                  <StoryboardView
                    storyboard={localProject.storyboard}
                    onOpenVideoStudio={() => setActiveTab("video")}
                    onOpenImageStudio={() => setActiveTab("image")}
                    onOpenAudioStudio={() => setActiveTab("audio")}
                    onGenerateAllMediaFast={handleGenerateAllMediaFast}
                    isGeneratingAll={isGeneratingAll}
                    fastProgress={fastProgress}
                    onGenerateVideo={(scene) => {
                      setTargetScene(scene);
                      setActiveTab("video");
                    }}
                    onGenerateImage={(scene) => {
                      setTargetScene(scene);
                      setActiveTab("image");
                    }}
                    onGenerateAudio={(scene) => {
                      setTargetScene(scene);
                      setActiveTab("audio");
                    }}
                  />
                ) : (
                  <div className="text-center py-16 studio-card">
                    <p className="text-studio-text-muted mb-4">Storyboard não gerado ainda</p>
                    <button onClick={handleAdvance} className="btn-primary">
                      <Sparkles className="w-4 h-4" /> Gerar Storyboard
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeTab === "image" && (
              <div className="max-w-5xl">
                <ImageEngineStudio
                  project={localProject}
                  onProjectUpdate={handleProjectUpdate}
                  initialScene={targetScene}
                  onSelectImageForScene={(sceneId, imgUrl) => {
                    if (localProject.storyboard) {
                      const updatedScenes = localProject.storyboard.scenes.map((s) =>
                        s.id === sceneId ? { ...s, imageUrl: imgUrl } : s
                      );
                      handleProjectUpdate({
                        ...localProject,
                        storyboard: { ...localProject.storyboard, scenes: updatedScenes },
                      });
                    }
                  }}
                />
              </div>
            )}

            {activeTab === "audio" && (
              <div className="max-w-5xl">
                <AudioEngineStudio
                  project={localProject}
                  onProjectUpdate={handleProjectUpdate}
                  initialScene={targetScene}
                />
              </div>
            )}

            {activeTab === "video" && (
              <div className="max-w-5xl">
                <VideoEngineStudio
                  project={localProject}
                  onProjectUpdate={handleProjectUpdate}
                  initialScene={targetScene}
                />
              </div>
            )}

            {activeTab === "seo" && (
              <div className="max-w-5xl">
                <YouTubeSEOAgentView
                  project={localProject}
                  onProjectUpdate={handleProjectUpdate}
                />
              </div>
            )}

            {activeTab === "repurpose" && (
              <div className="max-w-5xl">
                <RepurposeStudioView
                  project={localProject}
                  onProjectUpdate={handleProjectUpdate}
                />
              </div>
            )}

            {activeTab === "package" && (
              <div className="max-w-5xl">
                <ContentPackageBuilderView
                  project={localProject}
                  onProjectUpdate={handleProjectUpdate}
                />
              </div>
            )}

            {activeTab === "timeline" && (
              <TimelineEditor totalDuration={localProject.brief?.duration ?? 120} />
            )}

            {activeTab === "chat" && (
              <div className="max-w-2xl h-[calc(100vh-280px)] studio-panel overflow-hidden flex flex-col">
                <div className="px-4 py-3 border-b border-studio-border">
                  <h3 className="text-sm font-bold text-studio-text font-display">AI Assistant</h3>
                  <p className="text-xs text-studio-text-muted">Modifica o projeto com linguagem natural</p>
                </div>
                <ProjectChat project={localProject} onUpdate={handleProjectUpdate} />
              </div>
            )}
          </div>
        </div>

        {/* Right sidebar */}
        <div className="w-72 border-l border-studio-border bg-studio-surface flex flex-col overflow-y-auto p-4 space-y-4 shrink-0">
          <TaskPanel tasks={localProject.tasks} />

          <div className="studio-panel p-4">
            <h3 className="text-xs font-semibold text-studio-text-muted uppercase tracking-wide mb-3">Versões</h3>
            <div className="space-y-1.5">
              {["Brief", "Roteiro", "Storyboard"].map((type) => (
                <div key={type} className="flex items-center justify-between py-1.5 border-b border-studio-border/50 last:border-0">
                  <span className="text-xs text-studio-text-dim">{type}</span>
                  <span className="text-xs text-studio-text-muted">v1</span>
                </div>
              ))}
            </div>
          </div>

          <div className="studio-panel p-4">
            <h3 className="text-xs font-semibold text-studio-text-muted uppercase tracking-wide mb-3">Configurações</h3>
            <div className="space-y-2">
              {[
                { label: "Auto-edit", value: localProject.settings.autoEdit },
                { label: "Legendas auto", value: localProject.settings.autoSubtitles },
                { label: "Marca d'água", value: localProject.settings.watermark },
              ].map((setting) => (
                <div key={setting.label} className="flex items-center justify-between">
                  <span className="text-xs text-studio-text-dim">{setting.label}</span>
                  <div className={cn(
                    "w-8 h-4 rounded-full flex items-center px-0.5 transition-colors",
                    setting.value ? "bg-studio-blue justify-end" : "bg-studio-border justify-start"
                  )}>
                    <div className="w-3 h-3 rounded-full bg-white" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CORE 2.0 Modals */}
      <ThumbnailOptimizerModal
        isOpen={thumbnailModalOpen}
        onClose={() => setThumbnailModalOpen(false)}
        project={localProject}
        onSelectOptimizedPrompt={(newPrompt) => {
          setThumbnailModalOpen(false);
          setActiveTab("image");
        }}
      />

      <PrePublishApprovalModal
        isOpen={publishModalOpen}
        onClose={() => {
          setPublishModalOpen(false);
          const updated = getProject(localProject.id);
          if (updated) setLocalProject(updated);
        }}
        project={localProject}
        onSuccess={() => {
          const updated = getProject(localProject.id);
          if (updated) setLocalProject(updated);
        }}
      />

      {/* Delete Project Modal */}
      <DeleteProjectConfirmModal
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDeleteProject}
        projectTitle={localProject.title || ""}
      />
    </AppLayout>
  );
}
