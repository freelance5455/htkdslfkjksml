import { useMemo, useState } from 'react';
import { Coins, PackageCheck, Shield, ShoppingBag, Sparkles, Wallet } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader';
import { Badge } from '../components/ui/Feedback';
import { Chip, ProgressBar, SectionHeader } from '../components/ui/Card';
import { EMPTY_WALLET, REWARD_CATALOG, buyReward, categoryLabel, equipReward, nextPointProgress, unequipReward, useStreakShield, type RewardCategory } from '../services/economy';
import { KEYS, useStored } from '../services/storage';
import { formatMinutes, relativeDays } from '../utils/format';

type ShopFilter = 'all' | 'owned' | RewardCategory;

const filters: Array<{ id: ShopFilter; label: string }> = [
  { id: 'all', label: 'كل المتجر' },
  { id: 'owned', label: 'مقتنياتي' },
  { id: 'accent', label: 'ألوان' },
  { id: 'frame', label: 'إطارات' },
  { id: 'banner', label: 'لافتات' },
  { id: 'vehicle', label: 'مركبات' },
  { id: 'player-card', label: 'بطاقات اللاعبين' },
  { id: 'device', label: 'أجهزة' },
  { id: 'furniture', label: 'أثاث' },
  { id: 'decoration', label: 'ديكور' },
  { id: 'companion', label: 'رفاق' },
  { id: 'consumable', label: 'أدوات' },
];

function resultMessage(reason: string): string {
  return ({
    funds: 'رصيدك لا يكفي بعد — واصل الدراسة لتجمع نقاطاً أكثر.',
    owned: 'هذا العنصر موجود في مقتنياتك بالفعل.',
    empty: 'لا يوجد لديك عنصر من هذا النوع. يمكنك شراء واحد أولاً.',
    protected: 'السلسلة محمية لهذا اليوم بالفعل.',
    not_owned: 'اشتر العنصر أولاً قبل تجهيزه.',
  } as Record<string, string>)[reason] ?? 'تعذّر تنفيذ العملية. حاول مرة أخرى.';
}

export default function Shop() {
  const [filter, setFilter] = useState<ShopFilter>('all');
  const [message, setMessage] = useState('');
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  const items = useMemo(() => {
    if (filter === 'all') return REWARD_CATALOG;
    if (filter === 'owned') return REWARD_CATALOG.filter((item) => (wallet.owned[item.id] ?? 0) > 0);
    return REWARD_CATALOG.filter((item) => item.category === filter);
  }, [filter, wallet.owned]);
  const minutesToNextPoint = Math.ceil((360 - wallet.remainderSeconds) / 60);

  const buy = async (id: string) => {
    const result = await buyReward(id);
    setMessage(result.ok ? 'تم الشراء — أصبحت المكافأة في مقتنياتك.' : resultMessage(result.reason));
  };
  const equip = async (id: string) => {
    const item = REWARD_CATALOG.find((reward) => reward.id === id);
    if (item?.slot && wallet.equipped[item.slot] === item.id) {
      await unequipReward(item.slot);
      setMessage('تم إلغاء تجهيز العنصر.');
      return;
    }
    const result = await equipReward(id);
    setMessage(result.ok ? 'تم تجهيز مكافأتك.' : resultMessage(result.reason));
  };
  const activate = async (id: string) => {
    const result = await useStreakShield(id);
    setMessage(result.ok ? 'فُعّلت الحماية لليوم الحالي، واُستهلكت من مخزونك.' : resultMessage(result.reason));
  };

  return (
    <div>
      <PageHeader eyebrow="اجمعها بالدراسة، وأنفقها كما تحب" title="متجر المنارة" subtitle="كل ٦ دقائق دراسة نشطة تمنحك نقطة — ١٠ نقاط لكل ساعة كاملة. كل المركبات والأجهزة والمقتنيات هنا رقمية فقط، والمحتوى الدراسي مجاني دائماً." />

      <section className="mb-5 rounded-3xl bg-[linear-gradient(125deg,#0b2a3f,#144760)] p-5 text-white shadow-[var(--shadow-soft)]">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs text-white/65">رصيدك الحالي</p>
            <p className="mt-1 flex items-center gap-2 font-display text-3xl"><Coins size={23} className="text-[var(--gold)]" />{wallet.balance} <span className="text-sm font-normal text-white/70">نقطة</span></p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-center">
            <p className="text-lg font-semibold">{(wallet.owned['streak-shield'] ?? 0) + (wallet.owned['streak-shield-plus'] ?? 0)}</p>
            <p className="text-[0.62rem] text-white/65">حماية سلسلة</p>
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between text-[0.7rem] text-white/70">
          <span>دراسة نشطة: {formatMinutes(Math.floor(wallet.studySeconds / 60))}</span>
          <span>النقطة التالية بعد نحو {minutesToNextPoint} د</span>
        </div>
        <ProgressBar value={nextPointProgress()} className="mt-2" height={7} color="var(--gold)" label="التقدم نحو النقطة التالية" />
        <div className="mt-3 flex items-center justify-between text-[0.64rem] text-white/55">
          <span>إجمالي المكتسب: {wallet.totalEarned}</span>
          <span>إجمالي المنفق: {wallet.totalSpent}</span>
        </div>
      </section>

      <div className="no-scrollbar -mx-4 mb-4 flex gap-2 overflow-x-auto px-4">
        {filters.map((option) => <Chip key={option.id} active={filter === option.id} onClick={() => setFilter(option.id)}>{option.label}</Chip>)}
      </div>

      {message ? <p role="status" className="mb-3 rounded-2xl bg-[var(--surface-2)] px-3 py-2 text-xs text-[var(--ink)]">{message}</p> : null}
      <SectionHeader title={filter === 'owned' ? 'مقتنياتي الرقمية' : 'اختَر مكافأتك'} hint={`${items.length} من ${REWARD_CATALOG.length}`} />
      <div className="space-y-3">
        {items.length === 0 ? <p className="card p-5 text-center text-sm text-[var(--ink-soft)]">لم تجمع مقتنيات بعد؛ اختر شيئاً من المتجر وابدأ مجموعتك.</p> : null}
        {items.map((item) => {
          const quantity = wallet.owned[item.id] ?? 0;
          const isOwned = quantity > 0;
          const equipped = item.slot ? wallet.equipped[item.slot] === item.id : false;
          const affordable = wallet.balance >= item.price;
          return (
            <article key={item.id} className="card flex items-center gap-3 p-3.5">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl" style={{ background: `${item.color}20`, color: item.color }}>
                {item.emoji ? <span className="text-2xl leading-none" aria-hidden="true">{item.emoji}</span> : item.category === 'consumable' ? <Shield size={21} /> : item.category === 'accent' ? <Sparkles size={21} /> : item.category === 'frame' ? <PackageCheck size={21} /> : <ShoppingBag size={21} />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <h2 className="text-sm font-semibold text-[var(--ink)]">{item.name}</h2>
                  {isOwned ? <Badge tone="success">{item.category === 'consumable' ? `في المخزون: ${quantity}` : 'مملوك'}</Badge> : null}
                  {equipped ? <Badge tone="gold">مجهّز</Badge> : null}
                </div>
                <p className="mt-0.5 text-xs leading-relaxed text-[var(--ink-soft)]">{item.description}</p>
                <p className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">{categoryLabel(item.category)} · {item.price} نقطة</p>
              </div>
              <div className="flex shrink-0 flex-col gap-1.5">
                {item.slot ? !isOwned ? (
                  <button type="button" onClick={() => buy(item.id)} className="focus-ring min-h-10 rounded-full bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)]">{affordable ? 'شراء' : 'تحتاج رصيداً'}</button>
                ) : (
                  <button type="button" onClick={() => equip(item.id)} className="focus-ring min-h-10 rounded-full border border-[var(--line)] px-3 text-xs text-[var(--ink)]">{equipped ? 'إلغاء التجهيز' : 'تجهيز'}</button>
                ) : (
                  <>
                    {isOwned ? <button type="button" onClick={() => activate(item.id)} className="focus-ring min-h-10 rounded-full bg-[var(--gold)] px-3 text-xs font-semibold text-[#3a2606]">تفعيل ({quantity})</button> : null}
                    <button type="button" onClick={() => buy(item.id)} className="focus-ring min-h-10 rounded-full border border-[var(--line)] px-3 text-xs text-[var(--ink)]">{affordable ? (isOwned ? 'شراء أخرى' : 'شراء') : 'تحتاج رصيداً'}</button>
                  </>
                )}
              </div>
            </article>
          );
        })}
      </div>

      <section className="mt-6">
        <SectionHeader title="سجل النقاط" hint="آخر المعاملات" />
        {wallet.ledger.length ? <div className="card divide-y divide-[var(--line)] px-3">{wallet.ledger.slice(0, 12).map((entry) => <div key={entry.id} className="flex items-center gap-3 py-3"><span className={`w-12 text-center font-semibold ${entry.amount > 0 ? 'text-[var(--success)]' : entry.amount < 0 ? 'text-[var(--danger)]' : 'text-[var(--ink-soft)]'}`}>{entry.amount > 0 ? '+' : ''}{entry.amount}</span><div className="min-w-0 flex-1"><p className="truncate text-xs text-[var(--ink)]">{entry.label}</p><p className="text-[0.62rem] text-[var(--ink-soft)]">{relativeDays(entry.at)}</p></div><span className="text-[0.65rem] text-[var(--ink-soft)]">{entry.balanceAfter}</span></div>)}</div> : <div className="card flex items-center gap-3 p-4 text-xs text-[var(--ink-soft)]"><Wallet size={18} /> سيظهر سجل نقاطك بعد أول جلسة دراسة أو مكافأة.</div>}
      </section>
    </div>
  );
}
