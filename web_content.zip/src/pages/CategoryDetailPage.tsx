import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getCategories, getFormulas } from '../firebase/services';
import { Category, Formula } from '../types';
import { FormulaCard } from '../components/formula/FormulaCard';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import { ArrowLeft, Filter, Layers, Sigma } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CategoryDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { playSound } = useApp();

  const [category, setCategory] = useState<Category | null>(null);
  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('All');

  useEffect(() => {
    async function load() {
      try {
        const [cats, allFormulas] = await Promise.all([
          getCategories(),
          getFormulas()
        ]);
        const currentCat =
          cats.find((c) => c.slug === id || c.id === id) || null;
        setCategory(currentCat);

        if (currentCat) {
          const filtered = allFormulas.filter(
            (f) =>
              f.category.toLowerCase() === currentCat.slug.toLowerCase() ||
              f.category.toLowerCase() === currentCat.name.toLowerCase()
          );
          setFormulas(filtered);
        }
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  const displayedFormulas =
    selectedSubcategory === 'All'
      ? formulas
      : formulas.filter((f) => f.subcategory === selectedSubcategory);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-[#1C1C1C] rounded w-1/3 animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="text-center py-16 space-y-4">
        <h2 className="text-xl font-bold text-[#F5F2ED]">Category Not Found</h2>
        <p className="text-[#A9A39C] text-xs">
          The requested engineering category does not exist.
        </p>
        <Link
          to="/categories"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#D65A1F] text-[#F5F2ED] text-xs font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Categories</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16">
      {/* Breadcrumb / Back */}
      <div className="flex items-center justify-between">
        <Link
          to="/categories"
          onClick={() => playSound('tab')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#A9A39C] hover:text-[#F5F2ED] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>All Categories</span>
        </Link>
        <span className="text-xs font-mono text-[#A9A39C]">
          {formulas.length} total formulas
        </span>
      </div>

      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#1C1C1C] border border-[#303030] shadow-xl">
        <div className="flex items-center gap-3.5 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-[#232323] border border-[#303030] flex items-center justify-center text-[#D65A1F]">
            <Sigma className="w-6 h-6 text-[#D65A1F]" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
              {category.name}
            </h1>
            <p className="text-xs text-[#A9A39C] mt-0.5">
              {category.description}
            </p>
          </div>
        </div>
      </div>

      {/* Subcategory Filter Pills */}
      {category.subcategories && category.subcategories.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
          <button
            onClick={() => {
              playSound('tab');
              setSelectedSubcategory('All');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-colors border ${
              selectedSubcategory === 'All'
                ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] font-bold'
                : 'bg-[#151515] text-[#A9A39C] hover:text-[#F5F2ED] border-[#303030]'
            }`}
          >
            All Subcategories ({formulas.length})
          </button>
          {category.subcategories.map((sub) => {
            const subCount = formulas.filter((f) => f.subcategory === sub).length;
            return (
              <button
                key={sub}
                onClick={() => {
                  playSound('tab');
                  setSelectedSubcategory(sub);
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-colors border ${
                  selectedSubcategory === sub
                    ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] font-bold'
                    : 'bg-[#151515] text-[#A9A39C] hover:text-[#F5F2ED] border-[#303030]'
                }`}
              >
                {sub} ({subCount})
              </button>
            );
          })}
        </div>
      )}

      {/* Formulas Grid */}
      {displayedFormulas.length === 0 ? (
        <div className="text-center py-16 p-8 rounded-3xl bg-[#1C1C1C] border border-[#303030] space-y-3">
          <p className="text-sm font-semibold text-[#A9A39C]">
            No formulas found in "{selectedSubcategory}"
          </p>
          <button
            onClick={() => setSelectedSubcategory('All')}
            className="text-xs text-[#D65A1F] underline"
          >
            Show all {category.name} formulas
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {displayedFormulas.map((f) => (
            <FormulaCard key={f.id} formula={f} />
          ))}
        </div>
      )}
    </div>
  );
};
