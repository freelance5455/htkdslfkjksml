import React, { useState } from 'react';
import {
  Wrench,
  Activity,
  Zap,
  Rocket,
  Flame,
  Bot,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Info,
  ChevronRight,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ToolsPage: React.FC = () => {
  const { playSound, triggerHaptic, showToast } = useApp();
  const [activeTool, setActiveTool] = useState<
    'beam' | 'reynolds' | 'rocket' | 'circuit' | 'heat' | 'robotics'
  >('beam');
  const [copied, setCopied] = useState(false);

  // ----------------------------------------------------
  // TOOL 1: Beam Deflection & Stress State
  // ----------------------------------------------------
  const [beamType, setBeamType] = useState<'simply_supported' | 'cantilever'>('simply_supported');
  const [beamP, setBeamP] = useState<number>(5000); // 5000 N
  const [beamL, setBeamL] = useState<number>(3.0); // 3.0 m
  const [beamE, setBeamE] = useState<number>(200); // 200 GPa
  const [beamI, setBeamI] = useState<number>(0.0000833); // m^4 (8.33e-5)
  const [beamC, setBeamC] = useState<number>(0.1); // distance to outer fiber (m)

  // ----------------------------------------------------
  // TOOL 2: Reynolds Number & Flow Regime
  // ----------------------------------------------------
  const [flowRho, setFlowRho] = useState<number>(1000); // kg/m^3 (water)
  const [flowV, setFlowV] = useState<number>(1.8); // m/s
  const [flowD, setFlowD] = useState<number>(0.05); // 50mm pipe = 0.05 m
  const [flowMu, setFlowMu] = useState<number>(0.001002); // Pa.s

  // ----------------------------------------------------
  // TOOL 3: Tsiolkovsky Rocket Delta-v
  // ----------------------------------------------------
  const [rocketIsp, setRocketIsp] = useState<number>(330); // s
  const [rocketM0, setRocketM0] = useState<number>(550000); // kg (wet)
  const [rocketMf, setRocketMf] = useState<number>(32000); // kg (dry)
  const [rocketG0, setRocketG0] = useState<number>(9.80665); // m/s^2

  // ----------------------------------------------------
  // TOOL 4: AC Circuit & RLC Resonance
  // ----------------------------------------------------
  const [acFreq, setAcFreq] = useState<number>(60); // Hz
  const [acVolt, setAcVolt] = useState<number>(120); // V RMS
  const [acR, setAcR] = useState<number>(25); // Ohms
  const [acL, setAcL] = useState<number>(0.15); // Henry
  const [acC, setAcC] = useState<number>(0.000047); // 47 uF

  // ----------------------------------------------------
  // TOOL 5: Fourier's Heat Conduction
  // ----------------------------------------------------
  const [heatK, setHeatK] = useState<number>(205); // W/m.K (Aluminum)
  const [heatA, setHeatA] = useState<number>(0.5); // m^2
  const [heatD, setHeatD] = useState<number>(0.02); // 20mm = 0.02 m
  const [heatT1, setHeatT1] = useState<number>(90); // deg C
  const [heatT2, setHeatT2] = useState<number>(25); // deg C

  // ----------------------------------------------------
  // TOOL 6: Robotics 2-Link Planar Forward Kinematics
  // ----------------------------------------------------
  const [armL1, setArmL1] = useState<number>(40); // 40 cm
  const [armL2, setArmL2] = useState<number>(30); // 30 cm
  const [armTheta1, setArmTheta1] = useState<number>(45); // deg
  const [armTheta2, setArmTheta2] = useState<number>(30); // deg
  const [armPayload, setArmPayload] = useState<number>(2.5); // kg

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      playSound('copy');
      triggerHaptic('medium');
      setCopied(true);
      showToast('Calculated results copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Failed to copy', 'error');
    }
  };

  // ================= CALCULATIONS =================

  // 1. Beam
  const E_Pa = beamE * 1e9;
  let beamMaxDeflection = 0; // meters
  let beamMaxMoment = 0; // N.m
  if (beamType === 'simply_supported') {
    // Center point load: delta_max = (P * L^3) / (48 * E * I)
    beamMaxDeflection = (beamP * Math.pow(beamL, 3)) / (48 * E_Pa * beamI);
    beamMaxMoment = (beamP * beamL) / 4;
  } else {
    // Cantilever end load: delta_max = (P * L^3) / (3 * E * I)
    beamMaxDeflection = (beamP * Math.pow(beamL, 3)) / (3 * E_Pa * beamI);
    beamMaxMoment = beamP * beamL;
  }
  const beamBendingStressMPa = (beamMaxMoment * beamC) / (beamI * 1e6);

  // 2. Reynolds
  const reynoldsNumber = (flowRho * flowV * flowD) / flowMu;
  let flowRegime = 'Laminar';
  let flowColor = 'text-[#72A65A]';
  let darcyFriction = 0;
  if (reynoldsNumber < 2300) {
    flowRegime = 'Laminar (Smooth Streamline)';
    flowColor = 'text-[#72A65A]';
    darcyFriction = 64 / Math.max(reynoldsNumber, 1);
  } else if (reynoldsNumber <= 4000) {
    flowRegime = 'Transitional / Critical (Vortices forming)';
    flowColor = 'text-[#E87535]';
    darcyFriction = 0.035; // typical transition estimate
  } else {
    flowRegime = 'Turbulent (Full Eddies & Chaotic Mixing)';
    flowColor = 'text-[#D65A1F]';
    // Blasius formula for turbulent pipe flow
    darcyFriction = 0.3164 * Math.pow(reynoldsNumber, -0.25);
  }

  // 3. Rocket
  const rocketDeltaV = rocketIsp * rocketG0 * Math.log(Math.max(rocketM0, 1) / Math.max(rocketMf, 1));
  const rocketVe = rocketIsp * rocketG0;
  const rocketMassRatio = rocketM0 / Math.max(rocketMf, 1);
  const rocketPropellantMass = rocketM0 - rocketMf;
  const rocketMassFraction = (rocketPropellantMass / Math.max(rocketM0, 1)) * 100;

  // 4. Circuit
  const omega = 2 * Math.PI * acFreq;
  const X_L = omega * acL;
  const X_C = 1 / (omega * Math.max(acC, 1e-12));
  const Z = Math.sqrt(Math.pow(acR, 2) + Math.pow(X_L - X_C, 2));
  const circuitCurrent = acVolt / Math.max(Z, 1e-9);
  const f_0 = 1 / (2 * Math.PI * Math.sqrt(Math.max(acL * acC, 1e-16)));
  const phaseAngleRad = Math.atan2(X_L - X_C, acR);
  const phaseAngleDeg = (phaseAngleRad * 180) / Math.PI;
  const powerFactor = Math.cos(phaseAngleRad);
  const realPowerWatts = acVolt * circuitCurrent * powerFactor;

  // 5. Heat Conduction
  const deltaT = heatT1 - heatT2;
  const heatRateWatts = (heatK * heatA * deltaT) / Math.max(heatD, 0.0001);
  const thermalResistance = heatD / (heatK * Math.max(heatA, 0.0001));
  const heatFlux = heatRateWatts / Math.max(heatA, 0.0001);

  // 6. Robotics Forward Kinematics
  const rad1 = (armTheta1 * Math.PI) / 180;
  const rad2 = (armTheta2 * Math.PI) / 180;
  const elbowX = armL1 * Math.cos(rad1);
  const elbowY = armL1 * Math.sin(rad1);
  const endX = elbowX + armL2 * Math.cos(rad1 + rad2);
  const endY = elbowY + armL2 * Math.sin(rad1 + rad2);
  const armReachRadius = Math.sqrt(endX * endX + endY * endY);
  // Static torque under gravity (g = 9.81 m/s^2, load mass armPayload kg)
  // Joint 2 holds load at distance L2 * cos(theta1 + theta2)
  const gConst = 9.81;
  const loadForceN = armPayload * gConst;
  const joint2TorqueNm = Math.abs(loadForceN * (armL2 / 100) * Math.cos(rad1 + rad2));
  const joint1TorqueNm = Math.abs(loadForceN * (endX / 100));

  return (
    <div className="space-y-8 pb-16 max-w-5xl mx-auto">
      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#232323] border border-[#303030] text-[#D65A1F] text-xs font-mono font-medium">
          <Wrench className="w-3.5 h-3.5" />
          <span>Interactive Engineering Toolkit</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
          Specialized Engineering Calculators
        </h1>
        <p className="text-xs sm:text-sm text-[#A9A39C] max-w-2xl">
          Verified multi-variable calculators for structural beam deflection, fluid Reynolds regimes, rocket propulsion delta-v, RLC circuits, Fourier heat transfer, and 2-link robotic arm kinematics.
        </p>
      </div>

      {/* Tool Selector Tabs */}
      <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-[#151515] border border-[#303030]">
        {[
          { id: 'beam', label: 'Beam Deflection', icon: Activity },
          { id: 'reynolds', label: 'Reynolds Flow', icon: Flame },
          { id: 'rocket', label: 'Rocket Delta-v', icon: Rocket },
          { id: 'circuit', label: 'RLC Circuit', icon: Zap },
          { id: 'heat', label: 'Heat Conduction', icon: Flame },
          { id: 'robotics', label: 'Robotics Kinematics', icon: Bot }
        ].map((tool) => {
          const Icon = tool.icon;
          const isActive = activeTool === tool.id;
          return (
            <button
              key={tool.id}
              onClick={() => {
                playSound('tab');
                triggerHaptic('light');
                setActiveTool(tool.id as any);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-[#232323] text-[#D65A1F] border border-[#303030] shadow-sm'
                  : 'text-[#A9A39C] hover:text-[#F5F2ED] hover:bg-[#1C1C1C]'
              }`}
            >
              <Icon className="w-4 h-4 text-[#D65A1F]" />
              <span>{tool.label}</span>
            </button>
          );
        })}
      </div>

      {/* ======================================================== */}
      {/* 1. BEAM DEFLECTION CALCULATOR */}
      {/* ======================================================== */}
      {activeTool === 'beam' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-[#F5F2ED] flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#D65A1F]" />
                <span>Structural Parameters</span>
              </h2>
              <div className="flex bg-[#151515] border border-[#303030] p-1 rounded-xl text-xs">
                <button
                  onClick={() => setBeamType('simply_supported')}
                  className={`px-2.5 py-1 rounded-lg transition-colors ${
                    beamType === 'simply_supported'
                      ? 'bg-[#232323] text-[#D65A1F] font-bold'
                      : 'text-[#A9A39C]'
                  }`}
                >
                  Simply Supported
                </button>
                <button
                  onClick={() => setBeamType('cantilever')}
                  className={`px-2.5 py-1 rounded-lg transition-colors ${
                    beamType === 'cantilever'
                      ? 'bg-[#232323] text-[#D65A1F] font-bold'
                      : 'text-[#A9A39C]'
                  }`}
                >
                  Cantilever
                </button>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Applied Point Load (P): {beamP.toLocaleString()} N</span>
                  <span className="font-mono text-[#D65A1F]">{(beamP / 1000).toFixed(2)} kN</span>
                </label>
                <input
                  type="range"
                  min="100"
                  max="50000"
                  step="100"
                  value={beamP}
                  onChange={(e) => setBeamP(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Beam Span Length (L): {beamL} m</span>
                  <span className="font-mono text-[#D65A1F]">{(beamL * 1000).toFixed(0)} mm</span>
                </label>
                <input
                  type="range"
                  min="0.5"
                  max="12"
                  step="0.1"
                  value={beamL}
                  onChange={(e) => setBeamL(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[#A9A39C] font-medium">Young's Modulus (E)</span>
                  <span className="font-mono text-[#D65A1F]">{beamE} GPa</span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { label: 'Structural Steel', val: 200 },
                    { label: 'Aluminum 6061', val: 69 },
                    { label: 'Titanium Ti-6Al', val: 116 }
                  ].map((mat) => (
                    <button
                      key={mat.label}
                      onClick={() => setBeamE(mat.val)}
                      className={`p-2 rounded-xl border text-center transition-colors ${
                        beamE === mat.val
                          ? 'border-[#D65A1F] bg-[#232323] text-[#F5F2ED]'
                          : 'border-[#303030] bg-[#151515] text-[#A9A39C]'
                      }`}
                    >
                      <div className="font-bold text-[11px]">{mat.val} GPa</div>
                      <div className="text-[9px] text-[#A9A39C]">{mat.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="text-[#A9A39C] block mb-1">Moment of Inertia I (m⁴)</label>
                  <input
                    type="number"
                    step="0.00001"
                    value={beamI}
                    onChange={(e) => setBeamI(Math.max(Number(e.target.value), 1e-8))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
                <div>
                  <label className="text-[#A9A39C] block mb-1">Outer Fiber dist c (m)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={beamC}
                    onChange={(e) => setBeamC(Math.max(Number(e.target.value), 0.001))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Results Display */}
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#A9A39C] tracking-wider">
                  Computed Deflection & Stress
                </span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `Beam Type: ${beamType}\nLoad: ${beamP} N\nLength: ${beamL} m\nMax Deflection: ${(beamMaxDeflection * 1000).toFixed(3)} mm\nMax Bending Moment: ${beamMaxMoment.toFixed(1)} N*m\nBending Stress: ${beamBendingStressMPa.toFixed(2)} MPa`
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED] hover:text-[#D65A1F]"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Main Metric Cards */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">
                    Max Deflection (δ_max)
                  </span>
                  <div className="text-2xl font-extrabold text-[#D65A1F] mt-1 font-mono">
                    {(beamMaxDeflection * 1000).toFixed(2)} <span className="text-xs text-[#F5F2ED]">mm</span>
                  </div>
                  <span className="text-[10px] text-[#A9A39C] mt-1 block font-mono">
                    {(beamMaxDeflection).toExponential(3)} m
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">
                    Max Bending Stress (σ)
                  </span>
                  <div className="text-2xl font-extrabold text-[#F5F2ED] mt-1 font-mono">
                    {beamBendingStressMPa.toFixed(1)} <span className="text-xs text-[#A9A39C]">MPa</span>
                  </div>
                  <span className="text-[10px] text-[#A9A39C] mt-1 block font-mono">
                    Moment: {beamMaxMoment.toLocaleString()} N·m
                  </span>
                </div>
              </div>

              {/* Step By Step Formula Box */}
              <div className="p-4 rounded-xl bg-[#151515] border border-[#303030] space-y-2 text-xs">
                <div className="text-[11px] font-mono text-[#D65A1F] font-bold">
                  Governing Equation & Steps:
                </div>
                <div className="font-mono text-[#F5F2ED] bg-[#232323] p-2 rounded-lg border border-[#303030]">
                  {beamType === 'simply_supported'
                    ? 'δ_max = (P · L³) / (48 · E · I)'
                    : 'δ_max = (P · L³) / (3 · E · I)'}
                </div>
                <div className="text-[#A9A39C] space-y-1 font-mono text-[11px]">
                  <div>• Load P = {beamP} N</div>
                  <div>• Span L = {beamL} m ➔ L³ = {Math.pow(beamL, 3).toFixed(2)} m³</div>
                  <div>• Stiffness E·I = {(E_Pa * beamI).toExponential(3)} N·m²</div>
                  <div>• Peak Moment M_max = {beamMaxMoment.toFixed(1)} N·m</div>
                </div>
              </div>
            </div>

            {/* Visual Beam Schematic SVG */}
            <div className="mt-4 p-4 rounded-xl bg-[#151515] border border-[#303030] flex flex-col items-center">
              <span className="text-[10px] font-mono text-[#A9A39C] mb-2">Beam Loading Schematic</span>
              <svg viewBox="0 0 320 80" className="w-full max-w-sm h-16 stroke-[#A9A39C] fill-none">
                {/* Baseline beam */}
                <line x1="20" y1="50" x2="300" y2="50" strokeWidth="4" stroke="#D65A1F" />
                {beamType === 'simply_supported' ? (
                  <>
                    {/* Left pin support */}
                    <polygon points="20,52 10,70 30,70" fill="#232323" stroke="#303030" strokeWidth="1.5" />
                    {/* Right roller support */}
                    <circle cx="300" cy="62" r="8" fill="#232323" stroke="#303030" strokeWidth="1.5" />
                    {/* Center load arrow */}
                    <line x1="160" y1="15" x2="160" y2="46" stroke="#F5F2ED" strokeWidth="2.5" />
                    <polygon points="160,50 155,40 165,40" fill="#F5F2ED" />
                    <text x="165" y="24" fill="#F5F2ED" fontSize="10" fontFamily="monospace">P = {beamP} N</text>
                  </>
                ) : (
                  <>
                    {/* Left clamped wall */}
                    <line x1="20" y1="20" x2="20" y2="75" strokeWidth="6" stroke="#303030" />
                    {/* End load arrow */}
                    <line x1="300" y1="15" x2="300" y2="46" stroke="#F5F2ED" strokeWidth="2.5" />
                    <polygon points="300,50 295,40 305,40" fill="#F5F2ED" />
                    <text x="240" y="24" fill="#F5F2ED" fontSize="10" fontFamily="monospace">P = {beamP} N</text>
                  </>
                )}
              </svg>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. REYNOLDS NUMBER & FLOW REGIME */}
      {/* ======================================================== */}
      {activeTool === 'reynolds' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl">
            <h2 className="text-base font-bold text-[#F5F2ED] flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#D65A1F]" />
              <span>Fluid & Pipe Flow Parameters</span>
            </h2>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Fluid Velocity (v): {flowV} m/s</span>
                  <span className="font-mono text-[#D65A1F]">{(flowV * 3.6).toFixed(1)} km/h</span>
                </label>
                <input
                  type="range"
                  min="0.05"
                  max="25"
                  step="0.05"
                  value={flowV}
                  onChange={(e) => setFlowV(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Pipe Inner Diameter (D): {flowD} m</span>
                  <span className="font-mono text-[#D65A1F]">{(flowD * 1000).toFixed(0)} mm</span>
                </label>
                <input
                  type="range"
                  min="0.005"
                  max="1.0"
                  step="0.005"
                  value={flowD}
                  onChange={(e) => setFlowD(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              {/* Quick Presets for Fluid */}
              <div>
                <span className="text-[#A9A39C] font-medium block mb-1">Standard Fluid Presets:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => {
                      setFlowRho(1000);
                      setFlowMu(0.001002);
                    }}
                    className="p-2 rounded-xl bg-[#151515] border border-[#303030] text-center hover:border-[#D65A1F]"
                  >
                    <div className="font-bold text-[#F5F2ED]">Water 20°C</div>
                    <div className="text-[10px] text-[#A9A39C]">ρ=1000, μ=1e-3</div>
                  </button>
                  <button
                    onClick={() => {
                      setFlowRho(1.225);
                      setFlowMu(0.0000181);
                    }}
                    className="p-2 rounded-xl bg-[#151515] border border-[#303030] text-center hover:border-[#D65A1F]"
                  >
                    <div className="font-bold text-[#F5F2ED]">Air 15°C</div>
                    <div className="text-[10px] text-[#A9A39C]">ρ=1.225, μ=1.8e-5</div>
                  </button>
                  <button
                    onClick={() => {
                      setFlowRho(890);
                      setFlowMu(0.082);
                    }}
                    className="p-2 rounded-xl bg-[#151515] border border-[#303030] text-center hover:border-[#D65A1F]"
                  >
                    <div className="font-bold text-[#F5F2ED]">Engine Oil</div>
                    <div className="text-[10px] text-[#A9A39C]">ρ=890, μ=0.082</div>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="text-[#A9A39C] block mb-1">Fluid Density ρ (kg/m³)</label>
                  <input
                    type="number"
                    value={flowRho}
                    onChange={(e) => setFlowRho(Math.max(Number(e.target.value), 0.01))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
                <div>
                  <label className="text-[#A9A39C] block mb-1">Dynamic Viscosity μ (Pa·s)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={flowMu}
                    onChange={(e) => setFlowMu(Math.max(Number(e.target.value), 1e-7))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#A9A39C]">Flow Regime Assessment</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `Reynolds Number Re: ${reynoldsNumber.toFixed(0)}\nRegime: ${flowRegime}\nDarcy Friction factor f: ${darcyFriction.toFixed(5)}`
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED]"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-5 rounded-2xl bg-[#151515] border border-[#303030] text-center space-y-2">
                <span className="text-xs font-mono text-[#A9A39C] uppercase">Reynolds Number (Re)</span>
                <div className="text-4xl font-extrabold text-[#D65A1F] font-mono">
                  {reynoldsNumber >= 1e6
                    ? reynoldsNumber.toExponential(3)
                    : Math.round(reynoldsNumber).toLocaleString()}
                </div>
                <div className={`text-sm font-bold ${flowColor}`}>{flowRegime}</div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Friction Factor (f)</span>
                  <div className="text-lg font-bold text-[#F5F2ED] font-mono mt-1">
                    {darcyFriction.toFixed(5)}
                  </div>
                  <span className="text-[10px] text-[#A9A39C]">Darcy-Weisbach</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Critical Range</span>
                  <div className="text-lg font-bold text-[#F5F2ED] font-mono mt-1">2,300 – 4,000</div>
                  <span className="text-[10px] text-[#A9A39C]">Transition Boundary</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#151515] border border-[#303030] text-xs font-mono text-[#A9A39C] space-y-1">
                <div>Formula: Re = (ρ · v · D) / μ</div>
                <div>• Numerator: {flowRho} · {flowV} · {flowD} = {(flowRho * flowV * flowD).toFixed(2)}</div>
                <div>• Denominator (μ): {flowMu.toExponential(4)} Pa·s</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 3. ROCKET EQUATION & DELTA-V */}
      {/* ======================================================== */}
      {activeTool === 'rocket' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl">
            <h2 className="text-base font-bold text-[#F5F2ED] flex items-center gap-2">
              <Rocket className="w-4 h-4 text-[#D65A1F]" />
              <span>Propulsion & Mass Parameters</span>
            </h2>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Specific Impulse (Isp): {rocketIsp} s</span>
                  <span className="font-mono text-[#D65A1F]">Ve = {(rocketIsp * rocketG0).toFixed(0)} m/s</span>
                </label>
                <input
                  type="range"
                  min="200"
                  max="465"
                  step="1"
                  value={rocketIsp}
                  onChange={(e) => setRocketIsp(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Initial Wet Mass (m0): {(rocketM0 / 1000).toFixed(1)} tonnes</span>
                  <span className="font-mono text-[#D65A1F]">{rocketM0.toLocaleString()} kg</span>
                </label>
                <input
                  type="range"
                  min="1000"
                  max="3000000"
                  step="5000"
                  value={rocketM0}
                  onChange={(e) => setRocketM0(Math.max(Number(e.target.value), rocketMf + 100))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Final Dry Mass (mf): {(rocketMf / 1000).toFixed(1)} tonnes</span>
                  <span className="font-mono text-[#D65A1F]">{rocketMf.toLocaleString()} kg</span>
                </label>
                <input
                  type="range"
                  min="500"
                  max="200000"
                  step="500"
                  value={rocketMf}
                  onChange={(e) => setRocketMf(Math.min(Number(e.target.value), rocketM0 - 100))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              {/* Rocket Presets */}
              <div className="pt-2">
                <span className="text-[#A9A39C] font-medium block mb-1">Real-World Rocket Stage Profiles:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => {
                      setRocketIsp(311);
                      setRocketM0(549054);
                      setRocketMf(25600);
                    }}
                    className="p-2 rounded-xl bg-[#151515] border border-[#303030] text-center hover:border-[#D65A1F]"
                  >
                    <div className="font-bold text-[#F5F2ED]">Falcon 9 (Stage 1)</div>
                    <div className="text-[10px] text-[#A9A39C]">Isp 311s • 549t wet</div>
                  </button>
                  <button
                    onClick={() => {
                      setRocketIsp(348);
                      setRocketM0(111500);
                      setRocketMf(4000);
                    }}
                    className="p-2 rounded-xl bg-[#151515] border border-[#303030] text-center hover:border-[#D65A1F]"
                  >
                    <div className="font-bold text-[#F5F2ED]">Falcon 9 (Stage 2)</div>
                    <div className="text-[10px] text-[#A9A39C]">Isp 348s • 111t wet</div>
                  </button>
                  <button
                    onClick={() => {
                      setRocketIsp(452);
                      setRocketM0(760000);
                      setRocketMf(85200);
                    }}
                    className="p-2 rounded-xl bg-[#151515] border border-[#303030] text-center hover:border-[#D65A1F]"
                  >
                    <div className="font-bold text-[#F5F2ED]">Space Shuttle RS-25</div>
                    <div className="text-[10px] text-[#A9A39C]">Isp 452s • Hydrolox</div>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#A9A39C]">Mission Velocity Budget</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `Rocket Delta-v: ${rocketDeltaV.toFixed(1)} m/s (${(rocketDeltaV / 1000).toFixed(2)} km/s)\nMass Ratio: ${rocketMassRatio.toFixed(2)}\nPropellant Fraction: ${rocketMassFraction.toFixed(1)}%`
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED]"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-5 rounded-2xl bg-[#151515] border border-[#303030] text-center space-y-1">
                <span className="text-xs font-mono text-[#A9A39C] uppercase">Total Delta-v (Δv)</span>
                <div className="text-4xl font-extrabold text-[#D65A1F] font-mono">
                  {(rocketDeltaV / 1000).toFixed(2)} <span className="text-lg text-[#F5F2ED]">km/s</span>
                </div>
                <div className="text-xs text-[#A9A39C] font-mono">
                  {rocketDeltaV.toFixed(0).toLocaleString()} m/s
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="p-3 rounded-xl bg-[#151515] border border-[#303030] text-center">
                  <span className="text-[10px] text-[#A9A39C] block font-mono">Mass Ratio (m0/mf)</span>
                  <span className="font-bold text-[#F5F2ED] text-sm font-mono">{rocketMassRatio.toFixed(2)}</span>
                </div>
                <div className="p-3 rounded-xl bg-[#151515] border border-[#303030] text-center">
                  <span className="text-[10px] text-[#A9A39C] block font-mono">Propellant Fraction</span>
                  <span className="font-bold text-[#D65A1F] text-sm font-mono">{rocketMassFraction.toFixed(1)}%</span>
                </div>
                <div className="p-3 rounded-xl bg-[#151515] border border-[#303030] text-center">
                  <span className="text-[10px] text-[#A9A39C] block font-mono">Exhaust Velocity</span>
                  <span className="font-bold text-[#F5F2ED] text-sm font-mono">{rocketVe.toFixed(0)} m/s</span>
                </div>
              </div>

              {/* Orbital destination meters */}
              <div className="p-3 rounded-xl bg-[#151515] border border-[#303030] space-y-1.5 text-xs font-mono">
                <span className="text-[#A9A39C] block text-[10px]">Flight Capability Benchmarks:</span>
                <div className="flex justify-between items-center text-[11px]">
                  <span>Low Earth Orbit (LEO ~9.4 km/s)</span>
                  <span className={rocketDeltaV >= 9400 ? 'text-[#72A65A]' : 'text-[#C84A3A]'}>
                    {rocketDeltaV >= 9400 ? 'Achievable' : 'Suborbital'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span>Earth Escape Velocity (~11.2 km/s)</span>
                  <span className={rocketDeltaV >= 11200 ? 'text-[#72A65A]' : 'text-[#A9A39C]'}>
                    {rocketDeltaV >= 11200 ? 'Achieved' : 'Requires Staging'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 4. RLC CIRCUIT & AC IMPEDANCE */}
      {/* ======================================================== */}
      {activeTool === 'circuit' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl">
            <h2 className="text-base font-bold text-[#F5F2ED] flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#D65A1F]" />
              <span>AC Electrical Parameters</span>
            </h2>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#A9A39C] block mb-1">AC Frequency (Hz)</label>
                  <input
                    type="number"
                    value={acFreq}
                    onChange={(e) => setAcFreq(Math.max(Number(e.target.value), 1))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
                <div>
                  <label className="text-[#A9A39C] block mb-1">RMS Voltage (V)</label>
                  <input
                    type="number"
                    value={acVolt}
                    onChange={(e) => setAcVolt(Math.max(Number(e.target.value), 0))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Resistance (R): {acR} Ω</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="500"
                  step="1"
                  value={acR}
                  onChange={(e) => setAcR(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Inductance (L): {acL} H ({(acL * 1000).toFixed(0)} mH)</span>
                </label>
                <input
                  type="range"
                  min="0.001"
                  max="2.0"
                  step="0.005"
                  value={acL}
                  onChange={(e) => setAcL(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Capacitance (C): {(acC * 1e6).toFixed(1)} µF</span>
                </label>
                <input
                  type="range"
                  min="0.000001"
                  max="0.0005"
                  step="0.000005"
                  value={acC}
                  onChange={(e) => setAcC(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#A9A39C]">AC Impedance & Power</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `Impedance Z: ${Z.toFixed(2)} Ohms\nCurrent I: ${circuitCurrent.toFixed(3)} A\nResonant Freq: ${f_0.toFixed(1)} Hz\nPower Factor: ${powerFactor.toFixed(3)}\nReal Power: ${realPowerWatts.toFixed(1)} W`
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED]"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Impedance (Z)</span>
                  <div className="text-2xl font-bold text-[#D65A1F] font-mono mt-1">
                    {Z.toFixed(2)} <span className="text-xs text-[#F5F2ED]">Ω</span>
                  </div>
                  <span className="text-[10px] text-[#A9A39C] mt-1 block">Phase: {phaseAngleDeg.toFixed(1)}°</span>
                </div>

                <div className="p-4 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">RMS Current (I)</span>
                  <div className="text-2xl font-bold text-[#F5F2ED] font-mono mt-1">
                    {circuitCurrent.toFixed(3)} <span className="text-xs text-[#A9A39C]">A</span>
                  </div>
                  <span className="text-[10px] text-[#A9A39C] mt-1 block font-mono">
                    Power: {realPowerWatts.toFixed(1)} W
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-3 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] block font-mono">X_L (Inductive)</span>
                  <span className="font-bold text-[#F5F2ED] text-sm font-mono">{X_L.toFixed(1)} Ω</span>
                </div>
                <div className="p-3 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] block font-mono">X_C (Capacitive)</span>
                  <span className="font-bold text-[#F5F2ED] text-sm font-mono">{X_C.toFixed(1)} Ω</span>
                </div>
                <div className="p-3 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] block font-mono">Resonance (f₀)</span>
                  <span className="font-bold text-[#D65A1F] text-sm font-mono">{f_0.toFixed(1)} Hz</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 5. FOURIER'S HEAT CONDUCTION */}
      {/* ======================================================== */}
      {activeTool === 'heat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl">
            <h2 className="text-base font-bold text-[#F5F2ED] flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#D65A1F]" />
              <span>Thermal Boundary Parameters</span>
            </h2>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#A9A39C] block mb-1">Hot Side T1 (°C)</label>
                  <input
                    type="number"
                    value={heatT1}
                    onChange={(e) => setHeatT1(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
                <div>
                  <label className="text-[#A9A39C] block mb-1">Cold Side T2 (°C)</label>
                  <input
                    type="number"
                    value={heatT2}
                    onChange={(e) => setHeatT2(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Material Thickness (d): {(heatD * 1000).toFixed(0)} mm</span>
                  <span className="font-mono text-[#D65A1F]">{heatD} m</span>
                </label>
                <input
                  type="range"
                  min="0.001"
                  max="0.2"
                  step="0.002"
                  value={heatD}
                  onChange={(e) => setHeatD(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Surface Area (A): {heatA} m²</span>
                </label>
                <input
                  type="range"
                  min="0.05"
                  max="10"
                  step="0.05"
                  value={heatA}
                  onChange={(e) => setHeatA(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              {/* Material conductivity presets */}
              <div className="pt-2">
                <span className="text-[#A9A39C] font-medium block mb-1">Thermal Conductivity Presets (k):</span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Pure Copper', k: 401 },
                    { label: 'Aluminum', k: 237 },
                    { label: 'Carbon Steel', k: 50 },
                    { label: 'Glass / Silica', k: 1.0 },
                    { label: 'Fiberglass', k: 0.04 },
                    { label: 'Aerogel', k: 0.015 }
                  ].map((mat) => (
                    <button
                      key={mat.label}
                      onClick={() => setHeatK(mat.k)}
                      className={`p-2 rounded-xl border text-center transition-colors ${
                        heatK === mat.k
                          ? 'border-[#D65A1F] bg-[#232323] text-[#F5F2ED]'
                          : 'border-[#303030] bg-[#151515] text-[#A9A39C]'
                      }`}
                    >
                      <div className="font-bold text-[11px]">{mat.k} W/m·K</div>
                      <div className="text-[9px] text-[#A9A39C]">{mat.label}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#A9A39C]">Conduction Rate & Heat Flux</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `Heat Rate Q: ${heatRateWatts.toFixed(1)} Watts\nHeat Flux: ${heatFlux.toFixed(1)} W/m^2\nThermal Resistance: ${thermalResistance.toFixed(5)} K/W`
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED]"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-5 rounded-2xl bg-[#151515] border border-[#303030] text-center space-y-1">
                <span className="text-xs font-mono text-[#A9A39C] uppercase">Heat Transfer Rate (Q̇)</span>
                <div className="text-4xl font-extrabold text-[#D65A1F] font-mono">
                  {Math.abs(heatRateWatts) >= 1000
                    ? `${(heatRateWatts / 1000).toFixed(2)} kW`
                    : `${heatRateWatts.toFixed(1)} W`}
                </div>
                <div className="text-xs text-[#A9A39C] font-mono">
                  ΔT = {deltaT}°C • Heat Flux = {heatFlux.toFixed(1)} W/m²
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Thermal Resistance</span>
                  <div className="text-lg font-bold text-[#F5F2ED] font-mono mt-1">
                    {thermalResistance.toFixed(4)} K/W
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Temperature Drop</span>
                  <div className="text-lg font-bold text-[#F5F2ED] font-mono mt-1">
                    {deltaT} K
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 6. ROBOTICS FORWARD KINEMATICS */}
      {/* ======================================================== */}
      {activeTool === 'robotics' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl">
            <h2 className="text-base font-bold text-[#F5F2ED] flex items-center gap-2">
              <Bot className="w-4 h-4 text-[#D65A1F]" />
              <span>2-DOF Planar Arm Parameters</span>
            </h2>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#A9A39C] block mb-1">Link 1 Length L1 (cm)</label>
                  <input
                    type="number"
                    value={armL1}
                    onChange={(e) => setArmL1(Math.max(Number(e.target.value), 5))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
                <div>
                  <label className="text-[#A9A39C] block mb-1">Link 2 Length L2 (cm)</label>
                  <input
                    type="number"
                    value={armL2}
                    onChange={(e) => setArmL2(Math.max(Number(e.target.value), 5))}
                    className="w-full px-3 py-2 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Base Joint Angle θ1: {armTheta1}°</span>
                </label>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  step="1"
                  value={armTheta1}
                  onChange={(e) => setArmTheta1(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Elbow Joint Angle θ2: {armTheta2}°</span>
                </label>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  step="1"
                  value={armTheta2}
                  onChange={(e) => setArmTheta2(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>

              <div>
                <label className="text-[#A9A39C] font-medium flex justify-between">
                  <span>Payload Mass: {armPayload} kg</span>
                  <span className="font-mono text-[#D65A1F]">Force: {loadForceN.toFixed(1)} N</span>
                </label>
                <input
                  type="range"
                  min="0.1"
                  max="20"
                  step="0.1"
                  value={armPayload}
                  onChange={(e) => setArmPayload(Number(e.target.value))}
                  className="w-full mt-1.5 accent-[#D65A1F]"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#A9A39C]">End-Effector Coordinates</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `End-Effector: X = ${endX.toFixed(1)} cm, Y = ${endY.toFixed(1)} cm\nReach Radius: ${armReachRadius.toFixed(1)} cm\nJoint 1 Holding Torque: ${joint1TorqueNm.toFixed(2)} N*m\nJoint 2 Holding Torque: ${joint2TorqueNm.toFixed(2)} N*m`
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED]"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Position (X, Y)</span>
                  <div className="text-xl font-bold text-[#D65A1F] font-mono mt-1">
                    ({endX.toFixed(1)}, {endY.toFixed(1)}) <span className="text-xs text-[#F5F2ED]">cm</span>
                  </div>
                  <span className="text-[10px] text-[#A9A39C] mt-1 block">Reach: {armReachRadius.toFixed(1)} cm</span>
                </div>

                <div className="p-4 rounded-xl bg-[#151515] border border-[#303030]">
                  <span className="text-[10px] text-[#A9A39C] uppercase font-mono block">Base Torque (τ₁)</span>
                  <div className="text-xl font-bold text-[#F5F2ED] font-mono mt-1">
                    {joint1TorqueNm.toFixed(2)} <span className="text-xs text-[#A9A39C]">N·m</span>
                  </div>
                  <span className="text-[10px] text-[#A9A39C] mt-1 block font-mono">
                    Elbow τ₂: {joint2TorqueNm.toFixed(2)} N·m
                  </span>
                </div>
              </div>

              {/* 2D SVG Arm Visualization */}
              <div className="p-4 rounded-xl bg-[#151515] border border-[#303030] flex flex-col items-center">
                <span className="text-[10px] font-mono text-[#A9A39C] mb-1">Kinematic Planar Diagram</span>
                <svg viewBox="-100 -100 200 200" className="w-full max-w-xs h-40">
                  {/* Grid circle of max reach */}
                  <circle cx="0" cy="0" r={armL1 + armL2} fill="none" stroke="#303030" strokeWidth="0.8" strokeDasharray="3 3" />
                  <circle cx="0" cy="0" r="4" fill="#D65A1F" />
                  {/* Link 1 */}
                  <line x1="0" y1="0" x2={elbowX} y2={-elbowY} stroke="#F5F2ED" strokeWidth="4" strokeLinecap="round" />
                  {/* Elbow joint */}
                  <circle cx={elbowX} cy={-elbowY} r="3" fill="#D65A1F" />
                  {/* Link 2 */}
                  <line x1={elbowX} y1={-elbowY} x2={endX} y2={-endY} stroke="#D65A1F" strokeWidth="3" strokeLinecap="round" />
                  {/* End effector */}
                  <circle cx={endX} cy={-endY} r="4" fill="#72A65A" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
