import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { GlassCard } from '../components/ui/GlassCard';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, Target, TrendingDown, CircleDashed, Award, ChevronDown } from 'lucide-react';
import { Subject, SubjectAnalysis } from '../types';
import { SUBJECTS } from '../lib/scoring';

export const AnalysisReport: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { attempts, folders } = useStore();
  
  const attempt = attempts.find(a => a.id === id);
  const folder = folders.find(f => f.id === attempt?.testId);

  const [activeSubject, setActiveSubject] = useState<Subject | null>(null);

  if (!attempt || !folder) return null;

  const percentage = (attempt.totalScore / 720) * 100;
  const strokeDasharray = 283; // 2 * pi * r (r=45)
  const strokeDashoffset = strokeDasharray - (strokeDasharray * percentage) / 100;

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <button onClick={() => navigate('/')} className="flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors text-sm font-medium">
        <ChevronLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      {/* Header & Overall Performance */}
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, ease: 'easeOut' }}>
        <GlassCard className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white border-0 overflow-hidden relative p-8 md:p-12">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl -ml-20 -mb-20 pointer-events-none"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="text-center md:text-left flex-1">
              <span className="px-3 py-1 bg-white/10 text-indigo-200 text-xs font-bold tracking-wider uppercase rounded-full mb-4 inline-block">
                Final Analysis Report
              </span>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-2">
                {folder.instituteName} - Test {folder.testNo}
              </h1>
              <p className="text-indigo-200 text-lg">{folder.syllabus}</p>
              <div className="flex items-center justify-center md:justify-start gap-4 mt-6 text-sm text-indigo-300 font-medium">
                <span>Attempted on {attempt.dayStr}, {attempt.dateStr} {attempt.monthStr}</span>
              </div>
            </div>

            {/* Radial Progress */}
            <div className="relative flex items-center justify-center shrink-0">
              <svg className="w-48 h-48 transform -rotate-90">
                <circle cx="96" cy="96" r="80" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-white/10" />
                <motion.circle 
                  cx="96" cy="96" r="80" stroke="currentColor" strokeWidth="12" fill="transparent" 
                  className="text-emerald-400 drop-shadow-[0_0_12px_rgba(52,211,153,0.8)]"
                  strokeLinecap="round"
                  initial={{ strokeDashoffset: strokeDasharray }}
                  animate={{ strokeDashoffset }}
                  transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
                  style={{ strokeDasharray }}
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <motion.span 
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1 }}
                  className="text-5xl font-bold text-white tracking-tighter"
                >
                  {attempt.totalScore}
                </motion.span>
                <span className="text-sm font-medium text-indigo-200">out of 720</span>
              </div>
            </div>
          </div>
        </GlassCard>
      </motion.div>

      {/* 4 Performance Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Correct', value: attempt.totalCorrect, icon: Target, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Total Incorrect', value: attempt.totalIncorrect, icon: TrendingDown, color: 'text-rose-600', bg: 'bg-rose-50' },
          { label: 'Total Skipped', value: attempt.totalSkipped, icon: CircleDashed, color: 'text-slate-500', bg: 'bg-slate-100' },
          { label: 'Accuracy', value: `${Math.round((attempt.totalCorrect / (180 - attempt.totalSkipped)) * 100 || 0)}%`, icon: Award, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((stat, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 * i }}>
            <GlassCard hoverEffect className="flex flex-col items-center text-center p-6 cursor-default">
              <div className={`w-12 h-12 rounded-2xl ${stat.bg} ${stat.color} flex items-center justify-center mb-4`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <span className="text-3xl font-bold text-slate-800">{stat.value}</span>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">{stat.label}</span>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Subject Wise Micro Analysis */}
      <div className="mt-12">
        <h3 className="text-2xl font-bold text-slate-800 mb-6 px-2">Subject-Wise Micro Analysis</h3>
        <div className="space-y-4">
          {SUBJECTS.map((subject, index) => {
            const data = attempt.subjects[subject];
            const isActive = activeSubject === subject;

            return (
              <motion.div key={subject} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + (index * 0.1) }}>
                <GlassCard className="p-0 overflow-hidden">
                  <button 
                    onClick={() => setActiveSubject(isActive ? null : subject)}
                    className="w-full px-6 py-5 flex items-center justify-between hover:bg-slate-50/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-lg border border-indigo-100">
                        {subject.charAt(0)}
                      </div>
                      <div className="text-left">
                        <h4 className="text-lg font-bold text-slate-800">{subject}</h4>
                        <p className="text-sm font-medium text-slate-500">Score: {data.score} / 180</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="hidden sm:flex gap-4 text-sm font-medium">
                        <span className="text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">{data.correct} Correct</span>
                        <span className="text-rose-600 bg-rose-50 px-2 py-1 rounded-md">{data.incorrect} Incorrect</span>
                      </div>
                      <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform duration-300 ${isActive ? 'rotate-180' : ''}`} />
                    </div>
                  </button>

                  <AnimatePresence>
                    {isActive && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="border-t border-slate-100 bg-slate-50/30"
                      >
                        <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                          {/* Correct List */}
                          <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-4">
                            <h5 className="font-semibold text-emerald-800 flex items-center gap-2 mb-3">
                              <Target className="w-4 h-4" /> Correct Questions
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {data.correctList.length > 0 ? data.correctList.map(q => (
                                <span key={q} className="w-8 h-8 rounded-lg bg-white border border-emerald-200 text-emerald-700 text-xs font-bold flex items-center justify-center shadow-sm">
                                  {q}
                                </span>
                              )) : <span className="text-sm text-emerald-600/50">None</span>}
                            </div>
                          </div>

                          {/* Incorrect List */}
                          <div className="bg-rose-50/50 border border-rose-100 rounded-xl p-4">
                            <h5 className="font-semibold text-rose-800 flex items-center gap-2 mb-3">
                              <TrendingDown className="w-4 h-4" /> Incorrect Questions
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {data.incorrectList.length > 0 ? data.incorrectList.map(q => (
                                <span key={q} className="w-8 h-8 rounded-lg bg-white border border-rose-200 text-rose-700 text-xs font-bold flex items-center justify-center shadow-sm">
                                  {q}
                                </span>
                              )) : <span className="text-sm text-rose-600/50">None</span>}
                            </div>
                          </div>

                          {/* Skipped List */}
                          <div className="bg-slate-100/50 border border-slate-200 rounded-xl p-4">
                            <h5 className="font-semibold text-slate-700 flex items-center gap-2 mb-3">
                              <CircleDashed className="w-4 h-4" /> Skipped Questions
                            </h5>
                            <div className="flex flex-wrap gap-2">
                              {data.skippedList.length > 0 ? data.skippedList.map(q => (
                                <span key={q} className="w-8 h-8 rounded-lg bg-white border border-slate-200 text-slate-500 text-xs font-bold flex items-center justify-center shadow-sm">
                                  {q}
                                </span>
                              )) : <span className="text-sm text-slate-400">None</span>}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </GlassCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
