import { Award, BookOpenCheck, CalendarDays, Coins, FileText, ListChecks, ShoppingBag, Sprout, StickyNote, Target, Timer, Trophy, type LucideIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { useProfile } from '../hooks/useProfile';
import { useStudySession } from '../hooks/useStudySession';
import { allLessons, subjects } from '../data/content';
import { EMPTY_DAILY_TASKS, localDateKey, previewDailyTaskDay, type DailyTaskStore } from '../services/dailyTasks';
import { EMPTY_FARM } from '../services/farmModel';
import { EMPTY_WALLET, REWARD_CATALOG, type WalletState } from '../services/economy';
import { achievementSummary, challengeSummary } from '../services/gamification';
import { getPlan } from '../services/plan';
import { overallCurriculumProgress, type CurriculumCompletionState } from '../services/curriculumProgress';
import { getGradeRecords, weightedGradeAverage, type GradeRecord } from '../services/gradebook';
import { KEYS, useStored } from '../services/storage';
import { studyTimeSummary } from '../services/progress';
import { DAILY_ROUTINES, EMPTY_DAILY_ROUTINES, getDailyRoutineDay } from '../services/dailyRoutines';
import type { StudyPlan } from '../types';
import { formatMinutes } from '../utils/format';

interface EventCardProps {
  to: string;
  title: string;
  summary: string;
  icon: LucideIcon;
  detail?: string;
}

function EventCard({ to, title, summary, icon: Icon, detail }: EventCardProps) {
  return (
    <Link to={to} className="focus-ring card group flex min-h-32 flex-col justify-between p-4 transition-transform hover:-translate-y-0.5">
      <div className="flex items-center justify-between gap-2">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[var(--gold)]"><Icon size={19} /></span>
        <span className="text-[0.62rem] text-[var(--ink-soft)]">افتح القسم</span>
      </div>
      <div className="mt-3">
        <h2 className="font-display text-sm text-[var(--ink)]">{title}</h2>
        <p className="mt-1 text-xs leading-relaxed text-[var(--ink-soft)]">{summary}</p>
        {detail ? <p className="mt-1 text-[0.65rem] text-[var(--brand)]">{detail}</p> : null}
      </div>
    </Link>
  );
}

function clock(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  return `${Math.floor(safe / 60).toString().padStart(2, '0')}:${(safe % 60).toString().padStart(2, '0')}`;
}

export default function Events() {
  const { profile } = useProfile();
  const session = useStudySession();
  const wallet = useStored<WalletState>(KEYS.wallet, EMPTY_WALLET);
  useStored(KEYS.stats, { days: {} as Record<string, { seconds: number }> });
  const progressMap = useStored(KEYS.progress, {} as Record<string, { completed?: boolean }>);
  const dailyStore = useStored<DailyTaskStore>(KEYS.dailyTasks, EMPTY_DAILY_TASKS);
  const farm = useStored(KEYS.farm, EMPTY_FARM);
  const gradeRecords = useStored<GradeRecord[]>(KEYS.gradebook, getGradeRecords());
  const noteMap = useStored<Record<string, unknown[]>>(KEYS.notes, {});
  const curriculumState = useStored<CurriculumCompletionState>(KEYS.curriculumProgress, {});
  const quizAttempts = useStored<unknown[]>(KEYS.quizzes, []);
  const reviewCards = useStored<Record<string, { reps?: number }>>(KEYS.cards, {});
  const practiceAttempts = useStored<Array<{ answeredCount?: number }>>(KEYS.practiceAttempts, []);
  const writtenAnswers = useStored<unknown[]>(KEYS.writtenAnswers, []);
  const plan = useStored<StudyPlan>(KEYS.plan, getPlan());
  const routineStore = useStored(KEYS.dailyRoutines, EMPTY_DAILY_ROUTINES);

  const date = localDateKey();
  const dailyDay = dailyStore.days?.[date] ?? previewDailyTaskDay(new Date(), dailyStore);
  const routineDay = getDailyRoutineDay(new Date(), routineStore);
  const completedTasks = dailyDay.tasks.filter((task) => task.done).length;
  const dailyComplete = dailyDay.tasks.length > 0 && completedTasks === dailyDay.tasks.length;
  const challenges = challengeSummary();
  const achievements = achievementSummary();
  const curriculum = overallCurriculumProgress(curriculumState);
  const eligibleCertificates = [25, 50, 75, 100].filter((threshold) => curriculum.percent >= threshold).length + (dailyComplete ? 1 : 0);
  const notesCount = Object.values(noteMap).reduce((sum, notes) => sum + (Array.isArray(notes) ? notes.length : 0), 0);
  const gradeAverage = weightedGradeAverage(gradeRecords);
  const todaySessions = plan.sessions.filter((item) => item.day === new Date().getDay());
  const doneLessons = allLessons.filter((lesson) => progressMap[lesson.id]?.completed).length;
  const studyTime = studyTimeSummary();
  const routinesDone = DAILY_ROUTINES.filter((routine) => routineDay.done[routine.id]).length;
  const ownedCollectibles = Object.values(wallet.owned).filter((count) => count > 0).length;
  const activePlants = farm.plots.filter((plot) => Boolean(plot.plant)).length;
  const reviewedCount = Object.values(reviewCards).reduce((sum, card) => sum + Math.max(0, card.reps ?? 0), 0);
  const practiceCount = practiceAttempts.reduce((sum, attempt) => sum + Math.max(0, Number(attempt.answeredCount) || 0), 0);
  const subjectName = subjects.find((subject) => subject.id === session.subjectId)?.name ?? 'جلسة الدراسة';
  const sessionLabel = session.status === 'running' ? 'جلسة نشطة' : session.status === 'paused' ? 'جلسة متوقفة مؤقتاً' : session.status === 'completed' ? 'اكتملت الجلسة' : 'ابدأ جلسة دراسة';
  const sessionDetail = session.status === 'idle' ? 'اختر مادة ومدة ٢٥ أو ٥٠ دقيقة.' : `${subjectName} · ${clock(session.elapsedSeconds)} / ${clock(session.durationSeconds)}`;

  return (
    <div className="space-y-4 pb-4">
      <PageHeader eyebrow={`مسارك الدراسي${profile.name ? ` يا ${profile.name.split(' ')[0]}` : ''}`} title="الفعاليات" subtitle="مهامك ومكافآتك وتحدياتك وتقدمك — في لوحة واحدة، بلا منافسات أو حسابات وهمية." />

      <Link to="/study-session" className="focus-ring flex min-h-24 items-center gap-3 overflow-hidden rounded-3xl bg-[linear-gradient(125deg,#0b2a3f,#144760)] p-4 text-white shadow-[var(--shadow-soft)] sm:p-5">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-[var(--gold)]"><Timer size={23} /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-[0.68rem] text-white/65">{sessionLabel}</span>
          <span className="mt-0.5 block font-display text-base">{session.status === 'running' ? 'تابع جلسة الدراسة' : session.status === 'paused' ? 'استأنف جلستك' : 'ابدأ جلسة الدراسة'}</span>
          <span className="mt-1 block text-xs text-white/65">{sessionDetail}</span>
        </span>
        <span className="shrink-0 rounded-full bg-[var(--gold)] px-3 py-2 text-xs font-semibold text-[#3a2606]">المؤقت</span>
      </Link>

      <section className="grid grid-cols-2 gap-2 sm:grid-cols-4" aria-label="ملخص نشاطك">
        <div className="card p-3"><p className="text-[0.62rem] text-[var(--ink-soft)]">دراسة اليوم</p><p className="mt-1 font-display text-lg text-[var(--ink)]">{formatMinutes(Math.round(studyTime.todaySeconds / 60))}</p></div>
        <div className="card p-3"><p className="text-[0.62rem] text-[var(--ink-soft)]">هذا الأسبوع</p><p className="mt-1 font-display text-lg text-[var(--ink)]">{formatMinutes(Math.round(studyTime.weekSeconds / 60))}</p></div>
        <div className="card p-3"><p className="text-[0.62rem] text-[var(--ink-soft)]">هذا الشهر</p><p className="mt-1 font-display text-lg text-[var(--ink)]">{formatMinutes(Math.round(studyTime.monthSeconds / 60))}</p></div>
        <div className="card p-3"><p className="text-[0.62rem] text-[var(--ink-soft)]">الإجمالي الكلي</p><p className="mt-1 font-display text-lg text-[var(--ink)]">{formatMinutes(Math.round(studyTime.totalSeconds / 60))}</p></div>
      </section>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <EventCard to="/daily-tasks" title="مهامي اليومية" summary={`${completedTasks} من ${dailyDay.tasks.length} مهام أُنجزت اليوم.`} icon={ListChecks} detail={dailyComplete ? 'اكتملت مهام اليوم' : 'قائمة اليوم محفوظة على جهازك'} />
        <EventCard to="/daily-tasks#worship-routine" title="صلاتي ووردي اليومي" summary={`${routinesDone} من ${DAILY_ROUTINES.length} متابعات اليوم.`} icon={BookOpenCheck} detail="الصلوات الخمس · القرآن · أذكار الصباح والمساء" />
        <EventCard to="/challenges" title="التحديات الفردية" summary={`${challenges.completed} من ${challenges.total} تحديات معروضة مكتملة.`} icon={Target} detail={`${challenges.claimed} مكافآت مستلمة`} />
        <EventCard to="/achievements" title="الإنجازات" summary={`فتحت ${achievements.unlocked} من ${achievements.total} إنجازاً.`} icon={Award} detail={`${achievements.claimed} مكافآت استلمتها`} />
        <EventCard to="/shop" title="متجر النقاط" summary={`رصيدك ${wallet.balance} نقطة، وتملك ${ownedCollectibles} مقتنيات رقمية.`} icon={ShoppingBag} detail={`${REWARD_CATALOG.length} عنصراً رقمياً متاحاً`} />
        <EventCard to="/farm" title="مزرعتي" summary={`${activePlants} نباتات تنمو حالياً مع الدراسة النشطة.`} icon={Sprout} detail={`${farm.totalHarvests} محاصيل حُصدت`} />
        <EventCard to="/progress" title="تقدمي الدراسي" summary={`أكملت ${doneLessons} من ${allLessons.length} درساً متاحاً.`} icon={BookOpenCheck} detail={`${quizAttempts.length} اختبارات · ${practiceCount} سؤال تدريب · ${writtenAnswers.length} إجابة تحريرية · ${reviewedCount} مراجعة`} />
        <EventCard to="/certificates" title="شهاداتي الشخصية" summary={`${eligibleCertificates} شهادات شخصية مؤهلة وفق بياناتك الحالية.`} icon={Trophy} detail={`متابعة المنهاج ${curriculum.percent}٪ · غير رسمية`} />
        <EventCard to="/plan" title="جدول الدراسة" summary={`${todaySessions.length} حصص في جدول اليوم.`} icon={CalendarDays} detail={`${todaySessions.filter((item) => item.done).length} أُنجزت · هدف ${plan.hoursPerDay} ساعات يومياً`} />
        <EventCard to="/gradebook" title="سجل العلامات" summary={gradeRecords.length ? `${gradeRecords.length} سجلات محفوظة محلياً.` : 'أضف علامتك لتتبع نتائجك دون رفعها.'} icon={FileText} detail={gradeRecords.length ? `المتوسط الموزون ${gradeAverage.percent.toLocaleString('ar-SY')}٪` : 'لا توجد علامات مسجلة بعد'} />
        <EventCard to="/notes" title="مركز الملاحظات" summary={`${notesCount} ملاحظات مرتبطة بدروسك.`} icon={StickyNote} detail="بحث وتصفية وعودة إلى موضع الملاحظة" />
        <EventCard to="/question-bank" title="بنك أسئلة المنهاج" summary={`${practiceCount} سؤال تدريب أُجيب عنه وفق سجل جهازك.`} icon={Coins} detail="اختر المادة والوحدة ونوع السؤال" />
      </div>

      <p className="rounded-2xl bg-[var(--surface-2)] px-4 py-3 text-xs leading-relaxed text-[var(--ink-soft)]">خصوصيتك أولاً: العلامات والملاحظات والتقدم والمقتنيات محفوظة محلياً على هذا الجهاز، ولا تُرفع إلى خادم التطبيق.</p>
    </div>
  );
}
