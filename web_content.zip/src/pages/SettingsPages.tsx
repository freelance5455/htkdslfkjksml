import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Footer } from '../components/Footer.js';
import { Logo } from '../components/Logo.js';
import {
  User as UserIcon,
  Camera,
  ShieldCheck,
  Volume2,
  Sparkles,
  Palette,
  Bell,
  Cpu,
  Lock,
  ArrowLeft,
  Check,
  AlertCircle,
  Play,
  RotateCcw,
  Sliders,
  Trash2,
  ExternalLink,
  Loader2,
} from 'lucide-react';

interface SettingsLayoutProps {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}

const SettingsLayout: React.FC<SettingsLayoutProps> = ({ title, subtitle, children }) => {
  const { setCurrentPage } = useAuth();
  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/85 dark:bg-slate-950/85 backdrop-blur-md px-4 py-3 sm:px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentPage('chat')}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Return to Chat"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                {title}
              </h1>
              <p className="text-[11px] text-slate-400">{subtitle}</p>
            </div>
          </div>
          <button onClick={() => setCurrentPage('chat')} className="focus:outline-none">
            <Logo size="xs" showText={false} />
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {children}
      </main>

      <Footer compact />
    </div>
  );
};

// ==========================================
// 1. PROFILE OVERVIEW PAGE
// ==========================================
export const ProfilePage: React.FC = () => {
  const { user, setCurrentPage, logout } = useAuth();

  return (
    <SettingsLayout
      title="User Profile"
      subtitle="View and manage your AI Pocket Chat account credentials"
    >
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="relative">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user?.name}
                className="w-24 h-24 rounded-2xl object-cover border-2 border-indigo-500/30 shadow-md"
              />
            ) : (
              <div className="w-24 h-24 rounded-2xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-3xl flex items-center justify-center border-2 border-indigo-500/30 shadow-md">
                {user?.name?.charAt(0).toUpperCase() || 'U'}
              </div>
            )}
          </div>

          <div className="text-center sm:text-left space-y-1.5 flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{user?.name}</h2>
              {user?.emailVerified ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-850">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Verified Account
                </span>
              ) : (
                <button
                  onClick={() => setCurrentPage('verify-email')}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-850 hover:underline"
                >
                  Verify Email
                </button>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">{user?.email}</p>
            {user?.bio && (
              <p className="text-xs text-slate-600 dark:text-slate-300 pt-1 leading-relaxed">
                {user.bio}
              </p>
            )}
            <p className="text-[10px] text-slate-400 pt-1">
              Member since: {new Date(user?.createdAt || Date.now()).toLocaleDateString()}
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('edit-profile')}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-xs transition"
          >
            Edit Profile
          </button>
        </div>

        {/* Quick Settings Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={() => setCurrentPage('personalization-settings')}
            className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800 bg-slate-50/50 dark:bg-slate-800/40 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">AI Personalization</h4>
                <p className="text-[11px] text-slate-400">Persona, tone, language, custom instructions</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setCurrentPage('voice-settings')}
            className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800 bg-slate-50/50 dark:bg-slate-800/40 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Voice Settings</h4>
                <p className="text-[11px] text-slate-400">Speech synthesis voice, speed, pitch</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setCurrentPage('appearance-settings')}
            className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800 bg-slate-50/50 dark:bg-slate-800/40 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950 text-violet-600 dark:text-violet-400">
                <Palette className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Appearance & Theme</h4>
                <p className="text-[11px] text-slate-400">Dark, light, font sizes, animations</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setCurrentPage('privacy-security')}
            className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800 bg-slate-50/50 dark:bg-slate-800/40 text-left transition flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Privacy & Security</h4>
                <p className="text-[11px] text-slate-400">Passwords, session data, account removal</p>
              </div>
            </div>
          </button>
        </div>
      </div>
    </SettingsLayout>
  );
};

// ==========================================
// 2. EDIT PROFILE PAGE
// ==========================================
export const EditProfilePage: React.FC = () => {
  const { user, updateUser, authFetch, setCurrentPage } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [photoURL, setPhotoURL] = useState(user?.photoURL || '');
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sampleAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80',
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setError('Image must be less than 2MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setPhotoURL(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSaved(false);

    try {
      const res = await authFetch('/api/user/profile', {
        method: 'PATCH',
        body: JSON.stringify({ name: name.trim(), bio: bio.trim(), photoURL }),
      });
      const data = await res.json();
      if (res.ok) {
        updateUser(data.user);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      } else {
        setError(data.error || 'Failed to update profile.');
      }
    } catch {
      setError('Network error updating profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SettingsLayout title="Edit Profile" subtitle="Update your personal details and avatar">
      <form
        onSubmit={handleSave}
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6"
      >
        {saved && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Profile saved successfully!</span>
          </div>
        )}

        {error && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        {/* Avatar Section */}
        <div className="space-y-3">
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Profile Photo
          </label>
          <div className="flex items-center gap-4">
            {photoURL ? (
              <img
                src={photoURL}
                alt="Avatar Preview"
                className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700"
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-xl flex items-center justify-center">
                {name.charAt(0).toUpperCase() || 'U'}
              </div>
            )}
            <div className="space-y-1">
              <label className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer transition">
                <Camera className="w-3.5 h-3.5" />
                <span>Upload Photo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              {photoURL && (
                <button
                  type="button"
                  onClick={() => setPhotoURL('')}
                  className="block text-[11px] text-rose-500 hover:underline"
                >
                  Remove photo
                </button>
              )}
            </div>
          </div>

          <div>
            <span className="text-[11px] text-slate-400">Or choose a preset avatar:</span>
            <div className="flex items-center gap-2 pt-1.5">
              {sampleAvatars.map((url, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPhotoURL(url)}
                  className={`w-9 h-9 rounded-xl overflow-hidden border-2 transition ${
                    photoURL === url ? 'border-indigo-600 scale-105' : 'border-transparent opacity-80'
                  }`}
                >
                  <img src={url} alt={`Preset ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Full Name
          </label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            required
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Bio */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            About You (Bio)
          </label>
          <textarea
            rows={3}
            value={bio}
            onChange={e => setBio(e.target.value)}
            placeholder="Tell your AI assistant a little about your role, interests, or background..."
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setCurrentPage('profile')}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-xs font-semibold text-white shadow-sm shadow-indigo-600/30 transition flex items-center gap-2"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Changes'}
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};

// ==========================================
// 3. VOICE SETTINGS PAGE
// ==========================================
export const VoiceSettingsPage: React.FC = () => {
  const { preferences, updatePreferences } = useAuth();
  const voice = preferences?.voice || preferences?.voiceSettings;

  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceURI, setSelectedVoiceURI] = useState(voice?.voiceURI || '');
  const [rate, setRate] = useState(voice?.rate ?? 1.0);
  const [pitch, setPitch] = useState(voice?.pitch ?? 1.0);
  const [autoRead, setAutoRead] = useState(voice?.autoRead ?? false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const load = () => {
        const v = window.speechSynthesis.getVoices();
        setAvailableVoices(v);
      };
      load();
      window.speechSynthesis.onvoiceschanged = load;
    }
  }, []);

  const handleTestVoice = () => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(
      'Hello! This is how your AI Pocket Chat assistant sounds with your configured voice settings.'
    );
    utterance.rate = rate;
    utterance.pitch = pitch;
    if (selectedVoiceURI) {
      const matched = availableVoices.find(v => v.voiceURI === selectedVoiceURI);
      if (matched) utterance.voice = matched;
    }
    window.speechSynthesis.speak(utterance);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updatePreferences({
      voice: {
        voiceURI: selectedVoiceURI,
        rate,
        pitch,
        autoRead,
      },
      voiceSettings: {
        voiceURI: selectedVoiceURI,
        rate,
        pitch,
        autoRead,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <SettingsLayout
      title="Voice Settings"
      subtitle="Configure text-to-speech voice, speed, pitch, and playback"
    >
      <form
        onSubmit={handleSave}
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6"
      >
        {saved && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Voice settings updated!</span>
          </div>
        )}

        {/* Voice selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Select Voice
          </label>
          <select
            value={selectedVoiceURI}
            onChange={e => setSelectedVoiceURI(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">Default System Voice</option>
            {availableVoices.map(v => (
              <option key={v.voiceURI} value={v.voiceURI}>
                {v.name} ({v.lang})
              </option>
            ))}
          </select>
        </div>

        {/* Speed / Rate */}
        <div>
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            <span>Speech Speed (Rate)</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">{rate.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="2.0"
            step="0.1"
            value={rate}
            onChange={e => setRate(parseFloat(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400 mt-1">
            <span>0.5x (Slow)</span>
            <span>1.0x (Normal)</span>
            <span>2.0x (Fast)</span>
          </div>
        </div>

        {/* Pitch */}
        <div>
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            <span>Voice Pitch</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">{pitch.toFixed(1)}</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="1.5"
            step="0.1"
            value={pitch}
            onChange={e => setPitch(parseFloat(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400 mt-1">
            <span>Low (0.5)</span>
            <span>Standard (1.0)</span>
            <span>High (1.5)</span>
          </div>
        </div>

        {/* Auto read responses toggle */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              Auto Read AI Responses
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Automatically speak new messages aloud as soon as they are completed.
            </p>
          </div>
          <input
            type="checkbox"
            checked={autoRead}
            onChange={e => setAutoRead(e.target.checked)}
            className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
          />
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={handleTestVoice}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center justify-center gap-1.5 transition"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Test Voice Audio</span>
          </button>

          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition"
          >
            Save Voice Preferences
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};

// ==========================================
// 4. AI PERSONALIZATION PAGE
// ==========================================
export const PersonalizationSettingsPage: React.FC = () => {
  const { preferences, updatePreferences } = useAuth();
  const p = preferences?.personalization;

  const [aiName, setAiName] = useState(p?.aiName || 'AI Pocket Chat');
  const [responseStyle, setResponseStyle] = useState<'Professional' | 'Friendly' | 'Creative' | 'Simple' | 'Detailed'>(
    p?.responseStyle || 'Friendly'
  );
  const [responseLength, setResponseLength] = useState<'Short' | 'Balanced' | 'Detailed'>(
    p?.responseLength || 'Balanced'
  );
  const [preferredLanguage, setPreferredLanguage] = useState(p?.preferredLanguage || 'English');
  const [customInstructions, setCustomInstructions] = useState(p?.customInstructions || '');
  const [saved, setSaved] = useState(false);

  const styles: Array<'Professional' | 'Friendly' | 'Creative' | 'Simple' | 'Detailed'> = [
    'Professional',
    'Friendly',
    'Creative',
    'Simple',
    'Detailed',
  ];
  const lengths: Array<'Short' | 'Balanced' | 'Detailed'> = ['Short', 'Balanced', 'Detailed'];
  const languages = [
    'English',
    'Spanish',
    'Arabic',
    'French',
    'German',
    'Japanese',
    'Chinese',
    'Portuguese',
    'Urdu',
    'Hindi',
    'Russian',
  ];

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updatePreferences({
      personalization: {
        aiName,
        responseStyle: responseStyle as any,
        responseLength: responseLength as any,
        preferredLanguage,
        customInstructions,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <SettingsLayout
      title="AI Personalization"
      subtitle="Customize your AI companion's persona, language, tone, and directives"
    >
      <form
        onSubmit={handleSave}
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6"
      >
        {saved && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>AI Personalization updated! Gemini will adopt these guidelines immediately.</span>
          </div>
        )}

        {/* AI Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Assistant Name
          </label>
          <input
            type="text"
            value={aiName}
            onChange={e => setAiName(e.target.value)}
            placeholder="e.g. Athena, Pocket Assistant, Jarvis"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Response Style */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Response Style / Tone
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {styles.map(s => (
              <button
                key={s}
                type="button"
                onClick={() => setResponseStyle(s)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold transition border ${
                  responseStyle === s
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Response Length */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Response Length Preference
          </label>
          <div className="grid grid-cols-3 gap-2">
            {lengths.map(l => (
              <button
                key={l}
                type="button"
                onClick={() => setResponseLength(l)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold transition border ${
                  responseLength === l
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Preferred Language */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Primary Language
          </label>
          <select
            value={preferredLanguage}
            onChange={e => setPreferredLanguage(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            {languages.map(lang => (
              <option key={lang} value={lang}>
                {lang}
              </option>
            ))}
          </select>
        </div>

        {/* Custom Instructions */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Custom Instructions / System Directives
          </label>
          <textarea
            rows={4}
            value={customInstructions}
            onChange={e => setCustomInstructions(e.target.value)}
            placeholder="e.g. Always format programming code in TypeScript. Keep explanations simple. Refer to me as Doctor."
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
          />
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition"
          >
            Save AI Personality
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};

// ==========================================
// 5. APPEARANCE SETTINGS PAGE
// ==========================================
export const AppearanceSettingsPage: React.FC = () => {
  const { preferences, updatePreferences } = useAuth();
  const app = preferences?.appearance;

  const [theme, setTheme] = useState(preferences?.theme || 'system');
  const [fontSize, setFontSize] = useState(app?.fontSize || 'base');
  const [chatDensity, setChatDensity] = useState(app?.chatDensity || 'comfortable');
  const [animations, setAnimations] = useState(app?.animations ?? true);
  const [saved, setSaved] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updatePreferences({
      theme: theme as any,
      appearance: {
        theme: theme as any,
        fontSize: fontSize as any,
        chatDensity: chatDensity as any,
        animations,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <SettingsLayout title="Appearance & Theme" subtitle="Adjust colors, font sizes, and layout density">
      <form
        onSubmit={handleSave}
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6"
      >
        {saved && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Appearance settings saved!</span>
          </div>
        )}

        {/* Theme mode */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Theme Mode
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'system', label: 'System Auto', desc: 'Syncs with device mode' },
              { id: 'light', label: 'Light Theme', desc: 'Bright, clean white' },
              { id: 'dark', label: 'Dark Theme', desc: 'True dark OLED friendly' },
            ].map(t => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTheme(t.id as any)}
                className={`p-3.5 rounded-2xl border text-left transition ${
                  theme === t.id
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-600 dark:border-indigo-500 ring-2 ring-indigo-500/20'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-100'
                }`}
              >
                <p className="text-xs font-bold text-slate-900 dark:text-white">{t.label}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{t.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Font Size */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Font Size
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'sm', label: 'Compact (13px)' },
              { id: 'base', label: 'Default (15px)' },
              { id: 'lg', label: 'Large (17px)' },
            ].map(f => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFontSize(f.id as any)}
                className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition ${
                  fontSize === f.id
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Density */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Chat Message Density
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'comfortable', label: 'Comfortable', desc: 'Spacious padding' },
              { id: 'compact', label: 'Compact', desc: 'Fits more lines on screen' },
            ].map(d => (
              <button
                key={d.id}
                type="button"
                onClick={() => setChatDensity(d.id as any)}
                className={`p-3 rounded-xl border text-left transition ${
                  chatDensity === d.id
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-600 text-indigo-700 dark:text-indigo-300 font-semibold'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="text-xs font-bold">{d.label}</div>
                <div className="text-[11px] text-slate-400">{d.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Animations */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">Smooth Transitions</h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Enable subtle motion effects and layout animations.
            </p>
          </div>
          <input
            type="checkbox"
            checked={animations}
            onChange={e => setAnimations(e.target.checked)}
            className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
          />
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition"
          >
            Apply Appearance
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};

// ==========================================
// 6. AI & API SETTINGS PAGE
// ==========================================
export const AISettingsPage: React.FC = () => {
  const { preferences, updatePreferences } = useAuth();
  const ai = preferences?.aiSettings;

  const [model, setModel] = useState(ai?.model || 'gemini-3.8-flash');
  const [temperature, setTemperature] = useState(ai?.temperature ?? 0.7);
  const [streamResponse, setStreamResponse] = useState(ai?.streamResponse ?? true);
  const [saved, setSaved] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updatePreferences({
      aiSettings: {
        model,
        temperature,
        maxTokens: 4096,
        streamResponse,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <SettingsLayout
      title="API & Model Configuration"
      subtitle="Configure Gemini model generation parameters and server security"
    >
      <form
        onSubmit={handleSave}
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6"
      >
        {saved && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>AI model settings updated!</span>
          </div>
        )}

        {/* Security Architecture Callout */}
        <div className="p-4 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-850 space-y-2">
          <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-300 font-bold text-xs">
            <ShieldCheck className="w-4 h-4" />
            <span>Zero Client-Side Exposure (Server-Side Proxy Architecture)</span>
          </div>
          <p className="text-xs text-indigo-600 dark:text-indigo-400 leading-relaxed">
            All AI queries are processed through our protected Node.js backend. Secret credentials and API keys are never exposed to the client browser, strictly enforcing data isolation.
          </p>
        </div>

        {/* Model Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Active Intelligence Model
          </label>
          <select
            value={model}
            onChange={e => setModel(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="gemini-3.8-flash">Google Gemini 3.8 Flash (Recommended - Fastest)</option>
            <option value="gemini-2.5-flash">Google Gemini 2.5 Flash</option>
          </select>
        </div>

        {/* Temperature */}
        <div>
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            <span>Creativity vs Precision (Temperature)</span>
            <span className="font-mono text-indigo-600 dark:text-indigo-400">
              {temperature.toFixed(2)}
            </span>
          </div>
          <input
            type="range"
            min="0.0"
            max="1.0"
            step="0.05"
            value={temperature}
            onChange={e => setTemperature(parseFloat(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400 mt-1">
            <span>0.0 (Strict & Factual)</span>
            <span>0.7 (Balanced Default)</span>
            <span>1.0 (Highly Creative)</span>
          </div>
        </div>

        {/* Streaming Mode */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">Real-Time Streaming</h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Stream response tokens live using Server-Sent Events (SSE).
            </p>
          </div>
          <input
            type="checkbox"
            checked={streamResponse}
            onChange={e => setStreamResponse(e.target.checked)}
            className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
          />
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition"
          >
            Save Model Parameters
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};

// ==========================================
// 7. NOTIFICATIONS SETTINGS PAGE
// ==========================================
export const NotificationsSettingsPage: React.FC = () => {
  const { preferences, updatePreferences } = useAuth();
  const n = preferences?.notifications;

  const [enabled, setEnabled] = useState(n?.enabled ?? true);
  const [aiUpdates, setAiUpdates] = useState(n?.aiUpdates ?? true);
  const [productUpdates, setProductUpdates] = useState(n?.productUpdates ?? false);
  const [accountAlerts, setAccountAlerts] = useState(n?.accountAlerts ?? true);
  const [permissionStatus, setPermissionStatus] = useState<string>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported'
  );
  const [saved, setSaved] = useState(false);

  const requestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const res = await Notification.requestPermission();
      setPermissionStatus(res);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updatePreferences({
      notifications: {
        enabled,
        aiUpdates,
        productUpdates,
        accountAlerts,
      },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <SettingsLayout
      title="Notification Preferences"
      subtitle="Manage web alerts, response notifications, and security dispatches"
    >
      <form
        onSubmit={handleSave}
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6"
      >
        {saved && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Notification preferences updated!</span>
          </div>
        )}

        {/* Browser Permission Card */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              Browser Push Permissions
            </h4>
            <p className="text-[11px] text-slate-400">
              Current browser status:{' '}
              <strong className="text-indigo-600 dark:text-indigo-400 capitalize">
                {permissionStatus}
              </strong>
            </p>
          </div>
          {permissionStatus !== 'granted' && permissionStatus !== 'unsupported' && (
            <button
              type="button"
              onClick={requestNotificationPermission}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-500 transition"
            >
              Request Access
            </button>
          )}
        </div>

        {/* Toggle options */}
        <div className="space-y-3">
          {[
            {
              id: 'enabled',
              title: 'Master Notifications',
              desc: 'Enable in-app notifications and banner alerts.',
              checked: enabled,
              onChange: setEnabled,
            },
            {
              id: 'aiUpdates',
              title: 'AI Generation Alerts',
              desc: 'Notify when long AI tasks or summaries finish processing.',
              checked: aiUpdates,
              onChange: setAiUpdates,
            },
            {
              id: 'accountAlerts',
              title: 'Security & Account Alerts',
              desc: 'Notify upon new device login or password change events.',
              checked: accountAlerts,
              onChange: setAccountAlerts,
            },
            {
              id: 'productUpdates',
              title: 'Feature Release Announcements',
              desc: 'Receive updates on new AI models and tool features.',
              checked: productUpdates,
              onChange: setProductUpdates,
            },
          ].map(item => (
            <div
              key={item.id}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50/50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800"
            >
              <div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white">{item.title}</h5>
                <p className="text-[11px] text-slate-400">{item.desc}</p>
              </div>
              <input
                type="checkbox"
                checked={item.checked}
                onChange={e => item.onChange(e.target.checked)}
                className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
              />
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition"
          >
            Save Notification Settings
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};

// ==========================================
// 8. PRIVACY & SECURITY PAGE
// ==========================================
export const PrivacySecurityPage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  return (
    <SettingsLayout
      title="Privacy & Security"
      subtitle="Manage account protection, data retention, and privacy choices"
    >
      <div className="space-y-6">
        {/* Security Overview Card */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Account Credentials & Encryption
              </h3>
              <p className="text-xs text-slate-400">
                Passwords are salted and hashed using scrypt cryptography before persistence.
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={() => setCurrentPage('change-password')}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition text-center"
            >
              Change Password
            </button>

            {!user?.emailVerified && (
              <button
                onClick={() => setCurrentPage('verify-email')}
                className="px-4 py-2.5 rounded-xl border border-amber-300 dark:border-amber-800 text-amber-600 dark:text-amber-400 font-semibold text-xs hover:bg-amber-50 dark:hover:bg-amber-950/40 transition text-center"
              >
                Verify Email Address
              </button>
            )}
          </div>
        </div>

        {/* Data Retention & Privacy Rights */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Data Control & Erasure Rights
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            You maintain full sovereignty over your interactions with AI Pocket Chat. You can clear your chat history or permanently delete your account at any time.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={() => setCurrentPage('chat')}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs hover:bg-slate-100 dark:hover:bg-slate-800 transition text-center"
            >
              Open History in Dashboard
            </button>

            <button
              onClick={() => {
                const confirmed = window.confirm(
                  'Are you sure you want to delete your account? This will erase all conversations and settings.'
                );
                if (confirmed) {
                  // Direct to dashboard where modal handles deletion
                  setCurrentPage('chat');
                }
              }}
              className="px-4 py-2.5 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 font-semibold text-xs hover:bg-rose-50 dark:hover:bg-rose-950/40 transition text-center"
            >
              Delete Account Permanently
            </button>
          </div>
        </div>

        {/* Owner attribution footnote */}
        <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-900/60 text-xs text-slate-500 dark:text-slate-400 text-center font-medium">
          OWNER NAME: Ali ABDULLAH • AI Pocket Chat
        </div>
      </div>
    </SettingsLayout>
  );
};

// ==========================================
// 9. CHANGE PASSWORD PAGE
// ==========================================
export const ChangePasswordPage: React.FC = () => {
  const { authFetch, setCurrentPage } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError('New passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      const res = await authFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword, confirmNewPassword }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessage('Password updated successfully!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
        setTimeout(() => setCurrentPage('privacy-security'), 1800);
      } else {
        setError(data.error || 'Failed to update password.');
      }
    } catch {
      setError('Network error.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SettingsLayout
      title="Change Password"
      subtitle="Update your account security key with a new password"
    >
      <form
        onSubmit={handleSubmit}
        className="max-w-xl mx-auto rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-5"
      >
        {message && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>{message}</span>
          </div>
        )}

        {error && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Current Password
          </label>
          <input
            type="password"
            value={currentPassword}
            onChange={e => setCurrentPassword(e.target.value)}
            required
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            New Password (min. 6 chars)
          </label>
          <input
            type="password"
            value={newPassword}
            onChange={e => setNewPassword(e.target.value)}
            required
            minLength={6}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Confirm New Password
          </label>
          <input
            type="password"
            value={confirmNewPassword}
            onChange={e => setConfirmNewPassword(e.target.value)}
            required
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setCurrentPage('privacy-security')}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition flex items-center gap-2"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Update Password'}
          </button>
        </div>
      </form>
    </SettingsLayout>
  );
};
