import { useMemo, useState, type FormEvent } from 'react';
import { BookOpen, ClipboardList, ImagePlus, Pencil, Printer, Save, Trash2, X } from 'lucide-react';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Card, SectionHeader } from '../components/ui/Card';
import { Badge, EmptyState, Modal } from '../components/ui/Feedback';
import { subjects } from '../data/content';
import { useToast } from '../hooks/useToast';
import {
  compressGradeImage,
  deleteGradeRecord,
  getGradeRecords,
  saveGradeRecord,
  weightedGradeAverage,
  type GradeImage,
  type GradeInput,
  type GradeKind,
  type GradeRecord,
} from '../services/gradebook';
import { KEYS, useStored } from '../services/storage';

const inputClass = 'focus-ring h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]';
const today = () => {
  const now = new Date();
  return `${now.getFullYear()}-${`${now.getMonth() + 1}`.padStart(2, '0')}-${`${now.getDate()}`.padStart(2, '0')}`;
};
const kinds: GradeKind[] = ['اختبار يومي', 'اختبار شهري', 'امتحان', 'أخرى'];

interface GradeForm {
  subjectId: string;
  title: string;
  kind: GradeKind;
  date: string;
  score: string;
  maxScore: string;
  note: string;
  attachment: GradeImage | null;
}
function newForm(): GradeForm {
  return { subjectId: subjects[0]?.id ?? 'math', title: '', kind: 'اختبار يومي', date: today(), score: '', maxScore: '100', note: '', attachment: null };
}
function dateLabel(date: string): string {
  const value = new Date(`${date}T12:00:00`);
  return Number.isNaN(value.getTime()) ? date : value.toLocaleDateString('ar-SY', { day: 'numeric', month: 'long', year: 'numeric' });
}
function numberLabel(value: number): string {
  return new Intl.NumberFormat('ar-SY', { maximumFractionDigits: 1 }).format(value);
}
function downloadCsv(records: GradeRecord[]) {
  const fields = ['المادة', 'العنوان', 'النوع', 'التاريخ', 'العلامة', 'العلامة العظمى', 'ملاحظة'];
  const quote = (text: string | number) => `"${String(text).replaceAll('"', '""')}"`;
  const lines = [fields.map(quote).join(','), ...records.map((record) => [
    subjects.find((subject) => subject.id === record.subjectId)?.name ?? record.subjectId,
    record.title, record.kind, record.date, record.score, record.maxScore, record.note ?? '',
  ].map(quote).join(','))];
  const blob = new Blob(['\uFEFF', lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'سجل-علاماتي.csv';
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function Gradebook() {
  const { toast } = useToast();
  const grades = useStored(KEYS.gradebook, getGradeRecords());
  const [filterSubject, setFilterSubject] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [form, setForm] = useState<GradeForm>(newForm);
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => grades
    .filter((record) => filterSubject === 'all' || record.subjectId === filterSubject)
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date) || b.updatedAt - a.updatedAt), [filterSubject, grades]);
  const average = weightedGradeAverage(filtered);

  const openNew = () => {
    setEditingId(null);
    setForm(newForm());
    setFormOpen(true);
  };
  const openEdit = (record: GradeRecord) => {
    setEditingId(record.id);
    setForm({
      subjectId: record.subjectId, title: record.title, kind: record.kind, date: record.date,
      score: String(record.score), maxScore: String(record.maxScore), note: record.note ?? '', attachment: record.attachment ?? null,
    });
    setFormOpen(true);
  };

  const save = async (event: FormEvent) => {
    event.preventDefault();
    const input: GradeInput = {
      subjectId: form.subjectId,
      title: form.title,
      kind: form.kind,
      date: form.date,
      score: form.score.trim() ? Number(form.score) : Number.NaN,
      maxScore: form.maxScore.trim() ? Number(form.maxScore) : Number.NaN,
      note: form.note,
      ...(form.attachment ? { attachment: form.attachment } : {}),
    };
    setSaving(true);
    try {
      const result = await saveGradeRecord(input, editingId ?? undefined);
      if (!result.ok) {
        const message = result.reason === 'invalid' ? 'تحقق من المادة والعنوان والتاريخ، ومن أن العلامة بين صفر والعلامة العظمى.'
          : result.reason === 'too-many' ? 'وصل سجل العلامات إلى الحد الأقصى البالغ ٥٠٠ سجل.'
            : result.reason === 'too-large' ? 'بيانات الصور كبيرة جداً؛ احذف مرفقاً أو اختر صورة أصغر.'
              : 'لم تتسع مساحة الجهاز لحفظ العلامة. خفّف المرفقات أو احذف ملفات غير لازمة.';
        toast(message, 'error');
        return;
      }
      setFormOpen(false);
      toast(editingId ? 'حُدّث سجل العلامة على جهازك.' : 'حُفظت العلامة محلياً على جهازك.', 'success');
    } catch {
      toast('تعذّر حفظ العلامة في التخزين المحلي.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!pendingDelete) return;
    const ok = await deleteGradeRecord(pendingDelete);
    setPendingDelete(null);
    toast(ok ? 'حُذف سجل العلامة ومرفقه المحلي.' : 'تعذّر حذف السجل من مساحة الجهاز.', ok ? 'info' : 'error');
  };

  const selectImage = async (file?: File) => {
    if (!file) return;
    try {
      const image = await compressGradeImage(file);
      setForm((current) => ({ ...current, attachment: image }));
      toast(`ضُغطت الصورة إلى ${numberLabel(Math.ceil(image.sizeBytes / 1024))} كيلوبايت وحُفظت محلياً فقط.`, 'success');
    } catch (error) {
      toast(error instanceof Error ? error.message : 'تعذّر ضغط الصورة.', 'error');
    }
  };

  const overall = weightedGradeAverage(grades);

  return (
    <div>
      <PageHeader
        eyebrow="بياناتك تبقى على جهازك"
        title="سجل العلامات"
        subtitle="أضف اختباراتك واحسب المتوسط الموزون من مجموع العلامات إلى مجموع العلامات العظمى. لا نقاط ولا مكافآت مرتبطة بالعلامات."
        back="/"
        action={<Button className="min-h-11" size="sm" icon={<BookOpen size={15} />} onClick={openNew}>إضافة علامة</Button>}
      />

      <Card className="mb-4 border-[color-mix(in_srgb,var(--success)_35%,var(--line))] bg-[color-mix(in_srgb,var(--success)_7%,var(--surface))]">
        <div className="flex items-start gap-3">
          <ClipboardList size={20} className="mt-1 shrink-0 text-[var(--success)]" />
          <p className="text-sm leading-relaxed text-[var(--ink-soft)]">العلامات والصور محفوظة محلياً في هذا المتصفح وتدخل في النسخة الاحتياطية. لا نرفعها إلى خادم. تُضغط الصور وتُحوّل إلى JPEG صغير؛ احذف المرفق أو استخدم نسخة احتياطية إذا امتلأت مساحة الجهاز.</p>
        </div>
      </Card>

      <div className="mb-4 grid grid-cols-2 gap-2">
        <Card className="p-3"><p className="text-xs text-[var(--ink-soft)]">متوسط العرض</p><p className="mt-1 font-display text-xl text-[var(--ink)]">{numberLabel(average.percent)}%</p><p className="text-[0.68rem] text-[var(--ink-soft)]">{numberLabel(average.score)} من {numberLabel(average.total)} · {average.count} سجلات</p></Card>
        <Card className="p-3"><p className="text-xs text-[var(--ink-soft)]">الإجمالي للمواد الثماني</p><p className="mt-1 font-display text-xl text-[var(--ink)]">{numberLabel(overall.percent)}%</p><p className="text-[0.68rem] text-[var(--ink-soft)]">{numberLabel(overall.score)} من {numberLabel(overall.total)} · {overall.count} سجلات</p></Card>
      </div>

      <SectionHeader
        title="متوسط كل مادة"
        hint="الوزن يحسب بحسب مجموع العلامات العظمى، لا بمتوسط النسب البسيط."
      />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {subjects.map((subject) => {
          const subjectGrades = grades.filter((record) => record.subjectId === subject.id);
          const summary = weightedGradeAverage(subjectGrades);
          return <button key={subject.id} type="button" onClick={() => setFilterSubject(subject.id)} className={`focus-ring rounded-2xl border p-3 text-start ${filterSubject === subject.id ? 'border-[var(--gold)] bg-[var(--gold-soft)]' : 'border-[var(--line)] bg-[var(--surface)]'}`}>
            <span className="block truncate text-xs text-[var(--ink-soft)]">{subject.name}</span>
            <span className="mt-1 block font-display text-lg text-[var(--ink)]">{summary.count ? `${numberLabel(summary.percent)}%` : '—'}</span>
            <span className="block text-[0.65rem] text-[var(--ink-soft)]">{summary.count} اختبارات</span>
          </button>;
        })}
      </div>

      <div className="no-print mt-5 flex flex-wrap items-center justify-between gap-2">
        <SectionHeader title="سجل الاختبارات" className="mb-0" />
        <div className="flex flex-wrap gap-2">
          <select aria-label="تصفية العلامات حسب المادة" value={filterSubject} onChange={(event) => setFilterSubject(event.target.value)} className="focus-ring h-11 rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-xs text-[var(--ink)]">
            <option value="all">كل المواد</option>
            {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
          </select>
          <Button className="min-h-11" size="sm" variant="outline" icon={<Printer size={14} />} disabled={!filtered.length} onClick={() => window.print()}>طباعة</Button>
          <Button className="min-h-11" size="sm" variant="outline" disabled={!filtered.length} onClick={() => downloadCsv(filtered)}>تصدير CSV</Button>
        </div>
      </div>

      {filtered.length ? (
        <div className="no-print mt-3 space-y-2">
          {filtered.map((record) => {
            const subject = subjects.find((item) => item.id === record.subjectId);
            return <Card key={record.id} className="p-3">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl" style={{ background: subject?.colorSoft ?? 'var(--surface-2)', color: subject?.color ?? 'var(--ink)' }}><BookOpen size={18} /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5"><h3 className="font-display text-sm text-[var(--ink)]">{record.title}</h3><Badge>{record.kind}</Badge></div>
                  <p className="mt-0.5 text-xs text-[var(--ink-soft)]">{subject?.name} · {dateLabel(record.date)}</p>
                  <p className="mt-2 text-sm font-semibold text-[var(--ink)]">{numberLabel(record.score)} / {numberLabel(record.maxScore)} <span className="font-normal text-[var(--ink-soft)]">({numberLabel((record.score / record.maxScore) * 100)}%)</span></p>
                  {record.note ? <p className="mt-1 whitespace-pre-wrap text-xs leading-relaxed text-[var(--ink-soft)]">{record.note}</p> : null}
                  {record.attachment ? <div className="mt-2 flex items-center gap-2"><img src={record.attachment.dataUrl} alt={`مرفق محلي للاختبار ${record.title}`} className="h-14 w-14 rounded-xl border border-[var(--line)] object-cover" /><span className="text-[0.68rem] text-[var(--ink-soft)]">صورة محفوظة على الجهاز · {numberLabel(Math.ceil(record.attachment.sizeBytes / 1024))} كيلوبايت</span></div> : null}
                </div>
                <div className="flex shrink-0 flex-col gap-1">
                  <button type="button" onClick={() => openEdit(record)} aria-label={`تعديل ${record.title}`} className="focus-ring flex h-11 w-11 items-center justify-center rounded-xl text-[var(--ink-soft)] hover:bg-[var(--surface-2)]"><Pencil size={15} /></button>
                  <button type="button" onClick={() => setPendingDelete(record.id)} aria-label={`حذف ${record.title}`} className="focus-ring flex h-11 w-11 items-center justify-center rounded-xl text-[var(--ink-soft)] hover:text-[var(--danger)]"><Trash2 size={15} /></button>
                </div>
              </div>
            </Card>;
          })}
        </div>
      ) : (
        <EmptyState className="mt-3" icon={<ClipboardList size={19} />} title={grades.length ? 'لا توجد نتائج لهذا الفلتر' : 'لم تضف علامة بعد'} description={grades.length ? 'اختر مادة أخرى لعرض سجلاتها.' : 'سجّل نتيجتك في اختبار أو امتحان، وستظهر هنا متوسطاتك الموزونة.'} action={!grades.length ? <Button onClick={openNew}>إضافة أول علامة</Button> : undefined} />
      )}

      {filtered.length ? <section className="print-area mt-4" aria-label="تقرير العلامات القابل للطباعة">
        <header className="mb-5 border-b-2 border-[var(--brand)] pb-3">
          <p className="text-xs text-[var(--ink-soft)]">منارة البكالوريا · الفرع العلمي السوري</p>
          <h2 className="mt-1 font-display text-2xl text-[var(--ink)]">تقرير سجل العلامات</h2>
          <p className="mt-1 text-sm text-[var(--ink-soft)]">{filterSubject === 'all' ? 'كل المواد' : subjects.find((item) => item.id === filterSubject)?.name} · تاريخ الطباعة: {new Date().toLocaleDateString('ar-SY')}</p>
          <p className="mt-2 text-sm text-[var(--ink)]">المتوسط الموزون: {numberLabel(average.percent)}% ({numberLabel(average.score)} من {numberLabel(average.total)})</p>
        </header>
        <table className="w-full border-collapse text-start text-sm">
          <thead><tr className="border-b border-[var(--line)]"><th className="p-2 text-start">التاريخ</th><th className="p-2 text-start">المادة</th><th className="p-2 text-start">الاختبار</th><th className="p-2 text-start">العلامة</th><th className="p-2 text-start">ملاحظة</th></tr></thead>
          <tbody>{filtered.map((record) => <tr key={record.id} className="border-b border-[var(--line)]"><td className="p-2">{dateLabel(record.date)}</td><td className="p-2">{subjects.find((item) => item.id === record.subjectId)?.name}</td><td className="p-2">{record.title} · {record.kind}</td><td className="p-2">{numberLabel(record.score)} / {numberLabel(record.maxScore)}</td><td className="p-2">{record.note || '—'}</td></tr>)}</tbody>
        </table>
        <p className="mt-4 text-[0.7rem] text-[var(--ink-soft)]">هذا تقرير شخصي محلي، وليس سجلاً مدرسياً رسمياً.</p>
      </section> : null}

      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={editingId ? 'تعديل سجل العلامة' : 'إضافة اختبار أو امتحان'}
        size="lg"
        footer={<div className="no-print"><Button block icon={<Save size={16} />} disabled={saving} onClick={(event) => {
          const formElement = (event.currentTarget.closest('[role="dialog"]')?.querySelector('form')) as HTMLFormElement | null;
          formElement?.requestSubmit();
        }}>{saving ? 'جارٍ الحفظ…' : 'حفظ محلي'}</Button></div>}
      >
        <form onSubmit={save} className="space-y-3">
          <div><label className="mb-1 block text-xs text-[var(--ink-soft)]" htmlFor="grade-title">اسم الاختبار</label><input id="grade-title" required minLength={2} maxLength={120} value={form.title} onChange={(event) => setForm((value) => ({ ...value, title: event.target.value }))} className={inputClass} placeholder="مثال: اختبار النهايات الأول" /></div>
          <div className="grid grid-cols-2 gap-2">
            <label className="text-xs text-[var(--ink-soft)]">المادة<select required value={form.subjectId} onChange={(event) => setForm((value) => ({ ...value, subjectId: event.target.value }))} className={`${inputClass} mt-1`}>{subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}</select></label>
            <label className="text-xs text-[var(--ink-soft)]">النوع<select required value={form.kind} onChange={(event) => setForm((value) => ({ ...value, kind: event.target.value as GradeKind }))} className={`${inputClass} mt-1`}>{kinds.map((kind) => <option key={kind}>{kind}</option>)}</select></label>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <label className="col-span-3 text-xs text-[var(--ink-soft)] sm:col-span-1">التاريخ<input required type="date" value={form.date} onChange={(event) => setForm((value) => ({ ...value, date: event.target.value }))} className={`${inputClass} mt-1`} /></label>
            <label className="text-xs text-[var(--ink-soft)]">علامتك<input required type="number" min="0" step="any" value={form.score} onChange={(event) => setForm((value) => ({ ...value, score: event.target.value }))} className={`${inputClass} mt-1`} /></label>
            <label className="text-xs text-[var(--ink-soft)]">العظمى<input required type="number" min="0.01" step="any" value={form.maxScore} onChange={(event) => setForm((value) => ({ ...value, maxScore: event.target.value }))} className={`${inputClass} mt-1`} /></label>
          </div>
          <div><label className="mb-1 block text-xs text-[var(--ink-soft)]" htmlFor="grade-note">ملاحظة (اختيارية)</label><textarea id="grade-note" maxLength={2000} rows={3} value={form.note} onChange={(event) => setForm((value) => ({ ...value, note: event.target.value }))} className="focus-ring w-full resize-y rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3 text-sm text-[var(--ink)]" placeholder="موضوعات تحتاج إلى مراجعة…" /></div>
          <div className="rounded-2xl border border-dashed border-[var(--line)] p-3">
            <div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-sm text-[var(--ink)]">صورة اختيارية للورقة</p><p className="text-[0.68rem] text-[var(--ink-soft)]">حد الملف الأصلي ١٥ ميغابايت؛ نضغطه محلياً إلى JPEG صغير.</p></div><label className="focus-ring inline-flex h-11 cursor-pointer items-center gap-2 rounded-xl border border-[var(--line)] px-3 text-xs text-[var(--ink)]"><ImagePlus size={15} /> اختيار صورة<input type="file" accept="image/*" className="sr-only" onChange={(event) => { void selectImage(event.target.files?.[0]); event.currentTarget.value = ''; }} /></label></div>
            {form.attachment ? <div className="mt-3 flex items-center gap-3"><img src={form.attachment.dataUrl} alt="معاينة الصورة المحلية" className="h-20 w-20 rounded-xl object-cover" /><div className="min-w-0 flex-1"><p className="truncate text-xs text-[var(--ink)]">{form.attachment.name}</p><p className="text-[0.68rem] text-[var(--ink-soft)]">{numberLabel(Math.ceil(form.attachment.sizeBytes / 1024))} كيلوبايت مضغوط</p></div><button type="button" onClick={() => setForm((value) => ({ ...value, attachment: null }))} aria-label="حذف المرفق" className="focus-ring flex h-11 w-11 items-center justify-center rounded-xl text-[var(--danger)]"><X size={16} /></button></div> : null}
          </div>
          <p className="text-[0.68rem] leading-relaxed text-[var(--ink-soft)]">تأكد من صحة الدرجة؛ لا تمنح هذه السجلات نقاطاً أو إنجازات.</p>
          <button type="submit" className="sr-only">حفظ</button>
        </form>
      </Modal>

      <Modal open={pendingDelete !== null} onClose={() => setPendingDelete(null)} title="حذف سجل العلامة؟" footer={<div className="flex gap-2"><Button block variant="danger" icon={<Trash2 size={15} />} onClick={() => void remove()}>حذف السجل</Button><Button variant="outline" onClick={() => setPendingDelete(null)}>إلغاء</Button></div>}>
        <p className="text-sm leading-relaxed text-[var(--ink-soft)]">سيُحذف السجل وصورته المحلية من هذا الجهاز. إن كان لديك نسخة احتياطية قديمة، فستظل محتفظة بالبيانات السابقة.</p>
      </Modal>
    </div>
  );
}
