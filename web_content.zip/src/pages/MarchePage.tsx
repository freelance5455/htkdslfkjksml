import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Layers, 
  Coins, 
  DollarSign, 
  Flame, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  Radio, 
  Sparkles, 
  Info,
  BellRing,
  Gauge,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  BarChart3,
  ShieldCheck,
  Check
} from 'lucide-react';
import { AssetData, AssetCategory, ActiveVoiceAlert, ThemeMode } from '../types/market';
import { AssetCard } from '../components/AssetCard';
import { sendBrowserNotification } from '../services/marketApi';

interface MarchePageProps {
  assets: AssetData[];
  onOpenAlertModal: (asset: AssetData) => void;
  onOpenDetailModal: (asset: AssetData) => void;
  onQuickVoiceAnnounce: (asset: AssetData) => void;
  activeAlerts: ActiveVoiceAlert[];
  watchlist: string[];
  onToggleWatchlist: (assetId: string) => void;
  onRefreshPrices: () => Promise<void>;
  lastSyncTime: number;
  theme: ThemeMode;
  systemNotificationsEnabled: boolean;
  onRequestNotificationPermission: () => void;
}

export const MarchePage: React.FC<MarchePageProps> = ({
  assets,
  onOpenAlertModal,
  onOpenDetailModal,
  onQuickVoiceAnnounce,
  activeAlerts,
  watchlist,
  onToggleWatchlist,
  onRefreshPrices,
  lastSyncTime,
  theme,
  systemNotificationsEnabled,
  onRequestNotificationPermission,
}) => {
  const isLight = theme === 'light';
  const [selectedCategory, setSelectedCategory] = useState<AssetCategory | 'trending'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'volume' | 'change' | 'price' | 'name'>('volume');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Top gainers, losers, and most active
  const topGainers = useMemo(() => {
    return [...assets].sort((a, b) => b.change24h - a.change24h).slice(0, 3);
  }, [assets]);

  const topLosers = useMemo(() => {
    return [...assets].sort((a, b) => a.change24h - b.change24h).slice(0, 3);
  }, [assets]);

  const mostActive = useMemo(() => {
    return [...assets].slice(0, 4);
  }, [assets]);

  // Filtered Assets
  const filteredAssets = useMemo(() => {
    return assets
      .filter((asset) => {
        if (selectedCategory === 'trending') {
          return Math.abs(asset.change24h) >= 4.0;
        }
        if (selectedCategory !== 'all' && asset.category !== selectedCategory) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          return asset.name.toLowerCase().includes(q) || asset.symbol.toLowerCase().includes(q);
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'change') return Math.abs(b.change24h) - Math.abs(a.change24h);
        if (sortBy === 'price') return b.price - a.price;
        if (sortBy === 'name') return a.symbol.localeCompare(b.symbol);
        return 0;
      });
  }, [assets, selectedCategory, searchQuery, sortBy]);

  // Macro metrics
  const btcAsset = assets.find((a) => a.symbol === 'BTC');
  const totalMarketCapEst = '$3.28T';
  const totalVolumeEst = '$148.5B';
  const btcDominanceEst = '57.8%';
  const fearGreedScore = 74;

  return (
    <div className="space-y-6 pb-20">
      
      {/* REAL MARKET DASHBOARD (Replaces old hero banner) */}
      <div className={`rounded-3xl border shadow-xl p-5 sm:p-6 transition-colors ${
        isLight
          ? 'bg-white border-slate-200/90 shadow-slate-200/50'
          : 'bg-slate-900/90 border-slate-800 shadow-black/40'
      }`}>
        
        {/* Top Header of Dashboard */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
              </span>
              <h1 className={`text-xl sm:text-2xl font-extrabold font-['Chakra_Petch'] tracking-tight ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                TRADING FLOW ALERTS &bull; MARCHÉ EN TEMPS RÉEL
              </h1>
            </div>
            <p className={`text-xs mt-0.5 font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Cotations institutionnelles &bull; {assets.length} actifs surveillés &bull; Synchro : {new Date(lastSyncTime).toLocaleTimeString()}
            </p>
          </div>

          {/* System Notification Permission Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={onRequestNotificationPermission}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-mono font-semibold transition-all cursor-pointer ${
                systemNotificationsEnabled
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-600 dark:text-emerald-400'
                  : 'bg-amber-500/15 border-amber-500/40 text-amber-600 dark:text-amber-400 hover:bg-amber-500/25'
              }`}
              title="Activer les notifications système de bureau"
            >
              <BellRing className={`w-3.5 h-3.5 ${systemNotificationsEnabled ? 'text-emerald-500' : 'text-amber-500 animate-pulse'}`} />
              <span>
                {systemNotificationsEnabled ? 'Notifications Système : ON' : 'Activer Notifications Système'}
              </span>
            </button>

            <button
              onClick={async () => {
                setIsRefreshing(true);
                await onRefreshPrices();
                setTimeout(() => setIsRefreshing(false), 500);
              }}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                isLight ? 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700' : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
              }`}
              title="Actualiser les cours"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-amber-500' : ''}`} />
            </button>
          </div>
        </div>

        {/* Global Macro Ticker Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-4 border-b border-slate-200 dark:border-slate-800 font-mono text-xs">
          <div className={`p-3 rounded-2xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={`text-[10px] uppercase block font-semibold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              CAPITALISATION GLOBALE
            </span>
            <div className={`text-base font-bold mt-0.5 ${isLight ? 'text-slate-900' : 'text-white'}`}>
              {totalMarketCapEst}
            </div>
            <span className="text-[10px] text-emerald-500 font-bold">+3.4% 24h</span>
          </div>

          <div className={`p-3 rounded-2xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={`text-[10px] uppercase block font-semibold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              VOLUME ÉCHANGÉ 24H
            </span>
            <div className={`text-base font-bold mt-0.5 ${isLight ? 'text-slate-900' : 'text-white'}`}>
              {totalVolumeEst}
            </div>
            <span className="text-[10px] text-slate-400">Fort volume institutionnel</span>
          </div>

          <div className={`p-3 rounded-2xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={`text-[10px] uppercase block font-semibold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              DOMINANCE BITCOIN
            </span>
            <div className="text-base font-bold text-amber-500 mt-0.5">
              {btcDominanceEst}
            </div>
            <span className="text-[10px] text-slate-400">ETH: 14.2%</span>
          </div>

          <div className={`p-3 rounded-2xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={`text-[10px] uppercase block font-semibold ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              INDICE PEUR & CUPIDITÉ
            </span>
            <div className="text-base font-bold text-emerald-500 mt-0.5 flex items-center gap-1.5">
              <Gauge className="w-4 h-4" />
              <span>{fearGreedScore}/100</span>
            </div>
            <span className="text-[10px] text-emerald-500 font-semibold">CUPIDITÉ ÉLEVÉE</span>
          </div>
        </div>

        {/* Real-time Mover Leaders Strip */}
        <div className="pt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Top Gainers */}
          <div className={`p-3.5 rounded-2xl border ${isLight ? 'bg-slate-50/70 border-slate-200' : 'bg-slate-950/50 border-slate-800'}`}>
            <div className="flex items-center justify-between text-xs font-mono mb-2.5">
              <span className="font-bold flex items-center gap-1.5 text-emerald-500">
                <TrendingUp className="w-4 h-4" />
                <span>TOP HAUSSES DU JOUR</span>
              </span>
              <span className="text-[10px] text-slate-400">24H</span>
            </div>

            <div className="space-y-1.5">
              {topGainers.map((g) => (
                <div
                  key={g.id}
                  onClick={() => onOpenDetailModal(g)}
                  className={`flex items-center justify-between p-2 rounded-xl transition-all cursor-pointer ${
                    isLight ? 'hover:bg-white' : 'hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`font-bold font-mono text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      {g.symbol}
                    </span>
                    <span className="text-[11px] text-slate-400 truncate max-w-[90px]">{g.name}</span>
                  </div>
                  <div className="text-right font-mono">
                    <span className={`text-xs font-bold block ${isLight ? 'text-slate-800' : 'text-white'}`}>
                      ${g.price.toLocaleString(undefined, { maximumFractionDigits: g.price < 1 ? 4 : 2 })}
                    </span>
                    <span className="text-[11px] font-bold text-emerald-500">
                      +{g.change24h}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Losers / Dips */}
          <div className={`p-3.5 rounded-2xl border ${isLight ? 'bg-slate-50/70 border-slate-200' : 'bg-slate-950/50 border-slate-800'}`}>
            <div className="flex items-center justify-between text-xs font-mono mb-2.5">
              <span className="font-bold flex items-center gap-1.5 text-rose-500">
                <TrendingDown className="w-4 h-4" />
                <span>REPLIS / ACCUMULATION</span>
              </span>
              <span className="text-[10px] text-slate-400">24H</span>
            </div>

            <div className="space-y-1.5">
              {topLosers.map((l) => (
                <div
                  key={l.id}
                  onClick={() => onOpenDetailModal(l)}
                  className={`flex items-center justify-between p-2 rounded-xl transition-all cursor-pointer ${
                    isLight ? 'hover:bg-white' : 'hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`font-bold font-mono text-xs ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      {l.symbol}
                    </span>
                    <span className="text-[11px] text-slate-400 truncate max-w-[90px]">{l.name}</span>
                  </div>
                  <div className="text-right font-mono">
                    <span className={`text-xs font-bold block ${isLight ? 'text-slate-800' : 'text-white'}`}>
                      ${l.price.toLocaleString(undefined, { maximumFractionDigits: l.price < 1 ? 4 : 2 })}
                    </span>
                    <span className="text-[11px] font-bold text-rose-500">
                      {l.change24h}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sector / Layer Performance Blocks */}
          <div className={`p-3.5 rounded-2xl border ${isLight ? 'bg-slate-50/70 border-slate-200' : 'bg-slate-950/50 border-slate-800'}`}>
            <div className="flex items-center justify-between text-xs font-mono mb-2.5">
              <span className="font-bold flex items-center gap-1.5 text-purple-500">
                <Activity className="w-4 h-4" />
                <span>PERFORMANCE DES SECTEURS</span>
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              {[
                { name: 'Layer 1 & Cryptos Majeures', change: '+5.2%', isPos: true },
                { name: 'Meme Coins & Haute Volatilité', change: '+10.8%', isPos: true },
                { name: 'Matières Premières & Or', change: '+0.85%', isPos: true },
                { name: 'Big Tech & IA (NVDA/AAPL)', change: '+1.6%', isPos: true },
              ].map((sec) => (
                <div key={sec.name} className="flex items-center justify-between py-1 border-b border-slate-200/50 dark:border-slate-800/50 last:border-none">
                  <span className={`truncate max-w-[170px] ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                    {sec.name}
                  </span>
                  <span className={`font-bold ${sec.isPos ? 'text-emerald-500' : 'text-rose-500'}`}>
                    {sec.change}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Filter, Search & Categories Controls */}
      <div className={`flex flex-col md:flex-row md:items-center justify-between gap-4 p-3 sm:p-4 rounded-2xl border backdrop-blur-md ${
        isLight 
          ? 'bg-white border-slate-200 shadow-sm' 
          : 'bg-slate-900/60 border-slate-800/80'
      }`}>
        {/* Categories Selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {[
            { id: 'all', label: `Tous (${assets.length})`, icon: Layers },
            { id: 'trending', label: '🔥 Fort Mouvement', icon: Zap },
            { id: 'crypto', label: 'Cryptos (Top 20)', icon: Coins },
            { id: 'commodity', label: 'Matières 1ères', icon: Flame },
            { id: 'forex', label: 'Forex Devises', icon: DollarSign },
            { id: 'stock', label: 'Actions Tech', icon: TrendingUp },
          ].map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as any)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : isLight
                    ? 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                    : 'bg-slate-950/70 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search Input & Sort Menu */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex-1 md:w-56">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher SUI, BTC, PEPE..."
              className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs font-mono focus:outline-none focus:border-amber-500 border ${
                isLight 
                  ? 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400' 
                  : 'bg-slate-950 border-slate-800 text-white placeholder-slate-500'
              }`}
            />
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className={`px-3 py-2 rounded-xl text-xs font-mono focus:outline-none focus:border-amber-500 cursor-pointer border ${
              isLight 
                ? 'bg-slate-50 border-slate-200 text-slate-700' 
                : 'bg-slate-950 border-slate-800 text-slate-300'
            }`}
          >
            <option value="volume">Trier: Volume</option>
            <option value="change">Trier: Variation 24h</option>
            <option value="price">Trier: Prix</option>
            <option value="name">Trier: Nom</option>
          </select>
        </div>
      </div>

      {/* Grid of Assets */}
      {filteredAssets.length === 0 ? (
        <div className={`py-20 text-center space-y-3 rounded-3xl border ${
          isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-slate-900/30 border-slate-800/80 text-slate-400'
        }`}>
          <Info className="w-10 h-10 mx-auto text-slate-400" />
          <h3 className={`text-base font-semibold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
            Aucun actif ne correspond à votre filtre
          </h3>
          <p className="text-xs">Essayez un autre mot-clé ou réinitialisez la catégorie.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredAssets.map((asset) => {
            const hasActiveAlert = activeAlerts.some(
              (a) => (a.assetId === asset.id || a.assetSymbol === asset.symbol) && a.enabled
            );
            const isFav = watchlist.includes(asset.id);
            return (
              <AssetCard
                key={asset.id}
                asset={asset}
                onOpenAlertModal={onOpenAlertModal}
                onOpenDetailModal={onOpenDetailModal}
                onQuickVoiceAnnounce={onQuickVoiceAnnounce}
                hasActiveAlerts={hasActiveAlert}
                isFavorite={isFav}
                onToggleFavorite={onToggleWatchlist}
                theme={theme}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};
