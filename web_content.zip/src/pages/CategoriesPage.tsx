import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getCategories, getFormulas } from '../firebase/services';
import { Category, Formula } from '../types';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import {
  Sigma,
  Atom,
  FlaskConical,
  Cpu,
  Rocket,
  Zap,
  Bot,
  BarChart2,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const categoryIconMap: Record<string, React.ReactNode> = {
  mathematics: <Sigma className="w-6 h-6 text-[#D65A1F]" />,
  physics: <Atom className="w-6 h-6 text-[#D65A1F]" />,
  chemistry: <FlaskConical className="w-6 h-6 text-[#D65A1F]" />,
  engineering: <Cpu className="w-6 h-6 text-[#D65A1F]" />,
  aerospace: <Rocket className="w-6 h-6 text-[#D65A1F]" />,
  electronics: <Zap className="w-6 h-6 text-[#D65A1F]" />,
  robotics: <Bot className="w-6 h-6 text-[#D65A1F]" />,
  statistics: <BarChart2 className="w-6 h-6 text-[#D65A1F]" />
};

export const CategoriesPage: React.FC = () => {
  const { playSound } = useApp();
  const [categories, setCategories] = useState<Category[]>([]);
  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [cats, forms] = await Promise.all([getCategories(), getFormulas()]);
        setCategories(cats);
        setFormulas(forms);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div className="space-y-8 pb-16">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Layers className="w-5 h-5 text-[#D65A1F]" />
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            Academic Disciplines & Categories
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-[#A9A39C] max-w-2xl">
          Browse formulas structured across scientific principles, engineering methods, and applied mathematics.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {categories.map((cat) => {
            const count = formulas.filter(
              (f) => f.category.toLowerCase() === cat.slug.toLowerCase()
            ).length;

            return (
              <div
                key={cat.id}
                className="group flex flex-col justify-between rounded-3xl bg-[#1C1C1C] border border-[#303030] hover:border-[#D65A1F]/60 p-6 transition-all duration-200 shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#232323] border border-[#303030] flex items-center justify-center group-hover:scale-105 transition-transform">
                      {categoryIconMap[cat.slug] || <Sigma className="w-6 h-6 text-[#D65A1F]" />}
                    </div>
                    <span className="text-xs font-mono font-semibold text-[#D65A1F] bg-[#232323] border border-[#303030] px-2.5 py-1 rounded-xl">
                      {count} formulas
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-[#F5F2ED] mb-2 group-hover:text-[#D65A1F] transition-colors">
                    {cat.name}
                  </h3>

                  <p className="text-xs text-[#A9A39C] leading-relaxed mb-4">
                    {cat.description}
                  </p>

                  {/* Subcategories tags */}
                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {cat.subcategories.map((sub) => (
                      <span
                        key={sub}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#151515] border border-[#303030] text-[#A9A39C]"
                      >
                        {sub}
                      </span>
                    ))}
                  </div>
                </div>

                <Link
                  to={`/category/${cat.slug}`}
                  onClick={() => playSound('tab')}
                  className="inline-flex items-center justify-between w-full px-4 py-2.5 rounded-xl bg-[#232323] hover:bg-[#D65A1F] text-[#F5F2ED] text-xs font-semibold border border-[#303030] hover:border-[#D65A1F] transition-colors group/btn"
                >
                  <span>Explore {cat.name}</span>
                  <ArrowRight className="w-4 h-4 text-[#D65A1F] group-hover/btn:text-[#F5F2ED]" />
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
