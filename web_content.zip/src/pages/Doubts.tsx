import { useEffect, useState } from 'react';
import { BookOpen, MessageCircleQuestion, Send, Sparkles } from 'lucide-react';
import type { ResourceRow } from '@shared/types';
import { chaptersFor } from '@shared/syllabus';
import { api, ApiError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { cn, formatDateTime } from '../lib/utils';
import { Badge, Banner, Button, Card, EmptyState, Field, Select, SetupCard, Textarea, useToast } from '../components/ui';
import { Markdown } from '../components/Markdown';

interface Doubt {
  id: number;
  question: string;
  subject: string | null;
  answer: string;
  citations: { resourceName: string; page: number }[];
  createdAt: string;
}

export default function Doubts() {
  const { profile, aiEnabled } = useAuth();
  const { push } = useToast();
  const [question, setQuestion] = useState('');
  const [subject, setSubject] = useState(profile?.subjects[0] ?? '');
  const [chapter, setChapter] = useState('');
  const [level, setLevel] = useState<'beginner' | 'exam' | 'advanced'>('exam');
  const [resources, setResources] = useState<ResourceRow[]>([]);
  const [selected, setSelected] = useState<number[]>([]);
  const [history, setHistory] = useState<Doubt[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState<Doubt | null>(null);

  useEffect(() => {
    void api.get<{ resources: ResourceRow[] }>('/api/resources')
      .then((d) => setResources(d.resources.filter((r) => r.status === 'ready')))
      .catch(() => undefined);
    void api.get<{ doubts: Doubt[] }>('/api/doubts')
      .then((d) => { setHistory(d.doubts); setOpen(d.doubts[0] ?? null); })
      .catch(() => undefined);
  }, []);

  const submit = async () => {
    if (question.trim().length < 5) {
      setError('Write your doubt in a little more detail (at least a few words).');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const data = await api.post<{ doubt: Doubt }>('/api/doubts', {
        question: question.trim(), subject, chapter, level, resourceIds: selected,
      });
      setHistory((prev) => [data.doubt, ...prev]);
      setOpen(data.doubt);
      setQuestion('');
      push('Doubt solved — read the concept before the answer.', 'ok');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not solve this doubt.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_420px]">
      <div className="space-y-3">
        <Card>
          <h2 className="font-display text-base font-bold text-ink">Ask a doubt</h2>
          <p className="mt-0.5 text-sm text-muted">Paste a question, a derivation you are stuck on, or describe a diagram. You get the concept first, then the full solution.</p>
          {!aiEnabled && <div className="mt-3"><SetupCard /></div>}
          {error && <div className="mt-3"><Banner tone="bad">{error}</Banner></div>}

          <div className="mt-4 space-y-3">
            <Textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g. A block of mass 2 kg is on a rough incline of 30°. Find the minimum coefficient of friction for it to stay at rest."
              className="min-h-[130px]"
            />
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Subject">
                <Select value={subject} onChange={(e) => { setSubject(e.target.value); setChapter(''); }}>
                  {profile?.subjects.map((s) => <option key={s}>{s}</option>)}
                </Select>
              </Field>
              <Field label="Chapter">
                <Select value={chapter} onChange={(e) => setChapter(e.target.value)}>
                  <option value="">Not specific</option>
                  {(profile ? chaptersFor(profile.exam, subject) : []).map((c) => <option key={c}>{c}</option>)}
                </Select>
              </Field>
              <Field label="Explanation depth">
                <Select value={level} onChange={(e) => setLevel(e.target.value as typeof level)}>
                  <option value="beginner">Beginner</option>
                  <option value="exam">Exam level</option>
                  <option value="advanced">Advanced</option>
                </Select>
              </Field>
            </div>
            {resources.length > 0 && (
              <div>
                <span className="label">Answer from my documents (optional)</span>
                <div className="flex flex-wrap gap-1.5">
                  {resources.map((r) => {
                    const active = selected.includes(r.id);
                    return (
                      <button key={r.id} onClick={() => setSelected((p) => active ? p.filter((id) => id !== r.id) : [...p, r.id])}
                        className={cn('chip max-w-[240px]', active && 'border-brand/50 bg-brand/10 text-brand')}>
                        <BookOpen size={11} /><span className="truncate">{r.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
            <Button onClick={() => void submit()} loading={busy} disabled={!aiEnabled} className="w-full sm:w-auto">
              <Send size={16} /> Solve this doubt
            </Button>
          </div>
        </Card>

        <Card>
          <h2 className="font-display text-base font-bold text-ink">Your doubts</h2>
          {history.length === 0 ? (
            <p className="mt-2 text-sm text-muted">Nothing here yet. Solved doubts are saved so you can revise them before tests.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {history.map((d) => (
                <li key={d.id}>
                  <button onClick={() => setOpen(d)} className={cn('w-full rounded-xl border px-3 py-2.5 text-left transition',
                    open?.id === d.id ? 'border-brand/40 bg-brand/10' : 'border-line bg-elevated/30 hover:border-brand/40')}>
                    <div className="line-clamp-2 text-sm text-ink">{d.question}</div>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-muted">
                      {d.subject && <Badge>{d.subject}</Badge>}
                      <span>{formatDateTime(d.createdAt)}</span>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card className="h-fit">
        <div className="mb-3 flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand/15 text-brand"><Sparkles size={16} /></span>
          <h2 className="font-display text-base font-bold text-ink">Solution</h2>
        </div>
        {open ? (
          <div className="space-y-3">
            <div className="rounded-xl border border-line bg-elevated/30 p-3 text-sm text-ink">{open.question}</div>
            <div className="max-h-[60vh] overflow-y-auto pr-1 scroll-thin">
              <Markdown content={open.answer} />
            </div>
            {open.citations.length > 0 && (
              <div className="flex flex-wrap gap-1.5 border-t border-line pt-2.5">
                {open.citations.map((c, i) => <Badge key={i} tone="brand">{c.resourceName} · p. {c.page}</Badge>)}
              </div>
            )}
          </div>
        ) : (
          <EmptyState icon={<MessageCircleQuestion size={22} />} title="No solution yet" description="Ask a doubt and the full step-by-step solution appears here." />
        )}
      </Card>
    </div>
  );
}
