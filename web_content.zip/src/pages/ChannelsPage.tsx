import React, { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import { SocialChannelsView } from "@/components/features/SocialChannelsView";
import { YouTubeFactoryDashboard } from "@/components/features/youtubeFactory/YouTubeFactoryDashboard";
import { AddChannelsTab } from "@/components/features/AddChannelsTab";
import { SyncPlatformsTab } from "@/components/features/SyncPlatformsTab";
import { ExternalVideosStudio } from "@/components/features/ExternalVideosStudio";
import { CloneEngineStudio } from "@/components/features/CloneEngineStudio";
import { Tv, Share2, Plus, RefreshCw, Video, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

type ChannelPageTab = "add-channels" | "sync-platforms" | "external-videos" | "clone-studio" | "factory" | "oauth";

const VALID_TABS: ChannelPageTab[] = ["add-channels", "sync-platforms", "external-videos", "clone-studio", "factory", "oauth"];

export default function ChannelsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const tabParam = searchParams.get("tab") as ChannelPageTab | null;

  const [activeTab, setActiveTab] = useState<ChannelPageTab>(() => {
    if (tabParam && VALID_TABS.includes(tabParam)) {
      return tabParam;
    }
    return "add-channels";
  });

  useEffect(() => {
    if (tabParam && VALID_TABS.includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, [tabParam]);

  const handleTabChange = (tab: ChannelPageTab) => {
    setActiveTab(tab);
    setSearchParams({ tab });
  };

  return (
    <AppLayout
      title="Canais & Plataformas"
      subtitle="Gerenciador Central de Canais, Vídeos Externos, Clonagem AI e Sincronização Multi-Rede"
    >
      <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
        {/* Main Tab Toggle Bar */}
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-studio-panel border border-studio-border w-fit flex-wrap">
          {/* Aba: Adicionar Canais */}
          <button
            id="tab-btn-add-channels"
            onClick={() => handleTabChange("add-channels")}
            className={cn(
              "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              activeTab === "add-channels"
                ? "bg-studio-gold text-black shadow-md"
                : "text-studio-text-dim hover:text-studio-text"
            )}
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Canais</span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-black/20 text-black">
              CRIAR
            </span>
          </button>

          {/* Aba: Adicionar Plataformas e Sincronizar */}
          <button
            id="tab-btn-sync-platforms"
            onClick={() => handleTabChange("sync-platforms")}
            className={cn(
              "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              activeTab === "sync-platforms"
                ? "bg-studio-blue text-white shadow-md"
                : "text-studio-text-dim hover:text-studio-text"
            )}
          >
            <RefreshCw className={cn("w-4 h-4", activeTab === "sync-platforms" && "animate-spin-once")} />
            <span>Adicionar Plataformas e Sincronizar</span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-white/20 text-white">
              SYNC
            </span>
          </button>

          {/* Aba: Adicionar Vídeos Externos */}
          <button
            id="tab-btn-external-videos"
            onClick={() => handleTabChange("external-videos")}
            className={cn(
              "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              activeTab === "external-videos"
                ? "bg-emerald-600 text-white shadow-md"
                : "text-studio-text-dim hover:text-studio-text"
            )}
          >
            <Video className="w-4 h-4" />
            <span>Adicionar Vídeos Externos</span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-white/20 text-white">
              GALERIA & WEB
            </span>
          </button>

          {/* Aba: Clonar canal, vídeos, música, plataformas */}
          <button
            id="tab-btn-clone-studio"
            onClick={() => handleTabChange("clone-studio")}
            className={cn(
              "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              activeTab === "clone-studio"
                ? "bg-gradient-to-r from-amber-500 to-studio-gold text-black shadow-md font-black"
                : "text-studio-text-dim hover:text-studio-text"
            )}
          >
            <Copy className="w-4 h-4" />
            <span>Clonar Canal, Vídeos & Música</span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-black/20 text-black">
              AI CLONE
            </span>
          </button>

          {/* Aba: YouTube Channel Factory */}
          <button
            id="tab-btn-yt-factory"
            onClick={() => handleTabChange("factory")}
            className={cn(
              "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              activeTab === "factory"
                ? "bg-studio-surface text-studio-text border border-studio-gold shadow-md"
                : "text-studio-text-dim hover:text-studio-text"
            )}
          >
            <Tv className="w-4 h-4" />
            <span>YouTube Channel Factory</span>
          </button>

          {/* Aba: Contas & Redes Sociais OAuth */}
          <button
            id="tab-btn-oauth"
            onClick={() => handleTabChange("oauth")}
            className={cn(
              "px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
              activeTab === "oauth"
                ? "bg-studio-surface text-studio-text border border-studio-blue shadow-md"
                : "text-studio-text-dim hover:text-studio-text"
            )}
          >
            <Share2 className="w-4 h-4" />
            <span>Contas OAuth</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === "add-channels" && <AddChannelsTab />}
        {activeTab === "sync-platforms" && <SyncPlatformsTab />}
        {activeTab === "external-videos" && <ExternalVideosStudio />}
        {activeTab === "clone-studio" && <CloneEngineStudio />}
        {activeTab === "factory" && <YouTubeFactoryDashboard />}
        {activeTab === "oauth" && (
          <div className="max-w-5xl">
            <SocialChannelsView />
          </div>
        )}
      </div>
    </AppLayout>
  );
}

