import { useState } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { FileText, FolderOpen, GraduationCap, ScrollText, Sparkles } from 'lucide-react';
import { getSubject, teacherCovers } from '../data/content';
import { useProfile } from '../hooks/useProfile';
import { useStored, KEYS } from '../services/storage';
import { subjectProgress } from '../services/progress';
import { PageHeader } from '../components/layout/PageHeader';
import { SubjectGlyph, TeacherAvatar } from '../components/content/SubjectBits';
import { UnitAccordion } from '../components/content/UnitAccordion';
import { ProgressBar, SectionHeader } from '../components/ui/Card';
import { Tabs } from '../components/ui/Tabs';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { cn } from '../utils/format';

export default function SubjectDetail() {
  const { subjectId = '' } = useParams();
  const subject = getSubject(subjectId);
  const { profile, selectTeacher } = useProfile();
  useStored(KEYS.progress, {});
  const [tab, setTab] = useState('lessons');

  if (!subject) return <Navigate to="/subjects" replace />;

  const progress = subjectProgress(subject);
  const activeTeacherId = profile.teacherBySubject[subject.id] ?? subject.teachers[0]?.id ?? '';
  const activeTeacher = subject.teachers.find((t) => t.id === activeTeacherId) ?? subject.teachers[0];
  const lessons = subject.units.flatMap((u) => u.lessons);
  const attachments = lessons.flatMap((l) => l.attachments);
  const teacherCards = [...subject.teachers].sort(
    (left, right) => Number(Boolean(right.verifiedVideos?.length)) - Number(Boolean(left.verifiedVideos?.length)),
  );

  return (
    <div>
      <PageHeader
        title={subject.name}
        subtitle={subject.description}
        back="/subjects"
        eyebrow={`${subject.units.length} وحدات · ${lessons.length} درساً`}
      />

      {/* بطاقة المادة */}
      <div className="card mb-4 p-4" style={{ borderColor: `${subject.color}33` }}>
        <div className="flex items-center gap-3">
          <SubjectGlyph subject={subject} size="lg" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <p className="text-[0.72rem] text-[var(--ink-soft)]">نسبة الإنجاز</p>
              <span className="font-display text-base text-[var(--ink)]">{progress}%</span>
            </div>
            <ProgressBar value={progress} color={subject.color} className="mt-1" />
            <div className="mt-2 flex flex-wrap gap-1.5">
              <Badge tone="neutral">{lessons.length} درساً</Badge>
              <Badge tone="neutral">{subject.teachers.length} مدرّسين</Badge>
              <Badge tone="gold">وزن {subject.weight}</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* اختيار المدرّس */}
      <section className="mb-4">
        <SectionHeader title="اختر شرح المدرّس" hint="يظهر الفيديو البديل عند توفر مقطع مرتبط بالدرس؛ افتح المقاطع الموثقة للمشاهدة داخل التطبيق." />
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {teacherCards.map((teacher) => {
            const active = teacher.id === activeTeacher?.id;
            const linkedLessonCount = subject.units.reduce(
              (count, unit) => count + unit.lessons.filter((lesson) => teacherCovers(lesson, teacher.id)).length,
              0,
            );
            const canSelectTeacher = linkedLessonCount > 0;
            return (
              <div
                key={teacher.id}
                className={cn(
                  'flex w-56 shrink-0 flex-col gap-2 rounded-2xl border p-3 transition-colors',
                  active ? 'border-[var(--brand)] bg-[var(--surface)]' : 'border-[var(--line)] bg-[var(--surface)]',
                )}
              >
                <div className="flex items-center gap-2">
                  <TeacherAvatar teacher={teacher} size={38} />
                  <div className="min-w-0">
                    <p className="truncate text-[0.78rem] font-medium text-[var(--ink)]">{teacher.name}</p>
                    <p className="truncate text-[0.62rem] text-[var(--ink-soft)]">
                      {teacher.channelLabel ?? (teacher.years ? `${teacher.years} سنة خبرة · ملف مثال` : 'ملف توضيحي تجريبي')}
                    </p>
                  </div>
                </div>
                <p className="line-clamp-2 text-[0.66rem] leading-relaxed text-[var(--ink-soft)]">{teacher.headline}</p>
                <div className="mt-auto flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => selectTeacher(subject.id, teacher.id)}
                    disabled={!canSelectTeacher}
                    aria-label={canSelectTeacher ? `اختيار ${teacher.name}` : `لا توجد دروس مرتبطة ب${teacher.name} بعد`}
                    className={cn(
                      'focus-ring min-h-11 flex-1 rounded-full px-2 text-[0.65rem] font-medium disabled:cursor-not-allowed disabled:opacity-60',
                      active ? 'bg-[var(--brand)] text-[var(--brand-ink)]' : 'bg-[var(--surface-2)] text-[var(--ink)]',
                    )}
                  >
                    {active ? 'مختار ✓' : canSelectTeacher ? 'اختيار' : 'لا درس مرتبط'}
                  </button>
                  <Link
                    to={`/subject/${subject.id}/teacher/${teacher.id}`}
                    className="focus-ring flex min-h-11 items-center rounded-full border border-[var(--line)] px-2 text-[0.66rem] text-[var(--ink-soft)]"
                  >
                    {teacher.verifiedVideos?.length ? 'المقاطع' : 'الملف'}
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <Tabs
        className="mb-3"
        value={tab}
        onChange={setTab}
        items={[
          { id: 'lessons', label: 'الدروس' },
          { id: 'files', label: 'الملفات', badge: attachments.length },
          { id: 'papers', label: 'الدورات السابقة', badge: subject.pastPapers.length },
          { id: 'summaries', label: 'الملخصات' },
        ]}
      />

      {tab === 'lessons' ? (
        <div className="space-y-2.5">
          {subject.units.map((unit, i) => (
            <UnitAccordion key={unit.id} unit={unit} subject={subject} defaultOpen={i === 0} />
          ))}
          <p className="pt-1 text-center text-[0.68rem] text-[var(--ink-soft)]">
            يشرح هذه الوحدات: {activeTeacher?.name}
          </p>
        </div>
      ) : null}

      {tab === 'files' ? (
        <div className="space-y-2">
          {attachments.length === 0 ? (
            <EmptyState icon={<FolderOpen size={18} />} title="لا ملفات بعد" description="ستظهر ملفات الدروس هنا." />
          ) : (
            attachments.map((file) => (
              <Link
                key={file.id}
                to={`/library?file=${file.id}`}
                className="focus-ring card flex items-center gap-3 p-3"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#fdece2] text-[#a63a12] dark:bg-[#3a1c12] dark:text-[#f5a67f]">
                  <FileText size={16} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[0.82rem] text-[var(--ink)]">{file.title}</span>
                  <span className="text-[0.65rem] text-[var(--ink-soft)]">
                    PDF · {file.size}
                    {file.pages ? ` · ${file.pages} صفحات` : ''}
                  </span>
                </span>
              </Link>
            ))
          )}
        </div>
      ) : null}

      {tab === 'papers' ? (
        <div className="space-y-2">
          {subject.pastPapers.map((paper) => (
            <div key={paper.id} className="card p-3">
              <div className="flex items-center gap-2">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--ink)]">
                  <ScrollText size={16} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.82rem] text-[var(--ink)]">{paper.title}</p>
                  <p className="text-[0.65rem] text-[var(--ink-soft)]">دورة {paper.year} · نموذج وحل</p>
                </div>
              </div>
              <div className="mt-2 flex gap-2">
                <Link
                  to={`/library?file=${paper.paper.id}`}
                  className="focus-ring flex h-9 flex-1 items-center justify-center rounded-full bg-[var(--brand)] text-[0.7rem] text-[var(--brand-ink)]"
                >
                  النموذج
                </Link>
                {paper.solution ? (
                  <Link
                    to={`/library?file=${paper.solution.id}`}
                    className="focus-ring flex h-9 flex-1 items-center justify-center rounded-full border border-[var(--line)] text-[0.7rem] text-[var(--ink)]"
                  >
                    الحل
                  </Link>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      ) : null}

      {tab === 'summaries' ? (
        <div className="space-y-2">
          <SectionHeader title="مراجعات سريعة" hint="قبل الحصة أو قبل النوم" />
          {subject.quickReviews.map((item) => (
            <Link key={item.id} to={`/library?file=${item.id}`} className="focus-ring card flex items-center gap-3 p-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]">
                <Sparkles size={16} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.82rem] text-[var(--ink)]">{item.title}</span>
                <span className="text-[0.65rem] text-[var(--ink-soft)]">PDF · {item.size}</span>
              </span>
            </Link>
          ))}
          <SectionHeader className="pt-2" title="قوانين وملخصات" />
          {subject.formulas.map((item) => (
            <Link key={item.id} to={`/library?file=${item.id}`} className="focus-ring card flex items-center gap-3 p-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--ink)]">
                <GraduationCap size={16} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.82rem] text-[var(--ink)]">{item.title}</span>
                <span className="text-[0.65rem] text-[var(--ink-soft)]">PDF · {item.size}</span>
              </span>
            </Link>
          ))}
        </div>
      ) : null}
    </div>
  );
}
