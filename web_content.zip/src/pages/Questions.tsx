import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  Check,
  ChevronDown,
  Clock3,
  Copy,
  GripVertical,
  Image as ImageIcon,
  Info,
  ListChecks,
  Music2,
  Plus,
  Trash2,
  Upload,
  Video,
} from "lucide-react";
import type { Question, ViewKey } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { newEmptyQuestion, uid, moveItem, formatDuration, sanitizeFilename } from "@/data/defaults";
import { expectedAudioName, downloadBlob } from "@/lib/media";
import { buildTimeline } from "@/lib/timeline";
import { MediaPicker } from "@/components/MediaPicker";
import { SceneCanvas } from "@/components/PreviewSurface";
import { ImportQuestionsDialog } from "@/components/ImportQuestionsDialog";
import { Button, ConfirmDialog, Field, Input, SectionHeader, Textarea } from "@/components/ui";
import { cn } from "@/utils/cn";

const LETTERS = ["أ", "ب", "ج", "د"];

export function QuestionsPage({ onNavigate, importSignal }: { onNavigate: (view: ViewKey) => void; importSignal: number }) {
  const { project, updateProject, toast } = useStudio();
  const [expanded, setExpanded] = useState<string | null>(project.questions[0]?.id ?? null);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Question | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const lastSignal = useRef(0);
  const timeline = buildTimeline(project);
  const combined = project.timing.audioMode === "combined";

  useEffect(() => {
    if (importSignal > 0 && importSignal !== lastSignal.current) {
      lastSignal.current = importSignal;
      setImportOpen(true);
    }
  }, [importSignal]);

  const patchQuestion = (id: string, patch: Partial<Question>, touchSample = true) => {
    updateProject((current) => ({
      ...current,
      isSample: touchSample ? false : current.isSample,
      questions: current.questions.map((question) => (question.id === id ? { ...question, ...patch } : question)),
    }));
  };

  const addQuestion = () => {
    const question = newEmptyQuestion(project.timing.defaultThinkSec);
    updateProject((current) => ({ ...current, isSample: false, questions: [...current.questions, question] }));
    setExpanded(question.id);
    toast("أُضيف سؤال جديد. املأ النص والخيارات وحدّد الإجابة الصحيحة.", "success");
    window.setTimeout(() => document.getElementById(`question-${question.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
  };

  const duplicate = (question: Question) => {
    const index = project.questions.findIndex((entry) => entry.id === question.id);
    const copy: Question = { ...question, id: uid("q") };
    updateProject((current) => {
      const questions = [...current.questions];
      questions.splice(index + 1, 0, copy);
      return { ...current, isSample: false, questions };
    });
    setExpanded(copy.id);
    toast("نُسخ السؤال مع كامل إعداداته وملفاته. عدّل النسخة حسب الحاجة.", "success");
  };

  const move = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= project.questions.length) return;
    updateProject((current) => ({ ...current, questions: moveItem(current.questions, index, target) }));
  };

  const requestDelete = (question: Question) => {
    if (project.questions.length <= 1) {
      toast("لا يمكن حذف السؤال الأخير. أضف سؤالًا آخر أولًا أو ابدأ مشروعًا جديدًا.", "warning");
      return;
    }
    setDeleteTarget(question);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    const id = deleteTarget.id;
    updateProject((current) => ({ ...current, questions: current.questions.filter((question) => question.id !== id) }));
    setDeleteTarget(null);
    setPreviewId((value) => (value === id ? null : value));
    toast("حُذف السؤال من المشروع. ملفات الوسائط المرتبطة ما زالت محفوظة في مكتبة المشروع.", "info");
  };

  const downloadTemplate = () => {
    const template = {
      instructions: "ارفع ملفات q01_question.mp3 وq01_options.mp3 وq01_answer.mp3. correct من 0 إلى 3.",
      questions: project.questions.map((question, index) => ({
        question: question.question || `السؤال ${index + 1}`,
        options: question.options,
        correct: Math.max(0, question.correct),
        thinkingSec: question.thinkSec,
        revealHoldMs: question.revealHoldMs,
        question_audio: expectedAudioName(index, "question"),
        options_audio: expectedAudioName(index, "options"),
        answer_audio: expectedAudioName(index, "answer"),
      })),
    };
    downloadBlob(new Blob([JSON.stringify(template, null, 2)], { type: "application/json" }), `${sanitizeFilename(project.name, "quiz")}-questions.json`);
    toast("نُزّل ملف JSON بأسئلة المشروع الحالية وأسماء الملفات المقترحة.", "success");
  };

  const missingAudioCount = project.questions.filter((question) =>
    combined ? !question.combinedAudioId : !question.questionAudioId || !question.optionsAudioId,
  ).length;
  const needsCorrect = project.questions.filter((question) => question.correct < 0 || question.correct > 3).length;

  return (
    <div>
      <SectionHeader
        icon={<ListChecks size={18} />}
        eyebrow="بناء المحتوى"
        title="الأسئلة والأجوبة"
        description="أضف أي عدد من الأسئلة، رتّبها، اربط الأصوات، وحدّد إجابة صحيحة واحدة لكل سؤال. لا يسمح التصدير بأسئلة ناقصة."
        actions={
          <>
            <Button variant="ghost" onClick={downloadTemplate}><Upload size={14} /> نموذج JSON</Button>
            <Button variant="ghost" onClick={() => setImportOpen(true)}><Upload size={14} /> استيراد الأسئلة</Button>
            <Button variant="primary" onClick={addQuestion}><Plus size={15} /> سؤال جديد</Button>
          </>
        }
      />

      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        <div className="panel flex items-center justify-between px-3.5 py-2.5">
          <span className="text-[11px] text-[#9898a2]">إجمالي الأسئلة</span>
          <span className="font-display text-[15px] font-bold text-white">{project.questions.length}</span>
        </div>
        <button type="button" onClick={() => onNavigate("audio")} className={cn("panel flex items-center justify-between px-3.5 py-2.5 text-right transition hover:border-[#d9b65a]/30", missingAudioCount && "border-[#d9b65a]/25")}>
          <span className="flex items-center gap-1.5 text-[11px] text-[#9898a2]"><Music2 size={12} /> أسئلة بلا صوت مكتمل</span>
          <span className={cn("font-display text-[15px] font-bold", missingAudioCount ? "text-[#e7cf94]" : "text-[#7ce1a9]")}>{missingAudioCount}</span>
        </button>
        <div className={cn("panel flex items-center justify-between px-3.5 py-2.5", needsCorrect && "border-red-400/25")}>
          <span className="flex items-center gap-1.5 text-[11px] text-[#9898a2]"><Info size={12} /> تحتاج تحديد إجابة</span>
          <span className={cn("font-display text-[15px] font-bold", needsCorrect ? "text-red-300" : "text-[#7ce1a9]")}>{needsCorrect}</span>
        </div>
      </div>

      <div className="mb-4 flex flex-col gap-2 rounded-xl border border-white/[0.07] bg-white/[0.018] px-3.5 py-2.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-2 text-[10px] leading-5 text-[#8e8e98]">
          <Upload size={13} className="mt-0.5 shrink-0 text-[#b7a167]" />
          <span>للاستيراد الجماعي استخدم: <span dir="ltr" className="text-[#d9c187]">q01_question.mp3 · q01_options.mp3 · q01_answer.mp3 · q01.jpg</span></span>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-[#6f6f79]">
          <Clock3 size={12} /> المدة بعد اكتمال الصوت: {formatDuration(timeline.totalDuration)} — تُحسب من مدة كل ملف فعليًا
        </div>
      </div>

      <div className="space-y-3">
        {project.questions.map((question, index) => {
          const open = expanded === question.id;
          const textOk = Boolean(question.question.trim());
          const optionsOk = question.options.every((option) => option.trim());
          const correctOk = question.correct >= 0 && question.correct < 4;
          const questionAudioOk = combined ? Boolean(question.combinedAudioId) : Boolean(question.questionAudioId);
          const optionsAudioOk = combined ? Boolean(question.combinedAudioId) : Boolean(question.optionsAudioId);
          const complete = textOk && optionsOk && correctOk;
          return (
            <article key={question.id} id={`question-${question.id}`} className={cn("panel overflow-hidden transition", open && "border-white/[0.14]")}>
              <div className="flex items-start gap-2.5 p-3 sm:items-center sm:p-3.5">
                <GripVertical size={15} className="mt-1.5 hidden shrink-0 text-[#4f4f58] sm:block" />
                <button
                  type="button"
                  onClick={() => setExpanded(open ? null : question.id)}
                  className="flex min-w-0 flex-1 items-start gap-3 text-right sm:items-center"
                  aria-expanded={open}
                >
                  <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border font-display text-[12px] font-bold", complete ? "border-[#57dc96]/25 bg-[#57dc96]/[0.07] text-[#8cebb5]" : "border-[#d9b65a]/20 bg-[#d9b65a]/[0.06] text-[#e7cf94]")}>
                    {index + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className={cn("truncate text-[13px] font-medium", textOk ? "text-[#f0f0f3]" : "text-[#8a8a94]")}>{question.question || "سؤال بدون نص — اضغط لإكماله"}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      <span className={cn("chip !px-1.5 !py-0.5 !text-[9px]", correctOk ? "chip-mint" : "chip-gold")}>{correctOk ? `الإجابة: ${question.options[question.correct]}` : "لم تُحدد الإجابة"}</span>
                      <span className="chip !px-1.5 !py-0.5 !text-[9px]">{question.thinkSec} ث تفكير</span>
                      <span className="hidden text-[9px] text-[#6e6e78] sm:inline">{questionAudioOk && optionsAudioOk ? "الصوت مكتمل" : "الصوت ناقص"}</span>
                    </div>
                  </div>
                  <ChevronDown size={16} className={cn("mt-1 shrink-0 text-[#74747e] transition sm:mt-0", open && "rotate-180")} />
                </button>
                <div className="flex shrink-0 flex-col items-center gap-0.5 sm:flex-row">
                  <div className="flex">
                    <button type="button" onClick={() => move(index, -1)} disabled={index === 0} className="rounded-md p-1.5 text-[#7f7f89] transition hover:bg-white/5 hover:text-white disabled:opacity-25" aria-label="تحريك لأعلى"><ArrowUp size={13} /></button>
                    <button type="button" onClick={() => move(index, 1)} disabled={index === project.questions.length - 1} className="rounded-md p-1.5 text-[#7f7f89] transition hover:bg-white/5 hover:text-white disabled:opacity-25" aria-label="تحريك لأسفل"><ArrowDown size={13} /></button>
                  </div>
                  <button type="button" onClick={() => duplicate(question)} className="rounded-md p-1.5 text-[#7f7f89] transition hover:bg-white/5 hover:text-white" aria-label="نسخ السؤال"><Copy size={13} /></button>
                  <button type="button" onClick={() => requestDelete(question)} className="rounded-md p-1.5 text-[#7f7f89] transition hover:bg-red-500/10 hover:text-red-300" aria-label="حذف السؤال"><Trash2 size={13} /></button>
                </div>
              </div>

              {open ? (
                <div className="border-t border-white/[0.07] bg-[#0c0c10]/60 p-3.5 sm:p-4">
                  <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
                    <div className="space-y-3.5">
                      <Field
                        label="نص السؤال"
                        required
                        error={!textOk ? "نص السؤال مطلوب قبل التصدير." : undefined}
                        hint="اكتب سؤالًا واضحًا ومحددًا. يدعم تشكيل الحروف وعلامات الترقيم العربية."
                      >
                        <Textarea
                          rows={2}
                          value={question.question}
                          onChange={(event) => patchQuestion(question.id, { question: event.target.value })}
                          placeholder="مثال: ما هي عاصمة المملكة العربية السعودية؟"
                        />
                      </Field>

                      <div>
                        <div className="mb-1.5 flex items-center justify-between">
                          <label className="text-[12px] font-medium text-[#b9b9c2]">الخيارات <span className="text-[#e49c76]">*</span></label>
                          <span className="text-[10px] text-[#71717b]">اختر زر «الإجابة الصحيحة» بجانب خيار واحد فقط</span>
                        </div>
                        <div className="space-y-1.5">
                          {question.options.map((option, optionIndex) => {
                            const isCorrect = question.correct === optionIndex;
                            return (
                              <div key={optionIndex} className={cn("flex items-center gap-2 rounded-xl border p-1.5 transition", isCorrect ? "border-[#57dc96]/35 bg-[#57dc96]/[0.05]" : "border-white/[0.07] bg-[#0a0a0d]")}>
                                <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border text-[11px] font-bold", isCorrect ? "border-[#57dc96]/40 bg-[#57dc96]/15 text-[#9ef0c1]" : "border-white/10 bg-white/[0.04] text-[#d6bd82]")}>{LETTERS[optionIndex]}</span>
                                <input
                                  value={option}
                                  onChange={(event) => {
                                    const options = [...question.options];
                                    options[optionIndex] = event.target.value;
                                    patchQuestion(question.id, { options });
                                  }}
                                  placeholder={`نص الخيار ${LETTERS[optionIndex]}`}
                                  className="min-w-0 flex-1 bg-transparent px-1 py-1.5 text-[12px] text-white outline-none placeholder:text-[#5b5b65]"
                                  aria-label={`الخيار ${LETTERS[optionIndex]}`}
                                />
                                <button
                                  type="button"
                                  onClick={() => patchQuestion(question.id, { correct: optionIndex })}
                                  className={cn("flex shrink-0 items-center gap-1 rounded-lg border px-2 py-1.5 text-[10px] font-medium transition", isCorrect ? "border-[#57dc96]/40 bg-[#57dc96]/15 text-[#9ef0c1]" : "border-white/10 text-[#8e8e98] hover:border-[#57dc96]/30 hover:text-[#9ef0c1]")}
                                  aria-pressed={isCorrect}
                                >
                                  {isCorrect ? <Check size={12} /> : null}
                                  <span className="hidden sm:inline">{isCorrect ? "الإجابة الصحيحة" : "حدّد كصحيحة"}</span>
                                  <span className="sm:hidden">{isCorrect ? "صحيحة" : "تحديد"}</span>
                                </button>
                              </div>
                            );
                          })}
                        </div>
                        {!correctOk ? <p className="mt-1.5 text-[11px] text-red-300">حدّد إجابة صحيحة واحدة بالضبط قبل التصدير.</p> : null}
                        {!optionsOk ? <p className="mt-1 text-[11px] text-red-300">جميع الخيارات الأربعة مطلوبة.</p> : null}
                      </div>

                      <div className="grid gap-2.5 sm:grid-cols-2">
                        <Field label="مدة التفكير (ثانية)" hint="يبدأ المؤقت بعد انتهاء صوت الخيارات.">
                          <div className="flex items-center gap-2">
                            <button type="button" onClick={() => patchQuestion(question.id, { thinkSec: Math.max(1, question.thinkSec - 1) })} className="h-9 w-9 rounded-lg border border-white/10 text-[#cfcfd7] hover:bg-white/5">−</button>
                            <input type="number" min={1} max={120} value={question.thinkSec} onChange={(event) => patchQuestion(question.id, { thinkSec: Math.max(1, Math.min(120, Number(event.target.value) || 1)) })} className="input-number text-center" aria-label="مدة التفكير بالثواني" />
                            <button type="button" onClick={() => patchQuestion(question.id, { thinkSec: Math.min(120, question.thinkSec + 1) })} className="h-9 w-9 rounded-lg border border-white/10 text-[#cfcfd7] hover:bg-white/5">+</button>
                          </div>
                        </Field>
                        <Field label="بقاء الإجابة على الشاشة (ثانية)" hint="مدة ظهور اللون الأخضر بعد التفكير.">
                          <Input
                            type="number"
                            min={1}
                            max={10}
                            step={0.1}
                            value={Math.round((question.revealHoldMs / 1000) * 10) / 10}
                            onChange={(event) => patchQuestion(question.id, { revealHoldMs: Math.max(600, Math.min(10_000, Number(event.target.value) * 1000 || 1800)) })}
                          />
                        </Field>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button variant="ghost" className="!py-2 text-[11px]" onClick={() => setPreviewId(previewId === question.id ? null : question.id)}>
                          <Video size={13} /> {previewId === question.id ? "إخفاء معاينة السؤال" : "معاينة السؤال داخل الفيديو"}
                        </Button>
                        <Button variant="quiet" className="!py-2 text-[11px]" onClick={addQuestion}><Plus size={13} /> إضافة سؤال بعده</Button>
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <p className="text-[12px] font-semibold text-[#dedee4]">الصوت والصورة</p>
                        <button type="button" onClick={() => onNavigate("audio")} className="text-[10px] text-[#b6a271] hover:text-[#e7cf94]">إعدادات الصوت ←</button>
                      </div>
                      {combined ? (
                        <MediaPicker
                          label="الصوت الموحّد للسؤال"
                          hint="يُستخدم بدلًا من صوت السؤال والخيارات في وضع «ملف واحد»."
                          kind="audio"
                          value={question.combinedAudioId}
                          onSelect={(id) => patchQuestion(question.id, { combinedAudioId: id })}
                          onRemove={() => patchQuestion(question.id, { combinedAudioId: null })}
                          suggestedName={`q${String(index + 1).padStart(2, "0")}_combined.mp3`}
                          compact
                        />
                      ) : (
                        <>
                          <MediaPicker
                            label="صوت قراءة السؤال"
                            kind="audio"
                            value={question.questionAudioId}
                            onSelect={(id) => patchQuestion(question.id, { questionAudioId: id })}
                            onRemove={() => patchQuestion(question.id, { questionAudioId: null })}
                            suggestedName={expectedAudioName(index, "question")}
                            compact
                          />
                          <MediaPicker
                            label="صوت قراءة الخيارات"
                            kind="audio"
                            value={question.optionsAudioId}
                            onSelect={(id) => patchQuestion(question.id, { optionsAudioId: id })}
                            onRemove={() => patchQuestion(question.id, { optionsAudioId: null })}
                            suggestedName={expectedAudioName(index, "options")}
                            compact
                          />
                        </>
                      )}
                      <MediaPicker
                        label="صوت الإجابة الصحيحة (اختياري)"
                        kind="audio"
                        value={question.answerAudioId}
                        onSelect={(id) => patchQuestion(question.id, { answerAudioId: id })}
                        onRemove={() => patchQuestion(question.id, { answerAudioId: null })}
                        suggestedName={expectedAudioName(index, "answer")}
                        compact
                      />
                      <MediaPicker
                        label="صورة خلفية للسؤال (اختياري)"
                        kind="image"
                        value={question.imageId}
                        onSelect={(id) => patchQuestion(question.id, { imageId: id })}
                        onRemove={() => patchQuestion(question.id, { imageId: null })}
                        suggestedName={`q${String(index + 1).padStart(2, "0")}.jpg`}
                        compact
                      />
                    </div>
                  </div>

                  {previewId === question.id ? (
                    <div className="mt-4 rounded-xl border border-white/[0.08] bg-black/30 p-3">
                      <div className="mb-2 flex items-center justify-between">
                        <p className="flex items-center gap-1.5 text-[11px] text-[#c9c9d1]"><ImageIcon size={12} className="text-[#b5a06c]" /> معاينة حالة كشف الإجابة</p>
                        <span className="text-[9px] text-[#74747e]">{project.exportSettings.width}×{project.exportSettings.height}</span>
                      </div>
                      <div className="mx-auto max-w-[240px]">
                        <SceneCanvas questionIndex={index} stage="reveal" />
                      </div>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </article>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-dashed border-white/10 px-3.5 py-3">
        <p className="text-[11px] text-[#83838d]">إجمالي {project.questions.length} سؤالًا · حفظ تلقائي بعد كل تعديل.</p>
        <div className="flex gap-1.5">
          <Button variant="ghost" className="!py-2 text-[11px]" onClick={() => setImportOpen(true)}><Upload size={13} /> استيراد جماعي</Button>
          <Button variant="primary" className="!py-2 text-[11px]" onClick={addQuestion}><Plus size={13} /> إضافة سؤال</Button>
        </div>
      </div>

      <ImportQuestionsDialog open={importOpen} onClose={() => setImportOpen(false)} />
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title={`حذف «${deleteTarget?.question?.slice(0, 60) || "السؤال"}»؟`}
        description="سيُحذف السؤال وإعداداته من المشروع. الملفات الصوتية والصور تبقى محفوظة في مكتبة الوسائط ولا يمكن استرجاع ارتباط السؤال تلقائيًا."
        confirmLabel="حذف السؤال"
        danger
      />
    </div>
  );
}
