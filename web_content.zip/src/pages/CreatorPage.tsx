import { useState, useEffect, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import { useProjects } from "@/hooks/useProjects";
import AnalyzerResult from "@/components/features/AnalyzerResult";
import { analyzeRequestAsync } from "@/lib/analyzer";
import type { AnalyzedRequest } from "@/types";
import {
  AI_PROVIDERS,
  type AIProviderOption,
} from "@/constants/aiProviders";
import type { VideoEngineId } from "@/types/video";
import type { ImageEngineId } from "@/types/image";
import {
  Sparkles,
  ArrowRight,
  Wand2,
  Loader2,
  Bot,
  Zap,
  Film,
  Image as ImageIcon,
  Mic,
  SlidersHorizontal,
  Check,
  Cpu,
  Settings,
  Tv,
  Smartphone,
  Square,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function CreatorPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { createProject, createProjectFast } = useProjects();
  const [input, setInput] = useState(searchParams.get("q") ?? "");
  const [analyzed, setAnalyzed] = useState<AnalyzedRequest | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [creating, setCreating] = useState(false);

  // AI Provider selection state
  const initialProviderId =
    searchParams.get("provider") ||
    searchParams.get("providerId") ||
    "all";

  const [selectedProviderId, setSelectedProviderId] = useState<string>(initialProviderId);

  // Aspect ratio format (16:9 Horizontal, 9:16 Vertical, 1:1 Quadrado)
  const initialFormat =
    (searchParams.get("format") as "16:9" | "9:16" | "1:1") ||
    (searchParams.get("aspectRatio") as "16:9" | "9:16" | "1:1") ||
    "16:9";
  const [aspectRatio, setAspectRatio] = useState<"16:9" | "9:16" | "1:1">(initialFormat);

  // Turbo Fast Mode Settings
  const [turboMode, setTurboMode] = useState(true);
  const [generateVideos, setGenerateVideos] = useState(true);
  const [generateImages, setGenerateImages] = useState(true);
  const [generateAudio, setGenerateAudio] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Fast generation progress state
  const [progressStage, setProgressStage] = useState("");
  const [progressPercent, setProgressPercent] = useState(0);
  const [progressDetails, setProgressDetails] = useState("");

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const activeProvider: AIProviderOption =
    AI_PROVIDERS.find(
      (p) => p.id === selectedProviderId || p.model === selectedProviderId
    ) || AI_PROVIDERS[0];

  useEffect(() => {
    if (textareaRef.current) textareaRef.current.focus();
    const q = searchParams.get("q");
    if (q) {
      setInput(q);
      analyzeRequestAsync(q).then(setAnalyzed);
    }
    const prov = searchParams.get("provider") || searchParams.get("providerId");
    if (prov) {
      const match = AI_PROVIDERS.find((p) => p.id === prov || p.model === prov);
      if (match) setSelectedProviderId(match.id);
    }
    const fmt = searchParams.get("format") || searchParams.get("aspectRatio");
    if (fmt === "16:9" || fmt === "9:16" || fmt === "1:1") {
      setAspectRatio(fmt);
    }
  }, [searchParams]);

  const handleSelectProvider = (provider: AIProviderOption) => {
    setSelectedProviderId(provider.id);
    const newParams = new URLSearchParams(searchParams);
    newParams.set("provider", provider.id);
    newParams.set("model", provider.model);
    setSearchParams(newParams, { replace: true });
  };

  const handleAnalyze = async () => {
    if (!input.trim() || analyzing) return;
    setAnalyzing(true);
    try {
      const res = await analyzeRequestAsync(input);
      setAnalyzed(res);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCreate = async () => {
    if (!input.trim() || creating) return;
    setCreating(true);
    setProgressPercent(10);
    setProgressStage(`Orquestrando com ${activeProvider.name}...`);
    setProgressDetails(`Alocando modelos de IA e preparando pipeline`);

    const targetVideoEngine: VideoEngineId =
      (searchParams.get("videoEngine") as VideoEngineId) ||
      activeProvider.defaultVideoEngine ||
      "pixverse";

    const targetImageEngine: ImageEngineId =
      (searchParams.get("imageEngine") as ImageEngineId) ||
      activeProvider.defaultImageEngine ||
      "imagen-3";

    try {
      if (turboMode) {
        const project = await createProjectFast(input, {
          videoEngine: targetVideoEngine,
          imageEngine: targetImageEngine,
          generateVideos,
          generateImages,
          generateAudio,
          aspectRatio,
          onProgress: (stage, percent, details) => {
            setProgressStage(stage);
            setProgressPercent(percent);
            if (details) setProgressDetails(details);
          },
        });
        navigate(`/projects/${project.id}`);
      } else {
        const project = await createProject(input, {
          aspectRatio,
        });
        navigate(`/projects/${project.id}`);
      }
    } catch (err) {
      console.error("Erro na geração veloz do projeto:", err);
      // Fallback standard create
      const project = await createProject(input, {
        aspectRatio,
      });
      navigate(`/projects/${project.id}`);
    } finally {
      setCreating(false);
    }
  };

  const handleQuick = async (cmd: string) => {
    setInput(cmd);
    setAnalyzing(true);
    try {
      const res = await analyzeRequestAsync(cmd);
      setAnalyzed(res);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleCreate();
    }
  };

  return (
    <AppLayout title="Criador de Conteúdo com IA">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-1.5 rounded-lg bg-studio-gold/10 text-studio-gold">
              <Cpu className="w-5 h-5 animate-pulse" />
            </span>
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-studio-gold">
              Estúdio de Produção de Mídia com Inteligência Artificial
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-studio-text">
            O que você deseja criar com IA hoje?
          </h1>
          <p className="text-sm text-studio-text-muted mt-1 leading-relaxed">
            Selecione o provedor de IA desejado e descreva seu conteúdo. O estúdio orquestra roteiro, vídeos cinematográficos, imagens 4K e vozes neurais automaticamente.
          </p>
        </div>

        {/* Turbo Progress Overlay */}
        {creating && (
          <div className="studio-card p-6 border-studio-gold/30 bg-studio-surface/95 relative overflow-hidden animate-pulse">
            <div className="absolute top-0 left-0 right-0 h-1 bg-studio-panel">
              <div
                className="h-full bg-gradient-to-r from-studio-gold via-amber-400 to-amber-300 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-studio-gold/10 border border-studio-gold/30 flex items-center justify-center shrink-0 text-studio-gold">
                <Loader2 className="w-5 h-5 animate-spin" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-studio-text font-display">
                    {progressStage || "Gerando Conteúdo com Inteligência Artificial..."}
                  </h3>
                  <span className="text-xs font-mono text-studio-gold font-bold">
                    {progressPercent}%
                  </span>
                </div>
                <p className="text-xs text-studio-text-dim mt-1">
                  {progressDetails || `Orquestrando com ${activeProvider.name}...`}
                </p>
                <div className="mt-3 flex items-center gap-4 text-xs font-mono text-studio-text-muted">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                    {activeProvider.name}
                  </span>
                  <span>Formato: {aspectRatio}</span>
                  <span>Gemini 3.7 Flash</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Input Card */}
        <div className="studio-card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-studio-text-muted font-mono flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-studio-gold" />
              <span>Prompt / Descrição do Conteúdo</span>
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setTurboMode(!turboMode)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  turboMode
                    ? "bg-amber-400/10 text-amber-300 border border-amber-400/30"
                    : "bg-studio-panel text-studio-text-muted border border-studio-border"
                }`}
              >
                <Zap className={`w-3.5 h-3.5 ${turboMode ? "text-amber-400 animate-pulse" : ""}`} />
                <span>Modo Turbo Veloz</span>
              </button>
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-studio-blue/10 border border-studio-blue/20 text-xs text-studio-blue font-medium">
                <Bot className="w-3.5 h-3.5" />
                <span>Gemini 3.7 Flash</span>
              </div>
            </div>
          </div>

          {/* AI Providers Selector Bar */}
          <div className="p-3.5 rounded-xl bg-studio-surface/90 border border-studio-border/90 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase tracking-wider font-bold text-studio-gold flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 animate-pulse" />
                <span>Provedor de Inteligência Artificial:</span>
              </span>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-studio-text-muted hidden sm:inline">
                  {activeProvider.model}
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  {activeProvider.badge}
                </span>
              </div>
            </div>

            {/* Provider Buttons Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {AI_PROVIDERS.map((provider) => {
                const Icon = provider.icon;
                const isSelected = activeProvider.id === provider.id;
                return (
                  <button
                    key={provider.id}
                    type="button"
                    onClick={() => handleSelectProvider(provider)}
                    className={cn(
                      "flex items-center gap-2 p-2 rounded-lg text-left transition-all border text-xs cursor-pointer",
                      isSelected
                        ? "bg-studio-panel border-studio-gold shadow-sm ring-1 ring-studio-gold/30 text-studio-text"
                        : "bg-studio-panel/50 border-studio-border/60 hover:border-studio-border hover:bg-studio-panel text-studio-text-dim"
                    )}
                  >
                    <div
                      className={cn(
                        "w-6 h-6 rounded flex items-center justify-center shrink-0",
                        isSelected ? provider.bgLight : "bg-studio-surface"
                      )}
                    >
                      <Icon
                        className={cn(
                          "w-3.5 h-3.5",
                          isSelected ? provider.color : "text-studio-text-muted"
                        )}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <span
                          className={cn(
                            "font-semibold truncate text-[11px]",
                            isSelected ? "text-white" : "text-studio-text"
                          )}
                        >
                          {provider.id === "all" ? "Auto Orquestrador" : provider.name.split(" ")[0]}
                        </span>
                        {isSelected && (
                          <Check className="w-3 h-3 text-studio-gold shrink-0" />
                        )}
                      </div>
                      <span className="text-[9px] font-mono text-studio-text-muted block truncate">
                        {provider.categoryLabel}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Active Provider Info Card + Quick Format Toggle */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-2.5 rounded-lg bg-studio-panel/80 border border-studio-border/70 text-xs">
              <div className="flex items-start gap-2 min-w-0 flex-1">
                <span className="text-studio-gold font-bold shrink-0">Capacidade:</span>
                <p className="text-studio-text-dim leading-snug text-[11px]">
                  {activeProvider.subtitle}
                </p>
              </div>

              {/* Format pills (16:9, 9:16, 1:1) */}
              <div className="flex items-center gap-1 shrink-0 self-end sm:self-center border-t sm:border-t-0 pt-2 sm:pt-0 border-studio-border/60">
                <span className="text-[10px] font-mono text-studio-text-muted mr-1">Proporção:</span>
                {[
                  { id: "16:9", label: "16:9", icon: Tv, desc: "Horizontal" },
                  { id: "9:16", label: "9:16", icon: Smartphone, desc: "Vertical" },
                  { id: "1:1", label: "1:1", icon: Square, desc: "Quadrado" },
                ].map((fmt) => {
                  const FmtIcon = fmt.icon;
                  const isFmt = aspectRatio === fmt.id;
                  return (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => setAspectRatio(fmt.id as "16:9" | "9:16" | "1:1")}
                      className={cn(
                        "flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono transition-all cursor-pointer",
                        isFmt
                          ? "bg-studio-gold/20 text-studio-gold border border-studio-gold/50 font-bold"
                          : "bg-studio-surface text-studio-text-muted hover:text-studio-text border border-studio-border/50"
                      )}
                      title={fmt.desc}
                    >
                      <FmtIcon className="w-3 h-3" />
                      <span>{fmt.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Text Area */}
          <div className="relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                if (analyzed) setAnalyzed(null);
              }}
              onKeyDown={handleKey}
              placeholder={activeProvider.promptPlaceholder}
              className="studio-input min-h-[140px] resize-none text-sm leading-relaxed pb-12"
              rows={6}
            />
            <div className="absolute bottom-3 right-3 flex items-center gap-2">
              <span className="text-xs font-mono text-studio-text-muted">
                {input.length} chars
              </span>
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                  showAdvanced
                    ? "bg-studio-gold/10 border-studio-gold/30 text-studio-gold"
                    : "bg-studio-panel border-studio-border text-studio-text-muted hover:text-studio-text"
                }`}
                title="Ajustar motores gerados"
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Advanced options */}
          {showAdvanced && (
            <div className="p-4 rounded-xl bg-studio-panel border border-studio-border space-y-3 animate-in fade-in-0 duration-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-studio-text font-mono">
                  Módulos de Geração Ativos ({activeProvider.name})
                </span>
                <span className="text-[10px] text-studio-text-muted font-mono">
                  Desmarque para pular etapas específicas
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label className="flex items-center gap-2.5 p-2.5 rounded-lg bg-studio-surface border border-studio-border text-xs cursor-pointer hover:border-studio-gold/30">
                  <input
                    type="checkbox"
                    checked={generateVideos}
                    onChange={(e) => setGenerateVideos(e.target.checked)}
                    className="accent-studio-gold rounded"
                  />
                  <Film className="w-4 h-4 text-purple-400" />
                  <div>
                    <span className="font-semibold block text-studio-text">Vídeos Cinematográficos</span>
                    <span className="text-[10px] text-studio-text-muted">PixVerse V3.5 & Veo 2</span>
                  </div>
                </label>
                <label className="flex items-center gap-2.5 p-2.5 rounded-lg bg-studio-surface border border-studio-border text-xs cursor-pointer hover:border-studio-gold/30">
                  <input
                    type="checkbox"
                    checked={generateImages}
                    onChange={(e) => setGenerateImages(e.target.checked)}
                    className="accent-studio-gold rounded"
                  />
                  <ImageIcon className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="font-semibold block text-studio-text">Imagens em 4K</span>
                    <span className="text-[10px] text-studio-text-muted">Frames & Storyboards</span>
                  </div>
                </label>
                <label className="flex items-center gap-2.5 p-2.5 rounded-lg bg-studio-surface border border-studio-border text-xs cursor-pointer hover:border-studio-gold/30">
                  <input
                    type="checkbox"
                    checked={generateAudio}
                    onChange={(e) => setGenerateAudio(e.target.checked)}
                    className="accent-studio-gold rounded"
                  />
                  <Mic className="w-4 h-4 text-amber-400" />
                  <div>
                    <span className="font-semibold block text-studio-text">Voz Neural & Trilha</span>
                    <span className="text-[10px] text-studio-text-muted">Narração + Soundscape</span>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-1">
            <button
              onClick={handleAnalyze}
              disabled={!input.trim() || analyzing}
              className="btn-secondary text-sm py-2.5 w-full sm:w-auto"
            >
              {analyzing ? (
                <><Loader2 className="w-4 h-4 animate-spin text-studio-blue" /> Analisando com Gemini...</>
              ) : (
                <><Wand2 className="w-4 h-4" /> Analisar com Gemini</>
              )}
            </button>
            <button
              onClick={handleCreate}
              disabled={!input.trim() || creating}
              className="btn-gold text-sm py-2.5 flex-1 justify-center shadow-lg shadow-studio-gold/15"
            >
              {creating ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Gerando com {activeProvider.name}...</>
              ) : (
                <><Zap className="w-4 h-4 text-black" /> Criar Projeto com {activeProvider.id === "all" ? "Orquestrador IA" : activeProvider.name.split(" ")[0]}</>
              )}
            </button>
          </div>
        </div>

        {/* Analysis result */}
        {analyzed && <AnalyzerResult result={analyzed} />}

        {/* Quick commands for active AI Provider */}
        <div className="studio-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-studio-text font-display flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-studio-gold" />
              <span>Ideias e Prompts Otimizados para {activeProvider.name}</span>
            </h3>
            <span className="text-xs font-mono text-studio-text-muted">
              {activeProvider.model}
            </span>
          </div>
          <div className="grid grid-cols-1 gap-2">
            {activeProvider.presets.map((cmd) => (
              <button
                key={cmd}
                onClick={() => handleQuick(cmd)}
                className="flex items-center justify-between gap-3 p-3 rounded-xl bg-studio-panel hover:bg-studio-border border border-transparent hover:border-studio-blue/20 transition-all group text-left cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <Sparkles className="w-3.5 h-3.5 text-studio-gold shrink-0" />
                  <span className="text-sm text-studio-text-dim group-hover:text-studio-text transition-colors">{cmd}</span>
                </div>
                <ArrowRight className="w-4 h-4 text-studio-text-muted group-hover:text-studio-blue shrink-0 transition-colors" />
              </button>
            ))}
          </div>
        </div>

        {/* AI Engine Status & Tips */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            {
              icon: "⚡",
              title: "Orquestração Multimodal",
              tip: "O estúdio conecta Gemini, PixVerse, ElevenLabs e FFmpeg em uma linha de produção unificada.",
            },
            {
              icon: "🎬",
              title: "Vídeo & Imagem 4K",
              tip: "Cenas geradas em alta taxa de quadros com movimentos de câmera 3D e consistência visual.",
            },
            {
              icon: "🎙️",
              title: "Áudio & Pós-Produção",
              tip: "Síntese de voz neural e trilha sonora adaptativa mixadas automaticamente com auto-ducking.",
            },
          ].map((item) => (
            <div key={item.title} className="studio-card p-3.5">
              <div className="flex items-center gap-2">
                <span className="text-lg">{item.icon}</span>
                <span className="text-xs font-bold text-studio-text">{item.title}</span>
              </div>
              <p className="text-xs text-studio-text-muted mt-1.5 leading-relaxed">{item.tip}</p>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
