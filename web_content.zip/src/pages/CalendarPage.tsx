import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { CalendarSchedulerView } from "@/components/features/CalendarSchedulerView";
import { PublishingQueueView } from "@/components/features/PublishingQueueView";
import { Calendar, Layers } from "lucide-react";

export default function CalendarPage() {
  const [viewMode, setViewMode] = useState<"CALENDAR" | "QUEUE">("CALENDAR");

  return (
    <AppLayout title="Calendário & Publicação" subtitle="Cronograma de lançamentos e fila de publicação multicanal">
      <div className="p-6 max-w-6xl space-y-6">
        {/* Navigation Mode Switcher */}
        <div className="flex items-center justify-between border-b border-studio-border pb-4">
          <div className="flex rounded-lg bg-studio-panel border border-studio-border p-1">
            <button
              onClick={() => setViewMode("CALENDAR")}
              className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 transition-all ${
                viewMode === "CALENDAR"
                  ? "bg-studio-blue text-white shadow-sm"
                  : "text-studio-text-muted hover:text-studio-text"
              }`}
            >
              <Calendar className="w-4 h-4" />
              Calendário Mensal
            </button>
            <button
              onClick={() => setViewMode("QUEUE")}
              className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 transition-all ${
                viewMode === "QUEUE"
                  ? "bg-studio-blue text-white shadow-sm"
                  : "text-studio-text-muted hover:text-studio-text"
              }`}
            >
              <Layers className="w-4 h-4" />
              Fila & Logs de Auditoria
            </button>
          </div>

          <span className="text-xs text-studio-text-muted hidden sm:inline">
            CORE 2.0 • Publicação Multicanal
          </span>
        </div>

        {viewMode === "CALENDAR" ? <CalendarSchedulerView /> : <PublishingQueueView />}
      </div>
    </AppLayout>
  );
}
