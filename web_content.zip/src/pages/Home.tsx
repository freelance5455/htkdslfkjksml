import { Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CalendarDays, Coins, Flame, ListChecks, Layers, Play, Sparkles, Target, Timer, Trophy } from 'lucide-react';
import { subjects, getSubject } from '../data/content';
import { useProfile } from '../hooks/useProfile';
import { useStored, KEYS } from '../services/storage';
import { EMPTY_WALLET, nextPointProgress } from '../services/economy';
import { challengeSummary } from '../services/gamification';
import {
  completedCount,
  lastWatchedLesson,
  minutesOn,
  overallProgress,
  studyStreak,
  todayKey,
  subjectProgress,
} from '../services/progress';
import { getPlan } from '../services/plan';
import { daysUntilExam } from '../services/plan';
import { formatDate, formatDuration, formatMinutes } from '../utils/format';
import { useStudySession } from '../hooks/useStudySession';
import { SubjectCard } from '../components/content/SubjectBits';
import { ProgressBar } from '../components/ui/Card';

function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return 'ليلة دراسة موفّقة';
  if (h < 12) return 'صباح الخير';
  if (h < 17) return 'نهارك سعيد';
  if (h < 21) return 'مساء الخير';
  return 'مساء الدراسة';
}

export default function Home() {
  const { profile } = useProfile();
  const session = useStudySession();
  // نُشترك بتغيّر التقدم حتى تتحدّث النِسَب مباشرة
  useStored(KEYS.progress, {});
  useStored(KEYS.stats, { days: {} });
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  useStored(KEYS.quizzes, []);
  useStored(KEYS.cards, {});

  if (!profile.onboarded) return <Navigate to="/welcome" replace />;

  const last = lastWatchedLesson();
  const plan = getPlan();
  const goalMinutes = plan.hoursPerDay > 0 ? Math.round(plan.hoursPerDay * 60) : 90;
  const todayMinutes = minutesOn(todayKey());
  const streak = studyStreak();
  const days = daysUntilExam(profile.examDate);
  const overall = overallProgress();
  const done = completedCount();
  const todayDay = new Date().getDay();
  const todayPlan = plan.sessions.filter((s) => s.day === todayDay);
  const goalRatio = Math.min(1, todayMinutes / goalMinutes);
  const challenges = challengeSummary();

  const remaining = last ? Math.max(0, (last.progress.duration || last.lesson.duration) - last.progress.position) : 0;
  const subjectOfLast = last ? getSubject(last.lesson.subjectId) : undefined;

  return (
    <div className="space-y-5">
      {/* التحية */}
      <header className="profile-banner flex items-start justify-between gap-3 pt-1">
        <div>
          <p className="text-[0.75rem] text-[var(--ink-soft)]">{greeting()}</p>
          <h1 className="font-display text-2xl text-[var(--ink)]">
            {profile.name.split(' ')[0]}
            <span className="ms-1 text-[var(--gold)]">.</span>
          </h1>
          <p className="mt-1 text-[0.78rem] text-[var(--ink-soft)]">
            {days > 0 ? `${days} يوماً تفصلك عن هدفك — لنبدأ بحصة واحدة.` : 'الامتحان اليوم. هدوء وثقة.'}
          </p>
        </div>
        <Link
          to="/welcome"
          aria-label="ملفي"
          className="profile-avatar focus-ring flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--brand)] font-display text-sm text-[var(--brand-ink)]"
        >
          {profile.name.trim().charAt(0) || 'ط'}
        </Link>
      </header>

      <Link to="/study-session" className="focus-ring card flex min-h-16 items-center gap-3 border-[var(--gold)]/40 p-4">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[var(--gold)]"><Timer size={21} /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-semibold text-[var(--ink)]">{session.status === 'running' ? 'جلسة الدراسة جارية' : session.status === 'paused' ? 'استأنف جلسة الدراسة' : 'ابدأ جلسة الدراسة'}</span>
          <span className="block text-xs text-[var(--ink-soft)]">{session.status === 'idle' || session.status === 'completed' ? 'مؤقت واضح · ٢٥ أو ٥٠ دقيقة' : `${formatDuration(session.elapsedSeconds)} من ${formatDuration(session.durationSeconds)} · اضغط لفتح المؤقت`}</span>
        </span>
        <Play size={16} className="shrink-0 text-[var(--gold)]" />
      </Link>

      {/* تابع من حيث توقفت */}
      {last && subjectOfLast ? (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="card relative overflow-hidden p-0"
        >
          <div
            className="absolute inset-0 opacity-90"
            style={{
              background:
                'radial-gradient(120% 100% at 90% 0%, color-mix(in srgb, var(--gold) 22%, transparent), transparent 60%), linear-gradient(160deg, var(--brand) 0%, #061a26 100%)',
            }}
            aria-hidden="true"
          />
          <div className="relative p-4 text-white sm:p-5">
            <div className="flex items-center gap-2 text-[0.68rem] text-white/65">
              <Sparkles size={13} /> تابع من حيث توقفت
            </div>
            <p className="mt-1.5 font-display text-[1.05rem] leading-snug">{last.lesson.title}</p>
            <p className="mt-0.5 text-[0.7rem] text-white/65">
              {subjectOfLast.name} · توقفت عند {formatDuration(last.progress.position)} · بقي {formatDuration(remaining)}
            </p>
            <div className="mt-3 flex items-center gap-3">
              <ProgressBar
                value={Math.round((last.progress.position / (last.progress.duration || last.lesson.duration)) * 100)}
                height={6}
                color="var(--gold)"
                className="max-w-[14rem] bg-white/20"
                label="موضع التوقف"
              />
              <Link
                to={`/lesson/${last.lesson.subjectId}/${last.lesson.id}`}
                className="focus-ring ms-auto inline-flex h-10 items-center gap-1.5 rounded-full bg-[var(--gold)] px-4 text-[0.8rem] font-semibold text-[#3a2606]"
              >
                <Play size={15} className="fill-current" /> أكمل
              </Link>
            </div>
          </div>
        </motion.div>
      ) : (
        <div className="card beam p-5">
          <p className="font-display text-lg text-[var(--ink)]">لا سجل بعد — لنبدأ أول درس</p>
          <p className="mt-1 text-[0.8rem] leading-relaxed text-[var(--ink-soft)]">
            اختر مادة، ثم درساً، وسيتذكّر المشغّل موضع توقفك تلقائياً كل ٥ ثوانٍ.
          </p>
          <Link
            to="/subjects"
            className="focus-ring mt-3 inline-flex h-10 items-center gap-1.5 rounded-full bg-[var(--brand)] px-4 text-[0.8rem] font-medium text-[var(--brand-ink)]"
          >
            استعرض المواد
          </Link>
        </div>
      )}

      {/* العدّاد + هدف اليوم */}
      <div className="grid grid-cols-2 gap-3">
        <Link to="/plan" className="focus-ring card flex flex-col justify-between p-4">
          <span className="flex items-center gap-1.5 text-[0.7rem] text-[var(--ink-soft)]">
            <CalendarDays size={13} /> الأيام المتبقية
          </span>
          <div className="mt-2 flex items-end gap-1">
            <span className="font-display text-3xl leading-none text-[var(--ink)]">{days}</span>
            <span className="pb-0.5 text-[0.7rem] text-[var(--ink-soft)]">يوماً</span>
          </div>
          <span className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">الامتحان: {formatDate(profile.examDate)}</span>
        </Link>

        <div className="card flex flex-col justify-between p-4">
          <span className="flex items-center gap-1.5 text-[0.7rem] text-[var(--ink-soft)]">
            <Target size={13} /> هدف اليوم
          </span>
          <div className="mt-2 flex items-center gap-3">
            <GoalRing ratio={goalRatio} minutes={todayMinutes} />
            <div>
              <p className="font-display text-lg leading-none text-[var(--ink)]">
                {Math.round(goalRatio * 100)}%
              </p>
              <p className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">
                {formatMinutes(todayMinutes)} / {formatMinutes(goalMinutes)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* السلسلة + الإحصاء */}
      <div className="grid grid-cols-2 gap-3">
        <div className="card flex items-center gap-3 p-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]">
            <Flame size={19} />
          </span>
          <div>
            <p className="font-display text-lg leading-none text-[var(--ink)]">{streak}</p>
            <p className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">يوم متتالٍ</p>
          </div>
        </div>
        <div className="card flex items-center gap-3 p-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--surface-2)] text-[var(--ink-soft)]">
            <Timer size={19} />
          </span>
          <div>
            <p className="font-display text-lg leading-none text-[var(--ink)]">{overall}%</p>
            <p className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">{done} درساً مكتملاً</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Link to="/shop" className="focus-ring card p-3.5">
          <div className="flex items-center justify-between"><span className="flex items-center gap-1.5 text-[0.68rem] text-[var(--ink-soft)]"><Coins size={14} className="text-[var(--gold)]" /> رصيدك</span><span className="font-semibold text-[var(--ink)]">{wallet.balance}</span></div>
          <p className="mt-1 text-[0.65rem] text-[var(--ink-soft)]">١٠ نقاط لكل ساعة دراسة</p>
          <ProgressBar value={nextPointProgress()} className="mt-2" height={5} />
        </Link>
        <Link to="/challenges" className="focus-ring card flex items-center gap-2.5 p-3.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--gold-soft)] text-[var(--gold)]"><Trophy size={16} /></span>
          <span><span className="block text-[0.75rem] font-medium text-[var(--ink)]">تحدياتك</span><span className="text-[0.62rem] text-[var(--ink-soft)]">{challenges.completed} مكتملة · استلم {challenges.claimed}</span></span>
        </Link>
      </div>

      {/* حصص اليوم من الخطة */}
      {todayPlan.length > 0 ? (
        <section>
          <div className="mb-2 flex items-end justify-between">
            <h2 className="font-display text-base text-[var(--ink)]">حصص اليوم</h2>
            <Link to="/plan" className="text-[0.72rem] text-[var(--ink-soft)] underline-offset-4 hover:underline">
              الجدول الكامل
            </Link>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
            {todayPlan.map((session) => {
              const subject = getSubject(session.subjectId);
              return (
                <Link
                  key={session.id}
                  to={subject ? `/subject/${subject.id}` : '/subjects'}
                  className="card-quiet flex w-40 shrink-0 flex-col gap-1 p-3"
                >
                  <span
                    className="text-[0.62rem] font-medium"
                    style={{ color: subject?.color ?? 'var(--ink-soft)' }}
                  >
                    {subject?.name}
                  </span>
                  <span className="text-[0.78rem] text-[var(--ink)]">{session.minutes} دقيقة</span>
                  <span className="text-[0.62rem] text-[var(--ink-soft)]">
                    {session.done ? 'تم ✓' : 'لم تبدأ'}
                  </span>
                </Link>
              );
            })}
          </div>
        </section>
      ) : null}

      {/* المواد */}
      <section>
        <div className="mb-2 flex items-end justify-between">
          <h2 className="font-display text-base text-[var(--ink)]">موادي</h2>
          <Link to="/subjects" className="text-[0.72rem] text-[var(--ink-soft)] underline-offset-4 hover:underline">
            عرض الكل
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {subjects.slice(0, 4).map((subject) => (
            <SubjectCard key={subject.id} subject={subject} />
          ))}
        </div>
        <div className="mt-2 rounded-2xl bg-[var(--surface-2)] p-3 text-[0.72rem] text-[var(--ink-soft)]">
          إجمالي تقدمك الآن {overall}% — أكثر مادة تحتاج وقتاً:{' '}
          <strong className="text-[var(--ink)]">
            {[...subjects].sort((a, b) => subjectProgress(a) - subjectProgress(b))[0]?.name}
          </strong>
          .
        </div>
      </section>

      {/* روابط سريعة */}
      <section className="grid grid-cols-3 gap-2 pb-2">
        {[
          { to: '/tests', label: 'الاختبارات', icon: ListChecks },
          { to: '/review', label: 'المراجعة', icon: Layers },
          { to: '/plan', label: 'خطتي', icon: CalendarDays },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="focus-ring card flex flex-col items-center gap-1.5 p-3 text-[0.72rem] text-[var(--ink-soft)]"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--ink)]">
              <item.icon size={17} />
            </span>
            {item.label}
          </Link>
        ))}
      </section>
    </div>
  );
}

function GoalRing({ ratio, minutes }: { ratio: number; minutes: number }) {
  const r = 18;
  const c = 2 * Math.PI * r;
  return (
    <svg width="52" height="52" viewBox="0 0 48 48" role="img" aria-label={`هدف اليوم: ${Math.round(ratio * 100)}%`}>
      <circle cx="24" cy="24" r={r} fill="none" stroke="var(--surface-2)" strokeWidth="5" />
      <circle
        cx="24"
        cy="24"
        r={r}
        fill="none"
        stroke={minutes > 0 ? 'var(--gold)' : 'var(--line)'}
        strokeWidth="5"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - ratio)}
        transform="rotate(-90 24 24)"
        style={{ transition: 'stroke-dashoffset 600ms ease' }}
      />
    </svg>
  );
}
