import React, { useState, useMemo } from 'react';
import {
  UNIT_CATEGORIES,
  convertUnits,
  UnitCategory
} from '../data/unitConversionData';
import { useApp } from '../context/AppContext';
import {
  Compass,
  ArrowRightLeft,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Scale
} from 'lucide-react';

export const UnitConverterPage: React.FC = () => {
  const { showToast, playSound, triggerHaptic } = useApp();

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('length');
  const [inputValue, setInputValue] = useState<string>('10');
  const [fromUnitId, setFromUnitId] = useState<string>('km');
  const [toUnitId, setToUnitId] = useState<string>('m');
  const [copied, setCopied] = useState<boolean>(false);

  const activeCategory: UnitCategory = useMemo(() => {
    return (
      UNIT_CATEGORIES.find((c) => c.id === selectedCategoryId) ||
      UNIT_CATEGORIES[0]
    );
  }, [selectedCategoryId]);

  // Handle switching category
  const handleCategoryChange = (catId: string) => {
    playSound('tab');
    setSelectedCategoryId(catId);
    const cat = UNIT_CATEGORIES.find((c) => c.id === catId);
    if (cat && cat.units.length >= 2) {
      setFromUnitId(cat.units[1].id);
      setToUnitId(cat.units[0].id);
    }
  };

  // Convert calculation
  const convertedResult = useMemo(() => {
    const num = parseFloat(inputValue);
    if (isNaN(num)) return null;
    return convertUnits(num, activeCategory, fromUnitId, toUnitId);
  }, [inputValue, activeCategory, fromUnitId, toUnitId]);

  const formattedResult = useMemo(() => {
    if (convertedResult === null || isNaN(convertedResult)) return '—';
    const abs = Math.abs(convertedResult);
    if (abs !== 0 && (abs < 0.0001 || abs >= 10000000)) {
      return convertedResult.toExponential(6);
    }
    return Number(convertedResult.toFixed(6)).toLocaleString(undefined, {
      maximumFractionDigits: 6
    });
  }, [convertedResult]);

  const handleSwapUnits = () => {
    playSound('button');
    triggerHaptic('light');
    const prevFrom = fromUnitId;
    setFromUnitId(toUnitId);
    setToUnitId(prevFrom);
  };

  const handleCopy = async () => {
    if (convertedResult === null) return;
    const fromSymbol = activeCategory.units.find((u) => u.id === fromUnitId)?.symbol || '';
    const toSymbol = activeCategory.units.find((u) => u.id === toUnitId)?.symbol || '';
    const text = `${inputValue} ${fromSymbol} = ${formattedResult} ${toSymbol}`;

    try {
      await navigator.clipboard.writeText(text);
      playSound('copy');
      triggerHaptic('light');
      setCopied(true);
      showToast('Conversion copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Copy failed', 'error');
    }
  };

  const fromUnitObj = activeCategory.units.find((u) => u.id === fromUnitId);
  const toUnitObj = activeCategory.units.find((u) => u.id === toUnitId);

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Scale className="w-5 h-5 text-[#D65A1F]" />
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            SI Engineering Unit Converter
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-[#A9A39C]">
          Transform physical quantities across 11 scientific domains with exact conversion constants and thermal offset calculations.
        </p>
      </div>

      {/* Category Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {UNIT_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => handleCategoryChange(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold shrink-0 transition-all border ${
              selectedCategoryId === cat.id
                ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] font-bold shadow-sm'
                : 'bg-[#1C1C1C] text-[#A9A39C] hover:text-[#F5F2ED] border-[#303030]'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Converter Panel */}
      <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4 items-center">
          {/* FROM Unit & Input */}
          <div className="md:col-span-3 space-y-2">
            <label className="text-xs font-mono font-semibold text-[#A9A39C] uppercase tracking-wider block">
              From ({fromUnitObj?.name})
            </label>

            <div className="space-y-2">
              <input
                type="number"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Enter value..."
                className="w-full px-4 py-3 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] font-mono text-lg focus:outline-none focus:border-[#D65A1F] shadow-inner"
              />

              <select
                value={fromUnitId}
                onChange={(e) => {
                  playSound('tab');
                  setFromUnitId(e.target.value);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs font-mono focus:outline-none focus:border-[#D65A1F]"
              >
                {activeCategory.units.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* SWAP BUTTON */}
          <div className="md:col-span-1 flex justify-center py-2 md:py-0">
            <button
              onClick={handleSwapUnits}
              className="p-3 rounded-xl bg-[#232323] hover:bg-[#303030] text-[#D65A1F] border border-[#303030] transition-all hover:scale-105 active:scale-95 shadow-md"
              title="Swap units"
            >
              <ArrowRightLeft className="w-5 h-5" />
            </button>
          </div>

          {/* TO Unit & Output */}
          <div className="md:col-span-3 space-y-2">
            <label className="text-xs font-mono font-semibold text-[#A9A39C] uppercase tracking-wider block">
              To ({toUnitObj?.name})
            </label>

            <div className="space-y-2">
              <div className="w-full px-4 py-3 rounded-2xl bg-[#151515] border border-[#303030] text-[#D65A1F] font-mono text-lg truncate shadow-inner">
                {formattedResult}
              </div>

              <select
                value={toUnitId}
                onChange={(e) => {
                  playSound('tab');
                  setToUnitId(e.target.value);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] text-xs font-mono focus:outline-none focus:border-[#D65A1F]"
              >
                {activeCategory.units.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Highlighted Result Card */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#151515] border border-[#303030] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-mono text-[#D65A1F] font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Conversion Result</span>
            </div>
            <div className="text-lg sm:text-2xl font-extrabold text-[#F5F2ED] font-mono break-all">
              {inputValue} {fromUnitObj?.symbol} ={' '}
              <span className="text-[#D65A1F]">
                {formattedResult} {toUnitObj?.symbol}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#232323] hover:bg-[#303030] text-[#F5F2ED] text-xs font-semibold border border-[#303030] transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-[#72A65A]" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            <button
              onClick={() => {
                playSound('button');
                setInputValue('1');
              }}
              className="p-2.5 rounded-xl bg-[#232323] hover:bg-[#303030] text-[#A9A39C] border border-[#303030] transition-colors"
              title="Reset to 1"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Reference Table for Active Category */}
        <div className="pt-4 border-t border-[#303030]">
          <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-[#A9A39C] mb-3">
            Domain Units Reference: {activeCategory.name}
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
            {activeCategory.units.map((u) => (
              <div
                key={u.id}
                className="p-2.5 rounded-xl bg-[#151515] border border-[#303030] flex items-center justify-between"
              >
                <span className="text-[#F5F2ED]">{u.name}</span>
                <span className="text-[#D65A1F] font-bold">{u.symbol}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
