/* ============================================
   plix_ai studio — Developer Tools
   Keystore manager, CI/CD snippets, API docs, templates
   ============================================ */

import { useState } from 'react';
import type { PageId } from '../types';
import { CLI_SNIPPETS, TEMPLATES, API_CONTRACT } from '../utils/mock-api';
import { getKeystores, saveKeystore, deleteKeystore } from '../store';
import type { KeystoreConfig } from '../types';
import {
  IconKey, IconTerminal, IconCode, IconCopy,
  IconPlus, IconTrash, IconCheck, IconPackage
} from '../components/Icons';

interface DevToolsProps {
  onNavigate: (page: PageId) => void;
}

type TabId = 'templates' | 'keystores' | 'cicd' | 'api';

export default function DevTools({ onNavigate }: DevToolsProps) {
  const [activeTab, setActiveTab] = useState<TabId>('templates');
  const [copied, setCopied] = useState<string | null>(null);

  const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'templates', label: 'Templates', icon: <IconPackage size={15} /> },
    { id: 'keystores', label: 'Keystores', icon: <IconKey size={15} /> },
    { id: 'cicd', label: 'CI/CD', icon: <IconTerminal size={15} /> },
    { id: 'api', label: 'API', icon: <IconCode size={15} /> },
  ];

  function handleCopy(text: string, id: string) {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Developer Tools</h1>
        <p className="text-sm text-stone-400 mt-1">Templates, keystores, CI/CD integration, and API access.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 overflow-x-auto pb-1 border-b border-subtle">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px ${
              activeTab === tab.id
                ? 'text-sky-400 border-sky-400'
                : 'text-stone-400 border-transparent hover:text-stone-200'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Templates */}
      {activeTab === 'templates' && (
        <div className="animate-fade-in">
          <div className="mb-4">
            <h2 className="text-lg font-semibold mb-1">Project Templates</h2>
            <p className="text-sm text-stone-400">Quick-start templates for common Android project types.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {TEMPLATES.map(template => (
              <div
                key={template.id}
                className="card card-interactive group cursor-pointer"
                onClick={() => onNavigate('convert')}
              >
                <div className="flex items-start gap-3">
                  <div className="text-2xl">{template.icon}</div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm group-hover:text-sky-400 transition-colors">
                      {template.name}
                    </h3>
                    <p className="text-xs text-stone-400 mt-1 leading-relaxed">{template.description}</p>
                    <div className="flex gap-1 mt-2">
                      {template.tags.map(tag => (
                        <span key={tag} className="badge badge-neutral">{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Keystore Manager */}
      {activeTab === 'keystores' && (
        <KeystoreManager onCopy={handleCopy} copied={copied} />
      )}

      {/* CI/CD */}
      {activeTab === 'cicd' && (
        <div className="animate-fade-in">
          <div className="mb-4">
            <h2 className="text-lg font-semibold mb-1">CI/CD Snippets</h2>
            <p className="text-sm text-stone-400">Ready-to-use pipeline configurations for automated builds.</p>
          </div>
          <div className="space-y-4">
            {CLI_SNIPPETS.map(snippet => (
              <div key={snippet.id} className="card">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-sm">{snippet.title}</h3>
                    <p className="text-xs text-stone-400 mt-0.5">{snippet.description}</p>
                  </div>
                  <button
                    onClick={() => handleCopy(snippet.code, snippet.id)}
                    className="btn btn-ghost btn-sm"
                    aria-label="Copy snippet"
                  >
                    {copied === snippet.id ? <IconCheck size={14} className="text-emerald-400" /> : <IconCopy size={14} />}
                  </button>
                </div>
                <div className="code-block text-xs">{snippet.code}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* API Docs */}
      {activeTab === 'api' && (
        <div className="animate-fade-in">
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-1">API Reference</h2>
            <p className="text-sm text-stone-400">
              REST API for programmatic access. Base URL:{' '}
              <code className="font-mono text-sky-400">{API_CONTRACT.baseUrl}</code>
            </p>
          </div>

          {/* Endpoints */}
          <div className="space-y-3 mb-8">
            {API_CONTRACT.endpoints.map((ep, i) => (
              <div key={i} className="card">
                <div className="flex items-start gap-3">
                  <span className={`badge font-mono ${
                    ep.method === 'POST' ? 'badge-brand' :
                    ep.method === 'GET' ? 'badge-success' :
                    'badge-warning'
                  }`}>
                    {ep.method}
                  </span>
                  <div className="flex-1">
                    <code className="font-mono text-sm text-sky-400">{ep.path}</code>
                    <p className="text-xs text-stone-400 mt-1">{ep.description}</p>
                    {ep.auth && (
                      <p className="text-xs text-stone-500 mt-1">Auth: {ep.auth}</p>
                    )}
                    {ep.body && (
                      <div className="mt-2">
                        <p className="text-xs text-stone-500 mb-1">Body:</p>
                        <div className="code-block text-xs">
                          {Object.entries(ep.body).map(([key, val]) => (
                            <div key={key}>
                              <span className="text-sky-400">{key}</span>: <span className="text-stone-400">{val as string}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {ep.response && typeof ep.response === 'object' && (
                      <div className="mt-2">
                        <p className="text-xs text-stone-500 mb-1">Response:</p>
                        <div className="code-block text-xs">
                          {Object.entries(ep.response).map(([key, val]) => (
                            <div key={key}>
                              <span className="text-emerald-400">{key}</span>: <span className="text-stone-400">{val as string}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Security notes */}
          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Security Policy</h3>
            <ul className="space-y-2">
              {API_CONTRACT.security.map((note, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-stone-300">
                  <span className="text-emerald-500 mt-1 flex-shrink-0">•</span>
                  {note}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}

// --- Keystore Manager sub-component ---
function KeystoreManager({ onCopy, copied }: { onCopy: (text: string, id: string) => void; copied: string | null }) {
  const [keystores, setKeystores] = useState<KeystoreConfig[]>(() => getKeystores());
  const [showNew, setShowNew] = useState(false);
  const [newKs, setNewKs] = useState<Partial<KeystoreConfig>>({
    alias: '',
    password: '',
    keyPassword: '',
    cn: '',
    org: '',
    country: 'US',
    validityYears: 25,
  });

  function handleSave() {
    if (!newKs.alias) return;
    const ks: KeystoreConfig = {
      alias: newKs.alias || '',
      password: newKs.password || '',
      keyPassword: newKs.keyPassword || '',
      cn: newKs.cn || '',
      org: newKs.org || '',
      locality: '',
      state: '',
      country: newKs.country || 'US',
      validityYears: newKs.validityYears || 25,
      sha256Fingerprint: generateMockFingerprint(),
    };
    saveKeystore(ks);
    setKeystores(getKeystores());
    setShowNew(false);
    setNewKs({ alias: '', password: '', keyPassword: '', cn: '', org: '', country: 'US', validityYears: 25 });
  }

  function handleDelete(alias: string) {
    deleteKeystore(alias);
    setKeystores(getKeystores());
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold mb-1">Keystore Manager</h2>
          <p className="text-sm text-stone-400">Manage signing keystores. In demo mode, stored locally only.</p>
        </div>
        <button onClick={() => setShowNew(!showNew)} className="btn btn-primary btn-sm">
          <IconPlus size={14} />
          Generate Keystore
        </button>
      </div>

      {/* Security warning */}
      <div className="card bg-amber-500/5 border-amber-500/15 mb-4">
        <p className="text-xs text-amber-400/80">
          ⚠ In demo mode, keystores are stored in localStorage without encryption.
          In production, all keystores are encrypted with AES-256-GCM and never stored in logs.
        </p>
      </div>

      {/* New keystore form */}
      {showNew && (
        <div className="card mb-4">
          <h3 className="text-sm font-semibold mb-3">Generate New Keystore</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="input-label">Alias</label>
              <input type="text" value={newKs.alias || ''} onChange={e => setNewKs(prev => ({ ...prev, alias: e.target.value }))} className="input font-mono" placeholder="release" />
            </div>
            <div>
              <label className="input-label">Common Name (CN)</label>
              <input type="text" value={newKs.cn || ''} onChange={e => setNewKs(prev => ({ ...prev, cn: e.target.value }))} className="input" placeholder="Your Name" />
            </div>
            <div>
              <label className="input-label">Organization</label>
              <input type="text" value={newKs.org || ''} onChange={e => setNewKs(prev => ({ ...prev, org: e.target.value }))} className="input" placeholder="Company" />
            </div>
            <div>
              <label className="input-label">Country</label>
              <input type="text" value={newKs.country || ''} onChange={e => setNewKs(prev => ({ ...prev, country: e.target.value }))} className="input font-mono" placeholder="US" maxLength={2} />
            </div>
            <div>
              <label className="input-label">Password</label>
              <input type="password" value={newKs.password || ''} onChange={e => setNewKs(prev => ({ ...prev, password: e.target.value }))} className="input font-mono" placeholder="Min 6 characters" />
            </div>
            <div>
              <label className="input-label">Validity (years)</label>
              <input type="number" value={newKs.validityYears || 25} onChange={e => setNewKs(prev => ({ ...prev, validityYears: parseInt(e.target.value) || 25 }))} className="input" min={1} />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={handleSave} className="btn btn-primary btn-sm" disabled={!newKs.alias}>Generate</button>
            <button onClick={() => setShowNew(false)} className="btn btn-ghost btn-sm">Cancel</button>
          </div>
        </div>
      )}

      {/* Keystore list */}
      {keystores.length === 0 ? (
        <div className="card text-center py-10">
          <IconKey size={28} className="text-stone-600 mx-auto mb-3" />
          <p className="text-sm text-stone-400">No keystores configured.</p>
          <p className="text-xs text-stone-500 mt-1">Generate one above to use for signing builds.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {keystores.map(ks => (
            <div key={ks.alias} className="card card-compact">
              <div className="flex items-center gap-3">
                <IconKey size={18} className="text-sky-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold text-sm">{ks.alias}</span>
                    <span className="badge badge-neutral">{ks.validityYears}yr</span>
                  </div>
                  <div className="text-xs text-stone-500 mt-0.5">
                    {ks.cn && `${ks.cn} · `}{ks.org || 'No org'} · {ks.country}
                  </div>
                  {ks.sha256Fingerprint && (
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-stone-600 font-mono truncate max-w-xs">
                        SHA-256: {ks.sha256Fingerprint.slice(0, 32)}...
                      </span>
                      <button
                        onClick={() => onCopy(ks.sha256Fingerprint || '', `ks-${ks.alias}`)}
                        className="text-stone-500 hover:text-stone-300"
                        aria-label="Copy fingerprint"
                      >
                        {copied === `ks-${ks.alias}` ? <IconCheck size={12} className="text-emerald-400" /> : <IconCopy size={12} />}
                      </button>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(ks.alias)}
                  className="btn btn-ghost btn-sm text-red-400"
                  aria-label="Delete keystore"
                >
                  <IconTrash size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function generateMockFingerprint(): string {
  const chars = '0123456789ABCDEF';
  let result = '';
  for (let i = 0; i < 64; i++) {
    if (i > 0 && i % 2 === 0) result += ':';
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}