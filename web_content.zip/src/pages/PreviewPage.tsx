import { AudioLines, Eye, FileVideo2, ListChecks, Palette, PlayCircle, Timer, Waves } from "lucide-react";
import type { ViewKey } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { PlayerPreview } from "@/components/PreviewSurface";
import { Button, InlineNotice, SectionHeader } from "@/components/ui";
import { buildTimeline, formatClock } from "@/lib/timeline";
import { formatDuration } from "@/data/defaults";
import { validateProject, issueSummary } from "@/lib/preflight";

export function PreviewPage({ onNavigate }: { onNavigate: (view: ViewKey) => void }) {
  const { project, mediaUrls } = useStudio();
  const timeline = buildTimeline(project);
  const issues = validateProject(project, { availableMedia: new Set(Object.keys(mediaUrls)) });
  const summary = issueSummary(issues);

  return (
    <div>
      <SectionHeader
        icon={<PlayCircle size={18} />}
        eyebrow="معاينة الإنتاج"
        title="المعاينة الحية"
        description="شاهد الفيديو بالصوت والحركات قبل التصدير. المعاينة والتصدير يستخدمان نفس الخط الزمني ونفس منطق الرسم."
        actions={
          <>
            <Button variant="ghost" onClick={() => onNavigate("design")}><Palette size={14} /> تعديل التصميم</Button>
            <Button variant="primary" onClick={() => onNavigate("export")}><FileVideo2 size={14} /> تصدير الفيديو</Button>
          </>
        }
      />
      <PlayerPreview />

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <div className="panel p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="flex items-center gap-2 font-display text-[15px] font-bold text-white"><Timer size={15} className="text-[#d9b65a]" /> توقيت الأسئلة</h3>
            <span className="text-[10px] text-[#85858f]">{formatDuration(timeline.totalDuration)}</span>
          </div>
          <div className="max-h-[320px] space-y-1.5 overflow-y-auto pr-0.5">
            {timeline.scenes.map((scene) => (
              <div key={scene.questionId} className="flex items-center gap-2.5 rounded-lg border border-white/[0.06] bg-white/[0.018] px-2.5 py-2">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-white/[0.04] text-[10px] text-[#d8c089]">{scene.index + 1}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[11px] text-[#dedee4]">{scene.question.question || "سؤال بدون نص"}</p>
                  <p className="mt-0.5 flex flex-wrap gap-x-2 text-[9px] text-[#777781]">
                    <span>{formatClock(scene.timings.start)} → {formatClock(scene.timings.end)}</span>
                    <span className="text-[#a7d9bb]">إجابة {formatClock(scene.timings.start + scene.timings.revealStart)}</span>
                    <span>تفكير {scene.question.thinkSec} ث</span>
                  </p>
                </div>
                <span className={scene.audio.length ? "chip chip-mint !px-1.5 !py-0.5 !text-[8px]" : "chip !px-1.5 !py-0.5 !text-[8px]"}>{scene.audio.length ? `${scene.audio.length} صوت` : "صامت"}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <div className="panel p-4">
            <h3 className="mb-2 flex items-center gap-2 font-display text-[15px] font-bold text-white"><Waves size={15} className="text-[#57dc96]" /> التفاصيل الفنية</h3>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {[
                ["المقاس", `${project.exportSettings.width}×${project.exportSettings.height}`],
                ["معدل الإطارات", `${project.exportSettings.fps} إطار/ث`],
                ["عدد المشاهد", `${project.questions.length}`],
                ["ملفات الصوت", `${new Set(timeline.scenes.flatMap((scene) => scene.audio.map((clip) => clip.mediaId))).size}`],
                ["التوقيت", "موحد للمعاينة/التصدير"],
                ["المؤثرات", project.timing.sfxEnabled ? "مفعّلة" : "معطّلة"],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-white/[0.06] bg-white/[0.015] px-2.5 py-2">
                  <p className="text-[9px] text-[#75757f]">{label}</p>
                  <p className="mt-0.5 text-[11px] font-medium text-[#e7e7ec]" dir="auto">{value}</p>
                </div>
              ))}
            </div>
          </div>
          {summary.errors ? (
            <InlineNotice kind="error" title={`${summary.errors} أخطاء تمنع التصدير`}>
              راجع صفحة الأسئلة لاستكمال النصوص والإجابات والملفات. تصدير ملف غير مكتمل غير متاح.
            </InlineNotice>
          ) : summary.warnings ? (
            <InlineNotice kind="warning" title={`${summary.warnings} تنبيهات غير مانعة`}>
              يمكنك التصدير الآن، مع مراعاة أن بعض الأسئلة قد تعتمد على وقت صامت.
            </InlineNotice>
          ) : (
            <InlineNotice kind="success" title="المشروع جاهز للتصدير">
              لا توجد أخطاء مانعة في الفحص المسبق.
            </InlineNotice>
          )}
          <div className="flex gap-2">
            <Button variant="ghost" className="flex-1" onClick={() => onNavigate("questions")}><ListChecks size={14} /> تحرير الأسئلة</Button>
            <Button variant="ghost" className="flex-1" onClick={() => onNavigate("audio")}><AudioLines size={14} /> الصوت والتوقيت</Button>
          </div>
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.015] px-3 py-2.5 text-[10px] leading-5 text-[#81818b]">
            <span className="flex items-center gap-1.5 font-medium text-[#b8b8c2]"><Eye size={12} /> ملاحظة</span>
            الصوت لا يبدأ تلقائيًا على متصفحات الهاتف للحفاظ على سياسة التشغيل. اضغط زر التشغيل بوضوح.
          </div>
        </div>
      </div>
    </div>
  );
}
