/**
 * DisciplinePage.js — Habits, Routines, Prayer and the Weekly Review.
 * Habit logic is entirely delegated to habitsService.js (no duplication
 * with Dashboard, which uses the same service).
 */
import { weeklyFocus } from '../core/motivation/coach.js';
import { renderMasteryTab } from '../modules/mastery/masteryUI.js';
import {
  el, card, sectionHeader, checklistItem, button, xpBar, textareaInput, emptyState,
  tabs, statGrid, trendBadge, sliderField,
} from '../components/ui.js';
import { icon } from '../components/icons.js';
import { chartCanvas, renderBarChart, renderLineChart } from '../components/charts/canvasChart.js';
import { getAllHabits, habitStreak, habitCompletionPct, FREQUENCY } from '../modules/discipline/habits/habitsService.js';
import { openHabitForm } from '../modules/discipline/habits/habitForm.js';
import { getRoutineForToday, toggleRoutineStep } from '../modules/discipline/routines/routinesService.js';
import { submitWeeklyReview, getReviewHistory, getThisWeekReview } from '../modules/discipline/weeklyReview/weeklyReviewService.js';
import { thisAndLastWeek, delta, statsForWeek } from '../core/stats/statsService.js';
import { computeLifeScore, habitConsistencySeries } from '../core/scoring/scoreEngine.js';
import { buildPrayerCard } from '../components/prayerCard.js';
import { dailySeries } from '../core/stats/statsService.js';
import { startOfWeekISO, addDaysISO, formatFriendlyDate } from '../core/utils/dateUtils.js';
import { showToast } from '../core/notifications/toast.js';
import { navigate } from '../core/router.js';

let activeTab = 'habits';
let habitFilter = FREQUENCY.DAILY;

async function rerender(root) {
  root.innerHTML = '';
  await DisciplinePage(root);
}

async function renderHabitsTab(page, root) {
  page.append(tabs([
    { key: FREQUENCY.DAILY, label: 'Daily' }, { key: FREQUENCY.WEEKLY, label: 'Weekly' }, { key: FREQUENCY.CUSTOM, label: 'Custom' },
  ], habitFilter, async (k) => { habitFilter = k; await rerender(root); }));

  const all = await getAllHabits();
  const filtered = all.filter((h) => h.frequency === habitFilter);

  if (filtered.length === 0) {
    page.append(emptyState('No habits here yet', 'Add one below.'));
  } else {
    for (const h of filtered) {
      const streak = await habitStreak(h);
      const pct = await habitCompletionPct(h);
      const dayText = h.frequency === FREQUENCY.CUSTOM && h.days?.length ? ` · ${h.days.map((d) => ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'][d]).join(' ')}` : '';
      page.append(card([
        el('div', 'flex justify-between items-center', [
          el('span', null, h.name),
          streak > 0 ? el('span', 'streak-pill', [icon('flame'), `${streak}${h.frequency === FREQUENCY.WEEKLY ? 'w' : ''}`]) : null,
        ]),
        el('div', 'mt-4', xpBar(pct)),
        el('p', 'text-xs text-dim mt-1', `${pct}% consistency · ${h.domain}${dayText} · tap to edit`),
      ], { tappable: true, onClick: () => openHabitForm({ habit: h, onDone: () => rerender(root) }) }));
    }
  }

  page.append(el('div', 'mt-3', button('+ Add your own task / habit', { variant: 'ghost', block: true, onClick: () => openHabitForm({ defaultFrequency: habitFilter, onDone: () => rerender(root) }) })));
  page.append(el('p', 'text-xs text-dim mt-3', '🛡️ "Never miss twice": one missed day does not break a daily streak — two in a row do.'));
}

async function renderRoutinesTab(page, root) {
  const morning = await getRoutineForToday('morning');
  const evening = await getRoutineForToday('evening');

  page.append(sectionHeader('Morning', 'Routine'));
  page.append(card(morning.steps.map((s, i) => checklistItem(s.label, s.done, async (checked) => {
    await toggleRoutineStep('morning', i, checked);
    await rerender(root);
  }))));

  page.append(sectionHeader('Evening', 'Routine'));
  page.append(card(evening.steps.map((s, i) => checklistItem(s.label, s.done, async (checked) => {
    await toggleRoutineStep('evening', i, checked);
    await rerender(root);
  }))));
}

async function renderPrayerTab(page, root) {
  page.append(await buildPrayerCard({ full: true, onChange: () => rerender(root) }));
  const [prayers, c] = await Promise.all([dailySeries(14, 'prayers'), statsForWeek(startOfWeekISO())]);
  page.append(statGrid([
    { value: `${c.prayers}/35`, label: 'Prayers this week', hint: `${c.prayerPct}%` },
    { value: c.fastsKept, label: 'Fasts this week' },
  ]));
  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Prayers per day (14 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(sectionHeader(null, 'Consistency'), chartCard);
  requestAnimationFrame(() => renderBarChart(canvas, prayers, { maxOverride: 5 }));
  page.append(el('div', 'mt-3', button('Prayer settings (location & method)', { variant: 'ghost', block: true, onClick: () => navigate('/settings') })));
}

async function renderReviewTab(page, root) {
  const current = await getThisWeekReview();
  const history = await getReviewHistory(8);
  const { cur, prev } = await thisAndLastWeek();
  const scores = await computeLifeScore();

  page.append(sectionHeader(`Week of ${formatFriendlyDate(startOfWeekISO())}`, 'This week in numbers'));
  page.append(card([el('div', 'flex items-center gap-3', [el('div', 'stat-tile__value', `Life ${scores.life}`), el('span', 'text-xs text-dim', 'rolling 7 days')])]));
  const tile = (value, label, a, b) => ({ value, label, hint: `last week ${b}` , a });
  page.append(statGrid([
    { value: `${cur.habitPct}%`, label: 'Habits', hint: `last week ${prev.habitPct}%` },
    { value: `${cur.studyHours}h`, label: 'Study', hint: `last week ${prev.studyHours}h` },
    { value: cur.workouts, label: 'Workouts', hint: `last week ${prev.workouts}` },
    { value: cur.ankiCards, label: 'Anki cards', hint: `last week ${prev.ankiCards}` },
    { value: `${cur.prayers}/35`, label: 'Prayers', hint: `last week ${prev.prayers}` },
    { value: cur.waterAvgL ?? '–', label: 'Avg water (L)', hint: `last week ${prev.waterAvgL ?? '–'}` },
    { value: cur.skinDays, label: 'Skincare days', hint: `last week ${prev.skinDays}` },
    { value: cur.confidenceAvg ?? '–', label: 'Confidence avg', hint: 'out of 10' },
  ]));
  page.append(el('div', 'mt-2 flex items-center gap-2', [
    el('span', 'text-xs text-dim', 'Study vs last week:'), trendBadge(delta(cur.studyHours, prev.studyHours)),
    el('span', 'text-xs text-dim', 'Habits:'), trendBadge(delta(cur.habitPct, prev.habitPct)),
  ]));

  const cons = await habitConsistencySeries(7);
  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Habit completion by day (this week)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);

  // ---- reflection form ----
  page.append(sectionHeader(current ? 'Saved — you can update it' : null, 'Sunday reflection'));
  const d = current?.reflections || {};
  const wins = textareaInput({ placeholder: 'Wins this week', value: d.wins || '' });
  const misses = textareaInput({ placeholder: 'What slipped', value: d.misses || '' });
  const lesson = textareaInput({ placeholder: 'One lesson I learned', value: d.lesson || '', rows: 2 });
  const adjustments = textareaInput({ placeholder: 'Adjustments / focus for next week', value: d.adjustments || '' });
  const focus = await weeklyFocus();
  page.append(sectionHeader('From your numbers', 'Suggested focus for next week'));
  page.append(card([
    el('strong', null, `🎯 ${focus.title}`), el('p', 'text-xs text-dim mt-1', focus.why),
    el('div', 'mt-2', button('Use as my focus', { size: 'sm', variant: 'ghost', onClick: () => { adjustments.value = `${focus.title}. ${focus.why}`; showToast('Added to your adjustments.'); } })),
  ]));
  const rating = sliderField('How was this week? (1–10)', { min: 1, max: 10, value: current?.rating || 6 });
  page.append(card([
    wins, el('div', 'mt-3', misses), el('div', 'mt-3', lesson), el('div', 'mt-3', adjustments), el('div', 'mt-3', rating.node),
    el('div', 'mt-3', button(current ? 'Update review' : 'Submit review', { block: true, onClick: async () => {
      await submitWeeklyReview({ wins: wins.value, misses: misses.value, adjustments: adjustments.value, lesson: lesson.value, rating: rating.getValue() });
      showToast('Weekly review saved — nice consistency.');
      await rerender(root);
    } })),
  ]));

  // ---- history + life score trend ----
  page.append(sectionHeader(null, 'History'));
  const lifeSeries = history.slice().reverse().map((r) => ({ date: r.weekStartDate, value: r.metricsSnapshot?.life ?? 0 }));
  if (lifeSeries.length >= 2) {
    const lc = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Life Score by week')])]);
    const lcanvas = chartCanvas(100);
    lc.append(lcanvas);
    page.append(lc);
    requestAnimationFrame(() => renderLineChart(lcanvas, lifeSeries, { maxOverride: 100 }));
  }
  page.append(card(
    history.length === 0
      ? [emptyState('No reviews yet', 'Complete your first one above.')]
      : history.map((r) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', `${r.weekStartDate}${r.rating ? ` · ${r.rating}/10` : ''}`),
          el('span', 'text-xs text-dim', `Life ${r.metricsSnapshot?.life ?? '—'}`),
        ]))
  ));
  requestAnimationFrame(() => renderBarChart(canvas, cons.slice(-7), { maxOverride: 100, color: '#2A4DD0' }));
}

export async function DisciplinePage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Discipline'), el('p', 'page-subtitle', 'Habits · Routines · Mastery · Prayer · Weekly review'));
  page.append(tabs([
    { key: 'habits', label: 'Habits' }, { key: 'routines', label: 'Routines' },
    { key: 'mastery', label: 'Mastery' }, { key: 'prayer', label: 'Prayer' }, { key: 'review', label: 'Weekly Review' },
  ], activeTab, async (k) => { activeTab = k; await rerender(root); }));

  if (activeTab === 'habits') await renderHabitsTab(page, root);
  else if (activeTab === 'routines') await renderRoutinesTab(page, root);
  else if (activeTab === 'mastery') await renderMasteryTab(page, () => rerender(root));
  else if (activeTab === 'prayer') await renderPrayerTab(page, root);
  else await renderReviewTab(page, root);

  root.appendChild(page);
}
