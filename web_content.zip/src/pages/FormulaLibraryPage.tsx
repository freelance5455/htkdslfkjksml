import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Formula, Category } from '../types';
import { getFormulas, getCategories } from '../firebase/services';
import { FormulaCard } from '../components/formula/FormulaCard';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import { useApp } from '../context/AppContext';
import {
  Search,
  Filter,
  Bookmark,
  SlidersHorizontal,
  X,
  Compass,
  ArrowUpDown,
  BookOpen
} from 'lucide-react';

export const FormulaLibraryPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { isFavorite, favorites, playSound, triggerHaptic } = useApp();

  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState<string>(
    searchParams.get('category') || 'All'
  );
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'popularity' | 'title-asc' | 'title-desc'>('popularity');
  const [favoritesOnly, setFavoritesOnly] = useState<boolean>(false);

  useEffect(() => {
    async function loadData() {
      try {
        const [fList, cList] = await Promise.all([getFormulas(), getCategories()]);
        setFormulas(fList);
        setCategories(cList);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Sync URL search param if changed externally
  useEffect(() => {
    const urlSearch = searchParams.get('search');
    if (urlSearch !== null && urlSearch !== searchQuery) {
      setSearchQuery(urlSearch);
    }
  }, [searchParams]);

  // Filter and Sort Memo
  const filteredFormulas = useMemo(() => {
    return formulas
      .filter((formula) => {
        // Favorites filter
        if (favoritesOnly && !isFavorite(formula.id)) {
          return false;
        }

        // Category filter
        if (
          selectedCategory !== 'All' &&
          formula.category.toLowerCase() !== selectedCategory.toLowerCase()
        ) {
          return false;
        }

        // Difficulty filter
        if (
          selectedDifficulty !== 'All' &&
          formula.difficulty !== selectedDifficulty
        ) {
          return false;
        }

        // Search Query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const titleMatch = formula.title.toLowerCase().includes(q);
          const formulaMatch = formula.formula.toLowerCase().includes(q);
          const descMatch = formula.description.toLowerCase().includes(q);
          const catMatch = formula.category.toLowerCase().includes(q);
          const subcatMatch = formula.subcategory.toLowerCase().includes(q);
          const tagMatch = formula.tags.some((t) => t.toLowerCase().includes(q));
          const varMatch = formula.variables.some(
            (v) =>
              v.name.toLowerCase().includes(q) ||
              v.symbol.toLowerCase().includes(q) ||
              v.unit.toLowerCase().includes(q)
          );
          const unitMatch = formula.units?.some((u: string) => u.toLowerCase().includes(q)) ?? false;

          if (
            !titleMatch &&
            !formulaMatch &&
            !descMatch &&
            !catMatch &&
            !subcatMatch &&
            !tagMatch &&
            !varMatch &&
            !unitMatch
          ) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'popularity') return b.popularity - a.popularity;
        if (sortBy === 'title-asc') return a.title.localeCompare(b.title);
        if (sortBy === 'title-desc') return b.title.localeCompare(a.title);
        return 0;
      });
  }, [
    formulas,
    favoritesOnly,
    favorites,
    selectedCategory,
    selectedDifficulty,
    searchQuery,
    sortBy
  ]);

  const clearAllFilters = () => {
    playSound('button');
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedDifficulty('All');
    setFavoritesOnly(false);
    setSortBy('popularity');
    setSearchParams({});
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-[#D65A1F]" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
              Formula Library
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-[#A9A39C]">
            Search, filter, and calculate from over {formulas.length} verified mathematical, physical, and engineering laws.
          </p>
        </div>

        {/* Total Badge */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono px-3.5 py-1.5 rounded-xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED]">
            Showing <strong className="text-[#D65A1F]">{filteredFormulas.length}</strong> of {formulas.length} formulas
          </span>
        </div>
      </div>

      {/* Control Bar: Search, Category, Difficulty, Sort, Favorites */}
      <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-4 sm:p-5 shadow-xl space-y-4">
        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A9A39C]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, symbol (e.g. F, v, ρ), unit (N, Pa, J), or tag..."
            className="w-full pl-10 pr-10 py-3 rounded-2xl bg-[#151515] border border-[#303030] text-[#F5F2ED] placeholder-[#A9A39C] text-sm focus:outline-none focus:border-[#D65A1F] transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-[#A9A39C] hover:text-[#F5F2ED]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Dropdowns & Toggles */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          {/* Category Dropdown */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-[#A9A39C] uppercase tracking-wider font-mono">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => {
                playSound('tab');
                setSelectedCategory(e.target.value);
              }}
              className="w-full px-3 py-2.5 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] focus:outline-none focus:border-[#D65A1F]"
            >
              <option value="All">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.slug}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Difficulty Dropdown */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-[#A9A39C] uppercase tracking-wider font-mono">
              Difficulty
            </label>
            <select
              value={selectedDifficulty}
              onChange={(e) => {
                playSound('tab');
                setSelectedDifficulty(e.target.value);
              }}
              className="w-full px-3 py-2.5 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] focus:outline-none focus:border-[#D65A1F]"
            >
              <option value="All">All Difficulties</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          {/* Sort By Dropdown */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-[#A9A39C] uppercase tracking-wider font-mono">
              Sort By
            </label>
            <select
              value={sortBy}
              onChange={(e) => {
                playSound('tab');
                setSortBy(e.target.value as any);
              }}
              className="w-full px-3 py-2.5 rounded-xl bg-[#151515] border border-[#303030] text-[#F5F2ED] focus:outline-none focus:border-[#D65A1F]"
            >
              <option value="popularity">Popularity (High to Low)</option>
              <option value="title-asc">Title (A to Z)</option>
              <option value="title-desc">Title (Z to A)</option>
            </select>
          </div>

          {/* Favorites Filter Toggle */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-[#A9A39C] uppercase tracking-wider font-mono">
              Favorites Filter
            </label>
            <button
              onClick={() => {
                playSound('button');
                triggerHaptic('light');
                setFavoritesOnly(!favoritesOnly);
              }}
              className={`w-full flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl border transition-colors ${
                favoritesOnly
                  ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] font-bold'
                  : 'bg-[#151515] text-[#A9A39C] hover:text-[#F5F2ED] border-[#303030]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" fill={favoritesOnly ? '#D65A1F' : 'none'} />
              <span>{favoritesOnly ? 'Favorites Only' : 'All Formulas'}</span>
            </button>
          </div>
        </div>

        {/* Active Filters Reset */}
        {(searchQuery || selectedCategory !== 'All' || selectedDifficulty !== 'All' || favoritesOnly) && (
          <div className="pt-2 flex items-center justify-between border-t border-[#303030] text-xs">
            <span className="text-[#A9A39C]">Filters active</span>
            <button
              onClick={clearAllFilters}
              className="text-[#D65A1F] hover:underline flex items-center gap-1 font-semibold"
            >
              <X className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        )}
      </div>

      {/* Grid of Results */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : filteredFormulas.length === 0 ? (
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-12 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#232323] border border-[#303030] flex items-center justify-center mx-auto text-[#A9A39C]">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-[#F5F2ED]">
            No matching formulas found
          </h3>
          <p className="text-xs text-[#A9A39C] max-w-md mx-auto leading-relaxed">
            No formulas match your active filter criteria. Try adjusting your query or resetting filters.
          </p>
          <button
            onClick={clearAllFilters}
            className="px-4 py-2 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-xs transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredFormulas.map((f) => (
            <FormulaCard key={f.id} formula={f} />
          ))}
        </div>
      )}
    </div>
  );
};
