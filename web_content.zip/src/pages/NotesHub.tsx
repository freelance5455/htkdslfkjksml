import { useMemo, useState } from 'react';
import { BookOpen, Download, Pencil, Search, StickyNote, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Card, SectionHeader } from '../components/ui/Card';
import { EmptyState, Modal } from '../components/ui/Feedback';
import { subjects, getLesson } from '../data/content';
import type { VideoNote } from '../types';
import { useToast } from '../hooks/useToast';
import { deleteNote, exportNotesBundle, formatStamp, updateNote } from '../services/notes';
import { KEYS, useStored } from '../services/storage';

interface NoteEntry {
  subjectId: string;
  subjectName: string;
  lessonId: string;
  lessonTitle: string;
  unitTitle: string;
  note: VideoNote;
}

export default function NotesHub() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const notesByLesson = useStored(KEYS.notes, {} as Record<string, VideoNote[]>);
  const [query, setQuery] = useState('');
  const [filterSubject, setFilterSubject] = useState('all');
  const [filterLesson, setFilterLesson] = useState('all');
  const [editing, setEditing] = useState<NoteEntry | null>(null);
  const [draft, setDraft] = useState('');
  const [deleting, setDeleting] = useState<NoteEntry | null>(null);

  const allNotes = useMemo<NoteEntry[]>(() => Object.entries(notesByLesson).flatMap(([lessonId, notes]) => {
    const lesson = getLesson(lessonId);
    const subject = lesson ? subjects.find((item) => item.id === lesson.subjectId) : undefined;
    const unitTitle = subject?.units.find((unit) => unit.id === lesson?.unitId)?.title ?? 'وحدة غير محددة';
    if (!lesson || !subject || !Array.isArray(notes)) return [];
    return notes.map((note) => ({ subjectId: subject.id, subjectName: subject.name, lessonId, lessonTitle: lesson.title, unitTitle, note }));
  }).sort((a, b) => (b.note.updatedAt ?? b.note.createdAt) - (a.note.updatedAt ?? a.note.createdAt)), [notesByLesson]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase('ar');
    return allNotes.filter((entry) => {
      if (filterSubject !== 'all' && entry.subjectId !== filterSubject) return false;
      if (filterLesson !== 'all' && entry.lessonId !== filterLesson) return false;
      if (!needle) return true;
      return `${entry.note.text} ${entry.lessonTitle} ${entry.subjectName} ${entry.unitTitle}`.toLocaleLowerCase('ar').includes(needle);
    });
  }, [allNotes, filterLesson, filterSubject, query]);

  const lessonsForSubject = filterSubject === 'all'
    ? [...new Map(allNotes.map((entry) => [entry.lessonId, entry])).values()]
    : [...new Map(allNotes.filter((entry) => entry.subjectId === filterSubject).map((entry) => [entry.lessonId, entry])).values()];

  const openNote = (entry: NoteEntry) => navigate(`/lesson/${entry.subjectId}/${entry.lessonId}?t=${entry.note.time}`);
  const saveEdit = () => {
    if (!editing || !draft.trim()) return;
    const saved = updateNote(editing.lessonId, editing.note.id, draft);
    if (!saved) {
      toast('تعذّر حفظ التعديل على هذا الجهاز؛ أفرغ مساحة التخزين وحاول مجدداً.', 'error');
      return;
    }
    setEditing(null);
    toast('حُدّثت الملاحظة على جهازك.', 'success');
  };
  const remove = () => {
    if (!deleting) return;
    const deleted = deleteNote(deleting.lessonId, deleting.note.id);
    if (!deleted) {
      toast('تعذّر حذف الملاحظة من التخزين المحلي.', 'error');
      return;
    }
    setDeleting(null);
    toast('حُذفت الملاحظة من هذا الجهاز.', 'info');
  };

  return (
    <div>
      <PageHeader
        eyebrow="دفترك الدراسي المحلي"
        title="مركز الملاحظات"
        subtitle="كل ملاحظات الدروس في مكان واحد. افتح ختم الوقت للعودة إلى لحظة كتابتها داخل مشغل الدرس."
        back="/"
        action={<Button className="min-h-11" size="sm" variant="outline" icon={<Download size={15} />} disabled={!filtered.length} onClick={() => exportNotesBundle(filtered.map(({ subjectName, lessonTitle, note }) => ({ subjectName, lessonTitle, note })))}>تصدير النص</Button>}
      />

      <Card className="mb-4">
        <div className="relative">
          <Search size={17} className="pointer-events-none absolute start-3 top-3.5 text-[var(--ink-soft)]" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="بحث في كل الملاحظات" placeholder="ابحث في نص الملاحظات والدروس…" className="focus-ring h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] pe-3 ps-10 text-sm text-[var(--ink)]" />
        </div>
        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          <label className="text-xs text-[var(--ink-soft)]">المادة<select value={filterSubject} onChange={(event) => { setFilterSubject(event.target.value); setFilterLesson('all'); }} className="focus-ring mt-1 h-11 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]"><option value="all">كل المواد</option>{subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}</select></label>
          <label className="text-xs text-[var(--ink-soft)]">الدرس<select value={filterLesson} onChange={(event) => setFilterLesson(event.target.value)} className="focus-ring mt-1 h-11 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]"><option value="all">كل الدروس</option>{lessonsForSubject.map((entry) => <option key={entry.lessonId} value={entry.lessonId}>{entry.lessonTitle}</option>)}</select></label>
        </div>
        <p className="mt-2 text-[0.68rem] text-[var(--ink-soft)]">{filtered.length} ملاحظة · محفوظة محلياً ولا تُرفع إلى خادم</p>
      </Card>

      <SectionHeader title="ملاحظاتي" hint="مرتبة من الأحدث إلى الأقدم." />
      {filtered.length ? <div className="space-y-2">
        {filtered.map((entry) => <Card key={`${entry.lessonId}-${entry.note.id}`} className="p-3">
          <div className="flex items-start gap-2">
            <button type="button" onClick={() => openNote(entry)} aria-label={`افتح ${entry.lessonTitle} عند ${formatStamp(entry.note.time)}`} className="focus-ring mt-0.5 flex min-h-11 shrink-0 items-center gap-1 rounded-xl bg-[var(--gold-soft)] px-2.5 font-mono text-xs text-[#8a5b06] dark:text-[var(--gold)]"><BookOpen size={13} />{formatStamp(entry.note.time)}</button>
            <div className="min-w-0 flex-1">
              <button type="button" onClick={() => openNote(entry)} className="focus-ring min-h-11 text-start font-display text-sm text-[var(--ink)] hover:underline">{entry.lessonTitle}</button>
              <p className="text-[0.68rem] text-[var(--ink-soft)]">{entry.subjectName} · {entry.unitTitle}</p>
              <p className="mt-2 whitespace-pre-wrap break-words text-sm leading-relaxed text-[var(--ink)]">{entry.note.text}</p>
              <p className="mt-2 text-[0.62rem] text-[var(--ink-soft)]">{new Date(entry.note.updatedAt ?? entry.note.createdAt).toLocaleString('ar-SY')}</p>
            </div>
            <div className="flex shrink-0 flex-col gap-1">
              <button type="button" onClick={() => { setEditing(entry); setDraft(entry.note.text); }} aria-label="تعديل الملاحظة" className="focus-ring flex h-11 w-11 items-center justify-center rounded-xl text-[var(--ink-soft)] hover:bg-[var(--surface-2)]"><Pencil size={14} /></button>
              <button type="button" onClick={() => setDeleting(entry)} aria-label="حذف الملاحظة" className="focus-ring flex h-11 w-11 items-center justify-center rounded-xl text-[var(--ink-soft)] hover:text-[var(--danger)]"><Trash2 size={14} /></button>
            </div>
          </div>
        </Card>)}
      </div> : <EmptyState icon={<StickyNote size={19} />} title={allNotes.length ? 'لا تطابق الملاحظات هذا البحث' : 'دفترك فارغ حالياً'} description={allNotes.length ? 'جرّب كلمة أو مادة أخرى، أو أزل أحد المرشحين.' : 'أضف ملاحظة أثناء مشاهدة أي درس، وستظهر هنا مع ختم وقتها.'} />}

      <Modal open={editing !== null} onClose={() => setEditing(null)} title="تعديل الملاحظة" footer={<div className="flex gap-2"><Button block onClick={saveEdit} disabled={!draft.trim()}>حفظ التعديل</Button><Button variant="outline" onClick={() => setEditing(null)}>إلغاء</Button></div>}>
        <p className="mb-2 text-xs text-[var(--ink-soft)]">{editing?.subjectName} · {editing?.lessonTitle} · {editing ? formatStamp(editing.note.time) : ''}</p>
        <textarea value={draft} onChange={(event) => setDraft(event.target.value)} rows={5} maxLength={5000} autoFocus aria-label="نص الملاحظة" className="focus-ring w-full resize-y rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3 text-sm text-[var(--ink)]" />
      </Modal>

      <Modal open={deleting !== null} onClose={() => setDeleting(null)} title="حذف الملاحظة؟" footer={<div className="flex gap-2"><Button block variant="danger" onClick={remove}>حذف</Button><Button variant="outline" onClick={() => setDeleting(null)}>إلغاء</Button></div>}>
        <p className="text-sm leading-relaxed text-[var(--ink-soft)]">سيُحذف هذا النص من التخزين المحلي لهذا الجهاز.</p>
      </Modal>
    </div>
  );
}
