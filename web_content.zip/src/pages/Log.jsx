import React from 'react';
import { CalsenBase } from '../lib/CalsenBase';
import { go, ROUTES, css } from '../lib/calsen';
import BottomNav from '../components/BottomNav';
import { MEAL_ART } from '../assets/mealArt';

export default class LogPage extends CalsenBase {
  static defaultProps = {"accent": "#FF5C00", "theme": "sync"};

  scans() {
    try { const v = JSON.parse(window.localStorage.getItem('calsen-log') || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }
  renderVals() {
    const st = this.state || {};
    const off = st.off ?? 0;
    const mode = this.modeNow();
    const dark = this.isDark(mode);
    const base = this.props.accent ?? '#FF5C00';
    const accent = this.accentFor(base, dark);
    const accentInk = dark ? '#FF9A5C' : '#C2410C';
    const fmt = (n) => Math.round(n).toLocaleString('en-US');
    const MOONI = 'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z';
    const SUNI = 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M12 3v2 M12 19v2 M3 12h2 M19 12h2 M5.6 5.6l1.4 1.4 M17 17l1.4 1.4 M5.6 18.4L7 17 M17 7l1.4-1.4';
    const ICONS = [
      'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M12 3v2 M12 19v2 M3 12h2 M19 12h2 M5.6 5.6l1.4 1.4 M17 17l1.4 1.4 M5.6 18.4L7 17 M17 7l1.4-1.4',
      'M3 11h18a9 9 0 0 1-18 0z M8 7c0-1 1-1.5 1-3 M13 7c0-1 1-1.5 1-3',
      'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z',
      'M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5z M8.5 8.5v.01 M16 15.5v.01 M12 12v.01 M11 17v.01 M7 14v.01'
    ];
    const MEALS = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'];
    const GOAL = 2000;
    const TODAY_KEY = '2026-10-09';
    const KC = { '-14': 1940, '-13': 0, '-12': 2210, '-11': 1880, '-10': 2125, '-9': 0, '-8': 1975, '-7': 2320, '-6': 1850, '-5': 2150, '-4': 0, '-3': 2040 };
    const split = (k, i) => {
      if (!k) return [[0, 0], [0, 0], [0, 0], [0, 0]];
      const b = Math.round(k * 0.24 / 10) * 10, l = Math.round(k * 0.38 / 10) * 10, sn = Math.round(k * 0.08 / 10) * 10;
      return [[b, 3], [l, 4], [k - b - l - sn, 3], [sn, 1 + (i % 2)]];
    };
    let meals, P, C, F;
    if (off === -2) { meals = [[480, 3], [720, 4], [640, 3], [120, 1]]; P = 138; C = 201; F = 64; }
    else if (off === -1) { meals = [[510, 3], [790, 4], [640, 3], [225, 2]]; P = 151; C = 214; F = 71; }
    else if (off === 0) { meals = [[420, 3], [820, 4], [0, 0], [0, 0]]; P = 92; C = 120; F = 43; }
    else {
      const k = KC[String(off)] || 0;
      meals = split(k, off + 14);
      P = Math.round(k * 0.3 / 4); C = Math.round(k * 0.4 / 4); F = Math.round(k * 0.3 / 9);
    }
    const allScans = this.scans();
    const dayKey = off === 0 ? TODAY_KEY : '';
    const scans = allScans.filter((x) => x.date === dayKey);
    meals = meals.map((m) => [m[0], m[1]]);
    scans.forEach((x) => {
      if (meals[x.meal]) { meals[x.meal][0] += x.kcal; meals[x.meal][1] += 1; }
      P += x.p || 0; C += x.c || 0; F += x.f || 0;
    });
    const eaten = meals.reduce((a, m) => a + m[0], 0);

    const POOLS = [
      [['Oatmeal with berries', '1 bowl'], ['Boiled eggs', '2 eggs'], ['Greek yogurt', '170 g'], ['Whole-wheat toast', '2 slices'], ['Banana', '1 medium'], ['Orange juice', '1 glass']],
      [['Grilled chicken breast', '150 g'], ['Brown rice', '1 cup'], ['Mixed green salad', '1 bowl'], ['Lentil soup', '1 bowl'], ['Hummus and pita', '1 serving'], ['Tuna sandwich', '1 sandwich']],
      [['Baked salmon', '180 g'], ['Roasted vegetables', '1 cup'], ['Quinoa', '3/4 cup'], ['Beef stir-fry', '1 plate'], ['Whole-wheat pasta', '1.5 cups'], ['Olive oil', '1 tbsp']],
      [['Almonds', '30 g'], ['Apple', '1 medium'], ['Protein bar', '1 bar'], ['Dates', '3 pieces']]
    ];
    const W = [0.45, 0.3, 0.15, 0.1];
    const baseItems = (mi, kcal, n) => {
      if (!n) return [];
      const pool = POOLS[mi];
      const start = (off + 14 + mi * 2) % pool.length;
      const ws = W.slice(0, n);
      const sw = ws.reduce((a, b) => a + b, 0);
      let left = kcal;
      return ws.map((w, j) => {
        const k = j === n - 1 ? left : Math.round((kcal * w) / sw);
        left -= k;
        const it = pool[(start + j) % pool.length];
        return { name: it[0], por: it[1], kcal: fmt(k) };
      });
    };
    const IMG = MEAL_ART;
    const rows = [];
    MEALS.forEach((name, mi) => {
      const mine = scans.filter((x) => x.meal === mi);
      const scanKcal = mine.reduce((a, x) => a + x.kcal, 0);
      const baseK = meals[mi][0] - scanKcal;
      const baseN = meals[mi][1] - mine.length;
      const list = baseItems(mi, baseK, baseN);
      const count = meals[mi][1];
      const lines = mine.map((x) => ({ type: 'scan', name: x.name, por: x.n + (x.n === 1 ? ' food' : ' foods'), kcal: fmt(x.kcal), thumb: x.thumb || '' }))
        .concat(list.map((x) => Object.assign({ type: 'item' }, x)));
      if (!lines.length) lines.push({ type: 'empty', text: off === 0 ? 'Nothing logged yet. Tap + to scan a meal.' : 'Nothing logged.' });
      const lastScan = mine.length ? mine[mine.length - 1] : null;
      rows.push({
        type: 'head', name, icon: ICONS[mi], kcal: fmt(meals[mi][0]),
        sub: count ? count + (count === 1 ? ' item' : ' items') : 'Nothing logged yet',
        addLabel: 'Scan food for ' + name.toLowerCase(), first: mi === 0,
        banner: lastScan && lastScan.thumb ? lastScan.thumb : IMG[mi],
        photoAlt: lastScan ? lastScan.name : name + ' photo',
        imgFilter: count ? 'none' : 'grayscale(0.85) brightness(0.8)',
        go: () => { try { window.localStorage.setItem('calsen-meal', String(mi)); } catch (e) {} }
      });
      lines.forEach((l) => rows.push(l));
      rows.push({ type: 'end' });
    });
    const out = rows.map((r, i) => {
      const prev = rows[i - 1];
      const next = rows[i + 1];
      const isHead = r.type === 'head';
      const isEnd = r.type === 'end';
      const topEdge = isHead;
      const bottomEdge = isEnd;
      return {
        isHead, isEnd, isItem: r.type === 'item', isScan: r.type === 'scan', isEmpty: r.type === 'empty',
        name: r.name, por: r.por, kcal: r.kcal, sub: r.sub, icon: r.icon, thumb: r.thumb, text: r.text, addLabel: r.addLabel, banner: r.banner, photoAlt: r.photoAlt, imgFilter: r.imgFilter, go: r.go,
        mt: isHead && !r.first ? '12px' : '0',
        radius: topEdge ? '24px 24px 0 0' : bottomEdge ? '0 0 24px 24px' : '0',
        bw: topEdge ? '1px 1px 0 1px' : bottomEdge ? '0 1px 1px 1px' : '0 1px 0 1px'
      };
    });

    const cur = this.tw({ eaten, P, C, F }, 480);
    const pct = Math.round((eaten / GOAL) * 100);
    const pctCur = Math.round((cur.eaten / GOAL) * 100);
    const over = eaten > GOAL;
    let pill;
    if (!eaten) pill = { text: 'Nothing logged', bg: 'var(--chip)', ink: 'var(--muted)' };
    else if (over) pill = { text: fmt(eaten - GOAL) + ' kcal over', bg: 'var(--danger-bg)', ink: 'var(--danger)' };
    else pill = { text: fmt(GOAL - eaten) + ' kcal left', bg: 'var(--soft-bg)', ink: 'var(--soft-ink)' };

    const names = ['Today', 'Yesterday'];
    const dt = new Date(2026, 9, 9 + off);
    const fmtDate = dt.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const photos = allScans.filter((x) => x.thumb).slice().reverse().slice(0, 9).map((x) => ({ src: x.thumb, alt: x.name, kcal: fmt(x.kcal) }));

    return {
      accent, accentInk,
      glow: this.glowOf(accent, dark ? 0.45 : 0.3),
      numGlow: dark ? '0 0 20px ' + this.glowOf(accent, 0.4) : 'none',
      themeKey: dark ? 'dark' : 'light',
      themeIcon: dark ? SUNI : MOONI,
      themeAria: dark ? 'Switch to light mode' : 'Switch to dark mode',
      toggleTheme: () => this.setMode(dark ? 'light' : 'dark'),
      dayTitle: off === 0 ? 'Today' : off === -1 ? 'Yesterday' : fmtDate,
      daySub: off === 0 || off === -1 ? fmtDate : (-off) + ' days ago',
      prevDay: () => this.setState({ off: Math.max(-14, off - 1) }),
      nextDay: () => this.setState({ off: Math.min(0, off + 1) }),
      prevOpacity: off <= -14 ? '0.35' : '1',
      nextOpacity: off >= 0 ? '0.35' : '1',
      eaten: fmt(Math.round(cur.eaten)), goal: fmt(GOAL), pill,
      pctNum: String(Math.min(100, pct)), barW: Math.min(100, pctCur) + '%',
      barBg: over ? 'var(--danger)' : 'linear-gradient(90deg, ' + accent + ', ' + this.lighten(accent, 0.28) + ')',
      barGlow: dark ? '0 0 12px ' + this.glowOf(over ? '#F87171' : accent, 0.5) : 'none',
      macros: [{ label: 'Protein', color: this.macroSet(dark).P.color, g: fmt(Math.round(cur.P)) }, { label: 'Carbs', color: this.macroSet(dark).C.color, g: fmt(Math.round(cur.C)) }, { label: 'Fat', color: this.macroSet(dark).F.color, g: fmt(Math.round(cur.F)) }],
      rows: out,
      photos, hasPhotos: photos.length > 0, noPhotos: photos.length === 0,
      photoCount: photos.length ? photos.length + (photos.length === 1 ? ' photo' : ' photos') : ''
    };
  }

  render() {
    const v = this.renderVals();
    return (
      <div
        className="app"
        data-theme={v.themeKey}
        style={{
          position: 'relative',
          width: '390px',
          height: '844px',
          boxSizing: 'border-box',
          fontFamily: '\'Plus Jakarta Sans\', system-ui, sans-serif',
          overflow: 'hidden',
        }}
      >
        <div
          className="scroll"
          style={{
            position: 'absolute',
            left: '0',
            top: '0',
            right: '0',
            bottom: '0',
            overflowY: 'auto',
            overflowX: 'hidden',
            overscrollBehavior: 'contain',
          }}
        >
          <div
            className="stagger"
            style={{
              boxSizing: 'border-box',
              padding: '24px 20px 120px 20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
            }}
          >
            <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h1
                style={{
                  margin: '0',
                  fontSize: '28px',
                  lineHeight: '34px',
                  fontWeight: '800',
                  letterSpacing: '-0.03em',
                }}
              >Food log</h1>
              <button className="rbtn" aria-label={v.themeAria} onClick={v.toggleTheme}>
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d={v.themeIcon}></path>
                </svg>
              </button>
            </header>
            <div
              className="glass"
              style={{
                borderRadius: '24px',
                height: '56px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '0 8px',
              }}
            >
              <button
                className="rbtn"
                aria-label="Previous day"
                style={{ opacity: v.prevOpacity, boxShadow: 'none' }}
                onClick={v.prevDay}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M15 5l-7 7 7 7"></path>
                </svg>
              </button>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <span style={{ fontSize: '16px', lineHeight: '20px', fontWeight: '800' }}>{v.dayTitle}</span>
                <span
                  style={{
                    fontSize: '12px',
                    lineHeight: '16px',
                    fontWeight: '600',
                    color: 'var(--muted)',
                  }}
                >{v.daySub}</span>
              </div>
              <button
                className="rbtn"
                aria-label="Next day"
                style={{ opacity: v.nextOpacity, boxShadow: 'none' }}
                onClick={v.nextDay}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M9 5l7 7-7 7"></path>
                </svg>
              </button>
            </div>
            <section
              aria-label="Day summary"
              className="glass"
              style={{
                borderRadius: '24px',
                padding: '18px',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-end',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '8px',
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                  <span style={{ fontSize: '14px', fontWeight: '700', color: 'var(--muted)' }}>Eaten (kcal)</span>
                  <span style={{ display: 'flex', alignItems: 'baseline', gap: '6px' }}>
                    <span
                      style={{
                        fontSize: '38px',
                        lineHeight: '42px',
                        fontWeight: '800',
                        letterSpacing: '-0.03em',
                        color: v.accent,
                        textShadow: v.numGlow,
                      }}
                    >{v.eaten}</span>
                    <span style={{ fontSize: '17px', fontWeight: '700', color: 'var(--muted)' }}>/ {v.goal}</span>
                  </span>
                </div>
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    height: '28px',
                    padding: '0 12px',
                    borderRadius: '14px',
                    background: v.pill.bg,
                    color: v.pill.ink,
                    fontSize: '13px',
                    fontWeight: '800',
                    whiteSpace: 'nowrap',
                    marginBottom: '4px',
                  }}
                >{v.pill.text}</span>
              </div>
              <div
                role="progressbar"
                aria-label="Daily calorie goal"
                aria-valuemin="0"
                aria-valuemax="100"
                aria-valuenow={v.pctNum}
                style={{
                  height: '10px',
                  borderRadius: '5px',
                  background: 'var(--track)',
                  overflow: 'hidden',
                }}
              >
                <div
                  style={{
                    width: v.barW,
                    height: '100%',
                    borderRadius: '5px',
                    background: v.barBg,
                    boxShadow: v.barGlow,
                  }}
                ></div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '8px' }}>
                {v.macros.map((m, i1) => (
                  <React.Fragment key={i1}>
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '2px',
                        padding: '10px 12px',
                        borderRadius: '16px',
                        background: 'var(--tile)',
                        border: '1px solid var(--edge)',
                      }}
                    >
                      <span
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          fontSize: '12px',
                          fontWeight: '700',
                          color: 'var(--muted)',
                        }}
                      >
                        <span
                          style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '4px',
                            background: m.color,
                          }}
                        ></span>
                        {m.label}
                      </span>
                      <span
                        style={{
                          fontSize: '18px',
                          lineHeight: '22px',
                          fontWeight: '800',
                          letterSpacing: '-0.02em',
                        }}
                      >
                        {m.g}
                        <span style={{ fontSize: '12px', fontWeight: '700', color: 'var(--muted)' }}>{' '}g</span>
                      </span>
                    </div>
                  </React.Fragment>
                ))}
              </div>
            </section>
            <section aria-label="Meals" style={{ display: 'flex', flexDirection: 'column' }}>
              {v.rows.map((r, i1) => (
                <React.Fragment key={i1}>
                  <div
                    style={{
                      marginTop: r.mt,
                      borderRadius: r.radius,
                      background: 'var(--glass)',
                      borderStyle: 'solid',
                      borderColor: 'var(--edge)',
                      borderWidth: r.bw,
                      boxSizing: 'border-box',
                      overflow: 'hidden',
                    }}
                  >
                    {r.isHead && (
                      <>
                        <div
                          style={{
                            position: 'relative',
                            height: '128px',
                            borderRadius: '24px 24px 0 0',
                            overflow: 'hidden',
                            background: 'var(--track)',
                          }}
                        >
                          <img
                            src={r.banner}
                            alt={r.photoAlt}
                            style={{
                              position: 'absolute',
                              left: '0',
                              top: '0',
                              width: '100%',
                              height: '100%',
                              objectFit: 'cover',
                              filter: r.imgFilter,
                            }}
                           />
                          <div
                            aria-hidden="true"
                            style={{
                              position: 'absolute',
                              left: '0',
                              top: '0',
                              right: '0',
                              bottom: '0',
                              background: 'linear-gradient(180deg, rgba(5,8,13,0.04) 25%, rgba(5,8,13,0.8) 100%)',
                            }}
                          ></div>
                          <div
                            style={{
                              position: 'absolute',
                              left: '16px',
                              right: '12px',
                              bottom: '12px',
                              display: 'flex',
                              alignItems: 'flex-end',
                              justifyContent: 'space-between',
                              gap: '10px',
                              color: '#FFFFFF',
                            }}
                          >
                            <div
                              style={{
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '1px',
                                minWidth: '0',
                              }}
                            >
                              <span
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px',
                                  fontSize: '21px',
                                  lineHeight: '27px',
                                  fontWeight: '800',
                                  letterSpacing: '-0.02em',
                                }}
                              >
                                <svg
                                  width="19"
                                  height="19"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="1.9"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  aria-hidden="true"
                                >
                                  <path d={r.icon}></path>
                                </svg>
                                {r.name}
                              </span>
                              <span
                                style={{
                                  fontSize: '13px',
                                  lineHeight: '18px',
                                  fontWeight: '600',
                                  opacity: '0.85',
                                }}
                              >{r.sub}</span>
                            </div>
                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '10px',
                                flex: 'none',
                              }}
                            >
                              <span style={{ display: 'flex', alignItems: 'baseline', gap: '3px' }}>
                                <span style={{ fontSize: '22px', fontWeight: '800', letterSpacing: '-0.02em' }}>{r.kcal}</span>
                                <span style={{ fontSize: '12px', fontWeight: '700', opacity: '0.8' }}>kcal</span>
                              </span>
                              <a
                                href={ROUTES.scanner}
                                className="press"
                                aria-label={r.addLabel}
                                style={{
                                  width: '42px',
                                  height: '42px',
                                  borderRadius: '21px',
                                  background: '#FFFFFF',
                                  color: '#0B1220',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  textDecoration: 'none',
                                }}
                                onClick={(e) => { r.go(e); go(e, 'scanner', this.props); }}
                              >
                                <svg
                                  width="19"
                                  height="19"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2.6"
                                  strokeLinecap="round"
                                  aria-hidden="true"
                                >
                                  <path d="M12 5v14"></path>
                                  <path d="M5 12h14"></path>
                                </svg>
                              </a>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                    {r.isItem && (
                      <>
                        <div
                          style={{
                            margin: '0 14px',
                            borderTop: '1px solid var(--line)',
                            padding: '12px 0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: '12px',
                          }}
                        >
                          <div style={{ display: 'flex', flexDirection: 'column', minWidth: '0' }}>
                            <span style={{ fontSize: '15px', lineHeight: '20px', fontWeight: '700' }}>{r.name}</span>
                            <span style={{ fontSize: '13px', lineHeight: '18px', color: 'var(--muted)' }}>{r.por}</span>
                          </div>
                          <span style={{ fontSize: '15px', fontWeight: '800', flex: 'none' }}>
                            {r.kcal}{' '}
                            <span style={{ fontSize: '12px', fontWeight: '700', color: 'var(--muted)' }}>kcal</span>
                          </span>
                        </div>
                      </>
                    )}
                    {r.isScan && (
                      <>
                        <div
                          style={{
                            margin: '0 14px',
                            borderTop: '1px solid var(--line)',
                            padding: '12px 0',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px',
                          }}
                        >
                          <img
                            src={r.thumb}
                            alt=""
                            style={{
                              width: '52px',
                              height: '52px',
                              borderRadius: '14px',
                              objectFit: 'cover',
                              flex: 'none',
                              background: 'var(--track)',
                            }}
                           />
                          <div
                            style={{
                              flex: '1',
                              minWidth: '0',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '2px',
                            }}
                          >
                            <span style={{ fontSize: '15px', lineHeight: '20px', fontWeight: '700' }}>{r.name}</span>
                            <span
                              style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '4px',
                                fontSize: '12px',
                                fontWeight: '800',
                                color: v.accentInk,
                              }}
                            >
                              <svg
                                width="12"
                                height="12"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                aria-hidden="true"
                              >
                                <path d="M4 8h3l2-3h6l2 3h3v11H4z"></path>
                                <circle cx="12" cy="13" r="3.4"></circle>
                              </svg>
                              Scanned · {r.por}
                            </span>
                          </div>
                          <span style={{ fontSize: '15px', fontWeight: '800', flex: 'none' }}>
                            {r.kcal}{' '}
                            <span style={{ fontSize: '12px', fontWeight: '700', color: 'var(--muted)' }}>kcal</span>
                          </span>
                        </div>
                      </>
                    )}
                    {r.isEmpty && (
                      <>
                        <div
                          style={{
                            margin: '0 14px',
                            borderTop: '1px solid var(--line)',
                            padding: '14px 0',
                            fontSize: '14px',
                            color: 'var(--muted)',
                          }}
                        >{r.text}</div>
                      </>
                    )}
                    {r.isEnd && (
                      <>
                        <div style={{ height: '8px' }}></div>
                      </>
                    )}
                  </div>
                </React.Fragment>
              ))}
            </section>
            <section aria-label="Meal photos" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  justifyContent: 'space-between',
                  margin: '4px 2px 0 2px',
                }}
              >
                <h2
                  style={{
                    margin: '0',
                    fontSize: '18px',
                    lineHeight: '24px',
                    fontWeight: '800',
                    letterSpacing: '-0.01em',
                  }}
                >Meal photos</h2>
                <span style={{ fontSize: '13px', fontWeight: '600', color: 'var(--muted)' }}>{v.photoCount}</span>
              </div>
              {v.hasPhotos && (
                <>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '8px' }}>
                    {v.photos.map((p, i1) => (
                      <React.Fragment key={i1}>
                        <div
                          style={{
                            position: 'relative',
                            aspectRatio: '1 / 1',
                            borderRadius: '18px',
                            overflow: 'hidden',
                            background: 'var(--track)',
                          }}
                        >
                          <img
                            src={p.src}
                            alt={p.alt}
                            style={{
                              position: 'absolute',
                              left: '0',
                              top: '0',
                              width: '100%',
                              height: '100%',
                              objectFit: 'cover',
                            }}
                           />
                          <span
                            style={{
                              position: 'absolute',
                              left: '6px',
                              bottom: '6px',
                              padding: '3px 8px',
                              borderRadius: '10px',
                              background: 'rgba(5,8,13,.68)',
                              color: '#FFFFFF',
                              fontSize: '11px',
                              fontWeight: '800',
                            }}
                          >{p.kcal} kcal</span>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </>
              )}
              {v.noPhotos && (
                <>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '24px',
                      padding: '22px 18px',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '12px',
                      textAlign: 'center',
                    }}
                  >
                    <div
                      aria-hidden="true"
                      style={{
                        width: '56px',
                        height: '56px',
                        borderRadius: '28px',
                        background: 'var(--soft-bg)',
                        color: v.accentInk,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <svg
                        width="26"
                        height="26"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M4 8h3l2-3h6l2 3h3v11H4z"></path>
                        <circle cx="12" cy="13" r="3.5"></circle>
                      </svg>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                      <span style={{ fontSize: '16px', fontWeight: '800' }}>No meal photos yet</span>
                      <span style={{ fontSize: '14px', lineHeight: '20px', color: 'var(--muted)' }}>
                        Meals you scan with the camera show up here with their calories.
                      </span>
                    </div>
                    <a
                      href={ROUTES.scanner}
                      className="press"
                      style={{
                        height: '44px',
                        padding: '0 20px',
                        borderRadius: '22px',
                        background: v.accent,
                        color: 'var(--on-accent)',
                        fontSize: '14px',
                        fontWeight: '800',
                        textDecoration: 'none',
                        display: 'inline-flex',
                        alignItems: 'center',
                        boxShadow: `0 6px 16px ${v.glow}`,
                      }}
                      onClick={(e) => { go(e, 'scanner', this.props); }}
                    >Scan a meal</a>
                  </div>
                </>
              )}
            </section>
          </div>
        </div>
        <BottomNav active="log" accent={v.accent} glow={v.glow} onNavigate={this.props.onNavigate} />
      </div>
    );
  }
}
