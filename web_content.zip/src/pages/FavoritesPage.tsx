import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Formula } from '../types';
import { getFormulas } from '../firebase/services';
import { useApp } from '../context/AppContext';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import {
  Bookmark,
  Search,
  Calculator,
  Trash2,
  ArrowRight,
  Compass,
  BookOpen
} from 'lucide-react';
import { FormulaCard } from '../components/formula/FormulaCard';

export const FavoritesPage: React.FC = () => {
  const { favorites, playSound, triggerHaptic, showToast } = useApp();
  const navigate = useNavigate();

  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const allFormulas = await getFormulas();
        setFormulas(allFormulas);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const favoriteFormulas = formulas.filter((f) => favorites.includes(f.id));

  const filteredFavorites = favoriteFormulas.filter(
    (f) =>
      f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.formula.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Bookmark className="w-5 h-5 text-[#D65A1F] fill-[#D65A1F]" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
              Saved Favorites
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-[#A9A39C]">
            Your curated collection of frequently referenced formulas, saved locally on this device.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono px-3.5 py-1.5 rounded-xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED]">
            <strong className="text-[#D65A1F]">{favorites.length}</strong> saved formulas
          </span>
        </div>
      </div>

      {/* Search Bar */}
      {favoriteFormulas.length > 0 && (
        <div className="relative max-w-xl">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A9A39C]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search saved equations..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED] placeholder-[#A9A39C] text-sm focus:outline-none focus:border-[#D65A1F] transition-all"
          />
        </div>
      )}

      {/* Grid of Favorites */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : favoriteFormulas.length === 0 ? (
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-12 text-center space-y-4 max-w-lg mx-auto shadow-xl">
          <div className="w-14 h-14 rounded-2xl bg-[#232323] border border-[#303030] flex items-center justify-center mx-auto text-[#A9A39C]">
            <Bookmark className="w-6 h-6 text-[#A9A39C]" />
          </div>
          <h3 className="text-lg font-bold text-[#F5F2ED]">
            No saved formulas yet
          </h3>
          <p className="text-xs text-[#A9A39C] leading-relaxed">
            Browse the Formula Library and click the bookmark icon on any equation to save it for rapid offline access.
          </p>
          <button
            onClick={() => {
              playSound('button');
              navigate('/formulas');
            }}
            className="px-5 py-2.5 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-bold text-xs transition-colors"
          >
            Explore Formula Library
          </button>
        </div>
      ) : filteredFavorites.length === 0 ? (
        <div className="p-12 text-center text-[#A9A39C] rounded-2xl bg-[#1C1C1C] border border-[#303030]">
          No saved formulas match "{searchQuery}"
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredFavorites.map((f) => (
            <FormulaCard key={f.id} formula={f} />
          ))}
        </div>
      )}
    </div>
  );
};
