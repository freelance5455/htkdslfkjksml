import CalculatorCard from '@/components/calculator/CalculatorCard';

export default function Calculator() {
  return (
    <div className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden bg-[#F8F5EF] px-5 py-12">
      <div className="pointer-events-none absolute -left-24 top-[-10%] h-[26rem] w-[26rem] rounded-full bg-[#EFE3D3]/70 blur-[110px]" />
      <div className="pointer-events-none absolute -right-24 bottom-[-12%] h-[26rem] w-[26rem] rounded-full bg-[#E3E9E0]/60 blur-[110px]" />

      <div className="relative w-full max-w-[380px]">
        <div className="mb-6 flex items-end justify-between px-1">
          <h1 className="font-display text-[1.9rem] leading-none text-[#1A1A18]">Calculator</h1>
          <span className="pb-1 text-[10px] uppercase tracking-[0.28em] text-[#A9A196]">Simple</span>
        </div>
        <CalculatorCard />
      </div>
    </div>
  );
}