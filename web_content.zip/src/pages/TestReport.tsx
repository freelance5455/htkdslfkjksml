import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft, ArrowUpRight, CheckCircle2, Clock, MinusCircle, Target, XCircle,
} from 'lucide-react';
import type { AttemptReport, EvaluatedQuestion, QuestionRow } from '@shared/types';
import { MISTAKE_LABELS } from '@shared/exam';
import { api, ApiError } from '../lib/api';
import { cn, formatMinutes } from '../lib/utils';
import {
  Badge, Banner, Button, Card, EmptyState, ProgressBar, Ring, SectionHeading, Spinner, Tabs,
} from '../components/ui';
import { DifficultyRadar, MistakeBars, SubjectBars } from '../components/Charts';
import { Markdown } from '../components/Markdown';

interface ReportResponse {
  attempt: {
    id: number; testId: number; status: string; startedAt: string; submittedAt: string | null;
    score: number; maxScore: number; correct: number; incorrect: number; unattempted: number;
    accuracy: number; timeSpentSeconds: number; report: AttemptReport | null;
  };
  test: { id: number; title: string; exam: string; durationMinutes: number; totalMarks: number } | null;
  questions: (Pick<QuestionRow, 'id' | 'subject' | 'chapter' | 'type' | 'difficulty' | 'prompt' | 'options' | 'marks' | 'correct' | 'numericAnswer' | 'solution'>)[];
}

export default function TestReport() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState<ReportResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<'overview' | 'questions' | 'plan'>('overview');
  const [filter, setFilter] = useState<'all' | 'wrong' | 'unattempted'>('all');

  const load = useCallback(async () => {
    try {
      const res = await api.get<ReportResponse>(`/api/attempts/${id}`);
      setData(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load this report.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { void load(); }, [load]);

  const report = data?.attempt.report;
  const questionMap = useMemo(() => new Map((data?.questions ?? []).map((q) => [q.id, q])), [data]);

  if (loading) return <Spinner label="Crunching your result…" />;
  if (error) return <div className="p-6"><Banner tone="bad">{error}</Banner><Button className="mt-3" onClick={() => navigate('/tests')}>Back to tests</Button></div>;
  if (!data) return null;

  if (!report) {
    return (
      <div className="mx-auto max-w-2xl p-6">
        <Card>
          <EmptyState icon={<Clock size={22} />} title="This attempt is still in progress" description="Finish the paper to unlock evaluation and solutions." action={<Button onClick={() => navigate(`/tests/${data.attempt.testId}/run`)}>Resume test</Button>} />
        </Card>
      </div>
    );
  }

  const percent = data.attempt.maxScore ? Math.round((data.attempt.score / data.attempt.maxScore) * 1000) / 10 : 0;
  const attempted = report.evaluated.length - data.attempt.unattempted;
  const timePerQuestion = attempted ? Math.round(data.attempt.timeSpentSeconds / attempted) : 0;
  const filtered = report.evaluated.filter((e) => filter === 'all' || (filter === 'wrong' ? e.status === 'incorrect' || e.status === 'partial' : e.status === 'unattempted'));
  const mistakes = Object.entries(report.mistakeCounts).map(([type, count]) => ({ type: MISTAKE_LABELS[type] ?? type, count }));

  return (
    <div className="mx-auto max-w-6xl space-y-4 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Button variant="ghost" onClick={() => navigate('/tests')}><ArrowLeft size={16} /> Test Centre</Button>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => navigate('/revision')}>Revise mistakes</Button>
          <Button variant="secondary" onClick={() => window.print()}>Print / save PDF</Button>
        </div>
      </div>

      <Card className="relative overflow-hidden">
        <div className="absolute -right-10 -top-16 h-56 w-56 rounded-full bg-brand/15 blur-3xl" />
        <div className="relative flex flex-wrap items-center gap-6">
          <Ring value={percent} size={128} label={`${percent}%`} sub={`${Math.round(data.attempt.score)}/${Math.round(data.attempt.maxScore)}`} />
          <div className="min-w-[220px] flex-1">
            <h1 className="font-display text-xl font-extrabold tracking-tight text-ink">{data.test?.title}</h1>
            <p className="mt-1 text-sm text-muted">
              {data.test?.exam && <span className="uppercase tracking-wide">{data.test.exam}</span>} · submitted {data.attempt.submittedAt ? new Date(data.attempt.submittedAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—'}
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Metric label="Accuracy" value={`${data.attempt.accuracy}%`} />
              <Metric label="Attempt rate" value={`${report.attemptRate}%`} />
              <Metric label="Correct" value={data.attempt.correct} tone="ok" />
              <Metric label="Incorrect" value={data.attempt.incorrect} tone="bad" />
            </div>
          </div>
          <div className="space-y-1.5 text-xs text-muted">
            <div className="flex items-center gap-2"><Clock size={13} /> {formatMinutes(data.attempt.timeSpentSeconds / 60)} used</div>
            <div className="flex items-center gap-2"><Target size={13} /> {Math.round(timePerQuestion)}s per attempted question</div>
            <div className="flex items-center gap-2"><MinusCircle size={13} /> {data.attempt.unattempted} unattempted</div>
            <div className="flex items-center gap-2"><ArrowUpRight size={13} /> {report.analysisSource === 'ai' ? 'AI analysis' : 'Rule-based analysis'}</div>
          </div>
        </div>
      </Card>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <Tabs
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'overview', label: 'Analysis' },
            { value: 'questions', label: 'Question review', count: report.evaluated.length },
            { value: 'plan', label: 'Improvement plan', count: report.improvementPlan.length },
          ]}
        />
        <div className="flex gap-1.5">
          <Badge tone={percent >= 60 ? 'ok' : percent >= 35 ? 'warn' : 'bad'}>{percent >= 60 ? 'On track' : percent >= 35 ? 'Needs work' : 'Foundational gaps'}</Badge>
          <Badge>{report.mistakeCounts && Object.values(report.mistakeCounts).reduce((a, b) => a + b, 0)} mistakes tagged</Badge>
        </div>
      </div>

      {tab === 'overview' && (
        <div className="space-y-4">
          <Card>
            <SectionHeading title="Examiner-style summary" subtitle="What this paper actually says about your preparation" />
            <div className="rounded-xl border border-line bg-elevated/30 p-4">
              <Markdown content={report.summary} />
            </div>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-ok">What worked</h3>
                <ul className="space-y-1.5">
                  {report.strengths.map((s, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-ink/90"><CheckCircle2 size={15} className="mt-0.5 shrink-0 text-ok" />{s}</li>
                  ))}
                  {report.strengths.length === 0 && <li className="text-sm text-muted">No strengths recorded for this paper.</li>}
                </ul>
              </div>
              <div>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-warn">What to fix</h3>
                <ul className="space-y-1.5">
                  {report.improvements.map((s, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-ink/90"><XCircle size={15} className="mt-0.5 shrink-0 text-warn" />{s}</li>
                  ))}
                  {report.improvements.length === 0 && <li className="text-sm text-muted">No specific weaknesses detected.</li>}
                </ul>
              </div>
            </div>
            <p className="mt-4 rounded-lg border border-line bg-elevated/30 p-3 text-xs text-muted">{report.timeEfficiency}</p>
          </Card>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <SectionHeading title="Subject performance" subtitle="Attempted questions only for accuracy" />
              <SubjectBars data={report.subjects.map((s) => ({ subject: s.subject, accuracy: s.accuracy }))} height={220} />
              <div className="mt-3 space-y-1.5">
                {report.subjects.map((s) => (
                  <div key={s.subject} className="flex items-center justify-between gap-2 text-xs">
                    <span className="text-ink">{s.subject}</span>
                    <span className="text-muted">{s.score}/{s.max} marks · {s.accuracy}%</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card>
              <SectionHeading title="Mistake classification" subtitle="Tags applied from your answers" />
              {mistakes.length ? <MistakeBars data={mistakes} height={220} /> : <p className="text-sm text-muted">No mistakes to classify — excellent paper.</p>}
              <div className="mt-2 grid gap-1">
                {mistakes.map((m) => (
                  <div key={m.type} className="flex justify-between text-xs"><span className="text-muted">{m.type}</span><span className="font-semibold text-ink">{m.count}</span></div>
                ))}
              </div>
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <SectionHeading title="Difficulty-wise accuracy" />
              <DifficultyRadar data={report.difficulties.map((d) => ({ difficulty: d.difficulty, accuracy: d.accuracy }))} height={230} />
            </Card>
            <Card>
              <SectionHeading title="Chapter breakdown" subtitle="Sorted weakest first" />
              <div className="space-y-2">
                {[...report.chapters].sort((a, b) => a.accuracy - b.accuracy).slice(0, 8).map((ch) => (
                  <div key={`${ch.subject}-${ch.chapter}`}>
                    <div className="mb-1 flex items-center justify-between gap-2 text-xs">
                      <span className="truncate text-ink">{ch.chapter} <span className="text-muted">· {ch.subject}</span></span>
                      <span className={cn('font-semibold', ch.accuracy >= 70 ? 'text-ok' : ch.accuracy >= 40 ? 'text-warn' : 'text-bad')}>{ch.accuracy}%</span>
                    </div>
                    <ProgressBar value={ch.accuracy} tone={ch.accuracy >= 70 ? 'ok' : ch.accuracy >= 40 ? 'warn' : 'bad'} height="h-1.5" />
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      )}

      {tab === 'questions' && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            {(['all', 'wrong', 'unattempted'] as const).map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={cn('chip capitalize', filter === f && 'border-brand/50 bg-brand/10 text-brand')}>{f === 'all' ? 'All questions' : f}</button>
            ))}
            <Link to="/bank" className="ml-auto text-xs font-semibold text-brand hover:underline">Practice similar questions</Link>
          </div>
          {filtered.length === 0 && <Card><p className="text-sm text-muted">No questions match this filter.</p></Card>}
          {filtered.map((item) => {
            const question = questionMap.get(item.questionId);
            return <QuestionReview key={item.questionId} item={item} question={question} />;
          })}
        </div>
      )}

      {tab === 'plan' && (
        <div className="space-y-3">
          <Card>
            <SectionHeading title="Your next 7 days" subtitle="Built from the mistakes in this paper" />
            {report.improvementPlan.length === 0 ? (
              <p className="text-sm text-muted">No plan needed for this paper.</p>
            ) : (
              <ol className="space-y-2.5">
                {report.improvementPlan.map((step, i) => (
                  <li key={i} className="flex gap-3 rounded-xl border border-line bg-elevated/30 p-3.5">
                    <span className={cn('grid h-7 w-7 shrink-0 place-items-center rounded-lg text-xs font-bold',
                      step.priority === 'high' ? 'bg-bad/15 text-bad' : step.priority === 'medium' ? 'bg-warn/15 text-warn' : 'bg-brand/15 text-brand')}>
                      {i + 1}
                    </span>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-sm font-semibold text-ink">{step.title}</h3>
                        <Badge tone={step.priority === 'high' ? 'bad' : step.priority === 'medium' ? 'warn' : 'brand'}>{step.priority} priority</Badge>
                      </div>
                      <p className="mt-1 text-sm text-muted">{step.detail}</p>
                    </div>
                  </li>
                ))}
              </ol>
            )}
            <div className="mt-4 flex flex-wrap gap-2 border-t border-line pt-3">
              <Button onClick={() => navigate('/planner')}>Put this in my planner</Button>
              <Button variant="secondary" onClick={() => navigate('/revision')}>Open revision centre</Button>
              <Button variant="secondary" onClick={() => navigate('/teacher')}>Learn the weak chapters</Button>
            </div>
          </Card>
          <Card>
            <SectionHeading title="Mistakes saved for revision" subtitle={`${report.evaluated.filter((e) => e.mistakeType).length} questions were added to your revision cards`} />
            <div className="flex flex-wrap gap-1.5">
              {[...new Set(report.evaluated.filter((e) => e.mistakeType).map((e) => e.chapter))].map((chapter) => (
                <Badge key={chapter} tone="warn">{chapter}</Badge>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted">
              Every incorrectly answered objective question from this paper is now a due flashcard, so the same gap does not survive to the next test.
            </p>
          </Card>
        </div>
      )}
    </div>
  );
}

function Metric({ label, value, tone }: { label: string; value: React.ReactNode; tone?: 'ok' | 'bad' }) {
  return (
    <div className="rounded-lg border border-line bg-elevated/40 px-2.5 py-2">
      <div className={cn('text-sm font-bold', tone === 'ok' ? 'text-ok' : tone === 'bad' ? 'text-bad' : 'text-ink')}>{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted">{label}</div>
    </div>
  );
}

function QuestionReview({ item, question }: { item: EvaluatedQuestion; question?: ReportResponse['questions'][number] }) {
  const [open, setOpen] = useState(item.status !== 'correct');
  const statusTone = item.status === 'correct' ? 'ok' : item.status === 'incorrect' ? 'bad' : item.status === 'partial' ? 'warn' : 'neutral';
  const response = item.numericResponse ?? (item.response ?? []).join(', ');

  return (
    <Card className="p-4">
      <button onClick={() => setOpen((v) => !v)} className="flex w-full items-start gap-3 text-left">
        <span className={cn('mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-md text-[11px] font-bold',
          item.status === 'correct' ? 'bg-ok/15 text-ok' : item.status === 'incorrect' ? 'bg-bad/15 text-bad' : item.status === 'partial' ? 'bg-warn/15 text-warn' : 'bg-elevated text-muted')}>
          {item.status === 'correct' ? '✓' : item.status === 'incorrect' ? '✕' : item.status === 'partial' ? '½' : '–'}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge tone={statusTone as 'ok' | 'bad' | 'warn' | 'neutral'}>{item.status}</Badge>
            <Badge>{item.subject}</Badge>
            <Badge>{item.chapter}</Badge>
            <Badge>{item.awarded}/{item.maxMarks} marks</Badge>
            {item.mistakeType && <Badge tone="warn">{MISTAKE_LABELS[item.mistakeType] ?? item.mistakeType}</Badge>}
            <span className="ml-auto text-[10px] text-muted">{item.timeSpentSeconds}s</span>
          </div>
          <p className={cn('mt-1.5 text-sm text-ink', !open && 'line-clamp-2')}>{item.prompt}</p>
        </div>
      </button>

      {open && (
        <div className="mt-3 space-y-3 border-t border-line pt-3">
          {question?.options && (
            <div className="space-y-1.5">
              {question.options.map((option) => {
                const isCorrect = question.correct.includes(option.key);
                const chosen = (item.response ?? []).includes(option.key);
                return (
                  <div key={option.key} className={cn('flex items-start gap-2 rounded-lg border px-2.5 py-1.5 text-xs',
                    isCorrect ? 'border-ok/40 bg-ok/10' : chosen ? 'border-bad/40 bg-bad/10' : 'border-line bg-elevated/20')}>
                    <span className="font-bold text-ink">{option.key}</span>
                    <span className="flex-1 text-ink/90">{option.text}</span>
                    {isCorrect && <span className="text-[10px] font-semibold text-ok">correct</span>}
                    {chosen && !isCorrect && <span className="text-[10px] font-semibold text-bad">your answer</span>}
                  </div>
                );
              })}
            </div>
          )}
          <div className="grid gap-2 sm:grid-cols-2">
            <div className="rounded-lg border border-line bg-elevated/30 p-2.5">
              <div className="text-[10px] uppercase tracking-wide text-muted">Your answer</div>
              <div className="mt-1 whitespace-pre-wrap text-xs text-ink">{response || 'Not attempted'}</div>
            </div>
            <div className="rounded-lg border border-line bg-elevated/30 p-2.5">
              <div className="text-[10px] uppercase tracking-wide text-muted">Expected answer</div>
              <div className="mt-1 whitespace-pre-wrap text-xs text-ink">
                {item.numericAnswer ?? (item.correct.length ? item.correct.join(', ') : 'Descriptive — see model answer')}
              </div>
            </div>
          </div>
          {item.explanation && <div className="rounded-lg border border-brand/25 bg-brand/5 p-3 text-xs text-ink/90">{item.explanation}</div>}
          <div>
            <div className="mb-1 text-[10px] uppercase tracking-wide text-muted">Model solution</div>
            <div className="rounded-lg border border-line bg-elevated/20 p-3"><Markdown content={item.solution} /></div>
          </div>
        </div>
      )}
    </Card>
  );
}
