import { Link } from 'react-router-dom';
import { Award, BarChart3, Coins, Flame, Target, TrendingUp, Trophy } from 'lucide-react';
import { subjects } from '../data/content';
import { useStored, KEYS } from '../services/storage';
import {
  completedCount,
  last7Days,
  overallProgress,
  studyStreak,
  subjectProgress,
  studyTimeSummary,
} from '../services/progress';
import { attempts, overallAccuracy, weakPoints } from '../services/quiz';
import { deckProgress } from '../services/flashcards';
import { getPlan, planSummary } from '../services/plan';
import { useProfile } from '../hooks/useProfile';
import { PageHeader } from '../components/layout/PageHeader';
import { ProgressBar, SectionHeader } from '../components/ui/Card';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { formatMinutes, relativeDays } from '../utils/format';
import { EMPTY_WALLET } from '../services/economy';
import { achievementSummary, challengeSummary } from '../services/gamification';
import { overallCurriculumProgress, type CurriculumCompletionState } from '../services/curriculumProgress';

export default function Progress() {
  const { profile } = useProfile();
  useStored(KEYS.progress, {});
  useStored(KEYS.stats, { days: {} });
  useStored(KEYS.quizzes, []);
  useStored(KEYS.cards, {});
  const wallet = useStored(KEYS.wallet, EMPTY_WALLET);
  const curriculumState = useStored<CurriculumCompletionState>(KEYS.curriculumProgress, {});

  const days = last7Days();
  const maxSeconds = Math.max(1, ...days.map((d) => d.seconds));
  const accuracy = overallAccuracy();
  const weak = weakPoints(5);
  const quizAttempts = attempts().slice(0, 6);
  const deck = deckProgress();
  const plan = getPlan();
  const planStats = planSummary();
  const streak = studyStreak();
  const studyTime = studyTimeSummary();
  const completed = completedCount();
  const overall = overallProgress();
  const syllabus = overallCurriculumProgress(curriculumState);
  const challenges = challengeSummary();
  const achievements = achievementSummary();

  const badges = [
    { id: 'first', label: 'أول درس', earned: completed >= 1, icon: '١' },
    { id: 'ten', label: '١٠ دروس', earned: completed >= 10, icon: '١٠' },
    { id: 'streak3', label: '٣ أيام متتالية', earned: streak >= 3, icon: <Flame size={15} /> },
    { id: 'streak7', label: 'أسبوع كامل', earned: streak >= 7, icon: <Flame size={15} /> },
    { id: 'quiz', label: 'اختبار بدرجة كاملة', earned: attempts().some((a) => a.score === a.total && a.total > 0), icon: <Target size={15} /> },
    { id: 'review', label: '٢٠ بطاقة مراجعة', earned: deck.reviewed >= 20, icon: <Award size={15} /> },
    { id: 'plan', label: 'خطة أسبوعية', earned: plan.sessions.length > 0, icon: <BarChart3 size={15} /> },
    { id: 'half', label: 'نصف المنهاج', earned: overall >= 50, icon: <TrendingUp size={15} /> },
  ];

  return (
    <div>
      <PageHeader
        eyebrow={`هدفك: ${profile.targetAverage}%`}
        title="تقدمي"
        subtitle="ما يُقاس يتحسّن. هذه صورة صادقة لساعاتك ونتائجك ونقاط ضعفك."
      />

      <div className="mb-4 grid grid-cols-3 gap-2">
        <Stat label="ساعات الدراسة الكلية" value={formatMinutes(Math.round(studyTime.totalSeconds / 60))} />
        <Stat label="دروس مكتملة" value={`${completed}`} />
        <Stat label="دقة الإجابات" value={`${accuracy}%`} />
      </div>

      <div className="mb-5 grid grid-cols-3 gap-2" aria-label="تفصيل وقت الدراسة">
        <Stat label="اليوم" value={formatMinutes(Math.round(studyTime.todaySeconds / 60))} />
        <Stat label="هذا الأسبوع" value={formatMinutes(Math.round(studyTime.weekSeconds / 60))} />
        <Stat label="هذا الشهر" value={formatMinutes(Math.round(studyTime.monthSeconds / 60))} />
      </div>

      <div className="mb-5 grid grid-cols-3 gap-2">
        <Link to="/shop" className="focus-ring card flex min-h-20 flex-col items-center justify-center gap-1 p-2 text-center"><Coins size={17} className="text-[var(--gold)]" /><strong className="text-sm text-[var(--ink)]">{wallet.balance}</strong><span className="text-[0.58rem] text-[var(--ink-soft)]">نقطة · المتجر</span></Link>
        <Link to="/challenges" className="focus-ring card flex min-h-20 flex-col items-center justify-center gap-1 p-2 text-center"><Target size={17} className="text-[var(--gold)]" /><strong className="text-sm text-[var(--ink)]">{challenges.completed}/{challenges.total}</strong><span className="text-[0.58rem] text-[var(--ink-soft)]">تحديات مكتملة</span></Link>
        <Link to="/achievements" className="focus-ring card flex min-h-20 flex-col items-center justify-center gap-1 p-2 text-center"><Trophy size={17} className="text-[var(--gold)]" /><strong className="text-sm text-[var(--ink)]">{achievements.unlocked}/{achievements.total}</strong><span className="text-[0.58rem] text-[var(--ink-soft)]">إنجازات مفتوحة</span></Link>
      </div>

      <section className="mb-4">
        <SectionHeader title="آخر ٧ أيام" hint="بالدقائق" />
        <div className="card p-4">
          {days.every((d) => d.seconds === 0) ? (
            <p className="mb-2 rounded-xl bg-[var(--surface-2)] px-3 py-2 text-[0.7rem] leading-relaxed text-[var(--ink-soft)]">
              لا وقت دراسة مسجّل هذا الأسبوع بعد. يبدأ العدّ تلقائياً مع أول دقيقة مشاهدة.
            </p>
          ) : null}
          <div className="flex h-36 items-end justify-between gap-1.5">
            {days.map((day) => {
              const minutes = Math.round(day.seconds / 60);
              const height = Math.max(3, (day.seconds / maxSeconds) * 100);
              const date = new Date(`${day.date}T00:00:00`);
              return (
                <div key={day.date} className="flex flex-1 flex-col items-center gap-1.5">
                  <span className="text-[0.6rem] text-[var(--ink-soft)]">{minutes > 0 ? minutes : ''}</span>
                  <div
                    className="w-full max-w-8 rounded-t-lg transition-[height] duration-500"
                    style={{
                      height: `${height}%`,
                      background: minutes > 0 ? 'linear-gradient(180deg, var(--gold), #f7d089)' : 'var(--surface-2)',
                    }}
                    title={`${minutes} دقيقة`}
                  />
                  <span className="text-[0.58rem] text-[var(--ink-soft)]">
                    {date.toLocaleDateString('ar-SY', { weekday: 'short' })}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mb-4">
        <SectionHeader
          title="إنجاز المنهاج"
          hint={`${syllabus.completed.toLocaleString('ar-SY')} من ${syllabus.total.toLocaleString('ar-SY')} درساً أو فكرة`}
          action={<Link to="/curriculum-progress" className="text-[0.7rem] text-[var(--brand)]">التفاصيل</Link>}
        />
        <Link to="/curriculum-progress" className="focus-ring card block p-4">
          <div className="mb-2 flex items-center justify-between gap-2 text-xs">
            <span className="text-[var(--ink-soft)]">التقدم الشامل في المواد الثماني</span>
            <strong className="font-display text-base text-[var(--gold)]">{syllabus.percent.toLocaleString('ar-SY')}٪</strong>
          </div>
          <ProgressBar value={syllabus.percent} height={7} label="إنجاز المنهاج الشامل" />
          <p className="mt-2 text-[0.65rem] text-[var(--ink-soft)]">افتح قائمة الوحدات وحدّد الدروس والأفكار التي أنجزتها.</p>
        </Link>
      </section>

      <section className="mb-4">
        <SectionHeader title="تقدم الدروس المرئية" action={<Link to="/subjects" className="text-[0.7rem] text-[var(--ink-soft)]">المواد</Link>} />
        <div className="card space-y-3 p-4">
          {subjects.map((subject) => {
            const value = subjectProgress(subject);
            return (
              <div key={subject.id}>
                <div className="mb-1 flex items-center justify-between text-[0.72rem]">
                  <span className="text-[var(--ink)]">{subject.name}</span>
                  <span className="text-[var(--ink-soft)]">{value}%</span>
                </div>
                <ProgressBar value={value} height={6} color={subject.color} label={`تقدم ${subject.name}`} />
              </div>
            );
          })}
        </div>
      </section>

      <section className="mb-4">
        <SectionHeader title="نتائج الاختبارات" hint={`${attempts().length} محاولة محفوظة`} />
        {quizAttempts.length === 0 ? (
          <EmptyState
            icon={<BarChart3 size={18} />}
            title="لا محاولات بعد"
            description="ابدأ باختبار قصير من أي درس، وستظهر نتيجتك هنا مع تفسير كل إجابة."
            action={
              <Link to="/tests" className="focus-ring inline-flex h-10 items-center rounded-full bg-[var(--brand)] px-4 text-[0.78rem] text-[var(--brand-ink)]">
                إلى الاختبارات
              </Link>
            }
          />
        ) : (
          <div className="space-y-2">
            {quizAttempts.map((attempt) => {
              const percent = attempt.total ? Math.round((attempt.score / attempt.total) * 100) : 0;
              return (
                <div key={attempt.id} className="card flex items-center gap-3 p-3">
                  <span
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl font-display text-[0.8rem]"
                    style={{
                      background: percent >= 80 ? '#e6f7ef' : percent >= 50 ? 'var(--gold-soft)' : '#fdece2',
                      color: percent >= 80 ? '#0b6b4f' : percent >= 50 ? '#8a5b06' : '#a63a12',
                    }}
                  >
                    {percent}%
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[0.8rem] text-[var(--ink)]">
                      {attempt.score} / {attempt.total} إجابات صحيحة
                    </p>
                    <p className="text-[0.64rem] text-[var(--ink-soft)]">{relativeDays(attempt.at)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {weak.length > 0 ? (
        <section className="mb-4">
          <SectionHeader title="نقاط الضعف" hint="تتكرر في محاولاتك — راجعها أولاً" />
          <div className="flex flex-wrap gap-2">
            {weak.map((point) => (
              <Badge key={`${point.subjectId}-${point.label}`} tone="danger">
                {point.label} · {point.count} مرة
              </Badge>
            ))}
          </div>
          <Link
            to="/review"
            className="focus-ring mt-3 inline-flex h-10 items-center rounded-full border border-[var(--line)] px-4 text-[0.74rem] text-[var(--ink)]"
          >
            راجع البطاقات المرتبطة
          </Link>
        </section>
      ) : null}

      <section className="mb-4">
        <SectionHeader title="شارات الإنجاز" hint={`${badges.filter((b) => b.earned).length} من ${badges.length}`} />
        <div className="grid grid-cols-4 gap-2">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className="card flex flex-col items-center gap-1.5 p-2.5 text-center"
              style={{ opacity: badge.earned ? 1 : 0.45 }}
            >
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full"
                style={{
                  background: badge.earned ? 'var(--gold-soft)' : 'var(--surface-2)',
                  color: badge.earned ? '#8a5b06' : 'var(--ink-soft)',
                }}
              >
                {badge.icon}
              </span>
              <span className="text-[0.58rem] leading-tight text-[var(--ink-soft)]">{badge.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="الخطة" hint={planStats.total > 0 ? `${planStats.done} من ${planStats.total} حصة` : 'لم تُنشأ بعد'} />
        <Link to="/plan" className="focus-ring card flex items-center justify-between p-4">
          <div>
            <p className="text-[0.8rem] text-[var(--ink)]">
              {planStats.total > 0 ? `${Math.round((planStats.done / planStats.total) * 100)}% من خطة الأسبوع` : 'أنشئ خطتك الأسبوعية'}
            </p>
            <p className="text-[0.66rem] text-[var(--ink-soft)]">
              {plan.hoursPerDay > 0 ? `${plan.hoursPerDay} ساعة يومياً · ` : ''}
              {planStats.total > 0 ? `${planStats.minutes} دقيقة موزّعة` : 'من تاريخ امتحانك'}
            </p>
          </div>
          <TrendingUp size={18} className="text-[var(--ink-soft)]" />
        </Link>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-3 text-center">
      <p className="font-display text-base text-[var(--ink)]">{value}</p>
      <p className="mt-0.5 text-[0.6rem] leading-tight text-[var(--ink-soft)]">{label}</p>
    </div>
  );
}
