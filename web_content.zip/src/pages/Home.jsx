import { useMemo } from "react";
import useReports from "@/hooks/useReports";
import { computeStats, categorySplit } from "@/lib/reportStats";
import Hero from "@/components/home/Hero";
import MetricsBand from "@/components/home/MetricsBand";
import PulseSection from "@/components/home/PulseSection";
import BoardSection from "@/components/home/BoardSection";

export default function Home() {
  const { reports, loading } = useReports();

  const stats = useMemo(() => computeStats(reports), [reports]);
  const categoryData = useMemo(() => categorySplit(reports), [reports]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-border border-t-primary" />
      </div>
    );
  }

  return (
    <>
      <Hero stats={stats} />
      <MetricsBand stats={stats} />
      <PulseSection stats={stats} categoryData={categoryData} />
      <BoardSection reports={reports} />
    </>
  );
}