import React from 'react';
import { CalsenBase } from '../lib/CalsenBase';
import { go, ROUTES, css } from '../lib/calsen';
import BottomNav from '../components/BottomNav';
import bananaImg from '../assets/calsen-banana.png';
import { MEAL_ART, MEAL_DISHES } from '../assets/mealArt';
import { getCurrentLang, t } from '../lib/i18n';

export default class HomePage extends CalsenBase {
  static defaultProps = {"accent": "#FF5C00", "theme": "sync"};

  componentDidMount() {
    super.componentDidMount && super.componentDidMount();
    this._langListener = () => {
      this.forceUpdate();
    };
    window.addEventListener('calsen-lang-change', this._langListener);

    setTimeout(() => {
      try {
        const el = document.getElementById('week-strip');
        const t0 = el && el.querySelector('[data-today="true"]');
        if (el && t0) el.scrollLeft = t0.offsetLeft - (el.clientWidth - t0.offsetWidth) / 2;
      } catch (e) {}
    }, 60);
  }

  componentWillUnmount() {
    super.componentWillUnmount && super.componentWillUnmount();
    if (this._langListener) {
      window.removeEventListener('calsen-lang-change', this._langListener);
    }
  }

  addWater = (e) => {
    if (e && e.stopPropagation) e.stopPropagation();
    try {
      const current = Number(window.localStorage.getItem('calsen-today-water') || '1.5');
      const next = Math.round((current + 0.25) * 100) / 100;
      window.localStorage.setItem('calsen-today-water', String(next));
      this.setState({ todayWater: next, waterToast: true });
      setTimeout(() => this.setState({ waterToast: false }), 2000);
    } catch (err) {
      const current = this.state?.todayWater ?? 1.5;
      this.setState({ todayWater: current + 0.25 });
    }
  };

  renderVals() {
    const st = this.state || {};
    const mode = this.modeNow();
    const dark = this.isDark(mode);
    const base = this.props.accent ?? '#FF5C00';
    const accent = this.accentFor(base, dark);
    const accentInk = dark ? '#FF9A5C' : '#C2410C';
    const accent2 = this.lighten(accent, 0.28);
    const glow = dark ? this.glowOf(accent, 0.5) : 'none';
    const fmt = (n) => Number(n).toLocaleString('en-US');

    let savedGoal = 2000;
    let savedTG = { P: 150, C: 200, F: 67 };
    try {
      const g = Number(window.localStorage.getItem('calsen-target-cals'));
      if (g && !isNaN(g) && g > 800) savedGoal = Math.round(g);
      const p = Number(window.localStorage.getItem('calsen-protein'));
      const c = Number(window.localStorage.getItem('calsen-carbs'));
      const f = Number(window.localStorage.getItem('calsen-fat'));
      if (p && c && f) savedTG = { P: Math.round(p), C: Math.round(c), F: Math.round(f) };
    } catch (e) {}

    const GOAL = savedGoal;
    const TG = savedTG;
    const TODAY = 14; // index of today in strip
    const sel = st.sel ?? TODAY;
    const KC = [1940, 0, 2210, 1880, 2125, 0, 1975, 2320, 1850, 2150, 0, 2040]; // Sep 25 .. Oct 6
    const split = (k, i) => {
      if (!k) return [[0, 0], [0, 0], [0, 0], [0, 0]];
      const b = Math.round(k * 0.24 / 10) * 10, l = Math.round(k * 0.38 / 10) * 10, sn = Math.round(k * 0.08 / 10) * 10;
      return [[b, 3], [l, 4], [k - b - l - sn, 3], [sn, 1 + (i % 2)]];
    };
    const mk = (off, k, burn, mealsOverride, macroOverride) => {
      const dt = new Date(2026, 9, 9 + off);
      const i = off + TODAY;
      const m = macroOverride || (k ? { P: Math.round(k * 0.3 / 4), C: Math.round(k * 0.4 / 4), F: Math.round(k * 0.3 / 9) } : { P: 0, C: 0, F: 0 });
      return Object.assign({
        n: dt.toLocaleDateString('en-US', { weekday: 'short' }),
        mon: dt.toLocaleDateString('en-US', { month: 'short' }),
        d: dt.getDate(),
        off,
        burn: burn ?? (k ? 260 + ((i * 53) % 220) : 0),
        meals: mealsOverride || split(k, i)
      }, m);
    };
    const DAYS = [];
    for (let off = -14; off <= 14; off++) {
      if (off === -2) DAYS.push(mk(-2, 1960, 380, [[480, 3], [720, 4], [640, 3], [120, 1]], { P: 138, C: 201, F: 64 }));
      else if (off === -1) DAYS.push(mk(-1, 2165, 460, [[510, 3], [790, 4], [640, 3], [225, 2]], { P: 151, C: 214, F: 71 }));
      else if (off === 0) DAYS.push(mk(0, 1240, 320, [[420, 3], [820, 4], [0, 0], [0, 0]], { P: 92, C: 120, F: 43 }));
      else if (off < -2) DAYS.push(mk(off, KC[off + 14], null));
      else DAYS.push(mk(off, 0, 0));
    }
    const thumbBy = {};
    try {
      const sc = JSON.parse(window.localStorage.getItem('calsen-log') || '[]');
      (Array.isArray(sc) ? sc : []).filter((x) => x.date === '2026-10-09').forEach((x) => {
        const t0 = DAYS[TODAY];
        if (t0.meals[x.meal]) t0.meals[x.meal] = [t0.meals[x.meal][0] + x.kcal, t0.meals[x.meal][1] + 1];
        if (x.thumb) thumbBy[x.meal] = x.thumb;
        t0.P += x.p || 0; t0.C += x.c || 0; t0.F += x.f || 0;
      });
    } catch (e) {}
    const kc = (d) => d.meals.reduce((a, m) => a + m[0], 0);
    const statusOf = (d) => {
      if (d.off >= 0) return null;
      const k = kc(d);
      if (!k) return 'none';
      const ov = k - GOAL;
      return ov >= 200 ? 'bad' : ov >= 100 ? 'warn' : 'ok';
    };
    const FILL = { ok: '#10B981', warn: '#F59E0B', bad: '#EF4444', none: '#64748B' };
    const INK = { ok: '#FFFFFF', warn: '#2B1A00', bad: '#FFFFFF', none: '#FFFFFF' };
    const STATUS_TXT = { ok: 'on target', warn: 'a little over', bad: 'well over', none: 'not used' };

    const CIRC = 2 * Math.PI * 14;
    const RING = { ok: '#10B981', warn: '#F59E0B', bad: '#EF4444', none: '#94A3B8' };
    const ringOf = (d, st2) => {
      if (st2 === 'none') return { color: RING.none, dash: '2.6 3.4' };
      const k = kc(d);
      const p = Math.min(1, k / GOAL);
      if (st2) return { color: RING[st2], dash: (CIRC * p).toFixed(1) + ' ' + CIRC.toFixed(1) };
      if (d.off === 0) return { color: accent, dash: (CIRC * p).toFixed(1) + ' ' + CIRC.toFixed(1) };
      return { color: 'transparent', dash: '0 ' + CIRC.toFixed(1) };
    };
    const days = DAYS.map((d, i) => {
      const on = i === sel;
      const st2 = statusOf(d);
      return {
        label: d.n,
        num: String(d.d),
        today: i === TODAY ? 'true' : 'false',
        aria: d.n + ' ' + d.mon + ' ' + d.d + (i === TODAY ? ', today' : st2 ? ', ' + STATUS_TXT[st2] : ''),
        pressed: on ? 'true' : 'false',
        edge: on ? (dark ? accent : 'transparent') : 'var(--edge)',
        bg: 'var(--glass)',
        shadow: on ? (dark ? '0 0 14px ' + this.glowOf(accent, 0.45) : '0 6px 14px ' + this.glowOf(accent, 0.22)) : 'none',
        labelInk: on ? 'var(--ink)' : 'var(--muted)',
        discBg: on ? 'linear-gradient(145deg, ' + this.lighten(accent, 0.22) + ', ' + accent + ')' : 'transparent',
        trackColor: on ? 'rgba(255,255,255,.35)' : 'var(--track)',
        numInk: on ? '#FFFFFF' : 'var(--ink)',
        ringColor: on && !st2 ? '#FFFFFF' : ringOf(d, st2).color,
        ringDash: ringOf(d, st2).dash,
        pick: () => { if (this.justDragged) return; this.setState({ sel: i }); }
      };
    });

    const D = DAYS[sel];
    const kcal = kc(D);
    const cur = this.tw({ kcal, burn: D.burn, P: D.P, C: D.C, F: D.F }, 520);
    const left = GOAL - kcal;
    const over = left < 0;
    const pct = Math.round((kcal / GOAL) * 100);
    const BOLT = 'M13 2L4 14h7l-1 8 9-12h-7z';
    let pill;
    if (kcal === 0) pill = { text: 'Ready to log', bg: 'var(--chip)', ink: 'var(--muted)', icon: 'M12 5v14 M5 12h14' };
    else if (over) pill = { text: fmt(Math.max(0, Math.round(cur.kcal - GOAL))) + ' kcal over', bg: 'var(--danger-bg)', ink: 'var(--danger)', icon: BOLT };
    else pill = { text: fmt(Math.max(0, Math.round(GOAL - cur.kcal))) + ' kcal left', bg: 'var(--soft-bg)', ink: 'var(--soft-ink)', icon: BOLT };

    const gdash = (p, r) => {
      const C = 2 * Math.PI * r;
      return (C * 0.75 * p).toFixed(1) + ' ' + C.toFixed(1);
    };
    const MS = this.macroSet(dark);
    const macros = [
      Object.assign({ k: 'P', name: 'Protein', kind: 'P' }, MS.P),
      Object.assign({ k: 'C', name: 'Carbs', kind: 'C' }, MS.C),
      Object.assign({ k: 'F', name: 'Fat', kind: 'F' }, MS.F)
    ].map((m) => {
      const got = D[m.k];
      const t = TG[m.k];
      const gap = t - got;
      const isOver = gap < 0;
      const shown = cur[m.k];
      const p = Math.min(1, shown / t);
      return {
        value: Math.abs(Math.round(t - shown)) + 'g',
        label: m.name + (isOver ? ' over' : ' left'),
        labelInk: isOver ? 'var(--danger)' : 'var(--muted)',
        color: m.color,
        light: m.light,
        mid: m.mid,
        dark: m.dark,
        tint: this.glowOf(m.color, dark ? 0.2 : 0.14),
        isP: m.kind === 'P',
        isC: m.kind === 'C',
        isF: m.kind === 'F',
        dash: gdash(p, 30),
        glow: dark ? 'drop-shadow(0 0 5px ' + this.glowOf(m.color, 0.6) + ')' : 'none',
        aria: m.name + ': ' + got + ' of ' + t + ' grams eaten'
      };
    });

    const SUNI = 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M12 3v2 M12 19v2 M3 12h2 M19 12h2 M5.6 5.6l1.4 1.4 M17 17l1.4 1.4 M5.6 18.4L7 17 M17 7l1.4-1.4';
    const BOWL = 'M3 11h18a9 9 0 0 1-18 0z M8 7c0-1 1-1.5 1-3 M13 7c0-1 1-1.5 1-3';
    const MOONI = 'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z';
    const COOKIE = 'M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5z M8.5 8.5v.01 M16 15.5v.01 M12 12v.01 M11 17v.01 M7 14v.01';
    const defs = [
      { name: 'Breakfast', icon: SUNI, add: 'breakfast' },
      { name: 'Lunch', icon: BOWL, add: 'lunch' },
      { name: 'Dinner', icon: MOONI, add: 'dinner' },
      { name: 'Snacks', icon: COOKIE, add: 'snacks' }
    ];
    const IMG = MEAL_ART;
    const nextUp = sel >= TODAY ? D.meals.findIndex((m) => m[1] === 0) : -1;
    const meals = defs.map((m, i) => {
      const [k, n] = D.meals[i];
      const logged = n > 0;
      const main = i === nextUp;
      const dishList = MEAL_DISHES[i] || [];
      const itemDishes = [];
      if (sel === TODAY && thumbBy[i]) {
        itemDishes.push(thumbBy[i]);
      }
      dishList.forEach((url) => {
        if (itemDishes.length < Math.min(Math.max(n, 1), 3)) {
          if (!itemDishes.includes(url)) itemDishes.push(url);
        }
      });
      if (!itemDishes.length) itemDishes.push(dishList[0] || IMG[i]);

      return {
        name: m.name,
        icon: m.icon,
        logged,
        itemCount: n,
        sub: logged ? n + (n === 1 ? ' item' : ' items') : (sel > TODAY ? 'Plan ahead' : sel < TODAY ? 'No entries' : 'Not logged'),
        kcal: logged ? fmt(k) : '0',
        unit: 'kcal',
        kcalInk: logged ? 'var(--ink)' : 'var(--muted)',
        addLabel: 'Add to ' + m.add,
        dishes: itemDishes,
        previewDish: dishList[0] || IMG[i],
        fallbackArt: IMG[i],
        phFilter: logged ? 'none' : (dark ? 'grayscale(0.5) brightness(0.7)' : 'grayscale(0.4) opacity(0.6)'),
        padL: dark ? '16px' : '22px',
        stripe: dark ? 'none' : 'block',
        tileR: dark ? '14px' : '20px',
        tileBg: dark ? 'rgba(255,131,18,.14)' : '#FDE6D6',
        ringC: dark ? '#0F0F10' : '#FFFFFF',
        plusBg: dark ? '#232326' : '#F5F5F7',
        plusInk: dark ? '#FFFFFF' : '#6B7280',
        plusBorder: dark ? '0' : '1px solid #E5E7EB',
        go: () => { try { window.localStorage.setItem('calsen-meal', String(i)); } catch (e) {} },
        btnBg: 'var(--ink)',
        btnInk: 'var(--bgc)',
        btnShadow: 'none'
      };
    });

    return {
      accent,
      accent2,
      accentInk,
      logoInk: accent,
      flameBg: dark ? '#050505' : 'var(--soft-bg)',
      isLight: !dark,
      isDarkUi: dark,
      glow: this.glowOf(accent, dark ? 0.45 : 0.3),
      themeKey: dark ? 'dark' : 'light',
      themeIcon: dark ? SUNI : MOONI,
      themeAria: dark ? 'Switch to light mode' : 'Switch to dark mode',
      toggleTheme: () => this.setMode(dark ? 'light' : 'dark'),
      days,
      onDown: (e) => {
        const el = e.currentTarget;
        this.drag = { x: e.clientX, sl: el.scrollLeft, moved: false };
        el.classList.add('dragging');
      },
      onMove: (e) => {
        if (!this.drag) return;
        const dx = e.clientX - this.drag.x;
        if (Math.abs(dx) > 5) { this.drag.moved = true; this.justDragged = true; }
        e.currentTarget.scrollLeft = this.drag.sl - dx;
      },
      onUp: (e) => {
        if (!this.drag) return;
        e.currentTarget.classList.remove('dragging');
        this.drag = null;
        setTimeout(() => { this.justDragged = false; }, 60);
      },
      pill,
      consumed: fmt(Math.round(cur.kcal)),
      goalText: fmt(GOAL),
      counterGlow: dark ? '0 0 22px ' + this.glowOf(accent, 0.4) : 'none',
      burned: fmt(Math.round(cur.burn)),
      pctText: Math.round((cur.kcal / GOAL) * 100) + '%',
      heroDash: gdash(Math.min(1, cur.kcal / GOAL), 42),
      heroColor: over ? 'var(--danger)' : accent,
      heroGlow: dark ? 'drop-shadow(0 0 7px ' + this.glowOf(over ? '#F87171' : accent, 0.6) + ')' : 'none',
      gaugeAria: pct + ' percent of your daily calorie goal',
      macros,
      mealsTitle: sel === TODAY ? (getCurrentLang() === 'العربية' ? "وجبات اليوم" : "Today's meals") : (getCurrentLang() === 'العربية' ? "الوجبات · " : "Meals · ") + D.n + ', ' + D.mon + ' ' + D.d,
      heroTitle: sel === TODAY ? (getCurrentLang() === 'العربية' ? "سعرات اليوم" : "Today's calories") : D.n + ', ' + D.mon + ' ' + D.d,
      meals,
      dark,
      isAr: getCurrentLang() === 'العربية',
      rawKcal: Math.round(cur.kcal),
      goalNum: GOAL,
      isOver: (GOAL - Math.round(cur.kcal)) < 0,
      remKcalText: (getCurrentLang() === 'العربية')
        ? ((GOAL - Math.round(cur.kcal)) < 0 ? `${fmt(Math.abs(GOAL - Math.round(cur.kcal)))} سعرة زائدة` : `${fmt(GOAL - Math.round(cur.kcal))} سعرة متبقية`)
        : ((GOAL - Math.round(cur.kcal)) < 0 ? `${fmt(Math.abs(GOAL - Math.round(cur.kcal)))} kcal over` : `${fmt(GOAL - Math.round(cur.kcal))} kcal remaining`),
      curP: cur.P,
      targetP: TG.P,
      remPText: (getCurrentLang() === 'العربية')
        ? (TG.P - Math.round(cur.P) < 0 ? `${Math.abs(TG.P - Math.round(cur.P))} غ فائض` : `${TG.P - Math.round(cur.P)} غ متبقي`)
        : (TG.P - Math.round(cur.P) < 0 ? `${Math.abs(TG.P - Math.round(cur.P))}g over` : `${TG.P - Math.round(cur.P)}g remaining`),
      curC: cur.C,
      targetC: TG.C,
      remCText: (getCurrentLang() === 'العربية')
        ? (TG.C - Math.round(cur.C) < 0 ? `${Math.abs(TG.C - Math.round(cur.C))} غ فائض` : `${TG.C - Math.round(cur.C)} غ متبقي`)
        : (TG.C - Math.round(cur.C) < 0 ? `${Math.abs(TG.C - Math.round(cur.C))}g over` : `${TG.C - Math.round(cur.C)}g remaining`),
      curF: cur.F,
      targetF: TG.F,
      remFText: (getCurrentLang() === 'العربية')
        ? (TG.F - Math.round(cur.F) < 0 ? `${Math.abs(TG.F - Math.round(cur.F))} غ فائض` : `${TG.F - Math.round(cur.F)} غ متبقي`)
        : (TG.F - Math.round(cur.F) < 0 ? `${Math.abs(TG.F - Math.round(cur.F))}g over` : `${TG.F - Math.round(cur.F)}g remaining`),
      stepsCount: Number(window.localStorage.getItem('calsen-today-steps')) || 3482,
      stepsGoal: Number(window.localStorage.getItem('calsen-steps')) || 8000,
      waterL: this.state?.todayWater ?? (Number(window.localStorage.getItem('calsen-today-water')) || 1.5),
      waterGoalL: Number(window.localStorage.getItem('calsen-water-goal')) || 2.5,
    };
  }

  render() {
    const v = this.renderVals();
    const dark = v.dark;
    const isAr = v.isAr;
    return (
      <div
        className="app"
        data-theme={v.themeKey}
        style={{
          position: 'relative',
          width: '390px',
          height: '844px',
          boxSizing: 'border-box',
          fontFamily: '\'Plus Jakarta Sans\', system-ui, sans-serif',
          overflow: 'hidden',
        }}
      >
        {this.state?.waterToast && (
          <div
            style={{
              position: 'absolute',
              top: '20px',
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 999,
              background: '#0284C7',
              color: '#FFFFFF',
              padding: '7px 16px',
              borderRadius: '9999px',
              fontSize: '13px',
              fontWeight: '700',
              boxShadow: '0 8px 24px rgba(2, 132, 199, 0.4)',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              pointerEvents: 'none',
            }}
          >
            💧 {v.isAr ? `+250 مل (${v.waterL.toFixed(1)} لتر)` : `+250ml (${v.waterL.toFixed(1)} L)`}
          </div>
        )}
        <div
          className="scroll"
          style={{
            position: 'absolute',
            left: '0',
            top: '0',
            right: '0',
            bottom: '0',
            overflowY: 'auto',
            overflowX: 'hidden',
            overscrollBehavior: 'contain',
          }}
        >
          <div
            className="stagger"
            style={{
              boxSizing: 'border-box',
              padding: '24px 20px 112px 20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <img
                  src={bananaImg}
                  alt=""
                  aria-hidden="true"
                  style={{
                    height: '34px',
                    width: 'auto',
                    display: 'block',
                    flex: 'none',
                  }}
                 />
                <span
                  style={{
                    fontSize: '24px',
                    lineHeight: '30px',
                    fontWeight: '800',
                    letterSpacing: '-0.03em',
                    color: v.logoInk,
                  }}
                >CalSen</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button className="rbtn" aria-label={v.themeAria} onClick={v.toggleTheme}>
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.9"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d={v.themeIcon}></path>
                  </svg>
                </button>
                <button className="rbtn" aria-label="Notifications, 1 new">
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15z"></path>
                    <path d="M10 21a2 2 0 0 0 4 0"></path>
                  </svg>
                  <span
                    style={{
                      position: 'absolute',
                      top: '10px',
                      right: '11px',
                      boxSizing: 'border-box',
                      width: '11px',
                      height: '11px',
                      borderRadius: '6px',
                      background: v.accent,
                      border: '2px solid var(--glass)',
                    }}
                  ></span>
                </button>
                <a
                  href={ROUTES.profile}
                  className="rbtn"
                  aria-label="Profile and settings"
                  onClick={(e) => { go(e, 'profile', this.props); }}
                >
                  <svg
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.9"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <circle cx="12" cy="8" r="4"></circle>
                    <path d="M4 21c0-4 4-6 8-6s8 2 8 6"></path>
                  </svg>
                </a>
              </div>
            </div>
            <div
              id="week-strip"
              className="strip scroll"
              role="group"
              aria-label="Week, drag to see other days"
              onMouseDown={v.onDown}
              onMouseMove={v.onMove}
              onMouseUp={v.onUp}
              onMouseLeave={v.onUp}
              style={{
                position: 'relative',
                display: 'flex',
                gap: '10px',
                overflowX: 'auto',
                overflowY: 'hidden',
                margin: '0',
                padding: '4px 0 12px 0',
                scrollPadding: '0',
                cursor: 'grab',
                touchAction: 'pan-x',
                WebkitUserSelect: 'none',
                userSelect: 'none',
              }}
            >
              {v.days.map((d, i1) => (
                <React.Fragment key={i1}>
                  <button
                    data-today={d.today}
                    aria-label={d.aria}
                    aria-pressed={d.pressed}
                    style={{
                      flex: 'none',
                      width: 'calc((100% - 60px) / 7)',
                      height: '66px',
                      scrollSnapAlign: 'start',
                      borderRadius: '20px',
                      border: `1px solid ${d.edge}`,
                      background: d.bg,
                      boxShadow: d.shadow,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '5px',
                      padding: '0',
                      cursor: 'inherit',
                      color: 'var(--ink)',
                    }}
                    onClick={d.pick}
                  >
                    <span
                      style={{
                        fontSize: '9.5px',
                        lineHeight: '12px',
                        fontWeight: '700',
                        color: d.labelInk,
                      }}
                    >{d.label}</span>
                    <span
                      style={{
                        position: 'relative',
                        width: '36px',
                        height: '36px',
                        borderRadius: '18px',
                        background: d.discBg,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <svg
                        width="36"
                        height="36"
                        viewBox="0 0 36 36"
                        fill="none"
                        aria-hidden="true"
                        style={{ position: 'absolute', left: '0', top: '0' }}
                      >
                        <circle cx="18" cy="18" r="14" strokeWidth="3" style={{ stroke: d.trackColor }}></circle>
                        <circle
                          cx="18"
                          cy="18"
                          r="14"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeDasharray={d.ringDash}
                          transform="rotate(-90 18 18)"
                          style={{ stroke: d.ringColor }}
                        ></circle>
                      </svg>
                      <span
                        style={{
                          position: 'relative',
                          fontSize: '12px',
                          fontWeight: '800',
                          color: d.numInk,
                        }}
                      >{d.num}</span>
                    </span>
                  </button>
                </React.Fragment>
              ))}
            </div>
            {/* Card 1: Today's calories - in a standalone card */}
            <section
              aria-label="Today's calories"
              className="glass"
              style={{
                borderRadius: '24px',
                padding: '20px 22px',
                background: 'var(--glass, #FFFFFF)',
                border: '1px solid var(--edge)',
                boxShadow: dark ? 'none' : '0 4px 20px rgba(0, 0, 0, 0.04)',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '10px',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span
                    style={{
                      color: '#FF5C00',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#FF5C00"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M12 3c.8 3.2 4.5 5 4.5 9.2a4.5 4.5 0 0 1-9 0c0-1.7.7-3 1.7-4C9.8 9.6 11.5 8 12 3z"></path>
                    </svg>
                  </span>
                  <span
                    style={{
                      fontSize: '15px',
                      fontWeight: '700',
                      color: 'var(--ink)',
                    }}
                  >
                    {isAr ? "سعرات اليوم" : "Today's calories"}
                  </span>
                </div>
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px',
                    padding: '4px 12px',
                    borderRadius: '9999px',
                    fontSize: '12px',
                    fontWeight: '700',
                    background: v.isOver ? '#FEE2E2' : '#ECFDF5',
                    color: v.isOver ? '#DC2626' : '#10B981',
                    border: 'none',
                  }}
                >
                  {v.isOver ? (
                    <>⚠️ {isAr ? 'تجاوز الهدف' : 'Over budget'}</>
                  ) : (
                    <>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                      {isAr ? 'في المسار' : 'On track'}
                    </>
                  )}
                </span>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '12px',
                }}
              >
                <div style={{ flex: '1', minWidth: '0' }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'baseline',
                      gap: '6px',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '38px',
                        lineHeight: '42px',
                        fontWeight: '800',
                        letterSpacing: '-0.03em',
                        color: '#FF5C00',
                      }}
                    >
                      {v.consumed}
                    </span>
                    <span
                      style={{
                        fontSize: '18px',
                        lineHeight: '24px',
                        fontWeight: '700',
                        color: 'var(--ink)',
                      }}
                    >
                      / {v.goalText} {isAr ? 'سعرة' : 'kcal'}
                    </span>
                  </div>

                  <div
                    style={{
                      width: '100%',
                      height: '10px',
                      background: 'var(--track, #F3F4F6)',
                      borderRadius: '5px',
                      overflow: 'hidden',
                      margin: '12px 0 8px 0',
                    }}
                  >
                    <div
                      style={{
                        width: `${Math.min(100, Math.max(5, Math.round((v.rawKcal / v.goalNum) * 100)))}%`,
                        height: '100%',
                        background: 'linear-gradient(90deg, #FF8A3D 0%, #FF5C00 100%)',
                        borderRadius: '5px',
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px',
                      fontSize: '13px',
                      fontWeight: '600',
                      color: 'var(--muted)',
                    }}
                  >
                    <svg
                      width="13"
                      height="13"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#FF5C00"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M12 3c.8 3.2 4.5 5 4.5 9.2a4.5 4.5 0 0 1-9 0c0-1.7.7-3 1.7-4C9.8 9.6 11.5 8 12 3z"></path>
                    </svg>
                    <span>{v.remKcalText}</span>
                  </div>
                </div>

                {/* Circular ring indicator */}
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px',
                    flex: 'none',
                  }}
                >
                  <div style={{ position: 'relative', width: '74px', height: '74px' }}>
                    <svg
                      width="74"
                      height="74"
                      viewBox="0 0 80 80"
                      fill="none"
                      style={{ display: 'block', overflow: 'visible' }}
                    >
                      <circle
                        cx="40"
                        cy="40"
                        r="32"
                        stroke="var(--track, #F3F4F6)"
                        strokeWidth="8"
                        strokeLinecap="round"
                      />
                      <circle
                        cx="40"
                        cy="40"
                        r="32"
                        stroke="#FF5C00"
                        strokeWidth="8"
                        strokeLinecap="round"
                        strokeDasharray="201"
                        strokeDashoffset={Math.max(0, 201 - (201 * Math.min(1, v.rawKcal / v.goalNum)))}
                        transform="rotate(-90 40 40)"
                        style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                      />
                    </svg>
                    <div
                      style={{
                        position: 'absolute',
                        inset: 0,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <span style={{ color: '#FF5C00' }}>
                        <svg
                          width="22"
                          height="22"
                          viewBox="0 0 24 24"
                          fill="#FF5C00"
                          stroke="#FF5C00"
                          strokeWidth="1"
                        >
                          <path d="M12 3c.8 3.2 4.5 5 4.5 9.2a4.5 4.5 0 0 1-9 0c0-1.7.7-3 1.7-4C9.8 9.6 11.5 8 12 3z"></path>
                        </svg>
                      </span>
                    </div>
                  </div>
                  <span style={{ fontSize: '14px', fontWeight: '800', color: 'var(--ink)' }}>
                    {Math.round((v.rawKcal / v.goalNum) * 100)}%
                  </span>
                </div>
              </div>
            </section>

            {/* Card 2: Macros (Protein, Carbs, Fat) - in a standalone card */}
            <section
              aria-label="Macros breakdown"
              className="glass"
              style={{
                borderRadius: '24px',
                padding: '16px',
                background: 'var(--glass, #FFFFFF)',
                border: '1px solid var(--edge)',
                boxShadow: dark ? 'none' : '0 4px 20px rgba(0, 0, 0, 0.04)',
              }}
            >
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
                  gap: '10px',
                }}
              >
                {/* 1. Protein */}
                <div
                  style={{
                    background: dark ? 'rgba(255, 138, 61, 0.12)' : '#FFF7ED',
                    borderRadius: '20px',
                    padding: '14px 10px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    boxSizing: 'border-box',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span
                      style={{
                        width: '28px',
                        height: '28px',
                        borderRadius: '14px',
                        background: dark ? 'rgba(255, 138, 61, 0.25)' : '#FFEDD5',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#EA580C',
                        flex: 'none',
                      }}
                    >
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m6.5 6.5 11 11" /><path d="m21 21-1-1a2 2 0 0 0-2.8 0l-.7.7a2 2 0 0 1-2.8 0l-1.4-1.4a2 2 0 0 1 0-2.8l.7-.7a2 2 0 0 0 0-2.8l-1-1" /><path d="m3 3 1 1a2 2 0 0 0 2.8 0l.7-.7a2 2 0 0 1 2.8 0l1.4 1.4a2 2 0 0 1 0 2.8l-.7.7a2 2 0 0 0 0 2.8l1 1" />
                      </svg>
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#EA580C' }}>
                      {isAr ? 'بروتين' : 'Protein'}
                    </span>
                  </div>

                  <div>
                    <span style={{ fontSize: '18px', fontWeight: '800', color: 'var(--ink)' }}>
                      {Math.round(v.curP)}g
                    </span>
                    <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                      {' '}/ {v.targetP}g
                    </span>
                  </div>

                  <div
                    style={{
                      width: '100%',
                      height: '6px',
                      background: dark ? 'rgba(255, 255, 255, 0.1)' : '#FFEDD5',
                      borderRadius: '3px',
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        width: `${Math.min(100, Math.round((v.curP / v.targetP) * 100))}%`,
                        height: '100%',
                        background: '#EA580C',
                        borderRadius: '3px',
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>

                  <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)', whiteSpace: 'nowrap' }}>
                    {v.remPText}
                  </span>
                </div>

                {/* 2. Carbs */}
                <div
                  style={{
                    background: dark ? 'rgba(142, 82, 224, 0.12)' : '#FAF5FF',
                    borderRadius: '20px',
                    padding: '14px 10px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    boxSizing: 'border-box',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span
                      style={{
                        width: '28px',
                        height: '28px',
                        borderRadius: '14px',
                        background: dark ? 'rgba(142, 82, 224, 0.25)' : '#F3E8FF',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#9333EA',
                        flex: 'none',
                      }}
                    >
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2 22 16 8" /><path d="M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z" /><path d="M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z" /><path d="M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z" /><path d="M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z" /><path d="M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z" /><path d="M15.47 13.47 17 15l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z" /><path d="M19.47 9.47 21 11l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L13 11l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z" />
                      </svg>
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#9333EA' }}>
                      {isAr ? 'كارب' : 'Carbs'}
                    </span>
                  </div>

                  <div>
                    <span style={{ fontSize: '18px', fontWeight: '800', color: 'var(--ink)' }}>
                      {Math.round(v.curC)}g
                    </span>
                    <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                      {' '}/ {v.targetC}g
                    </span>
                  </div>

                  <div
                    style={{
                      width: '100%',
                      height: '6px',
                      background: dark ? 'rgba(255, 255, 255, 0.1)' : '#F3E8FF',
                      borderRadius: '3px',
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        width: `${Math.min(100, Math.round((v.curC / v.targetC) * 100))}%`,
                        height: '100%',
                        background: '#9333EA',
                        borderRadius: '3px',
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>

                  <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)', whiteSpace: 'nowrap' }}>
                    {v.remCText}
                  </span>
                </div>

                {/* 3. Fat */}
                <div
                  style={{
                    background: dark ? 'rgba(52, 184, 92, 0.12)' : '#F0FDF4',
                    borderRadius: '20px',
                    padding: '14px 10px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    boxSizing: 'border-box',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span
                      style={{
                        width: '28px',
                        height: '28px',
                        borderRadius: '14px',
                        background: dark ? 'rgba(52, 184, 92, 0.25)' : '#DCFCE7',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#16A34A',
                        flex: 'none',
                      }}
                    >
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
                      </svg>
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#16A34A' }}>
                      {isAr ? 'دهون' : 'Fat'}
                    </span>
                  </div>

                  <div>
                    <span style={{ fontSize: '18px', fontWeight: '800', color: 'var(--ink)' }}>
                      {Math.round(v.curF)}g
                    </span>
                    <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                      {' '}/ {v.targetF}g
                    </span>
                  </div>

                  <div
                    style={{
                      width: '100%',
                      height: '6px',
                      background: dark ? 'rgba(255, 255, 255, 0.1)' : '#DCFCE7',
                      borderRadius: '3px',
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        width: `${Math.min(100, Math.round((v.curF / v.targetF) * 100))}%`,
                        height: '100%',
                        background: '#16A34A',
                        borderRadius: '3px',
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>

                  <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)', whiteSpace: 'nowrap' }}>
                    {v.remFText}
                  </span>
                </div>
              </div>
            </section>

            {/* Row 3: Steps & Water (عدادين خاصين بالماء والخطوات مع زر زيادة الماء) */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
                gap: '12px',
              }}
            >
              {/* Steps Card */}
              <div
                className="glass"
                onClick={() => go(ROUTES.profile)}
                role="button"
                tabIndex={0}
                style={{
                  borderRadius: '20px',
                  padding: '12px 14px',
                  background: 'var(--glass, #FFFFFF)',
                  border: '1px solid var(--edge)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  boxShadow: dark ? 'none' : '0 4px 20px rgba(0, 0, 0, 0.04)',
                  cursor: 'pointer',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span
                      style={{
                        width: '32px',
                        height: '32px',
                        borderRadius: '16px',
                        background: dark ? 'rgba(255, 138, 61, 0.2)' : '#FFF7ED',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#EA580C',
                        flex: 'none',
                      }}
                    >
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M4 16v-2.38C4 11.5 7 11 7 11l1-4c.5-2 2-3 4-3s3.5 1 4 3l1 4s3 .5 3 2.62V16" />
                        <path d="M4 20h16" />
                      </svg>
                    </span>
                    <div>
                      <div style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                        {isAr ? 'الخطوات' : 'Steps'}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: '3px' }}>
                        <span style={{ fontSize: '15px', fontWeight: '800', color: 'var(--ink)' }}>
                          {Number(v.stepsCount).toLocaleString('en-US')}
                        </span>
                        <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                          / {Number(v.stepsGoal).toLocaleString('en-US')}
                        </span>
                      </div>
                    </div>
                  </div>
                  <span style={{ color: 'var(--muted)', display: 'flex', alignItems: 'center' }}>
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      style={{ transform: isAr ? 'rotate(180deg)' : 'none' }}
                    >
                      <path d="m9 18 6-6-6-6" />
                    </svg>
                  </span>
                </div>
                <div style={{ width: '100%', height: '5px', background: 'var(--track, #F3F4F6)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div
                    style={{
                      width: `${Math.min(100, Math.round((v.stepsCount / v.stepsGoal) * 100))}%`,
                      height: '100%',
                      background: '#FF7A1A',
                      borderRadius: '3px',
                      transition: 'width 0.4s ease',
                    }}
                  />
                </div>
              </div>

              {/* Water Card with interactive button */}
              <div
                className="glass"
                style={{
                  borderRadius: '20px',
                  padding: '12px 14px',
                  background: 'var(--glass, #FFFFFF)',
                  border: '1px solid var(--edge)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  boxShadow: dark ? 'none' : '0 4px 20px rgba(0, 0, 0, 0.04)',
                  position: 'relative',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span
                      style={{
                        width: '32px',
                        height: '32px',
                        borderRadius: '16px',
                        background: dark ? 'rgba(14, 165, 233, 0.2)' : '#EFF6FF',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#0284C7',
                        flex: 'none',
                      }}
                    >
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
                      </svg>
                    </span>
                    <div>
                      <div style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                        {isAr ? 'الماء' : 'Water'}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: '3px' }}>
                        <span style={{ fontSize: '15px', fontWeight: '800', color: 'var(--ink)' }}>
                          {v.waterL.toFixed(1)} L
                        </span>
                        <span style={{ fontSize: '11px', fontWeight: '600', color: 'var(--muted)' }}>
                          / {v.waterGoalL.toFixed(1)} L
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Sleek interactive + button */}
                  <button
                    onClick={this.addWater}
                    title={isAr ? 'إضافة 250 مل ماء' : 'Add 250ml water'}
                    aria-label="Add 250ml water"
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '14px',
                      background: '#0EA5E9',
                      color: '#FFFFFF',
                      border: 'none',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      boxShadow: '0 2px 8px rgba(14, 165, 233, 0.35)',
                      fontSize: '18px',
                      fontWeight: '700',
                      lineHeight: 1,
                      flex: 'none',
                      padding: 0,
                    }}
                  >
                    +
                  </button>
                </div>

                <div style={{ width: '100%', height: '5px', background: 'var(--track, #F3F4F6)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div
                    style={{
                      width: `${Math.min(100, Math.round((v.waterL / v.waterGoalL) * 100))}%`,
                      height: '100%',
                      background: '#0EA5E9',
                      borderRadius: '3px',
                      transition: 'width 0.4s ease',
                    }}
                  />
                </div>
              </div>
            </div>
            <div className="stagger" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '10px',
                  margin: '0 0 2px 2px',
                }}
              >
                <h2
                  style={{
                    minWidth: '0',
                    margin: '0',
                    fontSize: '18px',
                    lineHeight: '24px',
                    fontWeight: '800',
                    letterSpacing: '-0.01em',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >{v.mealsTitle}</h2>
                <a
                  href={ROUTES.scanner}
                  aria-label="Scan a meal with the camera"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    height: '36px',
                    boxSizing: 'border-box',
                    padding: '0 14px 0 11px',
                    borderRadius: '18px',
                    background: 'var(--soft-bg)',
                    color: 'var(--soft-ink)',
                    fontSize: '13px',
                    fontWeight: '800',
                    textDecoration: 'none',
                    flex: 'none',
                    whiteSpace: 'nowrap',
                  }}
                  onClick={(e) => { go(e, 'scanner', this.props); }}
                >
                  <svg
                    width="17"
                    height="17"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M4 8h3l2-3h6l2 3h3v11H4z"></path>
                    <circle cx="12" cy="13" r="3.4"></circle>
                  </svg>
                  Scan meal
                </a>
              </div>
              {v.meals.map((m, i1) => (
                <React.Fragment key={i1}>
                  <div
                    className="glass"
                    style={{
                      position: 'relative',
                      overflow: 'hidden',
                      borderRadius: '22px',
                      padding: `14px 14px 14px ${m.padL}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '8px',
                    }}
                  >
                    <span
                      aria-hidden="true"
                      style={{
                        position: 'absolute',
                        left: '0',
                        top: '0',
                        bottom: '0',
                        width: '5px',
                        background: `linear-gradient(180deg, ${v.accent2}, ${v.accent})`,
                        display: m.stripe,
                      }}
                    ></span>
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '10px',
                        minWidth: '0',
                      }}
                    >
                      <span style={{ fontSize: '18px', lineHeight: '24px', fontWeight: '700' }}>{m.name}</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <span
                          aria-hidden="true"
                          style={{
                            width: '40px',
                            height: '40px',
                            borderRadius: m.tileR,
                            background: m.tileBg,
                            color: v.accent,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flex: 'none',
                          }}
                        >
                          <svg
                            width="22"
                            height="22"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.8"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d={m.icon}></path>
                          </svg>
                        </span>
                        <div style={{ display: 'flex', flexDirection: 'column', minWidth: '0' }}>
                          <span
                            style={{
                              fontSize: '17px',
                              lineHeight: '22px',
                              fontWeight: '700',
                              whiteSpace: 'nowrap',
                              color: m.kcalInk,
                            }}
                          >
                            {m.kcal}{' '}
                            <span style={{ fontSize: '13px', fontWeight: '600', color: 'var(--muted)' }}>{m.unit}</span>
                          </span>
                          <span
                            style={{
                              fontSize: '12px',
                              lineHeight: '16px',
                              fontWeight: '600',
                              color: 'var(--muted)',
                            }}
                          >{m.sub}</span>
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', flex: 'none' }}>
                      <div aria-hidden="true" style={{ display: 'flex', alignItems: 'center' }}>
                        {m.logged ? (
                          m.dishes.map((src, di) => (
                            <img
                              key={di}
                              src={src}
                              alt=""
                              style={{
                                width: '48px',
                                height: '48px',
                                borderRadius: '24px',
                                objectFit: 'cover',
                                border: `2.5px solid ${m.ringC}`,
                                boxSizing: 'border-box',
                                marginLeft: di > 0 ? '-14px' : '0',
                                boxShadow: '0 2px 6px rgba(0,0,0,0.18)',
                                backgroundColor: '#181012',
                                filter: m.phFilter,
                              }}
                              onError={(e) => { e.currentTarget.src = m.fallbackArt; }}
                            />
                          ))
                        ) : (
                          <img
                            src={m.previewDish}
                            alt=""
                            style={{
                              width: '48px',
                              height: '48px',
                              borderRadius: '24px',
                              objectFit: 'cover',
                              border: `2px dashed ${m.ringC}`,
                              boxSizing: 'border-box',
                              opacity: 0.65,
                              filter: m.phFilter,
                              backgroundColor: '#181012',
                            }}
                            onError={(e) => { e.currentTarget.src = m.fallbackArt; }}
                          />
                        )}
                      </div>
                      <a
                        href={ROUTES.scanner}
                        className="add"
                        aria-label={m.addLabel}
                        style={{
                          marginLeft: '-4px',
                          position: 'relative',
                          width: '46px',
                          height: '46px',
                          boxSizing: 'border-box',
                          borderRadius: '23px',
                          background: m.plusBg,
                          color: m.plusInk,
                          border: m.plusBorder,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flex: 'none',
                          textDecoration: 'none',
                        }}
                        onClick={(e) => { m.go(e); go(e, 'scanner', this.props); }}
                      >
                        <svg
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2.4"
                          strokeLinecap="round"
                          aria-hidden="true"
                        >
                          <path d="M12 5v14"></path>
                          <path d="M5 12h14"></path>
                        </svg>
                      </a>
                    </div>
                  </div>
                </React.Fragment>
              ))}
            </div>

            {/* CalSen Pro Subscription Section that appears when scrolling down */}
            <div
              className="card glass"
              style={{
                position: 'relative',
                overflow: 'hidden',
                borderRadius: '26px',
                padding: '22px 20px',
                background: v.dark
                  ? 'linear-gradient(145deg, rgba(255,92,0,0.14) 0%, rgba(20,12,14,0.92) 100%)'
                  : 'linear-gradient(145deg, rgba(255,235,220,0.95) 0%, rgba(254,247,242,0.98) 100%)',
                border: `1.5px solid ${v.accent}`,
                boxShadow: v.dark ? '0 12px 32px rgba(255,92,0,0.18)' : '0 10px 28px rgba(255,92,0,0.12)',
                marginTop: '10px',
                marginBottom: '12px',
                direction: v.isAr ? 'rtl' : 'ltr',
              }}
            >
              {/* Top badge */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', marginBottom: '12px' }}>
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '4px 12px',
                    borderRadius: '999px',
                    background: v.dark ? 'rgba(255,92,0,0.22)' : 'rgba(255,92,0,0.15)',
                    border: '1px solid rgba(255,92,0,0.4)',
                    color: v.accent,
                    fontSize: '12px',
                    fontWeight: '800',
                    letterSpacing: '0.04em',
                  }}
                >
                  ⭐ {v.isAr ? 'كالسن برو' : 'CALSEN PRO'}
                </span>
                <span
                  style={{
                    fontSize: '11.5px',
                    fontWeight: '700',
                    color: '#FF7A24',
                    background: 'rgba(255,122,36,0.12)',
                    padding: '3px 10px',
                    borderRadius: '8px',
                  }}
                >
                  {v.isAr ? 'خصم 80% لفترة محدودة' : '80% OFF LIMITED OFFER'}
                </span>
              </div>

              {/* Title & Desc */}
              <h2
                style={{
                  margin: '0 0 6px 0',
                  fontSize: '20px',
                  lineHeight: '26px',
                  fontWeight: '800',
                  color: 'var(--ink)',
                }}
              >
                {v.isAr ? 'اشتراك كالسن برو' : 'CalSen Pro Subscription'}
              </h2>
              <p
                style={{
                  margin: '0 0 16px 0',
                  fontSize: '13.5px',
                  lineHeight: '1.5',
                  fontWeight: '500',
                  color: 'var(--muted)',
                }}
              >
                {v.isAr
                  ? 'حقق أهدافك أسرع بثلاث مرات مع مسح الوجبات اللامحدود بالذكاء الاصطناعي، وتحليل المغذيات الدقيقة وتوقعات نزول الوزن.'
                  : 'Reach your dream body 3x faster with unlimited AI meal scans, deep macro breakdowns, and personalized fat loss predictions.'}
              </p>

              {/* Key Features mini list */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '18px' }}>
                {[
                  { icon: '⚡', en: 'Unlimited AI Camera Meal Scans', ar: 'مسح غير محدود للوجبات بالذكاء الاصطناعي' },
                  { icon: '📊', en: 'Deep Macro & Micronutrients Analysis', ar: 'تحليل دقيق وتفصيلي للمغذيات والماكروز' },
                  { icon: '🎯', en: 'AI Deficit & Fat Loss Projections', ar: 'توقعات دقيقة للوصول لوزنك المثالي' },
                ].map((feat, idx) => (
                  <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: '600', color: 'var(--ink)' }}>
                    <span style={{ fontSize: '14px' }}>{feat.icon}</span>
                    <span>{v.isAr ? feat.ar : feat.en}</span>
                  </div>
                ))}
              </div>

              {/* Price & CTA */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '12px',
                  paddingTop: '12px',
                  borderTop: '1px solid var(--line)',
                  flexWrap: 'wrap',
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px' }}>
                    <span style={{ fontSize: '24px', fontWeight: '800', color: v.accent, lineHeight: 1 }}>$1.66</span>
                    <span style={{ fontSize: '12px', fontWeight: '600', color: 'var(--muted)' }}>{v.isAr ? '/ شهر' : '/ mo'}</span>
                  </div>
                  <span style={{ fontSize: '11px', fontWeight: '500', color: 'var(--muted)', display: 'block', marginTop: '2px' }}>
                    {v.isAr ? 'تجربة 3 أيام مجانية' : '3-Day Free Trial'}
                  </span>
                </div>

                <a
                  href={ROUTES.paywall}
                  onClick={(e) => {
                    go(e, 'paywall', this.props);
                  }}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px',
                    padding: '12px 18px',
                    borderRadius: '16px',
                    background: 'linear-gradient(135deg, #FF7A24, #F2570F)',
                    color: '#ffffff',
                    fontSize: '13.5px',
                    fontWeight: '700',
                    textDecoration: 'none',
                    boxShadow: '0 6px 18px rgba(242,87,15,0.4)',
                    cursor: 'pointer',
                    flex: 'none',
                  }}
                >
                  <span>{v.isAr ? 'عرض خطط الاشتراك' : 'View Subscription Plans'}</span>
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    style={{ transform: v.isAr ? 'rotate(180deg)' : 'none' }}
                  >
                    <path d="M5 12h14M13 6l6 6-6 6" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
        <BottomNav active="home" accent={v.accent} glow={v.glow} onNavigate={this.props.onNavigate} />
      </div>
    );
  }
}
