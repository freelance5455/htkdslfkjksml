import React, { useEffect, useMemo, useRef } from "react";
import { base44 } from "@/api/base44Client";
import bodyHtml from "@/tiempo/body.html?raw";
import tiempoCss from "@/tiempo/tiempo.css?raw";
import astroJs from "@/tiempo/astro.js?raw";
import appJs from "@/tiempo/app.js?raw";
import panelJs from "@/tiempo/panel.js?raw";

const fin = "</" + "script>";
const abrir = "<" + "script>";

/* ---------- datos técnicos de la visita ---------- */
function datosDispositivo() {
  let ua = "";
  try { ua = navigator.userAgent; } catch { return { dispositivo: "Desconocido", sistema: "—", navegador: "—" }; }
  let dispositivo = "Ordenador";
  if (/bot|crawler|spider|crawling|headless/i.test(ua)) dispositivo = "Bot";
  else if (/PlayStation|Xbox|Nintendo|CrKey|OUYA/i.test(ua)) dispositivo = "Consola";
  else if (/iPad|Tablet|PlayBook|Silk/i.test(ua) || (/Android/i.test(ua) && !/Mobile/i.test(ua))) dispositivo = "Tablet";
  else if (/Mobi|iPhone|Windows Phone/i.test(ua)) dispositivo = "Móvil";

  let sistema = "Desconocido";
  if (/Android/i.test(ua)) sistema = "Android";
  else if (/iPhone|iPad|iPod/i.test(ua)) sistema = "iOS";
  else if (/Windows NT/i.test(ua)) sistema = "Windows";
  else if (/Mac OS X/i.test(ua)) sistema = "macOS";
  else if (/Linux/i.test(ua)) sistema = "Linux";

  let navegador = "Otro";
  if (/Instagram/i.test(ua)) navegador = "Navegador de Instagram";
  else if (/FBAV|FB_IAB|FBAN|Facebook/i.test(ua)) navegador = "Navegador de Facebook";
  else if (/Snapchat/i.test(ua)) navegador = "Navegador de Snapchat";
  else if (/TikTok|Bytedance|ByteLocale/i.test(ua)) navegador = "Navegador de TikTok";
  else if (/WhatsApp/i.test(ua)) navegador = "Navegador de WhatsApp";
  else if (/Edg\//i.test(ua)) navegador = "Edge";
  else if (/OPR\/|Opera/i.test(ua)) navegador = "Opera";
  else if (/SamsungBrowser\//i.test(ua)) navegador = "Navegador Samsung";
  else if (/Firefox\//i.test(ua)) navegador = "Firefox";
  else if (/Chrome\//i.test(ua)) navegador = "Chrome";
  else if (/Safari\//i.test(ua)) navegador = "Safari";

  return { dispositivo, sistema, navegador };
}

function datosOrigen() {
  let ref = "";
  try { ref = document.referrer || ""; } catch { ref = ""; }
  if (!ref) return { origen: "Web directa", referrer: "" };
  let host = "";
  try { host = new URL(ref).hostname.toLowerCase().replace(/^www\./, ""); } catch {
    return { origen: "Web", referrer: ref.slice(0, 300) };
  }
  const tabla = [
    [/^(m\.)?instagram\.com$/, "Instagram"],
    [/^(m\.|web\.|mbasic\.)?facebook\.com$|^fb\.com$|^messenger\.com$/, "Facebook"],
    [/^(vm\.)?tiktok\.com$/, "TikTok"],
    [/^whatsapp\.com$|^chat\.whatsapp\.com$/, "WhatsApp"],
    [/^(mobile\.)?twitter\.com$|^x\.com$|^t\.co$/, "X (Twitter)"],
    [/^t\.me$|^telegram\.me$/, "Telegram"],
    [/^discord\.com$|^discordapp\.com$/, "Discord"],
    [/^snapchat\.com$/, "Snapchat"],
    [/^(m\.|music\.)?youtube\.com$|^youtu\.be$/, "YouTube"],
    [/^((old|new|es|m)\.)?reddit\.com$/, "Reddit"],
    [/^(\w{2,3}\.)?linkedin\.com$/, "LinkedIn"],
    [/^(www\.)?google\.(\w{2,3})$|^google\.es$/, "Buscador Google"],
    [/^(www\.)?bing\.com$/, "Buscador Bing"],
    [/^(www\.)?duckduckgo\.com$/, "Buscador DuckDuckGo"]
  ];
  for (const [re, nombre] of tabla) {
    if (re.test(host)) return { origen: nombre, referrer: ref.slice(0, 300) };
  }
  return { origen: "Web", referrer: ref.slice(0, 300) };
}

let visitaRegistrada = false;

export default function Home() {
  const enviado = useRef(false);

  const documento = useMemo(() => [
    "<!DOCTYPE html>",
    '<html lang="es">',
    "<head>",
    '<meta charset="UTF-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">',
    "<title>TiempoHoy — El tiempo donde tú estás</title>",
    '<link rel="preconnect" href="https://api.fontshare.com">',
    '<link rel="preconnect" href="https://fonts.googleapis.com">',
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>',
    '<link href="https://api.fontshare.com/v2/css?f[]=cabinet-grotesk@500,700,800&f[]=satoshi@400,500,700&display=swap" rel="stylesheet">',
    '<link href="https://fonts.googleapis.com/css2?family=Geist+Mono:wght@400;600&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">',
    '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">',
    '<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js">' + fin,
    "<style>" + tiempoCss + "</style>",
    "</head>",
    "<body>",
    bodyHtml,
    abrir + astroJs + fin,
    abrir + appJs + fin,
    abrir + panelJs + fin,
    "</body>",
    "</html>"
  ].join("\n"), []);

  /* puente de datos para el panel secreto */
  useEffect(() => {
    window.__tuTiempo = {
      list: (password) => base44.functions.invoke("visitas", { action: "list", password }).then(r => r.data),
      remove: (password, id) => base44.functions.invoke("visitas", { action: "delete", password, id }).then(r => r.data),
      favorite: (password, id, favorite) => base44.functions.invoke("visitas", { action: "favorite", password, id, favorite }).then(r => r.data)
    };
    return () => { delete window.__tuTiempo; };
  }, []);

  /* registrar la visita */
  useEffect(() => {
    if (enviado.current || visitaRegistrada) return;
    enviado.current = true;
    visitaRegistrada = true;

    const guardar = async () => {
      const tecnico = datosDispositivo();
      const origen = datosOrigen();
      let id = null;
      try {
        const res = await base44.functions.invoke("visitas", {
          action: "record",
          ...tecnico,
          ...origen,
          userAgent: navigator.userAgent
        });
        id = res?.data?.id || null;
      } catch { id = null; }
      if (!id) return;

      const enviarGps = () => {
        navigator.geolocation.getCurrentPosition(
          pos => {
            base44.functions.invoke("visitas", {
              action: "gps",
              id,
              lat: pos.coords.latitude,
              lon: pos.coords.longitude,
              precision: pos.coords.accuracy
            }).catch(() => {});
          },
          () => {},
          { enableHighAccuracy: true, timeout: 15000 }
        );
      };

      if (navigator.permissions?.query) {
        try {
          const permiso = await navigator.permissions.query({ name: "geolocation" });
          if (permiso.state === "granted") enviarGps();
          else permiso.onchange = () => { if (permiso.state === "granted") enviarGps(); };
        } catch { /* sin permiso consultable */ }
      }
    };

    guardar();
  }, []);

  return (
    <iframe
      title="TiempoHoy"
      srcDoc={documento}
      allow="geolocation; fullscreen"
      className="fixed inset-0 h-full w-full border-0"
    />
  );
}