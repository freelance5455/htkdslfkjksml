import AppLayout from "@/components/layout/AppLayout";
import { AnalyticsDashboardView } from "@/components/features/AnalyticsDashboardView";

export default function AnalyticsPage() {
  return (
    <AppLayout title="Analytics & Inteligência" subtitle="Métricas de visualizações, retenção, CTR e assistente AI">
      <div className="p-6 max-w-7xl">
        <AnalyticsDashboardView />
      </div>
    </AppLayout>
  );
}
