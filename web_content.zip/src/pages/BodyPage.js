/**
 * BodyPage.js — Skin / Fitness / Nutrition tabs.
 * Each tab is backed by its own service module; this file is presentation only.
 */
import { el, card, sectionHeader, checklistItem, button, xpBar, textInput, emptyState } from '../components/ui.js';
import { icon } from '../components/icons.js';
import { chartCanvas, renderLineChart } from '../components/charts/canvasChart.js';
import {
  getRoutineForToday, toggleSkincareStep, AM_STEPS, PM_STEPS,
} from '../modules/body/skin/skinService.js';
import {
  todaysSplitFocus, logWorkout, getRecentWorkouts, logBodyMetric,
  bodyMetricsSeries, weeklyWorkoutCount,
} from '../modules/body/fitness/fitnessService.js';
import {
  getTodayNutrition, logMeal, logHydration, nutritionSeries,
  MEAL_IDEAS, FOODS_TO_EAT, FOODS_TO_AVOID, DEFAULT_TARGETS,
} from '../modules/body/nutrition/nutritionService.js';
import { showToast } from '../core/notifications/toast.js';
import { statGrid, barList, sliderField } from '../components/ui.js';
import { renderWeightTab } from '../modules/body/weight/weightUI.js';
import { pickImage } from '../core/profile/profileService.js';
import { dailySeries } from '../core/stats/statsService.js';
import { renderBarChart } from '../components/charts/canvasChart.js';
import { daysBetween, todayISO } from '../core/utils/dateUtils.js';
import {
  listActives, settlingActive, startActive, stopActive, getTodayLog, saveTodayLog, skinSummary,
  listMarks, addMark, addMarkCheck, deleteMark, getPhoto,
} from '../modules/body/skin/skinTrackerService.js';

let activeTab = 'skin';

function tabRow(root) {
  const row = el('div', 'tab-row');
  [
    { key: 'skin', label: 'Skin' },
    { key: 'fitness', label: 'Fitness' },
    { key: 'nutrition', label: 'Nutrition' },
    { key: 'weight', label: 'Weight' },
  ].forEach(({ key, label }) => {
    const pill = el('button', `tab-pill${activeTab === key ? ' tab-pill--active' : ''}`, label);
    pill.addEventListener('click', async () => { activeTab = key; await rerender(root); });
    row.append(pill);
  });
  return row;
}

async function renderSkinTab(page, root) {
  const am = await getRoutineForToday('AM');
  const pm = await getRoutineForToday('PM');

  page.append(sectionHeader('Morning', 'AM routine'));
  page.append(card(am.steps.map((s, i) =>
    checklistItem(s.name, s.done, async (checked) => {
      await toggleSkincareStep('AM', i, checked);
      showToast(checked ? 'Step logged.' : 'Step unmarked.');
    })
  )));

  page.append(sectionHeader('Evening', 'PM routine'));
  page.append(card(pm.steps.map((s, i) =>
    checklistItem(s.name, s.done, async (checked) => {
      await toggleSkincareStep('PM', i, checked);
      showToast(checked ? 'Step logged.' : 'Step unmarked.');
    })
  )));

  await renderSkinTracker(page, root);
}

/* ---- Skin tracker (sits under the unchanged AM/PM routines) ---- */
async function renderSkinTracker(page, root) {
  const log = await getTodayLog();
  const sum = await skinSummary();
  const actives = await listActives();
  const settling = await settlingActive();
  const marks = await listMarks();

  page.append(sectionHeader('Tracker', 'Skin log'));
  const retChip = el('button', `chip${log.retinoid ? ' chip--active' : ''}`, log.retinoid ? 'Retinoid night ✓' : 'Retinoid night?');
  retChip.addEventListener('click', async () => { await saveTodayLog({ retinoid: !log.retinoid }); await rerender(root); });
  const irr = sliderField('Irritation today (0 none – 3 strong)', { min: 0, max: 3, value: log.irritation || 0 });
  const irrSave = button('Save irritation', { variant: 'ghost', block: true, onClick: async () => { await saveTodayLog({ irritation: irr.getValue() }); showToast('Saved.'); await rerender(root); } });
  page.append(card([retChip, el('div', 'mt-3', irr.node), el('div', 'mt-3', irrSave)]));
  page.append(statGrid([
    { value: sum.retinoidWeek, label: 'Retinoid nights (7d)' },
    { value: sum.retinoidTotal, label: 'Retinoid nights total' },
  ]));
  if (sum.recentIrritation) page.append(el('div', 'mt-3', el('div', 'warning-banner', [el('span', null, '⚠️ Strong irritation logged recently — pause actives; keep cleanser, moisturiser and sunscreen until your skin is calm.')])));
  if (sum.retinoidWeek >= 4) page.append(el('div', 'mt-3', el('div', 'warning-banner', [el('span', null, 'That is a lot of retinoid nights this week — more is not better. Build up slowly.')])));

  // actives: one new active at a time
  const live = actives.filter((a) => !a.endDate);
  const ac = card([el('span', 'text-xs text-dim', 'ACTIVES — introduce ONE new active at a time (give it ~2 weeks)')]);
  if (!live.length) ac.append(el('p', 'mt-2 text-xs', 'No active ingredient running right now.'));
  live.forEach((a) => {
    const d = daysBetween(a.startDate, todayISO());
    const stop = el('button', 'link-btn link-btn--danger', 'Stop');
    stop.addEventListener('click', async () => { await stopActive(a); await rerender(root); });
    ac.append(el('div', 'checklist-item', [el('span', 'checklist-item__label', a.name), el('span', 'text-xs text-dim', d < 14 ? `day ${d + 1} · settling in` : `day ${d + 1} · established`), stop]));
  });
  const nameIn = textInput({ placeholder: 'New active (e.g. adapalene, azelaic acid)' });
  ac.append(el('div', 'mt-3', nameIn), el('div', 'mt-3', button('Start new active', { variant: 'ghost', block: true, onClick: async () => {
    if (!nameIn.value.trim()) return;
    if (settling && !window.confirm(`"${settling.name}" is only on day ${daysBetween(settling.startDate, todayISO()) + 1}. Rule of thumb: wait until day 14 before adding another. Add anyway?`)) return;
    await startActive(nameIn.value.trim()); showToast('Started.'); await rerender(root);
  } })));
  page.append(ac);

  // dark-mark timeline
  page.append(sectionHeader('Check every ~2 weeks', 'Dark-mark timeline'));
  if (!marks.length) page.append(card([el('p', 'text-xs text-dim', 'Track a dark mark (e.g. left cheek) to see it fade over months. Photos stay private on this device and are blurred until you tap them.')]));
  for (const m of marks) {
    const checks = m.checks || [];
    const c = card([el('div', 'flex justify-between', [el('span', null, m.name), el('span', 'text-xs text-dim', `since ${m.startDate}`)])]);
    if (checks.length) {
      const cv = chartCanvas(70);
      const wrap = el('div', 'mt-2'); wrap.append(cv); c.append(wrap);
      requestAnimationFrame(() => renderLineChart(cv, checks.map((k) => ({ date: k.date, value: k.severity })), { color: '#E0A93B', maxOverride: 5, height: 70 }));
      const photos = el('div', 'photo-row');
      for (const k of checks) if (k.photoId) {
        const data = await getPhoto(k.photoId);
        if (data) { const im = el('img', 'skin-photo skin-photo--blur'); im.src = data; im.addEventListener('click', () => im.classList.toggle('skin-photo--blur')); photos.append(el('div', 'text-xs text-dim', [im, k.date.slice(5)])); }
      }
      c.append(photos);
    }
    const sev = textInput({ placeholder: 'Severity now (1 faint – 5 strong)', type: 'number' });
    c.append(el('div', 'mt-3', sev), el('div', 'mt-3 flex gap-3', [
      button('Add check', { onClick: async () => { const v = parseInt(sev.value, 10); if (!(v >= 1 && v <= 5)) { showToast('Enter 1–5.'); return; } await addMarkCheck(m, v); await rerender(root); } }),
      button('📷 + photo', { variant: 'ghost', onClick: async () => { const v = parseInt(sev.value, 10); if (!(v >= 1 && v <= 5)) { showToast('Enter severity 1–5 first.'); return; } const photo = await pickImage(500); if (!photo) return; await addMarkCheck(m, v, photo); await rerender(root); } }),
      button('Delete', { variant: 'ghost', onClick: async () => { if (window.confirm(`Delete "${m.name}" and its photos?`)) { await deleteMark(m); await rerender(root); } } }),
    ]));
    page.append(c);
  }
  const markIn = textInput({ placeholder: 'New mark to track (e.g. forehead)' });
  page.append(card([markIn, el('div', 'mt-3', button('Track this mark', { variant: 'ghost', block: true, onClick: async () => { if (!markIn.value.trim()) return; await addMark(markIn.value.trim()); await rerender(root); } }))]));
}

async function renderFitnessTab(page, root) {
  const focus = todaysSplitFocus();
  const recent = await getRecentWorkouts(5);
  const weeklyCount = await weeklyWorkoutCount();
  const series = await bodyMetricsSeries(30);

  page.append(sectionHeader('Today\'s split', focus.day));
  page.append(card([el('p', null, focus.focus)]));

  page.append(sectionHeader(`${weeklyCount}/4 this week`, 'Log a workout'));
  const notesInput = textInput({ placeholder: 'Exercises / notes (optional)' });
  page.append(card([
    notesInput,
    el('div', 'mt-3', button('Mark today\'s workout done', { block: true, onClick: async () => {
      await logWorkout({ splitDay: focus.focus, notes: notesInput.value });
      showToast('Workout logged.');
      await rerender(root);
    } })),
  ]));

  const wk = await dailySeries(14, 'workouts');
  const wkCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Workout days (14 days)')])]);
  const wkCanvas = chartCanvas(80);
  wkCard.append(wkCanvas);
  page.append(sectionHeader(null, 'Consistency'), wkCard);
  requestAnimationFrame(() => renderBarChart(wkCanvas, wk, { maxOverride: 1 }));

  page.append(sectionHeader(null, 'Recent workouts'));
  page.append(card(
    recent.length === 0
      ? [emptyState('No workouts logged yet', 'Log today\'s session above.')]
      : recent.map((w) => el('div', 'checklist-item', [
          el('span', 'checklist-item__label', `${w.date} — ${w.splitDay}`),
        ]))
  ));

  page.append(sectionHeader(null, 'Body metrics'));
  const weightInput = textInput({ placeholder: 'Weight (kg)', type: 'number' });
  const bfInput = textInput({ placeholder: 'Body fat % (estimate)', type: 'number' });
  page.append(card([
    weightInput, el('div', 'mt-3', bfInput),
    el('div', 'mt-3', button('Save today\'s metrics', { variant: 'ghost', block: true, onClick: async () => {
      await logBodyMetric({
        weightKg: weightInput.value ? parseFloat(weightInput.value) : null,
        bodyFatPct: bfInput.value ? parseFloat(bfInput.value) : null,
      });
      showToast('Metrics saved.');
      await rerender(root);
    } })),
  ]));

  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Body fat % trend (30 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);
  requestAnimationFrame(() => {
    const points = series.filter((s) => s.bodyFat != null).map((s) => ({ date: s.date, value: s.bodyFat }));
    if (points.length > 0) renderLineChart(canvas, points, { color: '#E0A93B' });
  });
}

async function renderNutritionTab(page, root) {
  const today = await getTodayNutrition();
  const series = await nutritionSeries(14);

  page.append(sectionHeader(`${today.caloriesLogged}/${today.caloriesTarget} kcal`, 'Today'));
  page.append(card([
    xpBar(Math.min(100, (today.caloriesLogged / today.caloriesTarget) * 100)),
    el('p', 'text-xs text-dim mt-1', `Protein: ${today.proteinG}g target ${DEFAULT_TARGETS.proteinG}g · Water: ${(today.waterMl / 1000).toFixed(2)}L / ${(DEFAULT_TARGETS.waterMl / 1000)}L`),
  ]));

  const descInput = textInput({ placeholder: 'What did you eat?' });
  const calInput = textInput({ placeholder: 'Calories', type: 'number' });
  const proteinInput = textInput({ placeholder: 'Protein (g)', type: 'number' });
  page.append(sectionHeader(null, 'Log a meal'));
  page.append(card([
    descInput, el('div', 'mt-3', calInput), el('div', 'mt-3', proteinInput),
    el('div', 'mt-3', button('Save meal', { block: true, onClick: async () => {
      if (!descInput.value) { showToast('Describe the meal first.'); return; }
      await logMeal({ description: descInput.value, calories: parseInt(calInput.value, 10) || 0, protein: parseInt(proteinInput.value, 10) || 0 });
      showToast('Meal logged.');
      await rerender(root);
    } })),
    el('div', 'mt-3 flex gap-3', [250, 500, 750].map((ml) => button(`+${ml}ml`, { variant: 'ghost', block: true, onClick: async () => {
      await logHydration(ml);
      showToast('Hydration logged.');
      await rerender(root);
    } }))),
  ]));

  page.append(sectionHeader(null, 'Meal ideas'));
  Object.entries(MEAL_IDEAS).forEach(([mealType, ideas]) => {
    page.append(card([
      el('span', 'text-xs text-dim', mealType.toUpperCase()),
      ...ideas.map((idea) => el('p', 'mt-1', idea)),
    ]));
  });

  page.append(sectionHeader(null, 'Foods to favor / avoid'));
  page.append(card([
    el('span', 'text-xs text-dim', 'EAT REGULARLY'),
    el('p', 'mt-1', FOODS_TO_EAT.join(' · ')),
    el('span', 'text-xs text-dim mt-4', 'REDUCE / AVOID'),
    el('p', 'mt-1', FOODS_TO_AVOID.join(' · ')),
  ]));

  const chartCard = card([el('div', 'chart-card__header', [el('span', 'chart-card__title', 'Calories logged (14 days)')])]);
  const canvas = chartCanvas(100);
  chartCard.append(canvas);
  page.append(chartCard);
  requestAnimationFrame(() => {
    renderLineChart(canvas, series.map((s) => ({ date: s.date, value: s.calories })), {});
  });
}

async function rerender(root) {
  root.innerHTML = '';
  await BodyPage(root);
}

export async function BodyPage(root) {
  const page = el('div', 'page');
  page.append(el('h1', 'page-title', 'Body'), el('p', 'page-subtitle', 'Skin · Fitness · Nutrition · Weight'));
  page.append(tabRow(root));

  if (activeTab === 'skin') await renderSkinTab(page, root);
  else if (activeTab === 'fitness') await renderFitnessTab(page, root);
  else if (activeTab === 'weight') await renderWeightTab(page, () => rerender(root));
  else await renderNutritionTab(page, root);

  root.appendChild(page);
}
