import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import MyVideosPrePublishView from "@/components/features/MyVideosPrePublishView";

export default function MyVideosPage() {
  return (
    <AppLayout
      title="Meus Vídeos"
      subtitle="Estúdio de visualização, inspeção e pré-publicação antes de postar no YouTube e redes sociais"
    >
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <MyVideosPrePublishView />
      </div>
    </AppLayout>
  );
}
