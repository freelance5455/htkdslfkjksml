import React, { useState } from 'react';
import { 
  Briefcase, 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Volume2, 
  Trash2, 
  PieChart, 
  Wallet, 
  DollarSign, 
  Check, 
  X,
  BellRing
} from 'lucide-react';
import { 
  PortfolioPosition, 
  AssetData, 
  ThemeMode, 
  AudioSettings 
} from '../types/market';
import { speakText, executeVoiceAlert } from '../services/audioEngine';

interface PortfolioPageProps {
  portfolio: PortfolioPosition[];
  onUpdatePortfolio: (newPortfolio: PortfolioPosition[]) => void;
  assets: AssetData[];
  audioSettings: AudioSettings;
  theme: ThemeMode;
  language: 'fr' | 'en';
}

export const PortfolioPage: React.FC<PortfolioPageProps> = ({
  portfolio,
  onUpdatePortfolio,
  assets,
  audioSettings,
  theme,
  language,
}) => {
  const isLight = theme === 'light';
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || 'bitcoin');
  const [amountInput, setAmountInput] = useState<string>('1');
  const [buyPriceInput, setBuyPriceInput] = useState<string>('');

  // Calculate real-time portfolio metrics
  const positionsWithLive = portfolio.map((pos) => {
    const liveAsset = assets.find((a) => a.id === pos.assetId || a.symbol === pos.symbol);
    const currentPrice = liveAsset ? liveAsset.price : pos.buyPrice;
    const totalValue = pos.amount * currentPrice;
    const costBasis = pos.amount * pos.buyPrice;
    const pnl = totalValue - costBasis;
    const pnlPercent = costBasis > 0 ? (pnl / costBasis) * 100 : 0;

    return {
      ...pos,
      currentPrice,
      totalValue,
      pnl,
      pnlPercent,
      change24h: liveAsset?.change24h || 0,
    };
  });

  const totalPortfolioValue = positionsWithLive.reduce((acc, p) => acc + p.totalValue, 0);
  const totalCostBasis = positionsWithLive.reduce((acc, p) => acc + p.amount * p.buyPrice, 0);
  const totalPnL = totalPortfolioValue - totalCostBasis;
  const totalPnLPercent = totalCostBasis > 0 ? (totalPnL / totalCostBasis) * 100 : 0;
  const isProfitable = totalPnL >= 0;

  // Allocation by category
  const allocation = positionsWithLive.reduce((acc, pos) => {
    acc[pos.category] = (acc[pos.category] || 0) + pos.totalValue;
    return acc;
  }, {} as Record<string, number>);

  const handleAddPosition = (e: React.FormEvent) => {
    e.preventDefault();
    const asset = assets.find((a) => a.id === selectedAssetId);
    if (!asset) return;

    const amount = parseFloat(amountInput) || 0;
    const buyPrice = parseFloat(buyPriceInput) || asset.price;

    const newPos: PortfolioPosition = {
      id: `pos-${Date.now()}`,
      assetId: asset.id,
      symbol: asset.symbol,
      name: asset.name,
      category: asset.category,
      amount,
      buyPrice,
      createdAt: Date.now(),
    };

    onUpdatePortfolio([...portfolio, newPos]);
    setIsAddModalOpen(false);
    setAmountInput('1');
    setBuyPriceInput('');
  };

  const handleDeletePosition = (id: string) => {
    onUpdatePortfolio(portfolio.filter((p) => p.id !== id));
  };

  const handleVoicePortfolioBrief = async () => {
    const text = language === 'fr'
      ? `Bilan vocal de votre portefeuille. Valeur totale estimée à ${Math.round(totalPortfolioValue).toLocaleString()} dollars. Plus-value globale de ${Math.round(totalPnL).toLocaleString()} dollars, soit ${totalPnLPercent.toFixed(2)} pour cent.`
      : `Portfolio voice summary. Total estimated value is ${Math.round(totalPortfolioValue).toLocaleString()} dollars. Overall profit and loss is ${Math.round(totalPnL).toLocaleString()} dollars, or ${totalPnLPercent.toFixed(2)} percent.`;
    await executeVoiceAlert(isProfitable ? 'bullish' : 'bell', text, audioSettings, language);
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Portfolio Hero Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-6 transition-colors ${
        isLight
          ? 'bg-gradient-to-r from-emerald-50 via-white to-slate-100 border-slate-200'
          : 'bg-gradient-to-r from-slate-900 via-slate-900/90 to-emerald-950/40 border-slate-800'
      }`}>
        <div className="space-y-3 max-w-xl">
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold border ${
              isLight ? 'bg-emerald-100 border-emerald-300 text-emerald-800' : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}>
              <Wallet className="w-3.5 h-3.5 text-emerald-500" />
              <span>PORTEFEUILLE &bull; SYNCHRO PRIX RÉELS</span>
            </span>
          </div>

          <div>
            <div className={`text-xs font-mono uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              VALEUR TOTALE DU PORTEFEUILLE
            </div>
            <div className="flex items-baseline gap-3 mt-1">
              <span className={`text-3xl sm:text-5xl font-extrabold font-mono tracking-tight ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                ${totalPortfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>

              <span className={`flex items-center gap-1 text-sm sm:text-base font-mono font-bold px-3 py-1 rounded-xl border ${
                isProfitable
                  ? isLight ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                  : isLight ? 'bg-rose-50 border-rose-200 text-rose-700' : 'bg-rose-500/20 border-rose-500/40 text-rose-400'
              }`}>
                {isProfitable ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{isProfitable ? '+' : ''}${totalPnL.toLocaleString(undefined, { maximumFractionDigits: 2 })} ({totalPnLPercent.toFixed(2)}%)</span>
              </span>
            </div>
          </div>

          <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            Revalorisation dynamique basée sur les cours en temps réel de vos cryptos, matières premières et actions.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
          <button
            onClick={handleVoicePortfolioBrief}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl border text-xs font-semibold transition-all cursor-pointer shadow-sm ${
              isLight 
                ? 'bg-white hover:bg-slate-100 border-slate-200 text-slate-800' 
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
            }`}
          >
            <Volume2 className="w-4 h-4 text-emerald-500" />
            <span>Synthèse Vocale PnL</span>
          </button>

          <button
            onClick={() => {
              setBuyPriceInput(assets[0]?.price.toString() || '');
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Ajouter Position</span>
          </button>
        </div>
      </div>

      {/* Asset Allocation Breakdown */}
      <div className={`p-5 rounded-3xl border shadow-md space-y-3 ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center justify-between text-xs font-mono">
          <span className={`font-bold flex items-center gap-2 ${isLight ? 'text-slate-800' : 'text-white'}`}>
            <PieChart className="w-4 h-4 text-emerald-500" />
            <span>RÉPARTITION DU CAPITAL</span>
          </span>
          <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>
            {portfolio.length} lignes de portefeuille
          </span>
        </div>

        {/* Segmented Bar */}
        <div className="h-3 w-full rounded-full bg-slate-800 overflow-hidden flex">
          {Object.entries(allocation).map(([cat, val], idx) => {
            const pct = totalPortfolioValue > 0 ? (val / totalPortfolioValue) * 100 : 0;
            const colors = ['bg-amber-500', 'bg-emerald-500', 'bg-blue-500', 'bg-purple-500'];
            return (
              <div
                key={cat}
                className={`${colors[idx % colors.length]} h-full transition-all`}
                style={{ width: `${pct}%` }}
                title={`${cat}: ${pct.toFixed(1)}%`}
              />
            );
          })}
        </div>

        {/* Legend Chips */}
        <div className="flex flex-wrap gap-3 pt-1 text-xs font-mono">
          {Object.entries(allocation).map(([cat, val], idx) => {
            const pct = totalPortfolioValue > 0 ? (val / totalPortfolioValue) * 100 : 0;
            const textColors = ['text-amber-500', 'text-emerald-500', 'text-blue-500', 'text-purple-500'];
            return (
              <div key={cat} className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${textColors[idx % textColors.length]}`} />
                <span className="capitalize">{cat}</span>
                <span className="font-bold opacity-80">{pct.toFixed(1)}% (${Math.round(val).toLocaleString()})</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Positions Table */}
      <div className={`rounded-3xl border overflow-hidden shadow-xl ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className={`p-4 border-b font-bold text-sm font-['Chakra_Petch'] ${
          isLight ? 'bg-slate-50 border-slate-200 text-slate-800' : 'bg-slate-950 border-slate-800 text-white'
        }`}>
          POSITIONS ACTIVES & VALORISATION DIRECTE
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className={`border-b ${
                isLight ? 'bg-slate-50/50 border-slate-200 text-slate-500' : 'bg-slate-950/50 border-slate-800 text-slate-400'
              }`}>
                <th className="p-4">ACTIF</th>
                <th className="p-4">QUANTITÉ</th>
                <th className="p-4">PRIX D'ACHAT</th>
                <th className="p-4">COURS DIRECT</th>
                <th className="p-4">VALEUR TOTALE</th>
                <th className="p-4">GAIN / PERTE (PNL)</th>
                <th className="p-4 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {positionsWithLive.map((pos) => {
                const isPos = pos.pnl >= 0;
                return (
                  <tr key={pos.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-xl border flex items-center justify-center font-bold text-[11px] ${
                          isLight ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-slate-800 border-slate-700 text-white'
                        }`}>
                          {pos.symbol.slice(0, 4)}
                        </div>
                        <div>
                          <strong className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                            {pos.symbol}
                          </strong>
                          <span className={`block text-[11px] ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                            {pos.name}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="p-4 font-bold">{pos.amount}</td>

                    <td className="p-4 text-slate-500">
                      ${pos.buyPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </td>

                    <td className="p-4 font-bold text-sm">
                      ${pos.currentPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </td>

                    <td className="p-4 font-bold">
                      ${pos.totalValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </td>

                    <td className="p-4">
                      <span className={`font-bold px-2 py-0.5 rounded-lg text-xs ${
                        isPos
                          ? isLight ? 'bg-emerald-50 text-emerald-700' : 'bg-emerald-500/20 text-emerald-400'
                          : isLight ? 'bg-rose-50 text-rose-700' : 'bg-rose-500/20 text-rose-400'
                      }`}>
                        {isPos ? '+' : ''}${pos.pnl.toLocaleString(undefined, { maximumFractionDigits: 2 })} ({isPos ? '+' : ''}{pos.pnlPercent.toFixed(2)}%)
                      </span>
                    </td>

                    <td className="p-4 text-right">
                      <button
                        onClick={() => handleDeletePosition(pos.id)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          isLight ? 'hover:bg-rose-50 text-slate-400 hover:text-rose-600' : 'hover:bg-rose-500/20 text-slate-400 hover:text-rose-400'
                        }`}
                        title="Clôturer cette position"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Position Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className={`w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden p-6 space-y-4 ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-950 border-slate-800'
          }`}>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className={`font-bold text-base font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                AJOUTER UNE POSITION AU PORTEFEUILLE
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddPosition} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-mono font-bold text-slate-400">Actif</label>
                <select
                  value={selectedAssetId}
                  onChange={(e) => {
                    setSelectedAssetId(e.target.value);
                    const found = assets.find((a) => a.id === e.target.value);
                    if (found) setBuyPriceInput(found.price.toString());
                  }}
                  className={`w-full p-2.5 rounded-xl border text-xs font-mono ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-white'
                  }`}
                >
                  {assets.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.symbol} - {a.name} (${a.price})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-bold text-slate-400">Quantité détenue</label>
                <input
                  type="number"
                  step="any"
                  value={amountInput}
                  onChange={(e) => setAmountInput(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-mono ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-white'
                  }`}
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-bold text-slate-400">Prix d'Achat Moyen ($)</label>
                <input
                  type="number"
                  step="any"
                  value={buyPriceInput}
                  onChange={(e) => setBuyPriceInput(e.target.value)}
                  className={`w-full p-2.5 rounded-xl border text-xs font-mono ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-white'
                  }`}
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className={`flex-1 py-2.5 rounded-xl border text-xs font-semibold ${
                    isLight ? 'bg-slate-100 border-slate-200 text-slate-700' : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                >
                  Valider
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
