import React, { useState, useMemo } from 'react';
import { 
  BarChart2, 
  CandlestickChart, 
  TrendingUp, 
  TrendingDown, 
  BellPlus, 
  Volume2, 
  Activity, 
  Layers, 
  ArrowUpDown,
  Coins,
  DollarSign,
  Flame,
  Zap,
  Sliders,
  PenTool,
  Sparkles,
  Target,
  Minus,
  Percent,
  Plus,
  Trash2,
  CheckCircle2,
  Loader2
} from 'lucide-react';
import { 
  AssetData, 
  ThemeMode, 
  SoundEffectType, 
  AudioSettings, 
  ChartAnnotation 
} from '../types/market';
import { speakText, executeVoiceAlert } from '../services/audioEngine';

interface GraphPageProps {
  assets: AssetData[];
  onOpenAlertModal: (asset: AssetData) => void;
  audioSettings: AudioSettings;
  theme: ThemeMode;
  language: 'fr' | 'en';
}

export const GraphPage: React.FC<GraphPageProps> = ({
  assets,
  onOpenAlertModal,
  audioSettings,
  theme,
  language,
}) => {
  const isLight = theme === 'light';
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || 'bitcoin');
  const [chartType, setChartType] = useState<'line' | 'candle'>('candle');
  const [timeframe, setTimeframe] = useState<'1H' | '24H' | '7D' | '30D' | '1Y'>('24H');
  
  // Indicator Toggles
  const [showMA, setShowMA] = useState<boolean>(true);
  const [showBollinger, setShowBollinger] = useState<boolean>(true);
  const [showRSI, setShowRSI] = useState<boolean>(true);
  const [showMACD, setShowMACD] = useState<boolean>(false);
  const [showFibonacci, setShowFibonacci] = useState<boolean>(false);

  // Annotations
  const [annotations, setAnnotations] = useState<ChartAnnotation[]>([
    {
      id: 'anno-1',
      type: 'horizontal_line',
      price: 0, // will calibrate to asset
      label: 'Résistance Clé',
      color: '#f59e0b',
    },
  ]);
  const [activeTool, setActiveTool] = useState<'none' | 'hline' | 'fib'>('none');
  const [isScanningPatterns, setIsScanningPatterns] = useState<boolean>(false);
  const [detectedPattern, setDetectedPattern] = useState<{
    name: string;
    bias: 'Haussier' | 'Baissier' | 'Neutre';
    probability: number;
    description: string;
  } | null>(null);

  const fallbackAsset: AssetData = {
    id: 'bitcoin',
    symbol: 'BTC',
    name: 'Bitcoin',
    category: 'crypto',
    price: 94500,
    change24h: 3.2,
    high24h: 96000,
    low24h: 92800,
    volume24h: '38.4B',
    sparkline: [93000, 93800, 94500],
    lastUpdated: Date.now(),
  };

  const asset = assets.find((a) => a.id === selectedAssetId) || assets[0] || fallbackAsset;
  const isPositive = asset.change24h >= 0;

  // Chart Generation with Bollinger Bands & MACD points
  const chartData = useMemo(() => {
    const count = timeframe === '1H' ? 24 : timeframe === '24H' ? 36 : timeframe === '7D' ? 42 : 50;
    const base = asset.price;
    const volatility = asset.category === 'crypto' ? 0.025 : 0.008;
    const points: Array<{
      open: number;
      close: number;
      high: number;
      low: number;
      time: string;
      ma: number;
      upperBand: number;
      lowerBand: number;
      macd: number;
      macdSignal: number;
      macdHist: number;
    }> = [];

    let current = base * (1 - (isPositive ? 0.03 : -0.03));
    let rollingSum = 0;
    const maPeriod = 5;

    for (let i = 0; i < count; i++) {
      const delta = (Math.sin(i * 0.45) + (Math.random() - 0.48)) * (base * volatility);
      const open = current;
      const close = i === count - 1 ? base : current + delta;
      const high = Math.max(open, close) + Math.random() * (base * volatility * 0.5);
      const low = Math.min(open, close) - Math.random() * (base * volatility * 0.5);
      current = close;

      rollingSum += close;
      if (i >= maPeriod) rollingSum -= points[i - maPeriod].close;
      const ma = rollingSum / Math.min(i + 1, maPeriod);
      const bandWidth = base * volatility * 1.5;

      const macd = Math.sin(i * 0.3) * (base * 0.006);
      const macdSignal = Math.sin((i - 1) * 0.3) * (base * 0.0055);
      const macdHist = macd - macdSignal;

      points.push({
        open,
        close,
        high,
        low,
        time: `${(i * 2) % 24}:00`,
        ma,
        upperBand: ma + bandWidth,
        lowerBand: ma - bandWidth,
        macd,
        macdSignal,
        macdHist,
      });
    }
    return points;
  }, [asset.id, asset.price, timeframe, isPositive]);

  const allPrices = chartData.flatMap((d) => [d.low, d.high, d.upperBand, d.lowerBand]);
  const minPrice = Math.min(...allPrices);
  const maxPrice = Math.max(...allPrices);
  const priceRange = maxPrice - minPrice || 1;

  const chartWidth = 720;
  const chartHeight = 280;

  // Geometry calculations
  const linePointsString = chartData
    .map((d, idx) => {
      const x = (idx / (chartData.length - 1)) * chartWidth;
      const y = chartHeight - ((d.close - minPrice) / priceRange) * (chartHeight - 40) - 20;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const maPointsString = chartData
    .map((d, idx) => {
      const x = (idx / (chartData.length - 1)) * chartWidth;
      const y = chartHeight - ((d.ma - minPrice) / priceRange) * (chartHeight - 40) - 20;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const upperBandPoints = chartData
    .map((d, idx) => {
      const x = (idx / (chartData.length - 1)) * chartWidth;
      const y = chartHeight - ((d.upperBand - minPrice) / priceRange) * (chartHeight - 40) - 20;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  const lowerBandPoints = chartData
    .map((d, idx) => {
      const x = (idx / (chartData.length - 1)) * chartWidth;
      const y = chartHeight - ((d.lowerBand - minPrice) / priceRange) * (chartHeight - 40) - 20;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  // Calculate Fibonacci levels (from 24h Low to 24h High)
  const fibDiff = asset.high24h - asset.low24h || 1;
  const fibLevels = [
    { ratio: 1.0, label: '100% (High)', price: asset.high24h, color: '#ef4444' },
    { ratio: 0.618, label: '61.8% Golden', price: asset.low24h + fibDiff * 0.618, color: '#f59e0b' },
    { ratio: 0.5, label: '50.0% Pivot', price: asset.low24h + fibDiff * 0.5, color: '#3b82f6' },
    { ratio: 0.382, label: '38.2%', price: asset.low24h + fibDiff * 0.382, color: '#10b981' },
    { ratio: 0.0, label: '0.0% (Low)', price: asset.low24h, color: '#10b981' },
  ];

  // Quick RSI calculation
  const currentRSI = Math.min(88, Math.max(18, Math.round(50 + asset.change24h * 3.5)));

  // Add Annotation on Chart Click
  const handleChartCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (activeTool === 'hline') {
      const rect = e.currentTarget.getBoundingClientRect();
      const clickY = e.clientY - rect.top;
      const ratio = Math.max(0, Math.min(1, 1 - (clickY - 20) / (chartHeight - 40)));
      const clickedPrice = parseFloat((minPrice + ratio * priceRange).toFixed(asset.price > 100 ? 2 : 4));

      const newAnno: ChartAnnotation = {
        id: `anno-${Date.now()}`,
        type: 'horizontal_line',
        price: clickedPrice,
        label: clickedPrice >= asset.price ? 'Résistance' : 'Support',
        color: clickedPrice >= asset.price ? '#ef4444' : '#10b981',
      };
      setAnnotations([...annotations, newAnno]);
      setActiveTool('none');
    }
  };

  // AI Chart Pattern Scanner
  const handleScanChartPatterns = async () => {
    setIsScanningPatterns(true);
    await new Promise((r) => setTimeout(r, 700));

    // Pattern decision based on actual change24h & RSI
    if (asset.change24h > 5) {
      setDetectedPattern({
        name: 'Drapeau Haussier (Bull Flag Breakout)',
        bias: 'Haussier',
        probability: 92,
        description: `Cassure confirmée avec expansion des bandes de Bollinger au-dessus de $${asset.price.toLocaleString()}. Cible haussière estimée à $${(asset.price * 1.055).toFixed(2)}.`,
      });
      await executeVoiceAlert(
        'bullish',
        `Figure chartiste détectée sur ${asset.symbol} : Drapeau Haussier de continuation. Probabilité de 92 pour cent.`,
        audioSettings,
        language
      );
    } else if (asset.change24h < -3) {
      setDetectedPattern({
        name: 'Rebond sur Support Critique (Double Creux)',
        bias: 'Haussier',
        probability: 84,
        description: `Zone de survente RSI atteinte (${currentRSI}). Formation d'un creux ascendant propice à un retournement haussier vers $${asset.high24h.toLocaleString()}.`,
      });
      await executeVoiceAlert(
        'sonar',
        `Figure chartiste sur ${asset.symbol} : Test de support majeur avec divergence acheteuse en cours.`,
        audioSettings,
        language
      );
    } else {
      setDetectedPattern({
        name: 'Canal Horizontal de Consolidation (Range Box)',
        bias: 'Neutre',
        probability: 88,
        description: `Le cours oscille entre le support à $${asset.low24h.toLocaleString()} et la résistance à $${asset.high24h.toLocaleString()}. Préparez vos alertes aux bornes du canal.`,
      });
      await executeVoiceAlert(
        'bell',
        `Analyse chartiste ${asset.symbol} : Marché en canal horizontal de consolidation. Surveillez la sortie de range.`,
        audioSettings,
        language
      );
    }
    setIsScanningPatterns(false);
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Top Asset Carousel */}
      <div className={`p-3 rounded-2xl border flex items-center gap-2 overflow-x-auto ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900/60 border-slate-800'
      }`}>
        {assets.map((item) => {
          const isSelected = item.id === asset.id;
          return (
            <button
              key={item.id}
              onClick={() => setSelectedAssetId(item.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-mono font-bold whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  : 'bg-slate-950 hover:bg-slate-800 text-slate-300'
              }`}
            >
              <span>{item.symbol}</span>
              <span className={`text-[10px] ${
                item.change24h >= 0 
                  ? isSelected ? 'text-slate-900' : 'text-emerald-500' 
                  : isSelected ? 'text-slate-900' : 'text-rose-500'
              }`}>
                {item.change24h >= 0 ? '+' : ''}{item.change24h}%
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Chart Station Header */}
      <div className={`p-5 rounded-3xl border shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900/80 border-slate-800'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-2xl border flex items-center justify-center font-bold text-sm font-mono shadow-inner ${
            isLight ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-slate-800 border-slate-700 text-white'
          }`}>
            {asset.symbol.slice(0, 4)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className={`font-bold text-xl font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                {asset.name}
              </h2>
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/30">
                {asset.symbol}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-0.5 text-xs font-mono">
              <span className={`text-2xl font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                ${asset.price.toLocaleString(undefined, {
                  minimumFractionDigits: asset.price < 1 ? 4 : 2,
                  maximumFractionDigits: asset.price < 1 ? 4 : 2,
                })}
              </span>
              <span className={`flex items-center gap-0.5 font-bold px-2 py-0.5 rounded-lg text-xs ${
                isPositive 
                  ? isLight ? 'bg-emerald-50 text-emerald-700' : 'bg-emerald-500/20 text-emerald-400' 
                  : isLight ? 'bg-rose-50 text-rose-700' : 'bg-rose-500/20 text-rose-400'
              }`}>
                {isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                <span>{isPositive ? '+' : ''}{asset.change24h}%</span>
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons: Scan Pattern & Set Alert */}
        <div className="flex flex-wrap items-center gap-2">
          {/* AI Pattern Recognition Scanner */}
          <button
            onClick={handleScanChartPatterns}
            disabled={isScanningPatterns}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 text-purple-600 dark:text-purple-300 font-semibold text-xs transition-all cursor-pointer shadow-sm"
          >
            {isScanningPatterns ? (
              <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
            ) : (
              <Sparkles className="w-4 h-4 text-purple-500" />
            )}
            <span>{isScanningPatterns ? 'Scan IA...' : 'Scanner Figures Chartistes'}</span>
          </button>

          <button
            onClick={() => onOpenAlertModal(asset)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all cursor-pointer"
          >
            <BellPlus className="w-4 h-4" />
            <span>Créer Alerte Vocale</span>
          </button>
        </div>
      </div>

      {/* AI Pattern Notification Banner if detected */}
      {detectedPattern && (
        <div className={`p-4 rounded-2xl border flex items-start justify-between gap-3 animate-in fade-in slide-in-from-top-2 duration-300 ${
          detectedPattern.bias === 'Haussier'
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
            : detectedPattern.bias === 'Baissier'
            ? 'bg-rose-500/10 border-rose-500/30 text-rose-700 dark:text-rose-300'
            : 'bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-300'
        }`}>
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-500">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs uppercase font-mono tracking-wider">
                  FIGURE DÉTECTÉE PAR L'IA : {detectedPattern.name}
                </span>
                <span className="px-2 py-0.2 rounded text-[10px] font-bold bg-black/20">
                  {detectedPattern.probability}% CONFIANCE
                </span>
              </div>
              <p className="text-xs mt-1 leading-relaxed font-mono">
                {detectedPattern.description}
              </p>
            </div>
          </div>
          <button
            onClick={() => setDetectedPattern(null)}
            className="text-xs opacity-60 hover:opacity-100 font-mono"
          >
            Fermer
          </button>
        </div>
      )}

      {/* Interactive Chart Canvas Panel */}
      <div className={`p-5 rounded-3xl border space-y-4 shadow-xl transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900/70 border-slate-800'
      }`}>
        
        {/* Toolbars: Mode, Timeframe, Indicators, Drawing Annotations */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          
          {/* Indicator toggles & Drawing tool */}
          <div className="flex flex-wrap items-center gap-1.5">
            {/* Candle/Line Switch */}
            <div className={`flex items-center p-1 rounded-xl border ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-950 border-slate-800'
            }`}>
              <button
                onClick={() => setChartType('candle')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  chartType === 'candle' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-500'
                }`}
              >
                <CandlestickChart className="w-3.5 h-3.5" />
                <span>Chandelier</span>
              </button>
              <button
                onClick={() => setChartType('line')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  chartType === 'line' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-500'
                }`}
              >
                <BarChart2 className="w-3.5 h-3.5" />
                <span>Courbe</span>
              </button>
            </div>

            {/* Indicator Pills */}
            <button
              onClick={() => setShowMA(!showMA)}
              className={`px-2.5 py-1 rounded-xl border text-xs font-mono font-semibold cursor-pointer ${
                showMA ? 'bg-amber-500/20 border-amber-500/40 text-amber-500' : 'text-slate-400 border-slate-700/50'
              }`}
            >
              MA (20)
            </button>

            <button
              onClick={() => setShowBollinger(!showBollinger)}
              className={`px-2.5 py-1 rounded-xl border text-xs font-mono font-semibold cursor-pointer ${
                showBollinger ? 'bg-blue-500/20 border-blue-500/40 text-blue-500' : 'text-slate-400 border-slate-700/50'
              }`}
            >
              Bollinger Bands
            </button>

            <button
              onClick={() => setShowFibonacci(!showFibonacci)}
              className={`px-2.5 py-1 rounded-xl border text-xs font-mono font-semibold cursor-pointer ${
                showFibonacci ? 'bg-orange-500/20 border-orange-500/40 text-orange-500' : 'text-slate-400 border-slate-700/50'
              }`}
            >
              Fibonacci Retracement
            </button>

            <button
              onClick={() => setShowRSI(!showRSI)}
              className={`px-2.5 py-1 rounded-xl border text-xs font-mono font-semibold cursor-pointer ${
                showRSI ? 'bg-purple-500/20 border-purple-500/40 text-purple-400' : 'text-slate-400 border-slate-700/50'
              }`}
            >
              RSI (14)
            </button>

            <button
              onClick={() => setShowMACD(!showMACD)}
              className={`px-2.5 py-1 rounded-xl border text-xs font-mono font-semibold cursor-pointer ${
                showMACD ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' : 'text-slate-400 border-slate-700/50'
              }`}
            >
              MACD
            </button>

            {/* Annotation Drawing Mode Button */}
            <button
              onClick={() => setActiveTool(activeTool === 'hline' ? 'none' : 'hline')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-xl border text-xs font-mono font-semibold transition-all cursor-pointer ${
                activeTool === 'hline'
                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 animate-pulse'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
              title="Cliquez sur le graphique pour placer une ligne de prix support/résistance"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>{activeTool === 'hline' ? 'Cliquer sur le graph...' : '+ Ligne Support/Résistance'}</span>
            </button>
          </div>

          {/* Timeframe Selector */}
          <div className={`flex items-center p-1 rounded-xl border font-mono text-xs ${
            isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-950 border-slate-800'
          }`}>
            {(['1H', '24H', '7D', '30D', '1Y'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                  timeframe === tf
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-white'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* SVG Drawing Canvas with Interactive Annotations */}
        <div className={`relative w-full h-[280px] rounded-2xl border p-2 overflow-hidden flex items-center justify-center transition-colors ${
          isLight ? 'bg-slate-50/70 border-slate-200' : 'bg-slate-950/80 border-slate-800/80'
        }`}>
          <svg 
            onClick={handleChartCanvasClick}
            className={`w-full h-full overflow-visible ${activeTool === 'hline' ? 'cursor-crosshair' : 'cursor-default'}`} 
            viewBox={`0 0 ${chartWidth} ${chartHeight}`} 
            preserveAspectRatio="none"
          >
            <defs>
              <linearGradient id={`graph-grad-${asset.id}-${theme}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity={isLight ? 0.2 : 0.4} />
                <stop offset="100%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Grid Lines */}
            {[0.2, 0.5, 0.8].map((ratio) => {
              const y = chartHeight * ratio;
              const priceLabel = maxPrice - priceRange * ratio;
              return (
                <g key={ratio}>
                  <line
                    x1="0"
                    y1={y}
                    x2={chartWidth}
                    y2={y}
                    stroke={isLight ? '#cbd5e1' : '#334155'}
                    strokeDasharray="4 4"
                    strokeWidth="1"
                    opacity="0.5"
                  />
                  <text 
                    x="8" 
                    y={y - 4} 
                    fill={isLight ? '#64748b' : '#94a3b8'} 
                    fontSize="10" 
                    fontFamily="monospace"
                  >
                    ${priceLabel.toFixed(priceLabel < 1 ? 4 : 2)}
                  </text>
                </g>
              );
            })}

            {/* Bollinger Bands Overlay */}
            {showBollinger && (
              <g>
                <polyline
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="1.2"
                  strokeDasharray="3 3"
                  opacity="0.6"
                  points={upperBandPoints}
                />
                <polyline
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="1.2"
                  strokeDasharray="3 3"
                  opacity="0.6"
                  points={lowerBandPoints}
                />
              </g>
            )}

            {/* Mode 1: Line Chart */}
            {chartType === 'line' && (
              <g>
                <polygon
                  points={`0,${chartHeight} ${linePointsString} ${chartWidth},${chartHeight}`}
                  fill={`url(#graph-grad-${asset.id}-${theme})`}
                />
                <polyline
                  fill="none"
                  stroke={isPositive ? '#10b981' : '#f43f5e'}
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={linePointsString}
                />
              </g>
            )}

            {/* Mode 2: Candlestick Chart */}
            {chartType === 'candle' &&
              chartData.map((d, i) => {
                const x = (i / (chartData.length - 1)) * chartWidth;
                const candleWidth = Math.max(3, chartWidth / chartData.length - 3);
                const isGreen = d.close >= d.open;
                const highY = chartHeight - ((d.high - minPrice) / priceRange) * (chartHeight - 40) - 20;
                const lowY = chartHeight - ((d.low - minPrice) / priceRange) * (chartHeight - 40) - 20;
                const openY = chartHeight - ((d.open - minPrice) / priceRange) * (chartHeight - 40) - 20;
                const closeY = chartHeight - ((d.close - minPrice) / priceRange) * (chartHeight - 40) - 20;
                const bodyTop = Math.min(openY, closeY);
                const bodyHeight = Math.max(2, Math.abs(openY - closeY));

                return (
                  <g key={i}>
                    <line
                      x1={x}
                      y1={highY}
                      x2={x}
                      y2={lowY}
                      stroke={isGreen ? '#10b981' : '#f43f5e'}
                      strokeWidth="1.2"
                    />
                    <rect
                      x={x - candleWidth / 2}
                      y={bodyTop}
                      width={candleWidth}
                      height={bodyHeight}
                      fill={isGreen ? '#10b981' : '#f43f5e'}
                      rx="1"
                    />
                  </g>
                );
              })}

            {/* Moving Average MA20 */}
            {showMA && (
              <polyline
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2"
                strokeDasharray="2 2"
                points={maPointsString}
              />
            )}

            {/* Fibonacci Levels Overlay */}
            {showFibonacci &&
              fibLevels.map((lvl) => {
                const y = chartHeight - ((lvl.price - minPrice) / priceRange) * (chartHeight - 40) - 20;
                return (
                  <g key={lvl.label}>
                    <line
                      x1="0"
                      y1={y}
                      x2={chartWidth}
                      y2={y}
                      stroke={lvl.color}
                      strokeWidth="1.2"
                      strokeDasharray="5 5"
                      opacity="0.8"
                    />
                    <text
                      x={chartWidth - 95}
                      y={y - 4}
                      fill={lvl.color}
                      fontSize="10"
                      fontFamily="monospace"
                      fontWeight="bold"
                    >
                      {lvl.label}: ${lvl.price.toFixed(lvl.price < 1 ? 4 : 2)}
                    </text>
                  </g>
                );
              })}

            {/* User Custom Price Annotations */}
            {annotations.map((anno) => {
              if (anno.price === 0) return null;
              const y = chartHeight - ((anno.price - minPrice) / priceRange) * (chartHeight - 40) - 20;
              return (
                <g key={anno.id}>
                  <line
                    x1="0"
                    y1={y}
                    x2={chartWidth}
                    y2={y}
                    stroke={anno.color}
                    strokeWidth="2"
                    strokeDasharray="4 2"
                  />
                  <rect
                    x="8"
                    y={y - 18}
                    width="140"
                    height="18"
                    fill="#020617"
                    stroke={anno.color}
                    rx="4"
                  />
                  <text
                    x="12"
                    y={y - 5}
                    fill={anno.color}
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    {anno.label}: ${anno.price.toLocaleString()}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* User Annotations Strip */}
        {annotations.filter((a) => a.price > 0).length > 0 && (
          <div className={`p-3 rounded-2xl border flex flex-wrap items-center justify-between gap-2 text-xs font-mono ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
          }`}>
            <div className="flex items-center gap-2">
              <span className="font-bold text-amber-500">ANNOTATIONS ACTIVES :</span>
              {annotations.filter((a) => a.price > 0).map((anno) => (
                <div key={anno.id} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-slate-700">
                  <span style={{ color: anno.color }}>{anno.label} (${anno.price})</span>
                  <button
                    onClick={() => setAnnotations(annotations.filter((a) => a.id !== anno.id))}
                    className="text-slate-400 hover:text-rose-400 ml-1"
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>

            <button
              onClick={() => onOpenAlertModal(asset)}
              className="text-xs text-amber-500 hover:underline flex items-center gap-1 cursor-pointer font-bold"
            >
              <BellPlus className="w-3.5 h-3.5" />
              <span>Convertir en Alerte Vocale</span>
            </button>
          </div>
        )}

        {/* Sub-panel 1: RSI (14) */}
        {showRSI && (
          <div className={`p-3 rounded-2xl border flex items-center justify-between text-xs font-mono ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
          }`}>
            <div className="flex items-center gap-3">
              <span className="font-bold text-purple-400">RSI (14): {currentRSI}</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                currentRSI > 70 
                  ? 'bg-rose-500/20 text-rose-400' 
                  : currentRSI < 30 
                  ? 'bg-emerald-500/20 text-emerald-400' 
                  : 'bg-slate-500/20 text-slate-400'
              }`}>
                {currentRSI > 70 ? 'SURACHETÉ (>70)' : currentRSI < 30 ? 'SURVENDU (<30)' : 'NEUTRE'}
              </span>
            </div>

            <div className="relative w-48 h-2 rounded-full bg-slate-800 overflow-hidden">
              <div 
                className={`h-full rounded-full ${
                  currentRSI > 70 ? 'bg-rose-500' : currentRSI < 30 ? 'bg-emerald-500' : 'bg-purple-500'
                }`}
                style={{ width: `${currentRSI}%` }}
              />
            </div>
          </div>
        )}

        {/* Sub-panel 2: MACD Indicator */}
        {showMACD && (
          <div className={`p-3 rounded-2xl border space-y-2 text-xs font-mono ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
          }`}>
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-500">MACD (12, 26, 9)</span>
              <span className="text-[11px] text-slate-400">Croisement Ligne de Signal / Momentum</span>
            </div>

            <div className="h-10 flex items-center gap-1 overflow-hidden px-2">
              {chartData.slice(-28).map((d, i) => (
                <div
                  key={i}
                  className={`flex-1 rounded-sm transition-all ${
                    d.macdHist >= 0 ? 'bg-emerald-500' : 'bg-rose-500'
                  }`}
                  style={{
                    height: `${Math.min(100, Math.max(15, Math.abs(d.macdHist) * 150))}%`,
                  }}
                  title={`MACD: ${d.macd.toFixed(2)}`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>PLUS HAUT 24H</span>
            <div className="font-bold text-sm mt-0.5">${asset.high24h.toLocaleString()}</div>
          </div>
          <div className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>PLUS BAS 24H</span>
            <div className="font-bold text-sm mt-0.5">${asset.low24h.toLocaleString()}</div>
          </div>
          <div className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>VOLUME 24H</span>
            <div className="font-bold text-sm mt-0.5">{asset.volume24h}</div>
          </div>
          <div className={`p-3 rounded-xl border ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'}`}>
            <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>CAPITALISATION</span>
            <div className="font-bold text-sm mt-0.5">{asset.marketCap || 'N/A'}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
