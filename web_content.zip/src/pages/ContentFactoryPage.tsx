import { useState } from "react";
import type { ElementType } from "react";
import AppLayout from "@/components/layout/AppLayout";
import ContentFactoryPipelineView from "@/components/features/core4/ContentFactoryPipelineView";
import BatchProductionStudio from "@/components/features/core4/BatchProductionStudio";
import CharacterUniverseView from "@/components/features/core4/CharacterUniverseView";
import CreatorCopilotView from "@/components/features/core4/CreatorCopilotView";
import SmartRepurposingStudio from "@/components/features/core4/SmartRepurposingStudio";
import ContentArchiveAndSearchView from "@/components/features/core4/ContentArchiveAndSearchView";
import KnowledgeGraphView from "@/components/features/core4/KnowledgeGraphView";
import ExperimentManagerView from "@/components/features/core4/ExperimentManagerView";
import SystemHealthAndAuditView from "@/components/features/core4/SystemHealthAndAuditView";
import AIProvidersManagerView from "@/components/features/core4/AIProvidersManagerView";
import AIJobsQueueView from "@/components/features/core4/AIJobsQueueView";
import KidsWeeklyAutomationModal from "@/components/features/core4/KidsWeeklyAutomationModal";
import { getEmergencyStopState } from "@/lib/core4/contentFactoryStore";
import { cn } from "@/lib/utils";
import {
  Layers, Sparkles, Globe2, Cpu, Scissors, Archive,
  Share2, FlaskConical, Activity, ShieldAlert, Play, Plus, Server, Radio
} from "lucide-react";

type Core4Tab =
  | "PIPELINE"
  | "BATCH_PRODUCTION"
  | "AI_JOBS"
  | "AI_PROVIDERS"
  | "CHARACTER_UNIVERSE"
  | "COPILOT"
  | "REPURPOSING"
  | "ARCHIVE_SEARCH"
  | "KNOWLEDGE_GRAPH"
  | "EXPERIMENTS"
  | "SYSTEM_HEALTH";

const CORE4_TABS: { key: Core4Tab; label: string; icon: ElementType; badge?: string }[] = [
  { key: "PIPELINE", label: "Pipeline (11 Estágios)", icon: Layers },
  { key: "AI_JOBS", label: "Fila de IA (SSE)", icon: Radio, badge: "Tempo Real" },
  { key: "AI_PROVIDERS", label: "Motores & Provedores", icon: Server, badge: "9 Motores" },
  { key: "BATCH_PRODUCTION", label: "Produção em Lote", icon: Sparkles, badge: "5-50" },
  { key: "CHARACTER_UNIVERSE", label: "Universos & Personagens", icon: Globe2 },
  { key: "COPILOT", label: "Creator Copilot", icon: Cpu, badge: "IA" },
  { key: "REPURPOSING", label: "Smart Repurposing", icon: Scissors },
  { key: "ARCHIVE_SEARCH", label: "Acervo & Busca IA", icon: Archive },
  { key: "KNOWLEDGE_GRAPH", label: "Knowledge Graph", icon: Share2 },
  { key: "EXPERIMENTS", label: "Testes A/B/C", icon: FlaskConical },
  { key: "SYSTEM_HEALTH", label: "Saúde & Auditoria", icon: Activity },
];

export default function ContentFactoryPage() {
  const [activeTab, setActiveTab] = useState<Core4Tab>("PIPELINE");
  const [showScenarioModal, setShowScenarioModal] = useState(false);
  const emergencyState = getEmergencyStopState();

  return (
    <AppLayout
      title="Content Factory · CORE 4.0"
      subtitle="Fábrica Inteligente de Conteúdo & Inteligência de Criação Avançada"
    >
      <div className="p-6 space-y-6 max-w-7xl">
        {/* Top Emergency Status Alert if active */}
        {emergencyState.isActive && (
          <div className="p-4 rounded-xl bg-red-500/20 border border-red-500/50 text-red-300 text-xs flex items-center justify-between shadow-lg">
            <span className="flex items-center gap-2 font-bold">
              <ShieldAlert className="w-5 h-5 text-red-400 animate-pulse" />
              PARADA DE EMERGÊNCIA ATIVA — Operações congeladas por {emergencyState.triggeredBy}.
            </span>
            <button
              onClick={() => setActiveTab("SYSTEM_HEALTH")}
              className="btn text-xs py-1.5 px-3 bg-red-500 text-white font-bold"
            >
              Ver Painel de Controle
            </button>
          </div>
        )}

        {/* Top Navigation Subtabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-studio-border">
          <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar p-1 rounded-xl bg-studio-panel border border-studio-border">
            {CORE4_TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.key;

              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all duration-200",
                    isActive
                      ? "bg-studio-gold text-black shadow-sm font-bold"
                      : "text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={cn(
                      "text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold",
                      isActive ? "bg-black/20 text-black" : "bg-studio-surface text-studio-gold border border-studio-gold/30"
                    )}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick 17-Step Scenario Action Button */}
          <button
            onClick={() => setShowScenarioModal(true)}
            className="btn-gold text-xs py-2 px-4 gap-2 shrink-0 shadow-md"
          >
            <Sparkles className="w-4 h-4" />
            🪄 Cenário Semana Infantil (17 Etapas)
          </button>
        </div>

        {/* Active Tab View Rendering */}
        <div className="transition-all duration-300">
          {activeTab === "PIPELINE" && (
            <ContentFactoryPipelineView />
          )}

          {activeTab === "AI_JOBS" && (
            <AIJobsQueueView />
          )}

          {activeTab === "AI_PROVIDERS" && (
            <AIProvidersManagerView />
          )}

          {activeTab === "BATCH_PRODUCTION" && (
            <BatchProductionStudio onBatchCompleted={() => setActiveTab("PIPELINE")} />
          )}

          {activeTab === "CHARACTER_UNIVERSE" && (
            <CharacterUniverseView />
          )}

          {activeTab === "COPILOT" && (
            <CreatorCopilotView
              onRunScenario={() => setShowScenarioModal(true)}
              onNavigateBatch={() => setActiveTab("BATCH_PRODUCTION")}
              onNavigateFactory={() => setActiveTab("PIPELINE")}
            />
          )}

          {activeTab === "REPURPOSING" && (
            <SmartRepurposingStudio />
          )}

          {activeTab === "ARCHIVE_SEARCH" && (
            <ContentArchiveAndSearchView />
          )}

          {activeTab === "KNOWLEDGE_GRAPH" && (
            <KnowledgeGraphView />
          )}

          {activeTab === "EXPERIMENTS" && (
            <ExperimentManagerView />
          )}

          {activeTab === "SYSTEM_HEALTH" && (
            <SystemHealthAndAuditView />
          )}
        </div>
      </div>

      {/* 17-Step Kids Weekly Scenario Modal */}
      <KidsWeeklyAutomationModal
        isOpen={showScenarioModal}
        onClose={() => setShowScenarioModal(false)}
        onFinished={() => setActiveTab("PIPELINE")}
      />
    </AppLayout>
  );
}
