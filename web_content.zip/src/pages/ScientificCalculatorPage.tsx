import React, { useState } from 'react';
import { evaluateScientificExpression } from '../calculator/scientificEngine';
import { useApp } from '../context/AppContext';
import {
  Sigma,
  Delete,
  RotateCcw,
  Copy,
  Check,
  History,
  Trash2
} from 'lucide-react';

export const ScientificCalculatorPage: React.FC = () => {
  const { showToast, playSound, triggerHaptic } = useApp();

  const [expression, setExpression] = useState('');
  const [displayResult, setDisplayResult] = useState('0');
  const [isRad, setIsRad] = useState(true);
  const [memory, setMemory] = useState(0);
  const [history, setHistory] = useState<{ expr: string; res: string }[]>(() => {
    try {
      const saved = localStorage.getItem('formulax_sci_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [copied, setCopied] = useState(false);

  const saveHistoryItem = (expr: string, res: string) => {
    const updated = [{ expr, res }, ...history.slice(0, 24)];
    setHistory(updated);
    try {
      localStorage.setItem('formulax_sci_history', JSON.stringify(updated));
    } catch {}
  };

  const clearHistory = () => {
    playSound('button');
    setHistory([]);
    try {
      localStorage.removeItem('formulax_sci_history');
    } catch {}
    showToast('Scientific history cleared');
  };

  const appendToken = (token: string) => {
    playSound('button');
    triggerHaptic('light');
    setExpression((prev) => prev + token);
  };

  const handleClear = () => {
    playSound('button');
    triggerHaptic('light');
    setExpression('');
    setDisplayResult('0');
  };

  const handleBackspace = () => {
    playSound('button');
    triggerHaptic('light');
    setExpression((prev) => prev.slice(0, -1));
  };

  const handleCalculate = () => {
    if (!expression.trim()) return;
    const { formatted, error } = evaluateScientificExpression(expression, isRad);
    if (error) {
      playSound('incorrect');
      triggerHaptic('error');
      showToast(error, 'error');
      setDisplayResult('Error');
    } else {
      playSound('calculate');
      triggerHaptic('success');
      setDisplayResult(formatted);
      saveHistoryItem(expression, formatted);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(displayResult);
      playSound('copy');
      triggerHaptic('light');
      setCopied(true);
      showToast('Copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Copy failed', 'error');
    }
  };

  // Memory buttons
  const memAdd = () => {
    playSound('button');
    const val = parseFloat(displayResult) || 0;
    setMemory((m) => m + val);
    showToast(`M+: Memory is ${memory + val}`);
  };

  const memSub = () => {
    playSound('button');
    const val = parseFloat(displayResult) || 0;
    setMemory((m) => m - val);
    showToast(`M-: Memory is ${memory - val}`);
  };

  const memRecall = () => {
    playSound('button');
    appendToken(String(memory));
  };

  const memClear = () => {
    playSound('button');
    setMemory(0);
    showToast('Memory cleared');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Sigma className="w-5 h-5 text-[#D65A1F]" />
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#F5F2ED] tracking-tight">
            Scientific Calculator
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-[#A9A39C]">
          Precision mathematical evaluation with trigonometric functions, logarithmic scaling, arbitrary powers, and physics constants.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Calculator */}
        <div className="lg:col-span-2 rounded-3xl border border-[#303030] bg-[#1C1C1C] p-5 sm:p-6 shadow-2xl space-y-5">
          {/* Top Controls: DEG/RAD toggle & Memory indicator */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playSound('tab');
                  setIsRad(!isRad);
                }}
                className="px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold bg-[#151515] border border-[#303030] text-[#D65A1F] hover:border-[#D65A1F] transition-colors"
              >
                {isRad ? 'RAD' : 'DEG'}
              </button>
              {memory !== 0 && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-[#232323] text-[#D65A1F] border border-[#303030]">
                  M = {memory}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopy}
                className="p-2 rounded-xl bg-[#151515] hover:bg-[#232323] text-[#A9A39C] hover:text-[#F5F2ED] border border-[#303030] transition-colors"
                title="Copy Display"
              >
                {copied ? <Check className="w-4 h-4 text-[#72A65A]" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                onClick={handleBackspace}
                className="p-2 rounded-xl bg-[#151515] hover:bg-[#232323] text-[#A9A39C] hover:text-[#F5F2ED] border border-[#303030] transition-colors"
                title="Backspace"
              >
                <Delete className="w-4 h-4" />
              </button>
              <button
                onClick={handleClear}
                className="p-2 rounded-xl bg-[#232323] hover:bg-[#C84A3A]/20 text-[#C84A3A] border border-[#303030] transition-colors"
                title="Clear All"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Display screen */}
          <div className="rounded-2xl bg-[#151515] border border-[#303030] p-4 sm:p-5 text-right font-mono select-all overflow-x-auto shadow-inner">
            <div className="text-xs sm:text-sm text-[#A9A39C] min-h-[20px] break-all">
              {expression || '0'}
            </div>
            <div className="text-2xl sm:text-4xl font-extrabold text-[#D65A1F] mt-1 tracking-tight break-all">
              {displayResult}
            </div>
          </div>

          {/* Keypad Grid */}
          <div className="grid grid-cols-5 gap-2 text-xs sm:text-sm font-mono">
            {/* Memory row */}
            <button onClick={memClear} className="btn-sci text-[#A9A39C] hover:text-[#F5F2ED]">MC</button>
            <button onClick={memRecall} className="btn-sci text-[#A9A39C] hover:text-[#F5F2ED]">MR</button>
            <button onClick={memAdd} className="btn-sci text-[#A9A39C] hover:text-[#F5F2ED]">M+</button>
            <button onClick={memSub} className="btn-sci text-[#A9A39C] hover:text-[#F5F2ED]">M-</button>
            <button onClick={() => appendToken('pi')} className="btn-sci text-[#D65A1F] font-bold">π</button>

            {/* Scientific row 1 */}
            <button onClick={() => appendToken('sin(')} className="btn-sci">sin</button>
            <button onClick={() => appendToken('cos(')} className="btn-sci">cos</button>
            <button onClick={() => appendToken('tan(')} className="btn-sci">tan</button>
            <button onClick={() => appendToken('log(')} className="btn-sci">log</button>
            <button onClick={() => appendToken('ln(')} className="btn-sci">ln</button>

            {/* Scientific row 2 */}
            <button onClick={() => appendToken('sqrt(')} className="btn-sci">√</button>
            <button onClick={() => appendToken('^2')} className="btn-sci">x²</button>
            <button onClick={() => appendToken('^')} className="btn-sci">xʸ</button>
            <button onClick={() => appendToken('(')} className="btn-sci">(</button>
            <button onClick={() => appendToken(')')} className="btn-sci">)</button>

            {/* Numeric row 1 */}
            <button onClick={() => appendToken('7')} className="btn-num">7</button>
            <button onClick={() => appendToken('8')} className="btn-num">8</button>
            <button onClick={() => appendToken('9')} className="btn-num">9</button>
            <button onClick={() => appendToken('/')} className="btn-op">÷</button>
            <button onClick={() => appendToken('%')} className="btn-op">%</button>

            {/* Numeric row 2 */}
            <button onClick={() => appendToken('4')} className="btn-num">4</button>
            <button onClick={() => appendToken('5')} className="btn-num">5</button>
            <button onClick={() => appendToken('6')} className="btn-num">6</button>
            <button onClick={() => appendToken('*')} className="btn-op">×</button>
            <button onClick={() => appendToken('e')} className="btn-sci text-[#D65A1F] font-bold">e</button>

            {/* Numeric row 3 */}
            <button onClick={() => appendToken('1')} className="btn-num">1</button>
            <button onClick={() => appendToken('2')} className="btn-num">2</button>
            <button onClick={() => appendToken('3')} className="btn-num">3</button>
            <button onClick={() => appendToken('-')} className="btn-op">−</button>
            <button onClick={() => appendToken('+')} className="btn-op">+</button>

            {/* Bottom row */}
            <button onClick={() => appendToken('0')} className="btn-num">0</button>
            <button onClick={() => appendToken('.')} className="btn-num">.</button>
            <button onClick={() => appendToken('abs(')} className="btn-sci">|x|</button>
            <button
              onClick={handleCalculate}
              className="col-span-2 py-3 rounded-xl bg-[#D65A1F] hover:bg-[#B94717] text-[#F5F2ED] font-extrabold text-base transition-all shadow-md active:scale-95 cursor-pointer"
            >
              =
            </button>
          </div>
        </div>

        {/* Calculation History Sidebar */}
        <div className="rounded-3xl border border-[#303030] bg-[#1C1C1C] p-5 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#303030] mb-4">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-[#D65A1F]" />
                <h3 className="text-sm font-bold text-[#F5F2ED]">Calculation Log</h3>
              </div>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="p-1 rounded text-[#A9A39C] hover:text-[#C84A3A] transition-colors"
                  title="Clear history"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <p className="text-xs text-[#A9A39C] text-center py-8 font-mono">
                No scientific calculations yet
              </p>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {history.map((h, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      playSound('button');
                      setExpression(h.expr);
                      setDisplayResult(h.res);
                    }}
                    className="w-full text-left p-2.5 rounded-xl bg-[#151515] border border-[#303030] hover:border-[#D65A1F]/50 transition-colors font-mono"
                  >
                    <div className="text-[11px] text-[#A9A39C] truncate">{h.expr}</div>
                    <div className="text-xs font-bold text-[#D65A1F] mt-0.5 truncate">= {h.res}</div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="text-[11px] font-mono text-[#A9A39C] pt-4 border-t border-[#303030]">
            Trig mode: {isRad ? 'Radians (rad)' : 'Degrees (deg)'}
          </div>
        </div>
      </div>

      <style>{`
        .btn-sci {
          padding: 0.65rem 0.25rem;
          border-radius: 0.75rem;
          background-color: #151515;
          border: 1px solid #303030;
          color: #A9A39C;
          font-weight: 600;
          transition: all 0.15s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }
        .btn-sci:hover {
          background-color: #232323;
          color: #F5F2ED;
          border-color: #D65A1F;
        }
        .btn-num {
          padding: 0.75rem 0.25rem;
          border-radius: 0.75rem;
          background-color: #232323;
          border: 1px solid #303030;
          color: #F5F2ED;
          font-weight: 700;
          font-size: 1rem;
          transition: all 0.15s ease;
          cursor: pointer;
        }
        .btn-num:hover {
          background-color: #1C1C1C;
          border-color: #D65A1F;
        }
        .btn-op {
          padding: 0.75rem 0.25rem;
          border-radius: 0.75rem;
          background-color: #151515;
          border: 1px solid #303030;
          color: #D65A1F;
          font-weight: 700;
          font-size: 1.1rem;
          transition: all 0.15s ease;
          cursor: pointer;
        }
        .btn-op:hover {
          background-color: #232323;
          border-color: #D65A1F;
        }
      `}</style>
    </div>
  );
};
