import React from "react";
import AppLayout from "@/components/layout/AppLayout";
import { CloneEngineStudio } from "@/components/features/CloneEngineStudio";

export default function CloneStudioPage() {
  return (
    <AppLayout
      title="Motor de Clonagem AI"
      subtitle="Clonar canais de alta retenção, vídeos virais anti-copyright, trilhas sonoras e plataformas"
    >
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <CloneEngineStudio />
      </div>
    </AppLayout>
  );
}
