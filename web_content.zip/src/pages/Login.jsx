import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Leaf, Loader2, Lock, Mail, MapPin, Phone } from "lucide-react";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Login() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();

  const typed = identifier.trim();
  const looksLikePhone = typed.length > 0 && !typed.includes("@");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      let email = typed;

      if (!typed.includes("@")) {
        const lookup = await base44.functions.invoke("resolvePhoneLogin", { phone: typed });
        const linkedEmail = lookup?.data?.email;
        if (!linkedEmail) {
          setError(
            "We couldn't find an account with that mobile number yet. Sign in with your email, then add your number from your account page."
          );
          return;
        }
        email = linkedEmail;
      }

      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = returnTo;
    } catch (err) {
      const apiMessage = err?.response?.data?.error || err?.data?.error;
      setError(apiMessage || err.message || "Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    base44.auth.loginWithProvider("google", returnTo);
  };

  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-2">
      <aside className="relative hidden overflow-hidden bg-primary p-12 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
        <div className="pointer-events-none absolute inset-0 opacity-[0.14] paper-grid" />
        <Link to="/" className="relative flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-foreground/15">
            <Leaf className="h-4 w-4" strokeWidth={2.2} />
          </span>
          <span className="leading-none">
            <span className="block font-display text-[15px] font-semibold tracking-tight">
              Clean City
            </span>
            <span className="block text-[10px] font-medium uppercase tracking-[0.18em] text-primary-foreground/60">
              Coimbatore
            </span>
          </span>
        </Link>

        <div className="relative max-w-sm">
          <p className="font-display text-3xl font-medium leading-[1.15]">
            “The board doesn&apos;t just log complaints. It shows the whole city what got
            fixed.”
          </p>
          <p className="mt-5 text-sm leading-relaxed text-primary-foreground/70">
            Sign in to report a spot, follow your neighbourhood, help the municipal team
            close the loop.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4 border-t border-primary-foreground/15 pt-6">
            {[
              { label: "Reports tracked", value: "Live" },
              { label: "Wards covered", value: "12" },
              { label: "Public by design", value: "100%" },
            ].map((item) => (
              <div key={item.label}>
                <p className="font-display text-lg font-semibold">{item.value}</p>
                <p className="mt-1 text-[10px] uppercase tracking-[0.12em] text-primary-foreground/55">
                  {item.label}
                </p>
              </div>
            ))}
          </div>
        </div>

        <p className="relative text-[11px] text-primary-foreground/50">
          Coimbatore · neighbourhood waste watch
        </p>
      </aside>

      <div className="flex items-center justify-center px-5 py-12 sm:px-10">
        <div className="w-full max-w-sm">
          <Link to="/" className="mb-8 flex items-center gap-2 lg:hidden">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Leaf className="h-4 w-4 text-primary-foreground" />
            </span>
            <span className="font-display text-sm font-semibold">Clean City Coimbatore</span>
          </Link>

          <h1 className="font-display text-3xl font-semibold tracking-tight">Welcome back</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Sign in to report an issue and follow what changed.
          </p>

          <Button
            variant="outline"
            className="mt-7 h-11 w-full rounded-full text-sm font-medium"
            onClick={handleGoogle}
          >
            <GoogleIcon className="mr-2 h-4 w-4" />
            Continue with Google
          </Button>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-[10px] uppercase tracking-[0.14em]">
              <span className="bg-background px-3 text-muted-foreground">or use a password</span>
            </div>
          </div>

          {error && (
            <div className="mb-4 rounded-xl border border-destructive/20 bg-destructive/10 p-3 text-xs leading-relaxed text-destructive">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="identifier">Email or mobile number</Label>
              <div className="relative">
                {looksLikePhone ? (
                  <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                ) : (
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                )}
                <Input
                  id="identifier"
                  type="text"
                  inputMode={looksLikePhone ? "tel" : "email"}
                  autoComplete="username"
                  autoFocus
                  placeholder={looksLikePhone ? "98765 43210" : "you@example.com"}
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="h-11 rounded-xl pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link to="/forgot-password" className="text-[11px] text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 rounded-xl pl-10"
                  required
                />
              </div>
            </div>

            <Button type="submit" className="h-11 w-full rounded-full font-medium" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign in"
              )}
            </Button>
          </form>

          <p className="mt-4 flex items-start gap-1.5 text-[11px] leading-relaxed text-muted-foreground">
            <MapPin className="mt-0.5 h-3 w-3 shrink-0" />
            Mobile sign-in works once your number is linked to your account — add or change it
            from your account page.
          </p>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            New here?{" "}
            <Link
              to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
              className="font-medium text-primary hover:underline"
            >
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}