import { el, card, button, sectionHeader, textInput, chipSelect, fieldLabel } from '../components/ui.js';
import {
  downloadBackup, shareBackupFile, importBackupFile, importBackupText, copyBackupText, downloadCSV,
} from '../core/storage/backupService.js';
import { getStoreNames, DB_VERSION } from '../core/storage/db.js';
import { withStoreClear } from '../core/storage/storageService.js';
import { showToast } from '../core/notifications/toast.js';
import { getProfile, updateProfile, applyTheme, pickImage, resetProfileCache } from '../core/profile/profileService.js';
import { getReminderConfig, saveReminderConfig, enableReminders } from '../core/notifications/reminderService.js';
import { nativeNotificationsAvailable, saveBackupFile, biometricAvailable } from '../core/native/bridge.js';
import { hasPin, setPin, removePin, getLockConfig, saveLockConfig, setRecovery, LOCK_OPTIONS } from '../core/security/pinLock.js';
import {
  getPrayerConfig, savePrayerConfig, METHODS, PRAYERS, PRAYER_LABEL, computePrayerTimes,
} from '../core/prayer/prayerService.js';
import { todayISO, formatClock } from '../core/utils/dateUtils.js';
import { navigate } from '../core/router.js';
import { appearancePanel, accessibilityPanel, behaviourPanel, dashboardPanel } from './settingsPanels.js';
import { icon } from '../components/icons.js';

export const APP_VERSION = '4.1.0';

const CATEGORIES = [
  { key: 'personalization', icon: '👤', title: 'Personalization', desc: 'Your name, photo, story, prayer times & location' },
  { key: 'appearance', icon: '🎨', title: 'Appearance', desc: 'Theme, accent colour, font size, density, cards, animation' },
  { key: 'dashboard', icon: '🏠', title: 'Dashboard customization', desc: 'Show, hide and reorder Home; layout; priorities' },
  { key: 'notifications', icon: '🔔', title: 'Notifications', desc: 'Reminders for routine, prayers, skills & weigh-in' },
  { key: 'privacy', icon: '🔐', title: 'Privacy and security', desc: 'PIN lock, lock timing, recovery' },
  { key: 'data', icon: '💾', title: 'Data and storage', desc: 'Backup, restore, export, delete' },
  { key: 'accessibility', icon: '♿', title: 'Accessibility', desc: 'Reduce motion, large touch targets, contrast' },
  { key: 'behaviour', icon: '⚙️', title: 'App behaviour', desc: 'Start screen, greeting, celebrations' },
  { key: 'about', icon: 'ℹ️', title: 'About Life Guide', desc: 'Version, developer, how your data is handled' },
];


async function rerender(root) { root.innerHTML = ''; await renderSettings(root, currentCat); }
let currentCat = null;

/** /settings = the category menu; /settings/<category> = one category. */
export async function Settings(root) { await renderSettings(root, null); }
export const settingsCategoryRoute = (cat) => (root) => renderSettings(root, cat);
export const SETTINGS_CATEGORY_KEYS = CATEGORIES.map((c) => c.key);

async function renderSettings(root, cat) {
  currentCat = cat;
  const profile = await getProfile();
  const pinOn = await hasPin();
  const lockCfg = await getLockConfig();
  const cfg = await getPrayerConfig();

  const page = el('div', 'page');
  if (!cat) {
    const first = (profile.name || 'Abbas').split(' ')[0];
    const avatar = profile.photo ? Object.assign(el('img', 'home-avatar'), { src: profile.photo, alt: '' }) : el('div', 'home-avatar home-avatar--initial', first.slice(0, 1).toUpperCase());
    page.append(el('div', 'set-hero', [avatar, el('div', null, [el('h1', 'page-title', 'Settings'), el('p', 'page-subtitle', `Make Life Guide yours, ${first}.`)])]));
    const menu = el('div', 'set-menu');
    CATEGORIES.forEach((c) => {
      const b = el('button', 'set-item', [el('span', 'set-item__icon', c.icon), el('span', 'set-item__text', [el('span', 'set-item__title', c.title), el('span', 'set-item__desc', c.desc)]), el('span', 'set-item__chev', '›')]);
      b.addEventListener('click', () => navigate(`/settings/${c.key}`));
      menu.append(b);
    });
    page.append(menu);
    root.appendChild(page);
    return;
  }
  const meta = CATEGORIES.find((c) => c.key === cat);
  page.append(button('← Settings', { variant: 'ghost', size: 'sm', onClick: () => navigate('/settings') }), el('h1', 'page-title mt-3', `${meta.icon} ${meta.title}`));
  page.append(el('p', 'page-subtitle', meta.desc));

  if (cat === 'personalization') {
  // ---- Profile ----
    page.append(sectionHeader('You', 'Profile'));
    const nameIn = textInput({ placeholder: 'Your name', value: profile.name });
    page.append(card([
      el('p', 'text-dim text-xs', 'Your name is used in the greeting every time you open the app.'),
      el('div', 'mt-3', nameIn),
      el('div', 'mt-3 flex gap-3', [
        button('Save name', { onClick: async () => { if (!nameIn.value.trim()) return; await updateProfile({ name: nameIn.value.trim() }); showToast('Name saved.'); } }),
        button('Change photo', { variant: 'ghost', onClick: async () => { const p = await pickImage(480); if (p) { await updateProfile({ photo: p }); showToast('Photo updated.'); await rerender(root); } } }),
      ]),
      el('div', 'mt-3', button('About the developer →', { variant: 'ghost', block: true, onClick: () => navigate('/about') })),
    ]));
  
    // ---- Prayer times ----
    page.append(sectionHeader(cfg.place, 'Prayer times'));
    const place = textInput({ placeholder: 'Place name', value: cfg.place });
    const lat = textInput({ placeholder: 'Latitude', value: String(cfg.lat), type: 'number' });
    const lng = textInput({ placeholder: 'Longitude', value: String(cfg.lng), type: 'number' });
    const tz = textInput({ placeholder: 'UTC offset (Nigeria = 1)', value: String(cfg.tz), type: 'number' });
    let method = cfg.method; let asr = cfg.asr;
    const methodSlot = el('div'); const asrSlot = el('div');
    const offsetInputs = {};
    const preview = el('p', 'text-xs text-dim mt-3');
    const refreshPreview = () => {
      const t = computePrayerTimes(todayISO(), { ...cfg, lat: +lat.value, lng: +lng.value, tz: +tz.value, method, asr, offsets: Object.fromEntries(Object.entries(offsetInputs).map(([k, i]) => [k, Number(i.value) || 0])) });
      preview.textContent = `Today: ${PRAYERS.map((p) => `${PRAYER_LABEL[p]} ${formatClock(t[p])}`).join(' · ')}`;
    };
    const drawChips = () => {
      methodSlot.replaceChildren(chipSelect(Object.entries(METHODS).map(([k, m]) => ({ label: m.name, value: k })), method, (v) => { method = v; drawChips(); refreshPreview(); }));
      asrSlot.replaceChildren(chipSelect([{ label: 'Shafi / Maliki / Hanbali', value: 1 }, { label: 'Hanafi', value: 2 }], asr, (v) => { asr = v; drawChips(); refreshPreview(); }));
    };
    drawChips();
    const offsetGrid = el('div', 'offset-grid');
    [...PRAYERS, 'sunrise'].forEach((p) => {
      const i = textInput({ placeholder: '0', value: String(cfg.offsets[p] || 0), type: 'number' });
      i.addEventListener('input', refreshPreview);
      offsetInputs[p] = i;
      offsetGrid.append(el('div', null, [fieldLabel(`${PRAYER_LABEL[p]} (min)`), i]));
    });
    [lat, lng, tz].forEach((i) => i.addEventListener('input', refreshPreview));
    page.append(card([
      el('p', 'text-dim text-xs', 'Calculated offline. Default is Kaduna (WAT, UTC+1). Compare with your local mosque timetable and use the minute offsets to match it.'),
      el('div', 'mt-3', [fieldLabel('Place'), place]),
      el('div', 'grid-2 mt-3', [el('div', null, [fieldLabel('Latitude'), lat]), el('div', null, [fieldLabel('Longitude'), lng])]),
      el('div', 'mt-3', [fieldLabel('UTC offset (hours)'), tz]),
      el('div', 'mt-3', [fieldLabel('Calculation method'), methodSlot]),
      el('div', 'mt-3', [fieldLabel('Asr'), asrSlot]),
      el('div', 'mt-3', [fieldLabel('Fine-tune to your mosque (minutes, + or −)'), offsetGrid]),
      el('div', 'mt-3', [fieldLabel('Hijri date adjustment (days: −1, 0, +1)'), (() => { const i = textInput({ value: String(cfg.hijriAdjust), type: 'number' }); i.id = 'hijri-adj'; return i; })()]),
      preview,
      el('div', 'mt-3', button('Save prayer settings', { block: true, onClick: async () => {
        await savePrayerConfig({
          place: place.value || 'Home', lat: +lat.value, lng: +lng.value, tz: +tz.value, method, asr,
          offsets: Object.fromEntries(Object.entries(offsetInputs).map(([k, i]) => [k, Number(i.value) || 0])),
          hijriAdjust: Math.max(-2, Math.min(2, Number(document.getElementById('hijri-adj').value) || 0)),
        });
        showToast('Prayer settings saved.');
      } })),
    ]));
    refreshPreview();
  }

  if (cat === 'appearance') await appearancePanel(page);
  if (cat === 'dashboard') await dashboardPanel(page);
  if (cat === 'accessibility') await accessibilityPanel(page);
  if (cat === 'behaviour') await behaviourPanel(page);

  if (cat === 'privacy') {
  // ---- PIN lock ----
    page.append(sectionHeader(pinOn ? 'On' : 'Off', 'PIN lock'));
    const pinIn = textInput({ placeholder: pinOn ? 'New PIN (4–8 digits)' : 'Choose a PIN (4–8 digits)', type: 'password' });
    pinIn.inputMode = 'numeric'; pinIn.maxLength = 8;
    page.append(card([
      el('p', 'text-dim text-xs', 'Locks the app when you open it, and again after the time you choose below. The timer you were running keeps counting. It keeps casual snoopers out — it does not encrypt your data.'),
      el('div', 'mt-3', pinIn),
      el('div', 'mt-3 flex gap-3', [
        button(pinOn ? 'Change PIN' : 'Set PIN', { onClick: async () => {
          if (!/^\d{4,8}$/.test(pinIn.value)) { showToast('PIN must be 4–8 digits.'); return; }
          await setPin(pinIn.value); showToast('PIN set.'); await rerender(root);
        } }),
        pinOn ? button('Remove PIN', { variant: 'ghost', onClick: async () => { await removePin(); showToast('PIN removed.'); await rerender(root); } }) : null,
      ]),
    ]));
  
    if (pinOn) {
      const lockSlot = el('div');
      const drawLock = (v) => lockSlot.replaceChildren(chipSelect(LOCK_OPTIONS, v, async (nv) => { await saveLockConfig({ timeoutSec: nv }); showToast('Lock timing saved.'); drawLock(nv); }));
      drawLock(lockCfg.timeoutSec);
      const rq = textInput({ placeholder: 'Recovery question (e.g. My first school?)', value: lockCfg.recoveryQ || '' });
      const ra = textInput({ placeholder: lockCfg.recoveryQ ? 'New answer (leave empty to keep)' : 'Answer', type: 'password' });
      page.append(card([
        el('p', 'text-xs text-dim', 'Lock again after being away for:'),
        el('div', 'mt-2', lockSlot),
        el('p', 'text-xs text-dim mt-3', 'Forgot-PIN recovery — if you forget your PIN you can answer this to remove it.'),
        el('div', 'mt-2', rq), el('div', 'mt-2', ra),
        el('div', 'mt-3', button('Save recovery question', { onClick: async () => {
          if (!rq.value.trim() || !ra.value.trim()) { showToast('Add both a question and an answer.'); return; }
          await setRecovery(rq.value, ra.value); ra.value = ''; showToast('Recovery saved.');
        } })),
      ]));
    }
  
    page.append(el('p', 'text-xs text-dim mt-3', 'Important: a PIN keeps casual snoopers out, but it is not encryption — your data is stored unencrypted on this device. Protect the phone itself with its own screen lock.'));
  }

  if (cat === 'notifications') {
  // ---- Reminders ----
    const rc = await getReminderConfig();
    const native = nativeNotificationsAvailable();
    page.append(sectionHeader(native ? 'Rings with the app closed' : 'Shows while the app is open', 'Reminders'));
    const remRows = rc.items.map((r) => {
      const tog = el('input'); tog.type = 'checkbox'; tog.checked = r.enabled;
      const time = textInput({ type: 'time', value: r.time });
      const apply = async () => { r.enabled = tog.checked; r.time = time.value || r.time; await saveReminderConfig(rc); };
      tog.addEventListener('change', async () => { if (tog.checked) await enableReminders(); await apply(); showToast(tog.checked ? 'Reminder on.' : 'Reminder off.'); });
      time.addEventListener('change', async () => { await apply(); showToast('Time saved.'); });
      return el('div', 'reminder-row', [tog, el('span', 'reminder-row__label', r.label), time]);
    });
    const flag = (label, get, set) => { const t = el('input'); t.type = 'checkbox'; t.checked = get(); t.addEventListener('change', async () => { if (t.checked) await enableReminders(); set(t.checked); await saveReminderConfig(rc); showToast('Saved.'); }); return el('div', 'reminder-row', [t, el('span', 'reminder-row__label', label)]); };
    page.append(card([
      el('p', 'text-dim text-xs', native ? 'These are scheduled on your phone, so they ring even when Life Guide is closed.' : 'This is the web version: reminders appear while Life Guide is open. For reminders that ring with the app closed, build the Capacitor app (see CAPACITOR_SETUP.md) — until then keep your Calendar and Clock alarms.'),
      el('div', 'mt-3', remRows),
      flag('🕌 Prayer reminders (10 min before)', () => rc.prayer.enabled, (v) => { rc.prayer.enabled = v; }),
      flag('🌱 Mastery skills at their set time', () => rc.mastery, (v) => { rc.mastery = v; }),
      flag('⚖️ Weekly weigh-in day', () => rc.weigh, (v) => { rc.weigh = v; }),
      el('div', 'mt-3', button('Allow notifications', { variant: 'ghost', block: true, onClick: async () => { showToast((await enableReminders()) ? 'Notifications allowed.' : 'Notifications blocked — allow them in phone settings.'); } })),
    ]));
  }

  if (cat === 'data') {
  // ---- Backup & restore ----
    page.append(sectionHeader('Data', 'Backup & restore'));
    const fileInput = el('input');
    fileInput.type = 'file';
    fileInput.accept = 'application/json,.json,text/plain';
    fileInput.style.display = 'none';
    let importMode = 'merge';
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files[0];
      if (!file) return;
      try {
        if (importMode === 'replace' && !window.confirm('Restoring will REPLACE everything currently in the app with the backup. Continue?')) return;
        const count = await importBackupFile(file, importMode);
        showToast(`Restored ${count} records.`);
        await rerender(root);
      } catch (err) {
        showToast(err.message || 'Import failed.');
      }
      fileInput.value = '';
    });
    const pasteArea = el('textarea', 'field-input');
    pasteArea.rows = 3;
    pasteArea.placeholder = 'Or paste backup text here to restore…';
    const everyIn = textInput({ value: String(profile.backupEveryDays), type: 'number' });
  
    page.append(
      card([
        el('p', 'text-dim text-xs', `Everything is stored only on this device. Last backup: ${profile.lastBackup || 'never'}. Export regularly so a lost phone never means lost progress.`),
        el('div', 'mt-4 flex gap-3 wrap', [
          button('📤 Share backup (WhatsApp / Drive)', { onClick: async () => { const r = await shareBackupFile(); showToast(r === 'cancelled' ? 'Cancelled.' : r === 'shared' ? 'Backup shared. Keep it safe.' : 'Backup saved to your downloads.'); await rerender(root); } }),
          button('Export backup', { variant: 'ghost', onClick: async () => { await downloadBackup(); showToast('Backup saved to your downloads.'); await rerender(root); } }),
          button('Copy backup text', { variant: 'ghost', onClick: async () => { await copyBackupText(); showToast('Copied — paste it into Notes or WhatsApp to keep it.'); await rerender(root); } }),
        ]),
        el('div', 'mt-3 flex gap-3', [
          button('Import (merge)', { variant: 'ghost', onClick: () => { importMode = 'merge'; fileInput.click(); } }),
          button('Import (replace all)', { variant: 'ghost', onClick: () => { importMode = 'replace'; fileInput.click(); } }),
        ]),
        el('div', 'mt-3', pasteArea),
        el('div', 'mt-3', button('Restore from pasted text', { variant: 'ghost', block: true, onClick: async () => {
          if (!pasteArea.value.trim()) { showToast('Paste the backup text first.'); return; }
          if (!window.confirm('Restoring from text REPLACES everything in the app. Continue?')) return;
          try { const n = await importBackupText(pasteArea.value, 'replace'); showToast(`Restored ${n} records.`); await rerender(root); } catch (e) { showToast(e.message); }
        } })),
        el('div', 'mt-4', [fieldLabel('Remind me to back up every (days, 0 = never)'), everyIn]),
        el('div', 'mt-3', button('Save reminder', { variant: 'ghost', block: true, onClick: async () => { await updateProfile({ backupEveryDays: Math.max(0, parseInt(everyIn.value, 10) || 0) }); showToast('Saved.'); } })),
        fileInput,
      ])
    );
  
    // ---- CSV export ----
    page.append(sectionHeader(null, 'Export CSV'));
    const csvRow = el('div', 'chip-row');
    [['habitLogs', 'Habit logs'], ['studySessions', 'Study'], ['ankiLogs', 'Anki'], ['workoutLogs', 'Workouts'], ['nutritionLogs', 'Nutrition'], ['bodyMetrics', 'Body metrics'], ['dayLogs', 'Prayer'], ['weeklyReviews', 'Reviews'], ['notesEntries', 'Notes']].forEach(([store, label]) => {
      const chip = el('button', 'chip', label);
      chip.addEventListener('click', async () => { const ok = await downloadCSV(store); showToast(ok ? `${label} exported.` : `${label} has no data yet.`); });
      csvRow.append(chip);
    });
    page.append(card([el('p', 'text-dim text-xs', 'Tap a table to download it as a spreadsheet file.'), el('div', 'mt-3', csvRow)]));
  
    // ---- Danger zone ----
    page.append(sectionHeader(null, 'Danger zone'));
    page.append(card([
      el('p', 'text-dim text-xs', 'Deletes ALL data on this device (habits, logs, notes, photos, settings). Export a backup first.'),
      el('div', 'mt-3', button('Delete all data', { variant: 'ghost', block: true, onClick: async () => {
        if (window.prompt('Type DELETE to erase everything on this device:') !== 'DELETE') { showToast('Cancelled.'); return; }
        for (const s of getStoreNames()) await withStoreClear(s);
        resetProfileCache();
        showToast('Everything deleted.');
        setTimeout(() => window.location.reload(), 700);
      } })),
    ]));
  }

  if (cat === 'about') {
  page.append(card([el('div', 'mt-1', button('About the developer →', { block: true, onClick: () => navigate('/about') }))]));
    page.append(el('div', 'mt-3'));
    page.append(card([el('p', 'text-dim text-xs', `Life Guide v${APP_VERSION} · database v${DB_VERSION} · built for one user, offline-first, no accounts, no tracking.`)]));
  
    page.append(card([el('p', 'text-dim text-xs', 'Your data stays on this device. There are no accounts, servers or tracking. Back up regularly (Data and storage).')]));
  }

  root.appendChild(page);
}
