import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LogOut, Phone, Save } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import ReportCard from "@/components/ReportCard";

export default function Account() {
  const { user, logout, checkUserAuth } = useAuth();
  const [phone, setPhone] = useState(user?.phone || "");
  const [saving, setSaving] = useState(false);
  const [myReports, setMyReports] = useState([]);
  const [loadingReports, setLoadingReports] = useState(true);

  useEffect(() => {
    if (!user?.id) return;
    base44.entities.IssueReport.filter(
      { created_by_id: user.id },
      { sort: "-created_date", limit: 24 }
    )
      .then((page) => setMyReports(page?.items || []))
      .catch(() => setMyReports([]))
      .finally(() => setLoadingReports(false));
  }, [user?.id]);

  const savePhone = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      const response = await base44.functions.invoke("setMyPhone", { phone });
      const saved = response?.data?.phone ?? "";
      setPhone(saved);
      await checkUserAuth();
      toast({
        title: saved ? "Mobile number saved" : "Mobile number removed",
        description: saved
          ? "You can now sign in with this number and your password."
          : "You can still sign in with your email.",
      });
    } catch (err) {
      toast({
        title: "Couldn't save that number",
        description:
          err?.response?.data?.error || err.message || "Please check the number and try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const name = user?.full_name || user?.email?.split("@")[0] || "Neighbour";

  return (
    <div className="mx-auto max-w-4xl px-5 py-12 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary font-display text-xl font-semibold text-primary-foreground">
            {name.slice(0, 1).toUpperCase()}
          </span>
          <div>
            <h1 className="font-display text-2xl font-semibold tracking-tight">{name}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{user?.email}</p>
          </div>
        </div>
        <Button variant="outline" className="rounded-full" onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          Log out
        </Button>
      </div>

      <div className="mt-8 grid gap-4 lg:grid-cols-[1fr_1.25fr]">
        <form onSubmit={savePhone} className="rounded-2xl border border-border bg-card p-6">
          <p className="font-display text-base font-semibold">Mobile number</p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            Link a number to sign in with your phone instead of your email. It is never shown
            publicly on the board.
          </p>
          <div className="mt-4 space-y-2">
            <Label htmlFor="phone" className="text-xs">Mobile number</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="phone"
                type="tel"
                inputMode="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="98765 43210"
                className="h-11 rounded-xl pl-10"
              />
            </div>
          </div>
          <Button type="submit" className="mt-4 w-full rounded-full" disabled={saving}>
            <Save className="mr-2 h-4 w-4" />
            {saving ? "Saving..." : "Save number"}
          </Button>
        </form>

        <div className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center justify-between">
            <p className="font-display text-base font-semibold">Your reports</p>
            <span className="text-[11px] text-muted-foreground">{myReports.length} sent</span>
          </div>
          {loadingReports ? (
            <div className="mt-6 flex justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-border border-t-primary" />
            </div>
          ) : myReports.length === 0 ? (
            <div className="mt-6 rounded-xl border border-dashed border-border p-6 text-center">
              <p className="text-sm text-muted-foreground">You haven&apos;t reported anything yet.</p>
              <Link
                to="/report"
                className="mt-3 inline-flex rounded-full bg-primary px-4 py-2 text-xs font-medium text-primary-foreground"
              >
                Report an issue
              </Link>
            </div>
          ) : (
            <ul className="mt-4 space-y-2">
              {myReports.slice(0, 6).map((report) => (
                <li key={report.id}>
                  <Link
                    to={`/issues/${report.id}`}
                    className="flex items-center justify-between gap-3 rounded-xl border border-border/70 px-3 py-2.5 text-sm transition-colors hover:border-primary/30"
                  >
                    <span className="truncate">{report.title}</span>
                    <span className="shrink-0 text-[10px] uppercase tracking-[0.1em] text-muted-foreground">
                      {report.status === "in_progress" ? "cleaning" : report.status}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}