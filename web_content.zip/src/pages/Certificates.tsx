import { useEffect, useMemo, useState } from 'react';
import { Award, BookOpenCheck, CheckCircle2, Printer, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Card, ProgressBar } from '../components/ui/Card';
import { Badge, EmptyState } from '../components/ui/Feedback';
import { useProfile } from '../hooks/useProfile';
import { useToast } from '../hooks/useToast';
import { overallCurriculumProgress } from '../services/curriculumProgress';
import { ensureDailyTaskDay, getDailyTaskStore, localDateKey, previewDailyTaskDay } from '../services/dailyTasks';
import { isKeyMemoryOnly, KEYS, useStored } from '../services/storage';

interface CertificateDefinition {
  id: string;
  title: string;
  criterion: string;
  details: string;
  eligible: boolean;
  icon: 'curriculum' | 'daily';
}

function dateLabel(date = new Date()) {
  return date.toLocaleDateString('ar-SY', { day: 'numeric', month: 'long', year: 'numeric' });
}

export default function Certificates() {
  const { profile } = useProfile();
  const { toast } = useToast();
  const [today, setToday] = useState(() => new Date());
  const curriculumState = useStored(KEYS.curriculumProgress, {} as Record<string, boolean>);
  const dailyStore = useStored(KEYS.dailyTasks, getDailyTaskStore());
  const todayKey = localDateKey(today);
  const dailyDay = dailyStore.days?.[todayKey] ?? previewDailyTaskDay(today, dailyStore);
  const progress = useMemo(() => overallCurriculumProgress(curriculumState), [curriculumState]);
  const dailyComplete = dailyDay.tasks.length >= 3 && dailyDay.tasks.every((task) => task.done);
  const definitions: CertificateDefinition[] = [25, 50, 75, 100].map<CertificateDefinition>((threshold) => ({
    id: `curriculum-${threshold}`,
    title: threshold === 100 ? 'إتمام متابعة المنهاج' : `إنجاز ${threshold}% من المنهاج`,
    criterion: `إكمال ${threshold}% على الأقل من بنود متابعة المنهاج الرسمي`,
    details: `أكملت ${progress.completed} من ${progress.total} بنداً موثقاً، أي ${progress.percent}%.`,
    eligible: progress.total > 0 && progress.completed / progress.total >= threshold / 100,
    icon: 'curriculum',
  })).concat({
    id: `daily-${todayKey}`,
    title: 'إنجاز مهام اليوم',
    criterion: 'إتمام جميع المهام الشخصية المحفوظة لتاريخ اليوم المحلي',
    details: `أنجزت ${dailyDay.tasks.filter((task) => task.done).length} من ${dailyDay.tasks.length} مهام بتاريخ ${todayKey}.`,
    eligible: dailyComplete,
    icon: 'daily',
  });
  const eligible = definitions.filter((item) => item.eligible);
  const [selectedId, setSelectedId] = useState<string | null>(eligible[0]?.id ?? null);
  const selected = definitions.find((item) => item.id === selectedId && item.eligible) ?? eligible[0];

  useEffect(() => {
    void ensureDailyTaskDay(today).then(() => {
      if (isKeyMemoryOnly(KEYS.dailyTasks)) toast('تعذّر حفظ قائمة اليوم دائماً على الجهاز.', 'error');
    }).catch(() => toast('تعذّر تحديث حالة مهام اليوم.', 'error'));
  }, [todayKey]);

  useEffect(() => {
    const nextMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
    const timer = window.setTimeout(() => setToday(new Date()), Math.max(1_000, nextMidnight.getTime() - Date.now() + 100));
    return () => window.clearTimeout(timer);
  }, [todayKey]);

  return (
    <div>
      <PageHeader
        eyebrow="وثائق شخصية مبنية على تقدمك الحقيقي"
        title="شهاداتي"
        subtitle="اختر معلم إنجاز مؤهلاً ثم اطبعه أو احفظه PDF من نافذة الطباعة في المتصفح."
        back="/"
        action={<Button className="min-h-11" size="sm" variant="outline" icon={<Printer size={15} />} disabled={!selected} onClick={() => window.print()}>طباعة / PDF</Button>}
      />

      <Card className="mb-4 border-[color-mix(in_srgb,var(--gold)_45%,var(--line))] bg-[var(--gold-soft)]">
        <div className="flex items-start gap-3"><ShieldAlert size={20} className="mt-1 shrink-0 text-[#8a5b06] dark:text-[var(--gold)]" /><p className="text-sm leading-relaxed text-[var(--ink)]"><strong>تنويه مهم:</strong> هذه شهادة شخصية تحفيزية من منصة منارة فقط. ليست وثيقة رسمية، ولا تصدر عن وزارة التربية، ولا تثبت نتيجة امتحانية أو تفوقاً مدرسياً.</p></div>
      </Card>

      <div className="space-y-2">
        {definitions.map((certificate) => (
          <button
            key={certificate.id}
            type="button"
            disabled={!certificate.eligible}
            aria-pressed={selected?.id === certificate.id}
            onClick={() => setSelectedId(certificate.id)}
            className={`focus-ring w-full rounded-2xl border p-4 text-start transition-colors ${certificate.eligible ? selected?.id === certificate.id ? 'border-[var(--gold)] bg-[var(--gold-soft)]' : 'border-[var(--line)] bg-[var(--surface)] hover:border-[var(--gold)]' : 'cursor-not-allowed border-[var(--line)] bg-[var(--surface-2)] opacity-70'}`}
          >
            <div className="flex items-start gap-3">
              <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${certificate.eligible ? 'bg-[var(--gold)] text-[#3a2606]' : 'bg-[var(--surface)] text-[var(--ink-soft)]'}`}>{certificate.icon === 'curriculum' ? <BookOpenCheck size={19} /> : <CheckCircle2 size={19} />}</span>
              <span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-2 font-display text-base text-[var(--ink)]">{certificate.title}<Badge tone={certificate.eligible ? 'success' : 'neutral'}>{certificate.eligible ? 'متاحة' : 'قيد التقدم'}</Badge></span><span className="mt-1 block text-xs leading-relaxed text-[var(--ink-soft)]">{certificate.criterion}</span><span className="mt-1 block text-[0.7rem] text-[var(--ink-soft)]">{certificate.details}</span></span>
            </div>
            {certificate.icon === 'curriculum' ? <ProgressBar className="mt-3" value={progress.percent} label="تقدم المنهاج" /> : null}
          </button>
        ))}
      </div>

      {selected ? (
        <section className="print-area mt-6" aria-label="معاينة الشهادة الشخصية">
          <div className="certificate-card relative overflow-hidden rounded-[2rem] border-[3px] border-double border-[var(--gold)] bg-[var(--surface)] px-6 py-10 text-center shadow-[var(--shadow-lift)] sm:px-10 sm:py-14">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]"><Award size={29} /></div>
            <p className="text-xs font-semibold tracking-[0.16em] text-[var(--ink-soft)]">منارة البكالوريا · الفرع العلمي السوري</p>
            <h2 className="mt-3 font-display text-3xl text-[var(--ink)]">شهادة إنجاز شخصية</h2>
            <p className="mt-4 text-sm text-[var(--ink-soft)]">تُمنح إلى</p>
            <p className="mt-1 break-words font-display text-2xl font-bold text-[var(--brand)]">{profile.name.trim() || 'طالب / طالبة البكالوريا'}</p>
            <div className="mx-auto my-5 h-px max-w-xs bg-[var(--line)]" />
            <p className="font-display text-xl text-[var(--ink)]">{selected.title}</p>
            <p className="mx-auto mt-2 max-w-lg text-sm leading-relaxed text-[var(--ink-soft)]">{selected.criterion}. {selected.details}</p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2 text-xs text-[var(--ink-soft)]"><Badge tone="gold">تاريخ الإصدار: {dateLabel()}</Badge><Badge>بيانات محلية من جهاز الطالب</Badge></div>
            <p className="mt-7 border-t border-[var(--line)] pt-4 text-[0.72rem] font-semibold leading-relaxed text-[var(--danger)]">وثيقة شخصية غير رسمية — لا تصدر عن وزارة التربية — ولا تثبت نتيجة امتحانية.</p>
          </div>
        </section>
      ) : (
        <EmptyState className="mt-5" icon={<Award size={20} />} title="لم يتحقق معلم شهادة بعد" description="أكمل ٢٥٪ من بنود متابعة المنهاج أو أتمّ مهام اليوم لتظهر شهادة قابلة للطباعة. الشهادات لا تُنشأ بدرجات أو معلومات مفترضة." action={<Link to="/curriculum-progress" className="focus-ring inline-flex min-h-11 items-center rounded-xl bg-[var(--brand)] px-4 text-sm text-[var(--brand-ink)]">متابعة المنهاج</Link>} />
      )}

      <p className="no-print mt-4 text-center text-xs text-[var(--ink-soft)]">لتغيير الاسم المطبوع، افتح <Link to="/welcome" className="underline underline-offset-4">ملف الطالب</Link>. من مربع الطباعة اختر «حفظ بتنسيق PDF».</p>
    </div>
  );
}
