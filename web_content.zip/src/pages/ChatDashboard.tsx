import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Conversation, ChatMessage } from '../types.js';
import { Sidebar } from '../components/Sidebar.js';
import { ChatMessageItem } from '../components/ChatMessageItem.js';
import { ChatInput } from '../components/ChatInput.js';
import { Modals } from '../components/Modals.js';
import { Logo } from '../components/Logo.js';
import {
  Menu,
  Plus,
  Search,
  Sparkles,
  Bot,
  User as UserIcon,
  ChevronRight,
  ShieldCheck,
  AlertCircle,
  Lightbulb,
  Keyboard,
} from 'lucide-react';

export const ChatDashboard: React.FC = () => {
  const { user, token, preferences, activeConversationId, setActiveConversationId, authFetch, setCurrentPage } =
    useAuth();

  // Conversations and Messages
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [loadingMessages, setLoadingMessages] = useState(false);

  // Streaming State
  const [isGenerating, setIsGenerating] = useState(false);
  const [streamingChunk, setStreamingChunk] = useState<string>('');
  const abortControllerRef = useRef<AbortController | null>(null);

  // UI Modals & Mobile Drawer
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);
  const [deleteAccountModalOpen, setDeleteAccountModalOpen] = useState(false);
  const [clearHistoryModalOpen, setClearHistoryModalOpen] = useState(false);
  const [renameModal, setRenameModal] = useState<{ open: boolean; conversationId: string; currentTitle: string }>({
    open: false,
    conversationId: '',
    currentTitle: '',
  });
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [shortcutsModalOpen, setShortcutsModalOpen] = useState(false);

  // Auto-scroll ref
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = (smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
  };

  useEffect(() => {
    scrollToBottom(true);
  }, [messages, streamingChunk]);

  // Load conversations list on mount
  const fetchConversations = async () => {
    try {
      const res = await authFetch('/api/conversations');
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
      }
    } catch (err) {
      console.error('Failed to load conversations:', err);
    }
  };

  useEffect(() => {
    fetchConversations();
  }, []);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = typeof window !== 'undefined' && /Mac|iPod|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
      const modifier = isMac ? e.metaKey : e.ctrlKey;

      // 1. Cmd/Ctrl + N -> New Chat
      if (modifier && e.key.toLowerCase() === 'n' && !e.shiftKey && !e.altKey) {
        e.preventDefault();
        handleNewChat();
        return;
      }

      // 2. Cmd/Ctrl + K or Cmd/Ctrl + F -> Search Conversations
      if (modifier && (e.key.toLowerCase() === 'k' || e.key.toLowerCase() === 'f') && !e.shiftKey && !e.altKey) {
        e.preventDefault();
        setSearchModalOpen(true);
        return;
      }

      // 3. Cmd/Ctrl + / or Cmd/Ctrl + ? -> Open Shortcuts Modal
      if (modifier && (e.key === '/' || e.key === '?')) {
        e.preventDefault();
        setShortcutsModalOpen(prev => !prev);
        return;
      }

      // 4. Cmd/Ctrl + Shift + R -> Regenerate AI Response
      if (modifier && e.shiftKey && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        handleRegenerate();
        return;
      }

      // 5. Escape -> Close any active modal / drawer / stop generation
      if (e.key === 'Escape') {
        if (searchModalOpen) {
          setSearchModalOpen(false);
          e.preventDefault();
        } else if (shortcutsModalOpen) {
          setShortcutsModalOpen(false);
          e.preventDefault();
        } else if (isMobileSidebarOpen) {
          setIsMobileSidebarOpen(false);
          e.preventDefault();
        } else if (logoutModalOpen) {
          setLogoutModalOpen(false);
          e.preventDefault();
        } else if (deleteAccountModalOpen) {
          setDeleteAccountModalOpen(false);
          e.preventDefault();
        } else if (clearHistoryModalOpen) {
          setClearHistoryModalOpen(false);
          e.preventDefault();
        } else if (renameModal.open) {
          setRenameModal({ open: false, conversationId: '', currentTitle: '' });
          e.preventDefault();
        } else if (isGenerating) {
          handleStopGenerating();
          e.preventDefault();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isGenerating,
    searchModalOpen,
    shortcutsModalOpen,
    isMobileSidebarOpen,
    logoutModalOpen,
    deleteAccountModalOpen,
    clearHistoryModalOpen,
    renameModal.open,
    messages,
  ]);

  // Load messages when activeConversationId changes
  useEffect(() => {
    if (!activeConversationId) {
      setMessages([]);
      setActiveConv(null);
      return;
    }

    const loadConv = async () => {
      setLoadingMessages(true);
      try {
        const res = await authFetch(`/api/conversations/${activeConversationId}`);
        if (res.ok) {
          const data = await res.json();
          setActiveConv(data.conversation);
          setMessages(data.messages || []);
        } else {
          setActiveConversationId(null);
        }
      } catch (err) {
        console.error('Error fetching conversation messages:', err);
      } finally {
        setLoadingMessages(false);
      }
    };

    loadConv();
  }, [activeConversationId]);

  // Start a new chat
  const handleNewChat = () => {
    if (isGenerating && abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setActiveConversationId(null);
    setActiveConv(null);
    setMessages([]);
    setStreamingChunk('');
    setIsGenerating(false);
  };

  // Select a conversation from sidebar or search
  const handleSelectConversation = (id: string) => {
    if (id === activeConversationId) return;
    if (isGenerating && abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsGenerating(false);
    setStreamingChunk('');
    setActiveConversationId(id);
  };

  // Rename a conversation
  const handleRenameSuccess = (id: string, newTitle: string) => {
    setConversations(prev =>
      prev.map(c => (c.id === id ? { ...c, title: newTitle, updatedAt: new Date().toISOString() } : c))
    );
    if (activeConv?.id === id) {
      setActiveConv(prev => (prev ? { ...prev, title: newTitle } : null));
    }
  };

  // Delete a conversation
  const handleDeleteConversation = async (id: string) => {
    try {
      const res = await authFetch(`/api/conversations/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setConversations(prev => prev.filter(c => c.id !== id));
        if (activeConversationId === id) {
          handleNewChat();
        }
      }
    } catch (err) {
      console.error('Error deleting conversation:', err);
    }
  };

  // Clear all history
  const handleClearHistorySuccess = () => {
    setConversations([]);
    handleNewChat();
  };

  // Send Message (Supports streaming)
  const handleSendMessage = async (userText: string, isRegenerate = false) => {
    if (!userText.trim() || isGenerating) return;

    setIsGenerating(true);
    setStreamingChunk('');

    // Optimistically add user message if not regenerating
    const tempUserMsgId = `temp-${Date.now()}`;
    if (!isRegenerate) {
      const tempUserMsg: ChatMessage = {
        id: tempUserMsgId,
        conversationId: activeConversationId || 'temp',
        userId: user?.id || '',
        role: 'user',
        content: userText,
        createdAt: new Date().toISOString(),
      };
      setMessages(prev => [...prev, tempUserMsg]);
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          conversationId: activeConversationId,
          content: userText,
          regenerate: isRegenerate,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`Server returned error ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');

      if (!reader) {
        throw new Error('ReadableStream not supported.');
      }

      let buffer = '';
      let currentAcc = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const eventData = JSON.parse(line.substring(6));

              if (eventData.type === 'init') {
                if (eventData.conversationId && eventData.conversationId !== activeConversationId) {
                  setActiveConversationId(eventData.conversationId);
                  fetchConversations();
                }
              } else if (eventData.type === 'chunk') {
                currentAcc += eventData.text;
                setStreamingChunk(currentAcc);
              } else if (eventData.type === 'done') {
                if (eventData.message) {
                  setMessages(prev => {
                    const filtered = isRegenerate && prev[prev.length - 1]?.role === 'model'
                      ? prev.slice(0, -1)
                      : prev;
                    return [...filtered, eventData.message];
                  });
                }
                if (eventData.title) {
                  fetchConversations();
                }
                setStreamingChunk('');
              } else if (eventData.type === 'error') {
                console.error('Stream error:', eventData.error);
                setMessages(prev => [
                  ...prev,
                  {
                    id: `err-${Date.now()}`,
                    conversationId: activeConversationId || 'temp',
                    userId: user?.id || '',
                    role: 'model',
                    content: `⚠️ Error: ${eventData.error}`,
                    createdAt: new Date().toISOString(),
                  },
                ]);
              }
            } catch (pErr) {
              console.warn('Error parsing SSE event:', pErr);
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream aborted by user.');
      } else {
        console.error('Generation failure:', err);
        setMessages(prev => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            conversationId: activeConversationId || 'temp',
            userId: user?.id || '',
            role: 'model',
            content: `⚠️ Failed to get AI response: ${err.message || 'Connection error'}. Please try again.`,
            createdAt: new Date().toISOString(),
          },
        ]);
      }
    } finally {
      setIsGenerating(false);
      setStreamingChunk('');
      abortControllerRef.current = null;
      fetchConversations();
    }
  };

  // Stop Generating
  const handleStopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsGenerating(false);
    }
  };

  // Regenerate Response
  const handleRegenerate = () => {
    if (messages.length === 0 || isGenerating) return;
    // Find last user message
    let lastUserMessage = '';
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'user') {
        lastUserMessage = messages[i].content;
        break;
      }
    }
    if (lastUserMessage) {
      handleSendMessage(lastUserMessage, true);
    }
  };

  // Message feedback
  const handleFeedback = async (messageId: string, feedback: 'like' | 'dislike' | null) => {
    try {
      await authFetch(`/api/messages/${messageId}/feedback`, {
        method: 'POST',
        body: JSON.stringify({ feedback }),
      });
      setMessages(prev =>
        prev.map(m => (m.id === messageId ? { ...m, feedback: feedback || undefined } : m))
      );
    } catch (err) {
      console.error('Failed to save feedback:', err);
    }
  };

  const starterPrompts = [
    {
      title: 'Write a professional email',
      prompt: 'Draft a polite and concise email following up on a job interview I had yesterday.',
      icon: '✉️',
    },
    {
      title: 'Explain quantum computing',
      prompt: 'Explain how quantum computing works simply, using analogies anyone can understand.',
      icon: '🔬',
    },
    {
      title: 'Plan a 3-day travel itinerary',
      prompt: 'Create a balanced 3-day travel itinerary for visiting Tokyo with sightseeing and food recommendations.',
      icon: '✈️',
    },
    {
      title: 'Debug JavaScript code',
      prompt: 'Can you look at my code logic and show me how to handle async fetch requests with error handling?',
      icon: '💻',
    },
  ];

  return (
    <div className="h-screen w-screen flex overflow-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Responsive Sidebar */}
      <Sidebar
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={handleSelectConversation}
        onNewChat={handleNewChat}
        onOpenRename={conv =>
          setRenameModal({ open: true, conversationId: conv.id, currentTitle: conv.title })
        }
        onDeleteConversation={handleDeleteConversation}
        onOpenClearHistory={() => setClearHistoryModalOpen(true)}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenLogoutModal={() => setLogoutModalOpen(true)}
        isOpenMobile={isMobileSidebarOpen}
        setIsOpenMobile={setIsMobileSidebarOpen}
      />

      {/* Main Chat Stage */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-white dark:bg-slate-950 transition-colors">
        {/* Top Chat Header */}
        <header className="h-14 sm:h-16 px-3 sm:px-5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between shrink-0 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md z-10">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            {/* Mobile hamburger */}
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="md:hidden p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Open sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Conversation Title & Model */}
            <div className="flex items-center gap-2 min-w-0">
              <div className="hidden sm:block">
                <Logo size="xs" showText={false} />
              </div>
              <div className="min-w-0">
                <h2 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate max-w-[180px] sm:max-w-md">
                  {activeConv ? activeConv.title : 'New Chat'}
                </h2>
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>Gemini 3.8 Flash</span>
                  <span className="hidden sm:inline">•</span>
                  <span className="hidden sm:inline">OWNER: Ali ABDULLAH</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => setShortcutsModalOpen(true)}
              className="p-2 rounded-xl text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Keyboard Shortcuts (⌘/Ctrl + /)"
            >
              <Keyboard className="w-4 h-4" />
            </button>

            <button
              onClick={() => setSearchModalOpen(true)}
              className="p-2 rounded-xl text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center gap-1"
              title="Search Conversations (⌘/Ctrl + K)"
            >
              <Search className="w-4 h-4" />
              <kbd className="hidden lg:inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-medium bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700">⌘K</kbd>
            </button>

            <button
              onClick={handleNewChat}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/80 font-semibold text-xs flex items-center gap-1.5 transition"
              title="New Chat (⌘/Ctrl + N)"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">New Chat</span>
              <kbd className="hidden lg:inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-medium bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300">⌘N</kbd>
            </button>

            <button
              onClick={() => setCurrentPage('profile')}
              className="p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Profile & Settings"
            >
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user?.name}
                  className="w-7 h-7 rounded-lg object-cover"
                />
              ) : (
                <div className="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center">
                  {user?.name?.charAt(0).toUpperCase() || 'U'}
                </div>
              )}
            </button>
          </div>
        </header>

        {/* Messages Feed OR Welcome Screen */}
        <div className="flex-1 overflow-y-auto">
          {messages.length === 0 && !streamingChunk && !loadingMessages ? (
            /* Welcome / Starter View */
            <div className="h-full max-w-2xl mx-auto px-4 py-8 flex flex-col justify-center items-center text-center space-y-6">
              <div className="relative">
                <Logo size="lg" showText={false} />
                <div className="absolute -bottom-1 -right-1 p-1 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-950 shadow-xs">
                  <Sparkles className="w-3 h-3 text-white" />
                </div>
              </div>

              <div className="space-y-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Hello, {user?.name || 'Explorer'}!
                </h1>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
                  How can AI Pocket Chat assist you today? You can type below or tap the microphone to speak hands-free.
                </p>
                <p className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400">
                  OWNER NAME: Ali ABDULLAH
                </p>
              </div>

              {/* Quick Starter Suggestions */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-left">
                {starterPrompts.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(p.prompt)}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/30 hover:border-indigo-300 dark:hover:border-indigo-800/60 transition group text-xs"
                  >
                    <div className="flex items-center gap-2 font-semibold text-slate-800 dark:text-slate-200 mb-1">
                      <span>{p.icon}</span>
                      <span>{p.title}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                      "{p.prompt}"
                    </p>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Active Messages List */
            <div className="py-4 space-y-1">
              {messages.map(m => (
                <ChatMessageItem
                  key={m.id}
                  message={m}
                  onRegenerate={m.role === 'model' ? handleRegenerate : undefined}
                  onFeedback={handleFeedback}
                  voiceSettings={preferences?.voiceSettings}
                />
              ))}

              {/* Active Streaming Message Bubble */}
              {isGenerating && streamingChunk && (
                <ChatMessageItem
                  message={{
                    id: 'streaming-live',
                    conversationId: activeConversationId || 'temp',
                    userId: user?.id || '',
                    role: 'model',
                    content: streamingChunk,
                    createdAt: new Date().toISOString(),
                  }}
                  isStreaming={true}
                />
              )}

              {/* Waiting for first token indicator */}
              {isGenerating && !streamingChunk && (
                <div className="w-full py-4 px-3 sm:px-5 bg-slate-100/50 dark:bg-slate-900/40">
                  <div className="max-w-4xl mx-auto flex items-center gap-3">
                    <Logo size="xs" showText={false} />
                    <div className="flex items-center gap-1.5 text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                      <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" />
                      <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.2s]" />
                      <span className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.4s]" />
                      <span className="ml-2 text-slate-400 text-[11px]">
                        AI Pocket Chat is thinking...
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Chat Input Bar */}
        <div className="shrink-0 bg-gradient-to-t from-white via-white to-transparent dark:from-slate-950 dark:via-slate-950 pt-2">
          <ChatInput
            onSendMessage={handleSendMessage}
            isGenerating={isGenerating}
            onStopGenerating={handleStopGenerating}
          />
        </div>
      </div>

      {/* Modals Collection */}
      <Modals
        logoutModalOpen={logoutModalOpen}
        setLogoutModalOpen={setLogoutModalOpen}
        deleteAccountModalOpen={deleteAccountModalOpen}
        setDeleteAccountModalOpen={setDeleteAccountModalOpen}
        clearHistoryModalOpen={clearHistoryModalOpen}
        setClearHistoryModalOpen={setClearHistoryModalOpen}
        renameModal={renameModal}
        setRenameModal={setRenameModal}
        onRenameSuccess={handleRenameSuccess}
        onClearHistorySuccess={handleClearHistorySuccess}
        searchModalOpen={searchModalOpen}
        setSearchModalOpen={setSearchModalOpen}
        onSelectSearchResult={handleSelectConversation}
        shortcutsModalOpen={shortcutsModalOpen}
        setShortcutsModalOpen={setShortcutsModalOpen}
      />
    </div>
  );
};
