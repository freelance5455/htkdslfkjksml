import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, BookOpenCheck, Check, ChevronLeft, ChevronRight, ExternalLink, HelpCircle, LoaderCircle, RotateCcw, Send, X } from 'lucide-react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { PageHeader } from '../components/layout/PageHeader';
import { Badge, EmptyState, Skeleton } from '../components/ui/Feedback';
import { ProgressBar } from '../components/ui/Card';
import { loadUnitQuestions } from '../data/questionBank';
import { CURRICULUM_SOURCES, CURRICULUM_UNITS } from '../data/curriculum/units';
import { recordObjectiveAttempt, recordWrittenAnswer } from '../services/practice';
import { getCurriculumItemTitle } from '../services/curriculumProgress';
import { KEYS, useStored } from '../services/storage';
import { subjects } from '../data/content';
import type { CurriculumPracticeAttempt, CurriculumQuestion } from '../types';
import { openAssetInNewTab } from '../utils/publicAssets';

const writtenKinds = new Set(['short-answer', 'reasoning', 'proof', 'problem', 'essay', 'language-writing']);

function kindLabel(question: CurriculumQuestion): string {
  if (question.kind === 'mcq') return 'اختيار من متعدد';
  if (question.kind === 'true-false') return 'صح أو خطأ';
  const labels: Record<string, string> = {
    'short-answer': 'إجابة قصيرة', reasoning: 'تعليل أو مقارنة', proof: 'برهان أو اشتقاق',
    problem: 'مسألة متعددة الخطوات', essay: 'سؤال تحريري', 'language-writing': 'كتابة وفهم لغوي',
  };
  return labels[question.kind] ?? 'تدريب';
}

export default function UnitPractice() {
  const { subjectId = '', unitId = '' } = useParams();
  const [searchParams] = useSearchParams();
  const lessonId = searchParams.get('lessonId') || undefined;
  const unit = CURRICULUM_UNITS.find((item) => item.id === unitId && item.subjectId === subjectId);
  const subject = subjects.find((item) => item.id === subjectId);
  const activeIdeaTitle = unit && lessonId ? getCurriculumItemTitle(unit, lessonId) : undefined;
  const [questions, setQuestions] = useState<CurriculumQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [objectiveCorrect, setObjectiveCorrect] = useState<boolean | null>(null);
  const [response, setResponse] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [selfScore, setSelfScore] = useState<number | null>(null);
  const [saved, setSaved] = useState(false);
  const [notice, setNotice] = useState('');
  const [saving, setSaving] = useState(false);
  const attempts = useStored(KEYS.practiceAttempts, [] as CurriculumPracticeAttempt[]);
  const current = questions[index];
  const scopedQuestionIds = useMemo(() => new Set(questions.map((question) => question.id)), [questions]);
  const attemptedIds = useMemo(
    () => new Set(attempts.filter((item) => item.unitId === unitId && scopedQuestionIds.has(item.questionId)).map((item) => item.questionId)),
    [attempts, unitId, scopedQuestionIds],
  );

  useEffect(() => {
    let live = true;
    setLoading(true);
    setLoadError('');
    setIndex(0);
    void loadUnitQuestions(subjectId, unitId, lessonId)
      .then((items) => { if (live) setQuestions(items); })
      .catch(() => { if (live) setLoadError('تعذّر تحميل أسئلة الوحدة. تحقق من الاتصال ثم أعد المحاولة.'); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [subjectId, unitId, lessonId]);

  useEffect(() => {
    setSelected(null);
    setObjectiveCorrect(null);
    setResponse('');
    setRevealed(false);
    setSelfScore(null);
    setSaved(false);
    setNotice('');
  }, [index, unitId, lessonId]);

  if (!unit || !subject) {
    return <EmptyState icon={<HelpCircle size={20} />} title="الوحدة غير موجودة" description="ارجع إلى بنك الأسئلة واختر وحدة من القائمة." action={<Link className="focus-ring rounded-xl bg-[var(--brand)] px-4 py-2 text-sm text-[var(--brand-ink)]" to="/question-bank">بنك الأسئلة</Link>} />;
  }

  const objective = current ? current.kind === 'mcq' || current.kind === 'true-false' : false;
  const options = current?.kind === 'true-false' ? (current.choices?.length ? current.choices : ['صح', 'خطأ']) : (current?.choices ?? []);
  const answerIndex = current?.kind === 'true-false' && current.answerIndex === undefined && current.answerBool !== undefined
    ? (current.answerBool ? 0 : 1)
    : current?.answerIndex;
  const answered = attemptedIds.size;
  const questionSources = current?.sourceIds.map((id) => CURRICULUM_SOURCES.find((source) => source.id === id)).filter((source) => source !== undefined) ?? [];
  const citationPages = current?.sourcePages?.length ? current.sourcePages : current?.sourcePage ? [current.sourcePage] : [];
  const modelAnswer = current?.modelAnswer ?? current?.expectedAnswer ?? current?.solutionSteps?.join('\n') ?? '';

  const chooseObjective = async (choiceIndex: number) => {
    if (!current || selected !== null || saving) return;
    setSelected(choiceIndex);
    const correct = current.kind === 'true-false' && current.answerBool !== undefined
      ? (choiceIndex === 0) === current.answerBool
      : choiceIndex === answerIndex;
    setObjectiveCorrect(correct);
    setSaving(true);
    try {
      await recordObjectiveAttempt(current, correct);
      setNotice(correct ? 'إجابة صحيحة، أحسنت.' : 'راجع الفكرة والشرح ثم حاول سؤالاً آخر.');
    } catch {
      setNotice('عرضنا التصحيح، لكن تعذّر حفظ المحاولة على هذا الجهاز.');
    } finally {
      setSaving(false);
    }
  };

  const saveWritten = async () => {
    if (!current || response.trim().length < 2) {
      setNotice('اكتب إجابتك أولاً، حتى لو كانت مختصرة.');
      return;
    }
    if (selfScore === null) {
      setNotice('اختر تقييماً ذاتياً بعد مقارنة إجابتك بالنموذج وسلم التصحيح.');
      return;
    }
    setSaving(true);
    try {
      await recordWrittenAnswer(current, response, selfScore);
      setSaved(true);
      setNotice('حُفظت إجابتك وتقييمك الذاتي على هذا الجهاز.');
    } catch {
      setNotice('تعذّر حفظ الإجابة. حاول مرة أخرى.');
    } finally {
      setSaving(false);
    }
  };

  const changeQuestion = (next: number) => setIndex(Math.max(0, Math.min(questions.length - 1, next)));

  return (
    <div>
      <div className="mb-3"><Link to="/question-bank" className="focus-ring inline-flex min-h-10 items-center gap-1 rounded-xl px-2 text-xs text-[var(--brand)]"><ArrowRight size={15} /> كل الوحدات</Link></div>
      <PageHeader eyebrow={`${subject.name} · ${activeIdeaTitle ? 'اختبار فكرة موثق' : 'تدريب مرتبط بالوحدة'}`} title={activeIdeaTitle ?? unit.title} subtitle="حلّ السؤال أولاً، ثم راجع الإجابة والشرح أو قيّم إجابتك التحريرية وفق سلم واضح." />
      {loading ? <div className="space-y-3"><Skeleton className="h-24" /><Skeleton className="h-52" /></div> : loadError ? (
        <EmptyState icon={<RotateCcw size={20} />} title="لم تُحمّل الأسئلة" description={loadError} />
      ) : questions.length === 0 ? (
        <EmptyState icon={<BookOpenCheck size={20} />} title={lessonId ? 'لا يوجد اختبار موثق لهذه الفكرة بعد' : 'لا توجد أسئلة منشورة لهذه الوحدة بعد'} description={lessonId ? `لم تُنشر أسئلة موثقة مرتبطة بـ «${activeIdeaTitle ?? 'هذه الفكرة'}» بعد. لن نعرض سؤالاً قبل ربطه بمصدر رسمي.` : 'لا نعرض سؤالاً قبل ربطه بمصدر رسمي موثّق. ستظهر الأسئلة هنا بعد استكمال فهرسة الكتاب لهذه الوحدة.'} />
      ) : current ? (
        <>
          <section className="card mb-3 p-3.5">
            <div className="flex items-center justify-between gap-3 text-xs text-[var(--ink-soft)]"><span>السؤال {(index + 1).toLocaleString('ar-SY')} من {questions.length.toLocaleString('ar-SY')}</span><span>{answered.toLocaleString('ar-SY')} محاولة محفوظة في الوحدة</span></div>
            <ProgressBar value={((index + 1) / questions.length) * 100} className="mt-2" height={6} label="التقدم في أسئلة الوحدة" />
          </section>

          <article className="card p-4 sm:p-5">
            <div className="mb-3 flex flex-wrap items-center gap-2"><Badge tone="brand">{kindLabel(current)}</Badge><Badge tone="neutral">{current.difficulty}</Badge><Badge tone="gold">{current.maxPoints} {current.maxPoints === 1 ? 'درجة' : 'درجات'}</Badge></div>
            <h2 className="whitespace-pre-line text-base font-semibold leading-relaxed text-[var(--ink)] sm:text-lg">{current.prompt}</h2>
            <p className="mt-2 text-xs text-[var(--ink-soft)]">الموضوع: {current.topic}</p>

            {objective ? (
              <div className="mt-4 space-y-2">
                {options.map((option, optionIndex) => {
                  const isAnswer = optionIndex === answerIndex;
                  const isSelected = selected === optionIndex;
                  const stateClass = objectiveCorrect !== null && isAnswer
                    ? 'border-[var(--success)] bg-[var(--success)]/10 text-[var(--success)]'
                    : isSelected && objectiveCorrect === false
                      ? 'border-[var(--danger)] bg-[var(--danger)]/10 text-[var(--danger)]'
                      : 'border-[var(--line)] bg-[var(--surface)] text-[var(--ink)] hover:bg-[var(--surface-2)]';
                  return (
                    <button key={`${current.id}-${optionIndex}`} type="button" disabled={selected !== null || saving} onClick={() => void chooseObjective(optionIndex)} className={`focus-ring flex min-h-12 w-full items-center gap-3 rounded-2xl border px-3 text-start text-sm transition-colors disabled:cursor-default ${stateClass}`}>
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[var(--surface-2)] text-xs">{objectiveCorrect !== null && isAnswer ? <Check size={15} /> : isSelected && objectiveCorrect === false ? <X size={15} /> : (optionIndex + 1).toLocaleString('ar-SY')}</span>
                      <span>{option}</span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="mt-4 space-y-3">
                <label htmlFor={`answer-${current.id}`} className="block text-xs font-medium text-[var(--ink)]">اكتب إجابتك قبل إظهار النموذج</label>
                <textarea id={`answer-${current.id}`} value={response} onChange={(event) => setResponse(event.target.value)} maxLength={5000} rows={5} placeholder="دوّن خطواتك أو أفكارك هنا…" disabled={saved} className="focus-ring w-full resize-y rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3 text-sm leading-relaxed text-[var(--ink)] placeholder:text-[var(--ink-soft)]" />
                {!revealed ? <button type="button" onClick={() => { if (response.trim().length < 2) setNotice('اكتب إجابتك أولاً قبل إظهار النموذج.'); else { setRevealed(true); setNotice('قارن إجابتك بعناصر النموذج وسلم التصحيح.'); } }} className="focus-ring flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[var(--brand)] px-3 text-sm font-semibold text-[var(--brand-ink)]"><BookOpenCheck size={16} /> أظهر نموذج الإجابة وسلم التصحيح</button> : null}
                {revealed ? (
                  <div className="space-y-3 rounded-2xl bg-[var(--surface-2)] p-3.5">
                    <div><p className="text-xs font-semibold text-[var(--ink)]">نموذج الإجابة</p><p className="mt-1 whitespace-pre-line text-sm leading-relaxed text-[var(--ink-soft)]">{modelAnswer || 'لا يتوفر نموذج إجابة موثق لهذا السؤال.'}</p></div>
                    {current.solutionSteps?.length ? <ol className="list-decimal space-y-1 pe-5 text-xs leading-relaxed text-[var(--ink-soft)]">{current.solutionSteps.map((step, stepIndex) => <li key={`${current.id}-step-${stepIndex}`}>{step}</li>)}</ol> : null}
                    {current.rubric?.length ? <div><p className="mb-1 text-xs font-semibold text-[var(--ink)]">سلم التصحيح ({current.maxPoints} درجات)</p><ul className="space-y-1">{current.rubric.map((criterion, criterionIndex) => <li key={`${current.id}-rubric-${criterionIndex}`} className="flex justify-between gap-2 text-xs text-[var(--ink-soft)]"><span>{criterion.label}</span><span className="shrink-0">{criterion.points} د</span></li>)}</ul></div> : null}
                    <label htmlFor={`score-${current.id}`} className="block text-xs font-medium text-[var(--ink)]">قيّم إجابتك بنفسك بعد المقارنة بالنموذج وسلم التصحيح</label>
                    <select id={`score-${current.id}`} value={selfScore ?? ''} onChange={(event) => setSelfScore(event.target.value === '' ? null : Number(event.target.value))} className="focus-ring min-h-11 w-full rounded-xl border border-[var(--line)] bg-[var(--surface)] px-3 text-sm text-[var(--ink)]"><option value="">اختر درجتك من ٠ إلى {current.maxPoints.toLocaleString('ar-SY')}</option>{Array.from({ length: current.maxPoints + 1 }, (_, score) => <option key={score} value={score}>{score.toLocaleString('ar-SY')} / {current.maxPoints.toLocaleString('ar-SY')}</option>)}</select>
                    <button type="button" onClick={() => void saveWritten()} disabled={saving || saved} className="focus-ring flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[var(--brand)] px-3 text-sm font-semibold text-[var(--brand-ink)] disabled:opacity-60"><Send size={15} /> {saving ? 'جارٍ الحفظ…' : saved ? 'حُفظت الإجابة' : 'احفظ إجابتي وتقييمي الذاتي'}</button>
                  </div>
                ) : null}
              </div>
            )}

            {objectiveCorrect !== null ? <div className={`mt-4 rounded-2xl p-3 text-sm ${objectiveCorrect ? 'bg-[var(--success)]/10 text-[var(--success)]' : 'bg-[var(--gold-soft)] text-[var(--ink)]'}`}><p className="font-semibold">{objectiveCorrect ? 'إجابة صحيحة' : 'الإجابة الصحيحة موضحة أدناه'}</p>{current.explanation ? <p className="mt-1 whitespace-pre-line text-xs leading-relaxed">{current.explanation}</p> : null}{!objectiveCorrect && answerIndex !== undefined ? <p className="mt-1 text-xs">الإجابة: {options[answerIndex]}</p> : null}</div> : null}
            {notice ? <p role="status" className="mt-3 rounded-xl bg-[var(--surface-2)] px-3 py-2 text-xs text-[var(--ink-soft)]">{notice}</p> : null}

            {questionSources.length ? (
              <div className="mt-4 border-t border-[var(--line)] pt-3">
                <p className="mb-1 text-[0.67rem] font-medium text-[var(--ink-soft)]">مرجع السؤال</p>
                <div className="flex flex-wrap gap-x-3 gap-y-1">
                  {questionSources.flatMap((source) => (citationPages.length ? citationPages : [undefined]).map((page) => (
                    <a key={`${source.id}-${page ?? 'book'}`} href={page && source.kind === 'textbook' ? `${source.url}#page=${page}` : source.url} target="_blank" rel="noreferrer" onClick={(event) => { const url = page && source.kind === 'textbook' ? `${source.url}#page=${page}` : source.url; if (url.startsWith('data:application/pdf;base64,')) { event.preventDefault(); openAssetInNewTab(url, `${source.id}.pdf`); } }} className="focus-ring inline-flex min-h-11 items-center gap-1 text-[0.68rem] text-[var(--brand)] underline-offset-4 hover:underline">
                      {source.title}{page ? ` · ص ${page.toLocaleString('ar-SY')}` : ''}<ExternalLink size={12} />
                    </a>
                  )))}
                </div>
              </div>
            ) : null}
          </article>

          <div className="mt-3 flex items-center justify-between gap-2">
            <button type="button" onClick={() => changeQuestion(index - 1)} disabled={index === 0} className="focus-ring flex min-h-11 items-center gap-1 rounded-xl border border-[var(--line)] px-3 text-xs text-[var(--ink)] disabled:opacity-45"><ChevronRight size={16} />السابق</button>
            <span className="text-[0.68rem] text-[var(--ink-soft)]">{writtenKinds.has(current.kind) ? 'تحريري · تقييم ذاتي' : 'تصحيح فوري'}</span>
            <button type="button" onClick={() => changeQuestion(index + 1)} disabled={index >= questions.length - 1} className="focus-ring flex min-h-11 items-center gap-1 rounded-xl bg-[var(--brand)] px-3 text-xs font-semibold text-[var(--brand-ink)] disabled:opacity-45">التالي<ChevronLeft size={16} /></button>
          </div>
        </>
      ) : <div className="card p-4 text-center text-sm text-[var(--ink-soft)]"><LoaderCircle className="mx-auto mb-2 animate-spin" size={19} />جارٍ التحميل…</div>}
    </div>
  );
}
