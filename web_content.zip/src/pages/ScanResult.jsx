import React, { useMemo, useState, useEffect } from "react";
import defaultBowlImg from "../assets/images/meal_mediterranean_bowl_1791967840332.jpg";
import { saveMealToFirestore } from "../lib/firebaseService";

/* CalSen — AI Food Scan Breakdown
   Layout follows the "Details" reference: full-bleed hero, translucent round
   buttons, a dark rounded sheet overlapping the hero, a capsule summary card,
   pill chips and two pill buttons at the bottom.
   Tailwind is used for layout only; colors/gradients/glass are inline styles. */

const DEFAULT_DISH = "Grilled Chicken Bowl";
const PROTEIN_GOAL = 120; // g/day, used by the insight text
const MEALS = ["Breakfast", "Lunch", "Dinner", "Snack"];

const CSS = `@import url('https://fonts.googleapis.com/css2?family=Urbanist:wght@500;600;700;800&display=swap');
.cs-in::placeholder{color:var(--ph)}
.cs-btn{transition:transform .12s ease;cursor:pointer;font-family:inherit}
.cs-btn:active{transform:scale(.96)}
.cs-btn:focus-visible,.cs-in:focus-visible{outline:2px solid #FB923C;outline-offset:2px}`;

const GRAD = { backgroundImage: "linear-gradient(135deg,#F97316,#EA580C)", color: "#fff" };
const BLUR = { backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" };

// per-100g values; tag = detection-box position (%) inside the plate box
const SEED = [
  { id: 1, name: "Grilled Chicken Breast", short: "Chicken", unit: "g", amount: 180, k: 165, p: 31, c: 0, f: 3.6, tag: { x: 34, y: 50 } },
  { id: 2, name: "Cooked Brown Rice", short: "Brown rice", unit: "g", amount: 150, k: 110, p: 2.6, c: 23, f: 0.9, tag: { x: 70, y: 56 } },
  { id: 3, name: "Olive Oil", short: "Olive oil", unit: "ml", amount: 10, k: 880, p: 0, c: 0, f: 100, tag: { x: 50, y: 80 } },
  { id: 4, name: "Steamed Veggies", short: "Veggies", unit: "g", amount: 120, k: 37.5, p: 2.5, c: 7, f: 0.3, tag: { x: 52, y: 26 } },
];

// ---- Built-in food database (values per 100 g) ----
const FOODS = [
  { id: "chicken-breast", name: "Chicken Breast", caloriesPer100g: 165, proteinPer100g: 31, carbsPer100g: 0, fatPer100g: 3.6, defaultUnit: "g", cat: "meat" },
  { id: "white-rice", name: "White Rice", caloriesPer100g: 130, proteinPer100g: 2.7, carbsPer100g: 28, fatPer100g: 0.3, defaultUnit: "g", cat: "grain" },
  { id: "brown-rice", name: "Brown Rice", caloriesPer100g: 112, proteinPer100g: 2.3, carbsPer100g: 23, fatPer100g: 0.8, defaultUnit: "g", cat: "grain" },
  { id: "eggs", name: "Eggs", caloriesPer100g: 155, proteinPer100g: 13, carbsPer100g: 1.1, fatPer100g: 11, defaultUnit: "g", cat: "meat" },
  { id: "banana", name: "Banana", caloriesPer100g: 89, proteinPer100g: 1.1, carbsPer100g: 23, fatPer100g: 0.3, defaultUnit: "g", cat: "produce" },
  { id: "apple", name: "Apple", caloriesPer100g: 52, proteinPer100g: 0.3, carbsPer100g: 14, fatPer100g: 0.2, defaultUnit: "g", cat: "produce" },
  { id: "orange", name: "Orange", caloriesPer100g: 47, proteinPer100g: 0.9, carbsPer100g: 12, fatPer100g: 0.1, defaultUnit: "g", cat: "produce" },
  { id: "olive-oil", name: "Olive Oil", caloriesPer100g: 884, proteinPer100g: 0, carbsPer100g: 0, fatPer100g: 100, defaultUnit: "g", cat: "drop" },
  { id: "salmon", name: "Salmon", caloriesPer100g: 208, proteinPer100g: 20, carbsPer100g: 0, fatPer100g: 13, defaultUnit: "g", cat: "meat" },
  { id: "tuna", name: "Tuna (canned in water)", caloriesPer100g: 116, proteinPer100g: 26, carbsPer100g: 0, fatPer100g: 0.8, defaultUnit: "g", cat: "meat" },
  { id: "ground-beef", name: "Ground Beef (cooked)", caloriesPer100g: 250, proteinPer100g: 26, carbsPer100g: 0, fatPer100g: 15, defaultUnit: "g", cat: "meat" },
  { id: "tofu", name: "Tofu", caloriesPer100g: 76, proteinPer100g: 8, carbsPer100g: 1.9, fatPer100g: 4.8, defaultUnit: "g", cat: "meat" },
  { id: "bread", name: "Bread", caloriesPer100g: 265, proteinPer100g: 9, carbsPer100g: 49, fatPer100g: 3.2, defaultUnit: "g", cat: "grain" },
  { id: "pasta", name: "Pasta (cooked)", caloriesPer100g: 131, proteinPer100g: 5, carbsPer100g: 25, fatPer100g: 1.1, defaultUnit: "g", cat: "grain" },
  { id: "oats", name: "Oats", caloriesPer100g: 389, proteinPer100g: 17, carbsPer100g: 66, fatPer100g: 7, defaultUnit: "g", cat: "grain" },
  { id: "lentils", name: "Lentils (cooked)", caloriesPer100g: 116, proteinPer100g: 9, carbsPer100g: 20, fatPer100g: 0.4, defaultUnit: "g", cat: "grain" },
  { id: "hummus", name: "Hummus", caloriesPer100g: 166, proteinPer100g: 8, carbsPer100g: 14, fatPer100g: 10, defaultUnit: "g", cat: "grain" },
  { id: "potato", name: "Potato (boiled)", caloriesPer100g: 87, proteinPer100g: 1.9, carbsPer100g: 20, fatPer100g: 0.1, defaultUnit: "g", cat: "produce" },
  { id: "sweet-potato", name: "Sweet Potato (baked)", caloriesPer100g: 90, proteinPer100g: 2, carbsPer100g: 21, fatPer100g: 0.1, defaultUnit: "g", cat: "produce" },
  { id: "broccoli", name: "Broccoli", caloriesPer100g: 34, proteinPer100g: 2.8, carbsPer100g: 7, fatPer100g: 0.4, defaultUnit: "g", cat: "produce" },
  { id: "tomato", name: "Tomato", caloriesPer100g: 18, proteinPer100g: 0.9, carbsPer100g: 3.9, fatPer100g: 0.2, defaultUnit: "g", cat: "produce" },
  { id: "cucumber", name: "Cucumber", caloriesPer100g: 15, proteinPer100g: 0.7, carbsPer100g: 3.6, fatPer100g: 0.1, defaultUnit: "g", cat: "produce" },
  { id: "avocado", name: "Avocado", caloriesPer100g: 160, proteinPer100g: 2, carbsPer100g: 9, fatPer100g: 15, defaultUnit: "g", cat: "produce" },
  { id: "almonds", name: "Almonds", caloriesPer100g: 579, proteinPer100g: 21, carbsPer100g: 22, fatPer100g: 50, defaultUnit: "g", cat: "produce" },
  { id: "milk", name: "Milk (whole)", caloriesPer100g: 61, proteinPer100g: 3.2, carbsPer100g: 4.8, fatPer100g: 3.3, defaultUnit: "g", cat: "drop" },
  { id: "peanut-butter", name: "Peanut Butter", caloriesPer100g: 588, proteinPer100g: 25, carbsPer100g: 20, fatPer100g: 50, defaultUnit: "g", cat: "drop" },
  { id: "greek-yogurt", name: "Greek Yogurt", caloriesPer100g: 59, proteinPer100g: 10, carbsPer100g: 3.6, fatPer100g: 0.4, defaultUnit: "g", cat: "drop" },
  { id: "cheddar", name: "Cheddar Cheese", caloriesPer100g: 403, proteinPer100g: 25, carbsPer100g: 1.3, fatPer100g: 33, defaultUnit: "g", cat: "drop" },
  { id: "butter", name: "Butter", caloriesPer100g: 717, proteinPer100g: 0.9, carbsPer100g: 0.1, fatPer100g: 81, defaultUnit: "g", cat: "drop" },
  { id: "honey", name: "Honey", caloriesPer100g: 304, proteinPer100g: 0.3, carbsPer100g: 82, fatPer100g: 0, defaultUnit: "g", cat: "drop" },
];

// Used when the typed name is not in the database (rough average per 100 g)
const GENERIC = { id: "generic", caloriesPer100g: 150, proteinPer100g: 6, carbsPer100g: 20, fatPer100g: 5, defaultUnit: "g", cat: "generic" };

const searchFoods = (q) =>
  FOODS.filter((f) => f.name.toLowerCase().includes(q))
    .sort((a, b) => Number(!a.name.toLowerCase().startsWith(q)) - Number(!b.name.toLowerCase().startsWith(q)))
    .slice(0, 5);

const estimate = (f, g) =>
  f && {
    kcal: Math.round((g * f.caloriesPer100g) / 100),
    p: Math.round((g * f.proteinPer100g) / 100),
    c: Math.round((g * f.carbsPer100g) / 100),
    f: Math.round((g * f.fatPer100g) / 100),
  };

const CATS = {
  meat: { c: "#F97316", d: "M15 4a5 5 0 00-3.6 8.4L6 18l1.5 1.5L9 21l5.4-5.4A5 5 0 0015 4z" },
  grain: { c: "#D97706", d: "M12 21V8M12 8c-2.2 0-3.5-1.6-3.5-3.5 2.2 0 3.5 1.6 3.5 3.5zm0 0c2.2 0 3.5-1.6 3.5-3.5-2.2 0-3.5 1.6-3.5 3.5zM12 14c-2.2 0-3.5-1.6-3.5-3.5 2.2 0 3.5 1.6 3.5 3.5zm0 0c2.2 0 3.5-1.6 3.5-3.5-2.2 0-3.5 1.6-3.5 3.5z" },
  produce: { c: "#16A34A", d: "M5 19c0-8 5-14 14-14 0 9-6 14-14 14zM5 19l7-7" },
  drop: { c: "#F59E0B", d: "M12 3c3 4 6 7 6 11a6 6 0 01-12 0c0-4 3-7 6-11z" },
  generic: { c: "#A8A29E", d: "M12 8v8M8 12h8" },
};

function FoodIcon({ cat }) {
  const k = CATS[cat] || CATS.generic;
  return (
    <span style={{ width: 36, height: 36, borderRadius: 12, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: `${k.c}26`, color: k.c }}>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={k.d} /></svg>
    </span>
  );
}

const THEMES = {
  dark: {
    page: "#0B0B0C", sheet: "#0D0D0E", text: "#fff", muted: "#A1A1AA", "--ph": "#71717A",
    card: { background: "#1A1A1C", border: "1px solid rgba(255,255,255,0.05)" },
    chip: { background: "#1C1C1F", color: "#F4F4F5" },
    soft: { background: "rgba(255,255,255,0.10)", color: "#F4F4F5" },
    track: "rgba(255,255,255,0.12)",
    input: { background: "#1C1C1F", border: "1px solid rgba(255,255,255,0.14)", color: "#fff" },
    hero: "radial-gradient(ellipse 80% 55% at 50% 62%, rgba(249,115,22,0.38), transparent 70%), radial-gradient(ellipse 60% 40% at 15% 10%, rgba(120,70,40,0.55), transparent 70%), linear-gradient(180deg,#2A1B12,#141011)",
    heroText: "#fff",
    heroBtn: { background: "rgba(255,255,255,0.16)", color: "#fff" },
    heroChip: { background: "rgba(255,255,255,0.14)", color: "#fff" },
  },
  light: {
    page: "#FFF6EA", sheet: "#FFF6EA", text: "#2A1A0E", muted: "#7C6250", "--ph": "#9A806C",
    card: { background: "#FFFFFF", border: "1px solid #FFE0C2" },
    chip: { background: "#FFFFFF", color: "#2A1A0E", border: "1px solid #FFE0C2" },
    soft: { background: "#FFE9D3", color: "#7A3E10" },
    track: "#FFE5CC",
    input: { background: "#fff", border: "1px solid #FDBA74", color: "#2A1A0E" },
    hero: "radial-gradient(ellipse 80% 55% at 50% 62%, rgba(249,115,22,0.35), transparent 70%), linear-gradient(180deg,#FFD9B3,#FFEBD6)",
    heroText: "#2A1A0E",
    heroBtn: { background: "rgba(255,255,255,0.7)", color: "#2A1A0E" },
    heroChip: { background: "rgba(255,255,255,0.7)", color: "#7A3E10" },
  },
};

const PATHS = {
  back: "M15 18l-6-6 6-6",
  sparkle: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z",
  flame: "M12 3c1 3 4 4.5 4 8.5a4 4 0 01-8 0c0-1.5.6-2.6 1.5-3.5.2 1.2.8 1.8 1.5 2 0-2.5-.3-4.5 1-7z",
  plus: "M12 5v14M5 12h14",
  minus: "M5 12h14",
  trash: "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3",
  sun: "M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4",
  moon: "M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z",
  heart: "M12 20s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.6-7 10-7 10z",
  check: "M5 12.5l4.5 4.5L19 7.5",
  scan: "M3 8V5a2 2 0 012-2h3M16 3h3a2 2 0 012 2v3M21 16v3a2 2 0 01-2 2h-3M8 21H5a2 2 0 01-2-2v-3",
};

function Icon({ n, size = 20, sw = 2, fill = "none" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={PATHS[n]} />
    </svg>
  );
}

const mealByHour = (h = new Date().getHours()) => (h < 11 ? "Breakfast" : h < 16 ? "Lunch" : h < 21 ? "Dinner" : "Snack");

function Plate({ viewBox = "0 0 360 224", fit = "xMidYMid meet", style }) {
  return (
    <svg viewBox={viewBox} preserveAspectRatio={fit} style={{ display: "block", width: "100%", height: "100%", ...style }} role="img" aria-label="Plate with chicken, brown rice and vegetables">
      <ellipse cx="180" cy="196" rx="132" ry="14" fill="rgba(0,0,0,0.25)" />
      <ellipse cx="180" cy="124" rx="150" ry="82" fill="#F6EFE4" />
      <ellipse cx="180" cy="124" rx="120" ry="62" fill="#FFFAF2" stroke="#E8DAC6" strokeWidth="2" />
      <g transform="rotate(-14 125 120)">
        <rect x="80" y="96" width="92" height="30" rx="15" fill="#C98B4E" />
        <rect x="86" y="122" width="86" height="28" rx="14" fill="#D9A06A" />
        <path d="M96 108h60M100 136h56" stroke="#8A5524" strokeWidth="3" strokeLinecap="round" opacity=".55" />
      </g>
      <ellipse cx="250" cy="132" rx="46" ry="30" fill="#E9D5B1" />
      <g fill="#C9A978">
        <circle cx="232" cy="124" r="3" /><circle cx="248" cy="120" r="3" /><circle cx="262" cy="130" r="3" />
        <circle cx="240" cy="140" r="3" /><circle cx="258" cy="144" r="3" /><circle cx="272" cy="122" r="3" />
      </g>
      <circle cx="182" cy="76" r="17" fill="#2E8B57" /><circle cx="204" cy="86" r="13" fill="#3FA566" />
      <circle cx="166" cy="92" r="12" fill="#256F46" /><circle cx="216" cy="70" r="11" fill="#F97316" />
      <path d="M170 160c14 8 34 8 48 0" stroke="#E0A526" strokeWidth="5" strokeLinecap="round" fill="none" opacity=".85" />
    </svg>
  );
}

export default function CalSenScanResult({
  photo = "",
  initialMeal,
  dishName,
  initialItems,
  dark: propDark,
  onToggleDark,
  onRetake,
  onClose,
  onLogComplete,
  onNavigate,
}) {
  const [dark, setDark] = useState(() => {
    if (typeof propDark === "boolean") return propDark;
    try {
      const v = window.localStorage.getItem('plateful-theme');
      if (v === 'dark') return true;
      if (v === 'light') return false;
      if (v === 'auto') return window.matchMedia?.('(prefers-color-scheme: dark)').matches || false;
    } catch (e) {}
    return false;
  });

  useEffect(() => {
    if (typeof propDark === "boolean") {
      setDark(propDark);
    }
  }, [propDark]);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    try {
      window.localStorage.setItem('plateful-theme', next ? 'dark' : 'light');
    } catch (e) {}
    if (onToggleDark) onToggleDark(next);
  };

  const [meal, setMeal] = useState(() => {
    if (initialMeal) {
      const found = MEALS.find((m) => m.toLowerCase().startsWith(String(initialMeal).toLowerCase().slice(0, 4)));
      if (found) return found;
    }
    return mealByHour();
  });

  const [items, setItems] = useState(() => (Array.isArray(initialItems) && initialItems.length > 0 ? initialItems : SEED));
  const [showTags, setShowTags] = useState(true);
  const [active, setActive] = useState(null);
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ name: "", amount: "", food: null });
  const [logged, setLogged] = useState(false);
  const [fav, setFav] = useState(false);
  const t = THEMES[dark ? "dark" : "light"];

  const dishTitle = dishName || DEFAULT_DISH;
  const activeHeroImage = photo || defaultBowlImg;

  const rows = useMemo(
    () => items.map((i) => ({ ...i, kcal: (i.amount * i.k) / 100, prot: (i.amount * i.p) / 100, carb: (i.amount * i.c) / 100, fat: (i.amount * i.f) / 100 })),
    [items]
  );
  const total = useMemo(
    () => rows.reduce((s, r) => ({ kcal: s.kcal + r.kcal, p: s.p + r.prot, c: s.c + r.carb, f: s.f + r.fat }), { kcal: 0, p: 0, c: 0, f: 0 }),
    [rows]
  );
  const kcal = Math.round(total.kcal);
  const pct = Math.round((total.p / PROTEIN_GOAL) * 100);
  const macros = [
    { label: "Protein", v: total.p, color: "#F97316" },
    { label: "Carbs", v: total.c, color: "#FBBF24" },
    { label: "Fat", v: total.f, color: "#C2410C" },
  ];

  // add-item form: autocomplete + automatic nutrition
  const q = draft.name.trim().toLowerCase();
  const exact = FOODS.find((f) => f.name.toLowerCase() === q) || null;
  const picked = draft.food || exact;
  const suggestions = !draft.food && q ? searchFoods(q) : [];
  const unknown = !!q && !picked && suggestions.length === 0;
  const grams = Number(draft.amount);
  const preview = grams > 0 ? estimate(picked || (q ? GENERIC : null), grams) : null;
  const canAdd = !!q && grams > 0;

  const step = (id, d) =>
    setItems((xs) => xs.map((x) => (x.id === id ? { ...x, amount: Math.max(5, x.amount + d * (x.unit === "ml" ? 5 : 10)) } : x)));
  const remove = (id) => setItems((xs) => xs.filter((x) => x.id !== id));
  const addItem = () => {
    if (!canAdd) return;
    const food = picked || GENERIC;
    const name = picked ? picked.name : draft.name.trim();
    setItems((xs) => [
      ...xs,
      { id: Date.now(), name, short: name, unit: food.defaultUnit, amount: grams, k: food.caloriesPer100g, p: food.proteinPer100g, c: food.carbsPer100g, f: food.fatPer100g, est: !picked, tag: null },
    ]);
    setDraft({ name: "", amount: "", food: null });
    setAdding(false);
  };

  const handleBack = () => {
    if (onRetake) onRetake();
    else if (onClose) onClose();
    else if (onNavigate) onNavigate('scanner');
    else if (typeof window !== 'undefined' && window.history) window.history.back();
  };

  const handleLog = () => {
    if (logged) return;
    setLogged(true);

    const mealIdx = MEALS.indexOf(meal);
    const entry = {
      id: Date.now(),
      date: '2026-10-09',
      meal: mealIdx >= 0 ? mealIdx : 1,
      name: dishTitle,
      n: rows.length,
      kcal,
      p: Math.round(total.p),
      c: Math.round(total.c),
      f: Math.round(total.f),
      thumb: activeHeroImage || '',
      items: rows.map(r => ({ name: r.name, grams: r.amount, kcal: Math.round(r.kcal) }))
    };

    try {
      const cur = JSON.parse(window.localStorage.getItem('calsen-log') || '[]');
      cur.unshift(entry);
      window.localStorage.setItem('calsen-log', JSON.stringify(cur));
      const todayISO = new Date().toISOString().split('T')[0];
      if (todayISO !== '2026-10-09') {
        const liveEntry = { ...entry, date: todayISO, id: Date.now() + 1 };
        cur.unshift(liveEntry);
        window.localStorage.setItem('calsen-log', JSON.stringify(cur));
      }
    } catch (e) {}

    try {
      saveMealToFirestore({
        name: dishTitle,
        meal: mealIdx >= 0 ? mealIdx : 1,
        kcal,
        p: Math.round(total.p),
        c: Math.round(total.c),
        f: Math.round(total.f),
        thumb: activeHeroImage || '',
      }).catch(() => {});
    } catch (e) {}

    setTimeout(() => {
      if (onLogComplete) onLogComplete();
      else if (onClose) onClose();
      else if (onNavigate) onNavigate('home');
    }, 900);
  };

  const round = { width: 48, height: 48, borderRadius: 24, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, border: "none" };
  const small = { width: 44, height: 44, borderRadius: 22, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, border: "none" };
  const field = { ...t.input, height: 52, borderRadius: 26, padding: "0 20px", fontSize: 16, fontWeight: 600, fontFamily: "inherit", minWidth: 0 };
  const h2 = { margin: 0, fontSize: 24, fontWeight: 700 };

  return (
    <div style={{ background: t.page, color: t.text, "--ph": t["--ph"], minHeight: "100vh", width: "100%", fontFamily: "Urbanist, system-ui, sans-serif", transition: "background .3s, color .3s" }}>
      <style>{CSS}</style>
      <div style={{ position: "relative", margin: "0 auto", width: "100%", maxWidth: 420, minHeight: "100vh", overflow: "hidden" }}>

        {/* Hero */}
        <div style={{ position: "relative", height: 440, background: t.hero, color: t.heroText }}>
          {activeHeroImage && <img src={activeHeroImage} alt="Scanned meal" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />}

          {/* plate (or photo) tag layer */}
          <div style={{ position: "absolute", left: "6%", right: "6%", top: 150, aspectRatio: "360 / 224" }}>
            {!activeHeroImage && <Plate />}
            {showTags &&
              rows.filter((r) => r.tag).map((r) => (
                <button
                  key={r.id}
                  onClick={() => setActive(active === r.id ? null : r.id)}
                  className="cs-btn text-xs font-bold"
                  style={{
                    position: "absolute", left: `${r.tag.x}%`, top: `${r.tag.y}%`, transform: "translate(-50%,-50%)",
                    borderRadius: 14, padding: "6px 10px", whiteSpace: "nowrap", color: "#fff",
                    border: `2px solid ${active === r.id ? "#fff" : "#F97316"}`,
                    background: active === r.id ? "#EA580C" : "rgba(20,12,6,0.72)", ...BLUR,
                  }}
                >
                  {r.short} · {Math.round(r.kcal)}
                </button>
              ))}
          </div>

          {/* top bar */}
          <div style={{ position: "absolute", top: 20, left: 20, right: 20, display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="flex items-center justify-between">
              <button onClick={handleBack} className="cs-btn" style={{ ...round, ...t.heroBtn, ...BLUR }} aria-label="Retake photo"><Icon n="back" size={22} sw={2.4} /></button>
              <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Scan Result</h1>
              <button onClick={toggleTheme} className="cs-btn" style={{ ...round, ...t.heroBtn, ...BLUR }} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}>
                <Icon n={dark ? "sun" : "moon"} />
              </button>
            </div>
            <div className="flex gap-2" role="radiogroup" aria-label="Meal time" style={{ overflowX: "auto", margin: "0 -20px", padding: "0 20px" }}>
              {MEALS.map((m) => (
                <button
                  key={m} role="radio" aria-checked={meal === m} onClick={() => setMeal(m)}
                  className="cs-btn text-sm font-bold"
                  style={{ flexShrink: 0, height: 44, padding: "0 20px", borderRadius: 22, border: "none", ...(meal === m ? GRAD : { ...t.heroChip, ...BLUR }) }}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* confidence + tag toggle */}
          <div style={{ position: "absolute", left: 20, right: 20, bottom: 68, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span className="text-sm font-bold" style={{ ...GRAD, display: "flex", alignItems: "center", gap: 6, height: 40, padding: "0 14px", borderRadius: 20 }}>
              <Icon n="sparkle" size={16} fill="currentColor" sw={1.2} /> AI Confidence: 96%
            </span>
            <button onClick={() => setShowTags(!showTags)} aria-pressed={showTags} aria-label="Toggle ingredient tags" className="cs-btn" style={{ ...round, ...(showTags ? GRAD : { ...t.heroBtn, ...BLUR }) }}>
              <Icon n="scan" />
            </button>
          </div>
        </div>

        {/* Sheet */}
        <div className="flex flex-col gap-6" style={{ position: "relative", marginTop: -48, background: t.sheet, borderRadius: "44px 44px 0 0", padding: "12px 20px 170px", transition: "background .3s" }}>

          {/* capsule summary card */}
          <section style={{ ...t.card, borderRadius: 48, padding: 12, display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ width: 104, height: 104, borderRadius: 52, overflow: "hidden", flexShrink: 0, background: t.hero }}>
              {activeHeroImage ? <img src={activeHeroImage} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <Plate viewBox="50 30 260 180" fit="xMidYMid slice" />}
            </div>
            <div style={{ minWidth: 0, display: "flex", flexDirection: "column", gap: 6 }}>
              <h2 style={{ margin: 0, fontSize: 26, fontWeight: 700, lineHeight: 1.1 }}>{dishTitle}</h2>
              <div className="flex items-end gap-1" style={{ color: "#F97316" }}>
                <Icon n="flame" size={26} fill="currentColor" sw={1} />
                <span aria-live="polite" style={{ fontSize: 34, fontWeight: 700, lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{kcal}</span>
                <span style={{ fontSize: 15, fontWeight: 600, color: t.muted, paddingBottom: 3 }}>kcal</span>
              </div>
              <span style={{ fontSize: 14, fontWeight: 500, color: t.muted }}>{rows.length} items detected · {meal}</span>
            </div>
          </section>

          {/* insight */}
          <section className="flex flex-col gap-2">
            <h2 style={h2}>Nutrition insight</h2>
            <p style={{ margin: 0, fontSize: 15, lineHeight: 1.65, fontWeight: 500, color: t.muted }}>
              {pct >= 30
                ? `Great pick. This meal covers ${pct}% of your daily protein target, which is what your muscles need to recover and grow.`
                : `This plate covers ${pct}% of your daily protein target. Add a protein source if you want to reach it today.`}
            </p>
          </section>

          {/* macro chips */}
          <div className="grid grid-cols-3 gap-2">
            {macros.map((m) => (
              <div key={m.label} style={{ ...t.chip, height: 52, borderRadius: 26, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, fontSize: 15, fontWeight: 600 }}>
                <span style={{ width: 8, height: 8, borderRadius: 4, background: m.color }} />
                <span style={{ color: t.muted }}>{m.label}</span>
                <span style={{ fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{Math.round(m.v)}g</span>
              </div>
            ))}
          </div>

          {/* items */}
          <section className="flex flex-col gap-3">
            <h2 style={h2}>What the AI found</h2>
            {rows.map((r) => (
              <div key={r.id} className="flex flex-col gap-3" style={{ ...t.card, borderRadius: 32, padding: 16, ...(active === r.id ? { boxShadow: "0 0 0 2px #F97316" } : {}) }}>
                <div className="flex items-baseline justify-between gap-3">
                  <span style={{ fontWeight: 700, fontSize: 17 }}>{r.name}{r.est && <span style={{ ...t.soft, marginLeft: 8, fontSize: 12, fontWeight: 700, padding: "2px 8px", borderRadius: 10, whiteSpace: "nowrap" }}>avg. values</span>}</span>
                  <span style={{ color: "#F97316", fontWeight: 700, whiteSpace: "nowrap", fontVariantNumeric: "tabular-nums" }}>{Math.round(r.kcal)} kcal</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button onClick={() => step(r.id, -1)} className="cs-btn" style={{ ...small, ...t.soft }} aria-label={`Decrease ${r.name}`}><Icon n="minus" /></button>
                    <span style={{ width: 64, textAlign: "center", fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{r.amount}{r.unit}</span>
                    <button onClick={() => step(r.id, 1)} className="cs-btn" style={{ ...small, ...GRAD }} aria-label={`Increase ${r.name}`}><Icon n="plus" /></button>
                  </div>
                  <button onClick={() => remove(r.id)} className="cs-btn" style={{ ...small, ...t.soft }} aria-label={`Remove ${r.name}`}><Icon n="trash" size={18} /></button>
                </div>
              </div>
            ))}

            {adding ? (
              <div className="flex flex-col gap-3" style={{ ...t.card, borderRadius: 32, padding: 16 }}>
                <div className="flex flex-col gap-2">
                  <input className="cs-in" aria-label="Item name" role="combobox" aria-expanded={suggestions.length > 0} aria-controls="food-list" autoComplete="off" placeholder="Item name (e.g. Salmon)" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value, food: null })} style={field} />
                  {suggestions.length > 0 && (
                    <div id="food-list" role="listbox" style={{ ...t.input, borderRadius: 24, padding: 6, display: "flex", flexDirection: "column", gap: 2 }}>
                      {suggestions.map((f) => (
                        <button key={f.id} role="option" aria-selected="false" onClick={() => setDraft({ ...draft, name: f.name, food: f })} className="cs-btn" style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", minHeight: 52, padding: "6px 10px", borderRadius: 18, border: "none", background: "transparent", color: t.text, textAlign: "left" }}>
                          <FoodIcon cat={f.cat} />
                          <span style={{ flexGrow: 1, fontWeight: 700, fontSize: 15 }}>{f.name}</span>
                          <span style={{ color: t.muted, fontSize: 13, fontWeight: 600, whiteSpace: "nowrap" }}>{f.caloriesPer100g} kcal / 100g</span>
                        </button>
                      ))}
                    </div>
                  )}
                  {unknown && (
                    <div className="flex items-center gap-3" style={{ padding: "4px 6px", color: t.muted, fontSize: 13, fontWeight: 500, lineHeight: 1.4 }}>
                      <FoodIcon cat="generic" />
                      <span>Not in our list. We will use average values (about 150 kcal per 100g). Fine-tune the amount with +/− after adding.</span>
                    </div>
                  )}
                </div>
                <input className="cs-in" aria-label="Amount in grams" inputMode="numeric" placeholder="Grams" value={draft.amount} onChange={(e) => setDraft({ ...draft, amount: e.target.value.replace(/[^0-9]/g, "") })} style={field} />
                {preview && (
                  <div aria-live="polite" style={{ background: "rgba(249,115,22,0.14)", color: dark ? "#FDBA74" : "#C2410C", borderRadius: 20, padding: "10px 16px", fontSize: 14, fontWeight: 700 }}>
                    Estimated: {preview.kcal} kcal
                    <span style={{ fontWeight: 600 }}> · P {preview.p}g · C {preview.c}g · F {preview.f}g</span>
                  </div>
                )}
                <div className="flex gap-3">
                  <button onClick={() => setAdding(false)} className="cs-btn" style={{ ...t.soft, flex: 1, height: 52, borderRadius: 26, border: "none", fontSize: 16, fontWeight: 700 }}>Cancel</button>
                  <button onClick={addItem} disabled={!canAdd} className="cs-btn" style={{ opacity: canAdd ? 1 : 0.5, ...GRAD, flex: 1, height: 52, borderRadius: 26, border: "none", fontSize: 16, fontWeight: 700 }}>Add item</button>
                </div>
              </div>
            ) : (
              <button onClick={() => setAdding(true)} className="cs-btn flex items-center justify-center gap-2" style={{ height: 56, borderRadius: 28, background: "transparent", border: "2px dashed rgba(249,115,22,0.65)", color: "#F97316", fontSize: 16, fontWeight: 700 }}>
                <Icon n="plus" size={18} sw={2.6} /> Add missing item
              </button>
            )}
          </section>
        </div>

        {/* Bottom action bar */}
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 10, pointerEvents: "none" }}>
          <div className="flex gap-3" style={{ margin: "0 auto", maxWidth: 420, padding: "28px 20px 24px", background: `linear-gradient(to top, ${t.sheet} 65%, transparent)`, pointerEvents: "auto" }}>
            <button onClick={() => setFav(!fav)} aria-pressed={fav} className="cs-btn flex items-center justify-center gap-2" style={{ ...t.card, color: fav ? "#F97316" : t.text, flex: 1, height: 64, borderRadius: 32, fontSize: 16, fontWeight: 700 }}>
              <Icon n="heart" size={18} fill={fav ? "currentColor" : "none"} /> {fav ? "Saved" : "Save recipe"}
            </button>
            <button onClick={handleLog} className="cs-btn flex items-center justify-center gap-2" style={{ ...GRAD, flex: 1.5, height: 64, borderRadius: 32, border: "none", fontSize: 17, fontWeight: 700, boxShadow: "0 10px 28px rgba(234,88,12,0.4)" }}>
              {logged ? (<><Icon n="check" sw={3} /> Logged</>) : `Log Meal • ${kcal}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
