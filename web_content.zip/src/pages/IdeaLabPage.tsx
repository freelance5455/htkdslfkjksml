import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import { useIdeas } from "@/hooks/useIdeas";
import { cn, formatDate } from "@/lib/utils";
import { generateIdeasWithGemini } from "@/lib/gemini";
import type { Idea } from "@/types";
import { Lightbulb, Plus, Trash2, Edit3, ArrowRight, Sparkles, X, Check, Loader2, Bot } from "lucide-react";

export default function IdeaLabPage() {
  const navigate = useNavigate();
  const { ideas, addIdea, updateIdea, deleteIdea } = useIdeas();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  const handleSave = () => {
    if (!title.trim()) return;
    const tagList = tags.split(",").map((t) => t.trim()).filter(Boolean);
    if (editingId) {
      const idea = ideas.find((i) => i.id === editingId);
      if (idea) updateIdea({ ...idea, title, description, tags: tagList });
      setEditingId(null);
    } else {
      addIdea(title, description, tagList);
    }
    setTitle(""); setDescription(""); setTags("");
    setShowForm(false);
  };

  const handleEdit = (idea: Idea) => {
    setTitle(idea.title);
    setDescription(idea.description);
    setTags(idea.tags.join(", "));
    setEditingId(idea.id);
    setShowForm(true);
  };

  const handleConvert = (idea: Idea) => {
    navigate(`/creator?q=${encodeURIComponent(idea.title + ". " + idea.description)}`);
  };

  const generateIdeas = async () => {
    setGenerating(true);
    try {
      const aiIdeas = await generateIdeasWithGemini("Ideias virais para YouTube, Shorts e TikTok", "MULTI_PLATFORM", 4);
      if (aiIdeas && aiIdeas.length > 0) {
        aiIdeas.forEach((s) => addIdea(s.title, s.description, [...(s.tags || []), "gemini-3.7-flash"]));
      } else {
        const suggested = [
          { title: "Vídeo: 10 Curiosidades Sobre o Espaço e o Universo", description: "Conteúdo educativo e visual sobre astronomia e buracos negros para jovens." },
          { title: "Short: Dicas de Produtividade em 60s com IA", description: "Técnicas rápidas de organização e automação para criadores." },
          { title: "Reel: Receitas Rápidas em 30 Segundos", description: "Culinária prática e visual com cortes dinâmicos para Instagram." },
          { title: "Música: ABC do Alfabeto dos Animais", description: "Canção infantil educativa com animação 3D colorida." },
        ];
        suggested.forEach((s) => addIdea(s.title, s.description, ["gerado-por-ia"]));
      }
    } finally {
      setGenerating(false);
    }
  };

  return (
    <AppLayout title="Ideas Lab" subtitle="Capture e organize suas ideias de conteúdo">
      <div className="p-6 space-y-5 max-w-5xl">

        {/* Toolbar */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => { setShowForm(true); setEditingId(null); setTitle(""); setDescription(""); setTags(""); }}
            className="btn-primary text-sm"
          >
            <Plus className="w-4 h-4" /> Nova Ideia
          </button>
          <button onClick={generateIdeas} disabled={generating} className="btn-secondary text-sm">
            {generating ? (
              <><Loader2 className="w-4 h-4 animate-spin text-studio-blue" /> Gerando com Gemini...</>
            ) : (
              <><Sparkles className="w-4 h-4" /> Gerar Ideias com Gemini</>
            )}
          </button>
          <span className="text-sm text-studio-text-muted ml-auto">{ideas.length} ideia{ideas.length !== 1 ? "s" : ""}</span>
        </div>

        {/* Add/Edit form */}
        {showForm && (
          <div className="studio-panel p-5 border border-studio-blue/20 animate-fade-in">
            <h3 className="text-sm font-bold text-studio-text font-display mb-4">
              {editingId ? "Editar Ideia" : "Nova Ideia"}
            </h3>
            <div className="space-y-3">
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Título da ideia..."
                className="studio-input text-sm"
                autoFocus
              />
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrição e detalhes..."
                className="studio-input text-sm resize-none h-20"
              />
              <input
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="Tags (separadas por vírgula): youtube, infantil, educativo"
                className="studio-input text-sm"
              />
              <div className="flex gap-2">
                <button onClick={handleSave} disabled={!title.trim()} className="btn-primary text-sm py-2 px-4">
                  <Check className="w-4 h-4" /> Salvar
                </button>
                <button onClick={() => setShowForm(false)} className="btn-secondary text-sm py-2 px-4">
                  <X className="w-4 h-4" /> Cancelar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Ideas grid */}
        {ideas.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 studio-card text-center">
            <Lightbulb className="w-12 h-12 text-studio-purple mb-4" />
            <h3 className="text-base font-semibold text-studio-text font-display mb-2">Ideas Lab vazio</h3>
            <p className="text-sm text-studio-text-muted mb-6">Capture suas ideias antes que passem</p>
            <button onClick={() => setShowForm(true)} className="btn-primary text-sm">
              <Plus className="w-4 h-4" /> Adicionar Primeira Ideia
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {ideas.map((idea) => (
              <div key={idea.id} className="studio-card p-4 group hover:border-studio-purple/30 transition-all flex flex-col">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h4 className="text-sm font-bold text-studio-text leading-tight line-clamp-2 flex-1">{idea.title}</h4>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                    <button onClick={() => handleEdit(idea)} className="p-1.5 rounded-lg hover:bg-studio-panel text-studio-text-muted hover:text-studio-blue transition-all">
                      <Edit3 className="w-3 h-3" />
                    </button>
                    <button onClick={() => deleteIdea(idea.id)} className="p-1.5 rounded-lg hover:bg-studio-red/10 text-studio-text-muted hover:text-studio-red transition-all">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {idea.description && (
                  <p className="text-xs text-studio-text-dim leading-relaxed line-clamp-3 mb-3 flex-1">{idea.description}</p>
                )}

                {idea.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {idea.tags.map((tag) => (
                      <span key={tag} className="task-badge text-xs bg-studio-purple/10 text-studio-purple border border-studio-purple/20">{tag}</span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-studio-border mt-auto">
                  <span className="text-xs text-studio-text-muted">{formatDate(idea.createdAt)}</span>
                  <button
                    onClick={() => handleConvert(idea)}
                    className="flex items-center gap-1 text-xs text-studio-blue hover:underline"
                  >
                    Criar projeto <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
