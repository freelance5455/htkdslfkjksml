import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getFormulaById } from '../firebase/services';
import { Formula } from '../types';
import { DynamicCalculator } from '../components/calculator/DynamicCalculator';
import { ShareModal } from '../components/formula/ShareModal';
import { CardSkeleton } from '../components/common/SkeletonLoader';
import {
  ArrowLeft,
  Bookmark,
  Copy,
  Check,
  Share2,
  Calculator,
  Sparkles,
  Layers,
  HelpCircle,
  BookOpen
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const FormulaDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { isFavorite, toggleFavorite, showToast, playSound, triggerHaptic } = useApp();

  const [formula, setFormula] = useState<Formula | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  useEffect(() => {
    async function load() {
      if (!id) return;
      try {
        const f = await getFormulaById(id);
        setFormula(f);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  const isFav = formula ? isFavorite(formula.id) : false;

  const handleToggleFav = () => {
    if (!formula) return;
    const nextState = toggleFavorite(formula.id);
    showToast(nextState ? 'Saved to favorites' : 'Removed from favorites');
  };

  const copyFormulaText = async () => {
    if (!formula) return;
    try {
      await navigator.clipboard.writeText(`${formula.title}: ${formula.formula}`);
      playSound('copy');
      triggerHaptic('light');
      setCopied(true);
      showToast('Formula copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('Failed to copy', 'error');
    }
  };

  if (loading) {
    return (
      <div className="space-y-6 max-w-4xl mx-auto">
        <div className="h-8 bg-[#1C1C1C] rounded-xl w-1/4 animate-pulse" />
        <CardSkeleton />
      </div>
    );
  }

  if (!formula) {
    return (
      <div className="text-center py-16 space-y-4 max-w-lg mx-auto">
        <h2 className="text-xl font-bold text-[#F5F2ED]">Formula Not Found</h2>
        <p className="text-[#A9A39C] text-xs">
          The requested formula specification could not be located.
        </p>
        <Link
          to="/formulas"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#D65A1F] text-[#F5F2ED] text-xs font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Formula Library</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      {/* Back button & Action Header */}
      <div className="flex items-center justify-between">
        <Link
          to="/formulas"
          onClick={() => playSound('tab')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#A9A39C] hover:text-[#F5F2ED] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Formula Library</span>
        </Link>

        <div className="flex items-center gap-2">
          <button
            onClick={copyFormulaText}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1C1C1C] hover:bg-[#232323] text-[#F5F2ED] text-xs font-medium border border-[#303030] transition-colors"
            title="Copy Formula"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#72A65A]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            onClick={() => {
              playSound('button');
              setShareOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1C1C1C] hover:bg-[#232323] text-[#F5F2ED] text-xs font-medium border border-[#303030] transition-colors"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share</span>
          </button>

          <button
            onClick={handleToggleFav}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
              isFav
                ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F]'
                : 'bg-[#1C1C1C] text-[#A9A39C] hover:text-[#F5F2ED] border-[#303030]'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" fill={isFav ? '#D65A1F' : 'none'} />
            <span>{isFav ? 'Saved' : 'Favorite'}</span>
          </button>
        </div>
      </div>

      {/* Main Formula Header & Math Display */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#1C1C1C] border border-[#303030] space-y-4 shadow-xl">
        <div className="flex items-center gap-2 flex-wrap">
          <Link
            to={`/category/${formula.category.toLowerCase()}`}
            className="text-[11px] font-mono uppercase tracking-wider font-semibold text-[#D65A1F] bg-[#232323] border border-[#303030] px-2.5 py-0.5 rounded-md hover:border-[#D65A1F] transition-colors"
          >
            {formula.category}
          </Link>
          <span className="text-xs font-mono text-[#A9A39C]">
            {formula.subcategory}
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#232323] text-[#A9A39C] border border-[#303030]">
            {formula.difficulty}
          </span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-[#F5F2ED] tracking-tight">
          {formula.title}
        </h1>

        <p className="text-sm sm:text-base text-[#A9A39C] max-w-3xl leading-relaxed">
          {formula.description}
        </p>

        {/* Large Math Display Box */}
        <div className="p-6 rounded-2xl bg-[#151515] border border-[#303030] text-center font-mono my-4">
          <div className="text-2xl sm:text-4xl font-extrabold text-[#D65A1F] tracking-wider">
            {formula.formula}
          </div>
          <p className="text-xs text-[#A9A39C] font-sans mt-2">
            Result variable: <span className="font-mono text-[#F5F2ED] font-bold">{formula.resultVariable}</span> ({formula.resultUnit})
          </p>
        </div>

        {/* Tags */}
        {formula.tags && formula.tags.length > 0 && (
          <div className="flex items-center gap-1.5 flex-wrap pt-2">
            <span className="text-xs text-[#A9A39C]">Tags:</span>
            {formula.tags.map((tag) => (
              <span
                key={tag}
                className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-[#151515] text-[#A9A39C] border border-[#303030]"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Variables & Units Grid & Example */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Variables List */}
        <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#303030] space-y-4 shadow-xl">
          <div className="flex items-center gap-2 pb-2 border-b border-[#303030]">
            <Layers className="w-4 h-4 text-[#D65A1F]" />
            <h3 className="text-sm font-bold text-[#F5F2ED] uppercase tracking-wider font-mono">
              Variables & Definitions
            </h3>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {formula.variables.map((v) => (
              <div
                key={v.symbol}
                className="p-3 rounded-xl bg-[#151515] border border-[#303030] flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-[#D65A1F] text-sm">{v.symbol}</span>
                  <span className="text-[#F5F2ED] font-sans ml-2 font-medium">{v.name}</span>
                </div>
                <div className="px-2 py-1 rounded bg-[#232323] border border-[#303030] text-[#A9A39C] text-[11px]">
                  Unit: {v.unit || 'dimensionless'}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Units & Example Scenario */}
        <div className="p-6 rounded-3xl bg-[#1C1C1C] border border-[#303030] space-y-4 shadow-xl">
          <div className="flex items-center gap-2 pb-2 border-b border-[#303030]">
            <Sparkles className="w-4 h-4 text-[#D65A1F]" />
            <h3 className="text-sm font-bold text-[#F5F2ED] uppercase tracking-wider font-mono">
              Units & Practical Scenario
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            {formula.units && formula.units.length > 0 && (
              <div className="p-3.5 rounded-xl bg-[#151515] border border-[#303030] space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#A9A39C] font-bold block">
                  SI Units Standard
                </span>
                <ul className="space-y-1 font-mono text-[#F5F2ED]">
                  {formula.units.map((u, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#D65A1F]" />
                      <span>{u}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {formula.example && (
              <div className="p-3.5 rounded-xl bg-[#232323] border border-[#303030] space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#D65A1F] font-bold block">
                  Worked Example Scenario
                </span>
                <p className="text-xs text-[#F5F2ED] font-mono leading-relaxed">
                  {formula.example}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Embedded Dynamic Calculator */}
      <section className="space-y-4 pt-4">
        <div className="flex items-center gap-2">
          <Calculator className="w-5 h-5 text-[#D65A1F]" />
          <h2 className="text-xl font-bold text-[#F5F2ED] tracking-tight">
            Interactive Calculator Engine
          </h2>
        </div>
        <DynamicCalculator formula={formula} />
      </section>

      <ShareModal
        isOpen={shareOpen}
        onClose={() => setShareOpen(false)}
        title={formula.title}
        formulaText={formula.formula}
        url={window.location.href}
      />
    </div>
  );
};
