import { useState } from 'react';
import { CalendarDays, Check, Plus, Printer, RefreshCw, Trash2 } from 'lucide-react';
import { subjects } from '../data/content';
import { useProfile } from '../hooks/useProfile';
import { useToast } from '../hooks/useToast';
import { useStored, KEYS } from '../services/storage';
import {
  WEEK_DAYS,
  addSession,
  daysUntilExam,
  generatePlan,
  getPlan,
  removeSession,
  toggleSession,
} from '../services/plan';
import { PageHeader } from '../components/layout/PageHeader';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Feedback';
import { ProgressBar, SectionHeader } from '../components/ui/Card';
import { cn, formatDate, formatMinutes } from '../utils/format';

export default function Plan() {
  const { profile } = useProfile();
  const { toast } = useToast();
  useStored(KEYS.plan, { generatedAt: 0, hoursPerDay: 3, sessions: [] });
  const [hours, setHours] = useState(3);
  const [addDay, setAddDay] = useState<number | null>(null);
  const [newSubject, setNewSubject] = useState(subjects[0]?.id ?? 'math');
  const [newMinutes, setNewMinutes] = useState(45);

  const plan = getPlan();
  const today = new Date().getDay();
  const days = daysUntilExam(profile.examDate);
  const totalAvg = plan.sessions.length > 0 ? plan.sessions.reduce((s, x) => s + x.minutes, 0) : 0;
  const doneCount = plan.sessions.filter((s) => s.done).length;

  const create = () => {
    generatePlan(hours);
    toast('أُنشئت خطتك الأسبوعية ويمكنك تعديلها', 'success');
  };

  return (
    <div className="print-area">
      <PageHeader
        eyebrow={`${days} يوماً حتى الامتحان`}
        title="جدول الدراسة"
        subtitle="خطة أسبوعية تُبنى من تاريخ امتحانك، وأوزان المواد، وما أنجزته فعلاً. عدّلها كما تشاء."
        back="/"
        action={<Button className="no-print min-h-11" size="sm" variant="outline" icon={<Printer size={15} />} onClick={() => window.print()}>طباعة الجدول</Button>}
      />

      {plan.sessions.length === 0 ? (
        <div className="card p-5">
          <p className="font-display text-base text-[var(--ink)]">كم ساعة تستطيع الدراسة يومياً؟</p>
          <p className="mt-1 text-[0.78rem] leading-relaxed text-[var(--ink-soft)]">
            كن واقعياً: البقاء على الخطة أهم من طموحها. يمكنك تغييرها لاحقاً.
          </p>
          <div className="mt-4 flex items-center gap-3">
            <input
              type="range"
              min={1}
              max={8}
              step={0.5}
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
              aria-label="عدد ساعات الدراسة اليومية"
              className="h-2 flex-1 cursor-pointer appearance-none rounded-full bg-[var(--surface-2)] accent-[var(--gold)]"
            />
            <span className="w-16 text-center font-display text-lg text-[var(--ink)]">{hours} س</span>
          </div>
          <Button block className="mt-4" variant="gold" icon={<CalendarDays size={16} />} onClick={create}>
            أنشئ خطتي الأسبوعية
          </Button>
          <p className="mt-3 text-center text-[0.66rem] text-[var(--ink-soft)]">
            الامتحان: {formatDate(profile.examDate)} — المواد الأقل تقدّماً تحصل على وقت أكبر.
          </p>
        </div>
      ) : (
        <>
          <div className="card mb-3 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[0.78rem] font-medium text-[var(--ink)]">
                  {doneCount} من {plan.sessions.length} حصة منجزة
                </p>
                <p className="mt-0.5 text-[0.66rem] text-[var(--ink-soft)]">
                  {formatMinutes(totalAvg)} أسبوعياً · {plan.hoursPerDay} ساعة يومياً
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  generatePlan(plan.hoursPerDay);
                  toast('أُعيد توليد الخطة حسب تقدّمك الحالي', 'info');
                }}
                aria-label="إعادة توليد الخطة"
                className="focus-ring flex h-11 items-center gap-1.5 rounded-full border border-[var(--line)] px-3 text-[0.68rem] text-[var(--ink)]"
              >
                <RefreshCw size={13} /> تحديث
              </button>
            </div>
            <ProgressBar
              className="mt-3"
              value={plan.sessions.length ? (doneCount / plan.sessions.length) * 100 : 0}
            />
          </div>

          <div className="space-y-3">
            {WEEK_DAYS.map((label, dayIndex) => {
              const sessions = plan.sessions.filter((s) => s.day === dayIndex);
              const isToday = dayIndex === today;
              return (
                <div
                  key={label}
                  className={cn('card p-3', isToday && 'ring-1 ring-[var(--gold)]')}
                >
                  <div className="mb-2 flex items-center justify-between">
                    <p className="flex items-center gap-1.5 text-[0.8rem] font-medium text-[var(--ink)]">
                      {label}
                      {isToday ? (
                        <span className="rounded-full bg-[var(--gold-soft)] px-1.5 text-[0.58rem] text-[#8a5b06] dark:text-[var(--gold)]">
                          اليوم
                        </span>
                      ) : null}
                    </p>
                    <button
                      type="button"
                      onClick={() => setAddDay(dayIndex)}
                      aria-label={`أضف حصة يوم ${label}`}
                      className="focus-ring flex h-11 w-11 items-center justify-center rounded-full text-[var(--ink-soft)] hover:bg-[var(--surface-2)]"
                    >
                      <Plus size={15} />
                    </button>
                  </div>

                  {sessions.length === 0 ? (
                    <p className="rounded-xl bg-[var(--surface-2)] px-3 py-2 text-[0.68rem] text-[var(--ink-soft)]">
                      يوم راحة — أو أضف حصة خفيفة.
                    </p>
                  ) : (
                    <div className="space-y-1.5">
                      {sessions.map((session) => {
                        const subject = subjects.find((s) => s.id === session.subjectId);
                        return (
                          <div key={session.id} className="flex items-center gap-2 rounded-xl bg-[var(--surface-2)] p-2">
                            <button
                              type="button"
                              onClick={() => toggleSession(session.id)}
                              aria-label={session.done ? 'إلغاء الإنجاز' : 'تعليم كمنجز'}
                              className={cn(
                                'focus-ring flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border',
                                session.done
                                  ? 'border-transparent bg-[var(--success)] text-white'
                                  : 'border-[var(--line)] bg-[var(--surface)] text-[var(--ink-soft)]',
                              )}
                            >
                              {session.done ? <Check size={14} /> : null}
                            </button>
                            <div className="min-w-0 flex-1">
                              <p className={cn('truncate text-[0.76rem] text-[var(--ink)]', session.done && 'line-through opacity-60')}>
                                {subject?.name ?? session.label}
                              </p>
                              <p className="text-[0.62rem] text-[var(--ink-soft)]">{session.minutes} دقيقة</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeSession(session.id)}
                              aria-label="حذف الحصة"
                              className="focus-ring flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-[var(--ink-soft)] hover:text-[var(--danger)]"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <SectionHeader className="mt-5" title="كيف تُبنى الخطة؟" />
          <p className="rounded-2xl bg-[var(--surface-2)] p-3 text-[0.72rem] leading-relaxed text-[var(--ink-soft)]">
            نضرب وزن كل مادة في حاجتها (١٠٠ − نسبة إنجازك)، ثم نوزّع الحصص على الأيام بمدة ٤٥ دقيقة تقريباً. كلما تقدّمت
            في مادة، قلّ نصيبها تلقائياً عند التحديث.
          </p>
        </>
      )}

      <Modal open={addDay !== null} onClose={() => setAddDay(null)} title="إضافة حصة">
        <div className="space-y-3">
          <div>
            <label htmlFor="subject" className="mb-1 block text-[0.75rem] text-[var(--ink)]">
              المادة
            </label>
            <select
              id="subject"
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              className="focus-ring h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-[0.82rem]"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="minutes" className="mb-1 block text-[0.75rem] text-[var(--ink)]">
              المدة (دقيقة)
            </label>
            <input
              id="minutes"
              type="number"
              min={15}
              max={240}
              step={15}
              value={newMinutes}
              onChange={(e) => setNewMinutes(Number(e.target.value))}
              className="focus-ring h-11 w-full rounded-2xl border border-[var(--line)] bg-[var(--surface)] px-3 text-[0.82rem]"
            />
          </div>
          <Button
            block
            onClick={() => {
              if (addDay === null) return;
              addSession(addDay as 0 | 1 | 2 | 3 | 4 | 5 | 6, newSubject, newMinutes);
              setAddDay(null);
              toast('أُضيفت الحصة', 'success');
            }}
          >
            إضافة
          </Button>
        </div>
      </Modal>
    </div>
  );
}
