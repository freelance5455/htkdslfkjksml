import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpenCheck, ArrowRight, ShieldCheck, Sparkles, LineChart } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { ApiError } from '../lib/api';
import { Banner, Button, Field, Input } from '../components/ui';

type Mode = 'login' | 'register';

export default function Login() {
  const { login, register, continueAsGuest } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [guestBusy, setGuestBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (mode === 'register' && name.trim().length < 2) next.name = 'Enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) next.email = 'Enter a valid email address.';
    if (password.length < 8) next.password = 'Use at least 8 characters.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setBusy(true);
    setServerError(null);
    try {
      if (mode === 'login') await login(email.trim(), password);
      else await register(name.trim(), email.trim(), password);
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setServerError(err instanceof ApiError ? err.message : 'Something went wrong. Try again.');
    } finally {
      setBusy(false);
    }
  };

  const startGuest = async () => {
    setGuestBusy(true);
    setServerError(null);
    try {
      await continueAsGuest();
      navigate('/onboarding', { replace: true });
    } catch (err) {
      setServerError(err instanceof ApiError ? err.message : 'Could not start a guest session. Try again.');
    } finally {
      setGuestBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <div className="relative hidden flex-col justify-between overflow-hidden border-r border-line bg-surface/40 p-10 lg:flex">
        <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-brand/20 blur-3xl" />
        <div className="absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-brand/10 blur-3xl" />
        <div className="relative flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand text-white shadow-glow">
            <BookOpenCheck size={21} />
          </span>
          <div>
            <div className="font-display text-lg font-extrabold tracking-tight text-ink">EduMentor AI</div>
            <div className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted">Personal academic mentor</div>
          </div>
        </div>

        <div className="relative max-w-lg">
          <h1 className="font-display text-4xl font-extrabold leading-[1.1] tracking-tight text-ink">
            Your syllabus, your schedule, <span className="text-brand">your plan</span> — managed end to end.
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            EduMentor reads your own textbooks, teaches at your level, builds a timetable around your school hours,
            and turns every test mistake into tomorrow's revision. Built for CBSE Class 10 &amp; 12, JEE Main and JEE Advanced.
          </p>
          <div className="mt-8 space-y-3">
            {[
              { icon: Sparkles, title: 'Teacher, not a chatbot', body: 'Beginner, exam and advanced modes with understanding checks.' },
              { icon: BookOpenCheck, title: 'Grounded in your books', body: 'Answers cite the document and page they came from.' },
              { icon: LineChart, title: 'Evidence-based progress', body: 'Analytics from your real attempts and study sessions.' },
            ].map(({ icon: Icon, title, body }) => (
              <div key={title} className="flex items-start gap-3 rounded-xl border border-line bg-elevated/40 p-3.5">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand/15 text-brand"><Icon size={16} /></span>
                <div>
                  <div className="text-sm font-semibold text-ink">{title}</div>
                  <div className="text-xs text-muted">{body}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative flex items-center gap-2 text-[11px] text-muted">
          <ShieldCheck size={14} /> Your study data stays in your own account.
        </div>
      </div>

      <div className="flex items-center justify-center p-5 sm:p-10">
        <div className="w-full max-w-sm">
          <div className="mb-7 flex items-center gap-2.5 lg:hidden">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand text-white"><BookOpenCheck size={19} /></span>
            <span className="font-display text-lg font-extrabold text-ink">EduMentor AI</span>
          </div>

          <h2 className="font-display text-2xl font-bold tracking-tight text-ink">
            {mode === 'login' ? 'Welcome back' : 'Create your account'}
          </h2>
          <p className="mt-1 text-sm text-muted">
            {mode === 'login' ? 'Sign in to continue your preparation.' : 'Set up your academic profile in two minutes.'}
          </p>

          <div className="mt-5 grid grid-cols-2 gap-1 rounded-xl border border-line bg-elevated/50 p-1">
            {(['login', 'register'] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setServerError(null); setErrors({}); }}
                className={`rounded-lg py-2 text-sm font-semibold transition ${mode === m ? 'bg-brand text-white' : 'text-muted hover:text-ink'}`}
              >
                {m === 'login' ? 'Sign in' : 'Sign up'}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-5 space-y-3.5" noValidate>
            {serverError && <Banner tone="bad">{serverError}</Banner>}
            {mode === 'register' && (
              <Field label="Full name" required error={errors.name}>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Aarav Sharma" autoComplete="name" />
              </Field>
            )}
            <Field label="Email" required error={errors.email}>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" />
            </Field>
            <Field label="Password" required error={errors.password} hint={mode === 'register' ? 'Minimum 8 characters.' : undefined}>
              <Input
                type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••" autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              />
            </Field>
            <Button type="submit" loading={busy} className="w-full">
              {mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={16} />
            </Button>
          </form>

          <p className="mt-5 text-center text-xs text-muted">
            {mode === 'login' ? 'New here? ' : 'Already have an account? '}
            <button className="font-semibold text-brand hover:underline" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
              {mode === 'login' ? 'Create an account' : 'Sign in'}
            </button>
          </p>

          <div className="my-5 flex items-center gap-3 text-[11px] uppercase tracking-wider text-muted">
            <span className="h-px flex-1 bg-line" />
            or
            <span className="h-px flex-1 bg-line" />
          </div>

          <Button variant="secondary" className="w-full" loading={guestBusy} disabled={busy} onClick={startGuest}>
            Skip sign in — continue as guest
          </Button>
          <p className="mt-2 text-center text-[11px] leading-relaxed text-muted">
            A guest account is created for this browser. Your profile, tests and progress are saved to it.
          </p>
        </div>
      </div>
    </div>
  );
}
