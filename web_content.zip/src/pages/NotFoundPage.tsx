import { useNavigate } from "react-router-dom";
import { Home } from "lucide-react";

export default function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-studio-bg flex items-center justify-center">
      <div className="text-center">
        <p className="text-6xl font-black text-gradient-blue font-display mb-4">404</p>
        <h2 className="text-xl font-bold text-studio-text mb-2">Página não encontrada</h2>
        <p className="text-studio-text-muted mb-6">Esta rota não existe no AI Creator Studio.</p>
        <button onClick={() => navigate("/")} className="btn-primary">
          <Home className="w-4 h-4" /> Voltar ao Dashboard
        </button>
      </div>
    </div>
  );
}
