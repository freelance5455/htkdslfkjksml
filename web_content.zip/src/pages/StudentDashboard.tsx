import React from 'react';
import { useStore } from '../context/StoreContext';
import { GlassCard } from '../components/ui/GlassCard';
import { Lock, Unlock, FileText, Calendar, Clock, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export const StudentDashboard: React.FC = () => {
  const { folders, attempts } = useStore();
  const navigate = useNavigate();

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">Student Dashboard</h2>
          <p className="text-slate-500 mt-1">Upload your OMR sheets and get instant AI-powered analysis.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {folders.map(folder => {
          const isLocked = !folder.hasAnswerKey;
          const attempt = attempts.find(a => a.testId === folder.id);

          return (
            <motion.div
              key={folder.id}
              whileHover={!isLocked ? { scale: 1.02, y: -4 } : {}}
              className="relative rounded-2xl h-full"
            >
              {isLocked && (
                <div className="absolute inset-0 z-10 bg-white/40 backdrop-blur-sm rounded-2xl border border-white/50 flex flex-col items-center justify-center cursor-not-allowed">
                  <motion.div 
                    initial={{ scale: 0.8 }} animate={{ scale: 1 }} transition={{ repeat: Infinity, duration: 2, repeatType: 'reverse' }}
                  >
                    <Lock className="w-10 h-10 text-slate-400 mb-2" />
                  </motion.div>
                  <p className="text-sm font-medium text-slate-500">Answer Key Pending</p>
                </div>
              )}

              <GlassCard className={`h-full flex flex-col ${isLocked ? 'opacity-50' : 'cursor-pointer hover:shadow-lg hover:shadow-indigo-500/10 border-indigo-100'}`} onClick={() => {
                if (isLocked) return;
                if (attempt) {
                  navigate(`/analysis/${attempt.id}`);
                } else {
                  navigate(`/attempt/${folder.id}`);
                }
              }}>
                <div className="flex justify-between items-start mb-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xl ${isLocked ? 'bg-slate-100 text-slate-400' : 'bg-indigo-100 text-indigo-600 shadow-inner'}`}>
                    {folder.testNo}
                  </div>
                  {attempt ? (
                    <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full flex items-center gap-1">
                      Score: {attempt.totalScore}/720
                    </span>
                  ) : !isLocked && (
                    <span className="px-2.5 py-1 bg-indigo-50 text-indigo-600 text-xs font-semibold rounded-full flex items-center gap-1">
                      <Unlock className="w-3 h-3" /> Open
                    </span>
                  )}
                </div>
                
                <h3 className="text-xl font-bold text-slate-800">{folder.instituteName}</h3>
                <p className="text-sm text-slate-500 mt-2 flex-1">{folder.syllabus}</p>
                
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex gap-3 text-xs text-slate-400 font-medium">
                    <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> 180 Qs</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> 200 Mins</span>
                  </div>
                  {!isLocked && (
                    <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  )}
                </div>
              </GlassCard>
            </motion.div>
          );
        })}

        {folders.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 bg-white/40 rounded-2xl border border-dashed border-slate-300">
            No tests available right now. Please wait for the admin to create tests.
          </div>
        )}
      </div>
    </div>
  );
};
