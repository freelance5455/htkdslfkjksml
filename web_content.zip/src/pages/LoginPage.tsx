import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import heroBg from "@/assets/hero-bg.jpg";
import { Zap, Eye, EyeOff, Lock, Sparkles, ArrowRight, UserCheck, ShieldCheck, AlertCircle, UserPlus, CheckCircle2 } from "lucide-react";
import { OWNER_EMAIL, OWNER_EMAILS } from "@/constants";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, directAccess, registerDirect, loading, error, authenticated, clearError } = useAuth();
  const [tab, setTab] = useState<"direct" | "custom" | "password">("direct");
  const [name, setName] = useState("Sadraque Ngola");
  const [email, setEmail] = useState(OWNER_EMAIL);
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);

  // If already authenticated, redirect to dashboard immediately
  useEffect(() => {
    if (authenticated) {
      navigate("/", { replace: true });
    }
  }, [authenticated, navigate]);

  const handleDirectEntry = async (targetEmail?: string) => {
    clearError();
    const cleanTargetEmail = (targetEmail || email || OWNER_EMAIL).trim();
    const ok = await directAccess("Sadraque Ngola", cleanTargetEmail);
    if (ok) {
      navigate("/", { replace: true });
    }
  };

  const handleCustomRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    clearError();
    const ok = await registerDirect(name.trim(), email.trim() || OWNER_EMAIL);
    if (ok) {
      navigate("/", { replace: true });
    }
  };

  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    const ok = await login(email.trim(), password.trim());
    if (ok) {
      navigate("/", { replace: true });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-studio-bg">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/80 via-studio-bg to-studio-bg" />

      {/* Grid pattern */}
      <div className="absolute inset-0 bg-studio-grid bg-grid opacity-50" />

      {/* Glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-studio-blue/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Login card */}
      <div className="relative z-10 w-full max-w-md mx-4">
        <div className="studio-glass rounded-2xl p-7 border border-studio-blue/20 shadow-2xl">
          {/* Logo */}
          <div className="flex flex-col items-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-studio-blue via-studio-purple to-studio-pink flex items-center justify-center mb-3 glow-blue">
              <Zap className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-studio-text font-display tracking-tight">AI Creator Studio</h1>
            <p className="text-xs text-studio-text-muted mt-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-studio-blue" />
              CORE 4.0 • Enterprise Engine
            </p>
          </div>

          {/* Mode Switcher */}
          <div className="grid grid-cols-3 gap-1 p-1 bg-studio-panel/70 rounded-xl border border-studio-border mb-6">
            <button
              type="button"
              onClick={() => {
                setTab("direct");
                clearError();
              }}
              className={`py-2 px-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                tab === "direct"
                  ? "bg-studio-blue text-white shadow-sm"
                  : "text-studio-text-dim hover:text-studio-text"
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              Direto
            </button>
            <button
              type="button"
              onClick={() => {
                setTab("custom");
                clearError();
              }}
              className={`py-2 px-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                tab === "custom"
                  ? "bg-studio-blue text-white shadow-sm"
                  : "text-studio-text-dim hover:text-studio-text"
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              Cadastro
            </button>
            <button
              type="button"
              onClick={() => {
                setTab("password");
                clearError();
              }}
              className={`py-2 px-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                tab === "password"
                  ? "bg-studio-blue text-white shadow-sm"
                  : "text-studio-text-dim hover:text-studio-text"
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              Senha
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2 text-xs text-red-400 animate-fade-in">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {tab === "direct" && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-studio-blue/10 border border-studio-blue/20 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-studio-gold to-studio-orange flex items-center justify-center text-black font-bold text-sm shadow-md">
                    SN
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-studio-text">Sadraque Ngola</h3>
                    <p className="text-xs text-studio-blue font-medium">{email} • Proprietário</p>
                  </div>
                </div>

                {/* Email Selector Pills */}
                <div className="pt-2 border-t border-studio-blue/15 space-y-1.5">
                  <p className="text-[11px] text-studio-text-muted font-medium">Selecione seu e-mail de acesso:</p>
                  <div className="grid grid-cols-1 gap-1.5">
                    {OWNER_EMAILS.map((em) => (
                      <button
                        key={em}
                        type="button"
                        onClick={() => setEmail(em)}
                        className={`text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between border ${
                          email === em
                            ? "bg-studio-blue/15 border-studio-blue/50 text-studio-blue font-semibold shadow-xs"
                            : "bg-white border-studio-border text-studio-text-muted hover:text-studio-text"
                        }`}
                      >
                        <span className="truncate">{em}</span>
                        {email === em && <CheckCircle2 className="w-3.5 h-3.5 text-studio-blue shrink-0" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-studio-green pt-1">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>Acesso direto 100% liberado e autenticado</span>
                </div>
              </div>

              <button
                type="button"
                id="btn-direct-login"
                onClick={() => handleDirectEntry()}
                disabled={loading}
                className="w-full btn-primary justify-center py-3.5 text-sm font-semibold shadow-lg shadow-studio-blue/25 flex items-center gap-2 cursor-pointer hover:scale-[1.01] active:scale-[0.99] transition-transform"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Entrando no Studio...
                  </span>
                ) : (
                  <>
                    <span>Entrar no Studio Agora</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          )}

          {tab === "custom" && (
            <form onSubmit={handleCustomRegister} className="space-y-4">
              <div>
                <label className="block text-xs text-studio-text-muted mb-1.5 font-medium">Nome do Criador</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome completo"
                  className="studio-input text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-studio-text-muted mb-1.5 font-medium">E-mail</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sadraquengola7@gmail.com"
                  className="studio-input text-sm"
                  required
                />
              </div>

              <div className="p-3 rounded-xl bg-studio-panel/50 border border-studio-border/70 text-xs text-studio-text-muted flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-studio-green flex-shrink-0" />
                <span>Cadastro direto sem burocracia com acesso total ao estúdio.</span>
              </div>

              <button
                type="submit"
                disabled={loading || !name.trim()}
                className="w-full btn-primary justify-center py-3.5 text-sm font-semibold mt-2 shadow-lg shadow-studio-blue/20 flex items-center gap-2 cursor-pointer"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Cadastrando e acessando...
                  </span>
                ) : (
                  <>
                    <span>Cadastrar e Acessar Estúdio</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {tab === "password" && (
            <form onSubmit={handlePasswordLogin} className="space-y-4">
              <div>
                <label className="block text-xs text-studio-text-muted mb-1.5 font-medium">E-mail Administrativo</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sadraquengola7@gmail.com"
                  className="studio-input text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-studio-text-muted mb-1.5 font-medium">Senha</label>
                <div className="relative">
                  <input
                    type={showPass ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="studio-input text-sm pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-studio-text-dim hover:text-studio-text"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !password.trim()}
                className="w-full btn-primary justify-center py-3 text-sm font-semibold mt-2 cursor-pointer"
              >
                {loading ? "Validando no Servidor..." : "Entrar com Senha"}
              </button>
            </form>
          )}

          <div className="mt-6 pt-4 border-t border-studio-border/60 flex items-center justify-between text-xs text-studio-text-muted">
            <span>AI Creator Studio v4.0</span>
            <span className="text-studio-blue font-medium">Servidor & DB Ativos</span>
          </div>
        </div>
      </div>
    </div>
  );
}

