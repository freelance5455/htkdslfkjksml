import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Navbar } from '../components/Navbar.js';
import { Footer } from '../components/Footer.js';
import { Logo } from '../components/Logo.js';
import {
  Zap,
  MessageSquare,
  History,
  Mic,
  Volume2,
  Sliders,
  Moon,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Smartphone,
  CheckCircle2,
  Lock,
  Bot,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();

  const handleStartChatting = () => {
    if (user) {
      setCurrentPage('chat');
    } else {
      setCurrentPage('signup');
    }
  };

  const featureCards = [
    {
      icon: Zap,
      color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-900/60',
      title: 'Fast AI Responses',
      description: 'Stream answers token by token with virtually zero latency powered by Gemini 3.8 Flash.',
    },
    {
      icon: Bot,
      color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-900/60',
      title: 'Smart Conversations',
      description: 'Retains multi-turn conversation context to give you accurate, deeply nuanced, high-level answers.',
    },
    {
      icon: History,
      color: 'text-sky-500 bg-sky-50 dark:bg-sky-950/60 border-sky-200 dark:border-sky-900/60',
      title: 'Chat History',
      description: 'Automatically saved and organized chronologically with instant full-text search across titles and messages.',
    },
    {
      icon: Mic,
      color: 'text-rose-500 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-900/60',
      title: 'Voice Input',
      description: 'Hands-free speech-to-text recognition lets you dictate complex thoughts and queries seamlessly on mobile.',
    },
    {
      icon: Volume2,
      color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-900/60',
      title: 'Read Responses Aloud',
      description: 'Natural text-to-speech audio with customizable voice, speaking rate, and pitch controls.',
    },
    {
      icon: Sliders,
      color: 'text-violet-500 bg-violet-50 dark:bg-violet-950/60 border-violet-200 dark:border-violet-900/60',
      title: 'Personalized AI',
      description: 'Customize your AI name, response tone (Professional, Friendly, Creative), length, language, and instructions.',
    },
    {
      icon: Moon,
      color: 'text-blue-500 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-900/60',
      title: 'Dark Mode & Custom Theme',
      description: 'Designed for OLED mobile screens with eye-pleasing dark, light, and system-adaptive interfaces.',
    },
    {
      icon: ShieldCheck,
      color: 'text-teal-500 bg-teal-50 dark:bg-teal-950/60 border-teal-200 dark:border-teal-900/60',
      title: 'Secure Account System',
      description: 'Multi-layer salted scrypt password hashing, session tokens, email verification, and private user databases.',
    },
  ];

  const steps = [
    {
      step: '01',
      title: 'Create Account',
      desc: 'Register in seconds with your email and a secure password. Verify your account with a single click.',
    },
    {
      step: '02',
      title: 'Login Securely',
      desc: 'Authenticate through our encrypted session system. Your chats and settings are synced privately to your account.',
    },
    {
      step: '03',
      title: 'Start Chatting With AI',
      desc: 'Ask questions, dictate via microphone, listen to responses, and explore ideas anywhere on any device.',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-12 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Glow ambient backgrounds */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-indigo-500/20 via-violet-500/20 to-pink-500/20 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>AI Pocket Chat • Mobile-First Intelligence</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15]">
            Your AI. Your Conversations.{' '}
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Anywhere.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            AI Pocket Chat helps you ask questions, get answers, organize conversations, and interact with AI through a fast and intelligent chat experience.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={handleStartChatting}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl text-base font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 active:scale-95 transition"
            >
              <span>Start Chatting</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {!user && (
              <button
                onClick={() => setCurrentPage('signup')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl text-base font-semibold border border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 transition shadow-xs"
              >
                <span>Create Account</span>
              </button>
            )}
          </div>

          {/* Owner attribution badge */}
          <div className="pt-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
            Created by <span className="text-indigo-600 dark:text-indigo-400 font-bold">Ali ABDULLAH</span>
          </div>

          {/* Interactive Chat Mockup Card */}
          <div className="pt-8 max-w-3xl mx-auto">
            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 shadow-2xl overflow-hidden backdrop-blur-md p-4 sm:p-6 text-left space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <Logo size="xs" showText={false} />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white">AI Pocket Chat</h3>
                    <p className="text-[10px] text-emerald-500 flex items-center gap-1 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Gemini 3.8 Flash Online
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500">
                    Mobile-Ready PWA
                  </span>
                </div>
              </div>

              {/* Sample Dialog */}
              <div className="space-y-3 text-xs">
                <div className="flex items-start gap-2.5 justify-end">
                  <div className="max-w-[80%] p-3 rounded-2xl rounded-tr-xs bg-indigo-600 text-white shadow-xs">
                    How can AI Pocket Chat help me streamline my daily workflow?
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                  <div className="max-w-[85%] p-3.5 rounded-2xl rounded-tl-xs bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 leading-relaxed shadow-xs space-y-1.5">
                    <p>
                      <strong>AI Pocket Chat</strong> is designed as your ultimate portable copilot:
                    </p>
                    <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                      <li>Voice dictation for hands-free queries on mobile.</li>
                      <li>Instant conversation search & persistent history.</li>
                      <li>Adjustable AI persona (tone, length, language).</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={handleStartChatting}
                  className="w-full py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 text-xs text-center hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 transition flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Click here to launch your first conversation</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features-section" className="py-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Powerful Capabilities
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
              Engineered for Speed, Precision, and Ease
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Every detail is crafted to provide a clean, production-grade AI chat experience on Android, iPhone, tablet, and desktop.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featureCards.map((feat, i) => {
              const Icon = feat.icon;
              return (
                <div
                  key={i}
                  className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 hover:border-indigo-300 dark:hover:border-indigo-800/60 transition duration-200 space-y-3"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${feat.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    {feat.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Simple 3-Step Setup
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
              How AI Pocket Chat Works
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Get started in under 30 seconds with complete data security.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((st, idx) => (
              <div
                key={idx}
                className="relative p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm space-y-4"
              >
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 font-bold text-lg flex items-center justify-center">
                  {st.step}
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {st.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {st.desc}
                </p>
              </div>
            ))}
          </div>

          {/* CTA Banner */}
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
            <div className="space-y-2 max-w-xl">
              <h3 className="text-2xl sm:text-3xl font-bold">Ready to experience AI Pocket Chat?</h3>
              <p className="text-indigo-100 text-sm">
                Join now and experience smart conversations, voice dictation, and personalized intelligence on any device.
              </p>
              <p className="text-xs text-indigo-200 font-semibold pt-1">
                OWNER NAME: Ali ABDULLAH
              </p>
            </div>
            <button
              onClick={handleStartChatting}
              className="px-6 py-3.5 rounded-2xl bg-white text-indigo-700 font-bold text-sm shadow-md hover:bg-indigo-50 active:scale-95 transition shrink-0"
            >
              Get Started Now
            </button>
          </div>
        </div>
      </section>

      {/* Main Footer with Owner Rule */}
      <Footer />
    </div>
  );
};
