import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Compass,
  Search,
  Sparkles,
  ArrowRight,
  Atom,
  Zap,
  Rocket,
  Flame,
  Bot,
  Sigma,
  Cpu,
  Layers,
  ChevronRight,
  TrendingUp,
  BookOpen,
  Calculator,
  Bookmark
} from 'lucide-react';
import { Formula, Category } from '../types';
import { getFormulas, getCategories } from '../firebase/services';
import { useApp } from '../context/AppContext';
import { CardSkeleton } from '../components/common/SkeletonLoader';

interface EngineeringDomain {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  categorySlug: string;
  featuredTopics: string[];
  keyFormulaIds: string[];
}

export const ExplorePage: React.FC = () => {
  const { playSound, triggerHaptic, isFavorite, toggleFavorite, showToast } = useApp();
  const navigate = useNavigate();

  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeDomain, setActiveDomain] = useState<string>('all');

  const engineeringDomains: EngineeringDomain[] = [
    {
      id: 'mechanics',
      title: 'Mechanics & Dynamics',
      description: 'Forces, accelerations, momentum conservation, and energy transformations.',
      icon: <Atom className="w-5 h-5 text-[#D65A1F]" />,
      categorySlug: 'physics',
      featuredTopics: ["Newton's Laws", 'Work-Energy', 'Gravitation', 'Momentum'],
      keyFormulaIds: ['newtons-second-law', 'kinetic-energy', 'gravitational-force', 'momentum-formula']
    },
    {
      id: 'electrical',
      title: 'Electronics & Circuits',
      description: 'DC/AC circuit analysis, Ohm’s law, impedance, and magnetic induction.',
      icon: <Zap className="w-5 h-5 text-[#D65A1F]" />,
      categorySlug: 'electronics',
      featuredTopics: ["Ohm's Law", 'Electrical Power', 'Capacitive Reactance', 'Inductive Reactance'],
      keyFormulaIds: ['ohms-law', 'electric-power', 'coulombs-law', 'rc-time-constant']
    },
    {
      id: 'aerospace',
      title: 'Aerospace & Propulsion',
      description: 'Orbital mechanics, rocket delta-v, aerodynamic drag, and atmospheric re-entry.',
      icon: <Rocket className="w-5 h-5 text-[#D65A1F]" />,
      categorySlug: 'aerospace',
      featuredTopics: ['Rocket Equation', 'Escape Velocity', 'Orbital Speed', 'Aerodynamic Drag'],
      keyFormulaIds: ['rocket-equation', 'escape-velocity', 'orbital-speed', 'drag-equation']
    },
    {
      id: 'thermo',
      title: 'Thermal & Fluid Systems',
      description: 'Ideal gases, heat transfer conduction, Carnot efficiency, and fluid mechanics.',
      icon: <Flame className="w-5 h-5 text-[#D65A1F]" />,
      categorySlug: 'physics',
      featuredTopics: ['Ideal Gas Law', 'Heat Conduction', 'Bernoulli Equation', 'Reynolds Number'],
      keyFormulaIds: ['ideal-gas-law', 'fourier-heat-conduction', 'bernoullis-principle', 'reynolds-number']
    },
    {
      id: 'robotics',
      title: 'Robotics & Mechatronics',
      description: 'Forward kinematics, joint actuators, gear ratios, and torque requirements.',
      icon: <Bot className="w-5 h-5 text-[#D65A1F]" />,
      categorySlug: 'robotics',
      featuredTopics: ['Joint Torque', 'Gear Ratios', 'Forward Kinematics', 'DC Motor Sizing'],
      keyFormulaIds: ['joint-torque', 'gear-ratio-speed', 'motor-power', 'reynolds-number']
    },
    {
      id: 'math',
      title: 'Applied Engineering Mathematics',
      description: 'Trigonometry, vectors, quadratic solutions, calculus, and matrix transformations.',
      icon: <Sigma className="w-5 h-5 text-[#D65A1F]" />,
      categorySlug: 'mathematics',
      featuredTopics: ['Quadratic Roots', 'Pythagorean Theorem', 'Standard Deviation', 'Dot Product'],
      keyFormulaIds: ['quadratic-formula', 'pythagorean-theorem', 'circle-area', 'distance-formula']
    }
  ];

  useEffect(() => {
    async function load() {
      try {
        const [fList, cList] = await Promise.all([getFormulas(), getCategories()]);
        setFormulas(fList);
        setCategories(cList);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      playSound('button');
      navigate(`/formulas?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const filteredFormulas = formulas.filter((f) => {
    if (activeDomain === 'all') return true;
    const domain = engineeringDomains.find((d) => d.id === activeDomain);
    if (!domain) return true;
    return (
      f.category.toLowerCase().includes(domain.categorySlug.toLowerCase()) ||
      domain.keyFormulaIds.includes(f.id) ||
      f.tags.some((t) => domain.featuredTopics.some((ft) => ft.toLowerCase().includes(t.toLowerCase())))
    );
  });

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Header */}
      <section className="relative rounded-3xl border border-[#303030] bg-[#151515] p-6 sm:p-10 overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#D65A1F]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#232323] border border-[#303030] text-[#D65A1F] text-xs font-mono font-medium">
            <Compass className="w-3.5 h-3.5" />
            <span>Interactive Engineering Discovery</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-[#F5F2ED] tracking-tight">
            Explore Formulas by Engineering Domain
          </h1>
          <p className="text-sm sm:text-base text-[#A9A39C] leading-relaxed">
            From Newton’s mechanics and circuit theory to aerospace propulsion and robotics kinematics. Select a discipline to inspect formulas, review derivations, and run dynamic calculations.
          </p>

          {/* Quick Search */}
          <form onSubmit={handleSearchSubmit} className="pt-2">
            <div className="relative max-w-xl flex items-center">
              <Search className="absolute left-4 w-4 h-4 text-[#A9A39C]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by topic, formula name, or variable (e.g. Bernoulli, Torque, Isp)..."
                className="w-full pl-11 pr-24 py-3 rounded-2xl bg-[#1C1C1C] border border-[#303030] text-[#F5F2ED] placeholder-[#A9A39C] text-sm focus:outline-none focus:border-[#D65A1F] transition-all shadow-inner"
              />
              <button
                type="submit"
                onClick={() => playSound('button')}
                className="absolute right-2 px-4 py-1.5 rounded-xl bg-[#D65A1F] text-[#F5F2ED] text-xs font-bold hover:bg-[#B94717] transition-colors"
              >
                Search
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Engineering Domain Chips */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#F5F2ED] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#D65A1F]" />
            <span>Engineering Disciplines</span>
          </h2>
          <span className="text-xs font-mono text-[#A9A39C]">
            {filteredFormulas.length} equations available
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => {
              playSound('tab');
              setActiveDomain('all');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
              activeDomain === 'all'
                ? 'bg-[#D65A1F] text-[#F5F2ED] border-[#D65A1F]'
                : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030] hover:text-[#F5F2ED]'
            }`}
          >
            All Disciplines
          </button>
          {engineeringDomains.map((domain) => (
            <button
              key={domain.id}
              onClick={() => {
                playSound('tab');
                setActiveDomain(domain.id);
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all border ${
                activeDomain === domain.id
                  ? 'bg-[#232323] text-[#D65A1F] border-[#D65A1F] shadow-sm'
                  : 'bg-[#1C1C1C] text-[#A9A39C] border-[#303030] hover:text-[#F5F2ED]'
              }`}
            >
              <span>{domain.title}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Domain Highlights Cards */}
      {activeDomain === 'all' && (
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {engineeringDomains.map((domain) => (
            <div
              key={domain.id}
              className="rounded-2xl border border-[#303030] bg-[#1C1C1C] p-5 hover:border-[#D65A1F]/60 transition-all flex flex-col justify-between group shadow-sm"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-[#232323] border border-[#303030] flex items-center justify-center">
                    {domain.icon}
                  </div>
                  <button
                    onClick={() => {
                      playSound('tab');
                      setActiveDomain(domain.id);
                    }}
                    className="text-xs font-mono text-[#D65A1F] hover:underline flex items-center gap-1"
                  >
                    <span>View Domain</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div>
                  <h3 className="text-base font-bold text-[#F5F2ED] group-hover:text-[#D65A1F] transition-colors">
                    {domain.title}
                  </h3>
                  <p className="text-xs text-[#A9A39C] mt-1 leading-relaxed">
                    {domain.description}
                  </p>
                </div>

                {/* Subtopic tags */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {domain.featuredTopics.map((topic, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#232323] border border-[#303030] text-[#A9A39C]"
                    >
                      {topic}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-[#303030] flex items-center justify-between">
                <span className="text-[11px] text-[#A9A39C] font-mono">
                  {domain.keyFormulaIds.length} Core Equations
                </span>
                <button
                  onClick={() => {
                    playSound('tab');
                    setActiveDomain(domain.id);
                  }}
                  className="px-3 py-1 rounded-lg bg-[#232323] border border-[#303030] text-xs text-[#F5F2ED] hover:bg-[#D65A1F] hover:border-[#D65A1F] transition-colors"
                >
                  Explore Formulas
                </button>
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Filtered Formulas Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#F5F2ED] flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#D65A1F]" />
            <span>
              {activeDomain === 'all'
                ? 'Curated Engineering Formula Roster'
                : `${engineeringDomains.find((d) => d.id === activeDomain)?.title} Formulas`}
            </span>
          </h2>
          <Link
            to="/formulas"
            onClick={() => playSound('tab')}
            className="text-xs font-mono text-[#D65A1F] hover:underline flex items-center gap-1"
          >
            <span>Full Library</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <CardSkeleton key={i} />
            ))}
          </div>
        ) : filteredFormulas.length === 0 ? (
          <div className="text-center py-12 rounded-2xl bg-[#1C1C1C] border border-[#303030] p-6 space-y-3">
            <Atom className="w-8 h-8 text-[#A9A39C] mx-auto opacity-50" />
            <p className="text-sm text-[#F5F2ED] font-semibold">No formulas matched this domain</p>
            <button
              onClick={() => setActiveDomain('all')}
              className="px-4 py-2 rounded-xl bg-[#232323] border border-[#303030] text-xs text-[#D65A1F]"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFormulas.slice(0, 12).map((formula) => {
              const fav = isFavorite(formula.id);
              return (
                <div
                  key={formula.id}
                  className="rounded-2xl border border-[#303030] bg-[#1C1C1C] p-5 flex flex-col justify-between hover:border-[#D65A1F]/60 transition-all group shadow-sm"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#232323] text-[#D65A1F] border border-[#303030]">
                        {formula.category}
                      </span>
                      <button
                        onClick={() => {
                          const nowFav = toggleFavorite(formula.id);
                          showToast(nowFav ? 'Added to favorites' : 'Removed from favorites');
                        }}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          fav
                            ? 'bg-[#D65A1F]/20 text-[#D65A1F] border-[#D65A1F]'
                            : 'bg-[#232323] text-[#A9A39C] border-[#303030] hover:text-[#F5F2ED]'
                        }`}
                        title={fav ? 'Remove favorite' : 'Save favorite'}
                      >
                        <Bookmark className="w-3.5 h-3.5" fill={fav ? '#D65A1F' : 'none'} />
                      </button>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-[#F5F2ED] group-hover:text-[#D65A1F] transition-colors leading-snug">
                        {formula.title}
                      </h3>
                      <p className="text-xs text-[#A9A39C] line-clamp-2 mt-1">
                        {formula.description}
                      </p>
                    </div>

                    {/* Formula Mathematical Expression Box */}
                    <div className="p-3 rounded-xl bg-[#151515] border border-[#303030] text-center font-mono font-bold text-sm text-[#F5F2ED] group-hover:border-[#D65A1F]/40 transition-colors">
                      {formula.formula}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-4 mt-3 border-t border-[#303030] flex items-center justify-between gap-2">
                    <Link
                      to={`/formula/${formula.id}`}
                      onClick={() => playSound('tab')}
                      className="text-xs text-[#A9A39C] hover:text-[#F5F2ED] flex items-center gap-1 font-medium"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </Link>

                    <Link
                      to={`/calculator/${formula.id}`}
                      onClick={() => playSound('tab')}
                      className="px-3 py-1.5 rounded-xl bg-[#232323] border border-[#303030] hover:bg-[#D65A1F] hover:border-[#D65A1F] text-xs font-semibold text-[#F5F2ED] transition-colors flex items-center gap-1.5"
                    >
                      <Calculator className="w-3.5 h-3.5 text-[#D65A1F] group-hover:text-[#F5F2ED]" />
                      <span>Calculate</span>
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Engineering Tools Quick Callout */}
      <section className="rounded-2xl border border-[#303030] bg-[#151515] p-6 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-lg font-bold text-[#F5F2ED]">
            Looking for multi-variable Engineering Calculators?
          </h3>
          <p className="text-xs text-[#A9A39C]">
            Use dedicated calculators for Beam Deflection, Reynolds Flow, Rocket Delta-v, and AC Impedance.
          </p>
        </div>
        <Link
          to="/tools"
          onClick={() => playSound('button')}
          className="shrink-0 px-5 py-2.5 rounded-xl bg-[#D65A1F] text-[#F5F2ED] text-xs font-bold hover:bg-[#B94717] transition-colors shadow-md flex items-center gap-2"
        >
          <span>Launch Engineering Tools</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </section>
    </div>
  );
};
