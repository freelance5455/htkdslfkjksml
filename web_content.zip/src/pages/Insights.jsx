import { useMemo } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, Clock, MapPin, TrendingUp } from "lucide-react";
import useReports from "@/hooks/useReports";
import { computeStats, categorySplit, statusSplit, areaCounts, weeklyVolume, reportDate, CATEGORIES } from "@/lib/reportStats";
import VolumeChart from "@/components/charts/VolumeChart";
import CategoryDonut from "@/components/charts/CategoryDonut";
import AreaBars from "@/components/charts/AreaBars";

function avgDaysFor(reports, category) {
  const items = reports.filter(
    (r) => r.category === category && r.status === "resolved" && r.resolved_date && reportDate(r)
  );
  if (!items.length) return null;
  const total = items.reduce(
    (sum, r) => sum + Math.max(0, (new Date(r.resolved_date) - new Date(reportDate(r))) / 86400000),
    0
  );
  return Math.round((total / items.length) * 10) / 10;
}

export default function Insights() {
  const { reports, loading } = useReports();

  const stats = useMemo(() => computeStats(reports), [reports]);
  const byCategory = useMemo(() => categorySplit(reports), [reports]);
  const byStatus = useMemo(() => statusSplit(reports), [reports]);
  const areas = useMemo(() => areaCounts(reports), [reports]);
  const trend = useMemo(() => weeklyVolume(reports, 12), [reports]);

  const tiles = [
    { label: "Reports on the board", value: stats.total, hint: "All time", icon: MapPin },
    { label: "Resolved", value: stats.resolved, hint: `${stats.resolvedRate}% close rate`, icon: CheckCircle2 },
    { label: "Average close time", value: stats.avgDays ?? "—", hint: "Days, report to clear", icon: Clock },
    { label: "Still open", value: stats.open + stats.inProgress, hint: `${stats.open} untouched`, icon: TrendingUp },
  ];

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-border border-t-primary" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-5 py-12 lg:px-8">
      <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-primary">Insights</p>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            How Coimbatore is doing
          </h1>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
            Every number below is built from the public board — reports raised by residents,
            cleared by the city team.
          </p>
        </div>
        <Link
          to="/report"
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2 text-sm transition-colors hover:border-primary/30"
        >
          Add a report
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tiles.map((tile) => (
          <div key={tile.label} className="rounded-2xl border border-border bg-card p-5">
            <tile.icon className="h-4 w-4 text-primary" />
            <p className="mt-4 font-display text-3xl font-semibold leading-none tabular-nums">
              {tile.value}
            </p>
            <p className="mt-2 text-[11px] font-medium uppercase tracking-[0.1em] text-foreground/70">
              {tile.label}
            </p>
            <p className="mt-1 text-[11px] text-muted-foreground">{tile.hint}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-2xl border border-border bg-card p-6">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
            Twelve-week trend
          </p>
          <p className="mt-1 font-display text-lg font-semibold">Reports raised per week</p>
          <div className="mt-4">
            <VolumeChart data={trend} height={240} />
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
            Board make-up
          </p>
          <p className="mt-1 font-display text-lg font-semibold">By category</p>
          <div className="mt-4">
            <CategoryDonut data={byCategory} height={180} />
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.4fr]">
        <div className="rounded-2xl border border-border bg-card p-6">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
            Work in progress
          </p>
          <p className="mt-1 font-display text-lg font-semibold">Status split</p>
          <div className="mt-5 space-y-4">
            {byStatus.map((row) => {
              const pct = stats.total ? Math.round((row.value / stats.total) * 100) : 0;
              return (
                <div key={row.name}>
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="inline-flex items-center gap-2 text-muted-foreground">
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: row.color }} />
                      {row.name}
                    </span>
                    <span className="font-medium tabular-nums">
                      {row.value} <span className="text-muted-foreground">· {pct}%</span>
                    </span>
                  </div>
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${pct}%`, backgroundColor: row.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 border-t border-border/70 pt-5">
            <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
              Average days to clear
            </p>
            <ul className="mt-3 space-y-2">
              {CATEGORIES.map((category) => (
                <li key={category.value} className="flex items-center justify-between text-[12px]">
                  <span className="inline-flex items-center gap-2 text-muted-foreground">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: category.color }} />
                    {category.short}
                  </span>
                  <span className="font-medium tabular-nums">
                    {avgDaysFor(reports, category.value) ?? "—"}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
                Hotspots
              </p>
              <p className="mt-1 font-display text-lg font-semibold">Reports by neighbourhood</p>
            </div>
            <span className="text-[11px] text-muted-foreground">{areas.length} areas</span>
          </div>
          <div className="mt-5">
            <AreaBars areas={areas.slice(0, 8)} />
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-border bg-secondary/40 p-6">
        <p className="font-display text-lg font-semibold">Why this matters</p>
        <p className="mt-1 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Hotspots usually point to a missing bin, a broken drain or a collection route that
          needs changing. When one neighbourhood keeps appearing, the city team can fix the cause
          instead of the symptom.
        </p>
      </div>
    </div>
  );
}