import React, { useState } from 'react';
import { 
  Star, 
  Volume2, 
  TrendingUp, 
  TrendingDown, 
  BellPlus, 
  Sparkles, 
  LayoutGrid, 
  List, 
  Plus, 
  AlertCircle 
} from 'lucide-react';
import { AssetData, ThemeMode, AudioSettings, ActiveVoiceAlert } from '../types/market';
import { AssetCard } from '../components/AssetCard';
import { speakText } from '../services/audioEngine';

interface WatchlistPageProps {
  assets: AssetData[];
  watchlist: string[];
  onToggleWatchlist: (assetId: string) => void;
  onOpenAlertModal: (asset: AssetData) => void;
  onOpenDetailModal: (asset: AssetData) => void;
  onQuickVoiceAnnounce: (asset: AssetData) => void;
  activeAlerts: ActiveVoiceAlert[];
  audioSettings: AudioSettings;
  theme: ThemeMode;
  language: 'fr' | 'en';
  onNavigateToMarket: () => void;
}

export const WatchlistPage: React.FC<WatchlistPageProps> = ({
  assets,
  watchlist,
  onToggleWatchlist,
  onOpenAlertModal,
  onOpenDetailModal,
  onQuickVoiceAnnounce,
  activeAlerts,
  audioSettings,
  theme,
  language,
  onNavigateToMarket,
}) => {
  const isLight = theme === 'light';
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [isReadingWatchlist, setIsReadingWatchlist] = useState<boolean>(false);

  const watchedAssets = assets.filter((a) => watchlist.includes(a.id));

  // Compute basket metrics
  const avgChange = watchedAssets.length > 0
    ? (watchedAssets.reduce((sum, a) => sum + a.change24h, 0) / watchedAssets.length).toFixed(2)
    : '0.00';
  const isPositiveBasket = parseFloat(avgChange) >= 0;

  const handleReadFullWatchlist = async () => {
    if (watchedAssets.length === 0) return;
    setIsReadingWatchlist(true);

    const intro = language === 'fr'
      ? `Synthèse vocale de votre Watchlist : ${watchedAssets.length} actifs suivis, variation moyenne de ${avgChange} pour cent.`
      : `Voice briefing for your Watchlist: ${watchedAssets.length} assets monitored, average change is ${avgChange} percent.`;
    
    await speakText(intro, audioSettings, language);

    // Speak top 3 assets concisely
    for (const item of watchedAssets.slice(0, 4)) {
      const line = language === 'fr'
        ? `${item.name} à ${item.price.toLocaleString()} dollars, ${item.change24h > 0 ? 'hausse' : 'baisse'} de ${item.change24h} pour cent.`
        : `${item.symbol} at ${item.price.toLocaleString()} dollars, ${item.change24h} percent.`;
      await speakText(line, audioSettings, language);
    }

    setIsReadingWatchlist(false);
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Header Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 transition-colors ${
        isLight
          ? 'bg-gradient-to-r from-amber-50 via-white to-yellow-50 border-amber-200'
          : 'bg-gradient-to-r from-slate-900 via-slate-900/90 to-amber-950/40 border-slate-800'
      }`}>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold border ${
              isLight ? 'bg-amber-100 border-amber-300 text-amber-800' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
            }`}>
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>SURVEILLANCE PRIORITAIRE &bull; WATCHLIST</span>
            </span>
          </div>

          <h1 className={`text-2xl sm:text-3xl font-extrabold font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
            Ma Watchlist Personnalisée
          </h1>
          <p className={`text-xs sm:text-sm max-w-xl leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
            Accès rapide à vos cryptos, devises et matières premières préférées. 
            Déclenchez une lecture vocale complète de vos cours favoris en 1 clic.
          </p>
        </div>

        {/* Watchlist Actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleReadFullWatchlist}
            disabled={watchedAssets.length === 0 || isReadingWatchlist}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all cursor-pointer whitespace-nowrap"
          >
            <Volume2 className="w-4 h-4" />
            <span>{isReadingWatchlist ? 'Lecture Vocale...' : 'Annoncer la Watchlist'}</span>
          </button>
        </div>
      </div>

      {/* Metrics & View Mode Toolbar */}
      <div className={`p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center gap-4 text-xs font-mono">
          <div>
            <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>ACTIFS FAVORIS : </span>
            <strong className={isLight ? 'text-slate-900' : 'text-white'}>{watchedAssets.length}</strong>
          </div>
          <div>
            <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>PERFORMANCE MOYENNE : </span>
            <span className={`font-bold ${isPositiveBasket ? 'text-emerald-500' : 'text-rose-500'}`}>
              {isPositiveBasket ? '+' : ''}{avgChange}%
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              viewMode === 'grid'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : isLight ? 'bg-slate-100 text-slate-600' : 'bg-slate-800 text-slate-400'
            }`}
            title="Vue Cartes"
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              viewMode === 'table'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : isLight ? 'bg-slate-100 text-slate-600' : 'bg-slate-800 text-slate-400'
            }`}
            title="Vue Tableau Compact"
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      {watchedAssets.length === 0 ? (
        <div className={`p-16 text-center space-y-4 rounded-3xl border ${
          isLight ? 'bg-white border-slate-200' : 'bg-slate-900/30 border-slate-800'
        }`}>
          <Star className="w-12 h-12 text-amber-400 mx-auto opacity-75" />
          <h3 className={`text-base font-bold ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>
            Votre Watchlist est vide
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Cliquez sur l'étoile ⭐ sur n'importe quel actif depuis l'onglet Marché pour l'épingler ici.
          </p>
          <button
            onClick={onNavigateToMarket}
            className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>Explorer le Marché</span>
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {watchedAssets.map((asset) => {
            const hasActiveAlert = activeAlerts.some(
              (a) => (a.assetId === asset.id || a.assetSymbol === asset.symbol) && a.enabled
            );
            return (
              <AssetCard
                key={asset.id}
                asset={asset}
                onOpenAlertModal={onOpenAlertModal}
                onOpenDetailModal={onOpenDetailModal}
                onQuickVoiceAnnounce={onQuickVoiceAnnounce}
                hasActiveAlerts={hasActiveAlert}
                isFavorite={true}
                onToggleFavorite={onToggleWatchlist}
                theme={theme}
              />
            );
          })}
        </div>
      ) : (
        /* Compact Table View */
        <div className={`rounded-3xl border overflow-hidden shadow-md ${
          isLight ? 'bg-white border-slate-200' : 'bg-slate-900/80 border-slate-800'
        }`}>
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className={`border-b font-mono ${
                isLight ? 'bg-slate-50 border-slate-200 text-slate-500' : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}>
                <th className="p-4">ACTIF</th>
                <th className="p-4">PRIX EN DIRECT</th>
                <th className="p-4">24H VARIATION</th>
                <th className="p-4">VOLUME</th>
                <th className="p-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-mono">
              {watchedAssets.map((asset) => {
                const isPos = asset.change24h >= 0;
                return (
                  <tr key={asset.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onToggleWatchlist(asset.id)}
                          className="text-amber-400 cursor-pointer"
                        >
                          <Star className="w-4 h-4 fill-amber-400" />
                        </button>
                        <div>
                          <strong className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                            {asset.symbol}
                          </strong>
                          <span className={`block text-[11px] ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>
                            {asset.name}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="p-4 font-bold text-sm">
                      ${asset.price.toLocaleString(undefined, {
                        minimumFractionDigits: asset.price < 1 ? 4 : 2,
                        maximumFractionDigits: asset.price < 1 ? 4 : 2,
                      })}
                    </td>

                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded-lg text-xs font-bold ${
                        isPos 
                          ? isLight ? 'bg-emerald-50 text-emerald-700' : 'bg-emerald-500/20 text-emerald-400' 
                          : isLight ? 'bg-rose-50 text-rose-700' : 'bg-rose-500/20 text-rose-400'
                      }`}>
                        {isPos ? '+' : ''}{asset.change24h}%
                      </span>
                    </td>

                    <td className="p-4 text-slate-500">{asset.volume24h}</td>

                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onQuickVoiceAnnounce(asset)}
                          className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                            isLight ? 'hover:bg-slate-100 text-slate-600' : 'hover:bg-slate-800 text-slate-300'
                          }`}
                          title="Voix"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onOpenAlertModal(asset)}
                          className="p-1.5 rounded-lg bg-amber-500/15 text-amber-500 border border-amber-500/30 hover:bg-amber-500/25 cursor-pointer"
                          title="Alerte"
                        >
                          <BellPlus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
