import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { GlassCard } from '../components/ui/GlassCard';
import { AnimatedButton } from '../components/ui/AnimatedButton';
import { AnswerGrid } from '../components/ui/AnswerGrid';
import { FolderPlus, Upload, FileKey, CheckCircle2, ChevronRight, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TestFolder, AnswerOption } from '../types';
import { parseCSV, generateMockCSV } from '../lib/csv';

export const AdminDashboard: React.FC = () => {
  const { folders, addFolder, updateFolder } = useStore();
  const [isCreating, setIsCreating] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState<TestFolder | null>(null);

  // New folder form state
  const [instName, setInstName] = useState('');
  const [testNo, setTestNo] = useState('');
  const [syllabus, setSyllabus] = useState('');

  const [uploadedKey, setUploadedKey] = useState<Record<number, AnswerOption>>({});

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!instName || !testNo) return;
    
    const newFolder: TestFolder = {
      id: Date.now().toString(),
      instituteName: instName,
      testNo,
      syllabus,
      createdAt: Date.now(),
      hasAnswerKey: false,
      answerKey: {}
    };
    
    addFolder(newFolder);
    setIsCreating(false);
    setInstName(''); setTestNo(''); setSyllabus('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const parsed = parseCSV(text);
      setUploadedKey(parsed);
    };
    reader.readAsText(file);
  };

  const loadMockData = () => {
    const mock = generateMockCSV(Date.now());
    setUploadedKey(parseCSV(mock));
  };

  const handleSaveKey = () => {
    if (!selectedFolder) return;
    updateFolder({
      ...selectedFolder,
      hasAnswerKey: true,
      answerKey: uploadedKey
    });
    setSelectedFolder(null);
    setUploadedKey({});
  };

  if (selectedFolder) {
    return (
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
          <button onClick={() => setSelectedFolder(null)} className="hover:text-slate-800">Folders</button>
          <ChevronRight className="w-4 h-4" />
          <span className="font-medium text-slate-800">{selectedFolder.instituteName} - Test {selectedFolder.testNo}</span>
        </div>

        <GlassCard>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                <FileKey className="w-6 h-6 text-indigo-500" />
                Upload Answer Key
              </h2>
              <p className="text-slate-500 mt-1">Upload CSV or use mock data to generate the 1-180 grid.</p>
            </div>
            <div className="flex items-center gap-3">
              <AnimatedButton variant="secondary" icon={Play} onClick={loadMockData} className="text-sm">
                Mock Data
              </AnimatedButton>
              <div className="relative">
                <input 
                  type="file" 
                  accept=".csv" 
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <AnimatedButton icon={Upload} className="pointer-events-none">
                  Upload CSV
                </AnimatedButton>
              </div>
            </div>
          </div>

          {Object.keys(uploadedKey).length > 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 flex items-center justify-between">
                <p className="text-indigo-800 font-medium">Verify the answers below. Click any cell to edit it manually.</p>
                <AnimatedButton icon={CheckCircle2} onClick={handleSaveKey} className="bg-emerald-500 hover:bg-emerald-600 shadow-emerald-200">
                  Lock & Save Key
                </AnimatedButton>
              </div>
              
              <AnswerGrid 
                answers={uploadedKey} 
                onChange={(q, ans) => setUploadedKey(prev => ({ ...prev, [q]: ans }))}
              />
            </motion.div>
          )}
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">Admin Portal</h2>
          <p className="text-slate-500 mt-1">Manage test folders and answer keys securely.</p>
        </div>
        <AnimatedButton icon={FolderPlus} onClick={() => setIsCreating(true)}>
          Create New Test
        </AnimatedButton>
      </div>

      <AnimatePresence>
        {isCreating && (
          <motion.div 
            initial={{ opacity: 0, height: 0, mb: 0 }}
            animate={{ opacity: 1, height: 'auto', mb: 32 }}
            exit={{ opacity: 0, height: 0, mb: 0 }}
            className="overflow-hidden"
          >
            <GlassCard className="bg-indigo-50/50 border-indigo-100">
              <form onSubmit={handleCreateFolder} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Institute Name</label>
                  <input required value={instName} onChange={e => setInstName(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white" placeholder="e.g. Allen" />
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Test No.</label>
                  <input required value={testNo} onChange={e => setTestNo(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white" placeholder="e.g. 05" />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <label className="text-sm font-medium text-slate-700">Syllabus</label>
                  <div className="flex gap-3">
                    <input required value={syllabus} onChange={e => setSyllabus(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white" placeholder="e.g. Kinematics, Mole Concept..." />
                    <AnimatedButton type="submit" className="shrink-0">Create</AnimatedButton>
                  </div>
                </div>
              </form>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {folders.map(folder => (
          <GlassCard 
            key={folder.id} 
            hoverEffect
            className="cursor-pointer group flex flex-col h-full"
            onClick={() => setSelectedFolder(folder)}
          >
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xl">
                {folder.testNo}
              </div>
              {folder.hasAnswerKey ? (
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Ready
                </span>
              ) : (
                <span className="px-2.5 py-1 bg-amber-100 text-amber-700 text-xs font-semibold rounded-full">
                  Pending Key
                </span>
              )}
            </div>
            <h3 className="text-lg font-bold text-slate-800">{folder.instituteName}</h3>
            <p className="text-sm text-slate-500 mt-1 flex-1 line-clamp-2">{folder.syllabus}</p>
            <div className="mt-4 pt-4 border-t border-slate-100 text-sm text-indigo-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-between">
              {folder.hasAnswerKey ? 'Update Answer Key' : 'Upload Answer Key'}
              <ChevronRight className="w-4 h-4" />
            </div>
          </GlassCard>
        ))}
        
        {folders.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 bg-white/40 rounded-2xl border border-dashed border-slate-300">
            No test folders created yet. Click "Create New Test" to begin.
          </div>
        )}
      </div>
    </div>
  );
};
