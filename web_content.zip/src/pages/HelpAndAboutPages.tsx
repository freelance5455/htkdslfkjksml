import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Navbar } from '../components/Navbar.js';
import { Footer } from '../components/Footer.js';
import { Logo } from '../components/Logo.js';
import {
  HelpCircle,
  Mail,
  Send,
  CheckCircle2,
  ChevronDown,
  ShieldCheck,
  Smartphone,
  Cpu,
  Heart,
  ExternalLink,
  ArrowRight,
  Info,
} from 'lucide-react';

// ==========================================
// 1. ABOUT PAGE
// ==========================================
export const AboutPage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Navbar />

      <main className="flex-1 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
            <Info className="w-3.5 h-3.5" />
            <span>Our Story & Mission</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            About AI Pocket Chat
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            A fast, intelligent, and versatile pocket assistant engineered for everyday productivity, creative thought, and continuous learning.
          </p>
        </div>

        {/* Creator Showcase Card */}
        <div className="rounded-3xl border border-indigo-200 dark:border-indigo-900/60 bg-gradient-to-br from-white via-indigo-50/30 to-purple-50/20 dark:from-slate-900 dark:via-indigo-950/20 dark:to-purple-950/20 p-8 sm:p-10 shadow-lg text-center space-y-4">
          <Logo size="lg" showText={false} />

          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">AI Pocket Chat</h2>
            <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold tracking-wide uppercase">
              Created and owned by:
            </p>
            <p className="text-2xl font-black text-slate-900 dark:text-white">
              Ali ABDULLAH
            </p>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 max-w-xl mx-auto leading-relaxed">
            AI Pocket Chat was conceived with a clear vision: to bring high-speed generative intelligence into a sleek, mobile-optimized format that feels natural, responsive, and respectful of personal privacy.
          </p>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-xs">
            <ShieldCheck className="w-4 h-4 text-indigo-500" />
            <span>Official Founder & Project Lead: Ali ABDULLAH</span>
          </div>
        </div>

        {/* Core Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Smartphone className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Mobile-First Design</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Designed from the ground up for seamless touch interaction on Android browsers, iPhones, and tablets, with full desktop responsiveness.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Gemini 3.8 Intelligence</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Powered by modern Google Gemini models, enabling rapid streaming responses, voice dictation, and personalized conversation styles.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-violet-50 dark:bg-violet-950 text-violet-600 dark:text-violet-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Data Privacy & Control</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Your conversations are stored securely on our protected backend. Zero third-party tracker scripts and instant full data deletion.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center pt-4">
          <button
            onClick={() => setCurrentPage(user ? 'chat' : 'signup')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-md transition"
          >
            <span>Start Chatting with AI Pocket Chat</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </main>

      <Footer />
    </div>
  );
};

// ==========================================
// 2. HELP & SUPPORT PAGE
// ==========================================
export const HelpSupportPage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [contactName, setContactName] = useState(user?.name || '');
  const [contactEmail, setContactEmail] = useState(user?.email || '');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [myTickets, setMyTickets] = useState<any[]>([]);

  const fetchMyTickets = async () => {
    const emailToUse = contactEmail || user?.email;
    if (!emailToUse && !user?.id) return;
    try {
      const query = user?.id ? `userId=${user.id}` : `email=${encodeURIComponent(emailToUse || '')}`;
      const res = await fetch(`/api/support/my-tickets?${query}`);
      if (res.ok) {
        const data = await res.json();
        setMyTickets(data.tickets || []);
      }
    } catch (err) {
      console.error('Error fetching tickets:', err);
    }
  };

  React.useEffect(() => {
    fetchMyTickets();
  }, [user, contactEmail]);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactEmail.trim() || !subject.trim() || !message.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/support/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          name: contactName.trim(),
          email: contactEmail.trim(),
          subject: subject.trim(),
          message: message.trim(),
        }),
      });

      if (res.ok) {
        setSubmitted(true);
        setMessage('');
        setSubject('');
        fetchMyTickets();
        setTimeout(() => setSubmitted(false), 5000);
      } else {
        const err = await res.json();
        alert(err.error || 'Failed to submit support ticket.');
      }
    } catch (err) {
      console.error('Support ticket error:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const faqs = [
    {
      q: 'How do I start a conversation?',
      a: 'After logging into your account, simply type your question in the prompt box at the bottom of the screen. Press Enter or click the Send button to stream the answer.',
    },
    {
      q: 'Can AI Pocket Chat read responses aloud?',
      a: 'Yes! Every assistant reply has a "Listen" button with a speaker icon. Click it to hear the response read aloud. You can customize the voice, playback speed, and pitch in the Voice Settings menu.',
    },
    {
      q: 'How do I personalize the AI assistant?',
      a: 'Go to Settings > AI Personalization. You can customize your assistant’s name, response style (Professional, Friendly, Creative, etc.), preferred response length, preferred language, and custom prompt directives.',
    },
    {
      q: 'Is my data safe and private?',
      a: 'Yes. All authentication is cryptographically secured with salted scrypt hashing. All Gemini API calls are proxied securely on our private server. You can search, rename, or permanently delete your conversations at any time.',
    },
    {
      q: 'Who built AI Pocket Chat?',
      a: 'AI Pocket Chat was built and is owned by Ali ABDULLAH. Official support email: aipocketchat.support@gmail.com.',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Navbar />

      <main className="flex-1 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Help Center & FAQ</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            How can we assist you?
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Browse answers to common questions or reach out to our team directly.
          </p>
        </div>

        {/* System Status Banner */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-semibold text-slate-900 dark:text-white">
              All Systems Operational
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Gemini 3.8 Flash • AI Pocket Chat Active
          </span>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h2>
          <div className="space-y-2">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full text-left p-4 flex items-center justify-between gap-4 font-semibold text-xs sm:text-sm text-slate-900 dark:text-white"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform ${
                      openFaq === idx ? 'rotate-180 text-indigo-600' : ''
                    }`}
                  />
                </button>
                {openFaq === idx && (
                  <div className="px-4 pb-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Contact Form */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Contact & Feedback
            </h2>
            <p className="text-xs text-slate-400">
              Have a suggestion or need help? Send a note directly to our team.
            </p>
          </div>

          {submitted && (
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Thank you! Your message has been recorded.</span>
            </div>
          )}

          <form onSubmit={handleContactSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  value={contactName}
                  onChange={e => setContactName(e.target.value)}
                  required
                  placeholder="e.g. Ali"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Your Email
                </label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={e => setContactEmail(e.target.value)}
                  required
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={e => setSubject(e.target.value)}
                required
                placeholder="Question, feature request, or support ticket"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Message
              </label>
              <textarea
                rows={4}
                value={message}
                onChange={e => setMessage(e.target.value)}
                required
                placeholder="Describe your inquiry in detail..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-sm transition flex items-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{submitting ? 'Sending...' : 'Send Message'}</span>
              </button>
            </div>
          </form>

          {/* User Submitted Tickets & Admin Replies */}
          {myTickets.length > 0 && (
            <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-indigo-500" />
                <span>Your Support Tickets & Admin Replies</span>
              </h3>

              <div className="space-y-3">
                {myTickets.map(tkt => (
                  <div
                    key={tkt.id}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 dark:text-white">{tkt.subject}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          tkt.status === 'replied'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {tkt.status}
                      </span>
                    </div>

                    <p className="text-slate-600 dark:text-slate-300 text-xs">{tkt.message}</p>

                    {tkt.replies && tkt.replies.length > 0 && (
                      <div className="mt-2 space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                        <span className="font-bold text-indigo-600 dark:text-indigo-400 block text-[11px]">
                          Admin Reply (Ali ABDULLAH):
                        </span>
                        {tkt.replies.map((r: any) => (
                          <div
                            key={r.id}
                            className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200/50 dark:border-indigo-900/50 text-slate-800 dark:text-slate-200"
                          >
                            <p>{r.message}</p>
                            <span className="text-[10px] text-slate-400 mt-1 block">
                              {new Date(r.createdAt).toLocaleString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

// ==========================================
// 3. 404 NOT FOUND PAGE
// ==========================================
export const NotFoundPage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-center">
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-md space-y-6">
          <Logo size="lg" showText={false} />

          <div className="space-y-2">
            <h1 className="text-6xl font-black text-indigo-600 dark:text-indigo-400">404</h1>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Page Not Found</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              The page or conversation view you are looking for might have been moved or removed.
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => setCurrentPage(user ? 'chat' : 'landing')}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition"
            >
              {user ? 'Return to Chat Dashboard' : 'Return to Home'}
            </button>
          </div>

          <div className="text-[11px] font-semibold text-slate-400">
            OWNER NAME: Ali ABDULLAH
          </div>
        </div>
      </div>

      <Footer compact />
    </div>
  );
};
