import React, { useState } from 'react';
import { 
  Mic, 
  Music, 
  BellRing, 
  Sliders, 
  Play, 
  Check, 
  Trash2, 
  RotateCcw, 
  TrendingUp, 
  TrendingDown, 
  Volume2, 
  PlusCircle, 
  Bell, 
  Coins, 
  Zap, 
  Activity, 
  AlertTriangle,
  Radio
} from 'lucide-react';
import { 
  VoiceAlertPreset, 
  SoundEffectType, 
  AudioSettings, 
  ActiveVoiceAlert, 
  TriggeredAlertEvent, 
  ThemeMode,
  AssetData 
} from '../types/market';
import { VOICE_ALERT_LIBRARY, SOUND_EFFECT_PRESETS, formatAlertScript } from '../services/voiceLibrary';
import { playChimeSound, executeVoiceAlert, speakText } from '../services/audioEngine';

interface AlerteStudioPageProps {
  activeAlerts: ActiveVoiceAlert[];
  onToggleAlert: (alertId: string) => void;
  onDeleteAlert: (alertId: string) => void;
  onSimulateTrigger: (alert: ActiveVoiceAlert) => void;
  alertHistory: TriggeredAlertEvent[];
  onClearHistory: () => void;
  audioSettings: AudioSettings;
  onUpdateAudioSettings: (settings: AudioSettings) => void;
  onSelectPresetForAlert: (preset: VoiceAlertPreset) => void;
  assets: AssetData[];
  theme: ThemeMode;
  language: 'fr' | 'en';
}

export const AlerteStudioPage: React.FC<AlerteStudioPageProps> = ({
  activeAlerts,
  onToggleAlert,
  onDeleteAlert,
  onSimulateTrigger,
  alertHistory,
  onClearHistory,
  audioSettings,
  onUpdateAudioSettings,
  onSelectPresetForAlert,
  assets,
  theme,
  language,
}) => {
  const isLight = theme === 'light';
  const [activeTab, setActiveTab] = useState<'presets' | 'sounds' | 'active' | 'settings'>('presets');
  const [selectedLanguage, setSelectedLanguage] = useState<'all' | 'fr' | 'en'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [playingPresetId, setPlayingPresetId] = useState<string | null>(null);
  const [playingSoundId, setPlayingSoundId] = useState<string | null>(null);

  const filteredPresets = VOICE_ALERT_LIBRARY.filter((preset) => {
    if (selectedLanguage !== 'all' && preset.language !== selectedLanguage) return false;
    if (selectedCategory !== 'all' && preset.category !== selectedCategory) return false;
    return true;
  });

  const handleTestPreset = async (preset: VoiceAlertPreset) => {
    setPlayingPresetId(preset.id);
    const demoAsset = assets[0]?.symbol || 'BTC';
    const sampleScript = formatAlertScript(preset.script, demoAsset, 95500, 94520);
    await executeVoiceAlert(preset.defaultChime, sampleScript, audioSettings, preset.language);
    setPlayingPresetId(null);
  };

  const handleTestChime = async (soundId: SoundEffectType) => {
    setPlayingSoundId(soundId);
    await playChimeSound(soundId, audioSettings.volume);
    setTimeout(() => setPlayingSoundId(null), 600);
  };

  const handleTestVoiceConfig = async () => {
    const text = audioSettings.selectedPersona.startsWith('fr')
      ? 'Système audio MarketPulse validé. Volume et tonalité opérationnels.'
      : 'MarketPulse voice engine test successful. Audio clarity and pitch optimal.';
    await executeVoiceAlert('bell', text, audioSettings);
  };

  const getSoundIcon = (id: SoundEffectType) => {
    switch (id) {
      case 'bell': return <Bell className="w-4 h-4 text-amber-500" />;
      case 'bullish': return <TrendingUp className="w-4 h-4 text-emerald-500" />;
      case 'bearish': return <TrendingDown className="w-4 h-4 text-rose-500" />;
      case 'alarm': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'kaching': return <Coins className="w-4 h-4 text-yellow-500" />;
      case 'laser': return <Zap className="w-4 h-4 text-cyan-500" />;
      case 'pulsar': return <Activity className="w-4 h-4 text-purple-500" />;
      default: return <Radio className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Studio Header Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl border shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 transition-colors ${
        isLight
          ? 'bg-gradient-to-r from-amber-50 via-white to-orange-50 border-amber-200'
          : 'bg-gradient-to-r from-slate-900 via-slate-900/90 to-amber-950/40 border-slate-800'
      }`}>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold border ${
              isLight ? 'bg-amber-100 border-amber-300 text-amber-800' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
            }`}>
              <Mic className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
              <span>STUDIO & BIBLIOTHÈQUE VOCALE</span>
            </span>
          </div>

          <h1 className={`text-2xl sm:text-3xl font-extrabold font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
            Studio d'Alertes Vocales & Soundbank
          </h1>
          <p className={`text-xs sm:text-sm max-w-xl leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
            Testez et personnalisez les annonces parlées et carillons synthétisés par Web Audio API. 
            Gérez vos alertes de cours actives avec déclenchement automatique.
          </p>
        </div>

        {/* Master Sound Status Pill */}
        <div className={`p-4 rounded-2xl border flex items-center gap-3 ${
          isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-950/70 border-slate-800'
        }`}>
          <div className="p-2.5 rounded-xl bg-amber-500/15 text-amber-500">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <div className={`text-xs font-bold font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
              VOLUME : {Math.round(audioSettings.volume * 100)}%
            </div>
            <div className={`text-[11px] font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Débit: {audioSettings.rate}x &bull; {audioSettings.selectedPersona}
            </div>
          </div>
        </div>
      </div>

      {/* Studio Navigation Tabs */}
      <div className={`flex border-b gap-2 pt-2 ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
        <button
          onClick={() => setActiveTab('presets')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
            activeTab === 'presets'
              ? 'text-amber-500 border-amber-500 font-bold'
              : isLight ? 'text-slate-500 hover:text-slate-900 border-transparent' : 'text-slate-400 hover:text-slate-200 border-transparent'
          }`}
        >
          <Mic className="w-4 h-4" />
          <span>Catalogue Vocaux ({VOICE_ALERT_LIBRARY.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('sounds')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
            activeTab === 'sounds'
              ? 'text-amber-500 border-amber-500 font-bold'
              : isLight ? 'text-slate-500 hover:text-slate-900 border-transparent' : 'text-slate-400 hover:text-slate-200 border-transparent'
          }`}
        >
          <Music className="w-4 h-4" />
          <span>Carillons Web Audio ({SOUND_EFFECT_PRESETS.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('active')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
            activeTab === 'active'
              ? 'text-amber-500 border-amber-500 font-bold'
              : isLight ? 'text-slate-500 hover:text-slate-900 border-transparent' : 'text-slate-400 hover:text-slate-200 border-transparent'
          }`}
        >
          <BellRing className="w-4 h-4" />
          <span>Alertes Armées ({activeAlerts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
            activeTab === 'settings'
              ? 'text-amber-500 border-amber-500 font-bold'
              : isLight ? 'text-slate-500 hover:text-slate-900 border-transparent' : 'text-slate-400 hover:text-slate-200 border-transparent'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Réglages Voix</span>
        </button>
      </div>

      {/* TAB 1: PRESETS */}
      {activeTab === 'presets' && (
        <div className="space-y-4">
          
          {/* Filters */}
          <div className={`p-3 rounded-2xl border flex flex-wrap items-center justify-between gap-3 ${
            isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900/60 border-slate-800'
          }`}>
            <div className="flex items-center gap-1.5">
              <span className={`text-xs font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>LANGUE :</span>
              <button
                onClick={() => setSelectedLanguage('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  selectedLanguage === 'all'
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : isLight ? 'bg-slate-100 text-slate-700' : 'bg-slate-800 text-slate-300'
                }`}
              >
                Toutes
              </button>
              <button
                onClick={() => setSelectedLanguage('fr')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  selectedLanguage === 'fr'
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : isLight ? 'bg-slate-100 text-slate-700' : 'bg-slate-800 text-slate-300'
                }`}
              >
                🇫🇷 Français
              </button>
              <button
                onClick={() => setSelectedLanguage('en')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  selectedLanguage === 'en'
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : isLight ? 'bg-slate-100 text-slate-700' : 'bg-slate-800 text-slate-300'
                }`}
              >
                🇺🇸 English
              </button>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className={`text-xs font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>CATÉGORIE :</span>
              {['all', 'breakout', 'profit', 'dump', 'whale', 'volatility'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-mono uppercase cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-amber-500/20 text-amber-500 border border-amber-500/40 font-bold'
                      : isLight ? 'bg-slate-100 text-slate-600' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Presets List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPresets.map((preset) => {
              const isPlaying = playingPresetId === preset.id;
              return (
                <div
                  key={preset.id}
                  className={`p-4 rounded-2xl border shadow-md transition-all flex flex-col justify-between space-y-3 ${
                    isLight 
                      ? 'bg-white border-slate-200 hover:border-amber-300' 
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 shadow-black/30'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className={`font-semibold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                            {preset.title}
                          </h4>
                          <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
                            isLight ? 'bg-slate-100 border-slate-200 text-slate-600' : 'bg-slate-800 border-slate-700 text-slate-300'
                          }`}>
                            {preset.tag}
                          </span>
                          <span>{preset.language === 'fr' ? '🇫🇷' : '🇺🇸'}</span>
                        </div>
                        <p className={`text-xs mt-0.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                          {preset.description}
                        </p>
                      </div>

                      <div className={`flex items-center gap-1 text-[11px] font-mono px-2 py-1 rounded-lg border ${
                        isLight ? 'bg-slate-100 border-slate-200 text-slate-700' : 'bg-slate-800 border-slate-700 text-slate-300'
                      }`}>
                        {getSoundIcon(preset.defaultChime)}
                        <span className="capitalize">{preset.defaultChime}</span>
                      </div>
                    </div>

                    <div className={`p-3 rounded-xl border text-xs font-mono leading-relaxed italic ${
                      isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-slate-950/80 border-slate-800 text-slate-300'
                    }`}>
                      "{preset.script}"
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => handleTestPreset(preset)}
                      disabled={isPlaying}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                        isPlaying
                          ? 'bg-amber-500 text-slate-950 animate-pulse'
                          : isLight
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                      }`}
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>{isPlaying ? 'Écoute...' : 'Tester la Voix'}</span>
                    </button>

                    <button
                      onClick={() => onSelectPresetForAlert(preset)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer transition-colors shadow-sm"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>Appliquer à un actif</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: SOUND EFFECTS */}
      {activeTab === 'sounds' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {SOUND_EFFECT_PRESETS.map((sound) => {
            const isPlaying = playingSoundId === sound.id;
            return (
              <div
                key={sound.id}
                className={`p-5 rounded-2xl border shadow-md flex flex-col justify-between space-y-3 transition-colors ${
                  isLight ? 'bg-white border-slate-200' : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className={`p-2.5 rounded-xl border ${
                      isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800 border-slate-700'
                    }`}>
                      {getSoundIcon(sound.id)}
                    </div>
                    <div>
                      <h4 className={`font-semibold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                        {sound.name}
                      </h4>
                      <span className="text-[10px] font-mono uppercase text-amber-500">
                        {sound.category}
                      </span>
                    </div>
                  </div>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                    {sound.description}
                  </p>
                </div>

                <button
                  onClick={() => handleTestChime(sound.id)}
                  disabled={isPlaying}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isPlaying
                      ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400'
                      : isLight
                      ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                      : 'bg-slate-800 hover:bg-slate-700 text-white'
                  }`}
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isPlaying ? 'Signal Web Audio...' : 'Jouer le Carillon'}</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 3: ACTIVE ALERTS */}
      {activeTab === 'active' && (
        <div className="space-y-4">
          {activeAlerts.length === 0 ? (
            <div className={`p-12 text-center space-y-3 rounded-2xl border ${
              isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-slate-900/30 border-slate-800 text-slate-400'
            }`}>
              <BellRing className="w-10 h-10 mx-auto text-slate-400" />
              <div className={`font-semibold text-sm ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>
                Aucune alerte vocale armée
              </div>
              <p className="text-xs max-w-sm mx-auto">
                Choisissez un preset dans le catalogue ou ouvrez un actif sur le marché pour configurer une alerte.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-2xl border transition-all space-y-3 ${
                    alert.enabled
                      ? isLight ? 'bg-white border-slate-300 shadow-sm' : 'bg-slate-900/80 border-slate-700'
                      : isLight ? 'bg-slate-50 border-slate-200 opacity-60' : 'bg-slate-950 border-slate-800 opacity-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center font-bold text-xs font-mono ${
                        isLight ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-slate-800 border-slate-700 text-white'
                      }`}>
                        {alert.assetSymbol.slice(0, 4)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`font-bold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                            {alert.assetSymbol}
                          </span>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                            alert.condition === 'above'
                              ? isLight ? 'bg-emerald-50 text-emerald-700' : 'bg-emerald-500/20 text-emerald-400'
                              : isLight ? 'bg-rose-50 text-rose-700' : 'bg-rose-500/20 text-rose-400'
                          }`}>
                            {alert.condition === 'above' ? '≥' : '≤'} ${alert.targetValue.toLocaleString()}
                          </span>
                        </div>
                        <span className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                          {alert.assetName}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onToggleAlert(alert.id)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        alert.enabled ? 'bg-emerald-500' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          alert.enabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className={`p-2.5 rounded-xl border font-mono text-xs italic ${
                    isLight ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-slate-950 border-slate-800 text-slate-300'
                  }`}>
                    "{alert.voiceScript}"
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <span className={`font-mono text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      Son: <strong className="capitalize">{alert.soundChime}</strong>
                      {alert.triggerCount > 0 && ` (${alert.triggerCount}x déclenché)`}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSimulateTrigger(alert)}
                        className="px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-600 dark:text-amber-300 font-semibold text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Play className="w-3 h-3" />
                        <span>Tester Trigger</span>
                      </button>

                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          isLight ? 'hover:bg-rose-50 text-slate-400 hover:text-rose-600' : 'hover:bg-rose-500/20 text-slate-400 hover:text-rose-400'
                        }`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SETTINGS */}
      {activeTab === 'settings' && (
        <div className="max-w-2xl mx-auto space-y-5">
          <div className={`p-5 rounded-3xl border space-y-4 shadow-sm ${
            isLight ? 'bg-white border-slate-200' : 'bg-slate-900/80 border-slate-800'
          }`}>
            <h3 className={`font-semibold text-sm flex items-center gap-2 ${isLight ? 'text-slate-900' : 'text-white'}`}>
              <Mic className="w-4 h-4 text-amber-500" />
              <span>Persona & Accent Vocal</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {[
                { id: 'fr-trader', name: '🇫🇷 Desk Parisien Pro', desc: 'Direct, dynamique et clair pour cryptos & actions' },
                { id: 'en-trader', name: '🇺🇸 US Trader Pro', desc: 'Sharp Wall Street alert broadcaster' },
                { id: 'en-analyst', name: '🇬🇧 UK Financial Analyst', desc: 'Calm institutional tone' },
                { id: 'cyber', name: '🤖 Cyber Sentinel AI', desc: 'Robotic high priority frequency modulation' },
              ].map((p) => {
                const isSelected = audioSettings.selectedPersona === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() =>
                      onUpdateAudioSettings({
                        ...audioSettings,
                        selectedPersona: p.id as any,
                      })
                    }
                    className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-500/50 text-slate-900 dark:text-white font-medium'
                        : isLight ? 'bg-slate-50 border-slate-200 text-slate-600' : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs">{p.name}</span>
                      {isSelected && <Check className="w-4 h-4 text-amber-500" />}
                    </div>
                    <p className="text-[11px] opacity-80">{p.desc}</p>
                  </button>
                );
              })}
            </div>

            {/* Sliders */}
            <div className="space-y-4 pt-3 border-t border-slate-200 dark:border-slate-800">
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className={isLight ? 'text-slate-600' : 'text-slate-300'}>Volume des Alertes</span>
                  <span className="font-mono font-bold text-amber-500">{Math.round(audioSettings.volume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={audioSettings.volume}
                  onChange={(e) =>
                    onUpdateAudioSettings({
                      ...audioSettings,
                      volume: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className={isLight ? 'text-slate-600' : 'text-slate-300'}>Débit de Parole (Vitesse)</span>
                  <span className="font-mono font-bold text-amber-500">{audioSettings.rate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.4"
                  step="0.05"
                  value={audioSettings.rate}
                  onChange={(e) =>
                    onUpdateAudioSettings({
                      ...audioSettings,
                      rate: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            <button
              onClick={handleTestVoiceConfig}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-[0.99]"
            >
              <Volume2 className="w-4 h-4" />
              <span>Tester la Configuration Vocale</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
