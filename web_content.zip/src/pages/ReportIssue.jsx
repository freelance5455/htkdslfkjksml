import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { AREAS, AREA_COORDS, CITY_CENTER } from "@/lib/coimbatore";
import { CATEGORIES } from "@/lib/reportStats";
import { Camera, Crosshair, Loader2, Send } from "lucide-react";
import { cn } from "@/lib/utils";

const URGENCY = [
  { value: "low", label: "Can wait" },
  { value: "medium", label: "Needs attention" },
  { value: "high", label: "Urgent / unsafe" },
];

export default function ReportIssue() {
  const navigate = useNavigate();
  const [category, setCategory] = useState("garbage");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [area, setArea] = useState("Gandhipuram");
  const [address, setAddress] = useState("");
  const [priority, setPriority] = useState("medium");
  const [photoUrl, setPhotoUrl] = useState("");
  const [coords, setCoords] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handlePhoto = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setPhotoUrl(file_url);
    } catch (err) {
      setError(err.message || "The photo couldn't be uploaded. Try a smaller image.");
    } finally {
      setUploading(false);
    }
  };

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({ lat: position.coords.latitude, lng: position.coords.longitude });
        toast({ title: "Location captured", description: "The pin will match where you are." });
      },
      () => setError("We couldn't read your location. You can still send the report — it will use the area centre.")
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    if (!title.trim()) {
      setError("Add a short headline so the team can scan the board.");
      return;
    }
    setSaving(true);
    try {
      const fallback = AREA_COORDS[area] || CITY_CENTER;
      const created = await base44.entities.IssueReport.create({
        title: title.trim(),
        description: description.trim(),
        category,
        status: "reported",
        priority,
        area,
        address: address.trim(),
        lat: coords?.lat ?? fallback.lat,
        lng: coords?.lng ?? fallback.lng,
        photo_url: photoUrl,
        supports: 0,
        reported_on: new Date().toISOString(),
      });
      toast({ title: "Report sent", description: "The city team can see it now." });
      navigate(`/issues/${created.id}`);
    } catch (err) {
      setError(err.message || "The report couldn't be sent. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-5 py-12 lg:px-8">
      <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-primary">New report</p>
      <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl">
        Report a waste issue
      </h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Add what you saw and where. A photo helps the team act faster.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        <section className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display text-base font-semibold">What kind of issue is it?</h2>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {CATEGORIES.map((item) => (
              <button
                key={item.value}
                type="button"
                onClick={() => setCategory(item.value)}
                className={cn(
                  "flex items-center gap-2.5 rounded-xl border px-3.5 py-3 text-left text-sm transition-colors",
                  category === item.value
                    ? "border-primary bg-primary/5 text-foreground"
                    : "border-border bg-background text-muted-foreground hover:text-foreground"
                )}
              >
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                {item.label}
              </button>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Short headline</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Overflowing bin outside the market"
                maxLength={90}
                className="h-11 rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">What&apos;s happening?</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="How long has it been there? What does it block or affect?"
                rows={4}
                className="rounded-xl"
              />
            </div>

            <div className="space-y-2">
              <Label>Photo</Label>
              <label className="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-dashed border-border bg-background px-4 py-3.5 text-sm transition-colors hover:border-primary/40">
                <span className="flex items-center gap-2.5 text-muted-foreground">
                  <Camera className="h-4 w-4" />
                  {photoUrl ? "Photo attached — tap to replace" : "Add a photo of the spot"}
                </span>
                {uploading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                <input type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
              </label>
              {photoUrl && (
                <img src={photoUrl} alt="Attached" className="mt-2 h-32 w-full rounded-xl object-cover" />
              )}
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display text-base font-semibold">Where is it?</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="area">Area</Label>
              <select
                id="area"
                value={area}
                onChange={(e) => setArea(e.target.value)}
                className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/30"
              >
                {AREAS.map((name) => (
                  <option key={name} value={name}>
                    {name}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Landmark or street</Label>
              <Input
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Near the bus stop"
                className="h-11 rounded-xl"
              />
            </div>
          </div>

          <button
            type="button"
            onClick={useMyLocation}
            className="mt-4 inline-flex items-center gap-2 rounded-full border border-border px-3.5 py-2 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
          >
            <Crosshair className="h-3.5 w-3.5" />
            {coords ? "Location captured — tap to update" : "Use my location"}
          </button>

          <div className="mt-6">
            <Label>How urgent is it?</Label>
            <div className="mt-2 flex flex-wrap gap-2">
              {URGENCY.map((item) => (
                <button
                  key={item.value}
                  type="button"
                  onClick={() => setPriority(item.value)}
                  className={cn(
                    "rounded-full border px-3.5 py-1.5 text-xs transition-colors",
                    priority === item.value
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground hover:text-foreground"
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {error && (
          <div className="rounded-xl border border-destructive/20 bg-destructive/10 p-3 text-xs leading-relaxed text-destructive">
            {error}
          </div>
        )}

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-sm text-[11px] leading-relaxed text-muted-foreground">
            Reports are public — anyone can read them. Please don&apos;t include personal details.
          </p>
          <Button type="submit" size="lg" className="rounded-full px-6" disabled={saving || uploading}>
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send the report
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}