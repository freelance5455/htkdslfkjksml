import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, TrendingUp } from 'lucide-react';
import { api, ApiError } from '../lib/api';
import { MISTAKE_LABELS } from '@shared/exam';
import { formatMinutes } from '../lib/utils';
import { Badge, Banner, Button, Card, EmptyState, ProgressBar, SectionHeading, Spinner, StatCard } from '../components/ui';
import { DifficultyRadar, HoursChart, MistakeBars, ScoreLine, SubjectBars, TrendChart } from '../components/Charts';

interface AnalyticsData {
  summary: {
    attempts: number; questionsAttempted: number; accuracy: number | null; studyMinutes: number;
    studyDays: number; averageScorePercent: number | null; bestScorePercent: number | null;
    revisionCards: number; revisionReviewed: number;
  };
  trend: { attemptId: number; title: string; exam: string; date: string; score: number; max: number; percent: number; accuracy: number; change: number | null; timeMinutes: number; mistakes: Record<string, number> }[];
  subjects: { subject: string; accuracy: number; score: number; max: number; correct: number; attempted: number }[];
  chapters: { subject: string; chapter: string; correct: number; total: number; accuracy: number }[];
  mistakes: { type: string; count: number }[];
  difficulties: { difficulty: string; accuracy: number; total: number }[];
  studyByDay: { date: string; minutes: number; sessions: number }[];
  subjectProgress: { subject: string; chapters: number; mastery: number; confident: number }[];
}

export default function Analytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void api.get<AnalyticsData>('/api/analytics')
      .then(setData)
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Could not load analytics.'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner label="Reading your attempt history…" />;
  if (error) return <Banner tone="bad">{error}</Banner>;
  if (!data) return null;

  const { summary } = data;
  const hasTests = summary.attempts > 0;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Tests completed" value={summary.attempts} hint={`${summary.questionsAttempted} questions attempted`} icon={<BarChart3 size={18} />} />
        <StatCard label="Overall accuracy" value={summary.accuracy === null ? '—' : `${summary.accuracy}%`} hint={summary.accuracy === null ? 'No attempts yet' : 'Correct ÷ attempted'} icon={<TrendingUp size={18} />} tone="ok" />
        <StatCard label="Average paper score" value={summary.averageScorePercent === null ? '—' : `${summary.averageScorePercent}%`} hint={summary.bestScorePercent === null ? 'Your best will show here' : `Best: ${summary.bestScorePercent}%`} icon={<BarChart3 size={18} />} />
        <StatCard label="Study time (30 days)" value={formatMinutes(summary.studyMinutes)} hint={`Across ${summary.studyDays} active days`} icon={<BarChart3 size={18} />} tone="warn" />
      </div>

      {!hasTests ? (
        <Card>
          <EmptyState
            icon={<TrendingUp size={22} />}
            title="No performance data yet"
            description="Charts here are drawn only from your own submitted tests and logged study sessions — nothing is fabricated. Take a diagnostic to start the record."
            action={<Link to="/tests"><Button>Create a diagnostic test</Button></Link>}
          />
        </Card>
      ) : (
        <>
          <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <Card>
              <SectionHeading title="Accuracy over time" subtitle="Every point is a submitted paper" />
              <TrendChart data={data.trend.map((t) => ({ date: t.date, accuracy: t.accuracy }))} height={250} />
              <div className="mt-3 space-y-1.5 border-t border-line pt-3">
                {data.trend.slice().reverse().slice(0, 5).map((t) => (
                  <Link key={t.attemptId} to={`/attempts/${t.attemptId}`} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-xs hover:bg-elevated/50">
                    <span className="truncate text-ink">{t.title}</span>
                    <span className="flex shrink-0 items-center gap-2">
                      <span className="text-muted">{t.percent}%</span>
                      {t.change !== null && (
                        <Badge tone={t.change >= 0 ? 'ok' : 'bad'}>{t.change >= 0 ? '+' : ''}{t.change} pts</Badge>
                      )}
                    </span>
                  </Link>
                ))}
              </div>
            </Card>
            <Card>
              <SectionHeading title="Subject accuracy" subtitle="Where marks are leaking" />
              <SubjectBars data={data.subjects.map((s) => ({ subject: s.subject, accuracy: s.accuracy }))} height={250} />
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <Card>
              <SectionHeading title="Mistake patterns" subtitle="All attempts combined" />
              {data.mistakes.length ? <MistakeBars data={data.mistakes.map((m) => ({ type: MISTAKE_LABELS[m.type] ?? m.type, count: m.count }))} height={240} /> : <p className="text-sm text-muted">No mistakes classified yet.</p>}
            </Card>
            <Card>
              <SectionHeading title="Difficulty profile" subtitle="Accuracy by question difficulty" />
              <DifficultyRadar data={data.difficulties.map((d) => ({ difficulty: d.difficulty, accuracy: d.accuracy }))} height={240} />
            </Card>
            <Card>
              <SectionHeading title="Study consistency" subtitle="Minutes logged per day" />
              {data.studyByDay.length ? <HoursChart data={data.studyByDay} height={240} /> : <p className="text-sm text-muted">No study sessions logged yet. Use the focus timer or complete planner sessions.</p>}
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <SectionHeading title="Chapter weakness map" subtitle="Lowest accuracy across all papers" />
              <div className="max-h-80 space-y-2 overflow-y-auto pr-1 scroll-thin">
                {data.chapters.slice(0, 20).map((ch) => (
                  <div key={`${ch.subject}-${ch.chapter}`}>
                    <div className="mb-1 flex items-center justify-between gap-2 text-xs">
                      <span className="truncate text-ink">{ch.chapter} <span className="text-muted">· {ch.subject}</span></span>
                      <span className="shrink-0 text-muted">{ch.correct}/{ch.total} · {ch.accuracy}%</span>
                    </div>
                    <ProgressBar value={ch.accuracy} tone={ch.accuracy >= 70 ? 'ok' : ch.accuracy >= 40 ? 'warn' : 'bad'} height="h-1.5" />
                  </div>
                ))}
                {data.chapters.length === 0 && <p className="text-sm text-muted">Chapter data appears after your first evaluated test.</p>}
              </div>
            </Card>

            <Card>
              <SectionHeading title="Paper scores" subtitle="Percentage per submitted test" />
              <ScoreLine data={data.trend.map((t) => ({ title: t.title, percent: t.percent }))} height={240} />
            </Card>
          </div>

          <Card>
            <SectionHeading title="Syllabus mastery" subtitle="From your chapter tracker, not estimates" />
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {data.subjectProgress.map((s) => (
                <div key={s.subject} className="rounded-xl border border-line bg-elevated/30 p-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-ink">{s.subject}</span>
                    <span className="text-muted">{s.mastery}%</span>
                  </div>
                  <ProgressBar value={s.mastery} className="mt-2" height="h-1.5" />
                  <p className="mt-1.5 text-[10px] text-muted">{s.confident} of {s.chapters} chapters confident</p>
                </div>
              ))}
            </div>
          </Card>
        </>
      )}

      <Card>
        <SectionHeading title="Revision health" subtitle="Cards are scheduled by your recall, not by a fixed calendar" />
        <div className="flex flex-wrap items-center gap-4">
          <div className="text-sm text-muted">
            <span className="font-display text-2xl font-bold text-ink">{summary.revisionReviewed}</span> of {summary.revisionCards} cards reviewed at least once
          </div>
          <Button variant="secondary" className="ml-auto" onClick={() => window.location.assign('/revision')}>Open revision centre</Button>
        </div>
        <ProgressBar className="mt-3" value={summary.revisionCards ? (summary.revisionReviewed / summary.revisionCards) * 100 : 0} />
      </Card>
    </div>
  );
}
