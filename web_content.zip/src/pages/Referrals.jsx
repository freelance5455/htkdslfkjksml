import React from 'react';
import { CalsenBase } from '../lib/CalsenBase';
import { go, ROUTES, css } from '../lib/calsen';
import BottomNav from '../components/BottomNav';

export default class ReferralsPage extends CalsenBase {
  static defaultProps = {"accent": "#FF5C00", "theme": "sync", "friends": "2", "device": "new"};

  renderVals() {
    const s = this.state || {};
    const mode = this.modeNow();
    const dark = this.isDark(mode);
    const base = this.props.accent ?? '#FF5C00';
    const accent = this.accentFor(base, dark);
    const accentInk = dark ? '#FF9A5C' : '#C2410C';
    const fmt = (n) => Number(n).toLocaleString('en-US');
    const CODE = 'PLATE-7K4Q';
    const friends = Math.max(0, Math.min(10, parseInt(this.props.friends ?? '2', 10) || 0));
    const deviceUsed = (this.props.device ?? 'new') === 'used';
    const redeemed = !!s.redeemed;
    const codeIn = s.codeIn || '';
    const err = s.err || '';
    const copied = !!s.copied;

    const SUNI = 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M12 3v2 M12 19v2 M3 12h2 M19 12h2 M5.6 5.6l1.4 1.4 M17 17l1.4 1.4 M5.6 18.4L7 17 M17 7l1.4-1.4';
    const MOONI = 'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z';
    const GIFT = 'M20 12v9H4v-9 M2 7h20v5H2z M12 22V7 M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7z M12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z';
    const SCAN = 'M3 7V5a2 2 0 0 1 2-2h2 M17 3h2a2 2 0 0 1 2 2v2 M21 17v2a2 2 0 0 1-2 2h-2 M7 21H5a2 2 0 0 1-2-2v-2 M7 12h10';
    const MEDAL = 'M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12z M8.2 13.5L7 22l5-3 5 3-1.2-8.5';
    const CROWN = 'M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z';

    const T = [
      { n: 1, days: 10, label: '1 friend', reward: '10 days', title: '+10 free Premium days', icon: GIFT, short: '10 free Premium days' },
      { n: 3, days: 30, label: '3 friends', reward: '1 month', title: '1 month free + AI Smart Food Scanner', icon: SCAN, short: '1 month free and the AI Smart Food Scanner' },
      { n: 5, days: 90, label: '5 friends', reward: '3 months', title: '3 months free + Ambassador badge', icon: MEDAL, short: '3 months free and your Ambassador badge' },
      { n: 10, days: 0, label: '10 friends', reward: 'Lifetime', title: 'Lifetime VIP access', icon: CROWN, short: 'Lifetime VIP access' }
    ];
    const nextIdx = T.findIndex((t) => friends < t.n);
    const lifetime = friends >= 10;
    const tierDays = T.reduce((a, t) => a + (friends >= t.n ? t.days : 0), 0);
    const total = tierDays + (redeemed ? 10 : 0);

    let pos;
    if (friends <= 1) pos = friends * 12.5;
    else if (friends <= 3) pos = 12.5 + ((friends - 1) / 2) * 25;
    else if (friends <= 5) pos = 37.5 + ((friends - 3) / 2) * 25;
    else pos = 62.5 + ((friends - 5) / 5) * 25;
    const fillPct = Math.round((pos / 87.5) * 100) + '%';

    const nodes = T.map((t, i) => {
      const done = friends >= t.n;
      const next = i === nextIdx;
      return {
        isDone: done,
        isOpen: !done,
        num: String(t.n),
        border: done ? '2px solid ' + accent : next ? '2px solid ' + accent : '2px solid var(--edge)',
        bg: done ? accent : next ? 'var(--glass)' : 'var(--chip)',
        ink: done ? 'var(--on-accent)' : next ? accentInk : 'var(--muted)',
        glow: done && dark ? '0 0 12px ' + this.glowOf(accent, 0.55) : 'none',
        label: t.label,
        labelInk: done || next ? 'var(--ink)' : 'var(--muted)',
        reward: t.reward
      };
    });

    const tiers = T.map((t, i) => {
      const done = friends >= t.n;
      const next = i === nextIdx;
      return {
        title: t.title,
        icon: t.icon,
        sub: done ? 'Tier ' + (i + 1) + ' \u00b7 Unlocked' : 'Tier ' + (i + 1) + ' \u00b7 Invite ' + t.label,
        subInk: done ? 'var(--ok-ink)' : 'var(--muted)',
        tileBg: done ? accent : next ? 'var(--soft-bg)' : 'var(--chip)',
        tileInk: done ? 'var(--on-accent)' : next ? accentInk : 'var(--muted)',
        tileGlow: done && dark ? '0 0 14px ' + this.glowOf(accent, 0.5) : 'none',
        opacity: !done && !next ? '0.82' : '1',
        isDone: done,
        isLocked: !done && !next,
        isNext: next,
        count: friends + ' of ' + t.n,
        w: Math.round((friends / t.n) * 100) + '%',
        have: String(friends),
        need: String(t.n),
        aria: friends + ' of ' + t.n + ' friends invited'
      };
    });

    let nextText;
    if (nextIdx === -1) nextText = 'Every reward unlocked. Thanks for spreading the word.';
    else {
      const need = T[nextIdx].n - friends;
      nextText = need + ' more ' + (need === 1 ? 'friend unlocks ' : 'friends unlock ') + T[nextIdx].short + '.';
    }

    const msg = 'I track my meals with CalSen. Use my code ' + CODE + ' when you sign up and get 10 free Premium days.';
    const redeemNow = () => {
      const c = (this.state || {}).codeIn || '';
      if (!c || (this.state || {}).redeemed) return;
      if (c === CODE) this.setState({ err: 'That is your own code. Share it with a friend instead.' });
      else if (c.length < 6) this.setState({ err: 'This code looks too short. Check it and try again.' });
      else if (deviceUsed) this.setState({ err: 'This device has already redeemed a code. Each device can redeem one.' });
      else this.setState({ redeemed: true, err: '' });
    };
    const empty = codeIn.length === 0;

    return {
      accent,
      accentInk,
      glow: this.glowOf(accent, dark ? 0.45 : 0.3),
      themeKey: dark ? 'dark' : 'light',
      themeIcon: dark ? SUNI : MOONI,
      themeAria: dark ? 'Switch to light mode' : 'Switch to dark mode',
      toggleTheme: () => this.setMode(dark ? 'light' : 'dark'),
      heroShadow: dark ? '0 0 32px ' + this.glowOf(accent, 0.28) : '0 10px 24px ' + this.glowOf(accent, 0.28),
      dashEdge: dark ? 'rgba(11,15,23,.4)' : 'rgba(255,255,255,.65)',
      code: CODE,
      copyLabel: copied ? 'Copied' : 'Copy code',
      copyIcon: copied ? 'M5 12.5l4.5 4.5L19 7.5' : 'M9 9h10v11H9z M5 15V4h10',
      copyCode: () => {
        try { if (navigator.clipboard) navigator.clipboard.writeText(CODE).catch(() => {}); } catch (e) {}
        this.setState({ copied: true });
        setTimeout(() => { this.setState({ copied: false }); }, 2000);
      },
      waHref: 'https://wa.me/?text=' + encodeURIComponent(msg),
      friends: String(friends),
      daysEarned: lifetime ? 'Lifetime' : fmt(total),
      daysLabel: lifetime ? 'VIP access' : 'Free days earned',
      numGlow: dark ? '0 0 18px ' + this.glowOf(accent, 0.45) : 'none',
      fillPct,
      barGlow: dark ? '0 0 12px ' + this.glowOf(accent, 0.6) : 'none',
      nodes,
      nextText,
      nextIcon: nextIdx === -1 ? 'M5 12.5l4.5 4.5L19 7.5' : 'M13 2L4 14h7l-1 8 9-12h-7z',
      codeIn,
      onCode: (e) => this.setState({ codeIn: String(e.target.value).toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 12), err: '' }),
      onKey: (e) => { if (e.key === 'Enter') redeemNow(); },
      redeem: redeemNow,
      inputOff: redeemed,
      inputOpacity: redeemed ? '0.6' : '1',
      inputEdge: err ? 'var(--danger)' : 'var(--edge)',
      redeemOff: empty || redeemed,
      redeemLabel: redeemed ? 'Redeemed' : 'Redeem',
      redeemBg: empty || redeemed ? 'var(--chip)' : accent,
      redeemInk: empty || redeemed ? 'var(--muted)' : 'var(--on-accent)',
      redeemOpacity: '1',
      hasErr: err !== '',
      err,
      redeemed,
      showIdle: err === '' && !redeemed,
      tiers
    };
  }

  render() {
    const v = this.renderVals();
    return (
      <div
        className="app"
        data-theme={v.themeKey}
        style={{
          position: 'relative',
          width: '390px',
          height: '844px',
          boxSizing: 'border-box',
          fontFamily: '\'Plus Jakarta Sans\', system-ui, sans-serif',
          overflow: 'hidden',
        }}
      >
        <div
          className="scroll"
          style={{
            position: 'absolute',
            left: '0',
            top: '0',
            right: '0',
            bottom: '0',
            overflowY: 'auto',
            overflowX: 'hidden',
            overscrollBehavior: 'contain',
          }}
        >
          <div
            className="stagger"
            style={{
              boxSizing: 'border-box',
              padding: '24px 20px 112px 20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
            }}
          >
            <header style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <a
                href={ROUTES.profile}
                className="rbtn"
                aria-label="Back to settings"
                onClick={(e) => { go(e, 'profile', this.props); }}
              >
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M15 5l-7 7 7 7"></path>
                </svg>
              </a>
              <h1
                style={{
                  flex: '1',
                  margin: '0',
                  fontSize: '22px',
                  lineHeight: '28px',
                  fontWeight: '800',
                  letterSpacing: '-0.03em',
                }}
              >Referral &amp; Rewards</h1>
              <button className="rbtn" aria-label={v.themeAria} onClick={v.toggleTheme}>
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d={v.themeIcon}></path>
                </svg>
              </button>
            </header>
            <section
              aria-label="Your referral code"
              style={{
                borderRadius: '24px',
                padding: '20px',
                background: v.accent,
                color: 'var(--on-accent)',
                boxShadow: v.heroShadow,
                display: 'flex',
                flexDirection: 'column',
                gap: '16px',
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <h2
                  style={{
                    margin: '0',
                    fontSize: '22px',
                    lineHeight: '28px',
                    fontWeight: '800',
                    letterSpacing: '-0.02em',
                  }}
                >Invite friends, get Premium free</h2>
                <p
                  style={{
                    margin: '0',
                    fontSize: '14px',
                    lineHeight: '20px',
                    fontWeight: '600',
                    opacity: '0.85',
                  }}
                >
                  Every friend who joins with your code starts with 10 free trial days.
                </p>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '12px',
                  border: `1.5px dashed ${v.dashEdge}`,
                  borderRadius: '16px',
                  padding: '12px 14px 12px 16px',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '2px',
                    minWidth: '0',
                  }}
                >
                  <span style={{ fontSize: '12px', fontWeight: '700', opacity: '0.8' }}>Your code</span>
                  <span
                    style={{
                      fontSize: '26px',
                      lineHeight: '32px',
                      fontWeight: '800',
                      letterSpacing: '0.1em',
                    }}
                  >{v.code}</span>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  className="press"
                  style={{
                    flex: '1',
                    height: '48px',
                    borderRadius: '24px',
                    border: '0',
                    background: 'var(--on-accent)',
                    color: v.accentInk,
                    fontSize: '15px',
                    fontWeight: '800',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                  }}
                  onClick={v.copyCode}
                >
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d={v.copyIcon}></path>
                  </svg>
                  <span aria-live="polite">{v.copyLabel}</span>
                </button>
                <a
                  className="press"
                  href={v.waHref}
                  target="_blank"
                  rel="noopener"
                  aria-label="Share your code on WhatsApp"
                  style={{
                    flex: '1',
                    height: '48px',
                    borderRadius: '24px',
                    background: '#25D366',
                    color: '#052E16',
                    fontSize: '15px',
                    fontWeight: '800',
                    textDecoration: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                  }}
                >
                  <svg
                    width="19"
                    height="19"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2-5.4A8.4 8.4 0 1 1 21 11.5z"></path>
                    <path d="M9.2 8.8c.2 2.6 3 5.3 5.8 5.8l1.4-1.5-2.2-1.1-1 .9c-.9-.4-1.9-1.4-2.3-2.3l.9-1-1.1-2.2z"></path>
                  </svg>
                  WhatsApp{' '}
                </a>
              </div>
            </section>
            <section
              aria-label="Your progress"
              className="glass"
              style={{
                borderRadius: '24px',
                padding: '18px 18px 20px 18px',
                display: 'flex',
                flexDirection: 'column',
                gap: '18px',
              }}
            >
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', alignItems: 'end' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px' }}>
                    <span
                      style={{
                        fontSize: '40px',
                        lineHeight: '44px',
                        fontWeight: '800',
                        letterSpacing: '-0.04em',
                      }}
                    >{v.friends}</span>
                    <span style={{ fontSize: '16px', fontWeight: '700', color: 'var(--muted)' }}>/ 10</span>
                  </div>
                  <div style={{ fontSize: '13px', fontWeight: '600', color: 'var(--muted)' }}>Friends joined</div>
                </div>
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px',
                    paddingLeft: '18px',
                    borderLeft: '1px solid var(--line)',
                  }}
                >
                  <div
                    style={{
                      fontSize: '40px',
                      lineHeight: '44px',
                      fontWeight: '800',
                      letterSpacing: '-0.04em',
                      color: v.accentInk,
                      textShadow: v.numGlow,
                    }}
                  >{v.daysEarned}</div>
                  <div style={{ fontSize: '13px', fontWeight: '600', color: 'var(--muted)' }}>{v.daysLabel}</div>
                </div>
              </div>
              <div style={{ position: 'relative' }}>
                <div
                  aria-hidden="true"
                  style={{
                    position: 'absolute',
                    left: '0',
                    width: '87.5%',
                    top: '13px',
                    height: '6px',
                    borderRadius: '3px',
                    background: 'var(--track)',
                    overflow: 'hidden',
                  }}
                >
                  <div
                    className="fill"
                    style={{
                      width: v.fillPct,
                      height: '100%',
                      borderRadius: '3px',
                      background: v.accent,
                      boxShadow: v.barGlow,
                    }}
                  ></div>
                </div>
                <ol
                  style={{
                    position: 'relative',
                    listStyle: 'none',
                    margin: '0',
                    padding: '0',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
                  }}
                >
                  {v.nodes.map((n, i1) => (
                    <React.Fragment key={i1}>
                      <li
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center',
                          gap: '8px',
                          textAlign: 'center',
                        }}
                      >
                        <span
                          style={{
                            width: '32px',
                            height: '32px',
                            boxSizing: 'border-box',
                            borderRadius: '16px',
                            border: n.border,
                            background: n.bg,
                            color: n.ink,
                            boxShadow: n.glow,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '13px',
                            fontWeight: '800',
                          }}
                        >
                          {n.isDone && (
                            <>
                              <svg
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="3"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                aria-hidden="true"
                              >
                                <path d="M5 12.5l4.5 4.5L19 7.5"></path>
                              </svg>
                            </>
                          )}
                          {n.isOpen && (
                            <>
                              {n.num}
                            </>
                          )}
                        </span>
                        <span style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
                          <span
                            style={{
                              fontSize: '12px',
                              lineHeight: '16px',
                              fontWeight: '700',
                              color: n.labelInk,
                            }}
                          >{n.label}</span>
                          <span
                            style={{
                              fontSize: '12px',
                              lineHeight: '16px',
                              fontWeight: '600',
                              color: 'var(--muted)',
                            }}
                          >{n.reward}</span>
                        </span>
                      </li>
                    </React.Fragment>
                  ))}
                </ol>
              </div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  borderRadius: '14px',
                  padding: '10px 12px',
                  background: 'var(--soft-bg)',
                  color: 'var(--soft-ink)',
                  fontSize: '13px',
                  lineHeight: '18px',
                  fontWeight: '700',
                }}
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                  style={{ flex: 'none' }}
                >
                  <path d={v.nextIcon}></path>
                </svg>
                <span>{v.nextText}</span>
              </div>
            </section>
            <section
              aria-label="Redeem a friend's code"
              className="glass"
              style={{
                borderRadius: '24px',
                padding: '18px',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <h2
                  style={{
                    margin: '0',
                    fontSize: '18px',
                    lineHeight: '24px',
                    fontWeight: '800',
                    letterSpacing: '-0.01em',
                  }}
                >Have a friend's code?</h2>
                <p
                  style={{
                    margin: '0',
                    fontSize: '14px',
                    lineHeight: '20px',
                    color: 'var(--muted)',
                  }}
                >Enter it to get 10 free trial days.</p>
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <input
                  className="code-in"
                  id="redeem-code"
                  type="text"
                  value={v.codeIn}
                  onChange={v.onCode}
                  onKeyDown={v.onKey}
                  disabled={v.inputOff}
                  placeholder="Friend's code"
                  maxLength="12"
                  autoComplete="off"
                  autoCapitalize="characters"
                  aria-label="Friend's referral code"
                  aria-invalid={v.hasErr}
                  style={{
                    flex: '1',
                    minWidth: '0',
                    height: '48px',
                    boxSizing: 'border-box',
                    borderRadius: '16px',
                    border: `1.5px solid ${v.inputEdge}`,
                    background: 'var(--chip)',
                    color: 'var(--ink)',
                    padding: '0 14px',
                    fontSize: '16px',
                    fontWeight: '800',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    opacity: v.inputOpacity,
                  }}
                 />
                <button
                  className="press"
                  disabled={v.redeemOff}
                  style={{
                    height: '48px',
                    padding: '0 20px',
                    borderRadius: '24px',
                    border: '0',
                    background: v.redeemBg,
                    color: v.redeemInk,
                    fontSize: '15px',
                    fontWeight: '800',
                    cursor: 'pointer',
                    opacity: v.redeemOpacity,
                  }}
                  onClick={v.redeem}
                >{v.redeemLabel}</button>
              </div>
              {v.showIdle && (
                <>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '13px',
                      lineHeight: '18px',
                      color: 'var(--muted)',
                    }}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                      style={{ flex: 'none', marginTop: '1px' }}
                    >
                      <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"></path>
                      <path d="M9 12l2 2 4-4"></path>
                    </svg>
                    <span>One code per device. We check this to keep rewards fair.</span>
                  </div>
                </>
              )}
              {v.hasErr && (
                <>
                  <div
                    className="fadein"
                    role="alert"
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      borderRadius: '12px',
                      padding: '10px 12px',
                      background: 'var(--danger-bg)',
                      color: 'var(--danger)',
                      fontSize: '13px',
                      lineHeight: '18px',
                      fontWeight: '700',
                    }}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                      style={{ flex: 'none', marginTop: '1px' }}
                    >
                      <circle cx="12" cy="12" r="9"></circle>
                      <path d="M12 8v5"></path>
                      <path d="M12 16.5v.01"></path>
                    </svg>
                    <span>{v.err}</span>
                  </div>
                </>
              )}
              {v.redeemed && (
                <>
                  <div
                    className="fadein"
                    role="status"
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      borderRadius: '12px',
                      padding: '10px 12px',
                      background: 'var(--ok-bg)',
                      color: 'var(--ok-ink)',
                      fontSize: '13px',
                      lineHeight: '18px',
                      fontWeight: '700',
                    }}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                      style={{ flex: 'none', marginTop: '1px' }}
                    >
                      <path d="M5 12.5l4.5 4.5L19 7.5"></path>
                    </svg>
                    <span>10 free days added to your trial.</span>
                  </div>
                </>
              )}
            </section>
            <section aria-label="Reward tiers" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <h2
                style={{
                  margin: '0 0 2px 2px',
                  fontSize: '18px',
                  lineHeight: '24px',
                  fontWeight: '800',
                  letterSpacing: '-0.01em',
                }}
              >Rewards</h2>
              {v.tiers.map((t, i1) => (
                <React.Fragment key={i1}>
                  <div
                    className="glass"
                    style={{
                      borderRadius: '20px',
                      padding: '14px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      opacity: t.opacity,
                    }}
                  >
                    <div
                      aria-hidden="true"
                      style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '16px',
                        background: t.tileBg,
                        color: t.tileInk,
                        boxShadow: t.tileGlow,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flex: 'none',
                      }}
                    >
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.9"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d={t.icon}></path>
                      </svg>
                    </div>
                    <div
                      style={{
                        flex: '1',
                        minWidth: '0',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '2px',
                      }}
                    >
                      <div
                        style={{
                          fontSize: '15px',
                          lineHeight: '20px',
                          fontWeight: '800',
                          letterSpacing: '-0.01em',
                        }}
                      >{t.title}</div>
                      <div
                        style={{
                          fontSize: '13px',
                          lineHeight: '18px',
                          fontWeight: '600',
                          color: t.subInk,
                        }}
                      >{t.sub}</div>
                      {t.isNext && (
                        <>
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                              marginTop: '6px',
                            }}
                          >
                            <div
                              role="progressbar"
                              aria-label={t.aria}
                              aria-valuemin="0"
                              aria-valuemax={t.need}
                              aria-valuenow={t.have}
                              style={{
                                flex: '1',
                                height: '6px',
                                borderRadius: '3px',
                                background: 'var(--track)',
                                overflow: 'hidden',
                              }}
                            >
                              <div
                                style={{
                                  width: t.w,
                                  height: '100%',
                                  borderRadius: '3px',
                                  background: v.accent,
                                }}
                              ></div>
                            </div>
                            <span style={{ fontSize: '12px', fontWeight: '800', color: v.accentInk }}>{t.count}</span>
                          </div>
                        </>
                      )}
                    </div>
                    {t.isDone && (
                      <>
                        <span
                          aria-label="Unlocked"
                          style={{
                            width: '28px',
                            height: '28px',
                            borderRadius: '14px',
                            background: 'var(--ok-bg)',
                            color: 'var(--ok-ink)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flex: 'none',
                          }}
                        >
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            aria-hidden="true"
                          >
                            <path d="M5 12.5l4.5 4.5L19 7.5"></path>
                          </svg>
                        </span>
                      </>
                    )}
                    {t.isLocked && (
                      <>
                        <span
                          aria-label="Locked"
                          style={{
                            width: '28px',
                            height: '28px',
                            borderRadius: '14px',
                            background: 'var(--chip)',
                            color: 'var(--muted)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flex: 'none',
                          }}
                        >
                          <svg
                            width="15"
                            height="15"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            aria-hidden="true"
                          >
                            <path d="M6 11h12v9H6z"></path>
                            <path d="M8 11V8a4 4 0 0 1 8 0v3"></path>
                          </svg>
                        </span>
                      </>
                    )}
                  </div>
                </React.Fragment>
              ))}
              <p
                style={{
                  margin: '4px 2px 0 2px',
                  fontSize: '12px',
                  lineHeight: '17px',
                  color: 'var(--muted)',
                }}
              >
                A friend counts once they sign up with your code. Rewards stack as you unlock tiers.
              </p>
            </section>
          </div>
        </div>
        <BottomNav active="profile" accent={v.accent} glow={v.glow} onNavigate={this.props.onNavigate} />
      </div>
    );
  }
}
