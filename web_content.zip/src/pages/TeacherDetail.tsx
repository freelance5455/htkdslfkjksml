import { useState } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { BadgeCheck, Clock3, ListVideo, Quote } from 'lucide-react';
import { getSubject } from '../data/content';
import { useProfile } from '../hooks/useProfile';
import { useSettings } from '../hooks/useSettings';
import { getProgressMap } from '../services/progress';
import { PageHeader } from '../components/layout/PageHeader';
import { SubjectGlyph, TeacherAvatar } from '../components/content/SubjectBits';
import { Badge } from '../components/ui/Feedback';
import { VideoPlayer } from '../components/player/VideoPlayer';
import { TeacherUploadsPlaylist } from '../components/player/TeacherUploadsPlaylist';
import { formatDuration } from '../utils/format';

export default function TeacherDetail() {
  const { subjectId = '', teacherId = '' } = useParams();
  const subject = getSubject(subjectId);
  const teacher = subject?.teachers.find((t) => t.id === teacherId);
  const { profile, selectTeacher } = useProfile();
  const { settings, update } = useSettings();
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [uploadsOpenForTeacherId, setUploadsOpenForTeacherId] = useState<string | null>(null);
  const uploadsOpen = Boolean(teacher && uploadsOpenForTeacherId === teacher.id);

  if (!subject || !teacher) return <Navigate to="/subjects" replace />;

  const lessons = subject.units
    .flatMap((u) => u.lessons.map((l) => ({ lesson: l, unit: u })))
    .filter(({ lesson }) => lesson.teacherId === teacher.id || lesson.alternates?.some((a) => a.teacherId === teacher.id));
  const progressMap = getProgressMap();
  const isSelected = profile.teacherBySubject[subject.id] === teacher.id;
  const verifiedVideos = teacher.verifiedVideos ?? [];
  const isVerifiedSource = Boolean(teacher.channelUrl && (verifiedVideos.length > 0 || teacher.uploadsPlaylistId));

  return (
    <div>
      <PageHeader title={teacher.name} subtitle={teacher.headline} back={`/subject/${subject.id}`} />

      <div className="card mb-4 p-4">
        <div className="flex items-start gap-3">
          <TeacherAvatar teacher={teacher} size={64} />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="truncate font-display text-base text-[var(--ink)]">{teacher.name}</p>
              {isVerifiedSource ? <BadgeCheck size={15} aria-label="مصدر موثق" className="shrink-0 text-[var(--success)]" /> : null}
            </div>
            <p className="mt-0.5 text-[0.72rem] text-[var(--ink-soft)]">
              {subject.name} · {isVerifiedSource ? 'مصدر تعليمي موثق' : 'ملف توضيحي تجريبي'}
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <Badge tone="neutral">{teacher.style}</Badge>
              {teacher.channelUrl && teacher.years ? <Badge tone="neutral">{teacher.years} سنة خبرة</Badge> : null}
              {lessons.length > 0 ? <Badge tone="gold">{lessons.length} درس مرتبط</Badge> : null}
              {verifiedVideos.length > 0 ? <Badge tone="success">{verifiedVideos.length} مقطع موثق</Badge> : null}
              {teacher.uploadsPlaylistId ? <Badge tone="neutral">مكتبة القناة كاملة</Badge> : null}
            </div>
          </div>
        </div>
        <p className="mt-3 text-[0.8rem] leading-relaxed text-[var(--ink-soft)]">{teacher.bio}</p>
        {teacher.channelLabel ? (
          <p className="mt-2 text-[0.7rem] text-[var(--ink-soft)]">
            القناة/المنصة المرتبطة: <span className="font-medium text-[var(--ink)]">{teacher.channelLabel}</span>
          </p>
        ) : null}
        <div className="mt-3 flex items-center gap-2">
          {lessons.length > 0 ? (
            <button
              type="button"
              onClick={() => selectTeacher(subject.id, teacher.id)}
              className="focus-ring min-h-11 flex-1 rounded-full bg-[var(--brand)] px-3 text-[0.78rem] font-medium text-[var(--brand-ink)]"
            >
              {isSelected ? 'هذا مدرّسي الحالي ✓' : `اعتمد شرح ${teacher.name.split(' ')[1] ?? 'المدرّس'}`}
            </button>
          ) : (
            <p className="flex min-h-11 flex-1 items-center rounded-full bg-[var(--surface-2)] px-3 text-[0.68rem] text-[var(--ink-soft)]">
              مقاطع هذه القناة متاحة للمشاهدة؛ لم تُربط بعد بدروس المنهاج.
            </p>
          )}
          <Link
            to={`/subject/${subject.id}`}
            className="focus-ring flex min-h-11 items-center rounded-full border border-[var(--line)] px-3 text-[0.72rem] text-[var(--ink)]"
          >
            وحدات المادة
          </Link>
        </div>
      </div>

      {verifiedVideos.length > 0 ? (
        <section className="mb-5" aria-labelledby="verified-teacher-videos">
          <div className="mb-2 flex items-center justify-between gap-2">
            <div>
              <h2 id="verified-teacher-videos" className="font-display text-base text-[var(--ink)]">مقاطع موثقة من القناة</h2>
              <p className="mt-0.5 text-[0.68rem] text-[var(--ink-soft)]">تُشغّل داخل مشغّل منارة، ولا تنقلك إلى موقع خارجي.</p>
            </div>
            <SubjectGlyph subject={subject} size="sm" />
          </div>
          <div className="space-y-2">
            {verifiedVideos.map((video) => {
              const isOpen = activeVideoId === video.id;
              return (
                <article key={video.id} className="card p-3">
                  <h3 className="text-[0.82rem] font-medium leading-relaxed text-[var(--ink)]">{video.title}</h3>
                  <p className="mt-1 text-[0.68rem] leading-relaxed text-[var(--ink-soft)]">{video.lessonLabel}</p>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => {
                      if (isOpen) {
                        setActiveVideoId(null);
                      } else {
                        setUploadsOpenForTeacherId(null);
                        setActiveVideoId(video.id);
                      }
                    }}
                    className="focus-ring mt-3 min-h-11 w-full rounded-full border border-[var(--line)] px-3 text-[0.75rem] font-medium text-[var(--ink)]"
                  >
                    {isOpen ? 'إخفاء المشغّل' : 'اعرض المشغّل داخل التطبيق'}
                  </button>
                  {isOpen ? (
                    <div className="mt-3 overflow-hidden rounded-2xl">
                      <VideoPlayer
                        key={video.videoId}
                        videoId={video.videoId}
                        title={video.title}
                        settings={settings}
                        onSettingsChange={update}
                        autoPlayNext={false}
                      />
                    </div>
                  ) : null}
                </article>
              );
            })}
          </div>
          <p className="mt-2 text-[0.65rem] leading-relaxed text-[var(--ink-soft)]">
            قد يمنع ناشر الفيديو تضمينه؛ عندئذٍ تظهر رسالة المشغّل ولا يحدث تحويل تلقائي إلى YouTube.
          </p>
        </section>
      ) : null}

      {teacher.uploadsPlaylistId ? (
        <section className="mb-5" aria-labelledby="teacher-uploads-title">
          <div className="card p-3">
            <div className="flex items-start gap-2">
              <ListVideo size={18} className="mt-0.5 shrink-0 text-[var(--brand)]" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <h2 id="teacher-uploads-title" className="font-display text-base text-[var(--ink)]">
                  جميع فيديوهات القناة العامة
                </h2>
                <p className="mt-1 text-[0.7rem] leading-relaxed text-[var(--ink-soft)]">
                  قائمة الرفع العامة التي يقدمها YouTube لقناة {teacher.name}، وتتحدث مع المقاطع الجديدة.
                </p>
              </div>
            </div>
            <button
              type="button"
              aria-expanded={uploadsOpen}
              aria-controls="teacher-uploads-player"
              onClick={() => {
                const nextOpen = !uploadsOpen;
                setUploadsOpenForTeacherId(nextOpen ? teacher.id : null);
                if (nextOpen) setActiveVideoId(null);
              }}
              className="focus-ring mt-3 flex min-h-11 w-full items-center justify-center gap-2 rounded-full border border-[var(--line)] px-3 text-[0.75rem] font-medium text-[var(--ink)]"
            >
              <ListVideo size={15} aria-hidden="true" />
              {uploadsOpen ? 'إخفاء قائمة القناة' : 'افتح قائمة الرفع الكاملة داخل التطبيق'}
            </button>
            {uploadsOpen ? (
              <div id="teacher-uploads-player" className="mt-3 overflow-hidden rounded-2xl">
                <TeacherUploadsPlaylist playlistId={teacher.uploadsPlaylistId} channelName={teacher.name} />
              </div>
            ) : null}
            <p className="mt-2 text-[0.66rem] leading-relaxed text-[var(--ink-soft)]">
              لا يُحمّل المشغّل حتى تضغط الزر. قد تضم القائمة دروساً من صفوف أو موضوعات أخرى؛ المقاطع الموثقة للمنهاج
              معروضة أعلاه بشكل منفصل. هذه قائمة الفيديوهات العامة التي يتيحها YouTube، ولا تشمل الخاص أو المحذوف؛ تخضع كل المقاطع
              لإعدادات صاحب القناة وقيود YouTube على التضمين.
            </p>
          </div>
        </section>
      ) : null}

      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-display text-base text-[var(--ink)]">دروسه المرتبطة بالمنهاج</h2>
        <SubjectGlyph subject={subject} size="sm" />
      </div>

      {lessons.length > 0 ? (
        <div className="space-y-2">
          {lessons.map(({ lesson, unit }) => {
            const p = progressMap[lesson.id];
            return (
              <Link
                key={lesson.id}
                to={`/lesson/${subject.id}/${lesson.id}`}
                className="focus-ring card flex min-h-11 items-center gap-3 p-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.82rem] font-medium text-[var(--ink)]">{lesson.title}</p>
                  <p className="mt-0.5 truncate text-[0.65rem] text-[var(--ink-soft)]">{unit.title}</p>
                  <p className="mt-1 flex items-center gap-2 text-[0.63rem] text-[var(--ink-soft)]">
                    <Clock3 size={11} /> {formatDuration(lesson.duration)}
                    {p?.completed ? <span className="text-[var(--success)]">· مكتمل</span> : null}
                    {lesson.alternates?.some((a) => a.teacherId === teacher.id) && lesson.teacherId !== teacher.id ? (
                      <span className="text-[var(--gold)]">· شرح بديل</span>
                    ) : null}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      ) : (
        <p className="card p-3 text-[0.72rem] leading-relaxed text-[var(--ink-soft)]">
          لا توجد دروس وحدات مرتبطة بهذا الملف بعد؛ استخدم المقاطع الموثقة أعلاه للمشاهدة داخل التطبيق.
        </p>
      )}

      <div className="mt-4 rounded-2xl bg-[var(--surface-2)] p-3">
        <p className="flex items-start gap-2 text-[0.72rem] leading-relaxed text-[var(--ink-soft)]">
          <Quote size={14} className="mt-0.5 shrink-0" />
          {isVerifiedSource
            ? 'التحقق يخص صلة القناة أو المنصة بالمحتوى وعنوان المقطع المحدد، ولا يثبت سنوات خبرة أو اعتماداً مهنياً غير منشور.'
            : 'هذا الاسم والملف مثال توضيحي، وليس توصية أو ادعاءً عن مدرس حقيقي.'}
        </p>
      </div>
    </div>
  );
}
