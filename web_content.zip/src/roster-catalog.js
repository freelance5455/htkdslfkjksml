import { LEGENDARY_DAMISTES } from './legacy-catalog.js';

const PLAYER_NAMES = [
  'Aïcha Koné','Moussa Diabaté','Fatou Bamba','Ibrahim Touré','Nadia Coulibaly','Yao Koffi','Mariam Traoré','Karim Ouattara',
  'Aminata Diallo','Sékou Camara','Aya N’Guessan','Ismaël Fofana','Salimata Cissé','Oumar Sanogo','Djeneba Keita','Kader Sylla',
  'Lina Mensah','Kwame Asare','Abena Boateng','Kojo Owusu','Ama Osei','Kofi Appiah','Akua Mensima','Yaw Addo',
  'Léa Moreau','Hugo Bernard','Inès Laurent','Noah Petit','Camille Robert','Lucas Simon','Sarah Michel','Enzo Garcia',
  'Mei Tanaka','Haruto Sato','Yuna Nakamura','Ren Ito','Aiko Suzuki','Daichi Kobayashi','Sora Watanabe','Hana Mori',
  'Amara Okafor','Chidi Nwosu','Zuri Mensah','Kofi Adeyemi','Nia Kamau','Tunde Balogun','Imani Diallo','Malik N’Diaye',
  'Elena Petrova','Milan Novak','Anya Ivanova','Luka Horvat','Sofia Costa','Tiago Silva','Marta Ruiz','Diego Santos',
  'Ravi Patel','Anaya Shah','Arjun Mehta','Priya Rao','Leila Haddad','Omar Mansour','Yasmine Khalil','Samir Benali',
  'Noor Rahman','Adam Walker','Maya Johnson','Ethan Brown','Chloe Davis','Liam Wilson','Zara Khan','Amir Hussein'
];
const GALAXY_SKILLS = ['stratégie','anticipation','maîtrise tactique','vitesse de calcul','défense','vision du jeu'];

function profile(id, name, index, origin) {
  const level = 58 + ((index * 7 + 11) % 35);
  return { id, name, gender: index % 2 ? 'F' : 'M', level, form: 55 + ((index * 11 + 3) % 41), age: 18 + (index * 3 % 19), nationality: ['Terra Unie','Mars Fédérale','Vénus Impériale','Mercure Solaire','Jupiter Majeure','Saturne des Anneaux','Neptune Abyssale','Uranus Glaciale'][index % 8], specialty: GALAXY_SKILLS[index % GALAXY_SKILLS.length], potential: Math.min(99, level + 3 + index % 9), origin };
}

export function populateRosterCatalog(state) {
  let cursor = 0;
  for (const division of state.divisions || []) {
    for (const club of division.clubs || []) {
      club.damistes ??= [];
      club.damistes = Array.from({ length: 2 }, (_, slot) => {
        const existing = club.damistes[slot];
        if (existing && existing.name && !/^Damiste [12]$/.test(existing.name)) return existing;
        const index = cursor++;
        return { ...profile(`${club.id}-d${slot + 1}`, PLAYER_NAMES[index % PLAYER_NAMES.length], index, club.name), ...(existing || {}), id: `${club.id}-d${slot + 1}`, name: PLAYER_NAMES[index % PLAYER_NAMES.length] };
      });
    }
  }
  const galaxies = state.world?.galaxies || [];
  for (let i = 0; i < galaxies.length; i++) {
    const galaxy = galaxies[i];
    galaxy.damistes ??= [0, 1].map(slot => profile(`galaxy-${String(i + 1).padStart(2, '0')}-d${slot + 1}`, PLAYER_NAMES[(i * 2 + slot + 2) % PLAYER_NAMES.length], i * 2 + slot, galaxy.name));
  }
  state.world.legendaryDamistes = (state.world.legendaryDamistes || LEGENDARY_DAMISTES.map(x => ({ ...x }))).map(legend => ({
    ...legend,
    specialty: legend.power,
    potential: 99,
    status: legend.recruitedToClubId ? 'recruited' : (legend.status || 'available'),
    recruitedToClubId: legend.recruitedToClubId || null,
    contractTemplate: legend.contractTemplate || { duration: 3, wage: 25000, signingBonus: 250000, appearanceBonus: 5000, victoryBonus: 15000, releaseClause: 7500000, loyaltyBonus: 100000, noTransfer: false }
  }));
  state.world.rosterCatalogVersion = 1;
  return state;
}

export function getAvailableLegendaryDamistes(state) {
  return (state.world?.legendaryDamistes || []).filter(p => !p.recruitedToClubId && p.status !== 'recruited');
}

export function recruitLegendaryDamiste(state, { legendaryId, replacePlayerId }) {
  const club = (state.divisions || []).flatMap(d => d.clubs || []).find(c => c.id === state.userClubId);
  if (!club) throw new Error('Aucun club dirigé : recrutement impossible.');
  const legend = (state.world?.legendaryDamistes || []).find(p => p.id === legendaryId);
  if (!legend || legend.recruitedToClubId || legend.status === 'recruited') throw new Error('Ce damiste légendaire n’est plus disponible.');
  const index = (club.damistes || []).findIndex(p => p.id === replacePlayerId);
  if (index < 0) throw new Error('Choisis un damiste de ton club à remplacer.');
  const price = Number(legend.price) || 2500000;
  if (Number(club.budget || 0) < price) throw new Error(`Budget insuffisant : ${price.toLocaleString('fr-FR')} Gold sont nécessaires.`);
  const terms = structuredClone(legend.contractTemplate || { duration: 3, wage: 25000, signingBonus: 250000, appearanceBonus: 5000, victoryBonus: 15000, releaseClause: 7500000, loyaltyBonus: 100000, noTransfer: false });
  const contract = { status: 'active', wage: terms.wage, duration: terms.duration, signingBonus: terms.signingBonus, appearanceBonus: terms.appearanceBonus, victoryBonus: terms.victoryBonus, loyaltyBonus: terms.loyaltyBonus, clauses: { releaseClause: terms.releaseClause, noTransfer: terms.noTransfer }, signedSeason: state.season, expiresSeason: state.season + terms.duration };
  const recruited = { ...legend, id: `${legend.id}@${club.id}`, level: 99, form: 90, age: 25, potential: 99, origin: legend.originGalaxy, legendary: true, contract, contractHistory: [{ ...structuredClone(contract), event: 'signature' }] };
  club.damistes[index] = recruited;
  club.budget = Number(club.budget || 0) - price;
  legend.recruitedToClubId = club.id;
  legend.status = 'recruited';
  legend.recruitedPlayerId = recruited.id;
  legend.recruitedAtSeason = state.season;
  return { clubId: club.id, player: recruited, replacedPlayerId: replacePlayerId, price };
}

export function validateRosterCatalog(state) {
  const clubs = (state.divisions || []).flatMap(d => d.clubs || []);
  for (const club of clubs) {
    if (club.damistes?.length !== 2) throw new Error(`Effectif invalide pour ${club.name} : deux damistes requis.`);
    if (club.damistes.some(p => !p.name || !Number.isFinite(Number(p.level)))) throw new Error(`Profil incomplet dans ${club.name}.`);
  }
  if (state.world?.galaxies?.length !== 24 || state.world.galaxies.some(g => g.damistes?.length !== 2)) throw new Error('Chaque galaxie doit posséder exactement deux damistes.');
  if (state.world?.legendaryDamistes?.length !== 24) throw new Error('Le catalogue doit contenir 24 damistes légendaires.');
  return true;
}
