export type DevicePlatform = 'android' | 'ios';

export type AppCategory = 'social' | 'games' | 'entertainment' | 'education' | 'utility' | 'system';

export interface InstalledApp {
  id: string;
  name: string;
  nameAr: string;
  packageName: string;
  icon: string;
  category: AppCategory;
  isBlocked: boolean;
  dailyLimitMinutes: number; // 0 = unlimited
  usedMinutesToday: number;
  installDate: string;
  sizeMb: number;
  version: string;
  isSystemApp: boolean;
}

export interface GeofenceZone {
  id: string;
  name: string;
  nameAr: string;
  lat: number;
  lng: number;
  radiusMeters: number;
  type: 'safe' | 'danger' | 'restricted';
  address: string;
  notifyOnEnter: boolean;
  notifyOnExit: boolean;
}

export interface DeviceSettings {
  wifiEnabled: boolean;
  bluetoothEnabled: boolean;
  cellularDataEnabled: boolean;
  airplaneMode: boolean;
  gpsEnabled: boolean;
  hotspotEnabled: boolean;
  flashlightEnabled: boolean;
  doNotDisturb: boolean;
  volumeMedia: number; // 0-100
  volumeRing: number; // 0-100
  volumeAlarm: number; // 0-100
  brightness: number; // 0-100
  autoBrightness: boolean;
  safeSearchEnabled: boolean;
  installAppsBlocked: boolean;
  uninstallAppsBlocked: boolean;
  cameraBlocked: boolean;
  micBlocked: boolean;
  screenLocked: boolean;
  lockMessage: string;
  sirenActive?: boolean;
  bedtimeStart: string; // "21:00"
  bedtimeEnd: string; // "07:00"
  bedtimeActive: boolean;
}

export interface ChildDevice {
  id: string;
  childName: string;
  childNameAr: string;
  childAge: number;
  avatarUrl: string;
  deviceName: string;
  platform: DevicePlatform;
  model: string;
  osVersion: string;
  batteryLevel: number;
  isCharging: boolean;
  isOnline: boolean;
  lastSyncTime: string;
  sirenActive?: boolean;
  screenTimeTodayMinutes: number;
  screenTimeLimitMinutes: number;
  currentLocation: {
    lat: number;
    lng: number;
    address: string;
    speedKmh: number;
    accuracyMeters: number;
    lastUpdated: string;
  };
  geofenceZones: GeofenceZone[];
  installedApps: InstalledApp[];
  settings: DeviceSettings;
  currentActiveApp?: string;
  simCarrier: string;
  pairingCode: string;
}

export type AlertSeverity = 'info' | 'warning' | 'danger' | 'critical';

export interface AlertNotification {
  id: string;
  deviceId: string;
  childName: string;
  title: string;
  titleAr: string;
  message: string;
  messageAr: string;
  timestamp: string;
  severity: AlertSeverity;
  type: 'geofence' | 'app_limit' | 'sos' | 'battery' | 'setting_change' | 'camera_mic' | 'curfew';
  isRead: boolean;
}

export interface RemoteCommandLog {
  id: string;
  deviceId: string;
  command: string;
  commandAr: string;
  status: 'sent' | 'received' | 'executed' | 'failed';
  timestamp: string;
  target?: string;
}

export interface ToastInfo {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}
