export type SupportedLanguage = 'roman_urdu' | 'urdu' | 'english';

export interface ActionProposal {
  type:
    | 'open_app'
    | 'send_sms'
    | 'whatsapp_chat'
    | 'set_alarm'
    | 'set_reminder'
    | 'analyze_crypto'
    | 'daily_signals'
    | 'quick_tool'
    | 'calculator'
    | 'take_note'
    | 'flashlight'
    | 'vibrate'
    | 'screen_wake'
    | 'speaker_test'
    | 'open_settings'
    | 'battery_status'
    | 'create_app'
    | 'run_code'
    | 'open_apk_modal'
    | 'download_apk';
  target?: string;
  recipient?: string;
  message?: string;
  label?: string;
  isSensitive?: boolean;
  value?: string | number | boolean;
  codePayload?: string;
  appTitle?: string;
}

export interface GeneratedApp {
  id: string;
  title: string;
  description: string;
  code: string;
  type: 'html' | 'javascript' | 'react' | 'kotlin';
  createdAt: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  actionProposal?: ActionProposal | null;
  actionExecuted?: boolean;
  appCode?: { title: string; code: string; type: string };
}

export interface CryptoTicker {
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
}

export interface TechnicalIndicators {
  latestClose: number;
  ema9: number;
  ema20: number;
  ema200: number;
  atr: number;
  support: number;
  resistance: number;
  liquidityHigh: number;
  liquidityLow: number;
  trend: string;
}

export interface AIAnalysisResult {
  marketBias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  summary: string;
  entryZone: string;
  stopLoss: string;
  takeProfit1: string;
  takeProfit2: string;
  riskRewardRatio: string;
  liquidityAnalysis: string;
  riskWarning: string;
}

export interface PaperTrade {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  amountUsdt: number;
  stopLoss: number;
  takeProfit: number;
  openTime: number;
  status: 'OPEN' | 'CLOSED';
  exitPrice?: number;
  pnlUsdt?: number;
}

export interface UserMemory {
  id: string;
  category: 'Routine' | 'Preference' | 'Goal' | 'Work' | 'Personal';
  fact: string;
  learnedAt: number;
}

export interface DailySignal {
  id: string;
  symbol: string;
  coinName: string;
  type: 'LONG' | 'SHORT';
  timeframe: string;
  currentPrice: number;
  entryZone: string;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  takeProfit3: number;
  riskReward: string;
  confidence: number;
  reasoning: string;
  status: 'ACTIVE' | 'TRIGGERED' | 'TARGET_HIT';
  timestamp: number;
}

export interface CryptoNewsItem {
  id: string;
  headline: string;
  source: string;
  time: string;
  sentiment: 'BULLISH' | 'NEUTRAL' | 'BEARISH';
  impactScore: number;
  summary: string;
}

export interface FearGreedData {
  score: number;
  label: string;
  yesterdayScore: number;
  lastWeekScore: number;
}
