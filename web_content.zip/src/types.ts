export type AssistantState = 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING';

export type PreferredLanguage = 'auto' | 'hinglish' | 'hi-IN' | 'en-IN' | 'en-US';
export type SpeechLanguage = 'hi-IN' | 'en-IN' | 'en-US';
export type ResponseLength = 'concise' | 'balanced' | 'detailed';
export type ThemeBrightness = 'dim' | 'standard' | 'high';
export type AppTab = 'assistant' | 'utilities' | 'settings';
export type UtilityPanelId =
  | 'clock'
  | 'weather'
  | 'timer'
  | 'stopwatch'
  | 'calculator'
  | 'notes'
  | 'shortcuts'
  | 'device'
  | 'camera';

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ActionCardData {
  type: 'url' | 'utility' | 'device' | 'unsupported';
  label: string;
  url?: string;
  utilityId?: UtilityPanelId;
  detail?: string;
  openedAutomatically?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  knowledgeMode?: 'live-web' | 'ai-knowledge' | 'local-command';
  sources?: GroundingSource[];
  actionCard?: ActionCardData;
  isError?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface UserSettings {
  assistantName: string;
  userNickname: string;
  preferredLanguage: PreferredLanguage;
  speechLanguage: SpeechLanguage;
  voiceEnabled: boolean;
  handsFreeMode: boolean;
  lowPowerMode: boolean;
  speechSpeed: number;
  responseLength: ResponseLength;
  themeBrightness: ThemeBrightness;
}

export interface NoteItem {
  id: string;
  title: string;
  body: string;
  updatedAt: number;
}

export interface ShortcutItem {
  id: string;
  label: string;
  url: string;
}

export interface WeatherData {
  locationName: string;
  country?: string;
  latitude: number;
  longitude: number;
  temperatureC: number;
  apparentTempC: number;
  humidity: number;
  windKmh: number;
  weatherCode: number;
  condition: string;
  isDay: boolean;
  updatedAt: string;
  daily: Array<{
    date: string;
    tempMax: number;
    tempMin: number;
    weatherCode: number;
    condition: string;
  }>;
}
