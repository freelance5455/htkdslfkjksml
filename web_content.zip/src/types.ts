export interface UserProfile {
  id: string; // ASEF-XXXXXX or ASEF-777777
  name: string;
  username: string;
  gender?: 'male' | 'female';
  pass: string;
  avatar?: string;
  wallpaper?: string;
  wallpaperOpacity?: number;
  rank?: string;
  points: number;
  vipLevel: number;
  online?: boolean;
  lastSeen?: any;
  statusText?: string;
  blockedUsers?: string[];
  privacyLastSeen?: 'everyone' | 'nobody';
  soundEnabled?: boolean;
  phone?: string;
}

export interface RoyalGift {
  id: string;
  name: string;
  icon: string;
  cost: number;
  recipientId?: string;
  recipientName?: string;
  description?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderVip: number;
  text?: string;
  type: 'text' | 'image' | 'audio' | 'file' | 'gift';
  fileUrl?: string;
  fileName?: string;
  fileSize?: string;
  replyToText?: string;
  replyToSender?: string;
  timestamp?: any;
  expiresAt?: number;
  reactions?: Record<string, string>;
  gift?: RoyalGift;
}

export interface ChatRoom {
  id: string;
  isGroup: boolean;
  groupName?: string;
  groupAvatar?: string;
  members: string[];
  admins?: string[];
  createdBy?: string;
  createdAt?: any;
  lastMessage?: string;
  lastMessageTime?: any;
  lastSenderName?: string;
  nameA?: string;
  nameB?: string;
  idA?: string;
  idB?: string;
  disappearing?: boolean;
  disappearingHours?: number;
  wallpaper?: string;
}

export type PageTab = 'home' | 'feed' | 'search' | 'account';

export interface PostComment {
  id: string;
  userId: string;
  userName: string;
  userVip: number;
  userAvatar?: string;
  text: string;
  createdAt?: any;
}

export interface UserPost {
  id: string;
  authorId: string;
  authorName: string;
  authorVip: number;
  authorAvatar?: string;
  content: string;
  imageUrl?: string;
  createdAt?: any;
  likes?: string[]; // list of user IDs
  commentsCount?: number;
}

export interface WallpaperPreset {
  id: string;
  name: string;
  url: string;
  thumbnail: string;
  description: string;
}
