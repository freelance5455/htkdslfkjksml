export type Language = "hindi" | "rajasthani" | "gujarati" | "vagadi";

export interface FieldEntry {
  fieldName: string;
  hours: number;
  fillingDuration?: string;
}

export interface PaymentItem {
  id?: string;
  date: string;
  amount: number;
  mode?: "Cash" | "UPI" | "Bank" | "Cheque" | string;
  note?: string;
}

export interface Record {
  id: string;
  farmer: string;
  crop: string;
  season?: string;
  date: string;
  rate: number;
  entries: FieldEntry[];
  previousBalance: number;
  paymentReceived: number;
  paymentsList?: PaymentItem[];
}

export interface RecordFormData {
  farmer: string;
  crop: string;
  season: string;
  date: string;
  rate: string;
  previousBalance: string;
  paymentReceived: string;
}

export interface Customer {
  id: string;
  name: string;
  crop: string;
  rate: number;
  fieldName: string;
  phone?: string;
}

export type ExpenseCategory = 
  | "diesel" 
  | "electricity" 
  | "motor_repair" 
  | "pipeline" 
  | "labor" 
  | "parts" 
  | "bank_deposit" 
  | "other";

export interface ExpenseUsage {
  id: string;
  date: string;
  amount: number;
  category: string;
  title: string;
  paidTo?: string;
  sourceParty?: string;
  paymentMode: "Cash" | "UPI" | "Bank" | "Cheque" | string;
  billNo?: string;
  note?: string;
}
