export interface PdfFileItem {
  id: string;
  file: File;
  name: string;
  size: number;
  pageCount: number;
  status: 'loading' | 'ready' | 'error';
  errorMessage?: string;
  previewUrl?: string;
}

export type PhoneDeviceType = 'responsive' | 'iphone-16' | 'galaxy-s24' | 'iphone-se';

export interface PhonePreset {
  id: PhoneDeviceType;
  name: string;
  width: string;
  iconName: string;
}
