export type UserRole = 'customer' | 'manufacturer' | 'wholesaler' | 'driver' | 'admin' | 'staff';

export type Language = 'en' | 'bn' | 'hi';

export interface UserProfile {
  id: string;
  name: string;
  mobile: string;
  email: string;
  address: string;
  pinCode: string;
  photoUrl?: string;
  role: UserRole;
  businessName?: string;
  gstNumber?: string;
  panNumber?: string;
  aadhaarNumber?: string;
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    ifscCode: string;
  };
  verified: boolean;
  kycStatus: 'pending' | 'verified' | 'rejected';
  gpsPermissionGranted: boolean;
}

export type BrickCategory =
  | '1st Class Brick'
  | '2nd Class Brick'
  | 'Fly Ash Brick'
  | 'Concrete Block'
  | 'Building Materials'
  | 'Transport';

export interface Product {
  id: string;
  name: string;
  brickType: BrickCategory;
  size: string; // e.g., "9\" x 4.25\" x 2.75\"" or "230 x 110 x 75 mm"
  quality: 'Class 1 Heavy Load' | 'Class 2 Standard' | 'Eco Green Grade A' | 'High Strength AAC' | 'Paving Grade';
  pricePerThousand: number; // In INR (₹)
  availableStockThousand: number; // in thousands (e.g. 85 = 85,000 bricks)
  minOrderThousand: number;
  photos: string[];
  manufacturerId: string;
  manufacturerName: string;
  dealerId?: string;
  dealerName?: string;
  rating: number;
  reviewCount: number;
  deliveryChargePerKm: number;
  deliveryAreaRadiusKm: number;
  gstPercent: number;
  description: string;
  isApproved: boolean;
  isActive: boolean;
}

export interface CartItem {
  product: Product;
  quantityThousand: number; // in thousands e.g. 5 = 5,000 bricks
}

export type OrderStatus =
  | 'Order Confirmed'
  | 'Manufacturer Preparing'
  | 'Vehicle Assigned'
  | 'Loading'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled';

export interface OrderItem {
  productId: string;
  productName: string;
  brickType: BrickCategory;
  quantityThousand: number;
  unitPrice: number; // per thousand
  totalProductPrice: number;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerMobile: string;
  deliveryAddress: string;
  deliveryPinCode: string;
  deliveryDate: string;
  items: OrderItem[];
  productTotal: number;
  transportCharge: number;
  discount: number;
  gstAmount: number;
  totalAmount: number;
  paymentMethod: 'UPI' | 'Card' | 'Net Banking' | 'Pay on Delivery';
  paymentStatus: 'Paid' | 'Pending' | 'Refunded';
  orderStatus: OrderStatus;
  manufacturerId: string;
  manufacturerName: string;
  vehicleType: '10-Wheeler Heavy Truck' | '6-Wheeler Dumper' | 'Tractor Trolley' | 'Mini Commercial Pickup';
  vehicleNumber?: string;
  driverId?: string;
  driverName?: string;
  driverMobile?: string;
  deliveryOtp: string;
  liveTracking?: {
    driverLat: number;
    driverLng: number;
    currentSpeedKmH: number;
    etaMinutes: number;
    distanceRemainingKm: number;
    currentStage: string;
  };
  loadingPhoto?: string;
  deliveryPhoto?: string;
  customerSignature?: string;
  createdAt: string;
  notes?: string;
}

export interface WholesalerInventoryItem {
  id: string;
  productId: string;
  name: string;
  category: BrickCategory;
  openingStockThousand: number;
  purchasedThousand: number;
  soldThousand: number;
  currentStockThousand: number;
  purchasePricePerThousand: number;
  sellingPricePerThousand: number;
  lowStockThresholdThousand: number;
}

export interface DriverTrip {
  id: string;
  orderId: string;
  pickupAddress: string;
  destinationAddress: string;
  brickQuantityThousand: number;
  vehicleType: string;
  estimatedDistanceKm: number;
  transportCharge: number;
  driverEarnings: number;
  status: 'requested' | 'accepted' | 'loading' | 'in_transit' | 'delivered' | 'rejected';
  vehicleNumber: string;
  customerName: string;
  customerMobile: string;
  manufacturerName: string;
  date: string;
}

export interface PlatformCommissionConfig {
  manufacturerCommissionPercent: number; // e.g. 3%
  dealerCommissionPercent: number; // e.g. 2%
  transportCommissionPercent: number; // e.g. 5%
  paymentGatewayFeePercent: number; // e.g. 1.8%
  gstPercent: number; // e.g. 5% or 18%
}

export interface SettlementRecord {
  id: string;
  orderId: string;
  beneficiaryType: 'Manufacturer' | 'Wholesaler' | 'Transporter';
  beneficiaryName: string;
  grossAmount: number;
  platformCommission: number;
  transportFee: number;
  netPayable: number;
  status: 'Pending' | 'Processing' | 'Paid';
  paymentRef?: string;
  date: string;
}

export interface ComplaintRecord {
  id: string;
  orderId: string;
  raisedByName: string;
  raisedByRole: UserRole;
  category:
    | 'Wrong quantity'
    | 'Damaged bricks'
    | 'Late delivery'
    | 'Payment issue'
    | 'Driver issue'
    | 'Product quality'
    | 'Refund';
  description: string;
  status: 'Open' | 'Assigned' | 'Investigation' | 'Resolved' | 'Closed';
  createdAt: string;
  assignedStaff?: string;
  resolutionNotes?: string;
}

export interface WalletTransaction {
  id: string;
  type: 'credit' | 'debit' | 'refund';
  amount: number;
  description: string;
  date: string;
  referenceId?: string;
}

export interface AppNotification {
  id: string;
  recipientRole: UserRole | 'all';
  title: string;
  message: string;
  type: 'order' | 'transport' | 'payment' | 'complaint' | 'system';
  timestamp: string;
  read: boolean;
  orderId?: string;
}
