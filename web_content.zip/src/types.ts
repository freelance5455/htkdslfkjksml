export type NavTab = "home" | "create" | "projects" | "history" | "settings";

export type ToolId =
  | "tts"
  | "voice-library"
  | "translator"
  | "music"
  | "ghazal-nasheed"
  | "image"
  | "image-to-video"
  | "text-to-video"
  | "enhance-audio"
  | "video-to-music"
  | "subtitles"
  | "script"
  | "lyrics"
  | "recording";

export interface VoiceItem {
  id: string;
  name: string;
  language: string;
  languageCode: string;
  gender: "Male" | "Female" | "Neutral";
  style: string;
  accent: string;
}

export interface SelectedMediaFile {
  file?: File;
  fileId?: string;
  url: string;
  name: string;
  size: number;
  type: "image" | "audio" | "video" | "document";
  mimeType: string;
  duration?: number;
  thumbnailUrl?: string;
}

export interface ProjectItem {
  id: string;
  name: string;
  type: ToolId | string;
  thumbnailUrl?: string;
  fileUrl?: string;
  mediaType: "audio" | "video" | "image" | "text" | "subtitle" | "document";
  createdAt: number;
  lastModified: number;
  metadata?: Record<string, any>;
}

export interface HistoryItem {
  id: string;
  type: ToolId | string;
  typeName: string;
  title: string;
  status: "processing" | "completed" | "failed";
  createdAt: number;
  fileUrl?: string;
  thumbnailUrl?: string;
  mediaType?: "audio" | "video" | "image" | "text" | "subtitle" | "document";
  metadata?: Record<string, any>;
}

export interface BackendStatus {
  connected: boolean;
  checking: boolean;
  statusText: string;
  providers?: {
    gemini?: boolean;
    tts?: boolean;
    translation?: boolean;
    music?: boolean;
    image?: boolean;
    video?: boolean;
  };
  serverTime?: string;
}
