import { TutorPersonaId, TeachingMode, AcademicLevel } from './utils/tutor-prompts';
import { QuizQuestion, Flashcard } from './utils/quiz-state';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  persona?: TutorPersonaId;
  isStreaming?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  persona: TutorPersonaId;
  teachingMode: TeachingMode;
  level: AcademicLevel;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
}

export type { TutorPersonaId, TeachingMode, AcademicLevel, QuizQuestion, Flashcard };
