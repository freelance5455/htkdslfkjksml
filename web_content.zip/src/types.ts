export interface NetworkStats {
  rssi: number; // in dBm, e.g. -52
  signalLevel: number; // 0 to 100%
  pingMs: number;
  jitterMs: number;
  packetLossPercent: number;
  isBoosted: boolean;
  boostTimestamp?: number;
  connectionType: 'wifi' | 'cellular' | 'ethernet' | 'unknown';
  activeDns: string;
}

export interface DnsProvider {
  id: string;
  name: string;
  primaryIp: string;
  secondaryIp: string;
  hostname: string;
  testUrl: string;
  ping: number | null;
  features: string[];
}

export interface GameServerProfile {
  id: string;
  name: string;
  game: 'freefire' | 'bgmi' | 'codm' | 'mlbb';
  region: string;
  flag: string;
  endpoint: string;
  basePing: number;
  currentPing: number;
  status: 'optimal' | 'good' | 'lag';
}

export interface BoostStep {
  id: string;
  text: string;
  detail: string;
  status: 'pending' | 'in_progress' | 'completed';
}

export interface AndroidToast {
  id: string;
  message: string;
  duration: 'short' | 'long';
}
