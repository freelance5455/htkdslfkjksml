export type Language = 'en';

export type PaymentMethod = 'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Other';

export type MovementType = 'stock_in' | 'stock_out' | 'adjustment' | 'sale' | 'sale_return';

export type ViewId =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'stock'
  | 'customers'
  | 'sales'
  | 'expenses'
  | 'analytics'
  | 'reports'
  | 'categories'
  | 'settings';

export interface StoreSettings {
  storeName: string;
  storePhone: string;
  storeLogo: string;
  language: Language;
  defaultLowStockLimit: number;
  receiptHeader: string;
  receiptFooter: string;
  showClock: boolean;
  clockFormat: '12h' | '24h';
  clockShowSeconds: boolean;
  clockShowDate: boolean;
  clockOffsetMinutes: number;
  defaultWalkInName: string;
  defaultCustomerId: string;
  allowCreditSales: boolean;
  showCustomerPhoneOnReceipt: boolean;
}

export interface Category {
  id: string;
  name: string;
  models: string[];
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  category: string;
  subCategory?: string;
  brand?: string;
  model: string;
  unit?: string;
  variantSpec?: string;
  purchasePrice: number;
  sellingPrice: number;
  quantity: number;
  minStock: number;
  supplier: string;
  notes: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  dueBalance: number;
  totalSpent: number;
  isDefault?: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  phone: string;
  address: string;
  duePayable: number;
}

export interface Expense {
  id: string;
  date: string;
  title: string;
  category: string;
  amount: number;
  paymentMethod: string;
  notes: string;
}

export interface SaleItem {
  productId: string;
  name: string;
  model: string;
  unit?: string;
  purchasePrice: number;
  sellingPrice: number;
  maxStock?: number;
  qty: number;
}

export interface Sale {
  id: string;
  invoiceNo: string;
  date: string;
  customerId: string;
  customerName: string;
  paymentMethod: string;
  items: SaleItem[];
  subtotal: number;
  discount: number;
  grandTotal: number;
  paidAmount: number;
  tenderedAmount?: number;
  dueAmount: number;
  changeReturn: number;
  profit: number;
}

export interface StockMovement {
  id: string;
  date: string;
  productId: string;
  productName: string;
  type: MovementType;
  prevQty: number;
  delta: number;
  newQty: number;
  reason: string;
}

export interface ShopSession {
  id: string;
  openedAt: string;
  closedAt?: string;
  durationMs?: number;
  dateKey?: string;
}

export interface StoreData {
  settings: StoreSettings;
  categories: Category[];
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  expenses: Expense[];
  sales: Sale[];
  movements: StockMovement[];
  shopSessions: ShopSession[];
  activeSession: ShopSession | null;
  recentCategories?: string[];
  categoriesSeededV3?: boolean;
}

export interface ReportPayload {
  title: string;
  subtitle?: string;
  sheetBanner?: string;
  categoryName?: string;
  summaryCards?: { label: string; value: string }[];
  headers: string[];
  rows: (string | number)[][];
  totalsRow?: (string | number)[];
}

export interface SalesStatementPayload {
  title: string;
  periodLabel: string;
  generatedAt: string;
  summary: {
    ordersCount: number;
    itemsCount: number;
    subtotal: number;
    discount: number;
    grandTotal: number;
    paid: number;
    due: number;
    cogs: number;
    grossProfit: number;
    marginPct: number;
    expenses: number;
    netProfit: number;
  };
  paymentBreakdown: { method: string; count: number; amount: number }[];
  categorySummary?: {
    category: string;
    productCount: number;
    totalUnits: number;
    costValue: number;
    retailValue: number;
    potentialProfit: number;
  }[];
  stockRows?: {
    sl: number;
    name: string;
    code: string;
    category: string;
    quantity: number;
    purchasePrice: number;
    sellingPrice: number;
    costValue: number;
    retailValue: number;
    status: string;
  }[];
  rows: {
    sl: number;
    date: string;
    invoiceNo: string;
    customerName: string;
    itemsCount: number;
    paymentMethod: string;
    subtotal: number;
    discount: number;
    grandTotal: number;
    paidAmount: number;
    dueAmount: number;
    profit: number;
  }[];
}

export type PrintMode =
  | { type: 'receipt'; sale: Sale }
  | { type: 'report'; report: ReportPayload }
  | { type: 'statement'; statement: SalesStatementPayload }
  | { type: 'labels'; items: Product[]; showPrice: boolean; showStore: boolean }
  | null;

export interface ToastMessage {
  id: number;
  msg: string;
  type: 'success' | 'error';
}
