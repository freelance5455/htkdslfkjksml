export interface UserProfile {
  uid: string;
  displayName: string;
  username: string;
  bio?: string;
  photoURL?: string;
  phone?: string;
  email?: string;
  badge?: string;
  level?: number;
  flowersCount?: number;
  birthDate?: string;
  friendsCount?: number;
  followersCount?: number;
  followingCount?: number;
  coins?: number;
  earnings?: number;
  lastDailyClaimDay?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface FriendItem {
  id: string;
  userId: string;
  displayName: string;
  username?: string;
  photoURL?: string;
  bio?: string;
  isOnline?: boolean;
  createdAt: string;
}

export interface FollowItem {
  id: string;
  userId: string;
  displayName: string;
  username?: string;
  photoURL?: string;
  bio?: string;
  createdAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorBadge?: string;
  content: string;
  mediaUrl?: string;
  likesCount: number;
  commentsCount: number;
  likedBy?: string[];
  createdAt: string;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  content: string;
  createdAt: string;
}

export interface Room {
  id: string;
  title: string;
  description: string;
  category: string;
  hostId: string;
  hostName: string;
  hostAvatar?: string;
  icon: string;
  bgGradient: string;
  participantsCount: number;
  isVoiceActive: boolean;
  isLocked: boolean;
  createdAt: string;
  moderators?: string[];
  coverUrl?: string;
  speakers?: {
    id: string;
    name: string;
    avatar: string;
    isMuted: boolean;
    isSpeaking: boolean;
  }[];
}

export interface PaymentRequest {
  id: string;
  userId: string;
  userDisplayName: string;
  userEmail: string;
  userPhone?: string;
  vodafoneNumber: string;
  senderNumber?: string;
  senderPhone?: string;
  transactionReference: string;
  amountEGP?: number;
  amount?: number;
  currency?: string;
  packageType?: string;
  packageTitle?: string;
  coins: number;
  flowers: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface RoomMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  text: string;
  type: 'text' | 'gift' | 'system';
  giftType?: string;
  createdAt: string;
}

export interface GiftItem {
  id: string;
  name: string;
  icon: string;
  cost: number;
  costCoins?: number;
  color: string;
  category?: 'flowers' | 'royal' | 'luxury' | 'special';
  description?: string;
}

export interface UserGiftRecord {
  id: string;
  giftId: string;
  name: string;
  icon: string;
  count: number;
  fromId: string;
  fromName: string;
  fromAvatar?: string;
  isSelfPurchased?: boolean;
  receivedAt: string;
  updatedAt?: string;
}

export interface DirectChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  text: string;
  type: 'text' | 'gift';
  gift?: {
    id: string;
    name: string;
    icon: string;
    cost: number;
    color?: string;
  };
  createdAt: string;
  timestamp: string;
}

export interface DirectChatConversation {
  id: string;
  participants: string[];
  participantDetails: {
    [uid: string]: {
      displayName: string;
      photoURL?: string;
      username?: string;
    };
  };
  lastMessage: string;
  lastMessageSenderId: string;
  lastTime: string;
  updatedAt: string;
  unreadCount?: number;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'topup' | 'daily_bonus' | 'gift_sent' | 'gift_purchase' | 'gift_received' | 'withdrawal_hold' | 'withdrawal_refund' | 'withdrawal_paid';
  currency: 'coins' | 'flowers' | 'earnings';
  amount: number;
  balanceAfter: number | null;
  refType?: string;
  refId?: string;
  counterpartyId?: string | null;
  note?: string;
  createdAt: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userDisplayName: string;
  userEmail?: string;
  amountEarnings: number;
  amountEGP: number;
  method: 'vodafone_cash';
  phone: string;
  status: 'pending' | 'approved' | 'paid' | 'rejected' | 'cancelled';
  adminNote?: string;
  createdAt: string;
  updatedAt?: string;
  history?: { status: string; at: string; by: string; note?: string }[];
}
