export type TrackId = 'sahara' | 'corniche' | 'atlas';

export interface CarModel {
  id: string;
  name: string;
  arabicName: string;
  origin: string;
  color: string;
  accent: string;
  highlight: string;
  maxSpeed: number; // in game speed units (e.g. 10 - 15)
  acceleration: number;
  handling: number;
  health: number; // default durability
  pixels: string[];
  description: string;
}

export interface TrackConfig {
  id: TrackId;
  name: string;
  arabicName: string;
  roadColor: string;
  roadEdgeColor: string;
  groundColor: string;
  groundTextureColor: string;
  curbColor1: string;
  curbColor2: string;
  skyGradient: [string, string];
  decorTypes: ('cactus' | 'palm' | 'rock' | 'sheep' | 'camel' | 'pine' | 'dune')[];
  bgSilhouette: 'dunes' | 'monument' | 'mountains';
}

export type PowerupType = 'nitro' | 'couscous' | 'coin' | 'repair';

export interface PowerupItem {
  id: number;
  x: number;
  y: number;
  type: PowerupType;
  collected: boolean;
}

export interface Obstacle {
  id: number;
  x: number;
  y: number;
  carId: string;
  speed: number;
  lane: number;
  vx: number;
  width: number;
  height: number;
  type: 'car' | 'truck' | 'taxi';
}

export interface Pedestrian {
  id: number;
  x: number;
  y: number;
  dir: number;
  frame: number;
  color: string;
  clothing: 'djellaba' | 'casual';
}

export interface RoadHazard {
  id: number;
  x: number;
  y: number;
  type: 'pothole' | 'sand' | 'oil';
  width: number;
  height: number;
}

export interface DecorItem {
  id: number;
  x: number;
  y: number;
  type: 'cactus' | 'palm' | 'rock' | 'sheep' | 'camel' | 'pine' | 'dune';
  size: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
}

export interface HighScoreEntry {
  id: string;
  name: string;
  score: number;
  carName: string;
  trackId: TrackId;
  distanceKm: number;
  date: string;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  life: number;
}

export interface SkidMark {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  alpha: number;
}

export type TimeOfDay = 'day' | 'sunset' | 'night';

export type GameStatus = 'MENU' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

