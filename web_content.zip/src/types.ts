export type SupportedLanguage =
  | 'html'
  | 'css'
  | 'javascript'
  | 'typescript'
  | 'python'
  | 'java'
  | 'cpp'
  | 'json';

export interface ProjectFile {
  id: string;
  name: string;
  path: string;
  language: SupportedLanguage;
  content: string;
}

export type ProjectCategory = 'web' | 'game' | 'react' | 'python' | 'custom';

export interface Project {
  id: string;
  name: string;
  description: string;
  category: ProjectCategory;
  files: ProjectFile[];
  activeFileId: string;
  createdAt: number;
  updatedAt: number;
}

export type ConsoleType = 'log' | 'info' | 'warn' | 'error' | 'system';

export interface ConsoleEntry {
  id: string;
  type: ConsoleType;
  message: string;
  timestamp: string;
  count?: number;
  stack?: string;
  source?: string;
}

export type StudioTheme = 'cyberpunk' | 'dark' | 'neon' | 'matrix' | 'light';

export type ViewportMode = 'responsive' | 'mobile' | 'tablet' | 'desktop';

export interface EditorSettings {
  fontSize: number;
  tabSize: number;
  fontFamily: 'Fira Code' | 'Courier New' | 'monospace';
  lineNumbers: boolean;
  wordWrap: boolean;
  autoRunOnChange: boolean;
  theme: StudioTheme;
}

export interface AIProposal {
  id: string;
  fileId: string;
  filename: string;
  originalCode: string;
  proposedCode: string;
  explanation: string;
  action: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
}

export interface TestResult {
  id: string;
  name: string;
  status: 'pass' | 'fail' | 'running';
  message: string;
  durationMs: number;
}

export interface SoundEffectDefinition {
  name: string;
  type: 'laser' | 'jump' | 'explosion' | 'coin' | 'powerup' | 'hit';
  description: string;
}
