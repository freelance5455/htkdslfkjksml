export type ZoneId = "gate1" | "gate2" | "mankweng" | "paledi" | "groceries" | "laundry" | "pharmacy" | "cash";

export type CategoryId =
  | "all"
  | "fastfood"
  | "kota"
  | "pizza"
  | "chicken"
  | "burgers"
  | "drinks"
  | "groceries"
  | "liquor"
  | "errands"
  | "laundry"
  | "pharmacy"
  | "cash";

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
}

export interface Shop {
  id: string;
  name: string;
  tagline: string;
  zone: ZoneId;
  category: CategoryId;
  rating: number;
  reviews: number;
  eta: string;
  image: string;
  tags: string[];
  hasMenu: boolean;
  featured?: boolean;
  deliveryFee?: number;
  menu?: MenuItem[];
}

export interface CartItem {
  key: string;
  shopId: string;
  shopName: string;
  itemId: string;
  name: string;
  description: string;
  price: number;
  qty: number;
  image: string;
  note?: string;
}

export interface PlacedOrder {
  id: string;
  createdAt: number;
  items: CartItem[];
  name: string;
  phone: string;
  address: string;
  zone: ZoneId;
  payment: "cash" | "capitec";
  when: "asap" | "schedule";
  scheduleAt?: string;
  note: string;
  subtotal: number;
  delivery: number;
  total: number;
}
