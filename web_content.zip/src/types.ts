export type ScreenId =
  | 'dashboard'
  | 'games'
  | 'ultra'
  | 'gfx'
  | 'hud'
  | 'monitor'
  | 'device-check'
  | 'coach'
  | 'network'
  | 'training'
  | 'settings'
  | 'splash'
  | 'onboarding';

export type LanguageCode = 'en' | 'es' | 'pt' | 'hi' | 'ja';

export interface GamePreferences {
  targetFps: 30 | 60 | 90 | 120;
  gfxPreset: 'smooth' | 'balanced' | 'hd' | 'hdr';
  dndEnabled: boolean;
  wakeLockEnabled: boolean;
  hudEnabled: boolean;
  audioFocus: 'balanced' | 'footsteps' | 'cinema';
  powerProfile: 'efficiency' | 'balanced' | 'performance';
}

export interface GameEntry {
  id: string;
  name: string;
  packageName: string;
  genre: 'Battle Royale' | 'Tactical FPS' | 'Racing' | 'MOBA' | 'RPG' | 'Arcade';
  iconUrl: string;
  launchUrl?: string;
  isCustom?: boolean;
  lastPlayedAt?: number;
  preferences: GamePreferences;
}

export interface TelemetrySample {
  timestamp: number;
  fps: number;
  frameTimeMs: number;
  mainThreadDriftMs: number;
  jsHeapUsedMb: number | null;
}

export interface SystemTelemetry {
  fps: number;
  frameTimeMs: number;
  estimatedRefreshHz: number;
  jsHeapUsedMb: number | null;
  jsHeapLimitMb: number | null;
  jsHeapPercent: number | null;
  deviceMemoryGb: number | null;
  cpuCores: number;
  mainThreadDriftMs: number;
  batteryLevel: number | null;
  batteryCharging: boolean | null;
  batteryChargingTime: number | null;
  batteryDischargingTime: number | null;
  batterySupported: boolean;
  connectionType: string | null;
  effectiveType: string | null;
  downlinkMbps: number | null;
  networkRttMs: number | null;
  online: boolean;
  screenWidth: number;
  screenHeight: number;
  pixelRatio: number;
  platform: string;
  userAgentSummary: string;
  history: TelemetrySample[];
}

export interface NetworkTestResult {
  id: string;
  timestamp: number;
  pingMinMs: number;
  pingAvgMs: number;
  pingMaxMs: number;
  jitterMs: number;
  stabilityPercent: number;
  downloadMbps: number;
  uploadMbps: number;
  effectiveType: string;
}

export interface TrainingRecord {
  id: string;
  timestamp: number;
  mode: 'reaction' | 'accuracy' | 'reflex' | 'coordination';
  scoreLabel: string;
  numericValue: number;
  unit: string;
  details: string;
}

export type HudCorner = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
export type HudAppearance = 'compact' | 'tactical' | 'minimal';

export interface HudConfig {
  enabled: boolean;
  locked: boolean;
  corner: HudCorner;
  appearance: HudAppearance;
  opacity: number;
  neonBorder: boolean;
  showFps: boolean;
  showRam: boolean;
  showBattery: boolean;
  showNetwork: boolean;
  showShortcuts: boolean;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  language: LanguageCode;
  notificationsEnabled: boolean;
  dndAutoPrompt: boolean;
  shareContextWithAi: boolean;
  autoRefreshTelemetry: boolean;
}
