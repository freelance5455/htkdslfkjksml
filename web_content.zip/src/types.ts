export type PersonaType =
  | 'mast_friend'
  | 'screen_accessibility'
  | 'phone_assistant'
  | 'coder'
  | 'tutor'
  | 'creative';

export type ToneType =
  | 'chatpata'
  | 'concise'
  | 'detailed'
  | 'shuddh_hindi'
  | 'english';

export interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'file' | 'screen';
  mimeType: string;
  size?: number;
  base64?: string; // base64 data for image/pdf
  text?: string;   // text content for code/txt/csv
  previewUrl?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  persona?: PersonaType;
  tone?: ToneType;
  isStreaming?: boolean;
}

export interface DeviceInfo {
  batteryLevel: number | null;
  isCharging: boolean | null;
  isOnline: boolean;
  screenResolution: string;
  deviceMemory: number | null;
  platform: string;
}

export interface ReminderItem {
  id: string;
  text: string;
  time: string;
  done: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  isLoggedIn: boolean;
  joinedAt: number;
  preferredLanguage?: 'hinglish' | 'hindi' | 'english';
}

export type VoiceActionType =
  | 'wake_greeting'
  | 'open_youtube'
  | 'open_google'
  | 'open_maps'
  | 'play_music'
  | 'open_search'
  | 'clear_tasks'
  | 'read_screen'
  | 'open_phone_tools'
  | 'open_screen_reader'
  | 'clear_chat'
  | 'export_chat'
  | 'toggle_auto_speak'
  | 'switch_persona'
  | 'switch_tone'
  | 'send_custom_prompt';

export interface VoiceCommandTrigger {
  id: string;
  phrase: string;
  action: VoiceActionType;
  actionPayload?: string;
  enabled: boolean;
  description: string;
  isBuiltIn?: boolean;
}

