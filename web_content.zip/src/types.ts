export type MaskStyle = 'box' | 'circle' | 'rounded' | 'full' | 'polaroid';

export type AspectRatio = '16:9' | '9:16' | '1:1' | '4:5';

export type MotionPattern = '4-linear' | 'inshot-classic' | 'zoom-drift' | 'diagonal-drift' | 'ken-burns';

export interface SlideItem {
  id: string;
  url: string;
  name: string;
  size?: number;
  zoom?: number; // 1.0 to 3.0 (e.g. 1.0 = normal, 1.3 = 130% zoom)
  offsetX?: number; // -50% to +50% horizontal pan/shift
  offsetY?: number; // -50% to +50% vertical pan/shift
  fitMode?: 'cover' | 'contain'; // 'cover' fills the card (cropped), 'contain' shows the whole photo
}

export interface SlideshowSettings {
  maskStyle: MaskStyle;
  blur: number; // 0 to 40
  brightness: number; // e.g. 1.1 for white vibe
  saturate: number; // e.g. 1.2 for vibrant white vibe
  interval: number; // seconds, default 3.5s
  transitionDuration: number; // seconds, default 3.5s
  easing: 'linear' | 'cubic';
  aspectRatio: AspectRatio;
  motionPattern: MotionPattern;
  borderWidth: number; // 0 to 10
  borderColor: string;
  showBorder: boolean;
  showShadow: boolean;
  foregroundScale: number; // 50 to 90 %
  crossfadeDuration: number; // e.g. 0.6s smooth dissolve between slides
}
