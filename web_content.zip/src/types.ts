export interface MacroBreakdown {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  saturatedFat: number;
}

export interface MealItem {
  id: string;
  name: string;
  nameEn: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  imageUrl: string;
  timestamp: string;
  weightGrams: number;
  macros: MacroBreakdown;
  healthScore: number; // 1-100
  aiInsight: string;
  aiSwaps?: string[];
  ingredients: string[];
}

export interface Invitee {
  id: string;
  name: string;
  joinedDate: string;
  avatar: string;
  isSubscribed: boolean;
  subscriptionPlan?: 'monthly' | 'annual';
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  inviteCode: string;
  dailyCalorieTarget: number;
  dailyProteinTarget: number;
  dailyCarbsTarget: number;
  dailyFatTarget: number;
  isDirectlySubscribed: boolean;
  subscriptionPlan: 'free' | 'monthly' | 'annual' | null;
  subscriptionExpiresAt: string | null;
  invitees: Invitee[];
  dailyScansUsed: number;
  dailyScansLimit: number; // 3 for free tier, unlimited (9999) for Pro
}

export type TierLevel = 1 | 2 | 3 | 4 | 5;

export interface TierConfig {
  level: TierLevel;
  nameAr: string;
  nameEn: string;
  badge: string;
  requiredInvites: number;
  requiresPayment: boolean; // Starting from level 3, requires payment by user OR invitees
  requiredPaidInvites: number; // If user is not paid, how many paid invitees needed
  color: string;
  summaryAr: string;
  featuresAr: string[];
}
