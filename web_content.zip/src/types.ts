export type BallColor = 'red' | 'yellow' | 'green' | 'brown' | 'blue' | 'pink' | 'black';

export interface BallInfo {
  id: BallColor;
  name: string;
  faName: string;
  points: number;
  bgGradient: string;
  shadowColor: string;
  textColor: string;
  borderClass?: string;
}

export interface Player {
  id: number;
  name: string;
  score: number;
  framesWon: number;
  hits: number;
  misses: number;
  highestBreak: number;
  currentBreak: number;
  matchHighestBreak: number;
}

export type ScoreMode = 'hit' | 'miss' | 'foul';

export interface ShotRecord {
  id: string;
  timestamp: number;
  playerId: number;
  playerName: string;
  ballId?: BallColor;
  ballName: string;
  points: number;
  mode: ScoreMode;
  isFoul: boolean;
  foulReason?: string;
  opponentAwardedId?: number;
  opponentAwardedName?: string;
  breakScoreBefore: number;
  breakScoreAfter: number;
}

export type RuleMode = 'official' | 'custom';

export interface MatchSettings {
  ruleMode: RuleMode; // 'official' (red=1, foul awards points to opponent) | 'custom' (red=10, miss deducts points like original user code)
  redValue: number;
  totalReds: number;
  remainingReds: number;
  bestOfFrames: number;
  currentFrame: number;
  soundEnabled: boolean;
}

export interface GameSnapshot {
  players: Player[];
  activePlayerId: number;
  currentMode: ScoreMode;
  settings: MatchSettings;
  historyLogs: ShotRecord[];
}
