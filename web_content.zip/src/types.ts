export interface ConversionRecord {
  id: string;
  timestamp: number;
  nyDateFormatted: string; // e.g. "16/05/2025"
  nyTimeFormatted: string; // e.g. "08:46:00"
  nyFullDateDisplay: string; // e.g. "Fri, May 16, 2025"
  nyTimeDisplay: string; // e.g. "08:46:00 AM"
  nyTzAbbr: string; // "EDT" or "EST"
  nyOffsetString: string; // "UTC-4" or "UTC-5"
  
  indiaFullDateDisplay: string; // e.g. "Fri, May 16, 2025"
  indiaTimeDisplay: string; // e.g. "06:16:00 PM"
  indiaTzAbbr: string; // "IST"
  indiaOffsetString: string; // "UTC+5:30"
  
  offsetDiffHours: string; // "+9h 30m" or "+10h 30m"
  note?: string;
}

export interface AppSettings {
  use24Hour: boolean;
  showKillzones: boolean;
  audioTick: boolean;
  autoSaveHistory: boolean;
}

export type ActiveTab = 'converter' | 'history' | 'about';

export interface KillZoneInfo {
  id: string;
  name: string;
  nyTimeRange: string;
  summerIstRange: string;
  winterIstRange: string;
  isActive: boolean;
}
