export interface Dish {
  id: string;
  name: string;
  description: string;
  price?: string | null;
  calories?: string | number | null;
  protein?: string | number | null;
  carbs?: string | number | null;
  fat?: string | number | null;
  dietaryLabel?: string[];
  ingredients?: string[] | null;
  imageUrl?: string;
  category: string;
  isEditorialFeature?: boolean;
}

export interface MenuCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  dishes: Dish[];
}

export interface JournalArticle {
  id: string;
  title: string;
  subtitle: string;
  date: string;
  readTime: string;
  excerpt: string;
  imageUrl: string;
  tag: string;
  content?: string;
  isPlaceholder?: boolean;
  locationOrCategory?: string;
}

export interface AtmosphereImage {
  id: string;
  title: string;
  caption: string;
  aspectRatio: "4:5" | "1:1" | "16:9";
  imageUrl: string;
}

export interface FloatingFrame {
  id: string;
  title: string;
  imageUrl: string;
  alt: string;
  rotation: number; // 1 to 3 degrees or -1 to -3
  motionType: "drift" | "rotate" | "diagonal" | "scale" | "horizontal" | "static";
  duration: number; // 6 to 15 seconds
  delay: number;
}

export type ChatRoleType = "host" | "nutritionist" | "quick";

export interface ChatMessage {
  id: string;
  role: "user" | "model" | "assistant";
  text: string;
  content?: string;
  timestamp: string;
  modelUsed?: string;
}
