export interface Player {
  uuid: string;
  name?: string;
  displayName: string;
  address?: string;
  port?: number;
  exhaustion?: number;
  exp?: number;
  whitelisted?: boolean;
  banned?: boolean;
  op?: boolean;
  location?: [number, number, number];
  dimension?: string;
  health?: number;
  hunger?: number;
  saturation?: number;
  gamemode?: string;
  lastPlayed?: number;
}

export interface ServerInfo {
  online: boolean;
  name?: string;
  motd?: string;
  version?: string;
  bukkitVersion?: string;
  tps?: string;
  onlinePlayers?: number;
  maxPlayers?: number;
  health?: {
    cpus?: number;
    uptime?: number;
    totalMemory?: number;
    maxMemory?: number;
    freeMemory?: number;
  };
}

export interface ConnectionConfig {
  host: string;
  port: string;
  key: string;
  protocol: 'http' | 'https';
  refreshInterval: number; // in seconds, 0 = paused
  soundEnabled: boolean;
}

export interface UserProfile {
  name: string;
  platform: 'java' | 'bedrock';
}

export interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  timestamp: number;
  platform: 'java' | 'bedrock';
  isOffline?: boolean;
}
