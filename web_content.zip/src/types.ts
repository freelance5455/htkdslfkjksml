/**
 * Types for Waqti (وقتي) Productivity & Gamification Platform
 */

export type ItemCategory = 'title' | 'frame' | 'avatar' | 'theme';

export interface CustomThemePalette {
  bg: string;
  card: string;
  border: string;
  accent: string;
  textAccent: string;
  gradient: string;
}

export interface CustomFrameConfig {
  borderColor1: string;
  borderColor2: string;
  glowColor: string;
  animation: 'pulse' | 'flame' | 'spin' | 'electric' | 'portal';
  borderWidth?: number;
}

export interface MarketItem {
  id: string;
  name: string;
  category: ItemCategory;
  price: number;
  description: string;
  icon?: string;
  cssClass?: string;
  rarity?: 'common' | 'rare' | 'epic' | 'legendary';
  isCustom?: boolean;
  // Custom design by Founder
  customDrawing?: string;
  customFrameConfig?: CustomFrameConfig;
  customThemePalette?: CustomThemePalette;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'founder' | 'user';
  avatar: string;
  customAvatarUrl?: string;
  title: string;
  frame: string;
  theme: string;
  coins: number;
  xp: number;
  level: number;
  streak: number;
  lastActiveDate: string;
  inventory: string[]; // List of item IDs owned
  createdAt: string;
}

export interface TaskItem {
  id: string;
  title: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  estimatedPomodoros: number;
  completedPomodoros: number;
  isCompleted: boolean;
  dueDate?: string;
  subtasks?: { id: string; title: string; completed: boolean }[];
  createdAt: string;
  completedAt?: string;
}

export interface Coupon {
  code: string;
  coinsReward: number;
  maxUses: number;
  usedCount: number;
  description?: string;
  createdAt: string;
}

export type PomodoroMode = 'focus' | 'shortBreak' | 'longBreak';

export interface PomodoroSettings {
  focusTime: number; // in minutes
  shortBreakTime: number;
  longBreakTime: number;
  longBreakInterval: number; // after how many focus sessions
  autoStartBreaks: boolean;
  soundEnabled: boolean;
}

export interface SyncPayload {
  user: UserProfile;
  tasks: TaskItem[];
  redeemedCoupons: string[];
}
