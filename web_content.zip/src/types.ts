export interface CategoryItem {
  id: string;
  name: string;
  hindiName: string;
  defaultRate: number | null; // Reference base rate per sq ft
  unit: string;
  iconName: string;
  description: string;
  tag?: string;
  popular?: boolean;
  rateNote?: string;
  defaultLabourRate?: number;
  labourUnit?: string; // "sq ft" | "Roll"
  hasDetailedBOQ?: boolean;
}

export interface BOQItem {
  id: string;
  name: string;
  hindiName?: string;
  size?: string;
  unit: string;
  quantity: number;
  unitRate: number;
  amount: number;
  note?: string;
}

export interface CalculationInputs {
  length: number | "";
  width: number | "";
  categoryId: string;
  includeLabour: boolean;
  labourRate: number | "";
  includeBuffer?: boolean;
  bufferPercent?: number;
}

export interface CalculationResult {
  id: string;
  timestamp: number;
  length: number;
  width: number;
  area: number;
  categoryId: string;
  categoryName: string;
  categoryHindiName?: string;
  
  // Reference / Display rate per sq ft
  referenceRatePerSqFt: number | null;
  
  // Material BOQ Breakdown
  hasDetailedBOQ: boolean;
  boqMessage?: string;
  boqItems: BOQItem[];
  materialTotal: number;
  
  // Optional Buffer / Wastage (0% by default, separately displayed if user enables)
  bufferEnabled: boolean;
  bufferPercent: number;
  bufferAmount: number;
  
  // Labour Breakdown
  includeLabour: boolean;
  labourRate: number;
  labourUnit: string; // "sq ft" or "Roll"
  labourQuantity: number;
  labourTotal: number;
  
  // Grand Total
  grandTotal: number;
  isRateConfigured: boolean;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: number;
  isAudioPlaying?: boolean;
}

export interface ContactInfo {
  businessName: string;
  personName: string;
  phone: string;
  whatsapp: string;
  city: string;
  availableHours: string;
}

