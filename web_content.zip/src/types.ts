export type TabletRole = 'reception' | 'altar' | 'secretary' | 'presentation';

export type VisitorCategory = 'adulto' | 'jovem' | 'crianca' | 'melhor_idade' | 'pastor_lider';

export interface Visitor {
  id: string;
  name: string;
  phone?: string;
  cityOrNeighborhood?: string;
  invitedBy?: string;
  companionCount: number;
  companionsDetails?: string;
  isFirstTime: boolean;
  prayerRequest?: string;
  category: VisitorCategory;
  status: 'pending' | 'presented';
  isPinned?: boolean;
  notes?: string;
  registeredAt: string; // ISO date
  presentedAt?: string;
  serviceId: string;
}

export interface ServiceInfo {
  id: string;
  title: string;
  leaderName: string;
  date: string;
  churchName?: string;
  notes?: string;
}

export type AltarTheme = 'pulpito_dark' | 'dourado_luxo' | 'claro_solar' | 'alto_contraste';

export type FontSizeLevel = 'normal' | 'grande' | 'extragrande' | 'gigante';
