export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}

export interface SosAlert {
  id: string;
  latitude: number;
  longitude: number;
  locationUrl: string;
  time: string;
  source: 'manual-sos' | 'voice-threat-detection';
  status: 'activated' | 'cancelled' | 'resolved';
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  createdAt: string;
}

export interface EmergencyServiceInfo {
  title: string;
  number: string;
  description: string;
  iconName: string;
}

export type ScreenType =
  | 'splash'
  | 'login'
  | 'register'
  | 'home'
  | 'sos'
  | 'contacts'
  | 'location'
  | 'voice_safety'
  | 'ai_copilot'
  | 'trip_planner'
  | 'safety_tips'
  | 'sos_history'
  | 'instructions'
  | 'profile';
