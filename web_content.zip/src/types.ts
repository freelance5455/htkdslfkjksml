export interface ShopService {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  description: string;
}

export interface AudioDeviceResult {
  deviceId: string;
  label: string;
  kind: MediaDeviceKind;
  groupId: string;
}

export interface DiagnosticLog {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
}

export type ActiveTab = 'home' | 'screen' | 'audio' | 'services' | 'diagnostics';
