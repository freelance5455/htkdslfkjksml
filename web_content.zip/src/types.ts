export type ProxyType = "faketls" | "secure" | "classic";
export type VerificationKind = "telegram" | "handshake" | "tcp" | "manual";
export type SourceStatus = "idle" | "loading" | "success" | "error" | "cached";

export interface ProxySource {
  id: string;
  name: string;
  shortName: string;
  url: string;
  homepage: string;
  description: string;
  method: Exclude<VerificationKind, "manual">;
  location: string;
  refresh: string;
  defaultEnabled: boolean;
}

export interface LiveCheck {
  state: "checking" | "online" | "offline" | "error";
  checkedAt: number;
  latency: number | null;
  message?: string;
}

export interface ProxyRecord {
  id: string;
  server: string;
  port: number;
  secret: string;
  type: ProxyType;
  ip: string | null;
  country: string | null;
  provider: string | null;
  latency: number | null;
  latencyFrom: string | null;
  uptime: number | null;
  checks: number | null;
  verification: VerificationKind;
  sourceIds: string[];
  feedNames: string[];
  lastChecked: string | null;
  reachableFrom: string[];
  resilience: number | null;
  fakeTlsDomain: string | null;
  score: number;
  isManual?: boolean;
  live?: LiveCheck;
}

export interface SourceState {
  status: SourceStatus;
  count: number;
  updated: string | null;
  fetchedAt: number | null;
  duration: number | null;
  message?: string;
}

export interface CatalogCache {
  version: 1;
  savedAt: number;
  records: Record<string, ProxyRecord[]>;
  states: Record<string, SourceState>;
}

export interface AppSettings {
  enabledSources: string[];
  autoRefresh: boolean;
  refreshMinutes: number;
  checkerUrl: string;
}

export type ToastMessage = {
  id: number;
  title: string;
  description?: string;
  tone?: "default" | "success" | "error";
};
