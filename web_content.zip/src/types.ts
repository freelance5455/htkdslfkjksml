export interface ColorOption {
  id: string;
  name: string;
  hex: string;
  ringHex: string;
  glow: string;
  isGolden?: boolean;
  isBomb?: boolean;
}

export type GameState = 'START' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

export type ActiveScreen = 'HOME' | 'THEMES' | 'DAILY' | 'ACHIEVEMENTS' | 'PROFILE' | 'LEADERBOARD' | 'SETTINGS' | 'STREAK';

export interface DailyStreakData {
  currentStreak: number;
  lastLoginDate: string;
  lastClaimedDate: string;
  totalDaysLogged: number;
}

export interface StreakRewardItem {
  day: number;
  coins: number;
  label: string;
  isJackpot?: boolean;
}

export const STREAK_REWARDS: StreakRewardItem[] = [
  { day: 1, coins: 15, label: 'Day 1' },
  { day: 2, coins: 25, label: 'Day 2' },
  { day: 3, coins: 40, label: 'Day 3' },
  { day: 4, coins: 60, label: 'Day 4' },
  { day: 5, coins: 80, label: 'Day 5' },
  { day: 6, coins: 100, label: 'Day 6' },
  { day: 7, coins: 150, label: 'Day 7', isJackpot: true },
];

export interface GameTheme {
  id: 'neon' | 'space' | 'fire' | 'ocean' | 'galaxy';
  name: string;
  description: string;
  cost: number;
  bgGradient: string;
  ambientGlow: string;
  accentColor: string;
  borderStyle: string;
  unlocked: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rewardCoins: number;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
}

export interface DailyChallenge {
  id: string;
  dateStr: string; // YYYY-MM-DD
  title: string;
  description: string;
  type: 'score' | 'combo' | 'golden_taps';
  target: number;
  current: number;
  rewardCoins: number;
  completed: boolean;
  claimed: boolean;
}

export interface PlayerProfile {
  uid?: string;
  name: string;
  avatar: string;
  isGoogleUser: boolean;
  email?: string;
  photoUrl?: string;
}

export interface LeaderboardEntry {
  id: string;
  rank: number;
  playerName: string;
  avatar: string;
  score: number;
  maxCombo: number;
  date: string;
  isCurrentPlayer?: boolean;
}

export interface GameStats {
  highScore: number;
  gamesPlayed: number;
  maxCombo: number;
  totalTaps: number;
  goldenTaps: number;
  coins: number;
  feverCount: number;
  bombsAvoided: number;
}

export interface FloatingText {
  id: number;
  text: string;
  x: number;
  y: number;
  color: string;
  isGolden?: boolean;
  isFever?: boolean;
}

export interface TapRipple {
  id: number;
  x: number;
  y: number;
  color: string;
}

export const BASE_COLORS: ColorOption[] = [
  {
    id: 'red',
    name: 'Red',
    hex: '#EF4444',
    ringHex: '#DC2626',
    glow: 'rgba(239, 68, 68, 0.45)',
  },
  {
    id: 'blue',
    name: 'Blue',
    hex: '#3B82F6',
    ringHex: '#2563EB',
    glow: 'rgba(59, 130, 246, 0.45)',
  },
  {
    id: 'green',
    name: 'Green',
    hex: '#10B981',
    ringHex: '#059669',
    glow: 'rgba(16, 185, 129, 0.45)',
  },
  {
    id: 'yellow',
    name: 'Yellow',
    hex: '#F59E0B',
    ringHex: '#D97706',
    glow: 'rgba(245, 158, 11, 0.45)',
  },
  {
    id: 'purple',
    name: 'Purple',
    hex: '#8B5CF6',
    ringHex: '#7C3AED',
    glow: 'rgba(139, 92, 246, 0.45)',
  },
  {
    id: 'pink',
    name: 'Pink',
    hex: '#EC4899',
    ringHex: '#DB2777',
    glow: 'rgba(236, 72, 153, 0.45)',
  },
  {
    id: 'cyan',
    name: 'Cyan',
    hex: '#06B6D4',
    ringHex: '#0891B2',
    glow: 'rgba(6, 182, 212, 0.45)',
  },
];

export const GOLDEN_COLOR: ColorOption = {
  id: 'golden',
  name: 'Golden Bonus',
  hex: '#FBBF24',
  ringHex: '#F59E0B',
  glow: 'rgba(251, 191, 36, 0.75)',
  isGolden: true,
};

export const BOMB_COLOR: ColorOption = {
  id: 'bomb',
  name: 'Danger Bomb',
  hex: '#18181B',
  ringHex: '#DC2626',
  glow: 'rgba(220, 38, 38, 0.75)',
  isBomb: true,
};

export const GAME_THEMES: GameTheme[] = [
  {
    id: 'neon',
    name: 'Neon',
    description: 'Electric arcade aesthetics with high-contrast vibrancy',
    cost: 0,
    bgGradient: 'bg-[#090d16]',
    ambientGlow: '#3B82F6',
    accentColor: '#3B82F6',
    borderStyle: 'border-slate-800',
    unlocked: true,
  },
  {
    id: 'space',
    name: 'Space',
    description: 'Deep cosmic starlight with astral cyans and nebulas',
    cost: 50,
    bgGradient: 'bg-[#060814]',
    ambientGlow: '#6366F1',
    accentColor: '#818CF8',
    borderStyle: 'border-indigo-900/60',
    unlocked: false,
  },
  {
    id: 'fire',
    name: 'Fire',
    description: 'Blazing volcanic heat with ember orange and crimson fury',
    cost: 100,
    bgGradient: 'bg-[#140606]',
    ambientGlow: '#EF4444',
    accentColor: '#F97316',
    borderStyle: 'border-rose-950',
    unlocked: false,
  },
  {
    id: 'ocean',
    name: 'Ocean',
    description: 'Submerged deep marine abyss with bioluminescent aqua',
    cost: 150,
    bgGradient: 'bg-[#040f16]',
    ambientGlow: '#06B6D4',
    accentColor: '#14B8A6',
    borderStyle: 'border-cyan-950',
    unlocked: false,
  },
  {
    id: 'galaxy',
    name: 'Galaxy',
    description: 'Ultraviolet interstellar stardust and cosmic royalty',
    cost: 250,
    bgGradient: 'bg-[#0d0417]',
    ambientGlow: '#C084FC',
    accentColor: '#D946EF',
    borderStyle: 'border-purple-950',
    unlocked: false,
  },
];
