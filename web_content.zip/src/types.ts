export type WorkspaceTab = 'chat' | 'call';

export type ScreenShareSource =
  | 'none'
  | 'android_mediaprojection'
  | 'android_camerax'
  | 'camera';

export type ScreenShareStatus =
  | 'idle'
  | 'requesting'
  | 'active'
  | 'paused'
  | 'error';

export type AttachmentKind = 'image' | 'video' | 'code';

export interface MediaAttachment {
  name: string;
  mimeType: string;
  data: string; // base64 for image/video, raw UTF-8 text for code files
  previewUrl: string;
  kind: AttachmentKind;
}

export interface ClipboardSnippet {
  id: string;
  title: string;
  language: string;
  code: string;
  createdAt: number;
  autoCopied: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  attachmentName?: string;
  attachmentPreviewUrl?: string;
  attachmentKind?: AttachmentKind;
  usedScreenShare?: boolean;
  clipboardSnippet?: ClipboardSnippet;
}

export interface HistorySession {
  id: string;
  type: 'chat' | 'call' | 'media' | 'clipboard';
  title: string;
  language: string;
  updatedAt: number;
  messages: ChatMessage[];
  durationSeconds?: number;
}

export type PermissionStateLabel =
  | 'granted'
  | 'prompt'
  | 'denied'
  | 'unsupported'
  | 'active'
  | 'idle';

export interface PermissionStatusMap {
  microphone: PermissionStateLabel;
  screenShare: PermissionStateLabel;
  clipboard: PermissionStateLabel;
  overlayPiP: PermissionStateLabel;
}
