/**
 * GODEX v0.0.2 - Core Type Definitions
 * Architecture: Autonomous AI Software Development Environment
 * Strict separation of Human Chat, Authoritative Workspace,
 * Live Execution Sandbox, Evidence Verification, and Self-Healing Debugger.
 */

export type TaskState =
  | 'IDLE'
  | 'PLANNING'
  | 'ANALYZING'
  | 'CODING'
  | 'INSTALLING'
  | 'BUILDING'
  | 'RUNNING'
  | 'TESTING'
  | 'VERIFYING'
  | 'DEBUGGING'
  | 'COMPLETED'
  | 'BLOCKED'
  | 'FAILED';

export type AgentRole =
  | 'Understanding Agent'
  | 'Project Analyst'
  | 'Architect'
  | 'Coding Agent'
  | 'Filesystem Agent'
  | 'Terminal Agent'
  | 'Execution Agent'
  | 'Build Agent'
  | 'Preview Agent'
  | 'Browser QA Agent'
  | 'Debugger'
  | 'Security Reviewer'
  | 'Final Verifier'
  | 'Planner'
  | 'Reviewer'
  | 'Verification Agent';

export type ExecutionMode = 'copilot' | 'autopilot';
export type ExecutionEnvironment = 'sandbox' | 'termux';

export type PreviewState =
  | 'STARTING'
  | 'BUILDING'
  | 'RUNNING'
  | 'STALE'
  | 'BUILD_FAILED'
  | 'RUNTIME_ERROR'
  | 'STOPPED'
  | 'PREVIEW_IDLE'
  | 'PREVIEW_STARTING'
  | 'PREVIEW_RUNNING'
  | 'PREVIEW_FAILED'
  | 'PREVIEW_STOPPED';

export interface PreviewBuildError {
  file?: string;
  line?: number;
  column?: number;
  message: string;
  codeSnippet?: string;
  rawError?: string;
}

export interface PreviewHealthReport {
  running: boolean;
  mounted: boolean;
  url?: string;
  elementsCount: number;
  runtimeErrors: string[];
  buildError?: PreviewBuildError | null;
  lastChecked: number;
}

export interface ResponsiveTestReport {
  timestamp: number;
  passed: boolean;
  score: number;
  checks: Array<{
    id: string;
    title: string;
    description: string;
    status: 'passed' | 'failed' | 'running';
    details?: string;
  }>;
}

export type ViewportDevice = 'desktop' | 'tablet' | 'mobile' | 'laptop' | 'desktop-lg';

export type MobileActiveTab = 'files' | 'preview' | 'chat' | 'terminal' | 'activity' | 'verification';

export interface ChatAttachment {
  id: string;
  name: string;
  type: string; // e.g. 'image/png', 'text/typescript', 'application/json'
  size: number;
  dataUrl?: string; // base64 preview for images
  textContent?: string; // string content for text/code/json/csv/md
  file?: File;
  status?: 'ready' | 'uploading' | 'error';
  error?: string;
}

export interface ChatMessageSource {
  path: string;
  line?: number;
  symbol?: string;
  description?: string;
  epistemic?: 'KNOWN' | 'INFERRED' | 'UNKNOWN';
}

/**
 * Human-Facing Conversational Stream
 * Exclusively contains natural language, requirement clarifications, progress summaries, and final answers.
 * NEVER contains raw tool calls, JSON, or state machine dumps.
 */
export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: number;
  isClarification?: boolean;
  status?: 'sending' | 'thinking' | 'done' | 'error';
  progressSummary?: string;
  sources?: ChatMessageSource[];
  suggestedActions?: string[];
  intent?: string;
  confidence?: number;
  attachments?: ChatAttachment[];
  epistemicSummary?: {
    known?: string[];
    inferred?: string[];
    unknown?: string[];
  };
  responseType?: 'conversational' | 'read_only_query' | 'engineering_action' | 'clarification';
}

export interface ProjectFile {
  path: string;
  name: string;
  content: string;
  language: 'typescript' | 'javascript' | 'html' | 'css' | 'json' | 'markdown' | 'python' | 'yaml' | 'shell';
  isDirty?: boolean;
  isNew?: boolean;
  isDeleted?: boolean;
  updatedAt: number;
  hash?: string;
  sizeBytes?: number;
}

/**
 * Workspace Event System
 */
export type WorkspaceEventType =
  | 'workspace:file-created'
  | 'workspace:file-modified'
  | 'workspace:file-deleted'
  | 'workspace:file-renamed'
  | 'workspace:directory-created'
  | 'workspace:batch-mutation'
  | 'workspace:changed'
  | 'workspace:reset';

export interface WorkspaceEventPayload {
  type: WorkspaceEventType;
  path?: string;
  oldPath?: string;
  content?: string;
  hash?: string;
  bytes?: number;
  timestamp: number;
  source: 'ai_tool' | 'user' | 'rollback' | 'template';
}

export interface WorkspaceManifest {
  totalFiles: number;
  totalBytes: number;
  files: Array<{
    path: string;
    bytes: number;
    hash: string;
    lastModified: number;
  }>;
  rootFolders: string[];
  entryPoint: string;
}

export interface WorkspaceFileMutationResult {
  path: string;
  success: boolean;
  operation: 'write' | 'patch' | 'delete' | 'create_dir' | 'rename';
  bytes: number;
  hashBefore?: string;
  hashAfter: string;
  verified: boolean;
  error?: string;
}

/**
 * Internal Technical Operations Stream (Activity Log)
 * Exclusively tracks files created/modified, commands run, DOM assertions, and verification reports.
 */
export interface ActivityLogItem {
  id: string;
  timestamp: number;
  role: AgentRole;
  state: TaskState;
  action: string;
  details?: string;
  status: 'pending' | 'success' | 'error' | 'warning' | 'info';
  diff?: {
    file: string;
    additions: number;
    deletions: number;
    patch?: string;
  };
  toolCall?: {
    toolName: string;
    args: Record<string, any>;
    result?: {
      success: boolean;
      stdout?: string;
      stderr?: string;
      exitCode?: number;
      data?: any;
    };
  };
}

export interface VerificationCheckItem {
  id: string;
  name: string;
  category: 'code' | 'runtime' | 'browser' | 'api' | 'regression' | 'ui_quality';
  status: 'pending' | 'passed' | 'failed' | 'skipped';
  message: string;
  durationMs?: number;
  details?: string;
}

export type VerificationClaimStatus = 
  | 'VERIFIED' 
  | 'PARTIALLY_VERIFIED' 
  | 'INFERRED' 
  | 'FAILED' 
  | 'NOT_VERIFIED' 
  | 'BLOCKED';

export interface EvidenceClaim {
  claim: string;
  status: VerificationClaimStatus;
  source: string;
  evidence: string[];
  timestamp: number;
  operation: string;
  validation: string;
}

export interface TruthfulVerificationDossier {
  whatIChanged: string[];
  whatITested: string[];
  whatPassed: string[];
  whatFailed: string[];
  whatICouldNotVerify: string[];
  claims: EvidenceClaim[];
}

export interface ProjectStateEvidence {
  taskCompleted: boolean;
  filesCreated: number;
  filesModified: number;
  filesDeleted: number;
  totalLinesAdded: number;
  totalLinesDeleted: number;
  meaningfulDiff: boolean;
  buildPassed: boolean;
  testsPassed: boolean;
  runtimePassed: boolean;
  browserPassed: boolean;
  failureReason?: string;
  claims?: EvidenceClaim[];
  dossier?: TruthfulVerificationDossier;
}

export interface VerificationReport {
  timestamp: number;
  passed: boolean;
  score: number; // 0 - 100%
  overallStatus?: 'PASSED' | 'FAILED';
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  summary: string;
  checks: VerificationCheckItem[];
  evidence?: ProjectStateEvidence;
  claims?: EvidenceClaim[];
  dossier?: TruthfulVerificationDossier;
  browserScreenshots?: string[];
  consoleErrorsDetected: string[];
  uiQuality?: {
    overallScore: number;
    rating: string;
    passedInvariants: string[];
    violations: Array<{ ruleName: string; description: string; severity: string }>;
  };
}

export interface Checkpoint {
  id: string;
  name: string;
  description: string;
  timestamp: number;
  files: Record<string, string>;
  changedFilesCount: number;
  author: 'user' | 'autopilot' | 'rollback';
}

export interface ProjectMemoryItem {
  id: string;
  category: 'architecture' | 'conventions' | 'decisions' | 'known_issues' | 'test_expectations';
  title: string;
  content: string;
  updatedAt: number;
}

export interface BrowserAction {
  id: string;
  type: 'navigate' | 'click' | 'type' | 'scroll' | 'assert_element' | 'screenshot' | 'eval';
  target?: string;
  value?: string;
  status: 'pending' | 'success' | 'failed';
  resultMessage?: string;
  timestamp: number;
}

export interface TerminalLog {
  id: string;
  timestamp: number;
  type: 'stdout' | 'stderr' | 'system' | 'command' | 'test';
  text: string;
  exitCode?: number;
}

export interface ViewportDimensions {
  width: number;
  height: number;
  label: string;
}

export interface ProjectTemplate {
  id: string;
  title: string;
  description: string;
  category: string;
  badge: string;
  iconName: string;
  files: Record<string, string>;
}

export interface ModelProviderConfig {
  provider: 'gemini' | 'custom-api' | 'offline-engine';
  model: string;
  temperature: number;
  apiKey?: string;
  endpointUrl?: string;
}

export interface AIPlanStep {
  id: string;
  title: string;
  description: string;
  agent: AgentRole;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  filesToTouch: string[];
}

/**
 * Capability Registry Types
 */
export interface CapabilityDefinition {
  id: string;
  name: string;
  category: 'frontend' | 'backend' | 'runtime' | 'styling' | 'testing' | 'database';
  supportLevel: 'native' | 'sandbox-transpiled' | 'termux-executable';
  description: string;
  supportedFileExtensions: string[];
  testRunner?: string;
}

/**
 * Self-Debugging Diagnostic Types
 */
export interface DiagnosticError {
  type: 'syntax' | 'runtime' | 'build' | 'dom_assertion' | 'network';
  file?: string;
  line?: number;
  column?: number;
  message: string;
  stack?: string;
  rawError: string;
}

export interface SelfHealingRepairPlan {
  errorSummary: string;
  rootCause: string;
  targetFiles: string[];
  repairActions: Array<{
    type: 'write_file' | 'patch_file';
    path: string;
    description: string;
  }>;
}

/**
 * GODEX Phase 0 - Workspace & View Architecture
 */
export type WorkspaceViewMode = 
  | 'home'
  | 'creative-studio'
  | 'media-studio'
  | 'dashboard'
  | 'studio'
  | 'agents'
  | 'intelligence'
  | 'task-graph'
  | 'preview' 
  | 'editor' 
  | 'memory' 
  | 'verifications'
  | 'dossier'
  | 'replay'
  | 'diff' 
  | 'architecture' 
  | 'git' 
  | 'mission-control'
  | 'settings';

export type SidebarNavCategory = 
  | 'PROJECT' 
  | 'INTELLIGENCE' 
  | 'ENGINEERING' 
  | 'SYSTEM';

export type SidebarViewId = 
  | 'explorer' 
  | 'search' 
  | 'open_files'
  | 'architecture' 
  | 'symbols' 
  | 'dependencies' 
  | 'memory'
  | 'git' 
  | 'checkpoints' 
  | 'tasks' 
  | 'verification'
  | 'settings' 
  | 'agents_config'
  | 'mission-control';

export type EngineeringBottomTab = 
  | 'terminal' 
  | 'execution'
  | 'debugger'
  | 'tests' 
  | 'logs' 
  | 'diff' 
  | 'agents' 
  | 'verification';

export type AICenterTab = 
  | 'chat' 
  | 'orchestration'
  | 'plan' 
  | 'activity' 
  | 'debugger'
  | 'agents'
  | 'context'
  | 'inspector'
  | 'diff'
  | 'simulation'
  | 'oracle'
  | 'visual-loop';

/**
 * Future Agent Specification Model
 */
export type AgentExecutionState = 'ready' | 'active' | 'planning' | 'coding' | 'testing' | 'offline' | 'idle';

export interface GodexAgentDefinition {
  id: string;
  name: string;
  role: AgentRole;
  title: string;
  description: string;
  capabilities: string[];
  status: AgentExecutionState;
  color: string;
  iconName: string;
  model: string;
}

export type TaskProgressState = 'pending' | 'running' | 'completed' | 'failed' | 'blocked';

export interface AgentTask {
  id: string;
  title: string;
  description: string;
  assignedAgent: AgentRole;
  status: TaskProgressState;
  progressPercent: number;
  files: string[];
  errorMessage?: string;
  startedAt?: number;
  completedAt?: number;
}

/**
 * Architecture Graph Models
 */
export type ArchitectureNodeType = 
  | 'entry' 
  | 'component' 
  | 'service' 
  | 'state' 
  | 'util' 
  | 'style' 
  | 'config' 
  | 'asset';

export interface ArchitectureNode {
  id: string;
  name: string;
  type: ArchitectureNodeType;
  path: string;
  lines: number;
  bytes: number;
  imports: string[];
  exports: string[];
}

export interface ArchitectureEdge {
  id: string;
  source: string;
  target: string;
  relation: 'imports' | 'renders' | 'invokes' | 'configures';
}

/**
 * Standard Internal Event Telemetry Model
 */
export interface StandardInternalEvent {
  id: string;
  operation: string;
  timestamp: number;
  agent: AgentRole;
  tool?: string;
  status: 'pending' | 'running' | 'success' | 'failed';
  input?: Record<string, any>;
  output?: Record<string, any>;
  error?: string;
  stackTrace?: string;
  filesChanged?: string[];
  durationMs?: number;
}

/**
 * Command Palette Item Definition
 */
export interface CommandPaletteItem {
  id: string;
  title: string;
  subtitle?: string;
  shortcut?: string;
  category: 'Workspace' | 'Navigation' | 'Engineering' | 'Intelligence' | 'Agent';
  icon: string;
  action: () => void;
}

export * from './intelligence/types';
export * from './coding/agentTypes';
export * from './intelligence/softwareEvolutionEngine';
export * from './intelligence/engineeringOracle';
export * from './intelligence/visualLoopTypes';

