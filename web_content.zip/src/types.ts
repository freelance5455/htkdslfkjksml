export type TabId = 'study' | 'notes' | 'hub';

export type ColorTheme = 'purple' | 'blue' | 'orange' | 'emerald' | 'rose';

export interface Subject {
  id: string;
  name: string;
  teacher?: string;
  progress: number;
  color: ColorTheme;
  updatedAt: number;
}

export interface TaskItem {
  id: string;
  title: string;
  subjectName?: string;
  done: boolean;
  priority: 'normal' | 'high';
  createdAt: number;
}

export interface PomodoroSettings {
  studyMinutes: number;
  breakMinutes: number;
}

export interface NoteItem {
  id: string;
  title: string;
  subjectTag: string;
  content: string;
  color: ColorTheme;
  updatedAt: number;
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentSize?: number;
  attachmentMediaType?: Exclude<WhatsNewMediaType, 'none'>;
}

export type AlarmRepeatMode = 'once' | 'daily' | 'study_days';

export type BuiltinRingtoneId =
  | 'calm_study'
  | 'classic_clock'
  | 'morning_birds'
  | 'motivational'
  | 'soft_adhan';

export interface StudyAlarm {
  id: string;
  title: string;
  taskId?: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  repeat: AlarmRepeatMode;
  ringtoneType: 'builtin' | 'custom';
  builtinRingtoneId: BuiltinRingtoneId;
  customAudioUrl?: string; // idb://...
  customAudioName?: string;
  enabled: boolean;
  lastTriggeredKey?: string; // prevents re-triggering within same minute
  snoozeUntilMs?: number;
  createdAt: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  attachmentName?: string;
  attachmentType?: string;
  timestamp: number;
}

export type WhatsNewCategory = 'file' | 'text' | 'news' | 'quiz' | 'summary';
export type WhatsNewTextKind = 'none' | 'ملخص' | 'تنبيه' | 'شرح';
export type WhatsNewMediaType =
  | 'none'
  | 'pdf'
  | 'word'
  | 'powerpoint'
  | 'excel'
  | 'video'
  | 'audio'
  | 'image';

export interface WhatsNewItem {
  id: string;
  title: string;
  description: string;
  category: WhatsNewCategory;
  textKind: WhatsNewTextKind;
  subjectName: string;
  mediaType: WhatsNewMediaType;
  fileUrl: string;
  fileName: string;
  fileSize: number;
  newsDate: string;
  quizQuestion: string;
  quizOptions: string[];
  quizCorrectIndex: number;
  authorUid: string;
  createdAtMs: number;
}
