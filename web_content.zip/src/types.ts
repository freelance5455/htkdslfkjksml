export type ImageSize = '1K' | '2K' | '4K';
export type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3' | '3:4';
export type VideoAspectRatio = '16:9' | '9:16';
export type VideoDuration = '5s' | '10s';

export interface LogoItem {
  id: string;
  brandName: string;
  industry: string;
  style: string;
  colors: string[];
  tagline: string;
  description: string;
  imageSize: ImageSize;
  aspectRatio: AspectRatio;
  imageUrl: string;
  imageBase64: string;
  mimeType: string;
  timestamp: number;
  promptUsed: string;
  modelUsed: string;
}

export interface VideoItem {
  id: string;
  logoId?: string;
  brandName: string;
  videoUrl: string;
  videoBase64?: string;
  mimeType: string;
  motionPrompt: string;
  motionPreset: string;
  aspectRatio: VideoAspectRatio;
  duration: VideoDuration;
  timestamp: number;
  modelUsed: string;
  sourceImageUrl?: string;
}

export interface AssistantMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: number;
  actionTaken?: string;
  generatedImage?: {
    imageUrl: string;
    prompt: string;
    endpointUsed: string;
  };
}

export interface MemoryItem {
  id: string;
  text: string;
  category: 'preference' | 'brand' | 'instruction' | 'fact';
  timestamp: number;
}

export interface CalculationHistoryItem {
  id: string;
  expression: string;
  result: string;
  mode: 'offline' | 'online';
  steps?: string[];
  timestamp: number;
}

export interface AppSettings {
  offlineMode: boolean;
  julliEnabled: boolean;
  julliWakeWordEnabled: boolean;
  julliVoiceFeedback: boolean;
  julliAutoSleepSeconds: number;
  julliListenTimeoutSeconds: number;
  pollinationsEnabled: boolean;
  pollinationsApiKey: string;
  pollinationsEndpoint1: string;
  pollinationsEndpoint2: string;
  geminiModel: string;
  geminiApiKey: string;
  geminiBaseUrl: string;
  groqModel: string;
  groqApiKey: string;
  groqBaseUrl: string;
  activeProvider: 'pollinations' | 'gemini' | 'groq';
  vaultPasswordHash: string;
  isVaultLocked: boolean;
}

export type SplitAppType = 'logo' | 'animate' | 'julli' | 'calculator' | 'gallery' | 'notes' | 'camera';
