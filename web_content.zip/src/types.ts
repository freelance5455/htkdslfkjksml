export type TabType = 'worship' | 'jm-crypto' | 'jm-wallet' | 'jm-global-trade' | 'jm-chat' | 'sermons' | 'devotionals' | 'soaking' | 'journal' | 'profile' | 'broadcast' | 'owner' | 'support' | 'audio' | 'video' | 'image' | 'textmessages' | 'wallet' | 'upload' | 'backup-profile';


export interface MediaComment {
  id: string;
  author: string;
  text: string;
  date: string;
  replies?: { id: string; author: string; text: string; date: string }[];
}

export interface UploadedMediaItem {
  id: string;
  type: 'audio' | 'video' | 'image';
  title: string;
  description: string;
  url: string;
  thumbnailUrl?: string;
  artistOrProphet: string;
  date: string;
  likes: number;
  downloads: number;
  shares: number;
  isLiked?: boolean;
  isSubscribed?: boolean;
  comments: MediaComment[];
  isDeleted?: boolean;
  tags?: string[];
}


export interface Playlist {
  id: string;
  title: string;
  description: string;
  themeCategory: 'Morning Praise' | 'Evening Reflection' | 'Intense Worship' | 'Soaking Meditation' | 'Warfare & Deliverance' | 'Custom';
  trackIds: string[];
  coverImage: string;
  createdAt: string;
}

export interface DevotionalItem extends Devotional {
  audioTrackId?: string;
}

export interface TrackBookmark {
  id: string;
  trackId: string;
  trackTitle: string;
  artist: string;
  albumArt: string;
  timestamp: number; // in seconds
  duration: number; // in seconds
  createdAt: string;
  category?: string;
  note?: string;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  category: 'Anointed Worship' | 'High Praise' | 'Soaking Meditation' | 'Prophetic Chants' | 'Deliverance & Power';
  duration: number; // seconds
  albumArt: string;
  description: string;
  scriptureRef: string;
  plays: number;
  isAnointedFeatured?: boolean;
  synthPreset?: '528hz' | '432hz' | 'angelic' | 'soaking' | 'warfare';
  audioUrl?: string;
  lyrics?: string;
  timestampBookmark?: number;
  bookmarkedAt?: string;
  bookmarkNote?: string;
}

export interface Devotional {
  id: string;
  date: string;
  title: string;
  scripture: string;
  scriptureText: string;
  propheticDecree: string;
  message: string;
  audioDuration: string;
  author: string;
  tags: string[];
}

export interface Sermon {
  id: string;
  title: string;
  prophet: string;
  date: string;
  duration: string;
  thumbnail: string;
  summary: string;
  keyScriptures: string[];
  isLiveNow?: boolean;
  viewersCount?: number;
  category: 'Prophetic Revelation' | 'Deliverance' | 'Spiritual Warfare' | 'Anointing & Grace';
  tags: string[];
}

export interface SoundscapePreset {
  id: string;
  name: string;
  description: string;
  frequencyHz: number;
  padType: 'soaking' | 'warfare' | 'angelic' | '432hz';
  chimesEnabled: boolean;
  riverEnabled: boolean;
  colorTheme: string;
}

export interface PrayerJournalEntry {
  id: string;
  date: string;
  title: string;
  prayerText: string;
  testimony?: string;
  isAnswered: boolean;
  category: 'Healing' | 'Breakthrough' | 'Family' | 'Ministry' | 'Peace' | 'General';
}

export interface GlobalPrayerRequest {
  id: string;
  userName: string;
  location: string;
  requestText: string;
  prayerCount: number;
  timestamp: string;
  hasUserPrayed?: boolean;
}

// ----------------------------------------------------
// BIBLE READER & OFFLINE SCRIPTURE TYPES
// ----------------------------------------------------

export type BibleTranslation = 'KJV' | 'NKJV' | 'AMP' | 'NIV' | 'PROPHETIC';
export type HighlightColor = 'gold' | 'emerald' | 'rose' | 'azure' | 'amber';

export interface BibleVerseItem {
  verseNumber: number;
  text: string;
  propheticNote?: string;
}

export interface BibleChapterItem {
  chapterNumber: number;
  verses: BibleVerseItem[];
}

export interface BibleBookItem {
  id: string;
  name: string;
  testament: 'Old Testament' | 'New Testament';
  category: 'Law' | 'History' | 'Poetry & Wisdom' | 'Prophets' | 'Gospels' | 'Epistles' | 'Prophecy';
  totalChapters: number;
  chapters: BibleChapterItem[];
}

export interface BibleHighlightRecord {
  id: string;
  bookId: string;
  bookName: string;
  chapter: number;
  verse: number;
  color: HighlightColor;
  verseText: string;
  createdAt: string;
}

export interface BibleBookmarkRecord {
  id: string;
  bookId: string;
  bookName: string;
  chapter: number;
  verse: number;
  verseText: string;
  title?: string;
  note?: string;
  tags?: string[];
  color: HighlightColor;
  createdAt: string;
}

// ----------------------------------------------------
// SMART CONTRACT AUDIT & DEFI TRUST SCORE TYPES
// ----------------------------------------------------

export type AuditTrustLevel = 'HIGH_TRUST' | 'VERIFIED' | 'MEDIUM_RISK' | 'CRITICAL_WARNING';
export type VulnerabilitySeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface SmartContractVulnerability {
  id: string;
  name: string;
  severity: VulnerabilitySeverity;
  status: 'PASSED' | 'PATCHED' | 'MITIGATED' | 'FLAGGED';
  description: string;
  recommendation: string;
  cwe?: string;
}

export interface SmartContractAuditItem {
  id: string;
  protocolName: string;
  symbol: string;
  contractAddress: string;
  chain: 'Base' | 'Ethereum' | 'Arbitrum' | 'Polygon' | 'Bitcoin Lightning' | 'Solana' | 'BNB Chain';
  category: 'DEX' | 'Lending' | 'Bridge' | 'Yield' | 'Liquid Staking' | 'Token Escrow' | 'Oracle';
  trustScore: number; // 0 to 100
  trustLevel: AuditTrustLevel;
  tvlUsd: number;
  lastAuditedDate: string;
  auditorOrg: string;
  compilerVersion: string;
  bytecodeHash: string;
  reentrancyShield: boolean;
  multisigTimelockHours: number;
  honeypotFree: boolean;
  flashLoanResistant: boolean;
  liquidityLockedPercent: number;
  vulnerabilities: SmartContractVulnerability[];
  isVerifiedSourceCode: boolean;
  contractUrl: string;
}

// ----------------------------------------------------
// GLOBAL PRAYER HEATMAP & TIMEZONE SYNC TYPES
// ----------------------------------------------------

export interface GlobalPrayerTimezoneNode {
  id: string;
  city: string;
  country: string;
  timezone: string;
  utcOffset: number; // e.g. +1, -5, +8
  latitude: number;
  longitude: number;
  activeIntercessors: number;
  prayerIntensity: number; // 0 - 100
  prayerFocus: 'Breakthrough' | 'Deliverance' | 'Healing' | 'Family Restoration' | 'Sovereign Peace' | 'Global Revival';
  localTimeFormatted: string;
  activeWave: 'Dawn Glory' | 'Noon Altar' | 'Twilight Watch' | 'Midnight Soaking' | 'Prophetic Fire';
}

