export type GenderTag = 'Female' | 'Male' | 'OC' | 'المجموعات' | 'موصى به' | 'الكل';

export interface Character {
  id: string;
  name: string;
  nameAr?: string;
  avatar: string;
  description: string;
  category: 'Female' | 'Male' | 'OC' | 'Group';
  likesCount: string;
  chatsCount: string;
  isPrivate?: boolean;
  greeting: string;
  systemPrompt: string;
  creatorName?: string;
  createdAt?: string;
  voiceId?: string;
}

export interface ChatMessage {
  id: string;
  characterId: string;
  sender: 'user' | 'character' | 'system';
  text: string;
  timestamp: string;
  isAudio?: boolean;
  audioUrl?: string;
  imageUrl?: string;
}

export interface ChatConversation {
  characterId: string;
  characterName: string;
  avatar: string;
  lastMessage: string;
  lastTimestamp: string;
  unreadCount: number;
}

export interface UserProfile {
  name: string;
  handle: string;
  uid: string;
  avatar: string;
  freeMessages: number;
  isPro: boolean;
  balanceDiamonds: number;
}

export type ChatModelType = 'Gemini 3.5' | 'DeepSeek-V3' | 'Grok-4.1 F' | 'Step 3.5 F' | 'Mistral AI';
export type ResponseLengthType = 'تلقائي' | 'منخفض' | 'طويل';
export type ImageModelType = 'FLUX' | 'Nano-Ban';
export type VideoModelType = 'Pixverse' | 'Seedance' | 'Kling 2.0' | 'Veo 3.1';

export interface ModelSettings {
  chatModel: ChatModelType;
  responseLength: ResponseLengthType;
  imageModel: ImageModelType;
  videoModel: VideoModelType;
}

export interface AppThemeSettings {
  colorMode: 'pink' | 'dark' | 'purple' | 'light';
  showBackground: boolean;
  followButton: boolean;
  pushNotifications: boolean;
  showNsfw: boolean;
  language: 'ar' | 'en';
}
