export type PartOfSpeech = 'adjective' | 'verb' | 'noun' | 'adverb';

export type CognitiveStatus = 'unassigned' | 'mastered' | 'revise' | 'learn';

export interface FormItem {
  form: string;
  pos: string;
  bng: string;
  ex: string;
}

export interface ConfusionItem {
  word: string;
  diff: string;
  ex: string;
}

export interface CollocationItem {
  type: string;
  expr: string;
  bn: string;
}

export interface SentenceItem {
  en: string;
  bn: string;
}

export interface SynonymGroup {
  nuance: string;
  words: string[];
  note?: string;
}

export interface AntonymGroup {
  nuance: string;
  words: string[];
  note?: string;
}

export interface CommonError {
  mistake: string;
  fix: string;
}

export interface ExamMCQ {
  q: string;
  opts: string[];
  ans: number;
  exp: string;
}

export interface WordData {
  word: string;
  pos: string;
  posFull?: string;
  ipa: string;
  ipaUK?: string;
  ipaUS?: string;
  bengaliPron: string;
  syllables?: string;
  cefr: string;
  register: string;
  frequency: string;
  simpleDef: string;
  advDef: string;
  bengali: string;
  bengaliExp: string;
  connotations: string;
  formsTable: FormItem[];
  formsUsageNote?: string;
  contexts?: { domain: string; note: string }[];
  sentences: SentenceItem[];
  synonyms: SynonymGroup[];
  antonyms: AntonymGroup[];
  confusions: ConfusionItem[];
  etymology: string;
  collocations: CollocationItem[];
  keyExpression?: string;
  keyExpressionBn?: string;
  grammar: string;
  pragmatics: string;
  errors: CommonError[];
  mnemonicBengali: string;
  literature?: string;
  essayQuote: string;
  essayQuoteBn: string;
  examBattery: ExamMCQ[];
  quickRevision: {
    sentence: string;
    collocation: string;
  };
  finalSummary: string[];
}

export interface SemanticPack {
  id: string;
  title: string;
  bengaliTitle: string;
  icon: string;
  color: string;
  words: string[];
}

export interface MistakeItem {
  word: string;
  wrongAns: string;
  correctAns: string;
  question: string;
  category: string;
  timestamp: string;
}

export interface ActivityLogItem {
  id: string;
  type: string;
  text: string;
  time: string;
  date: string;
}

export interface DailyQuest {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  xpReward: number;
  completed: boolean;
  claimed: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  pin?: string;
  targetExam: string;
  dailyGoal: number;
  streak: number;
  streakFreezes: number;
  xp: number;
  lastActiveDate: string;
  theme: 'light' | 'dark';
  voiceLang: 'en-US' | 'en-GB';
  createdAt: string;
}

export type SrsRating = 'again' | 'hard' | 'good' | 'easy';

export interface SrsItem {
  word: string;
  stage: number; // 0 to 6 (Ebbinghaus intervals: 1d, 2d, 4d, 7d, 15d, 35d, 90d)
  stability: number; // Stability in days
  lastReviewedAt: string; // ISO date string
  nextReviewAt: string; // ISO date string
  reviewsCount: number;
  lapses: number;
  retentionScore: number; // Computed 0 - 100% based on R = e^(-t/S)
}

export interface UserProgressData {
  mastered: string[];
  revise: string[];
  learn: string[];
  saved: string[]; // Bookmarked words
  todayLearned: string[];
  fluencyScores: Record<string, number>; // 0 to 100% WordUp style
  mistakesVault: MistakeItem[];
  activityLog: ActivityLogItem[];
  dailyQuests: DailyQuest[];
  customEnrichedDossiers: Record<string, WordData>; // Offline cached AI dossiers
  srsRecords?: Record<string, SrsItem>; // Ebbinghaus Spaced Repetition items
}

export interface UserAccount {
  profile: UserProfile;
  progress: UserProgressData;
}

export type FilterCategory = 'all' | 'hot' | 'saved' | 'mastered' | 'revise' | 'learn';
export type PosFilter = 'all' | 'noun' | 'verb' | 'adjective' | 'adverb';


