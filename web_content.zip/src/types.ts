export type GenerationMode = "ghazal_shayari" | "song_lyrics" | "bait_bazi" | "rhyme_meter";

export type Tone = "romantic" | "emotional" | "philosophical" | "motivational" | "sufi";

export type LanguageStyle = "simple" | "classic";

export type GhazalFormat = "sher_2_line" | "qata_4_line" | "full_ghazal";

export type SongGenre = "sufi" | "pop" | "classical" | "rap";

export type BaitBaziType = "counter_sher" | "powerful_verse" | "rare_gem";

export type RhymeToolType = "complete_sher" | "qafiya_finder" | "meter_check";

export interface GenerationParams {
  mode: GenerationMode;
  topic: string;
  tone: Tone;
  style: LanguageStyle;
  format?: GhazalFormat;
  genre?: SongGenre;
  letter?: string;
  baziType?: BaitBaziType;
  toolType?: RhymeToolType;
  userLine?: string;
}

export interface GeneratedPoetry {
  id: string;
  mode: GenerationMode;
  topic: string;
  tone: Tone;
  style: LanguageStyle;
  content: string;
  timestamp: number;
  format?: GhazalFormat;
  genre?: SongGenre;
  letter?: string;
  isFavorite?: boolean;
}

export interface AppSettings {
  customApiKey: string;
  selectedFont: "nastaliq" | "sans";
  fontSize: "normal" | "large" | "xlarge";
  soundEffects: boolean;
}
