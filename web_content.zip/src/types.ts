export interface SubtitleCue {
  id: number;
  startTime: number; // in seconds
  endTime: number;   // in seconds
  hindiText: string;
  originalText: string;
  romanizedHindi?: string;
}

export type AudioTrackMode = 'original' | 'subtitles' | 'hindi_dubbed';

export type PipelineStage =
  | 'idle'
  | 'extracting_audio'
  | 'speech_recognition'
  | 'translating'
  | 'generating_timestamps'
  | 'ready'
  | 'error';

export interface ModularPluginConfig {
  speechProvider: 'browser_speech' | 'gemini_transcribe' | 'manual_entry';
  translationEngine: 'gemini_flash' | 'local_dictionary' | 'manual';
  ttsEngine: 'android_web_speech' | 'gemini_tts';
  speechRate: number; // 0.8 to 1.5
  speechPitch: number; // 0.8 to 1.2
  selectedVoice: string;
  duckOriginalAudio: boolean; // low original audio volume (e.g. 15%) instead of complete mute
  duckingLevel: number; // 0.0 to 0.3
}

export interface AndroidProjectFile {
  path: string;
  filename: string;
  category: 'manifest' | 'gradle' | 'kotlin_ui' | 'kotlin_pipeline' | 'docs';
  language: 'kotlin' | 'xml' | 'groovy' | 'markdown';
  description: string;
  content: string;
}
