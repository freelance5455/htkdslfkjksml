export type Language = 'sw' | 'en';
export type Theme = 'light' | 'dark';

export interface WorldCashCrop {
  id: string;
  nameSw: string;
  nameEn: string;
  symbol: string;
  category: string;
  exchange: string;
  globalPriceUsd: number;
  globalUnit: string;
  localPriceTsh: number;
  localUnit: string;
  changePercent: number;
  isUp: boolean;
  demandStatusSw: string;
  demandStatusEn: string;
  producingRegionsSw: string;
  producingRegionsEn: string;
}

export type ViewId =
  | 'view-splash'
  | 'view-onboarding'
  | 'view-login'
  | 'view-home'
  | 'view-calendar'
  | 'view-market'
  | 'view-buyers'
  | 'view-community'
  | 'view-wallet'
  | 'view-farm-records'
  | 'view-pest-doctor'
  | 'view-aggregation-pools';

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  pin: string;
  region: string;
  primaryCrops: string[];
  avatar: string;
  accountType: 'farmer' | 'buyer' | 'broker';
}

export type WeatherCondition =
  | 'sunny'
  | 'partly-cloudy'
  | 'cloudy'
  | 'light-rain'
  | 'heavy-rain'
  | 'thunderstorm';

export interface DailyForecast {
  id: string;
  daySw: string;
  dayEn: string;
  dateStr: string;
  condition: WeatherCondition;
  tempMax: number;
  tempMin: number;
  rainChance: number;
  humidity: number;
  windSpeedKmh: number;
  soilMoistureSw: string;
  soilMoistureEn: string;
  plantingAdviceSw: string;
  plantingAdviceEn: string;
  recommendedActivitySw: string;
  recommendedActivityEn: string;
  activityType: 'planting' | 'spraying' | 'harvesting' | 'weeding' | 'rest';
}

export interface WalletTransaction {
  id: string;
  type: 'receive' | 'send' | 'buy_input' | 'top_up';
  titleSw: string;
  titleEn: string;
  party: string;
  amount: number;
  timestamp: string;
  status: 'completed' | 'pending';
  method: 'mpesa' | 'tigopesa' | 'airtel' | 'wallet';
  reference: string;
}

export interface FarmInputItem {
  id: string;
  nameSw: string;
  nameEn: string;
  categorySw: string;
  categoryEn: string;
  price: number;
  unitSw: string;
  unitEn: string;
  supplier: string;
  rating: number;
  icon: string;
  inStock: boolean;
  descriptionSw: string;
  descriptionEn: string;
}

export interface CropRecord {
  id: string;
  name: string;
  nameSw: string;
  nameEn: string;
  plotName: string;
  plotNameSw: string;
  plotNameEn: string;
  icon: string;
  plantedDays: number;
  totalDays: number;
  stageNoteSw: string;
  stageNoteEn: string;
  adviceSw: string;
  adviceEn: string;
  progressPercent: number;
}

export interface MarketPrice {
  id: string;
  cropNameSw: string;
  cropNameEn: string;
  marketName: string;
  priceDisplay: string;
  priceValue: number;
  unit: string;
  deltaPercent: number;
  isUp: boolean;
  timeframeSw: string;
  timeframeEn: string;
  isGlobal?: boolean;
}

export interface BuyerListing {
  id: string;
  name: string;
  typeSw: string;
  typeEn: string;
  location: string;
  cropSw: string;
  cropEn: string;
  offerPrice: string;
  minVolume: string;
  isVerified: boolean;
  contactPhone: string;
  requirements?: string;
}

export interface CommunityPost {
  id: string;
  authorName: string;
  location: string;
  avatarInitials: string;
  timeAgoSw: string;
  timeAgoEn: string;
  contentSw: string;
  contentEn: string;
  repliesCount: number;
  likesCount: number;
  liked?: boolean;
  tagSw: string;
  tagEn: string;
}

export type SeasonType = 'masika' | 'vuli' | 'kiangazi';

export interface ExpertTip {
  id: string;
  season: SeasonType;
  cropId: 'maize' | 'rice' | 'beans' | 'coffee' | 'vegetables' | 'all';
  cropNameSw: string;
  cropNameEn: string;
  titleSw: string;
  titleEn: string;
  summarySw: string;
  summaryEn: string;
  detailedStepsSw: string[];
  detailedStepsEn: string[];
  yieldImpactSw: string;
  yieldImpactEn: string;
  verifiedExpert: {
    name: string;
    titleSw: string;
    titleEn: string;
    organization: string;
    avatar: string;
  };
  communityEndorsements: number; // e.g. 342 farmers tried & verified
  ratingPercent: number; // e.g. 98%
  growthWalletLink?: {
    actionSw: string;
    actionEn: string;
    recommendedInputSw: string;
    recommendedInputEn: string;
    estimatedCostTsh: number;
    inputId?: string;
  };
  tags: string[];
}

export interface PriceAlert {
  id: string;
  cropId: string;
  cropNameSw: string;
  cropNameEn: string;
  unit: string;
  targetPriceTsh: number;
  condition: 'gte' | 'lte'; // 'gte': >= (Target high price to sell), 'lte': <= (Target low price to buy)
  note?: string;
  isTriggered: boolean;
  createdAt: string;
  triggeredAt?: string;
  currentPriceTsh: number;
}

export interface MarketAlertHistoryItem {
  id: string;
  alertId?: string;
  cropId: string;
  cropNameSw: string;
  cropNameEn: string;
  unit: string;
  targetPriceTsh: number;
  triggeredPriceTsh: number;
  condition: 'gte' | 'lte';
  marketName: string;
  note?: string;
  triggeredAt: string;
  timestamp: number;
  status: 'new' | 'reviewed' | 'action_taken';
  profitDeltaTsh: number;
  profitDeltaPercent: number;
}

export interface ExportMarketDemand {
  id: string;
  country: string; // e.g. 'China 🇨🇳', 'European Union 🇪🇺', 'United States 🇺🇸'
  countryCode: 'CN' | 'EU' | 'US' | 'IN' | 'AE' | 'NL';
  marketName: string;
  marketNameEn: string;
  city: string;
  cropId: string;
  cropSw: string;
  cropEn: string;
  cropIcon: string;
  category: 'oilseeds' | 'pulses' | 'roots' | 'fruits' | 'nuts_spices' | 'beverages';
  requiredVolumeSw: string; // e.g. 'Tan 25,000 (Makontena 1,000)'
  requiredVolumeEn: string;
  minVolumeSw: string; // e.g. 'Kiwango cha Chini: Tan 20 (Kontena 1)'
  minVolumeEn: string;
  standardQuantityReqSw?: string; // e.g. 'Kontena 1 la FCL 40ft (Tan 22 - 25)'
  standardQuantityReqEn?: string;
  exportPriceIndex?: number; // e.g. 138.4 (Base 100)
  exportPriceIndexDelta?: string; // e.g. '+9.4%'
  destinationPort?: string; // e.g. 'Port of Qingdao' or 'Port of Rotterdam'
  transitDays?: number; // e.g. 22 days
  tariffProtocolTagSw?: string; // e.g. 'Zero-Tariff 98%'
  tariffProtocolTagEn?: string;
  estimatedNetProfitMargin?: number; // e.g. 32%
  pricePerKgTsh: number;
  pricePerMtUsd: number;
  priceDisplaySw: string;
  priceDisplayEn: string;
  trendDelta: string;
  isUp: boolean;
  buyerEntity: string;
  tradeProtocolSw: string; // e.g. 'Makubaliano ya Biashara Tanzania-China (Zero-Tariff Protocol)'
  tradeProtocolEn: string;
  qualitySpecsSw: string[];
  qualitySpecsEn: string[];
  deliveryTermsSw: string; // e.g. 'Bandari ya Dar es Salaam (FOB) au Mtwara'
  deliveryTermsEn: string;
  contractDeadline: string;
  urgentStatus?: 'urgent' | 'active' | 'seasonal';
  contactPerson: string;
  contactPhone: string;
}

// Farm Record Keeping Types (Utunzaji wa Kumbukumbu za Shamba)
export interface FarmPlotRecord {
  id: string;
  name: string;
  location: string;
  sizeAcres: number;
  soilTypeSw: string;
  soilTypeEn: string;
  primaryCropSw: string;
  primaryCropEn: string;
  plantedDate: string;
  expectedHarvestDate: string;
  status: 'planted' | 'growing' | 'harvesting' | 'fallow';
  healthScore: number; // e.g. 94%
}

export interface FarmActivityLog {
  id: string;
  plotId: string;
  plotName: string;
  date: string;
  activityType: 'planting' | 'fertilizer' | 'pesticide' | 'weeding' | 'harvest' | 'sales';
  titleSw: string;
  titleEn: string;
  descriptionSw: string;
  descriptionEn: string;
  costTsh: number;
  yieldKg?: number;
  revenueTsh?: number;
  receiptNumber?: string;
}

// Certified Input Supplier (Wauzaji wa Pembejeo Zilizohakikiwa)
export interface CertifiedInputSupplier {
  id: string;
  companyName: string;
  category: 'seeds' | 'fertilizer' | 'chemicals' | 'irrigation';
  categorySw: string;
  categoryEn: string;
  certificationBody: 'TOSCI' | 'TFRA' | 'TPRI' | 'TBS';
  certNumber: string;
  location: string;
  phone: string;
  rating: number;
  verified: boolean;
  featuredProducts: {
    nameSw: string;
    nameEn: string;
    packSize: string;
    priceTsh: number;
    priceDisplay: string;
  }[];
}

// Financial Assistance & Production Collateral Dossier (Taarifa za Uzalishaji kama Dhamana ya Mikopo na Bima)
export interface FarmCreditDossier {
  farmerName: string;
  nationalIdMasked: string;
  creditScore: number; // e.g. 88 / 100
  tier: 'Daraja A (Uaminifu wa Juu)' | 'Daraja B (Imara)' | 'Daraja C';
  totalVerifiedAcres: number;
  activeSeasonsCount: number;
  averageAnnualYieldMt: number;
  grossProductionValueTsh: number;
  netProductionProfitTsh: number;
  recommendedLoanLimitTsh: number;
  recommendedInsuranceCoverTsh: number;
  certifiedBankPartners: string[];
  qrVerificationCode: string;
  issueDate: string;
}

// AI Profitability Analyzer Types (Uchambuzi wa Faida ya Mazao)
export interface CropCostBreakdown {
  seedsTsh: number;
  landPrepTsh: number;
  fertilizerTsh: number;
  cropProtectionTsh: number;
  laborTsh: number;
  transportPortTsh: number;
}

export interface CropProfitabilityModel {
  id: string;
  cropKey: string;
  nameSw: string;
  nameEn: string;
  icon: string;
  category: 'grains' | 'oilseeds' | 'pulses' | 'fruits' | 'tubers' | 'spices';
  primaryExportMarket: {
    country: string;
    flag: string;
    corridor: string;
    fobUsdMt: number;
    tariffProtocolSw: string;
    tariffProtocolEn: string;
    demandLevel: 'high' | 'very_high' | 'surging';
  };
  localMarketPriceTshKg: number;
  exportPriceTshKg: number;
  costBreakdownPerAcre: CropCostBreakdown;
  averageYieldKgPerAcre: number;
  daysToHarvest: number;
  climateRisk: 'low' | 'medium' | 'high';
  waterRequirementSw: string;
  waterRequirementEn: string;
  bestSoilTypes: string[];
  bestSeasons: ('masika' | 'vuli' | 'irrigation')[];
  aiVerdictSw: string;
  aiVerdictEn: string;
  recommendedVarietySw: string;
  recommendedVarietyEn: string;
  buyerNetworkPartnerSw: string;
  buyerNetworkPartnerEn: string;
}

// Plant Health & Pest Diagnostic Doctor Types (Daktari wa Mimea)
export type PlantPart = 'leaves' | 'stem' | 'fruit' | 'roots' | 'whole';
export type AfflictionSeverity = 'low' | 'moderate' | 'high' | 'critical';

export interface PestDiagnosticCase {
  id: string;
  nameSw: string;
  nameEn: string;
  scientificName: string;
  cropKey: string;
  cropNameSw: string;
  cropNameEn: string;
  icon: string;
  plantPart: PlantPart;
  severity: AfflictionSeverity;
  sampleImageUrl: string;
  symptomsSw: string[];
  symptomsEn: string[];
  organicTreatmentSw: string;
  organicTreatmentEn: string;
  chemicalTreatment: {
    productName: string;
    activeIngredient: string;
    tpriRegNumber: string;
    dosageGuideSw: string;
    dosageGuideEn: string;
    preHarvestIntervalDays: number;
    estimatedCostTsh: number;
  };
  preventiveMeasuresSw: string;
  preventiveMeasuresEn: string;
}

// Cooperative Harvest Aggregation & AMCOS Export Pools (Uuzaji wa Pamoja)
export type PoolStatus = 'open' | 'filling_fast' | 'final_call' | 'closed';

export interface AggregationPool {
  id: string;
  titleSw: string;
  titleEn: string;
  cropKey: string;
  cropNameSw: string;
  cropNameEn: string;
  icon: string;
  amcosCoopName: string;
  region: string;
  district: string;
  containerType: '20ft FCL' | '40ft FCL' | 'Reefer 20ft' | 'Bulk Truck';
  targetQuantityKg: number;
  currentPledgedKg: number;
  exportPriceTshKg: number;
  localBrokerPriceTshKg: number;
  exportBuyer: {
    name: string;
    country: string;
    flag: string;
    corridor: string;
  };
  closingDateStr: string;
  dropoffDepotSw: string;
  dropoffDepotEn: string;
  qualityRequirementsSw: string[];
  qualityRequirementsEn: string[];
  advancePaymentPercentage: number; // e.g. 70% advance on dropoff
  status: PoolStatus;
}

export interface HarvestPledge {
  id: string;
  poolId: string;
  farmerName: string;
  farmerPhone: string;
  quantityKg: number;
  totalPayoutTsh: number;
  advancePayoutTsh: number;
  finalBalanceTsh: number;
  warehouseReceiptNumber: string;
  pledgeDate: string;
  status: 'confirmed' | 'delivered' | 'paid';
}



