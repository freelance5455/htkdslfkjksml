export type Role = "worker" | "contractor" | null;

export type SkillCategory =
  | "electrical"
  | "plumbing"
  | "carpentry"
  | "painting"
  | "masonry"
  | "ac_repair"
  | "construction"
  | "other";

export interface CategoryMeta {
  id: SkillCategory;
  label: string;
  emoji: string;
}

export interface GeoPoint {
  x: number; // percentage position on demo map (0-100)
  y: number; // percentage position on demo map (0-100)
  area: string;
}

export interface Worker {
  id: string;
  name: string;
  skill: SkillCategory;
  skillLabel: string;
  secondarySkills: string[];
  rating: number;
  shramScore: number;
  distanceKm: number;
  jobsCompleted: number;
  experienceYears: number;
  verified: boolean;
  languages: string[];
  location: GeoPoint;
  earningsTotal: number;
  onTimeRate: number;
  initials: string;
  color: string; // avatar gradient key
  bio: string;
  availability: string;
}

export type JobStatus =
  | "open"
  | "matching"
  | "accepted"
  | "en_route"
  | "started"
  | "completed"
  | "paid"
  | "cancelled";

export interface JobPosting {
  id: string;
  title: string;
  category: SkillCategory;
  categoryLabel: string;
  emoji: string;
  description: string;
  location: GeoPoint;
  distanceKm: number;
  budgetMin: number;
  budgetMax: number;
  fixedBudget?: number;
  schedule: string;
  durationEstimate: string;
  workersRequired: number;
  requirements: string[];
  status: JobStatus;
  postedBy: string;
  assignedWorkerId?: string;
  createdAt: number;
}

export interface Review {
  id: string;
  fromName: string;
  toName: string;
  rating: number;
  tags: string[];
  comment: string;
  date: string;
  demo: true;
}

export type NotificationType =
  | "job"
  | "payment"
  | "score"
  | "system"
  | "match"
  | "review";

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  time: string;
  read: boolean;
  target?: { screen: string; params?: Record<string, unknown> };
}

export interface Transaction {
  id: string;
  label: string;
  amount: number;
  status: "pending" | "released" | "processing";
  date: string;
  jobId?: string;
}

export interface ToastMessage {
  id: string;
  kind: "success" | "error" | "info";
  message: string;
}
