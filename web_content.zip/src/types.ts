export type PersonaMode = 'utara' | 'santai' | 'formal';
export type ActiveTab = 'chat' | 'image';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  isError?: boolean;
  isThinking?: boolean;
}

export interface PromptSuggestion {
  title: string;
  prompt: string;
  category: 'utara' | 'santai' | 'pintar';
  icon: string;
}
