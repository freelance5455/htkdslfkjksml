export type RevelationType = 'Meccan' | 'Medinan';

export interface SurahMeta {
  number: number;
  name: string; // Arabic name with tashkeel
  englishName: string;
  revelationType: RevelationType;
  numberOfAyahs: number;
  startJuz: number;
  page: number;
}

export interface Ayah {
  number: number; // Global number in Quran (1..6236)
  numberInSurah: number; // 1..N
  text: string; // Arabic text with tashkeel
  juz: number;
  page?: number;
  tafseer?: string;
}

export interface SurahDetail extends SurahMeta {
  bismillahPre: boolean;
  ayahs: Ayah[];
}

export interface Reciter {
  id: string;
  name: string;
  subname: string;
  folder: string; // EveryAyah folder name
  fullSurahServer?: string; // Optional full-surah MP3Quran base URL
}

export interface Bookmark {
  surahNumber: number;
  surahName: string;
  ayahNumber: number;
  date: string;
  previewText?: string;
}

export type ReaderMode = 'verses' | 'mushaf' | 'pages';
export type AppTheme = 'emerald' | 'parchment' | 'dark' | 'light';
export type ArabicFont = 'amiri-quran' | 'cairo' | 'scheherazade';

export interface PageAyah {
  number: number; // Global number in Quran (1..6236)
  numberInSurah: number;
  text: string;
  surahNumber: number;
  surahName: string;
  surahEnglishName: string;
  numberOfAyahs: number;
  revelationType: RevelationType;
  juz: number;
  page: number;
  hizbQuarter?: number;
  tafseer?: string;
}

export interface QuranPageData {
  pageNumber: number; // 1..604
  juz: number;
  hizbQuarter?: number;
  surahsOnPage: {
    number: number;
    name: string;
    englishName: string;
    revelationType: RevelationType;
    numberOfAyahs: number;
  }[];
  ayahs: PageAyah[];
}

export type SalawatSoundType = 'uploaded' | 'mishary' | 'chime' | 'speech' | 'custom';

export interface SalawatReminderSettings {
  enabled: boolean;
  intervalMinutes: number; // Interval in minutes (e.g. 5, 10, 15, 20, 30, etc.)
  soundType: SalawatSoundType;
  customAudioDataUrl?: string; // Stored base64 audio data if user uploaded custom audio
  customAudioName?: string;
  volume: number; // 0.0 to 1.0
  pauseDuringQuranRecitation: boolean; // Do not interrupt Quran recitation
  showNotification: boolean; // Browser system notification
  backgroundMode: boolean; // Keep service active in background and when screen is locked
  persistentNotification: boolean; // Sticky ongoing Android notification for continuous background priority
  keepScreenAwakeDuringReading: boolean; // Wake Lock API for keeping screen on during reading
  count: number; // Counter of Salawat sent
  lastTriggeredAt?: number;
}

export interface UserSettings {
  theme: AppTheme;
  font: ArabicFont;
  fontSize: number; // in pixels, e.g. 24
  readerMode: ReaderMode;
  selectedReciterId: string;
  favoriteReciters?: string[]; // List of favorite reciter IDs
  autoScroll: boolean;
  playbackSpeed: number;
  salawatReminder?: SalawatReminderSettings;
}

export type SpecialRecitationCategory = 'ramadan_maghrib' | 'khashia';

export interface SpecialRecitation {
  id: string;
  title: string;
  reciterName: string;
  reciterId?: string;
  category: SpecialRecitationCategory;
  surahNumber: number;
  surahName: string;
  ayahRange?: string;
  durationText: string;
  approxDurationSec: number;
  audioUrl: string;
  description: string;
  stationOrOccasion: string;
  year?: string;
  tags?: string[];
}

export interface ActiveSpecialTrack {
  id: string;
  title: string;
  reciterName: string;
  category: SpecialRecitationCategory;
  surahNumber: number;
  surahName: string;
  audioUrl: string;
  stationOrOccasion?: string;
}

export interface AyahSearchResult {
  number: number; // Global number in Quran (1..6236)
  numberInSurah: number;
  surahNumber: number;
  surahName: string;
  surahEnglishName: string;
  text: string;
  page: number;
}
