export type NeuralModeId = 'classic' | 'deep' | 'coder' | 'creative' | 'turbo';

export interface NeuralModeConfig {
  id: NeuralModeId;
  name: string;
  badge: string;
  description: string;
  icon: string;
  accentColor: string;
  accentBg: string;
  borderCol: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  displayName: string;
  avatar: string;
  bio?: string;
  theme?: string;
  createdAt: string;
  stats?: {
    totalChats: number;
    totalMessages: number;
  };
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  mode?: NeuralModeId;
  error?: boolean;
}

export interface Chat {
  id: string;
  userId: string;
  title: string;
  mode: NeuralModeId;
  createdAt: string;
  updatedAt: string;
  messages: Message[];
}

export interface ChatSummary {
  id: string;
  title: string;
  mode: NeuralModeId;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
  preview: string;
}
