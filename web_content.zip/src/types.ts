export type GradeLevel =
  | '1st Grade'
  | '2nd Grade'
  | '3rd Grade'
  | '4th Grade'
  | '5th Grade'
  | '6th Grade'
  | '7th Grade'
  | '8th Grade'
  | '9th Grade (Freshman)'
  | '10th Grade (Sophomore)'
  | '11th Grade (Junior / AP)'
  | '12th Grade (Senior / AP)'
  | 'College / Undergraduate';

export interface StudentProfile {
  name: string;
  grade: GradeLevel;
  schoolName: string;
  avatar: string;
  createdAt: string;
  studyStreakDays: number;
  lastStudyDate?: string;
  solvedProblemsCount: number;
  writtenParagraphsCount: number;
  writtenEssaysCount: number;
  checkedGrammarCount: number;
}

export type ActiveTab = 'dashboard' | 'snap-solve' | 'paragraph' | 'essay' | 'grammar' | 'history';

// Snap and Solve Types
export interface SolveStep {
  stepNumber: number;
  title: string;
  explanation: string;
  mathOrFormula?: string;
}

export interface SnapSolveResult {
  subjectDetected: string;
  topic: string;
  transcribedProblem: string;
  directAnswer: string;
  steps: SolveStep[];
  gradeTailoredExplanation: string;
  keyConcepts: string[];
  commonMistakes: string[];
  similarPracticeQuestion?: {
    question: string;
    hint: string;
    answer: string;
  };
}

// Paragraph Types
export interface ParagraphResult {
  paragraph: string;
  actualWordCount: number;
  topicSentence: string;
  supportingSentences: string[];
  concludingSentence: string;
  vocabularyHighlights: {
    word: string;
    definition: string;
    contextInParagraph?: string;
  }[];
  transitionWords: string[];
  gradeLevelAnalysis: string;
}

// Essay Types
export interface EssayOutlineItem {
  section: string;
  summary: string;
  keyPoints: string[];
}

export interface EssayResult {
  title: string;
  thesisStatement: string;
  essay: string;
  actualWordCount: number;
  readingTimeMinutes: number;
  outline: EssayOutlineItem[];
  vocabularyList: {
    word: string;
    definition: string;
  }[];
  worksCited: string[];
  gradeLevelAlignment: string;
}

// Grammar Checker Types
export interface GrammarIssue {
  id: string;
  type: 'grammar' | 'spelling' | 'punctuation' | 'clarity' | 'vocabulary';
  originalText: string;
  suggestedReplacement: string;
  explanation: string;
}

export interface GrammarResult {
  overallScore: number;
  readabilityGrade: string;
  toneDetected: string;
  wordCount: number;
  correctedText: string;
  positiveStrengths: string[];
  issues: GrammarIssue[];
  vocabularyUpgrades: {
    originalWord: string;
    suggestedWord: string;
    reason: string;
  }[];
}

// History item
export interface SavedHistoryItem {
  id: string;
  type: 'snap-solve' | 'paragraph' | 'essay' | 'grammar';
  title: string;
  timestamp: number;
  data: any;
  gradeWhenCreated: string;
}
