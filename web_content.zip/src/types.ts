export type ObjectType =
  | 'cube'
  | 'sphere'
  | 'capsule'
  | 'cylinder'
  | 'plane'
  | 'cone'
  | 'empty'
  | 'light_directional'
  | 'light_point'
  | 'light_spot'
  | 'camera'
  | 'audio_source'
  | 'terrain'
  | 'vehicle'
  | 'npc'
  | 'building'
  | 'water';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface MaterialData {
  id: string;
  name: string;
  baseColor: string;
  metallic: number;
  roughness: number;
  emissive: string;
  emissiveIntensity: number;
  opacity: number;
  wireframe: boolean;
  textureType?: 'none' | 'grid' | 'rock' | 'wood' | 'metal' | 'sand';
}

export interface PhysicsData {
  enabled: boolean;
  type: 'static' | 'dynamic' | 'kinematic';
  mass: number;
  friction: number;
  bounciness: number;
  useGravity: boolean;
  colliderType: 'box' | 'sphere' | 'capsule' | 'mesh';
}

export interface LightingData {
  type: 'directional' | 'point' | 'spot' | 'ambient';
  color: string;
  intensity: number;
  distance: number;
  castShadow: boolean;
  angle?: number;
}

export interface AudioSourceData {
  clipName: string;
  volume: number;
  pitch: number;
  loop: boolean;
  spatial: boolean;
  maxDistance: number;
  soundType: 'synth_laser' | 'synth_jump' | 'synth_engine' | 'synth_drone' | 'synth_bell';
}

export interface AIData {
  enabled: boolean;
  type: 'patrol' | 'chase' | 'wander' | 'idle';
  speed: number;
  detectionRange: number;
  state: 'idle' | 'patrolling' | 'alert' | 'interacting';
}

export interface ScriptComponentData {
  enabled: boolean;
  scriptName: string;
  code: string;
}

export interface EngineObject {
  id: string;
  name: string;
  type: ObjectType;
  visible: boolean;
  locked: boolean;
  parentId: string | null;
  transform: {
    position: Vector3D;
    rotation: Vector3D; // in degrees
    scale: Vector3D;
  };
  material: MaterialData;
  physics?: PhysicsData;
  lighting?: LightingData;
  audio?: AudioSourceData;
  ai?: AIData;
  script?: ScriptComponentData;
  customProps?: Record<string, any>;
}

export interface SceneData {
  id: string;
  name: string;
  createdAt: string;
  fogColor: string;
  fogDensity: number;
  ambientLightColor: string;
  ambientLightIntensity: number;
  skyColor: string;
  groundColor: string;
  gravity: number;
  objects: EngineObject[];
}

export interface ProjectData {
  id: string;
  name: string;
  version: string;
  author: string;
  created: string;
  updated: string;
  currentSceneId: string;
  scenes: SceneData[];
  settings: {
    shadows: boolean;
    antialiasing: boolean;
    postProcessing: boolean;
    pixelRatioLimit: number;
    showGrid: boolean;
    gridSize: number;
    snapToGrid: boolean;
    snapStep: number;
  };
}

export type ViewportMode = 'wireframe' | 'solid' | 'material' | 'preview';
export type TransformGizmoMode = 'translate' | 'rotate' | 'scale';

export interface ConsoleLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
  source?: string;
}

export interface VisualScriptNode {
  id: string;
  title: string;
  type: 'event' | 'condition' | 'action' | 'math';
  x: number;
  y: number;
  inputs: string[];
  outputs: string[];
  params: Record<string, any>;
}

export interface VisualScriptConnection {
  id: string;
  fromNodeId: string;
  fromOutput: string;
  toNodeId: string;
  toInput: string;
}

export interface StreamingCell {
  id: string; // e.g., 'A1', 'B2'
  x: number;
  z: number;
  status: 'loaded' | 'unloaded' | 'loading';
  entitiesCount: number;
}
