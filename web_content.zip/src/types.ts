export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  genre: string;
  year?: number;
  duration: number; // in seconds
  audioUrl: string;
  artworkUrl?: string;
  dateAdded: number;
  playCount: number;
  isFavorite: boolean;
  contentHash?: string;
  fileSize?: number;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl?: string;
  createdAt: number;
  songIds: string[];
}

export type SortField = 'title' | 'artist' | 'album' | 'dateAdded' | 'playCount';
export type LibraryFilter = 'all' | 'favorites' | 'recent';
export type RepeatMode = 'off' | 'all' | 'one';
