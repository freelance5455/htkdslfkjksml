export type DayStatus = 'work' | 'annual';
export type ScheduleMode = 'weekly' | 'rotation';

export interface UserProfile {
  userId: string;
  returnStartDate: string; // "" or YYYY-MM-DD
  scheduleMode: ScheduleMode;
  weeklyRestDays: string;
  rotationWorkDays: number;
  rotationRestDays: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AttendanceRecord {
  userId: string;
  date: string; // YYYY-MM-DD
  monthKey: string; // YYYY-MM
  status: DayStatus;
  note: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ComputedDay {
  date: string; // YYYY-MM-DD
  weekday: number; // 0 (Sun) .. 6 (Sat)
  status: DayStatus;
  source: 'auto' | 'manual';
  isFirstReturnDay: boolean;
  isFuture: boolean;
  note: string;
}

export interface PeriodSummary {
  workDays: number;
  annualLeaveDays: number;
  totalDays: number;
  manualOverrides: number;
}
