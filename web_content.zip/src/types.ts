export type PageType = 'home' | 'events' | 'create' | 'tickets' | 'profile' | 'dashboard' | 'scanner' | 'login' | 'notifications';

export type EventCategory = 'all' | 'concerts' | 'classical' | 'electronic' | 'sports' | 'theatre';

export type PaymentProvider = 'mpesa' | 'paypal';

export type TicketType = 'personal' | 'group';

export interface EventTicketTier {
  id: string;
  name: string; // e.g. "Early Bird", "Regular Admission", "VIP Pass", "VVIP Diamond"
  price: number; // in KSh
  capacity: number; // Customizable passes to sell (any amount)
  description?: string;
  perks?: string;
}

export interface CustomGroupTier {
  id: string;
  name: string; // e.g. "Squad Bundle", "VIP Table (6)", "Couples Pass"
  size: number; // number of passes in group
  price: number; // bundle price in KSh
  perks?: string; // e.g. "Champagne bottle, VIP Fast Track, Lounge Entry"
}

export interface EventItem {
  id: string;
  title: string;
  subtitle: string;
  category: EventCategory;
  categoryLabel: string;
  city: string;
  venue: string;
  address: string;
  mapsUrl: string;
  date: string;
  time: string;
  doorTime: string;
  isoDate: string;
  image: string;
  price: number; // Personal ticket price in KSh
  personalPrice: number; // KSh
  groupPrice: number; // KSh (bundle for group)
  groupSize: number; // e.g. 5 tickets
  tiers?: EventTicketTier[]; // Customizable individual tiers (Early Bird, Regular, VIP, VVIP)
  groupTiers?: CustomGroupTier[]; // Custom group ticket tiers
  hostMpesa: string; // Event owner M-Pesa number
  hostName: string;
  rating: number;
  reviewCount: number;
  organizer: string;
  description: string;
  highlights: string[];
  isFeatured?: boolean;
  isTrending?: boolean;
  isUserCreated?: boolean;
  hostUid?: string;
  updatedAt?: string;
  updatedAtMs?: number;
  lastDeviceId?: string;
  isCuratedDefault?: boolean;
  // Enhanced User & Host Options
  hostEmail?: string;
  autoSendBuyerEmail?: boolean;
  ageRestriction?: 'All Ages' | '18+' | '21+' | string;
  dressCode?: string;
  parkingInfo?: string;
  refundPolicy?: 'Strict' | 'Flexible' | 'No Refunds' | string;
  capacity?: number;
  instagram?: string;
  tiktok?: string;
  gmail?: string;
  website?: string;
  tags?: string[];
}

export interface PurchasedTicket {
  ticketId: string;
  eventId: string;
  eventTitle: string;
  eventImage: string;
  venue: string;
  address: string;
  mapsUrl: string;
  city: string;
  date: string;
  time: string;
  isoDate: string;
  userId?: string;
  hostUid?: string;
  ticketType: TicketType;
  tierId?: string;
  tierName?: string;
  groupTierName?: string;
  groupTierSize?: number;
  ticketPrice: number; // in KSh
  quantity: number;
  totalPaid: number; // in KSh
  paymentMethod: PaymentProvider;
  transactionRef: string;
  orderNumber: string;
  ticketCode: string; // Distinct serial code for each pass (e.g. AUR-PASS-9821-X4)
  purchasedAt: string;
  qrCodeSeed?: string;
  holderName: string;
  holderPhone?: string;
  holderEmail?: string;
  hostMpesa: string; // Event owner M-Pesa
  mpesaReceiptSms?: string; // Real M-Pesa SMS confirmation
  smsSentToPhone?: boolean;
  mpesaSmsText?: string;
  checkedInAt?: string;
  admittedBy?: string;
  status: 'active' | 'used' | 'transferred' | 'refunded';
  refundAmount?: number;
  refundRef?: string;
  refundedAt?: string;
  // Automated Email Delivery Passbook
  emailSentToBuyer?: boolean;
  buyerEmailDeliveredAt?: string;
  emailSentToHost?: boolean;
  hostEmailDeliveredAt?: string;
  updatedAt?: string;
  updatedAtMs?: number;
  lastDeviceId?: string;
}

export interface HostWithdrawal {
  id: string;
  userId?: string;
  amount: number;
  mpesaNumber: string;
  ref: string;
  date: string;
  status: 'completed';
  updatedAt?: string;
  updatedAtMs?: number;
  lastDeviceId?: string;
}

export interface AppNotification {
  id: string;
  userId?: string;
  ticketId?: string;
  eventId?: string;
  title: string;
  message: string;
  date?: string;
  venue?: string;
  isRead: boolean;
  timestamp: string;
  createdAt?: string;
  type: 'event_reminder' | 'payment_payout' | 'check_in' | 'refund' | 'security' | 'system' | 'ticket_sale' | 'email_dispatch';
  refundAmount?: number;
  updatedAt?: string;
  updatedAtMs?: number;
  lastDeviceId?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string; // Primary phone number
  e164Phone?: string; // Normalized E.164 phone number (e.g. +254712345678)
  countryCode?: string; // e.g. KE
  countryName?: string; // e.g. Kenya
  dialCode?: string; // e.g. +254
  avatar: string;
  city: string;
  memberSince: string;
  isVerified: boolean;
  googleConnected: boolean;
  role?: 'user' | 'host' | 'admin';
  paypalEmail: string;
  mpesaNumber: string;
  darkMode: boolean;
  smsNotifications: boolean;
  googleCalendarSync?: boolean;
  appCalendarSync: boolean;
  bio?: string;
  isPublicProfile?: boolean;
  coverImage?: string;
  favorites?: string[];
  isDeleted?: boolean;
  sessionTerminatedAt?: number;
  updatedAt?: string;
  updatedAtMs?: number;
  lastDeviceId?: string;
}


