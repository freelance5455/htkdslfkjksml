export type ScreenType = 'splash' | 'profile' | 'voice' | 'settings';

export type CharacterGender = 'Male' | 'Female';

export interface UserProfile {
  name: string;
  gender: CharacterGender;
  characterName: string;
  persona: 'friend' | 'mentor' | 'funny' | 'formal';
  speechRate: number;
  speechPitch: number;
  language: 'Urdu' | 'English';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  emotion?: 'neutral' | 'happy' | 'thinking' | 'stern';
}

export type BotVoiceState = 'idle' | 'listening' | 'thinking' | 'speaking';
