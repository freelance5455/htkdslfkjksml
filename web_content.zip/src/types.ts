export type TransactionType = 'income' | 'expense' | 'transfer';

export type PaymentMethod = 'cash' | 'bkash' | 'nagad' | 'rocket' | 'bank' | 'card' | 'other';

export type AccountType = 'cash' | 'mobile_banking' | 'card' | 'bank' | 'receivable' | 'payable';

export interface Account {
  id: string;
  nameBangla: string;
  nameEnglish: string;
  type: AccountType;
  openingBalance: number;
  currentBalance?: number;
  accountNumber?: string;
  phoneNumber?: string;
  institutionName?: string;
  icon?: string;
  color?: string;
  isDefault?: boolean;
  isCustom?: boolean;
  notes?: string;
  dueDate?: string;
  createdAt?: number;
}

export interface UserProfile {
  userId?: string;
  cloudPassword?: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  profilePassword?: string;
  isProfileCompleted: boolean;
  joinedDate?: string;
  lastSyncedAt?: string;
  isCloudSynced?: boolean;
}

export interface AuditHistoryLog {
  id: string;
  action: 'CREATE' | 'EDIT' | 'DELETE';
  targetType: 'transaction' | 'account' | 'budget';
  targetId: string;
  timestamp: number;
  dateTimeFormatted: string;
  previousSnapshot?: Partial<Transaction> | Record<string, any>;
  newSnapshot?: Partial<Transaction> | Record<string, any>;
  summaryBangla: string;
  summaryEnglish: string;
  userNote?: string;
}

export interface Category {
  id: string;
  nameBangla: string;
  nameEnglish: string;
  type: 'income' | 'expense';
  icon: string; // lucide icon name
  color: string; // tailwind color class or hex
  isCustom?: boolean;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  paymentMethod: PaymentMethod;
  accountId?: string; // primary account for income/expense
  fromAccountId?: string; // for transfer
  toAccountId?: string; // for transfer
  ledgerPerson?: string; // গ্রহিতা/দাতা লেজার নাম (Recipient / Giver ledger name)
  ledgerAccountId?: string; // আইডি (linked individual ledger account ID)
  date: string; // YYYY-MM-DD
  time?: string;
  note: string;
  isRecurring?: boolean;
  recurringFrequency?: 'monthly' | 'weekly';
  createdAt: number;
  updatedAt?: number;
}

export interface CategoryBudget {
  categoryId: string;
  limit: number;
}

export interface MonthlyBudget {
  month: string; // YYYY-MM
  totalLimit: number;
  categoryLimits: CategoryBudget[];
  alertThreshold: number; // e.g. 80 for 80%
}

export interface ShoppingItem {
  id: string;
  title: string;
  quantity: string;
  estimatedPrice: number;
  actualPrice?: number;
  category: string;
  isBought: boolean;
  notes?: string;
  convertedToTransactionId?: string;
}

export type LockType = 'pin' | 'pattern';

export interface SecuritySettings {
  isPinEnabled: boolean;
  pinHash: string; // Hashed PIN
  isPatternEnabled?: boolean;
  patternHash?: string; // Hashed pattern representation
  activeLockType?: LockType; // 'pin' | 'pattern'
  is2FAEnabled: boolean;
  secret2FAKey?: string;
  autoLockMinutes: number; // 0 = immediate, 1, 5, 15
  isDataEncrypted: boolean;
  lastLockedAt?: number;
}

export type ThemeMode = 'light' | 'dark' | 'oled';
export type ThemeAccent = 
  | 'green' 
  | 'teal' 
  | 'cyan' 
  | 'blue' 
  | 'navy' 
  | 'purple' 
  | 'magenta' 
  | 'red' 
  | 'orange' 
  | 'yellow'
  | 'emerald'
  | 'indigo'
  | 'amber'
  | (string & {});
export type AppFontFamily =
  | 'system'
  | 'hind_siliguri'
  | 'tiro_bangla'
  | 'noto_sans'
  | 'inter'
  | 'poppins'
  | 'jakarta'
  | 'roboto'
  | 'playfair'
  | 'montserrat'
  | 'lato'
  | 'outfit'
  | 'raleway'
  | 'open_sans'
  | 'oswald'
  | 'mono'
  | (string & {});
export type AppFontSize = 'small' | 'medium' | 'large' | 'xlarge';
export type AppFontWeight = 'normal' | 'medium' | 'semibold' | 'bold';

export interface FinancialGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  targetDate?: string;
  category?: string;
  icon?: string;
  color?: string;
  notes?: string;
  createdAt: number;
}

export type NavigationTab = 'dashboard' | 'reports' | 'budget' | 'shopping' | 'security' | 'settings' | 'theme' | 'language' | 'loan';

export type CloudDriveProvider = 'google_drive' | 'onedrive' | 'dropbox' | 'custom';
export type SyncTimerInterval = 'realtime' | '15m' | '1h' | '6h' | 'daily' | 'manual';

export interface BackupSyncConfig {
  connected: boolean;
  provider: CloudDriveProvider;
  accountEmail: string;
  folderName: string;
  lastSyncedAt?: string;
  syncInterval: SyncTimerInterval;
  isAutoSyncActive: boolean;
  lastSyncStatus?: 'idle' | 'syncing' | 'success' | 'error';
  lastStatusMessage?: string;
  syncedItemsCount?: number;
  wifiOnly?: boolean;
}

export interface AppSettings {
  language: 'bn' | 'en';
  useBanglaDigits: boolean;
  currencySymbol: string;
  themeMode: ThemeMode;
  themeAccent: ThemeAccent;
  secondaryAccent?: ThemeAccent;
  accentPercentage?: number;
  themeShade?: number;
  fontFamily?: AppFontFamily;
  fontSize?: AppFontSize;
  fontWeight?: AppFontWeight;
  googleDriveConnected: boolean;
  googleDriveLastSynced?: string;
  autoBackupIntervalDays: number;
  backupSyncConfig?: BackupSyncConfig;
}

export interface EncryptedDataPayload {
  v: number;
  timestamp: number;
  ciphertext: string;
}
