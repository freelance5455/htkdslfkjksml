export interface SoundItem {
  id: string;
  name: string;
  blob?: Blob;
  url?: string;
  duration?: number;
  size?: number;
  type: string;
  createdAt: number;
}

export interface AndroidFileItem {
  path: string;
  name: string;
  description: string;
  category: 'manifest' | 'gradle' | 'kotlin' | 'java' | 'res' | 'docs';
  content: string;
}
