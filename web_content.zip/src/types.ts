export type UserRole = 'customer' | 'provider' | 'delivery' | 'admin';

export type ServiceCategoryType = 
  | 'food'
  | 'grocery'
  | 'ride'
  | 'home_service'
  | 'salon'
  | 'massage'
  | 'electrician'
  | 'plumber'
  | 'repair'
  | 'cleaning'
  | 'courier'
  | 'artists'
  | 'custom';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string;
  walletBalance: number;
  savedAddresses: Address[];
  emergencyContacts: EmergencyContact[];
  createdAt: string;
}

export interface Address {
  id: string;
  label: 'Home' | 'Work' | 'Other';
  street: string;
  locality: string;
  city: string;
  pincode: string;
  coordinates?: { lat: number; lng: number };
  isDefault?: boolean;
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

export interface Provider {
  id: string;
  userId: string;
  businessName: string;
  category: ServiceCategoryType;
  description: string;
  experienceYears: number;
  rating: number;
  reviewCount: number;
  avatar: string;
  bannerImage: string;
  serviceRadiusKm: number;
  serviceCity: string;
  isOnline: boolean;
  isVerified: boolean;
  kycStatus: 'pending' | 'verified' | 'rejected';
  documents: {
    idProofType: 'Aadhaar' | 'PAN' | 'DrivingLicense' | 'TradeLicense';
    documentNumber: string;
    documentUrl: string;
    submittedAt: string;
  }[];
  pricingStartsAt: number;
  commissionPercentage: number;
  customServices: ServiceItem[];
  earnings: {
    total: number;
    withdrawn: number;
    pendingPayout: number;
  };
  phone: string;
}

export interface DeliveryPartner {
  id: string;
  userId: string;
  name: string;
  phone: string;
  vehicleType: 'Bike' | 'Scooter' | 'EV_Bike';
  vehicleNumber: string;
  isOnline: boolean;
  currentLocation: {
    lat: number;
    lng: number;
    locality: string;
  };
  rating: number;
  totalDeliveries: number;
  walletBalance: number;
  activeOrderId?: string;
  kycStatus: 'pending' | 'verified' | 'rejected';
}

export interface CategoryMeta {
  id: ServiceCategoryType;
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  badge?: string;
  commissionPercent: number;
}

export interface ServiceItem {
  id: string;
  categoryId: ServiceCategoryType;
  providerId?: string;
  title: string;
  description: string;
  price: number;
  discountPrice?: number;
  durationMinutes?: number;
  imageUrl: string;
  isVeg?: boolean;
  unit?: string; // e.g. "kg", "pack", "visit", "item"
  rating: number;
  tags?: string[];
  options?: {
    name: string;
    choices: { label: string; price: number }[];
  }[];
}

export interface RideVehicleOption {
  id: 'auto' | 'bike' | 'mini' | 'sedan' | 'suv';
  title: string;
  capacity: number;
  baseFare: number;
  perKmRate: number;
  etaMinutes: number;
  icon: string;
  description: string;
}

export interface CourierDetails {
  senderName: string;
  senderPhone: string;
  pickupAddress: string;
  receiverName: string;
  receiverPhone: string;
  dropAddress: string;
  packageType: 'Document' | 'Food/Tiffin' | 'Electronics' | 'Clothes' | 'Other';
  weightKg: number;
  instruction?: string;
  estimatedCost: number;
}

export type OrderStatus = 
  | 'placed'
  | 'accepted'
  | 'preparing'
  | 'assigned'
  | 'out_for_delivery'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'refunded';

export type PaymentMethod = 'upi' | 'card' | 'wallet' | 'cash';
export type PaymentStatus = 'pending' | 'paid' | 'refunded';

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  category: ServiceCategoryType;
  providerId?: string;
  providerName?: string;
  deliveryPartnerId?: string;
  deliveryPartnerName?: string;
  deliveryPartnerPhone?: string;
  items: {
    serviceId: string;
    title: string;
    quantity: number;
    price: number;
    selectedOptions?: string[];
  }[];
  rideDetails?: {
    vehicleType: string;
    pickupLocation: string;
    dropLocation: string;
    distanceKm: number;
    driverOtp: string;
  };
  courierDetails?: CourierDetails;
  scheduledSlot?: string;
  deliveryAddress?: Address;
  itemTotal: number;
  deliveryFee: number;
  platformFee: number;
  taxes: number;
  discount: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  eta: string;
  deliveryOtp?: string;
  createdAt: string;
  cancelledAt?: string;
  cancelReason?: string;
  refundAmount?: number;
  rating?: number;
  reviewComment?: string;
}

export interface ChatMessage {
  id: string;
  sessionId: string;
  senderId: string;
  senderRole: UserRole;
  senderName: string;
  text: string;
  timestamp: string;
  isSystem?: boolean;
}

export interface ChatSession {
  id: string;
  orderId?: string;
  customerId: string;
  customerName: string;
  participantId: string; // provider or delivery partner
  participantName: string;
  participantRole: 'provider' | 'delivery';
  freeMessagesAllowed: number;
  freeMessagesUsed: number;
  isPaidUnlocked: boolean;
  paidUnlockPrice: number;
  lastMessage?: string;
  updatedAt: string;
}

export interface AdminConfig {
  platformCommissionDefaults: Record<ServiceCategoryType, number>;
  chatRules: {
    freeMessageLimit: number;
    unlockFee: number;
    allowPaidChat: boolean;
    providerChatSharePercent: number;
  };
  deliveryRules: {
    baseFare: number;
    perKmRate: number;
    freeDeliveryOver: number;
    platformFeePerOrder: number;
  };
  safetyHelpline: string;
  policeHelpline: string;
  womenHelpline: string;
}

export interface WithdrawalRequest {
  id: string;
  providerId: string;
  providerName: string;
  amount: number;
  bankAccount: string;
  ifscOrUpi: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  processedAt?: string;
}

export interface SafetyIncidentReport {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  orderId?: string;
  location: string;
  coordinates?: { lat: number; lng: number };
  emergencyType: 'medical' | 'safety' | 'accident' | 'dispute' | 'sos';
  status: 'active' | 'investigating' | 'resolved';
  timestamp: string;
  notes: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'chat' | 'safety' | 'payment';
  read: boolean;
  timestamp: string;
  linkId?: string;
}
