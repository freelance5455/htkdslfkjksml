export type Language = 'ar' | 'en';

export type ServiceType = 
  | 'medical_sector'         // القطاع الطبي الشامل
  | 'addiction_rehab'        // علاج الإدمان والتأهيل
  | 'medical_tourism'        // السياحة العلاجية والاستشفائية
  | 'foreign_reception'      // استقبال المرضى الأجانب
  | 'patient_followup'       // متابعة المرضى
  | 'international_services';// الخدمات الدولية

export type RequestStatus = 
  | 'new'            // جديد
  | 'under_review'   // قيد المراجعة
  | 'coordinating'   // جاري التنسيق
  | 'confirmed'      // تم التأكيد
  | 'completed'      // مكتمل
  | 'cancelled';     // ملغى

export interface PatientRequest {
  id: string;               // e.g. ALM-REQ-8902
  patientName: string;
  country: string;
  phone: string;
  email: string;
  preferredLanguage: string;
  serviceType: ServiceType;
  specialtyOrNeed: string;
  description: string;
  preferredContact: 'whatsapp' | 'phone' | 'email';
  agreedToPrivacy: boolean;
  status: RequestStatus;
  createdAt: string;
  assignedHospital?: string;
  assignedDoctor?: string;
  coordinatorNotes?: string;
  estimatedCost?: string;
  hotelBooked?: boolean;
  airportPickup?: boolean;
  translatorAssigned?: string;
}

export interface MedicalCenter {
  id: string;
  nameAr: string;
  nameEn: string;
  categoryAr: string;
  categoryEn: string;
  city: string;
  country: string;
  accreditation: string[];   // e.g. ["JCI", "GAHAR ذهبي", "ISO 9001"]
  specialties: string[];
  bedCapacity: number;
  rating: number;
  verified: boolean;
  imageUrl: string;
  descriptionAr: string;
  descriptionEn: string;
}

export interface Doctor {
  id: string;
  nameAr: string;
  nameEn: string;
  titleAr: string;
  titleEn: string;
  specialtyAr: string;
  specialtyEn: string;
  hospitalAr: string;
  hospitalEn: string;
  experienceYears: number;
  languages: string[];
  rating: number;
  consultationType: string[];
  avatarUrl: string;
}

export interface RehabCenter {
  id: string;
  nameAr: string;
  nameEn: string;
  location: string;
  programs: string[];
  confidentialityLevel: 'عالي السرية' | 'Strictly Confidential';
  amenities: string[];
  verifiedStatus: boolean;
  descriptionAr: string;
  descriptionEn: string;
}

export interface HealingDestination {
  id: string;
  nameAr: string;
  nameEn: string;
  governorate: string;
  climateBenefitAr: string;
  climateBenefitEn: string;
  featuredTreatmentsAr: string[];
  featuredTreatmentsEn: string[];
  seasonAr: string;
  seasonEn: string;
  imageUrl: string;
  disclaimerAr: string;
  disclaimerEn: string;
}

export interface TranslatorEscort {
  id: string;
  name: string;
  languages: string[];
  specialty: string;
  status: 'available' | 'on_assignment' | 'off_duty';
  activeAssignments: number;
  rating: number;
}

export interface DemoInvoice {
  id: string;
  requestId: string;
  patientName: string;
  serviceSummary: string;
  amountUsd: number;
  status: 'paid' | 'pending' | 'draft';
  date: string;
}
