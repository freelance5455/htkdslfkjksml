export interface Folder {
  id: string;
  name: string;
  color?: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  folderId: string;
  dealDate: string; // YYYY-MM-DD
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type ReminderStatus = 'today' | 'overdue' | 'upcoming';

export interface CustomerReminderInfo {
  customer: Customer;
  dealDate: Date;
  reminderDate: Date; // Deal date + 25 days (the 26th day) at 09:00 AM
  status: ReminderStatus;
  daysRemaining: number; // positive = days left, negative = days overdue, 0 = today
  is26thDay: boolean; // true if today is exactly the 26th day
  formattedDealDate: string;
  formattedReminderDate: string;
}

export type FilterStatus = 'all' | 'today' | 'overdue' | 'upcoming';
