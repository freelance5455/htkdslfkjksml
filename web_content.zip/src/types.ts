export interface TranscriptSegment {
  id: string;
  speaker: 'Speaker A' | 'Speaker B';
  speakerName: string;
  speakerRole: 'salesperson' | 'prospect';
  text: string;
  startTime: number;
  endTime: number;
  startTimeFormatted: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  sentimentScore: number; // 0 to 100 (where >60 is positive, 40-60 neutral, <40 hesitant/negative)
  topic?: string;
  coachingTag?: 'strength' | 'opportunity' | 'objection' | 'closing' | null;
}

export interface SentimentDataPoint {
  timeSeconds: number;
  timestamp: string;
  engagementScore: number; // 0 to 100 (engagement & rapport level)
  speaker: 'Speaker A' | 'Speaker B' | 'Both';
  sentiment: 'positive' | 'neutral' | 'negative';
  keyEvent?: string;
  quoteSnippet?: string;
}

export interface CoachingStrength {
  title: string;
  description: string;
  quote: string;
  timestamp: string;
  timeSeconds: number;
  competency: string;
  impact: string;
}

export interface CoachingOpportunity {
  title: string;
  description: string;
  quote: string;
  timestamp: string;
  timeSeconds: number;
  competency: string;
  coachingTip: string;
  suggestedScript: string;
}

export interface CoachingCardData {
  threeThingsDoneWell: [CoachingStrength, CoachingStrength, CoachingStrength];
  threeMissedOpportunities: [CoachingOpportunity, CoachingOpportunity, CoachingOpportunity];
  overallSummary: string;
  executiveSummary: string;
  keyMetrics: {
    talkPaceWpm: number;
    questionsAsked: number;
    objectionsFaced: number;
    fillerWordsCount: number;
    longestMonologueSeconds: number;
    nextStepsConfirmed: boolean;
  };
  recommendedActionPlan: string[];
}

export interface CallAnalysis {
  id: string;
  callTitle: string;
  callType: 'Enterprise Discovery' | 'Negotiation & Close' | 'Cold Outbound' | 'Product Demo' | 'Renewal & Upsell';
  date: string;
  duration: number; // total duration in seconds
  durationFormatted: string;
  dealSize?: string;
  stage?: string;
  overallScore: number; // 0 - 100
  dealHealth: 'strong' | 'promising' | 'at-risk' | 'stalled';
  salesperson: {
    name: string;
    role: string;
    avatarUrl?: string;
  };
  prospect: {
    name: string;
    role: string;
    company: string;
    avatarUrl?: string;
  };
  talkListenRatio: {
    salespersonPercent: number;
    prospectPercent: number;
  };
  transcript: TranscriptSegment[];
  sentimentTimeline: SentimentDataPoint[];
  coachingCard: CoachingCardData;
  audioUrl?: string;
  isAiGenerated?: boolean;
}
