export interface Carpeta {
  id: string;
  nombre: string;
  fechaCreacion: number;
  fechaModificacion: number;
  descripcion?: string;
  color?: string;
}

export interface Foto {
  id: string;
  carpetaId: string;
  nombre: string;
  dataUrl: string;
  fecha: number;
  tamanoBytes: number;
  ancho?: number;
  alto?: number;
}

export type Pantalla =
  | { tipo: 'splash' }
  | { tipo: 'inicio' }
  | { tipo: 'ajustes' }
  | { tipo: 'carpeta'; carpetaId: string }
  | { tipo: 'camara'; carpetaId: string }
  | { tipo: 'previa'; tempFoto: { dataUrl: string; tamanoBytes: number; ancho: number; alto: number }; carpetaId: string }
  | { tipo: 'visor'; carpetaId: string; fotoId: string }
  | { tipo: 'salida' };

export type ModoFlash = 'off' | 'on' | 'auto';
