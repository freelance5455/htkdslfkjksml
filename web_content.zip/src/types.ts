export type ToolType =
  | "stick"
  | "axe"
  | "hoe"
  | "water"
  | "seed_taro"
  | "seed_paddy"
  | "seed_eggplant"
  | "treat"
  | "fertilizer";

export type WeatherType = "clear" | "rain" | "fog";
export type SeasonType = "spring" | "summer" | "monsoon" | "winter";

export interface Item {
  id: string;
  name: string;
  bengaliName: string;
  type: "tool" | "seed" | "resource" | "crop" | "consumable";
  description: string;
  icon: string;
  count: number;
  maxStack?: number;
  tier?: number;
  power?: number;
  value: number;
}

export interface Player {
  x: number;
  y: number;
  z: number; // Vertical jump height
  vz: number; // Vertical velocity
  isJumping: boolean;
  isSprinting: boolean;
  stamina: number;
  maxStamina: number;
  width: number;
  height: number;
  speed: number;
  facing: "up" | "down" | "left" | "right";
  isMoving: boolean;
  isActing: boolean;
  actionTimer: number;
  actionType: "swing" | "chop" | "till" | "water" | "hand" | "pet" | null;
  walkFrame: number;
  handAnim: number;
  hp: number;
  maxHp: number;
  energy: number;
  maxEnergy: number;
  coins: number;
  equippedSlot: number;
  isExhausted?: boolean;
}

export interface Dog {
  id: string;
  name: string;
  bengaliName: string;
  x: number;
  y: number;
  z: number; // Puppy jump height
  vz: number;
  width: number;
  height: number;
  speed: number;
  facing: "up" | "down" | "left" | "right";
  state:
    | "wander"
    | "flee"
    | "follow"
    | "curious"
    | "eating"
    | "pet"
    | "digging"
    | "sitting"
    | "napping"
    | "playing";
  fearLevel: number;
  loyalty: number;
  speechBubble: string | null;
  bubbleTimer: number;
  targetX: number;
  targetY: number;
  wanderTimer: number;
  isFriend: boolean;
  color: string;
  sizeScale: number;
  tailWagSpeed: number;
  bellyRollTimer: number;
  digTimer: number;
  scratchTimer?: number;
  napTimer?: number;
  isSitting?: boolean;
  isMissing?: boolean;
  rescued?: boolean;
  furType?: "black" | "white" | "yellow";
}

export interface CampfireData {
  x: number;
  y: number;
  radius: number; // Safe building radius (in px)
  level: number;
  fuel: number; // Max 100
  maxRadius: number;
  logsDeposited: number;
  logsNeededForNextLevel: number;
  visibleMapRadius: number; // Exploration fog of war boundary
}

export interface BuildingStructure {
  id: string;
  type: "fence" | "chest" | "shelter" | "torch" | "dog_bed" | "crafting_table";
  name: string;
  bengaliName: string;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
}

export interface MonsterDog {
  id: string;
  name: string;
  bengaliName: string;
  x: number;
  y: number;
  z: number;
  vz: number;
  hp: number;
  maxHp: number;
  speed: number;
  facing: "up" | "down" | "left" | "right";
  state: "stalk" | "roam" | "attack" | "flee_fire" | "howl";
  targetX: number;
  targetY: number;
  growlTimer: number;
  speechBubble: string | null;
  bubbleTimer: number;
  attackCooldown: number;
}

export interface Tree {
  id: string;
  x: number;
  y: number;
  type: "mango" | "taro_giant" | "sal" | "bamboo";
  hp: number;
  maxHp: number;
  state: "mature" | "falling" | "stump" | "sapling" | "growing";
  regrowthTimer: number;
  maxRegrowthTime: number;
}

export interface FarmTile {
  x: number;
  y: number;
  isTilled: boolean;
  isWatered: boolean;
  waterLevel: number;
  cropType: "taro" | "paddy" | "eggplant" | null;
  growthStage: number;
  growthTimer: number;
  growthRequired: number;
}

export interface GroundDrop {
  id: string;
  x: number;
  y: number;
  item: Item;
  lifespan: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface AmbientCritter {
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: "butterfly" | "firefly" | "leaf";
  color: string;
  size: number;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  vy: number;
}

export interface Recipe {
  id: string;
  name: string;
  bengaliName: string;
  description: string;
  category: "tools" | "agriculture" | "special";
  resultItem: Item;
  ingredients: { itemId: string; count: number; name: string }[];
  requiresTier?: number;
}

export interface BiochemicalCompound {
  name: string;
  formula: string;
  pubchemCid: number;
  role: string;
}

export interface ScientificPlant {
  id: string;
  bengaliName: string;
  scientificName: string;
  family: string;
  growthDurationDays?: number;
  biochemicalCompounds: BiochemicalCompound[];
  ethnobotanyBengali: string;
  medicinalUses: string;
  soilRequirements?: string;
}

export interface LandPlot {
  id: string;
  name: string;
  bengaliName: string;
  description: string;
  cost: number;
  isUnlocked: boolean;
  minCol: number;
  maxCol: number;
  minRow: number;
  maxRow: number;
  signCol: number;
  signRow: number;
}

export interface Achievement {
  id: string;
  title: string;
  bengaliTitle: string;
  description: string;
  bengaliDescription: string;
  targetCount: number;
  currentCount: number;
  isUnlocked: boolean;
  rewardCoins: number;
  isClaimed: boolean;
  icon: string;
}

export interface GameStats {
  treesCut: number;
  daysSurvived: number;
  cropsHarvested: number;
  dogsBefriended: number;
  landBought: number;
  toolsCrafted: number;
  treasuresDug: number;
}

export interface RoadmapStage {
  id: string;
  stageNumber: number;
  title: string;
  bengaliTitle: string;
  subtitle: string;
  bengaliSubtitle: string;
  description: string;
  bengaliDescription: string;
  targetMetric: "days" | "dogs" | "trees" | "crops" | "land" | "tools" | "all";
  currentValue: number;
  targetValue: number;
  isUnlocked: boolean;
  isCompleted: boolean;
  rewardCoins: number;
  unlockedPerk: string;
  icon: string;
}

export interface UiCustomizationSettings {
  hudScale: "ultra_compact" | "compact" | "normal";
  controllerSize: "extra_small" | "small" | "medium" | "large";
  controllerOpacity: number; // 0.3 to 1.0
  showDpad: boolean;
  autoLandscapeSmall: boolean; // Automatically make UI small in landscape
  hotbarScale: "compact" | "normal"; // Smaller hotbar for landscape screens
  showHandButton: boolean; // Dedicated Hand / Pet button
  showSprintButton: boolean;
  showJumpButton: boolean;
  isMinimalMode: boolean; // Minimal clean UI mode
}
