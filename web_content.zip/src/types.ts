export type ScreenType =
  | 'splash'
  | 'welcome'
  | 'login'
  | 'register'
  | 'health-profile-setup'
  | 'home'
  | 'history'
  | 'notifications'
  | 'profile'
  | 'settings'
  | 'feature-medicine'
  | 'feature-report'
  | 'feature-tracker'
  | 'feature-reminder'
  | 'feature-education'
  | 'feature-emergency'
  | 'feature-services'
  | 'feature-symptom-guide';

export type BottomTabType = 'home' | 'history' | 'profile';

export type PreferredLanguage = 'English' | 'Hindi' | 'Marathi';

export interface UserHealthProfile {
  age?: number | string;
  gender?: string;
  height?: number | string;
  weight?: number | string;
  bloodGroup?: string;
  allergies?: string;
  existingDiseases?: string;
  emergencyContact?: string;
  preferredLanguage: PreferredLanguage;
  bmi?: string;
}

export interface UserAccount {
  id: string;
  fullName: string;
  email: string;
  mobileNumber: string;
  passwordHash: string; // Securely hashed, never plain text
  role: string;
  createdAt: string;
  healthProfile: UserHealthProfile;
}

export interface FeatureCardItem {
  id: ScreenType;
  title: string;
  description: string;
  category: string;
  badge: string;
  iconName: string;
  bgColor: string;
  iconColor: string;
  borderColor: string;
}

export interface HealthTip {
  id: string;
  title: string;
  summary: string;
  category: string;
  readTime: string;
  bgGradient: string;
  iconName: string;
}

export interface HistoryItem {
  id: string;
  title: string;
  featureName?: string;
  type: string;
  date: string;
  time?: string;
  timestamp?: number;
  status: string;
  summary: string;
  tags: string[];
  screen?: ScreenType;
}

export interface EmergencyContact {
  id: string;
  fullName: string;
  relationship: string;
  mobileNumber: string;
  createdAt?: string;
}

export interface EmergencyGuide {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  color: string;
  bgLight: string;
  borderColor: string;
  symptoms: string[];
  firstAidSteps: string[];
  doNotDo: string[];
  emergencyAction: string;
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  phone: string;
  distanceKm: number;
  distanceText?: string;
  estimatedTime?: string;
  latitude: number;
  longitude: number;
  is24x7?: boolean;
  hasICU?: boolean;
  specialty?: string;
  osmId?: number | string;
  osmType?: string;
  placeId?: number | string;
  internationalPhone?: string;
  formattedPhone?: string;
}

export interface PharmacyMedicineStock {
  id: string;
  name: string;
  genericName: string;
  category: string;
  categoryName: string;
  brandNames: string[];
  inStock: boolean;
  stockStatus: 'In Stock' | 'Limited Stock' | 'Available on Order';
  packSize?: string;
}

export interface PharmacyStore {
  id: string;
  name: string;
  address: string;
  phone: string;
  distanceKm: number;
  distanceText: string;
  estimatedTime?: string;
  latitude: number;
  longitude: number;
  operator?: string;
  openingHours?: string;
  is24x7?: boolean;
  availableStock?: PharmacyMedicineStock[];
}

export interface MedicalReportPage {
  id: string;
  pageNumber: number;
  dataUrl: string;
  name?: string;
  mimeType: string;
  fileType: 'image' | 'pdf';
  fileSize?: number;
}

export type TestStatus = 'normal' | 'high' | 'low' | 'abnormal' | 'attention';

export interface MedicalTestResult {
  testName: string;
  result: string;
  unit?: string | null;
  referenceRange?: string | null;
  status: TestStatus;
  explanation: string;
  explanationHi?: string;
  explanationMr?: string;
  pageNumbers?: number[];
  duplicateNote?: string | null;
  duplicateNoteHi?: string | null;
  duplicateNoteMr?: string | null;
}

export interface TrustedSourceReference {
  name: string;
  organizationType: string;
  url?: string;
  topicTitle?: string;
  retrievedAt?: string;
}

export interface EducationalTestMeaning {
  testName: string;
  clinicalMeaning: string;
  clinicalMeaningHi?: string;
  clinicalMeaningMr?: string;
}

export interface ConditionEducationalContent {
  overview: string;
  overviewHi?: string;
  overviewMr?: string;
  types: string[];
  typesHi?: string[];
  typesMr?: string[];
  causesAndRisks: string[];
  causesAndRisksHi?: string[];
  causesAndRisksMr?: string[];
  signsAndSymptoms: string[];
  signsAndSymptomsHi?: string[];
  signsAndSymptomsMr?: string[];
  diagnosisOverview: string;
  diagnosisOverviewHi?: string;
  diagnosisOverviewMr?: string;
  relevantTestsAndMeaning: EducationalTestMeaning[];
  complications: string[];
  complicationsHi?: string[];
  complicationsMr?: string[];
  preventionAndLifestyle: string[];
  preventionAndLifestyleHi?: string[];
  preventionAndLifestyleMr?: string[];
  treatmentApproaches: string[];
  treatmentApproachesHi?: string[];
  treatmentApproachesMr?: string[];
  whenToSeeDoctor: string[];
  whenToSeeDoctorHi?: string[];
  whenToSeeDoctorMr?: string[];
  additionalEducationalNotes?: string;
  additionalEducationalNotesHi?: string;
  additionalEducationalNotesMr?: string;
}

export interface ConditionEducationSection {
  conditionIdentified: boolean;
  conditionName?: string;
  conditionNameHi?: string;
  conditionNameMr?: string;
  relevanceExplanation?: string;
  relevanceExplanationHi?: string;
  relevanceExplanationMr?: string;
  retrievalSuccess: boolean;
  retrievalErrorNotice?: string;
  retrievalErrorNoticeHi?: string;
  retrievalErrorNoticeMr?: string;
  trustedSources: TrustedSourceReference[];
  educationalContent?: ConditionEducationalContent;
}

export interface MedicalReportAnalysis {
  patientInfo: {
    name?: string | null;
    age?: string | null;
    gender?: string | null;
    reportDate?: string | null;
    doctorRemarks?: string | null;
    doctorRemarksHi?: string | null;
    doctorRemarksMr?: string | null;
    labOrHospitalName?: string | null;
  };
  overallSummary: string;
  overallSummaryHi?: string;
  overallSummaryMr?: string;
  abnormalResults: MedicalTestResult[];
  normalResults: MedicalTestResult[];
  needsAttention: MedicalTestResult[];
  allTests: MedicalTestResult[];
  unreadablePages: Array<{
    pageNumber: number;
    reason: string;
    reasonHi?: string;
    reasonMr?: string;
  }>;
  conditionEducation?: ConditionEducationSection;
  safetyDisclaimer: string;
  safetyDisclaimerHi?: string;
  safetyDisclaimerMr?: string;
}

export type SymptomCategory =
  | 'General & Constitutional'
  | 'Respiratory & Throat'
  | 'Head & Neurological'
  | 'Digestive & Abdominal'
  | 'Chest & Cardiovascular'
  | 'Musculoskeletal'
  | 'Skin & Allergies';

export interface SymptomItem {
  id: string;
  name: string;
  category: SymptomCategory;
  description: string;
  isRedFlagTrigger?: boolean;
  nameTranslations?: Record<PreferredLanguage, string>;
  descriptionTranslations?: Record<PreferredLanguage, string>;
}

export type UrgencyLevel =
  | 'Low urgency'
  | 'Medical consultation recommended'
  | 'Urgent medical attention';

export interface AuthoritativeSource {
  organization: string; // e.g. 'WHO', 'CDC', 'NIH / NIDDK', 'NHS UK'
  title: string;
  guidelineTopic: string;
}

export interface PossibleCondition {
  id: string;
  name: string;
  description: string;
  matchingSymptoms: string[];
  totalMatchCount: number;
  sources: AuthoritativeSource[];
  nameTranslations?: Record<PreferredLanguage, string>;
  descriptionTranslations?: Record<PreferredLanguage, string>;
}

export interface SymptomAnalysisResult {
  selectedSymptoms: SymptomItem[];
  urgencyLevel: UrgencyLevel;
  urgencyReason: string;
  possibleConditions: PossibleCondition[];
  redFlags: string[];
  generalSelfCare: string[];
  whenToSeeDoctor: string[];
  sources: AuthoritativeSource[];
  disclaimer: string;
  language?: PreferredLanguage;
}
