export type CurrencyType =
  | 'coins'
  | 'gems'
  | 'diamonds'
  | 'gold'
  | 'rubies'
  | 'energy'
  | 'crystals'
  | 'credits';

export interface IdentifiedResource {
  id: string;
  filePath: string;
  currencyType: CurrencyType;
  keyName: string;
  originalValue: number;
  currentValue: number;
  fileType: 'json' | 'xml' | 'lua' | 'plist' | 'ini' | 'cfg' | 'txt' | 'other';
  lineNumber: number;
  contextSnippet: string;
  rawMatch: string;
}

export type ModificationMethod = 'manual' | 'automatic';

export interface PackageMetadata {
  fileName: string;
  fileSize: number;
  fileType: 'apk' | 'xapk';
  packageName: string;
  appName: string;
  version: string;
  fileCount: number;
  zipInstance: any; // JSZip instance
  rawFile?: File | Blob;
}

export interface RecompilationStep {
  id: string;
  label: string;
  status: 'pending' | 'in_progress' | 'completed' | 'error';
  detail?: string;
}

export type AppStage =
  | 'upload'
  | 'analyzing'
  | 'results'
  | 'manual_editing'
  | 'auto_editing'
  | 'recompiling'
  | 'completed';
