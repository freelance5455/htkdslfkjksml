export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type ArrowColor = 
  | 'black'
  | 'blue' 
  | 'red' 
  | 'green' 
  | 'yellow' 
  | 'purple' 
  | 'orange' 
  | 'pink' 
  | 'cyan' 
  | 'gold';

export type TileType = 
  | 'ARROW' 
  | 'OBSTACLE_WALL'      // Fixed rock/wall obstacle
  | 'OBSTACLE_WOOD'      // Breakable barrier (takes hit or bomb)
  | 'GATE'               // One-way gate or switch gate
  | 'SWITCH'             // Switch tile that toggles gates
  | 'PORTAL';            // Portal tile (links to partner portal)

export interface BoardTile {
  id: string;
  x: number;
  y: number;
  type: TileType;
  direction?: Direction; // For arrows & one-way gates
  isEscaping?: boolean;
  isBlocked?: boolean;
  isHinted?: boolean;
  
  // Long bent arrow path coordinates (ordered from tail to head)
  points?: { x: number; y: number }[];
  length?: number;
  exitWaypoints?: { x: number; y: number }[]; // Predefined railway path beyond the head to exit
  
  // Special mechanics
  isLocked?: boolean;          // Requires key arrow or key switch
  isFrozen?: boolean;          // Frozen arrow in ice
  isRotator?: boolean;         // Rotates 90 deg clockwise on tap if blocked or after move
  isBomb?: boolean;            // Explodes neighboring barriers on escape
  color?: ArrowColor | 'cyan' | 'amber' | 'rose' | 'emerald' | 'violet'; // Color coding for arrows/gates/switches
  
  // Gate / Switch specifics
  gateOpen?: boolean;          // For GATE tiles
  portalTargetId?: string;     // For PORTAL tiles (id of destination)
  woodHealth?: number;         // 1 or 2 hits remaining for breakable wood
}

export interface MoveRecord {
  tile: BoardTile;
  escapedTile: BoardTile;
  affectedTiles?: { id: string; prevProps: Partial<BoardTile> }[];
  comboCount: number;
}

export interface LevelConfig {
  id: number;
  worldId: number;
  levelNumber: number; // 1 to 20 inside world (or overall 1 to 200)
  name: string;
  themeDescription?: string;
  gridWidth: number;
  gridHeight: number;
  tiles: BoardTile[];
  targetMoves?: number;
  timeLimit?: number; // In seconds (for timed challenge mode)
  starThresholds: {
    threeStarMoves: number;
    twoStarMoves: number;
  };
  mechanicsIntroduced?: string[];
  tutorialText?: string;
}

export interface WorldInfo {
  id: number;
  name: string;
  theme: string;
  iconName: string;
  bgColor: string;
  boardBgColor: string;
  accentColor: string;
  description: string;
  requiredStars: number;
  levelRange: [number, number]; // e.g. [1, 20]
}

export type GameMode = 'SHORT_ARROW' | 'LONG_ARROW';

export interface PlayerStats {
  coins: number;
  hintsRemaining: number;
  undosRemaining: number;
  unlockedWorlds: number[];
  highestShortArrowLevel: number;
  highestLongArrowLevel: number;
  completedShortLevels: Record<number, { stars: number; bestMoves: number; bestTime: number }>;
  completedLongLevels: Record<number, { stars: number; bestMoves: number; bestTime: number }>;
  highestUnlockedLevel?: number; // legacy alias
  completedLevels?: Record<number, { stars: number; bestMoves: number; bestTime: number }>; // legacy alias
  equippedArrowSkin: string;
  equippedBoardTheme: string;
  equippedParticle: string;
  unlockedSkins: string[];
  unlockedThemes: string[];
  unlockedParticles: string[];
  lastDailyRewardDate: string | null;
  dailyRewardStreak: number;
  lastDailyChallengeDate?: string | null;
  dailyChallengeCompleted?: boolean;
}

export type Language = 'en' | 'hi' | 'bn';

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  voiceEnabled: boolean;
  vibrationEnabled: boolean;
  language: Language;
  hapticsSupported: boolean;
}

export interface CollectionItem {
  id: string;
  name: string;
  category: 'skin' | 'theme' | 'particle';
  cost: number;
  previewColor: string;
  description: string;
}
