export type Tab = "player" | "generate" | "models" | "library" | "tests" | "docs";

export interface Cue {
  start: number;
  end: number;
  text: string;
  failed?: boolean;
}

export type SubtitleKind = "generated" | "imported" | "translated";

export interface SubtitleSet {
  id: string;
  videoKey: string;
  videoName: string;
  title: string;
  sourceLang: string; // 'en' | 'ur' | 'auto->xx' | 'import'
  targetLang: string; // 'ur' | 'orig'
  kind: SubtitleKind;
  cues: Cue[];
  srt: string;
  vtt: string;
  failedCount: number;
  createdAt: number;
}

export interface VideoMeta {
  key: string;
  name: string;
  size: number;
  duration?: number;
  lastUsed: number;
  hasBlob: boolean;
}

export interface ActiveVideo {
  blob: Blob;
  url: string;
  name: string;
  size: number;
  duration?: number;
}

export interface TransWord {
  s: number;
  e: number;
  t: string;
}

export interface GenStage {
  id: "prep" | "asr" | "translate" | "save";
  label: string;
  state: "pending" | "active" | "done" | "error";
  done: number;
  total: number;
  detail?: string;
}

export type GenEvent =
  | { t: "stage"; stage: GenStage }
  | { t: "info"; msg: string }
  | { t: "warn"; msg: string }
  | { t: "done"; set: SubtitleSet; words: number; cues: number; failed: number };

export interface Settings {
  subsOn: boolean;
  subsSize: "S" | "M" | "L";
  asrModel: string;
  mtModel: string;
  sourceLang: string;
  installed: Record<string, { at: number; bytes?: number }>;
}

export type TestStatus = "pass" | "fail" | "skip" | "run";

export interface SelfTestResult {
  id: string;
  name: string;
  status: TestStatus;
  detail: string;
  at?: number;
}

export interface ModelState {
  status: "missing" | "installing" | "installed" | "error";
  progress: number;
  detail?: string;
  bytes?: number;
  error?: string;
}
