export type WingoInterval = '30s' | '1m' | '3m' | '5m';

export type WingoSize = 'BIG' | 'SMALL';

export type WingoColor = 'GREEN' | 'RED' | 'VIOLET' | 'RED_VIOLET' | 'GREEN_VIOLET';

export type MainTab = 'wingo' | 'play_game' | 'vtrx' | 'seven_step';

export interface AIServerNode {
  id: number;
  name: string;
  emoji: string;
  winRate: number;
  tag: string;
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  bgGradient: string;
  textColor: string;
}

export interface WingoPrediction {
  period: string;
  size: WingoSize;
  number: number;
  luckyNumbers: number[];
  color: WingoColor;
  confidence: number;
  logicTag: string;
  notes: string;
  serverName: string;
  serverEmoji: string;
  status: 'PENDING' | 'WIN' | 'LOSS';
  resultNumber?: number;
  resultSize?: WingoSize;
}

export interface HistoryRecord {
  period: string;
  prediction: string;
  resultSize: WingoSize;
  resultNumber: number;
  resultColor: WingoColor;
  status: 'WIN' | 'LOSS';
  profit: number;
  timestamp: string;
}

export interface MartingaleStep {
  level: number;
  mult: number;
  text: string;
  amount: number;
  cumulative: number;
  winReturn: number;
}

export interface TerminalLogEntry {
  id: string;
  time: string;
  text: string;
  level: 'info' | 'success' | 'warn' | 'error';
}
