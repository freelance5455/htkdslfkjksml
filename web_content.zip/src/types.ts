export type ActiveTab = 'chat' | 'music' | 'video' | 'photo';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface SavedItem {
  id: string;
  type: 'music' | 'video' | 'photo';
  title: string;
  subtitle: string;
  content: string;
  timestamp: number;
}
