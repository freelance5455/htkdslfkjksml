export type CefrBand = 'A0' | 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';

export type GameModeId =
  | 'missing'
  | 'scramble'
  | 'type_en'
  | 'type_ar'
  | 'listen_type'
  | 'mcq'
  | 'tf'
  | 'match'
  | 'mixed'
  | 'study';

export type ArcadeGameModeId =
  | 'wordle'
  | 'speed_blitz'
  | 'memory_flip'
  | 'word_rain'
  | 'save_rocket';

export type SentenceGameModeId =
  | 'sentence_order'
  | 'sentence_error'
  | 'sentence_dictation'
  | 'sentence_vanish'
  | 'sentence_cloze'
  | 'sentence_chat_reply'
  | 'sentence_speak'
  | 'sentence_blitz'
  | 'sentence_pattern_swap';

export type UiLanguageCode =
  | 'ar'
  | 'hi'
  | 'zh'
  | 'ru'
  | 'de'
  | 'fr'
  | 'es'
  | 'it'
  | 'pt'
  | 'sv';

export type PlacementSkillId =
  | 'vocabulary'
  | 'sentences'
  | 'reading'
  | 'writing'
  | 'listening'
  | 'speaking';

export interface PlacementResult {
  cefrBand: CefrBand;
  overallScore: number;
  nextBand: CefrBand | null;
  pointsToNext: number;
  progressInBandPct: number;
  skillScores: Record<PlacementSkillId, number>;
  weakestSkills: PlacementSkillId[];
  completedAt: number;
}

export type SourceType = 'level' | 'random' | 'mistakes' | 'favorites';

export type NavTab =
  | 'games'
  | 'levels'
  | 'dict'
  | 'sentences'
  | 'listening'
  | 'ai_coach'
  | 'articles'
  | 'grammar'
  | 'stats'
  | 'settings';

export type ScreenId =
  | 'games'
  | 'game_setup'
  | 'levels'
  | 'band_levels'
  | 'level_detail'
  | 'dict'
  | 'sentences'
  | 'listening'
  | 'ai_coach'
  | 'articles'
  | 'grammar'
  | 'stats'
  | 'settings'
  | 'game'
  | 'arcade_game'
  | 'study'
  | 'sentence_game'
  | 'word_detail';

export type SrsRating = 'again' | 'hard' | 'good' | 'easy';

export interface SrsCardState {
  wordId: number;
  easeFactor: number;
  intervalDays: number;
  repetitions: number;
  lapses: number;
  dueAt: number;
  lastReviewedAt: number;
}

export interface VocabEntry {
  id: number;
  band: CefrBand;
  en: string;
  ar: string;
}

export interface VocabStore {
  words: VocabEntry[];
  byBand: Record<CefrBand, number[]>;
  normEn: string[];
  normAr: string[];
}

export interface BandMeta {
  ar: string;
  desc: string;
  color: string;
  bgClass: string;
  textClass: string;
}

export interface GameDef {
  id: GameModeId;
  name: string;
  desc: string;
  featured?: boolean;
}

export interface PersistedSettings {
  levelSize: number;
  dailyGoal: number;
  todayDate: string;
  todayCount: number;
  theme: 'dark' | 'light';
  uiLang: UiLanguageCode;
  sfx: boolean;
  autoSpeak: boolean;
  ttsRate: number;
  mcqDir: 'en2ar' | 'ar2en';
  lastGame: GameModeId;
  lastBand: CefrBand;
  lastSubLevel: number;
  xp: number;
  streak: number;
  bestStreak: number;
  completed: Record<string, number>;
  mistakes: number[];
  favorites: number[];
  mastered: number[];
  favoriteSentences: number[];
  practicedSentences: number[];
  srsCards: Record<number, SrsCardState>;
  placementResult?: PlacementResult | null;
  listeningProgress?: Partial<Record<CefrBand, ListeningBandProgress>>;
  completedGrammarIds?: string[];
  savedWordNotes?: SavedWordNote[];
  wordMastery?: Record<string, WordMasteryRecord>;
  // New student-centered learning features (persisted offline in localStorage)
  onboardingCompleted?: boolean;
  learningGoal?: LearningGoalId;
  dailyPaceMinutes?: DailyPaceMinutes;
  dailyPlanDate?: string;
  dailyPlanSteps?: DailyPlanStepsState;
  dailySentencesCount?: number;
  studyHistory?: Record<string, number>;
  streakFreezes?: number;
  lastFreezeWeek?: string;
  lastActiveDate?: string;
  // Arcade & Sentence Pro game records (persisted offline in localStorage)
  wordleDailyDate?: string;
  wordleDailyStatus?: 'won' | 'lost';
  wordleDailyGuesses?: number;
  bestBlitzScore?: number;
  bestMemoryMoves?: number;
  bestWordRainScore?: number;
  bestRocketStreak?: number;
  bestSentenceBlitzScore?: number;
  pixabayKey: string;
  unsplashKey: string;
  backendUrl: string;
  usingCustom: boolean;
  customSourceName: string;
}

export type LearningGoalId = 'daily_chat' | 'work_interviews' | 'travel' | 'study_exams';

export type DailyPaceMinutes = 5 | 10 | 20;

export type DailyPlanStepId = 'srs' | 'words' | 'sentences' | 'grammarOrListening';

export interface DailyPlanStepsState {
  srs?: boolean;
  words?: boolean;
  sentences?: boolean;
  grammarOrListening?: boolean;
  bonusClaimed?: boolean;
}

export interface LetterSlot {
  type: 'fixed' | 'blank' | 'punct';
  target: string;
  value: string;
  tileId: number | null;
}

export interface BankTile {
  id: number;
  ch: string;
  used: boolean;
}

export interface McqOption {
  id: number;
  label: string;
  isCorrect: boolean;
}

export interface WordExampleSentence {
  text: string;
  segments: Array<{ text: string; highlight: boolean }>;
  source: string;
}

export interface WordInfoData {
  phonetic: string;
  posEn: string;
  posAr: string;
  examples: WordExampleSentence[];
}

export interface WordPhotoData {
  found: boolean;
  providerLabel?: string;
  imageUrl?: string;
  thumbUrl?: string;
  isFallbackCard?: boolean;
  alt?: string;
  photographer?: string;
  photographerUrl?: string;
  photoPageUrl?: string;
  providerHomeUrl?: string;
  ttl?: number;
  message?: string;
}

export interface ServerVideoExample {
  videoId: string;
  title: string;
  source: string;
  watchUrl: string;
  clipStartSec: number;
  clipEndSec: number;
  transcriptText: string;
  transcriptHtml?: string;
}

export interface VideoCaptionCue {
  startSec: number;
  endSec: number;
  text: string;
}

export interface WordVideoClip {
  id: string;
  word: string;
  matchedTerm: string;
  videoUrl: string;
  posterUrl: string;
  title: string;
  speaker: string;
  sourceLabel: string;
  wordStartSec: number;
  startSec: number;
  endSec: number;
  durationSec: number;
  captionText: string;
  cues: VideoCaptionCue[];
}

export interface WordClipsPageResponse {
  word: string;
  page: number;
  clips: WordVideoClip[];
  hasMore: boolean;
  totalFound: number;
}

export interface SentenceEntry {
  id: number;
  num: number;
  en: string;
}

export interface SpokenWordToken {
  word: string;
  matched: boolean;
}

export interface SpeechEvalResult {
  heardText: string;
  score: number;
  isMatch: boolean;
  tokens?: SpokenWordToken[];
  feedbackAr: string;
  tipAr?: string;
  source: 'local' | 'ai';
}

export type PatternSwapSlotType = 'subject' | 'verb' | 'object' | 'preposition' | 'free';

export interface PatternSwapWrongPart {
  wrong: string;
  right: string;
  reasonAr: string;
}

export interface PatternSwapEvalResult {
  heardText: string;
  swappedCorrectly: boolean;
  isGrammaticallyCorrect: boolean;
  score: number;
  correctedEn: string;
  newSentenceAr: string;
  feedbackAr: string;
  wrongParts: PatternSwapWrongPart[];
  source: 'ai' | 'offline';
}

export type CoachScenarioId =
  | 'free'
  | 'travel'
  | 'interview'
  | 'restaurant'
  | 'shopping'
  | 'doctor'
  | 'hotel'
  | 'friends';

export type AiProviderPref = 'auto' | 'open' | 'gemini';

export interface AiCoachCorrection {
  hasErrors: boolean;
  correctedEn: string;
  explanationAr: string;
  betterPhrasing: string;
  score: number;
}

export interface AiCoachTurn {
  id: string;
  role: 'user' | 'model';
  textEn: string;
  textAr?: string;
  audioUrl?: string;
  correction?: AiCoachCorrection;
  suggestions?: string[];
  providerLabel?: string;
  timestamp: number;
}

export interface AiCoachApiResponse {
  userTranscript: string;
  replyEn: string;
  replyAr: string;
  hasErrors: boolean;
  correctedEn: string;
  explanationAr: string;
  betterPhrasing: string;
  score: number;
  suggestions: string[];
  providerLabel?: string;
}

export type AiCoachModeId = 'chat' | 'picture' | 'topic' | 'article_summary';

export interface WordSentenceCheckResult {
  userSentence: string;
  containsTargetWord: boolean;
  isCorrect: boolean;
  score: number;
  correctedEn: string;
  wrongParts: string[];
  explanationAr: string;
  betterExampleEn: string;
}

export interface SentenceCorrectionItem {
  original: string;
  corrected: string;
  hasError: boolean;
  explanationAr: string;
}

export interface WritingEvaluationResult {
  userText: string;
  hasErrors: boolean;
  score: number;
  overallFeedbackAr: string;
  contentFeedbackAr: string;
  correctedText: string;
  wrongParts: string[];
  sentenceFeedback: SentenceCorrectionItem[];
  improvedVersionEn: string;
  vocabularyTips: string[];
  providerLabel?: string;
}

export interface PictureScenePrompt {
  id: string;
  titleAr: string;
  titleEn: string;
  unsplashQuery: string;
  fallbackImageUrl: string;
  sceneDescriptionEn: string;
  guidingQuestionsAr: string[];
  helpfulWords: string[];
}

export interface WritingTopicPrompt {
  id: string;
  titleEn: string;
  titleAr: string;
  promptEn: string;
  promptAr: string;
  keywords: string[];
  level: CefrBand;
}

export interface ArticleItem {
  id: string;
  title: string;
  titleAr: string;
  topicId: string;
  typeLabel: string;
  level: CefrBand;
  readingMinutes: number;
  summaryHintAr: string;
  paragraphs: string[];
}

export interface WordLookupResult {
  word: string;
  ar: string;
  posAr?: string;
  band?: CefrBand;
  wordId?: number;
}

export type CaptionLangCode = 'off' | 'en' | UiLanguageCode | 'dual';

export interface ListeningBandProgress {
  watchedSec: number;
  completedVideoIds: string[];
  quizScores: Record<string, number>;
}

export interface ListeningLevelConfig {
  band: CefrBand;
  nextBand: CefrBand | null;
  requiredHours: number;
  minDurationSec: number;
  maxDurationSec: number;
  titleAr: string;
  descAr: string;
  topics: string[];
}

export interface ListeningVideoItem {
  id: string;
  slug: string;
  title: string;
  speaker: string;
  sourceLabel?: string;
  durationSec: number;
  posterUrl: string;
  band: CefrBand;
  topicTag?: string;
}

export interface ListeningCatalogResponse {
  band: CefrBand;
  requiredHours: number;
  totalDurationSec: number;
  videos: ListeningVideoItem[];
}

export interface ListeningQuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface ListeningVideoDetail {
  id: string;
  slug: string;
  title: string;
  speaker: string;
  sourceLabel?: string;
  durationSec: number;
  videoUrl: string;
  posterUrl: string;
  enCues: VideoCaptionCue[];
  translatedCues: Record<string, VideoCaptionCue[]>;
}

export type GrammarCategoryId =
  | 'foundations'
  | 'tenses'
  | 'modals'
  | 'modifiers'
  | 'connectors'
  | 'voice_speech'
  | 'clauses'
  | 'advanced';

export type GrammarExerciseType = 'mcq' | 'fill_blank' | 'spot_error' | 'reorder';

export interface GrammarExample {
  en: string;
  ar: string;
  highlight?: string;
}

export interface GrammarCommonMistake {
  wrong: string;
  right: string;
  noteAr: string;
}

export interface GrammarExercise {
  id: string;
  type: GrammarExerciseType;
  prompt: string;
  /** For mcq: 4 options; for spot_error: 4 underlined tokens in the sentence */
  options?: string[];
  /** Index of correct option (mcq) or index of erroneous segment (spot_error) */
  correctIndex?: number;
  /** For fill_blank: accepted string answers; for reorder: target full English sentence */
  acceptedAnswers?: string[];
  /** For spot_error: corrected full sentence */
  correctedSentence?: string;
  /** For reorder: exact ordered target sentence */
  targetSentence?: string;
  hint?: string;
  explanationAr: string;
}

export interface GrammarLesson {
  id: string;
  band: CefrBand;
  category: GrammarCategoryId;
  titleEn: string;
  titleAr: string;
  formula: string;
  summaryAr: string;
  howToUseAr: string[];
  whenToUseAr: string[];
  commonMistakes: GrammarCommonMistake[];
  examples: GrammarExample[];
  exercises: GrammarExercise[];
}

export interface LocalizedGrammarPayload {
  title: string;
  summary: string;
  howToUse: string[];
  whenToUse: string[];
  mistakeNotes: string[];
  exampleNotes: string[];
}

export type WordHubTabId = 'overview' | 'relationships' | 'usage' | 'videos' | 'games';

export type WordHubGameId =
  | 'synonym_match'
  | 'antonym_challenge'
  | 'definition_quiz'
  | 'word_family'
  | 'collocation_challenge'
  | 'context_challenge'
  | 'memory_match'
  | 'sentence_completion';

export interface WordHubSynonym {
  word: string;
  ar: string;
  nuanceAr: string;
  exampleEn: string;
  exampleAr: string;
}

export interface WordHubAntonym {
  word: string;
  ar: string;
  contrastAr: string;
  exampleEn: string;
  exampleAr: string;
}

export type WordDerivativePos = 'Noun' | 'Verb' | 'Adjective' | 'Adverb';

export interface WordHubDerivative {
  word: string;
  pos: WordDerivativePos;
  posAr: string;
  ar: string;
  exampleEn: string;
}

export interface WordHubRelatedWord {
  word: string;
  ar: string;
  relationAr: string;
}

export interface WordHubCollocation {
  phrase: string;
  ar: string;
  exampleEn: string;
  exampleAr: string;
}

export interface WordHubExample {
  en: string;
  ar: string;
  register?: 'neutral' | 'formal' | 'informal';
}

export interface WordHubMistake {
  wrong: string;
  right: string;
  noteAr: string;
}

export interface WordHubExpression {
  phrase: string;
  ar: string;
  exampleEn: string;
}

export interface WordHubFormalRegister {
  registerLabel: 'Formal' | 'Informal' | 'Neutral';
  registerLabelAr: string;
  noteAr: string;
  formalAlt?: string;
  informalAlt?: string;
}

export interface WordHubData {
  word: string;
  posEn: string;
  posAr: string;
  ipaUs: string;
  ipaUk: string;
  audioUs?: string;
  audioUk?: string;
  definitionEn: string;
  definitionAr: string;
  secondaryMeanings?: Array<{ posEn: string; definitionEn: string; ar: string }>;
  synonyms: WordHubSynonym[];
  antonyms: WordHubAntonym[];
  wordFamily: WordHubDerivative[];
  relatedWords: WordHubRelatedWord[];
  collocations: WordHubCollocation[];
  examples: WordHubExample[];
  commonMistakes: WordHubMistake[];
  usageNotes: string[];
  formalVsInformal?: WordHubFormalRegister | null;
  idioms: WordHubExpression[];
  phrasalVerbs: WordHubExpression[];
  wordOrigin: string;
  memoryTip: string;
  source?: 'dictionary+ai' | 'dictionary' | 'offline';
}

export type SavedWordNoteKind =
  | 'synonym'
  | 'antonym'
  | 'derivative'
  | 'related'
  | 'collocation'
  | 'example'
  | 'idiom'
  | 'phrasal_verb';

export interface SavedWordNote {
  id: string;
  parentWord: string;
  kind: SavedWordNoteKind;
  text: string;
  meaningAr: string;
  extra?: string;
  savedAt: number;
}

export interface WordMasteryRecord {
  wordKey: string;
  completedGames: WordHubGameId[];
  pronunciationPassed?: boolean;
  sentencePassed?: boolean;
  correctAnswers: number;
  wrongAnswers: number;
  updatedAt: number;
}



