export interface FileItem {
  id: string;
  name: string;
  path: string;
  content: string;
  language: 'html' | 'css' | 'javascript' | 'json' | 'typescript' | string;
  isFolder?: boolean;
  parentId?: string | null;
}

export interface Project {
  id: string;
  name: string;
  updatedAt: string;
  files: FileItem[];
  assignmentId?: string;
}

export interface UserSession {
  role: 'guest' | 'student' | 'teacher';
  name: string;
  username?: string;
  classKey?: string;
  photoUrl?: string;
  uid?: string;
}

export interface AssignmentAttachment {
  id: string;
  title: string;
  type: 'image' | 'file';
  urlOrContent: string;
}

export interface Assignment {
  id: string;
  classKey: string;
  teacherId: string;
  teacherName: string;
  title: string;
  description: string;
  requiredTech: 'html' | 'html-css' | 'html-css-js';
  attachments?: AssignmentAttachment[];
  initialTemplateFiles?: FileItem[];
  createdAt: string;
}

export interface Submission {
  id: string;
  assignmentId: string;
  studentName: string;
  classKey: string;
  files: FileItem[];
  submittedAt: string;
  status?: 'submitted' | 'reviewed';
  score?: string;
  feedback?: string;
}

export interface ThemeConfig {
  id: string;
  name: string;
  isDark: boolean;
  bg: string;
  surface: string;
  surfaceHover: string;
  header: string;
  sidebar: string;
  border: string;
  text: string;
  textMuted: string;
  accent: string;
  accentText: string;
  accentHover: string;
  editorBg: string;
  monacoTheme: string;
}

export interface AccentConfig {
  id: string;
  name: string;
  color: string;
  hover: string;
  text: string;
}
