export type ImageModel = 'gemini-3-pro-image-preview' | 'gemini-3.1-flash-image-preview';

export type ImageSize = '1K' | '2K' | '4K' | '512px';

export type AspectRatio = '1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '9:16' | '16:9' | '21:9';

export interface BannerFormat {
  id: string;
  name: string;
  width: number;
  height: number;
  category: 'IAB Standard' | 'High Impact' | 'Mobile' | 'Social';
  aspectRatioLabel: string;
  recommendedAspect: AspectRatio;
  shape: 'square' | 'leaderboard' | 'skyscraper' | 'story' | 'socialLandscape';
  description: string;
}

export interface AdCopyGroup {
  headline: string;
  subhead: string;
  cta: string;
}

export interface AdCreativeData {
  brandName: string;
  category?: string;
  primaryHeadline: string;
  subheadline: string;
  offerBadge: string;
  ctaText: string;
  secondaryCtaText?: string;
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  textColor: string;
  imagePrompt: string;
  imageUrl?: string;
  productUrl?: string;
  productDescription?: string;
  copyVariations: {
    square: AdCopyGroup;
    leaderboard: AdCopyGroup;
    skyscraper: AdCopyGroup;
    story: AdCopyGroup;
    socialLandscape: AdCopyGroup;
  };
}

export interface ProductPreset {
  id: string;
  title: string;
  brand: string;
  url: string;
  description: string;
  theme: string;
  tone: string;
  primaryColor: string;
  badge: string;
  sampleImage: string;
}
