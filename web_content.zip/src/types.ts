export type PaymentMethodId = 'easypaisa' | 'jazzcash' | 'nayapay' | 'sadapay' | 'bank';

export interface PaymentMethod {
  id: PaymentMethodId;
  name: string;
  tagline: string;
  badgeUrl: string;
  color: string;
  accentBg: string;
  inputLabel: string;
  placeholder: string;
  accountNumberPattern: string;
  minWithdrawPKR: number;
  maxWithdrawPKR: number;
}

export interface WithdrawalRecord {
  id: string;
  trxId: string;
  method: PaymentMethodId;
  methodName: string;
  accountNumber: string;
  accountTitle: string;
  bankName?: string;
  amountPKR: number;
  coinsDebited: number;
  feePKR: number;
  status: 'processing' | 'completed' | 'pending';
  timestamp: number;
  estimatedArrival: string;
}

export interface UpgradeItem {
  id: string;
  title: string;
  description: string;
  category: 'tap' | 'energy' | 'idle' | 'crit';
  level: number;
  maxLevel: number;
  baseCost: number;
  costMultiplier: number;
  effectLabel: string;
  currentValue: number;
  nextValue: number;
  iconName: string;
}

export interface EarnTask {
  id: string;
  title: string;
  rewardCoins: number;
  rewardPKR: number;
  category: 'daily' | 'social' | 'special';
  actionUrl?: string;
  actionLabel: string;
  completed: boolean;
  claimed: boolean;
  cooldownSeconds?: number;
}

export interface LivePayoutItem {
  id: string;
  userName: string;
  city: string;
  amountPKR: number;
  method: PaymentMethodId;
  timeAgo: string;
}

export interface DailyStreakDay {
  day: number;
  coins: number;
  pkrValue: number;
  claimed: boolean;
  isToday: boolean;
  isFuture: boolean;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  targetCount: number;
  currentCount: number;
  rewardCoins: number;
  rewardPKR: number;
  claimed: boolean;
  type: 'taps' | 'upgrades' | 'spins' | 'balance';
}
