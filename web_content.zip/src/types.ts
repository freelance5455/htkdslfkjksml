// ─── Core market types ───────────────────────────────────────────────────────

export type SymbolId = "BTCUSDT" | "ETHUSDT" | "SOLUSDT" | "BNBUSDT";

export const SYMBOLS: SymbolId[] = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"];

export type Interval =
  | "1m" | "3m" | "5m"
  | "15m" | "30m" | "1h" | "2h"
  | "4h" | "6h" | "8h" | "12h" | "1d" | "1w";

export const ALL_INTERVALS: Interval[] = [
  "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "1w",
];

export const INTERVAL_MS: Record<Interval, number> = {
  "1m": 60_000, "3m": 180_000, "5m": 300_000,
  "15m": 900_000, "30m": 1_800_000, "1h": 3_600_000, "2h": 7_200_000,
  "4h": 14_400_000, "6h": 21_600_000, "8h": 28_800_000, "12h": 43_200_000,
  "1d": 86_400_000, "1w": 604_800_000,
};

export interface Candle {
  time: number; // open time ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Tick {
  symbol: SymbolId;
  price: number;
  qty: number;
  side: "buy" | "sell";
  ts: number;
  exchange: ExchangeId;
}

export type ExchangeId =
  | "Bybit" | "Binance" | "OKX" | "Kraken" | "Coinbase" | "KuCoin" | "SIM";

export interface FeedHealth {
  exchange: ExchangeId;
  latencyMs: number | null;
  connected: boolean;
  msgCount: number;
  droppedFrames: number;
}

export interface OrderBookLevel {
  price: number;
  size: number;
}

export interface OrderBook {
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
}

// ─── Positions / trades ──────────────────────────────────────────────────────

export type TradeSide = "LONG" | "SHORT";
export type TradeSource = "BOT" | "COPY" | "MANUAL";
export type OrderType = "MARKET" | "LIMIT" | "STOP_LIMIT" | "TRAILING_STOP";

export interface Position {
  id: string;
  symbol: SymbolId;
  side: TradeSide;
  source: TradeSource;
  strategyId: string;
  strategyName: string;
  masterTrader?: string;
  qty: number;
  leverage: number;
  entryPrice: number;
  markPrice: number;
  margin: number;
  stopLoss: number;
  takeProfit: number;
  tp1?: number; // tier-1 target (30%)
  tp2?: number; // tier-2 target (40%)
  tp1Hit?: boolean;
  tp2Hit?: boolean;
  trailingStop?: boolean;
  atrAtEntry: number;
  pnl: number;
  pnlPct: number;
  openedAt: number;
  diagnostics?: TradeDiagnostics;
}

export interface ClosedTrade {
  id: string;
  symbol: SymbolId;
  side: TradeSide;
  source: TradeSource;
  strategyId: string;
  strategyName: string;
  masterTrader?: string;
  qty: number;
  leverage: number;
  entryPrice: number;
  exitPrice: number;
  pnl: number;
  pnlPct: number;
  fees: number;
  closeReason: string;
  openedAt: number;
  closedAt: number;
  diagnostics?: TradeDiagnostics;
}

export interface TradeDiagnostics {
  rsi5m: number;
  rsi1h: number;
  emaSlope: number;
  vwapOffsetPct: number;
  volumeRatio: number;
  atrPct: number;
  hourOfDay: number;
  confluenceScore: number;
  regime: MarketRegime;
}

export interface PendingOrder {
  id: string;
  symbol: SymbolId;
  side: TradeSide;
  type: OrderType;
  qty: number;
  leverage: number;
  limitPrice?: number;
  stopPrice?: number;
  trailPct?: number;
  createdAt: number;
}

// ─── Multi-timeframe analysis ────────────────────────────────────────────────

export interface IntervalAnalysis {
  interval: Interval;
  score: number; // -1 .. +1 (bearish .. bullish)
  rsi: number;
  ema9: number;
  ema20: number;
  ema50: number;
  vwap: number;
  atr: number;
  atrPct: number;
  adx: number;
  bbWidth: number;
  volumeRatio: number;
  lastClose: number;
}

export interface MtfSnapshot {
  symbol: SymbolId;
  updatedAt: number;
  intervals: Partial<Record<Interval, IntervalAnalysis>>;
  microScore: number;   // 1m-15m
  mediumScore: number;  // 30m-2h
  macroScore: number;   // 4h-1w
  confluence: number;   // -100 .. +100
  aligned: boolean;
  direction: TradeSide | null;
}

// ─── Strategy engine ─────────────────────────────────────────────────────────

export type MarketRegime = "TRENDING" | "RANGING" | "BREAKOUT";

export interface StrategyDef {
  id: string;
  name: string;
  nameHe: string;
  icon: string;
  compatibleRegimes: MarketRegime[];
  description: string;
}

export interface StrategyScore {
  id: string;
  name: string;
  nameHe: string;
  icon: string;
  winRate: number;
  profitFactor: number;
  sharpe: number;
  avgPnl: number;
  ev: number;
  signals: number;
  paused: boolean;
  active: boolean;
}

export interface RegimeState {
  regime: MarketRegime;
  adx: number;
  atrPct: number;
  bbWidth: number;
  confidence: number;
  label: string;
}

// ─── Copy trading ────────────────────────────────────────────────────────────

export interface MasterTrader {
  id: string;
  name: string;
  exchange: "Bybit" | "Binance";
  winRate: number;
  roi30d: number;
  drawdown: number; // max drawdown %
  profitFactor: number;
  followers: number; // copiers count
  aum: number;
  confidence: number;
  avatar: string;
  strategy: string; // strategy badge, e.g. "Momentum Scalper"
  followed: boolean;
}

// ─── Optimizer ───────────────────────────────────────────────────────────────

export interface OptimizerState {
  targetWinRate: number;
  currentWinRate: number;
  tradesAnalyzed: number;
  confluenceThreshold: number;
  atrSlMult: number;
  atrTpMult: number;
  rsiOverbought: number;
  rsiOversold: number;
  calibrations: number;
  lastAction: string;
}

// ─── Misc UI ─────────────────────────────────────────────────────────────────

export type TabId =
  | "ai" | "active" | "copy" | "paper"
  | "terminal" | "heatmap" | "tax" | "settings";

export type BotStatus = "OFF" | "ACTIVE" | "SCANNING" | "HALTED";

export interface LogEntry {
  id: string;
  ts: number;
  kind: "info" | "trade" | "learn" | "warn" | "signal";
  text: string;
}

export interface HeatmapCoin {
  symbol: string;
  name: string;
  marketCap: number;
  change24h: number;
  price: number;
}

export interface AppSettings {
  realTradingUnlocked: boolean;
  notificationsEnabled: boolean;
  soundEnabled: boolean;
  riskPct: number;
  maxConcurrent: number;
  dailyLossLimitPct: number;
  copyTradingEnabled: boolean;
  preferredFeed: ExchangeId | "AUTO";
  defaultLeverage: number;
}

export const FMT = {
  usd: (v: number, d = 2) =>
    v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }),
  price: (v: number) =>
    v >= 1000
      ? v.toLocaleString("en-US", { maximumFractionDigits: 2 })
      : v.toLocaleString("en-US", { maximumFractionDigits: 4 }),
  pct: (v: number) => `${v >= 0 ? "+" : ""}${v.toFixed(2)}%`,
};

export const SYMBOL_META: Record<SymbolId, { name: string; color: string; base: number }> = {
  BTCUSDT: { name: "Bitcoin", color: "#f7931a", base: 97400 },
  ETHUSDT: { name: "Ethereum", color: "#627eea", base: 3420 },
  SOLUSDT: { name: "Solana", color: "#14f195", base: 198 },
  BNBUSDT: { name: "BNB", color: "#f3ba2f", base: 660 },
};
