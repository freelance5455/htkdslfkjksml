export type TransactionType = 'P' | 'S'; // 'P' = Purchase (Stock In), 'S' = Sale (Stock Out)

export interface Product {
  id: string;
  name: string;
  sku?: string; // Barcode or SKU
  cat: string;
  unit: string;
  open: number; // Opening stock quantity
  cost: number; // Cost / Buy rate
  price: number; // Selling rate
  min: number; // Low-stock reorder threshold
  createdAt?: string;
}

export type PaymentMethod = 'cash' | 'upi' | 'card' | 'credit';

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  pid: string;
  type: TransactionType;
  qty: number;
  rate: number;
  cust?: string; // Customer name (for Sales) or Supplier (for Purchases)
  paymentMethod?: PaymentMethod;
  note?: string;
}

export interface WidgetItem {
  id: string;
  title: string;
  on: boolean;
}

export interface StoreData {
  co: string;
  tagline?: string;
  phone?: string;
  address?: string;
  cur: string;
  units: string[];
  cats: string[];
  widgets: WidgetItem[];
  products: Product[];
  txns: Transaction[];
  theme?: 'system' | 'light' | 'dark';
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export interface CalculatedProduct {
  p: Product;
  qty: number;
  inq: number;
  sold: number;
  rev: number;
  cogs: number;
  buy: number;
  stockValue: number;
  profit: number;
  isLowStock: boolean;
}

export interface PeriodSummary {
  rev: number;
  cogs: number;
  buy: number;
  pr: number;
}
