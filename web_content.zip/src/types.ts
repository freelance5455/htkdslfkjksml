export type ZmanCategory = 'dawn' | 'morning' | 'noon' | 'afternoon' | 'evening' | 'night';

export type CalendarViewMode = 'month' | 'week' | 'day' | 'agenda';

export interface LocationPreset {
  id: string;
  name: string;
  nameHe: string;
  country: string;
  lat: number;
  long: number;
  elevation: number;
  timezone: string;
  isIsrael: boolean;
  candleLightingOffset: number; // minutes before sunset (e.g. 18, 40 for JLM)
}

export interface ZmanItem {
  id: string;
  title: string;
  hebrewTitle: string;
  description: string;
  time: Date | null;
  formattedTime: string;
  category: ZmanCategory;
  isPassed: boolean;
  isNext: boolean;
  timeRemaining?: string;
  highlight?: boolean;
}

export type HebrewEventType =
  | 'birthday'
  | 'yahrzeit'
  | 'anniversary'
  | 'barmitzvah'
  | 'batmitzvah'
  | 'memorial'
  | 'custom';

export interface HebrewEvent {
  id: string;
  title: string;
  hebrewTitle?: string;
  type: HebrewEventType;
  hebrewDay: number; // 1-30
  hebrewMonth: number; // 1 (Nisan) to 13 (Adar II), standard Hebcal mapping
  hebrewMonthName: string;
  hebrewYear?: number; // original year if known (e.g. 5750)
  gregorianOriginDate?: string; // YYYY-MM-DD
  recurrence: 'hebrew-annual' | 'hebrew-monthly' | 'once';
  repeatCount?: number; // Optional number of repetitions (e.g. 5, 10, 120 or undefined for infinite)
  participants?: string[]; // Optional list of guest/participant names or emails
  leapYearRule: 'adar2' | 'adar1' | 'both'; // For events in regular Adar
  notes?: string;
  location?: string;
  color: string;
  enableReminder: boolean;
  reminderDaysBefore: number;
  candleLighting?: boolean;
  showCounter?: boolean;
  counterStart?: number;
  startHebrewYear?: number;
  displayTitle?: string;
  displayHebrewTitle?: string;
  createdAt: number;
  updatedAt: number;
}

export interface HolidayItem {
  name: string;
  hebrewName: string;
  category: 'major' | 'minor' | 'roshchodesh' | 'fast' | 'modern' | 'special_shabbat';
  emoji?: string;
  description?: string;
  candles?: string;
  havdalah?: string;
}

export interface CalendarDay {
  gregorianDate: Date;
  dateKey: string; // YYYY-MM-DD
  hebrewDateStr: string; // "18 Elul 5786"
  hebrewDateStrHe: string; // "י״ח בֶּאֱלוּל תשפ״ו"
  hebrewDay: number;
  hebrewDayLetters: string; // "י״ח"
  hebrewMonth: number;
  hebrewMonthName: string;
  hebrewMonthNameHe: string;
  hebrewYear: number;
  hebrewYearLetters: string; // "תשפ״ו"
  isShabbat: boolean;
  isErevShabbat: boolean;
  isRoshChodesh: boolean;
  roshChodeshName?: string;
  isFastDay: boolean;
  isYomTov: boolean;
  isCholHamoed: boolean;
  isMajorHoliday: boolean;
  isMinorHoliday: boolean;
  holidays: HolidayItem[];
  parasha?: {
    name: string;
    hebrewName: string;
    fullReading?: string;
  };
  omer?: {
    count: number;
    weeks: number;
    days: number;
    textHe: string;
  };
  dafYomi?: {
    masechet: string;
    daf: number;
    hebrew: string;
  };
  candleLighting?: string;
  havdalah?: string;
  events: HebrewEvent[];
  isToday: boolean;
  isSelected: boolean;
}

export interface DailyVerse {
  id: string;
  source: string;
  sourceHe: string;
  category: 'torah' | 'psalms' | 'prophets' | 'proverbs' | 'pirkei_avot' | 'halacha';
  hebrew: string;
  transliteration: string;
  english: string;
  theme: string;
  practicalTakeaway: string;
}

export interface SyncState {
  roomId: string;
  roomPin: string;
  isConnected: boolean;
  lastSyncedAt: number | null;
  deviceName: string;
  status: 'idle' | 'syncing' | 'synced' | 'error';
  errorMessage?: string;
}

export type Language = 'en' | 'he';

export interface UserSettings {
  language: Language;
  location: LocationPreset;
  useGps: boolean;
  theme: 'dark' | 'light' | 'system';
  darkMode?: boolean;
  viewMode: 'month' | 'week' | 'day' | 'agenda';
  candleLightingOffset: number;
  havdalahOpinion: '8.5' | '42' | '50' | '72';
  notifications: {
    enabled: boolean;
    shabbatCandles: boolean;
    shabbatMinutesBefore: number;
    holidays: boolean;
    dailyVerse: boolean;
    dailyVerseTime: string;
    zmanimAlerts: boolean;
    personalEvents: boolean;
  };
  homeWidget: {
    style: 'compact' | 'expanded' | 'minimal' | 'zmanim_focus';
    showNextZman: boolean;
    showDailyVerse: boolean;
    floatingPinned: boolean;
  };
  display?: {
    showDafYomi: boolean;
    showOmer: boolean;
    showParasha: boolean;
    showHebrewGematriya: boolean;
    showSecularDates: boolean;
  };
  zmanim?: {
    shabbatOffset: number;
    havdalahOpinion: '8.5' | '42' | '50' | '72';
    useElevation: boolean;
    opinion: 'gra' | 'mga';
  };
}
