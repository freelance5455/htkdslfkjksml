export type WeaponType = 'pistol' | 'shotgun' | 'rifle' | 'sniper' | 'rpg' | 'plasma';

export interface WeaponConfig {
  id: WeaponType;
  name: string;
  description: string;
  icon: string;
  damage: number;
  fireRate: number; // shots per second
  magazineSize: number;
  reloadTime: number; // in seconds
  spread: number; // spread angle in radians
  bulletSpeed: number;
  pellets: number; // number of projectiles per shot
  unlocked: boolean;
  unlockCostCoins: number;
  unlockWave: number;
  damageLevel: number;
  fireRateLevel: number;
  magLevel: number;
  reloadLevel: number;
}

export type ZombieType =
  | 'walker'
  | 'runner'
  | 'tank'
  | 'spitter'
  | 'boomer'
  | 'boss'
  | 'sprinter'  // 1. Tezkor Zombi (Fast sprinter with lightning dash)
  | 'armored'   // 2. Zirhli Zombi (Armored juggernaut with 50% bullet resistance and double wall damage)
  | 'kamikaze'; // 3. Portlovchi Zombi (Toxic explosive bomber with countdown and poison cloud)

export interface Zombie {
  id: string;
  type: ZombieType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  attackCooldown: number;
  lastAttackTime: number;
  color: string;
  targetType: 'base' | 'player';
  targetWallIndex?: number;
  spitCooldown?: number;
  isBoss?: boolean;
  scoreValue: number;
  woodDrop: number;
  metalDrop: number;
  coinDrop: number;
  ammoDropChance: number;
  // Special abilities & states
  dashCooldown?: number;
  isDashing?: boolean;
  dashTimer?: number;
  isArmored?: boolean;
  detonating?: boolean;
  detonationTimer?: number;
  maxDetonationTime?: number;
}

export interface HazardZone {
  id: string;
  x: number;
  y: number;
  radius: number;
  life: number;
  maxLife: number;
  damagePerSec: number;
  slowFactor: number;
  color: string;
}

export interface Bullet {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  radius: number;
  rangeRemaining: number;
  isRpg?: boolean;
  isPlasma?: boolean;
  isTurret?: boolean;
  pierceCount: number;
  color: string;
}

export interface AcidSpit {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  radius: number;
}

export interface ResourceDrop {
  id: string;
  x: number;
  y: number;
  type: 'wood' | 'metal' | 'coin' | 'ammo' | 'medkit';
  amount: number;
  life: number; // expires after some time
}

export interface Turret {
  id: string;
  x: number;
  y: number;
  range: number;
  damage: number;
  fireRate: number;
  lastFireTime: number;
  targetId: string | null;
  angle: number;
  level: number;
}

export interface WallSegment {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  orientation: 'horizontal' | 'vertical';
  health: number;
  maxHealth: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  decay: number;
}

export interface BloodDecal {
  x: number;
  y: number;
  radius: number;
  color: string;
  alpha: number;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  vy: number;
}

export interface BaseState {
  x: number;
  y: number;
  radius: number;
  health: number;
  maxHealth: number;
  defenseLevel: number;
  repairEfficiencyLevel: number;
}

export interface PlayerState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  health: number;
  maxHealth: number;
  speed: number;
  speedLevel: number;
  currentWeapon: WeaponType;
  currentAmmo: number;
  isReloading: boolean;
  reloadProgress: number; // 0 to 1
  grenades: number;
  dashCooldown: number;
  lastDashTime: number;
}

export interface GameResources {
  wood: number;
  metal: number;
  coins: number;
  ammo: number;
}

export interface GraphicsSettings {
  preset: 'low' | 'medium' | 'high' | 'ultra';
  particleQuality: 'low' | 'medium' | 'high';
  bloodDecals: boolean;
  lightingEffects: boolean;
  screenShake: number; // 0, 0.5, 1
  targetFps: 30 | 60 | 120;
  damageNumbers: boolean;
  autoAim: boolean;
}

export interface ControlButtonConfig {
  id: string;
  nameUz: string;
  xPercent: number; // 0 to 100 percentage of screen
  yPercent: number; // 0 to 100 percentage of screen
  size: number; // in pixels (e.g., 60 - 90)
  opacity: number; // 0.3 to 1
}

export interface CustomControlsSettings {
  leftHanded: boolean;
  buttons: {
    joystick: ControlButtonConfig;
    fire: ControlButtonConfig;
    reload: ControlButtonConfig;
    repair: ControlButtonConfig;
    switchWeapon: ControlButtonConfig;
    grenade: ControlButtonConfig;
    dash: ControlButtonConfig;
    placeTurret: ControlButtonConfig;
  };
}

export type GameState = 'menu' | 'playing' | 'upgrade' | 'gameover' | 'victory_wave';
