export type Language = 'en' | 'bn' | 'hi';

export type Subject =
  | 'History'
  | 'Geography'
  | 'Science'
  | 'Mathematics'
  | 'Bengali'
  | 'English'
  | 'Political Science'
  | 'Economics'
  | 'Computer'
  | 'Aptitude & Reasoning'
  | 'General Awareness'
  | 'Competitive Exams'
  | 'General Studies';

export type TeacherLevel = 'kids' | 'madhyamik' | 'hs' | 'college' | 'competitive';

export type LearningStyle = 'teacher' | 'story' | 'simple' | 'step_by_step' | 'exam_focused' | 'quick_revision';

export type SummaryDuration = '1m' | '5m' | '10m';

export type NotesType = 'class' | 'short' | 'exam' | 'last_minute';

export type ExamCategory = 'school' | 'college' | 'govt' | 'private' | 'custom';

export type ExamType =
  | 'Madhyamik'
  | 'Higher Secondary'
  | 'Class 6-9'
  | 'Primary'
  | 'College Semester'
  | 'University Exam'
  | 'WBCS'
  | 'WBPSC'
  | 'SSC CGL/CHSL'
  | 'Railway NTPC/Group D'
  | 'Banking IBPS/SBI'
  | 'UPSC Civil Services'
  | 'Police & Defence'
  | 'Primary TET & Teaching'
  | 'Private Job & Placement'
  | 'Aptitude & Reasoning'
  | 'Custom Exam'
  | 'Other';

export interface UserProfile {
  id?: string;
  name: string;
  photoUrl?: string; // base64 or URL for custom user photo
  avatar?: string;
  phone?: string;
  email?: string;
  role?: 'user' | 'admin';
  category: ExamCategory;
  subCategory?: string;
  qualification: string;
  boardOrUniversity: string;
  targetExam: string;
  customExamName?: string;
  customSubjects?: string[];
  selectedSubjects: string[];
  dailyQuestionTarget: number; // 50 | 100 | 150 | 200
  targetYear: string;
  examDate?: string;
  dailyStudyTimeMinutes: number;
  currentLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  preferredLanguage: Language;
  parentPin?: string;
  notificationsEnabled?: boolean;
  theme?: 'light' | 'dark' | 'system';
  onboardingCompleted?: boolean;
  streakDays?: number;
  lastActiveDate?: string;
  isPro?: boolean;
  proPlan?: 'monthly' | 'yearly';
  proExpiryDate?: string;
  proOrderId?: string;
  proPaymentMethod?: string;
  proPaidAmount?: number;
  proTransactionId?: string;
}

export interface SubscriptionPaymentRecord {
  orderId: string;
  userId?: string;
  userName?: string;
  userPhone?: string;
  plan: 'monthly' | 'yearly';
  amount: number;
  currency: 'INR';
  paymentMethod: 'upi' | 'card' | 'netbanking';
  transactionId: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  paidAt: string;
  expiresAt: string;
}

export interface MCQQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  shortConcept?: string;
  rememberPoint?: string;
  whyOthersWrong?: string;
  subject: string;
  topic?: string;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
  marks?: number;
  negativeMarks?: number;
}

export interface DailyQuestionSet {
  id: string;
  date: string; // YYYY-MM-DD
  exam: string;
  selectedSubjects: string[];
  targetCount: number;
  questions: MCQQuestion[];
  completedCount: number;
  score: number;
  userAnswers: Record<number, number>; // index -> selectedOption
  subjectDistribution: Record<string, number>;
  createdAt: string;
}

export interface MistakeItem {
  id: string;
  question: MCQQuestion;
  userAnswerIndex: number;
  dateAdded: string;
  reviewedCount: number;
}

export interface ExamProfileDefinition {
  id: string;
  name: string;
  category: ExamCategory;
  subCategory?: string;
  allowedSubjects: string[];
  description: string;
  syllabus: string[];
  defaultDistribution?: Record<string, number>;
}

export interface SavedItem {
  id: string;
  title: string;
  type: 'note' | 'lesson' | 'question' | 'pyq' | 'flashcard' | 'solution';
  subject: string;
  content: any;
  dateSaved: string;
}

export interface Question {
  id: string;
  question: string;
  type: 'short' | 'long' | 'v_important' | 'board' | 'competitive';
  answer?: string;
  points?: string[];
  detailedAnswer?: string;
}

export interface MCQ {
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  subject: string;
}

export interface StudyPlanItem {
  id: string;
  day: string;
  time: string;
  subject: string;
  topic: string;
  completed: boolean;
}

export interface ProgressReport {
  studyTimeMinutes: number;
  questionsAsked: number;
  quizzesTaken: number;
  averageScore: number;
  completedTasks?: number;
  weakTopics: { topic: string; score: number }[];
  completedChapters: string[];
  totalQuestions?: number;
  correctAnswers?: number;
  wrongAnswers?: number;
  accuracy?: number;
  examsCompleted?: number;
  history?: any[];
  totalStudyTimeMinutes?: number;
}

export interface MindMapNode {
  id: string;
  label: string;
  description?: string;
  type?: 'root' | 'main' | 'sub';
  connections?: string[];
}

export interface MindMap {
  nodes: MindMapNode[];
  edges: { from: string; to: string }[];
}

export interface HomeworkSolutionStep {
  stepNumber: number;
  title: string;
  description: string;
  formulaUsed?: string;
}

export interface HomeworkSolution {
  problemText: string;
  finalAnswer: string;
  steps: HomeworkSolutionStep[];
  conceptsInvolved: string[];
}

export type WeeklyQuizStatus = 'draft' | 'scheduled' | 'published' | 'live' | 'paused' | 'ended' | 'completed' | 'archived' | 'winner_announced';

export type PrizeDeliveryStatus = 
  | 'Pending Verification' 
  | 'Winner Confirmed' 
  | 'Prize Processing' 
  | 'Prize Sent' 
  | 'Prize Delivered'
  | 'Winner Announced' 
  | 'Prize Pending';

export interface WeeklyPrizeItem {
  id?: string;
  name: string;
  description: string;
  image?: string;
  value?: string;
  quantity?: number;
  position?: '1st Prize' | '2nd Prize' | '3rd Prize' | 'Top 5' | 'Participation' | string;
  terms?: string;
}

export interface WeeklyQuizWinnerClaimInfo {
  fullName: string;
  phone: string;
  address: string;
  pincode: string;
  state?: string;
  additionalNotes?: string;
  submittedAt: string;
}

export interface WeeklyQuizWinner {
  userId: string;
  displayName: string;
  score: number;
  totalQuestions: number;
  completionTimeSeconds: number;
  rank: number;
  status: PrizeDeliveryStatus;
  announcedAt?: string;
  deliveryNotes?: string;
  claimInfo?: WeeklyQuizWinnerClaimInfo;
}

export interface WeeklyQuiz {
  id: string;
  weekNumber?: number | string;
  title: string;
  description: string;
  shortDescription?: string;
  fullDescription?: string;
  instructions?: string[];
  rules?: string[];
  category?: string;
  startDate: string; // YYYY-MM-DD
  startTime: string; // HH:MM (e.g. "10:00" or "08:00 PM")
  endDate: string; // YYYY-MM-DD
  endTime: string; // HH:MM (e.g. "20:00" or "10:00 PM")
  questionCount?: number;
  timeLimit: number; // in minutes (e.g. 5, 10, 15, 20, 30, 45, 60, 90, custom)
  subjects: string[];
  targetLevel: string; // 'Class 6' | 'Class 7' | 'Class 8' | 'Class 9' | 'SSC' | 'Government Job' | 'Competitive Exam' | 'Custom'
  language?: Language;
  
  // Prize Configuration
  prizeName: string;
  prizeDescription: string;
  prizeImage?: string;
  prizeValue?: string;
  prizeQuantity?: number;
  prizePosition?: string;
  prizeTerms?: string;
  prizeDeliveryNotes?: string;
  prizes?: WeeklyPrizeItem[];
  
  // Rules & Scoring Controls
  eligibilityRules?: string[];
  maxAttempts?: number;
  passingScore?: number;
  negativeMarking?: boolean;
  negativeMarks?: number; // e.g. 0.25
  negativeMarksPerWrong?: number; // e.g. 0.25
  marksPerQuestion?: number; // e.g. 1
  
  // Entry & Ad Requirements
  requireAdsBeforeQuiz?: boolean; // Must watch ads before taking quiz
  numberOfAds?: number; // e.g. 2 ads (default: 2)
  adWatchSeconds?: number; // Seconds per ad (default: 5)
  joinedUserIds?: string[]; // Array of user IDs who have successfully joined
  
  // Reminder & Push Notifications for Joined Users
  enable10MinAlerts?: boolean;
  notificationReminderEnabled?: boolean;
  notificationReminderMinutes?: number; // 5, 10, 15 or custom minutes before start
  notificationTitle?: string;
  notificationMessage?: string;
  notification10MinSent?: boolean; // Whether reminder broadcast has been triggered
  
  winnerAnnouncementDate?: string;
  status: WeeklyQuizStatus;
  isArchived?: boolean;
  questions: MCQQuestion[];
  participantsCount: number;
  winner?: WeeklyQuizWinner;
  winnerVerified: boolean;
  winnerClaimInfo?: WeeklyQuizWinnerClaimInfo;
  prizeStatus: PrizeDeliveryStatus;
  createdAt: string;
  updatedAt: string;
}

export interface QuizNotificationAlert {
  id: string;
  quizId: string;
  quizTitle: string;
  startTime: string;
  startDate: string;
  message: string;
  timestamp: string;
  type: '10_min_warning' | 'quiz_started' | 'admin_broadcast';
}

export interface QuizReminderSubscription {
  id: string;
  quizId: string;
  userId: string;
  userName?: string;
  phone?: string;
  browserPushEnabled?: boolean;
  createdAt: string;
}

export interface WeeklyQuizSubmission {
  id: string;
  userId: string;
  displayName: string;
  quizId: string;
  answers: Record<number, number>; // index -> chosen option
  correctAnswers: number;
  wrongAnswers: number;
  unanswered: number;
  score: number;
  totalQuestions: number;
  startTime: string; // ISO string
  submitTime: string; // ISO string
  completionTimeSeconds: number;
  timeTakenSeconds?: number;
  rank?: number;
  status: 'submitted' | 'flagged' | 'verified';
}

export interface WeeklyQuizLeaderboardEntry {
  rank: number;
  userId: string;
  displayName: string;
  score: number;
  totalQuestions: number;
  correctAnswers?: number;
  wrongAnswers?: number;
  unanswered?: number;
  completionTimeSeconds: number;
  submitTime: string;
  isCurrentUser?: boolean;
  isWinner?: boolean;
}

export interface AdminOverviewStats {
  totalUsers: number;
  totalParticipants: number;
  totalQuizzes: number;
  activeQuizzesCount: number;
  upcomingQuizzesCount: number;
  completedQuizzesCount: number;
  draftQuizzesCount: number;
  totalQuestionsCount: number;
  currentQuiz?: WeeklyQuiz;
  currentPrize?: {
    name: string;
    description: string;
    image?: string;
    status: PrizeDeliveryStatus;
  };
  recentSubmissions: WeeklyQuizSubmission[];
}

export interface AdminQuizGlobalSettings {
  defaultRules: string[];
  defaultDuration: number;
  defaultMarksPerQuestion: number;
  defaultNegativeMarking: boolean;
  defaultNegativeMarks: number;
  leaderboardVisibility: boolean;
  resultVisibility: boolean;
  explanationVisibility: boolean;
  maxAttempts: number;
  showPrizeSection: boolean;
  showCountdownTimer: boolean;
  requireAdsBeforeQuiz?: boolean;
  defaultAdSeconds?: number;
  enable10MinAlerts?: boolean;
  adminEmail?: string;
  adminAuthRole?: 'admin';
}

// -----------------------------------------------------------------------------
// NOTIFICATION SYSTEM TYPES
// -----------------------------------------------------------------------------

export type NotificationStatus = 'DRAFT' | 'QUEUED' | 'PROCESSING' | 'SENT' | 'PARTIALLY_SENT' | 'FAILED' | 'SCHEDULED';

export type NotificationAudienceType = 
  | 'all_users'
  | 'active_users'
  | 'inactive_users'
  | 'new_users'
  | 'specific_user'
  | 'specific_exam'
  | 'specific_language'
  | 'custom_audience';

export type NotificationCategory = 
  | 'announcement'
  | 'exam_alert'
  | 'weekly_quiz'
  | 'daily_questions'
  | 'study_reminder'
  | 'achievement'
  | 'system_update';

export interface AppNotification {
  notificationId: string;
  title: string;
  message: string;
  imageUrl?: string;
  icon?: string;
  actionUrl?: string;
  actionTab?: string;
  actionText?: string;
  category: NotificationCategory;
  audience: NotificationAudienceType;
  targetExam?: string;
  targetLanguage?: string;
  targetUserId?: string;
  createdBy: string;
  createdAt: string;
  scheduledAt?: string | null;
  status: NotificationStatus;
  sentAt?: string | null;
  recipientsCount?: number;
  deliveredCount?: number;
  failedCount?: number;
  fcmTopic?: string;
  fcmMessageId?: string | null;
  read?: boolean;
  readAt?: string | null;
}

export interface NotificationStats {
  totalNotifications: number;
  queuedCount: number;
  processingCount: number;
  sentCount: number;
  failedCount: number;
  scheduledCount: number;
  totalAudience: number;
  totalDelivered: number;
}

