export type NavTab = 'home' | 'chat' | 'create' | 'history' | 'settings';

export type LanguageCode = 'az' | 'tr' | 'en' | 'ru';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  image?: {
    base64: string;
    mimeType: string;
    url?: string;
  };
  fileContent?: {
    fileName: string;
    text: string;
  };
  isError?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
  category?: 'general' | 'code' | 'text' | 'translation' | 'business' | 'image' | 'voice';
}

export interface QuickPrompt {
  id: string;
  title: string;
  subtitle: string;
  prompt: string;
  icon: string;
  category: 'code' | 'text' | 'translation' | 'business' | 'image' | 'qa';
}

export type ImageStyle = 'Futuristic' | '3D Render' | 'Cyberpunk' | 'Photorealistic' | 'Gold Luxury' | 'Minimalist Art';

export interface GeneratedImageItem {
  id: string;
  prompt: string;
  imageUrl: string;
  aspectRatio: string;
  style: ImageStyle;
  createdAt: string;
  isDemo?: boolean;
}

export interface FileAttachment {
  name: string;
  size: number;
  type: string;
  text?: string;
  base64?: string;
}
