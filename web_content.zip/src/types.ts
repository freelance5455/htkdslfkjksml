export interface Attachment {
  id: string;
  name: string;
  mime: string;
  size: number;
  data: string; // Base64 Data URL
}

export interface TaskItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface AudioNote {
  id: string;
  name: string;
  duration: number; // in seconds
  data: string; // Base64 audio or data URL
  createdAt: string;
}

export interface ElementSnippet {
  id: string;
  name: string;
  category?: string; // e.g. "Kırpıntılarım (Snippets)", "Çıkartmalar (Stickers)", "Post-it & Notlar", "Şekil & İşaretçiler"
  data: string; // Base64 transparent PNG or SVG data URL
  createdAt: string;
  sourceText?: string;
  type?: "lasso" | "sticker" | "postit" | "upload" | "snippet";
  width?: number;
  height?: number;
}

export type ImageClip = ElementSnippet;

export interface Note {
  id: string;
  title: string;
  content: string;
  htmlContent?: string; // Rich-text formatted HTML
  category: string;
  tags: string[];
  pinned: boolean;
  favorite: boolean;
  color?: string; // Accent color: 'teal', 'emerald', 'blue', 'amber', 'rose', 'purple', 'slate'
  fontFamily?: string;
  reminder?: string; // ISO datetime
  attachments?: Attachment[];
  tasks?: TaskItem[];
  audioNotes?: AudioNote[];
  isVault?: boolean;
  sourceDocument?: string; // Decoupled provenance: e.g. "DOC-20260919-WA0000.bin"
  aiCategorized?: boolean;
  aiCategoryReason?: string;
  aiCategoryConfidence?: number;
  aiSuggestedTags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface ArchivedDocument {
  id: string;
  name: string;
  size: number;
  mime: string;
  uploadedAt: string;
  sourceType: string; // e.g. 'colornote', 'binary', 'docx', 'xlsx', 'pdf', 'zip'
  extractedCount: number;
  data?: string; // Base64 raw data for download or re-inspection
  status: 'archived' | 'extracted';
}

export interface TrashItem extends Note {
  deletedAt: string;
  originalVault?: boolean;
}

export interface Flashcard {
  id: string;
  noteId?: string;
  question: string;
  answer: string;
  mastered?: boolean;
}

export interface VaultMetadata {
  version: number;
  salt: string;
  keyIv: string;
  keyData: string;
  dataIv: string;
  data: string;
  securityQuestion?: string;
  recoveryKeyIv?: string;
  recoveryKeyData?: string;
  hint?: string;
  recoveryMnemonicIv?: string;
  recoveryMnemonicData?: string;
  emergencyTokenHash?: string;
  autoLockTimeout?: number; // in seconds: 0 (immediate on blur), 30, 60, 300
}

export interface SectionItem {
  id: string;
  name: string;
  icon?: string; // e.g. 'User', 'Briefcase', 'Lightbulb', 'FolderKanban', 'GraduationCap', 'Star', 'Heart'
  color?: string; // 'teal', 'emerald', 'blue', 'amber', 'rose', 'purple', 'slate'
  description?: string;
  isDefault?: boolean;
}

export interface UserProfile {
  name: string;
  email: string;
  title: string;
  avatarUrl?: string;
  isLoggedIn: boolean; // whether user is signed in with Gmail, Apple, Email or Firebase
  authProvider: 'google' | 'apple' | 'email' | 'firebase' | 'guest';
  uid?: string;
  emailVerified?: boolean;
  aiModeEnabled: boolean; // whether user wants AI tools active or classic clean mode
  autoSync: boolean;
  syncFrequency: 'instant' | 'daily' | 'manual';
  googleDriveBackup: boolean;
  socialShareEnabled: boolean;
  xHandle?: string;
  lastBackupDate?: string;
  joinedDate?: string;
  aiQuestionsCount?: number;
}

export interface SyncedNoteRecord {
  id: string;
  noteId: string;
  noteTitle: string;
  destination: string; // e.g. 'Gmail (enes02erdm@gmail.com)', 'Google Drive', 'X/Twitter'
  channelType: 'email' | 'gdrive' | 'social' | 'webhook';
  status: 'success' | 'pending' | 'failed';
  timestamp: string;
  details?: string;
  previewUrl?: string;
}

export interface MindMapNode {
  id: string;
  label: string;
  type: 'root' | 'category' | 'concept' | 'action' | 'note';
  color?: string;
  noteId?: string;
  details?: string;
  x?: number;
  y?: number;
}

export interface MindMapEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
}

export interface MindMapData {
  title: string;
  rootLabel?: string;
  nodes: MindMapNode[];
  edges: MindMapEdge[];
}

export interface InfographicMetric {
  label: string;
  value: string;
  icon?: string;
  color?: string;
}

export interface InfographicStep {
  stepNumber: number;
  title: string;
  description: string;
  tag?: string;
}

export interface InfographicPillar {
  title: string;
  points: string[];
  icon?: string;
  color?: string;
}

export interface InfographicData {
  title: string;
  subtitle: string;
  quote?: string;
  metrics: InfographicMetric[];
  steps: InfographicStep[];
  pillars: InfographicPillar[];
  actionItems: string[];
}

export type ActiveTab =
  | 'home'
  | 'docs'
  | 'mindmap'
  | 'study'
  | 'vault'
  | 'profile'
  | 'tips'
  | 'settings'
  | 'plus_action'
  | 'ai_chat'
  | 'quick_search'
  | 'voice_memo';
export type SortOption = 'updated' | 'newest' | 'oldest' | 'alphabetical' | 'color';
export type FilterOption = 'all' | 'favorites' | 'reminders' | 'tasks';
export type ViewLayout = 'grid' | 'largeGrid' | 'list' | 'details' | 'kanban' | 'timeline' | 'mindmap_canvas' | 'compact_strip';
export type ThemeAccent = 'teal' | 'ocean' | 'purple' | 'amber' | 'rose' | 'emerald' | 'slate' | 'blue';
export type UIThemeStyle = 'minimalist' | 'circadian_pkm' | 'enterprise_pkm' | 'terminal' | 'cyberpunk' | 'mental_canvas';
export type CanvasThemeStyle = 'fluid_parchment' | 'zen_sapphire' | 'timeline_chronicle' | 'hybrid_white';

export interface CanvasThemeDefinition {
  id: CanvasThemeStyle;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  dayBg: string;
  nightBg: string;
  dayText: string;
  nightText: string;
  bgGradient: string;
  lineStructureDesc: string;
  typographyDesc: string;
  lineType: 'horizontal_gold' | 'sapphire_grid' | 'timeline_vertical' | 'clean_white';
  fontFamily: string;
  headingColor: string;
  features: string[];
}

export interface MenuSectionDefinition {
  id: ActiveTab;
  title: string;
  subtitle: string;
  iconName: string;
  enabled: boolean;
}

export interface OfflineActionItem {
  id: string;
  type: 'categorize' | 'sync' | 'ocr' | 'save_note';
  noteId?: string;
  payload?: any;
  createdAt: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

// ============================================================================
// STYLUS & DIGITAL PEN (DIGITAL INK ENGINE) TYPES
// ============================================================================

export type StylusToolType =
  | 'fountain'      // 1. Dolma Kalem (Basınç ve Açı Duyarlı Kaligrafi)
  | 'ballpoint'     // 2. Tükenmez Kalem (Pürüzsüz, Net Çizgi)
  | 'pencil'        // 3. Kurşun Kalem (Mat Grafik Doku)
  | 'neon_glow'     // 4. Neon Işıltı Kalemi (Parlayan Neon Işığı)
  | 'calligraphy'   // 5. Kaligrafi Fırçası (Esnek Sanatsal Fırça)
  | 'highlighter'   // 6. Fosforlu Kalem (Yarı Şeffaf Vurgulayıcı)
  | 'technical'     // 7. Teknik Çizim / Rapido (Hassas Milimetrik Sabit Çizgi)
  | 'watercolor'    // 8. Sulu Boya Fırçası (Islak Islak Yumuşak Yayılım)
  | 'laser_marker'  // 9. Lazer İşaretleyici / Vurgu Kalemi (Geçici Lazer & İşaretleme)
  | 'recall_tape'    // 10. Hafıza Bandı (Active Recall Scratch & Reveal Tape)
  | 'eraser'        // Silgi (Obje / Piksel Silici)
  | 'lasso_cut';    // Çizip Kesme / Kement Seçim & Taşıma Aracı

export type PalmRejectionMode = 'strict' | 'balanced' | 'disabled';
export type SmartEraserFilterMode = 'all' | 'ink_only' | 'highlighter_only' | 'tape_only';
export type BoundedFramePreset = 'infinite' | 'a4' | 'b5' | 'pdf_page';
export type CanvasLayerType = 'grid' | 'highlighter' | 'text_box' | 'ink_stroke' | 'recall_tape';

export interface BoundedFrame {
  id: string;
  type: 'a4' | 'b5' | 'pdf_page' | 'custom';
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  pageNumber?: number;
  backgroundStyle?: string;
}

export interface ActiveRecallTape {
  id: string;
  label?: string;
  color: string;
  points: StylusPoint[];
  width: number;
  isRevealed: boolean;
  createdAt: number;
}

export interface BidirectionalLinkNode {
  id: string;
  sourceNoteId?: string;
  targetTitle: string;
  targetNoteId?: string;
  anchorText: string;
  x?: number;
  y?: number;
  timestamp: number;
}

export interface StylusPoint {
  x: number;
  y: number;
  pressure: number;
  tiltX?: number;
  tiltY?: number;
  timestamp: number;
}

export interface StylusStroke {
  id: string;
  tool: StylusToolType;
  color: string;
  size: number;
  opacity: number;
  points: StylusPoint[];
  recognizedText?: string;
  isRecallTape?: boolean;
  isRevealed?: boolean;
  layerType?: CanvasLayerType;
  zIndex?: number;
  createdAt?: number;
}

export interface StylusSettings {
  palmRejection: PalmRejectionMode;
  doubleTapAction: 'eraser' | 'undo' | 'palette' | 'toggle_tool';
  smoothingEnabled: boolean;
  pressureSensitivity: number; // 0.1 to 2.0 (default 1.0)
  gridSnapping: boolean;
  autoOCR: boolean;
  engineType: 'gms' | 'hms' | 'universal';
  hapticFeedback: boolean;
  activeEraserFilter: SmartEraserFilterMode;
  activeFramePreset: BoundedFramePreset;
  adaptiveNightModeInk: boolean;
  bidirectionalLinksEnabled: boolean;
  recallTapeColor: string;
}

/**
 * Offline-First & Encrypted Vault Vector Canvas Data Model
 * Stores object-based vectors, bounded frames, layers, and bidirectional links.
 */
export interface EncryptedCanvasDocumentSchema {
  version: number;
  documentId: string;
  title: string;
  viewport: {
    panX: number;
    panY: number;
    zoom: number;
  };
  framePreset: BoundedFramePreset;
  frames: BoundedFrame[];
  layers: {
    highlighters: StylusStroke[];
    textBoxes: Array<{
      id: string;
      x: number;
      y: number;
      width: number;
      height: number;
      html: string;
      links: string[];
    }>;
    inkStrokes: StylusStroke[];
    recallTapes: ActiveRecallTape[];
  };
  bidirectionalLinks: BidirectionalLinkNode[];
  vaultEncrypted: boolean;
  lastModified: number;
}

/**
 * Categorical Global Responsive Scaling Configuration
 * Zero quality loss, zero pixelation, zero overflow across all screens.
 */
export type DisplayScalePreset = 'compact' | 'standard' | 'comfortable' | 'accessible';

export interface DisplayScaleConfig {
  uiScale: number;             // Genel Arayüz ve Düzen (0.75 - 1.75)
  typographyScale: number;     // Tipografi ve Metin (0.75 - 1.75)
  toolDockScale: number;       // Yüzen Kalem Çubuğu ve Araçlar (0.75 - 1.75)
  canvasScale: number;         // Tuval ve Not Görünümü (0.75 - 1.75)
  autoSystemFontScale: boolean;// Sistem metin boyutuna otomatik uy
  minTouchTargetSize: number;  // Min 48px touch target
  safeLayoutMode: boolean;     // Taşma ve bozulmaya karşı koruma
}

/**
 * ColorNote Full-Bleed Ruled Paper Themes
 */
export type PaperThemeId = "yellow_parchment" | "night_charcoal" | "pastel_green" | "classic_white";

export interface PaperNotebookConfig {
  activeTheme: PaperThemeId;
  fontSize: number;          // Default: 17
  lineHeightRatio: number;   // Default: 1.65
  showRuledLines: boolean;   // Default: true
  showMarginLine: boolean;   // Default: true
  enableLineHighlight: boolean; // Default: true
}

/**
 * Strict Types for Ultra-Realistic Contextual Radial Menu System
 */
export type RadialMenuTheme = 'productivity' | 'media' | 'gaming' | 'photo' | 'smarthome' | 'launcher';

export type RadialActionType = 
  | 'bold' | 'italic' | 'underline' | 'strikethrough'
  | 'h1' | 'h2' | 'h3' | 'paragraph'
  | 'ul' | 'ol' | 'align-left' | 'align-center' | 'align-right'
  | 'font-family' | 'font-size' | 'text-color' | 'highlight'
  | 'voice-record' | 'camera-capture' | 'attachment' | 'ai-mindmap';

export interface RadialMenuItem {
  id: RadialActionType | string;
  label: string;
  icon: React.ReactNode | string;
  category?: 'format' | 'media' | 'structure' | 'ai';
  isVisible?: boolean;
  order?: number;
  action?: () => void;
  color?: string;
  badge?: string;
  subLabel?: string;
}

export interface RadialMenuConfig {
  activeTheme: RadialMenuTheme;
  useLegacyMenu: boolean;
  position: { x: number; y: number };
  scale: number; // 0.5 to 2.0
  isDragging?: boolean;
  isOpen?: boolean;
  followCursor?: boolean;
  idleAutoCollapse?: boolean;
  visibleActions?: Record<string, boolean>;
}
export type NavBarPosition = "bottom_fixed" | "floating_dock" | "top_bar" | "sidebar_left" | "sidebar_right";
export type NavBarActiveIndicatorStyle = "pill" | "underline" | "glow" | "scale_icon";
export type NavBarLabelMode = "always" | "active_only" | "hidden";

export interface NavBarConfig {
  position: NavBarPosition;             // Alt yapışık, yüzen dok, üst çubuk, sol/sağ kenar
  height: number;                       // 48dp - 80dp (Compact / Normal / Exp)
  widthPercent: number;                 // %70 - %100
  iconLabelScale: number;               // 0.8x - 1.4x
  labelMode: NavBarLabelMode;           // always, active_only, hidden
  borderRadius: number;                 // 0dp - 40dp (Kapsül, Yuvarlak, Dikdörtgen)
  glassmorphism: boolean;               // Cam efekti ve saydamlık
  opacity: number;                      // %50 - %100
  blur: number;                         // 0px - 30px
  activeIndicatorStyle: NavBarActiveIndicatorStyle; // pill, underline, glow, scale_icon
  showBadges: boolean;                  // Rozet ve sayaçları göster
}

/**
 * Advanced Profile Interface & Navigation Experience Configuration
 */
export type NavigationConcept = "classic" | "vertical_cards" | "adaptive_dock" | "minimal_icons";
export type ToolSortMode = "smart_relational" | "alphabetical" | "drag_drop";

export interface ProfileInterfaceConfig {
  navigationConcept: NavigationConcept;
  showThumbnails: boolean;
  showInlineControls: boolean;
  toolSortMode: ToolSortMode;
  customToolOrder: string[];
  inlineUiScale: number;    // 0.8 to 1.4
  inlineFontSize: number;   // 12 to 24
}



