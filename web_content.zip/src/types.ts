export interface User {
  id: string;
  name: string;
  email: string;
  photoURL?: string;
  bio?: string;
  emailVerified: boolean;
  createdAt: string;
}

export interface VoiceSettings {
  voiceURI: string;
  rate: number;
  pitch: number;
  autoRead: boolean;
}

export interface AIPersonalization {
  aiName: string;
  responseStyle: 'Professional' | 'Friendly' | 'Creative' | 'Simple' | 'Detailed';
  responseLength: 'Short' | 'Balanced' | 'Detailed';
  preferredLanguage: string;
  customInstructions: string;
}

export interface NotificationSettings {
  enabled: boolean;
  aiUpdates: boolean;
  productUpdates: boolean;
  accountAlerts: boolean;
}

export interface AppearanceSettings {
  theme: 'system' | 'light' | 'dark';
  fontSize: 'sm' | 'base' | 'lg';
  chatDensity: 'compact' | 'comfortable';
  animations: boolean;
}

export interface AISettings {
  model: string;
  temperature: number;
  maxTokens: number;
  streamResponse: boolean;
}

export interface UserPreferences {
  theme: 'system' | 'light' | 'dark';
  voice: VoiceSettings;
  voiceSettings?: VoiceSettings;
  personalization: AIPersonalization;
  notifications: NotificationSettings;
  appearance: AppearanceSettings;
  aiSettings: AISettings;
}

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  lastMessage?: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  userId: string;
  role: 'user' | 'model';
  content: string;
  createdAt: string;
  feedback?: 'like' | 'dislike' | null;
}

export type PageView =
  | 'splash'
  | 'landing'
  | 'login'
  | 'signup'
  | 'verify-email'
  | 'forgot-password'
  | 'reset-password'
  | 'chat'
  | 'profile'
  | 'edit-profile'
  | 'notifications-settings'
  | 'voice-settings'
  | 'personalization-settings'
  | 'appearance-settings'
  | 'ai-settings'
  | 'privacy-security'
  | 'change-password'
  | 'help-support'
  | 'about'
  | 'admin'
  | '404';

export interface TicketReply {
  id: string;
  sender: 'admin' | 'user';
  message: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId?: string;
  userName: string;
  userEmail: string;
  subject: string;
  category?: string;
  message: string;
  status: 'pending' | 'replied' | 'closed';
  replies: TicketReply[];
  createdAt: string;
  updatedAt: string;
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  targetUserId?: string;
  createdAt: string;
  read?: boolean;
}

export interface SearchResult {
  conversationId: string;
  conversationTitle: string;
  messageId?: string;
  messageContent?: string;
  matchType: 'title' | 'message';
  date: string;
}
