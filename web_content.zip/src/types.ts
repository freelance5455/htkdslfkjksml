export interface Question {
  text: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  subjectId: string;
  subCategoryId: string;
  title: string;
  description?: string;
  questions: Question[];
  createdAt: number;
}

export interface SubCategory {
  id: string;
  name: string;
  iconName: string;
}

export interface Subject {
  id: string;
  num: string;
  name: string;
  iconName: string;
  color: string;
  badgeBg: string;
  subcategories: SubCategory[];
}

export const SUBJECTS_DATA: Subject[] = [
  {
    id: 'maths',
    num: '1',
    name: 'Maths (गणित)',
    iconName: 'Calculator',
    color: 'from-amber-500 to-orange-600',
    badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
    subcategories: [
      { id: 'maths_all', name: 'गणित संपूर्ण विषय (All Maths Topics)', iconName: 'Layers' },
      { id: 'maths_arithmetic', name: 'अंकगणित (Arithmetic)', iconName: 'Percent' },
      { id: 'maths_algebra', name: 'बीजगणित व रेखागणित (Algebra & Geometry)', iconName: 'Shapes' },
    ],
  },
  {
    id: 'gk_gs',
    num: '2',
    name: 'GK / GS (सामान्य ज्ञान & विज्ञान)',
    iconName: 'Globe',
    color: 'from-blue-600 to-indigo-700',
    badgeBg: 'bg-blue-100 text-blue-800 border-blue-200',
    subcategories: [
      { id: 'indian_history', name: 'भारतीय इतिहास (Indian History)', iconName: 'Landmark' },
      { id: 'indian_polity', name: 'भारतीय राजनीति (Indian Polity)', iconName: 'Scale' },
      { id: 'indian_geography', name: 'भारतीय भूगोल (Indian Geography)', iconName: 'Compass' },
      { id: 'general_science', name: 'सामान्य विज्ञान (General Science)', iconName: 'FlaskConical' },
    ],
  },
  {
    id: 'reasoning',
    num: '3',
    name: 'Reasoning (रीजनिंग)',
    iconName: 'Brain',
    color: 'from-purple-600 to-pink-600',
    badgeBg: 'bg-purple-100 text-purple-800 border-purple-200',
    subcategories: [
      { id: 'reasoning_verbal', name: 'भाषिक रीजनिंग (Verbal Reasoning)', iconName: 'MessageSquare' },
      { id: 'reasoning_nonverbal', name: 'अभाषिक रीजनिंग (Non-Verbal Reasoning)', iconName: 'Puzzle' },
    ],
  },
  {
    id: 'english',
    num: '4',
    name: 'English (इंग्लिश)',
    iconName: 'Languages',
    color: 'from-emerald-600 to-teal-700',
    badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    subcategories: [
      { id: 'eng_grammar', name: 'English Grammar', iconName: 'SpellCheck' },
      { id: 'eng_vocab', name: 'Vocabulary & Comprehension', iconName: 'BookA' },
    ],
  },
  {
    id: 'rajasthan_gk',
    num: '5',
    name: 'Rajasthan GK (राजस्थान जीके)',
    iconName: 'ShieldAlert',
    color: 'from-rose-600 to-red-700',
    badgeBg: 'bg-rose-100 text-rose-800 border-rose-200',
    subcategories: [
      { id: 'raj_art_culture', name: 'राजस्थान कला एवं संस्कृति (Art & Culture)', iconName: 'Palette' },
      { id: 'raj_history', name: 'राजस्थान इतिहास (Rajasthan History)', iconName: 'Crown' },
      { id: 'raj_geography', name: 'राजस्थान भूगोल (Rajasthan Geography)', iconName: 'Map' },
      { id: 'raj_polity', name: 'राजस्थान राजनीति (Rajasthan Polity)', iconName: 'Building2' },
    ],
  },
  {
    id: 'hindi',
    num: '6',
    name: 'Hindi (हिंदी)',
    iconName: 'BookOpen',
    color: 'from-cyan-600 to-blue-700',
    badgeBg: 'bg-cyan-100 text-cyan-800 border-cyan-200',
    subcategories: [
      { id: 'hindi_vyakaran', name: 'हिंदी व्याकरण (Hindi Grammar)', iconName: 'Type' },
      { id: 'hindi_sahitya', name: 'हिंदी साहित्य एवं शब्दकोश', iconName: 'Book' },
    ],
  },
];
