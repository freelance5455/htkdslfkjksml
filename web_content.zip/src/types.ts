export type ViewKey =
  | "dashboard"
  | "questions"
  | "audio"
  | "design"
  | "preview"
  | "export"
  | "selftest"
  | "help";

export type MediaKind = "audio" | "image";

export interface MediaMeta {
  id: string;
  name: string;
  type: string;
  size: number;
  kind: MediaKind;
  duration?: number;
  width?: number;
  height?: number;
  peaks?: number[];
  createdAt: number;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  correct: number;
  questionAudioId: string | null;
  optionsAudioId: string | null;
  combinedAudioId: string | null;
  answerAudioId: string | null;
  imageId: string | null;
  thinkSec: number;
  revealHoldMs: number;
}

export type FontKey = "Tajawal" | "Cairo" | "Almarai" | "Amiri" | "IBM Plex Sans Arabic";

export interface DesignConfig {
  presetName: string;
  background: {
    kind: "gradient" | "color";
    colorA: string;
    colorB: string;
    angle: number;
    imageId: string | null;
    overlay: number;
    glow: boolean;
    grid: boolean;
  };
  typography: {
    font: FontKey;
    questionSize: number;
    optionSize: number;
    questionWeight: number;
    optionWeight: number;
    lineHeight: number;
    align: "right" | "center";
    questionColor: string;
    optionColor: string;
  };
  options: {
    gap: number;
    radius: number;
    padding: number;
    fill: string;
    fillOpacity: number;
    borderColor: string;
    borderWidth: number;
    shadow: boolean;
    letters: "arabic" | "latin" | "numbers" | "none";
    correctColor: string;
    dimOpacity: number;
    showCheck: boolean;
  };
  timer: {
    visible: boolean;
    style: "ring" | "pill" | "bar";
    position: "top" | "bottom";
    x: number;
    y: number;
    size: number;
    color: string;
    trackColor: string;
  };
  content: {
    x: number;
    y: number;
    width: number;
    showCard: boolean;
    showQuestionNumber: boolean;
  };
  brand: {
    show: boolean;
    text: string;
    logoId: string | null;
    opacity: number;
    showProgress: boolean;
  };
  motion: {
    entrance: "fade" | "slide" | "zoom" | "rise" | "none";
    reveal: "glow" | "pulse" | "none";
    transition: "fade" | "slide" | "zoom" | "none";
    speed: number;
  };
}

export interface TimingConfig {
  audioMode: "separate" | "combined";
  combinedSplit: number;
  questionHoldMs: number;
  optionsHoldMs: number;
  questionSilentMs: number;
  optionsSilentMs: number;
  nextHoldMs: number;
  defaultThinkSec: number;
  requireAudio: boolean;
  voiceVolume: number;
  musicVolume: number;
  sfxVolume: number;
  backgroundMusicId: string | null;
  sfxEnabled: boolean;
  showOptionLetters: boolean;
}

export interface ExportSettings {
  aspect: "vertical" | "landscape" | "square" | "custom";
  width: number;
  height: number;
  fps: 24 | 25 | 30;
  quality: "economy" | "standard" | "high";
  videoBitrate: number;
  audioBitrate: number;
  filename: string;
}

export interface Project {
  version: 1;
  id: string;
  name: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  isSample: boolean;
  questions: Question[];
  design: DesignConfig;
  timing: TimingConfig;
  exportSettings: ExportSettings;
  media: Record<string, MediaMeta>;
  designPresets: { id: string; name: string; design: DesignConfig }[];
}

export interface ProjectSummary {
  id: string;
  name: string;
  updatedAt: number;
  questionCount: number;
  width: number;
  height: number;
  isSample: boolean;
}

export type IssueLevel = "error" | "warning";

export interface ValidationIssue {
  level: IssueLevel;
  message: string;
  questionId?: string;
  field?: string;
}

export interface SceneAudioClip {
  id: string;
  role: "question" | "options" | "answer";
  mediaId: string;
  start: number;
  duration: number;
  volume: number;
}

export interface SceneTimings {
  start: number;
  duration: number;
  optionsStart: number;
  thinkingStart: number;
  revealStart: number;
  end: number;
  revealDuration: number;
}

export interface QuestionScene {
  questionId: string;
  index: number;
  question: Question;
  timings: SceneTimings;
  audio: SceneAudioClip[];
}

export interface Timeline {
  scenes: QuestionScene[];
  totalDuration: number;
  hasAudio: boolean;
  warnings: string[];
}

export type ExportPhase =
  | "idle"
  | "preparing"
  | "mixing"
  | "rendering"
  | "encoding-audio"
  | "finalizing"
  | "validating"
  | "done"
  | "error"
  | "cancelled";

export interface ExportProgress {
  phase: ExportPhase;
  percent: number;
  label: string;
  detail?: string;
  etaSeconds?: number;
  startedAt?: number;
}

export interface Mp4Check {
  key: string;
  label: string;
  status: "pass" | "fail" | "warn";
  detail: string;
}

export interface ExportResult {
  blob: Blob;
  url: string;
  filename: string;
  width: number;
  height: number;
  duration: number;
  size: number;
  checks: Mp4Check[];
  createdAt: number;
  audioCodec: string;
  videoCodec: string;
  frames: number;
}

export interface ToastMessage {
  id: string;
  text: string;
  kind: "success" | "error" | "info" | "warning";
}
