export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  email?: string;
  photoURL: string;
  bannerURL?: string;
  bio: string;
  isVerified: boolean;
  postsCount: number;
  followersCount: number;
  followingCount: number;
  usernameLastChangedAt?: string;
  hasInfluencerCertificate?: boolean;
  certificateId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Post {
  id: string;
  userId: string;
  username: string;
  userDisplayName: string;
  userPhotoURL: string;
  isVerified: boolean;
  mediaType: 'video' | 'image';
  mediaUrl: string;
  coverUrl: string;
  caption: string;
  hashtags: string[];
  musicTitle: string;
  privacy: 'public' | 'followers' | 'private';
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  viewsCount: number;
  category: string;
  createdAt: string;
  updatedAt?: string;
  likedByMe?: boolean;
  savedByMe?: boolean;
  followedByMe?: boolean;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  username: string;
  userDisplayName: string;
  userPhotoURL: string;
  isCreator: boolean;
  text: string;
  likesCount: number;
  likedByMe?: boolean;
  parentId?: string | null;
  replyToUsername?: string | null;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  senderId: string;
  senderUsername: string;
  senderDisplayName: string;
  senderPhotoURL: string;
  type: 'like' | 'comment' | 'follow' | 'milestone' | 'mention' | 'certificate';
  message: string;
  targetId?: string;
  targetThumbnail?: string;
  read: boolean;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  text: string;
  mediaUrl?: string;
  read: boolean;
  createdAt: string;
}

export interface InfluencerCertificate {
  id: string;
  userId: string;
  username: string;
  userDisplayName: string;
  followerCountAtIssuance: number;
  issuedAt: string;
  verificationCode: string;
  title: string;
  description: string;
}

export interface StudioMetric {
  value: string;
  numericValue: number;
  changePercent: number;
  isPositive: boolean;
  trend: number[];
}

export interface StudioAnalytics {
  period: '7d' | '30d' | '90d';
  views: StudioMetric;
  reach: StudioMetric;
  engagement: StudioMetric;
  followerGrowth: number;
  totalLikes: number;
  totalComments: number;
  totalShares: number;
  topVideos: {
    id: string;
    title: string;
    coverUrl: string;
    views: string;
    growthPercent: number;
  }[];
}
