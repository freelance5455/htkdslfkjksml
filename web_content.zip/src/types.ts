export type Role = 'ADMIN' | 'EMPLEADO';

export interface WorkArea {
  id: string;
  name: string;
  iconName?: string;
  color?: string;
}

export interface User {
  id: string;
  name: string;
  username: string;
  password?: string;
  role: Role;
  areaId: string; // ID of WorkArea
  areaName?: string;
  shift: string; // e.g. "Turno 1", "Turno 2", "Turno 3"
  active: boolean;
  createdAt: string;
}

export interface TaskTemplate {
  id: string;
  areaId: string;
  title: string;
  description?: string;
  shiftTarget?: string; // 'Todos' | 'Turno 1' | 'Turno 2' | 'Turno 3'
  priority?: 'Normal' | 'Alta' | 'Urgente';
  createdAt: string;
}

export type TaskStatus = 'pendiente' | 'realizada';

export interface TaskRecord {
  id: string;
  templateId: string;
  title: string;
  areaId: string;
  areaName: string;
  status: TaskStatus;
  shift: string; // e.g. "Turno 1"
  date: string; // DD/MM/YYYY
  time: string; // hh:mm A
  completedByUserId?: string;
  completedByName?: string;
  completedAt?: string;
  pendingReason?: string;
  pendingReportedByUserId?: string;
  pendingReportedByName?: string;
  // If picked up and resolved by the next shift:
  resolvedInNextShift?: boolean;
  resolvedByUserId?: string;
  resolvedByName?: string;
  resolvedShift?: string;
  resolvedDate?: string;
  resolvedTime?: string;
  resolvedAt?: string;
}

export interface ShortageItem {
  id: string;
  product: string;
  quantity: string;
  comment: string;
  reportedByUserId: string;
  reportedByName: string;
  areaId: string;
  areaName: string;
  shift: string;
  date: string;
  time: string;
  status: 'Pendiente' | 'Comprado';
  purchasedAt?: string;
  purchasedByName?: string;
  createdAt: string;
}

export interface ShiftHandover {
  id: string;
  areaId: string;
  areaName: string;
  fromShift: string;
  employeeId: string;
  employeeName: string;
  date: string;
  time: string;
  completedTasksSummary: string[];
  pendingTasksSummary: {
    title: string;
    reason: string;
  }[];
  shortagesSummary: {
    product: string;
    quantity: string;
  }[];
  observations: string;
  receivedByEmployeeName?: string;
  receivedAt?: string;
  createdAt: string;
}

export interface ActivityLogEntry {
  id: string;
  type:
    | 'TAREA_REALIZADA'
    | 'TAREA_PENDIENTE'
    | 'PENDIENTE_RESUELTO'
    | 'CAMBIO_TURNO'
    | 'FALTANTE_REPORTADO'
    | 'COMPRA_REALIZADA'
    | 'TAREA_CREADA'
    | 'EMPLEADO_CREADO';
  employeeName: string;
  area: string;
  shift: string;
  task?: string;
  status: string;
  details: string;
  date: string;
  time: string;
  timestamp: number;
}
