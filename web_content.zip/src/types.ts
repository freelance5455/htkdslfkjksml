export type ProductCategory = 'grocery' | 'general' | 'cosmetics' | 'pansar' | 'books';

export interface Product {
  id: string;
  name: string;
  urduName: string;
  category: ProductCategory;
  unit: string;
  price: number;
  originalPrice?: number;
  image: string;
  inStock: boolean;
  isFeatured?: boolean;
  description?: string;
  urduDescription?: string;
  badge?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'dispatched' | 'delivered' | 'cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  urduName: string;
  unit: string;
  price: number;
  quantity: number;
  total: number;
}

export interface Order {
  id: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  villageName: string;
  streetAddress: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  paymentMethod: 'cod' | 'jazzcash_easypaisa';
  status: OrderStatus;
}

export interface StoreSettings {
  storeName: string;
  storeUrduName: string;
  ownerName: string;
  phone: string;
  whatsappNumber: string;
  adminPin: string;
  deliveryFee: number;
  freeDeliveryThreshold: number;
  villages: string[];
  announcement: string;
  announcementUrdu: string;
}

export type AppLanguage = 'ur' | 'en';
