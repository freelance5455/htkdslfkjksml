export type CharacterGender = 'boy' | 'girl';

export type SkinId = 'classic' | 'biohazard' | 'golden' | 'cryo' | 'toxic';

export type HazardType = 'acid_puddle' | 'plasma_laser' | 'cryo_spill' | 'steam_vent';

export interface SkinDef {
  id: SkinId;
  nameAr: string;
  nameEn: string;
  cost: number;
  description: string;
  badge: string;
  coatColor: string;
  coatTrim: string;
  accentColor: string;
  pantsColor: string;
  gogglesColor: string;
  gogglesLens: string;
  auraColor?: string;
  glowColor: string;
}

export interface Question {
  id: number;
  q: string;
  a: string[];
  c: number; // correct answer index
  e: string; // explanation in Egyptian Arabic
  topic?: string;
}

export interface Player {
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  grounded: boolean;
  face: number;
  run: number;
  invulnerableTime: number;
}

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  type?: 'standard' | 'high' | 'floating';
}

export interface Capsule {
  id: number;
  x: number;
  y: number;
  taken: boolean;
  colorType?: number;
}

export interface Station {
  index: number;
  x: number;
  done: boolean;
  answeredCorrectly?: boolean;
}

export interface Hazard {
  x: number;
  y: number;
  w: number;
  h: number;
  type: HazardType;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export type GameScreen = 'START' | 'PLAYING' | 'PAUSED' | 'QUIZ' | 'END' | 'STUDY_GUIDE';

export interface GameScore {
  score: number;
  correctAnswers: number;
  capsulesCollected: number;
  totalQuestions: number;
  date?: string;
}
