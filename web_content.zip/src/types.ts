export type ThemeMode = 'cyber-rgb' | 'black-white' | 'midnight-dark' | 'clean-light';

export type LanguageCode = 'en' | 'hi' | 'bn' | 'hinglish';

export interface Agent {
  id: string;
  name: string;
  role: string;
  avatar: string;
  color: string;
  customInstructions: string;
  isDefault: boolean;
  isCustom: boolean;
  createdAt: string;
}

export interface GeneratedImagePayload {
  prompt: string;
  title: string;
  subtitle?: string;
  style?: string;
  category?: string;
  badge?: string;
  palette?: string[];
  aspectRatio?: '16:9' | '1:1' | '9:16';
  dataUrl?: string;
}

export interface ChatMessage {
  id: string;
  agentId: string;
  sender: 'user' | 'agent' | 'system';
  text: string;
  timestamp: string;
  generatedImage?: GeneratedImagePayload;
}

export interface TrendingVideo {
  id: string;
  title: string;
  channel: string;
  category: string;
  views: string;
  growthRate: string;
  viralityScore: number;
  tags: string[];
  hook: string;
  audioTrack: string;
  futurePrediction: string;
}

export interface ViralAudio {
  id: string;
  name: string;
  artist: string;
  usedInShorts: string;
  bpm: number;
  mood: string;
  viralityStatus: string;
  category: string;
}

export interface RgbLogItem {
  id: string;
  time: string;
  type: 'INFO' | 'PREDICT' | 'AUDIO' | 'ALGO' | 'VIRAL';
  message: string;
}
