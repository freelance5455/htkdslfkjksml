export type Language = "auto" | "bn" | "hi" | "en";

export type TabType = "chat" | "voice" | "image" | "editor" | "content" | "memory";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: string;
  durationMs?: number;
  isVoice?: boolean;
  offline?: boolean;
}

export interface UserMemory {
  addressingMode: "tumi" | "apni";
  profession: string;
  interests: string;
  language: Language;
  facts: string[];
  lastUpdated: string;
}

export interface GeneratedImageItem {
  id: string;
  prompt: string;
  title: string;
  url: string;
  timestamp: string;
  style: string;
  tags?: string[];
  colors?: {
    primary: string;
    secondary: string;
  };
  alternativeImages?: Array<{
    url: string;
    title: string;
    thumbnail?: string;
  }>;
}

export interface ContentStudioResult {
  titles: { title: string; score: string; vibe: string }[];
  description: string;
  hashtags: string[];
  thumbnail: {
    headlineText: string;
    visualConcept: string;
    badgeText: string;
    bgStyle: string;
  };
  reelsCaption: string;
}
