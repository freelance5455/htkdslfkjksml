export type AnswerOption = 'A' | 'B' | 'C' | 'D' | '';

export type Subject = 'Physics' | 'Chemistry' | 'Botany' | 'Zoology';

export interface TestFolder {
  id: string;
  instituteName: string;
  testNo: string;
  syllabus: string;
  createdAt: number;
  hasAnswerKey: boolean;
  answerKey: Record<number, AnswerOption>;
}

export interface SubjectAnalysis {
  subject: Subject;
  correct: number;
  incorrect: number;
  skipped: number;
  score: number;
  correctList: number[];
  incorrectList: number[];
  skippedList: number[];
}

export interface TestAttempt {
  id: string;
  testId: string;
  timestamp: number;
  dateStr: string;
  dayStr: string;
  monthStr: string;
  studentAnswers: Record<number, AnswerOption>;
  totalScore: number;
  totalCorrect: number;
  totalIncorrect: number;
  totalSkipped: number;
  subjects: Record<Subject, SubjectAnalysis>;
}

export interface AppState {
  folders: TestFolder[];
  attempts: TestAttempt[];
}
