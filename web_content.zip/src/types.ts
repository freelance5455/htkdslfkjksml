export type ProjectType = 'Website' | 'App' | 'Website + App';
export type PaymentMode = 'UPI' | 'Bank' | 'Cash';
export type TaskStage = 'todo' | 'doing' | 'done';
export type TaskPriority = 'high' | 'medium' | 'low';
export type ExpenseCategory = 'Hardware' | 'Team & Events' | 'Cloud & Hosting' | 'Marketing' | 'Operations';

export type AppTab =
  | 'home'
  | 'clients'
  | 'payments'
  | 'tasks'
  | 'more'
  | 'invoices'
  | 'expenses'
  | 'reports';

export interface ReminderLog {
  id: string;
  sentAt: string;
  channel: 'WhatsApp';
  amountReminded: number;
  message: string;
}

export interface Client {
  id: string;
  name: string;
  city: string;
  projectType: ProjectType;
  projectTitle: string;
  phone: string;
  totalAmount: number;
  paidAmount: number;
  pendingSince?: string;
  status: 'active' | 'completed';
  notes: string;
  reminderHistory: ReminderLog[];
}

export interface Payment {
  id: string;
  clientId: string;
  amount: number;
  date: string;
  mode: PaymentMode;
  note: string;
  invoiceNumber?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  clientId: string;
  projectName: string;
  totalAmount: number;
  advancePaid: number;
  notes?: string;
  status: 'Paid' | 'Unpaid';
}

export interface TaskItem {
  id: string;
  title: string;
  clientId: string;
  deadline: string;
  priority: TaskPriority;
  stage: TaskStage;
}

export interface ExpenseItem {
  id: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  date: string;
  note: string;
}

export interface StudioSettings {
  adminName: string;
  adminTitle: string;
  adminBio: string;
  adminEmail: string;
  companyName: string;
  companyAbout: string;
  companyAddress: string;
  upiId: string;
  invoiceNote: string;
  pinCode: string;
}
