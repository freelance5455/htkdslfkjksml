export interface UserProfile {
  id: number;
  name: string;
  email: string;
  phone?: string;
  walletBalancePaise?: number;
  accountType: 'customer' | 'admin';
  role: string;
  permissions?: string[];
}

export interface ServiceItem {
  id: number;
  slug: string;
  name: string;
  category: string;
  description: string;
  compliance_note: string;
  reference_quantity: number;
  reference_price_paise: number;
  min_quantity: number;
  max_quantity: number;
  estimated_turnaround: string;
  is_active: number;
  policy_approved: number;
}

export interface OrderItem {
  id: number;
  order_code: string;
  user_id: number;
  service_id: number;
  service_name_snapshot: string;
  target_url: string;
  quantity: number;
  reference_quantity_snapshot: number;
  reference_price_paise_snapshot: number;
  total_amount_paise: number;
  status: 'awaiting_payment' | 'queued' | 'in_progress' | 'completed' | 'payment_failed' | 'refunded' | 'cancelled';
  payment_status: 'unpaid' | 'pending' | 'paid' | 'failed' | 'refunded';
  progress_percent: number;
  notes: string;
  created_at: string;
  updated_at: string;
  latest_payment_id?: number | null;
  latest_payment_code?: string | null;
  payment_method?: string | null;
  payment_gateway_status?: string | null;
  utr_number?: string | null;
  receipt_number?: string | null;
  webhook_verified?: number;
  customer_name?: string;
  customer_email?: string;
}

export interface PaymentRecord {
  id: number;
  payment_code: string;
  order_id: number | null;
  user_id: number;
  purpose: 'order_payment' | 'wallet_topup';
  gateway: 'upi_direct' | 'razorpay' | 'wallet' | 'demo_razorpay';
  gateway_order_id: string;
  gateway_payment_id: string | null;
  method: 'upi' | 'gpay' | 'phonepe' | 'paytm' | 'card_netbanking' | 'wallet';
  amount_paise: number;
  currency: string;
  status: 'created' | 'pending' | 'captured' | 'failed' | 'refunded';
  webhook_verified: number;
  webhook_event_id: string | null;
  receipt_number: string | null;
  utr_number?: string | null;
  failure_reason: string | null;
  verified_at: string | null;
  created_at: string;
  order_code?: string | null;
  target_url?: string | null;
  service_name_snapshot?: string | null;
  quantity?: number | null;
  order_status?: string | null;
  customer_name?: string;
  customer_email?: string;
}

export interface UpiConfig {
  merchantUpiId: string;
  merchantName: string;
  upiDirectEnabled: boolean;
  upiQrImageUrl?: string;
}

export interface TransactionRecord {
  id: number;
  tx_code: string;
  user_id: number;
  order_id: number | null;
  payment_id: number | null;
  refund_id: number | null;
  type: 'order_payment' | 'wallet_topup' | 'wallet_debit' | 'refund_credit';
  direction: 'credit' | 'debit';
  amount_paise: number;
  status: 'pending' | 'completed' | 'failed';
  description: string;
  created_at: string;
  payment_code?: string | null;
  payment_method?: string | null;
  receipt_number?: string | null;
  order_code?: string | null;
}

export interface RefundRecord {
  id: number;
  refund_code: string;
  payment_id: number;
  order_id: number | null;
  user_id: number;
  admin_id: number;
  amount_paise: number;
  reason: string;
  destination: 'wallet' | 'original_source';
  status: 'processed' | 'pending' | 'failed';
  created_at: string;
  customer_name?: string;
  customer_email?: string;
  payment_code?: string;
  order_code?: string | null;
  admin_name?: string;
}

export interface SupportTicket {
  id: number;
  ticket_code: string;
  user_id: number;
  order_id: number | null;
  subject: string;
  message: string;
  admin_reply: string;
  status: 'open' | 'in_review' | 'resolved';
  created_at: string;
  updated_at: string;
  order_code?: string | null;
  customer_name?: string;
  customer_email?: string;
}

export interface AuditLogRecord {
  id: number;
  actor_type: string;
  actor_id: number | null;
  actor_email: string;
  action: string;
  entity_type: string;
  entity_id: string;
  ip_address: string;
  metadata_json: string;
  created_at: string;
}

export interface CustomerDashboardData {
  walletBalancePaise: number;
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  availableServices: number;
  recentTransactions: TransactionRecord[];
  recentOrders: OrderItem[];
}

export interface AdminOverviewData {
  dailyRevenuePaise: number;
  monthlyRevenuePaise: number;
  totalRefundedPaise: number;
  totalCustomers: number;
  totalOrders: number;
  activeOrders: number;
  openTickets: number;
  revenueSeries: Array<{ day: string; revenue_paise: number; tx_count: number }>;
}

export interface ReceiptDetail extends PaymentRecord {
  customer_name: string;
  customer_email: string;
  quantity?: number;
  target_url?: string;
}
