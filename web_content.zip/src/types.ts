export interface CapturedNotification {
  id: string;
  app: string;
  packageName: string;
  category: 'Messaging' | 'Email' | 'Calendar' | 'Video' | 'Work' | 'System';
  title: string;
  text: string;
  timestamp: number;
  timeReceived: string;
  importance: 'high' | 'normal' | 'low';
  isOngoing?: boolean;
}

export interface CalendarEvent {
  id: string;
  title: string;
  time: string;
  location?: string;
  isImportant: boolean;
}

export type VoicePersonalityType =
  | 'JARVIS'
  | 'VISION'
  | 'ULTRON'
  | 'Classic Android'
  | 'British Butler'
  | 'Tactical AI'
  | 'Concise Executive';

export type PermissionStatus = 'GRANTED' | 'REQUIRED' | 'DENIED';

export interface JarvisSettings {
  morningBriefingTime: string;
  isDailyBriefingEnabled: boolean;
  voicePitch: number;
  voiceSpeed: number;
  voiceLanguage: string;
  voicePersonality: VoicePersonalityType;
  wakeWordEnabled: boolean;
  readNotificationsOnArrival: boolean;
  filterImportantOnly: boolean;
  isNotificationAccessGranted: boolean;
  isCalendarPermissionGranted: boolean;
  isMicrophonePermissionGranted: boolean;
  isFullScreenIntentGranted: boolean;
  isExactAlarmGranted: boolean;
  isPostNotificationsGranted: boolean;
  isBatteryOptimizationIgnored: boolean;
  isBootCompletedRegistered: boolean;
  permissionStatuses?: Record<string, PermissionStatus>;
  lastBriefingCompletedTimestamp: number | null;
  allowedApps: string[];
  userName: string;
  capturedNotifications: CapturedNotification[];
  calendarEvents: CalendarEvent[];
}

export const INITIAL_CAPTURED_NOTIFICATIONS: CapturedNotification[] = [
  {
    id: 'notif-1',
    app: 'WhatsApp',
    packageName: 'com.whatsapp',
    category: 'Messaging',
    title: 'Sarah Connor',
    text: 'Are we still meeting at Stark Tower at 10:00 AM?',
    timestamp: Date.now() - 45 * 60 * 1000,
    timeReceived: '06:15 AM',
    importance: 'high',
  },
  {
    id: 'notif-2',
    app: 'WhatsApp',
    packageName: 'com.whatsapp',
    category: 'Messaging',
    title: 'Avengers Dev Team',
    text: 'Production deploy v2.4 build verification complete.',
    timestamp: Date.now() - 30 * 60 * 1000,
    timeReceived: '06:30 AM',
    importance: 'high',
  },
  {
    id: 'notif-3',
    app: 'Gmail',
    packageName: 'com.google.android.gm',
    category: 'Email',
    title: 'Alex Rivers • Architecture Review',
    text: 'Finalized subsystem specifications for the on-device AI model.',
    timestamp: Date.now() - 25 * 60 * 1000,
    timeReceived: '06:35 AM',
    importance: 'high',
  },
  {
    id: 'notif-4',
    app: 'Calendar',
    packageName: 'com.google.android.calendar',
    category: 'Calendar',
    title: 'Event in 2 hours: Executive Standup',
    text: 'Conference Room Alpha / Video Link active at 09:00 AM.',
    timestamp: Date.now() - 15 * 60 * 1000,
    timeReceived: '06:45 AM',
    importance: 'high',
  },
  {
    id: 'notif-5',
    app: 'YouTube',
    packageName: 'com.google.android.youtube',
    category: 'Video',
    title: 'MKBHD uploaded a new video',
    text: 'The Future of On-Device AI Assistants is finally here.',
    timestamp: Date.now() - 10 * 60 * 1000,
    timeReceived: '06:50 AM',
    importance: 'normal',
  },
  {
    id: 'notif-6-noise',
    app: 'Google Play Services',
    packageName: 'com.google.android.gms',
    category: 'System',
    title: 'Background Syncing',
    text: 'Syncing accounts in the background...',
    timestamp: Date.now() - 5 * 60 * 1000,
    timeReceived: '06:55 AM',
    importance: 'low',
    isOngoing: true,
  },
];

export const INITIAL_CALENDAR_EVENTS: CalendarEvent[] = [
  {
    id: 'cal-1',
    title: 'Executive Architecture Standup',
    time: '09:00 AM',
    location: 'Conference Room Alpha',
    isImportant: true,
  },
  {
    id: 'cal-2',
    title: 'Subsystem Telemetry Review',
    time: '02:00 PM',
    location: 'Lab 4B',
    isImportant: true,
  },
];

export const DEFAULT_SETTINGS: JarvisSettings = {
  morningBriefingTime: '07:00',
  isDailyBriefingEnabled: true,
  voicePitch: 1.0,
  voiceSpeed: 1.0,
  voiceLanguage: 'en-US',
  voicePersonality: 'JARVIS',
  wakeWordEnabled: true,
  readNotificationsOnArrival: false,
  filterImportantOnly: true,
  isNotificationAccessGranted: false, // Explicit user grant required
  isCalendarPermissionGranted: true, // Android READ_CALENDAR permission
  isMicrophonePermissionGranted: true, // Android RECORD_AUDIO permission
  isFullScreenIntentGranted: true, // Android 14+ USE_FULL_SCREEN_INTENT
  isExactAlarmGranted: true, // Android 12+ SCHEDULE_EXACT_ALARM
  isPostNotificationsGranted: true, // Android 13+ POST_NOTIFICATIONS
  isBatteryOptimizationIgnored: false, // Recommended for real OEM device reliability
  isBootCompletedRegistered: true, // RECEIVE_BOOT_COMPLETED manifest verified
  permissionStatuses: {
    notification_listener: 'REQUIRED',
    microphone: 'GRANTED',
    calendar: 'GRANTED',
    fullscreen_intent: 'GRANTED',
    exact_alarm: 'GRANTED',
    post_notifications: 'GRANTED',
    battery_optimization: 'REQUIRED',
    boot_completed: 'GRANTED',
  },
  lastBriefingCompletedTimestamp: null,
  allowedApps: ['WhatsApp', 'Gmail', 'Calendar', 'YouTube', 'Slack', 'Messages'],
  userName: 'Sir',
  capturedNotifications: INITIAL_CAPTURED_NOTIFICATIONS,
  calendarEvents: INITIAL_CALENDAR_EVENTS,
};

export type ScreenType = 'main' | 'settings' | 'call';

export interface AndroidNotification {
  id: string;
  app: string;
  title: string;
  body: string;
  time: string;
}

export interface AndroidProjectFile {
  path: string;
  name: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'markdown' | 'properties' | 'toml';
  category: 'Compose UI' | 'Architecture & Storage' | 'Services & Receivers' | 'Build & Config';
  content: string;
}
