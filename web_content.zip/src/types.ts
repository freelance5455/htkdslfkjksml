export type SubjectKey = 'phy' | 'chem' | 'bot' | 'zoo';

export type MaterialStatus = 'pending' | 'partial' | 'done';

export interface SubItem {
  name: string;
  done: boolean;
}

export type StatusStore = Record<string, MaterialStatus>; // key: `${subject}|${chapter}|${material}`

// sub-items store: Record<subject, Record<chapter, Record<material, SubItem[]>>>
export type SubItemStore = Record<string, Record<string, Record<string, SubItem[]>>>;

// started chapters store: Record<subject, string[]>
export type StartedChaptersStore = Record<string, string[]>;

export interface StreakData {
  d: string; // YYYY-MM-DD
  n: number; // streak count
}

export interface TestResult {
  s?: number; // 1 = done / attempted, 0 = not done
  t?: number | string; // total / 720
  p?: number | string; // phy / 180
  c?: number | string; // chem / 180
  b?: number | string; // bot / 180
  z?: number | string; // zoo / 180
  r?: number | string; // rank
  n?: string; // notes / mistakes
}

export type TestStore = Record<string, TestResult>; // key: `${prefix}:${testName}`

export interface TestDefinition {
  k: string; // e.g. "B:NEET-1" or "P1:01"
  n: string; // e.g. "NEET-1"
  d: string; // YYYY-MM-DD
  f: number; // 1 = full syllabus, 0 = part syllabus
  m?: 'Offline' | 'Online';
}

export interface TestSeries {
  id: string;
  name: string;
  sh: string;
  late: string;
  modes?: boolean;
  list: TestDefinition[];
}

export interface BacklogItem {
  id: string;
  g: 'L' | 'M' | 'T'; // Group: Lectures, Materials, Tests
  t: 'L' | 'L0' | 'C' | 'M' | 'T';
  s: string; // subject key or series name
  c: string; // chapter name or test name
  m?: string; // material name
  i?: number; // item index
  ic: string; // icon
  kd: 'Lecture' | 'Material' | 'Test';
  d: string; // description
  k?: string; // test key if test
  priorityTier: 1 | 2 | 3;
  priorityRank: number;
  priorityLabel: string;
}

export interface BackupPayload {
  nv3?: StatusStore;
  nsb?: SubItemStore;
  nst?: StartedChaptersStore;
  nstrk?: StreakData;
  ntt?: TestStore;
  neetDate?: string;
}
