export type ModuleId =
  | 'chat'
  | 'voice'
  | 'memory'
  | 'image'
  | 'pdf'
  | 'research'
  | 'study'
  | 'questions'
  | 'japanese'
  | 'diagrams'
  | 'tutor'
  | 'progress'
  | 'coding'
  | 'tasks'
  | 'voice-studio'
  | 'settings';

export type SupportedLanguage = 'English' | 'Hindi' | 'Hinglish' | 'Japanese';

export type VoiceProfileId =
  | 'Natural Male'
  | 'Natural Female'
  | 'Anime Hero'
  | 'Anime Girl'
  | 'Japanese Teacher'
  | 'My Voice';

export interface VoiceProfileInfo {
  id: VoiceProfileId;
  name: string;
  subtitle: string;
  geminiVoice: 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' | 'Puck';
  styleDescription: string;
  isFutureFeature?: boolean;
  sampleGreeting: Record<SupportedLanguage, string>;
}

export interface ChatMessage {
  id: string;
  ownerId: string;
  sessionId: string;
  role: 'user' | 'assistant';
  content: string;
  module: ModuleId;
  language: SupportedLanguage;
  createdAt: string;
  attachmentName?: string;
  tokensUsed?: number;
}

export type MemoryCategory = 'Preference' | 'Study Goal' | 'Language' | 'Project' | 'Personal';

export interface PersonalMemory {
  id: string;
  ownerId: string;
  title: string;
  content: string;
  category: MemoryCategory;
  userConsented: boolean;
  createdAt: string;
  updatedAt: string;
}

export type TaskCategory = 'Study' | 'Japanese' | 'Coding' | 'Daily' | 'Research';
export type TaskPriority = 'High' | 'Medium' | 'Low';

export interface UserTask {
  id: string;
  ownerId: string;
  title: string;
  category: TaskCategory;
  priority: TaskPriority;
  dueDate: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface StudyProgressRecord {
  id: string;
  ownerId: string;
  subject: string;
  topic: string;
  score: number;
  totalQuestions: number;
  masteryLevel: 'Beginner' | 'Intermediate' | 'Advanced' | 'Mastered';
  updatedAt: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export type SmartQuestionType = 'mcq' | 'fill_blank' | 'translation' | 'descriptive';
export type SmartDifficulty = 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';

export interface SmartQuestion {
  id: string;
  type: SmartQuestionType;
  topic: string;
  difficulty: SmartDifficulty;
  conceptTag: string;
  question: string;
  options?: string[];
  correctIndex?: number;
  expectedAnswer: string;
  acceptableAnswers?: string[];
  explanation: string;
  hindiHint?: string;
}

export interface PracticeAttempt {
  id: string;
  questionId: string;
  topic: string;
  conceptTag: string;
  type: SmartQuestionType;
  difficulty: SmartDifficulty;
  questionText: string;
  userAnswer: string;
  isCorrect: boolean;
  timestamp: string;
}

export interface LearningAnalytics {
  dailyMinutes: number;
  streakDays: number;
  lastActiveDate: string;
  masteredKanji: string[];
  learnedVocabCount: number;
}

export interface PdfAnalysisResult {
  executiveSummary: string;
  chapterBreakdown: Array<{ title: string; summary: string }>;
  keyPoints: string[];
  studyNotes: string;
  mcqs: QuizQuestion[];
}

export interface KanaItem {
  char: string;
  romaji: string;
  hindi: string;
  type: 'hiragana' | 'katakana' | 'dakuten' | 'handakuten';
  row?: string;
  exampleWord: string;
  exampleMeaningEn: string;
  exampleMeaningHi: string;
  strokes: string[];
}

export interface KanjiItem {
  kanji: string;
  onyomi: string;
  kunyomi: string;
  meaningEn: string;
  meaningHi: string;
  jlpt: 'N5' | 'N4' | 'N3' | 'N2' | 'N1';
  strokesCount: number;
  radicals: Array<{ part: string; name: string; meaning: string }>;
  memoryTrick: string;
  visualIllustration: 'mountain' | 'sun' | 'book' | 'study' | 'speech' | 'heart' | 'tree' | 'water' | 'fire' | 'person' | 'future' | 'knowledge' | 'wisdom' | 'moon' | 'forest';
  vocabulary: Array<{ word: string; reading: string; meaningEn: string; meaningHi: string }>;
  exampleSentence: {
    jp: string;
    romaji: string;
    en: string;
    hi: string;
  };
  strokePaths: string[];
}
