export interface Product {
  id: string;
  barcode: string;
  name: string;
  nameEn?: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  stock: number;
  minStock: number;
  unit: string;
  image?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  discountPercent: number; // 0 - 100
  notes?: string;
}

export type PaymentMethod = 'cash' | 'card' | 'debt' | 'split';
export type InvoiceStatus = 'paid' | 'pending' | 'returned';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string; // ISO date
  items: CartItem[];
  subtotal: number;
  taxRate: number; // e.g. 15%
  taxAmount: number;
  discountAmount: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  amountPaid: number;
  changeAmount: number;
  customerName?: string;
  customerPhone?: string;
  customerId?: string;
  cashierName: string;
  status: InvoiceStatus;
  notes?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  balance: number; // Positive means customer owes money (debt)
  notes?: string;
  createdAt: string;
}

export interface StoreSettings {
  storeName: string;
  storeNameEn: string;
  taxNumber: string;
  commercialReg: string;
  phone: string;
  address: string;
  currency: string;
  vatRate: number; // e.g. 15
  enableVat: boolean;
  receiptFooter: string;
  cashierName: string;
}

export interface CodeFile {
  id: string;
  name: string;
  language: string;
  content: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
}
