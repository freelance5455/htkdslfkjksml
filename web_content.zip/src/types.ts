export interface SceneBreakdown {
  lightingAndAtmosphere: string;
  focalPoint: string;
  historicalEra: string;
  impliedConflict: string;
}

export interface SensoryPalette {
  sounds: string[];
  scents: string[];
  tactile: string[];
}

export interface AlternativeHook {
  style: string;
  paragraph: string;
}

export interface StoryAnalysisData {
  storyTitle: string;
  genre: string;
  moodKeywords: string[];
  sceneBreakdown: SceneBreakdown;
  sensoryPalette: SensoryPalette;
  worldLore: string;
  openingParagraph: string;
  alternativeHooks: AlternativeHook[];
}

export type VoicePersona = 'Kore' | 'Puck' | 'Fenrir' | 'Charon' | 'Zephyr';

export interface VoiceOption {
  id: VoicePersona;
  name: string;
  gender: 'Female' | 'Male' | 'Neutral';
  description: string;
  bestFor: string;
}

export type ChatRoleType = 'ghostwriter' | 'lorekeeper' | 'stylist' | 'dramatist';

export interface ChatRoleConfig {
  id: ChatRoleType;
  title: string;
  tagline: string;
  systemPrompt: string;
  iconName: string;
}

export type ComplexityLevel = 'complex' | 'general' | 'fast';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  modelUsed?: string;
  complexity?: ComplexityLevel;
}

export interface SamplePreset {
  id: string;
  title: string;
  genre: string;
  imageUrl: string;
  tone: string;
  promptHint: string;
}
