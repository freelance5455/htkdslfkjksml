export type Language = 'en' | 'bn';

export type AppView = 'landing' | 'dashboard' | 'storefront' | 'admin';

export type UserRole = 'SUPER_ADMIN' | 'MERCHANT' | 'STAFF' | 'CUSTOMER';

export interface AuthUserProfile {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  role: UserRole;
  storeId?: string; // Tenant store ID for merchants and staff
  createdAt: string;
  avatarUrl?: string;
  isEmailVerified?: boolean;
}

export type DashboardTab = 
  | 'overview' 
  | 'orders'
  | 'orders_drafts'
  | 'orders_abandoned'
  | 'orders_returns'
  | 'shipping'
  | 'products'
  | 'products_collections'
  | 'products_inventory'
  | 'inventory'
  | 'products_purchase_orders'
  | 'products_transfers'
  | 'products_gift_cards'
  | 'customers' 
  | 'growth'
  | 'discounts'
  | 'content'
  | 'markets'
  | 'analytics'
  | 'customizer' 
  | 'copilot' 
  | 'pos'
  | 'agentic'
  | 'flow'
  | 'messaging'
  | 'billing'
  | 'settings';

export interface StoreTheme {
  primaryColor: string; // hex or tailwind class identifier
  accentColor: string;
  fontFamily: string;
  announcementText: string;
  announcementTextBn: string;
  showAnnouncement: boolean;
  heroHeadline: string;
  heroHeadlineBn: string;
  heroSubheadline: string;
  heroSubheadlineBn: string;
  heroBannerImage: string;
  layoutStyle: 'modern' | 'minimal' | 'bold';
}

export interface StoreLocation {
  division: string;
  district: string;
  city: string;
  address?: string;
  postalCode?: string;
}

export interface Store {
  id: string;
  name: string;
  slug: string;
  logo: string;
  category: string;
  currency: 'BDT' | 'USD' | 'EUR';
  currencySymbol: string;
  status: 'active' | 'paused' | 'setup';
  plan: 'starter' | 'growth' | 'enterprise';
  customDomain?: string;
  theme: StoreTheme;
  createdAt: string;
  ownerId?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
  city?: string;
  storeLocation?: StoreLocation;
  deliverySettings?: {
    localDeliveryCharge: number;
    outsideDeliveryCharge: number;
  };
}

export interface ProductVariant {
  id: string;
  name: string;
  sku?: string;
  price?: number;
  stock: number;
}

export interface Product {
  id: string;
  storeId: string;
  name: string;
  nameBn: string;
  sku: string;
  category: string;
  categoryBn: string;
  price: number;
  compareAtPrice?: number;
  stock: number;
  image: string;
  videoUrl?: string;
  mediaType?: 'image' | 'video';
  additionalMedia?: Array<{ url: string; type: 'image' | 'video'; name?: string }>;
  rating: number;
  reviewsCount: number;
  description: string;
  descriptionBn: string;
  isFeatured: boolean;
  tags: string[];
  brand?: string;
  status?: 'active' | 'draft' | 'archived';
  variants?: ProductVariant[];
  salesChannels?: string[];
}

export type CollectionConditionField = 'title' | 'category' | 'price' | 'inventory' | 'sku' | 'status' | 'tag';
export type CollectionConditionOperator = 
  | 'equals' 
  | 'not_equals' 
  | 'contains' 
  | 'not_contains' 
  | 'starts_with' 
  | 'ends_with' 
  | 'greater_than' 
  | 'less_than' 
  | 'greater_than_or_equal' 
  | 'less_than_or_equal';

export interface CollectionCondition {
  field: CollectionConditionField;
  operator: CollectionConditionOperator;
  value: string;
}

export interface Collection {
  id: string;
  storeId: string;
  title: string;
  titleBn?: string;
  description?: string;
  descriptionBn?: string;
  image?: string;
  type: 'manual' | 'automated';
  conditions?: CollectionCondition[];
  conditionMatch?: 'all' | 'any'; // all conditions or any condition
  productIds?: string[]; // for manual collections
  publishedScope?: string;
  createdAt: string;
  updatedAt?: string;
}

export type PaymentMethod = 'bkash' | 'nagad' | 'card' | 'cod' | 'manual' | 'online';
export type PaymentStatus = 'paid' | 'pending' | 'partially_paid' | 'failed' | 'refunded';
export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'packed' | 'shipped' | 'delivered' | 'cancelled' | 'returned' | 'refunded';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  sku?: string;
  variant?: string;
}

export interface OrderTimelineEvent {
  id: string;
  status: OrderStatus | string;
  title: string;
  description?: string;
  timestamp: string;
  actor?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  storeId: string;
  customerId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  tax?: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  deliveryAddress: string;
  billingAddress?: string;
  city: string;
  deliveryZone?: 'local' | 'outside';
  deliveryCharge?: number;
  storeLocationAtOrder?: {
    division?: string;
    district?: string;
    city?: string;
  };
  createdAt: string;
  updatedAt?: string;
  notes?: string;
  courierTrackingId?: string;
  courierProvider?: 'pathao' | 'steadfast' | 'redx';
  courierName?: string;
  shippingMethod?: string;
  transactionId?: string;
  timeline?: OrderTimelineEvent[];
}

export interface DraftOrder {
  id: string;
  orderNumber: string;
  poNumber?: string;
  storeId: string;
  customerId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  deliveryAddress: string;
  city: string;
  deliveryZone?: 'local' | 'outside';
  deliveryCharge?: number;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  tax?: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
  status: 'draft' | 'converted' | 'cancelled' | 'open' | 'completed';
  createdAt: string;
  updatedAt?: string;
}

export interface AbandonedCheckout {
  id: string;
  storeId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  deliveryAddress: string;
  city: string;
  items: OrderItem[];
  cartTotal: number;
  recoveryStatus: 'incomplete' | 'recovered' | 'blocked';
  createdAt: string;
  updatedAt?: string;
}

export interface ReturnRefundRecord {
  id: string;
  storeId: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  items: Array<{ productId: string; name: string; quantity: number; refundPrice: number }>;
  reason: string;
  notes?: string;
  refundAmount: number;
  status: 'pending' | 'approved' | 'processed' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface ShippingSettings {
  id?: string;
  storeId: string;
  localDeliveryCharge: number;
  outsideDeliveryCharge: number;
  insideCityCharge?: number;
  outsideCityCharge?: number;
  freeShippingThreshold: number;
  defaultCourier: string;
  availableCouriers: string[];
  storeLocation?: StoreLocation;
}

export interface Customer {
  id: string;
  storeId: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: string;
  status: 'active' | 'vip' | 'new';
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface PricingPlan {
  id: string;
  name: string;
  nameBn: string;
  tagline: string;
  taglineBn: string;
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  popular?: boolean;
  features: string[];
  featuresBn: string[];
  limits: {
    products: string;
    stores: number;
    transactionFee: string;
    customDomain: boolean;
    aiAssistant: boolean;
  };
}

export interface MerchantUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  password?: string;
  storeId: string;
  storeName: string;
  plan: 'starter' | 'growth' | 'enterprise';
  status: 'active' | 'suspended' | 'pending';
  joinedDate: string;
  lastLogin: string;
  trialDaysLeft?: number;
  totalPaidBDT: number;
  role?: UserRole;
}

export type PaymentGatewayProvider = 'aamarpay' | 'shohozpay' | 'shurjopay' | 'bkash_direct' | 'nagad_direct';

export interface PaymentGatewayConfig {
  id: PaymentGatewayProvider;
  name: string;
  nameBn: string;
  logo: string;
  description: string;
  descriptionBn: string;
  isEnabled: boolean;
  isLiveMode: boolean; // false = Sandbox / Test Mode, true = Live Production
  storeIdOrMerchantId: string;
  signatureOrSecretKey: string;
  appKeyOrPassword?: string;
  webhookUrl: string;
  transactionFeePercent: number;
  supportedCurrencies: string[];
}

export interface SubscriptionPayment {
  id: string;
  storeId: string;
  storeName: string;
  userName: string;
  userPhone: string;
  planId: 'starter' | 'growth' | 'enterprise';
  planName: string;
  amount: number;
  billingCycle: 'monthly' | 'yearly';
  gateway: PaymentGatewayProvider;
  transactionId: string;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  notes?: string;
}
