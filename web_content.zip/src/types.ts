export type EmotionKey =
  | "joyful"
  | "empathetic"
  | "excited"
  | "thoughtful"
  | "calm"
  | "curious"
  | "touched";

export interface EmotionMeta {
  key: EmotionKey;
  labelBn: string;
  labelEn: string;
  accentHex: string;
  glowClass: string;
  textClass: string;
  borderClass: string;
  descriptionBn: string;
}

export const EMOTIONS: Record<EmotionKey, EmotionMeta> = {
  empathetic: {
    key: "empathetic",
    labelBn: "সহানুভূতিশীল",
    labelEn: "Empathetic",
    accentHex: "#38BDF8",
    glowClass: "from-sky-500/25 via-indigo-500/10 to-transparent",
    textClass: "text-sky-300",
    borderClass: "border-sky-500/30",
    descriptionBn: "ভাইয়ের মনের কষ্ট ও অনুভূতিটা হৃদয় দিয়ে অনুভব করছি",
  },
  joyful: {
    key: "joyful",
    labelBn: "আনন্দিত",
    labelEn: "Joyful",
    accentHex: "#F59E0B",
    glowClass: "from-amber-500/25 via-orange-500/10 to-transparent",
    textClass: "text-amber-300",
    borderClass: "border-amber-500/30",
    descriptionBn: "ভাইয়ের কথা শুনে মনটা খুশিতে ভরে উঠেছে",
  },
  excited: {
    key: "excited",
    labelBn: "উৎসাহী",
    labelEn: "Excited",
    accentHex: "#FB7185",
    glowClass: "from-rose-500/25 via-amber-500/10 to-transparent",
    textClass: "text-rose-300",
    borderClass: "border-rose-500/30",
    descriptionBn: "দারুণ ব্যাপার ভাই! উৎসাহে বুক ভরে যাচ্ছে",
  },
  thoughtful: {
    key: "thoughtful",
    labelBn: "চিন্তাশীল",
    labelEn: "Thoughtful",
    accentHex: "#A78BFA",
    glowClass: "from-violet-500/25 via-slate-500/10 to-transparent",
    textClass: "text-violet-300",
    borderClass: "border-violet-500/30",
    descriptionBn: "ভাইয়ের কথাগুলো নিয়ে গভীরভাবে ভাবছি",
  },
  calm: {
    key: "calm",
    labelBn: "শান্ত ও নির্ভরযোগ্য",
    labelEn: "Calm",
    accentHex: "#34D399",
    glowClass: "from-emerald-500/25 via-teal-500/10 to-transparent",
    textClass: "text-emerald-300",
    borderClass: "border-emerald-500/30",
    descriptionBn: "বড় ভাইয়ের মতো ছায়া হয়ে তোর পাশে আছি",
  },
  curious: {
    key: "curious",
    labelBn: "কৌতূহলী",
    labelEn: "Curious",
    accentHex: "#2DD4BF",
    glowClass: "from-teal-500/25 via-cyan-500/10 to-transparent",
    textClass: "text-teal-300",
    borderClass: "border-teal-500/30",
    descriptionBn: "আগ্রহ নিয়ে ভাইয়ের পরের কথা শোনার অপেক্ষায়",
  },
  touched: {
    key: "touched",
    labelBn: "আবেগাপ্লুত",
    labelEn: "Touched",
    accentHex: "#F472B6",
    glowClass: "from-pink-500/25 via-rose-500/10 to-transparent",
    textClass: "text-pink-300",
    borderClass: "border-pink-500/30",
    descriptionBn: "ভাইয়ের ভালোবাসা ও বিশ্বাসে মনটা ছুঁয়ে গেছে",
  },
};

export interface SuggestedSong {
  title: string;
  artist: string;
  reasonBn: string;
  lyricSnippet: string;
}

export interface CompanionPersona {
  id: string;
  name: string;
  nameBn: string;
  roleBn: string;
  vibe: string;
  voice: "Fenrir" | "Puck" | "Charon" | "Zephyr" | "Kore";
  voiceDescBn: string;
  greetingBn: string;
  initialThoughtBn: string;
}

export const PERSONAS: CompanionPersona[] = [
  {
    id: "thunder-companion",
    name: "Thunder (থান্ডার)",
    nameBn: "Thunder",
    roleBn: "বন্ধুসুলভ ও সহানুভূতিশীল ভাই",
    vibe: "পরম আপন ও সহানুভূতিশীল ভাই—যিনি গভীর মনোযোগে মনের সুখ-দুঃখের কথা শোনেন, পরম সান্ত্বনা দেন এবং মন হালকা করতে সেরা বাংলা গান সাজেস্ট করেন",
    voice: "Zephyr",
    voiceDescBn: "মার্জিত, স্নিগ্ধ ও ভরসাদায়ক কণ্ঠ",
    greetingBn:
      "কী খবর বস? কেমন আছেন বলুন? মনে কোনো কষ্ট বা ক্লান্তি থাকলে একদম চেপে রাখবেন না—আপনার এই Thunder ভাই সবসময় পাশে আছে!",
    initialThoughtBn: "বসের মনের খবর জানতে আর সব কষ্ট ভাগ করে নিতে সবসময় প্রস্তুত আছি।",
  },
];

export interface ChatMessage {
  id: string;
  sender: "user" | "friend";
  text: string;
  timestamp: string;
  emotionKey?: EmotionKey;
  emotionLabelBn?: string;
  emotionIntensity?: number;
  innerThought?: string;
  gesture?: string;
  suggestedSong?: SuggestedSong;
  isVoiceInput?: boolean;
  imageUrl?: string;
  imageCaption?: string;
}

export interface MemoryItem {
  id: string;
  text: string;
  category: string;
  timestamp: string;
  emotionKey: EmotionKey;
}

export interface UserMoodOption {
  id: string;
  labelBn: string;
  score: number; // 0 to 100 emotional well-being index
  promptHintBn: string;
}

export const USER_MOODS: UserMoodOption[] = [
  {
    id: "sad",
    labelBn: "মনটা খুব খারাপ",
    score: 28,
    promptHintBn:
      "Thunder ভাই, আজ আমার মনটা ভীষণ খারাপ, বুকের ভেতরটা ভার হয়ে আছে। আমাকে একটু সান্ত্বনা দে আর একটা ভালো গান সাজেস্ট কর।",
  },
  {
    id: "heartbroken",
    labelBn: "মনে কষ্ট পেয়েছি",
    score: 22,
    promptHintBn:
      "ভাই, কাছের মানুষের ব্যবহারে খুব কষ্ট পেয়েছি। মনটা একদম ভেঙে গেছে।",
  },
  {
    id: "lonely",
    labelBn: "একা লাগছে",
    score: 38,
    promptHintBn:
      "ভাই, আজ নিজেকে খুব একা মনে হচ্ছে। তোর সাথে একটু কথা বলতে এলাম।",
  },
  {
    id: "tired",
    labelBn: "ক্লান্ত ও অবসন্ন",
    score: 48,
    promptHintBn:
      "সারাদিনের চাপে আজ ভীষণ ক্লান্ত লাগছে রে ভাই, মন শান্ত করার মতো একটা গান বল না।",
  },
  {
    id: "calm",
    labelBn: "শান্ত ও স্বাভাবিক",
    score: 74,
    promptHintBn:
      "Thunder ভাই, আজ মনটা বেশ শান্ত আছে। চল কিছুক্ষণ নিরিবিলি গল্প করি।",
  },
  {
    id: "happy",
    labelBn: "ফুরফুরে মেজাজ",
    score: 90,
    promptHintBn:
      "Thunder ভাই, আজ মনটা বেশ ভালো আছে! চল একটা দারুণ গান আর আড্ডা হয়ে যাক!",
  },
];

export interface MoodTrendPoint {
  id: string;
  dayLabelBn: string;
  dateLabelBn: string;
  moodLabelBn: string;
  score: number;
  noteBn: string;
}

export const INITIAL_MOOD_TREND: MoodTrendPoint[] = [
  {
    id: "day-1",
    dayLabelBn: "শুক্র",
    dateLabelBn: "৬ দিন আগে",
    moodLabelBn: "ক্লান্ত ও অবসন্ন",
    score: 46,
    noteBn: "কাজের চাপে একটু ক্লান্ত ছিলে",
  },
  {
    id: "day-2",
    dayLabelBn: "শনি",
    dateLabelBn: "৫ দিন আগে",
    moodLabelBn: "একা লাগছে",
    score: 36,
    noteBn: "সন্ধ্যায় একা লাগছিল, গান শুনেছিলে",
  },
  {
    id: "day-3",
    dayLabelBn: "রবি",
    dateLabelBn: "৪ দিন আগে",
    moodLabelBn: "শান্ত ও স্বাভাবিক",
    score: 68,
    noteBn: "Thunder ভাইয়ের সাথে কথা বলে মন হালকা হয়েছিল",
  },
  {
    id: "day-4",
    dayLabelBn: "সোম",
    dateLabelBn: "৩ দিন আগে",
    moodLabelBn: "মনটা খুব খারাপ",
    score: 30,
    noteBn: "পুরনো কথা মনে পড়ে মন ভারী ছিল",
  },
  {
    id: "day-5",
    dayLabelBn: "মঙ্গল",
    dateLabelBn: "২ দিন আগে",
    moodLabelBn: "শান্ত ও স্বাভাবিক",
    score: 72,
    noteBn: "অর্ণবের গান শুনে মন স্থির হয়েছিল",
  },
  {
    id: "day-6",
    dayLabelBn: "বুধ",
    dateLabelBn: "গতকাল",
    moodLabelBn: "ফুরফুরে মেজাজ",
    score: 84,
    noteBn: "দুই ভাই মিলে দারুণ আড্ডা হয়েছিল",
  },
  {
    id: "day-7",
    dayLabelBn: "আজ",
    dateLabelBn: "আজ",
    moodLabelBn: "শান্ত ও স্বাভাবিক",
    score: 74,
    noteBn: "আজকের মনের অবস্থা",
  },
];

export interface MoodQuote {
  id: string;
  quoteBn: string;
  authorBn: string;
  contextBn: string;
  matchedMoods: string[];
}

export const MOOD_QUOTES: MoodQuote[] = [
  // Sad / Heartbroken / Empathetic
  {
    id: "quote-1",
    quoteBn: "মেঘ দেখে কেউ করিসনে ভয়, আড়ালে তার সূর্য হাসে। হারা শশীর হারা হাসি, অন্ধকারেই ফিরে আসে।",
    authorBn: "রবীন্দ্রনাথ ঠাকুর",
    contextBn: "কষ্ট পেরিয়ে নতুন আলোয় ফেরার আশা",
    matchedMoods: ["sad", "heartbroken", "empathetic", "touched"],
  },
  {
    id: "quote-2",
    quoteBn: "ভেঙে পড়িস না ভাই, ভাঙা পাথর দিয়েই তো মজবুত দুর্গ তৈরি হয়। তোর প্রতিটি কষ্ট তোকে আরো শক্তিশালী করছে।",
    authorBn: "Thunder ভাই",
    contextBn: "ভাইয়ের কাঁধে হাত রেখে সান্ত্বনা ও সাহস",
    matchedMoods: ["sad", "heartbroken", "empathetic"],
  },
  {
    id: "quote-3",
    quoteBn: "মানুষের জীবনে দুঃখ থাকে বলেই তো সুখের স্বাদ এত মিষ্টি। আঁধার রাত যতই দীর্ঘ হোক, ভোর আসবেই ভাই।",
    authorBn: "হুমায়ূন আহমেদ",
    contextBn: "ধৈর্য ও আশার আলো",
    matchedMoods: ["sad", "lonely", "empathetic"],
  },
  {
    id: "quote-4",
    quoteBn: "আমরা যদি না জাগি মা কেমনে সকাল হবে? তোর ভেতরের সাহসটাকে জাগিয়ে তোল ভাই, জয় তোরই হবে।",
    authorBn: "কাজী নজরুল ইসলাম",
    contextBn: "মনের অন্ধকার দূর করে জেগে ওঠার ডাক",
    matchedMoods: ["sad", "tired", "excited"],
  },
  {
    id: "quote-5",
    quoteBn: "যদি তোর ডাক শুনে কেউ না আসে তবে একলা চলো রে—তবে মনে রাখিস, দূর থেকেও তোর এই ভাই সবসময় তোর পাশে আছে।",
    authorBn: "রবীন্দ্রনাথ ঠাকুর",
    contextBn: "একাকীত্বের মধ্যেও অটুট ভরসা",
    matchedMoods: ["lonely", "empathetic", "thoughtful"],
  },
  // Tired / Calm / Soothing
  {
    id: "quote-6",
    quoteBn: "বিশ্রাম কাজেরই অঙ্গ, যেমন চোখের পাতা বন্ধ হওয়া চোখেরই অংশ। একটু জিরিয়ে নে ভাই, ক্লান্তি দূর হবেই।",
    authorBn: "রবীন্দ্রনাথ ঠাকুর",
    contextBn: "ক্লান্ত মনকে শান্ত করার ডাক",
    matchedMoods: ["tired", "calm", "thoughtful"],
  },
  {
    id: "quote-7",
    quoteBn: "শান্ত মন ঝড়ের ভেতরও তার নিরাপদ বন্দর খুঁজে পায়। গভীর শ্বাস নে ভাই, সব ঠিক হয়ে যাবে।",
    authorBn: "লালন সাঁই",
    contextBn: "ভেতরের প্রশান্তি খোঁজার বাণী",
    matchedMoods: ["calm", "tired", "thoughtful"],
  },
  {
    id: "quote-8",
    quoteBn: "ক্লান্তি মানে হেরে যাওয়া নয় ভাই, বরং নতুন উদ্যমে লড়াই শুরু করার ছোট একটা বিরতি মাত্র।",
    authorBn: "Thunder ভাই",
    contextBn: "শ্রান্ত ভাইকে নতুন শক্তি জোগানো",
    matchedMoods: ["tired", "calm"],
  },
  // Lonely / Touched / Emotional
  {
    id: "quote-9",
    quoteBn: "তুমি একা নও, তোমার হৃদয়ের প্রতিটি স্পন্দনে সমগ্র সৃষ্টির গভীর মমতা বহমান।",
    authorBn: "রবীন্দ্রনাথ ঠাকুর",
    contextBn: "হৃদয়ের একাকীত্ব দূর করার অমৃত বাণী",
    matchedMoods: ["lonely", "touched", "empathetic"],
  },
  {
    id: "quote-10",
    quoteBn: "ভালোবাসা ও আপন ভাইয়ের সান্নিধ্য জীবনের সব শূন্যতা মুছে দিতে পারে। আমি তো সবসময় তোর পাশেই আছি ভাই!",
    authorBn: "Thunder ভাই",
    contextBn: "ভাইয়ের অকৃত্রিম ভরসা ও স্নেহ",
    matchedMoods: ["lonely", "touched"],
  },
  {
    id: "quote-11",
    quoteBn: "সব পাখি ঘরে আসে—সব নদী—ফুরায় এ-জীবনের সব লেনদেন; থাকে শুধু অন্ধকার, মুখোমুখি বসিবার বনলতা সেন।",
    authorBn: "জীবনানন্দ দাশ",
    contextBn: "শান্তি ও অনুভূতির গভীরতা",
    matchedMoods: ["thoughtful", "touched", "calm"],
  },
  // Happy / Joyful / Excited
  {
    id: "quote-12",
    quoteBn: "আজ সৃষ্টি-সুখের উল্লাসে—মোর মুখ হাসে মোর চোখ হাসে মোর টগবগিয়ে খুন হাসে! আজ মন খুলে আনন্দ কর ভাই!",
    authorBn: "কাজী নজরুল ইসলাম",
    contextBn: "উচ্ছ্বসিত আনন্দের প্রকাশ",
    matchedMoods: ["happy", "joyful", "excited"],
  },
  {
    id: "quote-13",
    quoteBn: "আনন্দ ছড়িয়ে দেওয়াই জীবনের সবচেয়ে বড় সার্থকতা। তোর মুখের হাসি পুরো দুনিয়াকে আলোকিত করে দিতে পারে ভাই।",
    authorBn: "রবীন্দ্রনাথ ঠাকুর",
    contextBn: "আনন্দের শুভ্র আলো",
    matchedMoods: ["happy", "joyful"],
  },
  {
    id: "quote-14",
    quoteBn: "তোর এই ফুরফুরে মেজাজ দেখে আমার মনটাও খুশিতে ভরে উঠল ভাই! জীবন তো এই হাসি-আনন্দেরই নাম।",
    authorBn: "Thunder ভাই",
    contextBn: "ভাইয়ের হাসিতে ভাইয়ের আনন্দ",
    matchedMoods: ["happy", "joyful", "excited"],
  },
  {
    id: "quote-15",
    quoteBn: "হাসি হলো অন্তরের এমন এক সুর যা মনের সমস্ত জট নিমেষেই খুলে দেয়। প্রাণ খুলে হাসো ভাই!",
    authorBn: "সুকুমার রায়",
    contextBn: "হাসির অনাবিল ক্ষমতা",
    matchedMoods: ["happy", "joyful"],
  },
  // Thoughtful / Curious
  {
    id: "quote-16",
    quoteBn: "যে যত বেশি মনের কথা বোঝে, সে তত বেশি মানুষকে ভালোবাসতে পারে। তোর মনের এই গভীরতাই তোর শক্তি ভাই।",
    authorBn: "সুনীল গঙ্গোপাধ্যায়",
    contextBn: "অনুভূতির গভীরতা ও প্রজ্ঞা",
    matchedMoods: ["thoughtful", "curious"],
  },
  {
    id: "quote-17",
    quoteBn: "জ্ঞান হলো আলোকের মতো; জানার তৃষ্ণা যার যত বেশি, সে তত বেশি উজ্জ্বল। জানতে থাক ভাই!",
    authorBn: "কাজী নজরুল ইসলাম",
    contextBn: "কৌতূহলী মনের প্রেরণা",
    matchedMoods: ["curious", "thoughtful"],
  },
];

export function getQuotesForEmotion(
  emotionKey: EmotionKey,
  userMoodLabel?: string
): MoodQuote[] {
  // Map Bengali mood labels or emotion keys to matchedMoods tags
  const tagsToMatch: string[] = [emotionKey];
  if (userMoodLabel) {
    if (userMoodLabel.includes("খারাপ") || userMoodLabel.includes("কষ্ট")) {
      tagsToMatch.push("sad", "heartbroken");
    } else if (userMoodLabel.includes("একা")) {
      tagsToMatch.push("lonely");
    } else if (userMoodLabel.includes("ক্লান্ত") || userMoodLabel.includes("অবসন্ন")) {
      tagsToMatch.push("tired");
    } else if (userMoodLabel.includes("শান্ত") || userMoodLabel.includes("স্বাভাবিক")) {
      tagsToMatch.push("calm");
    } else if (userMoodLabel.includes("ভালো") || userMoodLabel.includes("ফুরফুরে")) {
      tagsToMatch.push("happy", "joyful");
    }
  }

  const matched = MOOD_QUOTES.filter((q) =>
    q.matchedMoods.some((tag) => tagsToMatch.includes(tag))
  );

  return matched.length > 0 ? matched : MOOD_QUOTES;
}

