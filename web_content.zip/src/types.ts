export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error' | 'reconnecting';

export type AssistantState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'interrupted';

export type VoiceGender = 'female' | 'male';

export type VoiceOption = 'Kore' | 'Aoede' | 'Puck' | 'Charon';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  languageDetected?: string;
  sources?: Array<{ title: string; uri: string }>;
  audioBase64?: string;
  isPlaying?: boolean;
}

export interface AppSettings {
  gender: VoiceGender;
  voice: VoiceOption;
  handsFree: boolean;
}

export interface QuotaDetails {
  model: string;
  rateLimits: string;
  costNotice: string;
}
