export type AspectRatio = "1:1" | "16:9" | "9:16" | "4:3" | "3:4";

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  compiledPrompt?: string;
  aspectRatio: AspectRatio;
  style: string;
  timestamp: number;
  isFavorite?: boolean;
  negativePrompt?: string;
  model?: string;
  isImg2Img?: boolean;
  isFallback?: boolean;
}

export interface StylePreset {
  id: string;
  name: string;
  description: string;
  promptSuffix: string;
  previewGradient: string;
  iconName: string;
  badgeColor: string;
}

export interface SamplePrompt {
  id: string;
  title: string;
  category: "Cinematic" | "Anime" | "3D Art" | "Sci-Fi" | "Fantasy" | "Photorealistic" | "Abstract" | "Biology" | "Genetics" | "Microscopy" | "Anatomy";
  prompt: string;
  styleId: string;
  aspectRatio: AspectRatio;
  tags: string[];
}

export type ActiveTab = "studio" | "mindmap" | "editor" | "gallery" | "inspiration";

export interface MindMapNode {
  id: string;
  title: string;
  summary: string;
  category?: string;
  imagePrompt: string;
  imageUrl?: string;
  imageObj?: GeneratedImage;
  isMainRoot?: boolean;
  parentId?: string | null;
  childrenIds?: string[];
}

export interface MindMapData {
  id: string;
  topicTitle: string;
  originalParagraph: string;
  rootNodeId: string;
  nodes: MindMapNode[];
  createdAt: number;
}
