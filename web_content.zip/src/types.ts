/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Status types
export type TaskStatus = 'done' | 'not_done' | 'wont_do' | 'postponed';

export type RepeatType = 'daily' | 'weekly' | 'interval' | 'custom';

export interface RepeatConfig {
  type: RepeatType;
  daysOfWeek?: number[]; // 0=Sun, 1=Mon, ..., 6=Sat
  intervalDays?: number; // e.g. 3
  startDate?: string;    // YYYY-MM-DD
  dates?: string[];      // YYYY-MM-DD[]
}

export interface ToDoTask {
  id: string;
  groupId: string;
  name: string;
  details?: string;
  repeat: RepeatConfig;
  createdAt: string; // YYYY-MM-DD
  order: number;
  postponedDates?: Record<string, string>; // fromDate -> toDate (YYYY-MM-DD)
  reports?: Record<string, TaskStatus>;    // date -> status
}

export interface ToDoGroup {
  id: string;
  name: string;
  details?: string;
  order: number;
  tasks: ToDoTask[];
}

export interface WorkTask {
  id: string;
  groupId: string;
  title: string;
  details?: string;
  completed: boolean;
  order: number;
}

export interface WorkGroup {
  id: string;
  title: string;
  order: number;
  tasks: WorkTask[];
}

export interface AppData {
  workGroups: WorkGroup[];
  todoGroups: ToDoGroup[];
  todayCustomOrder: string[]; // task IDs for custom ordering in Today tab
}
