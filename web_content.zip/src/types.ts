export type MatchStatus = 'live' | 'upcoming' | 'finished';

export interface StreamServer {
  id: string;
  name: string;
  quality: string;
  url: string;
  isBackup?: boolean;
}

export interface MatchEvent {
  id: string;
  minute: number;
  type: 'goal' | 'yellow_card' | 'red_card' | 'substitution' | 'penalty_scored' | 'penalty_missed' | 'var';
  team: 'home' | 'away';
  player: string;
  assistPlayer?: string;
  description?: string;
}

export interface Player {
  number: number;
  name: string;
  position: 'GK' | 'DF' | 'MF' | 'FW';
  isCaptain?: boolean;
  yellowCard?: boolean;
  goals?: number;
}

export interface TeamLineup {
  formation: string;
  coach: string;
  startingXI: Player[];
  substitutes: Player[];
}

export interface MatchStats {
  possession: [number, number]; // [home%, away%]
  shots: [number, number];
  shotsOnTarget: [number, number];
  corners: [number, number];
  fouls: [number, number];
  yellowCards: [number, number];
  redCards: [number, number];
  offsides: [number, number];
  passesAccuracy: [number, number];
}

export interface Match {
  id: string;
  homeTeam: {
    name: string;
    shortName: string;
    logo: string;
    country: string;
  };
  awayTeam: {
    name: string;
    shortName: string;
    logo: string;
    country: string;
  };
  tournament: {
    name: string;
    logo: string;
    category: string;
  };
  status: MatchStatus;
  minute?: number;
  homeScore?: number;
  awayScore?: number;
  date: string;
  time: string; // e.g. "21:00"
  dayGroup: 'today' | 'tomorrow' | 'yesterday';
  channel: string;
  commentator: string;
  stadium: string;
  round: string;
  videoUrl: string;
  servers: StreamServer[];
  events: MatchEvent[];
  stats: MatchStats;
  lineup: {
    home: TeamLineup;
    away: TeamLineup;
  };
}

export interface SportsChannel {
  id: string;
  name: string;
  category: 'beIN Sports' | 'SSC' | 'Alkass' | 'AD Sports' | 'Open';
  logo: string;
  quality: '4K' | 'FHD' | 'HD';
  currentShow: string;
  viewers: string;
  videoUrl: string;
  servers: StreamServer[];
}

export interface ChatMessage {
  id: string;
  user: string;
  avatar: string;
  text: string;
  time: string;
  teamTag?: string;
  isSuperfan?: boolean;
  likes: number;
}

export interface HighlightVideo {
  id: string;
  title: string;
  tournament: string;
  duration: string;
  date: string;
  views: string;
  thumbnail: string;
  videoUrl: string;
  goalsSummary: string;
}
