import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { Network } from '@capacitor/network';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { SplashScreen } from '@capacitor/splash-screen';

const native = Capacitor.isNativePlatform();

export function tap() {
  if (native) Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
}

export async function initNative({ showMessage, onNetwork, onBack }) {
  if (!native) return;
  try {
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#4f46e5' });
    await StatusBar.setOverlaysWebView({ overlay: false });
  } catch (e) {}

  try {
    const s = await Network.getStatus();
    onNetwork(s.connected);
    Network.addListener('networkStatusChange', st => onNetwork(st.connected));
  } catch (e) {}

  // زر الرجوع: يغلق النافذة/التعديل أولاً، ثم ضغطتان للخروج
  let lastBack = 0;
  App.addListener('backButton', () => {
    if (onBack()) return;
    if (Date.now() - lastBack < 2000) { App.exitApp(); return; }
    lastBack = Date.now();
    showMessage('اضغط مرة أخرى للخروج', 'success');
  });

  // عند العودة للتطبيق: أعد فحص الاتصال
  App.addListener('resume', async () => {
    try { onNetwork((await Network.getStatus()).connected); } catch (e) {}
  });

  SplashScreen.hide().catch(() => {});
}
