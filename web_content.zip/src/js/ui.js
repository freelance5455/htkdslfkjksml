import { gameState } from './state.js';

const scoreDOM = document.getElementById('score');
const cpsDOM = document.getElementById('cps');
const costClickDOM = document.getElementById('cost-click');
const costPassiveDOM = document.getElementById('cost-passive');

// Обновить все цифры на экране
export function render() {
    scoreDOM.textContent = gameState.score;
    cpsDOM.textContent = gameState.passiveIncome;
    costClickDOM.textContent = gameState.costs.click;
    costPassiveDOM.textContent = gameState.costs.passive;
}

// СОЗДАНИЕ ВСПЛЫВАЮЩЕЙ ЦИФРЫ (Объявлена один раз!)
export function spawnClickNumber(x, y, value) {
    const numEl = document.createElement('div');
    numEl.classList.add('click-number');
    numEl.textContent = `+${value}`;
    
    numEl.style.left = `${x}px`;
    numEl.style.top = `${y}px`;
    
    document.body.appendChild(numEl);
    
    setTimeout(() => {
        numEl.remove();
    }, 800);
}
