import { gameState } from './state.js';
import { render } from './ui.js';

export function buyUpgrade(type) {
    if (type === 'click' && gameState.score >= gameState.costs.click) {
        gameState.score -= gameState.costs.click;
        gameState.clickPower += 1;
        gameState.costs.click = Math.round(gameState.costs.click * 1.5);
        render();
    } 
    else if (type === 'passive' && gameState.score >= gameState.costs.passive) {
        gameState.score -= gameState.costs.passive;
        gameState.passiveIncome += 1;
        gameState.costs.passive = Math.round(gameState.costs.passive * 1.6);
        render();
    } else {
        console.log('Недостаточно монет для покупки:', type);
    }
}
