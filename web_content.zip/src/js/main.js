import { gameState } from './state.js';
import { render, spawnClickNumber } from './ui.js';
import { buyUpgrade } from './shop.js';
import { saveGame, loadGame } from './storage.js';

// Элементы управления
const clickBtn = document.getElementById('click-btn');
const upClickBtn = document.getElementById('up-click');
const upPassiveBtn = document.getElementById('up-passive');

// Загрузка сохранения
loadGame();

// Клик по главной кнопке
clickBtn.addEventListener('click', (event) => {
    gameState.score += gameState.clickPower;
    render();
    
    // Если кликают на мобилке, координаты берем из первого тача, иначе из мыши
    let clientX = event.clientX;
    let clientY = event.clientY;
    
    if (event.changedTouches && event.changedTouches.length > 0) {
        clientX = event.changedTouches[0].clientX;
        clientY = event.changedTouches[0].clientY;
    }
    
    // Запасной план: если координаты равны 0 (баг эмулятора), бьем в центр экрана
    const x = clientX || window.innerWidth / 2;
    const y = clientY || window.innerHeight / 2;
    
    spawnClickNumber(x, y, gameState.clickPower);
});

// Нажатия на кнопки магазина
upClickBtn.addEventListener('click', () => {
    buyUpgrade('click');
    saveGame();
});

upPassiveBtn.addEventListener('click', () => {
    buyUpgrade('passive');
    saveGame();
});

// Игровой цикл пассивного дохода
setInterval(() => {
    gameState.score += gameState.passiveIncome;
    render();
}, 1000);

// Цикл автосохранения (каждые 5 секунд)
setInterval(() => {
    saveGame();
}, 5000);

// Стартовый рендер
render();
