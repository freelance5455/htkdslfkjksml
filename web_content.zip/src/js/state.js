export const gameState = {
    score: 0,
    clickPower: 1,
    passiveIncome: 0,
    
    // Цены на улучшения
    costs: {
        click: 10,
        passive: 50
    }
};
