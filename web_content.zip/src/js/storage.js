import { gameState } from './state.js';

// Уникальный ключ, под которым игра будет лежать в памяти браузера
const SAVE_KEY = 'root_clicker_save_v1';

// ================= ФУНКЦИЯ СОХРАНЕНИЯ =================
export function saveGame() {
    try {
        // Переводим наш объект gameState в строку, так как localStorage умеет хранить только текст
        const jsonString = JSON.stringify(gameState);
        localStorage.setItem(SAVE_KEY, jsonString);
        console.log('Игра успешно сохранена автоматически!');
    } catch (error) {
        console.error('Не удалось сохранить игру:', error);
    }
}

// ================= ФУНКЦИЯ ЗАГРУЗКИ =================
export function loadGame() {
    try {
        const rawData = localStorage.getItem(SAVE_KEY);
        
        // Если сохранение найдено, парсим строку обратно в объект и обновляем gameState
        if (rawData) {
            const savedState = JSON.parse(rawData);
            
            // Заменяем значения в gameState на сохраненные
            Object.assign(gameState, savedState);
            console.log('Прогресс успешно загружен!');
            return true;
        }
    } catch (error) {
        console.error('Ошибка при загрузке сохранения:', error);
    }
    return false; // Если сохранения нет или произошла ошибка
}

// ================= ФУНКЦИЯ СБРОСА (НА ВСЯКИЙ СЛУЧАЙ) =================
export function resetGame() {
    localStorage.removeItem(SAVE_KEY);
    location.reload(); // Перезагружаем страницу, чтобы обнулить state
}
