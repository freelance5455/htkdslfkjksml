const SOUND_KEY='ramenShiftSoundEnabled';
function readEnabled(){try{return localStorage.getItem(SOUND_KEY)!=='false';}catch{return true;}}
function saveEnabled(value){try{localStorage.setItem(SOUND_KEY,String(value));}catch{}}

export function createAudio(){
  let enabled=readEnabled(),context=null,master=null,playing=false,paused=true,ambience=[],musicTimer=0,chirpTimer=0,motifIndex=0;
  const motif=[146.83,174.61,164.81,110.00,130.81,98.00];
  function ensureContext(){
    if(context)return true;
    const AudioContextClass=globalThis.AudioContext||globalThis.webkitAudioContext;if(!AudioContextClass)return false;
    try{context=new AudioContextClass();master=context.createGain();master.gain.value=0;master.connect(context.destination);return true;}catch{return false;}
  }
  function fadeMaster(){if(!master||!context)return;const t=context.currentTime;master.gain.cancelScheduledValues(t);master.gain.setTargetAtTime(enabled&&playing&&!paused ? 0.38 : 0,t,.18);}
  function tone(frequency,duration=.2,type='sine',volume=.06,endFrequency=null,filterHz=2400){
    if(!context||!master||!enabled||paused)return;
    try{
      const t=context.currentTime,osc=context.createOscillator(),gain=context.createGain(),filter=context.createBiquadFilter();osc.type=type;osc.frequency.setValueAtTime(frequency,t);if(endFrequency!==null)osc.frequency.exponentialRampToValueAtTime(Math.max(1,endFrequency),t+duration);
      filter.type='lowpass';filter.frequency.setValueAtTime(filterHz,t);gain.gain.setValueAtTime(.0001,t);gain.gain.linearRampToValueAtTime(volume,t+Math.min(.035,duration*.2));gain.gain.exponentialRampToValueAtTime(.0001,t+duration);osc.connect(filter);filter.connect(gain);gain.connect(master);osc.start(t);osc.stop(t+duration+.025);osc.onended=()=>{osc.disconnect();filter.disconnect();gain.disconnect();};
    }catch{/* Audio is an enhancement; unsupported devices continue silently. */}
  }
  function stopAmbience(){
    clearTimeout(musicTimer);clearTimeout(chirpTimer);musicTimer=chirpTimer=0;
    for(const node of ambience){try{node.stop?.();}catch{}try{node.disconnect?.();}catch{}}
    ambience=[];
  }
  function scheduleMusic(){
    if(!enabled||!playing||paused)return;
    tone(motif[motifIndex++%motif.length],1.7,'triangle',.055,null,900);
    musicTimer=setTimeout(scheduleMusic,4200);
  }
  function scheduleChirp(){
    if(!enabled||!playing||paused)return;
    const base=1550+Math.random()*500;tone(base,.11,'sine',.027,base*1.35,3200);tone(base*1.35,.13,'sine',.018,base*1.62,3600);
    chirpTimer=setTimeout(scheduleChirp,4200+Math.random()*4500);
  }
  function startAmbience(){
    if(!context||!master||!enabled||!playing||paused||ambience.length)return;
    try{
      const size=Math.max(2048,Math.floor(context.sampleRate*.75)),buffer=context.createBuffer(1,size,context.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<size;i++)data[i]=(Math.random()*2-1)*.65;
      const wind=context.createBufferSource(),lowpass=context.createBiquadFilter(),windGain=context.createGain();wind.buffer=buffer;wind.loop=true;lowpass.type='lowpass';lowpass.frequency.value=360;windGain.gain.value=.045;wind.connect(lowpass);lowpass.connect(windGain);windGain.connect(master);wind.start();ambience.push(wind,lowpass,windGain);
      for(const [hz,volume]of[[49,.012],[73.5,.008],[98,.004]]){const osc=context.createOscillator(),gain=context.createGain();osc.type='sine';osc.frequency.value=hz;gain.gain.value=volume;osc.connect(gain);gain.connect(master);osc.start();ambience.push(osc,gain);}
      motifIndex=0;scheduleMusic();scheduleChirp();
    }catch{stopAmbience();}
  }
  function start(){playing=true;paused=false;if(!ensureContext())return;fadeMaster();context.resume?.().catch?.(()=>{});startAmbience();}
  function setPaused(value){paused=Boolean(value);if(paused)stopAmbience();else{if(context?.state==='suspended')context.resume?.().catch?.(()=>{});startAmbience();}fadeMaster();}
  function setEnabled(value){enabled=Boolean(value);saveEnabled(enabled);if(enabled&&playing&&!paused){if(!ensureContext())return enabled;context.resume?.().catch?.(()=>{});startAmbience();}else if(!enabled)stopAmbience();fadeMaster();return enabled;}
  function toggle(){return setEnabled(!enabled);}
  function uiClick(){tone(740,.045,'sine',.035,610,1800);}
  function computer(){tone(520,.07,'sine',.04,690,1800);}
  function carArrival(){tone(112,1.25,'sawtooth',.075,48,320);tone(58,.85,'sine',.035,42,180);}
  function horn(){tone(392,.34,'sawtooth',.085,370,1100);tone(494,.32,'sawtooth',.075,466,1300);}
  function watcher(){tone(66,1.1,'sine',.055,48,250);tone(188,.38,'triangle',.018,130,700);}
  function scare(reduced=false){const level=reduced?.55:1;tone(115,.82,'sawtooth',.15*level,39,520);tone(57,.9,'sine',.12*level,31,240);tone(880,.18,'sine',.035*level,260,2500);}
  function wrong(){tone(145,.65,'triangle',.09,83,550);tone(117,.72,'sine',.075,59,380);}
  function correct(){tone(523.25,.18,'sine',.055,null,1600);setTimeout(()=>tone(659.25,.24,'sine',.05,null,1800),100);}
  function cook(){tone(125,.48,'triangle',.045,175,550);tone(310,.16,'sine',.024,420,1100);}
  function serve(){tone(660,.12,'sine',.045,null,2200);tone(880,.18,'sine',.04,null,2400);}
  function order(){tone(520,.08,'sine',.035,640,1500);}
  function sleep(){tone(196,1.2,'sine',.05,73,650);}
  return{start,setPaused,setEnabled,toggle,get enabled(){return enabled;},uiClick,computer,carArrival,horn,watcher,scare,wrong,correct,cook,serve,order,sleep,dispose(){playing=false;stopAmbience();if(context){context.close?.().catch?.(()=>{});context=null;master=null;}}};
}
