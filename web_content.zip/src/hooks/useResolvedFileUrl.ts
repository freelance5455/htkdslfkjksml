import { useEffect, useState } from 'react';
import type { WhatsNewMediaType } from '../types';
import { extractIdbKey, getFileBlobRecord, inferMimeFromFilename } from '../lib/fileDb';

export function useResolvedFileUrl(
  fileUrl: string,
  expectedMediaType?: WhatsNewMediaType
) {
  const [resolvedUrl, setResolvedUrl] = useState<string>(() =>
    fileUrl && !fileUrl.startsWith('idb://') ? fileUrl : ''
  );
  const [resolvedBlob, setResolvedBlob] = useState<Blob | null>(null);
  const [loading, setLoading] = useState<boolean>(() =>
    Boolean(fileUrl && fileUrl.startsWith('idb://'))
  );
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    let createdObjectUrl: string | null = null;

    if (!fileUrl) {
      setResolvedUrl('');
      setResolvedBlob(null);
      setLoading(false);
      setError(null);
      return;
    }

    const idbKey = extractIdbKey(fileUrl);
    if (!idbKey) {
      setResolvedUrl(fileUrl);
      setResolvedBlob(null);
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);
    setResolvedBlob(null);

    getFileBlobRecord(idbKey)
      .then((record) => {
        if (cancelled) return;
        if (!record) {
          setResolvedUrl('');
          setResolvedBlob(null);
          setError('الملف غير موجود في ذاكرة المتصفح.');
          return;
        }

        const isPdf =
          expectedMediaType === 'pdf' ||
          record.fileName.toLowerCase().endsWith('.pdf') ||
          record.mimeType === 'application/pdf';

        const targetMime = isPdf
          ? 'application/pdf'
          : inferMimeFromFilename(record.fileName, record.mimeType || record.blob.type);

        const typedBlob =
          record.blob.type === targetMime
            ? record.blob
            : new Blob([record.blob], { type: targetMime });

        createdObjectUrl = URL.createObjectURL(typedBlob);
        setResolvedBlob(typedBlob);
        setResolvedUrl(createdObjectUrl);
      })
      .catch((err) => {
        if (cancelled) return;
        setResolvedUrl('');
        setResolvedBlob(null);
        setError(err instanceof Error ? err.message : 'تعذر تحميل الملف من ذاكرة المتصفح.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
      if (createdObjectUrl) {
        URL.revokeObjectURL(createdObjectUrl);
      }
    };
  }, [fileUrl, expectedMediaType]);

  return { resolvedUrl, blob: resolvedBlob, loading, error };
}
