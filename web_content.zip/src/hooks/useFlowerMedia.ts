import { useEffect, useState } from "react";

export interface FlowerMediaResult {
  imageUrl: string | null;
  fullImageUrl: string | null;
  extract: string | null;
  wikiTitle: string | null;
  sourceUrl: string | null;
}

const clientMediaCache = new Map<string, FlowerMediaResult>();
const inFlightRequests = new Map<string, Promise<FlowerMediaResult>>();

export async function fetchFlowerMedia(
  wikiQuery: string,
  latinName: string,
  enName: string
): Promise<FlowerMediaResult> {
  const key = `${wikiQuery}|${latinName}|${enName}`.toLowerCase();
  const cached = clientMediaCache.get(key);
  if (cached) return cached;

  const existing = inFlightRequests.get(key);
  if (existing) return existing;

  const promise = (async (): Promise<FlowerMediaResult> => {
    try {
      const params = new URLSearchParams({
        q: wikiQuery,
        latin: latinName,
        en: enName,
      });
      const res = await fetch(`/api/flower-media?${params.toString()}`);
      if (!res.ok) {
        return {
          imageUrl: null,
          fullImageUrl: null,
          extract: null,
          wikiTitle: null,
          sourceUrl: null,
        };
      }
      const data = (await res.json()) as FlowerMediaResult;
      clientMediaCache.set(key, data);
      return data;
    } catch {
      return {
        imageUrl: null,
        fullImageUrl: null,
        extract: null,
        wikiTitle: null,
        sourceUrl: null,
      };
    } finally {
      inFlightRequests.delete(key);
    }
  })();

  inFlightRequests.set(key, promise);
  return promise;
}

export function useFlowerMedia(
  wikiQuery: string,
  latinName: string,
  enName: string,
  enabled = true
): { media: FlowerMediaResult | null; loading: boolean } {
  const key = `${wikiQuery}|${latinName}|${enName}`.toLowerCase();
  const [media, setMedia] = useState<FlowerMediaResult | null>(
    () => clientMediaCache.get(key) ?? null
  );
  const [loading, setLoading] = useState<boolean>(
    () => enabled && !clientMediaCache.has(key)
  );

  useEffect(() => {
    if (!enabled) return;
    const cached = clientMediaCache.get(key);
    if (cached) {
      setMedia(cached);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    fetchFlowerMedia(wikiQuery, latinName, enName).then((res) => {
      if (!cancelled) {
        setMedia(res);
        setLoading(false);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [key, wikiQuery, latinName, enName, enabled]);

  return { media, loading };
}
