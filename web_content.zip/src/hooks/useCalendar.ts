import { useState, useCallback } from "react";
import type { CalendarEvent } from "@/types";
import { getCalendarEvents, saveCalendarEvent, deleteCalendarEvent as deleteEventStorage } from "@/lib/storage";
import { generateId } from "@/lib/utils";

export function useCalendar() {
  const [events, setEvents] = useState<CalendarEvent[]>(getCalendarEvents);

  const addEvent = useCallback((event: Omit<CalendarEvent, "id">) => {
    const newEvent: CalendarEvent = { ...event, id: generateId() };
    saveCalendarEvent(newEvent);
    setEvents(getCalendarEvents());
    return newEvent;
  }, []);

  const updateEvent = useCallback((event: CalendarEvent) => {
    saveCalendarEvent(event);
    setEvents(getCalendarEvents());
  }, []);

  const deleteEvent = useCallback((id: string) => {
    deleteEventStorage(id);
    setEvents(getCalendarEvents());
  }, []);

  return { events, addEvent, updateEvent, deleteEvent };
}
