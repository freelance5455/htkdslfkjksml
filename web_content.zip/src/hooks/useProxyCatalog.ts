import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { DEFAULT_SETTINGS, PROXY_SOURCES } from "../data/sources";
import { mergeProxies, parseProxyInput, parseSourcePayload, scoreProxy } from "../lib/proxy";
import type { AppSettings, CatalogCache, LiveCheck, ProxyRecord, SourceState } from "../types";
import { useLocalStorage } from "./useLocalStorage";

const CACHE_KEY = "mt-radar-catalog-v1";
const MANUAL_KEY = "mt-radar-manual-v1";
const SETTINGS_KEY = "mt-radar-settings-v1";

function readCache(): CatalogCache | null {
  try {
    const parsed = JSON.parse(localStorage.getItem(CACHE_KEY) ?? "null") as CatalogCache | null;
    return parsed?.version === 1 ? parsed : null;
  } catch {
    return null;
  }
}

async function fetchJson(url: string, timeout: number, parentSignal?: AbortSignal) {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeout);
  const abort = () => controller.abort();
  parentSignal?.addEventListener("abort", abort, { once: true });
  try {
    const response = await fetch(url, { signal: controller.signal, cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } finally {
    window.clearTimeout(timer);
    parentSignal?.removeEventListener("abort", abort);
  }
}

function checkerEndpoint(template: string, proxy: ProxyRecord) {
  const replacements: Record<string, string> = {
    server: encodeURIComponent(proxy.server),
    port: String(proxy.port),
    secret: encodeURIComponent(proxy.secret),
  };
  if (template.includes("{server}")) {
    return template.replace(/\{(server|port|secret)\}/g, (_, key: string) => replacements[key]);
  }
  const url = new URL(template);
  url.searchParams.set("server", proxy.server);
  url.searchParams.set("port", String(proxy.port));
  url.searchParams.set("secret", proxy.secret);
  return url.toString();
}

export function useProxyCatalog() {
  const initialCache = useMemo(readCache, []);
  const [settings, setSettings] = useLocalStorage<AppSettings>(SETTINGS_KEY, DEFAULT_SETTINGS);
  const [groups, setGroups] = useState<Record<string, ProxyRecord[]>>(initialCache?.records ?? {});
  const [states, setStates] = useState<Record<string, SourceState>>(() => initialCache?.states ?? Object.fromEntries(
    PROXY_SOURCES.map((source) => [source.id, { status: "idle", count: 0, updated: null, fetchedAt: null, duration: null }]),
  ));
  const [manual, setManual] = useLocalStorage<ProxyRecord[]>(MANUAL_KEY, []);
  const [liveResults, setLiveResults] = useState<Record<string, LiveCheck>>({});
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<number | null>(initialCache?.savedAt ?? null);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const groupsRef = useRef(groups);
  const abortRef = useRef<AbortController | null>(null);
  const refreshRunning = useRef(false);

  useEffect(() => { groupsRef.current = groups; }, [groups]);

  const refresh = useCallback(async () => {
    if (refreshRunning.current) return;
    const enabled = settings.enabledSources.filter((id) => PROXY_SOURCES.some((source) => source.id === id));
    if (!enabled.length) return;
    refreshRunning.current = true;
    const controller = new AbortController();
    abortRef.current = controller;
    setIsRefreshing(true);
    setProgress({ done: 0, total: enabled.length });
    let successfulSources = 0;

    await Promise.all(enabled.map(async (id) => {
      const source = PROXY_SOURCES.find((item) => item.id === id)!;
      const sourceStarted = performance.now();
      setStates((previous) => ({
        ...previous,
        [id]: { ...previous[id], status: "loading", message: undefined },
      }));
      try {
        const payload = await fetchJson(source.url, 14_000, controller.signal);
        const parsed = parseSourcePayload(payload, source);
        successfulSources += 1;
        setGroups((previous) => ({ ...previous, [id]: parsed.proxies }));
        setStates((previous) => ({
          ...previous,
          [id]: {
            status: "success",
            count: parsed.proxies.length,
            updated: parsed.updated,
            fetchedAt: Date.now(),
            duration: Math.round(performance.now() - sourceStarted),
            message: undefined,
          },
        }));
      } catch (error) {
        if (controller.signal.aborted) return;
        const cached = groupsRef.current[id] ?? [];
        const message = error instanceof DOMException && error.name === "AbortError"
          ? "Источник не ответил за 14 секунд."
          : error instanceof TypeError
            ? "Сеть или CORS не позволили загрузить источник."
            : error instanceof Error ? error.message : "Не удалось загрузить источник.";
        setStates((previous) => ({
          ...previous,
          [id]: {
            ...previous[id],
            status: cached.length ? "cached" : "error",
            count: cached.length,
            fetchedAt: Date.now(),
            duration: Math.round(performance.now() - sourceStarted),
            message,
          },
        }));
      } finally {
        if (!controller.signal.aborted) setProgress((previous) => ({ ...previous, done: previous.done + 1 }));
      }
    }));

    // A cancelled or superseded request must not clear a newer request's state.
    if (abortRef.current !== controller) return;
    if (!controller.signal.aborted && successfulSources > 0) setLastRefresh(Date.now());
    setIsRefreshing(false);
    refreshRunning.current = false;
    abortRef.current = null;
  }, [settings.enabledSources]);

  const cancelRefresh = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    refreshRunning.current = false;
    setIsRefreshing(false);
    setStates((previous) => Object.fromEntries(Object.entries(previous).map(([id, state]) => [id, state.status === "loading" ? {
      ...state,
      status: state.count > 0 ? "cached" : "idle",
      message: "Загрузка остановлена пользователем.",
    } : state])));
  }, []);

  useEffect(() => {
    void refresh();
    return () => {
      abortRef.current?.abort();
      abortRef.current = null;
      refreshRunning.current = false;
    };
    // Source selection is the refresh trigger; refresh changes only with it.
  }, [refresh]);

  useEffect(() => {
    if (!settings.autoRefresh || settings.refreshMinutes <= 0) return;
    const timer = window.setInterval(() => void refresh(), settings.refreshMinutes * 60_000);
    return () => window.clearInterval(timer);
  }, [refresh, settings.autoRefresh, settings.refreshMinutes]);

  useEffect(() => {
    const hasRecords = Object.values(groups).some((records) => records.length > 0);
    if (isRefreshing || (!lastRefresh && !hasRecords)) return;
    const cache: CatalogCache = { version: 1, savedAt: lastRefresh ?? Date.now(), records: groups, states };
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    } catch {
      // Large catalogs can exceed private-mode quotas; live state still works.
    }
  }, [groups, states, isRefreshing, lastRefresh]);

  const proxies = useMemo(() => {
    const enabledGroups = settings.enabledSources.map((id) => groups[id] ?? []);
    const merged = mergeProxies([...enabledGroups, manual]);
    return merged.map((proxy) => liveResults[proxy.id] ? { ...proxy, live: liveResults[proxy.id] } : proxy);
  }, [groups, manual, settings.enabledSources, liveResults]);

  const addManual = useCallback((input: string) => {
    const parsed = parseProxyInput(input);
    if (!parsed) return { ok: false as const, error: "Не удалось распознать ссылку. Нужны server, port и hex-secret." };
    const existing = proxies.find((proxy) => proxy.id === parsed.id);
    if (existing) return { ok: true as const, proxy: existing, duplicate: true };
    const record = { ...parsed, sourceIds: ["manual"], feedNames: [] };
    const withScore = { ...record, score: scoreProxy(record) };
    setManual((previous) => [withScore, ...previous]);
    return { ok: true as const, proxy: withScore, duplicate: false };
  }, [proxies, setManual]);

  const removeManual = useCallback((id: string) => {
    setManual((previous) => previous.filter((proxy) => proxy.id !== id));
  }, [setManual]);

  const checkOne = useCallback(async (proxy: ProxyRecord) => {
    if (!settings.checkerUrl.trim()) return { ok: false as const, error: "Сначала укажите URL checker API в настройках." };
    setLiveResults((previous) => ({
      ...previous,
      [proxy.id]: { state: "checking", checkedAt: Date.now(), latency: null },
    }));
    try {
      const endpoint = checkerEndpoint(settings.checkerUrl.trim(), proxy);
      const result = await fetchJson(endpoint, 10_000) as Record<string, unknown>;
      const status = String(result.status ?? "").toLowerCase();
      const explicitOnline = typeof result.online === "boolean" ? result.online
        : typeof result.ok === "boolean" ? result.ok
          : ["up", "online", "reachable", "handshake_ok"].includes(status) ? true
            : ["down", "offline", "timeout", "unreachable"].includes(status) ? false : null;
      if (explicitOnline === null) throw new Error("API не вернул online/ok или понятный status.");
      const latencyValue = Number(result.latency_ms ?? result.rtt_ms ?? result.ping_ms);
      const live: LiveCheck = {
        state: explicitOnline ? "online" : "offline",
        checkedAt: Date.now(),
        latency: Number.isFinite(latencyValue) && latencyValue >= 0 ? Math.round(latencyValue) : null,
        message: typeof result.message === "string" ? result.message.slice(0, 180) : undefined,
      };
      setLiveResults((previous) => ({ ...previous, [proxy.id]: live }));
      return { ok: true as const, result: live };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Ошибка checker API";
      const live: LiveCheck = { state: "error", checkedAt: Date.now(), latency: null, message };
      setLiveResults((previous) => ({ ...previous, [proxy.id]: live }));
      return { ok: false as const, error: message };
    }
  }, [settings.checkerUrl]);

  const checkMany = useCallback(async (items: ProxyRecord[]) => {
    const queue = [...items];
    const workers = Array.from({ length: Math.min(3, queue.length) }, async () => {
      while (queue.length) {
        const proxy = queue.shift();
        if (proxy) await checkOne(proxy);
      }
    });
    await Promise.all(workers);
  }, [checkOne]);

  const hasCache = Object.values(groups).some((records) => records.length > 0);

  return {
    proxies,
    settings,
    setSettings,
    states,
    isRefreshing,
    lastRefresh,
    progress,
    refresh,
    cancelRefresh,
    addManual,
    removeManual,
    checkOne,
    checkMany,
    hasCache,
  };
}
