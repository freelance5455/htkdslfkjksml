import { useEffect, type RefObject } from "react";

export function useSentinel(
  ref: RefObject<Element | null>,
  enabled: boolean,
  loadMore: () => void,
  rootMargin = "720px",
) {
  useEffect(() => {
    const node = ref.current;
    if (!node || !enabled) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) loadMore();
      },
      { rootMargin },
    );
    io.observe(node);
    return () => io.disconnect();
  }, [enabled, loadMore, ref, rootMargin]);
}
