import { useState, useEffect, useRef, useCallback } from 'react';
import {
  DailySchedule,
  PrayerSettings,
  PrayerName,
  ActiveAlarmState,
  NextPrayerInfo,
  AdhanVoice,
  AlarmTone,
} from '../types/prayer';
import {
  getScheduleForDate,
  calculateAlarmTime,
  getNextPrayerInfo,
  calculateNightTimings,
} from '../utils/prayerCalculator';
import { soundEngine } from '../services/soundEngine';
import { NotificationService } from '../services/notificationService';

const DEFAULT_SETTINGS: PrayerSettings = {
  timeFormat: '12h',
  alarmDelayMinutes: 10, // Default 10 minutes delay after Adhan
  adhanVoice: 'makkah',
  alarmTone: 'sacred_bell',
  volume: 85,
  timeZone: 'Asia/Dhaka',
  adhanEnabled: {
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  },
  alarmEnabled: {
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  },
};

const PRAYER_LABELS: Record<PrayerName, string> = {
  fajr: 'Fajr (ফজর)',
  dhuhr: 'Dhuhr (যোহর)',
  asr: 'Asr (আসর)',
  maghrib: 'Maghrib (মাগরিব)',
  isha: 'Isha (এশা)',
};

export function usePrayerScheduler() {
  const [settings, setSettings] = useState<PrayerSettings>(() => {
    try {
      const saved = localStorage.getItem('salat_sathi_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_SETTINGS;
  });

  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [activeDate, setActiveDate] = useState<Date>(new Date());
  const [activeAlarm, setActiveAlarm] = useState<ActiveAlarmState | null>(null);
  const [isPlayingSound, setIsPlayingSound] = useState<boolean>(false);
  const soundStopHandleRef = useRef<(() => void) | null>(null);
  const triggeredKeysRef = useRef<Set<string>>(new Set());

  // Save settings
  const updateSettings = useCallback((newPartial: Partial<PrayerSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newPartial };
      try {
        localStorage.setItem('salat_sathi_settings', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  const toggleAdhan = useCallback((name: PrayerName) => {
    setSettings(prev => {
      const updated = {
        ...prev,
        adhanEnabled: {
          ...prev.adhanEnabled,
          [name]: !prev.adhanEnabled[name],
        },
      };
      try {
        localStorage.setItem('salat_sathi_settings', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  const toggleAlarm = useCallback((name: PrayerName) => {
    setSettings(prev => {
      const updated = {
        ...prev,
        alarmEnabled: {
          ...prev.alarmEnabled,
          [name]: !prev.alarmEnabled[name],
        },
      };
      try {
        localStorage.setItem('salat_sathi_settings', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  // Compute schedules
  const todaySchedule = getScheduleForDate(activeDate);
  const tomorrowDate = new Date(activeDate);
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowSchedule = getScheduleForDate(tomorrowDate);
  const nightTimings = calculateNightTimings(todaySchedule, tomorrowSchedule);

  // Compute next prayer info based on real clock
  const nextPrayerInfo: NextPrayerInfo = getNextPrayerInfo(
    currentDate,
    settings,
    getScheduleForDate(currentDate),
    getScheduleForDate(new Date(currentDate.getTime() + 86400000))
  );

  // Dismiss currently ringing alarm or adhan
  const dismissActiveAlarm = useCallback(() => {
    soundEngine.stopCurrentSound();
    if (soundStopHandleRef.current) {
      soundStopHandleRef.current();
      soundStopHandleRef.current = null;
    }
    setIsPlayingSound(false);
    setActiveAlarm(null);
    NotificationService.releaseWakeLock();
  }, []);

  // Snooze alarm by X minutes
  const snoozeActiveAlarm = useCallback((minutes: number) => {
    dismissActiveAlarm();
    setTimeout(() => {
      triggerAlarmSound('salah_alarm', 'dhuhr', `Snoozed Prayer Reminder (${minutes}m)`);
    }, minutes * 60 * 1000);
  }, [dismissActiveAlarm]);

  // Play Adhan sound and manage active state
  const triggerAdhanSound = useCallback((prayer: PrayerName) => {
    dismissActiveAlarm();
    NotificationService.acquireWakeLock();
    setIsPlayingSound(true);
    setActiveAlarm({
      type: 'adhan',
      prayerName: prayer,
      prayerLabel: PRAYER_LABELS[prayer],
      timeString: todaySchedule[prayer],
    });

    NotificationService.showPrayerNotification(
      `🕌 ${PRAYER_LABELS[prayer]} Adhan Time`,
      `It is now time for ${prayer.toUpperCase()} prayer. The Adhan is playing.`,
      false
    );

    const { stop } = soundEngine.playAdhan(settings.adhanVoice, settings.volume);
    soundStopHandleRef.current = stop;
  }, [dismissActiveAlarm, settings.adhanVoice, settings.volume, todaySchedule]);

  // Play Salah Alarm sound and manage active state
  const triggerAlarmSound = useCallback((type: 'salah_alarm', prayer: PrayerName, customLabel?: string) => {
    dismissActiveAlarm();
    NotificationService.acquireWakeLock();
    setIsPlayingSound(true);
    const alarmTime = calculateAlarmTime(todaySchedule[prayer], settings.alarmDelayMinutes);
    setActiveAlarm({
      type: 'salah_alarm',
      prayerName: prayer,
      prayerLabel: customLabel || PRAYER_LABELS[prayer],
      timeString: alarmTime,
      scheduledAlarmTime: alarmTime,
      delayMinutes: settings.alarmDelayMinutes,
    });

    NotificationService.showPrayerNotification(
      `⏰ Salah Reminder: ${PRAYER_LABELS[prayer]}`,
      `${settings.alarmDelayMinutes} minutes have passed since Adhan. Please perform your Salah now.`,
      true
    );

    const { stop } = soundEngine.playAlarm(settings.alarmTone, settings.volume);
    soundStopHandleRef.current = stop;
  }, [dismissActiveAlarm, settings.alarmTone, settings.volume, settings.alarmDelayMinutes, todaySchedule]);

  // Test button trigger for Adhan
  const testAdhan = useCallback((customVoice?: AdhanVoice) => {
    soundEngine.unlockAudio();
    dismissActiveAlarm();
    NotificationService.acquireWakeLock();
    setIsPlayingSound(true);
    setActiveAlarm({
      type: 'adhan',
      prayerName: 'fajr',
      prayerLabel: 'Test Adhan Audio Preview',
      timeString: 'Now',
    });
    const { stop } = soundEngine.playAdhan(customVoice || settings.adhanVoice, settings.volume);
    soundStopHandleRef.current = stop;
  }, [dismissActiveAlarm, settings.adhanVoice, settings.volume]);

  // Test button trigger for Salah Alarm
  const testAlarm = useCallback((customTone?: AlarmTone) => {
    soundEngine.unlockAudio();
    dismissActiveAlarm();
    NotificationService.acquireWakeLock();
    setIsPlayingSound(true);
    setActiveAlarm({
      type: 'salah_alarm',
      prayerName: 'dhuhr',
      prayerLabel: 'Test Salah Alarm Sound Preview',
      timeString: 'Now',
      delayMinutes: settings.alarmDelayMinutes,
    });
    const { stop } = soundEngine.playAlarm(customTone || settings.alarmTone, settings.volume);
    soundStopHandleRef.current = stop;
  }, [dismissActiveAlarm, settings.alarmTone, settings.volume, settings.alarmDelayMinutes]);

  // Real-time loop (runs every second)
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentDate(now);

      // Check current HH:MM in format 'HH:MM'
      const curH = now.getHours().toString().padStart(2, '0');
      const curM = now.getMinutes().toString().padStart(2, '0');
      const curSec = now.getSeconds();
      const currentHM = `${curH}:${curM}`;
      const dateKey = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;

      // Only check on second 0-2 of the minute to prevent multiple triggers in same minute
      if (curSec > 2) return;

      const sched = getScheduleForDate(now);
      const prayerKeys: PrayerName[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

      prayerKeys.forEach(p => {
        const adhanTime = sched[p];
        const adhanKey = `adhan-${dateKey}-${p}-${adhanTime}`;

        // 1. Check Adhan trigger
        if (adhanTime === currentHM && settings.adhanEnabled[p] && !triggeredKeysRef.current.has(adhanKey)) {
          triggeredKeysRef.current.add(adhanKey);
          triggerAdhanSound(p);
        }

        // 2. Check Salah Alarm trigger
        if (settings.alarmDelayMinutes > 0 && settings.alarmEnabled[p]) {
          const alarmTime = calculateAlarmTime(adhanTime, settings.alarmDelayMinutes);
          const alarmKey = `alarm-${dateKey}-${p}-${alarmTime}`;

          if (alarmTime === currentHM && !triggeredKeysRef.current.has(alarmKey)) {
            triggeredKeysRef.current.add(alarmKey);
            triggerAlarmSound('salah_alarm', p);
          }
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [settings, triggerAdhanSound, triggerAlarmSound]);

  return {
    currentDate,
    activeDate,
    setActiveDate,
    todaySchedule,
    tomorrowSchedule,
    nightTimings,
    nextPrayerInfo,
    settings,
    updateSettings,
    toggleAdhan,
    toggleAlarm,
    activeAlarm,
    isPlayingSound,
    dismissActiveAlarm,
    snoozeActiveAlarm,
    testAdhan,
    testAlarm,
  };
}
