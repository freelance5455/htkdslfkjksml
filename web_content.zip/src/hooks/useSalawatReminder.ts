import { useState, useEffect, useRef, useCallback } from 'react';
import { SalawatReminderSettings, SalawatSoundType } from '../types';
import { backgroundKeepAlive } from '../utils/backgroundKeepAlive';

export const DEFAULT_SALAWAT_SETTINGS: SalawatReminderSettings = {
  enabled: false,
  intervalMinutes: 15,
  soundType: 'uploaded',
  volume: 0.85,
  pauseDuringQuranRecitation: true,
  showNotification: true,
  backgroundMode: true,
  persistentNotification: true,
  keepScreenAwakeDuringReading: false,
  count: 0,
};

interface UseSalawatReminderProps {
  settings: SalawatReminderSettings;
  onUpdateSettings: (newSettings: Partial<SalawatReminderSettings>) => void;
  isQuranAudioPlaying: boolean;
}

export function useSalawatReminder({
  settings,
  onUpdateSettings,
  isQuranAudioPlaying,
}: UseSalawatReminderProps) {
  const [isBannerVisible, setIsBannerVisible] = useState(false);
  const [secondsUntilNext, setSecondsUntilNext] = useState<number>(0);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const reminderAudioRef = useRef<HTMLAudioElement | null>(null);
  const bannerTimerRef = useRef<number | null>(null);
  const lastReminderTimeRef = useRef<number>(Date.now());
  const pendingReminderAfterRecitation = useRef<boolean>(false);
  const serviceWorkerRegistrationRef = useRef<ServiceWorkerRegistration | null>(null);

  // Retrieve Service Worker registration for rich / persistent notifications on Android
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then((reg) => {
        serviceWorkerRegistrationRef.current = reg;
      }).catch((e) => {
        console.warn('SW ready error:', e);
      });

      // Listen for message from Service Worker action button click (e.g. user tapped "صلّيت على النبي")
      const handleMessage = (event: MessageEvent) => {
        if (event.data && event.data.type === 'SALAWAT_INCREMENT') {
          onUpdateSettings({ count: (settings.count || 0) + 1 });
        }
      };

      navigator.serviceWorker.addEventListener('message', handleMessage);
      return () => {
        navigator.serviceWorker.removeEventListener('message', handleMessage);
      };
    }
  }, [onUpdateSettings, settings.count]);

  // Handle Background Mode & Keep-Alive for Screen Off / Background
  useEffect(() => {
    if (settings.enabled && settings.backgroundMode) {
      backgroundKeepAlive.startKeepAlive();
    } else {
      backgroundKeepAlive.stopKeepAlive();
    }

    return () => {
      backgroundKeepAlive.stopKeepAlive();
    };
  }, [settings.enabled, settings.backgroundMode]);

  // Handle Screen Wake Lock when reading
  useEffect(() => {
    if (settings.keepScreenAwakeDuringReading) {
      backgroundKeepAlive.requestWakeLock();
    }
  }, [settings.keepScreenAwakeDuringReading]);

  // Stop any active preview
  const stopPreview = useCallback(() => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current.currentTime = 0;
      previewAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingPreview(false);
  }, []);

  // Helper to play a sound by type
  const playAudioForType = useCallback(
    (
      soundType: SalawatSoundType,
      volume: number,
      customUrl?: string,
      onEndedCallback?: () => void
    ) => {
      // Speech synthesis
      if (soundType === 'speech') {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance('اللهم صلِّ وسلِّم وبارك على سيدنا محمد وعلى آله وصحبه وسلم');
          utterance.lang = 'ar-SA';
          utterance.volume = Math.max(0.1, volume);
          utterance.rate = 0.9;
          utterance.onend = () => {
            if (onEndedCallback) onEndedCallback();
          };
          utterance.onerror = () => {
            if (onEndedCallback) onEndedCallback();
          };
          window.speechSynthesis.speak(utterance);
          return null;
        }
      }

      // Audio file URL
      let src = '/audio/salawat_full.mp3';
      if (soundType === 'mishary') {
        src = '/audio/salawat_mishary.mp3';
      } else if (soundType === 'chime') {
        src = '/audio/salawat_chime.mp3';
      } else if (soundType === 'custom' && customUrl) {
        src = customUrl;
      } else if (soundType === 'uploaded') {
        src = '/audio/salawat_full.mp3';
      }

      const audio = new Audio(src);
      audio.volume = Math.min(1, Math.max(0, volume));

      audio.onended = () => {
        if (onEndedCallback) onEndedCallback();
      };

      audio.onerror = () => {
        // Fallback to speech if audio fails
        if ('speechSynthesis' in window) {
          const utterance = new SpeechSynthesisUtterance('اللهم صلِّ وسلِّم وبارك على سيدنا محمد');
          utterance.lang = 'ar-SA';
          utterance.volume = volume;
          window.speechSynthesis.speak(utterance);
        }
        if (onEndedCallback) onEndedCallback();
      };

      // Set MediaSession for background audio priority on Android
      if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: 'ﷺ الصلاة على النبي',
          artist: 'اللهم صلِّ وسلِّم وبارك على سيدنا محمد',
          album: 'تطبيق القرآن الكريم',
          artwork: [
            { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
            { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
          ],
        });
      }

      audio.play().catch(() => {
        // Autoplay may require prior user interaction
      });

      return audio;
    },
    []
  );

  // Preview a specific sound
  const previewSound = useCallback(
    (soundType: SalawatSoundType, customUrl?: string) => {
      stopPreview();
      setIsPlayingPreview(true);
      const audio = playAudioForType(soundType, settings.volume, customUrl, () => {
        setIsPlayingPreview(false);
      });
      previewAudioRef.current = audio;
    },
    [playAudioForType, settings.volume, stopPreview]
  );

  // Trigger high-priority Android / browser notification
  const triggerBrowserNotification = useCallback(() => {
    if (!settings.showNotification) return;
    if (typeof window === 'undefined' || !('Notification' in window)) return;

    if (Notification.permission === 'granted') {
      const title = 'ﷺ الصلاة على النبي';
      const countText = settings.count ? ` (صلواتك: ${settings.count + 1})` : '';
      const notificationOptions: NotificationOptions = {
        body: `اللهم صلِّ وسلِّم وبارك على سيدنا محمد وعلى آله وصحبه وسلم${countText}`,
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        tag: 'salawat-reminder-active',
        // renotify alerts the user every interval
        renotify: true,
        // vibrate pattern for Android
        vibrate: [200, 100, 200, 100, 300],
        silent: false,
        requireInteraction: settings.persistentNotification, // stays on screen until dismissed or acted upon
        actions: [
          {
            action: 'salawat_count',
            title: '❤️ صلَّيتُ على النَّبِيّ',
          },
        ],
        data: {
          timestamp: Date.now(),
          url: '/',
        },
      } as any;

      // Prefer ServiceWorkerRegistration.showNotification (works reliably in background and lock screen)
      if (
        serviceWorkerRegistrationRef.current &&
        'showNotification' in serviceWorkerRegistrationRef.current
      ) {
        serviceWorkerRegistrationRef.current
          .showNotification(title, notificationOptions)
          .catch((err) => {
            console.warn('SW showNotification error, falling back to Notification constructor:', err);
            try {
              new Notification(title, notificationOptions);
            } catch (e) {
              console.warn('Notification constructor error:', e);
            }
          });
      } else {
        try {
          new Notification(title, notificationOptions);
        } catch (err) {
          console.warn('Notification failed:', err);
        }
      }
    }
  }, [settings.count, settings.persistentNotification, settings.showNotification]);

  // Request notification permission and update state
  const requestNotificationPermission = useCallback(async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }
    try {
      const res = await Notification.requestPermission();
      setNotificationPermission(res);
      if (res === 'granted') {
        onUpdateSettings({ showNotification: true });
        return true;
      } else {
        onUpdateSettings({ showNotification: false });
        return false;
      }
    } catch {
      return false;
    }
  }, [onUpdateSettings]);

  // Fire the actual reminder
  const fireReminder = useCallback(() => {
    lastReminderTimeRef.current = Date.now();
    pendingReminderAfterRecitation.current = false;

    // Increment count
    onUpdateSettings({
      count: (settings.count || 0) + 1,
      lastTriggeredAt: Date.now(),
    });

    // Show visual banner
    setIsBannerVisible(true);
    if (bannerTimerRef.current) {
      window.clearTimeout(bannerTimerRef.current);
    }
    bannerTimerRef.current = window.setTimeout(() => {
      setIsBannerVisible(false);
    }, 15000); // Hide banner after 15 seconds

    // Vibrate device if supported
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([200, 100, 200, 100, 300]);
      } catch {
        // ignore
      }
    }

    // Play Sound
    const audio = playAudioForType(
      settings.soundType,
      settings.volume,
      settings.customAudioDataUrl,
      () => {
        reminderAudioRef.current = null;
      }
    );
    reminderAudioRef.current = audio;

    // Trigger Android Notification
    triggerBrowserNotification();
  }, [
    onUpdateSettings,
    playAudioForType,
    settings.count,
    settings.customAudioDataUrl,
    settings.soundType,
    settings.volume,
    triggerBrowserNotification,
  ]);

  // Manual test of reminder
  const testReminder = useCallback(() => {
    fireReminder();
  }, [fireReminder]);

  // Manually increment count
  const incrementCount = useCallback(() => {
    onUpdateSettings({ count: (settings.count || 0) + 1 });
  }, [onUpdateSettings, settings.count]);

  // Reset count
  const resetCount = useCallback(() => {
    onUpdateSettings({ count: 0 });
  }, [onUpdateSettings]);

  // Dismiss banner
  const dismissBanner = useCallback(() => {
    setIsBannerVisible(false);
    if (bannerTimerRef.current) {
      window.clearTimeout(bannerTimerRef.current);
      bannerTimerRef.current = null;
    }
    if (reminderAudioRef.current) {
      reminderAudioRef.current.pause();
      reminderAudioRef.current = null;
    }
  }, []);

  // Main countdown and trigger effect with timestamp drift correction (handles sleep/lock screen)
  useEffect(() => {
    if (!settings.enabled || settings.intervalMinutes <= 0) {
      setSecondsUntilNext(0);
      return;
    }

    const intervalSec = settings.intervalMinutes * 60;

    const timer = setInterval(() => {
      const now = Date.now();
      const elapsedSec = Math.floor((now - lastReminderTimeRef.current) / 1000);
      const remaining = Math.max(0, intervalSec - elapsedSec);
      setSecondsUntilNext(remaining);

      if (remaining <= 0) {
        if (isQuranAudioPlaying && settings.pauseDuringQuranRecitation) {
          // Defer until Quran playback stops
          pendingReminderAfterRecitation.current = true;
        } else {
          fireReminder();
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [
    settings.enabled,
    settings.intervalMinutes,
    settings.pauseDuringQuranRecitation,
    isQuranAudioPlaying,
    fireReminder,
  ]);

  // When Quran stops playing, if a reminder was pending, trigger it
  useEffect(() => {
    if (!isQuranAudioPlaying && pendingReminderAfterRecitation.current && settings.enabled) {
      fireReminder();
    }
  }, [isQuranAudioPlaying, settings.enabled, fireReminder]);

  return {
    isBannerVisible,
    secondsUntilNext,
    isPlayingPreview,
    notificationPermission,
    previewSound,
    stopPreview,
    testReminder,
    incrementCount,
    resetCount,
    dismissBanner,
    requestNotificationPermission,
  };
}
