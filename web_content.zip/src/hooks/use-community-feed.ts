import { loadFeedPageFn } from "@/lib/youtube/api";
import { TYPE_FILTER } from "@/lib/youtube/topics";
import type { ChannelSummary, CommunityPost, TopicId } from "@/lib/youtube/types";
import { sortPosts, type PostSort, type TypeFilter } from "@/lib/sort";
import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo } from "react";

export type FeedTab = "community" | "following" | "search";

type Cursor = { id: string; continuation: string | null };

type Page = {
  posts: CommunityPost[];
  channels: ChannelSummary[];
  queryIndex: number;
  searchContinuation: string | null;
  nextCursors: Cursor[];
};

export function useCommunityFeed(opts: {
  topic: TopicId;
  type: TypeFilter;
  sort: PostSort;
  subscribedIds: string[];
  enabled: boolean;
}) {
  const query = useInfiniteQuery({
    queryKey: ["feed", opts.topic, opts.subscribedIds.join(",")],
    enabled: opts.enabled,
    initialPageParam: {
      queryIndex: 0,
      searchContinuation: null as string | null,
      cursors: opts.subscribedIds.map((id) => ({
        id,
        continuation: null as string | null,
      })),
    },
    queryFn: async ({ pageParam }): Promise<Page> => {
      return loadFeedPageFn({
        data: {
          topic: opts.topic,
          queryIndex: pageParam.queryIndex,
          searchContinuation: pageParam.searchContinuation,
          extraChannelIds: [],
          channelCursors: pageParam.cursors.slice(0, 400),
          discover: true,
        },
      });
    },
    getNextPageParam: (last, pages) => {
      const prev = pages.at(-2);
      const sameCursor =
        prev &&
        prev.queryIndex === last.queryIndex &&
        prev.searchContinuation === last.searchContinuation &&
        JSON.stringify(prev.nextCursors) === JSON.stringify(last.nextCursors);
      if (sameCursor) {
        return {
          queryIndex: last.queryIndex + 1,
          searchContinuation: null as string | null,
          cursors: last.nextCursors,
        };
      }
      return {
        queryIndex: last.queryIndex,
        searchContinuation: last.searchContinuation,
        cursors: last.nextCursors,
      };
    },
    retry: 1,
    refetchOnMount: false,
    throwOnError: false,
  });

  const channels = useMemo(() => {
    const seen = new Set<string>();
    const list: ChannelSummary[] = [];
    for (const page of query.data?.pages ?? []) {
      for (const ch of page.channels) {
        if (seen.has(ch.id)) continue;
        seen.add(ch.id);
        list.push(ch);
      }
    }
    return list;
  }, [query.data]);

  const posts = useMemo(() => {
    const seen = new Set<string>();
    const list: CommunityPost[] = [];
    for (const page of query.data?.pages ?? []) {
      for (const post of page.posts) {
        if (seen.has(post.id)) continue;
        seen.add(post.id);
        list.push(post);
      }
    }
    const fromType = opts.type !== "all" ? TYPE_FILTER[opts.type] : undefined;
    const fromTopic = TYPE_FILTER[opts.topic];
    const kind = fromType ?? fromTopic;
    const typed = kind ? list.filter((p) => p.kind === kind) : list;
    return sortPosts(typed, opts.sort);
  }, [opts.sort, opts.topic, opts.type, query.data]);

  return { ...query, posts, channels };
}
