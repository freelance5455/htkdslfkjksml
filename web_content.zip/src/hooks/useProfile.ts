/** بيانات الطالب (تُحفظ محلياً بدون كلمة مرور في هذه النسخة) */
import type { Profile } from '../types';
import { KEYS, useStored, writeKey } from '../services/storage';

const defaultExam = getDefaultExamDate();

/** تاريخ امتحان افتراضي: أول حزيران من السنة الدراسية القادمة */
function getDefaultExamDate(): string {
  const now = new Date();
  const year = now.getMonth() > 5 ? now.getFullYear() + 1 : now.getFullYear();
  return `${year}-06-01`;
}

export const defaultProfile: Profile = {
  name: '',
  governorate: '',
  targetAverage: 80,
  examDate: defaultExam,
  createdAt: new Date().toISOString(),
  teacherBySubject: {},
  onboarded: false,
};

export function useProfile() {
  const profile = useStored<Profile>(KEYS.profile, defaultProfile);

  const save = (patch: Partial<Profile>) => {
    writeKey<Profile>(KEYS.profile, { ...profile, ...patch });
  };

  const selectTeacher = (subjectId: string, teacherId: string) => {
    writeKey<Profile>(KEYS.profile, {
      ...profile,
      teacherBySubject: { ...profile.teacherBySubject, [subjectId]: teacherId },
    });
  };

  const teacherFor = (subjectId: string, fallback: string): string =>
    profile.teacherBySubject[subjectId] ?? fallback;

  return { profile, save, selectTeacher, teacherFor };
}

export const GOVERNORATES = [
  'دمشق',
  'ريف دمشق',
  'حلب',
  'حمص',
  'حماة',
  'اللاذقية',
  'طرطوس',
  'إدلب',
  'درعا',
  'السويداء',
  'القنيطرة',
  'دير الزور',
  'الرقة',
  'الحسكة',
  'خارج سوريا',
];
