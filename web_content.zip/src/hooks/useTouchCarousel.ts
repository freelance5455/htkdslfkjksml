import { useRef, useEffect } from 'react';

export function useTouchCarousel<T extends HTMLElement = HTMLDivElement>() {
  const containerRef = useRef<T | null>(null);
  const isDragging = useRef(false);
  const startX = useRef(0);
  const startY = useRef(0);
  const startScrollLeft = useRef(0);
  const isHorizontalSwipe = useRef<boolean | null>(null);

  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      startX.current = e.touches[0].clientX;
      startY.current = e.touches[0].clientY;
      startScrollLeft.current = element.scrollLeft;
      isHorizontalSwipe.current = null;
      isDragging.current = false;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      const currentX = e.touches[0].clientX;
      const currentY = e.touches[0].clientY;
      const diffX = currentX - startX.current;
      const diffY = currentY - startY.current;

      // Lock axis direction once threshold exceeded (6px)
      if (isHorizontalSwipe.current === null) {
        if (Math.abs(diffX) > 6 || Math.abs(diffY) > 6) {
          isHorizontalSwipe.current = Math.abs(diffX) > Math.abs(diffY);
        }
      }

      // If user is swiping horizontally, scroll the carousel horizontally.
      if (isHorizontalSwipe.current === true) {
        isDragging.current = true;
        element.scrollLeft = startScrollLeft.current - diffX;
      }
      // If user is swiping vertically (isHorizontalSwipe === false):
      // We do nothing! Native vertical page scrolling executes unhindered.
    };

    const onTouchEnd = () => {
      // Delay resetting isDragging so onClick handlers know if this was a drag vs a tap
      setTimeout(() => {
        isDragging.current = false;
        isHorizontalSwipe.current = null;
      }, 60);
    };

    element.addEventListener('touchstart', onTouchStart, { passive: true });
    element.addEventListener('touchmove', onTouchMove, { passive: true });
    element.addEventListener('touchend', onTouchEnd, { passive: true });
    element.addEventListener('touchcancel', onTouchEnd, { passive: true });

    return () => {
      element.removeEventListener('touchstart', onTouchStart);
      element.removeEventListener('touchmove', onTouchMove);
      element.removeEventListener('touchend', onTouchEnd);
      element.removeEventListener('touchcancel', onTouchEnd);
    };
  }, []);

  return { containerRef, isDragging };
}

export default useTouchCarousel;
