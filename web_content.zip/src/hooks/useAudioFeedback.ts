import { useState, useEffect, useCallback } from 'react';
import { soundEngine, triggerHaptic } from '../utils/audio';

export interface AudioFeedbackControls {
  playButtonClick: () => void;
  playCoinCollect: (burstCount?: number) => void;
  playTap: (combo?: number) => void;
  playCashOut: () => void;
  playCrit: () => void;
  playTick: () => void;
  playError: () => void;
  isMuted: boolean;
  setMuted: (muted: boolean) => void;
  toggleMute: () => void;
}

/**
 * Custom React hook for playing instant Web Audio API sound effects
 * on button clicks, coin collection, and interactive touch events.
 */
export function useAudioFeedback(): AudioFeedbackControls {
  const [isMuted, setIsMutedState] = useState<boolean>(() => soundEngine.getMuted());

  // Unlock AudioContext on the user's first interaction
  useEffect(() => {
    const handleFirstInteraction = () => {
      soundEngine.initCtx();
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };

    window.addEventListener('click', handleFirstInteraction, { once: true });
    window.addEventListener('touchstart', handleFirstInteraction, { once: true });

    return () => {
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, []);

  const setMuted = useCallback((muted: boolean) => {
    soundEngine.setMuted(muted);
    setIsMutedState(muted);
  }, []);

  const toggleMute = useCallback(() => {
    const next = !soundEngine.getMuted();
    soundEngine.setMuted(next);
    setIsMutedState(next);
  }, []);

  const playButtonClick = useCallback(() => {
    triggerHaptic('light');
    soundEngine.playButtonClick();
  }, []);

  const playCoinCollect = useCallback((burstCount: number = 3) => {
    triggerHaptic('medium');
    soundEngine.playCoinCollect(burstCount);
  }, []);

  const playTap = useCallback((combo: number = 1) => {
    soundEngine.playTap(combo);
  }, []);

  const playCashOut = useCallback(() => {
    triggerHaptic('success');
    soundEngine.playCashRegister();
  }, []);

  const playCrit = useCallback(() => {
    triggerHaptic('heavy');
    soundEngine.playCrit();
  }, []);

  const playTick = useCallback(() => {
    soundEngine.playSpinTick();
  }, []);

  const playError = useCallback(() => {
    triggerHaptic('heavy');
    soundEngine.playError();
  }, []);

  return {
    playButtonClick,
    playCoinCollect,
    playTap,
    playCashOut,
    playCrit,
    playTick,
    playError,
    isMuted,
    setMuted,
    toggleMute,
  };
}
