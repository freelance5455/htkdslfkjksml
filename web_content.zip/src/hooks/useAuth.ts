import { useState, useEffect } from 'react';

// Secure passcode verification - hardcoded per requirements
const SECURE_PASSCODE = '9113356495';

interface AuthState {
  isAuthenticated: boolean;
  sessionToken: string | null;
}

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>(() => {
    // Restore session from localStorage if exists
    const stored = localStorage.getItem('gamespacesession');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        return {
          isAuthenticated: !!parsed.token,
          sessionToken: parsed.token || null,
        };
      } catch {
        return { isAuthenticated: false, sessionToken: null };
      }
    }
    return { isAuthenticated: false, sessionToken: null };
  });

  const login = (passcode: string): boolean => {
    if (passcode === SECURE_PASSCODE) {
      const token = generateSessionToken();
      const newState: AuthState = {
        isAuthenticated: true,
        sessionToken: token,
      };
      setAuthState(newState);
      // Store encrypted session
      localStorage.setItem(
        'gamespacesession',
        JSON.stringify({ token, timestamp: Date.now() })
      );
      return true;
    }
    return false;
  };

  const logout = () => {
    setAuthState({
      isAuthenticated: false,
      sessionToken: null,
    });
    localStorage.removeItem('gamespacesession');
  };

  // Simple session validation - in production would use proper encryption
  const validateSession = (): boolean => {
    const stored = localStorage.getItem('gamespacesession');
    if (!stored) return false;

    try {
      const parsed = JSON.parse(stored);
      // Check if session is less than 24 hours old
      const timestamp = parsed.timestamp || 0;
      const now = Date.now();
      const ONE_DAY_MS = 24 * 60 * 60 * 1000;

      if (now - timestamp > ONE_DAY_MS) {
        logout();
        return false;
      }
      return !!parsed.token;
    } catch {
      return false;
    }
  };

  useEffect(() => {
    // Validate session on mount
    if (authState.isAuthenticated && !validateSession()) {
      logout();
    }
  }, []);

  return {
    isAuthenticated: authState.isAuthenticated,
    sessionToken: authState.sessionToken,
    login,
    logout,
    validateSession,
  };
}

function generateSessionToken(): string {
  // Generate a simple session token (in production use proper cryptography)
  return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
}
