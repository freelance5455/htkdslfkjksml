import { useContext } from "react";
import { AuthContext } from "@/context/AuthContext";
import { getUser, isAuthenticated, directAccess, registerDirect, login, logout } from "@/lib/auth";

export function useAuth() {
  const context = useContext(AuthContext);
  if (context) {
    return context;
  }

  // Fallback if rendered outside of AuthProvider
  const currentUser = getUser();
  return {
    user: currentUser,
    loading: false,
    error: null,
    authenticated: isAuthenticated(),
    login: async (e: string, p: string) => {
      const res = await login(e, p);
      return res.success;
    },
    directAccess: async (name?: string, email?: string) => {
      const res = await directAccess(name, email);
      return res.success;
    },
    registerDirect: async (name: string, email: string) => {
      const res = await registerDirect(name, email);
      return res.success;
    },
    logout: async () => {
      await logout();
    },
    clearError: () => {},
  };
}


