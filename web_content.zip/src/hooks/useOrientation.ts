import { useState, useEffect } from 'react';

/**
 * Hook to accurately detect device orientation in real-time.
 * Returns true if portrait (vertical), false if landscape (horizontal).
 */
export function useOrientation(): boolean {
  const detectPortrait = (): boolean => {
    if (typeof window === 'undefined') return false;

    // 1. Check window.screen.orientation if available (standard modern mobile browser API)
    if (window.screen && window.screen.orientation && window.screen.orientation.type) {
      if (window.screen.orientation.type.startsWith('portrait')) {
        return true;
      }
      if (window.screen.orientation.type.startsWith('landscape')) {
        return false;
      }
    }

    // 2. Check matchMedia query
    if (window.matchMedia) {
      const mql = window.matchMedia('(orientation: portrait)');
      if (mql && typeof mql.matches === 'boolean') {
        return mql.matches;
      }
    }

    // 3. Viewport dimensions fallback
    return window.innerHeight >= window.innerWidth;
  };

  const [isPortrait, setIsPortrait] = useState<boolean>(detectPortrait);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const check = () => {
      setIsPortrait(detectPortrait());
    };

    check();

    window.addEventListener('resize', check, { passive: true });
    window.addEventListener('orientationchange', check, { passive: true });

    // screen.orientation change listener (Android Chrome / WebView)
    if (window.screen && window.screen.orientation && window.screen.orientation.addEventListener) {
      window.screen.orientation.addEventListener('change', check);
    }

    let mql: MediaQueryList | null = null;
    if (window.matchMedia) {
      mql = window.matchMedia('(orientation: portrait)');
      if (mql.addEventListener) {
        mql.addEventListener('change', check);
      } else if ('addListener' in mql) {
        (mql as any).addListener(check);
      }
    }

    return () => {
      window.removeEventListener('resize', check);
      window.removeEventListener('orientationchange', check);
      if (window.screen && window.screen.orientation && window.screen.orientation.removeEventListener) {
        window.screen.orientation.removeEventListener('change', check);
      }
      if (mql) {
        if (mql.removeEventListener) {
          mql.removeEventListener('change', check);
        } else if ('removeListener' in mql) {
          (mql as any).removeListener(check);
        }
      }
    };
  }, []);

  return isPortrait;
}
