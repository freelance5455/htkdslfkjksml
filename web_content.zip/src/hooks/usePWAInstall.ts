import { useState, useEffect, useCallback } from "react";

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

export type InstallDiagnosticReason = "ready" | "iframe" | "ios" | "unprompted" | "installed" | "insecure";

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isInIframe, setIsInIframe] = useState(false);
  const [isSecure, setIsSecure] = useState(true);
  const [diagnosticReason, setDiagnosticReason] = useState<InstallDiagnosticReason>("unprompted");

  useEffect(() => {
    // Check if running in standalone PWA mode
    const checkStandalone = () => {
      const isStandalone =
        window.matchMedia("(display-mode: standalone)").matches ||
        (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
        document.referrer.includes("android-app://");
      setIsInstalled(isStandalone);
      if (isStandalone) {
        setDiagnosticReason("installed");
      }
    };

    checkStandalone();

    // Check iframe context
    const inIframe = window.self !== window.top;
    setIsInIframe(inIframe);

    // Check secure context (HTTPS / localhost)
    const secure = window.isSecureContext || window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1";
    setIsSecure(secure);

    // Check device types
    const ua = navigator.userAgent.toLowerCase();
    const android = /android/.test(ua);
    const ios = /iphone|ipad|ipod/.test(ua);
    setIsAndroid(android);
    setIsIOS(ios);

    if (inIframe) {
      setDiagnosticReason("iframe");
    } else if (ios) {
      setDiagnosticReason("ios");
    } else if (!secure) {
      setDiagnosticReason("insecure");
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      // Prevent browser default mini-infobar so our custom install button handles it
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      setDeferredPrompt(promptEvent);
      setDiagnosticReason("ready");
      console.log("[PWA] beforeinstallprompt event captured and ready.");
    };

    const handleAppInstalled = () => {
      console.log("[PWA] App was successfully installed on the device!");
      setIsInstalled(true);
      setDeferredPrompt(null);
      setDiagnosticReason("installed");
      setIsInstallModalOpen(false);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const triggerInstall = useCallback(async () => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        console.log("[PWA] User choice outcome:", choice.outcome);
        if (choice.outcome === "accepted") {
          setDeferredPrompt(null);
          return true;
        }
      } catch (err) {
        console.warn("[PWA] Error triggering install prompt:", err);
      }
    }
    // Open detailed guide modal with diagnostics
    setIsInstallModalOpen(true);
    return false;
  }, [deferredPrompt]);

  const openDirectBrowserTab = useCallback(() => {
    try {
      window.open(window.location.href, "_blank", "noopener,noreferrer");
    } catch {
      window.location.href = window.location.href;
    }
  }, []);

  return {
    isInstallable: Boolean(deferredPrompt),
    isInstalled,
    isAndroid,
    isIOS,
    isInIframe,
    isSecure,
    diagnosticReason,
    isInstallModalOpen,
    setIsInstallModalOpen,
    triggerInstall,
    openDirectBrowserTab,
  };
}
