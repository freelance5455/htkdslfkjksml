/**
 * حفظ موضع المشاهدة كل ٥ ثوانٍ + عند الإيقاف + عند إخفاء الصفحة/الخروج.
 * ويستنتج «تمت المشاهدة» عند ٩٠٪ (يحدث داخل savePlayback).
 */
import { useEffect, useRef } from 'react';
import type { Lesson } from '../types';
import { savePlayback } from '../services/progress';
import type { PlayerStatus } from './useYouTubePlayer';

export function useVideoProgress(params: {
  lesson?: Lesson;
  currentTime: number;
  duration: number;
  status: PlayerStatus;
}): void {
  const { lesson, currentTime, duration, status } = params;
  const timeRef = useRef(currentTime);
  const durationRef = useRef(duration);

  timeRef.current = currentTime;
  durationRef.current = duration;

  // كل ٥ ثوانٍ أثناء التشغيل
  useEffect(() => {
    if (!lesson || status !== 'playing') return undefined;
    const id = window.setInterval(() => {
      savePlayback(lesson, timeRef.current, durationRef.current);
    }, 5000);
    return () => window.clearInterval(id);
  }, [lesson, status]);

  // عند الإيقاف أو الانتهاء أو تغيير الحالة
  useEffect(() => {
    if (lesson && (status === 'paused' || status === 'ended' || status === 'buffering')) {
      if (timeRef.current > 1) savePlayback(lesson, timeRef.current, durationRef.current);
    }
  }, [lesson, status]);

  // عند إخفاء التبويب أو مغادرة الصفحة
  useEffect(() => {
    const flush = () => {
      if (lesson && timeRef.current > 1) savePlayback(lesson, timeRef.current, durationRef.current);
    };
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') flush();
    };
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', flush);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', flush);
      flush();
    };
  }, [lesson]);
}
