import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { checkUrlHealth } from "@/lib/check-url";
import { copy } from "@/lib/i18n";
import { inQuietHours, intervalMs, useLaksha, type Watch } from "@/lib/store";
import { istParts, playSignal } from "@/lib/utils";

function deliver(watch: Watch, body: string, force = false, status?: Watch["lastStatus"]) {
  const alert = useLaksha.getState().fireAlert({ watch, body, force, status });
  if (!alert) return;
  const state = useLaksha.getState();
  const quiet = inQuietHours(state);
  const c = copy[state.lang];

  if (watch.channels.notification && !quiet) {
    try {
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        new Notification(`${c.app}: ${watch.title}`, { body, tag: watch.id });
      }
    } catch {
      /* ignore */
    }
    toast(watch.title, { description: body });
  } else {
    toast(watch.title, { description: body });
  }

  if (state.sound && !quiet) playSignal();
  try {
    navigator.vibrate?.(160);
  } catch {
    /* ignore */
  }
}

async function runSiteCheck(watch: Watch, force: boolean) {
  if (!watch.url) return;
  const c = copy[useLaksha.getState().lang];
  useLaksha.getState().recordCheck(watch.id, {
    lastCheckedAt: Date.now(),
    lastStatus: watch.lastStatus,
    lastMessage: c.checking,
  });
  try {
    const res = await checkUrlHealth({ data: { url: watch.url } });
    const prev = useLaksha.getState().watches.find((w) => w.id === watch.id);
    if (!prev) return;
    if (res.ok) {
      useLaksha.getState().recordCheck(watch.id, {
        lastCheckedAt: res.checkedAt,
        lastStatus: "ok",
        lastLatencyMs: res.ms,
        lastMessage: `${c.siteUp} · ${res.status} · ${res.ms}ms`,
      });
      if (prev.lastStatus === "alert") {
        deliver({ ...prev, lastStatus: "ok" }, `${c.recovered} — ${watch.url}`, true, "ok");
      }
    } else {
      useLaksha.getState().recordCheck(watch.id, {
        lastCheckedAt: res.checkedAt,
        lastStatus: "alert",
        lastLatencyMs: res.ms,
        lastMessage: `${c.siteDown} · ${res.status || "—"}`,
      });
      if (force || prev.lastStatus !== "alert") {
        deliver(prev, `${c.siteDown}${watch.url ? ` — ${watch.url}` : ""}`, force);
      }
    }
  } catch {
    useLaksha.getState().recordCheck(watch.id, {
      lastCheckedAt: Date.now(),
      lastStatus: "alert",
      lastMessage: c.failedCheck,
    });
  }
}

function tickReminders() {
  const { watches, lang } = useLaksha.getState();
  const c = copy[lang];
  const parts = istParts();
  for (const watch of watches) {
    if (!watch.enabled || watch.kind !== "reminder") continue;
    const mode = watch.reminderMode ?? "daily";
    if (mode === "daily") {
      if (watch.reminderAt === parts.hhmm && watch.lastFiredDate !== parts.dateKey) {
        deliver(watch, `${c.reminderFire} · ${watch.reminderAt} — ${watch.note || watch.title}`);
      }
    } else {
      const gap = intervalMs(mode);
      if (gap && Date.now() - (watch.lastFiredAt ?? watch.createdAt) >= gap) {
        deliver(watch, `${c.reminderFire} — ${watch.note || watch.title}`);
      }
    }
  }
}

export function useEngine() {
  const checking = useRef(false);

  useEffect(() => {
    const remind = window.setInterval(tickReminders, 1000);
    const sites = window.setInterval(async () => {
      if (checking.current) return;
      const list = useLaksha.getState().watches.filter((w) => w.enabled && w.kind === "site" && w.url);
      const due = list.filter((w) => !w.lastCheckedAt || Date.now() - w.lastCheckedAt > 45_000);
      if (due.length === 0) return;
      checking.current = true;
      try {
        await Promise.all(due.slice(0, 3).map((w) => runSiteCheck(w, false)));
      } finally {
        checking.current = false;
      }
    }, 4000);

    const first = useLaksha.getState().watches.find((w) => w.enabled && w.kind === "site" && w.url);
    if (first) void runSiteCheck(first, false);

    return () => {
      window.clearInterval(remind);
      window.clearInterval(sites);
    };
  }, []);
}

export function checkWatchNow(watch: Watch) {
  if (watch.kind === "site") {
    void runSiteCheck(watch, true);
    return;
  }
  const c = copy[useLaksha.getState().lang];
  if (watch.kind === "target") {
    const hit = crossesTarget(watch);
    deliver(
      watch,
      hit ? `${c.targetHit} — ${watch.currentValue} / ${watch.targetValue}` : `${c.valueNow} ${watch.currentValue ?? "—"}`,
      true,
    );
    return;
  }
  if (watch.kind === "keyword") {
    deliver(watch, `${c.keywordHit}: ${watch.keyword ?? watch.note}`, true);
    return;
  }
  deliver(watch, watch.note || c.testBody, true);
}

export function crossesTarget(watch: Watch) {
  if (watch.currentValue == null || watch.targetValue == null) return false;
  if (watch.targetDirection === "above") return watch.currentValue >= watch.targetValue;
  return watch.currentValue <= watch.targetValue;
}

export function sendTestAlert(watch: Watch) {
  const c = copy[useLaksha.getState().lang];
  const status = watch.lastStatus === "unknown" ? "ok" : watch.lastStatus;
  deliver(watch, c.testBody, true, status);
}
