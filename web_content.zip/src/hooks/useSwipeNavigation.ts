import React, { useRef } from 'react';

interface UseSwipeNavigationOptions {
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  isRotatedPortrait?: boolean;
  stepPx?: number;
  disabled?: boolean;
}

/**
 * Enables smooth left/right finger swipe and mouse drag navigation across console tiles.
 * Supports multi-step continuous swiping as a finger glides across multiple icons,
 * and handles 90-degree rotated landscape mode on portrait devices.
 */
export function useSwipeNavigation({
  onSwipeLeft,
  onSwipeRight,
  isRotatedPortrait = false,
  stepPx = 56,
  disabled = false,
}: UseSwipeNavigationOptions) {
  const startAxisRef = useRef<{ x: number; y: number } | null>(null);
  const lastStepXRef = useRef<number>(0);
  const didSwipeRef = useRef(false);
  const activePointerIdRef = useRef<number | null>(null);

  const getVisualCoords = (clientX: number, clientY: number) => {
    // When container is rotated 90deg clockwise, physical +Y maps to visual +X
    if (isRotatedPortrait) {
      return { x: clientY, y: -clientX };
    }
    return { x: clientX, y: clientY };
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if (disabled) return;
    // Only primary mouse button or touch/pen
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    const coords = getVisualCoords(e.clientX, e.clientY);
    startAxisRef.current = coords;
    lastStepXRef.current = coords.x;
    didSwipeRef.current = false;
    activePointerIdRef.current = e.pointerId;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (disabled || !startAxisRef.current) return;
    if (activePointerIdRef.current !== null && e.pointerId !== activePointerIdRef.current) {
      return;
    }

    const coords = getVisualCoords(e.clientX, e.clientY);
    const totalDx = coords.x - startAxisRef.current.x;
    const totalDy = coords.y - startAxisRef.current.y;

    // Require predominantly horizontal motion before locking into horizontal swipe
    if (!didSwipeRef.current && Math.abs(totalDx) < 18) return;
    if (!didSwipeRef.current && Math.abs(totalDy) > Math.abs(totalDx) * 1.15) {
      // Vertical gesture; ignore horizontal swipe
      startAxisRef.current = null;
      return;
    }

    const deltaFromLastStep = coords.x - lastStepXRef.current;

    if (deltaFromLastStep >= stepPx) {
      didSwipeRef.current = true;
      lastStepXRef.current = coords.x;
      // Swiping finger toward the right moves highlight right
      onSwipeRight();
    } else if (deltaFromLastStep <= -stepPx) {
      didSwipeRef.current = true;
      lastStepXRef.current = coords.x;
      // Swiping finger toward the left moves highlight left
      onSwipeLeft();
    }
  };

  const finishPointer = () => {
    startAxisRef.current = null;
    activePointerIdRef.current = null;
    if (didSwipeRef.current) {
      // Clear flag right after current click microtask so click handler knows it was a swipe
      window.setTimeout(() => {
        didSwipeRef.current = false;
      }, 40);
    }
  };

  const handlePointerLeave = () => {
    startAxisRef.current = null;
    activePointerIdRef.current = null;
  };

  const shouldSuppressClick = () => didSwipeRef.current;

  return {
    swipeHandlers: {
      onPointerDown: handlePointerDown,
      onPointerMove: handlePointerMove,
      onPointerUp: finishPointer,
      onPointerCancel: finishPointer,
      onPointerLeave: handlePointerLeave,
    },
    shouldSuppressClick,
  };
}
