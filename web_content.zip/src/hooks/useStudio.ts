import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  db,
  DEFAULT_SETTINGS,
  type StoredFile,
  type StoredSettings,
} from "@/lib/db";
import { detectLanguage } from "@/lib/language";

export interface StudioFile extends StoredFile {
  dirty?: boolean;
}

export interface StudioApi {
  files: StudioFile[];
  activeFileId: string | null;
  settings: StoredSettings;
  ready: boolean;
  persistent: boolean;
  setActiveFile: (id: string) => void;
  updateContent: (id: string, content: string) => void;
  saveFile: (id: string) => Promise<void>;
  saveAll: () => Promise<void>;
  createFile: (name: string, content?: string) => Promise<void>;
  renameFile: (id: string, name: string) => Promise<void>;
  deleteFile: (id: string) => Promise<void>;
  duplicateFile: (id: string) => Promise<void>;
  setMainFile: (id: string) => Promise<void>;
  createProject: (template: string, projectName: string) => Promise<void>;
  updateSettings: (patch: Partial<StoredSettings>) => void;
  resetSettings: () => void;
  exportProject: () => void;
  importProject: (file: File) => Promise<void>;
}

const TEMPLATES: Record<string, { name: string; content: string }[]> = {
  blank: [],
  html: [
    {
      name: "index.html",
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>صفحة جديدة</title>
</head>
<body>
  <h1>مرحبًا بك في Mobile Code Studio</h1>
  <p>ابدأ بتحرير هذا الملف.</p>
</body>
</html>`,
    },
  ],
  web: [
    {
      name: "index.html",
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>مشروع ويب</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header class="hero">
    <h1>مشروع ويب متكامل</h1>
    <p>HTML + CSS + JavaScript</p>
    <button id="cta">اضغط هنا</button>
  </header>
  <script src="js/script.js"></script>
</body>
</html>`,
    },
    {
      name: "css/style.css",
      content: `* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: system-ui, sans-serif;
  background: linear-gradient(135deg, #0f172a, #1e293b);
  color: #e2e8f0;
  min-height: 100vh;
  display: grid;
  place-items: center;
}
.hero { text-align: center; padding: 2rem; }
.hero h1 { font-size: 2rem; margin-bottom: 0.5rem; color: #38bdf8; }
.hero p { color: #94a3b8; margin-bottom: 1.5rem; }
button {
  background: #0ea5e9;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 0.75rem;
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.15s;
}
button:active { transform: scale(0.96); }`,
    },
    {
      name: "js/script.js",
      content: `const cta = document.getElementById("cta");
let count = 0;
cta.addEventListener("click", () => {
  count++;
  cta.textContent = "تم الضغط " + count + " مرة";
  console.log("Clicked:", count);
});
console.log("التطبيق جاهز");`,
    },
    {
      name: "README.md",
      content: `# مشروع ويب

بنية المشروع:
- index.html
- css/style.css
- js/script.js`,
    },
  ],
  landing: [
    {
      name: "index.html",
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>صفحة هبوط</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <nav class="nav"><span class="logo">شركتي</span><button class="nav-btn">ابدأ الآن</button></nav>
  <section class="hero">
    <h1>حلول رقمية متكاملة</h1>
    <p>نبني لك تجربة رقمية استثنائية</p>
    <button class="cta">اطلب عرضًا</button>
  </section>
  <section class="features">
    <div class="card"><h3>سريع</h3><p>أداء عالٍ</p></div>
    <div class="card"><h3>آمن</h3><p>حماية كاملة</p></div>
    <div class="card"><h3>مرن</h3><p>قابل للتوسع</p></div>
  </section>
</body>
</html>`,
    },
    {
      name: "css/style.css",
      content: `* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: system-ui, sans-serif; background: #f8fafc; color: #0f172a; }
.nav { display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.5rem; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.logo { font-weight: 700; color: #4f46e5; font-size: 1.25rem; }
.nav-btn { background: #4f46e5; color: white; border: none; padding: 0.5rem 1rem; border-radius: 0.5rem; }
.hero { text-align: center; padding: 4rem 1.5rem; background: linear-gradient(135deg, #eef2ff, #faf5ff); }
.hero h1 { font-size: 2.25rem; margin-bottom: 1rem; }
.hero p { color: #64748b; margin-bottom: 2rem; }
.cta { background: #4f46e5; color: white; border: none; padding: 1rem 2rem; border-radius: 0.75rem; font-size: 1.1rem; }
.features { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; padding: 3rem 1.5rem; }
.card { background: white; padding: 2rem; border-radius: 1rem; box-shadow: 0 4px 12px rgba(0,0,0,0.06); }
.card h3 { color: #4f46e5; margin-bottom: 0.5rem; }`,
    },
  ],
  canvas: [
    {
      name: "index.html",
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>لعبة Canvas</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <canvas id="game"></canvas>
  <div class="hud">استخدم الأسهم للتحرك</div>
  <script src="js/script.js"></script>
</body>
</html>`,
    },
    {
      name: "css/style.css",
      content: `* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: #0f172a; display: grid; place-items: center; min-height: 100vh; }
canvas { background: #1e293b; border-radius: 1rem; box-shadow: 0 8px 32px rgba(0,0,0,0.4); }
.hud { position: fixed; bottom: 1rem; color: #94a3b8; font-family: system-ui; }`,
    },
    {
      name: "js/script.js",
      content: `const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
canvas.width = 320;
canvas.height = 320;

const player = { x: 160, y: 160, size: 20, speed: 4 };
const keys = {};

window.addEventListener("keydown", (e) => (keys[e.key] = true));
window.addEventListener("keyup", (e) => (keys[e.key] = false));

function update() {
  if (keys["ArrowUp"]) player.y -= player.speed;
  if (keys["ArrowDown"]) player.y += player.speed;
  if (keys["ArrowLeft"]) player.x -= player.speed;
  if (keys["ArrowRight"]) player.x += player.speed;
  player.x = Math.max(0, Math.min(canvas.width - player.size, player.x));
  player.y = Math.max(0, Math.min(canvas.height - player.size, player.y));
}

function draw() {
  ctx.fillStyle = "#1e293b";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#38bdf8";
  ctx.fillRect(player.x, player.y, player.size, player.size);
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}
loop();
console.log("اللعبة بدأت");`,
    },
  ],
};

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function useStudio(): StudioApi {
  const [files, setFiles] = useState<StudioFile[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [settings, setSettings] = useState<StoredSettings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);
  const [persistent, setPersistent] = useState(true);
  const settingsRef = useRef(settings);
  const filesRef = useRef(files);
  const saveTimers = useRef<Record<string, number>>({});

  settingsRef.current = settings;
  filesRef.current = files;

  useEffect(() => {
    (async () => {
      try {
        const isPersistent = await db.isPersistent();
        setPersistent(isPersistent);

        const [storedFiles, storedSettings, session] = await Promise.all([
          db.allFiles(),
          db.getSettings(),
          db.getSession(),
        ]);
        if (storedSettings) setSettings({ ...DEFAULT_SETTINGS, ...storedSettings });
        if (storedFiles.length) {
          setFiles(storedFiles);
          setActiveFileId(session?.activeFileId ?? storedFiles[0].id);
        } else {
          const initial = TEMPLATES.web.map((t) => ({
            id: uid(),
            name: t.name,
            path: t.name,
            language: detectLanguage(t.name),
            content: t.content,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            isMain: t.name === "index.html",
          }));
          await db.putFiles(initial);
          setFiles(initial);
          setActiveFileId(initial[0].id);
        }
      } catch {
        toast.error("تعذر تحميل البيانات المحفوظة");
      } finally {
        setReady(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (ready) db.saveSettings(settings).catch(() => {});
  }, [settings, ready]);

  useEffect(() => {
    if (ready) db.saveSession({ activeFileId }).catch(() => {});
  }, [activeFileId, ready]);

  const setActiveFile = useCallback((id: string) => setActiveFileId(id), []);

  const persist = useCallback(async (file: StudioFile) => {
    const { dirty, ...rest } = file;
    await db.putFile(rest);
  }, []);

  const updateContent = useCallback(
    (id: string, content: string) => {
      setFiles((prev) =>
        prev.map((f) => (f.id === id ? { ...f, content, dirty: true } : f))
      );
      const s = settingsRef.current;
      if (!s.autoSave) return;
      window.clearTimeout(saveTimers.current[id]);
      saveTimers.current[id] = window.setTimeout(async () => {
        const file = filesRef.current.find((f) => f.id === id);
        if (!file) return;
        const updated = { ...file, updatedAt: Date.now(), dirty: false };
        try {
          await persist(updated);
          setFiles((prev) => prev.map((f) => (f.id === id ? updated : f)));
        } catch {
          /* keep dirty flag so the user can retry */
        }
      }, s.autoSaveDelay);
    },
    [persist]
  );

  const saveFile = useCallback(
    async (id: string) => {
      const file = filesRef.current.find((f) => f.id === id);
      if (!file) return;
      const updated = { ...file, updatedAt: Date.now(), dirty: false };
      try {
        await persist(updated);
        setFiles((prev) => prev.map((f) => (f.id === id ? updated : f)));
        toast.success("تم الحفظ");
      } catch {
        toast.error("فشل الحفظ — قد تكون مساحة التخزين ممتلئة");
      }
    },
    [persist]
  );

  const saveAll = useCallback(async () => {
    const dirty = filesRef.current.filter((f) => f.dirty);
    if (!dirty.length) {
      toast.info("لا توجد تعديلات غير محفوظة");
      return;
    }
    await Promise.all(dirty.map((f) => saveFile(f.id)));
  }, [saveFile]);

  const createFile = useCallback(async (name: string, content = "") => {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (filesRef.current.some((f) => f.name === trimmed)) {
      toast.error("يوجد ملف بنفس الاسم");
      return;
    }
    const file: StudioFile = {
      id: uid(),
      name: trimmed,
      path: trimmed,
      language: detectLanguage(trimmed),
      content,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await db.putFile(file);
    setFiles((prev) => [...prev, file]);
    setActiveFileId(file.id);
    toast.success("تم إنشاء الملف");
  }, []);

  const renameFile = useCallback(async (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (filesRef.current.some((f) => f.id !== id && f.name === trimmed)) {
      toast.error("يوجد ملف بنفس الاسم");
      return;
    }
    const file = filesRef.current.find((f) => f.id === id);
    if (!file) return;
    const updated: StudioFile = {
      ...file,
      name: trimmed,
      path: trimmed,
      language: detectLanguage(trimmed),
      updatedAt: Date.now(),
    };
    await db.putFile(updated);
    setFiles((prev) => prev.map((f) => (f.id === id ? updated : f)));
    toast.success("تمت إعادة التسمية");
  }, []);

  const deleteFile = useCallback(
    async (id: string) => {
      await db.deleteFile(id);
      setFiles((prev) => {
        const next = prev.filter((f) => f.id !== id);
        if (activeFileId === id) setActiveFileId(next[0]?.id ?? null);
        return next;
      });
      toast.success("تم الحذف");
    },
    [activeFileId]
  );

  const duplicateFile = useCallback(async (id: string) => {
    const file = filesRef.current.find((f) => f.id === id);
    if (!file) return;
    const dot = file.name.lastIndexOf(".");
    const base = dot === -1 ? file.name : file.name.slice(0, dot);
    const ext = dot === -1 ? "" : file.name.slice(dot);
    let name = `${base}-copy${ext}`;
    let n = 2;
    while (filesRef.current.some((f) => f.name === name)) {
      name = `${base}-copy${n}${ext}`;
      n++;
    }
    const copy: StudioFile = {
      ...file,
      id: uid(),
      name,
      path: name,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isMain: false,
    };
    await db.putFile(copy);
    setFiles((prev) => [...prev, copy]);
    toast.success("تم النسخ");
  }, []);

  const setMainFile = useCallback(async (id: string) => {
    const updated = filesRef.current.map((f) => ({ ...f, isMain: f.id === id }));
    await db.putFiles(updated.map(({ dirty, ...rest }) => rest));
    setFiles(updated);
    toast.success("تم تعيين الملف الرئيسي للمعاينة");
  }, []);

  const createProject = useCallback(
    async (template: string, projectName: string) => {
      const tpl = TEMPLATES[template] ?? TEMPLATES.web;
      const prefix = projectName.trim() ? projectName.trim() + "/" : "";
      const newFiles: StudioFile[] = tpl.map((t) => ({
        id: uid(),
        name: t.name,
        path: prefix + t.name,
        language: detectLanguage(t.name),
        content: t.content,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        isMain: t.name === "index.html",
      }));
      await db.putFiles(newFiles.map(({ dirty, ...rest }) => rest));
      setFiles((prev) => [...prev, ...newFiles]);
      if (newFiles[0]) setActiveFileId(newFiles[0].id);
      toast.success("تم إنشاء المشروع");
    },
    []
  );

  const updateSettings = useCallback((patch: Partial<StoredSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const resetSettings = useCallback(() => {
    setSettings(DEFAULT_SETTINGS);
    toast.success("تمت إعادة ضبط الإعدادات");
  }, []);

  const exportProject = useCallback(() => {
    const payload = {
      version: 1,
      exportedAt: new Date().toISOString(),
      files: filesRef.current.map(({ dirty, ...rest }) => rest),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mobile-code-studio-project.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("تم تصدير المشروع");
  }, []);

  const importProject = useCallback(async (file: File) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as { files?: StoredFile[] };
      if (!parsed.files || !Array.isArray(parsed.files)) {
        toast.error("ملف المشروع غير صالح");
        return;
      }
      const imported: StudioFile[] = parsed.files.map((f) => ({
        id: uid(),
        name: String(f.name ?? "file.txt"),
        path: String(f.path ?? f.name ?? "file.txt"),
        language: detectLanguage(String(f.name ?? "file.txt")),
        content: String(f.content ?? ""),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        isMain: Boolean(f.isMain),
      }));
      await db.putFiles(imported.map(({ dirty, ...rest }) => rest));
      setFiles((prev) => [...prev, ...imported]);
      if (imported[0]) setActiveFileId(imported[0].id);
      toast.success("تم استيراد المشروع");
    } catch {
      toast.error("تعذر قراءة ملف المشروع");
    }
  }, []);

  return {
    files,
    activeFileId,
    settings,
    ready,
    persistent,
    setActiveFile,
    updateContent,
    saveFile,
    saveAll,
    createFile,
    renameFile,
    deleteFile,
    duplicateFile,
    setMainFile,
    createProject,
    updateSettings,
    resetSettings,
    exportProject,
    importProject,
  };
}