import { useEffect, useState } from 'react';

export interface BatteryStatus {
  supported: boolean;
  level: number | null;
  charging: boolean | null;
}

interface BatteryManagerLike extends EventTarget {
  level: number;
  charging: boolean;
}

export function useBatteryMonitor(): BatteryStatus {
  const [battery, setBattery] = useState<BatteryStatus>({
    supported: false,
    level: null,
    charging: null,
  });

  useEffect(() => {
    let active = true;
    let manager: BatteryManagerLike | null = null;

    const nav = navigator as Navigator & {
      getBattery?: () => Promise<BatteryManagerLike>;
    };

    if (typeof nav.getBattery !== 'function') {
      return;
    }

    const sync = () => {
      if (!active || !manager) return;
      setBattery({
        supported: true,
        level: Math.round(manager.level * 100),
        charging: manager.charging,
      });
    };

    nav
      .getBattery()
      .then((bat) => {
        if (!active) return;
        manager = bat;
        sync();
        bat.addEventListener('levelchange', sync);
        bat.addEventListener('chargingchange', sync);
      })
      .catch(() => {
        if (active) {
          setBattery({ supported: false, level: null, charging: null });
        }
      });

    return () => {
      active = false;
      if (manager) {
        manager.removeEventListener('levelchange', sync);
        manager.removeEventListener('chargingchange', sync);
      }
    };
  }, []);

  return battery;
}
