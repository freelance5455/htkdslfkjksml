import { useState, useEffect, useRef, useCallback } from 'react';
import { GPSCoordinate, SplitLap } from '../types';
import { calculateHaversineDistance, calculatePace, calculateSpeedKmh, formatDuration } from '../utils/runningCalculations';

export type TrackingState = 'idle' | 'ready' | 'running' | 'paused' | 'stopped';

export interface UseGeolocationTrackerOptions {
  autoPauseEnabled?: boolean;
  voiceAnnouncementsEnabled?: boolean;
  lapIntervalMeters?: number; // default 1000m (or 400m for track)
}

export function useGeolocationTracker(options: UseGeolocationTrackerOptions = {}) {
  const {
    autoPauseEnabled = false,
    voiceAnnouncementsEnabled = true,
    lapIntervalMeters = 1000,
  } = options;

  const [trackingState, setTrackingState] = useState<TrackingState>('idle');
  const [permissionStatus, setPermissionStatus] = useState<'prompt' | 'granted' | 'denied' | 'unsupported'>('prompt');
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(null); // in meters
  const [lastPosition, setLastPosition] = useState<GPSCoordinate | null>(null);
  const [routeCoordinates, setRouteCoordinates] = useState<GPSCoordinate[]>([]);
  
  // Running telemetry
  const [distanceMeters, setDistanceMeters] = useState<number>(0);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [currentPace, setCurrentPace] = useState<string>('--:--');
  const [averagePace, setAveragePace] = useState<string>('--:--');
  const [currentSpeedKmh, setCurrentSpeedKmh] = useState<number>(0);
  const [splits, setSplits] = useState<SplitLap[]>([]);
  const [isSimulated, setIsSimulated] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Refs for timer and watcher
  const watchIdRef = useRef<number | null>(null);
  const timerIntervalRef = useRef<number | null>(null);
  const simulationIntervalRef = useRef<number | null>(null);
  
  const currentLapStartMetersRef = useRef<number>(0);
  const currentLapStartSecondsRef = useRef<number>(0);
  const lastVoiceAnnouncementKmRef = useRef<number>(0);
  const consecutiveZeroSpeedRef = useRef<number>(0);
  const isAutoPausedRef = useRef<boolean>(false);

  // Voice speech announcement utility
  const announceVoice = useCallback((text: string) => {
    if (!voiceAnnouncementsEnabled) return;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.05;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn('Speech synthesis failed', e);
      }
    }
  }, [voiceAnnouncementsEnabled]);

  // Check geolocation permission on mount
  useEffect(() => {
    if (!navigator.geolocation) {
      setPermissionStatus('unsupported');
      return;
    }

    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'geolocation' as PermissionName }).then((res) => {
        setPermissionStatus(res.state as any);
        res.onchange = () => {
          setPermissionStatus(res.state as any);
        };
      }).catch(() => {
        setPermissionStatus('prompt');
      });
    }
  }, []);

  // Request GPS position once to get readiness
  const requestGPSPermission = useCallback(() => {
    if (!navigator.geolocation) {
      setPermissionStatus('unsupported');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setPermissionStatus('granted');
        setGpsAccuracy(pos.coords.accuracy);
        const coord: GPSCoordinate = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          timestamp: pos.timestamp,
          speed: pos.coords.speed,
        };
        setLastPosition(coord);
        setErrorMessage(null);
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          setPermissionStatus('denied');
          setErrorMessage('Location permission was denied. Please allow location access or use simulated test mode.');
        } else {
          setErrorMessage('Waiting for GPS satellite lock...');
        }
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }, []);

  // Handle GPS location update
  const handleNewPosition = useCallback((pos: GeolocationPosition) => {
    const { latitude, longitude, accuracy, speed } = pos.coords;
    setGpsAccuracy(accuracy);
    setErrorMessage(null);

    // Reject very inaccurate fixes (>45m) to avoid GPS jumping
    if (accuracy > 45) {
      return;
    }

    const newCoord: GPSCoordinate = {
      lat: latitude,
      lng: longitude,
      timestamp: pos.timestamp,
      speed,
    };

    setLastPosition(newCoord);

    if (trackingState !== 'running') return;

    setRouteCoordinates((prev) => {
      if (prev.length === 0) {
        return [newCoord];
      }

      const prevCoord = prev[prev.length - 1];
      const deltaMeters = calculateHaversineDistance(
        prevCoord.lat,
        prevCoord.lng,
        newCoord.lat,
        newCoord.lng
      );

      // Filter out GPS drift jitter (< 1.5 meters)
      if (deltaMeters < 1.5) {
        return prev;
      }

      // Calculate instantaneous speed and pace
      const timeDeltaSec = (newCoord.timestamp - prevCoord.timestamp) / 1000;
      let instantSpeedKmh = 0;
      if (timeDeltaSec > 0) {
        instantSpeedKmh = (deltaMeters / 1000) / (timeDeltaSec / 3600);
      } else if (speed !== null && speed !== undefined && speed >= 0) {
        instantSpeedKmh = speed * 3.6;
      }

      // Check auto-pause condition if stationary
      if (autoPauseEnabled) {
        if (instantSpeedKmh < 1.2) {
          consecutiveZeroSpeedRef.current += 1;
          if (consecutiveZeroSpeedRef.current >= 3 && !isAutoPausedRef.current) {
            isAutoPausedRef.current = true;
            announceVoice('Auto paused');
          }
        } else {
          if (isAutoPausedRef.current) {
            isAutoPausedRef.current = false;
            announceVoice('Auto resumed');
          }
          consecutiveZeroSpeedRef.current = 0;
        }
      }

      if (isAutoPausedRef.current) {
        return prev;
      }

      setCurrentSpeedKmh(Number(instantSpeedKmh.toFixed(1)));
      if (instantSpeedKmh > 2.0 && instantSpeedKmh < 45) {
        const instantPaceSecKm = 3600 / instantSpeedKmh;
        setCurrentPace(calculatePace(deltaMeters, timeDeltaSec));
      }

      setDistanceMeters((prevDist) => {
        const nextDist = prevDist + deltaMeters;
        
        // Check for lap split
        const lapDist = nextDist - currentLapStartMetersRef.current;
        if (lapDist >= lapIntervalMeters) {
          const lapDuration = elapsedSeconds - currentLapStartSecondsRef.current;
          const lapNum = splits.length + 1;
          const lapPace = calculatePace(lapDist, lapDuration);
          const lapSpeed = calculateSpeedKmh(lapDist, lapDuration);

          setSplits((prevSplits) => [
            ...prevSplits,
            {
              lapNumber: lapNum,
              distanceMeters: Math.round(lapDist),
              durationSeconds: lapDuration,
              pace: lapPace,
              speedKmh: lapSpeed,
            },
          ]);

          currentLapStartMetersRef.current = nextDist;
          currentLapStartSecondsRef.current = elapsedSeconds;

          announceVoice(`Split ${lapNum}. Pace ${lapPace}.`);
        }

        // Voice announcement at every 1.0 km
        const currentKm = Math.floor(nextDist / 1000);
        if (currentKm > lastVoiceAnnouncementKmRef.current && currentKm > 0) {
          lastVoiceAnnouncementKmRef.current = currentKm;
          const avgP = calculatePace(nextDist, elapsedSeconds);
          announceVoice(`${currentKm} kilometer completed. Average pace ${avgP}.`);
        }

        return nextDist;
      });

      return [...prev, newCoord];
    });
  }, [trackingState, autoPauseEnabled, announceVoice, lapIntervalMeters, elapsedSeconds, splits.length]);

  // Stopwatch timer interval
  useEffect(() => {
    if (trackingState === 'running') {
      timerIntervalRef.current = window.setInterval(() => {
        if (!isAutoPausedRef.current) {
          setElapsedSeconds((prev) => {
            const nextSec = prev + 1;
            // update average pace
            if (distanceMeters > 20) {
              setAveragePace(calculatePace(distanceMeters, nextSec));
            }
            return nextSec;
          });
        }
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [trackingState, distanceMeters]);

  // Start watching GPS when state enters running
  const startTracking = useCallback(() => {
    setErrorMessage(null);
    setTrackingState('running');
    announceVoice('Run started. Stay disciplined.');

    if (isSimulated) {
      // Start simulation loop (running around a 400m track)
      let centerLat = lastPosition?.lat || 28.6139;
      let centerLng = lastPosition?.lng || 77.2090;
      let angle = 0;
      const radiusLat = 0.0018; // approx 200m radius
      const radiusLng = 0.0018;

      simulationIntervalRef.current = window.setInterval(() => {
        angle += 0.08;
        const lat = centerLat + Math.sin(angle) * radiusLat;
        const lng = centerLng + Math.cos(angle) * radiusLng;
        const fakePos = {
          coords: {
            latitude: lat,
            longitude: lng,
            accuracy: 4,
            altitude: 120,
            altitudeAccuracy: 2,
            heading: (angle * 180) / Math.PI,
            speed: 3.4, // ~12.2 km/h (~4:55 min/km pace)
          },
          timestamp: Date.now(),
        } as any;
        handleNewPosition(fakePos);
      }, 1000);
      return;
    }

    if (navigator.geolocation) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        handleNewPosition,
        (err) => {
          console.warn('GPS watch error:', err);
          if (err.code === err.PERMISSION_DENIED) {
            setPermissionStatus('denied');
            setErrorMessage('Location permission denied. Switching to test mode is available.');
          } else {
            setErrorMessage('Weak GPS signal. Finding open sky satellite link...');
          }
        },
        {
          enableHighAccuracy: true,
          maximumAge: 1000,
          timeout: 10000,
        }
      );
    } else {
      setPermissionStatus('unsupported');
    }
  }, [handleNewPosition, isSimulated, lastPosition, announceVoice]);

  const pauseTracking = useCallback(() => {
    setTrackingState('paused');
    announceVoice('Run paused.');
  }, [announceVoice]);

  const resumeTracking = useCallback(() => {
    setTrackingState('running');
    announceVoice('Run resumed.');
  }, [announceVoice]);

  const manualLap = useCallback(() => {
    if (distanceMeters < 5) return;
    const lapDist = distanceMeters - currentLapStartMetersRef.current;
    const lapDuration = elapsedSeconds - currentLapStartSecondsRef.current;
    const lapNum = splits.length + 1;
    const lapPace = calculatePace(lapDist, lapDuration);
    const lapSpeed = calculateSpeedKmh(lapDist, lapDuration);

    setSplits((prev) => [
      ...prev,
      {
        lapNumber: lapNum,
        distanceMeters: Math.round(lapDist),
        durationSeconds: lapDuration,
        pace: lapPace,
        speedKmh: lapSpeed,
      },
    ]);

    currentLapStartMetersRef.current = distanceMeters;
    currentLapStartSecondsRef.current = elapsedSeconds;
    announceVoice(`Manual lap ${lapNum}. Pace ${lapPace}.`);
  }, [distanceMeters, elapsedSeconds, splits.length, announceVoice]);

  const stopTracking = useCallback(() => {
    setTrackingState('stopped');
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (simulationIntervalRef.current !== null) {
      clearInterval(simulationIntervalRef.current);
      simulationIntervalRef.current = null;
    }
    if (timerIntervalRef.current !== null) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    // Finalize last lap split if > 50m
    const finalLapDist = distanceMeters - currentLapStartMetersRef.current;
    if (finalLapDist > 50) {
      const finalLapDur = elapsedSeconds - currentLapStartSecondsRef.current;
      setSplits((prev) => [
        ...prev,
        {
          lapNumber: prev.length + 1,
          distanceMeters: Math.round(finalLapDist),
          durationSeconds: finalLapDur,
          pace: calculatePace(finalLapDist, finalLapDur),
          speedKmh: calculateSpeedKmh(finalLapDist, finalLapDur),
        },
      ]);
    }

    announceVoice(`Run completed. Total distance ${(distanceMeters / 1000).toFixed(2)} kilometers.`);
  }, [distanceMeters, elapsedSeconds, announceVoice]);

  const resetTracker = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (simulationIntervalRef.current !== null) {
      clearInterval(simulationIntervalRef.current);
      simulationIntervalRef.current = null;
    }
    if (timerIntervalRef.current !== null) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    setTrackingState('idle');
    setDistanceMeters(0);
    setElapsedSeconds(0);
    setCurrentPace('--:--');
    setAveragePace('--:--');
    setCurrentSpeedKmh(0);
    setSplits([]);
    setRouteCoordinates([]);
    currentLapStartMetersRef.current = 0;
    currentLapStartSecondsRef.current = 0;
    lastVoiceAnnouncementKmRef.current = 0;
    isAutoPausedRef.current = false;
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current);
      if (simulationIntervalRef.current !== null) clearInterval(simulationIntervalRef.current);
      if (timerIntervalRef.current !== null) clearInterval(timerIntervalRef.current);
    };
  }, []);

  return {
    trackingState,
    permissionStatus,
    gpsAccuracy,
    lastPosition,
    routeCoordinates,
    distanceMeters,
    distanceKm: Number((distanceMeters / 1000).toFixed(3)),
    elapsedSeconds,
    elapsedFormatted: formatDuration(elapsedSeconds),
    currentPace,
    averagePace,
    currentSpeedKmh,
    splits,
    isSimulated,
    errorMessage,
    setIsSimulated,
    requestGPSPermission,
    startTracking,
    pauseTracking,
    resumeTracking,
    manualLap,
    stopTracking,
    resetTracker,
  };
}
