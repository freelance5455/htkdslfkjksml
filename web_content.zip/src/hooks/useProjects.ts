import { useState, useCallback, useEffect } from "react";
import type { Project, AnalyzedRequest, ProjectStatus, OutputFormat, Platform, ContentType } from "@/types";
import {
  getProjects, saveProject, deleteProject as deleteProjectFromStorage,
  getProject
} from "@/lib/storage";
import {
  generateBriefAsync, generateScriptAsync, generateStoryboardAsync,
  generateMediaPlan, createWorkflowTasks, getWelcomeChatMessage
} from "@/lib/orchestrator";
import { generateFullProjectFast, generateAllMediaFast, type FastGeneratorOptions } from "@/lib/fastGenerator";
import { analyzeRequestAsync } from "@/lib/analyzer";
import { generateId } from "@/lib/utils";
import { CONTENT_TYPE_LABELS } from "@/constants";

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>(getProjects);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(() => {
    setProjects(getProjects());
  }, []);

  useEffect(() => {
    const handleChanged = () => {
      setProjects(getProjects());
    };
    window.addEventListener("acs_projects_changed", handleChanged);
    window.addEventListener("storage", handleChanged);
    return () => {
      window.removeEventListener("acs_projects_changed", handleChanged);
      window.removeEventListener("storage", handleChanged);
    };
  }, []);

  const createProject = useCallback(async (
    input: string,
    overrides?: {
      platform?: Platform;
      contentType?: ContentType;
      outputFormat?: OutputFormat;
      aspectRatio?: "16:9" | "9:16" | "1:1" | "4:5";
    }
  ): Promise<Project> => {
    setLoading(true);
    const analyzed = await analyzeRequestAsync(input);
    const now = new Date().toISOString();

    const targetPlatform = (overrides?.platform && overrides.platform !== "GENERAL")
      ? overrides.platform
      : analyzed.platform;

    const targetContentType = overrides?.contentType || (
      overrides?.aspectRatio === "9:16" ? "SHORT" :
      targetPlatform === "TIKTOK" ? "TIKTOK_VIDEO" :
      targetPlatform === "INSTAGRAM" && overrides?.aspectRatio === "9:16" ? "REEL" :
      targetPlatform === "INSTAGRAM" && overrides?.aspectRatio === "1:1" ? "INSTAGRAM_POST" :
      analyzed.contentType
    );

    const targetOutputFormat = overrides?.outputFormat || (
      overrides?.aspectRatio === "9:16" || targetPlatform === "TIKTOK" || targetContentType === "SHORT" || targetContentType === "REEL"
        ? "SHORTS_1080p"
        : overrides?.aspectRatio === "1:1" || targetContentType === "INSTAGRAM_POST"
        ? "INSTAGRAM_SQUARE"
        : "YOUTUBE_1080p"
    );

    const project: Project = {
      id: generateId(),
      title: analyzed.topic && analyzed.topic.length > 5
        ? analyzed.topic.split(" ").slice(0, 6).join(" ")
        : `Projeto ${CONTENT_TYPE_LABELS[targetContentType] || "Vídeo"}`,
      description: input,
      status: "BRIEFING",
      contentType: targetContentType,
      platform: targetPlatform,
      outputFormats: [targetOutputFormat],
      analyzedRequest: analyzed,
      assets: [],
      characters: [],
      tasks: [],
      versions: [],
      conversation: [],
      tags: analyzed.requirements,
      settings: {
        language: analyzed.language,
        outputFormat: targetOutputFormat,
        targetDuration: analyzed.duration || (overrides?.aspectRatio === "9:16" ? 60 : 120),
        autoEdit: true,
        autoSubtitles: true,
        watermark: false,
      },
      createdAt: now,
      updatedAt: now,
    };

    project.brief = await generateBriefAsync(project);
    project.tasks = createWorkflowTasks(project);
    project.conversation = [getWelcomeChatMessage(project)];
    saveProject(project);
    setProjects(getProjects());
    setLoading(false);
    return project;
  }, []);

  // Fast one-click project generator creating video, images, and audio in parallel
  const createProjectFast = useCallback(async (
    input: string,
    options?: FastGeneratorOptions
  ): Promise<Project> => {
    setLoading(true);
    try {
      const project = await generateFullProjectFast(input, options);
      setProjects(getProjects());
      return project;
    } finally {
      setLoading(false);
    }
  }, []);

  // Fast media generation for existing project
  const generateProjectMediaFast = useCallback(async (
    project: Project,
    options?: FastGeneratorOptions,
    onProgress?: (stage: string, percent: number) => void
  ): Promise<Project> => {
    setLoading(true);
    try {
      const updated = await generateAllMediaFast(project, options, onProgress);
      setProjects(getProjects());
      return updated;
    } finally {
      setLoading(false);
    }
  }, []);

  const advanceWorkflow = useCallback(async (projectId: string, step: ProjectStatus) => {
    const project = getProject(projectId);
    if (!project) return;

    const updated = { ...project, status: step, updatedAt: new Date().toISOString() };

    if (step === "SCRIPTING" && !updated.script) {
      updated.script = await generateScriptAsync(updated);
    }
    if (step === "STORYBOARDING" && !updated.storyboard) {
      updated.storyboard = await generateStoryboardAsync(updated);
    }
    if (step === "MEDIA_PLANNING" && !updated.mediaPlan) {
      updated.mediaPlan = generateMediaPlan(updated);
    }

    saveProject(updated);
    setProjects(getProjects());
  }, []);

  const updateProject = useCallback((project: Project) => {
    saveProject(project);
    setProjects(getProjects());
  }, []);

  const deleteProject = useCallback((id: string) => {
    deleteProjectFromStorage(id);
    setProjects(getProjects());
  }, []);

  return {
    projects,
    loading,
    createProject,
    createProjectFast,
    generateProjectMediaFast,
    advanceWorkflow,
    updateProject,
    deleteProject,
    refresh,
  };
}
