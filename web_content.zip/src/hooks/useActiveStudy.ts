/** يسجل الوقت النشط فقط؛ يفرغ الثواني عند إخفاء الصفحة أو مغادرتها، ويتوقف عند الخمول التفاعلي. */
import { useEffect, useRef } from 'react';
import { recordStudySeconds } from '../services/economy';

const INACTIVITY_LIMIT_MS = 5 * 60_000;

export function useActiveStudy(
  active: boolean,
  subjectId: string | undefined,
  kind: 'video' | 'interactive' | 'session',
): void {
  const activeRef = useRef(active);
  activeRef.current = active;

  useEffect(() => {
    if (!active || !subjectId) return undefined;
    let lastActivityAt = Date.now();
    let lastTickAt = Date.now();

    const markActivity = () => {
      lastActivityAt = Date.now();
    };

    const flush = (wasVisible = false) => {
      const now = Date.now();
      const activeUntil = kind === 'interactive' ? Math.min(now, lastActivityAt + INACTIVITY_LIMIT_MS) : now;
      const elapsed = Math.min(10, Math.floor((activeUntil - lastTickAt) / 1000));
      lastTickAt = now;
      const visible = wasVisible || document.visibilityState === 'visible';
      if (elapsed <= 0 || !visible || !activeRef.current) return;
      // الجلسة المعلنة تستمر ما دامت ظاهرة وغير موقوفة؛ النشاط التفاعلي يتوقف بعد خمس دقائق من الخمول.
      void recordStudySeconds(subjectId, elapsed).catch((error: unknown) => console.error('تعذّر حفظ زمن الدراسة', error));
    };

    const interval = window.setInterval(() => flush(), 5000);
    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') flush(true);
      else {
        lastTickAt = Date.now();
        markActivity();
      }
    };

    document.addEventListener('pointermove', markActivity, { passive: true });
    document.addEventListener('pointerdown', markActivity, { passive: true });
    document.addEventListener('keydown', markActivity);
    document.addEventListener('touchstart', markActivity, { passive: true });
    document.addEventListener('scroll', markActivity, { passive: true, capture: true });
    document.addEventListener('wheel', markActivity, { passive: true });
    document.addEventListener('input', markActivity, true);
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      window.clearInterval(interval);
      // لا نضيف وقتاً بعد الإيقاف؛ أما مغادرة الصفحة النشطة فتُفرغ الثواني المتراكمة.
      flush();
      document.removeEventListener('pointermove', markActivity);
      document.removeEventListener('pointerdown', markActivity);
      document.removeEventListener('keydown', markActivity);
      document.removeEventListener('touchstart', markActivity);
      document.removeEventListener('scroll', markActivity, true);
      document.removeEventListener('wheel', markActivity);
      document.removeEventListener('input', markActivity, true);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [active, subjectId, kind]);
}
