import { useCallback, useEffect, useRef, useState } from 'react';
import type { SpeechLanguage } from '../types';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike extends Event {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionErrorEventLike extends Event {
  error: string;
  message?: string;
}

interface SpeechRecognitionInstanceLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onsoundstart: (() => void) | null;
  onspeechstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstanceLike;

function getSpeechRecognitionCtor(): SpeechRecognitionConstructor | null {
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

const AUTO_SEND_SILENCE_MS = 1200;

export function useVoiceAssistant(options: {
  speechLanguage: SpeechLanguage;
  voiceEnabled: boolean;
  speechSpeed: number;
  handsFreeMode: boolean;
  onLiveTranscript?: (text: string) => void;
  onAutoSend?: (transcript: string) => void;
  onSpeakEnd?: () => void;
}) {
  const {
    speechLanguage,
    voiceEnabled,
    speechSpeed,
    handsFreeMode,
    onLiveTranscript,
    onAutoSend,
    onSpeakEnd,
  } = options;

  const [sttSupported] = useState(() =>
    typeof window !== 'undefined' ? Boolean(getSpeechRecognitionCtor()) : false,
  );
  const [ttsSupported] = useState(() =>
    typeof window !== 'undefined' ? 'speechSynthesis' in window : false,
  );

  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [autoSendPending, setAutoSendPending] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [audioActivity, setAudioActivity] = useState(0.15);

  const recognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const recognitionTokenRef = useRef(0);
  const voicesRef = useRef<SpeechSynthesisVoice[]>([]);
  const silenceTimerRef = useRef<number | null>(null);
  const manualStopRef = useRef(false);
  const manuallyCancelledTtsRef = useRef(false);
  const collectedFinalRef = useRef('');
  const latestInterimRef = useRef('');
  const submittedUtteranceRef = useRef(false);
  const lastSentGuardRef = useRef<{ text: string; timestamp: number }>({
    text: '',
    timestamp: 0,
  });

  const handsFreeRef = useRef(handsFreeMode);
  const onLiveTranscriptRef = useRef(onLiveTranscript);
  const onAutoSendRef = useRef(onAutoSend);
  const onSpeakEndRef = useRef(onSpeakEnd);

  handsFreeRef.current = handsFreeMode;
  onLiveTranscriptRef.current = onLiveTranscript;
  onAutoSendRef.current = onAutoSend;
  onSpeakEndRef.current = onSpeakEnd;

  const clearSilenceTimer = useCallback(() => {
    if (silenceTimerRef.current !== null) {
      window.clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    setAutoSendPending(false);
  }, []);

  useEffect(() => {
    if (!ttsSupported) return;
    const loadVoices = () => {
      voicesRef.current = window.speechSynthesis.getVoices();
    };
    loadVoices();
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
      window.speechSynthesis.cancel();
    };
  }, [ttsSupported]);

  useEffect(() => {
    return () => {
      recognitionTokenRef.current += 1;
      clearSilenceTimer();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // Ignore
        }
      }
    };
  }, [clearSilenceTimer]);

  const stopSpeaking = useCallback(() => {
    if (!ttsSupported) return;
    manuallyCancelledTtsRef.current = true;
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setAudioActivity(0.15);
  }, [ttsSupported]);

  const stopListening = useCallback(() => {
    manualStopRef.current = true;
    recognitionTokenRef.current += 1;
    clearSilenceTimer();
    collectedFinalRef.current = '';
    latestInterimRef.current = '';
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore
      }
    }
    setIsListening(false);
    setInterimTranscript('');
    setAudioActivity(0.15);
  }, [clearSilenceTimer]);

  // Stop active listening and cancel pending auto-send when Hands-Free Mode is turned OFF
  useEffect(() => {
    if (!handsFreeMode) {
      clearSilenceTimer();
      if (isListening) {
        stopListening();
      }
    }
  }, [handsFreeMode, clearSilenceTimer, isListening, stopListening]);

  const clearTranscript = useCallback(() => {
    collectedFinalRef.current = '';
    latestInterimRef.current = '';
    setInterimTranscript('');
    setFinalTranscript('');
  }, []);

  const flushAutoSend = useCallback(() => {
    const candidate = `${collectedFinalRef.current} ${latestInterimRef.current}`
      .replace(/\s+/g, ' ')
      .trim();

    if (
      manualStopRef.current ||
      !handsFreeRef.current ||
      submittedUtteranceRef.current ||
      !candidate
    ) {
      return;
    }

    const now = Date.now();
    if (
      candidate === lastSentGuardRef.current.text &&
      now - lastSentGuardRef.current.timestamp < 2000
    ) {
      return;
    }

    submittedUtteranceRef.current = true;
    recognitionTokenRef.current += 1;
    lastSentGuardRef.current = { text: candidate, timestamp: now };
    collectedFinalRef.current = '';
    latestInterimRef.current = '';
    clearSilenceTimer();

    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore
      }
    }
    setIsListening(false);
    setInterimTranscript('');
    setAudioActivity(0.15);

    onAutoSendRef.current?.(candidate);
  }, [clearSilenceTimer]);

  const scheduleAutoSend = useCallback(() => {
    if (!handsFreeRef.current || manualStopRef.current) return;
    clearSilenceTimer();
    setAutoSendPending(true);
    silenceTimerRef.current = window.setTimeout(() => {
      silenceTimerRef.current = null;
      setAutoSendPending(false);
      flushAutoSend();
    }, AUTO_SEND_SILENCE_MS);
  }, [clearSilenceTimer, flushAutoSend]);

  const startListening = useCallback(async () => {
    setVoiceError(null);
    clearSilenceTimer();

    if (!sttSupported) {
      setVoiceError(
        'Voice input (Speech Recognition) is not supported in this browser. Try Android Chrome or type your message.',
      );
      return false;
    }

    stopSpeaking();

    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor) return false;

    const token = ++recognitionTokenRef.current;

    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {
        // Ignore
      }
    }

    const recognition = new Ctor();
    recognition.lang = speechLanguage;
    recognition.continuous = handsFreeRef.current;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    manualStopRef.current = false;
    submittedUtteranceRef.current = false;
    collectedFinalRef.current = '';
    latestInterimRef.current = '';

    recognition.onstart = () => {
      if (token !== recognitionTokenRef.current) return;
      setIsListening(true);
      setInterimTranscript('');
      setFinalTranscript('');
      setAudioActivity(0.45);
    };

    recognition.onsoundstart = () => {
      if (token !== recognitionTokenRef.current) return;
      setAudioActivity(0.85);
    };

    recognition.onspeechstart = () => {
      if (token !== recognitionTokenRef.current) return;
      // User resumed speaking during the 1.2s delay -> cancel pending auto-send
      if (silenceTimerRef.current !== null) {
        clearSilenceTimer();
      }
      setAudioActivity(0.9);
    };

    recognition.onresult = (event) => {
      if (token !== recognitionTokenRef.current) return;
      // Cancel any pending auto-send whenever new speech arrives
      clearSilenceTimer();
      submittedUtteranceRef.current = false;

      let finalText = '';
      let interimText = '';

      for (let i = 0; i < event.results.length; i++) {
        const result = event.results[i];
        const piece = result[0]?.transcript ?? '';
        if (result.isFinal) {
          finalText += `${piece} `;
        } else {
          interimText += `${piece} `;
        }
      }

      const cleanFinal = finalText.replace(/\s+/g, ' ').trim();
      const cleanInterim = interimText.replace(/\s+/g, ' ').trim();
      const combined = `${cleanFinal} ${cleanInterim}`.replace(/\s+/g, ' ').trim();

      collectedFinalRef.current = cleanFinal;
      latestInterimRef.current = cleanInterim;
      setInterimTranscript(combined);
      setAudioActivity(combined ? 0.92 : 0.45);

      if (combined) {
        onLiveTranscriptRef.current?.(combined);
      }

      if (handsFreeRef.current && combined && !manualStopRef.current) {
        scheduleAutoSend();
      }
    };

    recognition.onerror = (event) => {
      if (token !== recognitionTokenRef.current) return;
      clearSilenceTimer();
      setIsListening(false);
      setAudioActivity(0.15);

      switch (event.error) {
        case 'not-allowed':
        case 'service-not-allowed':
          manualStopRef.current = true;
          setVoiceError(
            'Microphone permission was denied. Please allow microphone access in your browser site settings.',
          );
          break;
        case 'audio-capture':
          manualStopRef.current = true;
          setVoiceError('No working microphone was detected on this device.');
          break;
        case 'no-speech':
          if (!manualStopRef.current) {
            setVoiceError(
              handsFreeRef.current
                ? 'No speech detected. Tap the microphone to resume listening.'
                : 'No speech detected. Tap the microphone and speak clearly.',
            );
          }
          manualStopRef.current = true;
          break;
        case 'network':
          manualStopRef.current = true;
          setVoiceError(
            'Speech recognition requires an active internet connection on this browser.',
          );
          break;
        case 'aborted':
          break;
        default:
          manualStopRef.current = true;
          setVoiceError(`Voice recognition error (${event.error}). Please try again.`);
      }
    };

    recognition.onend = () => {
      if (token !== recognitionTokenRef.current) return;
      setIsListening(false);
      setInterimTranscript('');
      setAudioActivity(0.15);

      if (manualStopRef.current) {
        return;
      }

      const pendingText = `${collectedFinalRef.current} ${latestInterimRef.current}`
        .replace(/\s+/g, ' ')
        .trim();

      if (!handsFreeRef.current) {
        // Hands-Free Mode OFF: leave recognized text in input for manual review/send
        if (pendingText) {
          setFinalTranscript(pendingText);
        }
        return;
      }

      // Hands-Free Mode ON: wait ~1.2s after speech ends before auto-sending
      if (pendingText && !submittedUtteranceRef.current && silenceTimerRef.current === null) {
        scheduleAutoSend();
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
      return true;
    } catch {
      setIsListening(false);
      setVoiceError('Could not start microphone listener. Please tap again.');
      return false;
    }
  }, [clearSilenceTimer, scheduleAutoSend, speechLanguage, stopSpeaking, sttSupported]);

  const speakText = useCallback(
    (rawText: string) => {
      if (!ttsSupported || !voiceEnabled) return false;
      const cleanText = rawText
        .replace(/[*_`#>-]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (!cleanText) return false;

      manuallyCancelledTtsRef.current = false;
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(cleanText);
      const hasDevanagari = /[\u0900-\u097F]/.test(cleanText);
      const voices =
        voicesRef.current.length > 0
          ? voicesRef.current
          : window.speechSynthesis.getVoices();

      if (hasDevanagari) {
        const hiVoice =
          voices.find((v) => v.lang.toLowerCase().startsWith('hi')) ??
          voices.find((v) => v.lang.toLowerCase().includes('in'));
        if (hiVoice) utterance.voice = hiVoice;
        utterance.lang = 'hi-IN';
      } else {
        const enVoice =
          voices.find((v) => v.lang.toLowerCase() === 'en-in') ??
          voices.find((v) => v.lang.toLowerCase().startsWith('en-'));
        if (enVoice) utterance.voice = enVoice;
        utterance.lang = speechLanguage === 'hi-IN' ? 'en-IN' : speechLanguage;
      }

      utterance.rate = Math.min(1.8, Math.max(0.6, speechSpeed));
      utterance.pitch = 1.0;

      utterance.onstart = () => {
        setIsSpeaking(true);
        setAudioActivity(0.8);
      };
      utterance.onend = () => {
        setIsSpeaking(false);
        setAudioActivity(0.15);
        if (!manuallyCancelledTtsRef.current) {
          onSpeakEndRef.current?.();
        }
      };
      utterance.onerror = () => {
        setIsSpeaking(false);
        setAudioActivity(0.15);
        if (!manuallyCancelledTtsRef.current) {
          onSpeakEndRef.current?.();
        }
      };

      window.speechSynthesis.speak(utterance);
      return true;
    },
    [speechLanguage, speechSpeed, ttsSupported, voiceEnabled],
  );

  return {
    sttSupported,
    ttsSupported,
    isListening,
    isSpeaking,
    autoSendPending,
    interimTranscript,
    finalTranscript,
    voiceError,
    audioActivity,
    setVoiceError,
    startListening,
    stopListening,
    speakText,
    stopSpeaking,
    clearTranscript,
  };
}
