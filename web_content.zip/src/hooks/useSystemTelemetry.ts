import { useEffect, useRef, useState } from 'react';
import { SystemTelemetry, TelemetrySample } from '../types';

interface BatteryManagerLike extends EventTarget {
  level: number;
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
}

interface NavigatorWithCapabilities extends Navigator {
  getBattery?: () => Promise<BatteryManagerLike>;
  deviceMemory?: number;
  connection?: {
    type?: string;
    effectiveType?: string;
    downlink?: number;
    rtt?: number;
    addEventListener?: (type: string, listener: () => void) => void;
    removeEventListener?: (type: string, listener: () => void) => void;
  };
}

interface PerformanceWithMemory extends Performance {
  memory?: {
    usedJSHeapSize: number;
    totalJSHeapSize: number;
    jsHeapSizeLimit: number;
  };
}

function summarizeUserAgent(ua: string): string {
  if (/Android/i.test(ua)) return 'Android Mobile WebView / Browser';
  if (/iPhone|iPad/i.test(ua)) return 'iOS Mobile Browser';
  if (/Mac OS X/i.test(ua)) return 'macOS Desktop';
  if (/Windows/i.test(ua)) return 'Windows Desktop';
  if (/Linux/i.test(ua)) return 'Linux Desktop';
  return 'Web Runtime';
}

export function useSystemTelemetry(enabled: boolean): SystemTelemetry {
  const nav = navigator as NavigatorWithCapabilities;
  const perf = performance as PerformanceWithMemory;

  const [telemetry, setTelemetry] = useState<SystemTelemetry>(() => ({
    fps: 60,
    frameTimeMs: 16.7,
    estimatedRefreshHz: 60,
    jsHeapUsedMb: perf.memory ? Number((perf.memory.usedJSHeapSize / 1048576).toFixed(1)) : null,
    jsHeapLimitMb: perf.memory ? Number((perf.memory.jsHeapSizeLimit / 1048576).toFixed(0)) : null,
    jsHeapPercent: perf.memory
      ? Math.round((perf.memory.usedJSHeapSize / perf.memory.jsHeapSizeLimit) * 100)
      : null,
    deviceMemoryGb: typeof nav.deviceMemory === 'number' ? nav.deviceMemory : null,
    cpuCores: navigator.hardwareConcurrency || 4,
    mainThreadDriftMs: 0,
    batteryLevel: null,
    batteryCharging: null,
    batteryChargingTime: null,
    batteryDischargingTime: null,
    batterySupported: typeof nav.getBattery === 'function',
    connectionType: nav.connection?.type ?? null,
    effectiveType: nav.connection?.effectiveType ?? null,
    downlinkMbps: typeof nav.connection?.downlink === 'number' ? nav.connection.downlink : null,
    networkRttMs: typeof nav.connection?.rtt === 'number' ? nav.connection.rtt : null,
    online: navigator.onLine,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    pixelRatio: window.devicePixelRatio || 1,
    platform: navigator.platform || 'Unknown',
    userAgentSummary: summarizeUserAgent(navigator.userAgent),
    history: [],
  }));

  const frameCountRef = useRef(0);
  const lastSampleTimeRef = useRef(performance.now());
  const peakHzRef = useRef(60);
  const latestDriftRef = useRef(0);

  // Real Battery API listener
  useEffect(() => {
    let batteryRef: BatteryManagerLike | null = null;
    let mounted = true;

    const syncBattery = () => {
      if (!mounted || !batteryRef) return;
      setTelemetry((prev) => ({
        ...prev,
        batterySupported: true,
        batteryLevel: Math.round(batteryRef!.level * 100),
        batteryCharging: batteryRef!.charging,
        batteryChargingTime: Number.isFinite(batteryRef!.chargingTime)
          ? batteryRef!.chargingTime
          : null,
        batteryDischargingTime: Number.isFinite(batteryRef!.dischargingTime)
          ? batteryRef!.dischargingTime
          : null,
      }));
    };

    if (typeof nav.getBattery === 'function') {
      nav
        .getBattery()
        .then((battery) => {
          if (!mounted) return;
          batteryRef = battery;
          syncBattery();
          battery.addEventListener('levelchange', syncBattery);
          battery.addEventListener('chargingchange', syncBattery);
        })
        .catch(() => {
          if (!mounted) return;
          setTelemetry((prev) => ({ ...prev, batterySupported: false }));
        });
    }

    return () => {
      mounted = false;
      if (batteryRef) {
        batteryRef.removeEventListener('levelchange', syncBattery);
        batteryRef.removeEventListener('chargingchange', syncBattery);
      }
    };
  }, [nav]);

  // Network Info & Online listeners
  useEffect(() => {
    const updateNet = () => {
      setTelemetry((prev) => ({
        ...prev,
        online: navigator.onLine,
        connectionType: nav.connection?.type ?? prev.connectionType,
        effectiveType: nav.connection?.effectiveType ?? prev.effectiveType,
        downlinkMbps:
          typeof nav.connection?.downlink === 'number'
            ? nav.connection.downlink
            : prev.downlinkMbps,
        networkRttMs:
          typeof nav.connection?.rtt === 'number' ? nav.connection.rtt : prev.networkRttMs,
      }));
    };

    window.addEventListener('online', updateNet);
    window.addEventListener('offline', updateNet);
    nav.connection?.addEventListener?.('change', updateNet);

    return () => {
      window.removeEventListener('online', updateNet);
      window.removeEventListener('offline', updateNet);
      nav.connection?.removeEventListener?.('change', updateNet);
    };
  }, [nav]);

  // Real FPS via requestAnimationFrame + Main-Thread Event Loop Drift Probe
  useEffect(() => {
    if (!enabled) return;

    let rafId = 0;
    let driftTimer = 0;
    let expectedDriftAt = performance.now() + 500;

    const measureDrift = () => {
      const now = performance.now();
      latestDriftRef.current = Math.max(0, Number((now - expectedDriftAt).toFixed(1)));
      expectedDriftAt = now + 500;
      driftTimer = window.setTimeout(measureDrift, 500);
    };
    driftTimer = window.setTimeout(measureDrift, 500);

    const tick = (now: number) => {
      frameCountRef.current += 1;
      const elapsed = now - lastSampleTimeRef.current;

      if (elapsed >= 750) {
        const measuredFps = Math.max(
          1,
          Math.round((frameCountRef.current * 1000) / elapsed)
        );
        const frameTimeMs = Number((1000 / measuredFps).toFixed(1));
        if (measuredFps > peakHzRef.current) {
          if (measuredFps >= 110) peakHzRef.current = 120;
          else if (measuredFps >= 82) peakHzRef.current = 90;
          else if (measuredFps >= 70) peakHzRef.current = 75;
        }

        const jsHeapUsedMb = perf.memory
          ? Number((perf.memory.usedJSHeapSize / 1048576).toFixed(1))
          : null;
        const jsHeapLimitMb = perf.memory
          ? Number((perf.memory.jsHeapSizeLimit / 1048576).toFixed(0))
          : null;
        const jsHeapPercent = perf.memory
          ? Math.round((perf.memory.usedJSHeapSize / perf.memory.jsHeapSizeLimit) * 100)
          : null;

        const sample: TelemetrySample = {
          timestamp: Date.now(),
          fps: measuredFps,
          frameTimeMs,
          mainThreadDriftMs: latestDriftRef.current,
          jsHeapUsedMb,
        };

        setTelemetry((prev) => ({
          ...prev,
          fps: measuredFps,
          frameTimeMs,
          estimatedRefreshHz: peakHzRef.current,
          jsHeapUsedMb,
          jsHeapLimitMb,
          jsHeapPercent,
          mainThreadDriftMs: latestDriftRef.current,
          history: [...prev.history.slice(-39), sample],
        }));

        frameCountRef.current = 0;
        lastSampleTimeRef.current = now;
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(rafId);
      clearTimeout(driftTimer);
    };
  }, [enabled, perf]);

  return telemetry;
}
