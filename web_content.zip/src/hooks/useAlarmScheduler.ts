import { useEffect, useState, useCallback, useRef } from 'react';
import { Task } from '../types';
import {
  startAlarmChannel,
  stopAlarmChannel,
  stopAllAlarms,
  primeAudioForBackground,
  getSelectedTone,
} from '../utils/audioManager';
import { getTodayString } from '../context/AppContext';
import { requestScreenWakeLock, releaseScreenWakeLock } from '../utils/wakeLockManager';
import {
  scheduleNativeAlarm,
  cancelNativeAlarm,
  silenceNativeAlarm,
  dismissNativeAlarm,
  snoozeNativeAlarm,
  testNativeLockScreenAlarm,
  setupNativeAlarmListeners,
  isNativeAndroid,
} from '../utils/nativeAlarmBridge';

interface UseAlarmSchedulerProps {
  tasks: Task[];
  updateTask: (task: Task) => void;
  toggleTaskCompleted: (id: string) => void;
}

export function useAlarmScheduler({ tasks, updateTask, toggleTaskCompleted }: UseAlarmSchedulerProps) {
  // Support multiple simultaneous independent alarms
  const [ringingTasks, setRingingTasks] = useState<Task[]>([]);
  const [isTestAlarmCountingDown, setIsTestAlarmCountingDown] = useState(false);
  const [testCountdownSec, setTestCountdownSec] = useState<number | null>(null);

  const firedAlarmsRef = useRef<Set<string>>(new Set());
  const scheduledNativeTaskIdsRef = useRef<Set<string>>(new Set());
  const lastPendingReminderTimeRef = useRef<number>(0);
  const workerRef = useRef<Worker | null>(null);

  // Backward compatibility: single ringing task
  const ringingTask = ringingTasks.length > 0 ? ringingTasks[0] : null;

  // Silence audio without dismissing the modal
  const silenceAlarmSound = useCallback(() => {
    stopAllAlarms();
    silenceNativeAlarm();
  }, []);

  // Dismiss a specific alarm or all alarms
  const dismissAlarm = useCallback((taskId?: string) => {
    if (taskId) {
      // Stop this specific alarm channel
      stopAlarmChannel(`alarm-${taskId}`);
      dismissNativeAlarm(taskId);
      setRingingTasks((prev) => {
        const next = prev.filter((t) => t.id !== taskId);
        if (next.length === 0) {
          releaseScreenWakeLock();
        }
        return next;
      });
    } else {
      // Stop all active alarm channels
      stopAllAlarms();
      dismissNativeAlarm();
      releaseScreenWakeLock();
      setRingingTasks([]);
    }
  }, []);

  const dismissAllAlarms = useCallback(() => {
    stopAllAlarms();
    dismissNativeAlarm();
    releaseScreenWakeLock();
    setRingingTasks([]);
  }, []);

  // Snooze Alarm for exactly 5 minutes (Requirement 7)
  const snoozeAlarm = useCallback(
    (task: Task) => {
      // 1. Stop audio for this alarm channel
      stopAlarmChannel(`alarm-${task.id}`);
      snoozeNativeAlarm(task, 5);

      // 2. Remove from ringing queue
      setRingingTasks((prev) => {
        const next = prev.filter((t) => t.id !== task.id);
        if (next.length === 0) {
          releaseScreenWakeLock();
        }
        return next;
      });

      // 3. Compute snooze time: now + 5 minutes
      const now = new Date();
      now.setMinutes(now.getMinutes() + 5);
      const snoozeTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      // 4. Update task record: set new time and reset ringing flags
      const updatedTask: Task = {
        ...task,
        dueTime: snoozeTime,
        alarmMinutesBefore: 0,
        hasAlarmRung: false,
      };
      updateTask(updatedTask);

      // 5. Schedule native alarm for snooze
      scheduleNativeAlarm(updatedTask, now);

      // 6. Show desktop/web notification confirmation if allowed
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        try {
          new Notification('⏰ Alarm Snoozed (৫ মিনিট পর আবার বাজবে)', {
            body: `পরবর্তী অ্যালার্ম বাজবে ${snoozeTime} এ।`,
            icon: '/pwa-192x192.png',
          });
        } catch {
          // ignore
        }
      }
    },
    [updateTask]
  );

  // Complete task from alarm screen (Requirement 7)
  const completeTaskFromAlarm = useCallback(
    (task: Task) => {
      stopAlarmChannel(`alarm-${task.id}`);
      dismissNativeAlarm(task.id);
      cancelNativeAlarm(task.id);

      setRingingTasks((prev) => {
        const next = prev.filter((t) => t.id !== task.id);
        if (next.length === 0) {
          releaseScreenWakeLock();
        }
        return next;
      });

      toggleTaskCompleted(task.id);
    },
    [toggleTaskCompleted]
  );

  // Trigger alarm for a task: independent channel, independent tone (Requirement 5 & 6)
  const triggerAlarm = useCallback((task: Task) => {
    // Add to active ringing tasks list if not already present
    setRingingTasks((prev) => {
      if (prev.some((t) => t.id === task.id)) return prev;
      return [...prev, task];
    });

    const channelId = `alarm-${task.id}`;
    const chosenTone = task.ringtone || getSelectedTone();

    // Start independent audio channel
    startAlarmChannel({
      channelId,
      title: task.title,
      toneId: chosenTone,
      onSnooze: () => snoozeAlarm(task),
      onDismiss: () => dismissAlarm(task.id),
    });

    requestScreenWakeLock();

    // Trigger Notification for web/PWA
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        const leadText = task.alarmMinutesBefore
          ? `(${task.alarmMinutesBefore} মিনিট আগে)`
          : '';
        const title = `🔔 অ্যালার্ম: ${task.title} ${leadText}`;
        const options: NotificationOptions = {
          body: task.notes || `সময়: ${task.dueTime || task.dueDate}। অনুগ্রহ করে কাজটি সম্পন্ন করুন!`,
          icon: '/pwa-192x192.png',
          badge: '/favicon.ico',
          tag: `alarm-${task.id}`,
          requireInteraction: true,
          silent: false,
        };
        (options as any).vibrate = [1000, 400, 1000, 400, 1500];

        if ('serviceWorker' in navigator) {
          navigator.serviceWorker.ready.then((reg) => {
            reg.showNotification(title, options).catch(() => {});
          }).catch(() => {
            try {
              new Notification(title, options);
            } catch {
              // ignore
            }
          });
        } else {
          try {
            new Notification(title, options);
          } catch {
            // ignore
          }
        }
      } catch (e) {
        console.warn('Notification trigger error:', e);
      }
    }
  }, [dismissAlarm, snoozeAlarm]);

  // Requirement 4: Hardware volume button silencing listener in Web/PWA
  useEffect(() => {
    const handleHardwareVolumeKeys = (e: KeyboardEvent) => {
      if (
        e.key === 'VolumeDown' ||
        e.key === 'VolumeUp' ||
        e.key === 'AudioVolumeDown' ||
        e.key === 'AudioVolumeUp'
      ) {
        if (ringingTasks.length > 0) {
          silenceAlarmSound();
        }
      }
    };

    window.addEventListener('keydown', handleHardwareVolumeKeys);
    return () => {
      window.removeEventListener('keydown', handleHardwareVolumeKeys);
    };
  }, [ringingTasks, silenceAlarmSound]);

  // Connect native Android plugin events to React state
  useEffect(() => {
    const cleanup = setupNativeAlarmListeners({
      onTriggered: (data) => {
        const matchingTask = tasks.find((t) => t.id === data.taskId);
        if (matchingTask) {
          triggerAlarm(matchingTask);
        } else {
          const fallbackTask: Task = {
            id: data.taskId,
            title: data.title || 'Alarm Reminder',
            dueDate: getTodayString(),
            dueTime: data.dueTime || '',
            ringtone: data.ringtone || 'morning_birds',
            priority: 'high',
            category: 'routine',
            completed: false,
            createdAt: new Date().toISOString(),
          };
          triggerAlarm(fallbackTask);
        }
      },
      onCompleted: (data) => {
        toggleTaskCompleted(data.taskId);
        dismissAlarm(data.taskId);
      },
      onSnoozed: (data) => {
        const matchingTask = tasks.find((t) => t.id === data.taskId);
        if (matchingTask) {
          updateTask({
            ...matchingTask,
            dueTime: data.snoozeTime,
            hasAlarmRung: false,
            alarmMinutesBefore: 0,
          });
        }
        dismissAlarm(data.taskId);
      },
      onDismissed: (data) => {
        dismissAlarm(data.taskId);
      },
    });

    return () => {
      cleanup();
    };
  }, [tasks, triggerAlarm, toggleTaskCompleted, updateTask, dismissAlarm]);

  // Check pending uncompleted tasks and notify user periodically
  const notifyPendingTasks = useCallback((pendingTasks: Task[]) => {
    if (pendingTasks.length === 0) return;
    const now = Date.now();
    if (now - lastPendingReminderTimeRef.current < 30 * 60 * 1000) return;

    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        lastPendingReminderTimeRef.current = now;
        const firstTask = pendingTasks[0];
        const remainingCount = pendingTasks.length;
        const title = `📝 আপনার ${remainingCount}টি কাজ এখনও বাকি আছে`;
        const body = `পরবর্তী কাজ: "${firstTask.title}". সময় থাকতে সম্পন্ন করে নিন!`;

        const pendingOptions: NotificationOptions = {
          body,
          icon: '/pwa-192x192.png',
          tag: 'pending-tasks-reminder',
        };
        (pendingOptions as any).vibrate = [300, 150, 300];

        if ('serviceWorker' in navigator) {
          navigator.serviceWorker.ready.then((reg) => {
            reg.showNotification(title, pendingOptions).catch(() => {});
          }).catch(() => {
            try {
              new Notification(title, pendingOptions);
            } catch {
              // ignore
            }
          });
        } else {
          try {
            new Notification(title, pendingOptions);
          } catch {
            // ignore
          }
        }
      } catch (e) {
        console.warn('Pending notification error:', e);
      }
    }
  }, []);

  // Precision alarm checker & Native AlarmManager synchronizer
  const checkAlarms = useCallback(() => {
    const now = new Date();
    const todayStr = getTodayString();
    const currentHours = now.getHours();
    const currentMinutes = now.getMinutes();
    const currentTotalMinutes = currentHours * 60 + currentMinutes;

    const uncompletedTasksToday: Task[] = [];

    tasks.forEach((task) => {
      // Incomplete tasks due today
      if (!task.completed && (task.dueDate === todayStr || task.isRoutine)) {
        uncompletedTasksToday.push(task);
      }

      // Check alarm eligibility
      if (task.completed || (!task.reminderSet && !task.alarmEnabled)) {
        if (scheduledNativeTaskIdsRef.current.has(task.id)) {
          cancelNativeAlarm(task.id);
          scheduledNativeTaskIdsRef.current.delete(task.id);
        }
        return;
      }

      if (task.dueDate !== todayStr && !task.isRoutine) return;
      if (!task.dueTime) return;

      const [dueH, dueM] = task.dueTime.split(':').map(Number);
      if (isNaN(dueH) || isNaN(dueM)) return;

      const dueTotalMinutes = dueH * 60 + dueM;
      const alarmLead = task.alarmMinutesBefore || 0;
      const targetAlarmMinutes = dueTotalMinutes - alarmLead;
      const alarmKey = `${task.id}-${todayStr}-${targetAlarmMinutes}`;

      // Schedule native alarm if in native Android and not already registered
      if (isNativeAndroid() && !scheduledNativeTaskIdsRef.current.has(task.id) && !task.hasAlarmRung) {
        const triggerDate = new Date();
        triggerDate.setHours(dueH, dueM - alarmLead, 0, 0);
        if (triggerDate.getTime() > Date.now()) {
          scheduleNativeAlarm(task, triggerDate);
          scheduledNativeTaskIdsRef.current.add(task.id);
        }
      }

      const diff = currentTotalMinutes - targetAlarmMinutes;
      // Precision match within 3 minutes window
      if (diff >= 0 && diff <= 3) {
        if (!firedAlarmsRef.current.has(alarmKey) && !task.hasAlarmRung) {
          firedAlarmsRef.current.add(alarmKey);
          triggerAlarm(task);
          updateTask({ ...task, hasAlarmRung: true });
        }
      }
    });

    // Check if we should alert about pending tasks (every 30 mins, after 12:00 PM)
    if (currentHours >= 12 && uncompletedTasksToday.length > 0) {
      notifyPendingTasks(uncompletedTasksToday);
    }
  }, [tasks, triggerAlarm, updateTask, notifyPendingTasks]);

  // Set up unthrottled Web Worker timer for background and lock-screen reliability
  useEffect(() => {
    checkAlarms();

    let worker: Worker | null = null;
    let fallbackInterval: number | null = null;

    try {
      const workerBlob = new Blob([
        `setInterval(function() { postMessage('tick'); }, 2000);`
      ], { type: 'application/javascript' });
      worker = new Worker(URL.createObjectURL(workerBlob));
      worker.onmessage = () => {
        checkAlarms();
      };
      workerRef.current = worker;
    } catch {
      fallbackInterval = window.setInterval(checkAlarms, 3000);
    }

    return () => {
      if (worker) {
        worker.terminate();
        workerRef.current = null;
      }
      if (fallbackInterval !== null) {
        clearInterval(fallbackInterval);
      }
    };
  }, [checkAlarms]);

  // Test Alarm with countdown so user can lock phone and test!
  const testAlarmWithCountdown = useCallback(
    (delaySeconds = 5, taskTitle = 'লক স্ক্রিন অ্যালার্ম টেস্ট — Habivio') => {
      setIsTestAlarmCountingDown(true);
      setTestCountdownSec(delaySeconds);

      // Pre-authorize audio engine & wake lock
      primeAudioForBackground();
      requestScreenWakeLock();

      // If running on native Android, schedule through native AlarmManager
      if (isNativeAndroid()) {
        testNativeLockScreenAlarm(delaySeconds, taskTitle);
      }

      let remaining = delaySeconds;
      const countTimer = setInterval(() => {
        remaining -= 1;
        setTestCountdownSec(remaining);
        if (remaining <= 0) {
          clearInterval(countTimer);
          setIsTestAlarmCountingDown(false);
          setTestCountdownSec(null);

          const mockTask: Task = {
            id: 'test-alarm-' + Date.now(),
            title: taskTitle,
            notes: 'স্ক্রিন লক থাকা অবস্থায় অ্যালার্ম, সাউন্ড ও ভাইব্রেশন নিখুঁতভাবে কাজ করছে!',
            dueDate: getTodayString(),
            dueTime: 'এখনই',
            priority: 'high',
            category: 'routine',
            completed: false,
            alarmEnabled: true,
            createdAt: new Date().toISOString(),
          };
          triggerAlarm(mockTask);
        }
      }, 1000);
    },
    [triggerAlarm]
  );

  return {
    ringingTask,
    ringingTasks,
    dismissAlarm,
    dismissAllAlarms,
    snoozeAlarm,
    completeTaskFromAlarm,
    silenceAlarmSound,
    testAlarm: () => testAlarmWithCountdown(5),
    testAlarmWithCountdown,
    isTestAlarmCountingDown,
    testCountdownSec,
  };
}
