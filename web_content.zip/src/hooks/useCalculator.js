import { useState } from 'react';

const SYMBOLS = { '+': '+', '-': '−', '*': '×', '/': '÷' };

const format = (value) => {
  if (!isFinite(value) || Number.isNaN(value)) return 'Error';
  const rounded = Math.round(value * 1e10) / 1e10;
  const abs = Math.abs(rounded);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-6)) {
    return rounded.toExponential(6);
  }
  return String(rounded);
};

const apply = (a, b, operator) => {
  if (operator === '+') return a + b;
  if (operator === '-') return a - b;
  if (operator === '*') return a * b;
  if (operator === '/') return b === 0 ? NaN : a / b;
  return b;
};

export default function useCalculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [stored, setStored] = useState(null);
  const [operator, setOperator] = useState(null);
  const [overwrite, setOverwrite] = useState(true);
  const [error, setError] = useState(false);

  const clearAll = () => {
    setDisplay('0');
    setExpression('');
    setStored(null);
    setOperator(null);
    setOverwrite(true);
    setError(false);
  };

  const inputDigit = (digit) => {
    if (error) {
      clearAll();
      setDisplay(digit);
      setOverwrite(false);
      return;
    }
    if (overwrite) {
      setDisplay(digit);
      setOverwrite(false);
      return;
    }
    setDisplay((prev) => {
      if (prev === '0') return digit;
      if (prev.replace(/[-.]/g, '').length >= 12) return prev;
      return prev + digit;
    });
  };

  const inputDot = () => {
    if (error || overwrite) {
      if (error) clearAll();
      setDisplay('0.');
      setOverwrite(false);
      return;
    }
    setDisplay((prev) => (prev.includes('.') ? prev : `${prev}.`));
  };

  const backspace = () => {
    if (error) {
      clearAll();
      return;
    }
    if (overwrite) return;
    setDisplay((prev) => (prev.length > 1 ? prev.slice(0, -1) : '0'));
  };

  const toggleSign = () => {
    if (error) {
      clearAll();
      return;
    }
    setDisplay((prev) => (prev === '0' ? prev : prev.startsWith('-') ? prev.slice(1) : `-${prev}`));
  };

  const percent = () => {
    if (error) {
      clearAll();
      return;
    }
    setDisplay(format(parseFloat(display) / 100));
    setOverwrite(true);
  };

  const chooseOperator = (next) => {
    if (error) return;
    const value = parseFloat(display);
    if (operator && stored !== null && !overwrite) {
      const result = apply(stored, value, operator);
      const text = format(result);
      setExpression(`${text} ${SYMBOLS[next]}`);
      setDisplay(text);
      setStored(isFinite(result) ? result : null);
      setError(!isFinite(result));
      setOperator(next);
      setOverwrite(true);
      return;
    }
    setStored(value);
    setOperator(next);
    setExpression(`${display} ${SYMBOLS[next]}`);
    setOverwrite(true);
  };

  const equals = () => {
    if (error || operator === null || stored === null) return;
    const result = apply(stored, parseFloat(display), operator);
    setExpression(`${format(stored)} ${SYMBOLS[operator]} ${display} =`);
    setDisplay(format(result));
    setError(!isFinite(result));
    setStored(null);
    setOperator(null);
    setOverwrite(true);
  };

  return {
    display,
    expression,
    inputDigit,
    inputDot,
    clearAll,
    backspace,
    toggleSign,
    percent,
    chooseOperator,
    equals,
  };
}