import { useCallback, useEffect, useRef, useState } from 'react';

type SensorStatus = 'idle' | 'requesting' | 'listening' | 'active' | 'unavailable' | 'denied';
type PermissionConstructor = typeof DeviceMotionEvent & {
  requestPermission?: () => Promise<'granted' | 'denied'>;
};

interface SensorState {
  status: SensorStatus;
  isMoving: boolean;
  magnitude: number;
  debugInfo: string;
}

const initialState: SensorState = {
  status: 'idle',
  isMoving: false,
  magnitude: 0,
  debugInfo: 'Motion sensors will activate once the journey begins.',
};

export function useVibrationDetection(sensitivity = 6) {
  const [state, setState] = useState<SensorState>(initialState);
  const running = useRef(false);
  const threshold = useRef(1.35);
  const gravity = useRef<{ x: number; y: number; z: number } | null>(null);
  const filtered = useRef(0);
  const moveUntil = useRef(0);
  const lastReading = useRef(0);
  const startedAt = useRef(0);
  const lastPublish = useRef(0);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const generation = useRef(0);

  useEffect(() => {
    threshold.current = 3.15 - sensitivity * 0.3;
  }, [sensitivity]);

  const handleMotion = useCallback((event: DeviceMotionEvent) => {
    if (!running.current) return;
    const acceleration = event.acceleration;
    const hasLinear = acceleration && [acceleration.x, acceleration.y, acceleration.z]
      .some(value => typeof value === 'number' && Number.isFinite(value));
    let x: number;
    let y: number;
    let z: number;

    if (hasLinear && acceleration) {
      x = acceleration.x ?? 0;
      y = acceleration.y ?? 0;
      z = acceleration.z ?? 0;
    } else {
      const value = event.accelerationIncludingGravity;
      if (!value || ![value.x, value.y, value.z].some(item => typeof item === 'number')) return;
      const sample = { x: value.x ?? 0, y: value.y ?? 0, z: value.z ?? 0 };
      if (!gravity.current) gravity.current = { ...sample };
      const g = gravity.current;
      // Estimate gravity on all axes, including when the phone is held horizontally.
      g.x = g.x * 0.92 + sample.x * 0.08;
      g.y = g.y * 0.92 + sample.y * 0.08;
      g.z = g.z * 0.92 + sample.z * 0.08;
      x = sample.x - g.x;
      y = sample.y - g.y;
      z = sample.z - g.z;
    }

    if (![x, y, z].every(Number.isFinite)) return;
    const now = performance.now();
    lastReading.current = now;
    filtered.current = filtered.current * 0.35 + Math.hypot(x, y, z) * 0.65;
    if (filtered.current > threshold.current) moveUntil.current = now + 480;
    if (now - lastPublish.current < 65) return;
    lastPublish.current = now;
    setState({
      status: 'active',
      isMoving: now < moveUntil.current,
      magnitude: filtered.current,
      debugInfo: `Motion sensor active. Threshold: ${threshold.current.toFixed(2)} m/s².`,
    });
  }, []);

  const cleanup = useCallback(() => {
    running.current = false;
    generation.current += 1;
    window.removeEventListener('devicemotion', handleMotion);
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    gravity.current = null;
    filtered.current = 0;
    moveUntil.current = 0;
    lastReading.current = 0;
  }, [handleMotion]);

  const stop = useCallback(() => {
    cleanup();
    setState(initialState);
  }, [cleanup]);

  const requestPermission = useCallback(async (): Promise<boolean> => {
    cleanup();
    const requestId = generation.current;
    if (!window.isSecureContext || !('DeviceMotionEvent' in window)) {
      setState({
        ...initialState,
        status: 'unavailable',
        debugInfo: 'Motion sensors require a mobile device over HTTPS. Manual controls remain fully available.',
      });
      return false;
    }
    setState(previous => ({ ...previous, status: 'requesting' }));
    try {
      const MotionEvent = window.DeviceMotionEvent as PermissionConstructor;
      const permission = MotionEvent.requestPermission ? await MotionEvent.requestPermission() : 'granted';
      if (requestId !== generation.current) return false;
      if (permission !== 'granted') {
        setState({
          ...initialState,
          status: 'denied',
          debugInfo: 'Motion permission denied. Enable Motion & Orientation in your browser settings or use manual controls.',
        });
        return false;
      }
      running.current = true;
      startedAt.current = performance.now();
      window.addEventListener('devicemotion', handleMotion, { passive: true });
      setState({ ...initialState, status: 'listening', debugInfo: 'Awaiting phone movement data...' });
      timer.current = setInterval(() => {
        const now = performance.now();
        if (lastReading.current > 0 && now - lastReading.current > 350) filtered.current = 0;
        const stale = (lastReading.current === 0 && now - startedAt.current > 2500)
          || (lastReading.current > 0 && now - lastReading.current > 2500);
        setState(previous => {
          if (stale) return {
            ...previous,
            status: 'unavailable',
            isMoving: false,
            magnitude: 0,
            debugInfo: 'No sensor data received yet. Use the Walk button or W / Space. Please access over HTTPS on mobile.',
          };
          if (previous.isMoving && now >= moveUntil.current) return { ...previous, isMoving: false, magnitude: 0 };
          return previous;
        });
      }, 100);
      return true;
    } catch {
      if (requestId !== generation.current) return false;
      setState({
        ...initialState,
        status: 'denied',
        debugInfo: 'Motion sensor could not be accessed. Ensure HTTPS is used and allow motion permissions in settings.',
      });
      return false;
    }
  }, [cleanup, handleMotion]);

  const isMovingNow = useCallback(() => running.current && performance.now() < moveUntil.current, []);

  useEffect(() => cleanup, [cleanup]);

  return { ...state, requestPermission, stop, isMovingNow };
}
