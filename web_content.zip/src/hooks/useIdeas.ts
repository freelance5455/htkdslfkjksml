import { useState, useCallback } from "react";
import type { Idea } from "@/types";
import { getIdeas, saveIdea, deleteIdea as deleteIdeaStorage } from "@/lib/storage";
import { generateId } from "@/lib/utils";

export function useIdeas() {
  const [ideas, setIdeas] = useState<Idea[]>(getIdeas);

  const addIdea = useCallback((title: string, description: string, tags: string[] = []) => {
    const idea: Idea = {
      id: generateId(),
      title,
      description,
      tags,
      status: "RAW",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveIdea(idea);
    setIdeas(getIdeas());
    return idea;
  }, []);

  const updateIdea = useCallback((idea: Idea) => {
    saveIdea({ ...idea, updatedAt: new Date().toISOString() });
    setIdeas(getIdeas());
  }, []);

  const deleteIdea = useCallback((id: string) => {
    deleteIdeaStorage(id);
    setIdeas(getIdeas());
  }, []);

  return { ideas, addIdea, updateIdea, deleteIdea };
}
