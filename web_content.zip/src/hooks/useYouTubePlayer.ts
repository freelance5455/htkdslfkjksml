/**
 * غلاف React فوق YouTube IFrame Player API.
 * - يحمّل سكربت iframe_api مرة واحدة فقط لكل جلسة.
 * - ينشئ المشغّل من نطاق youtube-nocookie مع تعطيل أدوات يوتيوب.
 * - يوفّر حالة تفاعلية (وقت، مدة، صوت، سرعة، جودة) وأوامر تحكّم.
 * - ينظّف المشغّل (destroy) عند تغيير الفيديو أو الخروج من الصفحة لمنع تسرّب الذاكرة.
 */
import { useCallback, useEffect, useRef, useState } from 'react';

/* ------------------------- تعريفات مختصرة لـ YT ------------------------- */

interface YTPlayerLike {
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  setVolume: (v: number) => void;
  getVolume: () => number;
  mute: () => void;
  unMute: () => void;
  isMuted: () => boolean;
  setPlaybackRate: (rate: number) => void;
  getPlaybackRate: () => number;
  getAvailableQualityLevels: () => string[];
  getPlaybackQuality: () => string;
  setPlaybackQuality: (q: string) => void;
  loadVideoById: (opts: { videoId: string; startSeconds?: number }) => void;
  cueVideoById: (opts: { videoId: string; startSeconds?: number }) => void;
  getVideoLoadedFraction: () => number;
  destroy: () => void;
}

interface YTNamespace {
  Player: new (
    el: HTMLElement | string,
    options: {
      videoId?: string;
      host?: string;
      width?: string | number;
      height?: string | number;
      playerVars?: Record<string, string | number>;
      events?: {
        onReady?: (event: { target: YTPlayerLike }) => void;
        onStateChange?: (event: { data: number; target: YTPlayerLike }) => void;
        onError?: (event: { data: number; target: YTPlayerLike }) => void;
        onPlaybackRateChange?: (event: { data: number }) => void;
      };
    },
  ) => YTPlayerLike;
}

declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

let apiPromise: Promise<YTNamespace> | null = null;

function loadIframeApi(): Promise<YTNamespace> {
  if (window.YT && typeof window.YT.Player === 'function') return Promise.resolve(window.YT);
  if (apiPromise) return apiPromise;
  apiPromise = new Promise<YTNamespace>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>('script[data-manara-yt]');
    const timeout = window.setTimeout(() => reject(new Error('timeout')), 12_000);

    const finish = () => {
      if (window.YT && typeof window.YT.Player === 'function') {
        window.clearTimeout(timeout);
        resolve(window.YT);
      }
    };

    window.onYouTubeIframeAPIReady = finish;

    if (existing) {
      // السكربت موجود لكن الـ API لم يجهز بعد: ننتظر الحدث أعلاه
      const poll = window.setInterval(() => {
        if (window.YT && typeof window.YT.Player === 'function') {
          window.clearInterval(poll);
          finish();
        }
      }, 200);
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    script.async = true;
    script.dataset.manaraYt = 'true';
    script.onerror = () => {
      window.clearTimeout(timeout);
      reject(new Error('network'));
    };
    document.head.appendChild(script);
  }).catch((error: unknown) => {
    // لا نحتفظ بوعد مرفوض: إعادة المحاولة تحتاج تحميلاً جديداً للسكربت
    apiPromise = null;
    throw error;
  });
  return apiPromise;
}

export type PlayerStatus = 'loading' | 'ready' | 'playing' | 'paused' | 'buffering' | 'ended' | 'error';

export interface YouTubePlayerState {
  status: PlayerStatus;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  rate: number;
  quality: string;
  qualities: string[];
  buffered: number;
  errorCode: number | null;
}

export interface YouTubePlayerApi {
  play: () => void;
  pause: () => void;
  toggle: () => void;
  seek: (seconds: number) => void;
  seekBy: (delta: number) => void;
  setVolume: (value: number) => void;
  toggleMute: () => void;
  setRate: (rate: number) => void;
  setQuality: (quality: string) => void;
  state: YouTubePlayerState;
}

const QUALITY_LABELS: Record<string, string> = {
  highres: 'أعلى جودة',
  hd2160: '2160p',
  hd1440: '1440p',
  hd1080: '1080p',
  hd720: '720p',
  large: '480p',
  medium: '360p',
  small: '240p',
  tiny: '144p',
  auto: 'تلقائي',
  default: 'افتراضي',
};

export function qualityLabel(q: string): string {
  return QUALITY_LABELS[q] ?? q;
}

export function useYouTubePlayer(options: {
  videoId: string;
  startAt?: number;
  hostRef: React.RefObject<HTMLDivElement | null>;
  paused?: boolean;
  onEnded?: () => void;
  onProgress?: (position: number, duration: number) => void;
  onStatusChange?: (status: PlayerStatus) => void;
  dataSaver?: boolean;
  initialVolume?: number;
  reloadToken?: number;
}): YouTubePlayerApi {
  const {
    videoId,
    startAt = 0,
    hostRef,
    onEnded,
    onProgress,
    onStatusChange,
    dataSaver,
    initialVolume = 80,
    reloadToken = 0,
  } = options;

  const playerRef = useRef<YTPlayerLike | null>(null);
  const rafRef = useRef<number | null>(null);
  const progressRef = useRef(onProgress);
  const endedRef = useRef(onEnded);
  const statusRef = useRef(onStatusChange);

  const stateRef = useRef<YouTubePlayerState | null>(null);

  const [state, setState] = useState<YouTubePlayerState>({
    status: 'loading',
    currentTime: startAt,
    duration: 0,
    volume: initialVolume,
    muted: false,
    rate: 1,
    quality: 'auto',
    qualities: ['auto'],
    buffered: 0,
    errorCode: null,
  });

  useEffect(() => {
    progressRef.current = onProgress;
    endedRef.current = onEnded;
    statusRef.current = onStatusChange;
  }, [onProgress, onEnded, onStatusChange]);

  stateRef.current = state;

  const patch = useCallback((next: Partial<YouTubePlayerState>) => {
    setState((prev) => ({ ...prev, ...next }));
  }, []);

  /* ---------------------------- إنشاء المشغّل ---------------------------- */
  useEffect(() => {
    const host = hostRef.current;
    if (!host || !videoId) return undefined;

    let cancelled = false;
    let pollId: number | null = null;
    let player: YTPlayerLike | null = null;

    // مشغّل جديد يعني حالة جديدة تماماً (يمنع تسرّب وقت/حالة الدرس السابق)
    setState({
      status: 'loading',
      currentTime: startAt,
      duration: 0,
      volume: initialVolume,
      muted: false,
      rate: 1,
      quality: 'default',
      qualities: ['default'],
      buffered: 0,
      errorCode: null,
    });

    const mount = document.createElement('div');
    mount.className = 'h-full w-full';
    host.innerHTML = '';
    host.appendChild(mount);

    const startPolling = () => {
      let lastEmit = 0;
      const loop = (time: number) => {
        if (!player) return;
        // تحديث الحالة ٥ مرات/ثانية يكفي لسلاسة الشريط ويوفّر إعادة رسم كامل الصفحة
        if (time - lastEmit > 200) {
          lastEmit = time;
          try {
            const current = player.getCurrentTime();
            const total = player.getDuration();
            const buffered = player.getVideoLoadedFraction();
            setState((prev) => ({
              ...prev,
              currentTime: current,
              duration: total > 0 ? total : prev.duration,
              buffered,
            }));
            progressRef.current?.(current, total);
          } catch {
            /* المشغّل قد يكون في طور التهيئة */
          }
        }
        rafRef.current = window.requestAnimationFrame(loop);
      };
      if (rafRef.current) window.cancelAnimationFrame(rafRef.current);
      rafRef.current = window.requestAnimationFrame(loop);
    };

    const stopPolling = () => {
      if (rafRef.current) {
        window.cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };

    loadIframeApi()
      .then((YT) => {
        if (cancelled) return;
        player = new YT.Player(mount, {
          videoId,
          host: 'https://www.youtube-nocookie.com',
          width: '100%',
          height: '100%',
          playerVars: {
            controls: 0,
            modestbranding: 1,
            rel: 0,
            iv_load_policy: 3,
            playsinline: 1,
            disablekb: 1,
            fs: 0,
            cc_load_policy: 0,
            enablejsapi: 1,
            ...(window.location.origin !== 'null' ? { origin: window.location.origin } : {}),
            start: Math.max(0, Math.floor(startAt)),
            autoplay: 0,
          },
          events: {
            onReady: (event) => {
              if (cancelled) return;
              player = event.target;
              playerRef.current = event.target;
              const duration = event.target.getDuration();
              const qualities = event.target.getAvailableQualityLevels();
              try {
                event.target.setVolume(Math.max(0, Math.min(100, initialVolume)));
              } catch {
                /* تجاهل */
              }
              patch({
                status: 'ready',
                duration,
                qualities: ['default', ...qualities],
                currentTime: startAt,
              });
              if (dataSaver) {
                const lowest = qualities[qualities.length - 1];
                if (lowest) event.target.setPlaybackQuality(lowest);
              }
              statusRef.current?.('ready');
            },
            onStateChange: (event) => {
              if (cancelled) return;
              const map: Record<number, PlayerStatus> = {
                [-1]: 'ready',
                0: 'ended',
                1: 'playing',
                2: 'paused',
                3: 'buffering',
                5: 'ready',
              };
              const status = map[event.data] ?? 'ready';
              patch({
                status,
                duration: event.target.getDuration() || state.duration,
                rate: event.target.getPlaybackRate?.() ?? 1,
              });
              statusRef.current?.(status);
              if (status === 'playing') startPolling();
              if (status === 'buffering') startPolling();
              if (status === 'paused' || status === 'ended') stopPolling();
              if (status === 'ended') {
                try {
                  progressRef.current?.(event.target.getDuration(), event.target.getDuration());
                } catch {
                  /* تجاهل */
                }
                endedRef.current?.();
              }
            },
            onError: (event) => {
              if (cancelled) return;
              stopPolling();
              patch({ status: 'error', errorCode: event.data });
              statusRef.current?.('error');
            },
          },
        });
        // شبكة أمان: بعض المتصفحات لا تطلق onReady إذا مُنع التضمين
        pollId = window.setTimeout(() => {
          if (!cancelled && !playerRef.current) {
            patch({ status: 'error', errorCode: 101 });
          }
        }, 9000);
      })
      .catch(() => {
        if (cancelled) return;
        patch({ status: 'error', errorCode: 5 });
        statusRef.current?.('error');
      });

    return () => {
      cancelled = true;
      stopPolling();
      if (pollId) window.clearTimeout(pollId);
      try {
        player?.destroy();
      } catch {
        /* تجاهل أخطاء التدمير */
      }
      playerRef.current = null;
      if (host) host.innerHTML = '';
    };
    // نُنشئ المشغّل عند تغيير الفيديو فقط
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoId, reloadToken]);

  /* ------------------------------- الأوامر ------------------------------- */

  const play = useCallback(() => {
    try {
      playerRef.current?.playVideo();
    } catch {
      /* تجاهل */
    }
  }, []);

  const pause = useCallback(() => {
    try {
      playerRef.current?.pauseVideo();
    } catch {
      /* تجاهل */
    }
  }, []);

  const toggle = useCallback(() => {
    const current = stateRef.current;
    try {
      if (current?.status === 'playing' || current?.status === 'buffering') playerRef.current?.pauseVideo();
      else playerRef.current?.playVideo();
    } catch {
      /* تجاهل */
    }
  }, []);

  const seek = useCallback((seconds: number) => {
    try {
      const player = playerRef.current;
      if (!player) return;
      const total = player.getDuration();
      const target = Math.max(0, Math.min(total > 0 ? total - 0.2 : seconds, seconds));
      player.seekTo(target, true);
      patch({ currentTime: target });
    } catch {
      /* تجاهل */
    }
  }, [patch]);

  const seekBy = useCallback((delta: number) => {
    const current = stateRef.current;
    const base = current?.currentTime ?? 0;
    const total = current?.duration ?? 0;
    const target = Math.max(0, Math.min(total > 0 ? total : base + delta, base + delta));
    try {
      playerRef.current?.seekTo(target, true);
    } catch {
      /* تجاهل */
    }
    setState((prev) => ({ ...prev, currentTime: target }));
  }, []);

  const setVolume = useCallback((value: number) => {
    const v = Math.max(0, Math.min(100, Math.round(value)));
    try {
      playerRef.current?.setVolume(v);
      if (v > 0 && playerRef.current?.isMuted()) playerRef.current.unMute();
    } catch {
      /* تجاهل */
    }
    setState((prev) => ({ ...prev, volume: v, muted: v === 0 }));
  }, []);

  const toggleMute = useCallback(() => {
    const muted = stateRef.current?.muted ?? false;
    try {
      if (muted) playerRef.current?.unMute();
      else playerRef.current?.mute();
    } catch {
      /* تجاهل */
    }
    setState((prev) => ({ ...prev, muted: !muted }));
  }, []);

  const setRate = useCallback((rate: number) => {
    try {
      playerRef.current?.setPlaybackRate(rate);
    } catch {
      /* تجاهل */
    }
    patch({ rate });
  }, [patch]);

  const setQuality = useCallback((quality: string) => {
    try {
      playerRef.current?.setPlaybackQuality(quality);
    } catch {
      /* تجاهل */
    }
    patch({ quality });
  }, [patch]);

  return { play, pause, toggle, seek, seekBy, setVolume, toggleMute, setRate, setQuality, state };
}
