import { useLayoutEffect } from 'react';
import type { Settings, ThemePalette } from '../types';
import { KEYS, useStored, writeKey } from '../services/storage';

export const defaultSettings: Settings = {
  theme: 'system',
  fontScale: 1,
  language: 'ar',
  dataSaver: false,
  autoplayNext: true,
  lastRate: 1,
  lastVolume: 80,
  palette: 'ocean',
  timerSkin: 'classic',
};

const DEFAULT_PALETTE: ThemePalette = 'ocean';

function applyAppearance(theme: Settings['theme'], palette: ThemePalette, systemIsDark: boolean): void {
  const dark = theme === 'dark' || (theme === 'system' && systemIsDark);
  const root = document.documentElement;
  root.dataset.theme = dark ? 'dark' : 'light';
  root.dataset.palette = palette;
  root.style.colorScheme = dark ? 'dark' : 'light';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', dark ? '#07141c' : '#fbf8f2');
}

export function useSettings(): {
  settings: Settings;
  update: (patch: Partial<Settings>) => boolean;
} {
  const settings = useStored<Settings>(KEYS.settings, defaultSettings);
  const palette = settings.palette ?? DEFAULT_PALETTE;

  useLayoutEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => applyAppearance(settings.theme, palette, media.matches);
    apply();
    if (settings.theme !== 'system') return undefined;
    media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, [settings.theme, palette]);

  useLayoutEffect(() => {
    document.documentElement.style.setProperty('--font-scale', String(settings.fontScale));
    document.documentElement.setAttribute('lang', 'ar');
    document.documentElement.setAttribute('dir', 'rtl');
  }, [settings.fontScale, settings.language]);

  const update = (patch: Partial<Settings>): boolean => {
    const next = { ...defaultSettings, ...settings, ...patch };
    applyAppearance(next.theme, next.palette ?? DEFAULT_PALETTE, window.matchMedia('(prefers-color-scheme: dark)').matches);
    return writeKey<Settings>(KEYS.settings, next);
  };

  return { settings, update };
}
