import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function useReports() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;

    base44.entities.IssueReport.filter({}, { sort: "-created_date", limit: 200 })
      .then((page) => {
        if (!active) return;
        setReports(page?.items || []);
      })
      .catch((err) => {
        if (active) setError(err);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    const unsubscribe = base44.entities.IssueReport.subscribe((event) => {
      if (!event?.data) return;
      if (event.type === "create") {
        setReports((prev) => (prev.some((r) => r.id === event.data.id) ? prev : [event.data, ...prev]));
      } else if (event.type === "update") {
        setReports((prev) => prev.map((r) => (r.id === event.data.id ? event.data : r)));
      } else if (event.type === "delete") {
        setReports((prev) => prev.filter((r) => r.id !== event.id));
      }
    });

    return () => {
      active = false;
      if (typeof unsubscribe === "function") unsubscribe();
    };
  }, []);

  return { reports, loading, error };
}