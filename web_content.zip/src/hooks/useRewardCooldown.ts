/**
 * SPR - Sahil Powerful Run
 * React Hook for 24-Hour Reward Cooldowns
 * 
 * Provides reactive seconds-level countdowns that tick accurately and
 * unlock components the instant the timer reaches 00:00:00.
 */

import { useState, useEffect } from 'react';
import { rewardCooldowns, RewardType } from '../game/storage/RewardCooldowns';

export function useRewardCooldown(type: RewardType, customLabel?: string) {
  const [remainingMs, setRemainingMs] = useState<number>(() => rewardCooldowns.getRemainingMs(type));
  const isAvailable = remainingMs <= 0;
  const countdown = rewardCooldowns.formatCountdown(remainingMs);
  const label = rewardCooldowns.getCountdownLabel(type, customLabel);

  useEffect(() => {
    // Immediate check
    setRemainingMs(rewardCooldowns.getRemainingMs(type));

    // Update every second while on cooldown
    const interval = setInterval(() => {
      const rem = rewardCooldowns.getRemainingMs(type);
      setRemainingMs(rem);
    }, 1000);

    // Also subscribe to manual claim updates
    const unsubscribe = rewardCooldowns.subscribe(() => {
      setRemainingMs(rewardCooldowns.getRemainingMs(type));
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, [type]);

  const claim = () => {
    rewardCooldowns.recordClaim(type);
    setRemainingMs(rewardCooldowns.getRemainingMs(type));
  };

  return {
    isAvailable,
    remainingMs,
    countdown,
    label,
    claim,
  };
}
