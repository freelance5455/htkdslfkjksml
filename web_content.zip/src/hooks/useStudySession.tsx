import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useActiveStudy } from './useActiveStudy';
import { recordStudySession } from '../services/studySessions';

type SessionStatus = 'idle' | 'running' | 'paused' | 'completed';
type PauseReason = 'manual' | 'idle' | 'hidden' | null;
type SessionData = {
  status: SessionStatus;
  id: string;
  subjectId: string;
  elapsedSeconds: number;
  durationSeconds: number;
  pauseReason: PauseReason;
};

export interface StudySessionState extends SessionData {
  start: (subjectId: string, durationMinutes: 25 | 50) => void;
  setSubject: (subjectId: string) => void;
  pause: () => void;
  resume: () => void;
  end: () => void;
}

const INACTIVITY_LIMIT_MS = 5 * 60_000;
const StudySessionContext = createContext<StudySessionState | null>(null);

function saveSession(session: SessionData, completed: boolean): void {
  if (!session.id) return;
  void recordStudySession({
    id: session.id,
    subjectId: session.subjectId,
    elapsedSeconds: session.elapsedSeconds,
    plannedSeconds: session.durationSeconds,
    completed,
    at: Date.now(),
  }).catch((error: unknown) => console.error('تعذّر حفظ جلسة الدراسة', error));
}

export function StudySessionProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<SessionData>({
    status: 'idle',
    id: '',
    subjectId: '',
    elapsedSeconds: 0,
    durationSeconds: 25 * 60,
    pauseReason: null,
  });
  const lastTick = useRef(Date.now());
  const lastInteraction = useRef(Date.now());
  const sessionRef = useRef(session);
  const recordedSession = useRef('');
  sessionRef.current = session;
  const active = session.status === 'running' && Boolean(session.subjectId);

  useActiveStudy(active, active ? session.subjectId : undefined, 'session');

  useEffect(() => {
    if (session.status !== 'completed' || !session.id || recordedSession.current === session.id) return;
    recordedSession.current = session.id;
    saveSession(session, true);
  }, [session]);

  useEffect(() => {
    if (session.status !== 'running') return undefined;
    lastTick.current = Date.now();
    lastInteraction.current = Date.now();

    const markActivity = () => { lastInteraction.current = Date.now(); };
    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setSession((current) => current.status === 'running' ? { ...current, status: 'paused', pauseReason: 'hidden' } : current);
      } else {
        lastTick.current = Date.now();
        lastInteraction.current = Date.now();
      }
    };

    const interval = window.setInterval(() => {
      const now = Date.now();
      if (document.visibilityState !== 'visible') {
        setSession((current) => current.status === 'running' ? { ...current, status: 'paused', pauseReason: 'hidden' } : current);
        return;
      }
      if (now - lastInteraction.current >= INACTIVITY_LIMIT_MS) {
        setSession((current) => current.status === 'running' ? { ...current, status: 'paused', pauseReason: 'idle' } : current);
        return;
      }
      const elapsed = Math.min(2, Math.floor((now - lastTick.current) / 1000));
      if (elapsed <= 0) return;
      lastTick.current = now;
      setSession((current) => {
        if (current.status !== 'running') return current;
        const elapsedSeconds = Math.min(current.durationSeconds, current.elapsedSeconds + elapsed);
        return {
          ...current,
          elapsedSeconds,
          status: elapsedSeconds >= current.durationSeconds ? 'completed' : 'running',
        };
      });
    }, 1000);

    document.addEventListener('pointermove', markActivity, { passive: true });
    document.addEventListener('pointerdown', markActivity, { passive: true });
    document.addEventListener('keydown', markActivity);
    document.addEventListener('touchstart', markActivity, { passive: true });
    document.addEventListener('scroll', markActivity, { passive: true, capture: true });
    document.addEventListener('input', markActivity, true);
    document.addEventListener('wheel', markActivity, { passive: true });
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      window.clearInterval(interval);
      document.removeEventListener('pointermove', markActivity);
      document.removeEventListener('pointerdown', markActivity);
      document.removeEventListener('keydown', markActivity);
      document.removeEventListener('touchstart', markActivity);
      document.removeEventListener('scroll', markActivity, true);
      document.removeEventListener('input', markActivity, true);
      document.removeEventListener('wheel', markActivity);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [session.status, session.durationSeconds]);

  const start = useCallback((subjectId: string, durationMinutes: 25 | 50) => {
    const now = Date.now();
    const id = `session-${now}-${Math.random().toString(36).slice(2, 8)}`;
    recordedSession.current = '';
    lastTick.current = now;
    lastInteraction.current = now;
    setSession({ status: 'running', id, subjectId, elapsedSeconds: 0, durationSeconds: durationMinutes * 60, pauseReason: null });
  }, []);

  const setSubject = useCallback((subjectId: string) => {
    setSession((current) => current.status === 'running' && current.subjectId !== subjectId ? { ...current, subjectId } : current);
  }, []);

  const pause = useCallback(() => {
    setSession((current) => current.status === 'running' ? { ...current, status: 'paused', pauseReason: 'manual' } : current);
  }, []);

  const resume = useCallback(() => {
    lastTick.current = Date.now();
    lastInteraction.current = Date.now();
    setSession((current) => current.status === 'paused' ? { ...current, status: 'running', pauseReason: null } : current);
  }, []);

  const end = useCallback(() => {
    const current = sessionRef.current;
    if (current.status === 'running' || current.status === 'paused') saveSession(current, false);
    setSession((value) => ({ ...value, status: 'idle', subjectId: '', pauseReason: null }));
  }, []);

  const value = useMemo<StudySessionState>(
    () => ({ ...session, start, setSubject, pause, resume, end }),
    [session, start, setSubject, pause, resume, end],
  );

  return <StudySessionContext.Provider value={value}>{children}</StudySessionContext.Provider>;
}

export function useStudySession(): StudySessionState {
  const value = useContext(StudySessionContext);
  if (!value) throw new Error('useStudySession must be used within StudySessionProvider');
  return value;
}
