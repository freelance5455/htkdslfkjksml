import { useCallback, useEffect, useRef, useState } from 'react';
import { LiveDictationState } from '../types/recorder';
import {
  blobToBase64,
  computeRmsLevel,
  createWavBlobFromPcmChunks,
  downsampleFloat32,
  floatTo16BitPcmBase64,
} from '../utils/audioUtils';
import {
  findLanguageByCode,
  resolveEffectiveOutputLanguage,
} from '../constants/languages';
import { stitchTranscriptChunk } from '../utils/formatting';
import { hasHttpApiOrigin, transcribeLiveChunk } from '../services/geminiApiClient';

const BAR_COUNT = 24;

const INITIAL_STATE: LiveDictationState = {
  isListening: false,
  isConnected: false,
  liveRawText: '',
  interimRawText: '',
  liveTranslatedText: '',
  audioLevel: 0,
  waveformBars: Array(BAR_COUNT).fill(0.1),
  errorMessage: null,
};

interface SpeechRecognitionAlternative {
  transcript: string;
}

interface SpeechRecognitionResultItem {
  isFinal: boolean;
  0: SpeechRecognitionAlternative;
}

interface SpeechRecognitionResultEvent {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultItem>;
}

interface BrowserSpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionResultEvent) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

/**
 * Pure real-time speech-to-text hook.
 * Never creates, records, or persists any audio files.
 * Streams live mic PCM to Gemini Live WebSocket with overlapping chunk fallback
 * and seamless browser SpeechRecognition preview so words never cut off.
 */
export function useLiveDictation() {
  const [state, setState] = useState<LiveDictationState>(INITIAL_STATE);
  const [permissionDenied, setPermissionDenied] = useState(false);

  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const silentGainRef = useRef<GainNode | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const recognitionRef = useRef<BrowserSpeechRecognition | null>(null);
  const chunkIntervalRef = useRef<number | null>(null);

  // Rolling PCM buffer strictly for transient live chunk transcription (never saved)
  const pendingChunkPcmRef = useRef<Float32Array[]>([]);
  const overlapTailPcmRef = useRef<Float32Array | null>(null);

  const isListeningRef = useRef(false);
  const liveRawRef = useRef('');
  const interimRawRef = useRef('');
  const liveTranslatedRef = useRef('');
  const lastWsTextAtRef = useRef(0);
  const lastBrowserSpeechAtRef = useRef(0);
  const chunkMaxRmsRef = useRef(0);
  const chunkBusyRef = useRef(false);
  const draftGenerationRef = useRef(0);

  const cleanupPipeline = useCallback(() => {
    isListeningRef.current = false;
    if (chunkIntervalRef.current !== null) {
      window.clearInterval(chunkIntervalRef.current);
      chunkIntervalRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
      } catch {
        // Ignore
      }
      recognitionRef.current = null;
    }
    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {
        // Ignore
      }
      processorRef.current.onaudioprocess = null;
      processorRef.current = null;
    }
    if (silentGainRef.current) {
      try {
        silentGainRef.current.disconnect();
      } catch {
        // Ignore
      }
      silentGainRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (mediaStreamRef.current) {
      for (const track of mediaStreamRef.current.getTracks()) {
        track.stop();
      }
      mediaStreamRef.current = null;
    }
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // Ignore
      }
      wsRef.current = null;
    }
    pendingChunkPcmRef.current = [];
    overlapTailPcmRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      cleanupPipeline();
    };
  }, [cleanupPipeline]);

  const startListening = useCallback(
    async (
      speakingLangCode: string,
      outputLangCode: string,
      preserveExistingDraft = false
    ) => {
      cleanupPipeline();
      setPermissionDenied(false);

      if (!preserveExistingDraft) {
        liveRawRef.current = '';
        interimRawRef.current = '';
        liveTranslatedRef.current = '';
      }
      lastWsTextAtRef.current = 0;
      lastBrowserSpeechAtRef.current = 0;
      chunkMaxRmsRef.current = 0;
      chunkBusyRef.current = false;
      pendingChunkPcmRef.current = [];
      overlapTailPcmRef.current = null;

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setState((prev) => ({
          ...prev,
          errorMessage: 'Microphone access is unavailable in this browser.',
        }));
        return false;
      }

      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      } catch (err) {
        const isPermErr =
          err instanceof DOMException &&
          (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError');
        if (isPermErr) {
          setPermissionDenied(true);
        } else {
          setState((prev) => ({
            ...prev,
            errorMessage: 'Could not access your microphone. Please check device permissions.',
          }));
        }
        return false;
      }

      mediaStreamRef.current = stream;
      isListeningRef.current = true;

      // AudioContext -> silent gain (zero audio output echo) + 16kHz PCM stream
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      const audioCtx = new AudioCtx({ sampleRate: 16000 });
      if (audioCtx.state === 'suspended') {
        await audioCtx.resume().catch(() => {});
      }
      audioContextRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      const silentGain = audioCtx.createGain();
      silentGain.gain.value = 0;

      processorRef.current = processor;
      silentGainRef.current = silentGain;

      source.connect(processor);
      processor.connect(silentGain);
      silentGain.connect(audioCtx.destination);

      const speakingLang = findLanguageByCode(speakingLangCode);
      const effectiveOutputLang = resolveEffectiveOutputLanguage(
        speakingLangCode,
        outputLangCode
      );
      const shouldTranslate =
        outputLangCode !== 'same' && effectiveOutputLang.code !== speakingLangCode;

      const backendAvailable = hasHttpApiOrigin();

      // 1. Live WebSocket bridge to Gemini Live Transcription (only when hosted over HTTP/HTTPS)
      if (backendAvailable) {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${
          window.location.host
        }/ws/live?speakingLang=${encodeURIComponent(
          speakingLangCode
        )}&outputLang=${encodeURIComponent(
          outputLangCode
        )}&outputLangName=${encodeURIComponent(effectiveOutputLang.englishName)}`;

        try {
          const ws = new WebSocket(wsUrl);
          wsRef.current = ws;

          ws.onmessage = (event) => {
            try {
              const msg = JSON.parse(event.data as string) as {
                type?: string;
                text?: string;
              };
              if (msg.type === 'ready') {
                setState((prev) => ({ ...prev, isConnected: true }));
              } else if (msg.type === 'interim' && msg.text) {
                lastWsTextAtRef.current = Date.now();
                interimRawRef.current = msg.text;
                setState((prev) => ({ ...prev, interimRawText: msg.text ?? '' }));
              } else if (msg.type === 'transcript' && msg.text) {
                lastWsTextAtRef.current = Date.now();
                const nextRaw = stitchTranscriptChunk(liveRawRef.current, msg.text);
                liveRawRef.current = nextRaw;
                interimRawRef.current = '';
                pendingChunkPcmRef.current = [];
                setState((prev) => ({
                  ...prev,
                  liveRawText: nextRaw,
                  interimRawText: '',
                }));
              } else if (msg.type === 'translation' && msg.text) {
                const nextTranslated = stitchTranscriptChunk(
                  liveTranslatedRef.current,
                  msg.text
                );
                liveTranslatedRef.current = nextTranslated;
                setState((prev) => ({
                  ...prev,
                  liveTranslatedText: nextTranslated,
                }));
              } else if (msg.type === 'fallback') {
                setState((prev) => ({ ...prev, isConnected: false }));
              }
            } catch {
              // Ignore malformed WS message
            }
          };

          ws.onerror = () => {
            setState((prev) => ({ ...prev, isConnected: false }));
          };

          ws.onclose = () => {
            setState((prev) => ({ ...prev, isConnected: false }));
          };
        } catch {
          // Chunk + SpeechRecognition fallback handles seamlessly
        }
      }

      // 2. Instant browser SpeechRecognition for zero-latency word appearance
      const SpeechRecCtor =
        (
          window as unknown as {
            SpeechRecognition?: new () => BrowserSpeechRecognition;
            webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
          }
        ).SpeechRecognition ||
        (
          window as unknown as {
            webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
          }
        ).webkitSpeechRecognition;

      if (SpeechRecCtor) {
        try {
          const rec = new SpeechRecCtor();
          rec.continuous = true;
          rec.interimResults = true;
          rec.lang = speakingLangCode === 'auto' ? 'ur-PK' : speakingLangCode;

          rec.onresult = (event) => {
            // If Gemini Live WS is actively producing words, defer to WS to avoid duplicates
            if (Date.now() - lastWsTextAtRef.current < 3500 && liveRawRef.current) {
              return;
            }
            lastBrowserSpeechAtRef.current = Date.now();

            let interim = '';
            let finalized = '';
            for (let i = event.resultIndex; i < event.results.length; i += 1) {
              const res = event.results[i];
              const text = res[0]?.transcript ?? '';
              if (res.isFinal) {
                finalized += ` ${text}`;
              } else {
                interim += ` ${text}`;
              }
            }

            if (finalized.trim()) {
              const nextRaw = stitchTranscriptChunk(liveRawRef.current, finalized.trim());
              liveRawRef.current = nextRaw;
              interimRawRef.current = interim.trim();
              setState((prev) => ({
                ...prev,
                liveRawText: nextRaw,
                interimRawText: interim.trim(),
              }));

              // Translate finalized speech snippet immediately if target language differs
              if (shouldTranslate && backendAvailable) {
                const activeGen = draftGenerationRef.current;
                fetch('/api/translate-text', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    text: nextRaw,
                    targetLangName: effectiveOutputLang.englishName,
                    targetLangCode: effectiveOutputLang.code,
                  }),
                })
                  .then((r) => (r.ok ? r.json() : null))
                  .then((data: { translatedText?: string } | null) => {
                    if (
                      data?.translatedText &&
                      draftGenerationRef.current === activeGen &&
                      isListeningRef.current
                    ) {
                      liveTranslatedRef.current = data.translatedText;
                      setState((prev) => ({
                        ...prev,
                        liveTranslatedText: data.translatedText ?? prev.liveTranslatedText,
                      }));
                    }
                  })
                  .catch(() => {});
              }
            } else if (interim.trim()) {
              interimRawRef.current = interim.trim();
              setState((prev) => ({
                ...prev,
                interimRawText: interim.trim(),
              }));
            }
          };

          rec.onerror = () => {
            // Silent fallback to Gemini Live WS / chunk transcription
          };

          rec.onend = () => {
            if (isListeningRef.current) {
              try {
                rec.start();
              } catch {
                // Ignore rapid restart race
              }
            }
          };

          rec.start();
          recognitionRef.current = rec;
        } catch {
          recognitionRef.current = null;
        }
      }

      // 3. Live PCM audio frame streaming + amplitude meter
      processor.onaudioprocess = (event) => {
        if (!isListeningRef.current) return;
        const rawInput = event.inputBuffer.getChannelData(0);
        const downsampled = downsampleFloat32(rawInput, audioCtx.sampleRate, 16000);
        const copy = new Float32Array(downsampled.length);
        copy.set(downsampled);

        pendingChunkPcmRef.current.push(copy);

        const level = computeRmsLevel(copy);
        if (level > chunkMaxRmsRef.current) {
          chunkMaxRmsRef.current = level;
        }

        setState((prev) => ({
          ...prev,
          audioLevel: level,
          waveformBars: [
            ...prev.waveformBars.slice(1),
            Math.max(0.1, Math.min(1, level)),
          ],
        }));

        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          const base64Pcm = floatTo16BitPcmBase64(copy);
          wsRef.current.send(JSON.stringify({ audio: base64Pcm }));
        }
      };

      // 4. Overlapping 2.5s PCM chunk fallback (never saves files; prevents any word drop)
      if (backendAvailable) {
        chunkIntervalRef.current = window.setInterval(async () => {
          if (!isListeningRef.current || chunkBusyRef.current) return;
        const now = Date.now();
        if (
          now - lastWsTextAtRef.current < 3200 ||
          now - lastBrowserSpeechAtRef.current < 3200
        ) {
          pendingChunkPcmRef.current = [];
          chunkMaxRmsRef.current = 0;
          return;
        }

        const slice = pendingChunkPcmRef.current;
        const maxLevel = chunkMaxRmsRef.current;
        if (slice.length === 0 || maxLevel < 0.025) {
          pendingChunkPcmRef.current = [];
          chunkMaxRmsRef.current = 0;
          return;
        }

        // Prepend ~0.35s tail overlap from previous chunk so boundary words never get cut
        const chunksToSend = overlapTailPcmRef.current
          ? [overlapTailPcmRef.current, ...slice]
          : slice;
        const lastChunk = slice[slice.length - 1];
        overlapTailPcmRef.current =
          lastChunk && lastChunk.length > 0 ? lastChunk : null;

        pendingChunkPcmRef.current = [];
        chunkMaxRmsRef.current = 0;
        chunkBusyRef.current = true;
        const activeGen = draftGenerationRef.current;

        try {
          const wavBlob = createWavBlobFromPcmChunks(chunksToSend, 16000);
          const audioBase64 = await blobToBase64(wavBlob);
          const res = await transcribeLiveChunk({
            audioBase64,
            mimeType: 'audio/wav',
            speakingLangName: speakingLang.englishName,
            speakingLangCode,
            outputLangName: effectiveOutputLang.englishName,
            outputLangCode: effectiveOutputLang.code,
          });

          if (res.transcript && draftGenerationRef.current === activeGen) {
            const nextRaw = stitchTranscriptChunk(liveRawRef.current, res.transcript);
            liveRawRef.current = nextRaw;
            const nextTr = res.translation
              ? stitchTranscriptChunk(liveTranslatedRef.current, res.translation)
              : liveTranslatedRef.current;
            liveTranslatedRef.current = nextTr;

            setState((prev) => ({
              ...prev,
              liveRawText: nextRaw,
              interimRawText: '',
              liveTranslatedText: nextTr,
            }));
          }
          } finally {
            chunkBusyRef.current = false;
          }
        }, 2600);
      }

      setState({
        ...INITIAL_STATE,
        isListening: true,
        liveRawText: preserveExistingDraft ? liveRawRef.current : '',
        interimRawText: preserveExistingDraft ? interimRawRef.current : '',
        liveTranslatedText: preserveExistingDraft ? liveTranslatedRef.current : '',
      });

      return true;
    },
    [cleanupPipeline]
  );

  const stopListening = useCallback(() => {
    cleanupPipeline();
    const combinedRaw = [liveRawRef.current, interimRawRef.current]
      .filter(Boolean)
      .join(' ')
      .trim();
    const translated = liveTranslatedRef.current.trim();

    liveRawRef.current = combinedRaw;
    interimRawRef.current = '';

    setState((prev) => ({
      ...prev,
      isListening: false,
      isConnected: false,
      audioLevel: 0,
      waveformBars: Array(BAR_COUNT).fill(0.1),
      liveRawText: combinedRaw,
      interimRawText: '',
    }));

    return {
      rawText: combinedRaw,
      translatedText: translated,
    };
  }, [cleanupPipeline]);

  /**
   * Atomically grabs the current live speech draft and resets the live buffer
   * so pressing "Next" immediately writes the block below while keeping the mic running.
   */
  const consumeCurrentDraft = useCallback(() => {
    const rawText = [liveRawRef.current, interimRawRef.current]
      .filter(Boolean)
      .join(' ')
      .trim();
    const translatedText = liveTranslatedRef.current.trim();

    draftGenerationRef.current += 1;
    liveRawRef.current = '';
    interimRawRef.current = '';
    liveTranslatedRef.current = '';
    pendingChunkPcmRef.current = [];
    overlapTailPcmRef.current = null;

    setState((prev) => ({
      ...prev,
      liveRawText: '',
      interimRawText: '',
      liveTranslatedText: '',
    }));

    return { rawText, translatedText };
  }, []);

  const setDraftTranslatedText = useCallback((translated: string) => {
    liveTranslatedRef.current = translated;
    setState((prev) => ({ ...prev, liveTranslatedText: translated }));
  }, []);

  const clearError = useCallback(() => {
    setState((prev) => ({ ...prev, errorMessage: null }));
  }, []);

  const dismissPermissionModal = useCallback(() => {
    setPermissionDenied(false);
  }, []);

  return {
    liveState: state,
    permissionDenied,
    startListening,
    stopListening,
    consumeCurrentDraft,
    setDraftTranslatedText,
    clearError,
    dismissPermissionModal,
  };
}
