import { useState, useEffect, useRef, useCallback } from 'react';
import { Language } from '../types';

interface UseSpeechRecognitionOptions {
  language: Language;
  onResult?: (transcript: string) => void;
  onError?: (error: string) => void;
}

export function useSpeechRecognition({ language, onResult, onError }: UseSpeechRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      setIsSupported(true);
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';

        recognition.onstart = () => {
          setIsListening(true);
        };

        recognition.onresult = (event: any) => {
          if (event.results && event.results[0] && event.results[0][0]) {
            const spokenText = event.results[0][0].transcript.trim();
            setTranscript(spokenText);
            if (onResult) onResult(spokenText);
          }
          setIsListening(false);
        };

        recognition.onerror = (event: any) => {
          setIsListening(false);
          if (onError) onError(event.error || 'Speech recognition error');
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      } catch (err) {
        console.warn('SpeechRecognition initialization error:', err);
      }
    }
  }, [language, onResult, onError]);

  const startListening = useCallback((fallbackDemoWords: string[] = ['إسطنبول', 'باريس', 'دبي']) => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.lang = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
        recognitionRef.current.start();
        return;
      } catch {
        // Recognition might already be running or blocked
      }
    }

    // Fallback simulation if browser blocks microphone or doesn't support Web Speech API
    setIsListening(true);
    const randomPick = fallbackDemoWords[Math.floor(Math.random() * fallbackDemoWords.length)];
    const timer = setTimeout(() => {
      setTranscript(randomPick);
      if (onResult) onResult(randomPick);
      setIsListening(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, [language, onResult]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore
      }
    }
    setIsListening(false);
  }, []);

  return {
    isListening,
    transcript,
    isSupported,
    startListening,
    stopListening,
  };
}
