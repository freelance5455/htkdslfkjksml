import { ensureClubOffice } from './manager-office.js';

const clubList = state => (state?.divisions || []).flatMap(division =>
  (division.clubs || []).map(club => ({ ...club, divisionId: division.id, divisionName: division.name, divisionRank: division.rank }))
);

/** Officialise la prise de fonction une seule fois et rattache le manager au club choisi. */
export function takeManagerOffice(state) {
  const manager = state?.career?.manager;
  if (!manager) throw new Error('Crée d’abord ton profil de manager.');
  if (state.career.mode === 'unemployed' || !state.userClubId) {
    return { appointed: false, reason: 'unemployed', manager };
  }
  const club = clubList(state).find(item => item.id === state.userClubId);
  if (!club) throw new Error('Le club sélectionné est introuvable dans le catalogue.');
  if (manager.clubId && manager.clubId !== club.id) throw new Error('Le club du manager ne correspond pas au club sélectionné.');
  if (club.manager && club.manager !== manager.displayName) throw new Error('Ce club possède déjà un manager.');

  manager.clubId = club.id;
  manager.mode = state.career.mode || 'club';
  club.manager = manager.displayName;
  state.career.started = true;
  state.career.officeActivated = true;
  state.career.appointedAt ??= {
    season: Number(state.season) || 1,
    day: Number(state.calendar?.currentDay || state.day || 1),
    clubId: club.id,
    clubName: club.name
  };
  state.career.history ??= [];
  const alreadyRecorded = state.career.history.some(item => item.type === 'appointment' && item.clubId === club.id);
  if (!alreadyRecorded) state.career.history.unshift({
    type: 'appointment', clubId: club.id, clubName: club.name,
    season: state.career.appointedAt.season, day: state.career.appointedAt.day
  });
  const office = ensureClubOffice(state)?.office || null;
  return { appointed: true, club, office, manager, appointedAt: state.career.appointedAt };
}

/** Données agrégées du tableau de bord ; aucune simulation ni écriture de sauvegarde. */
export function getManagerDashboard(state) {
  const manager = state?.career?.manager;
  if (!manager) return null;
  const clubs = clubList(state);
  const club = clubs.find(item => item.id === state.userClubId) || null;
  const division = club ? (state.divisions || []).find(item => item.id === club.divisionId) : null;
  const day = Number(state.calendar?.currentDay || state.day || 1);
  const fixtures = state.calendar?.fixtures || [];
  const ownFixtures = club ? fixtures.filter(item => item.home === club.id || item.away === club.id) : [];
  const upcoming = ownFixtures.filter(item => item.status === 'scheduled').sort((a, b) =>
    Number(a.absoluteDay ?? a.scheduledDay ?? a.scheduledMatchday ?? a.round ?? 99999) - Number(b.absoluteDay ?? b.scheduledDay ?? b.scheduledMatchday ?? b.round ?? 99999)
  ).slice(0, 5);
  const results = ownFixtures.filter(item => item.status === 'played').slice(-5).reverse();
  const inbox = state.management?.inbox || [];
  const unread = inbox.filter(item => item.status !== 'answered').length;
  const office = club ? (ensureClubOffice(state)?.office || club.office || null) : null;
  const finance = office?.finance || { cash: Number(club?.budget) || 0, transferBudget: 0, wageBudget: 0 };
  const board = office?.board || { confidence: Number(state.management?.relations?.boardConfidence ?? 50), objectives: [] };
  const gate = club ? null : 'Sans emploi';
  return {
    manager, club, division, season: Number(state.season) || 1, day,
    upcoming, results, unread, finance, board,
    playerCount: club?.damistes?.length || 0,
    staffCount: office?.staff?.length || 0,
    appointment: state.career?.appointedAt || null,
    gate
  };
}

/** Vue éditoriale et sportive du monde CGD, calculée sans modifier la sauvegarde. */
export function getDashboardUniverse(state) {
  const divisions = (state?.divisions || []).filter(d => d.status === 'active');
  const clubs = divisions.flatMap(d => (d.clubs || []).map(club => ({ ...club, divisionName: d.name, divisionRank: d.rank })));
  const played = (state?.calendar?.fixtures || []).filter(f => f.status === 'played');
  const scheduled = (state?.calendar?.fixtures || []).filter(f => f.status === 'scheduled');
  const damistes = clubs.flatMap(club => (club.damistes || []).map(player => ({ ...player, clubName: club.name, clubId: club.id, divisionName: club.divisionName })));
  const ranking = [...clubs].sort((a,b) => (b.points||0)-(a.points||0) || ((b.gf||0)-(b.ga||0))-((a.gf||0)-(a.ga||0)) || (b.gf||0)-(a.gf||0));
  const topDamistes = [...damistes].sort((a,b) => (b.level||0)-(a.level||0) || (b.form||0)-(a.form||0)).slice(0,5);
  const news = [
    ...(state?.management?.inbox || []).map(item => ({ date: item.createdAt || item.date || '', title: item.subject || item.from || 'Message du monde CGD', detail: item.body || '', type: item.type || 'info' })),
    ...(state?.history?.notices || []).map(item => ({ date: item.date || '', title: item.text || 'Information officielle', detail: item.divisionId || '', type: 'official' })),
    ...(state?.management?.press?.history || []).map(item => ({ date: item.answeredAt || '', title: item.subject || 'Écho de la presse', detail: item.response || '', type: 'press' }))
  ].sort((a,b) => String(b.date).localeCompare(String(a.date))).slice(0,6);
  const calendar = [...scheduled].sort((a,b) => Number(a.absoluteDay ?? a.scheduledDay ?? a.round ?? 99999)-Number(b.absoluteDay ?? b.scheduledDay ?? b.round ?? 99999)).slice(0,6);
  return { divisions, clubs, playedCount: played.length, scheduledCount: scheduled.length, ranking: ranking.slice(0,8), topDamistes, news, calendar,
    stats: { clubs: clubs.length, damistes: damistes.length, divisions: divisions.length, played: played.length, scheduled: scheduled.length } };
}
