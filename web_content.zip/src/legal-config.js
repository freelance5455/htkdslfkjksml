/* ──────────────────────────────────────────────────────────────────────────
   LEGAL CONFIG — fill these in BEFORE publishing (open index.html in a text editor, or edit this file and rebuild).
   تنظیمات حقوقی — پیش از انتشار این مقادیر را پر کنید.
   Empty values show up highlighted as [owner], [email]… inside the Terms and Privacy texts and in Settings → Legal.
   ────────────────────────────────────────────────────────────────────────── */
window.AN_LEGAL_CONFIG = {
  owner: "",          // legal name of the person/company that operates AccoNova  (نام حقوقی مالک/شرکت)
  email: "",          // contact e-mail for legal and privacy questions            (ایمیل تماس)
  jurisdiction: "",   // governing law and courts, e.g. "Islamic Republic of Iran" / "England and Wales"  (قانون و مرجع رسیدگی)
  refundPolicy: "",   // e.g. "no refund for a started month unless required by law"  (سیاست بازپرداخت)
  version: "1.0",     // bump when the texts change — users are asked to accept again
  effective: "2026-10-17"
};
