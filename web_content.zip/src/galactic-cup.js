import { recordResult } from './calendar.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';

export const GALACTIC_CUP_ID = 'coupe-galactique';
export const GALACTIC_CUP_NAME = 'Coupe Galactique';
const ROUND_LABELS = ['Quarts de finale', 'Demi-finales', 'Finale'];
const MATCHDAYS = [6, 12, 18];

function hash(text) {
  let h = 2166136261;
  for (const ch of text) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function seededOrder(ids, seed) {
  return [...ids].sort((a, b) => hash(`${seed}|${a}`) - hash(`${seed}|${b}`) || a.localeCompare(b));
}
function allClubs(state) { return state.divisions.filter(d => d.status === 'active').flatMap(d => d.clubs); }
function makeFixture(state, round, home, away, index) {
  return { id: `S${state.season}:${GALACTIC_CUP_ID}:R${round}:${index}:${home}:${away}`, season: state.season,
    divisionId: null, competitionId: GALACTIC_CUP_ID, competitionName: GALACTIC_CUP_NAME,
    round, roundLabel: ROUND_LABELS[round - 1], scheduledMatchday: MATCHDAYS[round - 1], home, away, venueType: 'club-arena',
    status: 'scheduled', score: null, playedAt: null, arenaId: 'terrestrial' };
}

/** V116 : huit clubs, dont le club dirigé, puis quarts, demi-finales et finale. */
export function createGalacticCupSeason(state) {
  const cup = state.competitions.find(c => c.id === GALACTIC_CUP_ID);
  if (!cup) throw new Error('La Coupe Galactique est absente du registre');
  if (cup.season === state.season && cup.status !== 'pending') return [];
  const clubs = allClubs(state);
  if (!clubs.some(c => c.id === state.userClubId) || clubs.length < 8) throw new Error('La Coupe Galactique exige le club dirigé et au moins sept autres clubs actifs');
  const others = seededOrder(clubs.map(c => c.id).filter(id => id !== state.userClubId), `CGD|${state.season}|${GALACTIC_CUP_ID}|selection`).slice(0, 7);
  const entrants = [state.userClubId, ...others];
  cup.season = state.season;
  cup.status = 'in-progress';
  cup.format = { type: 'knockout', entrants: 8, rounds: ROUND_LABELS, legs: 1, source: 'V116' };
  cup.championId = null;
  cup.rounds = [];
  cup.fixtures = [];
  return createRound(state, cup, entrants, 1);
}

function createRound(state, cup, entrants, roundNumber) {
  const ordered = seededOrder(entrants, `CGD|${state.season}|${GALACTIC_CUP_ID}|R${roundNumber}`);
  if (ordered.length !== 2 ** (4 - roundNumber)) throw new Error('Tableau invalide pour la Coupe Galactique');
  const fixtures = [];
  for (let i = 0; i < ordered.length; i += 2) {
    const [home, away] = hash(`${state.season}|${roundNumber}|${ordered[i]}|${ordered[i + 1]}`) % 2
      ? [ordered[i], ordered[i + 1]] : [ordered[i + 1], ordered[i]];
    fixtures.push(makeFixture(state, roundNumber, home, away, i / 2 + 1));
  }
  const round = { number: roundNumber, label: ROUND_LABELS[roundNumber - 1], participants: [...entrants], fixtureIds: fixtures.map(f => f.id), completed: false, advancedClubIds: [] };
  cup.rounds.push(round);
  cup.fixtures.push(...fixtures.map(f => f.id));
  state.calendar.fixtures.push(...fixtures);
  scheduleCompetitionCalendar(state);
  return fixtures;
}

export function resolveGalacticCupDraw(fixture, winnerId) {
  if (winnerId) return winnerId;
  return hash(`${fixture.id}|V116-tie-break`) % 2 ? fixture.home : fixture.away;
}

export function recordGalacticCupResult(state, fixtureId, homeScore, awayScore, { winnerId = null, matchDetails = {} } = {}) {
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId && f.competitionId === GALACTIC_CUP_ID);
  if (!fixture) throw new Error('Rencontre de Coupe Galactique introuvable');
  if (fixture.status === 'played') return { accepted: false, nextFixtures: [] };
  if (![homeScore, awayScore].every(n => Number.isInteger(n) && n >= 0)) throw new Error('Score invalide');
  if (homeScore === awayScore) winnerId = resolveGalacticCupDraw(fixture, winnerId);
  else winnerId = homeScore > awayScore ? fixture.home : fixture.away;
  if (![fixture.home, fixture.away].includes(winnerId)) throw new Error('Vainqueur absent de la rencontre');
  const accepted = recordResult(state, fixtureId, homeScore, awayScore, matchDetails);
  if (!accepted) return { accepted: false, nextFixtures: [] };
  fixture.winnerId = winnerId;
  fixture.matchDetails = { ...matchDetails, winnerId, tieBreak: homeScore === awayScore ? 'V116-deterministic-draw-decision' : null };
  const cup = state.competitions.find(c => c.id === GALACTIC_CUP_ID);
  const round = cup.rounds.find(r => r.fixtureIds.includes(fixtureId));
  if (!round) throw new Error('Tour de Coupe Galactique introuvable');
  round.advancedClubIds = round.fixtureIds.map(id => state.calendar.fixtures.find(f => f.id === id)?.winnerId).filter(Boolean);
  if (!round.fixtureIds.every(id => state.calendar.fixtures.find(f => f.id === id)?.status === 'played')) return { accepted: true, nextFixtures: [] };
  round.completed = true;
  if (round.number === 3) {
    cup.status = 'completed'; cup.championId = round.advancedClubIds[0]; cup.completedAtSeason = state.season;
    return { accepted: true, nextFixtures: [] };
  }
  const nextFixtures = createRound(state, cup, round.advancedClubIds, round.number + 1);
  return { accepted: true, nextFixtures };
}

export function getGalacticCupStatus(state) {
  const cup = state.competitions.find(c => c.id === GALACTIC_CUP_ID);
  if (!cup) return null;
  const round = cup.rounds?.at(-1) ?? null;
  return { name: GALACTIC_CUP_NAME, status: cup.status, participantCount: cup.format ? 8 : 0,
    round: round?.number ?? 0, roundLabel: round?.label ?? 'À venir',
    pendingFixtures: round?.fixtureIds.filter(id => state.calendar.fixtures.find(f => f.id === id)?.status !== 'played').length ?? 0,
    requiredMatchday: round ? MATCHDAYS[round.number - 1] : null,
    championId: cup.championId ?? null };
}

export function validateGalacticCup(state) {
  const cup = state.competitions.find(c => c.id === GALACTIC_CUP_ID);
  if (!cup) throw new Error('Coupe Galactique manquante');
  if (cup.status === 'in-progress' || cup.status === 'completed') {
    if (cup.format?.entrants !== 8 || cup.rounds?.length < 1) throw new Error('Tableau de Coupe Galactique incomplet');
    if (new Set(cup.fixtures).size !== cup.fixtures.length) throw new Error('Rencontre dupliquée dans la Coupe Galactique');
    for (const id of cup.fixtures) if (!state.calendar.fixtures.some(f => f.id === id && f.competitionId === GALACTIC_CUP_ID)) throw new Error(`Rencontre absente du calendrier central : ${id}`);
  }
  return true;
}
