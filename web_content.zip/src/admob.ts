import { AdMob, RewardAdPluginEvents, AdMobRewardItem } from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';

export const ADMOB_REWARDED_AD_UNIT_ID = 'ca-app-pub-7257687669217703/5696349618';
export const ADMOB_APP_ID = 'ca-app-pub-7257687669217703~4909222410';
export const REWARDED_COINS_AMOUNT = 10;

let isInitialized = false;

/**
 * Initialize AdMob SDK on Android / Native platforms with production configuration
 */
export async function initAdMob(): Promise<void> {
  if (!Capacitor.isNativePlatform() || isInitialized) return;
  try {
    await AdMob.initialize({
      initializeForTesting: false,
    });
    isInitialized = true;
  } catch (err) {
    console.warn('AdMob initialization notice:', err);
  }
}

/**
 * Show Google AdMob Rewarded Ad
 * Only grants the 10 coins after the ad is fully watched/completed.
 */
export async function showNativeRewardedAd(): Promise<{
  success: boolean;
  rewardEarned: boolean;
  error?: string;
}> {
  if (!Capacitor.isNativePlatform()) {
    return { success: false, rewardEarned: false, error: 'NOT_NATIVE' };
  }

  await initAdMob();

  return new Promise(async (resolve) => {
    let rewardEarned = false;
    let cleanupListeners: (() => void) | null = null;

    try {
      // 1. Listen for reward completion event
      const rewardedListener = await AdMob.addListener(
        RewardAdPluginEvents.Rewarded,
        (reward: AdMobRewardItem) => {
          console.log('AdMob Rewarded video ad completed. Reward granted:', reward);
          rewardEarned = true;
        }
      );

      // 2. Listen for dismiss event
      const dismissedListener = await AdMob.addListener(
        RewardAdPluginEvents.Dismissed,
        () => {
          console.log('AdMob Rewarded ad dismissed. Reward earned:', rewardEarned);
          if (cleanupListeners) cleanupListeners();
          resolve({ success: true, rewardEarned });
        }
      );

      // 3. Listen for failure
      const failedListener = await AdMob.addListener(
        RewardAdPluginEvents.FailedToShow,
        (error) => {
          console.warn('AdMob Rewarded ad failed to show:', error);
          if (cleanupListeners) cleanupListeners();
          resolve({ success: false, rewardEarned: false, error: 'FAILED_TO_SHOW' });
        }
      );

      cleanupListeners = () => {
        rewardedListener.remove();
        dismissedListener.remove();
        failedListener.remove();
      };

      // Load production rewarded ad using the user's specific Ad Unit ID
      await AdMob.prepareRewardVideoAd({
        adId: ADMOB_REWARDED_AD_UNIT_ID,
        isTesting: false,
      });

      // Present the full-screen rewarded video ad
      await AdMob.showRewardVideoAd();
    } catch (err) {
      console.warn('AdMob prepare/show error:', err);
      if (cleanupListeners) cleanupListeners();
      resolve({ success: false, rewardEarned: false, error: String(err) });
    }
  });
}
