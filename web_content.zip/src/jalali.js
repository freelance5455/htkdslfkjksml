/* Solar Hijri (Jalali) <-> Gregorian conversion, integer-only, no Intl dependency.
   Algorithm: 33-year-cycle break table (valid for Jalali years -61 … 3177). */
(function (root) {
  "use strict";
  var BREAKS = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  function div(a, b) { return ~~(a / b); }
  function mod(a, b) { return a - ~~(a / b) * b; }

  function jalCal(jy) {
    var bl = BREAKS.length, gy = jy + 621, leapJ = -14, jp = BREAKS[0], jm, jump = 0, n, i, leapG, march;
    if (jy < jp || jy >= BREAKS[bl - 1]) throw new RangeError("Invalid Jalali year " + jy);
    for (i = 1; i < bl; i += 1) {
      jm = BREAKS[i]; jump = jm - jp;
      if (jy < jm) break;
      leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
      jp = jm;
    }
    n = jy - jp;
    leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
    if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
    leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
    march = 20 + leapJ - leapG;
    if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
    var leap = mod(mod(n + 1, 33) - 1, 4);
    if (leap === -1) leap = 4;
    return { leap: leap, gy: gy, march: march };
  }
  function g2d(gy, gm, gd) {
    var d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) + div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408;
    d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
    return d;
  }
  function d2g(jdn) {
    var j = 4 * jdn + 139361631;
    j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
    var i = div(mod(j, 1461), 4) * 5 + 308;
    var gd = div(mod(i, 153), 5) + 1, gm = mod(div(i, 153), 12) + 1, gy = div(j, 1461) - 100100 + div(8 - gm, 6);
    return { gy: gy, gm: gm, gd: gd };
  }
  function j2d(jy, jm, jd) {
    var r = jalCal(jy);
    return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
  }
  function d2j(jdn) {
    var gy = d2g(jdn).gy, jy = gy - 621, r = jalCal(jy), jdn1f = g2d(gy, 3, r.march), jm, jd, k = jdn - jdn1f;
    if (k >= 0) {
      if (k <= 185) { jm = 1 + div(k, 31); jd = mod(k, 31) + 1; return { jy: jy, jm: jm, jd: jd }; }
      k -= 186;
    } else {
      jy -= 1; k += 179;
      if (r.leap === 1) k += 1;
    }
    jm = 7 + div(k, 30); jd = mod(k, 30) + 1;
    return { jy: jy, jm: jm, jd: jd };
  }
  function isLeapJalali(jy) { return jalCal(jy).leap === 0; }
  function jalaliMonthLength(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return isLeapJalali(jy) ? 30 : 29;
  }
  function isValidJalali(jy, jm, jd) {
    return Number.isInteger(jy) && Number.isInteger(jm) && Number.isInteger(jd) && jy >= -61 && jy < 3177 && jm >= 1 && jm <= 12 && jd >= 1 && jd <= jalaliMonthLength(jy, jm);
  }
  function gregorianMonthLength(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); }
  function isValidGregorian(y, m, d) {
    return Number.isInteger(y) && Number.isInteger(m) && Number.isInteger(d) && y >= 1 && y <= 9999 && m >= 1 && m <= 12 && d >= 1 && d <= gregorianMonthLength(y, m);
  }
  function toJalali(gy, gm, gd) { var r = d2j(g2d(gy, gm, gd)); return { y: r.jy, m: r.jm, d: r.jd }; }
  function toGregorian(jy, jm, jd) { var r = d2g(j2d(jy, jm, jd)); return { y: r.gy, m: r.gm, d: r.gd }; }
  /* ISO "YYYY-MM-DD" helpers */
  function pad(n, w) { n = String(n); while (n.length < w) n = "0" + n; return n; }
  function isoFrom(y, m, d) { return pad(y, 4) + "-" + pad(m, 2) + "-" + pad(d, 2); }
  function parseIso(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s));
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    return isValidGregorian(y, mo, d) ? { y: y, m: mo, d: d } : null;
  }
  /* Accept Persian/Arabic digits; separators / - . ; returns ISO or null. kind: "jalali" | "gregorian" */
  function normDigits(s) {
    return String(s).replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 0x06F0; })
      .replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 0x0660; })
      .replace(/[٫٬،]/g, "/");
  }
  function parseDateInput(s, kind) {
    var t = normDigits(s).trim().replace(/[.\-\s]+/g, "/");
    var m = /^(\d{1,4})\/(\d{1,2})\/(\d{1,4})$/.exec(t);
    if (!m) return null;
    var a = +m[1], b = +m[2], c = +m[3], y, mo, d;
    if (String(m[1]).length >= 3) { y = a; mo = b; d = c; } else if (String(m[3]).length >= 3) { y = c; mo = b; d = a; } else return null;
    if (kind === "jalali") {
      if (!isValidJalali(y, mo, d)) return null;
      var g = toGregorian(y, mo, d); return isoFrom(g.y, g.m, g.d);
    }
    return isValidGregorian(y, mo, d) ? isoFrom(y, mo, d) : null;
  }
  function isoToJalali(iso) { var p = parseIso(iso); return p ? toJalali(p.y, p.m, p.d) : null; }
  function addDaysIso(iso, n) {
    var p = parseIso(iso), t = Date.UTC(p.y, p.m - 1, p.d) + n * 864e5, d = new Date(t);
    return isoFrom(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
  }
  function diffDaysIso(a, b) { /* b - a */
    var x = parseIso(a), y = parseIso(b);
    return Math.round((Date.UTC(y.y, y.m - 1, y.d) - Date.UTC(x.y, x.m - 1, x.d)) / 864e5);
  }
  var API = {
    toJalali: toJalali, toGregorian: toGregorian, isLeapJalali: isLeapJalali, jalaliMonthLength: jalaliMonthLength,
    isValidJalali: isValidJalali, isValidGregorian: isValidGregorian, gregorianMonthLength: gregorianMonthLength,
    isoFrom: isoFrom, parseIso: parseIso, parseDateInput: parseDateInput, isoToJalali: isoToJalali,
    addDaysIso: addDaysIso, diffDaysIso: diffDaysIso, normDigits: normDigits
  };
  if (typeof module === "object" && module.exports) module.exports = API; else root.AN_J = API;
})(typeof globalThis !== "undefined" ? globalThis : this);
