import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { DEFAULT_DAILY_LIMIT } from "../ai/config";

// ---------------------------------------------------------------------------
// Honest quota tracking.
//
// This project is a static frontend with no backend of its own deployed by
// default, so there is no reliable, secure way to identify a "user" or
// enforce a tamper-proof quota purely in the browser. What we track here is
// a DEVICE-BASED counter stored in localStorage:
//   - It survives page refreshes (it is not component state).
//   - It resets once per day, at UTC midnight (a single, consistent
//     "server-side" time zone, rather than the user's local clock, which
//     could be changed to bypass the limit).
//   - It is NOT a secure per-account limit: clearing site data, using a
//     different browser, or private/incognito mode will reset it. This is
//     clearly surfaced in the UI (see AiTutor.tsx) rather than claimed to be
//     a secure per-user quota.
//   - If a real backend is deployed (see AI_TUTOR_SETUP.md) and it reports
//     an authoritative `remainingToday`, the UI prefers that number instead.
// ---------------------------------------------------------------------------

const USAGE_KEY = "formulaverse-ai-usage";
const DEVICE_KEY = "formulaverse-device-id";

interface UsageRecord {
  dateUTC: string; // yyyy-mm-dd in UTC
  count: number;
}

function todayUTC(): string {
  return new Date().toISOString().slice(0, 10);
}

function nextResetISO(): string {
  const now = new Date();
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
  return next.toISOString();
}

function getDeviceId(): string {
  try {
    let id = localStorage.getItem(DEVICE_KEY);
    if (!id) {
      id = `dev_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
      localStorage.setItem(DEVICE_KEY, id);
    }
    return id;
  } catch {
    return "dev_unknown";
  }
}

function loadUsage(): UsageRecord {
  try {
    const raw = localStorage.getItem(USAGE_KEY);
    if (!raw) return { dateUTC: todayUTC(), count: 0 };
    const parsed = JSON.parse(raw) as UsageRecord;
    if (parsed.dateUTC !== todayUTC()) return { dateUTC: todayUTC(), count: 0 };
    return parsed;
  } catch {
    return { dateUTC: todayUTC(), count: 0 };
  }
}

interface AiUsageValue {
  used: number;
  limit: number;
  remaining: number;
  resetAt: string;
  deviceId: string;
  canSend: boolean;
  recordMessageSent: () => void;
  /** Called when a backend reports an authoritative remaining count, so the
   *  UI reflects the real server-enforced quota rather than only the local
   *  estimate. */
  syncFromServer: (remainingToday: number) => void;
}

const AiUsageContext = createContext<AiUsageValue | null>(null);

export function AiUsageProvider({ children }: { children: ReactNode }) {
  const [record, setRecord] = useState<UsageRecord>(() => loadUsage());
  const [deviceId] = useState<string>(() => getDeviceId());
  const limit = DEFAULT_DAILY_LIMIT;

  useEffect(() => {
    localStorage.setItem(USAGE_KEY, JSON.stringify(record));
  }, [record]);

  // Re-check for a day rollover periodically (covers the case where the tab
  // stays open across midnight UTC).
  useEffect(() => {
    const interval = setInterval(() => {
      setRecord((prev) => (prev.dateUTC !== todayUTC() ? { dateUTC: todayUTC(), count: 0 } : prev));
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const recordMessageSent = useCallback(() => {
    setRecord((prev) => {
      const current = prev.dateUTC === todayUTC() ? prev : { dateUTC: todayUTC(), count: 0 };
      return { dateUTC: current.dateUTC, count: current.count + 1 };
    });
  }, []);

  const syncFromServer = useCallback(
    (remainingToday: number) => {
      setRecord({ dateUTC: todayUTC(), count: Math.max(0, limit - remainingToday) });
    },
    [limit]
  );

  const used = record.dateUTC === todayUTC() ? record.count : 0;
  const remaining = Math.max(0, limit - used);

  const value = useMemo<AiUsageValue>(
    () => ({
      used,
      limit,
      remaining,
      resetAt: nextResetISO(),
      deviceId,
      canSend: remaining > 0,
      recordMessageSent,
      syncFromServer,
    }),
    [used, limit, remaining, deviceId, recordMessageSent, syncFromServer]
  );

  return <AiUsageContext.Provider value={value}>{children}</AiUsageContext.Provider>;
}

export function useAiUsage(): AiUsageValue {
  const ctx = useContext(AiUsageContext);
  if (!ctx) throw new Error("useAiUsage must be used within AiUsageProvider");
  return ctx;
}
