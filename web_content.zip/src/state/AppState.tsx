import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Board, ClassLevel, Subject } from "../data/types";

export type Screen =
  | { name: "home" }
  | { name: "class"; classLevel: ClassLevel; subject?: Subject; chapter?: string }
  | { name: "search" }
  | { name: "favorites" }
  | { name: "recent" }
  | { name: "solver" }
  | { name: "history" }
  | { name: "quiz" }
  | { name: "ai" }
  | { name: "formula"; id: string };

interface AppStateValue {
  theme: "light" | "dark";
  toggleTheme: () => void;
  board: Board;
  setBoard: (b: Board) => void;
  favorites: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  recent: string[];
  addRecent: (id: string) => void;
  screen: Screen;
  navigate: (s: Screen) => void;
  back: () => void;
  canGoBack: boolean;
}

const AppStateContext = createContext<AppStateValue | null>(null);

const FAVORITES_KEY = "formulaverse-favorites";
const THEME_KEY = "formulaverse-theme";
const BOARD_KEY = "formulaverse-board";

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") return stored;
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });

  const [board, setBoardState] = useState<Board>(() => {
    const stored = localStorage.getItem(BOARD_KEY);
    return stored === "CBSE" || stored === "ICSE" ? stored : "CBSE";
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(FAVORITES_KEY);
      return raw ? (JSON.parse(raw) as string[]) : [];
    } catch {
      return [];
    }
  });

  // Recently viewed is session-only (not persisted across reloads).
  const [recent, setRecent] = useState<string[]>([]);

  const [history, setHistory] = useState<Screen[]>([{ name: "home" }]);
  const screen = history[history.length - 1];

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem(BOARD_KEY, board);
  }, [board]);

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === "light" ? "dark" : "light"));
  }, []);

  const setBoard = useCallback((b: Board) => setBoardState(b), []);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  }, []);

  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  const addRecent = useCallback((id: string) => {
    setRecent((r) => [id, ...r.filter((x) => x !== id)].slice(0, 20));
  }, []);

  const navigate = useCallback((s: Screen) => {
    setHistory((h) => [...h, s]);
  }, []);

  const back = useCallback(() => {
    setHistory((h) => (h.length > 1 ? h.slice(0, -1) : h));
  }, []);

  const value = useMemo<AppStateValue>(
    () => ({
      theme,
      toggleTheme,
      board,
      setBoard,
      favorites,
      toggleFavorite,
      isFavorite,
      recent,
      addRecent,
      screen,
      navigate,
      back,
      canGoBack: history.length > 1,
    }),
    [theme, toggleTheme, board, setBoard, favorites, toggleFavorite, isFavorite, recent, addRecent, screen, navigate, back, history.length]
  );

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState(): AppStateValue {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error("useAppState must be used within AppStateProvider");
  return ctx;
}
