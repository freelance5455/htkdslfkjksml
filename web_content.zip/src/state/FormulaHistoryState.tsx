import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Board, ClassLevel, Subject } from "../data/types";
import type { FormulaUsage } from "../solver/types";

export interface FormulaHistoryEntry extends FormulaUsage {
  id: string;
  question: string;
  reason: string;
  firstUsedAt: string; // ISO timestamp
  lastUsedAt: string; // ISO timestamp
  usageCount: number;
}

interface FormulaHistoryValue {
  entries: FormulaHistoryEntry[];
  recordUsage: (usage: FormulaUsage, question: string, reason: string) => void;
  removeEntry: (id: string) => void;
  clearAll: () => void;
}

const FormulaHistoryContext = createContext<FormulaHistoryValue | null>(null);

const HISTORY_KEY = "formulaverse-formula-history";

function entryKey(usage: FormulaUsage): string {
  // Dedupe by formulaId when it exists (library formula), otherwise by name+expression.
  return usage.formulaId ?? `${usage.name}::${usage.expression}`;
}

export function FormulaHistoryProvider({ children }: { children: ReactNode }) {
  const [entries, setEntries] = useState<FormulaHistoryEntry[]>(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      return raw ? (JSON.parse(raw) as FormulaHistoryEntry[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(entries));
    } catch {
      /* storage may be unavailable (e.g. private browsing quota) — fail silently */
    }
  }, [entries]);

  const recordUsage = useCallback((usage: FormulaUsage, question: string, reason: string) => {
    setEntries((prev) => {
      const key = entryKey(usage);
      const now = new Date().toISOString();
      const existingIdx = prev.findIndex((e) => entryKey(e) === key);
      if (existingIdx >= 0) {
        const updated = [...prev];
        const existing = updated[existingIdx];
        updated[existingIdx] = {
          ...existing,
          ...usage,
          question,
          reason,
          lastUsedAt: now,
          usageCount: existing.usageCount + 1,
        };
        // Move most-recently-used entry to the front.
        const [moved] = updated.splice(existingIdx, 1);
        return [moved, ...updated];
      }
      const newEntry: FormulaHistoryEntry = {
        ...usage,
        id: `${key}-${now}-${Math.random().toString(36).slice(2, 8)}`,
        question,
        reason,
        firstUsedAt: now,
        lastUsedAt: now,
        usageCount: 1,
      };
      return [newEntry, ...prev];
    });
  }, []);

  const removeEntry = useCallback((id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setEntries([]);
  }, []);

  const value = useMemo<FormulaHistoryValue>(() => ({ entries, recordUsage, removeEntry, clearAll }), [entries, recordUsage, removeEntry, clearAll]);

  return <FormulaHistoryContext.Provider value={value}>{children}</FormulaHistoryContext.Provider>;
}

export function useFormulaHistory(): FormulaHistoryValue {
  const ctx = useContext(FormulaHistoryContext);
  if (!ctx) throw new Error("useFormulaHistory must be used within FormulaHistoryProvider");
  return ctx;
}

export function filterHistory(
  entries: FormulaHistoryEntry[],
  opts: { search?: string; subject?: Subject | "All"; classLevel?: ClassLevel | "All"; topic?: string | "All"; board?: Board | "All" }
): FormulaHistoryEntry[] {
  return entries.filter((e) => {
    if (opts.subject && opts.subject !== "All" && e.subject !== opts.subject) return false;
    if (opts.classLevel && opts.classLevel !== "All" && e.classLevel !== opts.classLevel) return false;
    if (opts.topic && opts.topic !== "All" && e.topic !== opts.topic) return false;
    if (opts.board && opts.board !== "All" && e.board && e.board !== opts.board) return false;
    if (opts.search) {
      const q = opts.search.toLowerCase();
      const haystack = `${e.name} ${e.expression} ${e.topic ?? ""} ${e.subject ?? ""} ${e.question}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });
}
