import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { ClassLevel, Subject } from "../data/types";
import type { Difficulty } from "../data/quiz";

export interface QuizPreferences {
  classLevel: ClassLevel;
  subject: Subject;
  difficulty: Difficulty | "All";
}

export interface QuizStats {
  attempted: number;
  correct: number;
  bestStreak: number;
}

interface QuizStateValue {
  prefs: QuizPreferences;
  setPrefs: (p: QuizPreferences) => void;
  stats: QuizStats;
  recordAnswer: (wasCorrect: boolean) => void;
  resetStats: () => void;
}

const QuizStateContext = createContext<QuizStateValue | null>(null);

const PREFS_KEY = "formulaverse-quiz-prefs";
const STATS_KEY = "formulaverse-quiz-stats";

const DEFAULT_PREFS: QuizPreferences = { classLevel: 9, subject: "Mathematics", difficulty: "All" };
const DEFAULT_STATS: QuizStats = { attempted: 0, correct: 0, bestStreak: 0 };

export function QuizStateProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefsState] = useState<QuizPreferences>(() => {
    try {
      const raw = localStorage.getItem(PREFS_KEY);
      return raw ? { ...DEFAULT_PREFS, ...JSON.parse(raw) } : DEFAULT_PREFS;
    } catch {
      return DEFAULT_PREFS;
    }
  });

  const [stats, setStats] = useState<QuizStats>(() => {
    try {
      const raw = localStorage.getItem(STATS_KEY);
      return raw ? { ...DEFAULT_STATS, ...JSON.parse(raw) } : DEFAULT_STATS;
    } catch {
      return DEFAULT_STATS;
    }
  });

  const [, setCurrentStreak] = useState(0);

  useEffect(() => {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  }, [prefs]);

  useEffect(() => {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  }, [stats]);

  const setPrefs = useCallback((p: QuizPreferences) => setPrefsState(p), []);

  const recordAnswer = useCallback((wasCorrect: boolean) => {
    setStats((prev) => ({
      attempted: prev.attempted + 1,
      correct: prev.correct + (wasCorrect ? 1 : 0),
      bestStreak: prev.bestStreak,
    }));
    setCurrentStreak((s) => {
      const next = wasCorrect ? s + 1 : 0;
      setStats((prev) => ({ ...prev, bestStreak: Math.max(prev.bestStreak, next) }));
      return next;
    });
  }, []);

  const resetStats = useCallback(() => {
    setStats(DEFAULT_STATS);
    setCurrentStreak(0);
  }, []);

  const value = useMemo<QuizStateValue>(() => ({ prefs, setPrefs, stats, recordAnswer, resetStats }), [prefs, setPrefs, stats, recordAnswer, resetStats]);

  return <QuizStateContext.Provider value={value}>{children}</QuizStateContext.Provider>;
}

export function useQuizState(): QuizStateValue {
  const ctx = useContext(QuizStateContext);
  if (!ctx) throw new Error("useQuizState must be used within QuizStateProvider");
  return ctx;
}
