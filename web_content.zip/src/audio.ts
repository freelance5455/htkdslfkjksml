import { AudioSettings } from "./storage";

/**
 * Synced procedural audio — no samples, no network.
 * The pour loop is driven every animation frame from GameScreen via
 * updatePour(flow, fill) so hiss, gurgle and droplet pitch always match
 * the visible stream width and the rising water level.
 */
class AquaAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private waterBus: GainNode | null = null;
  private glassBus: GainNode | null = null;
  private ambientBus: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private settings: AudioSettings = { sound: true, water: true, ambient: true, volume: 0.7 };

  // Pour loop nodes (created on startPour, destroyed on stopPour)
  private pourNodes: AudioScheduledSourceNode[] = [];
  private pourHissGain: GainNode | null = null;
  private pourBodyGain: GainNode | null = null;
  private pourBodyFilter: BiquadFilterNode | null = null;
  private pourBodyFilter2: BiquadFilterNode | null = null;
  private pourGlugGain: GainNode | null = null;
  private pourGlugOsc: OscillatorNode | null = null;
  private pourActive = false;
  private pourAmount = 1;
  private lastDroplet = 0;

  private ambientSource: AudioBufferSourceNode | null = null;
  private ambientOscillator: OscillatorNode | null = null;
  private ambientTimer: number | null = null;
  private available = true;

  get supported() {
    return this.available;
  }

  unlock(settings: AudioSettings) {
    this.settings = settings;
    if (!this.available) return;
    try {
      if (!this.context) {
        const AudioContextClass =
          window.AudioContext ??
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AudioContextClass) {
          this.available = false;
          return;
        }
        this.context = new AudioContextClass();
        this.master = this.context.createGain();
        this.waterBus = this.context.createGain();
        this.glassBus = this.context.createGain();
        this.ambientBus = this.context.createGain();
        this.waterBus.connect(this.master);
        this.glassBus.connect(this.master);
        this.ambientBus.connect(this.master);
        this.master.connect(this.context.destination);
        this.noiseBuffer = this.makeNoiseBuffer(2);
      }
      if (this.context.state === "suspended") void this.context.resume();
      this.sync(settings);
    } catch {
      this.available = false;
    }
  }

  sync(settings: AudioSettings) {
    this.settings = settings;
    if (!this.context || !this.master || !this.waterBus || !this.glassBus || !this.ambientBus) return;
    const now = this.context.currentTime;
    this.master.gain.setTargetAtTime(settings.sound ? settings.volume * 0.9 : 0, now, 0.025);
    this.waterBus.gain.setTargetAtTime(settings.water ? 0.9 : 0, now, 0.025);
    this.glassBus.gain.setTargetAtTime(settings.water ? 0.9 : 0, now, 0.025);
    this.ambientBus.gain.setTargetAtTime(settings.ambient ? 0.3 : 0, now, 0.08);
    if (settings.sound && settings.ambient) this.startAmbient();
    else this.stopAmbient();
  }

  private makeNoiseBuffer(seconds: number): AudioBuffer {
    const context = this.context!;
    const buffer = context.createBuffer(1, Math.floor(context.sampleRate * seconds), context.sampleRate);
    const data = buffer.getChannelData(0);
    // Pure white noise — filters shape it per-sound so one buffer serves all.
    for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  private canUseWater() {
    return Boolean(
      this.context &&
        this.master &&
        this.waterBus &&
        this.settings.sound &&
        this.settings.water &&
        this.context.state !== "closed",
    );
  }

  private canUseGlass() {
    return Boolean(
      this.context &&
        this.master &&
        this.glassBus &&
        this.settings.sound &&
        this.settings.water &&
        this.context.state !== "closed",
    );
  }

  // ---------------- POUR LOOP (frame-synced) ----------------

  /** Begin the continuous pour. Call updatePour() every frame, stopPour() at the end. */
  startPour(amount: number, initialFill = 0.25) {
    if (!this.canUseWater()) return;
    this.stopPour(true);
    const context = this.context!;
    const now = context.currentTime;
    this.pourActive = true;
    this.pourAmount = Math.max(1, Math.min(4, amount));
    this.lastDroplet = now;

    // Layer 1 — stream hiss: turbulent high-frequency noise, follows flow.
    const hissSource = context.createBufferSource();
    hissSource.buffer = this.noiseBuffer;
    hissSource.loop = true;
    hissSource.playbackRate.value = 0.9 + Math.random() * 0.2;
    const hissFilter = context.createBiquadFilter();
    hissFilter.type = "highpass";
    hissFilter.frequency.value = 2800 + this.pourAmount * 300;
    const hissGain = context.createGain();
    hissGain.gain.setValueAtTime(0.0001, now);
    hissSource.connect(hissFilter).connect(hissGain).connect(this.waterBus!);
    hissSource.start();

    // Layer 2 — pour body: resonant band that rises as the target fills.
    const bodySource = context.createBufferSource();
    bodySource.buffer = this.noiseBuffer;
    bodySource.loop = true;
    bodySource.playbackRate.value = 0.55 + Math.random() * 0.1;
    const bodyFilter = context.createBiquadFilter();
    bodyFilter.type = "bandpass";
    bodyFilter.Q.value = 1.1;
    bodyFilter.frequency.value = this.fillToFreq(initialFill);
    const bodyFilter2 = context.createBiquadFilter();
    bodyFilter2.type = "bandpass";
    bodyFilter2.Q.value = 2.2;
    bodyFilter2.frequency.value = this.fillToFreq(initialFill) * 2.02;
    const bodyGain = context.createGain();
    bodyGain.gain.setValueAtTime(0.0001, now);
    bodySource.connect(bodyFilter).connect(bodyGain);
    bodyFilter.connect(bodyFilter2);
    const harmonicGain = context.createGain();
    harmonicGain.gain.value = 0.35;
    bodyFilter2.connect(harmonicGain).connect(bodyGain);
    bodyGain.connect(this.waterBus!);
    bodySource.start();

    // Layer 3 — source glug: air gulping back into the tilted tube.
    const glugOsc = context.createOscillator();
    glugOsc.type = "sine";
    glugOsc.frequency.value = 110;
    const glugLfo = context.createOscillator();
    glugLfo.type = "sine";
    glugLfo.frequency.value = 5.5 + Math.random() * 2;
    const glugLfoDepth = context.createGain();
    glugLfoDepth.gain.value = 45;
    glugLfo.connect(glugLfoDepth).connect(glugOsc.frequency);
    const glugGain = context.createGain();
    glugGain.gain.setValueAtTime(0.0001, now);
    glugOsc.connect(glugGain).connect(this.waterBus!);
    glugOsc.start();
    glugLfo.start();

    this.pourNodes = [hissSource, bodySource, glugOsc, glugLfo];
    this.pourHissGain = hissGain;
    this.pourBodyGain = bodyGain;
    this.pourBodyFilter = bodyFilter;
    this.pourBodyFilter2 = bodyFilter2;
    this.pourGlugGain = glugGain;
    this.pourGlugOsc = glugOsc;

    // Attack transient: the first "chug" as water leaves the lip.
    this.attackChug();
  }

  /** Drive the loop from the animation frame. flow 0..1 = stream width, fill 0..1 = target level. */
  updatePour(flow: number, fill: number) {
    if (!this.pourActive || !this.context) return;
    if (!this.canUseWater()) return;
    const now = this.context.currentTime;
    const f = Math.max(0, Math.min(1, flow));
    const fillClamped = Math.max(0, Math.min(1, fill));
    const amountBoost = 0.75 + this.pourAmount * 0.14;

    // Hiss follows flow almost linearly — thin stream = quiet hiss.
    this.pourHissGain?.gain.setTargetAtTime(0.0001 + f * 0.075 * amountBoost, now, 0.03);
    // Body is louder and swells a touch slower for a wet feel.
    this.pourBodyGain?.gain.setTargetAtTime(0.0001 + Math.pow(f, 1.25) * 0.34 * amountBoost, now, 0.045);
    // Resonance rises as the glass fills — the classic "filling glass" cue.
    const freq = this.fillToFreq(fillClamped);
    this.pourBodyFilter?.frequency.setTargetAtTime(freq, now, 0.05);
    this.pourBodyFilter2?.frequency.setTargetAtTime(freq * 2.02, now, 0.05);
    // Glugging deepens and strengthens toward the end of the pour.
    const glugDepth = 0.2 + fillClamped * 0.8;
    this.pourGlugGain?.gain.setTargetAtTime(0.0001 + f * 0.05 * glugDepth * amountBoost, now, 0.06);
    this.pourGlugOsc?.frequency.setTargetAtTime(120 - fillClamped * 35, now, 0.1);

    // Droplet plinks synced to the visible splash — pitch tracks water level.
    if (f > 0.12 && now - this.lastDroplet > 0.09 + Math.random() * 0.13) {
      this.lastDroplet = now;
      this.plink(fillClamped, 0.35 + f * 0.65);
    }
  }

  stopPour(immediate = false) {
    if (!this.context) {
      this.pourActive = false;
      return;
    }
    const now = this.context.currentTime;
    const fade = immediate ? 0.02 : 0.12;
    this.pourActive = false;
    [this.pourHissGain, this.pourBodyGain, this.pourGlugGain].forEach((gain) => {
      if (!gain) return;
      gain.gain.cancelScheduledValues(now);
      gain.gain.setTargetAtTime(0.0001, now, fade / 3);
    });
    const sources = this.pourNodes;
    this.pourNodes = [];
    this.pourHissGain = null;
    this.pourBodyGain = null;
    this.pourBodyFilter = null;
    this.pourBodyFilter2 = null;
    this.pourGlugGain = null;
    this.pourGlugOsc = null;
    window.setTimeout(
      () =>
        sources.forEach((source) => {
          try {
            source.stop();
          } catch {
            /* already stopped */
          }
        }),
      fade * 1000 + 60,
    );
  }

  private fillToFreq(fill: number): number {
    // Empty glass resonates low (~420Hz), nearly-full rings near ~980Hz.
    return 420 + fill * 560;
  }

  private attackChug() {
    if (!this.canUseWater()) return;
    const context = this.context!;
    const now = context.currentTime;
    // Short low thump + noise burst = water breaking free of the lip.
    const osc = context.createOscillator();
    const oscGain = context.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(210, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.09);
    oscGain.gain.setValueAtTime(0.09, now);
    oscGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.1);
    osc.connect(oscGain).connect(this.waterBus!);
    osc.start(now);
    osc.stop(now + 0.12);

    const noise = context.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = context.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 900;
    const gain = context.createGain();
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
    noise.connect(filter).connect(gain).connect(this.waterBus!);
    noise.start(now, Math.random());
    noise.stop(now + 0.1);
  }

  /** A single water droplet hitting the surface. Pitch rises with fill level. */
  plink(fill = 0.5, intensity = 1) {
    if (!this.canUseWater()) return;
    const context = this.context!;
    const now = context.currentTime;
    const base = 640 + fill * 1050 + Math.random() * 160;
    // Fundamental with a fast downward chirp — the signature of a water drop.
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(base * 1.35, now);
    osc.frequency.exponentialRampToValueAtTime(base, now + 0.03);
    const peak = 0.028 * intensity;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(peak, now + 0.006);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11);
    osc.connect(gain).connect(this.waterBus!);
    osc.start(now);
    osc.stop(now + 0.13);
    // Faint harmonic shimmer an octave-ish up.
    const osc2 = context.createOscillator();
    const gain2 = context.createGain();
    osc2.type = "sine";
    osc2.frequency.setValueAtTime(base * 2.4, now);
    gain2.gain.setValueAtTime(0.0001, now);
    gain2.gain.exponentialRampToValueAtTime(peak * 0.3, now + 0.008);
    gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);
    osc2.connect(gain2).connect(this.waterBus!);
    osc2.start(now);
    osc2.stop(now + 0.09);
  }

  splash(intensity = 1, fill = 0.5) {
    if (!this.canUseWater()) return;
    const context = this.context!;
    const now = context.currentTime;
    const source = context.createBufferSource();
    source.buffer = this.noiseBuffer;
    const filter = context.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 750 + fill * 700 + Math.random() * 250;
    filter.Q.value = 0.8;
    const gain = context.createGain();
    const duration = 0.14 + Math.random() * 0.08;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.085 * intensity, now + 0.014);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    source.connect(filter).connect(gain).connect(this.waterBus!);
    source.start(now, Math.random());
    source.stop(now + duration + 0.02);
    // Two staggered droplets sell the splash tail.
    window.setTimeout(() => this.plink(fill, intensity * 0.8), 35 + Math.random() * 30);
    window.setTimeout(() => this.plink(Math.min(1, fill + 0.08), intensity * 0.55), 90 + Math.random() * 40);
  }

  // ---------------- GLASS ----------------

  /** Real-ish glass tap: inharmonic partials + a tiny contact click. */
  tap(strength = 1) {
    if (!this.canUseGlass()) return;
    const context = this.context!;
    const now = context.currentTime;
    const base = 2050 + Math.random() * 320;
    const partials = [1, 2.76, 5.4];
    const decays = [0.22, 0.14, 0.08];
    partials.forEach((ratio, index) => {
      const osc = context.createOscillator();
      const gain = context.createGain();
      osc.type = "sine";
      osc.frequency.value = base * ratio;
      const peak = (index === 0 ? 0.05 : index === 1 ? 0.022 : 0.01) * strength;
      gain.gain.setValueAtTime(peak, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + decays[index]);
      osc.connect(gain).connect(this.glassBus!);
      osc.start(now);
      osc.stop(now + decays[index] + 0.02);
    });
    // Contact click.
    const click = context.createBufferSource();
    click.buffer = this.noiseBuffer;
    const clickFilter = context.createBiquadFilter();
    clickFilter.type = "highpass";
    clickFilter.frequency.value = 4500;
    const clickGain = context.createGain();
    clickGain.gain.setValueAtTime(0.05 * strength, now);
    clickGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);
    click.connect(clickFilter).connect(clickGain).connect(this.glassBus!);
    click.start(now, Math.random());
    click.stop(now + 0.04);
  }

  /** Soft lift: tube leaving the surface. */
  lift() {
    if (!this.canUseGlass()) return;
    const context = this.context!;
    const now = context.currentTime;
    const noise = context.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = context.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 1400;
    filter.Q.value = 1.4;
    const gain = context.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.035, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11);
    noise.connect(filter).connect(gain).connect(this.glassBus!);
    noise.start(now, Math.random());
    noise.stop(now + 0.13);
  }

  /** Soft landing: tube set back down. */
  land() {
    if (!this.canUseGlass()) return;
    const context = this.context!;
    const now = context.currentTime;
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(190, now + 0.07);
    gain.gain.setValueAtTime(0.05, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
    osc.connect(gain).connect(this.glassBus!);
    osc.start(now);
    osc.stop(now + 0.1);
    this.tap(0.45);
  }

  /** Lid snapping onto a finished glass: soft thock + bright seal tick. */
  cap() {
    if (!this.canUseGlass()) return;
    const context = this.context!;
    const now = context.currentTime;
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(240, now + 0.06);
    gain.gain.setValueAtTime(0.09, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
    osc.connect(gain).connect(this.glassBus!);
    osc.start(now);
    osc.stop(now + 0.1);
    window.setTimeout(() => this.tap(0.55), 70);
  }

  clink() {
    this.tap(0.9);
  }

  /** Dull muted knock for illegal moves. */
  thunk() {
    if (!this.canUseGlass()) return;
    const context = this.context!;
    const now = context.currentTime;
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(185, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.1);
    gain.gain.setValueAtTime(0.07, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
    osc.connect(gain).connect(this.glassBus!);
    osc.start(now);
    osc.stop(now + 0.14);
    const noise = context.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const filter = context.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 500;
    const noiseGain = context.createGain();
    noiseGain.gain.setValueAtTime(0.05, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);
    noise.connect(filter).connect(noiseGain).connect(this.glassBus!);
    noise.start(now, Math.random());
    noise.stop(now + 0.08);
  }

  invalid() {
    this.thunk();
  }

  bubble(ambient = false, intensity = 1) {
    if (!this.context || !this.settings.sound) return;
    if (ambient && !this.settings.ambient) return;
    if (!ambient && !this.settings.water) return;
    const context = this.context;
    const now = context.currentTime;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const startFrequency = (ambient ? 180 : 320) + Math.random() * 380;
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(startFrequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(startFrequency * (1.5 + Math.random() * 0.5), now + 0.07);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime((ambient ? 0.012 : 0.022) * intensity, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.085);
    oscillator.connect(gain).connect(ambient ? this.ambientBus! : this.waterBus!);
    oscillator.start(now);
    oscillator.stop(now + 0.1);
  }

  victory() {
    if (!this.canUseWater()) return;
    this.splash(1.2, 0.8);
    const context = this.context!;
    const now = context.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((frequency, index) => {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const start = now + 0.08 + index * 0.105;
      oscillator.type = index === 3 ? "sine" : "triangle";
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.04, start + 0.018);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.42);
      oscillator.connect(gain).connect(this.waterBus!);
      oscillator.start(start);
      oscillator.stop(start + 0.45);
    });
  }

  private startAmbient() {
    if (!this.context || this.ambientSource || !this.noiseBuffer) return;
    const context = this.context;
    const source = context.createBufferSource();
    source.buffer = this.noiseBuffer;
    source.loop = true;
    source.playbackRate.value = 0.4;
    const filter = context.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 240;
    const gain = context.createGain();
    gain.gain.value = 0.06;
    source.connect(filter).connect(gain).connect(this.ambientBus!);
    source.start();

    const oscillator = context.createOscillator();
    const oscillatorGain = context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.value = 48;
    oscillatorGain.gain.value = 0.016;
    oscillator.connect(oscillatorGain).connect(this.ambientBus!);
    oscillator.start();
    this.ambientSource = source;
    this.ambientOscillator = oscillator;
    this.ambientTimer = window.setInterval(() => {
      if (Math.random() > 0.35) this.bubble(true, 0.6 + Math.random() * 0.6);
    }, 1700);
  }

  private stopAmbient() {
    if (this.ambientTimer !== null) window.clearInterval(this.ambientTimer);
    this.ambientTimer = null;
    try {
      this.ambientSource?.stop();
    } catch {
      /* already stopped */
    }
    try {
      this.ambientOscillator?.stop();
    } catch {
      /* already stopped */
    }
    this.ambientSource = null;
    this.ambientOscillator = null;
  }
}

export const audio = new AquaAudio();
