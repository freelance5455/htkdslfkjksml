import { LanguageOption } from '../types/recorder';

export const AUTO_DETECT_LANGUAGE: LanguageOption = {
  code: 'auto',
  englishName: 'Auto-Detect',
  nativeName: 'Auto',
  isRtl: false,
  scriptFamily: 'other',
};

export const SAME_AS_SPEAKING_CODE = 'same';

export const LANGUAGES_CATALOG: LanguageOption[] = [
  // Featured priority languages
  { code: 'ur-PK', englishName: 'Urdu', nativeName: 'اردو', isRtl: true, scriptFamily: 'nastaliq' },
  { code: 'en-US', englishName: 'English', nativeName: 'English', isRtl: false, scriptFamily: 'latin' },
  { code: 'ar-SA', englishName: 'Arabic', nativeName: 'العربية', isRtl: true, scriptFamily: 'arabic' },
  { code: 'hi-IN', englishName: 'Hindi', nativeName: 'हिन्दी', isRtl: false, scriptFamily: 'devanagari' },
  { code: 'pa-PK', englishName: 'Punjabi (Shahmukhi)', nativeName: 'پنجابی', isRtl: true, scriptFamily: 'nastaliq' },
  { code: 'fa-IR', englishName: 'Persian', nativeName: 'فارسی', isRtl: true, scriptFamily: 'arabic' },
  { code: 'ps-AF', englishName: 'Pashto', nativeName: 'پښتو', isRtl: true, scriptFamily: 'arabic' },
  { code: 'sd-PK', englishName: 'Sindhi', nativeName: 'سنڌي', isRtl: true, scriptFamily: 'arabic' },
  // Global languages (alphabetical)
  { code: 'af-ZA', englishName: 'Afrikaans', nativeName: 'Afrikaans', isRtl: false, scriptFamily: 'latin' },
  { code: 'sq-AL', englishName: 'Albanian', nativeName: 'Shqip', isRtl: false, scriptFamily: 'latin' },
  { code: 'am-ET', englishName: 'Amharic', nativeName: 'አማርኛ', isRtl: false, scriptFamily: 'other' },
  { code: 'hy-AM', englishName: 'Armenian', nativeName: 'Հայերեն', isRtl: false, scriptFamily: 'other' },
  { code: 'az-AZ', englishName: 'Azerbaijani', nativeName: 'Azərbaycan', isRtl: false, scriptFamily: 'latin' },
  { code: 'bn-BD', englishName: 'Bengali', nativeName: 'বাংলা', isRtl: false, scriptFamily: 'other' },
  { code: 'bs-BA', englishName: 'Bosnian', nativeName: 'Bosanski', isRtl: false, scriptFamily: 'latin' },
  { code: 'bg-BG', englishName: 'Bulgarian', nativeName: 'Български', isRtl: false, scriptFamily: 'other' },
  { code: 'my-MM', englishName: 'Burmese', nativeName: 'မြန်မာ', isRtl: false, scriptFamily: 'other' },
  { code: 'zh-CN', englishName: 'Chinese (Mandarin)', nativeName: '中文', isRtl: false, scriptFamily: 'cjk' },
  { code: 'hr-HR', englishName: 'Croatian', nativeName: 'Hrvatski', isRtl: false, scriptFamily: 'latin' },
  { code: 'cs-CZ', englishName: 'Czech', nativeName: 'Čeština', isRtl: false, scriptFamily: 'latin' },
  { code: 'da-DK', englishName: 'Danish', nativeName: 'Dansk', isRtl: false, scriptFamily: 'latin' },
  { code: 'nl-NL', englishName: 'Dutch', nativeName: 'Nederlands', isRtl: false, scriptFamily: 'latin' },
  { code: 'fil-PH', englishName: 'Filipino', nativeName: 'Filipino', isRtl: false, scriptFamily: 'latin' },
  { code: 'fi-FI', englishName: 'Finnish', nativeName: 'Suomi', isRtl: false, scriptFamily: 'latin' },
  { code: 'fr-FR', englishName: 'French', nativeName: 'Français', isRtl: false, scriptFamily: 'latin' },
  { code: 'de-DE', englishName: 'German', nativeName: 'Deutsch', isRtl: false, scriptFamily: 'latin' },
  { code: 'el-GR', englishName: 'Greek', nativeName: 'Ελληνικά', isRtl: false, scriptFamily: 'other' },
  { code: 'gu-IN', englishName: 'Gujarati', nativeName: 'ગુજરાતી', isRtl: false, scriptFamily: 'other' },
  { code: 'he-IL', englishName: 'Hebrew', nativeName: 'עברית', isRtl: true, scriptFamily: 'arabic' },
  { code: 'hu-HU', englishName: 'Hungarian', nativeName: 'Magyar', isRtl: false, scriptFamily: 'latin' },
  { code: 'id-ID', englishName: 'Indonesian', nativeName: 'Bahasa Indonesia', isRtl: false, scriptFamily: 'latin' },
  { code: 'it-IT', englishName: 'Italian', nativeName: 'Italiano', isRtl: false, scriptFamily: 'latin' },
  { code: 'ja-JP', englishName: 'Japanese', nativeName: '日本語', isRtl: false, scriptFamily: 'cjk' },
  { code: 'kn-IN', englishName: 'Kannada', nativeName: 'ಕನ್ನಡ', isRtl: false, scriptFamily: 'other' },
  { code: 'kk-KZ', englishName: 'Kazakh', nativeName: 'Қазақ', isRtl: false, scriptFamily: 'other' },
  { code: 'ko-KR', englishName: 'Korean', nativeName: '한국어', isRtl: false, scriptFamily: 'cjk' },
  { code: 'ku-IQ', englishName: 'Kurdish (Sorani)', nativeName: 'کوردی', isRtl: true, scriptFamily: 'arabic' },
  { code: 'ms-MY', englishName: 'Malay', nativeName: 'Bahasa Melayu', isRtl: false, scriptFamily: 'latin' },
  { code: 'ml-IN', englishName: 'Malayalam', nativeName: 'മലയാളം', isRtl: false, scriptFamily: 'other' },
  { code: 'mr-IN', englishName: 'Marathi', nativeName: 'मराठी', isRtl: false, scriptFamily: 'devanagari' },
  { code: 'ne-NP', englishName: 'Nepali', nativeName: 'नेपाली', isRtl: false, scriptFamily: 'devanagari' },
  { code: 'nb-NO', englishName: 'Norwegian', nativeName: 'Norsk', isRtl: false, scriptFamily: 'latin' },
  { code: 'pl-PL', englishName: 'Polish', nativeName: 'Polski', isRtl: false, scriptFamily: 'latin' },
  { code: 'pt-BR', englishName: 'Portuguese', nativeName: 'Português', isRtl: false, scriptFamily: 'latin' },
  { code: 'ro-RO', englishName: 'Romanian', nativeName: 'Română', isRtl: false, scriptFamily: 'latin' },
  { code: 'ru-RU', englishName: 'Russian', nativeName: 'Русский', isRtl: false, scriptFamily: 'other' },
  { code: 'es-ES', englishName: 'Spanish', nativeName: 'Español', isRtl: false, scriptFamily: 'latin' },
  { code: 'sw-KE', englishName: 'Swahili', nativeName: 'Kiswahili', isRtl: false, scriptFamily: 'latin' },
  { code: 'sv-SE', englishName: 'Swedish', nativeName: 'Svenska', isRtl: false, scriptFamily: 'latin' },
  { code: 'ta-IN', englishName: 'Tamil', nativeName: 'தமிழ்', isRtl: false, scriptFamily: 'other' },
  { code: 'te-IN', englishName: 'Telugu', nativeName: 'తెలుగు', isRtl: false, scriptFamily: 'other' },
  { code: 'th-TH', englishName: 'Thai', nativeName: 'ไทย', isRtl: false, scriptFamily: 'other' },
  { code: 'tr-TR', englishName: 'Turkish', nativeName: 'Türkçe', isRtl: false, scriptFamily: 'latin' },
  { code: 'uk-UA', englishName: 'Ukrainian', nativeName: 'Українська', isRtl: false, scriptFamily: 'other' },
  { code: 'uz-UZ', englishName: 'Uzbek', nativeName: "O'zbek", isRtl: false, scriptFamily: 'latin' },
  { code: 'vi-VN', englishName: 'Vietnamese', nativeName: 'Tiếng Việt', isRtl: false, scriptFamily: 'latin' },
];

export const SPEAKING_LANGUAGE_OPTIONS: LanguageOption[] = [
  AUTO_DETECT_LANGUAGE,
  ...LANGUAGES_CATALOG,
];

export const OUTPUT_LANGUAGE_OPTIONS: LanguageOption[] = [
  {
    code: SAME_AS_SPEAKING_CODE,
    englishName: 'Same as Speaking',
    nativeName: 'Original',
    isRtl: false,
    scriptFamily: 'other',
  },
  ...LANGUAGES_CATALOG,
];

export function findLanguageByCode(code: string): LanguageOption {
  if (code === AUTO_DETECT_LANGUAGE.code) {
    return AUTO_DETECT_LANGUAGE;
  }
  if (code === SAME_AS_SPEAKING_CODE) {
    return OUTPUT_LANGUAGE_OPTIONS[0];
  }
  return (
    LANGUAGES_CATALOG.find((lang) => lang.code === code) ?? {
      code,
      englishName: code,
      nativeName: code,
      isRtl: false,
      scriptFamily: 'other',
    }
  );
}

export function resolveEffectiveOutputLanguage(
  speakingCode: string,
  outputCode: string
): LanguageOption {
  if (outputCode === SAME_AS_SPEAKING_CODE) {
    if (speakingCode === AUTO_DETECT_LANGUAGE.code) {
      return findLanguageByCode('ur-PK');
    }
    return findLanguageByCode(speakingCode);
  }
  return findLanguageByCode(outputCode);
}
