import { Language } from '../types/tts';

export const SUPPORTED_LANGUAGES: Language[] = [
  // Indic Languages
  {
    code: 'ta-IN',
    name: 'Tamil',
    nativeName: 'தமிழ்',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: '🥤 சோடா துள்ளல் (Soda Pop)',
        text: 'சோடா போல புத்துணர்ச்சியூட்டும் சுவை! எங்களின் புதிய சோடா குரல் வடிவமைப்புடன் உங்கள் உரையை உற்சாகமாக உருவாக்குங்கள்!',
      },
      {
        title: 'வணக்கம் (Greeting)',
        text: 'வணக்கம்! SK உரை முதல் பேச்சு தொழில்நுட்பத்திற்கு வரவேற்கிறோம். தெளிவான குரலில் வாசிக்கப்படும்.',
      },
      {
        title: 'திருக்குறள் (Thirukkural)',
        text: 'கற்க கசடறக் கற்பவை கற்றபின் நிற்க அதற்குத் தக.',
      },
      {
        title: 'பாரதியார் கவிதை (Bharathiyar)',
        text: 'சென்றிடுவீர் எட்டுத் திக்கும், கலைச் செல்வங்கள் யாவும் கொணர்ந்திங்கு சேர்ப்பீர்!',
      },
      {
        title: 'தொழில்நுட்பம் (Tech Quote)',
        text: 'செயற்கை நுண்ணறிவு மற்றும் குரல் தொழில்நுட்பம் எதிர்கால மனித தகவல் தொடர்பை மாற்றியமைக்கிறது.',
      },
    ],
  },
  {
    code: 'te-IN',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: '🥤 సోడా పాప్ (Soda Pop)',
        text: 'సోడా లాంటి రిఫ్రెషింగ్ ఉత్సాహం! కొత్త సోడా వాయిస్ మోడల్‌తో మీ మాటలను అద్భుతమైన శక్తితో మార్చండి!',
      },
      {
        title: 'నమస్కారం (Greeting)',
        text: 'నమస్కారం! SK టెక్స్ట్ టు స్పీచ్‌కు స్వాగతం. మీ మాటలను అద్భుతమైన స్వరంగా మారుస్తుంది.',
      },
      {
        title: 'సూక్తి (Proverb)',
        text: 'విద్య లేని వాడు వింత పశువు. జ్ఞానమే నిజమైన సంపద.',
      },
      {
        title: 'ప్రేరణ (Inspiration)',
        text: 'ప్రయత్నిస్తే సాధించలేనిది ఏదీ లేదు. మీ లక్ష్యం వైపు అడుగులు వేయండి.',
      },
    ],
  },
  {
    code: 'ml-IN',
    name: 'Malayalam',
    nativeName: 'മലയാളം',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: '🥤 സോഡ പോപ്പ് (Soda Pop)',
        text: 'സോഡ പോലെ ഉന്മേഷദായകമായ പുതിയ ശബ്ദം! നിങ്ങളുടെ വാചകങ്ങൾ ഇപ്പോൾ ഊർജ്ജസ്വലമായി തത്സമയം കേൾക്കൂ!',
      },
      {
        title: 'നമസ്കാരം (Greeting)',
        text: 'നമസ്കാരം! SK ടെക്സ്റ്റ് ടു സ്പീച്ച് സിസ്റ്റത്തിലേക്ക് സ്വാഗതം. നിങ്ങളുടെ വാക്കുകൾ ജീവസുറ്റതാക്കൂ.',
      },
      {
        title: 'കവിത (Poetry)',
        text: 'മാതൃഭൂമിയെ സ്നേഹിക്കുക, ഭാഷയെ പ്രണയിക്കുക. കേരളം സുന്ദരമായ നാടാണ്.',
      },
      {
        title: 'പ്രചോദനം (Inspiration)',
        text: 'സ്വപ്നങ്ങൾ കാണുക മാത്രമല്ല, അവ യാഥാർത്ഥ്യമാക്കാൻ കഠിനാധ്വാനം ചെയ്യുക.',
      },
    ],
  },
  {
    code: 'kn-IN',
    name: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: '🥤 ಸೋಡಾ ಪಾಪ್ (Soda Pop)',
        text: 'ಸೋಡಾದಂತೆ ಉಲ್ಲಾಸಕರ ಮತ್ತು ಶಕ್ತಿಯುತ ಧ್ವನಿ! ಹೊಸ ಸೋಡಾ ವಾಯ್ಸ್ ಮಾದರಿಯೊಂದಿಗೆ ತಕ್ಷಣ ಆಲಿಸಿ!',
      },
      {
        title: 'ನಮಸ್ಕಾರ (Greeting)',
        text: 'ನಮಸ್ಕಾರ! SK ಪಠ್ಯದಿಂದ ಧ್ವನಿ ಪರಿವರ್ತಕಕ್ಕೆ ಸುಸ್ವಾಗತ. ನೈಜ ಮಾನವ ಧ್ವನಿಯಲ್ಲಿ ಆಲಿಸಿ.',
      },
      {
        title: 'ಬಸವಣ್ಣ ವಚನ (Vachana)',
        text: 'ಕಾಯಕವೇ ಕೈಲಾಸ ಎಂಬುದು ವಿಶ್ವಗುರು ಬಸವಣ್ಣನವರ ಅಮೃತ ಸಂದೇಶ.',
      },
      {
        title: 'ಕುವೆಂಪು ನುಡಿ (Kuvempu)',
        text: 'ಎಲ್ಲಾದರೂ ಇರು, ಎಂತಾದರೂ ಇರು, ಎಂದೆಂದಿಗೂ ನೀ ಕನ್ನಡವಾಗಿರು.',
      },
    ],
  },
  {
    code: 'hi-IN',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: '🥤 सोडा पॉप (Soda Pop)',
        text: 'सोडा जैसा ताजगी भरा और जोशीला अंदाज़! नए सोडा वॉइस मॉडल से अपनी आवाज़ को बनाएं और भी ख़ास!',
      },
      {
        title: 'नमस्ते (Greeting)',
        text: 'नमस्ते! SK टेक्स्ट टू स्पीच में आपका स्वागत है। उच्च गुणवत्ता वाली स्वाभाविक आवाज का अनुभव करें।',
      },
      {
        title: 'कबीर दोहा (Kabir)',
        text: 'काल करे सो आज कर, आज करे सो अब। पल में प्रलय होएगी, बहुरि करेगा कब।',
      },
      {
        title: 'प्रेरणा (Inspiration)',
        text: 'लहरों से डर कर नौका पार नहीं होती, कोशिश करने वालों की कभी हार नहीं होती।',
      },
    ],
  },
  {
    code: 'bn-IN',
    name: 'Bengali',
    nativeName: 'বাংলা',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: 'নমস্কার (Greeting)',
        text: 'নমস্কার! SK টেক্সট টু স্পিচ প্ল্যাটফর্মে আপনাকে স্বাগতম।',
      },
      {
        title: 'রবীন্দ্রনাথ (Tagore)',
        text: 'চিত্ত যেথা ভয়শূন্য, উচ্চ যেথা শির, জ্ঞান যেথা মুক্ত, যেথা গৃহের প্রাচীর।',
      },
    ],
  },
  {
    code: 'mr-IN',
    name: 'Marathi',
    nativeName: 'मराठी',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: 'नमस्कार (Greeting)',
        text: 'नमस्कार! SK टेक्स्ट टू स्पीच मध्ये आपले स्वागत आहे. नैसर्गिक आवाज ऐका.',
      },
      {
        title: 'सुविचार (Quote)',
        text: 'प्रयत्नांती परमेश्वर. कष्ट आणि सातत्य यातूनच यश साध्य होते.',
      },
    ],
  },
  {
    code: 'gu-IN',
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    flag: '🇮🇳',
    category: 'indic',
    sampleTexts: [
      {
        title: 'નમસ્તે (Greeting)',
        text: 'નમસ્તે! SK ટેક્સ્ટ ટુ સ્પીચમાં આપનું સ્વાગત છે. સ્પષ્ટ અને મધુર અવાજ.',
      },
      {
        title: 'સુવિચાર (Quote)',
        text: 'જ્યાં પરિશ્રમ છે ત્યાં જ સફળતાની સુગંધ પ્રસરે છે.',
      },
    ],
  },

  // International Languages
  {
    code: 'en-US',
    name: 'English (US)',
    nativeName: 'English (US)',
    flag: '🇺🇸',
    category: 'international',
    sampleTexts: [
      {
        title: '🥤 Fizzy Soda Pop',
        text: 'Pop open the energy! Like a sparkling cold soda bursting with fizz, this energetic voice brings unbeatable excitement and punch to your speech!',
      },
      {
        title: 'Studio Welcome',
        text: 'Welcome to SK text to speech. Experience lifelike neural voice synthesis with studio-grade clarity and real-time offline export.',
      },
      {
        title: 'ElevenLabs Style Dialogue',
        text: 'The horizon stretched into infinity, bathed in the amber glow of the setting sun. Every sound told a story of timeless mystery.',
      },
      {
        title: 'Tech & AI Podcast',
        text: 'In the digital era, speech synthesis isn’t just about converting text—it gives character, emotion, and presence to synthetic audio.',
      },
    ],
  },
  {
    code: 'en-IN',
    name: 'English (India)',
    nativeName: 'English (India)',
    flag: '🇮🇳',
    category: 'international',
    sampleTexts: [
      {
        title: 'Welcome India',
        text: 'Hello and welcome! SK text to speech brings seamless multilingual voice synthesis to creators across the subcontinent.',
      },
      {
        title: 'Innovation Quote',
        text: 'India’s rich linguistic diversity meets cutting-edge neural audio engineering.',
      },
    ],
  },
  {
    code: 'en-GB',
    name: 'English (UK)',
    nativeName: 'English (UK)',
    flag: '🇬🇧',
    category: 'international',
    sampleTexts: [
      {
        title: 'British Narration',
        text: 'Good day. Welcome to the SK speech studio. May your audio projects flourish with distinction and eloquence.',
      },
      {
        title: 'Classic Literature',
        text: 'It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife.',
      },
    ],
  },
  {
    code: 'es-ES',
    name: 'Spanish',
    nativeName: 'Español',
    flag: '🇪🇸',
    category: 'international',
    sampleTexts: [
      {
        title: 'Bienvenida',
        text: '¡Hola! Bienvenido a SK text to speech. Convierte cualquier texto en audio con máxima calidad y emoción.',
      },
      {
        title: 'Cervantes',
        text: 'En un lugar de la Mancha, de cuyo nombre no quiero acordarme, no ha mucho tiempo que vivía un hidalgo.',
      },
    ],
  },
  {
    code: 'fr-FR',
    name: 'French',
    nativeName: 'Français',
    flag: '🇫🇷',
    category: 'international',
    sampleTexts: [
      {
        title: 'Bienvenue',
        text: 'Bienvenue sur SK text to speech. Donnez une voix chaleureuse et captivante à toutes vos créations.',
      },
      {
        title: 'Saint-Exupéry',
        text: 'On ne voit bien qu’avec le cœur. L’essentiel est invisible pour les yeux.',
      },
    ],
  },
  {
    code: 'de-DE',
    name: 'German',
    nativeName: 'Deutsch',
    flag: '🇩🇪',
    category: 'international',
    sampleTexts: [
      {
        title: 'Willkommen',
        text: 'Willkommen bei SK text to speech. Erleben Sie fortschrittliche Sprachsynthese mit höchster Präzision.',
      },
      {
        title: 'Goethe Zitat',
        text: 'Es ist nicht genug zu wissen, man muss auch anwenden; es ist nicht genug zu wollen, man muss auch tun.',
      },
    ],
  },
  {
    code: 'ja-JP',
    name: 'Japanese',
    nativeName: '日本語',
    flag: '🇯🇵',
    category: 'international',
    sampleTexts: [
      {
        title: '挨拶 (Greeting)',
        text: 'こんにちは！SK text to speech へようこそ。自然で美しい音声をお届けします。',
      },
      {
        title: '名言 (Quote)',
        text: '一期一会。今この瞬間を大切に、心に響く言葉を紡ぎ出しましょう。',
      },
    ],
  },
  {
    code: 'ko-KR',
    name: 'Korean',
    nativeName: '한국어',
    flag: '🇰🇷',
    category: 'international',
    sampleTexts: [
      {
        title: '환영합니다 (Welcome)',
        text: '안녕하세요! SK 텍스트 투 스피치에 오신 것을 환영합니다. 생생하고 자연스러운 음성을 경험하세요.',
      },
    ],
  },
  {
    code: 'ar-SA',
    name: 'Arabic',
    nativeName: 'العربية',
    flag: '🇸🇦',
    category: 'international',
    sampleTexts: [
      {
        title: 'ترحيب (Welcome)',
        text: 'مرحباً بكم في SK text to speech. استمع إلى نصوصك بصوت نقي وعالي الجودة.',
      },
    ],
  },
  {
    code: 'pt-BR',
    name: 'Portuguese',
    nativeName: 'Português',
    flag: '🇧🇷',
    category: 'international',
    sampleTexts: [
      {
        title: 'Boas-vindas',
        text: 'Olá e bem-vindo ao SK text to speech. Transforme palavras em fala de alta fidelidade.',
      },
    ],
  },
  {
    code: 'it-IT',
    name: 'Italian',
    nativeName: 'Italiano',
    flag: '🇮🇹',
    category: 'international',
    sampleTexts: [
      {
        title: 'Benvenuto',
        text: 'Benvenuto su SK text to speech. La voce del futuro per i tuoi progetti sonori.',
      },
    ],
  },
  {
    code: 'ru-RU',
    name: 'Russian',
    nativeName: 'Русский',
    flag: '🇷🇺',
    category: 'international',
    sampleTexts: [
      {
        title: 'Добро пожаловать',
        text: 'Здравствуйте! Добро пожаловать в SK text to speech. Живой и выразительный синтез речи.',
      },
    ],
  },
];
