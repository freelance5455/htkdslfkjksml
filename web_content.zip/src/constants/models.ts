import type { ModelOption, ProviderId } from '../types/mycode';

export const PROVIDER_META: Record<
  ProviderId,
  { name: string; keyLabel: string; placeholder: string; docsHint: string }
> = {
  google: {
    name: 'Google AI Studio',
    keyLabel: 'Google AI Studio API Key',
    placeholder: 'AIzaSy...',
    docsHint: 'Optional if server GEMINI_API_KEY is active',
  },
  groq: {
    name: 'Groq',
    keyLabel: 'Groq API Key',
    placeholder: 'gsk_...',
    docsHint: 'OpenAI-compatible fast inference endpoint',
  },
  openrouter: {
    name: 'OpenRouter',
    keyLabel: 'OpenRouter API Key',
    placeholder: 'sk-or-v1-...',
    docsHint: 'Access DeepSeek R1/V3, GLM 4.5 Air, Qwen3 Coder, and free models',
  },
  zhipu: {
    name: 'Zhipu / Z.ai (GLM)',
    keyLabel: 'Zhipu Z.ai API Key',
    placeholder: 'your-zhipu-api-key',
    docsHint: 'GLM-4.5-Flash & GLM-4-Flash free models',
  },
  openai: {
    name: 'OpenAI',
    keyLabel: 'OpenAI API Key',
    placeholder: 'sk-...',
    docsHint: 'GPT-4o, GPT-4.1, and o3-mini models',
  },
  anthropic: {
    name: 'Anthropic',
    keyLabel: 'Anthropic API Key',
    placeholder: 'sk-ant-...',
    docsHint: 'Claude 3.7 Sonnet and Claude 3.5 Haiku',
  },
};

export const BUILT_IN_MODELS: ModelOption[] = [
  // Free Models
  {
    id: 'gemini-4-hydrogen',
    label: 'Gemini 4 Hydrogen (Free)',
    provider: 'google',
    tier: 'Free',
  },
  {
    id: 'gemini-3.1-flash-lite',
    label: 'Gemini 3.1 Flash Lite (Free)',
    provider: 'google',
    tier: 'Free',
  },
  {
    id: 'glm-4.5-flash',
    label: 'GLM 4.5 Flash - Z.ai (Free)',
    provider: 'zhipu',
    tier: 'Free',
  },
  {
    id: 'glm-4-flash',
    label: 'GLM 4 Flash - Z.ai (Free)',
    provider: 'zhipu',
    tier: 'Free',
  },
  {
    id: 'z-ai/glm-4.5-air:free',
    label: 'GLM 4.5 Air - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },
  {
    id: 'deepseek/deepseek-r1:free',
    label: 'DeepSeek R1 - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },
  {
    id: 'deepseek/deepseek-chat-v3-0324:free',
    label: 'DeepSeek V3 - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },
  {
    id: 'deepseek-r1-distill-llama-70b',
    label: 'DeepSeek R1 Distill 70B - Groq (Free)',
    provider: 'groq',
    tier: 'Free',
  },
  {
    id: 'llama-3.3-70b-versatile',
    label: 'Llama 3.3 70B - Groq (Free)',
    provider: 'groq',
    tier: 'Free',
  },
  {
    id: 'qwen/qwen3-coder:free',
    label: 'Qwen3 Coder - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },
  {
    id: 'meta-llama/llama-3.3-70b-instruct:free',
    label: 'Llama 3.3 70B - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },
  {
    id: 'google/gemma-3-27b-it:free',
    label: 'Gemma 3 27B - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },
  {
    id: 'mistralai/mistral-small-3.1-24b-instruct:free',
    label: 'Mistral Small 3.1 - OpenRouter (Free)',
    provider: 'openrouter',
    tier: 'Free',
  },

  // Paid Models
  {
    id: 'gemini-4-argon',
    label: 'Gemini 4 Argon (Paid)',
    provider: 'google',
    tier: 'Paid',
  },
  {
    id: 'gemini-4-carbon',
    label: 'Gemini 4 Carbon (Paid)',
    provider: 'google',
    tier: 'Paid',
  },
  {
    id: 'claude-3-7-sonnet-latest',
    label: 'Claude 3.7 Sonnet (Paid)',
    provider: 'anthropic',
    tier: 'Paid',
  },
  {
    id: 'claude-3-5-haiku-latest',
    label: 'Claude 3.5 Haiku (Paid)',
    provider: 'anthropic',
    tier: 'Paid',
  },
  {
    id: 'gpt-4o',
    label: 'GPT-4o (Paid)',
    provider: 'openai',
    tier: 'Paid',
  },
  {
    id: 'gpt-4.1',
    label: 'GPT-4.1 (Paid)',
    provider: 'openai',
    tier: 'Paid',
  },
  {
    id: 'o3-mini',
    label: 'o3-mini (Paid)',
    provider: 'openai',
    tier: 'Paid',
  },
  {
    id: 'deepseek/deepseek-r1',
    label: 'DeepSeek R1 - OpenRouter (Paid)',
    provider: 'openrouter',
    tier: 'Paid',
  },
  {
    id: 'glm-4-plus',
    label: 'GLM 4 Plus - Z.ai (Paid)',
    provider: 'zhipu',
    tier: 'Paid',
  },
];

export const QUICK_ACTIONS: Array<{ label: string; prompt: string }> = [
  {
    label: 'Build a Web App',
    prompt:
      'Build a clean, responsive interactive Pomodoro & Task Timer web app with index.html, styles.css, and app.js. Keep the UI minimalist white with crisp dark typography.',
  },
  {
    label: 'Write Python Script',
    prompt:
      'Write a complete, production-ready Python CLI script (app.py) with tests (test_app.py) that organizes files in a directory by extension and logs a clean summary report.',
  },
  {
    label: 'Fix Bug',
    prompt:
      'Inspect the current workspace files and help me diagnose and fix any bugs, edge cases, or layout issues.',
  },
  {
    label: 'REST API Server',
    prompt:
      'Create a clean Node.js + Express TypeScript REST API starter (server.ts, routes/items.ts, package.json) with input validation and structured error handling.',
  },
];

export function buildSystemPrompt(workspaceSummary: string): string {
  return [
    'You are MyCode, a senior principal software engineer and personal coding agent.',
    'Write complete, production-ready, bug-free, multi-file code without placeholders, "// ... rest of code", or truncation.',
    '',
    'CRITICAL FORMATTING RULES FOR FILES:',
    '1. Whenever you create or modify a file, put the relative file path immediately in the fenced code block info string using a colon, like:',
    '   ```html:index.html',
    '   ```python:app.py',
    '   ```tsx:src/App.tsx',
    '2. Output the FULL contents of each created or edited file so the built-in workspace manager can save it directly.',
    '3. Keep explanations concise, high-signal, and structured so the user can scan architecture, files changed, and next steps effortlessly.',
    '4. If the user asks about existing workspace files, read and preserve existing functionality while applying clean targeted improvements.',
    '',
    workspaceSummary
      ? `CURRENT WORKSPACE FILES:\n${workspaceSummary}`
      : 'CURRENT WORKSPACE: Empty (no files saved yet).',
  ].join('\n');
}
