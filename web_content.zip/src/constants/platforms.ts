import {
  Tv,
  Flame,
  Music2,
  Film,
  LayoutGrid,
  Share2,
  Sparkles,
  Globe,
  type LucideIcon,
} from "lucide-react";
import type { Platform, ContentType } from "@/types";

export type AspectRatioType = "16:9" | "9:16" | "1:1" | "4:5";

export interface PlatformOption {
  id: string;
  name: string;
  platform: Platform;
  format: "16:9" | "9:16" | "1:1" | "4:5" | "ALL";
  contentType: ContentType;
  badge: string;
  subtitle: string;
  tag: string;
  color: string;
  borderColor: string;
  bgLight: string;
  icon: LucideIcon;
}

export const PLATFORM_OPTIONS: PlatformOption[] = [
  {
    id: "ALL",
    name: "Multi-Plataforma (Omnichannel)",
    platform: "GENERAL",
    format: "ALL",
    contentType: "VIDEO",
    badge: "TODAS AS REDES",
    subtitle: "Gera pacote unificado (16:9 + 9:16 + 1:1) com roteiro e copy adaptados para todas as redes simultaneamente",
    tag: "16:9 + 9:16 + 1:1",
    color: "text-studio-gold",
    borderColor: "border-studio-gold/30 hover:border-studio-gold",
    bgLight: "bg-studio-gold/10",
    icon: Sparkles,
  },
  {
    id: "YOUTUBE",
    name: "YouTube Vídeo Longo",
    platform: "YOUTUBE",
    format: "16:9",
    contentType: "YOUTUBE_VIDEO",
    badge: "16:9 HORIZONTAL",
    subtitle: "Vídeo completo em 1080p/4K, roteiro detalhado, capítulos de retenção, tags de SEO e capas em alta conversão",
    tag: "16:9 • 1080p / 4K",
    color: "text-red-400",
    borderColor: "border-red-500/30 hover:border-red-500",
    bgLight: "bg-red-500/10",
    icon: Tv,
  },
  {
    id: "SHORTS",
    name: "YouTube Shorts",
    platform: "YOUTUBE",
    format: "9:16",
    contentType: "SHORT",
    badge: "9:16 VERTICAL",
    subtitle: "Vídeo vertical rápido, gancho de retenção nos 3 primeiros segundos, legendas dinâmicas e ritmo contínuo",
    tag: "9:16 • Até 60s",
    color: "text-red-400",
    borderColor: "border-red-500/30 hover:border-red-500",
    bgLight: "bg-red-500/10",
    icon: Flame,
  },
  {
    id: "TIKTOK",
    name: "TikTok Viral",
    platform: "TIKTOK",
    format: "9:16",
    contentType: "TIKTOK_VIDEO",
    badge: "9:16 VERTICAL",
    subtitle: "Cortes acelerados, storytelling magnético, efeitos sonoros dinâmicos e hashtags de alta viralização",
    tag: "9:16 • Viral",
    color: "text-cyan-400",
    borderColor: "border-cyan-500/30 hover:border-cyan-500",
    bgLight: "bg-cyan-500/10",
    icon: Music2,
  },
  {
    id: "INSTAGRAM_REELS",
    name: "Instagram Reels",
    platform: "INSTAGRAM",
    format: "9:16",
    contentType: "REEL",
    badge: "9:16 VERTICAL",
    subtitle: "Estética cinematográfica apurada, transições elegantes, hooks visuais e sincronização com tendências",
    tag: "9:16 • Estética HD",
    color: "text-pink-400",
    borderColor: "border-pink-500/30 hover:border-pink-500",
    bgLight: "bg-pink-500/10",
    icon: Film,
  },
  {
    id: "INSTAGRAM_FEED",
    name: "Instagram Feed & Carrossel",
    platform: "INSTAGRAM",
    format: "1:1",
    contentType: "INSTAGRAM_POST",
    badge: "1:1 QUADRADO",
    subtitle: "Post visual e carrossel de alto engajamento, imagens com IA de ultra-definição e copy persuasiva com CTA",
    tag: "1:1 ou 4:5 • Posts",
    color: "text-purple-400",
    borderColor: "border-purple-500/30 hover:border-purple-500",
    bgLight: "bg-purple-500/10",
    icon: LayoutGrid,
  },
  {
    id: "FACEBOOK",
    name: "Facebook Vídeo & Reels",
    platform: "FACEBOOK",
    format: "16:9",
    contentType: "FACEBOOK_POST",
    badge: "16:9 / 9:16",
    subtitle: "Conteúdo compartilhável para páginas e grupos, legenda envolvente e apelo de debate comunitário",
    tag: "16:9 / 9:16 • Social",
    color: "text-blue-400",
    borderColor: "border-blue-500/30 hover:border-blue-500",
    bgLight: "bg-blue-500/10",
    icon: Share2,
  },
  {
    id: "OTHER",
    name: "Canais Alternativos & Globais",
    platform: "RUMBLE",
    format: "16:9",
    contentType: "VIDEO",
    badge: "RUMBLE / VIMEO",
    subtitle: "Distribuição independente para canais como Rumble, FebSpot, Dailymotion, Vimeo e Bilibili",
    tag: "16:9 • Global",
    color: "text-emerald-400",
    borderColor: "border-emerald-500/30 hover:border-emerald-500",
    bgLight: "bg-emerald-500/10",
    icon: Globe,
  },
];
