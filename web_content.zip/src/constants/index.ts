// ============================================================
// AI CREATOR STUDIO — CONSTANTS
// CORE 1.0 | SADRAQUE NGOLA
// ============================================================

import type { AgeRange, ContentType, Platform, Language, OutputFormat } from "@/types";

export const APP_NAME = "AI Creator Studio";
export const APP_OWNER = "Sadraque Ngola";
export const APP_VERSION = "CORE 4.0";
export const OWNER_EMAIL = "sadraquengola7@gmail.com";
export const OWNER_EMAILS = ["sadraquengola7@gmail.com", "sadraquengola83@gmail.com"];


export const AGE_RANGES: AgeRange[] = [
  { label: "Bebês (0–2)", min: 0, max: 2, category: "0-2" },
  { label: "Primeira Infância (1–3)", min: 1, max: 3, category: "1-3" },
  { label: "Pré-Escolar (3–5)", min: 3, max: 5, category: "3-5" },
  { label: "Infantil (5–8)", min: 5, max: 8, category: "5-8" },
  { label: "Juvenil (8–12)", min: 8, max: 12, category: "8-12" },
  { label: "Adolescentes", category: "TEENS" },
  { label: "Adultos", category: "ADULT" },
  { label: "Geral", category: "GENERAL" },
];

export const PLATFORMS: { value: Platform; label: string; icon: string; color: string }[] = [
  { value: "YOUTUBE", label: "YouTube", icon: "▶", color: "#ff0000" },
  { value: "TIKTOK", label: "TikTok", icon: "♪", color: "#69c9d0" },
  { value: "INSTAGRAM", label: "Instagram", icon: "◈", color: "#e1306c" },
  { value: "FACEBOOK", label: "Facebook", icon: "f", color: "#1877f2" },
  { value: "FEBSPOT", label: "FebSpot", icon: "★", color: "#10b981" },
  { value: "RUMBLE", label: "Rumble", icon: "▶", color: "#85c742" },
  { value: "BILIBILI", label: "Bilibili.com", icon: "📺", color: "#00a1d6" },
  { value: "DAILYMOTION", label: "Dailymotion", icon: "d", color: "#0066dc" },
  { value: "VIMEO", label: "Vimeo", icon: "v", color: "#1ab7ea" },
  { value: "UOL_MAIS", label: "UOL Mais / Vol Mais", icon: "✦", color: "#f97316" },
  { value: "SAPO_VIDEOS", label: "SAPO Vídeos", icon: "🐸", color: "#14b8a6" },
  { value: "GENERAL", label: "Geral", icon: "◉", color: "#94a3b8" },
];

export const LANGUAGES: { value: Language; label: string; flag: string }[] = [
  { value: "PT_BR", label: "Português (Brasil)", flag: "🇧🇷" },
  { value: "PT_PT", label: "Português (Portugal)", flag: "🇵🇹" },
  { value: "PT", label: "Português", flag: "🌐" },
  { value: "EN", label: "English", flag: "🇬🇧" },
  { value: "ES", label: "Español", flag: "🇪🇸" },
  { value: "FR", label: "Français", flag: "🇫🇷" },
  { value: "DE", label: "Deutsch", flag: "🇩🇪" },
];

export const OUTPUT_FORMATS: { value: OutputFormat; label: string; platform: Platform; resolution: string; aspectRatio: string }[] = [
  { value: "YOUTUBE_1080p", label: "YouTube 1080p", platform: "YOUTUBE", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "YOUTUBE_4K", label: "YouTube 4K", platform: "YOUTUBE", resolution: "3840×2160", aspectRatio: "16:9" },
  { value: "SHORTS_1080p", label: "YouTube Shorts", platform: "YOUTUBE", resolution: "1080×1920", aspectRatio: "9:16" },
  { value: "TIKTOK_1080p", label: "TikTok", platform: "TIKTOK", resolution: "1080×1920", aspectRatio: "9:16" },
  { value: "INSTAGRAM_SQUARE", label: "Instagram Quadrado", platform: "INSTAGRAM", resolution: "1080×1080", aspectRatio: "1:1" },
  { value: "INSTAGRAM_PORTRAIT", label: "Instagram Retrato", platform: "INSTAGRAM", resolution: "1080×1350", aspectRatio: "4:5" },
  { value: "INSTAGRAM_LANDSCAPE", label: "Instagram Paisagem", platform: "INSTAGRAM", resolution: "1080×608", aspectRatio: "16:9" },
  { value: "FACEBOOK_1080p", label: "Facebook 1080p", platform: "FACEBOOK", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "FEBSPOT_1080p", label: "FebSpot 1080p", platform: "FEBSPOT", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "RUMBLE_1080p", label: "Rumble 1080p", platform: "RUMBLE", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "BILIBILI_1080p", label: "Bilibili 1080p", platform: "BILIBILI", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "DAILYMOTION_1080p", label: "Dailymotion 1080p", platform: "DAILYMOTION", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "VIMEO_1080p", label: "Vimeo 1080p", platform: "VIMEO", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "UOL_MAIS_1080p", label: "UOL Mais / Vol Mais 1080p", platform: "UOL_MAIS", resolution: "1920×1080", aspectRatio: "16:9" },
  { value: "SAPO_VIDEOS_1080p", label: "SAPO Vídeos 1080p", platform: "SAPO_VIDEOS", resolution: "1920×1080", aspectRatio: "16:9" },
];

export const CONTENT_TYPE_LABELS: Record<ContentType, string> = {
  VIDEO: "Vídeo",
  SHORT: "Short",
  REEL: "Reel",
  IMAGE: "Imagem",
  THUMBNAIL: "Thumbnail",
  SCRIPT: "Roteiro",
  STORYBOARD: "Storyboard",
  MUSIC: "Música",
  VOICE: "Narração",
  SFX: "Efeito Sonoro",
  CHILDREN_VIDEO: "Vídeo Infantil",
  YOUTUBE_VIDEO: "Vídeo YouTube",
  TIKTOK_VIDEO: "Vídeo TikTok",
  INSTAGRAM_POST: "Post Instagram",
  FACEBOOK_POST: "Post Facebook",
  PODCAST: "Podcast",
  COURSE: "Curso",
};

export const WORKFLOW_STEPS = [
  { key: "BRIEFING", label: "Briefing", icon: "📋" },
  { key: "SCRIPTING", label: "Roteiro", icon: "✍️" },
  { key: "STORYBOARDING", label: "Storyboard", icon: "🎬" },
  { key: "MEDIA_PLANNING", label: "Plano de Mídia", icon: "🗂️" },
  { key: "GENERATING", label: "Geração de Mídia", icon: "✨" },
  { key: "EDITING", label: "Edição", icon: "🎞️" },
  { key: "REVIEW", label: "Revisão", icon: "👁️" },
  { key: "RENDERING", label: "Render", icon: "⚙️" },
  { key: "COMPLETED", label: "Concluído", icon: "✅" },
];

export const QUICK_COMMANDS = [
  "Cria um vídeo infantil de 5 minutos sobre animais cantando",
  "Cria um Short para YouTube sobre curiosidades científicas",
  "Cria uma publicidade para o meu perfume",
  "Cria uma imagem para Instagram de viagens",
  "Cria uma música infantil animada",
  "Cria um Reel motivacional para Instagram",
  "Cria um roteiro de podcast sobre tecnologia",
  "Gera uma thumbnail para canal de culinária",
];

export const MUSIC_GENRES = [
  "Pop Infantil", "Hip Hop", "Lo-fi", "Eletrônico", "Acústico",
  "Orquestral", "Jazz", "R&B", "Gospel", "Animação",
];

export const VOICE_STYLES = [
  { id: "pt_narrator_m", label: "Narrador PT-BR Masculino", language: "PT_BR" },
  { id: "pt_narrator_f", label: "Narradora PT-BR Feminina", language: "PT_BR" },
  { id: "pt_children", label: "Voz Infantil PT-BR", language: "PT_BR" },
  { id: "pt_pt_m", label: "Narrador PT-PT Masculino", language: "PT_PT" },
  { id: "en_narrator", label: "English Narrator", language: "EN" },
];

export const SFX_CATEGORIES = [
  "Animais", "Água", "Vento", "Passos", "Risos",
  "Aplausos", "Ambientes", "Transições", "Efeitos Infantis", "Outros",
];
