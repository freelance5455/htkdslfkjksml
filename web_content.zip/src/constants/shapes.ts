import { CellColor, ShapeDefinition } from '../types/game';

// Helper to count active cells and get width/height
function makeShape(id: string, name: string, matrix: number[][], color: CellColor): ShapeDefinition {
  const height = matrix.length;
  const width = matrix[0].length;
  let cellCount = 0;
  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      if (matrix[r][c] === 1) cellCount++;
    }
  }
  return { id, name, matrix, color, width, height, cellCount };
}

export const ALL_SHAPES: ShapeDefinition[] = [
  // 1x1 Single
  makeShape('dot_1', 'Single Gem', [[1]], 'cyan'),

  // 2-blocks
  makeShape('line_2_h', 'Duo Rod H', [[1, 1]], 'blue'),
  makeShape('line_2_v', 'Duo Rod V', [[1], [1]], 'blue'),

  // 3-blocks
  makeShape('line_3_h', 'Trio Rod H', [[1, 1, 1]], 'emerald'),
  makeShape('line_3_v', 'Trio Rod V', [[1], [1], [1]], 'emerald'),
  makeShape('corner_2_tl', 'Corner TL', [[1, 1], [1, 0]], 'amber'),
  makeShape('corner_2_tr', 'Corner TR', [[1, 1], [0, 1]], 'amber'),
  makeShape('corner_2_bl', 'Corner BL', [[1, 0], [1, 1]], 'amber'),
  makeShape('corner_2_br', 'Corner BR', [[0, 1], [1, 1]], 'amber'),

  // 4-blocks: Square
  makeShape('square_2', 'Core Cube', [[1, 1], [1, 1]], 'coral'),

  // 4-blocks: 4-line
  makeShape('line_4_h', 'Beam 4 H', [[1, 1, 1, 1]], 'purple'),
  makeShape('line_4_v', 'Beam 4 V', [[1], [1], [1], [1]], 'purple'),

  // 4-blocks: L shapes (3x2 and 2x3)
  makeShape('L_4_1', 'L Shape 1', [[1, 0], [1, 0], [1, 1]], 'ruby'),
  makeShape('L_4_2', 'L Shape 2', [[0, 1], [0, 1], [1, 1]], 'ruby'),
  makeShape('L_4_3', 'L Shape 3', [[1, 1, 1], [1, 0, 0]], 'ruby'),
  makeShape('L_4_4', 'L Shape 4', [[1, 1, 1], [0, 0, 1]], 'ruby'),
  makeShape('L_4_5', 'L Shape 5', [[1, 1], [1, 0], [1, 0]], 'ruby'),
  makeShape('L_4_6', 'L Shape 6', [[1, 1], [0, 1], [0, 1]], 'ruby'),
  makeShape('L_4_7', 'L Shape 7', [[0, 0, 1], [1, 1, 1]], 'ruby'),
  makeShape('L_4_8', 'L Shape 8', [[1, 0, 0], [1, 1, 1]], 'ruby'),

  // 4-blocks: T shapes
  makeShape('T_4_down', 'T Shape D', [[1, 1, 1], [0, 1, 0]], 'violet'),
  makeShape('T_4_up', 'T Shape U', [[0, 1, 0], [1, 1, 1]], 'violet'),
  makeShape('T_4_left', 'T Shape L', [[0, 1], [1, 1], [0, 1]], 'violet'),
  makeShape('T_4_right', 'T Shape R', [[1, 0], [1, 1], [1, 0]], 'violet'),

  // 4-blocks: S and Z
  makeShape('S_4_h', 'S Shape H', [[0, 1, 1], [1, 1, 0]], 'cyan'),
  makeShape('S_4_v', 'S Shape V', [[1, 0], [1, 1], [0, 1]], 'cyan'),
  makeShape('Z_4_h', 'Z Shape H', [[1, 1, 0], [0, 1, 1]], 'blue'),
  makeShape('Z_4_v', 'Z Shape V', [[0, 1], [1, 1], [1, 0]], 'blue'),

  // 5-blocks: Long Beams
  makeShape('line_5_h', 'Titan Beam H', [[1, 1, 1, 1, 1]], 'coral'),
  makeShape('line_5_v', 'Titan Beam V', [[1], [1], [1], [1], [1]], 'coral'),

  // 5-blocks: Corner 3x3 big
  makeShape('corner_3_tl', 'Big Corner TL', [[1, 1, 1], [1, 0, 0], [1, 0, 0]], 'amber'),
  makeShape('corner_3_tr', 'Big Corner TR', [[1, 1, 1], [0, 0, 1], [0, 0, 1]], 'amber'),
  makeShape('corner_3_bl', 'Big Corner BL', [[1, 0, 0], [1, 0, 0], [1, 1, 1]], 'amber'),
  makeShape('corner_3_br', 'Big Corner BR', [[0, 0, 1], [0, 0, 1], [1, 1, 1]], 'amber'),

  // Plus 5-blocks
  makeShape('plus_5', 'Cross Star', [[0, 1, 0], [1, 1, 1], [0, 1, 0]], 'emerald'),

  // 5-blocks: U-shapes (Horseshoe in 4 orientations)
  makeShape('U_5_up', 'Horseshoe U', [[1, 0, 1], [1, 1, 1]], 'cyan'),
  makeShape('U_5_down', 'Horseshoe D', [[1, 1, 1], [1, 0, 1]], 'cyan'),
  makeShape('U_5_left', 'Horseshoe L', [[1, 1], [1, 0], [1, 1]], 'cyan'),
  makeShape('U_5_right', 'Horseshoe R', [[1, 1], [0, 1], [1, 1]], 'cyan'),

  // 5-blocks: W-shape
  makeShape('W_5_1', 'Stair W1', [[1, 0, 0], [1, 1, 0], [0, 1, 1]], 'purple'),
  makeShape('W_5_2', 'Stair W2', [[0, 1, 1], [1, 1, 0], [1, 0, 0]], 'purple'),

  // 3x3 Square (Big boss block)
  makeShape('square_3', 'Titan Cube', [[1, 1, 1], [1, 1, 1], [1, 1, 1]], 'purple'),

  // 2x3 Rectangles
  makeShape('rect_2x3_h', 'Matrix 2x3', [[1, 1, 1], [1, 1, 1]], 'ruby'),
  makeShape('rect_2x3_v', 'Matrix 3x2', [[1, 1], [1, 1], [1, 1]], 'ruby'),

  // Hollow 3x3 Frame (Ring of 8 blocks)
  makeShape('ring_3x3', 'Cosmic Portal Ring', [[1, 1, 1], [1, 0, 1], [1, 1, 1]], 'prism'),
];

// Color palette mapping to gradients and glow effects
export const COLOR_MAP: Record<CellColor, {
  primary: string;
  gradient: string;
  shadow: string;
  glow: string;
  border: string;
  specular: string;
}> = {
  prism: {
    primary: '#ec4899',
    gradient: 'from-pink-400 via-indigo-500 to-cyan-400',
    shadow: 'shadow-pink-500/50',
    glow: 'rgba(236, 72, 153, 0.7)',
    border: 'border-pink-300/80',
    specular: 'rgba(255, 255, 255, 0.6)',
  },
  cyan: {
    primary: '#06b6d4',
    gradient: 'from-cyan-400 via-cyan-500 to-teal-600',
    shadow: 'shadow-cyan-500/40',
    glow: 'rgba(6, 182, 212, 0.6)',
    border: 'border-cyan-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  blue: {
    primary: '#3b82f6',
    gradient: 'from-blue-400 via-indigo-500 to-blue-700',
    shadow: 'shadow-blue-500/40',
    glow: 'rgba(59, 130, 246, 0.6)',
    border: 'border-blue-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  purple: {
    primary: '#a855f7',
    gradient: 'from-purple-400 via-fuchsia-500 to-purple-700',
    shadow: 'shadow-purple-500/40',
    glow: 'rgba(168, 85, 247, 0.6)',
    border: 'border-purple-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  emerald: {
    primary: '#10b981',
    gradient: 'from-emerald-300 via-teal-500 to-emerald-700',
    shadow: 'shadow-emerald-500/40',
    glow: 'rgba(16, 185, 129, 0.6)',
    border: 'border-emerald-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  amber: {
    primary: '#f59e0b',
    gradient: 'from-amber-300 via-amber-500 to-yellow-600',
    shadow: 'shadow-amber-500/40',
    glow: 'rgba(245, 158, 11, 0.6)',
    border: 'border-amber-200/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  ruby: {
    primary: '#f43f5e',
    gradient: 'from-rose-400 via-rose-500 to-red-600',
    shadow: 'shadow-rose-500/40',
    glow: 'rgba(244, 63, 94, 0.6)',
    border: 'border-rose-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  coral: {
    primary: '#fb923c',
    gradient: 'from-orange-400 via-amber-500 to-orange-600',
    shadow: 'shadow-orange-500/40',
    glow: 'rgba(251, 146, 60, 0.6)',
    border: 'border-orange-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
  violet: {
    primary: '#8b5cf6',
    gradient: 'from-violet-400 via-purple-500 to-indigo-700',
    shadow: 'shadow-violet-500/40',
    glow: 'rgba(139, 92, 246, 0.6)',
    border: 'border-violet-300/60',
    specular: 'rgba(255, 255, 255, 0.45)',
  },
};

/**
 * Intelligent generator for 3 playable pieces:
 * Balances shape difficulty so the user never gets 3 massive impossible pieces at once.
 */
export function generateThreePieces(): ShapeDefinition[] {
  const smallPool = ALL_SHAPES.filter(s => s.cellCount <= 3);
  const mediumPool = ALL_SHAPES.filter(s => s.cellCount === 4);
  const largePool = ALL_SHAPES.filter(s => s.cellCount >= 5);

  const getRandom = (arr: ShapeDefinition[]) => arr[Math.floor(Math.random() * arr.length)];

  // Strategy:
  // 1 shape is guaranteed small-to-medium (cellCount <= 4)
  // 1 shape is medium
  // 1 shape can be small, medium, or large (max 1 large shape per set of 3)
  const roll = Math.random();
  let piece1: ShapeDefinition;
  let piece2: ShapeDefinition;
  let piece3: ShapeDefinition;

  if (roll < 0.4) {
    // 1 small, 1 medium, 1 large
    piece1 = getRandom(smallPool);
    piece2 = getRandom(mediumPool);
    piece3 = getRandom(largePool);
  } else if (roll < 0.75) {
    // 2 small/medium, 1 medium
    piece1 = getRandom(smallPool);
    piece2 = getRandom(mediumPool);
    piece3 = getRandom(mediumPool);
  } else {
    // 2 small, 1 large/medium
    piece1 = getRandom(smallPool);
    piece2 = getRandom(smallPool);
    piece3 = Math.random() < 0.5 ? getRandom(largePool) : getRandom(mediumPool);
  }

  // Shuffle order of the 3 pieces
  const pieces = [piece1, piece2, piece3];
  for (let i = pieces.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pieces[i], pieces[j]] = [pieces[j], pieces[i]];
  }

  return pieces;
}
