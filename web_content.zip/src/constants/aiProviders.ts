import {
  Sparkles,
  Bot,
  Video,
  Film,
  Image as ImageIcon,
  Mic,
  Smile,
  Sliders,
  Cpu,
  Zap,
  type LucideIcon,
} from "lucide-react";
import type { VideoEngineId } from "@/types/video";
import type { ImageEngineId } from "@/types/image";

export type AIProviderCategoryId =
  | "ORCHESTRATOR"
  | "TEXT"
  | "VIDEO"
  | "IMAGE"
  | "VOICE"
  | "AVATAR"
  | "RENDER";

export interface AIProviderOption {
  id: string;
  name: string;
  providerCompany: string;
  model: string;
  category: AIProviderCategoryId;
  categoryLabel: string;
  badge: string;
  subtitle: string;
  tag: string;
  status: "OPERATIONAL" | "ACTIVE" | "READY";
  color: string;
  borderColor: string;
  bgLight: string;
  icon: LucideIcon;
  defaultVideoEngine?: VideoEngineId;
  defaultImageEngine?: ImageEngineId;
  promptPlaceholder: string;
  presets: string[];
}

export const AI_PROVIDERS: AIProviderOption[] = [
  {
    id: "all",
    name: "Orquestrador Multimodal (Auto IA)",
    providerCompany: "Google Gemini + PixVerse + Neural Studio",
    model: "full-multimodal-orchestration",
    category: "ORCHESTRATOR",
    categoryLabel: "Full-Stack Multimodal",
    badge: "TODOS OS MOTORES",
    subtitle: "Combina o melhor de cada IA: Gemini 3.7 para roteiro + PixVerse/Veo para vídeo + Imagens 4K + Voz Neural + FFmpeg.",
    tag: "Gemini + PixVerse + Neural",
    status: "OPERATIONAL",
    color: "text-studio-gold",
    borderColor: "border-studio-gold/40 hover:border-studio-gold",
    bgLight: "bg-studio-gold/15",
    icon: Sparkles,
    defaultVideoEngine: "pixverse",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva o conteúdo que você deseja criar com inteligência artificial completa...

Exemplos:
• Cria um vídeo explicativo de 2 minutos sobre o futuro da inteligência artificial e robótica
• Cria um comercial cinematográfico para lançamento de um app futurista de produtividade
• Cria um Short/Reel viral sobre 5 curiosidades fascinantes do oceano profundo`,
    presets: [
      "Vídeo completo com roteiro, cenas em vídeo cinemático, narração e trilha sonora",
      "Short de alta retenção com gancho dinâmico nos 3 primeiros segundos e cortes rápidos",
      "Comercial cinematográfico de produto com iluminação de estúdio e copy persuasiva",
      "Documentário explicativo detalhado com capítulos, imagens conceituais e narração épica",
    ],
  },
  {
    id: "gemini-text",
    name: "Google Gemini 3.7 Flash & Pro",
    providerCompany: "Google DeepMind",
    model: "gemini-3.7-flash",
    category: "TEXT",
    categoryLabel: "Raciocínio & Roteiro",
    badge: "MOTOR PRINCIPAL",
    subtitle: "Especialista em roteiros complexos, análise multimodal, divisão de cenas, ganchos de retenção e SEO de alta conversão.",
    tag: "Gemini 3.7 Flash",
    status: "OPERATIONAL",
    color: "text-blue-400",
    borderColor: "border-blue-500/30 hover:border-blue-500",
    bgLight: "bg-blue-500/10",
    icon: Bot,
    defaultVideoEngine: "veo-2",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva o tema ou roteiro que você deseja criar com o Google Gemini 3.7...

Exemplos:
• Elabora um roteiro aprofundado com capítulos, gancho inicial e chamada para ação sobre produtividade
• Cria um storytelling dramático de 5 atos sobre a corrida espacial com dados históricos precisos`,
    presets: [
      "Roteiro detalhado com marcações de cenas, ganchos psicológicos e timestamps",
      "Storytelling magnético de alta retenção para YouTube e canais dark",
      "Estrutura completa de documentário com fatos verificados e conclusões impactantes",
      "Texto publicitário com técnicas de persuasão, copy AIDA e chamada para ação",
    ],
  },
  {
    id: "pixverse",
    name: "PixVerse AI Video V3.5",
    providerCompany: "PixVerse AI (API Oficial)",
    model: "pixverse-v3.5",
    category: "VIDEO",
    categoryLabel: "Vídeo Cinemático",
    badge: "API OFICIAL ATIVA",
    subtitle: "Geração de cenas de vídeo cinematográficas com movimentos de câmera 3D (Pan, Zoom, Orbit), física realista e ultra-definição.",
    tag: "PixVerse V3.5 1080p",
    status: "OPERATIONAL",
    color: "text-purple-400",
    borderColor: "border-purple-500/30 hover:border-purple-500",
    bgLight: "bg-purple-500/10",
    icon: Film,
    defaultVideoEngine: "pixverse",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva as cenas e a estética cinematográfica para gerar com PixVerse V3.5...

Exemplos:
• Câmera em órbita lenta cinematográfica ao redor de uma estação espacial com iluminação volumétrica
• Drone FPV sobrevoando montanhas nevadas no pôr do sol em 1080p 60fps`,
    presets: [
      "Vídeo de ficção científica com iluminação volumétrica e movimento de câmera 3D",
      "Cenas de natureza em alta definição com câmera lenta e detalhes fotográficos",
      "Cenas urbanas cyberpunk com néon, reflexos de chuva e movimento contínuo",
      "Vídeo dinâmico de produto com foco seletivo macro e iluminação de estúdio",
    ],
  },
  {
    id: "runway-luma",
    name: "Runway Gen-3 & Luma Ray",
    providerCompany: "RunwayML / Luma Dream Machine",
    model: "gen3-alpha / luma-ray",
    category: "VIDEO",
    categoryLabel: "Cinema Hollywoodiano",
    badge: "ULTRA DINÂMICO",
    subtitle: "Simulação de física avançada, transições complexas, controle fino de iluminação e renderização de grau cinematográfico.",
    tag: "Runway Gen-3 + Luma",
    status: "OPERATIONAL",
    color: "text-amber-400",
    borderColor: "border-amber-500/30 hover:border-amber-500",
    bgLight: "bg-amber-500/10",
    icon: Video,
    defaultVideoEngine: "runway-gen3",
    defaultImageEngine: "midjourney-v6",
    promptPlaceholder: `Descreva uma sequência de vídeo de nível cinematográfico para Runway/Luma...

Exemplos:
• Plano sequência contínuo atravessando um laboratório futurista com partículas de poeira e luz difusa
• Transição fluida entre um deserto escaldante e uma floresta densa com física precisa`,
    presets: [
      "Plano sequência contínuo com física de tecidos e iluminação dramática",
      "Câmera lenta dramática com partículas flutuantes e profundidade de campo",
      "Vídeo de ação com movimentos rápidos de câmera e estabilização fluida",
    ],
  },
  {
    id: "image-engine-studio",
    name: "AI Studio Image Engine 4K (Flux/Imagen)",
    providerCompany: "Google Imagen 3 & Flux 1 Pro",
    model: "studio-image-gen-v2",
    category: "IMAGE",
    categoryLabel: "Frames & Capas 4K",
    badge: "4K RESOLUÇÃO",
    subtitle: "Geração de arte conceitual, storyboards ilustrados, thumbnails de alta taxa de clique e consistência visual de personagens.",
    tag: "Flux & Imagen 4K",
    status: "OPERATIONAL",
    color: "text-emerald-400",
    borderColor: "border-emerald-500/30 hover:border-emerald-500",
    bgLight: "bg-emerald-500/10",
    icon: ImageIcon,
    defaultVideoEngine: "veo-2",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva as imagens ou frames que você deseja criar com o Image Engine 4K...

Exemplos:
• Capa de alta conversão para YouTube com expressão marcante, texto em destaque e iluminação dramática
• Arte conceitual de uma metrópole sustentável coberta por vegetação futurista`,
    presets: [
      "Thumbnail magnética de alto contraste e foco no assunto principal",
      "Storyboards detalhados para cada cena com consistência de estilo e luz",
      "Personagem consistente em múltiplos ângulos e iluminações fotográficas",
      "Texturas e fundos conceituais em 4K para composição gráfica",
    ],
  },
  {
    id: "elevenlabs-voice",
    name: "ElevenLabs & Neural Voice",
    providerCompany: "ElevenLabs / Studio Neural Speech",
    model: "neural-speech-multilingual-v2",
    category: "VOICE",
    categoryLabel: "Voz & Fala Neural",
    badge: "VOZ HUMANA",
    subtitle: "Síntese vocal humana ultrarrealista com modulação emocional, entonação cinematográfica, clonagem e sincronia de ritmo.",
    tag: "Neural TTS Multilíngue",
    status: "OPERATIONAL",
    color: "text-rose-400",
    borderColor: "border-rose-500/30 hover:border-rose-500",
    bgLight: "bg-rose-500/10",
    icon: Mic,
    defaultVideoEngine: "pixverse",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva a narração ou texto para ser falado com vozes neurais hiper-realistas...

Exemplos:
• Narração empolgante com voz de trailer de cinema para um documentário misterioso
• Voz calma, didática e acolhedora em português brasileiro para curso em vídeo`,
    presets: [
      "Narração cinematográfica profunda para documentários e histórias épicas",
      "Voz dinâmica e jovem com ritmo acelerado para vídeos do TikTok e Reels",
      "Locução corporativa clara e elegante para apresentações e tutoriais",
    ],
  },
  {
    id: "avatar-engine-studio",
    name: "AI Studio Avatar Presenter",
    providerCompany: "AI Studio Digital Human",
    model: "avatar-sync-host-v2",
    category: "AVATAR",
    categoryLabel: "Apresentador Virtual",
    badge: "LIP-SYNC MP4",
    subtitle: "Geração de apresentador virtual com sincronização labial perfeita em MP4, expressões faciais naturais e opção de fundo transparente.",
    tag: "Lip-Sync & Host Digital",
    status: "OPERATIONAL",
    color: "text-cyan-400",
    borderColor: "border-cyan-500/30 hover:border-cyan-500",
    bgLight: "bg-cyan-500/10",
    icon: Smile,
    defaultVideoEngine: "pixverse",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva o apresentador virtual e o roteiro que ele deverá comunicar...

Exemplos:
• Apresentador profissional de terno moderno dando as boas-vindas ao novo produto
• Apresentadora entusiasta de tecnologia explicando as novidades de IA em 60 segundos`,
    presets: [
      "Apresentador virtual executivo com fundo de redação ou escritório moderno",
      "Host carismático de canal do YouTube com gesticulação e expressões vivas",
      "Especialista explicando conceitos complexos em vídeo com legendas automáticas",
    ],
  },
  {
    id: "render-engine-ffmpeg",
    name: "AI Studio FFmpeg Compositor",
    providerCompany: "FFmpeg Native Engine",
    model: "ffmpeg-timeline-compositor-v2",
    category: "RENDER",
    categoryLabel: "Montagem & Render",
    badge: "1080P/4K EXPORT",
    subtitle: "Motor nativo de pós-produção acelerada: montagem de cenas, auto-ducking musical, sobreposição de legendas e exportação final.",
    tag: "FFmpeg Timeline & Audio",
    status: "OPERATIONAL",
    color: "text-teal-400",
    borderColor: "border-teal-500/30 hover:border-teal-500",
    bgLight: "bg-teal-500/10",
    icon: Sliders,
    defaultVideoEngine: "pixverse",
    defaultImageEngine: "imagen-3",
    promptPlaceholder: `Descreva os parâmetros de montagem, ritmo e transições de renderização...

Exemplos:
• Compilação rápida de 60 segundos com cortes na batida da música e legendas animadas
• Renderização 4K master com correção de cor cinematográfica e trilha multifaixa`,
    presets: [
      "Montagem rítmica sincronizada com as batidas da música e cortes precisos",
      "Vídeo vertical 9:16 com legendas dinâmicas em amarelo e azul estilo Alex Hormozi",
      "Exportação horizontal 16:9 em alta taxa de bits para qualidade máxima no YouTube",
    ],
  },
];
