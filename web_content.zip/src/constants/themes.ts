export type ThemeId = 'dark' | 'light' | 'sepia' | 'midnight';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  className: string;
  icon: string;
  bgPreview: string;
  accentPreview: string;
}

export const THEMES: Record<ThemeId, ThemeConfig> = {
  dark: {
    id: 'dark',
    name: 'Claude Dark',
    className: '', // Default dark root
    icon: '🌙',
    bgPreview: '#1f1e1d',
    accentPreview: '#d97757',
  },
  light: {
    id: 'light',
    name: 'Claude Light',
    className: 'theme-light',
    icon: '☀️',
    bgPreview: '#faf9f5',
    accentPreview: '#c46445',
  },
  sepia: {
    id: 'sepia',
    name: 'Claude Sepia',
    className: 'theme-sepia',
    icon: '☕',
    bgPreview: '#2b2520',
    accentPreview: '#e08253',
  },
  midnight: {
    id: 'midnight',
    name: 'Midnight Cyber',
    className: 'theme-midnight',
    icon: '🌌',
    bgPreview: '#09090b',
    accentPreview: '#f97316',
  },
};
