import { ThemeId } from '../types/game';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  subtitle: string;
  primaryAccent: string;
  secondaryAccent: string;
  boardBg: string;
  boardBorder: string;
  boardGlow: string;
  previewColor: string;
}

export const GAME_THEMES: Record<ThemeId, ThemeConfig> = {
  cosmic: {
    id: 'cosmic',
    name: 'Cosmic Deep Space',
    subtitle: 'Electric Cyan & Deep Indigo',
    primaryAccent: '#06b6d4',
    secondaryAccent: '#3b82f6',
    boardBg: '#091122',
    boardBorder: 'rgba(6, 182, 212, 0.25)',
    boardGlow: 'rgba(6, 182, 212, 0.15)',
    previewColor: '#06b6d4',
  },
  cyber: {
    id: 'cyber',
    name: 'Cyber Neon',
    subtitle: 'Hot Magenta & High-Voltage Violet',
    primaryAccent: '#ec4899',
    secondaryAccent: '#a855f7',
    boardBg: '#13091e',
    boardBorder: 'rgba(236, 72, 153, 0.3)',
    boardGlow: 'rgba(236, 72, 153, 0.2)',
    previewColor: '#ec4899',
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald Nebula',
    subtitle: 'Jade Green & Radiant Mint',
    primaryAccent: '#10b981',
    secondaryAccent: '#06b6d4',
    boardBg: '#061714',
    boardBorder: 'rgba(16, 185, 129, 0.3)',
    boardGlow: 'rgba(16, 185, 129, 0.2)',
    previewColor: '#10b981',
  },
  supernova: {
    id: 'supernova',
    name: 'Supernova Fire',
    subtitle: 'Solar Amber & Volcanic Crimson',
    primaryAccent: '#f59e0b',
    secondaryAccent: '#ef4444',
    boardBg: '#1a0d0a',
    boardBorder: 'rgba(245, 158, 11, 0.3)',
    boardGlow: 'rgba(245, 158, 11, 0.2)',
    previewColor: '#f59e0b',
  },
};

export interface BlockStyleConfig {
  id: 'crystalline' | 'neon' | 'metallic' | 'obsidian';
  name: string;
  subtitle: string;
  description: string;
  unlockCondition: string;
  isUnlocked: (stats: { highScore: number; rushHighScore: number; totalLinesCleared: number; highestCombo: number; bombsDefused: number }) => boolean;
  progressText: (stats: { highScore: number; rushHighScore: number; totalLinesCleared: number; highestCombo: number; bombsDefused: number }) => string;
  progressPercent: (stats: { highScore: number; rushHighScore: number; totalLinesCleared: number; highestCombo: number; bombsDefused: number }) => number;
}

export const BLOCK_STYLES: Record<'crystalline' | 'neon' | 'metallic' | 'obsidian', BlockStyleConfig> = {
  crystalline: {
    id: 'crystalline',
    name: 'Crystalline Gem',
    subtitle: 'Faceted Diamond & Jewel Shards',
    description: 'Multi-faceted crystal refractions with diamond edge highlights and glistening specular sparkles.',
    unlockCondition: 'Unlocked by default',
    isUnlocked: () => true,
    progressText: () => 'Unlocked',
    progressPercent: () => 100,
  },
  neon: {
    id: 'neon',
    name: 'Electric Neon',
    subtitle: 'High-Voltage Plasma Bloom',
    description: 'Intense fluorescent neon aura with bright glowing filaments and electric light bleeding.',
    unlockCondition: 'Score 1,000 pts or blast 15 lines',
    isUnlocked: (stats) => stats.highScore >= 1000 || stats.totalLinesCleared >= 15,
    progressText: (stats) => {
      const maxPts = Math.min(1000, stats.highScore);
      return `${maxPts} / 1,000 pts (${stats.totalLinesCleared}/15 lines)`;
    },
    progressPercent: (stats) => {
      const p1 = Math.min(1, stats.highScore / 1000);
      const p2 = Math.min(1, stats.totalLinesCleared / 15);
      return Math.round(Math.max(p1, p2) * 100);
    },
  },
  metallic: {
    id: 'metallic',
    name: 'Chrome Metallic',
    subtitle: 'Brushed Cyber Alloy',
    description: 'Polished chrome and brushed titanium bevels with high-contrast metallic gleam and industrial chamfered edges.',
    unlockCondition: 'Score 2,500 pts in any mode',
    isUnlocked: (stats) => stats.highScore >= 2500 || stats.rushHighScore >= 2000,
    progressText: (stats) => `${Math.min(2500, stats.highScore)} / 2,500 pts`,
    progressPercent: (stats) => Math.min(100, Math.round((stats.highScore / 2500) * 100)),
  },
  obsidian: {
    id: 'obsidian',
    name: 'Cosmic Obsidian',
    subtitle: 'Starlight Dark Glass',
    description: 'Smoky obsidian glass infused with glittering stardust flecks and holographic iridescent rims.',
    unlockCondition: 'Reach a 4x Combo streak or defuse 3 bombs',
    isUnlocked: (stats) => stats.highestCombo >= 4 || stats.bombsDefused >= 3,
    progressText: (stats) => `Combo x${stats.highestCombo}/x4 · ${stats.bombsDefused}/3 Bombs`,
    progressPercent: (stats) => {
      const p1 = Math.min(1, stats.highestCombo / 4);
      const p2 = Math.min(1, stats.bombsDefused / 3);
      return Math.round(Math.max(p1, p2) * 100);
    },
  },
};
