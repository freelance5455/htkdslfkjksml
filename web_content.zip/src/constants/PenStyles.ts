export interface PenTypeConfig {
  id: "pencil" | "fountain" | "ballpoint" | "highlighter" | "brush" | "eraser" | "lasso";
  name: string;
  subtitle: string;
  defaultWidth: number; // in mm or px
  minWidth: number;
  maxWidth: number;
  defaultOpacity: number;
  textureType: "hexagonal_wood" | "chrome_lacquer" | "matte_plastic" | "frosted_glass" | "calligraphy_grip" | "rubber_eraser" | "lasso_tool";
  accentColorHex: string;
  gradientBg: string;
  shadowColor: string;
}

export const PEN_TYPES: PenTypeConfig[] = [
  {
    id: "pencil",
    name: "Kurşun Kalem (Pencil 2B)",
    subtitle: "Altıgen Ahşap Gövde & Grafit Uç",
    defaultWidth: 1.5,
    minWidth: 0.3,
    maxWidth: 4.0,
    defaultOpacity: 0.85,
    textureType: "hexagonal_wood",
    accentColorHex: "#D97706",
    gradientBg: "linear-gradient(135deg, #F59E0B 0%, #D97706 50%, #B45309 100%)",
    shadowColor: "rgba(217, 119, 6, 0.35)",
  },
  {
    id: "fountain",
    name: "Dolma Kalem (Fountain Pen)",
    subtitle: "Koyu Krom & İki Renkli Çelik Uç",
    defaultWidth: 2.0,
    minWidth: 0.5,
    maxWidth: 6.0,
    defaultOpacity: 1.0,
    textureType: "chrome_lacquer",
    accentColorHex: "#1E293B",
    gradientBg: "linear-gradient(135deg, #334155 0%, #0F172A 60%, #020617 100%)",
    shadowColor: "rgba(15, 23, 42, 0.4)",
  },
  {
    id: "ballpoint",
    name: "Jel / Tükenmez Kalem",
    subtitle: "Mat Plastik & Mürekkep Penceresi",
    defaultWidth: 1.0,
    minWidth: 0.2,
    maxWidth: 3.0,
    defaultOpacity: 0.95,
    textureType: "matte_plastic",
    accentColorHex: "#2563EB",
    gradientBg: "linear-gradient(135deg, #3B82F6 0%, #1D4ED8 60%, #1E40AF 100%)",
    shadowColor: "rgba(37, 99, 235, 0.35)",
  },
  {
    id: "highlighter",
    name: "Fosforlu Kalem (Highlighter)",
    subtitle: "Yarı Saydam Keçe Kesik Uç",
    defaultWidth: 8.0,
    minWidth: 4.0,
    maxWidth: 20.0,
    defaultOpacity: 0.4,
    textureType: "frosted_glass",
    accentColorHex: "#10B981",
    gradientBg: "linear-gradient(135deg, rgba(16, 185, 129, 0.8) 0%, rgba(5, 150, 105, 0.9) 100%)",
    shadowColor: "rgba(16, 185, 129, 0.3)",
  },
  {
    id: "brush",
    name: "Fırça Kalem (Calligraphy Brush)",
    subtitle: "Esnek Kıl Fırça & Kaligrafi Tutamaç",
    defaultWidth: 3.5,
    minWidth: 0.8,
    maxWidth: 12.0,
    defaultOpacity: 0.9,
    textureType: "calligraphy_grip",
    accentColorHex: "#8B5CF6",
    gradientBg: "linear-gradient(135deg, #A855F7 0%, #7E22CE 60%, #581C87 100%)",
    shadowColor: "rgba(139, 92, 246, 0.35)",
  },
  {
    id: "eraser",
    name: "Hassas Silgi (Mono Eraser)",
    subtitle: "Sentetik Kauçuk & Çizim Temizleme",
    defaultWidth: 12.0,
    minWidth: 2.0,
    maxWidth: 30.0,
    defaultOpacity: 1.0,
    textureType: "rubber_eraser",
    accentColorHex: "#EC4899",
    gradientBg: "linear-gradient(135deg, #F472B6 0%, #DB2777 100%)",
    shadowColor: "rgba(236, 72, 153, 0.3)",
  },
  {
    id: "lasso",
    name: "Kement Seçici (Lasso Tool)",
    subtitle: "Vektörel Seçim & Taşıma",
    defaultWidth: 1.0,
    minWidth: 1.0,
    maxWidth: 1.0,
    defaultOpacity: 1.0,
    textureType: "lasso_tool",
    accentColorHex: "#0EA5E9",
    gradientBg: "linear-gradient(135deg, #38BDF8 0%, #0284C7 100%)",
    shadowColor: "rgba(14, 165, 233, 0.3)",
  },
];

export interface InkColorSwatch {
  hex: string;
  name: string;
  category: "archival" | "vibrant" | "pastel" | "metallic";
}

export const PALETTE_INK_COLORS: InkColorSwatch[] = [
  { hex: "#0F172A", name: "Siyah Kadife", category: "archival" },
  { hex: "#1E3A8A", name: "Kraliyet Safir Mavi", category: "archival" },
  { hex: "#065F46", name: "Zümrüt Orman Yeşili", category: "archival" },
  { hex: "#991B1B", name: "Yakut Kırmızı", category: "archival" },
  { hex: "#9A3412", name: "Sıcak Kehribar", category: "archival" },
  { hex: "#581C87", name: "Ametist Moru", category: "archival" },
  { hex: "#2563EB", name: "Jel Mavi", category: "vibrant" },
  { hex: "#10B981", name: "Fosforlu Yeşil", category: "vibrant" },
  { hex: "#F59E0B", name: "Güneş Sarı", category: "vibrant" },
  { hex: "#EF4444", name: "Mercan Kırmızı", category: "vibrant" },
  { hex: "#EC4899", name: "Pembe Kuvars", category: "pastel" },
  { hex: "#8B5CF6", name: "Lavanta Lila", category: "pastel" },
  { hex: "#06B6D4", name: "Turkuaz Deniz", category: "vibrant" },
  { hex: "#64748B", name: "Grafit Kurşun Gri", category: "archival" },
  { hex: "#FFFFFF", name: "Opak Beyaz", category: "metallic" },
];

export const STROKE_WIDTH_PRESETS = [
  { label: "0.5mm", val: 0.5 },
  { label: "1.0mm", val: 1.0 },
  { label: "2.0mm", val: 2.0 },
  { label: "3.5mm", val: 3.5 },
  { label: "5.0mm", val: 5.0 },
  { label: "10mm", val: 10.0 },
];

/**
 * Trigger mechanical haptic click feedback
 */
export function triggerPenHapticFeedback(type: "light" | "medium" | "heavy" = "light"): void {
  if (typeof window !== "undefined" && "navigator" in window && "vibrate" in navigator) {
    try {
      if (type === "light") navigator.vibrate(8);
      else if (type === "medium") navigator.vibrate([10, 15, 10]);
      else navigator.vibrate([15, 20, 25]);
    } catch (e) {
      // Audio fallback or ignored
    }
  }
}
