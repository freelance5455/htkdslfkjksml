export interface ReactionItem {
  id: string;
  emoji: string;
  label: string;
}

export const BOOK_REACTIONS: ReactionItem[] = [
  { id: 'love', emoji: '❤️', label: 'Me encantó' },
  { id: 'laugh', emoji: '😂', label: 'Me hizo reír' },
  { id: 'cry', emoji: '😭', label: 'Me hizo llorar' },
  { id: 'moved', emoji: '🥹', label: 'Me conmovió' },
  { id: 'fascinated', emoji: '😍', label: 'Me fascinó' },
  { id: 'adorable', emoji: '🥰', label: 'Me pareció adorable' },
  { id: 'shocked', emoji: '😱', label: 'Me impactó' },
  { id: 'surprised', emoji: '😮', label: 'Me sorprendió' },
  { id: 'mindblown', emoji: '🤯', label: 'Me dejó en shock' },
  { id: 'sad', emoji: '😢', label: 'Me puso triste' },
  { id: 'angry', emoji: '😡', label: 'Me enojó' },
  { id: 'enraged', emoji: '🤬', label: 'Me enfureció' },
  { id: 'thoughtful', emoji: '🤔', label: 'Me hizo pensar' },
  { id: 'bored', emoji: '🥱', label: 'Me aburrió' },
  { id: 'uncomfortable', emoji: '😬', label: 'Me incomodó' },
  { id: 'disagree', emoji: '🤨', label: 'No estoy de acuerdo' },
  { id: 'unexpected', emoji: '🫢', label: 'No me lo esperaba' },
  { id: 'cringe', emoji: '🫣', label: 'Me dio vergüenza ajena' },
  { id: 'chills', emoji: '🥶', label: 'Me dio escalofríos' },
  { id: 'destroyed', emoji: '😭😂', label: 'Me destruyó' },
  { id: 'fire', emoji: '🔥', label: 'Fue increíble' },
  { id: 'dead', emoji: '💀', label: 'Me mató' },
  { id: 'eyes', emoji: '👀', label: 'Me llamó la atención' },
  { id: 'cherish', emoji: '🫶', label: 'Lo guardo para siempre' },
  { id: 'star', emoji: '⭐', label: 'Importante' },
  { id: 'idea', emoji: '💡', label: 'Buena idea' },
];

export const HIGHLIGHT_COLORS = [
  { id: 'blue', hex: '#3b82f6', label: 'Azul' },
  { id: 'green', hex: '#22c55e', label: 'Verde' },
  { id: 'purple', hex: '#a855f7', label: 'Morado' },
  { id: 'yellow', hex: '#eab308', label: 'Amarillo' },
  { id: 'pink', hex: '#ec4899', label: 'Rosa' },
  { id: 'wine', hex: '#881337', label: 'Rojo vino' },
];

export const LED_PRESET_COLORS = [
  { id: 'warm_amber', hex: '#ffb74d', label: 'Luz Cálida Ámbar' },
  { id: 'warm_gold', hex: '#facc15', label: 'Luz Cálida Dorada' },
  { id: 'candle', hex: '#ffa726', label: 'Luz de Vela' },
  { id: 'warm_white', hex: '#fef3c7', label: 'Blanco Cálido' },
  { id: 'cyan', hex: '#00e5ff', label: 'Cian Neón' },
  { id: 'violet', hex: '#a855f7', label: 'Violeta Sutil' },
  { id: 'emerald', hex: '#10b981', label: 'Verde Suave' },
  { id: 'white', hex: '#e2e8f0', label: 'Blanco Lunar' },
];
