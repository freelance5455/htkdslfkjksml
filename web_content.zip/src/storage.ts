export type PocketwiseSnapshot = {
  txs: unknown[];
  loans: unknown[];
  auditHistory: unknown[];
  coachGoals: { monthlySavingsGoal: number; weeklySpendLimit: number };
  coachTasks: unknown[];
  customCategories?: string[];
};

const DB_NAME = 'pocketwise-local';
const STORE_NAME = 'snapshots';
const SNAPSHOT_KEY = 'main';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not available on this device.'));
      return;
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) {
        request.result.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open the on-device database.'));
  });
}

function readLegacy<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch {
    return fallback;
  }
}

export async function loadPocketwiseSnapshot(fallback: PocketwiseSnapshot): Promise<PocketwiseSnapshot> {
  const db = await openDatabase();
  try {
    const saved = await new Promise<PocketwiseSnapshot | undefined>((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(SNAPSHOT_KEY);
      request.onsuccess = () => resolve(request.result as PocketwiseSnapshot | undefined);
      request.onerror = () => reject(request.error || new Error('Could not read the on-device database.'));
    });
    if (saved && Array.isArray(saved.txs) && Array.isArray(saved.loans)) {
      return {
        txs: saved.txs,
        loans: saved.loans,
        auditHistory: Array.isArray(saved.auditHistory) ? saved.auditHistory : [],
        coachGoals: saved.coachGoals || fallback.coachGoals,
        coachTasks: Array.isArray(saved.coachTasks) ? saved.coachTasks : [],
        customCategories: Array.isArray(saved.customCategories) ? saved.customCategories : []
      };
    }

    // First-run migration: use the existing browser records where present.
    // The legacy keys are left in place as a recovery copy.
    const migrated: PocketwiseSnapshot = {
      txs: readLegacy<unknown[]>('pocketwise-txs', fallback.txs),
      loans: readLegacy<unknown[]>('pocketwise-loans', fallback.loans),
      auditHistory: readLegacy<unknown[]>('pocketwise-audit-history', fallback.auditHistory),
      coachGoals: readLegacy('pocketwise-coach-goals', fallback.coachGoals),
      coachTasks: readLegacy<unknown[]>('pocketwise-coach-tasks', fallback.coachTasks),
      customCategories: readLegacy<string[]>('pocketwise-custom-categories', fallback.customCategories || [])
    };
    await writeSnapshot(db, migrated);
    return migrated;
  } finally {
    db.close();
  }
}

function writeSnapshot(db: IDBDatabase, snapshot: PocketwiseSnapshot): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    transaction.objectStore(STORE_NAME).put(snapshot, SNAPSHOT_KEY);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error('Could not save to the on-device database.'));
    transaction.onabort = () => reject(transaction.error || new Error('The on-device database save was cancelled.'));
  });
}

export async function savePocketwiseSnapshot(snapshot: PocketwiseSnapshot): Promise<void> {
  const db = await openDatabase();
  try {
    await writeSnapshot(db, snapshot);
  } finally {
    db.close();
  }
}
