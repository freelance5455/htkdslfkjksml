import { LevelResult, SkinId, TOTAL_LEVELS, TUBE_SKINS } from "./game";

const SAVE_KEY = "aqua-sort-progress-v1";

export interface AudioSettings {
  sound: boolean;
  water: boolean;
  ambient: boolean;
  volume: number;
}

export interface LevelRecord {
  stars: number;
  bestMoves: number;
  bestScore: number;
  bestTime: number;
}

export interface ScoreEntry extends LevelResult {
  date: string;
}

export interface Progress {
  unlocked: number;
  completed: Record<string, LevelRecord>;
  totalMoves: number;
  currentStreak: number;
  bestStreak: number;
  selectedSkin: SkinId;
  settings: AudioSettings;
  highScores: ScoreEntry[];
}

export const DEFAULT_SETTINGS: AudioSettings = {
  sound: true,
  water: true,
  ambient: true,
  volume: 0.7,
};

export const DEFAULT_PROGRESS: Progress = {
  unlocked: 1,
  completed: {},
  totalMoves: 0,
  currentStreak: 0,
  bestStreak: 0,
  selectedSkin: "classic",
  settings: DEFAULT_SETTINGS,
  highScores: [],
};

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { ...DEFAULT_PROGRESS, completed: {}, highScores: [], settings: { ...DEFAULT_SETTINGS } };
    const saved = JSON.parse(raw) as Partial<Progress>;
    const skin = TUBE_SKINS.some((item) => item.id === saved.selectedSkin) ? saved.selectedSkin! : "classic";
    return {
      ...DEFAULT_PROGRESS,
      ...saved,
      unlocked: Math.max(1, Math.min(TOTAL_LEVELS, Number(saved.unlocked) || 1)),
      completed: saved.completed && typeof saved.completed === "object" ? saved.completed : {},
      highScores: Array.isArray(saved.highScores) ? saved.highScores.slice(0, 10) : [],
      selectedSkin: skin,
      settings: {
        ...DEFAULT_SETTINGS,
        ...(saved.settings ?? {}),
        volume: Math.max(0, Math.min(1, Number(saved.settings?.volume ?? DEFAULT_SETTINGS.volume))),
      },
    };
  } catch {
    return { ...DEFAULT_PROGRESS, completed: {}, highScores: [], settings: { ...DEFAULT_SETTINGS } };
  }
}

export function saveProgress(progress: Progress): void {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(progress));
  } catch {
    // Private browsing or a full storage quota must never stop play.
  }
}

export function emptyProgress(): Progress {
  return { ...DEFAULT_PROGRESS, completed: {}, highScores: [], settings: { ...DEFAULT_SETTINGS } };
}

export function totalStars(progress: Progress): number {
  return Object.values(progress.completed).reduce((sum, record) => sum + (record.stars || 0), 0);
}

export function totalScore(progress: Progress): number {
  return Object.values(progress.completed).reduce((sum, record) => sum + (record.bestScore || 0), 0);
}
