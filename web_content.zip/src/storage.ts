import { GameStats, Achievement, DailyChallenge, PlayerProfile, GAME_THEMES, DailyStreakData, STREAK_REWARDS } from './types';

const STATS_KEY = 'color_rush_game_stats_v2';
const THEMES_KEY = 'color_rush_unlocked_themes_v2';
const SELECTED_THEME_KEY = 'color_rush_selected_theme_v2';
const ACHIEVEMENTS_KEY = 'color_rush_achievements_v2';
const DAILY_KEY = 'color_rush_daily_v2';
const PROFILE_KEY = 'color_rush_player_profile_v2';
const TUTORIAL_KEY = 'color_rush_tutorial_seen_v2';
const STREAK_KEY = 'color_rush_daily_streak_v2';

const defaultStats: GameStats = {
  highScore: 0,
  gamesPlayed: 0,
  maxCombo: 0,
  totalTaps: 0,
  goldenTaps: 0,
  coins: 0,
  feverCount: 0,
  bombsAvoided: 0,
};

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_game',
    title: 'First Step',
    description: 'Play your first game of Color Rush',
    icon: '🎮',
    rewardCoins: 15,
    unlocked: false,
    progress: 0,
    maxProgress: 1,
  },
  {
    id: 'score_50',
    title: 'Color Adept',
    description: 'Reach a score of 50 in a single game',
    icon: '🎯',
    rewardCoins: 25,
    unlocked: false,
    progress: 0,
    maxProgress: 50,
  },
  {
    id: 'score_100',
    title: 'Color Master',
    description: 'Reach a score of 100 in a single game',
    icon: '🏆',
    rewardCoins: 50,
    unlocked: false,
    progress: 0,
    maxProgress: 100,
  },
  {
    id: 'combo_10',
    title: 'In the Flow',
    description: 'Reach a 10x combo streak',
    icon: '⚡',
    rewardCoins: 20,
    unlocked: false,
    progress: 0,
    maxProgress: 10,
  },
  {
    id: 'combo_25',
    title: 'Unstoppable',
    description: 'Reach a 25x combo streak',
    icon: '🔥',
    rewardCoins: 40,
    unlocked: false,
    progress: 0,
    maxProgress: 25,
  },
  {
    id: 'fever_master',
    title: 'Fever Master',
    description: 'Activate Fever Mode 3 times',
    icon: '🌋',
    rewardCoins: 30,
    unlocked: false,
    progress: 0,
    maxProgress: 3,
  },
  {
    id: 'daily_complete',
    title: 'Daily Champion',
    description: 'Complete a Daily Challenge',
    icon: '📅',
    rewardCoins: 35,
    unlocked: false,
    progress: 0,
    maxProgress: 1,
  },
  {
    id: 'golden_touch',
    title: 'Midas Touch',
    description: 'Collect 10 Golden Bonus buttons',
    icon: '✨',
    rewardCoins: 30,
    unlocked: false,
    progress: 0,
    maxProgress: 10,
  },
  {
    id: 'theme_stylist',
    title: 'Theme Stylist',
    description: 'Unlock any 2 custom themes',
    icon: '🎨',
    rewardCoins: 45,
    unlocked: false,
    progress: 0,
    maxProgress: 2,
  },
  {
    id: 'streak_3',
    title: 'On a Roll',
    description: 'Reach a 3-day login streak',
    icon: '🔥',
    rewardCoins: 35,
    unlocked: false,
    progress: 0,
    maxProgress: 3,
  },
  {
    id: 'streak_7',
    title: 'Streak Legend',
    description: 'Complete a 7-day login streak',
    icon: '👑',
    rewardCoins: 100,
    unlocked: false,
    progress: 0,
    maxProgress: 7,
  },
];

export function loadGameStats(): GameStats {
  if (typeof window === 'undefined') return defaultStats;
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (!raw) return defaultStats;
    const parsed = JSON.parse(raw);
    return {
      highScore: Number(parsed.highScore) || 0,
      gamesPlayed: Number(parsed.gamesPlayed) || 0,
      maxCombo: Number(parsed.maxCombo) || 0,
      totalTaps: Number(parsed.totalTaps) || 0,
      goldenTaps: Number(parsed.goldenTaps) || 0,
      coins: Number(parsed.coins) || 0,
      feverCount: Number(parsed.feverCount) || 0,
      bombsAvoided: Number(parsed.bombsAvoided) || 0,
    };
  } catch {
    return defaultStats;
  }
}

export function saveGameStats(stats: GameStats): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch {
    // ignore
  }
}

export function addCoins(amount: number): number {
  const current = loadGameStats();
  const updated = { ...current, coins: Math.max(0, current.coins + amount) };
  saveGameStats(updated);
  return updated.coins;
}

// Themes
export function loadUnlockedThemes(): string[] {
  if (typeof window === 'undefined') return ['neon'];
  try {
    const raw = localStorage.getItem(THEMES_KEY);
    if (!raw) return ['neon'];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.includes('neon') ? parsed : ['neon', ...parsed];
  } catch {
    return ['neon'];
  }
}

export function saveUnlockedThemes(themes: string[]): void {
  try {
    localStorage.setItem(THEMES_KEY, JSON.stringify(themes));
  } catch {
    // ignore
  }
}

export function loadSelectedTheme(): string {
  if (typeof window === 'undefined') return 'neon';
  try {
    return localStorage.getItem(SELECTED_THEME_KEY) || 'neon';
  } catch {
    return 'neon';
  }
}

export function saveSelectedTheme(themeId: string): void {
  try {
    localStorage.setItem(SELECTED_THEME_KEY, themeId);
  } catch {
    // ignore
  }
}

// Achievements
export function loadAchievements(): Achievement[] {
  if (typeof window === 'undefined') return INITIAL_ACHIEVEMENTS;
  try {
    const raw = localStorage.getItem(ACHIEVEMENTS_KEY);
    if (!raw) return INITIAL_ACHIEVEMENTS;
    const parsed: Achievement[] = JSON.parse(raw);
    // Merge with any newly added achievements
    return INITIAL_ACHIEVEMENTS.map((initial) => {
      const found = parsed.find((p) => p.id === initial.id);
      return found ? { ...initial, ...found } : initial;
    });
  } catch {
    return INITIAL_ACHIEVEMENTS;
  }
}

export function saveAchievements(achievements: Achievement[]): void {
  try {
    localStorage.setItem(ACHIEVEMENTS_KEY, JSON.stringify(achievements));
  } catch {
    // ignore
  }
}

// Daily Challenge
export function getTodayDateStr(): string {
  const today = new Date();
  const y = today.getFullYear();
  const m = String(today.getMonth() + 1).padStart(2, '0');
  const d = String(today.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function loadDailyChallenge(): DailyChallenge {
  const todayStr = getTodayDateStr();
  const defaultChallenge: DailyChallenge = {
    id: `daily-${todayStr}`,
    dateStr: todayStr,
    title: 'Daily Rush Challenge',
    description: 'Score 50 points in a single run',
    type: 'score',
    target: 50,
    current: 0,
    rewardCoins: 35,
    completed: false,
    claimed: false,
  };

  if (typeof window === 'undefined') return defaultChallenge;

  try {
    const raw = localStorage.getItem(DAILY_KEY);
    if (!raw) return defaultChallenge;
    const parsed = JSON.parse(raw);
    if (parsed.dateStr === todayStr) {
      return parsed;
    }
    // New day: generate rotating challenge
    const dayOfMonth = new Date().getDate();
    if (dayOfMonth % 3 === 0) {
      defaultChallenge.title = 'Golden Rush Day';
      defaultChallenge.description = 'Collect 3 Golden Bonus buttons';
      defaultChallenge.type = 'golden_taps';
      defaultChallenge.target = 3;
      defaultChallenge.rewardCoins = 30;
    } else if (dayOfMonth % 3 === 1) {
      defaultChallenge.title = 'Combo Streak Challenge';
      defaultChallenge.description = 'Achieve a 15-tap combo streak';
      defaultChallenge.type = 'combo';
      defaultChallenge.target = 15;
      defaultChallenge.rewardCoins = 25;
    }
    saveDailyChallenge(defaultChallenge);
    return defaultChallenge;
  } catch {
    return defaultChallenge;
  }
}

export function saveDailyChallenge(daily: DailyChallenge): void {
  try {
    localStorage.setItem(DAILY_KEY, JSON.stringify(daily));
  } catch {
    // ignore
  }
}

// Player Profile
const defaultProfile: PlayerProfile = {
  name: 'Runner',
  avatar: '🦊',
  isGoogleUser: false,
};

export function loadPlayerProfile(): PlayerProfile {
  if (typeof window === 'undefined') return defaultProfile;
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return defaultProfile;
    return JSON.parse(raw);
  } catch {
    return defaultProfile;
  }
}

export function savePlayerProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch {
    // ignore
  }
}

// Tutorial flag
export function hasSeenTutorial(): boolean {
  if (typeof window === 'undefined') return true;
  try {
    return localStorage.getItem(TUTORIAL_KEY) === 'true';
  } catch {
    return true;
  }
}

export function markTutorialSeen(): void {
  try {
    localStorage.setItem(TUTORIAL_KEY, 'true');
  } catch {
    // ignore
  }
}

// Daily Streak Management
export const defaultDailyStreak: DailyStreakData = {
  currentStreak: 0,
  lastLoginDate: '',
  lastClaimedDate: '',
  totalDaysLogged: 0,
};

export function loadDailyStreak(): DailyStreakData {
  if (typeof window === 'undefined') return defaultDailyStreak;
  try {
    const raw = localStorage.getItem(STREAK_KEY);
    if (!raw) return defaultDailyStreak;
    const parsed = JSON.parse(raw);
    return {
      currentStreak: Number(parsed.currentStreak) || 0,
      lastLoginDate: parsed.lastLoginDate || '',
      lastClaimedDate: parsed.lastClaimedDate || '',
      totalDaysLogged: Number(parsed.totalDaysLogged) || 0,
    };
  } catch {
    return defaultDailyStreak;
  }
}

export function saveDailyStreak(data: DailyStreakData): void {
  try {
    localStorage.setItem(STREAK_KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

export function getDaysBetweenDates(d1Str: string, d2Str: string): number {
  if (!d1Str || !d2Str) return 999;
  const d1 = new Date(d1Str + 'T00:00:00');
  const d2 = new Date(d2Str + 'T00:00:00');
  const diffTime = Math.abs(d2.getTime() - d1.getTime());
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

export function checkDailyStreakStatus(): {
  data: DailyStreakData;
  canClaim: boolean;
  dayIndexToClaim: number; // 0 to 6
  isNewStreakDay: boolean;
} {
  const todayStr = getTodayDateStr();
  const current = loadDailyStreak();

  let streak = current.currentStreak;
  let totalDays = current.totalDaysLogged;
  let isNewStreakDay = false;

  if (!current.lastLoginDate) {
    // First time login ever
    streak = 1;
    totalDays = 1;
    isNewStreakDay = true;
  } else if (current.lastLoginDate !== todayStr) {
    const daysSinceLastLogin = getDaysBetweenDates(current.lastLoginDate, todayStr);
    if (daysSinceLastLogin === 1) {
      // Consecutive day login!
      streak = streak >= 7 ? 1 : streak + 1; // Cycle 1-7
      totalDays += 1;
      isNewStreakDay = true;
    } else if (daysSinceLastLogin > 1) {
      // Missed a day! Reset streak to Day 1
      streak = 1;
      totalDays += 1;
      isNewStreakDay = true;
    }
  }

  const updated: DailyStreakData = {
    ...current,
    currentStreak: Math.max(1, streak),
    lastLoginDate: todayStr,
    totalDaysLogged: Math.max(1, totalDays),
  };
  saveDailyStreak(updated);

  const canClaim = updated.lastClaimedDate !== todayStr;
  const dayIndexToClaim = Math.max(0, Math.min(6, updated.currentStreak - 1));

  return {
    data: updated,
    canClaim,
    dayIndexToClaim,
    isNewStreakDay,
  };
}

export function claimStreakReward(): {
  success: boolean;
  coinsEarned: number;
  streakDay: number;
  updatedData: DailyStreakData;
} {
  const status = checkDailyStreakStatus();
  if (!status.canClaim) {
    return {
      success: false,
      coinsEarned: 0,
      streakDay: status.data.currentStreak,
      updatedData: status.data,
    };
  }

  const todayStr = getTodayDateStr();
  const rewardItem = STREAK_REWARDS[status.dayIndexToClaim];
  const coinsEarned = rewardItem ? rewardItem.coins : 25;

  // Add coins
  addCoins(coinsEarned);

  const updated: DailyStreakData = {
    ...status.data,
    lastClaimedDate: todayStr,
  };
  saveDailyStreak(updated);

  return {
    success: true,
    coinsEarned,
    streakDay: status.data.currentStreak,
    updatedData: updated,
  };
}
