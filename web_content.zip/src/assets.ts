// ── Asset registry — Polvo Pintor ──
import bg_atelier from './assets/bg_atelier.jpg'
import bg_result from './assets/bg_result.jpg'
import spr_polvo from './assets/spr_polvo.png'
import spr_stain from './assets/spr_stain.png'
import bgm_theme from './assets/bgm_theme.mp3'
import sfx_paint from './assets/sfx_paint.mp3'
import sfx_stain from './assets/sfx_stain.mp3'
import sfx_combo from './assets/sfx_combo.mp3'
import sfx_gameover from './assets/sfx_gameover.mp3'

export const ASSETS: Record<string, string> = {
  bg_atelier,
  bg_result,
  spr_polvo,
  spr_stain,
  bgm_theme,
  sfx_paint,
  sfx_stain,
  sfx_combo,
  sfx_gameover,
}
