// ── Asset registry — you own and maintain this file ──
import bgFarmLake from './assets/bg_farm_lake.jpg'
import fisher from './assets/fisher.png'
import fishCommon from './assets/fish_common.png'
import fishRare from './assets/fish_rare.png'
import fishLegend from './assets/fish_legend.png'
import iconGold from './assets/icon_gold.png'
import iconBait from './assets/icon_bait.png'
import bgmTheme from './assets/bgm_theme.mp3'
import sfxCast from './assets/sfx_cast.mp3'
import sfxCatch from './assets/sfx_catch.mp3'
import sfxSell from './assets/sfx_sell.mp3'
import sfxMiss from './assets/sfx_miss.mp3'

export const ASSETS: Record<string, string> = {
  bg_farm_lake: bgFarmLake,
  fisher,
  fish_common: fishCommon,
  fish_rare: fishRare,
  fish_legend: fishLegend,
  icon_gold: iconGold,
  icon_bait: iconBait,
  bgm_theme: bgmTheme,
  sfx_cast: sfxCast,
  sfx_catch: sfxCatch,
  sfx_sell: sfxSell,
  sfx_miss: sfxMiss,
}
