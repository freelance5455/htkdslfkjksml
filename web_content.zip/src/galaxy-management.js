/** Read-only sporting overview for the 24 historical galaxies. */
export function getGalaxyManagementOverview(state) {
  const clubs = (state.divisions || []).flatMap(d => d.clubs || []);
  const galaxies = state.world?.galaxies || [];
  const rows = galaxies.map((galaxy, index) => {
    const representatives = galaxy.damistes || [];
    const levels = representatives.map(p => Number(p.level) || 0);
    const power = levels.length ? Math.round(levels.reduce((a, b) => a + b, 0) / levels.length) : 0;
    const clubRows = clubs.filter(c => c.galaxyId === galaxy.id || c.galaxy === galaxy.name);
    const clubPower = clubRows.flatMap(c => c.damistes || []).reduce((sum, p) => sum + (Number(p.level) || 0), 0);
    return { id: galaxy.id || `galaxy-${index + 1}`, name: galaxy.name || `Galaxie ${index + 1}`, representatives: representatives.length, representativePower: power, clubs: clubRows.length, clubPower, collectivePower: power + clubPower, competitionPoints: Number(galaxy.competitionPoints) || 0 };
  });
  rows.sort((a, b) => b.collectivePower - a.collectivePower || b.competitionPoints - a.competitionPoints || a.name.localeCompare(b.name, 'fr'));
  return rows.map((row, index) => ({ ...row, rank: index + 1 }));
}

export function validateGalaxyManagement(state) {
  const rows = getGalaxyManagementOverview(state);
  if (rows.length !== 24) throw new Error('Le championnat doit conserver exactement 24 galaxies');
  if (new Set(rows.map(x => x.id)).size !== 24) throw new Error('Identifiants de galaxies dupliqués');
  return true;
}
