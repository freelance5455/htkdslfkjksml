/* ==========================================================================
   storage.js — لایه ذخیره‌سازی محلی (localStorage) + کلیدهای مدیریت‌شده
   هیچ داده‌ای از دستگاه خارج نمی‌شود.
   ========================================================================== */

const NS = 'bp_v1_';

export const KEYS = {
  state: NS + 'state',
  logs: NS + 'logs',
  settings: NS + 'settings',
  snapshots: NS + 'snapshots',
  security: NS + 'security',
  meta: NS + 'meta',
};

export function readLS(key, fallback = null) {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}

export function writeLS(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    // حافظه پر است: سعی در آزادسازی لاگ‌ها
    try { localStorage.removeItem(KEYS.logs); localStorage.setItem(key, JSON.stringify(value)); return true; } catch (e2) { return false; }
  }
}

export function removeLS(key) {
  try { localStorage.removeItem(key); } catch (e) { void e; }
}

export function clearAll() {
  try {
    Object.keys(localStorage)
      .filter((k) => k.indexOf(NS) === 0)
      .forEach((k) => localStorage.removeItem(k));
  } catch (e) { void e; }
}

export function storageUsage() {
  let bytes = 0;
  try {
    Object.keys(localStorage).forEach((k) => {
      if (k.indexOf(NS) === 0) bytes += (localStorage.getItem(k) || '').length * 2;
    });
  } catch (e) { void e; }
  return bytes;
}
