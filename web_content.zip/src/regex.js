/**
 * Regex key API (D1).
 * Mounted at /<ACCESS>/regex/api/*  (and also /<ACCESS>/api/*).
 */

import { json, sha256Hex, randomToken, clientIp, sameText } from './security.js';

const SESSION_COOKIE = 'rm_session';
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const REMEMBER_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const KEY_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS regex_keys (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     key_hash TEXT NOT NULL UNIQUE,
     key_hint TEXT NOT NULL,
     label TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'active',
     created_at TEXT NOT NULL,
     expires_at TEXT,
     last_used_at TEXT,
     activation TEXT NOT NULL DEFAULT 'created',
     activated_at TEXT,
     duration_seconds INTEGER,
     lifetime_label TEXT NOT NULL DEFAULT 'Never expires')`,
  `CREATE TABLE IF NOT EXISTS sessions (
     token_hash TEXT PRIMARY KEY,
     expires_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS login_failures (
     ip TEXT PRIMARY KEY,
     count INTEGER NOT NULL,
     window_start INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS activity (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     at TEXT NOT NULL,
     action TEXT NOT NULL,
     detail TEXT NOT NULL DEFAULT '')`,
  `CREATE TABLE IF NOT EXISTS dominant_files (
     path TEXT PRIMARY KEY,
     content TEXT NOT NULL,
     updated_at TEXT NOT NULL,
     size INTEGER NOT NULL,
     sha256 TEXT)`,
  `CREATE TABLE IF NOT EXISTS dominant_meta (
     key TEXT PRIMARY KEY,
     value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS dominant_file_index (
     path TEXT PRIMARY KEY,
     b2_key TEXT NOT NULL,
     content_type TEXT NOT NULL DEFAULT 'application/octet-stream',
     updated_at TEXT NOT NULL,
     size INTEGER NOT NULL DEFAULT 0,
     sha256 TEXT,
     is_binary INTEGER NOT NULL DEFAULT 0)`,
  `CREATE INDEX IF NOT EXISTS idx_dominant_file_index_updated ON dominant_file_index(updated_at)`,
  `CREATE TABLE IF NOT EXISTS dominant_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL,
    history_key TEXT NOT NULL,
    content_type TEXT,
    size INTEGER,
    sha256 TEXT,
    is_binary INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    reason TEXT
  )`,
  `CREATE INDEX IF NOT EXISTS idx_dominant_versions_path ON dominant_versions(path)`,
  `CREATE TABLE IF NOT EXISTS load_tokens (
     token_hash TEXT PRIMARY KEY,
     key_hint TEXT NOT NULL,
     expires_at INTEGER NOT NULL,
     used INTEGER NOT NULL DEFAULT 0)`,
];

const schemaReady = new WeakMap();

export async function ensureRegexSchema(db) {
  if (!schemaReady.has(db)) {
    const p = (async () => {
      for (const sql of SCHEMA) {
        await db.prepare(sql).run();
      }
    })().catch((err) => {
      schemaReady.delete(db);
      throw err;
    });
    schemaReady.set(db, p);
  }
  return schemaReady.get(db);
}

function cookieGet(request, name) {
  for (const part of (request.headers.get('Cookie') || '').split(';')) {
    const i = part.indexOf('=');
    if (i !== -1 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return null;
}

function sessionCookie(value, maxAge, secure) {
  // Path=/ so cookie works for both /CODE/regex/api and /CODE/api
  const attrs = [
    `${SESSION_COOKIE}=${value}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.max(0, Math.floor(maxAge))}`,
  ];
  if (secure) attrs.push('Secure');
  return attrs.join('; ');
}

async function createSession(db, ttlMs = SESSION_TTL_MS) {
  const token = randomToken(32);
  const hash = await sha256Hex(token);
  await db
    .prepare('INSERT INTO sessions(token_hash, expires_at) VALUES(?, ?)')
    .bind(hash, Date.now() + ttlMs)
    .run();
  return token;
}

async function hasSession(db, token) {
  if (!token) return false;
  const hash = await sha256Hex(token);
  const row = await db.prepare('SELECT expires_at FROM sessions WHERE token_hash = ?').bind(hash).first();
  if (!row) return false;
  if (row.expires_at < Date.now()) {
    await db.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(hash).run();
    return false;
  }
  return true;
}

function generateKey() {
  let out = 'REGEX_';
  const buf = crypto.getRandomValues(new Uint8Array(10));
  for (const b of buf) out += KEY_ALPHABET[b % KEY_ALPHABET.length];
  return out;
}

async function record(db, action, detail = '') {
  await db
    .prepare('INSERT INTO activity(at, action, detail) VALUES(?, ?, ?)')
    .bind(new Date().toISOString(), action, detail)
    .run()
    .catch(() => {});
}

export async function isAdmin(request, env) {
  const token = cookieGet(request, SESSION_COOKIE);
  return hasSession(env.DB, token);
}

function adminPassword(env) {
  // No default password: when the secret is missing, login stays closed.
  const fromEnv = env.ADMIN_PASSWORD;
  return typeof fromEnv === 'string' && fromEnv.length > 0 ? fromEnv : null;
}

async function digestHex(text) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function parseKeyLifetime(body) {
  const source = body && body.lifetime && typeof body.lifetime === 'object' ? body.lifetime : null;
  if (!source || source.value === null || source.value === undefined) return { seconds: null, label: 'Never expires' };
  const value = Number(source.value);
  const unit = String(source.unit || 'days').toLowerCase();
  const factors = { minutes: 60, hours: 3600, days: 86400, weeks: 604800, months: 2592000, years: 31536000 };
  if (!Number.isSafeInteger(value) || value < 1 || !factors[unit]) throw new Error('Invalid key duration');
  const seconds = value * factors[unit];
  if (seconds < 60 || seconds > 10 * 31536000) throw new Error('Duration must be between 1 minute and 10 years');
  const unitName = unit.slice(0, -1);
  return { seconds, label: `${value} ${unitName}${value === 1 ? '' : 's'}` };
}

function keyDto(row) {
  return {
    id: row.id,
    hint: row.key_hint || '',
    label: row.label || '',
    status: row.status === 'active' && row.expires_at && Date.parse(row.expires_at) < Date.now() ? 'expired' : (row.status || 'active'),
    createdAt: row.created_at,
    expiresAt: row.expires_at || null,
    lastUsedAt: row.last_used_at || null,
    lifetime: row.lifetime_label || 'Never expires',
    activation: row.activation || 'created',
    activatedAt: row.activated_at || null,
    durationSeconds: row.duration_seconds ?? null,
  };
}

export async function handleRegex(request, env) {
  await ensureRegexSchema(env.DB);

  const url = new URL(request.url);
  const parts = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const action = parts[0] || '';
  const secure = url.protocol === 'https:';

  // Health (UI checks this on boot)
  if (action === 'health' && request.method === 'GET') {
    return json({ ok: true, version: '2.0.0', d1: true });
  }

  // Session probe
  if (action === 'session' && request.method === 'GET') {
    const admin = await isAdmin(request, env);
    return json({ authenticated: admin, admin });
  }

  if (action === 'login' && request.method === 'POST') {
    let body = {};
    try {
      body = await request.json();
    } catch {
      body = {};
    }
    const password = String(body.password ?? '');
    const remember = Boolean(body.remember);
    const expected = adminPassword(env);
    if (expected === null) {
      return json({ error: 'ADMIN_PASSWORD secret is not set' }, 503);
    }

    // Compare digests: both are 64 hex characters, so the password length never leaks.
    const ok = sameText(await digestHex(password), await digestHex(expected));

    if (!ok) {
      await record(env.DB, 'login.failed', clientIp(request));
      return json({ error: 'invalid password' }, 401);
    }

    const ttl = remember ? REMEMBER_TTL_MS : SESSION_TTL_MS;
    let token;
    try {
      token = await createSession(env.DB, ttl);
    } catch (e) {
      return json({
        error: 'session table failed — run sql/schema.sql on D1',
        detail: String(e?.message || e),
      }, 500);
    }

    await record(env.DB, 'login.succeeded', clientIp(request));
    return json(
      { ok: true },
      200,
      { 'Set-Cookie': sessionCookie(token, ttl / 1000, secure) }
    );
  }

  if (action === 'logout' && request.method === 'POST') {
    const token = cookieGet(request, SESSION_COOKIE);
    if (token) {
      const hash = await sha256Hex(token);
      await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(hash).run();
    }
    return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0, secure) });
  }

  if (action === 'logout-all' && request.method === 'POST') {
    const admin = await isAdmin(request, env);
    if (!admin) return json({ error: 'unauthorized' }, 401);
    await env.DB.prepare('DELETE FROM sessions').run();
    return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0, secure) });
  }

  if (action === 'me' && request.method === 'GET') {
    return json({ admin: await isAdmin(request, env) });
  }

  // Public validate
  if (action === 'validate' && (request.method === 'POST' || request.method === 'GET')) {
    let key = url.searchParams.get('key') || '';
    if (request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      key = String(body.key || key);
    }
    const hash = await sha256Hex(key);
    const row = await env.DB
      .prepare('SELECT id, status, expires_at, activation, activated_at, duration_seconds FROM regex_keys WHERE key_hash = ?')
      .bind(hash)
      .first();
    if (!row || !['active', 'unused'].includes(row.status)) return json({ valid: false });
    // Start first-use duration atomically on the first successful validation.
    if (row.activation === 'first_use' && !row.activated_at) {
      const now = new Date();
      const expiresAt = row.duration_seconds ? new Date(now.getTime() + row.duration_seconds * 1000).toISOString() : null;
      await env.DB.prepare(`UPDATE regex_keys SET activated_at = ?, expires_at = ?, status = 'active', last_used_at = ? WHERE id = ? AND activated_at IS NULL`)
        .bind(now.toISOString(), expiresAt, now.toISOString(), row.id).run();
      const refreshed = await env.DB.prepare('SELECT expires_at, status FROM regex_keys WHERE id = ?').bind(row.id).first();
      if (!refreshed || refreshed.status !== 'active' || (refreshed.expires_at && Date.parse(refreshed.expires_at) < Date.now())) return json({ valid: false });
      return json({ valid: true });
    }
    if (row.expires_at && Date.parse(row.expires_at) < Date.now()) {
      await env.DB.prepare(`UPDATE regex_keys SET status = 'expired' WHERE id = ? AND status = 'active'`).bind(row.id).run();
      return json({ valid: false });
    }
    await env.DB.prepare('UPDATE regex_keys SET last_used_at = ? WHERE id = ?').bind(new Date().toISOString(), row.id).run();
    return json({ valid: true });
  }

  // Dashboard stub for UI
  if (action === 'dashboard' && request.method === 'GET') {
    const admin = await isAdmin(request, env);
    if (!admin) return json({ error: 'unauthorized' }, 401);
    const keys = await env.DB.prepare(`SELECT COUNT(*) AS n FROM regex_keys`).first();
    const active = await env.DB.prepare(`SELECT COUNT(*) AS n FROM regex_keys WHERE status = 'active'`).first();
    return json({
      keys: keys?.n || 0,
      active: active?.n || 0,
      version: '2.0.0',
    });
  }

  if (action === 'settings' && request.method === 'GET') {
    const admin = await isAdmin(request, env);
    if (!admin) return json({ error: 'unauthorized' }, 401);
    return json({
      items: [
        { id: 'auth', label: 'Admin password', message: 'Set with wrangler secret put ADMIN_PASSWORD' },
        { id: 'database', label: 'Database (D1)', message: 'shqmeqgh2vu7 — keys, sessions, Dominant source' },
        { id: 'info', label: 'Admin secret', message: env.ADMIN_PASSWORD ? 'ADMIN_PASSWORD is set' : 'Not set: login is disabled until you run wrangler secret put ADMIN_PASSWORD' },
      ],
    });
  }

  if (action === 'activity' && request.method === 'GET') {
    const admin = await isAdmin(request, env);
    if (!admin) return json({ error: 'unauthorized' }, 401);
    const { results } = await env.DB
      .prepare('SELECT at, action, detail FROM activity ORDER BY id DESC LIMIT 50')
      .all();
    return json({ activity: results || [] });
  }

  if (action === 'sessions' && request.method === 'GET') {
    const admin = await isAdmin(request, env);
    if (!admin) return json({ error: 'unauthorized' }, 401);
    const { results } = await env.DB.prepare('SELECT expires_at FROM sessions').all();
    return json({ sessions: (results || []).map((r) => ({ expires_at: r.expires_at })) });
  }

  const admin = await isAdmin(request, env);
  if (!admin) return json({ error: 'unauthorized' }, 401);

  if (action === 'keys' && request.method === 'GET' && !parts[1]) {
    const { results } = await env.DB.prepare(
      `SELECT id, key_hint, label, status, created_at, expires_at, last_used_at,
              lifetime_label, activation, activated_at, duration_seconds
       FROM regex_keys ORDER BY id DESC LIMIT 500`
    ).all();
    return json({ keys: (results || []).map(keyDto) });
  }

  if (action === 'keys' && request.method === 'POST' && !parts[1]) {
    const body = await request.json().catch(() => ({}));
    const count = Math.min(25, Math.max(1, Number(body.count) || 1));
    const label = String(body.label || '').trim().slice(0, 80);
    let lifetime;
    try { lifetime = parseKeyLifetime(body); }
    catch (error) { return json({ error: error.message || 'Invalid duration' }, 400); }
    const activation = body.activation === 'first_use' && lifetime.seconds ? 'first_use' : 'created';
    const created = [];
    for (let i = 0; i < count; i++) {
      const key = generateKey();
      const hash = await sha256Hex(key);
      const hint = key.slice(0, 8) + '…';
      const now = new Date();
      const expiresAt = activation === 'created' && lifetime.seconds
        ? new Date(now.getTime() + lifetime.seconds * 1000).toISOString() : null;
      await env.DB.prepare(
        `INSERT INTO regex_keys(key_hash, key_hint, label, status, created_at, expires_at, activation, duration_seconds, lifetime_label)
         VALUES(?, ?, ?, 'active', ?, ?, ?, ?, ?)`
      ).bind(hash, hint, label, now.toISOString(), expiresAt, activation, lifetime.seconds, lifetime.label).run();
      created.push(key);
    }
    await record(env.DB, 'key.created', `n=${count}; label=${label || 'none'}; lifetime=${lifetime.label}`);
    return json({ ok: true, keys: created, count, label, lifetime: lifetime.label, activation });
  }

  // Bulk operations use the exact IDs selected in the UI; they never create keys.
  if (action === 'keys' && parts[1] === 'bulk' && request.method === 'POST') {
    const body = await request.json().catch(() => ({}));
    const actionName = String(body.action || '');
    const ids = [...new Set((Array.isArray(body.ids) ? body.ids : []).map(Number).filter(id => Number.isSafeInteger(id) && id > 0))];
    if (!['revoke', 'restore', 'delete'].includes(actionName)) return json({ error: 'Unsupported bulk action' }, 400);
    if (!ids.length) return json({ error: 'Select at least one key' }, 400);
    let done = 0;
    for (const id of ids) {
      let result;
      if (actionName === 'revoke') result = await env.DB.prepare("UPDATE regex_keys SET status = 'revoked' WHERE id = ? AND status IN ('active','unused')").bind(id).run();
      else if (actionName === 'restore') result = await env.DB.prepare("UPDATE regex_keys SET status = 'active' WHERE id = ? AND status = 'revoked'").bind(id).run();
      else result = await env.DB.prepare('DELETE FROM regex_keys WHERE id = ?').bind(id).run();
      done += result.meta?.changes || 0;
    }
    await record(env.DB, `key.bulk_${actionName}`, `requested=${ids.length}; changed=${done}`);
    return json({ ok: true, done, skipped: ids.length - done });
  }

  // /api/keys/:id/revoke|restore|delete|rename|time
  if (action === 'keys' && parts[1] && parts[1] !== 'purge') {
    const id = Number(parts[1]);
    const sub = parts[2] || '';
    if (!Number.isSafeInteger(id) || id < 1) return json({ error: 'Invalid key ID' }, 400);
    if (sub === 'revoke' && request.method === 'POST') {
      const result = await env.DB.prepare("UPDATE regex_keys SET status = 'revoked' WHERE id = ? AND status IN ('active','unused')").bind(id).run();
      if (!(result.meta?.changes > 0)) return json({ error: 'Key not found or already revoked' }, 409);
      await record(env.DB, 'key.revoked', `id=${id}`);
      return json({ ok: true, id, status: 'revoked' });
    }
    if (sub === 'restore' && request.method === 'POST') {
      const result = await env.DB.prepare("UPDATE regex_keys SET status = 'active' WHERE id = ? AND status = 'revoked'").bind(id).run();
      if (!(result.meta?.changes > 0)) return json({ error: 'Key not found or not revoked' }, 409);
      await record(env.DB, 'key.restored', `id=${id}`);
      return json({ ok: true, id, status: 'active' });
    }
    if ((sub === 'delete' || request.method === 'DELETE') && (request.method === 'POST' || request.method === 'DELETE')) {
      const result = await env.DB.prepare('DELETE FROM regex_keys WHERE id = ?').bind(id).run();
      if (!(result.meta?.changes > 0)) return json({ error: 'Key not found' }, 404);
      await record(env.DB, 'key.deleted', `id=${id}`);
      return json({ ok: true, id, deleted: true });
    }
    if (sub === 'rename' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const result = await env.DB.prepare('UPDATE regex_keys SET label = ? WHERE id = ?').bind(String(body.label || '').trim().slice(0, 80), id).run();
      if (!(result.meta?.changes > 0)) return json({ error: 'Key not found' }, 404);
      await record(env.DB, 'key.renamed', `id=${id}`);
      return json({ ok: true, id });
    }
    if (sub === 'time' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      let lifetime;
      try { lifetime = parseKeyLifetime(body); }
      catch (error) { return json({ error: error.message || 'Invalid duration' }, 400); }
      const row = await env.DB.prepare('SELECT activation, activated_at FROM regex_keys WHERE id = ?').bind(id).first();
      if (!row) return json({ error: 'Key not found' }, 404);
      let expiresAt = null;
      if (lifetime.seconds) {
        const base = row.activation === 'first_use' && !row.activated_at ? null : Date.now();
        expiresAt = base === null ? null : new Date(base + lifetime.seconds * 1000).toISOString();
      }
      const result = await env.DB.prepare('UPDATE regex_keys SET duration_seconds = ?, lifetime_label = ?, expires_at = ? WHERE id = ?')
        .bind(lifetime.seconds, lifetime.label, expiresAt, id).run();
      if (!(result.meta?.changes > 0)) return json({ error: 'Key was not updated' }, 500);
      await record(env.DB, 'key.duration_updated', `id=${id}; lifetime=${lifetime.label}`);
      return json({ ok: true, id, lifetime: lifetime.label, expiresAt });
    }
  }

  if (action === 'keys' && parts[1] === 'purge' && request.method === 'POST') {
    const r = await env.DB.prepare("DELETE FROM regex_keys WHERE status IN ('revoked','expired')").run();
    await record(env.DB, 'key.purged', `n=${r.meta?.changes || 0}`);
    return json({ ok: true, deleted: r.meta?.changes || 0 });
  }

  return json({ error: 'not found', action }, 404);
}
