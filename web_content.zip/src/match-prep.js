// Étape 6.9 — Préparation du match (écran 09, disposition FM27).
// Aucun changement des règles : l'écran choisit seulement le damiste titulaire affiché pendant la rencontre.
import { tacticsSummary } from './tactics.js';
import { getFixtureDamiste } from './dame-or.js';
const COMPETITIONS = { 'coupe-lunaire': 'Coupe lunaire', intergalactique: 'Coupe intergalactique' };
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const formLabel = value => (value >= 75 ? 'Haute' : value >= 60 ? 'Moyenne' : 'Basse');
const average = (list, key) => (list.length ? Math.round(list.reduce((sum, item) => sum + Number(item[key] || 0), 0) / list.length) : null);

export function buildMatchPrep(state, fixture) {
  const clubs = new Map((state?.divisions || []).flatMap(division => (division.clubs || []).map(club => [club.id, club])));
  const nameOf = id => clubs.get(id)?.name || String(id);
  const own = clubs.get(state?.userClubId);
  const opponentId = fixture.home === state?.userClubId ? fixture.away : fixture.home;
  const opponent = clubs.get(opponentId);
  const squad = [...(own?.damistes || [])].sort((a, b) => (b.level || 0) - (a.level || 0));
  const rivals = opponent?.damistes || [];
  const side = fixture.home === state?.userClubId ? 'home' : 'away';
  let current = null;
  try { current = own ? getFixtureDamiste(own, fixture, side) : null; } catch { current = null; }
  return {
    side,
    fixture,
    competition: COMPETITIONS[fixture.competitionId] || 'Championnat',
    title: `${nameOf(fixture.home)} — ${nameOf(fixture.away)}`,
    ownName: own?.name || 'Ton club',
    opponentName: opponent?.name || nameOf(opponentId),
    opponentLevel: average(rivals, 'level'),
    opponentForm: average(rivals, 'form'),
    tactics: tacticsSummary(state),
    squad,
    starterId: current?.id || squad[0]?.id || null
  };
}

export function renderMatchPrep(host, prep, { onLaunch, onCancel, onSimulate }) {
  let starterId = prep.starterId;
  const paint = () => {
    const starter = prep.squad.find(player => player.id === starterId);
    const rows = prep.squad.length
      ? prep.squad.map(player => `<button type="button" class="fm-pl${player.id === starterId ? ' on' : ''}" data-player="${esc(player.id)}" aria-pressed="${player.id === starterId}"><span>${esc(player.name)}</span><small>niv. ${esc(player.level)} · forme ${formLabel(player.form)}</small><b>${player.id === starterId ? 'Titulaire' : 'Remplaçant'}</b></button>`).join('')
      : '<p class="fm-empty">Aucun damiste disponible pour ce club.</p>';
    host.innerHTML = `<div class="fm-prep-in"><header><b>PRÉPARATION DU MATCH</b><small>${esc(prep.competition)} · ${esc(prep.title)}</small></header>
<div class="fm-prep-cols"><section class="fm-pn"><h3>${esc(prep.opponentName)}</h3><small>Adversaire</small>
<div class="fm-lab">Niveau moyen</div><div class="fm-box"><b>${prep.opponentLevel ?? '—'}</b></div>
<div class="fm-lab">Forme</div><div class="fm-box"><b>${prep.opponentForm == null ? '—' : formLabel(prep.opponentForm)}</b></div>
<div class="fm-lab">Tactique</div><div class="fm-box"><b>${esc(prep.tactics)}</b></div></section>
<section class="fm-pn"><h3>Damistes de ${esc(prep.ownName)}</h3><small>Touche un damiste pour le choisir comme titulaire</small><div class="fm-pl-list">${rows}</div></section></div>
<footer class="fm-bt"><button type="button" data-prep="cancel">‹ Retour</button><button type="button" data-prep="simulate">⏩ Simuler</button><button type="button" class="fm-go" data-prep="launch"${starter || !prep.squad.length ? '' : ' disabled'}>Lancer le match ▶</button></footer></div>`;
    host.querySelectorAll('[data-player]').forEach(button => button.addEventListener('click', () => { starterId = button.dataset.player; paint(); }));
    host.querySelector('[data-prep="cancel"]').addEventListener('click', () => { host.hidden = true; onCancel?.(); });
    host.querySelector('[data-prep="simulate"]').addEventListener('click', () => { host.hidden = true; onSimulate?.({ starter: prep.squad.find(player => player.id === starterId) || null, prep }); });
    host.querySelector('[data-prep="launch"]').addEventListener('click', () => { host.hidden = true; onLaunch?.({ starter: prep.squad.find(player => player.id === starterId) || null, prep }); });
  };
  paint();
  host.hidden = false;
}
