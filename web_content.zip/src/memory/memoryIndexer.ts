/**
 * GODEX Phase 7 - Multi-Dimensional Memory Indexer
 * Indexes engineering memories across files, symbols, error codes,
 * commit lineages, tasks, layers, and temporal ranges.
 */

import { EngineeringMemoryEntry, MemoryQueryFilter } from './memoryTypes';
import { MemoryStore } from './memoryStore';

export class MemoryIndexer {
  /**
   * Matches candidate memory entries based on structured query filters.
   */
  public static filterEntries(filter: MemoryQueryFilter, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    let candidates = store.getAllEntries();

    // 1. Filter by Types
    if (filter.types && filter.types.length > 0) {
      const typeSet = new Set(filter.types);
      candidates = candidates.filter(e => typeSet.has(e.type));
    }

    // 2. Filter by Statuses
    if (filter.statuses && filter.statuses.length > 0) {
      const statusSet = new Set(filter.statuses);
      candidates = candidates.filter(e => statusSet.has(e.status));
    }

    // 2b. Filter by Trust Levels
    if (filter.trustLevels && filter.trustLevels.length > 0) {
      const trustSet = new Set(filter.trustLevels);
      candidates = candidates.filter(e => trustSet.has(e.trustLevel));
    }

    // 3. Filter by Epistemic Statuses
    if (filter.epistemicStatuses && filter.epistemicStatuses.length > 0) {
      const epistemicSet = new Set(filter.epistemicStatuses);
      candidates = candidates.filter(e => epistemicSet.has(e.epistemicStatus));
    }

    // 4. Filter by Sources
    if (filter.sources && filter.sources.length > 0) {
      const sourceSet = new Set(filter.sources);
      candidates = candidates.filter(e => sourceSet.has(e.source));
    }

    // 5. Filter by File
    if (filter.file) {
      const targetFile = filter.file.toLowerCase();
      candidates = candidates.filter(e => 
        e.relatedFiles.some(f => f.toLowerCase().includes(targetFile) || targetFile.includes(f.toLowerCase()))
      );
    }

    // 6. Filter by Symbol
    if (filter.symbol) {
      const targetSymbol = filter.symbol.toLowerCase();
      candidates = candidates.filter(e => 
        e.relatedSymbols.some(s => s.toLowerCase().includes(targetSymbol) || targetSymbol.includes(s.toLowerCase()))
      );
    }

    // 7. Filter by Error Code
    if (filter.errorCode) {
      const targetErr = filter.errorCode.toUpperCase();
      candidates = candidates.filter(e => 
        e.failureDetails?.errorCode?.toUpperCase() === targetErr ||
        e.repairDetails?.errorCode?.toUpperCase() === targetErr ||
        e.content.toUpperCase().includes(targetErr)
      );
    }

    // 8. Filter by Commit Hash
    if (filter.commitHash) {
      const targetHash = filter.commitHash.toLowerCase();
      candidates = candidates.filter(e => 
        e.relatedCommits.some(c => c.toLowerCase().startsWith(targetHash) || targetHash.startsWith(c.toLowerCase()))
      );
    }

    // 9. Filter by Task ID
    if (filter.taskId) {
      const targetTask = filter.taskId.toUpperCase();
      candidates = candidates.filter(e => 
        e.relatedTasks.some(t => t.toUpperCase() === targetTask) || e.sourceTaskId?.toUpperCase() === targetTask
      );
    }

    // 9b. Filter by Mission ID
    if (filter.missionId) {
      const targetMission = filter.missionId.toUpperCase();
      candidates = candidates.filter(e => 
        e.sourceMissionId?.toUpperCase() === targetMission || e.evidence.some(ev => ev.toUpperCase().includes(targetMission))
      );
    }

    // 9c. Filter by Failure Signature
    if (filter.failureSignature) {
      const targetSig = filter.failureSignature.toLowerCase();
      candidates = candidates.filter(e => 
        e.failureSignature?.toLowerCase().includes(targetSig) ||
        e.failureDetails?.errorCode?.toLowerCase().includes(targetSig) ||
        e.content.toLowerCase().includes(targetSig)
      );
    }

    // 9d. Filter by Failure Category
    if (filter.failureCategory) {
      const targetCat = filter.failureCategory.toUpperCase();
      candidates = candidates.filter(e => 
        e.failureCategory?.toUpperCase() === targetCat || e.failureDetails?.category?.toUpperCase() === targetCat
      );
    }

    // 10. Filter by Architecture Layer
    if (filter.layer) {
      const targetLayer = filter.layer.toLowerCase();
      candidates = candidates.filter(e => e.architecturalLayer?.toLowerCase() === targetLayer);
    }

    // 11. Filter by Confidence
    if (filter.minConfidence !== undefined) {
      candidates = candidates.filter(e => e.confidence >= filter.minConfidence!);
    }

    // 12. Filter by Date Range
    if (filter.startDate) {
      candidates = candidates.filter(e => e.createdAt >= filter.startDate!);
    }
    if (filter.endDate) {
      candidates = candidates.filter(e => e.createdAt <= filter.endDate!);
    }

    // 13. Text search query
    if (filter.query && filter.query.trim()) {
      const q = filter.query.toLowerCase().trim();
      const terms = q.split(/\s+/).filter(t => t.length > 1);

      candidates = candidates.filter(e => {
        const textToSearch = [
          e.content,
          e.reason || '',
          e.decisionDetails?.fact || '',
          e.decisionDetails?.reason || '',
          e.decisionDetails?.decision || '',
          e.failureDetails?.errorMessage || '',
          e.failureDetails?.errorCode || '',
          e.failureDetails?.rootCause || '',
          e.repairDetails?.strategy || '',
          e.relatedFiles.join(' '),
          e.relatedSymbols.join(' '),
          e.relatedTasks.join(' '),
          e.relatedCommits.join(' ')
        ].join(' ').toLowerCase();

        return terms.every(term => textToSearch.includes(term));
      });
    }

    // 14. Apply limit
    if (filter.limit && filter.limit > 0) {
      return candidates.slice(0, filter.limit);
    }

    return candidates;
  }
}
