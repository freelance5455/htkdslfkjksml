/**
 * GODEX Phase 7 - Engineering Memory Types
 * Strict data contracts for structured engineering memory:
 * Decisions, Changes, Failures, Repairs, Verifications, Architecture,
 * Epistemic status, Sources, Invalidation, and Relevance explanations.
 */

export type EngineeringMemoryType = 
  | 'ARCHITECTURAL_DECISION'
  | 'DECISION'
  | 'VERIFIED_SUCCESS'
  | 'FAILURE'
  | 'REPAIR'
  | 'REPLAN'
  | 'SECURITY_EVENT'
  | 'VERIFICATION_RESULT'
  | 'VERIFICATION'
  | 'MISSION_OUTCOME'
  | 'CHANGE'
  | 'ARCHITECTURE'
  | 'TASK_OUTCOME'
  | 'REVIEW'
  | 'REGRESSION';

export type EpistemicStatus = 'KNOWN' | 'LIKELY' | 'UNKNOWN' | 'ASSUMED' | 'DERIVED' | 'CONJECTURAL';

export type MemoryTrustLevel = 'VERIFIED' | 'ADVISORY' | 'STALE' | 'INVALID';

export type MemorySource = 
  | 'SOURCE_CODE'
  | 'GIT'
  | 'EXECUTION'
  | 'TEST'
  | 'BUILD'
  | 'DEBUGGER'
  | 'CODING_AGENT'
  | 'ORCHESTRATOR'
  | 'REVIEWER'
  | 'VERIFIER'
  | 'USER_DECISION';

export type MemoryStatus = 
  | 'ACTIVE'
  | 'STALE'
  | 'SUPERSEDED'
  | 'INVALIDATED';

export interface DecisionDetails {
  fact?: string;
  reason: string;
  decision: string;
  evidenceSummary?: string;
  alternativesConsidered?: string[];
}

export interface FailureDetails {
  errorCode: string;
  errorMessage: string;
  location?: string;
  symbol?: string;
  rootCause?: string;
  category?: string;
  classification?: string;
  recoveryStatus?: 'RECOVERED' | 'UNRESOLVED' | 'REGRESSED';
}

export interface RepairDetails {
  failureId?: string;
  errorCode?: string;
  attemptNumber: number;
  strategy: string;
  diffSummary?: string;
  proposedFix?: string;
  outcome: 'SUCCESS' | 'FAILED' | 'REGRESSED';
  touchedFiles?: string[];
  touchedSymbols?: string[];
}

export interface VerificationDetails {
  verificationType: 'TYPECHECK' | 'TEST' | 'BUILD' | 'LINT' | 'EXECUTION' | 'REGRESSION';
  passed: boolean;
  exitCode: number;
  executionId: string;
  summary: string;
  failureCount?: number;
  durationMs?: number;
}

export interface ChangeDetails {
  summary: string;
  files: string[];
  symbols: string[];
  diffSummary?: string;
  validationEvidence?: string[];
}

export interface EngineeringMemoryEntry {
  id: string;
  type: EngineeringMemoryType;
  projectId: string;
  createdAt: number;
  updatedAt: number;
  source: MemorySource;
  relatedFiles: string[];
  relatedSymbols: string[];
  relatedCommits: string[];
  relatedTasks: string[];
  evidence: string[]; // concrete proof: execution IDs, commit hashes, test results, AST hashes
  confidence: number; // 0.0 to 1.0
  epistemicStatus: EpistemicStatus;
  status: MemoryStatus;
  trustLevel?: MemoryTrustLevel;
  content: string; // Redacted, concise description of fact/decision
  reason?: string; // Reason for decision, repair, or status invalidation
  version: number;
  supersededBy?: string; // ID of memory entry that replaced this one
  invalidationReason?: string;
  whyIncluded?: string; // Dynamically generated contextual explanation for retrieval
  architecturalLayer?: string;
  
  // P1.5 Provenance & Fingerprint Tracking
  sourceMissionId?: string;
  sourceTaskId?: string;
  fileFingerprints?: Record<string, string>;
  failureSignature?: string;
  failureCategory?: string;
  verificationStatus?: 'VERIFIED' | 'UNVERIFIED' | 'FAILED';

  // Typed details
  decisionDetails?: DecisionDetails;
  failureDetails?: FailureDetails;
  repairDetails?: RepairDetails;
  verificationDetails?: VerificationDetails;
  changeDetails?: ChangeDetails;
  
  metadata?: Record<string, any>;
}

export interface MemoryQueryFilter {
  query?: string;
  types?: EngineeringMemoryType[];
  sources?: MemorySource[];
  statuses?: MemoryStatus[];
  trustLevels?: MemoryTrustLevel[];
  epistemicStatuses?: EpistemicStatus[];
  file?: string;
  symbol?: string;
  errorCode?: string;
  failureSignature?: string;
  failureCategory?: string;
  missionId?: string;
  commitHash?: string;
  taskId?: string;
  layer?: string;
  startDate?: number;
  endDate?: number;
  minConfidence?: number;
  limit?: number;
}

export interface MemoryScoredResult {
  memory: EngineeringMemoryEntry;
  score: number; // 0 to 1
  relevanceScore?: number;
  matchedSignals: string[];
  whyIncluded: string;
}

export interface EngineeringTimelineEvent {
  id: string;
  timestamp: number;
  category: 'GIT' | 'TASK' | 'CHANGE' | 'EXECUTION' | 'FAILURE' | 'REPAIR' | 'VERIFICATION' | 'DECISION';
  title: string;
  description: string;
  source: string;
  relatedFiles: string[];
  relatedSymbols: string[];
  epistemicStatus: EpistemicStatus;
  memoryId?: string;
  status?: string;
  metadata?: Record<string, any>;
}

export interface MemoryStatsSummary {
  totalMemories: number;
  activeMemories: number;
  staleMemories: number;
  supersededMemories: number;
  verifiedDecisions: number;
  historicalFailures: number;
  successfulRepairs: number;
  failedRepairs: number;
  verificationsCount: number;
  knownCount: number;
  likelyCount: number;
  unknownCount: number;
  trustLevelCounts: Record<MemoryTrustLevel, number>;
}
