/**
 * GODEX Phase 7 - Memory Relevance Ranker & Explainer
 * Scores and selects high-signal engineering memories for bounded ContextPacks.
 * Produces structured "Why This Memory?" explanations.
 */

import { EngineeringMemoryEntry, MemoryScoredResult } from './memoryTypes';

export interface RelevanceQueryContext {
  targetFiles?: string[];
  affectedSymbols?: string[];
  errorCode?: string;
  failureSignature?: string;
  failureCategory?: string;
  taskId?: string;
  missionId?: string;
  objective?: string;
  architecturalLayer?: string;
  recentCommit?: string;
  role?: 'ARCHITECT' | 'RESEARCHER' | 'CODER' | 'DEBUGGER' | 'TESTER' | 'REVIEWER' | 'VERIFIER' | 'GENERAL';
  includeStale?: boolean;
  maxResults?: number;
}

export class MemoryRelevanceRanker {
  /**
   * Scores and ranks engineering memories against the active context.
   */
  public static rankMemories(
    memories: EngineeringMemoryEntry[],
    context: RelevanceQueryContext
  ): MemoryScoredResult[] {
    const scored: MemoryScoredResult[] = [];

    memories.forEach(mem => {
      // Discard INVALID entries entirely from relevance queries
      if (mem.trustLevel === 'INVALID' || mem.status === 'INVALIDATED') {
        return;
      }
      if (!context.includeStale && (mem.trustLevel === 'STALE' || mem.status === 'STALE') && !context.targetFiles?.length) {
        return;
      }

      // Base score
      let score = 0;
      const matchedSignals: string[] = [];
      const whyReasons: string[] = [];

      // 1. File Match (Weight ~0.35)
      if (context.targetFiles && context.targetFiles.length > 0) {
        const matchingFiles = mem.relatedFiles.filter(rf =>
          context.targetFiles!.some(tf => tf.toLowerCase() === rf.toLowerCase() || tf.includes(rf) || rf.includes(tf))
        );
        if (matchingFiles.length > 0) {
          score += 0.35;
          matchedSignals.push(`File Match: ${matchingFiles.join(', ')}`);
          whyReasons.push(`Matched file ${matchingFiles[0]}`);
        }
      }

      // 2. Symbol Match (Weight ~0.25)
      if (context.affectedSymbols && context.affectedSymbols.length > 0) {
        const matchingSymbols = mem.relatedSymbols.filter(rs =>
          context.affectedSymbols!.some(as => as.toLowerCase() === rs.toLowerCase() || as.includes(rs) || rs.includes(as))
        );
        if (matchingSymbols.length > 0) {
          score += 0.25;
          matchedSignals.push(`Symbol Match: ${matchingSymbols.join(', ')}`);
          whyReasons.push(`Matched symbol ${matchingSymbols[0]}`);
        }
      }

      // 3. Error Code & Failure Signature Match (Weight ~0.35)
      if (context.failureSignature && mem.failureSignature) {
        if (mem.failureSignature.toLowerCase() === context.failureSignature.toLowerCase()) {
          score += 0.40;
          matchedSignals.push(`Exact Failure Signature: ${context.failureSignature}`);
          whyReasons.push(`Exact failure signature matched: ${context.failureSignature}`);
        }
      }

      if (context.errorCode) {
        const memErr = mem.failureDetails?.errorCode || mem.repairDetails?.errorCode;
        if (memErr && memErr.toUpperCase() === context.errorCode.toUpperCase()) {
          score += 0.30;
          matchedSignals.push(`Error Code Match: ${context.errorCode}`);
          whyReasons.push(`Historical relevance: Same error code ${context.errorCode}`);
        }
      }

      // 3b. Failure Category Match (Weight ~0.20)
      if (context.failureCategory) {
        const memCat = mem.failureCategory || mem.failureDetails?.category;
        if (memCat && memCat.toUpperCase() === context.failureCategory.toUpperCase()) {
          score += 0.20;
          matchedSignals.push(`Category Match: ${context.failureCategory}`);
          whyReasons.push(`Same failure category (${context.failureCategory})`);
        }
      }

      // 4. Task ID & Mission ID Match (Weight ~0.20)
      if (context.taskId) {
        if (mem.relatedTasks.some(t => t.toUpperCase() === context.taskId!.toUpperCase()) || mem.sourceTaskId?.toUpperCase() === context.taskId!.toUpperCase()) {
          score += 0.20;
          matchedSignals.push(`Task Lineage: ${context.taskId}`);
          whyReasons.push(`Related to task ${context.taskId}`);
        }
      }

      if (context.missionId) {
        if (mem.sourceMissionId?.toUpperCase() === context.missionId.toUpperCase()) {
          score += 0.20;
          matchedSignals.push(`Mission Lineage: ${context.missionId}`);
        }
      }

      // 4b. Objective keyword overlap (Weight ~0.20)
      if (context.objective && context.objective.trim()) {
        const objKeywords = context.objective.toLowerCase().split(/\s+/).filter(w => w.length > 3);
        const memText = `${mem.content} ${mem.reason || ''}`.toLowerCase();
        const matches = objKeywords.filter(k => memText.includes(k));
        if (matches.length > 0) {
          score += Math.min(0.25, matches.length * 0.08);
          matchedSignals.push(`Objective Match: ${matches.slice(0, 2).join(', ')}`);
          whyReasons.push(`Keywords matched: ${matches.slice(0, 2).join(', ')}`);
        }
      }

      // 5. Architectural Layer Match (Weight ~0.15)
      if (context.architecturalLayer && mem.architecturalLayer) {
        if (context.architecturalLayer.toLowerCase() === mem.architecturalLayer.toLowerCase()) {
          score += 0.15;
          matchedSignals.push(`Layer Match: ${mem.architecturalLayer}`);
          whyReasons.push(`Shared architectural layer (${mem.architecturalLayer})`);
        }
      }

      // 6. Role-Specific Boost (Weight ~0.15)
      if (context.role) {
        if (context.role === 'ARCHITECT' && (mem.type === 'DECISION' || mem.type === 'ARCHITECTURAL_DECISION' || mem.type === 'ARCHITECTURE')) {
          score += 0.15;
          matchedSignals.push('Architectural Focus');
        } else if (context.role === 'DEBUGGER' && (mem.type === 'FAILURE' || mem.type === 'REPAIR')) {
          score += 0.20;
          matchedSignals.push('Debugger Repair Focus');
        } else if (context.role === 'TESTER' && (mem.type === 'VERIFICATION' || mem.type === 'VERIFICATION_RESULT' || mem.type === 'FAILURE')) {
          score += 0.15;
          matchedSignals.push('Test Verification Focus');
        } else if (context.role === 'REVIEWER' && (mem.type === 'DECISION' || mem.type === 'REGRESSION' || mem.type === 'REVIEW')) {
          score += 0.15;
          matchedSignals.push('Review & Regression Focus');
        } else if (context.role === 'CODER' && (mem.type === 'DECISION' || mem.type === 'CHANGE' || mem.type === 'REPAIR' || mem.type === 'VERIFIED_SUCCESS')) {
          score += 0.15;
          matchedSignals.push('Coding Pattern Focus');
        }
      }

      // 7. Trust Level Multiplier (P1.5 Trust Hierarchy: VERIFIED > ADVISORY > STALE > INVALID)
      let trustMultiplier = 1.0;
      if (mem.trustLevel === 'VERIFIED') trustMultiplier = 1.2;
      else if (mem.trustLevel === 'ADVISORY') trustMultiplier = 1.0;
      else if (mem.trustLevel === 'STALE') trustMultiplier = 0.35;
      else if (mem.trustLevel === 'INVALID') trustMultiplier = 0.0;

      // 8. Epistemic Status Multiplier
      let epistemicMultiplier = 1.0;
      if (mem.epistemicStatus === 'KNOWN') epistemicMultiplier = 1.0;
      else if (mem.epistemicStatus === 'LIKELY') epistemicMultiplier = 0.85;
      else epistemicMultiplier = 0.5;

      // 9. Historical Outcome Multiplier (e.g. successful repairs get boost)
      let outcomeMultiplier = 1.0;
      if (mem.type === 'REPAIR' && mem.repairDetails?.outcome === 'SUCCESS') {
        outcomeMultiplier = 1.15;
        whyReasons.push('Previously fixed successfully');
      }

      // Calculate final score
      const finalScore = Math.min(1.0, score * trustMultiplier * epistemicMultiplier * outcomeMultiplier);

      if (finalScore > 0.05 || matchedSignals.length > 0) {
        const explanation = whyReasons.length > 0 
          ? whyReasons.join(' | ') 
          : `Relevant ${mem.type.toLowerCase()} memory [Trust: ${mem.trustLevel || 'ADVISORY'}]`;

        scored.push({
          memory: {
            ...mem,
            whyIncluded: explanation
          },
          score: Math.round(finalScore * 100) / 100,
          relevanceScore: Math.round(finalScore * 100) / 100,
          matchedSignals,
          whyIncluded: explanation
        });
      }
    });

    // Sort descending by score
    scored.sort((a, b) => b.score - a.score);

    if (context.maxResults && context.maxResults > 0) {
      return scored.slice(0, context.maxResults);
    }

    return scored;
  }
}
