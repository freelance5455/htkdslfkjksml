/**
 * GODEX Phase 7 - Memory Query Service
 * Multi-criteria search engine returning scored, ranked memories with explanations.
 */

import { EngineeringMemoryEntry, MemoryQueryFilter, MemoryScoredResult } from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { MemoryIndexer } from './memoryIndexer';
import { MemoryRelevanceRanker, RelevanceQueryContext } from './memoryRelevance';

export class MemoryQueryService {
  /**
   * Performs an indexed, relevance-scored query over engineering memories.
   */
  public static search(
    filter: MemoryQueryFilter,
    relevanceContext?: RelevanceQueryContext,
    store: MemoryStore = MemoryStore.getInstance()
  ): MemoryScoredResult[] {
    // 1. Initial filtered set via indexer
    const candidates = MemoryIndexer.filterEntries(filter, store);

    // 2. If relevance context provided, score and rank
    const context: RelevanceQueryContext = {
      targetFiles: filter.file ? [filter.file] : relevanceContext?.targetFiles,
      affectedSymbols: filter.symbol ? [filter.symbol] : relevanceContext?.affectedSymbols,
      errorCode: filter.errorCode || relevanceContext?.errorCode,
      taskId: filter.taskId || relevanceContext?.taskId,
      architecturalLayer: filter.layer || relevanceContext?.architecturalLayer,
      role: relevanceContext?.role,
      maxResults: filter.limit || relevanceContext?.maxResults || 20
    };

    return MemoryRelevanceRanker.rankMemories(candidates, context);
  }

  /**
   * Fast retrieval of relevant memories for a specific task & agent role.
   */
  public static getScopedMemoryForAgent(
    role: 'ARCHITECT' | 'RESEARCHER' | 'CODER' | 'DEBUGGER' | 'TESTER' | 'REVIEWER' | 'VERIFIER' | 'GENERAL',
    targetFiles: string[],
    affectedSymbols: string[] = [],
    errorCode?: string,
    taskId?: string,
    maxCount = 6
  ): MemoryScoredResult[] {
    const filter: MemoryQueryFilter = {
      statuses: ['ACTIVE', 'STALE'],
      limit: 50
    };

    const relevanceContext: RelevanceQueryContext = {
      role,
      targetFiles,
      affectedSymbols,
      errorCode,
      taskId,
      maxResults: maxCount
    };

    return this.search(filter, relevanceContext);
  }
}
