/**
 * GODEX Phase 7 - Deterministic Engineering Memory & Git Intelligence Test Suite
 * Validates all 15 required memory invariants, Git intelligence mappings,
 * context pack injection, secret redactions, conflict resolutions, and E2E repair workflows.
 */

import { EngineeringMemoryEngine } from './engineeringMemory';
import { MemoryStore } from './memoryStore';
import { DecisionMemory } from './decisionMemory';
import { FailureMemory } from './failureMemory';
import { RepairMemory } from './repairMemory';
import { VerificationMemory } from './verificationMemory';
import { MemoryRelevanceRanker } from './memoryRelevance';
import { MemoryInvalidationEngine } from './memoryInvalidation';
import { GitIntelligence } from '../git/gitIntelligence';
import { GitChangeMapper } from '../git/gitChangeMapper';
import { ContextPackBuilder } from '../intelligence/contextPackBuilder';
import { TaskExtractor } from '../intelligence/taskExtractor';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';

export interface TestResultItem {
  testId: number;
  name: string;
  passed: boolean;
  message: string;
  evidence?: string;
}

export interface SimulationSuiteReport {
  timestamp: number;
  totalTests: number;
  passedCount: number;
  failedCount: number;
  durationMs: number;
  results: TestResultItem[];
}

export class SimulationMemoryTest {
  public static async runAllTests(): Promise<SimulationSuiteReport> {
    const startTime = Date.now();
    const results: TestResultItem[] = [];
    const memory = EngineeringMemoryEngine.getInstance();
    const store = memory.getStore();

    // 1. Create decision memory -> retrievable
    try {
      const dec = DecisionMemory.recordDecision({
        title: 'Keep Auth Logic In Services',
        fact: 'UI components should not directly handle token refreshes',
        reason: 'Separation of concerns between React rendering and authentication token lifecycle',
        decision: 'Authentication tokens must be refreshed in AuthService exclusively',
        evidence: ['src/services/authService.ts', 'src/types.ts'],
        relatedFiles: ['src/services/authService.ts'],
        relatedSymbols: ['AuthService.login', 'AuthService.refreshToken'],
        relatedTasks: ['TASK-AUTH-42'],
        relatedCommits: ['abc1234'],
        source: 'SOURCE_CODE',
        confidence: 0.98,
        epistemicStatus: 'KNOWN'
      }, store);

      const retrieved = store.getEntry(dec.id);
      const passed = retrieved !== undefined && retrieved.epistemicStatus === 'KNOWN' && retrieved.relatedFiles.includes('src/services/authService.ts');
      results.push({
        testId: 1,
        name: 'Create Decision Memory',
        passed,
        message: passed ? 'Decision memory created and retrieved by ID and file index' : 'Failed to retrieve decision memory',
        evidence: `ID: ${dec.id}, Status: ${dec.status}, Epistemic: ${dec.epistemicStatus}`
      });
    } catch (err: any) {
      results.push({ testId: 1, name: 'Create Decision Memory', passed: false, message: err.message });
    }

    // 2. Create verified failure memory -> retrievable by same error
    try {
      const fail = FailureMemory.recordFailure({
        errorCode: 'TS2304',
        errorMessage: 'Cannot find name "TokenPayload"',
        location: 'src/services/authService.ts:42',
        symbol: 'AuthService.refreshToken',
        relatedFiles: ['src/services/authService.ts'],
        rootCause: 'Missing import for TokenPayload',
        classification: 'MISSING_IMPORT',
        executionId: 'exec-test-101',
        task: 'TASK-AUTH-42'
      }, store);

      const queried = store.getEntriesByErrorCode('TS2304');
      const passed = queried.some(q => q.id === fail.id);
      results.push({
        testId: 2,
        name: 'Create Verified Failure Memory',
        passed,
        message: passed ? 'Failure memory indexed by error code TS2304' : 'Failure memory not found by error code',
        evidence: `Found ${queried.length} failures for TS2304`
      });
    } catch (err: any) {
      results.push({ testId: 2, name: 'Create Verified Failure Memory', passed: false, message: err.message });
    }

    // 3. Create successful repair memory -> candidate for similar current failure
    try {
      const rep = RepairMemory.recordRepair({
        errorCode: 'TS2304',
        attemptNumber: 1,
        strategy: 'Add named import { TokenPayload } from ./types',
        files: ['src/services/authService.ts'],
        symbols: ['AuthService.refreshToken'],
        outcome: 'SUCCESS',
        verificationEvidence: ['Typecheck exitCode 0', 'Lint exitCode 0'],
        proposedFix: "import { TokenPayload } from './types';",
        task: 'TASK-AUTH-42'
      }, store);

      const candidates = RepairMemory.findCandidateRepairs('TS2304', 'src/services/authService.ts', undefined, store);
      const passed = candidates.length > 0 && candidates[0].strategy.includes('TokenPayload') && candidates[0].mustReverify === true;
      results.push({
        testId: 3,
        name: 'Create Successful Repair Memory',
        passed,
        message: passed ? 'Historical repair retrieved as candidate with mustReverify=true invariant' : 'Repair not returned as candidate',
        evidence: `Top candidate strategy: "${candidates[0]?.strategy}", mustReverify: ${candidates[0]?.mustReverify}`
      });
    } catch (err: any) {
      results.push({ testId: 3, name: 'Create Successful Repair Memory', passed: false, message: err.message });
    }

    // 4. Create stale memory -> marked STALE
    try {
      const tempEntry = DecisionMemory.recordDecision({
        title: 'Legacy Webpack Configuration',
        reason: 'Initial setup used Webpack bundler',
        decision: 'Build scripts invoke webpack CLI',
        evidence: ['webpack.config.js'],
        relatedFiles: ['webpack.config.js']
      }, store);

      store.markStatus(tempEntry.id, 'STALE', 'Project migrated to Vite plugin pipeline');
      const updated = store.getEntry(tempEntry.id);
      const passed = updated?.status === 'STALE' && updated.invalidationReason?.includes('Vite');
      results.push({
        testId: 4,
        name: 'Create Stale Memory',
        passed,
        message: passed ? 'Memory successfully downgraded to STALE with invalidation reason' : 'Failed to mark memory STALE',
        evidence: `Status: ${updated?.status}, Reason: ${updated?.invalidationReason}`
      });
    } catch (err: any) {
      results.push({ testId: 4, name: 'Create Stale Memory', passed: false, message: err.message });
    }

    // 5. Create superseded decision -> old decision remains history, new decision wins
    try {
      const v1 = DecisionMemory.recordDecision({
        title: 'Use Pure In-Memory State for Cart',
        reason: 'Cart only needed single-session memory',
        decision: 'Cart items stored in React useState',
        evidence: ['src/components/Cart.tsx'],
        relatedFiles: ['src/components/Cart.tsx']
      }, store);

      const { oldEntry, newEntry } = DecisionMemory.supersedeDecision(
        v1.id,
        {
          title: 'Use LocalStorage Sync for Cart',
          reason: 'Users requested persistence across tab refreshes',
          decision: 'Cart items stored in localStorage with React hook synchronization',
          evidence: ['src/hooks/useCart.ts'],
          relatedFiles: ['src/hooks/useCart.ts', 'src/components/Cart.tsx']
        },
        'Migrated cart from ephemeral useState to localStorage persistence',
        store
      );

      const passed = oldEntry?.status === 'SUPERSEDED' && oldEntry.supersededBy === newEntry.id && newEntry.status === 'ACTIVE' && newEntry.version === 2;
      results.push({
        testId: 5,
        name: 'Superseded Decision Preserves Evolution',
        passed,
        message: passed ? 'Decision versioning verified (v1 SUPERSEDED, v2 ACTIVE, history preserved)' : 'Failed to supersede decision',
        evidence: `v1 Status: ${oldEntry?.status} (supersededBy ${oldEntry?.supersededBy}), v2 Version: ${newEntry.version}`
      });
    } catch (err: any) {
      results.push({ testId: 5, name: 'Superseded Decision Preserves Evolution', passed: false, message: err.message });
    }

    // 6. Git repository state detection -> accurate or UNKNOWN
    try {
      const git = GitIntelligence.getInstance();
      const state = git.getRepositoryState({ 'src/App.tsx': 'export default function App() {}' });
      const passed = state.currentBranch === 'main' && (state.epistemicStatus === 'KNOWN' || state.epistemicStatus === 'UNKNOWN') && state.headCommitHash.length > 0;
      results.push({
        testId: 6,
        name: 'Git Repository State Detection',
        passed,
        message: passed ? `Repository state verified (branch: ${state.currentBranch}, HEAD: ${state.headShortHash}, status: ${state.epistemicStatus})` : 'Invalid git state',
        evidence: `isWorkingTreeClean: ${state.isWorkingTreeClean}, epistemic: ${state.epistemicStatus}`
      });
    } catch (err: any) {
      results.push({ testId: 6, name: 'Git Repository State Detection', passed: false, message: err.message });
    }

    // 7. Commit history parsing -> correct commits and changed files
    try {
      const git = GitIntelligence.getInstance();
      const commits = git.getRecentCommits(5);
      const passed = commits.length >= 3 && commits.every(c => c.hash.length > 0 && c.changedFiles.length > 0 && c.message.length > 0);
      results.push({
        testId: 7,
        name: 'Commit History Parsing',
        passed,
        message: passed ? `Parsed ${commits.length} commits with commit messages, timestamps, and changed files` : 'Commit history incomplete',
        evidence: `Latest: [${commits[0]?.shortHash}] ${commits[0]?.message.slice(0, 50)}...`
      });
    } catch (err: any) {
      results.push({ testId: 7, name: 'Commit History Parsing', passed: false, message: err.message });
    }

    // 8. File history lookup -> correct historical commits
    try {
      const git = GitIntelligence.getInstance();
      const history = git.getFileHistory('src/orchestration/orchestrator.ts');
      const passed = history.length > 0 && history[0].commitHash.length > 0 && history[0].linesChanged.added > 0;
      results.push({
        testId: 8,
        name: 'File History Lookup',
        passed,
        message: passed ? `Successfully retrieved ${history.length} historical commits for orchestrator.ts` : 'File history empty',
        evidence: `Commit: ${history[0]?.shortHash}, Msg: ${history[0]?.message}`
      });
    } catch (err: any) {
      results.push({ testId: 8, name: 'File History Lookup', passed: false, message: err.message });
    }

    // 9. Diff-to-symbol mapping -> correct symbol where AST mapping exists
    try {
      const sampleCode = `
export class PaymentProcessor {
  public processCheckout(amount: number): boolean {
    return amount > 0;
  }
}
      `;
      const symbols = GitChangeMapper.mapLinesToSymbols('src/payment/processor.ts', sampleCode, [3]);
      const passed = symbols.length > 0 && (symbols.includes('PaymentProcessor') || symbols.includes('PaymentProcessor.processCheckout') || symbols.includes('processCheckout') || symbols.includes('FileLevelDeclaration'));
      results.push({
        testId: 9,
        name: 'Diff-to-Symbol Mapping',
        passed,
        message: passed ? `Mapped changed line 3 to semantic symbol: ${symbols.join(', ')}` : 'Symbol mapping failed',
        evidence: `Matched: ${symbols.join(', ')}`
      });
    } catch (err: any) {
      results.push({ testId: 9, name: 'Diff-to-Symbol Mapping', passed: false, message: err.message });
    }

    // 10. Memory relevance ranking -> high relevance ranked above unrelated
    try {
      const allMemories = store.getAllEntries();
      const scored = MemoryRelevanceRanker.rankMemories(allMemories, {
        targetFiles: ['src/services/authService.ts'],
        errorCode: 'TS2304',
        role: 'DEBUGGER'
      });

      const top = scored[0];
      const passed = scored.length > 0 && top.score > 0.5 && top.memory.relatedFiles.some(f => f.includes('authService'));
      results.push({
        testId: 10,
        name: 'Memory Relevance Ranking',
        passed,
        message: passed ? `Top ranked memory score: ${top.score}, Why included: "${top.whyIncluded}"` : 'Relevance ranking failed',
        evidence: `Signals: ${top?.matchedSignals.join(', ')}`
      });
    } catch (err: any) {
      results.push({ testId: 10, name: 'Memory Relevance Ranking', passed: false, message: err.message });
    }

    // 11. Secret redaction -> credentials never enter memory
    try {
      const secretEntry = DecisionMemory.recordDecision({
        title: 'Auth Header Configuration with sk-abcdef12345678901234567890123456',
        reason: 'API_KEY="super_secret_password_12345" required for upstream gateway',
        decision: 'Include Bearer 9876543210abcdef in all service requests',
        evidence: ['Bearer 1234567890abcdef1234567890abcdef']
      }, store);

      const hasRawSecret = secretEntry.content.includes('sk-abcdef') || 
                           secretEntry.reason?.includes('super_secret_password') ||
                           secretEntry.decisionDetails?.reason.includes('super_secret_password');
      const passed = !hasRawSecret && (secretEntry.content.includes('[REDACTED') || secretEntry.reason?.includes('[REDACTED'));
      results.push({
        testId: 11,
        name: 'Secret Redaction in Memory',
        passed,
        message: passed ? 'Secret keys and passwords successfully masked with [REDACTED]' : 'Secret leak detected in memory entry',
        evidence: `Content: "${secretEntry.content}", Reason: "${secretEntry.reason}"`
      });
    } catch (err: any) {
      results.push({ testId: 11, name: 'Secret Redaction in Memory', passed: false, message: err.message });
    }

    // 12. Context integration -> relevant memory appears in ContextPack
    try {
      const intelState = ProjectIntelligence.getState();
      const rawFiles = { 'src/services/authService.ts': 'export class AuthService {}' };
      const task = TaskExtractor.extract('Fix auth token error in authService', ['src/services/authService.ts'], ['AuthService']);

      const pack = ContextPackBuilder.build(
        'Fix auth token error in authService',
        'DEBUG',
        task,
        intelState,
        rawFiles
      );

      const passed = pack.engineeringMemory !== undefined && pack.engineeringMemory.length > 0 && pack.explanation.memoryReasons !== undefined;
      results.push({
        testId: 12,
        name: 'ContextPack Memory Integration',
        passed,
        message: passed ? `Injected ${pack.engineeringMemory?.length} scoped memories into ContextPack` : 'ContextPack missing engineering memory',
        evidence: `First memory: [${pack.engineeringMemory?.[0]?.type}] ${pack.engineeringMemory?.[0]?.content}`
      });
    } catch (err: any) {
      results.push({ testId: 12, name: 'ContextPack Memory Integration', passed: false, message: err.message });
    }

    // 13. Historical failure matching -> previous successful repair appears as candidate
    try {
      const candidates = RepairMemory.findCandidateRepairs('TS2304', 'src/services/authService.ts', undefined, store);
      const passed = candidates.length > 0 && candidates.some(c => c.historicalOutcome === 'SUCCESS' && c.mustReverify === true);
      results.push({
        testId: 13,
        name: 'Historical Failure Matching',
        passed,
        message: passed ? `Found ${candidates.length} candidate repairs with historical success records` : 'No candidates found',
        evidence: `Candidate strategy: "${candidates[0]?.strategy}"`
      });
    } catch (err: any) {
      results.push({ testId: 13, name: 'Historical Failure Matching', passed: false, message: err.message });
    }

    // 14. Current-vs-historical conflict -> current verified code wins
    try {
      const oldMem = DecisionMemory.recordDecision({
        title: 'Use XML Parser for Manifest',
        reason: 'Legacy Android format',
        decision: 'Parse manifest using xml2js',
        evidence: ['manifest.xml'],
        relatedFiles: ['manifest.xml']
      }, store);

      const conflictRes = MemoryInvalidationEngine.resolveConflictWithCurrentCode(
        oldMem,
        'Project uses JSON manifest format (metadata.json)',
        'metadata.json',
        store
      );

      const updated = store.getEntry(oldMem.id);
      const passed = conflictRes.currentTruthWins === true && updated?.status === 'STALE';
      results.push({
        testId: 14,
        name: 'Current-vs-Historical Conflict Resolution',
        passed,
        message: passed ? 'Verified current source code took precedence over stale memory' : 'Historical memory failed to downgrade',
        evidence: conflictRes.resolutionMessage
      });
    } catch (err: any) {
      results.push({ testId: 14, name: 'Current-vs-Historical Conflict Resolution', passed: false, message: err.message });
    }

    // 15. Memory invalidation after file mutation -> affected memory becomes stale
    try {
      const memTarget = DecisionMemory.recordDecision({
        title: 'Custom Logger Implementation',
        reason: 'Centralized telemetry logging',
        decision: 'Use CustomLogger class in logger.ts',
        evidence: ['src/utils/logger.ts'],
        relatedFiles: ['src/utils/logger.ts'],
        relatedSymbols: ['CustomLogger']
      }, store);

      // Mutate files (delete logger.ts)
      const currentFiles = {
        'src/App.tsx': 'export default function App() {}',
        'src/services/authService.ts': 'export class AuthService {}'
      };

      const invRes = MemoryInvalidationEngine.evaluateFileMutations(currentFiles, store);
      const updated = store.getEntry(memTarget.id);
      const passed = updated?.status === 'INVALIDATED' || updated?.status === 'STALE';
      results.push({
        testId: 15,
        name: 'Memory Invalidation on File Mutation',
        passed,
        message: passed ? `Memory invalidated upon file deletion (status: ${updated?.status})` : 'Memory was not invalidated',
        evidence: `Reason: ${updated?.invalidationReason}`
      });
    } catch (err: any) {
      results.push({ testId: 15, name: 'Memory Invalidation on File Mutation', passed: false, message: err.message });
    }

    // 16. End-to-End Historical Repair Simulation Scenario
    try {
      // Step 1: Controlled failure recorded
      const failId = FailureMemory.recordFailure({
        errorCode: 'TS2345',
        errorMessage: 'Argument of type "string" is not assignable to parameter of type "number"',
        location: 'src/utils/math.ts:12',
        symbol: 'calculateTax',
        relatedFiles: ['src/utils/math.ts'],
        rootCause: 'String passed instead of parsed float',
        classification: 'TYPE_MISMATCH',
        executionId: 'exec-sim-100',
        source: 'DEBUGGER'
      }, store);

      // Step 2: Debugger repairs it
      const repId = RepairMemory.recordRepair({
        failureId: failId.id,
        errorCode: 'TS2345',
        attemptNumber: 1,
        strategy: 'Wrap input with parseFloat() before arithmetic',
        files: ['src/utils/math.ts'],
        symbols: ['calculateTax'],
        outcome: 'SUCCESS',
        proposedFix: 'calculateTax(parseFloat(rawAmount))',
        verificationEvidence: ['Typecheck exitCode 0', 'Test exitCode 0'],
        source: 'DEBUGGER'
      }, store);

      // Step 3: Verification passed
      const verId = VerificationMemory.recordVerification({
        verificationType: 'TEST',
        passed: true,
        exitCode: 0,
        evidenceId: 'exec-sim-100',
        summary: 'All unit test assertions passed for calculateTax',
        relatedFiles: ['src/utils/math.ts'],
        source: 'TEST'
      }, store);

      // Step 4: Similar failure occurs later -> query memory
      const candidates = RepairMemory.findCandidateRepairs('TS2345', 'src/utils/math.ts', 'calculateTax', store);
      const passed = candidates.length > 0 && 
                     candidates[0].proposedFix?.includes('parseFloat') && 
                     candidates[0].mustReverify === true &&
                     store.getEntry(verId.id)?.type === 'VERIFICATION';

      results.push({
        testId: 16,
        name: 'End-to-End Historical Repair Workflow',
        passed,
        message: passed ? 'End-to-end failure -> repair -> verification -> candidate reuse cycle validated' : 'E2E repair workflow failed',
        evidence: `Retrieved Candidate Fix: "${candidates[0]?.proposedFix}" (mustReverify: ${candidates[0]?.mustReverify})`
      });
    } catch (err: any) {
      results.push({ testId: 16, name: 'End-to-End Historical Repair Workflow', passed: false, message: err.message });
    }

    // 17. Git + Orchestration Integration Scenario
    try {
      const git = GitIntelligence.getInstance();
      const recentCommits = git.getRecentCommits(3);
      const scopedDecisions = DecisionMemory.getActiveDecisions(store);
      const timeline = memory.getEngineeringTimeline();

      const passed = recentCommits.length > 0 && scopedDecisions.length > 0 && timeline.length >= 5;
      results.push({
        testId: 17,
        name: 'Git + Multi-Agent Memory Orchestration',
        passed,
        message: passed ? `Unified Engineering Timeline assembled with ${timeline.length} timeline events across Git, Decs, Repairs, and Verifications` : 'Git + Orchestration integration incomplete',
        evidence: `Timeline count: ${timeline.length}, Active Decisions: ${scopedDecisions.length}`
      });
    } catch (err: any) {
      results.push({ testId: 17, name: 'Git + Multi-Agent Memory Orchestration', passed: false, message: err.message });
    }

    // 18. P1.5 Trust Hierarchy Multipliers (VERIFIED > ADVISORY > STALE > INVALID)
    try {
      const entryVerified = DecisionMemory.recordDecision({
        title: 'Use Strict Typing for Mission State',
        reason: 'Prevents null runtime errors',
        decision: 'Enforce non-null assertions on mission progress',
        evidence: ['gate:verified-100'],
        relatedFiles: ['src/mission/missionState.ts'],
        epistemicStatus: 'KNOWN',
        confidence: 1.0
      }, store);
      store.markTrustLevel(entryVerified.id, 'VERIFIED');

      const entryAdvisory = DecisionMemory.recordDecision({
        title: 'Use Strict Typing for Mission State Alternate',
        reason: 'Suggestion for state typing',
        decision: 'Enforce non-null assertions on mission progress alternate',
        evidence: ['conjectural'],
        relatedFiles: ['src/mission/missionState.ts'],
        epistemicStatus: 'ASSUMED',
        confidence: 0.7
      }, store);
      store.markTrustLevel(entryAdvisory.id, 'ADVISORY');

      const entryStale = DecisionMemory.recordDecision({
        title: 'Use Strict Typing for Mission State Deprecated',
        reason: 'Old state typing',
        decision: 'Enforce non-null assertions on mission progress old',
        evidence: [],
        relatedFiles: ['src/mission/missionState.ts'],
        epistemicStatus: 'DERIVED',
        confidence: 0.5
      }, store);
      store.markTrustLevel(entryStale.id, 'STALE');

      const queryResults = memory.queryContextPackMemories({
        objective: 'Strict Typing for Mission State',
        targetFiles: ['src/mission/missionState.ts'],
        maxResults: 10
      });

      const topRanked = queryResults[0]?.memory;
      const verifiedScore = queryResults.find(r => r.memory.id === entryVerified.id)?.relevanceScore || 0;
      const advisoryScore = queryResults.find(r => r.memory.id === entryAdvisory.id)?.relevanceScore || 0;
      const staleScore = queryResults.find(r => r.memory.id === entryStale.id)?.relevanceScore || 0;

      const passed = topRanked?.id === entryVerified.id && verifiedScore > advisoryScore && advisoryScore > staleScore;
      results.push({
        testId: 18,
        name: 'P1.5 Trust Hierarchy Multipliers (VERIFIED > ADVISORY > STALE)',
        passed,
        message: passed ? `Trust hierarchy validated: VERIFIED (${verifiedScore.toFixed(2)}) > ADVISORY (${advisoryScore.toFixed(2)}) > STALE (${staleScore.toFixed(2)})` : 'Trust ranking failed to prioritize verified memory',
        evidence: `Top: ${topRanked?.id} (Trust: ${topRanked?.trustLevel})`
      });
    } catch (err: any) {
      results.push({ testId: 18, name: 'P1.5 Trust Hierarchy Multipliers', passed: false, message: err.message });
    }

    // 19. P1.5 Invalidation on Workspace Cryptographic Fingerprint Mismatch
    try {
      const originalCode = 'export const testUtil = () => 42;';
      const fp = MemoryInvalidationEngine.hashContent(originalCode);
      const decFp = DecisionMemory.recordDecision({
        title: 'Fingerprint Tracked Utility',
        reason: 'Static util helper',
        decision: 'Helper returns 42',
        evidence: ['unit-test-pass'],
        relatedFiles: ['src/utils/testUtil.ts'],
        epistemicStatus: 'KNOWN'
      }, store);

      store.updateEntry(decFp.id, {
        trustLevel: 'VERIFIED',
        fileFingerprints: {
          'src/utils/testUtil.ts': fp
        }
      });

      // Mutate the workspace file
      const mutatedWorkspace = {
        'src/utils/testUtil.ts': 'export const testUtil = () => 999; // modified'
      };

      const audit = MemoryInvalidationEngine.invalidateStaleEntriesByFingerprints(store, mutatedWorkspace);
      const updatedEntry = store.getEntry(decFp.id);

      const passed = audit.invalidatedCount >= 1 && updatedEntry?.trustLevel === 'STALE' && updatedEntry.status === 'STALE';
      results.push({
        testId: 19,
        name: 'P1.5 Invalidation on Workspace Fingerprint Mismatch',
        passed,
        message: passed ? 'Memory entry successfully downgraded to STALE upon cryptographic hash mismatch with live workspace' : 'Fingerprint invalidation failed',
        evidence: `Audit count: ${audit.invalidatedCount}, New Trust Level: ${updatedEntry?.trustLevel}`
      });
    } catch (err: any) {
      results.push({ testId: 19, name: 'P1.5 Invalidation on Workspace Fingerprint Mismatch', passed: false, message: err.message });
    }

    // 20. P1.5 Mission Planning Context Pack Retrieval with Trust Badges
    try {
      const { MissionMemoryConnector } = await import('../mission/missionMemory');
      const retrieved = MissionMemoryConnector.retrievePlanningContext(
        'Refactor authentication token and security headers',
        ['src/services/authService.ts']
      );

      const passed = Array.isArray(retrieved.decisions) &&
                     Array.isArray(retrieved.verifiedSuccesses) &&
                     Array.isArray(retrieved.failures) &&
                     retrieved.advisorySummary.includes('strictly advisory');

      results.push({
        testId: 20,
        name: 'P1.5 Mission Planning Context Retrieval with Advisory Notice',
        passed,
        message: passed ? `Planning context retrieved with ${retrieved.decisions.length} decisions and explicit advisory disclaimer` : 'Planning context retrieval failed',
        evidence: `Advisory summary: "${retrieved.advisorySummary}"`
      });
    } catch (err: any) {
      results.push({ testId: 20, name: 'P1.5 Mission Planning Context Retrieval', passed: false, message: err.message });
    }

    // 21. P1.5 Memory-Informed Failure Classification and Candidate Repair Retrieval
    try {
      const { MissionMemoryConnector } = await import('../mission/missionMemory');
      const repairContext = MissionMemoryConnector.retrieveRepairContext(
        {
          taskId: 'task-test-err',
          category: 'TYPECHECK',
          errorMessage: 'Cannot find name "TokenPayload"',
          timestamp: Date.now(),
          retryCount: 1,
          loopDetected: false
        },
        ['src/services/authService.ts']
      );

      const passed = repairContext.foundCandidates && repairContext.candidates.length > 0 && repairContext.candidates[0].mustReverify === true;
      results.push({
        testId: 21,
        name: 'P1.5 Memory-Informed Repair Retrieval & Re-verify Invariant',
        passed,
        message: passed ? `Candidate repair retrieved (${repairContext.candidates.length} candidates) with mandatory mustReverify=true` : 'Candidate repair retrieval failed',
        evidence: `Rationale: ${repairContext.rationale}`
      });
    } catch (err: any) {
      results.push({ testId: 21, name: 'P1.5 Memory-Informed Repair Retrieval', passed: false, message: err.message });
    }

    // 22. P1.5 Verified Success Persistence with Cryptographic Fingerprints
    try {
      const { MissionMemoryConnector } = await import('../mission/missionMemory');
      const sampleCode = 'export const safeAuth = true;';
      const created = MissionMemoryConnector.persistVerifiedSuccess({
        missionId: 'mission-sim-001',
        taskId: 'task-auth-001',
        title: 'Auth Header Hardening',
        files: ['src/auth/headers.ts'],
        fileContents: { 'src/auth/headers.ts': sampleCode },
        evidence: ['gate:security-audit-passed', 'test:100%']
      });

      const expectedFp = MemoryInvalidationEngine.hashContent(sampleCode);
      const passed = created !== null &&
                     created.trustLevel === 'VERIFIED' &&
                     created.fileFingerprints?.['src/auth/headers.ts'] === expectedFp &&
                     created.sourceMissionId === 'mission-sim-001';

      results.push({
        testId: 22,
        name: 'P1.5 Verified Success Persistence with Hash Fingerprints',
        passed,
        message: passed ? 'Verified success persisted with trustLevel=VERIFIED and cryptographic SHA/FNV hash fingerprints' : 'Persistence of verified success failed',
        evidence: `Created ID: ${created?.id}, Fingerprint: ${created?.fileFingerprints?.['src/auth/headers.ts']}`
      });
    } catch (err: any) {
      results.push({ testId: 22, name: 'P1.5 Verified Success Persistence', passed: false, message: err.message });
    }

    const durationMs = Date.now() - startTime;
    const passedCount = results.filter(r => r.passed).length;
    const failedCount = results.filter(r => !r.passed).length;

    return {
      timestamp: Date.now(),
      totalTests: results.length,
      passedCount,
      failedCount,
      durationMs,
      results
    };
  }
}

if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].endsWith('simulationMemoryTest.ts')) {
  SimulationMemoryTest.runAllTests().then(suite => {
    console.log(`\n=== P1.5 MEMORY & GIT INTELLIGENCE TEST SUITE: ${suite.passedCount}/${suite.totalTests} PASSED ===`);
    for (const r of suite.results) {
      console.log(` ${r.passed ? '✅' : '❌'} #${r.testId} ${r.name} (${r.passed ? 'PASS' : 'FAIL'})${r.message ? `: ${r.message}` : ''}`);
    }
    if (suite.failedCount > 0) {
      process.exit(1);
    }
  }).catch(err => {
    console.error(err);
    process.exit(1);
  });
}
