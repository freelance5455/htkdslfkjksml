/**
 * GODEX Phase 7 - Unified Engineering Memory Engine
 * Central facade managing the lifecycle of engineering memories, timeline generation,
 * secret redaction, and event ingestion from compiler, debugger, git, and agents.
 */

import { 
  EngineeringMemoryEntry, 
  EngineeringTimelineEvent, 
  MemoryStatsSummary, 
  MemoryQueryFilter, 
  MemoryScoredResult 
} from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { DecisionMemory, CreateDecisionParams } from './decisionMemory';
import { FailureMemory, RecordFailureParams } from './failureMemory';
import { RepairMemory, RecordRepairParams, CandidateRepair } from './repairMemory';
import { VerificationMemory, RecordVerificationParams } from './verificationMemory';
import { MemoryQueryService } from './memoryQuery';
import { MemoryRelevanceRanker } from './memoryRelevance';
import { MemoryInvalidationEngine, InvalidationResult } from './memoryInvalidation';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export class EngineeringMemoryEngine {
  private static instance: EngineeringMemoryEngine | null = null;
  private store: MemoryStore;

  private constructor() {
    this.store = MemoryStore.getInstance();
  }

  public static getInstance(): EngineeringMemoryEngine {
    if (!EngineeringMemoryEngine.instance) {
      EngineeringMemoryEngine.instance = new EngineeringMemoryEngine();
    }
    return EngineeringMemoryEngine.instance;
  }

  public getStore(): MemoryStore {
    return this.store;
  }

  /**
   * Records an architectural or design decision.
   */
  public recordDecision(params: CreateDecisionParams): EngineeringMemoryEntry {
    return DecisionMemory.recordDecision(params, this.store);
  }

  /**
   * Supersedes an existing decision with a newer one.
   */
  public supersedeDecision(oldId: string, newParams: CreateDecisionParams, reason: string): { oldEntry: EngineeringMemoryEntry | null; newEntry: EngineeringMemoryEntry } {
    return DecisionMemory.supersedeDecision(oldId, newParams, reason, this.store);
  }

  /**
   * Records a failure instance from compiler, runtime, or debugger.
   */
  public recordFailure(params: RecordFailureParams): EngineeringMemoryEntry {
    return FailureMemory.recordFailure(params, this.store);
  }

  /**
   * Records a repair attempt (success or failure).
   */
  public recordRepair(params: RecordRepairParams): EngineeringMemoryEntry {
    return RepairMemory.recordRepair(params, this.store);
  }

  /**
   * Finds candidate repairs for an active error code.
   */
  public findCandidateRepairs(errorCode?: string, file?: string, symbol?: string): CandidateRepair[] {
    return RepairMemory.findCandidateRepairs(errorCode, file, symbol, this.store);
  }

  /**
   * Records a verified outcome with required evidenceId.
   */
  public recordVerification(params: RecordVerificationParams): EngineeringMemoryEntry {
    return VerificationMemory.recordVerification(params, this.store);
  }

  /**
   * Searches memories with relevance scoring and explanations.
   */
  public search(filter: MemoryQueryFilter): MemoryScoredResult[] {
    return MemoryQueryService.search(filter, undefined, this.store);
  }

  /**
   * P1.5 Context Pack Memory Query Engine.
   * Multi-signal relevance scoring with trust hierarchy weighting.
   */
  public queryContextPackMemories(params: {
    objective?: string;
    targetFiles?: string[];
    affectedSymbols?: string[];
    role?: 'ARCHITECT' | 'RESEARCHER' | 'CODER' | 'DEBUGGER' | 'TESTER' | 'REVIEWER' | 'VERIFIER' | 'GENERAL';
    maxResults?: number;
    errorCode?: string;
    failureSignature?: string;
    failureCategory?: string;
    taskId?: string;
    missionId?: string;
  }): MemoryScoredResult[] {
    const all = this.store.getAllEntries();
    return MemoryRelevanceRanker.rankMemories(all, {
      objective: params.objective,
      targetFiles: params.targetFiles,
      affectedSymbols: params.affectedSymbols,
      role: params.role,
      maxResults: params.maxResults || 10,
      errorCode: params.errorCode,
      failureSignature: params.failureSignature,
      failureCategory: params.failureCategory,
      taskId: params.taskId,
      missionId: params.missionId
    });
  }

  /**
   * Gets memory scoped for an agent role.
   */
  public getScopedMemoryForAgent(
    role: 'ARCHITECT' | 'RESEARCHER' | 'CODER' | 'DEBUGGER' | 'TESTER' | 'REVIEWER' | 'VERIFIER' | 'GENERAL',
    targetFiles: string[],
    affectedSymbols: string[] = [],
    errorCode?: string,
    taskId?: string,
    maxCount = 6
  ): MemoryScoredResult[] {
    return MemoryQueryService.getScopedMemoryForAgent(
      role,
      targetFiles,
      affectedSymbols,
      errorCode,
      taskId,
      maxCount
    );
  }

  /**
   * Re-evaluates memories upon workspace file mutation.
   */
  public handleFileMutation(currentFiles: Record<string, string>): InvalidationResult {
    return MemoryInvalidationEngine.evaluateFileMutations(currentFiles, this.store);
  }

  /**
   * Builds a unified engineering history timeline from all memory entries.
   */
  public getEngineeringTimeline(filterCategory?: string): EngineeringTimelineEvent[] {
    const all = this.store.getAllEntries();
    const events: EngineeringTimelineEvent[] = [];

    all.forEach(mem => {
      let category: EngineeringTimelineEvent['category'] = 'DECISION';
      let title = mem.content;

      if (mem.type === 'FAILURE') {
        category = 'FAILURE';
        title = `Failure ${mem.failureDetails?.errorCode || 'Error'}: ${mem.failureDetails?.errorMessage || mem.content}`;
      } else if (mem.type === 'REPAIR') {
        category = 'REPAIR';
        title = `Repair Attempt: ${mem.repairDetails?.strategy || mem.content} (${mem.repairDetails?.outcome})`;
      } else if (mem.type === 'VERIFICATION') {
        category = 'VERIFICATION';
        title = `Verification ${mem.verificationDetails?.verificationType}: ${mem.verificationDetails?.summary}`;
      } else if (mem.type === 'CHANGE') {
        category = 'CHANGE';
        title = `Code Change: ${mem.content}`;
      } else if (mem.type === 'TASK_OUTCOME') {
        category = 'TASK';
        title = `Task Outcome: ${mem.content}`;
      }

      events.push({
        id: `tl-${mem.id}`,
        timestamp: mem.createdAt,
        category,
        title: SecuritySanitizer.redact(title),
        description: SecuritySanitizer.redact(mem.reason || mem.content),
        source: mem.source,
        relatedFiles: mem.relatedFiles,
        relatedSymbols: mem.relatedSymbols,
        epistemicStatus: mem.epistemicStatus,
        memoryId: mem.id,
        status: mem.status,
        metadata: mem.metadata
      });
    });

    // Sort descending by timestamp
    events.sort((a, b) => b.timestamp - a.timestamp);

    if (filterCategory && filterCategory !== 'ALL') {
      return events.filter(e => e.category === filterCategory);
    }

    return events;
  }

  /**
   * Returns memory stats summary.
   */
  public getStats(): MemoryStatsSummary {
    return this.store.getStatsSummary();
  }

  public clear(): void {
    this.store.clear();
  }
}
