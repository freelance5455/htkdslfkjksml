/**
 * GODEX Phase 7 - Verification Memory Subsystem
 * Stores verified engineering outcomes: TYPECHECK, TEST, BUILD, LINT, EXECUTION, and REGRESSION.
 * Invariant: Never stores "verified" without concrete evidence (execution ID, exitCode, output hash).
 */

import { EngineeringMemoryEntry, EpistemicStatus, MemorySource, VerificationDetails } from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export interface RecordVerificationParams {
  verificationType: 'TYPECHECK' | 'TEST' | 'BUILD' | 'LINT' | 'EXECUTION' | 'REGRESSION';
  passed: boolean;
  exitCode: number;
  evidenceId: string;
  summary: string;
  failureCount?: number;
  durationMs?: number;
  relatedFiles?: string[];
  relatedSymbols?: string[];
  relatedCommits?: string[];
  relatedTasks?: string[];
  source?: MemorySource;
  confidence?: number;
  metadata?: Record<string, any>;
}

export class VerificationMemory {
  /**
   * Records a verification event into engineering memory with strict evidence validation.
   */
  public static recordVerification(
    params: RecordVerificationParams,
    store: MemoryStore = MemoryStore.getInstance()
  ): EngineeringMemoryEntry {
    if (!params.evidenceId || typeof params.evidenceId !== 'string') {
      throw new Error('VerificationMemory invariant violation: Cannot record verification without concrete evidenceId.');
    }

    const id = `ver-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    const verificationDetails: VerificationDetails = {
      verificationType: params.verificationType,
      passed: params.passed,
      exitCode: params.exitCode,
      executionId: SecuritySanitizer.redact(params.evidenceId),
      summary: SecuritySanitizer.redact(params.summary),
      failureCount: params.failureCount,
      durationMs: params.durationMs
    };

    const evidence = [
      `Evidence ID: ${params.evidenceId}`,
      `Verification Type: ${params.verificationType}`,
      `Exit Code: ${params.exitCode}`,
      `Result: ${params.passed ? 'PASS' : 'FAIL'}`,
      `Summary: ${params.summary}`
    ];

    const epistemicStatus: EpistemicStatus = 'KNOWN'; // Direct verified test/execution evidence

    const entry: EngineeringMemoryEntry = {
      id,
      type: 'VERIFICATION',
      projectId: 'godex-workspace',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      source: params.source || (params.verificationType === 'TEST' ? 'TEST' : params.verificationType === 'BUILD' ? 'BUILD' : 'VERIFIER'),
      relatedFiles: params.relatedFiles || [],
      relatedSymbols: params.relatedSymbols || [],
      relatedCommits: params.relatedCommits || [],
      relatedTasks: params.relatedTasks || [],
      evidence: evidence.map(e => SecuritySanitizer.redact(e)),
      confidence: params.confidence ?? 1.0,
      epistemicStatus,
      status: 'ACTIVE',
      content: SecuritySanitizer.redact(
        `Verification ${params.verificationType} (${params.passed ? 'PASSED' : 'FAILED'}): ${params.summary}`
      ),
      reason: `Exit code ${params.exitCode}`,
      version: 1,
      verificationDetails,
      metadata: params.metadata
    };

    store.addEntry(entry);
    return entry;
  }

  /**
   * Retrieves verification records for a specific file.
   */
  public static getVerificationsForFile(file: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByFile(file).filter(e => e.type === 'VERIFICATION');
  }

  /**
   * Retrieves verification records for a specific commit.
   */
  public static getVerificationsForCommit(commitHash: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByCommit(commitHash).filter(e => e.type === 'VERIFICATION');
  }

  /**
   * Retrieves verification records for a specific task.
   */
  public static getVerificationsForTask(taskId: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByTask(taskId).filter(e => e.type === 'VERIFICATION');
  }
}
