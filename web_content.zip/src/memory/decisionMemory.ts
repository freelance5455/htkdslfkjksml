/**
 * GODEX Phase 7 - Decision Memory Subsystem
 * Records, supersedes, and queries architectural & system engineering decisions.
 * Strictly separates: FACT (Context), REASON (Justification), DECISION (Rule), and EVIDENCE (Proof).
 */

import { 
  EngineeringMemoryEntry, 
  EpistemicStatus, 
  MemorySource, 
  DecisionDetails 
} from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export interface CreateDecisionParams {
  title: string;
  fact?: string;
  reason: string;
  decision: string;
  evidence: string[];
  relatedFiles?: string[];
  relatedSymbols?: string[];
  relatedTasks?: string[];
  relatedCommits?: string[];
  source?: MemorySource;
  confidence?: number;
  epistemicStatus?: EpistemicStatus;
  architecturalLayer?: string;
  alternativesConsidered?: string[];
  metadata?: Record<string, any>;
}

export class DecisionMemory {
  /**
   * Records a verified or user-provided engineering decision into memory.
   */
  public static recordDecision(
    params: CreateDecisionParams,
    store: MemoryStore = MemoryStore.getInstance()
  ): EngineeringMemoryEntry {
    const id = `dec-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    
    // Distinguish source epistemic status
    let epistemic: EpistemicStatus = params.epistemicStatus || 'KNOWN';
    if (params.source === 'USER_DECISION') {
      // User decision is directly stated by human
      epistemic = 'KNOWN';
    } else if (params.source === 'REVIEWER' || params.source === 'CODING_AGENT') {
      epistemic = params.evidence.length > 0 ? 'KNOWN' : 'LIKELY';
    }

    const decisionDetails: DecisionDetails = {
      fact: params.fact ? SecuritySanitizer.redact(params.fact) : undefined,
      reason: SecuritySanitizer.redact(params.reason),
      decision: SecuritySanitizer.redact(params.decision),
      evidenceSummary: params.evidence.join('; '),
      alternativesConsidered: params.alternativesConsidered
    };

    const entry: EngineeringMemoryEntry = {
      id,
      type: 'DECISION',
      projectId: 'godex-workspace',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      source: params.source || 'SOURCE_CODE',
      relatedFiles: params.relatedFiles || [],
      relatedSymbols: params.relatedSymbols || [],
      relatedCommits: params.relatedCommits || [],
      relatedTasks: params.relatedTasks || [],
      evidence: params.evidence.map(e => SecuritySanitizer.redact(e)),
      confidence: Math.min(1.0, Math.max(0.0, params.confidence ?? 0.95)),
      epistemicStatus: epistemic,
      status: 'ACTIVE',
      content: SecuritySanitizer.redact(params.title || params.decision),
      reason: SecuritySanitizer.redact(params.reason),
      version: 1,
      architecturalLayer: params.architecturalLayer,
      decisionDetails,
      metadata: params.metadata
    };

    store.addEntry(entry);
    return entry;
  }

  /**
   * Supersedes an existing decision with a newer version.
   * Preserves history: the old decision becomes SUPERSEDED, the new decision becomes ACTIVE.
   */
  public static supersedeDecision(
    oldDecisionId: string,
    newParams: CreateDecisionParams,
    supersedeReason: string,
    store: MemoryStore = MemoryStore.getInstance()
  ): { oldEntry: EngineeringMemoryEntry | null; newEntry: EngineeringMemoryEntry } {
    const oldEntry = store.getEntry(oldDecisionId) || null;
    const oldVersion = oldEntry ? oldEntry.version : 1;

    const newEntry = this.recordDecision(
      {
        ...newParams,
        confidence: newParams.confidence ?? 0.95
      },
      store
    );

    // Update new entry version
    store.updateEntry(newEntry.id, {
      version: oldVersion + 1,
      metadata: {
        ...newEntry.metadata,
        supersedes: oldDecisionId
      }
    });

    if (oldEntry) {
      store.markSuperseded(oldDecisionId, newEntry.id, SecuritySanitizer.redact(supersedeReason));
    }

    return {
      oldEntry: store.getEntry(oldDecisionId) || null,
      newEntry: store.getEntry(newEntry.id)!
    };
  }

  /**
   * Retrieves active decisions for a specific file.
   */
  public static getDecisionsForFile(file: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByFile(file).filter(e => e.type === 'DECISION' && e.status === 'ACTIVE');
  }

  /**
   * Retrieves active decisions for a specific symbol.
   */
  public static getDecisionsForSymbol(symbol: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesBySymbol(symbol).filter(e => e.type === 'DECISION' && e.status === 'ACTIVE');
  }

  /**
   * Returns all active verified decisions.
   */
  public static getActiveDecisions(store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByType('DECISION').filter(e => e.status === 'ACTIVE');
  }
}
