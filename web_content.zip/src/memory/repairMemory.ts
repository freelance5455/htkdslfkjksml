/**
 * GODEX Phase 7 - Repair Memory Subsystem
 * Records successful and unsuccessful repair attempts with associated strategies,
 * diff summaries, and verification proofs. Provides candidate repair retrieval
 * for similar new failures without blindly trusting past solutions.
 */

import { EngineeringMemoryEntry, EpistemicStatus, MemorySource, RepairDetails } from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export interface RecordRepairParams {
  failureId?: string;
  errorCode?: string;
  attemptNumber: number;
  strategy: string;
  files: string[];
  symbols?: string[];
  outcome: 'SUCCESS' | 'FAILED' | 'REGRESSED';
  verificationEvidence?: string[];
  proposedFix?: string;
  diffSummary?: string;
  task?: string;
  commit?: string;
  source?: MemorySource;
  confidence?: number;
  epistemicStatus?: EpistemicStatus;
  metadata?: Record<string, any>;
}

export interface CandidateRepair {
  memoryId: string;
  errorCode?: string;
  strategy: string;
  proposedFix?: string;
  historicalOutcome: 'SUCCESS' | 'FAILED' | 'REGRESSED';
  confidence: number;
  epistemicStatus: EpistemicStatus;
  relatedFiles: string[];
  explanation: string;
  mustReverify: boolean;
}

export class RepairMemory {
  /**
   * Records a repair attempt (successful, failed, or regressed).
   */
  public static recordRepair(
    params: RecordRepairParams,
    store: MemoryStore = MemoryStore.getInstance()
  ): EngineeringMemoryEntry {
    const id = `rep-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    const repairDetails: RepairDetails = {
      failureId: params.failureId,
      errorCode: params.errorCode ? SecuritySanitizer.redact(params.errorCode) : undefined,
      attemptNumber: params.attemptNumber,
      strategy: SecuritySanitizer.redact(params.strategy),
      diffSummary: params.diffSummary ? SecuritySanitizer.redact(params.diffSummary) : undefined,
      proposedFix: params.proposedFix ? SecuritySanitizer.redact(params.proposedFix) : undefined,
      outcome: params.outcome,
      touchedFiles: params.files,
      touchedSymbols: params.symbols
    };

    const evidence = [
      `Outcome: ${params.outcome}`,
      `Strategy: ${params.strategy}`,
      ...(params.verificationEvidence || [])
    ];

    const entry: EngineeringMemoryEntry = {
      id,
      type: 'REPAIR',
      projectId: 'godex-workspace',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      source: params.source || 'DEBUGGER',
      relatedFiles: params.files,
      relatedSymbols: params.symbols || [],
      relatedCommits: params.commit ? [params.commit] : [],
      relatedTasks: params.task ? [params.task] : [],
      evidence: evidence.map(e => SecuritySanitizer.redact(e)),
      confidence: params.confidence ?? (params.outcome === 'SUCCESS' ? 0.95 : 0.7),
      epistemicStatus: params.epistemicStatus || 'KNOWN',
      status: 'ACTIVE',
      content: SecuritySanitizer.redact(`Repair Attempt (${params.outcome}): ${params.strategy}`),
      reason: SecuritySanitizer.redact(params.strategy),
      version: 1,
      repairDetails,
      metadata: params.metadata
    };

    store.addEntry(entry);
    return entry;
  }

  /**
   * Finds candidate repairs for a similar failure.
   * Returns candidate solutions with clear notice that they MUST be re-verified against current code.
   */
  public static findCandidateRepairs(
    errorCode?: string,
    file?: string,
    symbol?: string,
    store: MemoryStore = MemoryStore.getInstance()
  ): CandidateRepair[] {
    const allRepairs = store.getEntriesByType('REPAIR');
    if (allRepairs.length === 0) return [];

    const candidates: CandidateRepair[] = [];

    allRepairs.forEach(rep => {
      let matchScore = 0;
      const reasons: string[] = [];

      if (errorCode && rep.repairDetails?.errorCode?.toUpperCase() === errorCode.toUpperCase()) {
        matchScore += 0.5;
        reasons.push(`Matched error code ${errorCode}`);
      }

      if (file && rep.relatedFiles.some(f => f.toLowerCase().includes(file.toLowerCase()))) {
        matchScore += 0.3;
        reasons.push(`Matched related file ${file}`);
      }

      if (symbol && rep.relatedSymbols.some(s => s.toLowerCase().includes(symbol.toLowerCase()))) {
        matchScore += 0.2;
        reasons.push(`Matched symbol ${symbol}`);
      }

      // Prioritize successful past repairs
      if (rep.repairDetails?.outcome === 'SUCCESS') {
        matchScore += 0.2;
      } else {
        matchScore -= 0.1;
      }

      if (matchScore > 0.3 || (errorCode && rep.repairDetails?.errorCode?.toUpperCase() === errorCode.toUpperCase())) {
        candidates.push({
          memoryId: rep.id,
          errorCode: rep.repairDetails?.errorCode,
          strategy: rep.repairDetails?.strategy || rep.content,
          proposedFix: rep.repairDetails?.proposedFix,
          historicalOutcome: rep.repairDetails?.outcome || 'SUCCESS',
          confidence: matchScore,
          epistemicStatus: rep.epistemicStatus,
          relatedFiles: rep.relatedFiles,
          explanation: reasons.join('; ') || 'Relevant historical repair pattern',
          mustReverify: true
        });
      }
    });

    // Sort candidates: highest match score first, then successful repairs
    return candidates.sort((a, b) => {
      if (b.confidence !== a.confidence) return b.confidence - a.confidence;
      if (a.historicalOutcome === 'SUCCESS' && b.historicalOutcome !== 'SUCCESS') return -1;
      if (b.historicalOutcome === 'SUCCESS' && a.historicalOutcome !== 'SUCCESS') return 1;
      return 0;
    });
  }

  /**
   * Retrieves all repairs for a given file.
   */
  public static getRepairsForFile(file: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByFile(file).filter(e => e.type === 'REPAIR');
  }
}
