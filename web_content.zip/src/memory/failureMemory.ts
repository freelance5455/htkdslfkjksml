/**
 * GODEX Phase 7 - Failure Memory Subsystem
 * Records concrete failure events from Phase 5 (Self-Healing Debugger),
 * compilation runs, and tests for historical reference and future repair candidate retrieval.
 */

import { EngineeringMemoryEntry, EpistemicStatus, MemorySource, FailureDetails } from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export interface RecordFailureParams {
  errorCode: string;
  errorMessage: string;
  location?: string;
  symbol?: string;
  relatedFiles: string[];
  rootCause?: string;
  category?: string;
  classification?: string;
  recoveryStatus?: 'RECOVERED' | 'UNRESOLVED' | 'REGRESSED';
  executionId?: string;
  commit?: string;
  task?: string;
  source?: MemorySource;
  confidence?: number;
  epistemicStatus?: EpistemicStatus;
  metadata?: Record<string, any>;
}

export class FailureMemory {
  /**
   * Records a verified failure into engineering memory.
   */
  public static recordFailure(
    params: RecordFailureParams,
    store: MemoryStore = MemoryStore.getInstance()
  ): EngineeringMemoryEntry {
    const id = `fail-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    const failureDetails: FailureDetails = {
      errorCode: SecuritySanitizer.redact(params.errorCode),
      errorMessage: SecuritySanitizer.redact(params.errorMessage),
      location: params.location ? SecuritySanitizer.redact(params.location) : undefined,
      symbol: params.symbol ? SecuritySanitizer.redact(params.symbol) : undefined,
      rootCause: params.rootCause ? SecuritySanitizer.redact(params.rootCause) : undefined,
      category: params.category,
      classification: params.classification,
      recoveryStatus: params.recoveryStatus || 'UNRESOLVED'
    };

    const evidence = [
      `Error Code: ${params.errorCode}`,
      params.executionId ? `Execution ID: ${params.executionId}` : '',
      params.location ? `Location: ${params.location}` : '',
      params.rootCause ? `Root Cause: ${params.rootCause}` : ''
    ].filter(Boolean);

    const entry: EngineeringMemoryEntry = {
      id,
      type: 'FAILURE',
      projectId: 'godex-workspace',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      source: params.source || 'DEBUGGER',
      relatedFiles: params.relatedFiles,
      relatedSymbols: params.symbol ? [params.symbol] : [],
      relatedCommits: params.commit ? [params.commit] : [],
      relatedTasks: params.task ? [params.task] : [],
      evidence: evidence.map(e => SecuritySanitizer.redact(e)),
      confidence: params.confidence ?? 1.0,
      epistemicStatus: params.epistemicStatus || 'KNOWN',
      status: 'ACTIVE',
      content: SecuritySanitizer.redact(`Failure ${params.errorCode}: ${params.errorMessage.slice(0, 140)}`),
      reason: params.rootCause ? SecuritySanitizer.redact(params.rootCause) : undefined,
      version: 1,
      failureDetails,
      metadata: params.metadata
    };

    store.addEntry(entry);
    return entry;
  }

  /**
   * Searches for similar historical failures by error code, file, or symbol.
   */
  public static searchSimilarFailures(
    errorCode?: string,
    file?: string,
    symbol?: string,
    store: MemoryStore = MemoryStore.getInstance()
  ): EngineeringMemoryEntry[] {
    const allFailures = store.getEntriesByType('FAILURE');
    if (!errorCode && !file && !symbol) return allFailures;

    return allFailures.filter(f => {
      const matchErr = errorCode && f.failureDetails?.errorCode?.toUpperCase() === errorCode.toUpperCase();
      const matchFile = file && f.relatedFiles.some(rf => rf.toLowerCase().includes(file.toLowerCase()));
      const matchSymbol = symbol && f.relatedSymbols.some(rs => rs.toLowerCase().includes(symbol.toLowerCase()));
      return matchErr || matchFile || matchSymbol;
    });
  }

  /**
   * Retrieves failure records for a specific file.
   */
  public static getFailuresForFile(file: string, store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByFile(file).filter(e => e.type === 'FAILURE');
  }

  /**
   * Retrieves all failure history.
   */
  public static getFailureHistory(store: MemoryStore = MemoryStore.getInstance()): EngineeringMemoryEntry[] {
    return store.getEntriesByType('FAILURE');
  }
}
