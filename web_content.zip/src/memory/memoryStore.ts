/**
 * GODEX Phase 7 - In-Memory Engineering Memory Store
 * Fast multi-indexed repository storing durable engineering facts,
 * decisions, failure histories, repairs, and verifications.
 */

import { 
  EngineeringMemoryEntry, 
  EngineeringMemoryType, 
  MemoryStatus, 
  MemoryTrustLevel, 
  MemoryStatsSummary 
} from './memoryTypes';

export type MemoryStoreListener = (entry: EngineeringMemoryEntry, action: 'ADD' | 'UPDATE' | 'DELETE') => void;

export class MemoryStore {
  private static instance: MemoryStore | null = null;

  private entries: Map<string, EngineeringMemoryEntry> = new Map();
  private fileIndex: Map<string, Set<string>> = new Map();
  private symbolIndex: Map<string, Set<string>> = new Map();
  private typeIndex: Map<EngineeringMemoryType, Set<string>> = new Map();
  private commitIndex: Map<string, Set<string>> = new Map();
  private taskIndex: Map<string, Set<string>> = new Map();
  private errorCodeIndex: Map<string, Set<string>> = new Map();
  private statusIndex: Map<MemoryStatus, Set<string>> = new Map();
  private trustLevelIndex: Map<MemoryTrustLevel, Set<string>> = new Map();

  private listeners: Set<MemoryStoreListener> = new Set();

  private constructor() {
    this.seedDefaultProjectMemories();
  }

  public static getInstance(): MemoryStore {
    if (!MemoryStore.instance) {
      MemoryStore.instance = new MemoryStore();
    }
    return MemoryStore.instance;
  }

  public subscribe(listener: MemoryStoreListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(entry: EngineeringMemoryEntry, action: 'ADD' | 'UPDATE' | 'DELETE'): void {
    this.listeners.forEach(fn => {
      try {
        fn(entry, action);
      } catch (err) {
        console.error('Error in MemoryStore listener:', err);
      }
    });
  }

  /**
   * Derives default trust level from entry attributes if not explicitly provided.
   */
  public static deriveTrustLevel(entry: Partial<EngineeringMemoryEntry>): MemoryTrustLevel {
    if (entry.trustLevel) return entry.trustLevel;
    if (entry.status === 'INVALIDATED') return 'INVALID';
    if (entry.status === 'STALE') return 'STALE';
    if (entry.verificationStatus === 'VERIFIED') return 'VERIFIED';
    if (entry.epistemicStatus === 'KNOWN' && entry.evidence && entry.evidence.length > 0 && entry.status === 'ACTIVE') {
      return 'VERIFIED';
    }
    return 'ADVISORY';
  }

  /**
   * Adds or replaces a memory entry and updates indexes.
   */
  public addEntry(entry: EngineeringMemoryEntry): void {
    const existing = this.entries.get(entry.id);
    if (existing) {
      this.removeFromIndexes(existing);
    }

    const normalizedEntry: EngineeringMemoryEntry = {
      ...entry,
      trustLevel: entry.trustLevel || MemoryStore.deriveTrustLevel(entry)
    };

    this.entries.set(normalizedEntry.id, normalizedEntry);
    this.addToIndexes(normalizedEntry);
    this.notify(normalizedEntry, existing ? 'UPDATE' : 'ADD');
  }

  /**
   * Updates an existing memory entry.
   */
  public updateEntry(id: string, updates: Partial<EngineeringMemoryEntry>): EngineeringMemoryEntry | null {
    const entry = this.entries.get(id);
    if (!entry) return null;

    this.removeFromIndexes(entry);
    const updated: EngineeringMemoryEntry = {
      ...entry,
      ...updates,
      updatedAt: Date.now()
    };
    if (!updates.trustLevel && updates.status) {
      updated.trustLevel = MemoryStore.deriveTrustLevel(updated);
    }

    this.entries.set(id, updated);
    this.addToIndexes(updated);
    this.notify(updated, 'UPDATE');
    return updated;
  }

  /**
   * Retrieves an entry by ID.
   */
  public getEntry(id: string): EngineeringMemoryEntry | undefined {
    return this.entries.get(id);
  }

  /**
   * Returns all stored entries.
   */
  public getAllEntries(): EngineeringMemoryEntry[] {
    return Array.from(this.entries.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  /**
   * Retrieves entries by memory type.
   */
  public getEntriesByType(type: EngineeringMemoryType): EngineeringMemoryEntry[] {
    const ids = this.typeIndex.get(type);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Retrieves entries referencing a file.
   */
  public getEntriesByFile(file: string): EngineeringMemoryEntry[] {
    const ids = this.fileIndex.get(file);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Retrieves entries referencing a symbol.
   */
  public getEntriesBySymbol(symbol: string): EngineeringMemoryEntry[] {
    const ids = this.symbolIndex.get(symbol);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Retrieves entries referencing a task.
   */
  public getEntriesByTask(taskId: string): EngineeringMemoryEntry[] {
    const ids = this.taskIndex.get(taskId);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Retrieves entries referencing a commit.
   */
  public getEntriesByCommit(commitHash: string): EngineeringMemoryEntry[] {
    const ids = this.commitIndex.get(commitHash);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Retrieves entries referencing an error code.
   */
  public getEntriesByErrorCode(errorCode: string): EngineeringMemoryEntry[] {
    const ids = this.errorCodeIndex.get(errorCode);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Marks an existing memory as SUPERSEDED by a newer entry.
   */
  public markSuperseded(oldId: string, newId: string, reason: string): boolean {
    const oldEntry = this.entries.get(oldId);
    if (!oldEntry) return false;

    this.updateEntry(oldId, {
      status: 'SUPERSEDED',
      supersededBy: newId,
      invalidationReason: reason
    });
    return true;
  }

  /**
   * Marks a memory status (e.g. STALE or INVALIDATED).
   */
  public markStatus(id: string, status: MemoryStatus, reason?: string): boolean {
    const entry = this.entries.get(id);
    if (!entry) return false;

    this.updateEntry(id, {
      status,
      invalidationReason: reason || entry.invalidationReason
    });
    return true;
  }

  /**
   * Retrieves entries by memory trust level.
   */
  public getEntriesByTrustLevel(trustLevel: MemoryTrustLevel): EngineeringMemoryEntry[] {
    const ids = this.trustLevelIndex.get(trustLevel);
    if (!ids) return [];
    return Array.from(ids).map(id => this.entries.get(id)!).filter(Boolean);
  }

  /**
   * Marks a memory trust level (e.g. VERIFIED, ADVISORY, STALE, INVALID).
   */
  public markTrustLevel(id: string, trustLevel: MemoryTrustLevel, reason?: string): boolean {
    const entry = this.entries.get(id);
    if (!entry) return false;

    this.updateEntry(id, {
      trustLevel,
      status: trustLevel === 'INVALID' ? 'INVALIDATED' : trustLevel === 'STALE' ? 'STALE' : entry.status,
      invalidationReason: reason || entry.invalidationReason
    });
    return true;
  }

  /**
   * Generates high-level statistical overview of engineering memory.
   */
  public getStatsSummary(): MemoryStatsSummary {
    const all = this.getAllEntries();
    const trustLevelCounts: Record<MemoryTrustLevel, number> = {
      VERIFIED: all.filter(m => (m.trustLevel || 'ADVISORY') === 'VERIFIED').length,
      ADVISORY: all.filter(m => (m.trustLevel || 'ADVISORY') === 'ADVISORY').length,
      STALE: all.filter(m => m.trustLevel === 'STALE' || m.status === 'STALE').length,
      INVALID: all.filter(m => m.trustLevel === 'INVALID' || m.status === 'INVALIDATED').length
    };

    return {
      totalMemories: all.length,
      activeMemories: all.filter(m => m.status === 'ACTIVE').length,
      staleMemories: all.filter(m => m.status === 'STALE' || m.trustLevel === 'STALE').length,
      supersededMemories: all.filter(m => m.status === 'SUPERSEDED').length,
      verifiedDecisions: all.filter(m => (m.type === 'DECISION' || m.type === 'ARCHITECTURAL_DECISION') && (m.epistemicStatus === 'KNOWN' || m.trustLevel === 'VERIFIED')).length,
      historicalFailures: all.filter(m => m.type === 'FAILURE').length,
      successfulRepairs: all.filter(m => m.type === 'REPAIR' && m.repairDetails?.outcome === 'SUCCESS').length,
      failedRepairs: all.filter(m => m.type === 'REPAIR' && m.repairDetails?.outcome !== 'SUCCESS').length,
      verificationsCount: all.filter(m => m.type === 'VERIFICATION' || m.type === 'VERIFICATION_RESULT').length,
      knownCount: all.filter(m => m.epistemicStatus === 'KNOWN').length,
      likelyCount: all.filter(m => m.epistemicStatus === 'LIKELY').length,
      unknownCount: all.filter(m => m.epistemicStatus === 'UNKNOWN').length,
      trustLevelCounts
    };
  }

  public clear(): void {
    this.entries.clear();
    this.fileIndex.clear();
    this.symbolIndex.clear();
    this.typeIndex.clear();
    this.commitIndex.clear();
    this.taskIndex.clear();
    this.errorCodeIndex.clear();
    this.statusIndex.clear();
    this.trustLevelIndex.clear();
  }

  public exportJSON(): string {
    return JSON.stringify(Array.from(this.entries.values()), null, 2);
  }

  public importJSON(jsonStr: string): boolean {
    try {
      const items: EngineeringMemoryEntry[] = JSON.parse(jsonStr);
      if (Array.isArray(items)) {
        this.clear();
        items.forEach(item => this.addEntry(item));
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  private addToIndexes(entry: EngineeringMemoryEntry): void {
    // Type Index
    if (!this.typeIndex.has(entry.type)) this.typeIndex.set(entry.type, new Set());
    this.typeIndex.get(entry.type)!.add(entry.id);

    // Status Index
    if (!this.statusIndex.has(entry.status)) this.statusIndex.set(entry.status, new Set());
    this.statusIndex.get(entry.status)!.add(entry.id);

    // Trust Level Index
    if (!this.trustLevelIndex.has(entry.trustLevel)) this.trustLevelIndex.set(entry.trustLevel, new Set());
    this.trustLevelIndex.get(entry.trustLevel)!.add(entry.id);

    // File Index
    entry.relatedFiles.forEach(f => {
      if (!this.fileIndex.has(f)) this.fileIndex.set(f, new Set());
      this.fileIndex.get(f)!.add(entry.id);
    });

    // Symbol Index
    entry.relatedSymbols.forEach(s => {
      if (!this.symbolIndex.has(s)) this.symbolIndex.set(s, new Set());
      this.symbolIndex.get(s)!.add(entry.id);
    });

    // Commit Index
    entry.relatedCommits.forEach(c => {
      if (!this.commitIndex.has(c)) this.commitIndex.set(c, new Set());
      this.commitIndex.get(c)!.add(entry.id);
    });

    // Task Index
    entry.relatedTasks.forEach(t => {
      if (!this.taskIndex.has(t)) this.taskIndex.set(t, new Set());
      this.taskIndex.get(t)!.add(entry.id);
    });

    // Error Code Index
    if (entry.failureDetails?.errorCode) {
      const err = entry.failureDetails.errorCode;
      if (!this.errorCodeIndex.has(err)) this.errorCodeIndex.set(err, new Set());
      this.errorCodeIndex.get(err)!.add(entry.id);
    }
  }

  private removeFromIndexes(entry: EngineeringMemoryEntry): void {
    this.typeIndex.get(entry.type)?.delete(entry.id);
    this.statusIndex.get(entry.status)?.delete(entry.id);
    this.trustLevelIndex.get(entry.trustLevel)?.delete(entry.id);
    entry.relatedFiles.forEach(f => this.fileIndex.get(f)?.delete(entry.id));
    entry.relatedSymbols.forEach(s => this.symbolIndex.get(s)?.delete(entry.id));
    entry.relatedCommits.forEach(c => this.commitIndex.get(c)?.delete(entry.id));
    entry.relatedTasks.forEach(t => this.taskIndex.get(t)?.delete(entry.id));
    if (entry.failureDetails?.errorCode) {
      this.errorCodeIndex.get(entry.failureDetails.errorCode)?.delete(entry.id);
    }
  }

  private seedDefaultProjectMemories(): void {
    const baseDecisions: EngineeringMemoryEntry[] = [
      {
        id: 'mem-arch-001',
        type: 'DECISION',
        projectId: 'godex-workspace',
        createdAt: Date.now() - 86400000 * 3,
        updatedAt: Date.now() - 86400000 * 3,
        source: 'SOURCE_CODE',
        relatedFiles: ['src/services/workspaceService.ts', 'src/App.tsx'],
        relatedSymbols: ['WorkspaceService', 'WorkspaceService.emitFileChange'],
        relatedCommits: ['a1b2c3d'],
        relatedTasks: ['TASK-CORE-1'],
        evidence: ['AST parser export verification', 'Single source of truth invariant verified'],
        confidence: 0.98,
        epistemicStatus: 'KNOWN',
        status: 'ACTIVE',
        content: 'Authoritative In-Memory Workspace acts as single source of truth for code editing and runtime pipelines.',
        reason: 'Prevents race conditions between editor tabs and execution sandbox.',
        version: 1,
        decisionDetails: {
          fact: 'WorkspaceService manages active buffer states and broadcasts SHA-256 fingerprint changes.',
          reason: 'Ensures deterministic file state across compiler, debugger, and live preview.',
          decision: 'All write operations must route through authoritative FileEditEngine.',
          evidenceSummary: 'src/services/workspaceService.ts exports authoritative state'
        },
        architecturalLayer: 'core'
      },
      {
        id: 'mem-arch-002',
        type: 'DECISION',
        projectId: 'godex-workspace',
        createdAt: Date.now() - 86400000 * 2,
        updatedAt: Date.now() - 86400000 * 2,
        source: 'SOURCE_CODE',
        relatedFiles: ['src/intelligence/contextPackBuilder.ts', 'src/intelligence/contextBudget.ts'],
        relatedSymbols: ['ContextPackBuilder', 'DEFAULT_CONTEXT_BUDGET'],
        relatedCommits: ['d4e5f6a'],
        relatedTasks: ['TASK-INTEL-2'],
        evidence: ['Token budget tests passed', 'Strict budget threshold enforcement verified'],
        confidence: 0.95,
        epistemicStatus: 'KNOWN',
        status: 'ACTIVE',
        content: 'Context Packs enforce token budgeting and relevance scoring rather than dumping entire repository into model prompts.',
        reason: 'Prevents context pollution and keeps token costs bounded.',
        version: 1,
        decisionDetails: {
          fact: 'Large codebases exceed model context limits and induce hallucinations when ungrounded.',
          reason: 'Bounded context packs with exact symbol extracts maximize reasoning precision.',
          decision: 'Assemble layered context packs bounded by 8000 token maximum.',
          evidenceSummary: 'Token budget tests in intelligence test suite'
        },
        architecturalLayer: 'services'
      },
      {
        id: 'mem-repair-001',
        type: 'REPAIR',
        projectId: 'godex-workspace',
        createdAt: Date.now() - 86400000 * 1,
        updatedAt: Date.now() - 86400000 * 1,
        source: 'DEBUGGER',
        relatedFiles: ['src/auth/authService.ts'],
        relatedSymbols: ['AuthService.refreshToken'],
        relatedCommits: ['f7g8h9i'],
        relatedTasks: ['TASK-DEBUG-12'],
        evidence: ['ExecutionResult-exec-901', 'Typecheck PASS exitCode: 0', 'Lint PASS exitCode: 0'],
        confidence: 0.99,
        epistemicStatus: 'KNOWN',
        status: 'ACTIVE',
        content: 'Repaired TS2304 missing import for TokenPayload in AuthService by injecting named import from tokenTypes.',
        reason: 'Type identifier was missing in module header.',
        version: 1,
        failureDetails: {
          errorCode: 'TS2304',
          errorMessage: 'Cannot find name "TokenPayload"',
          location: 'src/auth/authService.ts:18',
          rootCause: 'Missing named type import from tokenTypes.ts',
          classification: 'MISSING_IMPORT'
        },
        repairDetails: {
          errorCode: 'TS2304',
          attemptNumber: 1,
          strategy: 'Inject missing type import in header block',
          outcome: 'SUCCESS',
          proposedFix: "import { TokenPayload } from './tokenTypes';",
          touchedFiles: ['src/auth/authService.ts']
        },
        verificationDetails: {
          verificationType: 'TYPECHECK',
          passed: true,
          exitCode: 0,
          executionId: 'exec-901',
          summary: 'TypeScript typecheck passed with 0 errors.'
        },
        architecturalLayer: 'services'
      }
    ];

    baseDecisions.forEach(d => this.addEntry(d));
  }
}
