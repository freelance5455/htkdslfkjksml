/**
 * GODEX Phase 7 - Memory Invalidation & Conflict Resolution Engine
 * Handles staleness, symbol mutations, file deletions, and memory-vs-code conflict resolution.
 * Invariant: CURRENT VERIFIED CODE ALWAYS WINS OVER HISTORICAL MEMORY.
 */

import { EngineeringMemoryEntry } from './memoryTypes';
import { MemoryStore } from './memoryStore';
import { AstParser } from '../intelligence/astParser';

export interface InvalidationResult {
  invalidatedIds: string[];
  staleIds: string[];
  supersededIds: string[];
  reasons: Record<string, string>;
}

export class MemoryInvalidationEngine {
  /**
   * Generates a fast deterministic hash of file content.
   */
  public static hashContent(content: string): string {
    let hash = 0;
    for (let i = 0; i < content.length; i++) {
      const char = content.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    return 'h_' + Math.abs(hash).toString(16);
  }

  /**
   * Re-evaluates active memories after workspace file mutations.
   * Marks memories as STALE, SUPERSEDED, or INVALIDATED when referenced files, fingerprints, or symbols disappear.
   */
  public static evaluateFileMutations(
    currentFiles: Record<string, string>,
    store: MemoryStore = MemoryStore.getInstance()
  ): InvalidationResult {
    const result: InvalidationResult = {
      invalidatedIds: [],
      staleIds: [],
      supersededIds: [],
      reasons: {}
    };

    const allMemories = store.getAllEntries();
    const existingFileKeys = new Set(Object.keys(currentFiles));

    // Parse AST symbols for available files
    const fileSymbolsMap: Record<string, Set<string>> = {};
    const fileHashMap: Record<string, string> = {};

    Object.entries(currentFiles).forEach(([filePath, code]) => {
      fileHashMap[filePath] = MemoryInvalidationEngine.hashContent(code);
      try {
        const parsed = AstParser.parse(filePath, code);
        const symNames = new Set<string>();
        parsed.symbols.forEach(s => {
          symNames.add(s.name);
          if (s.name.includes('.')) {
            symNames.add(s.name.split('.')[0]);
          }
        });
        fileSymbolsMap[filePath] = symNames;
      } catch {
        fileSymbolsMap[filePath] = new Set();
      }
    });

    allMemories.forEach(mem => {
      // 0. Structural Integrity Check
      if (!mem.id || !mem.type || !mem.content) {
        const reason = 'Malformed or corrupted memory record';
        store.markTrustLevel(mem.id, 'INVALID', reason);
        result.invalidatedIds.push(mem.id);
        result.reasons[mem.id] = reason;
        return;
      }

      if (mem.status === 'SUPERSEDED' || mem.status === 'INVALIDATED' || mem.trustLevel === 'INVALID') {
        return;
      }

      // 1. Check if referenced files still exist
      if (mem.relatedFiles && mem.relatedFiles.length > 0) {
        const missingFiles = mem.relatedFiles.filter(rf => !existingFileKeys.has(rf));
        if (missingFiles.length === mem.relatedFiles.length) {
          // All related files have been deleted
          const reason = `All referenced files deleted: ${missingFiles.join(', ')}`;
          store.markTrustLevel(mem.id, 'INVALID', reason);
          result.invalidatedIds.push(mem.id);
          result.reasons[mem.id] = reason;
          return;
        } else if (missingFiles.length > 0) {
          // Partial deletion: mark as stale
          const reason = `Some referenced files deleted: ${missingFiles.join(', ')}`;
          store.markTrustLevel(mem.id, 'STALE', reason);
          result.staleIds.push(mem.id);
          result.reasons[mem.id] = reason;
          return;
        }
      }

      // 2. Check File Fingerprints if stored
      if (mem.fileFingerprints && Object.keys(mem.fileFingerprints).length > 0) {
        const fingerprintMismatches: string[] = [];
        Object.entries(mem.fileFingerprints).forEach(([filePath, recordedHash]) => {
          const currentHash = fileHashMap[filePath];
          if (currentHash && currentHash !== recordedHash) {
            fingerprintMismatches.push(filePath);
          }
        });

        if (fingerprintMismatches.length > 0 && mem.trustLevel === 'VERIFIED') {
          const reason = `File contents changed since verification: ${fingerprintMismatches.join(', ')}`;
          store.markTrustLevel(mem.id, 'STALE', reason);
          result.staleIds.push(mem.id);
          result.reasons[mem.id] = reason;
          return;
        }
      }

      // 3. Check if referenced symbols still exist in AST
      if (mem.relatedSymbols && mem.relatedSymbols.length > 0) {
        const missingSymbols: string[] = [];
        mem.relatedSymbols.forEach(sym => {
          let found = false;
          mem.relatedFiles.forEach(rf => {
            const symsInFile = fileSymbolsMap[rf];
            if (symsInFile && (symsInFile.has(sym) || Array.from(symsInFile).some(s => s.includes(sym) || sym.includes(s)))) {
              found = true;
            }
          });

          if (!found) {
            missingSymbols.push(sym);
          }
        });

        if (missingSymbols.length > 0) {
          const reason = `Referenced symbols no longer found in AST: ${missingSymbols.join(', ')}`;
          store.markTrustLevel(mem.id, 'STALE', reason);
          result.staleIds.push(mem.id);
          result.reasons[mem.id] = reason;
        }
      }
    });

    return result;
  }

  /**
   * Resolves conflicts between a historical memory entry and the current verified source code.
   * Invariant: Current source code always takes precedence.
   */
  public static resolveConflictWithCurrentCode(
    memory: EngineeringMemoryEntry,
    currentCodeFact: string,
    evidenceFile: string,
    store: MemoryStore = MemoryStore.getInstance()
  ): { currentTruthWins: boolean; resolutionMessage: string } {
    const reason = `Historical memory contradicted by verified current code in ${evidenceFile}: "${currentCodeFact}"`;
    store.markTrustLevel(memory.id, 'STALE', reason);

    return {
      currentTruthWins: true,
      resolutionMessage: `Memory [${memory.id}] marked STALE. Current verified project state in ${evidenceFile} takes precedence over historical memory.`
    };
  }

  /**
   * Audits and invalidates stale entries against current live workspace file fingerprints.
   */
  public static invalidateStaleEntriesByFingerprints(
    store: MemoryStore = MemoryStore.getInstance(),
    currentFiles: Record<string, string>
  ): { totalChecked: number; invalidatedCount: number; staleCount: number; details: string[] } {
    const res = this.evaluateFileMutations(currentFiles, store);
    const details = Object.entries(res.reasons).map(([id, r]) => `[${id}]: ${r}`);
    return {
      totalChecked: store.getAllEntries().length,
      invalidatedCount: res.invalidatedIds.length + res.staleIds.length,
      staleCount: res.staleIds.length,
      details
    };
  }
}
