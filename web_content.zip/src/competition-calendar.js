/**
 * Calendrier central de carrière CGD V117.
 * Jour 1 = jour de référence interne ; les compétitions conservent leurs créneaux historiques.
 * Les dates lunaires et AGD/FGD restent des données officielles à injecter :
 * le moteur ne fabrique jamais ces dates.
 */
import { LUNAR_WEEKDAYS, getLunarDate, isLunarWeekday } from './lunar-calendar.js';
export const WEEKDAYS = Object.freeze(['lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche']);
export const INTERGALACTIC_COMPETITIONS = Object.freeze({
  'intergalactique': { authority: 'AGD', calendarKey: 'coupeIntergalactiqueGalaxies', label: 'Coupe Intergalactique des galaxies', frequency: 3, roundOffsets: [0,2,4,6,8,10,12], windowEndOffset: 12 },
  'intergalactique-clubs': { authority: 'AGD', calendarKey: 'intergalactiqueClubs', label: 'Intergalactique des Clubs', frequency: 4, drawOffset: 0, roundOffsets: [2,6,10,14,18,21,24], windowEndOffset: 24 }
});
export const CLUB_CUP_SCHEDULE_RULE = Object.freeze({ period: 'regular-season', cadence: 'every-lunar-thursday', until: 'final', authority: 'FGD' });
export const LEAGUE_SCHEDULE_RULE = Object.freeze({ authority: 'FGD', weekday: 'samedi', cadence: 'weekly' });
const DAY = Object.freeze({ monday:1, tuesday:2, wednesday:3, thursday:4, friday:5, saturday:6, sunday:7 });
const GALACTIC_CUP_MATCHDAYS = Object.freeze([6,12,18]);

export function weekdayForSeasonDay(day) {
  if (!Number.isInteger(day) || day < 1) throw new Error('Jour de saison invalide');
  return WEEKDAYS[(day - 1) % 7];
}
export function leagueMatchdaySeasonDay(round) {
  if (!Number.isInteger(round) || round < 1 || round > 22) throw new Error('Journée de championnat invalide');
  return DAY.saturday + 7 * (round - 1);
}
function galacticCupSeasonDay(round) {
  const leagueDay = leagueMatchdaySeasonDay(GALACTIC_CUP_MATCHDAYS[round - 1]);
  return leagueDay - 3; // troisième jour lunaire de la même séquence
}
function eventKey(competitionId, round) { return `${competitionId}:R${round}`; }
function isIntegerDay(value) { return Number.isInteger(value) && value > 0; }

export function getClubCupThursday(state, roundNumber) {
  const date = state.calendar?.lunarThursdays?.[roundNumber - 1];
  if (!date) return null;
  if (String(date.weekday || '').toLocaleLowerCase('fr') !== 'jeudi' && !isLunarWeekday(date.weekday, 4)) throw new Error(`La date fournie pour le tour ${roundNumber} de la Coupe des Clubs n'est pas un jeudi lunaire`);
  if (!isIntegerDay(date.absoluteDay) || !Number.isInteger(date.lunarMonth) || !Number.isInteger(date.lunarDay)) throw new Error(`Date lunaire officielle incomplète pour le tour ${roundNumber}`);
  if (weekdayForSeasonDay(date.absoluteDay) !== 'jeudi') throw new Error(`Le jour ${date.absoluteDay} ne correspond pas à un jeudi dans le calendrier de saison (jour 1 = lundi)`);
  return { ...date };
}

export function getOfficialRegularSeasonEndDate(state) {
  const date = state.calendar?.officialCalendars?.FGD?.regularSeasonEnd;
  if (!date) return null;
  if (!isIntegerDay(date.absoluteDay) || date.phase !== 'end-of-regular-season') throw new Error('La fin de saison régulière doit être datée officiellement par la FGD');
  return { ...date, authority: 'FGD' };
}
export function getOfficialEndSeasonDate(state, competitionId) {
  const rule = INTERGALACTIC_COMPETITIONS[competitionId];
  if (!rule) throw new Error(`Compétition intergalactique inconnue : ${competitionId}`);
  if(Number(state.season||1)%rule.frequency!==0)return null;
  const date = state.calendar?.officialCalendars?.AGD?.[rule.calendarKey];
  if (!date) return null;
  if (!isIntegerDay(date.absoluteDay) || date.phase !== 'after-regular-season') throw new Error(`La date ${rule.label} doit provenir du calendrier AGD et être située après la saison régulière`);
  const fgdEnd = getOfficialRegularSeasonEndDate(state);
  if (!fgdEnd) throw new Error('La date officielle de fin de saison régulière FGD doit être connue avant les compétitions AGD');
  if (date.absoluteDay <= fgdEnd.absoluteDay) throw new Error(`${rule.label} doit se jouer après la fin officielle de la saison régulière`);
  return { ...date, authority: 'AGD', competitionId, label: rule.label };
}

/** Chaque compétition a son jour : deux événements ne peuvent jamais tomber le même jour. */
export function validateCompetitionSpacing(events) {
  const ordered = (events || []).filter(event => isIntegerDay(event.absoluteDay)).sort((a,b) => a.absoluteDay-b.absoluteDay || String(a.competitionId).localeCompare(String(b.competitionId)));
  const conflicts = [];
  for (let i=1;i<ordered.length;i++) {
    const previous=ordered[i-1], current=ordered[i];
    const gap=current.absoluteDay-previous.absoluteDay;
    if (gap < 1) conflicts.push({ previous, current, minimumGapDays: 0, actualGapDays: gap });
  }
  return { valid: conflicts.length===0, conflicts };
}

function pushEvent(events, event) {
  if (!event || !isIntegerDay(event.absoluteDay)) return;
  events.push({ ...event, id: event.id || (Number.isInteger(event.round)?eventKey(event.competitionId,event.round):`${event.competitionId}:D${event.absoluteDay}`) });
}
function isDayFree(day, events) { return events.every(e => e.absoluteDay !== day); }
/** Jour de match propre à chaque compétition (Le jour de référence reste sans match). */
export const COMPETITION_MATCH_DAYS = Object.freeze({
  'championnat': { weekday: 'samedi', number: 6, authority: 'FGD' },
  'champions-league': { weekday: 'mardi', number: 2, authority: 'FGD' },
  'coupe-galactique': { weekday: 'mercredi', number: 3, authority: 'FGD' },
  'coupe-des-clubs': { weekday: 'jeudi', number: 4, authority: 'FGD' },
  'coupe-federal': { weekday: 'dimanche', number: 7, authority: 'AGD' }
});
function nextWeekdaySlot(weekdayNumber, startDay, events, maxDay) {
  let day = Math.max(weekdayNumber, startDay);
  const offset = ((day-weekdayNumber)%7+7)%7;
  day += (7-offset)%7;
  for (;day<=maxDay;day+=7) if (isDayFree(day,events)) return day;
  return null;
}
function fixtureGroups(fixtures, competitionId, season) {
  const rows=fixtures.filter(f=>f.season===season && f.status!=='cancelled' && (competitionId ? f.competitionId===competitionId : !f.competitionId));
  const map=new Map();
  for(const f of rows){const key=competitionId?`${f.competitionId}:${f.round}`:`championnat:${f.round}`;if(!map.has(key))map.set(key,[]);map.get(key).push(f);}
  return [...map.entries()].map(([key,items])=>({key,fixtures:items,round:items[0].round})).sort((a,b)=>a.round-b.round);
}

/** Reconstruit les dates des événements connus sans toucher aux résultats déjà joués. */
export function scheduleCompetitionCalendar(state) {
  state.calendar ??= {};
  state.calendar.fixtures ??=[];
  const fixtures=state.calendar.fixtures;
  const events=[];
  const leagueGroups=fixtureGroups(fixtures,null,state.season);
  for(const group of leagueGroups){
    const day=leagueMatchdaySeasonDay(group.round);
    for(const f of group.fixtures){f.scheduledDay=day;f.scheduledWeekday='samedi';f.scheduleAuthority='FGD';}
    pushEvent(events,{competitionId:'championnat',competitionName:'Championnats FGD',authority:'FGD',kind:'league-matchday',round:group.round,absoluteDay:day,weekday:'samedi',fixtureIds:group.fixtures.map(f=>f.id)});
  }
  // Coupe des Clubs : créneau fixe du jeudi lunaire officiel.
  for(const group of fixtureGroups(fixtures,'coupe-des-clubs',state.season)){
    const date=getClubCupThursday(state,group.round);
    for(const f of group.fixtures){f.scheduledDate=date;f.scheduledDay=date?.absoluteDay??null;f.scheduledWeekday='jeudi';f.dateStatus=date?'official-date-assigned':'awaiting-official-lunar-calendar';f.scheduleAuthority='FGD';}
    if(date)pushEvent(events,{competitionId:'coupe-des-clubs',competitionName:'Coupe des Clubs',authority:'FGD',kind:'cup-round',round:group.round,absoluteDay:date.absoluteDay,weekday:'jeudi',fixtureIds:group.fixtures.map(f=>f.id),lunarMonth:date.lunarMonth,lunarDay:date.lunarDay});
  }
  // Coupe Galactique : les trois dates historiques restent liées aux J6, J12 et J18,
  // mais sont placées le mercredi, jamais le même jour que le championnat.
  for(const group of fixtureGroups(fixtures,'coupe-galactique',state.season)){
    const day=galacticCupSeasonDay(group.round);
    for(const f of group.fixtures){f.scheduledDay=day;f.scheduledWeekday='mercredi';f.scheduleAuthority='FGD';}
    pushEvent(events,{competitionId:'coupe-galactique',competitionName:'Coupe Galactique',authority:'FGD',kind:'cup-round',round:group.round,absoluteDay:day,weekday:'mercredi',fixtureIds:group.fixtures.map(f=>f.id),linkedLeagueMatchday:GALACTIC_CUP_MATCHDAYS[group.round-1]});
  }
  // Coupe Lunaire AGD : calendrier annuel V116, mois 12, trois créneaux hebdomadaires internes 342/349/356.
  for(const group of fixtureGroups(fixtures,'coupe-lunaire',state.season)){
    const day=342+7*(group.round-1);
    for(const f of group.fixtures){f.scheduledDay=day;f.scheduledWeekday=weekdayForSeasonDay(day);f.dateStatus='V116-month-12-official-window';f.scheduleAuthority='AGD';}
    pushEvent(events,{competitionId:'coupe-lunaire',competitionName:'Coupe Lunaire — AGD',authority:'AGD',kind:'lunar-cup-round',round:group.round,absoluteDay:day,weekday:weekdayForSeasonDay(day),fixtureIds:group.fixtures.map(f=>f.id),lunarMonth:12,legacySeasonOffset:day});
  }
  // Coupes FGD : protéger d'abord tous les créneaux déjà attribués. Ainsi, lorsqu'un tour
  // suivant est créé, il ne peut pas voler la date d'une phase de groupes déjà programmée.
  const maxLeagueDay=leagueGroups.length?leagueMatchdaySeasonDay(Math.max(...leagueGroups.map(g=>g.round))):154;
  const fixedEvents=[...events];
  const pendingCupGroups=[];
  for(const competitionId of ['coupe-federal','champions-league']){
    for(const group of fixtureGroups(fixtures,competitionId,state.season)){
      const dates=[...new Set(group.fixtures.map(f=>f.scheduledDay).filter(isIntegerDay))];
      const existing=dates.length===1&&group.fixtures.every(f=>isIntegerDay(f.scheduledDay))?dates[0]:null;
      const hasPlayed=group.fixtures.some(f=>f.status==='played');
      const matchDay=COMPETITION_MATCH_DAYS[competitionId];
      if(existing&&(hasPlayed||(isDayFree(existing,fixedEvents)&&weekdayForSeasonDay(existing)===matchDay.weekday))){
        const event={competitionId,competitionName:group.fixtures[0].competitionName||competitionId,authority:matchDay.authority,kind:'cup-round',round:group.round,absoluteDay:existing,weekday:weekdayForSeasonDay(existing),fixtureIds:group.fixtures.map(f=>f.id)};
        pushEvent(events,event);fixedEvents.push(event);
        for(const f of group.fixtures){f.scheduledWeekday=weekdayForSeasonDay(existing);f.scheduleAuthority=matchDay.authority;f.dateStatus='scheduled-by-central-calendar';}
      }else pendingCupGroups.push({competitionId,group});
    }
  }
  for(const {competitionId,group} of pendingCupGroups){
    const matchDay=COMPETITION_MATCH_DAYS[competitionId];
    const day=nextWeekdaySlot(matchDay.number,matchDay.number,fixedEvents,maxLeagueDay);
    if(day===null){for(const f of group.fixtures){f.scheduledDay=null;f.dateStatus='awaiting-free-slot';}continue;}
    for(const f of group.fixtures){f.scheduledDay=day;f.scheduledWeekday=matchDay.weekday;f.scheduleAuthority=matchDay.authority;f.dateStatus='scheduled-by-central-calendar';}
    const event={competitionId,competitionName:group.fixtures[0].competitionName||competitionId,authority:matchDay.authority,kind:'cup-round',round:group.round,absoluteDay:day,weekday:matchDay.weekday,fixtureIds:group.fixtures.map(f=>f.id)};
    pushEvent(events,event);fixedEvents.push(event);
  }
  // Les compétitions AGD se jouent après la saison régulière. La date officielle est
  // leur date d'ouverture ; les journées/phases suivantes sont étalées avec un jour libre.
  for(const competitionId of Object.keys(INTERGALACTIC_COMPETITIONS)){
    const rule=INTERGALACTIC_COMPETITIONS[competitionId];
    const date=getOfficialEndSeasonDate(state,competitionId);
    const rows=fixtures.filter(f=>f.competitionId===competitionId && f.status!=='cancelled');
    const groups=fixtureGroups(fixtures,competitionId,state.season);
    if(date){
      if(!rows.length)pushEvent(events,{competitionId,competitionName:rule.label,authority:'AGD',kind:'reserved-intergalactic-window',absoluteDay:date.absoluteDay,weekday:weekdayForSeasonDay(date.absoluteDay),fixtureIds:[]});
      if(competitionId==='intergalactique-clubs'&&rows.length)pushEvent(events,{competitionId,competitionName:rule.label,authority:'AGD',kind:'intergalactic-draw',absoluteDay:date.absoluteDay,weekday:weekdayForSeasonDay(date.absoluteDay),fixtureIds:[]});
      for(const group of groups){
        const day=date.absoluteDay+Number(rule.roundOffsets[group.round-1]??(2*(group.round-1)));
        for(const f of group.fixtures){f.scheduledDay=day;f.scheduledWeekday=weekdayForSeasonDay(day);f.dateStatus='official-agd-window';f.scheduleAuthority='AGD';}
        pushEvent(events,{competitionId,competitionName:rule.label,authority:'AGD',kind:'intergalactic-round',round:group.round,absoluteDay:day,weekday:weekdayForSeasonDay(day),fixtureIds:group.fixtures.map(f=>f.id)});
      }
    }else for(const f of rows){f.scheduledDay=null;f.dateStatus='awaiting-official-agd-calendar';f.scheduleAuthority='AGD';}
  }
  events.sort((a,b)=>a.absoluteDay-b.absoluteDay);
  const spacing=validateCompetitionSpacing(events);
  const clubConflicts=[];
  const byClub=new Map();
  for(const f of fixtures){if(!isIntegerDay(f.scheduledDay)||f.status==='cancelled')continue;for(const clubId of [f.home,f.away]){if(!clubId)continue;if(!byClub.has(clubId))byClub.set(clubId,[]);byClub.get(clubId).push(f);}}
  for(const [clubId,rows] of byClub){rows.sort((a,b)=>a.scheduledDay-b.scheduledDay);for(let i=1;i<rows.length;i++){const gap=rows[i].scheduledDay-rows[i-1].scheduledDay;if(gap<1)clubConflicts.push({clubId,previousFixtureId:rows[i-1].id,currentFixtureId:rows[i].id,actualGapDays:gap});}}
  state.calendar.competitionEvents=events;
  state.calendar.scheduleValidation={valid:spacing.valid&&clubConflicts.length===0,spacing,clubConflicts,generatedAtVersion:'V117-calendar-1.6'};
  return {events,validation:state.calendar.scheduleValidation};
}

/** Contrôle si la saison peut démarrer sans risquer d'omettre une compétition. */
export function getCalendarReadiness(state) {
  const missingCompetitionEngines=(state.competitions||[]).filter(c=>c.calendarEngineReady!==true).map(c=>({id:c.id,name:c.name,authority:c.authority}));
  const missingLunarThursdays=Math.max(0,7-(state.calendar?.lunarThursdays?.length||0));
  const regularSeasonEndKnown=Boolean(state.calendar?.officialCalendars?.FGD?.regularSeasonEnd);
  const agdDates=state.calendar?.officialCalendars?.AGD||{};
  const missingAgdDates=Object.entries(INTERGALACTIC_COMPETITIONS).filter(([id,rule])=>Number(state.season||1)%rule.frequency===0&&!agdDates[rule.calendarKey]).map(([,rule])=>rule.calendarKey);
  const calendarConflicts=state.calendar?.scheduleValidation?.valid===false;
  const unscheduledFixtures=(state.calendar?.fixtures||[]).filter(f=>f.status==='scheduled'&&f.competitionId&&!isIntegerDay(f.scheduledDay)).map(f=>f.id);
  const missingFgdEndDate=!regularSeasonEndKnown;
  return { canStartRegularSeason:missingCompetitionEngines.length===0&&missingLunarThursdays===0&&!missingFgdEndDate&&missingAgdDates.length===0&&!calendarConflicts&&unscheduledFixtures.length===0, missingCompetitionEngines, missingLunarThursdays, regularSeasonEndKnown, missingFgdEndDate, missingAgdDates, calendarConflicts, unscheduledFixtures, endSeasonReady:regularSeasonEndKnown&&missingAgdDates.length===0 };
}

/** Injecte les jeudis issus du calendrier lunaire officiel et recalcule tout le calendrier. */
export function setOfficialLunarThursdays(state, dates) {
  if(!Array.isArray(dates))throw new Error('La liste des jeudis lunaires doit être un tableau');
  const normalized=dates.map((date,index)=>{
    if(String(date.weekday||'').toLocaleLowerCase('fr')!=='jeudi' && !isLunarWeekday(date.weekday,4))throw new Error(`L'entrée ${index+1} n'est pas un jeudi`);
    if(![date.absoluteDay,date.lunarMonth,date.lunarDay].every(Number.isInteger)||date.absoluteDay<1)throw new Error(`L'entrée lunaire ${index+1} est incomplète`);
    if(weekdayForSeasonDay(date.absoluteDay)!=='jeudi')throw new Error(`L'entrée ${index+1} ne correspond pas au jeudi attendu (jour 1 = lundi)`);
    return {...date};
  });
  for(let i=1;i<normalized.length;i++){const gap=normalized[i].absoluteDay-normalized[i-1].absoluteDay;if(gap!==7)throw new Error('La Coupe des Clubs suit chaque jeudi lunaire : les dates successives doivent être espacées de sept jours');}
  state.calendar.lunarThursdays=normalized;
  scheduleCompetitionCalendar(state);
  return normalized.length;
}

/** Enregistre la borne de fin de saison transmise par la FGD. */
export function setOfficialRegularSeasonEndDate(state,date){
  if(!date||!isIntegerDay(date.absoluteDay)||date.phase!=='end-of-regular-season')throw new Error('La date doit être la date officielle de fin de saison régulière FGD');
  const lastLeagueDay=leagueMatchdaySeasonDay(22);
  if(date.absoluteDay<lastLeagueDay)throw new Error('La fin officielle de saison ne peut précéder la dernière journée du championnat');
  state.calendar.officialCalendars??={};state.calendar.officialCalendars.FGD??={};
  state.calendar.officialCalendars.FGD.regularSeasonEnd={...date,authority:'FGD'};
  scheduleCompetitionCalendar(state);
  return state.calendar.officialCalendars.FGD.regularSeasonEnd;
}

/** Les deux compétitions intergalactiques relèvent de l'AGD, pas de la FGD. */
export function setOfficialIntergalacticDate(state,competitionId,date){
  const rule=INTERGALACTIC_COMPETITIONS[competitionId];
  if(!rule)throw new Error(`Compétition intergalactique inconnue : ${competitionId}`);
  if(!date||!isIntegerDay(date.absoluteDay)||date.phase!=='after-regular-season')throw new Error('La date doit provenir du calendrier AGD et être située après la saison régulière');
  const fgdEnd=getOfficialRegularSeasonEndDate(state);
  if(!fgdEnd)throw new Error('Il faut d’abord enregistrer la date officielle de fin de saison FGD');
  if(date.absoluteDay-fgdEnd.absoluteDay<2)throw new Error('La compétition AGD doit se jouer après la fin officielle de la saison régulière FGD, avec un jour complet d’intervalle');
  const otherEntry=Object.entries(INTERGALACTIC_COMPETITIONS).find(([id,other])=>id!==competitionId&&state.calendar.officialCalendars?.AGD?.[other.calendarKey]&&Number(state.season||1)%other.frequency===0);
  const otherDate=otherEntry?state.calendar.officialCalendars.AGD[otherEntry[1].calendarKey]:null;
  if(otherDate){const otherRule=Object.values(INTERGALACTIC_COMPETITIONS).find(x=>x.calendarKey===otherEntry[1].calendarKey);const earlierIsThis=date.absoluteDay<otherDate.absoluteDay;const earlierRule=earlierIsThis?rule:otherRule;const earlierDay=Math.min(date.absoluteDay,otherDate.absoluteDay),laterDay=Math.max(date.absoluteDay,otherDate.absoluteDay);const minimumWindowGap=Number(earlierRule.windowEndOffset||0)+2;if(laterDay-earlierDay<minimumWindowGap)throw new Error('Les fenêtres des deux compétitions AGD se chevauchent : prévoir toute la durée de la première édition et un jour complet de repos');}
  state.calendar.officialCalendars??={};state.calendar.officialCalendars.AGD??={};
  state.calendar.officialCalendars.AGD[rule.calendarKey]={...date,authority:'AGD',competitionId};
  scheduleCompetitionCalendar(state);
  return {authority:'AGD',competitionId,...date};
}
