import { recordResult } from './calendar.js';
import { simulateBoardMatch } from './board-simulation.js';
import { FEDERAL_CUP_ID, recordFederalCupResult } from './federal-cup.js';
import { GALACTIC_CUP_ID, recordGalacticCupResult, resolveGalacticCupDraw } from './galactic-cup.js';
import { CLUB_CUP_ID, recordClubCupResult } from './club-cup.js';
import { CHAMPIONS_LEAGUE_ID, recordChampionsLeagueResult } from './champions-league.js';
import { getCalendarReadiness } from './competition-calendar.js';
import { LUNAR_CUP_ID, recordLunarCupResult, resolveLunarCupDraw } from './lunar-cup.js';
import { INTERGALACTIC_CUP_ID, recordIntergalacticCupResult, simulateIntergalacticFixture } from './intergalactic-cup.js';
import { INTERGALACTIC_CLUBS_ID, recordIntergalacticClubsResult, simulateIntergalacticClubsFixture } from './intergalactic-clubs.js';
import { closeDameOrSeason, getFixtureDamiste } from './dame-or.js';
import { getStaffMatchPreparationBonus } from './manager-consequences.js';
import { getTacticBonus } from './tactics.js';

function teamStrength(club) {
  const players = club.damistes ?? [];
  if (players.length !== 2) throw new Error(`Effectif invalide pour ${club.name}: deux damistes requis`);
  return players.reduce((sum, p) => sum + (Number(p.level) || 0) * .72 + (Number(p.form) || 0) * .28, 0) / 2;
}
function fixturePlayerStrength(club, fixture, side) {
  const player = getFixtureDamiste(club, fixture, side);
  return (Number(player.level) || 0) * .72 + (Number(player.form) || 0) * .28;
}
function findClub(state, id) {
  const club = state.divisions.flatMap(d => d.clubs).find(c => c.id === id);
  if (!club) throw new Error(`Club introuvable: ${id}`);
  return club;
}

// Simulation stable : le même état et le même identifiant de rencontre donnent le même score.
export function simulateFixture(state, fixtureId, { force = false, arena = null } = {}) {
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId);
  if (!fixture) throw new Error('Rencontre introuvable');
  if (fixture.status === 'played' || state.calendar.processedFixtureIds.includes(fixtureId)) return false;
  if (fixture.competitionId === GALACTIC_CUP_ID && Number(state.day || 1) < Number(fixture.scheduledMatchday || 1)) return false;
  if(fixture.competitionId===LUNAR_CUP_ID){
    if(fixture.scheduledDay&&Number(state.calendar.currentDay||1)<Number(fixture.scheduledDay))return false;
    const match=simulateBoardMatch({fixtureId,season:fixture.season??state.season,arena:fixture.arenaId||'terrestrial',homeStrength:60,awayStrength:60});
    const winnerId=match.winnerSide===1?fixture.home:match.winnerSide===-1?fixture.away:resolveLunarCupDraw(fixture);
    let score=match.score;if(score[0]===score[1])score=winnerId===fixture.home?[1,0]:[0,1];
    return recordLunarCupResult(state,fixtureId,score[0],score[1],{winnerId,matchDetails:{...match,mode:'automatic'}}).accepted;
  }
  if(fixture.competitionId===INTERGALACTIC_CUP_ID)return simulateIntergalacticFixture(state,fixtureId);
  if(fixture.competitionId===INTERGALACTIC_CLUBS_ID)return simulateIntergalacticClubsFixture(state,fixtureId);
  const home = findClub(state, fixture.home), away = findClub(state, fixture.away);
  let homeStrength = fixturePlayerStrength(home, fixture, 'home'), awayStrength = fixturePlayerStrength(away, fixture, 'away');
  let staffPreparationBonus = 0;
  let tacticBonus = 0;
  if (home.id === state.userClubId || away.id === state.userClubId) {
    staffPreparationBonus = getStaffMatchPreparationBonus(state);
    if (home.id === state.userClubId) homeStrength += staffPreparationBonus;
    else awayStrength += staffPreparationBonus;
  }
  if (home.id === state.userClubId || away.id === state.userClubId) {
    const mine = home.id === state.userClubId;
    const ownForm = Number(getFixtureDamiste(mine ? home : away, fixture, mine ? 'home' : 'away').form) || 0;
    tacticBonus = getTacticBonus(state, mine ? homeStrength : awayStrength, mine ? awayStrength : homeStrength, ownForm);
    if (mine) homeStrength += tacticBonus; else awayStrength += tacticBonus;
  }
  const selectedArena = arena || fixture.arenaId || home.arenaId || 'terrestrial';
  const match = simulateBoardMatch({ fixtureId, season: fixture.season ?? state.season, arena: selectedArena, homeStrength, awayStrength });
  const details = { ...match, homeStrength, awayStrength, staffPreparationBonus, tacticBonus, homeClub: home.id, awayClub: away.id, mode: 'automatic' };
  if (fixture.competitionId === CHAMPIONS_LEAGUE_ID) {
    let winnerId = null;
    if (fixture.round >= 7) winnerId = match.winnerSide === 1 ? fixture.home : match.winnerSide === -1 ? fixture.away : null;
    return recordChampionsLeagueResult(state, fixtureId, match.score[0], match.score[1], { winnerId, matchDetails: details }).accepted;
  }
  if (fixture.competitionId === GALACTIC_CUP_ID) {
    const winnerId = match.winnerSide === 1 ? fixture.home : match.winnerSide === -1 ? fixture.away : resolveGalacticCupDraw(fixture);
    const accepted = recordGalacticCupResult(state, fixtureId, match.score[0], match.score[1], { winnerId, matchDetails: details }).accepted;
    return accepted;
  }
  if (fixture.competitionId === CLUB_CUP_ID) {
    let winnerId = match.winnerSide === 1 ? fixture.home : match.winnerSide === -1 ? fixture.away : null;
    let penalties = null;
    if (!winnerId) { const seed=[...fixture.id].reduce((n,ch)=>(Math.imul(n^ch.charCodeAt(0),16777619)>>>0),2166136261); const homeWins=(seed/4294967296)<Math.max(.2,Math.min(.8,.5+(homeStrength-awayStrength)/250)); winnerId=homeWins?fixture.home:fixture.away; penalties=homeWins?[5,4]:[4,5]; }
    const homeWon=winnerId===fixture.home;
    return recordClubCupResult(state,fixtureId,homeWon?1:0,homeWon?0:1,{winnerId,penalties,matchDetails:details}).accepted;
  }
  if (fixture.competitionId === FEDERAL_CUP_ID) {
    let winnerId = match.winnerSide === 1 ? fixture.home : match.winnerSide === -1 ? fixture.away : null;
    let penalties = null;
    if (!winnerId) {
      const seed = [...`${fixture.id}|${homeStrength}|${awayStrength}`].reduce((n, ch) => (Math.imul(n ^ ch.charCodeAt(0), 16777619) >>> 0), 2166136261);
      const homeChance = Math.max(0.2, Math.min(0.8, 0.5 + (homeStrength - awayStrength) / 250));
      const homeWon = (seed / 4294967296) < homeChance;
      winnerId = homeWon ? fixture.home : fixture.away;
      penalties = homeWon ? [5, 4] : [4, 5];
    }
    const homeWon = winnerId === fixture.home;
    const accepted = recordFederalCupResult(state, fixtureId, homeWon ? 1 : 0, homeWon ? 0 : 1, { winnerId, penalties, matchDetails: details }).accepted;
    return accepted;
  }
  const accepted = recordResult(state, fixtureId, match.score[0], match.score[1], details);
  if (accepted) fixture.matchDetails = details;
  return accepted;
}


/** Avance la carrière jusqu'au prochain événement officiel du calendrier central.
 * Les matchs des autres clubs sont simulés automatiquement ; celui du club dirigé
 * reste à jouer et bloque l'avance tant qu'il n'a pas été résolu.
 */
export function advanceToNextCalendarEvent(state, { userClubId = state.userClubId, simulateUser = false } = {}) {
  const readiness=getCalendarReadiness(state);
  if(!readiness.canStartRegularSeason)return {event:null,simulated:[],userFixture:null,complete:false,blockedByIncompleteSeasonSetup:true,readiness};
  const events = [...(state.calendar.competitionEvents || [])].sort((a,b)=>a.absoluteDay-b.absoluteDay);
  const pendingAtCurrent = events.find(e=>e.absoluteDay===Number(state.calendar.currentDay||1) && (e.kind==='reserved-intergalactic-window'||e.fixtureIds?.some(id=>state.calendar.fixtures.find(f=>f.id===id)?.status!=='played')));
  const event = pendingAtCurrent || events.find(e=>e.absoluteDay>Number(state.calendar.currentDay||1));
  if(!event){if(Number(state.calendar.currentDay||1)>=153&&!readiness.endSeasonReady)return {event:null,simulated:[],userFixture:null,complete:false,blockedByMissingFederationDates:true,readiness};const fgdEnd=Number(state.calendar.officialCalendars?.FGD?.regularSeasonEnd?.absoluteDay||Infinity);const pendingSeasonFixtures=state.calendar.fixtures.some(f=>f.season===state.season&&f.status!=='played'&&f.status!=='cancelled');if(Number(state.calendar.currentDay||1)>=fgdEnd&&!pendingSeasonFixtures){const winnerId=closeDameOrSeason(state,state.season);return {event:null,simulated:[],userFixture:null,complete:true,dameOrCeremony:true,winnerId,message:winnerId?`Cérémonie de la Dame d’Or : ${winnerId} est sacré(e) pour la saison ${state.season}.`:'Saison clôturée : aucun damiste n’a disputé de rencontre homologuée pour la Dame d’Or.'};}return {event:null,simulated:[],userFixture:null,complete:true,message:'Aucun autre événement programmé.'};}
  if(event.kind==='reserved-intergalactic-window'&&readiness.missingAgdDates.length)return {event,simulated:[],userFixture:null,complete:false,blockedByMissingFederationDates:true,readiness};
  if(event.kind==='reserved-intergalactic-window'&&!(event.fixtureIds||[]).length){
    const competition=state.competitions.find(c=>c.id===event.competitionId);
    if(competition?.status==='blocked-insufficient-eligible-clubs')return {event,simulated:[],userFixture:null,complete:false,blockedByInsufficientEligibleClubs:true,eligibleCount:competition.eligibleCount,requiredCount:32,message:`L'AGD ne peut pas lancer l'Intergalactique des Clubs : ${competition.eligibleCount||0} clubs éligibles sur 32. Aucun club fictif ne sera ajouté.`};
    return {event,simulated:[],userFixture:null,complete:false,blockedByUnimplementedCompetition:true,message:'La date AGD est réservée, mais le moteur ou les participants de cette compétition ne sont pas prêts.'};
  }
  state.calendar.currentDay=event.absoluteDay;
  state.calendar.currentDate={season:state.season,seasonDay:event.absoluteDay,weekday:event.weekday};
  const simulated=[];let userFixture=null;
  for(const id of event.fixtureIds||[]){
    const fixture=state.calendar.fixtures.find(f=>f.id===id);
    if(!fixture||fixture.status==='played')continue;
    const isUser=fixture.competitionId===LUNAR_CUP_ID?(fixture.home===state.userGalaxyId||fixture.away===state.userGalaxyId):fixture.competitionId===INTERGALACTIC_CUP_ID?(fixture.home===state.userNationId||fixture.away===state.userNationId):(fixture.home===userClubId||fixture.away===userClubId);
    if(isUser&&!simulateUser){userFixture=fixture;continue;}
    if(simulateFixture(state,id))simulated.push(id);
  }
  const unresolved=(event.fixtureIds||[]).map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(f=>f&&f.status!=='played');
  if(event.competitionId==='championnat'&&!unresolved.length)state.day=Math.max(Number(state.day||1),Number(event.round||0)+1);
  return {event,simulated,userFixture,complete:unresolved.length===0,blockedByUserMatch:Boolean(userFixture),unresolved:unresolved.map(f=>f.id)};
}

export function getCurrentMatchday(state) {
  const active = state.divisions.filter(d => d.status === 'active');
  // Les coupes ont leur propre numérotation de tours : elles ne doivent jamais bloquer les journées de championnat.
  const pending = state.calendar.fixtures.filter(f => !f.competitionId && f.status !== 'played' && f.season === state.season);
  if (!pending.length) return null;
  const round = Math.min(...pending.map(f => f.round));
  const fixtures = pending.filter(f => f.round === round && active.some(d => d.id === f.divisionId));
  return fixtures.length ? { season: state.season, round, fixtures } : null;
}

// Tous les matchs du jour sont simulés, sauf celui du club de l'utilisateur si demandé.
export function simulateNextMatchday(state, { userClubId = state.userClubId, simulateUser = false } = {}) {
  const matchday = getCurrentMatchday(state);
  if (!matchday) return { round: null, simulated: [], userFixture: null, complete: true };
  const simulated = [];
  let userFixture = null;
  for (const fixture of matchday.fixtures) {
    const isUserMatch = fixture.home === userClubId || fixture.away === userClubId;
    if (isUserMatch && !simulateUser) { userFixture = fixture; continue; }
    if (simulateFixture(state, fixture.id)) simulated.push(fixture.id);
  }
  const unresolved = matchday.fixtures.filter(f => f.status !== 'played');
  if (!unresolved.length) state.day = matchday.round + 1;
  return { round: matchday.round, simulated, userFixture, complete: unresolved.length === 0 };
}

export function simulateUserMatch(state, fixtureId) {
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId);
  if (!fixture || (fixture.home !== state.userClubId && fixture.away !== state.userClubId)) throw new Error('Cette rencontre ne concerne pas le club dirigé');
  const accepted = simulateFixture(state, fixtureId);
  const stillPending = state.calendar.fixtures.some(f => !f.competitionId && f.season === state.season && f.round === fixture.round && f.status !== 'played');
  if (!stillPending) state.day = fixture.round + 1;
  return accepted;
}

/** Simule le tour courant de la Coupe Galactique ; le match du club dirigé peut rester jouable. */
export function simulateGalacticCupRound(state, { userClubId = state.userClubId, simulateUser = false } = {}) {
  const cup = state.competitions.find(c => c.id === GALACTIC_CUP_ID);
  const round = cup?.rounds?.at(-1);
  if (!round || cup.status !== 'in-progress') return { round: null, simulated: [], userFixture: null, complete: true };
  const fixtures = round.fixtureIds.map(id => state.calendar.fixtures.find(f => f.id === id)).filter(Boolean);
  const requiredDay = Math.min(...fixtures.map(f => Number(f.scheduledDay || Number.MAX_SAFE_INTEGER)));
  if (!Number.isFinite(requiredDay) || requiredDay===Number.MAX_SAFE_INTEGER || Number(state.calendar.currentDay || 1) < requiredDay) return { round: round.number, roundLabel: round.label, simulated: [], userFixture: null, complete: false, available: false, requiredSeasonDay: requiredDay===Number.MAX_SAFE_INTEGER?null:requiredDay, cupStatus: cup.status };
  const simulated = []; let userFixture = null;
  for (const fixture of fixtures) {
    const isUserMatch = fixture.home === userClubId || fixture.away === userClubId;
    if (isUserMatch && !simulateUser) { userFixture = fixture; continue; }
    if (simulateFixture(state, fixture.id)) simulated.push(fixture.id);
  }
  return { round: round.number, roundLabel: round.label, simulated, userFixture, complete: fixtures.every(f => f.status === 'played'), available: true, requiredSeasonDay: requiredDay, cupStatus: cup.status, championId: cup.championId ?? null };
}


/** Simule la journée active de la Champions League sans prendre le match du club dirigé. */
export function simulateChampionsLeagueRound(state,{userClubId=state.userClubId,simulateUser=false}={}){
  const cup=state.competitions.find(c=>c.id===CHAMPIONS_LEAGUE_ID),round=cup?.rounds?.find(r=>!r.completed);
  if(!round||cup.status!=='in-progress')return{round:null,simulated:[],userFixture:null,complete:true};
  const fixtures=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean);
  const requiredDay=Math.min(...fixtures.map(f=>Number(f.scheduledDay||Number.MAX_SAFE_INTEGER)));
  if(requiredDay===Number.MAX_SAFE_INTEGER||Number(state.calendar.currentDay||1)<requiredDay)return{round:round.number,roundLabel:round.label,simulated:[],userFixture:null,complete:false,available:false,requiredSeasonDay:requiredDay===Number.MAX_SAFE_INTEGER?null:requiredDay,cupStatus:cup.status};
  const simulated=[];let userFixture=null;
  for(const fixture of fixtures){const isUser=fixture.competitionId===LUNAR_CUP_ID?(fixture.home===state.userGalaxyId||fixture.away===state.userGalaxyId):fixture.competitionId===INTERGALACTIC_CUP_ID?(fixture.home===state.userNationId||fixture.away===state.userNationId):(fixture.home===userClubId||fixture.away===userClubId);if(isUser&&!simulateUser){userFixture=fixture;continue;}if(simulateFixture(state,fixture.id))simulated.push(fixture.id);}
  return{round:round.number,roundLabel:round.label,simulated,userFixture,complete:fixtures.every(f=>f.status==='played'),available:true,requiredSeasonDay:requiredDay,cupStatus:cup.status,championId:cup.championId||null};
}

/** Simule le tour courant de la Coupe Fédéral ; le match du club dirigé peut rester jouable. */
export function simulateFederalCupRound(state, { userClubId = state.userClubId, simulateUser = false } = {}) {
  const cup = state.competitions.find(c => c.id === FEDERAL_CUP_ID);
  const round = cup?.rounds?.at(-1);
  if (!round || cup.status !== 'in-progress') return { round: null, simulated: [], userFixture: null, complete: true };
  const fixtures = round.fixtureIds.map(id => state.calendar.fixtures.find(f => f.id === id)).filter(Boolean);
  const requiredDay = Math.min(...fixtures.map(f => Number(f.scheduledDay || Number.MAX_SAFE_INTEGER)));
  if (requiredDay === Number.MAX_SAFE_INTEGER || Number(state.calendar.currentDay || 1) < requiredDay) return { round: round.number, simulated: [], userFixture: null, complete: false, available: false, requiredSeasonDay: requiredDay === Number.MAX_SAFE_INTEGER ? null : requiredDay, cupStatus: cup.status };
  const simulated = []; let userFixture = null;
  for (const fixture of fixtures) {
    const isUserMatch = fixture.home === userClubId || fixture.away === userClubId;
    if (isUserMatch && !simulateUser) { userFixture = fixture; continue; }
    if (simulateFixture(state, fixture.id)) simulated.push(fixture.id);
  }
  const unresolved = fixtures.filter(f => f.status !== 'played');
  return { round: round.number, simulated, userFixture, complete: unresolved.length === 0, available: true, requiredSeasonDay: requiredDay, cupStatus: cup.status, championId: cup.championId ?? null };
}

/** Simule le tour AGD courant ; le match de la galaxie choisie reste jouable. */
export function simulateLunarCupRound(state,{userGalaxyId=state.userGalaxyId,simulateUser=false}={}){
  const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID),round=cup?.rounds?.find(r=>!r.completed);
  if(!round||cup.status!=='in-progress')return{round:null,simulated:[],userFixture:null,complete:true};
  const fixtures=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean);
  const requiredDay=Math.min(...fixtures.map(f=>Number(f.scheduledDay||Number.MAX_SAFE_INTEGER)));
  if(requiredDay===Number.MAX_SAFE_INTEGER||Number(state.calendar.currentDay||1)<requiredDay)return{round:round.number,roundLabel:round.label,simulated:[],userFixture:null,complete:false,available:false,requiredSeasonDay:requiredDay===Number.MAX_SAFE_INTEGER?null:requiredDay};
  const simulated=[];let userFixture=null;
  for(const fixture of fixtures){const isUser=fixture.home===userGalaxyId||fixture.away===userGalaxyId;if(isUser&&!simulateUser){userFixture=fixture;continue;}if(simulateFixture(state,fixture.id))simulated.push(fixture.id);}
  return{round:round.number,roundLabel:round.label,simulated,userFixture,complete:fixtures.every(f=>f.status==='played'),available:true,requiredSeasonDay:requiredDay,championId:cup.championId||null};
}

/** Simule le tour courant de la Coupe des Clubs ; le match du club dirigé reste jouable. */
export function simulateClubCupRound(state,{userClubId=state.userClubId,simulateUser=false}={}){const cup=state.competitions.find(c=>c.id===CLUB_CUP_ID),round=cup?.rounds?.at(-1);if(!round||cup.status!=='in-progress')return{round:null,simulated:[],userFixture:null,complete:true};const fixtures=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean);const requiredDay=Math.min(...fixtures.map(f=>Number(f.scheduledDay||Number.MAX_SAFE_INTEGER)));if(requiredDay===Number.MAX_SAFE_INTEGER||Number(state.calendar.currentDay||1)<requiredDay)return{round:round.number,roundLabel:round.label,simulated:[],userFixture:null,complete:false,available:false,requiredSeasonDay:requiredDay===Number.MAX_SAFE_INTEGER?null:requiredDay,cupStatus:cup.status};const simulated=[];let userFixture=null;for(const f of fixtures){const isUser=f.home===userClubId||f.away===userClubId;if(isUser&&!simulateUser){userFixture=f;continue;}if(simulateFixture(state,f.id))simulated.push(f.id);}return{round:round.number,roundLabel:round.label,simulated,userFixture,complete:fixtures.every(f=>f.status==='played'),available:true,requiredSeasonDay:requiredDay,cupStatus:cup.status,championId:cup.championId??null};}

/** Simule la journée de l'Intergalactique des Clubs ; le match du club dirigé reste jouable. */
export function simulateIntergalacticClubsRound(state,{userClubId=state.userClubId,simulateUser=false}={}){
  const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CLUBS_ID),round=cup?.rounds?.find(r=>!r.completed);
  if(!round||cup.status!=='in-progress')return{round:null,simulated:[],userFixture:null,complete:true};
  const fixtures=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean);
  const requiredDay=Math.min(...fixtures.map(f=>Number(f.scheduledDay||Number.MAX_SAFE_INTEGER)));
  if(requiredDay===Number.MAX_SAFE_INTEGER||Number(state.calendar.currentDay||1)<requiredDay)return{round:round.number,roundLabel:round.label,simulated:[],userFixture:null,complete:false,available:false,requiredSeasonDay:requiredDay===Number.MAX_SAFE_INTEGER?null:requiredDay};
  const simulated=[];let userFixture=null;
  for(const f of fixtures){const isUser=f.home===userClubId||f.away===userClubId;if(isUser&&!simulateUser){userFixture=f;continue;}if(simulateFixture(state,f.id))simulated.push(f.id);}
  return{round:round.number,roundLabel:round.label,simulated,userFixture,complete:fixtures.every(f=>f.status==='played'),available:true,requiredSeasonDay:requiredDay,championId:cup.championId||null};
}

/** Simule la journée AGD courante ; la sélection de l'utilisateur peut rester jouable. */
export function simulateIntergalacticCupRound(state,{userNationId=state.userNationId,simulateUser=false}={}){
  const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID),round=cup?.rounds?.find(r=>!r.completed);
  if(!round||cup.status!=='in-progress')return{round:null,simulated:[],userFixture:null,complete:true};
  const fixtures=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean);
  const requiredDay=Math.min(...fixtures.map(f=>Number(f.scheduledDay||Number.MAX_SAFE_INTEGER)));
  if(requiredDay===Number.MAX_SAFE_INTEGER||Number(state.calendar.currentDay||1)<requiredDay)return{round:round.number,roundLabel:round.label,simulated:[],userFixture:null,complete:false,available:false,requiredSeasonDay:requiredDay===Number.MAX_SAFE_INTEGER?null:requiredDay};
  const simulated=[];let userFixture=null;
  for(const f of fixtures){const isUser=f.home===userNationId||f.away===userNationId;if(isUser&&!simulateUser){userFixture=f;continue;}if(simulateFixture(state,f.id))simulated.push(f.id);}
  return{round:round.number,roundLabel:round.label,simulated,userFixture,complete:fixtures.every(f=>f.status==='played'),available:true,requiredSeasonDay:requiredDay,championId:cup.championId||null};
}

// Enregistre le résultat d'une partie jouée sur le damier pour le club dirigé.
// Le camp rouge représente toujours le club de l'utilisateur, qu'il soit à domicile ou à l'extérieur.
export function recordPlayedGame(state, fixtureId, winnerSide, matchDetails = {}) {
  if (![1, -1, null].includes(winnerSide)) throw new Error('Résultat de partie invalide');
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId);
  if (!fixture) throw new Error('Rencontre introuvable');
  if(fixture.competitionId===INTERGALACTIC_CLUBS_ID){
    const userHome=fixture.home===state.userClubId,userAway=fixture.away===state.userClubId;
    if(!userHome&&!userAway)throw new Error('Cette rencontre ne concerne pas le club dirigé');
    if(fixture.scheduledDay&&Number(state.calendar.currentDay||1)<Number(fixture.scheduledDay))throw new Error(`Cette rencontre AGD est programmée au jour ${fixture.scheduledDay}`);
    const winnerId=winnerSide===null?null:(winnerSide===1?state.userClubId:(userHome?fixture.away:fixture.home));
    const homeScore=winnerSide===null?0:(winnerId===fixture.home?1:0),awayScore=winnerSide===null?0:(winnerId===fixture.away?1:0);
    const result=recordIntergalacticClubsResult(state,fixtureId,homeScore,awayScore,{winnerId,matchDetails:{...matchDetails,mode:'manual',winnerSide}});
    return{accepted:result.accepted,score:[homeScore,awayScore],fixture,nextFixtures:result.nextFixtures,championId:result.championId};
  }
  if(fixture.competitionId===INTERGALACTIC_CUP_ID){
    const nation=state.userNationId,userHome=fixture.home===nation,userAway=fixture.away===nation;
    if(!nation||(!userHome&&!userAway))throw new Error('Choisis ta sélection nationale avant de jouer la Coupe Intergalactique');
    if(fixture.scheduledDay&&Number(state.calendar.currentDay||1)<Number(fixture.scheduledDay))throw new Error(`Cette rencontre AGD est programmée au jour ${fixture.scheduledDay}`);
    const winnerId=winnerSide===null?null:(winnerSide===1?nation:(userHome?fixture.away:fixture.home));
    const homeScore=winnerSide===null?0:(winnerId===fixture.home?1:0),awayScore=winnerSide===null?0:(winnerId===fixture.away?1:0);
    const result=recordIntergalacticCupResult(state,fixtureId,homeScore,awayScore,{winnerId,matchDetails:{...matchDetails,mode:'manual',winnerSide,userNationId:nation}});
    return{accepted:result.accepted,score:[homeScore,awayScore],fixture,nextFixtures:result.nextFixtures,championId:result.championId};
  }
  if(fixture.competitionId===LUNAR_CUP_ID){
    const userGalaxy=state.userGalaxyId,userIsHome=fixture.home===userGalaxy,userIsAway=fixture.away===userGalaxy;
    if(!userGalaxy||(!userIsHome&&!userIsAway))throw new Error('Choisis ta galaxie avant de jouer la Coupe Lunaire');
    if(fixture.scheduledDay&&Number(state.calendar.currentDay||1)<Number(fixture.scheduledDay))throw new Error(`Cette rencontre est programmée au jour ${fixture.scheduledDay} du calendrier général`);
    const winnerId=winnerSide===1?userGalaxy:winnerSide===-1?(userIsHome?fixture.away:fixture.home):resolveLunarCupDraw(fixture),homeWon=winnerId===fixture.home,score=homeWon?[1,0]:[0,1];
    const result=recordLunarCupResult(state,fixtureId,score[0],score[1],{winnerId,matchDetails:{...matchDetails,mode:'manual',winnerSide,userGalaxy}});
    return{accepted:result.accepted,score,fixture,nextFixtures:result.nextFixtures,championId:result.championId};
  }
  const userIsHome = fixture.home === state.userClubId;
  const userIsAway = fixture.away === state.userClubId;
  if (!userIsHome && !userIsAway) throw new Error('Cette rencontre ne concerne pas le club dirigé');
  if (fixture.scheduledDay && Number(state.calendar.currentDay || 1) < Number(fixture.scheduledDay)) throw new Error(`Cette rencontre est programmée au jour ${fixture.scheduledDay} du calendrier général`);
  if (fixture.competitionId === CHAMPIONS_LEAGUE_ID) {
    const homeScore=winnerSide===null?0:(winnerSide===1?(userIsHome?1:0):(userIsHome?0:1));
    const awayScore=winnerSide===null?0:(winnerSide===1?(userIsHome?0:1):(userIsHome?1:0));
    const winnerId=winnerSide===null?null:(homeScore>awayScore?fixture.home:fixture.away);
    const result=recordChampionsLeagueResult(state,fixtureId,homeScore,awayScore,{winnerId,matchDetails:{...matchDetails,mode:'manual',winnerSide}});
    return{accepted:result.accepted,score:[homeScore,awayScore],fixture,nextFixtures:result.nextFixtures};
  }
  if (fixture.competitionId === GALACTIC_CUP_ID) {
    const opponentId = userIsHome ? fixture.away : fixture.home;
    const userWins = winnerSide === 1 || (winnerSide === null && resolveGalacticCupDraw(fixture) === state.userClubId);
    const winnerId = userWins ? state.userClubId : opponentId;
    const homeScore = winnerSide === null ? 0 : (winnerId === fixture.home ? 1 : 0);
    const awayScore = winnerSide === null ? 0 : (winnerId === fixture.away ? 1 : 0);
    const result = recordGalacticCupResult(state, fixtureId, homeScore, awayScore, { winnerId, matchDetails: { ...matchDetails, mode: 'manual', winnerSide } });
    return { accepted: result.accepted, score: [homeScore, awayScore], fixture, nextFixtures: result.nextFixtures };
  }
  if (fixture.competitionId === CLUB_CUP_ID) {
    const opponentId=userIsHome?fixture.away:fixture.home;let userWins=winnerSide===1,penalties=null;if(winnerSide===null){const seed=[...fixture.id].reduce((n,ch)=>(Math.imul(n^ch.charCodeAt(0),16777619)>>>0),2166136261);const us=teamStrength(findClub(state,state.userClubId)),them=teamStrength(findClub(state,opponentId));userWins=(seed/4294967296)<Math.max(.2,Math.min(.8,.5+(us-them)/250));penalties=userWins?[5,4]:[4,5];}const winnerId=userWins?state.userClubId:opponentId,homeWon=winnerId===fixture.home;const result=recordClubCupResult(state,fixtureId,homeWon?1:0,homeWon?0:1,{winnerId,penalties,matchDetails:{...matchDetails,mode:'manual'}});return{accepted:result.accepted,score:homeWon?[1,0]:[0,1],fixture,penalties,nextFixtures:result.nextFixtures};
  }
  if (fixture.competitionId === FEDERAL_CUP_ID) {
    const opponentId = userIsHome ? fixture.away : fixture.home;
    let userWins = winnerSide === 1;
    let penalties = null;
    if (winnerSide === null) {
      const seed = [...fixture.id].reduce((n, ch) => (Math.imul(n ^ ch.charCodeAt(0), 16777619) >>> 0), 2166136261);
      const userStrength = teamStrength(findClub(state, state.userClubId));
      const opponentStrength = teamStrength(findClub(state, opponentId));
      const chance = Math.max(0.2, Math.min(0.8, 0.5 + (userStrength - opponentStrength) / 250));
      userWins = (seed / 4294967296) < chance;
      penalties = userWins ? [5, 4] : [4, 5];
    }
    const winnerId = userWins ? state.userClubId : opponentId;
    const homeWon = winnerId === fixture.home;
    const result = recordFederalCupResult(state, fixtureId, homeWon ? 1 : 0, homeWon ? 0 : 1, { winnerId, penalties, matchDetails: { ...matchDetails, mode: 'manual' } });
    return { accepted: result.accepted, score: homeWon ? [1, 0] : [0, 1], fixture, penalties, nextFixtures: result.nextFixtures };
  }
  const userWon = winnerSide === 1;
  const opponentWon = winnerSide === -1;
  const userScore = winnerSide === null ? 0 : userWon ? 1 : 0;
  const opponentScore = winnerSide === null ? 0 : opponentWon ? 1 : 0;
  const homeScore = userIsHome ? userScore : opponentScore;
  const awayScore = userIsHome ? opponentScore : userScore;
  const finalDetails = { ...matchDetails, winnerSide, userClubSide: userIsHome ? 'home' : 'away' };
  const accepted = recordResult(state, fixtureId, homeScore, awayScore, finalDetails);
  if (accepted) {
    fixture.matchDetails = finalDetails;
    const roundStillPending = state.calendar.fixtures.some(f => !f.competitionId && f.season === fixture.season && f.round === fixture.round && f.status !== 'played');
    if (!roundStillPending) state.day = fixture.round + 1;
  }
  return { accepted, score: [homeScore, awayScore], fixture };
}
