import React, { useState, useEffect } from 'react';
import { MusicProvider, useMusic } from './context/MusicContext';
import { TopAppBar } from './components/common/TopAppBar';
import { BottomNavigation } from './components/common/BottomNavigation';
import { MiniPlayer } from './components/player/MiniPlayer';
import { NowPlayingModal } from './components/player/NowPlayingModal';
import { HomeScreen } from './components/home/HomeScreen';
import { SearchScreen } from './components/search/SearchScreen';
import { LibraryScreen } from './components/library/LibraryScreen';
import { DownloadsScreen } from './components/downloads/DownloadsScreen';
import { ProfileScreen } from './components/profile/ProfileScreen';
import { PlaylistDetailModal } from './components/modals/PlaylistDetailModal';
import { ArtistDetailModal } from './components/modals/ArtistDetailModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { OnboardingModal } from './components/modals/OnboardingModal';
import { AuthModal } from './components/modals/AuthModal';

const MainAppContent: React.FC = () => {
  const { activeTab, setIsOnboardingOpen } = useMusic();
  const [deviceView, setDeviceView] = useState<'mobile' | 'tablet' | 'responsive'>('responsive');

  // Trigger welcome onboarding for first-time visitors
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('music_express_onboarding_done');
    if (!hasSeenOnboarding) {
      setIsOnboardingOpen(true);
    }
  }, [setIsOnboardingOpen]);

  // Screen container max-width based on device switcher
  const getContainerWidth = () => {
    if (deviceView === 'mobile') return 'max-w-[420px] shadow-2xl rounded-3xl my-3 border border-white/10 ring-8 ring-black/40 overflow-hidden';
    if (deviceView === 'tablet') return 'max-w-[800px] shadow-2xl rounded-3xl my-3 border border-white/10 ring-8 ring-black/40 overflow-hidden';
    return 'w-full';
  };

  return (
    <div className="min-h-screen bg-[#07080b] flex flex-col items-center justify-start text-[#f1f3f9] selection:bg-purple-600 selection:text-white">
      {/* Device wrapper */}
      <div className={`w-full ${getContainerWidth()} min-h-screen flex flex-col bg-[#0b0c10] relative transition-all duration-300`}>
        {/* Android Punch Hole Camera indicator in Mobile Preview Mode */}
        {deviceView === 'mobile' && (
          <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-black ring-2 ring-white/10 z-50 pointer-events-none" />
        )}

        {/* Top App Bar with Logo, Greeting, Device switcher, Notifications & Profile */}
        <TopAppBar deviceView={deviceView} setDeviceView={setDeviceView} />

        {/* Scrollable Main Content Area */}
        <main className="flex-1 overflow-y-auto px-3 sm:px-5">
          {activeTab === 'home' && <HomeScreen />}
          {activeTab === 'search' && <SearchScreen />}
          {activeTab === 'library' && <LibraryScreen />}
          {activeTab === 'downloads' && <DownloadsScreen />}
          {activeTab === 'profile' && <ProfileScreen />}
        </main>

        {/* Sticky Bottom Area: Mini Player + Bottom Navigation */}
        <div className="sticky bottom-0 z-40 w-full flex flex-col bg-gradient-to-t from-[#0b0c10] via-[#0b0c10]/95 to-transparent pt-2">
          <MiniPlayer />
          <BottomNavigation />
        </div>

        {/* Fullscreen Overlays and Modals */}
        <NowPlayingModal />
        <PlaylistDetailModal />
        <ArtistDetailModal />
        <AdminDashboard />
        <OnboardingModal />
        <AuthModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <MusicProvider>
      <MainAppContent />
    </MusicProvider>
  );
}
