import { useCallback, useMemo, useRef, useState } from "react";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Models from "./components/Models";
import Forge from "./components/Forge";
import Arcade from "./components/Arcade";
import Voice from "./components/Voice";
import Footer from "./components/Footer";
import GamePlayer from "./components/GamePlayer";
import { IconCheck, IconX, IconDownload, IconGamepad } from "./components/Icons";
import { MODELS, SEED_BUILDS, type Build, type YunoModel } from "./lib/models";
import { useOnline, usePersistentState } from "./lib/hooks";
import { buildExportHtml, downloadText, slugify } from "./lib/engine";

interface Toast {
  id: number;
  msg: string;
  kind: "ok" | "warn";
}

function BackgroundFX() {
  const particles = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        id: i,
        left: (i * 61) % 100,
        top: (i * 37 + 11) % 100,
        size: 2 + ((i * 7) % 4),
        dur: 9 + ((i * 5) % 12),
        delay: -((i * 1.7) % 10),
        teal: i % 3 === 0,
      })),
    []
  );
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden" aria-hidden>
      <div className="absolute inset-0 bg-gridlines" />
      <div className="absolute -top-40 -left-40 w-[620px] h-[620px] bg-[radial-gradient(circle,rgba(255,122,47,0.09),transparent_65%)] glow-breathe" />
      <div className="absolute -bottom-52 -right-40 w-[700px] h-[700px] bg-[radial-gradient(circle,rgba(47,230,200,0.07),transparent_65%)] glow-breathe" style={{ animationDelay: "-2.2s" }} />
      {particles.map((p) => (
        <span
          key={p.id}
          className="particle"
          style={{
            left: p.left + "%",
            top: p.top + "%",
            width: p.size,
            height: p.size,
            background: p.teal ? "#2fe6c8" : "#ffb454",
            animationDuration: p.dur + "s",
            animationDelay: p.delay + "s",
            boxShadow: `0 0 ${p.size * 3}px ${p.teal ? "rgba(47,230,200,0.6)" : "rgba(255,180,84,0.6)"}`,
          }}
        />
      ))}
    </div>
  );
}

export default function App() {
  const online = useOnline();
  const [model, setModel] = useState<YunoModel>(MODELS[0]);
  const [builds, setBuilds] = usePersistentState<Build[]>("yuno.builds.v1", SEED_BUILDS);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [prefill, setPrefill] = useState<{ text: string; nonce: number } | null>(null);
  const [playing, setPlaying] = useState<Build | null>(null);
  const toastId = useRef(0);

  const toast = useCallback((msg: string, kind: "ok" | "warn" = "ok") => {
    const id = ++toastId.current;
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);

  const onBuilt = useCallback(
    (b: Build) => {
      setBuilds((prev) => [b, ...prev.filter((x) => x.id !== b.id)].slice(0, 24));
    },
    [setBuilds]
  );

  const onUpdateThumb = useCallback(
    (id: string, thumb: string) => {
      setBuilds((prev) => prev.map((b) => (b.id === id && !b.thumb ? { ...b, thumb } : b)));
    },
    [setBuilds]
  );

  const onDelete = useCallback(
    (id: string) => {
      setBuilds((prev) => prev.filter((b) => b.id !== id));
      toast("Build scrapped. Its files remain yours if you exported them.", "ok");
    },
    [setBuilds, toast]
  );

  const onDownload = useCallback(
    (b: Build) => {
      downloadText(slugify(b.config.title) + ".html", buildExportHtml(b.config));
      toast(b.title + " downloaded as a single HTML file", "ok");
    },
    [toast]
  );

  const onVoiceForge = useCallback(
    (prompt: string) => {
      setPrefill({ text: prompt, nonce: Date.now() });
      toast("Idea routed to the forge — review and ignite", "ok");
      document.getElementById("forge")?.scrollIntoView({ behavior: "smooth" });
    },
    [toast]
  );

  return (
    <div className="scanlines relative min-h-screen bg-ink text-snow font-body">
      <BackgroundFX />
      <div className="relative z-10">
        <Nav online={online} />
        <main>
          <Hero />
          <Models selectedId={model.id} onSelect={setModel} toast={toast} />
          <Forge model={model} prefill={prefill} onBuilt={onBuilt} onUpdateThumb={onUpdateThumb} toast={toast} />
          <Arcade builds={builds} onPlay={setPlaying} onDelete={onDelete} onDownload={onDownload} />
          <Voice onForge={onVoiceForge} toast={toast} />
        </main>
        <Footer />
      </div>

      {/* toasts */}
      <div className="fixed bottom-5 right-5 z-[90] space-y-2.5 w-[min(92vw,380px)]">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`toast-in clip-hud-sm border bg-panel/95 backdrop-blur px-4 py-3.5 flex items-start gap-3 shadow-[0_12px_40px_rgba(0,0,0,0.5)] ${
              t.kind === "ok" ? "border-teal/45" : "border-ember/55"
            }`}
          >
            <span className={`mt-0.5 shrink-0 w-5 h-5 clip-tag flex items-center justify-center ${t.kind === "ok" ? "bg-teal/15 text-teal" : "bg-ember/15 text-ember"}`}>
              {t.kind === "ok" ? <IconCheck size={12} /> : <IconX size={12} />}
            </span>
            <p className="text-[12.5px] leading-snug text-mist font-medium">{t.msg}</p>
          </div>
        ))}
      </div>

      {/* play modal */}
      {playing && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-ink/85 backdrop-blur-sm"
          onClick={() => setPlaying(null)}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="w-full max-w-3xl border border-line2 bg-panel clip-hud shadow-[0_40px_120px_rgba(0,0,0,0.7)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 px-5 h-12 border-b border-line">
              <IconGamepad size={16} className="text-ember" />
              <div>
                <p className="font-display font-bold text-[13.5px] text-snow leading-none">{playing.title}</p>
                <p className="font-mono text-[9px] tracking-[0.18em] text-fog mt-1">{playing.genre} · {playing.modelName}</p>
              </div>
              <button
                onClick={() => onDownload(playing)}
                className="ml-auto btn-ghost clip-tag px-3.5 h-9 font-mono text-[10px] tracking-[0.14em] inline-flex items-center gap-2"
              >
                <IconDownload size={12} /> .HTML
              </button>
              <button
                onClick={() => setPlaying(null)}
                className="w-9 h-9 border border-line2 text-fog hover:text-coral hover:border-coral clip-tag flex items-center justify-center transition-colors"
                aria-label="Close"
              >
                <IconX size={15} />
              </button>
            </div>
            <GamePlayer config={playing.config} />
            <div className="px-5 py-3 border-t border-line flex items-center justify-between flex-wrap gap-2">
              <span className="font-mono text-[9.5px] tracking-[0.16em] text-fog">
                CLICK TO START · ARROWS/WASD · SPACE · P PAUSE
              </span>
              <span className="font-mono text-[9.5px] tracking-[0.16em] text-teal">"{playing.config.prompt}"</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
