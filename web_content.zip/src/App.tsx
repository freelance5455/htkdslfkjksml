import React, { useState, useEffect, useRef } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { auth } from './firebase';
import { ChatMessage, ScreenType, UserProfile } from './types';
import { SplashScreen } from './components/SplashScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { VoiceScreen } from './components/VoiceScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { ConversationHistoryModal } from './components/ConversationHistoryModal';
import { AuthModal } from './components/AuthModal';
import {
  getUserProfileFromFirestore,
  saveUserProfileToFirestore,
  saveMessageToFirestore,
  deleteMessageFromFirestore,
  subscribeUserMessages,
  validateFirestoreConnection,
} from './services/userService';

const DEFAULT_PROFILE: UserProfile = {
  name: '',
  gender: 'Male',
  characterName: 'حمزہ (Hamza)',
  persona: 'friend',
  speechRate: 1.0,
  speechPitch: 1.0,
  language: 'Urdu',
};

export default function App() {
  const [screen, setScreen] = useState<ScreenType>('splash');
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const unsubscribeMessagesRef = useRef<(() => void) | null>(null);

  // Initial Load from LocalStorage
  useEffect(() => {
    validateFirestoreConnection();

    const storedName = localStorage.getItem('user_name') || '';
    const storedGender = (localStorage.getItem('bot_gender') as 'Male' | 'Female') || 'Male';
    const storedPersona = (localStorage.getItem('bot_persona') as any) || 'friend';
    const storedRate = parseFloat(localStorage.getItem('speech_rate') || '1.0');
    const storedPitch = parseFloat(localStorage.getItem('speech_pitch') || '1.0');
    const storedLanguage = (localStorage.getItem('bot_language') as 'Urdu' | 'English') || 'Urdu';

    if (storedName) {
      setProfile({
        name: storedName,
        gender: storedGender,
        characterName: storedGender === 'Female' ? 'عائشہ (Ayesha)' : 'حمزہ (Hamza)',
        persona: storedPersona,
        speechRate: isNaN(storedRate) ? 1.0 : storedRate,
        speechPitch: isNaN(storedPitch) ? 1.0 : storedPitch,
        language: storedLanguage,
      });
    }

    // Load local history (matching Cordova chat_memory format)
    try {
      const storedHistory = localStorage.getItem('chat_memory');
      if (storedHistory) {
        const parsed = JSON.parse(storedHistory);
        if (Array.isArray(parsed)) {
          // If in format "User: ..." / "Bot: ..." or ChatMessage object
          const formatted: ChatMessage[] = parsed.map((item, idx) => {
            if (typeof item === 'string') {
              const isUser = item.startsWith('User: ');
              const text = item.replace(/^(User:\s*|Bot:\s*)/, '');
              return {
                id: `legacy-${idx}-${Date.now()}`,
                role: isUser ? 'user' : 'model',
                text,
                timestamp: Date.now() - (parsed.length - idx) * 60000,
              };
            }
            return item;
          });
          setMessages(formatted);
        }
      }
    } catch (e) {
      console.warn('Error reading stored chat_memory');
    }
  }, []);

  // Listen for Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);

      if (user) {
        // Authenticated: load user profile from Firestore or sync existing
        try {
          const remoteProfile = await getUserProfileFromFirestore(user.uid);
          if (remoteProfile && remoteProfile.name) {
            setProfile(remoteProfile);
            localStorage.setItem('user_name', remoteProfile.name);
            localStorage.setItem('bot_gender', remoteProfile.gender);
          } else {
            // Save current profile to new account
            const nameToUse = user.displayName || profile.name || 'دوست';
            const updated: UserProfile = {
              ...profile,
              name: nameToUse,
            };
            setProfile(updated);
            await saveUserProfileToFirestore(user.uid, updated, user.email);
          }

          // Subscribe to cloud messages for this user
          if (unsubscribeMessagesRef.current) {
            unsubscribeMessagesRef.current();
          }
          unsubscribeMessagesRef.current = subscribeUserMessages(user.uid, (cloudMsgs) => {
            if (cloudMsgs && cloudMsgs.length > 0) {
              setMessages(cloudMsgs);
              // backup locally
              localStorage.setItem('chat_memory', JSON.stringify(cloudMsgs));
            }
          });
        } catch (err) {
          console.error('Error syncing user with Firestore:', err);
        }
      } else {
        // Unauthenticated / Logged out
        if (unsubscribeMessagesRef.current) {
          unsubscribeMessagesRef.current();
          unsubscribeMessagesRef.current = null;
        }
      }
    });

    return () => {
      unsubscribe();
      if (unsubscribeMessagesRef.current) {
        unsubscribeMessagesRef.current();
      }
    };
  }, []);

  // Handle transition from splash screen
  const handleSplashComplete = () => {
    // If name already saved, jump straight to voice screen just as in user's Cordova script:
    // window.onload = function() { if(localStorage.getItem('user_name')) { window.location.href = "voice.html"; } }
    if (profile.name.trim()) {
      setScreen('voice');
    } else {
      setScreen('profile');
    }
  };

  // Save profile updates
  const handleSaveProfile = async (newProfile: UserProfile) => {
    setProfile(newProfile);
    localStorage.setItem('user_name', newProfile.name);
    localStorage.setItem('bot_gender', newProfile.gender);
    localStorage.setItem('bot_persona', newProfile.persona);
    localStorage.setItem('speech_rate', newProfile.speechRate.toString());
    localStorage.setItem('speech_pitch', newProfile.speechPitch.toString());
    localStorage.setItem('bot_language', newProfile.language || 'Urdu');

    if (currentUser) {
      try {
        await saveUserProfileToFirestore(currentUser.uid, newProfile, currentUser.email);
      } catch (e) {
        console.warn('Could not sync profile to cloud', e);
      }
    }

    setScreen('voice');
  };

  // Add new message to history
  const handleAddMessage = (msg: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMsg: ChatMessage = {
      ...msg,
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
    };

    setMessages((prev) => {
      const updated = [...prev, newMsg];
      localStorage.setItem('chat_memory', JSON.stringify(updated));
      return updated;
    });

    // If authenticated, sync with Firestore
    if (currentUser) {
      saveMessageToFirestore(currentUser.uid, newMsg).catch((err) => {
        console.warn('Cloud message sync skipped:', err);
      });
    }
  };

  // Clear conversation history
  const handleClearHistory = () => {
    setMessages([]);
    localStorage.removeItem('chat_memory');
  };

  // Delete single message
  const handleDeleteMessage = (id: string) => {
    setMessages((prev) => {
      const updated = prev.filter((m) => m.id !== id);
      localStorage.setItem('chat_memory', JSON.stringify(updated));
      return updated;
    });

    if (currentUser) {
      deleteMessageFromFirestore(currentUser.uid, id).catch((e) => {
        console.warn('Could not delete from Firestore:', e);
      });
    }
  };

  // Reset profile / change name
  const handleResetProfile = () => {
    localStorage.removeItem('user_name');
    localStorage.removeItem('bot_gender');
    setProfile(DEFAULT_PROFILE);
    setScreen('profile');
  };

  // User Sign Out
  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Sign out error:', e);
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#081225] flex justify-center text-white">
      {/* Mobile-first centered app shell */}
      <div className="w-full max-w-lg min-h-screen relative flex flex-col bg-[#081225] shadow-2xl overflow-x-hidden">
        {screen === 'splash' && (
          <SplashScreen onComplete={handleSplashComplete} />
        )}

        {screen === 'profile' && (
          <ProfileScreen
            initialProfile={profile}
            onSave={handleSaveProfile}
          />
        )}

        {screen === 'voice' && (
          <VoiceScreen
            profile={profile}
            messages={messages}
            onAddMessage={handleAddMessage}
            onOpenSettings={() => setScreen('settings')}
            onOpenHistory={() => setIsHistoryModalOpen(true)}
            currentUser={currentUser}
            onOpenAuth={(mode) => {
              setAuthMode(mode || 'login');
              setIsAuthModalOpen(true);
            }}
            onSignOut={handleSignOut}
          />
        )}

        {screen === 'settings' && (
          <SettingsScreen
            profile={profile}
            onUpdateProfile={(updated) => {
              setProfile(updated);
              localStorage.setItem('speech_rate', updated.speechRate.toString());
              localStorage.setItem('speech_pitch', updated.speechPitch.toString());
              localStorage.setItem('bot_gender', updated.gender);
              localStorage.setItem('bot_language', updated.language || 'Urdu');
              if (currentUser) {
                saveUserProfileToFirestore(currentUser.uid, updated, currentUser.email).catch(() => {});
              }
            }}
            onResetProfile={handleResetProfile}
            onBack={() => setScreen('voice')}
            onOpenHistory={() => setIsHistoryModalOpen(true)}
            historyCount={messages.length}
            onClearHistory={handleClearHistory}
            currentUser={currentUser}
            onOpenAuth={(mode) => {
              setAuthMode(mode || 'login');
              setIsAuthModalOpen(true);
            }}
            onSignOut={handleSignOut}
          />
        )}

        {/* Conversation History Modal */}
        <ConversationHistoryModal
          isOpen={isHistoryModalOpen}
          onClose={() => setIsHistoryModalOpen(false)}
          messages={messages}
          onClearHistory={handleClearHistory}
          onDeleteMessage={handleDeleteMessage}
          profile={profile}
        />

        {/* User Authentication Modal */}
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          defaultMode={authMode}
          onSuccess={() => {
            // Refresh
          }}
        />
      </div>
    </div>
  );
}
