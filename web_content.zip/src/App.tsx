import React, { useState, useEffect, useCallback } from 'react';
import { DataProvider, useData } from './context/DataContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { FoundersPage } from './components/FoundersPage.tsx';
import { ProjectsPage } from './components/ProjectsPage.tsx';
import { StartProjectPage } from './components/StartProjectPage.tsx';
import { WhatWeDoPage } from './components/WhatWeDoPage.tsx';
import { AiAssistantPage } from './components/AiAssistantPage.tsx';
import { VouchesPage } from './components/VouchesPage.tsx';
import { AdminDashboard } from './components/admin/AdminDashboard.tsx';
import { RefreshCw } from 'lucide-react';

export type AppView =
  | 'home'
  | 'founders'
  | 'projects'
  | 'what-we-do'
  | 'start-project'
  | 'vouches'
  | 'ai-assistant'
  | 'admin';

function MainApp() {
  const { data, loading, syncing, syncError } = useData();

  // Route views: 'home' | 'founders' | 'projects' | 'what-we-do' | 'vouches' | 'ai-assistant' | 'admin'
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [adminInitialTab, setAdminInitialTab] = useState<string>('dashboard');

  // Parse path and synchronize view with clean URLs
  const syncViewFromPath = useCallback((pathname: string) => {
    const path = pathname.toLowerCase();
    const params = new URLSearchParams(window.location.search);
    const cat = params.get('category');
    if (cat) setCategoryFilter(cat);

    if (path.startsWith('/founders')) {
      setCurrentView('founders');
    } else if (path.startsWith('/admin')) {
      setCurrentView('admin');
    } else if (path.startsWith('/vouches')) {
      setCurrentView('vouches');
    } else if (path.startsWith('/ai-assistant')) {
      setCurrentView('ai-assistant');
    } else if (path.startsWith('/what-we-do') || path.startsWith('/start-project')) {
      setCurrentView('start-project');
    } else if (path.startsWith('/projects') || path.startsWith('/gallery')) {
      setCurrentView('projects');
    } else {
      setCurrentView('home');
    }
  }, []);

  // Initialize and canonicalize URL on mount
  useEffect(() => {
    let path = window.location.pathname.toLowerCase();
    const hash = window.location.hash;
    const search = window.location.search;

    // Normalize legacy / non-clean URLs to clean expected URLs:
    // / or /index.html -> /home
    // /founder.html or #founders -> /founders
    // /admin.html or #admin -> /admin
    if (path === '/' || path === '/index.html' || path === '/home.html' || path === '/index') {
      window.history.replaceState(null, '', '/home' + (search || '') + (hash || ''));
      path = '/home';
    } else if (path.includes('founder') || hash === '#founders') {
      window.history.replaceState(null, '', '/founders' + (search || ''));
      path = '/founders';
    } else if (path.includes('admin') || hash === '#admin') {
      window.history.replaceState(null, '', '/admin' + (search || ''));
      path = '/admin';
    } else if (path.includes('vouches') || hash === '#vouches') {
      window.history.replaceState(null, '', '/vouches' + (search || '') + (hash === '#vouches' ? '' : hash || ''));
      path = '/vouches';
    } else if (path.includes('what-we-do') || path.includes('start-project') || hash === '#what-we-do' || hash === '#start-project') {
      window.history.replaceState(null, '', '/start-project' + (search || ''));
      path = '/start-project';
    } else if (path.includes('projects') || path.includes('gallery') || hash === '#projects') {
      const cleanPath = path.startsWith('/gallery') ? '/gallery' : '/projects';
      window.history.replaceState(null, '', cleanPath + (search || ''));
      path = cleanPath;
    }

    syncViewFromPath(path);

    // If there's an anchor on initial load, scroll to it
    if (hash && hash.length > 1) {
      setTimeout(() => {
        const id = hash.replace('#', '');
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    }

    // Listen to browser Back / Forward buttons
    const handlePopState = () => {
      syncViewFromPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [syncViewFromPath]);

  // Central Navigation Handler with Clean HTML5 URLs
  const navigateTo = (view: AppView, options?: { scrollId?: string; category?: string; tab?: string }) => {
    let newPath = '/home';
    if (view === 'founders') newPath = '/founders';
    else if (view === 'admin') newPath = '/admin';
    else if (view === 'vouches') {
      newPath = options?.scrollId ? `/vouches#${options.scrollId}` : '/vouches';
    } else if (view === 'ai-assistant') newPath = '/ai-assistant';
    else if (view === 'what-we-do' || view === 'start-project') newPath = '/start-project';
    else if (view === 'projects') {
      newPath = options?.category ? `/projects?category=${encodeURIComponent(options.category)}` : '/projects';
    }

    if (view === 'home' && options?.scrollId) {
      newPath = `/home#${options.scrollId}`;
    }

    if (options?.category) {
      setCategoryFilter(options.category);
    }
    if (options?.tab) {
      setAdminInitialTab(options.tab);
    }

    // Update browser URL bar cleanly without page reload
    if (window.location.pathname + window.location.hash + window.location.search !== newPath) {
      window.history.pushState(null, '', newPath);
    }

    setCurrentView(view);

    if (options?.scrollId) {
      setTimeout(() => {
        const el = document.getElementById(options.scrollId!);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 120);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSelectCategory = (cat: string) => {
    navigateTo('projects', { category: cat });
  };

  const handleOpenAdmin = (tab: string = 'overview') => {
    navigateTo('admin', { tab });
  };

  const handleNavigateHome = () => {
    navigateTo('home');
  };

  useEffect(() => {
    if (currentView === 'home') {
      document.documentElement.removeAttribute('data-cubix-subpage');
    } else {
      document.documentElement.setAttribute('data-cubix-subpage', 'true');
    }
  }, [currentView]);

  const heroBg = data?.settings?.heroBackground;
  const heroBgImageUrl =
    heroBg?.imageUrl && heroBg.imageUrl !== 'none' && String(heroBg.imageUrl).trim() !== ''
      ? String(heroBg.imageUrl).trim()
      : '/b90c9408e77c5a808a0f1adfab828f1b.jpg';
  const rawHeroPos = heroBg?.position || 'top center';
  const heroBgPosition =
    rawHeroPos === 'top'
      ? 'top center'
      : rawHeroPos === 'bottom'
      ? 'bottom center'
      : rawHeroPos === 'center'
      ? 'center center'
      : rawHeroPos;
  const heroBgBlur = typeof heroBg?.blur === 'number' ? Math.min(Math.max(heroBg.blur, 0), 40) : 0;
  const heroBgOverlayOpacity =
    typeof heroBg?.overlayOpacity === 'number'
      ? Math.min(Math.max(heroBg.overlayOpacity, 0), 100) / 100
      : 0.8;
  const heroBgSolidColor = heroBg?.solidColor || '#06101e';

  return (
    <div className="min-h-screen flex flex-col justify-between relative bg-[#030712] text-[#f8fafc] selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background Ambience - Subtle navy/cyan tones */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[400px] bg-cyan-600/[0.07] blur-[140px] rounded-full" />
        <div className="absolute top-1/3 -left-40 w-[600px] h-[600px] bg-blue-700/[0.05] blur-[160px] rounded-full" />
        <div className="absolute bottom-20 -right-40 w-[600px] h-[600px] bg-cyan-900/[0.05] blur-[160px] rounded-full" />
      </div>

      <div className="relative z-10 flex-1">
        {/* Global Syncing Indicator / Error State */}
        {syncing ? (
          <div className="fixed bottom-4 left-4 z-40 flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#05111c]/90 border border-cyan-500/30 text-cyan-300 text-xs font-mono shadow-[0_0_15px_rgba(0,210,255,0.2)] animate-fadeIn">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
            <span>Syncing with Cloud Firestore...</span>
          </div>
        ) : syncError ? (
          <div className="fixed bottom-4 left-4 z-40 flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#1c0808]/90 border border-rose-500/40 text-rose-300 text-xs font-mono shadow-[0_0_15px_rgba(244,63,94,0.2)]">
            <span className="w-2 h-2 rounded-full bg-rose-400" />
            <span>{syncError}</span>
          </div>
        ) : null}

        {/* 1. HOMEPAGE VIEW */}
        {currentView === 'home' ? (
          <div>
            {/* Top Homepage Zone with Background: starts at top of page, includes header, ends at separator directly above About Cubix Studio */}
            <div
              className="relative border-b border-white/10 overflow-hidden"
              style={{ backgroundColor: heroBgSolidColor }}
            >
              {/* Background Image Layer ONLY (receives blur filter without blurring any foreground elements) */}
              <div
                className="absolute inset-0 z-0 pointer-events-none select-none"
                style={{
                  backgroundColor: heroBgSolidColor,
                  backgroundImage: `url("${heroBgImageUrl}")`,
                  backgroundPosition: heroBgPosition,
                  backgroundSize: heroBg?.size || 'cover',
                  backgroundRepeat: heroBg?.repeat || 'no-repeat',
                  filter: heroBgBlur > 0 ? `blur(${heroBgBlur}px)` : 'none',
                  transform: heroBgBlur > 0 ? 'scale(1.08)' : 'scale(1)',
                  willChange: heroBgBlur > 0 ? 'filter, transform' : 'auto'
                }}
              />

              {/* Background Overlay / Darkness Layer (0% to 100% intensity) */}
              <div
                className="absolute inset-0 z-0 pointer-events-none"
                style={{
                  backgroundColor: heroBgSolidColor,
                  opacity: heroBgOverlayOpacity
                }}
              />

              {/* Subtle bottom transition blend into About section */}
              <div className="absolute inset-x-0 bottom-0 h-28 z-0 pointer-events-none bg-gradient-to-b from-transparent to-[#030712]/90" />

              {/* Foreground Header and Hero inside background zone (remains 100% sharp and readable) */}
              <div className="relative z-10">
                <Navbar
                  currentView={currentView}
                  onNavigate={navigateTo}
                  setCategoryFilter={setCategoryFilter}
                />
                <HeroSection
                  onNavigateStartProject={() => navigateTo('start-project')}
                  onNavigateFounders={() => navigateTo('founders')}
                  onNavigateVouches={() => navigateTo('vouches')}
                  onNavigateAddVouch={() => navigateTo('vouches', { scrollId: 'submit-vouch' })}
                />
              </div>
            </div>

            {/* D. About the Studio - Starts directly at the border where the paper background ends */}
            <main>
              <AboutSection />

              {/* E. Our Projects (Original homepage section restored with "OUR PROJECTS") */}
              <ServicesSection onSelectCategory={handleSelectCategory} />

              {/* FAQ */}
              <FaqSection />

              {/* F. Contact / Get in Touch */}
              <ContactSection
                onNavigateStartProject={() => navigateTo('start-project')}
                onOpenAdmin={() => handleOpenAdmin('ticketSettings')}
              />
            </main>
          </div>
        ) : (
          <div>
            {/* Standard Glass Header for other pages */}
            <Navbar
              currentView={currentView}
              onNavigate={navigateTo}
              setCategoryFilter={setCategoryFilter}
            />

            {/* Main View Router for other pages */}
            <main className="min-h-[75vh]">
              {/* 2. DEDICATED MEET THE FOUNDERS PAGE */}
              {currentView === 'founders' && (
                <FoundersPage
                  onBack={handleNavigateHome}
                  onOpenAdmin={() => handleOpenAdmin('founders')}
                />
              )}

              {/* 3. DEDICATED PROJECTS PAGE */}
              {currentView === 'projects' && (
                <ProjectsPage
                  initialCategory={categoryFilter}
                  onBack={handleNavigateHome}
                />
              )}

              {/* 4. DEDICATED WHAT WE DO PAGE (Replaces Start a Project) */}
              {(currentView === 'what-we-do' || currentView === 'start-project') && (
                <WhatWeDoPage
                  onBack={handleNavigateHome}
                />
              )}

              {/* 5. DEDICATED CUBIX VOUCHES PAGE */}
              {currentView === 'vouches' && (
                <VouchesPage
                  onBackHome={handleNavigateHome}
                />
              )}

              {/* 6. DEDICATED AI ASSISTANT PAGE (Legacy route preserved if visited directly) */}
              {currentView === 'ai-assistant' && (
                <AiAssistantPage
                  onBackHome={handleNavigateHome}
                />
              )}

              {/* 7. DEDICATED ADMIN DASHBOARD */}
              {currentView === 'admin' && (
                <AdminDashboard
                  onBackToSite={handleNavigateHome}
                  initialTab={adminInitialTab}
                />
              )}
            </main>
          </div>
        )}
      </div>

      {/* For non-homepage views, show compact footer */}
      {currentView !== 'home' && currentView !== 'admin' && (
        <footer className="relative z-10 py-8 border-t border-white/10 text-xs text-slate-500 text-center">
          <div>Cubix Studio • Gurgaon, Haryana, India • Operated by RealCubix</div>
        </footer>
      )}
    </div>
  );
}

export default function App() {
  return (
    <DataProvider>
      <MainApp />
    </DataProvider>
  );
}
