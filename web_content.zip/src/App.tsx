import React, { useState } from 'react';
import {
  Calendar,
  Moon,
  Compass,
  Settings as SettingsIcon,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle,
  BellRing,
} from 'lucide-react';
import { usePrayerScheduler } from './hooks/usePrayerScheduler';
import { Header } from './components/Header';
import { CountdownHero } from './components/CountdownHero';
import { PrayerCardList } from './components/PrayerCardList';
import { NightTimingsCard } from './components/NightTimingsCard';
import { TimetableModal } from './components/TimetableModal';
import { SettingsModal } from './components/SettingsModal';
import { AlarmRingingOverlay } from './components/AlarmRingingOverlay';
import { QiblaCompassModal } from './components/QiblaCompassModal';
import { BatteryOptimizationModal } from './components/BatteryOptimizationModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  const {
    currentDate,
    activeDate,
    setActiveDate,
    todaySchedule,
    nightTimings,
    nextPrayerInfo,
    settings,
    updateSettings,
    toggleAdhan,
    toggleAlarm,
    activeAlarm,
    dismissActiveAlarm,
    snoozeActiveAlarm,
    testAdhan,
    testAlarm,
  } = usePrayerScheduler();

  // Active section for navigation
  const [activeSection, setActiveSection] = useState<'prayers' | 'night'>('prayers');

  // Modals state
  const [isTimetableOpen, setIsTimetableOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isQiblaOpen, setIsQiblaOpen] = useState(false);
  const [isBatteryGuideOpen, setIsBatteryGuideOpen] = useState(false);

  // Quick day navigation for October 2026
  const handlePrevDay = () => {
    const next = new Date(activeDate);
    next.setDate(next.getDate() - 1);
    setActiveDate(next);
  };

  const handleNextDay = () => {
    const next = new Date(activeDate);
    next.setDate(next.getDate() + 1);
    setActiveDate(next);
  };

  const handleResetToday = () => {
    setActiveDate(new Date(currentDate));
  };

  const isOctober2026 =
    activeDate.getFullYear() === 2026 && activeDate.getMonth() === 9; // 0-indexed 9 = October

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-700 selection:text-white pb-20 md:pb-12">
      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Top Bar Contract (3 zones) */}
      <Header
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenTimetable={() => setIsTimetableOpen(true)}
        onOpenQibla={() => setIsQiblaOpen(true)}
        onOpenNightTimings={() => {
          setActiveSection('night');
          window.scrollTo({ top: 600, behavior: 'smooth' });
        }}
        onTestAudio={() => testAdhan()}
        activeSection={activeSection}
        setActiveSection={sec => setActiveSection(sec as 'prayers' | 'night')}
      />

      {/* Main Content Area */}
      <main className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8 flex-1 space-y-8">
        {/* Dominant Visual Anchor: Countdown & Real-Time Hero */}
        <CountdownHero
          now={currentDate}
          nextPrayer={nextPrayerInfo}
          settings={settings}
          onTestAdhan={() => testAdhan()}
          onTestAlarm={() => testAlarm()}
        />

        {/* Date Selector Strip (Quick Day Navigation) */}
        <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-3 sm:px-5">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrevDay}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
              title="Previous Day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="font-semibold text-sm text-white">
              {new Intl.DateTimeFormat('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              }).format(activeDate)}
              {isOctober2026 && (
                <span className="ml-2 text-xs font-normal text-emerald-400">
                  (October 2026 Schedule Day {activeDate.getDate()})
                </span>
              )}
            </div>
            <button
              onClick={handleNextDay}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
              title="Next Day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetToday}
              className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition cursor-pointer"
            >
              Reset to Today
            </button>
            <button
              onClick={() => setIsTimetableOpen(true)}
              className="flex items-center gap-1.5 rounded-lg border border-emerald-800/80 bg-emerald-950/60 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-900 transition cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Full 31-Day Timetable</span>
            </button>
          </div>
        </section>

        {/* Today's Prayers & Separate Salah Alarms Grid */}
        <PrayerCardList
          schedule={todaySchedule}
          settings={settings}
          onToggleAdhan={toggleAdhan}
          onToggleAlarm={toggleAlarm}
          onPreviewAdhan={(_prayer) => testAdhan()}
        />

        {/* Islamic Night Timings (Midnight, First Third, Last Third / Tahajjud) */}
        <NightTimingsCard
          nightTimings={nightTimings}
          settings={settings}
        />

        {/* System & Reliability Overview Banner */}
        <section className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle className="w-4 h-4" />
                Automatic Adhan Playback
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Adhan plays precisely at Fajr, Dhuhr, Asr, Maghrib, and Isha. Sound engine synthesizes authentic Maqam Bayati Takbeer with zero external network delays.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <BellRing className="w-4 h-4" />
                Dynamic Salah Alarm (+{settings.alarmDelayMinutes}m)
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Calculates dynamic Salah alarm for every individual date. Sunrise is purely informational and will never trigger an Adhan or alarm.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                <ShieldCheck className="w-4 h-4" />
                Background & Reboot Resilience
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Schedules survive device restarts. Deduplication locks prevent double rings.
              </p>
              <button
                onClick={() => setIsBatteryGuideOpen(true)}
                className="text-xs text-emerald-400 hover:text-emerald-300 underline font-medium cursor-pointer"
              >
                Configure phone battery settings →
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-900 bg-slate-950 px-4 py-8 text-center text-xs text-slate-500">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-emerald-400">Salat Sathi</span>
            <span aria-hidden="true">·</span>
            <span>Islamic Prayer Timetable & Automatic Adhan System</span>
          </div>
          <div className="text-[11px] text-slate-400">
            Bangladesh Standard Time (BST, UTC+06:00) · Dhaka · October 2026 Official Timetable
          </div>
        </div>
      </footer>

      {/* Mobile Fixed Bottom Tab Bar (Navigation Anchor - Reference Pattern 1) */}
      <nav aria-label="Mobile Navigation" className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800">
        <div className="grid grid-cols-4 items-center h-16 max-w-md mx-auto px-2">
          <button
            onClick={() => {
              setActiveSection('prayers');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex flex-col items-center justify-center cursor-pointer text-slate-400 hover:text-emerald-400 py-1"
          >
            <Calendar className={`w-5 h-5 ${activeSection === 'prayers' ? 'text-emerald-400' : ''}`} />
            <span className={`text-[10px] mt-1 font-medium ${activeSection === 'prayers' ? 'text-emerald-400 font-semibold' : ''}`}>
              Prayers
            </span>
          </button>

          <button
            onClick={() => setIsTimetableOpen(true)}
            className="flex flex-col items-center justify-center cursor-pointer text-slate-400 hover:text-emerald-400 py-1"
          >
            <Calendar className="w-5 h-5" />
            <span className="text-[10px] mt-1 font-medium">Timetable</span>
          </button>

          <button
            onClick={() => setIsQiblaOpen(true)}
            className="flex flex-col items-center justify-center cursor-pointer text-slate-400 hover:text-emerald-400 py-1"
          >
            <Compass className="w-5 h-5" />
            <span className="text-[10px] mt-1 font-medium">Qibla</span>
          </button>

          <button
            onClick={() => setIsSettingsOpen(true)}
            className="flex flex-col items-center justify-center cursor-pointer text-slate-400 hover:text-emerald-400 py-1"
          >
            <SettingsIcon className="w-5 h-5" />
            <span className="text-[10px] mt-1 font-medium">Settings</span>
          </button>
        </div>
      </nav>

      {/* Active Alarm or Adhan Ringing Overlay */}
      <AlarmRingingOverlay
        activeAlarm={activeAlarm}
        onDismiss={dismissActiveAlarm}
        onSnooze={snoozeActiveAlarm}
      />

      {/* October 2026 Timetable Modal */}
      <TimetableModal
        isOpen={isTimetableOpen}
        onClose={() => setIsTimetableOpen(false)}
        activeDay={activeDate.getDate()}
        onSelectDay={day => {
          const d = new Date(2026, 9, day);
          setActiveDate(d);
        }}
        settings={settings}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={updateSettings}
        onTestAdhan={testAdhan}
        onTestAlarm={testAlarm}
        onOpenBatteryGuide={() => {
          setIsSettingsOpen(false);
          setIsBatteryGuideOpen(true);
        }}
      />

      {/* Qibla Direction Compass Modal */}
      <QiblaCompassModal
        isOpen={isQiblaOpen}
        onClose={() => setIsQiblaOpen(false)}
      />

      {/* Android Battery Optimization Guide Modal */}
      <BatteryOptimizationModal
        isOpen={isBatteryGuideOpen}
        onClose={() => setIsBatteryGuideOpen(false)}
      />
    </div>
  );
}
