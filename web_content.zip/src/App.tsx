import { AppStateProvider, useAppState } from "./state/AppState";
import { FormulaHistoryProvider } from "./state/FormulaHistoryState";
import { QuizStateProvider } from "./state/QuizState";
import { AiUsageProvider } from "./state/AiUsageState";
import Header from "./components/Header";
import Home from "./components/Home";
import ClassExplorer from "./components/ClassExplorer";
import SearchView from "./components/SearchView";
import { FavoritesView, RecentView } from "./components/ListViews";
import FormulaDetail from "./components/FormulaDetail";
import ProblemSolver from "./components/ProblemSolver";
import FormulaHistoryView from "./components/FormulaHistoryView";
import Quiz from "./components/Quiz";
import AiTutor from "./components/AiTutor";
import ErrorBoundary from "./components/ErrorBoundary";
import OfflineBanner from "./components/OfflineBanner";

function Screen() {
  const { screen } = useAppState();

  switch (screen.name) {
    case "home":
      return <Home />;
    case "class":
      return <ClassExplorer classLevel={screen.classLevel} subject={screen.subject} chapter={screen.chapter} />;
    case "search":
      return <SearchView />;
    case "favorites":
      return <FavoritesView />;
    case "recent":
      return <RecentView />;
    case "solver":
      return <ProblemSolver />;
    case "history":
      return <FormulaHistoryView />;
    case "quiz":
      return <Quiz />;
    case "ai":
      return <AiTutor />;
    case "formula":
      return <FormulaDetail id={screen.id} />;
    default:
      return <Home />;
  }
}

export default function App() {
  return (
    <AppStateProvider>
      <FormulaHistoryProvider>
        <QuizStateProvider>
          <AiUsageProvider>
            <div className="min-h-screen bg-slate-50 text-slate-900 transition-colors dark:bg-slate-950 dark:text-slate-100">
              <OfflineBanner />
              <Header />
              <main className="pb-16">
                <ErrorBoundary>
                  <Screen />
                </ErrorBoundary>
              </main>
              <footer className="border-t border-slate-200 py-6 text-center text-xs text-slate-400 dark:border-slate-800 dark:text-slate-600">
                FormulaVerse · Class 8–10 Formula Library · Built for understanding, not memorizing.
              </footer>
            </div>
          </AiUsageProvider>
        </QuizStateProvider>
      </FormulaHistoryProvider>
    </AppStateProvider>
  );
}
