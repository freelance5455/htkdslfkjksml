import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Bot,
  Calculator,
  CheckCircle2,
  ClipboardCheck,
  Compass,
  Droplets,
  Flame,
  GraduationCap,
  Hammer,
  HardHat,
  HelpCircle,
  Home,
  Languages,
  Layers,
  LayoutGrid,
  PlaySquare,
  Ruler,
  Search,
  ShieldAlert,
  Wrench,
  X,
} from 'lucide-react';
import { CategoryTile, LangMode, SectionId } from './data/types';
import {
  ATOZ_ENTRIES,
  JOINTING_METHODS,
  PIPE_FITTINGS,
  PIPE_MATERIALS,
  PIPE_SIZES,
  PPR_FUSION_TABLE,
  SUPPLY_DWV_SYSTEMS,
} from './data/pipesAndFittings';
import {
  BUILDING_PHASES,
  DAILY_SITE_INSTRUCTIONS,
  DUBAI_STANDARDS,
  FIXTURE_ROUGH_INS,
  PLUMBING_TOOLS,
  PUMP_TANK_GUIDES,
  SAFETY_RULES,
  SECTOR_COMPARISONS,
  TROUBLESHOOTING_ITEMS,
} from './data/installationAndDubai';
import { INTERVIEW_QAS, VOCAB_WORDS } from './data/vocabQuizAndCareer';
import { BiTextBlock, SafeImage } from './components/BilingualBlock';
import { BlueprintStudio, FittingGraphic } from './components/FittingAndBlueprintSvgs';
import { BoqEstimator, CalculatorsPanel } from './components/CalculatorsAndBoq';
import { InterviewPanel, QuizPanel, VocabularyPanel } from './components/VocabQuizAndCareer';
import { AiPlumberAssistant, MediaLessonsPanel } from './components/MediaAndAiAssistant';
import { DailySiteRoutine } from './components/DailySiteRoutine';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallBanner';

const CATEGORY_TILES: CategoryTile[] = [
  {
    id: 'atoz',
    topicNumber: '01',
    group: 'core',
    title: { en: 'Plumbing A to Z', hi: 'प्लंबिंग A से Z ज्ञान' },
    subtitle: { en: '26 core concepts & field tips', hi: '26 जरूरी शब्द व प्रैक्टिकल टिप्स' },
  },
  {
    id: 'pipes',
    topicNumber: '02',
    group: 'core',
    title: { en: 'Pipe Sizes & Materials', hi: 'पाइप साइज (15–110mm) व मटेरियल' },
    subtitle: { en: '15mm–110mm · PPR, uPVC, CPVC, GI, Copper', hi: 'इंच/mm चार्ट व सभी पाइप के प्रकार' },
  },
  {
    id: 'fittings',
    topicNumber: '03',
    group: 'core',
    title: { en: 'Pipe Fittings & Traps', hi: 'पाइप फिटिंग्स और ट्रैप' },
    subtitle: { en: 'Elbow, Tee, Socket, Reducer, Union, Valve, Bend', hi: 'एल्बो, टी, सॉकेट, यूनियन, वॉल्व व ट्रैप' },
  },
  {
    id: 'supply_dwv',
    topicNumber: '04',
    group: 'core',
    title: { en: 'Supply, Drainage & Vent', hi: 'वाटर सप्लाई, ड्रेनेज और वेंट' },
    subtitle: { en: 'Cold, hot, soil, greywater & vent stacks', hi: 'गर्म-ठंडा पानी, सॉइल, वेस्ट व वेंट सिस्टम' },
  },
  {
    id: 'bathroom_kitchen',
    topicNumber: '05',
    group: 'field',
    title: { en: 'Bathroom & Kitchen Setup', hi: 'बाथरूम, किचन व शावर फिटिंग' },
    subtitle: { en: 'WC, basin, shower mixer heights & rough-in', hi: 'टॉयलेट, बेसिन व मिक्सर ऊंचाई माप' },
  },
  {
    id: 'jointing',
    topicNumber: '06',
    group: 'field',
    title: { en: 'Welding, Threading & Joints', hi: 'कटिंग, थ्रेडिंग और PPR वेल्डिंग' },
    subtitle: { en: '260°C PPR fusion table, solvent & GI threads', hi: '260°C फ्यूजन चार्ट, ग्लू व चूड़ी बनाना' },
  },
  {
    id: 'diagrams',
    topicNumber: '07',
    group: 'tools',
    title: { en: 'Drawings, Symbols & Plans', hi: 'प्लंबिंग ड्रॉइंग, सिंबल और नक्शा' },
    subtitle: { en: 'Interactive isometric blueprints & symbols', hi: 'बाथरूम, किचन व राइजर इंटरैक्टिव नक्शा' },
  },
  {
    id: 'calculators',
    topicNumber: '08',
    group: 'tools',
    title: { en: 'Slope, Offset & Tank Calc', hi: 'स्लोप, ऑफसेट और टैंक कैलकुलेटर' },
    subtitle: { en: '1:40–1:100 fall, 45° travel & tank sizing', hi: 'ढलान mm/cm और 45° पाइप लंबाई निकालें' },
  },
  {
    id: 'pumps_tanks',
    topicNumber: '09',
    group: 'field',
    title: { en: 'Pumps, Tanks & Heaters', hi: 'पंप, टंकी, गीजर और बूस्टर' },
    subtitle: { en: 'Booster skids, pressure vessel & solar heaters', hi: 'बूस्टर पंप, टैंक फिटिंग व गीजर सेफ्टी' },
  },
  {
    id: 'testing_repair',
    topicNumber: '10',
    group: 'field',
    title: { en: 'Leak Detection & Testing', hi: 'लीकेज, ब्लॉकेज और प्रेशर टेस्ट' },
    subtitle: { en: '10 Bar hydrostatic test & choke removal', hi: '10 Bar प्रेशर टेस्ट और जाम पाइप खोलना' },
  },
  {
    id: 'dubai_site',
    topicNumber: '11',
    group: 'field',
    title: { en: 'Dubai / UAE & Daily Routine', hi: 'दुबई/UAE नियम और डेली रूटीन' },
    subtitle: { en: 'DEWA/DM specs, daily site routine checklist & tasks', hi: 'DEWA स्टैंडर्ड व डेली साइट चेकलिस्ट' },
  },
  {
    id: 'building_phases',
    topicNumber: '12',
    group: 'field',
    title: { en: 'Building Start to Finish', hi: 'पूरी बिल्डिंग प्लंबिंग (1 से 6 फेज)' },
    subtitle: { en: 'Foundation sleeves to handover · Res/Com/Ind', hi: 'नींव से हैंडओवर और घरेलू/कमर्शियल अंतर' },
  },
  {
    id: 'tools',
    topicNumber: '13',
    group: 'tools',
    title: { en: 'Plumbing Tools & Photos', hi: 'प्लंबिंग टूल्स व औजार की फोटो' },
    subtitle: { en: 'PPR welder, cutters, wrenches & test pump', hi: 'वेल्डर, कटर, रिंच, स्पिरिट लेवल व पंप' },
  },
  {
    id: 'safety',
    topicNumber: '14',
    group: 'field',
    title: { en: 'Plumbing Safety & PPE', hi: 'प्लंबिंग सेफ्टी नियम और PPE' },
    subtitle: { en: 'PPE checklist, 260°C burns & manhole safety', hi: 'हेलमेट, चश्मा, ग्लू व मैनहोल सुरक्षा' },
  },
  {
    id: 'media_lessons',
    topicNumber: '15',
    group: 'tools',
    title: { en: 'Photo & Video Lessons', hi: 'फोटो और वीडियो स्टेप-बाय-स्टेप' },
    subtitle: { en: 'Interactive frame-by-frame visual tutorials', hi: 'असली साइट फोटो के साथ आसान ट्रेनिंग' },
  },
  {
    id: 'vocabulary',
    topicNumber: '16',
    group: 'career',
    title: { en: 'English · Arabic · Hindi Words', hi: 'अंग्रेजी · अरबी · हिंदी शब्दकोश' },
    subtitle: { en: '44+ Gulf site words with audio & pronunciation', hi: 'दुबई साइट के अरबी शब्द व उच्चारण' },
  },
  {
    id: 'interview_quiz',
    topicNumber: '17',
    group: 'career',
    title: { en: 'Interview Q&A & Skill Quiz', hi: 'इंटरव्यू सवाल-जवाब व प्रैक्टिस टेस्ट' },
    subtitle: { en: 'Gulf trade test questions & live MCQ quiz', hi: 'दुबई ट्रेड टेस्ट तैयारी और क्विज़' },
  },
  {
    id: 'boq',
    topicNumber: '18',
    group: 'tools',
    title: { en: 'Material List & BOQ Costing', hi: 'मटेरियल लिस्ट (BOQ) और खर्च' },
    subtitle: { en: 'Auto-calculate bathroom & kitchen BOM in AED/INR', hi: 'सामान की मात्रा व कीमत का तुरंत हिसाब' },
  },
];

function getTileIcon(id: SectionId) {
  switch (id) {
    case 'atoz': return <BookOpen className="w-5 h-5" />;
    case 'pipes': return <Ruler className="w-5 h-5" />;
    case 'fittings': return <Layers className="w-5 h-5" />;
    case 'supply_dwv': return <Droplets className="w-5 h-5" />;
    case 'bathroom_kitchen': return <Home className="w-5 h-5" />;
    case 'jointing': return <Flame className="w-5 h-5" />;
    case 'diagrams': return <Compass className="w-5 h-5" />;
    case 'calculators': return <Calculator className="w-5 h-5" />;
    case 'pumps_tanks': return <Droplets className="w-5 h-5" />;
    case 'testing_repair': return <ClipboardCheck className="w-5 h-5" />;
    case 'dubai_site': return <CheckCircle2 className="w-5 h-5" />;
    case 'building_phases': return <LayoutGrid className="w-5 h-5" />;
    case 'tools': return <Wrench className="w-5 h-5" />;
    case 'safety': return <HardHat className="w-5 h-5" />;
    case 'media_lessons': return <PlaySquare className="w-5 h-5" />;
    case 'vocabulary': return <Languages className="w-5 h-5" />;
    case 'interview_quiz': return <GraduationCap className="w-5 h-5" />;
    case 'boq': return <Hammer className="w-5 h-5" />;
    default: return <Bot className="w-5 h-5" />;
  }
}

interface SearchHit {
  section: SectionId;
  categoryLabel: string;
  title: string;
  subtitle: string;
}

export default function App() {
  const [activeSection, setActiveSection] = useState<SectionId>('home');
  const [lang, setLang] = useState<LangMode>('both');
  const [globalSearch, setGlobalSearch] = useState('');
  const [selectedLetter, setSelectedLetter] = useState<string>('ALL');
  const [selectedPipeMm, setSelectedPipeMm] = useState<number>(25);
  const [fittingFilter, setFittingFilter] = useState<string>('All');
  const [careerTab, setCareerTab] = useState<'interview' | 'quiz'>('interview');
  const [checkedSteps, setCheckedSteps] = useState<Record<string, boolean>>({});

  const navigateTo = (sec: SectionId) => {
    setActiveSection(sec);
    setGlobalSearch('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Global cross-topic search index
  const searchResults = useMemo<SearchHit[]>(() => {
    const q = globalSearch.trim().toLowerCase();
    if (!q) return [];
    const hits: SearchHit[] = [];

    CATEGORY_TILES.forEach((tile) => {
      if (
        tile.title.en.toLowerCase().includes(q) ||
        tile.title.hi.includes(q) ||
        tile.subtitle.en.toLowerCase().includes(q)
      ) {
        hits.push({
          section: tile.id,
          categoryLabel: 'Module',
          title: tile.title.en,
          subtitle: tile.title.hi,
        });
      }
    });

    ATOZ_ENTRIES.forEach((item) => {
      if (
        item.term.toLowerCase().includes(q) ||
        item.hindiTerm.includes(q) ||
        item.summary.en.toLowerCase().includes(q) ||
        item.summary.hi.includes(q)
      ) {
        hits.push({
          section: 'atoz',
          categoryLabel: `A–Z (${item.letter})`,
          title: item.term,
          subtitle: item.hindiTerm,
        });
      }
    });

    PIPE_SIZES.forEach((p) => {
      if (
        `${p.mm}mm`.includes(q) ||
        p.inch.includes(q) ||
        p.materials.toLowerCase().includes(q) ||
        p.usage.en.toLowerCase().includes(q)
      ) {
        hits.push({
          section: 'pipes',
          categoryLabel: 'Pipe Size',
          title: `${p.mm}mm (${p.inch}) · ${p.materials}`,
          subtitle: p.usage.hi,
        });
      }
    });

    PIPE_FITTINGS.forEach((f) => {
      if (
        f.name.toLowerCase().includes(q) ||
        f.hindiName.includes(q) ||
        f.purpose.en.toLowerCase().includes(q)
      ) {
        hits.push({
          section: 'fittings',
          categoryLabel: 'Fitting',
          title: f.name,
          subtitle: f.hindiName,
        });
      }
    });

    VOCAB_WORDS.forEach((v) => {
      if (
        v.english.toLowerCase().includes(q) ||
        v.arabicPronunciation.toLowerCase().includes(q) ||
        v.hindi.includes(q) ||
        v.hinglish.toLowerCase().includes(q)
      ) {
        hits.push({
          section: 'vocabulary',
          categoryLabel: 'Arabic Vocab',
          title: `${v.english} → ${v.arabicPronunciation} (${v.arabic})`,
          subtitle: v.hindi,
        });
      }
    });

    INTERVIEW_QAS.forEach((iq) => {
      if (iq.question.en.toLowerCase().includes(q) || iq.question.hi.includes(q)) {
        hits.push({
          section: 'interview_quiz',
          categoryLabel: 'Interview Q&A',
          title: iq.question.en,
          subtitle: iq.question.hi,
        });
      }
    });

    return hits.slice(0, 14);
  }, [globalSearch]);

  const activeTile = CATEGORY_TILES.find((t) => t.id === activeSection);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 pb-20 md:pb-8">
      {/* Strict 3-Zone Top Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          <button
            onClick={() => navigateTo('home')}
            className="text-lg font-extrabold tracking-tight text-blue-800 whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <Wrench className="w-5 h-5 text-blue-700" />
            <span>Farid Plumber Pro</span>
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => navigateTo('home')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 ${
                activeSection === 'home' ? 'text-blue-700 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => navigateTo('pipes')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 ${
                activeSection === 'pipes' ? 'text-blue-700 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Pipe Sizes
            </button>
            <button
              onClick={() => navigateTo('diagrams')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 ${
                activeSection === 'diagrams' ? 'text-blue-700 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Diagrams
            </button>
            <button
              onClick={() => navigateTo('calculators')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 ${
                activeSection === 'calculators' ? 'text-blue-700 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Calculators
            </button>
            <button
              onClick={() => navigateTo('vocabulary')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 ${
                activeSection === 'vocabulary' ? 'text-blue-700 font-semibold underline underline-offset-8' : ''
              }`}
            >
              Vocabulary
            </button>
          </nav>

          <div className="shrink-0">
            <button
              onClick={() => navigateTo('ai_assistant')}
              className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 min-h-[40px]"
            >
              <Bot className="w-4 h-4" />
              <span>AI Plumber</span>
            </button>
          </div>
        </div>
      </header>

      {/* Workspace Search & Bilingual Language Toolbar (below header) */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-2xl">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'कोई भी टॉपिक खोजें (जैसे: 25mm, Elbow, PPR, Dubai, Slope, Mahbas)...'
                  : 'Search any plumbing topic (e.g., 25mm, Elbow, PPR, Dubai, Slope, Mahbas)...'
              }
              className="w-full h-11 pl-10 pr-10 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            {globalSearch && (
              <button
                onClick={() => setGlobalSearch('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-200"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            {/* Instant Search Results Dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-12 z-40 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-96 overflow-y-auto divide-y divide-slate-100">
                {searchResults.map((hit, idx) => (
                  <button
                    key={`${hit.section}-${idx}`}
                    onClick={() => navigateTo(hit.section)}
                    className="w-full text-left px-4 py-3 hover:bg-blue-50 transition-colors flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-blue-700">{hit.categoryLabel}</div>
                      <div className="text-sm font-semibold text-slate-900 truncate">{hit.title}</div>
                      <div className="text-xs text-slate-600 truncate">{hit.subtitle}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
            {globalSearch.trim() && searchResults.length === 0 && (
              <div className="absolute left-0 right-0 top-12 z-40 bg-white border border-slate-200 rounded-2xl shadow-xl p-4 text-sm text-slate-600 flex items-center justify-between gap-3">
                <span>
                  {lang === 'hi'
                    ? `"${globalSearch}" नहीं मिला — AI प्लंबर से पूछें?`
                    : `No exact match for "${globalSearch}" — Ask AI Plumber instead?`}
                </span>
                <button
                  onClick={() => navigateTo('ai_assistant')}
                  className="px-3 py-1.5 rounded-lg bg-blue-700 text-white text-xs font-semibold shrink-0"
                >
                  Ask AI
                </button>
              </div>
            )}
          </div>

          {/* Bilingual Language Toggle */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200 self-start sm:self-auto">
            {(
              [
                { id: 'both', label: 'EN + हिन्दी' },
                { id: 'en', label: 'English' },
                { id: 'hi', label: 'हिन्दी' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                onClick={() => setLang(opt.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[36px] ${
                  lang === opt.id ? 'bg-blue-700 text-white shadow-sm' : 'text-slate-700 hover:bg-white'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* Back Breadcrumb when inside any learning module */}
        {activeSection !== 'home' && (
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigateTo('home')}
                className="h-11 px-3.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 text-xs font-semibold flex items-center gap-1.5 shrink-0"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{lang === 'hi' ? 'होम' : 'Dashboard'}</span>
              </button>
              <div>
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  {activeSection === 'ai_assistant'
                    ? lang === 'hi'
                      ? 'AI प्लंबर असिस्टेंट (उस्ताद फरीद)'
                      : 'AI Plumber Assistant — Ustad Farid'
                    : lang === 'hi'
                      ? activeTile?.title.hi
                      : activeTile?.title.en}
                </h1>
                {lang === 'both' && activeTile && (
                  <p className="text-sm text-blue-700 font-medium">{activeTile.title.hi}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* HOME DASHBOARD */}
        {activeSection === 'home' && (
          <div className="space-y-8">
            {/* Hero Split Banner */}
            <section className="bg-white border border-slate-200 rounded-3xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
              <div className="lg:col-span-7 p-6 sm:p-8 lg:p-10 flex flex-col justify-between gap-6">
                <div className="space-y-3">
                  <div className="text-xs font-semibold text-blue-700 tracking-wide">
                    Farid Plumber Pro · Hindi & English Master Training
                  </div>
                  <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight text-balance">
                    {lang === 'hi'
                      ? 'शुरुआत से प्रोफेशनल दुबई व इंडियन प्लंबिंग मास्टर बनें'
                      : 'Complete A to Z Plumbing Mastery for Beginners & Dubai Site Pros'}
                  </h1>
                  {lang === 'both' && (
                    <p className="text-base font-medium text-blue-800">
                      हिंदी और अंग्रेजी में पाइप साइज, फिटिंग, दुबई साइट नियम, ड्रॉइंग, कैलकुलेटर और AI उस्ताद।
                    </p>
                  )}
                  <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
                    {lang === 'hi'
                      ? '15mm से 110mm पाइप, PPR 260°C वेल्डिंग, बाथरूम-किचन राफ-इन ऊंचाई, 10 Bar प्रेशर टेस्ट, अरबी शब्दकोश, BOQ एस्टीमेटर और इंटरव्यू तैयारी सब कुछ एक ही ऐप में।'
                      : 'Master 15mm–110mm pipe sizing, fittings, PPR 260°C fusion, bathroom & kitchen rough-ins, 10 Bar pressure testing, Arabic site vocabulary, BOQ costing, and live AI troubleshooting.'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => navigateTo('atoz')}
                    className="h-12 px-5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
                  >
                    {lang === 'hi' ? 'A से Z सीखना शुरू करें' : 'Start A to Z Learning'}
                  </button>
                  <button
                    onClick={() => navigateTo('dubai_site')}
                    className="h-12 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
                  >
                    {lang === 'hi' ? 'दुबई व UAE साइट गाइड' : 'Dubai & UAE Methods'}
                  </button>
                  <PWAInstallButton lang={lang} />
                </div>
              </div>

              <div className="lg:col-span-5 relative min-h-[220px] lg:min-h-full bg-slate-900">
                <SafeImage
                  src="/src/assets/images/hero_plumbing_workshop.jpg"
                  alt="Organized copper and PPR plumbing manifold with pressure gauges"
                  className="w-full h-full lg:h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-slate-950/10 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white text-xs">
                  <div className="font-semibold">DEWA & International Rough-In Standard</div>
                  <div className="text-slate-200">Hot Left · Cold Right · 10 Bar Tested</div>
                </div>
              </div>
            </section>

            {/* 4-Column Quick Metrics Strip */}
            <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              {[
                { val: '15–110 mm', label: lang === 'hi' ? 'सभी पाइप साइज व इंच चार्ट' : 'All Pipe Sizes & Inch Chart', target: 'pipes' as SectionId },
                { val: '260°C · 10 Bar', label: lang === 'hi' ? 'PPR वेल्डिंग व प्रेशर टेस्ट' : 'PPR Fusion & Dubai Testing', target: 'jointing' as SectionId },
                { val: '44+ Words', label: lang === 'hi' ? 'अंग्रेजी–अरबी–हिंदी शब्दकोश' : 'Arabic–Hindi Site Vocabulary', target: 'vocabulary' as SectionId },
                { val: '24/7 AI', label: lang === 'hi' ? 'उस्ताद फरीद से सवाल पूछें' : 'Ask Ustad Farid AI Mentor', target: 'ai_assistant' as SectionId },
              ].map((stat) => (
                <button
                  key={stat.val}
                  onClick={() => navigateTo(stat.target)}
                  className="bg-white border border-slate-200 hover:border-blue-400 rounded-2xl p-4 text-left transition-colors"
                >
                  <div className="text-lg sm:text-xl font-extrabold font-mono-num text-blue-700">{stat.val}</div>
                  <div className="text-xs sm:text-sm font-medium text-slate-700 mt-1">{stat.label}</div>
                </button>
              ))}
            </section>

            {/* Large Clickable Category Buttons Grid */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">
                    {lang === 'hi' ? 'सभी 18 प्लंबिंग लर्निंग सेक्शन' : 'All Plumbing Master Modules'}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600">
                    {lang === 'hi'
                      ? 'शुरुआती से मास्टर प्लंबर तक — किसी भी बड़े बटन पर क्लिक करें'
                      : 'Tap any category button to open step-by-step lessons, diagrams, and tools'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
                {CATEGORY_TILES.map((tile) => (
                  <button
                    key={tile.id}
                    onClick={() => navigateTo(tile.id)}
                    className="group bg-white border border-slate-200 hover:border-blue-600 hover:shadow-md rounded-2xl p-4 sm:p-5 text-left transition-all flex items-start gap-4 min-h-[96px]"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 group-hover:bg-blue-700 group-hover:text-white text-blue-700 flex items-center justify-center shrink-0 transition-colors">
                      {getTileIcon(tile.id)}
                    </div>
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="text-xs font-mono-num text-slate-400 font-semibold">
                        {tile.topicNumber}
                      </div>
                      <h3 className="font-bold text-slate-900 text-base leading-snug group-hover:text-blue-700 transition-colors">
                        {lang === 'hi' ? tile.title.hi : tile.title.en}
                      </h3>
                      {lang === 'both' && (
                        <div className="text-xs font-medium text-blue-700">{tile.title.hi}</div>
                      )}
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {lang === 'hi' ? tile.subtitle.hi : tile.subtitle.en}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* 1. PLUMBING A TO Z */}
        {activeSection === 'atoz' && (
          <div className="space-y-5">
            <div className="flex flex-wrap gap-1.5 bg-white p-3 rounded-2xl border border-slate-200">
              <button
                onClick={() => setSelectedLetter('ALL')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold min-h-[36px] ${
                  selectedLetter === 'ALL' ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-700'
                }`}
              >
                ALL (A–Z)
              </button>
              {ATOZ_ENTRIES.map((e) => (
                <button
                  key={e.letter}
                  onClick={() => setSelectedLetter(e.letter)}
                  className={`w-9 h-9 rounded-lg text-xs font-bold font-mono-num ${
                    selectedLetter === e.letter
                      ? 'bg-blue-700 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-blue-50'
                  }`}
                >
                  {e.letter}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {ATOZ_ENTRIES.filter((e) => selectedLetter === 'ALL' || e.letter === selectedLetter).map((entry) => (
                <div key={entry.letter} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-blue-700 text-white font-extrabold font-mono-num text-lg flex items-center justify-center shrink-0">
                      {entry.letter}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">{entry.term}</h3>
                      <div className="text-xs font-semibold text-blue-700">{entry.hindiTerm}</div>
                    </div>
                  </div>
                  <BiTextBlock text={entry.summary} lang={lang} className="text-sm text-slate-700 leading-relaxed" />
                  <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-100 text-xs">
                    <span className="font-bold text-blue-900 block mb-1">
                      {lang === 'hi' ? 'फील्ड उस्ताद टिप:' : 'Field Pro Tip:'}
                    </span>
                    <BiTextBlock text={entry.fieldTip} lang={lang} className="text-xs text-blue-950" hiClassName="text-xs text-blue-900" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 2. PIPE SIZES (15mm–110mm) & MATERIALS */}
        {activeSection === 'pipes' && (
          <div className="space-y-8">
            {/* Interactive Pipe Size Comparison */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-5">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  {lang === 'hi' ? '15mm से 110mm पाइप साइज तुलना (क्लिक करें)' : 'Interactive Pipe Diameter Comparison (15mm – 110mm)'}
                </h2>
                <p className="text-xs text-slate-600">
                  {lang === 'hi' ? 'हर साइज पर क्लिक करके उसका इंच, उपयोग और दीवार नियम देखें' : 'Tap any diameter to inspect inch equivalent, material, and usage'}
                </p>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {PIPE_SIZES.map((p) => (
                  <button
                    key={p.mm}
                    onClick={() => setSelectedPipeMm(p.mm)}
                    className={`p-3 rounded-xl border text-center transition-all min-h-[68px] flex flex-col items-center justify-center ${
                      selectedPipeMm === p.mm
                        ? 'bg-blue-700 border-blue-800 text-white shadow-sm'
                        : 'bg-slate-50 border-slate-200 text-slate-800 hover:border-blue-400'
                    }`}
                  >
                    <span className="font-bold font-mono-num text-sm">{p.mm}mm</span>
                    <span className={`text-xs font-mono-num ${selectedPipeMm === p.mm ? 'text-blue-100' : 'text-slate-500'}`}>
                      {p.inch}
                    </span>
                  </button>
                ))}
              </div>

              {(() => {
                const activePipe = PIPE_SIZES.find((p) => p.mm === selectedPipeMm) || PIPE_SIZES[2];
                const circleSize = Math.max(24, Math.min(112, activePipe.mm));
                return (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center bg-slate-50 border border-slate-200 rounded-2xl p-5">
                    <div className="md:col-span-4 flex flex-col items-center justify-center py-4">
                      <div
                        className="rounded-full border-[6px] border-blue-700 bg-blue-100/70 flex items-center justify-center font-mono-num font-extrabold text-blue-950 text-xs transition-all"
                        style={{ width: `${circleSize + 18}px`, height: `${circleSize + 18}px` }}
                      >
                        {activePipe.mm}mm
                      </div>
                      <div className="mt-3 text-xs font-mono-num text-slate-600">
                        {activePipe.dn} · {activePipe.inch} · {activePipe.pressureRating}
                      </div>
                    </div>
                    <div className="md:col-span-8 space-y-3">
                      <div className="text-sm font-semibold text-blue-700">Materials: {activePipe.materials}</div>
                      <BiTextBlock text={activePipe.usage} lang={lang} className="text-sm font-medium text-slate-900" />
                      <div className="p-3 bg-white border border-slate-200 rounded-xl">
                        <BiTextBlock text={activePipe.wallNote} lang={lang} className="text-xs text-slate-700" hiClassName="text-xs text-slate-600" />
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* All Pipe Materials Matrix */}
            <div className="space-y-3">
              <h2 className="text-lg font-bold text-slate-900">
                {lang === 'hi' ? 'पाइप के सभी प्रकार (PPR, PVC, uPVC, CPVC, HDPE, GI, Copper)' : 'All Piping Materials & Applications'}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {PIPE_MATERIALS.map((mat) => (
                  <div key={mat.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                    <div className="flex items-baseline justify-between gap-2 border-b border-slate-100 pb-2.5">
                      <h3 className="text-lg font-extrabold text-blue-800">{mat.name}</h3>
                      <span className="text-xs font-mono-num text-slate-500">{mat.tempMax} · {mat.pressureMax}</span>
                    </div>
                    <div className="text-xs font-semibold text-slate-800">{mat.fullName}</div>
                    <div className="text-xs text-slate-500">Color: {mat.colorCode}</div>
                    <div className="text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="font-semibold text-slate-800 block mb-0.5">
                        {lang === 'hi' ? 'जोड़ने का तरीका:' : 'Joining Method:'}
                      </span>
                      <BiTextBlock text={mat.joining} lang={lang} className="text-xs text-slate-700" hiClassName="text-xs text-slate-600" />
                    </div>
                    <BiTextBlock text={mat.bestFor} lang={lang} className="text-xs text-slate-700" hiClassName="text-xs text-slate-600" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 3. PIPE FITTINGS */}
        {activeSection === 'fittings' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 items-center">
              <div className="md:col-span-5">
                <SafeImage
                  src="/src/assets/images/fittings_pipes_collection.jpg"
                  alt="Plumbing pipe fittings studio reference"
                  className="w-full h-56 md:h-full object-cover"
                />
              </div>
              <div className="md:col-span-7 p-5 sm:p-6 space-y-3">
                <h2 className="text-lg font-bold text-slate-900">
                  {lang === 'hi' ? 'एल्बो, टी, सॉकेट, रिड्यूसर, यूनियन, वॉल्व व ट्रैप' : 'Essential Plumbing Fittings Reference'}
                </h2>
                <p className="text-sm text-slate-600">
                  {lang === 'hi'
                    ? 'नीचे फिल्टर चुनकर हर फिटिंग का नक्शा, काम और लगाने का सही तरीका पढ़ें।'
                    : 'Filter by category to examine technical profiles, purpose, and site installation tips.'}
                </p>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {['All', 'Direction & Branch', 'Connection & Size', 'Valves', 'Traps'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setFittingFilter(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold min-h-[38px] ${
                        fittingFilter === cat
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {PIPE_FITTINGS.filter((f) => fittingFilter === 'All' || f.category === fittingFilter).map((fit) => (
                <div key={fit.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <div className="bg-slate-50 rounded-xl p-2 border border-slate-100">
                    <FittingGraphic type={fit.svgType} />
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">{fit.category}</div>
                    <h3 className="font-bold text-slate-900 text-base">{fit.name}</h3>
                    <div className="text-xs font-semibold text-blue-700">{fit.hindiName}</div>
                  </div>
                  <BiTextBlock text={fit.purpose} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                  <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-100">
                    <BiTextBlock text={fit.installationTip} lang={lang} className="text-xs text-blue-950" hiClassName="text-xs text-blue-900" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. WATER SUPPLY & DWV */}
        {activeSection === 'supply_dwv' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {SUPPLY_DWV_SYSTEMS.map((sys) => (
              <div key={sys.id} className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <span className="text-xs font-mono-num font-bold text-blue-700">
                    {sys.system === 'supply' ? 'WATER SUPPLY' : 'DWV DRAINAGE'} · {sys.pipeSizes}
                  </span>
                  <span className="text-xs text-slate-500">{sys.colorOrSlope}</span>
                </div>
                <BiTextBlock text={sys.title} lang={lang} className="text-lg font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-700" />
                <BiTextBlock text={sys.description} lang={lang} className="text-sm text-slate-700 leading-relaxed" />
                <ul className="space-y-2 pt-2 border-t border-slate-100">
                  {sys.keyPoints.map((kp, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                      <BiTextBlock text={kp} lang={lang} className="text-xs text-slate-800" hiClassName="text-xs text-slate-600" />
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        {/* 5. BATHROOM & KITCHEN INSTALLATION */}
        {activeSection === 'bathroom_kitchen' && (
          <div className="space-y-6">
            <div className="p-4 rounded-2xl bg-blue-700 text-white flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs text-blue-100">Universal Rough-In Golden Rule</div>
                <div className="font-bold text-base">
                  {lang === 'hi'
                    ? 'गर्म पानी हमेशा बाईं तरफ (LEFT) · ठंडा पानी हमेशा दाईं तरफ (RIGHT) · सेंटर 150mm'
                    : 'HOT is Always LEFT · COLD is Always RIGHT · Wall Mixer Centers = 150 mm'}
                </div>
              </div>
              <button
                onClick={() => navigateTo('diagrams')}
                className="px-4 py-2 rounded-xl bg-white text-blue-800 text-xs font-bold shrink-0"
              >
                {lang === 'hi' ? 'ब्लूप्रिंट नक्शा देखें' : 'Open Blueprint'}
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {FIXTURE_ROUGH_INS.map((fix) => (
                <div key={fix.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                  <BiTextBlock
                    text={fix.fixture}
                    lang={lang}
                    className="text-base sm:text-lg font-bold text-slate-900"
                    hiClassName="text-sm font-semibold text-blue-700"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200 font-mono-num">
                    <div>
                      <span className="text-slate-500 block font-sans">Supply Height:</span>
                      <span className="font-bold text-slate-900">{fix.waterSupplyHeight}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-sans">Drain Rough-In:</span>
                      <span className="font-bold text-slate-900">{fix.drainHeight}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-sans">Spacing / Note:</span>
                      <span className="font-bold text-blue-800">{fix.centerDistance}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-sans">Pipe Sizes:</span>
                      <span className="font-bold text-slate-900">{fix.pipeSizes}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {fix.steps.map((step, i) => {
                      const key = `${fix.id}-${i}`;
                      const checked = !!checkedSteps[key];
                      return (
                        <button
                          key={key}
                          onClick={() => setCheckedSteps((prev) => ({ ...prev, [key]: !prev[key] }))}
                          className={`w-full text-left p-3 rounded-xl border flex items-start gap-2.5 transition-colors ${
                            checked ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <span
                            className={`w-5 h-5 rounded-md text-xs font-mono-num font-bold flex items-center justify-center shrink-0 mt-0.5 ${
                              checked ? 'bg-emerald-600 text-white' : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {checked ? '✓' : i + 1}
                          </span>
                          <BiTextBlock text={step} lang={lang} className="text-xs sm:text-sm text-slate-800" hiClassName="text-xs text-slate-600" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. JOINTING, WELDING & THREADING */}
        {activeSection === 'jointing' && (
          <div className="space-y-6">
            {/* PPR 260C Fusion Reference Table */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  {lang === 'hi' ? 'PPR 260°C हीट वेल्डिंग समय चार्ट (20mm – 110mm)' : 'PPR 260°C Socket Fusion Timing Chart (20mm – 110mm)'}
                </h2>
                <p className="text-xs text-slate-600">
                  {lang === 'hi'
                    ? 'पाइप साइज के अनुसार ठीक इतने सेकंड गर्म करें—ज्यादा गर्म करने से पाइप अंदर से जाम हो सकता है।'
                    : 'Follow exact heating depth, heating seconds, and cooling minutes for leak-free PPR joints.'}
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm font-mono-num">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500 font-sans">
                      <th className="py-2.5 pr-4">Pipe Size</th>
                      <th className="py-2.5 px-3">Mark Depth</th>
                      <th className="py-2.5 px-3">Heating Time (260°C)</th>
                      <th className="py-2.5 px-3">Hold / Join Time</th>
                      <th className="py-2.5 pl-3">Cooling Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {PPR_FUSION_TABLE.map((row) => (
                      <tr key={row.sizeMm} className="hover:bg-blue-50/40">
                        <td className="py-2.5 pr-4 font-bold text-blue-800">{row.sizeMm}</td>
                        <td className="py-2.5 px-3 text-slate-800">{row.depthMm}</td>
                        <td className="py-2.5 px-3 font-semibold text-red-700">{row.heatingSec}</td>
                        <td className="py-2.5 px-3 text-slate-800">{row.joiningSec}</td>
                        <td className="py-2.5 pl-3 text-slate-600">{row.coolingMin}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Step-by-Step Jointing Guides */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {JOINTING_METHODS.map((method) => (
                <div key={method.id} className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between gap-4">
                  <div className="space-y-3">
                    <div className="text-xs font-mono-num text-blue-700 font-semibold">
                      {method.pipeTypes} · {method.temperature}
                    </div>
                    <BiTextBlock text={method.title} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-700" />
                    <ol className="space-y-2.5">
                      {method.steps.map((s, idx) => (
                        <li key={idx} className="flex items-start gap-2.5">
                          <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 text-xs font-mono-num font-bold flex items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <BiTextBlock text={s} lang={lang} className="text-xs sm:text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs">
                    <span className="font-bold text-red-900 block mb-0.5">
                      {lang === 'hi' ? 'सावधान (गलती न करें):' : 'Mistake to Avoid:'}
                    </span>
                    <BiTextBlock text={method.mistakeToAvoid} lang={lang} className="text-xs text-red-900" hiClassName="text-xs text-red-800" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 7. DIAGRAMS */}
        {activeSection === 'diagrams' && <BlueprintStudio lang={lang} />}

        {/* 8. CALCULATORS */}
        {activeSection === 'calculators' && <CalculatorsPanel lang={lang} />}

        {/* 9. PUMPS, TANKS & HEATERS */}
        {activeSection === 'pumps_tanks' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {PUMP_TANK_GUIDES.map((guide) => (
              <div key={guide.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <div className="text-xs font-mono-num text-blue-700 font-semibold">{guide.specs}</div>
                <BiTextBlock text={guide.title} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-700" />
                <BiTextBlock text={guide.explanation} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                <ul className="space-y-2 pt-3 border-t border-slate-100">
                  {guide.checklist.map((c, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                      <BiTextBlock text={c} lang={lang} className="text-xs sm:text-sm text-slate-800" hiClassName="text-xs text-slate-600" />
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        {/* 10. LEAK DETECTION, TESTING & REPAIR */}
        {activeSection === 'testing_repair' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 items-center">
              <div className="md:col-span-5">
                <SafeImage
                  src="/src/assets/images/pressure_test_pump.jpg"
                  alt="10 Bar Hydrostatic Pressure Test Pump"
                  className="w-full h-56 md:h-full object-cover"
                />
              </div>
              <div className="md:col-span-7 p-5 sm:p-6 space-y-3">
                <div className="text-xs font-mono-num font-bold text-blue-700">10 BAR (150 PSI) · ZERO DROP CHECK</div>
                <h2 className="text-lg font-bold text-slate-900">
                  {lang === 'hi' ? 'हाइड्रोस्टैटिक प्रेशर टेस्ट, लीकेज पहचान व जाम खोलना' : 'Pressure Testing, Leak Detection & Choke Troubleshooting'}
                </h2>
                <p className="text-sm text-slate-600">
                  {lang === 'hi'
                    ? 'दीवार बंद करने से पहले सभी पाइप में पानी भरकर हवा निकालें और 10 Bar प्रेशर पर कम से कम 2 घंटे जांच करें।'
                    : 'Always purge all trapped air, pressurize sealed lines to 10 Bar for 2–4 hours, and verify gauge stability before tiling.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {TROUBLESHOOTING_ITEMS.map((item) => (
                <div key={item.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <BiTextBlock text={item.issue} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-700" />
                  <div className="text-xs bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1">
                    <span className="font-bold text-slate-800 block">{lang === 'hi' ? 'मुख्य कारण:' : 'Root Cause:'}</span>
                    <BiTextBlock text={item.cause} lang={lang} className="text-xs text-slate-700" hiClassName="text-xs text-slate-600" />
                  </div>
                  <div className="text-xs bg-blue-50/70 p-3 rounded-xl border border-blue-100 space-y-1">
                    <span className="font-bold text-blue-900 block">{lang === 'hi' ? 'जांच कैसे करें:' : 'How to Detect:'}</span>
                    <BiTextBlock text={item.detectionMethod} lang={lang} className="text-xs text-blue-950" hiClassName="text-xs text-blue-900" />
                  </div>
                  <ol className="space-y-2 pt-1">
                    {item.fixSteps.map((st, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-md bg-slate-900 text-white text-xs font-mono-num flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <BiTextBlock text={st} lang={lang} className="text-xs text-slate-800" hiClassName="text-xs text-slate-600" />
                      </li>
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 11. DUBAI & UAE METHODS + DAILY SITE INSTRUCTIONS */}
        {activeSection === 'dubai_site' && (
          <div className="space-y-8">
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 items-center">
              <div className="md:col-span-5">
                <SafeImage
                  src="/src/assets/images/dubai_bathroom_roughin.jpg"
                  alt="Dubai bathroom concealed cistern and insulated PPR lines"
                  className="w-full h-56 md:h-full object-cover"
                />
              </div>
              <div className="md:col-span-7 p-5 sm:p-6 space-y-3">
                <div className="text-xs font-bold text-blue-700">DEWA · Dubai Municipality · GCC MEP Practice</div>
                <h2 className="text-xl font-extrabold text-slate-900">
                  {lang === 'hi' ? 'दुबई और UAE प्लंबिंग मानक व साइट काम करने का तरीका' : 'UAE & Dubai MEP Plumbing Standards'}
                </h2>
                <p className="text-sm text-slate-600">
                  {lang === 'hi'
                    ? 'गल्फ में काम करने के लिए DEWA व म्युनिसिपैलिटी नियम, IR इंस्पेक्शन और रोज़ के साइट काम की आदतें समझना बहुत जरूरी है।'
                    : 'Essential UAE inspection practices, thermal insulation, multi-inlet floor traps, and daily site execution rules.'}
                </p>
              </div>
            </div>

            <DailySiteRoutine lang={lang} />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {DUBAI_STANDARDS.map((std) => (
                <div key={std.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <div className="text-xs font-bold text-blue-700">{std.authority}</div>
                  <BiTextBlock text={std.title} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-800" />
                  <BiTextBlock text={std.spec} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <BiTextBlock text={std.siteRule} lang={lang} className="text-xs text-slate-800" hiClassName="text-xs text-slate-600" />
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-bold text-slate-900">
                {lang === 'hi' ? 'रोज़मर्रा के साइट वर्क निर्देश (सुबह से शाम)' : 'Daily Site Work Instructions (Morning to Handover)'}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {DAILY_SITE_INSTRUCTIONS.map((brief) => (
                  <div key={brief.phase} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                    <div className="text-xs font-mono-num font-bold text-blue-700">{brief.phase}</div>
                    <BiTextBlock text={brief.title} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-800" />
                    <BiTextBlock text={brief.morningInstruction} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                    <div className="p-3 rounded-xl bg-blue-50 border border-blue-100">
                      <BiTextBlock text={brief.checkBeforeLeaving} lang={lang} className="text-xs text-blue-950" hiClassName="text-xs text-blue-900" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 12. BUILDING START TO FINISH + RES/COM/IND */}
        {activeSection === 'building_phases' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {BUILDING_PHASES.map((phase) => (
                <div key={phase.step} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <div className="text-xs font-mono-num font-bold text-blue-700">PHASE 0{phase.step}</div>
                  <BiTextBlock text={phase.title} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-800" />
                  <BiTextBlock text={phase.scope} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                  <div className="text-xs text-slate-500 pt-2 border-t border-slate-100">
                    Materials: <span className="font-semibold text-slate-800">{phase.materials}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-blue-50 border border-blue-100">
                    <BiTextBlock text={phase.inspectionGate} lang={lang} className="text-xs font-semibold text-blue-950" hiClassName="text-xs text-blue-900" />
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-bold text-slate-900">
                {lang === 'hi' ? 'घरेलू, कमर्शियल व इंडस्ट्रियल प्लंबिंग की तुलना' : 'Residential vs Commercial vs Industrial Plumbing'}
              </h3>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {SECTOR_COMPARISONS.map((sec, idx) => (
                  <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                    <BiTextBlock text={sec.sector} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-700" />
                    <div className="text-xs font-mono-num text-slate-600">
                      {sec.pipeSpecs} · {sec.pressure}
                    </div>
                    <BiTextBlock text={sec.keySystems} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 13. TOOLS */}
        {activeSection === 'tools' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {PLUMBING_TOOLS.map((tool) => (
              <div key={tool.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col">
                <SafeImage src={tool.photo} alt={tool.name} className="w-full h-48 object-cover" />
                <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                  <div className="space-y-2">
                    <h3 className="font-bold text-slate-900 text-base">{tool.name}</h3>
                    <div className="text-xs font-semibold text-blue-700">{tool.hindiName}</div>
                    <BiTextBlock text={tool.purpose} lang={lang} className="text-sm text-slate-700" hiClassName="text-xs text-slate-600" />
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <BiTextBlock text={tool.careTip} lang={lang} className="text-xs text-slate-700" hiClassName="text-xs text-slate-600" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 14. SAFETY & PPE */}
        {activeSection === 'safety' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {SAFETY_RULES.map((rule) => (
              <div key={rule.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-red-700">
                  <ShieldAlert className="w-4 h-4" />
                  <span>{rule.hazardLevel}</span>
                </div>
                <BiTextBlock text={rule.title} lang={lang} className="text-base font-bold text-slate-900" hiClassName="text-sm font-semibold text-blue-700" />
                <BiTextBlock text={rule.rule} lang={lang} className="text-sm text-slate-700 leading-relaxed" />
                <div className="p-3 rounded-xl bg-red-50 border border-red-200">
                  <span className="text-xs font-bold text-red-900 block mb-0.5">
                    {lang === 'hi' ? 'आपातकालीन कदम:' : 'Emergency Action:'}
                  </span>
                  <BiTextBlock text={rule.emergencyAction} lang={lang} className="text-xs text-red-950" hiClassName="text-xs text-red-900" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 15. MEDIA & STEP-BY-STEP VIDEO LESSONS */}
        {activeSection === 'media_lessons' && <MediaLessonsPanel lang={lang} />}

        {/* 16. ENGLISH - ARABIC - HINDI VOCABULARY */}
        {activeSection === 'vocabulary' && <VocabularyPanel lang={lang} />}

        {/* 17. INTERVIEW Q&A & SKILL QUIZ */}
        {activeSection === 'interview_quiz' && (
          <div className="space-y-6">
            <div className="flex p-1 bg-slate-200/70 rounded-xl w-fit">
              <button
                onClick={() => setCareerTab('interview')}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors min-h-[40px] flex items-center gap-2 ${
                  careerTab === 'interview' ? 'bg-white text-blue-800 shadow-sm' : 'text-slate-700'
                }`}
              >
                <HelpCircle className="w-4 h-4" />
                <span>{lang === 'hi' ? 'इंटरव्यू सवाल-जवाब' : 'Interview Q&A'}</span>
              </button>
              <button
                onClick={() => setCareerTab('quiz')}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors min-h-[40px] flex items-center gap-2 ${
                  careerTab === 'quiz' ? 'bg-white text-blue-800 shadow-sm' : 'text-slate-700'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>{lang === 'hi' ? 'प्रैक्टिस क्विज़ टेस्ट' : 'Practice Skill Quiz'}</span>
              </button>
            </div>
            {careerTab === 'interview' ? <InterviewPanel lang={lang} /> : <QuizPanel lang={lang} />}
          </div>
        )}

        {/* 18. BOQ & MATERIAL COSTING */}
        {activeSection === 'boq' && <BoqEstimator lang={lang} />}

        {/* 19. AI PLUMBER ASSISTANT */}
        {activeSection === 'ai_assistant' && <AiPlumberAssistant lang={lang} />}
      </main>

      {/* Quiet Footer */}
      <footer className="max-w-7xl w-full mx-auto px-4 sm:px-6 pt-4 pb-6 border-t border-slate-200 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
        <span>Farid Plumber Pro · Bilingual Hindi & English Plumbing Academy</span>
        <span>Pipe Sizes 15–110mm · DEWA / DM Methods · AI Plumbing Mentor</span>
      </footer>

      {/* Mobile Bottom Navigation Bar (Compact 64px thumb zone) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-5 items-center"
      >
        {(
          [
            { id: 'home', label: 'Home', icon: Home },
            { id: 'pipes', label: 'Pipes', icon: Ruler },
            { id: 'diagrams', label: 'Diagrams', icon: Compass },
            { id: 'vocabulary', label: 'Vocab', icon: Languages },
            { id: 'ai_assistant', label: 'AI Ustad', icon: Bot },
          ] as const
        ).map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => navigateTo(item.id)}
              className={`flex flex-col items-center justify-center h-full gap-1 ${
                active ? 'text-blue-700 font-bold' : 'text-slate-600'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <OfflineIndicator lang={lang} />
    </div>
  );
}
