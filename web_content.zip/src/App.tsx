// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — الواجهة: القوائم، HUD، اللمس، الحوار، الشاشات
// ═══════════════════════════════════════════════════════════════
import { useCallback, useEffect, useRef, useState } from "react";
import {
  CHARACTERS, CharacterDef, DEFAULT_SETTINGS, ENDINGS, KAGUNE_TYPE_AR, KEYART,
  Line, MISSIONS, SPEAKERS, SaveData,
} from "./game/data";
import { GameEngine, HudState } from "./game/engine";
import { clearSave, defaultSave, loadSave, storeSave } from "./game/systems";
import imgRen from "./assets/char_ren.jpg";
import imgGenji from "./assets/char_genji.jpg";
import imgHollow from "./assets/char_hollow.jpg";

const SPEAKER_IMG: Record<string, string> = {
  kuro: CHARACTERS[0].img,
  ren: imgRen,
  genji: imgGenji,
  mura: imgHollow,
};

type Screen = "boot" | "menu" | "select" | "game";

// ─────────────── أيقونات SVG ───────────────
const I = {
  sword: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 21l6-6M14 4l6 6-9 9-6-6 9-9z" /></svg>,
  heavy: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 3v10M8 7l4-4 4 4M5 21h14M7 17h10" /></svg>,
  dodge: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 12h13M13 6l6 6-6 6M4 5h6M4 19h6" /></svg>,
  jump: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 20V6M6 12l6-6 6 6" /></svg>,
  kagune: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 21c-4-3-8-6-8-11a8 8 0 0116 0c0 5-4 8-8 11z" /><circle cx="12" cy="10" r="2.6" /></svg>,
  skill: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2l2.4 7.2H22l-6 4.4 2.3 7.4-6.3-4.6-6.3 4.6L8 13.6l-6-4.4h7.6z" /></svg>,
  lock: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="7" /><path d="M12 2v4M12 18v4M2 12h4M18 12h4" /></svg>,
  block: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2l8 3v7c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V5l8-3z" /></svg>,
  interact: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9" /><path d="M12 8v5M12 16.5v.5" /></svg>,
  pause: <svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" /></svg>,
};

// ─────────────── أدوات واجهة ───────────────
function StatBar({ label, v, color }: { label: string; v: number; color: string }) {
  return (
    <div className="flex items-center gap-2 text-[11px]">
      <span className="w-10 shrink-0 text-stone-400">{label}</span>
      <div className="h-1.5 flex-1 bg-black/60 overflow-hidden skew-x-[-20deg]">
        <div className="h-full" style={{ width: `${v * 10}%`, background: color }} />
      </div>
    </div>
  );
}

function Panel({ title, children, onClose, wide }: { title: string; children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-[2px]" dir="rtl">
      <div className={`relative bg-[#0c0a0e]/95 border border-[#d21f3c]/40 shadow-[0_0_60px_rgba(210,31,60,0.15)] ${wide ? "w-[min(94vw,900px)]" : "w-[min(92vw,620px)]"} max-h-[86vh] overflow-y-auto p-5`}>
        <div className="absolute top-0 right-0 h-[3px] w-24 bg-[#d21f3c]" />
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl md:text-2xl font-extrabold text-stone-100">{title}</h2>
          <button onClick={onClose} className="pointer-events-auto px-3 py-1 border border-stone-600 text-stone-300 hover:border-[#d21f3c] hover:text-white text-sm">إغلاق ✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─────────────── الإعدادات ───────────────
function SettingsPanel({ s, onChange, onDone, editLayout, setEditLayout }: {
  s: typeof DEFAULT_SETTINGS; onChange: (p: Partial<typeof DEFAULT_SETTINGS>) => void;
  onDone: () => void; editLayout?: boolean; setEditLayout?: (v: boolean) => void;
}) {
  const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="flex items-center justify-between gap-4 py-2.5 border-b border-white/5">
      <span className="text-stone-300 text-sm">{label}</span>
      <div className="flex items-center gap-2">{children}</div>
    </div>
  );
  return (
    <div>
      <Row label="جودة الرسوميات (تُطبق عند بدء الجولة)">
        {(["منخفضة", "متوسطة", "عالية"] as const).map((q, i) => (
          <button key={q} onClick={() => onChange({ quality: i as 0 | 1 | 2 })}
            className={`px-3 py-1 text-xs border ${s.quality === i ? "bg-[#d21f3c] border-[#d21f3c] text-white" : "border-stone-600 text-stone-400 hover:border-stone-400"}`}>{q}</button>
        ))}
      </Row>
      <Row label={`موسيقى ${Math.round(s.music * 100)}%`}>
        <input type="range" min={0} max={100} value={s.music * 100} onChange={(e) => onChange({ music: +e.target.value / 100 })} className="w-40 accent-[#d21f3c]" />
      </Row>
      <Row label={`مؤثرات صوتية ${Math.round(s.sfx * 100)}%`}>
        <input type="range" min={0} max={100} value={s.sfx * 100} onChange={(e) => onChange({ sfx: +e.target.value / 100 })} className="w-40 accent-[#d21f3c]" />
      </Row>
      <Row label={`حساسية الكاميرا ${s.sens.toFixed(1)}`}>
        <input type="range" min={30} max={220} value={s.sens * 100} onChange={(e) => onChange({ sens: +e.target.value / 100 })} className="w-40 accent-[#d21f3c]" />
      </Row>
      <Row label={`حجم أزرار اللمس ${Math.round(s.touchScale * 100)}%`}>
        <input type="range" min={70} max={140} value={s.touchScale * 100} onChange={(e) => onChange({ touchScale: +e.target.value / 100 })} className="w-40 accent-[#d21f3c]" />
      </Row>
      <Row label="اهتزاز الكاميرا السينمائي">
        <button onClick={() => onChange({ shake: !s.shake })}
          className={`px-4 py-1 text-xs border ${s.shake ? "bg-[#d21f3c] border-[#d21f3c] text-white" : "border-stone-600 text-stone-400"}`}>{s.shake ? "مفعّل" : "معطّل"}</button>
      </Row>
      {setEditLayout && (
        <Row label="تحريك أماكن الأزرار (اسحب الأزرار في الشاشة)">
          <button onClick={() => setEditLayout(!editLayout)}
            className={`px-4 py-1 text-xs border ${editLayout ? "bg-[#ffb02e] border-[#ffb02e] text-black" : "border-stone-600 text-stone-400"}`}>{editLayout ? "جارٍ التعديل…" : "تعديل"}</button>
        </Row>
      )}
      <div className="mt-4 flex justify-end">
        <button onClick={onDone} className="px-6 py-2 bg-[#d21f3c] text-white font-display font-bold hover:bg-[#e6334f]">تم</button>
      </div>
    </div>
  );
}

// ─────────────── عنصر زر لمسي ───────────────
function TouchBtn({ id, icon, label, size, onDown, onUp, className = "", editLayout, offsets, setOffsets, ring }: {
  id: string; icon: React.ReactNode; label: string; size: number;
  onDown: () => void; onUp?: () => void; className?: string;
  editLayout: boolean; offsets: Record<string, { x: number; y: number }>;
  setOffsets: (o: Record<string, { x: number; y: number }>) => void;
  ring?: React.ReactNode;
}) {
  const off = offsets[id] || { x: 0, y: 0 };
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number } | null>(null);
  return (
    <div className="absolute select-none" style={{ transform: `translate(${off.x}px, ${off.y}px)`, touchAction: "none" }}
      onPointerDown={(e) => {
        e.stopPropagation();
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        if (editLayout) drag.current = { sx: e.clientX, sy: e.clientY, ox: off.x, oy: off.y };
        else onDown();
      }}
      onPointerMove={(e) => {
        if (editLayout && drag.current) {
          setOffsets({ ...offsets, [id]: { x: drag.current.ox + e.clientX - drag.current.sx, y: drag.current.oy + e.clientY - drag.current.sy } });
        }
      }}
      onPointerUp={(e) => {
        e.stopPropagation();
        if (editLayout) {
          drag.current = null;
          try { localStorage.setItem("dg2_btnpos", JSON.stringify(offsets)); } catch { /* ignore */ }
        } else onUp?.();
      }}
      onPointerCancel={() => { drag.current = null; onUp?.(); }}
    >
      <div className={`relative grid place-items-center rounded-full border-2 font-display font-bold active:scale-90 transition-transform ${editLayout ? "border-[#ffb02e] animate-pulse" : ""} ${className}`}
        style={{ width: size, height: size }}>
        {ring}
        <span className="w-[46%] h-[46%] block">{icon}</span>
        <span className="absolute -bottom-4 text-[9px] text-stone-400 whitespace-nowrap">{label}</span>
      </div>
    </div>
  );
}

// ─────────────── شاشة اللعب ───────────────
function GameView({ save, onExit, onEnding }: { save: SaveData; onExit: () => void; onEnding: (id: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [toasts, setToasts] = useState<{ id: number; msg: string; kind: string }[]>([]);
  const [dlg, setDlg] = useState<{ lines: Line[]; idx: number } | null>(null);
  const [typed, setTyped] = useState(0);
  const [modal, setModal] = useState<null | "pause" | "skills" | "missions" | "settings" | "guide">(null);
  const [dead, setDead] = useState(false);
  const [hurtKey, setHurtKey] = useState(0);
  const [editLayout, setEditLayout] = useState(false);
  const [offsets, setOffsets] = useState<Record<string, { x: number; y: number }>>(() => {
    try { return JSON.parse(localStorage.getItem("dg2_btnpos") || "{}"); } catch { return {}; }
  });
  const [, setForce] = useState(0);
  const toastId = useRef(0);
  const joy = useRef<{ id: number; ox: number; oy: number; x: number; y: number } | null>(null);
  const cam = useRef<{ id: number; x: number; y: number } | null>(null);

  const addToast = useCallback((msg: string, kind: string) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-3), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const eng = new GameEngine(canvas, save, {
      onHud: setHud,
      onToast: addToast,
      onDialogue: (lines) => {
        if (lines) setDlg({ lines, idx: 0 });
        else setDlg(null);
        setTyped(0);
      },
      onEnding: (id) => onEnding(id),
      onDeath: () => setDead(true),
      onHurt: () => setHurtKey((k) => k + 1),
      onMissionChanged: () => setForce((x) => x + 1),
    });
    engineRef.current = eng;
    if (minimapRef.current) eng.attachMinimap(minimapRef.current);
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Escape" || e.code === "KeyP") setModal((m) => (m ? null : "pause"));
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      eng.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engineRef.current?.setPaused(modal !== null);
  }, [modal]);

  // آلة كاتبة للحوار
  useEffect(() => {
    if (!dlg) return;
    setTyped(0);
    const line = dlg.lines[dlg.idx];
    if (!line) return;
    const iv = setInterval(() => setTyped((t) => {
      if (t >= line.t.length) { clearInterval(iv); return t; }
      return t + 1;
    }), 16);
    return () => clearInterval(iv);
  }, [dlg]);

  const advanceDlg = () => {
    if (!dlg) return;
    const line = dlg.lines[dlg.idx];
    if (line.c && typed >= line.t.length) return; // انتظر الاختيار
    if (typed < line.t.length) { setTyped(line.t.length); return; }
    if (dlg.idx + 1 < dlg.lines.length) { setDlg({ ...dlg, idx: dlg.idx + 1 }); }
    else engineRef.current?.endDialogue();
  };

  const press = (n: string) => engineRef.current?.press(n);
  const ts = save.settings.touchScale;

  // جويستيك
  const joyBase = useRef<HTMLDivElement>(null);
  const [joyKnob, setJoyKnob] = useState({ x: 0, y: 0 });
  const onJoyDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    const r = joyBase.current!.getBoundingClientRect();
    joy.current = { id: e.pointerId, ox: r.left + r.width / 2, oy: r.top + r.height / 2, x: 0, y: 0 };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const onJoyMove = (e: React.PointerEvent) => {
    if (!joy.current || e.pointerId !== joy.current.id) return;
    let dx = e.clientX - joy.current.ox, dy = e.clientY - joy.current.oy;
    const len = Math.hypot(dx, dy), max = 52 * ts;
    if (len > max) { dx = (dx / len) * max; dy = (dy / len) * max; }
    joy.current.x = dx; joy.current.y = dy;
    setJoyKnob({ x: dx, y: dy });
    engineRef.current?.setAxis(dx / max, -dy / max);
  };
  const onJoyUp = () => {
    joy.current = null;
    setJoyKnob({ x: 0, y: 0 });
    engineRef.current?.setAxis(0, 0);
  };

  // سحب الكاميرا
  const onCamDown = (e: React.PointerEvent) => {
    cam.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
  };
  const onCamMove = (e: React.PointerEvent) => {
    if (!cam.current || e.pointerId !== cam.current.id) return;
    engineRef.current?.cameraDrag(e.clientX - cam.current.x, e.clientY - cam.current.y);
    cam.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
  };

  const hpFrac = hud ? hud.hp / hud.hpMax : 1;
  const rcFrac = hud ? hud.rc / hud.rcMax : 0;

  return (
    <div className="fixed inset-0 bg-black overflow-hidden" dir="rtl">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* طبقة سحب الكاميرا */}
      <div className="absolute inset-0 z-10" style={{ touchAction: "none" }}
        onPointerDown={onCamDown} onPointerMove={onCamMove} onPointerUp={() => (cam.current = null)} onPointerCancel={() => (cam.current = null)} />

      {/* وميض إصابة */}
      <div key={hurtKey} className="absolute inset-0 z-20 pointer-events-none hurt-flash" />
      {/* تظليل دائم */}
      <div className="absolute inset-0 z-20 pointer-events-none" style={{ boxShadow: "inset 0 0 140px rgba(0,0,0,0.75), inset 0 0 40px rgba(120,10,25,0.25)" }} />
      {hud?.transforming && <div className="absolute inset-0 z-20 pointer-events-none animate-pulse" style={{ boxShadow: "inset 0 0 180px rgba(210,31,60,0.55)" }} />}

      {/* ── HUD ── */}
      <div className="absolute inset-0 z-30 pointer-events-none font-body">
        {/* متتبع المهمة */}
        {hud?.mission && (
          <div className="absolute top-3 left-3 max-w-[330px] bg-black/55 border-r-2 border-[#d21f3c] px-3 py-2">
            <div className="flex items-center gap-2">
              <span className="text-[9px] px-1.5 py-0.5 bg-[#d21f3c] text-white font-bold">مهمة</span>
              <span className="font-display font-bold text-stone-100 text-sm">{hud.mission.title}</span>
            </div>
            <p className="text-[11px] leading-relaxed text-stone-300 mt-1">{hud.mission.desc}</p>
            {hud.sideMission && (
              <div className="mt-1.5 pt-1.5 border-t border-white/10 text-[10px] text-[#ffb02e]">◈ {hud.sideMission.title}</div>
            )}
          </div>
        )}

        {/* الخريطة + الوقت */}
        <div className="absolute top-3 right-3 flex flex-col items-center gap-1">
          <canvas ref={minimapRef} width={150} height={150} className="border border-[#d21f3c]/50 bg-black/60" />
          <div className="text-[10px] text-stone-400 bg-black/50 px-2 py-0.5 flex items-center gap-2">
            <span>{hud?.timeLabel}</span><span className="text-stone-600">•</span><span>{hud?.fps} FPS</span>
          </div>
        </div>

        {/* شريط الزعيم */}
        {hud?.boss && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-[min(520px,60vw)]">
            <div className="text-center font-display font-extrabold text-[#ff5d77] text-sm mb-1 drop-shadow-[0_0_8px_rgba(210,31,60,0.8)]">{hud.boss.name}</div>
            <div className="h-3 bg-black/70 border border-[#d21f3c]/60 p-[2px]">
              <div className="h-full bg-gradient-to-l from-[#d21f3c] to-[#7a0f22] transition-[width] duration-200" style={{ width: `${hud.boss.frac * 100}%` }} />
            </div>
          </div>
        )}

        {/* المؤشرات الحيوية */}
        <div className="absolute left-5 w-[240px] space-y-1.5" style={{ transform: `scale(${0.85 + ts * 0.15})`, transformOrigin: "bottom left", bottom: 148 * ts + 62 }}>
          <div className="flex items-center gap-2">
            <span className="font-display font-extrabold text-lg text-[#ff5d77] w-12">صحة</span>
            <div className="h-4 flex-1 bg-black/70 border border-white/15 p-[2px] skew-x-[-14deg]">
              <div className="h-full transition-[width] duration-200" style={{ width: `${hpFrac * 100}%`, background: hpFrac > 0.35 ? "linear-gradient(90deg,#d21f3c,#ff5d77)" : "#ff2038" }} />
            </div>
            <span className="text-[10px] text-stone-300 w-14 text-left">{hud?.hp}/{hud?.hpMax}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-[11px] text-[#c026d3]/90 w-12">RC</span>
            <div className="h-2.5 flex-1 bg-black/70 border border-white/10 p-[2px] skew-x-[-14deg]">
              <div className={`h-full transition-[width] duration-200 ${hud?.kagune ? "animate-pulse" : ""}`} style={{ width: `${rcFrac * 100}%`, background: "linear-gradient(90deg,#5b0f6e,#c026d3,#ff2d55)" }} />
            </div>
            <span className="text-[10px] text-stone-400 w-14 text-left">{hud?.rc}/{hud?.rcMax}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-stone-500 w-12">طاقة</span>
            <div className="h-1.5 flex-1 bg-black/70 p-[1px]">
              <div className="h-full bg-[#c9a86a] transition-[width]" style={{ width: `${hud?.stam ?? 100}%` }} />
            </div>
            <span className="text-[10px] text-[#c9a86a] w-14 text-left">LV {hud?.level} • {hud?.cells}🔻</span>
          </div>
          <div className="h-1 bg-black/60">
            <div className="h-full bg-[#7aa2ff]" style={{ width: `${((hud?.xp ?? 0) / Math.max(1, hud?.xpNext ?? 1)) * 100}%` }} />
          </div>
        </div>

        {/* عدّاد الضربات */}
        {hud && hud.combo > 1 && (
          <div className="absolute text-left" style={{ opacity: hud.comboT, right: 320 * ts, bottom: 200 * ts }}>
            <div className="font-display font-extrabold text-5xl text-[#ff5d77] drop-shadow-[0_0_14px_rgba(210,31,60,0.9)] leading-none">{hud.combo}</div>
            <div className="text-[11px] text-stone-300 tracking-widest">سلسلة ضربات</div>
          </div>
        )}

        {/* قفل الهدف */}
        {hud?.locked && (
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 border-2 border-[#ff2d55]/80 rotate-45 animate-pulse" />
        )}

        {/* إشعار التفاعل */}
        {hud?.interact && (
          <div className="absolute bottom-[38%] left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/70 border border-[#ffb02e]/60 px-4 py-2">
            <span className="text-[#ffb02e]">{hud.interact}</span>
            <span className="pointer-events-auto">
              <TouchBtn id="interact" icon={I.interact} label="" size={44 * ts} onDown={() => press("interact")}
                className="border-[#ffb02e] bg-[#ffb02e]/15 text-[#ffb02e]" editLayout={false} offsets={{}} setOffsets={() => { }} />
            </span>
          </div>
        )}

        {/* التنبيهات */}
        <div className="absolute top-[19%] left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5">
          {toasts.map((t) => (
            <div key={t.id} className={`toast-in px-4 py-1.5 text-[12px] border bg-black/75 ${t.kind === "good" ? "border-[#4ade80]/60 text-[#86efac]" : t.kind === "warn" ? "border-[#ffb02e]/60 text-[#fcd34d]" : "border-[#d21f3c]/60 text-stone-200"}`}>
              {t.msg}
            </div>
          ))}
        </div>
      </div>

      {/* ── التحكم باللمس ── */}
      <div className="absolute inset-0 z-40 pointer-events-none">
        {/* جويستيك */}
        <div ref={joyBase} className="absolute bottom-8 left-6 pointer-events-auto rounded-full border-2 border-white/15 bg-white/5"
          style={{ width: 132 * ts, height: 132 * ts, touchAction: "none" }}
          onPointerDown={onJoyDown} onPointerMove={onJoyMove} onPointerUp={onJoyUp} onPointerCancel={onJoyUp}>
          <div className="absolute rounded-full bg-[#d21f3c]/60 border border-[#ff5d77]"
            style={{ width: 54 * ts, height: 54 * ts, left: "50%", top: "50%", transform: `translate(calc(-50% + ${joyKnob.x}px), calc(-50% + ${joyKnob.y}px))` }} />
          <span className="absolute inset-0 grid place-items-center text-[9px] text-white/25 font-bold">حركة</span>
        </div>

        {/* أزرار الأكشن — يمين الشاشة */}
        <div className="absolute bottom-6 right-5 pointer-events-auto" style={{ width: 300 * ts, height: 300 * ts }}>
          <div className="absolute" style={{ left: 208 * ts, bottom: 2 * ts }}>
            <TouchBtn id="attack" icon={I.sword} label="هجوم" size={82 * ts} onDown={() => press("attack")}
              className="border-[#d21f3c] bg-[#d21f3c]/25 text-[#ff5d77] shadow-[0_0_24px_rgba(210,31,60,0.35)]"
              editLayout={editLayout} offsets={offsets} setOffsets={setOffsets} />
          </div>
          <div className="absolute" style={{ left: 100 * ts, bottom: 34 * ts }}>
            <TouchBtn id="heavy" icon={I.heavy} label="ثقيل" size={58 * ts} onDown={() => press("heavy")}
              className="border-[#ff5d77]/70 bg-[#7a0f22]/30 text-[#ff8ba0]" editLayout={editLayout} offsets={offsets} setOffsets={setOffsets} />
          </div>
          <div className="absolute" style={{ left: 8 * ts, bottom: 106 * ts }}>
            <TouchBtn id="dodge" icon={I.dodge} label="مراوغة" size={56 * ts} onDown={() => press("dodge")}
              className="border-stone-400/70 bg-white/10 text-stone-200" editLayout={editLayout} offsets={offsets} setOffsets={setOffsets} />
          </div>
          <div className="absolute" style={{ left: 118 * ts, bottom: 116 * ts }}>
            <TouchBtn id="jump" icon={I.jump} label="قفز/تسلق" size={64 * ts} onDown={() => press("jump")}
              className="border-stone-300/70 bg-white/10 text-white" editLayout={editLayout} offsets={offsets} setOffsets={setOffsets} />
          </div>
          <div className="absolute" style={{ left: 60 * ts, bottom: 196 * ts }}>
            <TouchBtn id="transform" icon={I.kagune} label="تحوّل" size={64 * ts} onDown={() => press("transform")}
              className={`border-[#c026d3] text-[#e879f9] ${rcFrac > 0.3 ? "bg-[#c026d3]/30 shadow-[0_0_26px_rgba(192,38,211,0.5)]" : "bg-black/40 opacity-60"}`}
              editLayout={editLayout} offsets={offsets} setOffsets={setOffsets}
              ring={<span className="absolute inset-0 rounded-full" style={{ background: `conic-gradient(rgba(192,38,211,0.5) ${rcFrac * 360}deg, transparent 0deg)` }} />} />
          </div>
          <div className="absolute" style={{ left: 196 * ts, bottom: 196 * ts }}>
            <TouchBtn id="skill" icon={I.skill} label="مهارة" size={54 * ts} onDown={() => press("skill")}
              className="border-[#ff2d55]/80 bg-[#d21f3c]/20 text-[#ff5d77]" editLayout={editLayout} offsets={offsets} setOffsets={setOffsets}
              ring={hud && hud.skillCd > 0 ? <span className="absolute inset-0 rounded-full bg-black/70" style={{ clipPath: `inset(0 0 ${(1 - hud.skillCd) * 100}% 0)` }} /> : undefined} />
          </div>
          <div className="absolute" style={{ left: 236 * ts, bottom: 96 * ts }}>
            <TouchBtn id="block" icon={I.block} label="صد" size={50 * ts} onDown={() => engineRef.current?.hold("block", true)} onUp={() => engineRef.current?.hold("block", false)}
              className="border-[#c9a86a]/80 bg-[#c9a86a]/15 text-[#c9a86a]" editLayout={editLayout} offsets={offsets} setOffsets={setOffsets} />
          </div>
          <div className="absolute" style={{ left: 228 * ts, bottom: 262 * ts }}>
            <TouchBtn id="lock" icon={I.lock} label="قفل هدف" size={46 * ts} onDown={() => press("lock")}
              className={`${hud?.locked ? "border-[#ff2d55] bg-[#d21f3c]/40 text-white" : "border-stone-500 bg-black/30 text-stone-400"}`} editLayout={editLayout} offsets={offsets} setOffsets={setOffsets} />
          </div>
        </div>

        {/* زر الإيقاف */}
        <button className="absolute top-3 right-[172px] pointer-events-auto w-9 h-9 grid place-items-center border border-white/25 bg-black/50 text-stone-300 hover:text-white"
          onClick={() => setModal("pause")}>
          <span className="w-4 h-4">{I.pause}</span>
        </button>
      </div>

      {/* ── الحوار ── */}
      {dlg && dlg.lines[dlg.idx] && (
        <div className="absolute inset-0 z-50 flex items-end justify-center pb-6" dir="rtl" onClick={advanceDlg}>
          <div className="w-[min(92vw,860px)] bg-gradient-to-l from-[#12060b]/97 to-[#0b0a10]/97 border border-[#d21f3c]/50 border-r-4 border-r-[#d21f3c] shadow-[0_0_50px_rgba(210,31,60,0.25)] p-4 flex gap-4">
            <div className="w-20 h-20 md:w-24 md:h-24 shrink-0 border border-white/15 overflow-hidden bg-black">
              {SPEAKER_IMG[dlg.lines[dlg.idx].s] ? (
                <img src={SPEAKER_IMG[dlg.lines[dlg.idx].s]} alt="" className="w-full h-full object-cover object-top" />
              ) : (
                <div className="w-full h-full grid place-items-center font-display text-3xl font-extrabold" style={{ color: SPEAKERS[dlg.lines[dlg.idx].s]?.color }}>
                  {(SPEAKERS[dlg.lines[dlg.idx].s]?.name || "؟")[0]}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[11px] font-bold mb-1" style={{ color: SPEAKERS[dlg.lines[dlg.idx].s]?.color }}>
                {SPEAKERS[dlg.lines[dlg.idx].s]?.name || ""}
              </div>
              <p className="text-stone-100 text-sm md:text-[15px] leading-relaxed min-h-[44px]">
                {dlg.lines[dlg.idx].t.slice(0, typed)}
                {typed < dlg.lines[dlg.idx].t.length && <span className="text-[#d21f3c] animate-pulse">▌</span>}
              </p>
              {dlg.lines[dlg.idx].c && typed >= dlg.lines[dlg.idx].t.length && (
                <div className="mt-3 space-y-2">
                  {dlg.lines[dlg.idx].c!.map((ch) => (
                    <button key={ch.t} onClick={(e) => { e.stopPropagation(); engineRef.current?.endDialogue(ch.f); }}
                      className="block w-full text-right px-3 py-2 border border-[#d21f3c]/50 text-stone-200 text-[13px] hover:bg-[#d21f3c]/25 hover:border-[#d21f3c] transition-colors">
                      ◆ {ch.t}
                    </button>
                  ))}
                </div>
              )}
              {!dlg.lines[dlg.idx].c && typed >= dlg.lines[dlg.idx].t.length && (
                <div className="mt-2 text-[10px] text-stone-500 animate-pulse">▼ المس للمتابعة</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── الموت ── */}
      {dead && (
        <div className="absolute inset-0 z-50 grid place-items-center bg-[#1a040a]/85" dir="rtl">
          <div className="text-center">
            <div className="font-display text-6xl font-extrabold text-[#d21f3c] drop-shadow-[0_0_30px_rgba(210,31,60,0.8)]">سَقَطت…</div>
            <p className="text-stone-400 mt-3 text-sm">الغيلان لا تموت بسهولة. انهض مجدداً.</p>
            <button onClick={() => { setDead(false); engineRef.current?.respawn(); }}
              className="mt-6 px-10 py-3 bg-[#d21f3c] text-white font-display font-bold text-lg hover:bg-[#e6334f]">انهض من جديد</button>
          </div>
        </div>
      )}

      {/* ── القوائم المنبثقة ── */}
      {modal === "pause" && (
        <Panel title="الإيقاف المؤقت" onClose={() => setModal(null)}>
          <div className="grid grid-cols-1 gap-2">
            {[
              { t: "▶ استئناف", f: () => setModal(null) },
              { t: "🧬 شجرة المهارات", f: () => setModal("skills") },
              { t: "🗺 سجل المهمات", f: () => setModal("missions") },
              { t: "⚙ الإعدادات", f: () => setModal("settings") },
              { t: "🎮 دليل التحكم", f: () => setModal("guide") },
              { t: "💾 حفظ والخروج إلى القائمة", f: () => { engineRef.current?.persist(); onExit(); } },
            ].map((b) => (
              <button key={b.t} onClick={b.f} className="text-right px-4 py-3 border border-white/10 text-stone-200 hover:border-[#d21f3c] hover:bg-[#d21f3c]/10 font-display">{b.t}</button>
            ))}
          </div>
          <p className="text-[11px] text-stone-500 mt-4">الحفظ التلقائي يعمل عند إكمال المهمات وعند المقهى.</p>
        </Panel>
      )}

      {modal === "skills" && hud && (
        <Panel title={`شجرة مهارات — ${CHARACTERS.find((c) => c.id === save.charId)?.nameAr}`} onClose={() => setModal(null)} wide>
          <SkillTree save={engineRef.current?.save || save} onBuy={() => { engineRef.current?.refreshStats(); engineRef.current?.persist(); setForce((x) => x + 1); }} />
        </Panel>
      )}

      {modal === "missions" && (
        <Panel title="سجل المهمات" onClose={() => setModal(null)} wide>
          <MissionLog save={save} eng={engineRef.current} onChanged={() => setForce((x) => x + 1)} />
        </Panel>
      )}

      {modal === "settings" && (
        <Panel title="الإعدادات" onClose={() => setModal(null)}>
          <SettingsPanel s={save.settings}
            onChange={(p) => {
              Object.assign(save.settings, p);
              const eng = engineRef.current;
              if (eng) {
                Object.assign(eng.save.settings, p);
                eng.setVolumes();
                storeSave(eng.save);
              } else storeSave(save);
              setForce((x) => x + 1);
            }}
            onDone={() => setModal(null)} editLayout={editLayout} setEditLayout={setEditLayout} />
        </Panel>
      )}

      {modal === "guide" && (
        <Panel title="دليل التحكم" onClose={() => setModal(null)} wide>
          <ControlsGuide />
        </Panel>
      )}

      {editLayout && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-50 bg-[#ffb02e] text-black px-4 py-1.5 text-xs font-bold">
          وضع التعديل: اسحب الأزرار لتغيير أماكنها — افتح الإعدادات للخروج
        </div>
      )}
    </div>
  );
}

// ─────────────── شجرة المهارات ───────────────
function SkillTree({ save, onBuy }: { save: SaveData; onBuy: () => void }) {
  const def = CHARACTERS.find((c) => c.id === save.charId)!;
  const pfx = def.id === "daisuke" ? "dai" : def.id === "hollow" ? "hol" : def.id;
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <img src={def.img} className="w-16 h-16 object-cover object-top border border-[#d21f3c]/50" alt="" />
        <div>
          <div className="font-display font-bold text-stone-100">{def.kaguneName} — {KAGUNE_TYPE_AR[def.kaguneType]}</div>
          <div className="text-[12px] text-[#ffb02e]">خلايا RC المتاحة: {save.cells}</div>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {def.tree.map((n) => {
          const owned = save.skills.includes(n.id);
          const reqOk = !n.req || save.skills.includes(n.req);
          const can = !owned && reqOk && save.cells >= n.cost;
          return (
            <button key={n.id} disabled={!can}
              onClick={() => {
                if (!can) return;
                save.cells -= n.cost;
                save.skills.push(n.id);
                storeSave(save);
                onBuy();
              }}
              className={`text-right p-3 border transition-colors ${owned ? "border-[#4ade80]/60 bg-[#4ade80]/10" : can ? "border-[#d21f3c] bg-[#d21f3c]/10 hover:bg-[#d21f3c]/25" : "border-white/10 opacity-45"}`}>
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-sm text-stone-100">{n.name}</span>
                <span className={`text-[10px] px-1.5 py-0.5 ${owned ? "bg-[#4ade80] text-black" : "bg-[#d21f3c] text-white"}`}>{owned ? "مفتوحة" : `${n.cost} 🔻`}</span>
              </div>
              <p className="text-[11px] text-stone-400 mt-1 leading-relaxed">{n.desc}</p>
              {!reqOk && <p className="text-[10px] text-[#ffb02e] mt-1">تتطلب المهارة السابقة</p>}
            </button>
          );
        })}
      </div>
      <p className="text-[11px] text-stone-500 mt-4">اكسب خلايا RC من المستوى الجديد، الملتقطات الحمراء، وإتمام المهمات. البادئة «{pfx}» خاصة بمسار هذه الشخصية.</p>
    </div>
  );
}

// ─────────────── سجل المهمات ───────────────
function MissionLog({ save, eng, onChanged }: { save: SaveData; eng: GameEngine | null; onChanged: () => void }) {
  const sv = eng?.save || save;
  const curIdx = eng ? eng.missions.storyIdx : sv.missionIdx;
  const story = MISSIONS.filter((m) => m.kind === "story");
  const sides = MISSIONS.filter((m) => m.kind === "side");
  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-display font-bold text-[#ff5d77] mb-2">القصة الرئيسية — «بين عالمين»</h3>
        <div className="space-y-1.5">
          {story.map((m, i) => {
            const done = sv.done.includes(m.id);
            const current = i === curIdx && !done;
            return (
              <div key={m.id} className={`flex items-center gap-3 px-3 py-2 border text-[13px] ${current ? "border-[#d21f3c] bg-[#d21f3c]/10 text-stone-100" : done ? "border-[#4ade80]/30 text-stone-400" : "border-white/8 text-stone-600"}`}>
                <span className={`w-6 h-6 grid place-items-center text-[11px] border ${current ? "border-[#d21f3c] text-[#ff5d77] animate-pulse" : done ? "border-[#4ade80]/50 text-[#4ade80]" : "border-white/15"}`}>{done ? "✓" : i + 1}</span>
                <span className="font-bold">{m.title}</span>
                {current && <span className="text-[10px] text-[#ffb02e]">— جارية الآن</span>}
              </div>
            );
          })}
        </div>
      </div>
      <div>
        <h3 className="font-display font-bold text-[#ffb02e] mb-2">مهمات جانبية</h3>
        <div className="space-y-1.5">
          {sides.map((m) => {
            const done = sv.done.includes(m.id);
            const active = eng && eng.missions.side?.id === m.id && eng.missions.sidePhase === "active";
            return (
              <div key={m.id} className={`flex items-center gap-3 px-3 py-2 border text-[13px] ${active ? "border-[#ffb02e] bg-[#ffb02e]/10" : "border-white/8"} ${done ? "text-stone-500" : "text-stone-200"}`}>
                <div className="flex-1">
                  <div className="font-bold">{m.title} {done && "✓"}</div>
                  <div className="text-[11px] text-stone-400">{m.desc}</div>
                </div>
                {!done && !active && (
                  <button onClick={() => { eng?.startSide(m.id); onChanged(); }}
                    className="px-3 py-1 text-[11px] border border-[#ffb02e] text-[#ffb02e] hover:bg-[#ffb02e]/15">تفعيل</button>
                )}
                {active && <span className="text-[10px] text-[#ffb02e] animate-pulse">نشطة</span>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─────────────── دليل التحكم ───────────────
function ControlsGuide() {
  const K = ({ k, v }: { k: string; v: string }) => (
    <div className="flex items-center justify-between py-1.5 border-b border-white/5 text-[13px]">
      <span className="text-stone-300">{v}</span>
      <span className="font-mono text-[11px] px-2 py-0.5 bg-white/8 border border-white/15 text-stone-100">{k}</span>
    </div>
  );
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div>
        <h3 className="font-display font-bold text-stone-100 mb-2">⌨ لوحة المفاتيح والفأرة</h3>
        <K k="W A S D" v="الحركة" /><K k="سحب الفأرة" v="تدوير الكاميرا" /><K k="عجلة الفأرة" v="تقريب/إبعاد" />
        <K k="Space" v="قفز (وعلى الجدار: قفزة خلفية)" /><K k="Shift" v="ركض" /><K k="J" v="هجوم سريع (سلسلة)" />
        <K k="K" v="هجوم ثقيل" /><K k="L" v="مراوغة" /><K k="C (استمرار)" v="صد" /><K k="T" v="تحوّل الكاغوني" />
        <K k="Q" v="مهارة الكاغوني" /><K k="F" v="قفل الهدف" /><K k="E" v="تفاعل" /><K k="Esc / P" v="الإيقاف المؤقت" />
      </div>
      <div>
        <h3 className="font-display font-bold text-stone-100 mb-2">📱 اللمس (أفقي)</h3>
        <K k="عصا يسار" v="الحركة — ادفعها للآخر للركض" />
        <K k="سحب يمين الشاشة" v="الكاميرا" />
        <K k="زر هجوم ×3" v="سلسلة ضربات متتابعة" />
        <K k="قفز قرب جدار" v="تسلق المباني — حرّك العصا للأعلى" />
        <K k="تحوّل (RC ≥ 30)" v="سينمائية الكاغوني الكاملة" />
        <K k="الإعدادات ← تحريك الأزرار" v="غيّر أماكن وأحجام الأزرار" />
        <p className="text-[11px] text-stone-500 mt-3 leading-relaxed">نصيحة: في هيئة الكاغوني تقفز أعلى وتضرب أبعد، لكن مقياس RC يستنزف — التقط البلورات الحمراء.</p>
      </div>
    </div>
  );
}

// ─────────────── اختيار الشخصية ───────────────
function CharSelect({ save, isNew, onBack, onStart }: { save: SaveData; isNew: boolean; onBack: () => void; onStart: (s: SaveData) => void }) {
  const [sel, setSel] = useState(save.charId);
  const def = CHARACTERS.find((c) => c.id === sel) as CharacterDef;
  const unlocked = save.unlocked;
  return (
    <div className="fixed inset-0 overflow-y-auto bg-[#08070a] text-stone-200" dir="rtl">
      <div className="absolute inset-0 opacity-25" style={{ background: "radial-gradient(ellipse at 70% 20%, rgba(210,31,60,0.28), transparent 55%), radial-gradient(ellipse at 20% 90%, rgba(192,38,211,0.15), transparent 50%)" }} />
      <div className="relative max-w-6xl mx-auto p-5 md:p-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="text-[11px] tracking-[0.3em] text-[#d21f3c] font-bold">SELECT YOUR GHOUL</div>
            <h1 className="font-display text-3xl md:text-4xl font-extrabold">اختر غولك</h1>
          </div>
          <button onClick={onBack} className="px-4 py-2 border border-white/20 text-stone-400 hover:border-white/60 hover:text-white text-sm">→ رجوع</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {CHARACTERS.map((c) => {
            const locked = !unlocked.includes(c.id);
            return (
              <button key={c.id} onClick={() => !locked && setSel(c.id)}
                className={`relative text-right border transition-all overflow-hidden group ${sel === c.id ? "border-[#d21f3c] shadow-[0_0_28px_rgba(210,31,60,0.35)]" : "border-white/12 hover:border-white/40"} ${locked ? "opacity-100" : ""}`}>
                <div className="aspect-[3/4] overflow-hidden">
                  <img src={c.img} alt={c.nameAr} className={`w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105 ${locked ? "grayscale brightness-[0.35]" : sel === c.id ? "" : "grayscale-[0.35] brightness-75"}`} />
                </div>
                {locked && (
                  <div className="absolute inset-0 grid place-items-center">
                    <div className="text-center px-2">
                      <div className="text-2xl">🔒</div>
                      <div className="text-[10px] text-stone-400 mt-1 leading-snug">تُفتح عبر القصة</div>
                    </div>
                  </div>
                )}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/80 to-transparent p-2 pt-6">
                  <div className="font-display font-bold text-[13px] leading-tight">{c.nameAr}</div>
                  <div className="text-[9px] text-[#ff5d77] tracking-wider">{c.kaguneName}</div>
                </div>
              </button>
            );
          })}
        </div>
        {/* تفاصيل */}
        <div className="mt-5 grid md:grid-cols-[1fr_1.4fr] gap-5 items-start">
          <div className="border border-white/10 bg-black/40 p-4">
            <div className="text-[10px] tracking-[0.25em] text-stone-500">{def.nameEn}</div>
            <h2 className="font-display text-2xl font-extrabold text-white">{def.nameAr}</h2>
            <div className="inline-block mt-1 px-2 py-0.5 text-[10px] bg-[#d21f3c]/20 border border-[#d21f3c]/60 text-[#ff5d77]">{KAGUNE_TYPE_AR[def.kaguneType]} — {def.kaguneName}</div>
            <div className="mt-4 space-y-2">
              <StatBar label="قوة" v={def.stats.power} color="#d21f3c" />
              <StatBar label="سرعة" v={def.stats.speed} color="#ffb02e" />
              <StatBar label="دفاع" v={def.stats.defense} color="#7aa2ff" />
              <StatBar label="RC" v={def.stats.rc} color="#c026d3" />
            </div>
          </div>
          <div className="border border-white/10 bg-black/40 p-4">
            <p className="text-[13px] leading-relaxed text-stone-300">{def.bio}</p>
            <p className="text-[12px] leading-relaxed text-[#ff8ba0] mt-3 border-r-2 border-[#d21f3c] pr-3">{def.kaguneDesc}</p>
          </div>
        </div>
        <div className="mt-6 flex gap-3">
          <button onClick={() => onStart({ ...save, charId: sel })}
            className="px-12 py-3.5 bg-[#d21f3c] font-display font-extrabold text-lg text-white hover:bg-[#e6334f] shadow-[0_0_30px_rgba(210,31,60,0.4)]">
            {isNew ? "ابدأ الحكاية" : "ادخل المدينة"}
          </button>
          <div className="text-[11px] text-stone-500 self-center">المستوى {save.level} • {save.cells} خلية RC • {save.done.length} مهمة مكتملة</div>
        </div>
      </div>
    </div>
  );
}

// ─────────────── التطبيق ───────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("boot");
  const [runSave, setRunSave] = useState<SaveData | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [ending, setEnding] = useState<string | null>(null);
  const [runId, setRunId] = useState(0);
  const [confirmNew, setConfirmNew] = useState(false);
  const [menuModal, setMenuModal] = useState<null | "settings" | "guide" | "about">(null);
  const [menuSettings, setMenuSettings] = useState(() => loadSave()?.settings || { ...DEFAULT_SETTINGS });
  const [portrait, setPortrait] = useState(window.innerHeight > window.innerWidth);

  useEffect(() => {
    const onR = () => setPortrait(window.innerHeight > window.innerWidth);
    window.addEventListener("resize", onR);
    window.addEventListener("orientationchange", onR);
    return () => { window.removeEventListener("resize", onR); window.removeEventListener("orientationchange", onR); };
  }, []);

  const startRun = (s: SaveData) => {
    storeSave(s);
    setRunSave(s);
    setRunId((r) => r + 1);
    setEnding(null);
    setScreen("game");
  };
  const newGame = () => {
    clearSave();
    const s = defaultSave();
    setIsNew(true);
    setRunSave(s);
    setScreen("select");
  };
  const continueGame = () => {
    const s = loadSave();
    if (!s) return;
    setIsNew(false);
    setScreen("select");
    setRunSave(s);
  };

  return (
    <div className="font-body text-stone-200">
      {/* تحذير الوضع العمودي */}
      {portrait && screen === "game" && (
        <div className="fixed inset-0 z-[100] bg-black grid place-items-center text-center p-6" dir="rtl">
          <div>
            <div className="text-5xl animate-pulse mb-4">📱⟲</div>
            <div className="font-display text-2xl font-extrabold text-[#ff5d77]">أدِر جهازك إلى الوضع الأفقي</div>
            <p className="text-stone-400 text-sm mt-2">DARK GHOUL V2 مصممة للعب بالعرض الأفقي Landscape</p>
          </div>
        </div>
      )}

      {screen === "boot" && (
        <div className="fixed inset-0 z-[90] bg-black grid place-items-center cursor-pointer" onPointerDown={() => setScreen("menu")} dir="rtl">
          <div className="text-center">
            <div className="font-display text-[11vw] md:text-7xl font-extrabold leading-none">
              <span className="text-stone-100">DARK</span> <span className="text-[#d21f3c] title-glow">GHOUL</span>
            </div>
            <div className="font-display text-3xl md:text-5xl font-extrabold text-stone-300 mt-1 tracking-widest">V2</div>
            <div className="text-stone-500 text-sm mt-3 tracking-[0.4em]">الغول المظلم</div>
            <div className="mt-10 text-stone-400 text-sm animate-pulse">— المس في أي مكان للدخول —</div>
          </div>
        </div>
      )}

      {screen === "menu" && (
        <div className="fixed inset-0 overflow-hidden bg-black" dir="rtl">
          <img src={KEYART} alt="" className="absolute inset-0 w-full h-full object-cover kenburns opacity-80" />
          <div className="absolute inset-0 bg-gradient-to-l from-black/90 via-black/45 to-black/20" />
          <div className="absolute inset-0 scanlines opacity-40" />
          <div className="absolute inset-0 vignette" />

          <div className="relative h-full flex flex-col justify-center pr-6 md:pr-16 max-w-3xl">
            <div className="text-[10px] md:text-[11px] tracking-[0.45em] text-[#ff5d77] font-bold mb-2">TOKYO • الحي العشرون • 3:12 فجراً</div>
            <h1 className="font-display font-extrabold leading-[0.95]">
              <span className="block text-6xl md:text-8xl text-stone-100">DARK</span>
              <span className="block text-6xl md:text-8xl text-[#d21f3c] title-glow">GHOUL</span>
              <span className="block text-2xl md:text-4xl text-stone-300 tracking-[0.5em] mt-1">V2 — الظلال الألف</span>
            </h1>
            <p className="text-stone-400 text-sm md:text-[15px] mt-4 max-w-md leading-relaxed">
              عالم مفتوح ثلاثي الأبعاد. تحوّل عضوي سينمائي. مدينة تتنفس تحت المطر.
              <span className="text-[#ff8ba0]"> بين بشريتك ووحشيتك… اختر.</span>
            </p>
            <nav className="mt-8 space-y-1.5">
              {loadSave() && (
                <button onClick={continueGame} className="menu-btn bg-[#d21f3c] border-[#d21f3c] text-white">
                  ▶ متابعة — المستوى {loadSave()?.level} • {CHARACTERS.find((c) => c.id === loadSave()?.charId)?.nameAr}
                </button>
              )}
              <button onClick={() => (loadSave() ? setConfirmNew(true) : newGame())} className="menu-btn">✚ لعبة جديدة</button>
              <button onClick={() => { const s = loadSave(); if (s) { setIsNew(false); setRunSave(s); setScreen("select"); } else newGame(); }} className="menu-btn">👥 اختيار الشخصية</button>
              <button onClick={() => setMenuModal("settings")} className="menu-btn">⚙ الإعدادات</button>
              <button onClick={() => setMenuModal("guide")} className="menu-btn">🎮 دليل التحكم</button>
              <button onClick={() => setMenuModal("about")} className="menu-btn">📦 عن المشروع وتحويله إلى APK</button>
            </nav>
          </div>

          <div className="absolute bottom-0 inset-x-0 border-t border-[#d21f3c]/30 bg-black/70 py-2 overflow-hidden">
            <div className="ticker text-[11px] text-stone-400 whitespace-nowrap">
              ◆ قسم مكافحة الغيلان يعلن حملة تطهير في الحي العشرين ◆ اختفاء ثالث هذا الأسبوع قرب المستودعات الشرقية ◆ مقهى «اللوتس الأسود» يفتح أبوابه بعد منتصف الليل ◆ شوهدت أجنحة سوداء فوق البرج الأحمر ◆ لا تمشِ وحيداً بعد الثالثة فجراً ◆
            </div>
          </div>
          <div className="absolute top-4 left-4 text-[10px] text-stone-500 text-left" dir="ltr">
            DARK GHOUL V2 — build 2.0.26<br />Three.js WebGL • Web 3D → APK ready
          </div>

          {confirmNew && (
            <div className="absolute inset-0 z-50 grid place-items-center bg-black/80">
              <div className="border border-[#d21f3c]/60 bg-[#0c0a0e] p-6 max-w-sm text-center">
                <h3 className="font-display font-bold text-lg text-white">لديك تقدم محفوظ</h3>
                <p className="text-stone-400 text-sm mt-2">بدء لعبة جديدة سيمحو القصة والمستويات المحفوظة. متأكد؟</p>
                <div className="flex gap-3 justify-center mt-5">
                  <button onClick={() => { setConfirmNew(false); newGame(); }} className="px-6 py-2 bg-[#d21f3c] text-white font-bold hover:bg-[#e6334f]">امحُ وابدأ</button>
                  <button onClick={() => setConfirmNew(false)} className="px-6 py-2 border border-white/25 text-stone-300">تراجع</button>
                </div>
              </div>
            </div>
          )}

          {menuModal === "settings" && (
            <Panel title="الإعدادات" onClose={() => setMenuModal(null)}>
              <SettingsPanel s={menuSettings}
                onChange={(p) => {
                  const ns = { ...menuSettings, ...p };
                  setMenuSettings(ns);
                  const s = loadSave();
                  if (s) { s.settings = ns; storeSave(s); }
                  else storeSave({ ...defaultSave(), settings: ns });
                }}
                onDone={() => setMenuModal(null)} />
            </Panel>
          )}
          {menuModal === "guide" && <Panel title="دليل التحكم" onClose={() => setMenuModal(null)} wide><ControlsGuide /></Panel>}
          {menuModal === "about" && (
            <Panel title="عن المشروع — DARK GHOUL V2" onClose={() => setMenuModal(null)} wide>
              <div className="text-[13px] leading-relaxed text-stone-300 space-y-3">
                <p>لعبة أكشن RPG ثلاثية الأبعاد قابلة للعب بالكامل، مبنية بـ <b className="text-[#ff5d77]">Three.js + React + Vite</b> — عالم مفتوح، قتال حقيقي، تسلق مبانٍ، تحولات كاغوني سينمائية، قصة بـ 7 مهمات رئيسية و4 جانبية و3 نهايات، حفظ تلقائي، وطقس متغير.</p>
                <p className="text-[#ffb02e]">ملاحظة شفافة: الشخصيات مبنية بهياكل مفصلية إجرائية (بديل مؤقت واضح). لاستبدالها بنماذج احترافية: أضف ملفات GLB في <span dir="ltr" className="font-mono text-[11px] bg-black/50 px-1">src/assets/models/</span> وحمّلها عبر GLTFLoader داخل <span dir="ltr" className="font-mono text-[11px] bg-black/50 px-1">characters.ts → buildHumanoid</span> مع الحفاظ على نفس نقاط الارتكاز — التفاصيل الكاملة في README.md.</p>
                <p><b className="text-white">تحويل اللعبة إلى APK (Capacitor):</b></p>
                <ol className="list-decimal pr-5 space-y-1 text-stone-400 text-[12px]" dir="rtl">
                  <li dir="ltr" className="text-left font-mono text-[11px] bg-black/50 p-2">npm run build</li>
                  <li dir="ltr" className="text-left font-mono text-[11px] bg-black/50 p-2">npm i @capacitor/core @capacitor/cli @capacitor/android</li>
                  <li dir="ltr" className="text-left font-mono text-[11px] bg-black/50 p-2">npx cap init "Dark Ghoul V2" com.darkghoul.v2 --web-dir=dist</li>
                  <li dir="ltr" className="text-left font-mono text-[11px] bg-black/50 p-2">npx cap add android && npx cap sync</li>
                  <li dir="ltr" className="text-left font-mono text-[11px] bg-black/50 p-2">npx cap open android → Build APK في Android Studio</li>
                </ol>
                <p className="text-stone-500 text-[11px]">الشاشة الأفقية تُفعّل تلقائياً عبر تنبيه التدوير + يمكن قفلها في AndroidManifest (screenOrientation="landscape").</p>
              </div>
            </Panel>
          )}
        </div>
      )}

      {screen === "select" && runSave && (
        <CharSelect save={runSave} isNew={isNew} onBack={() => setScreen("menu")} onStart={startRun} />
      )}

      {screen === "game" && runSave && (
        <GameView key={runId} save={runSave} onExit={() => setScreen("menu")} onEnding={(id) => { setEnding(id); setScreen("menu"); }} />
      )}

      {/* شاشة النهاية */}
      {ending && (
        <div className="fixed inset-0 z-[95] bg-black" dir="rtl">
          <img src={KEYART} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40 kenburns" style={{ filter: `hue-rotate(${ending === "end_veil" ? "-30deg" : ending === "end_human" ? "120deg" : "0deg"}) saturate(1.3)` }} />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/30" />
          <div className="relative h-full grid place-items-center p-6">
            <div className="max-w-2xl text-center">
              <div className="text-[11px] tracking-[0.5em] text-stone-400 mb-3">— النهاية —</div>
              <h1 className="font-display text-5xl md:text-6xl font-extrabold" style={{ color: ENDINGS[ending].color, textShadow: `0 0 40px ${ENDINGS[ending].color}66` }}>
                {ENDINGS[ending].title}
              </h1>
              <p className="text-stone-300 leading-loose mt-6 text-[15px]">{ENDINGS[ending].text}</p>
              <button onClick={() => { setEnding(null); setScreen("menu"); }}
                className="mt-8 px-10 py-3 bg-[#d21f3c] text-white font-display font-bold text-lg hover:bg-[#e6334f]">العودة إلى القائمة</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
