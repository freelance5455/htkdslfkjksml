import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { MobileBottomNav } from './components/common/MobileBottomNav';
import { NotificationDrawer } from './components/common/NotificationDrawer';
import { AuthModal } from './components/auth/AuthModal';
import { DashboardView } from './components/dashboard/DashboardView';
import { TasksView } from './components/tasks/TasksView';
import { TaskExecutionModal } from './components/tasks/TaskExecutionModal';
import { GoogleTasksSyncModal } from './components/tasks/GoogleTasksSyncModal';
import { WalletView } from './components/wallet/WalletView';
import { MembershipView } from './components/membership/MembershipView';
import { ReferralView } from './components/referrals/ReferralView';
import { ProfileView } from './components/profile/ProfileView';
import { DownloadAppView } from './components/pwa/DownloadAppView';
import { VipTasksView } from './components/vip/VipTasksView';
import { GameZoneView } from './components/games/GameZoneView';
import { InvestmentDashboardView } from './components/investment/InvestmentDashboardView';
import { OffersView } from './components/offers/OffersView';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AiVoiceAssistantModal } from './components/voice/AiVoiceAssistantModal';
import { SupportChatModal } from './components/support/SupportChatModal';
import { CookieSecurityBanner } from './components/auth/CookieSecurityBanner';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { SplashScreenController } from './components/common/SplashScreenController';
import { Task } from './types';
import { ShieldCheck, Mic, Sparkles } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { isAdminAuthenticated } = useApp();
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  
  // Modals state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [isGoogleTasksOpen, setIsGoogleTasksOpen] = useState(false);
  const [isAiVoiceOpen, setIsAiVoiceOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [aiVoiceInitialQuery, setAiVoiceInitialQuery] = useState<string>('');
  const [activeTaskToExecute, setActiveTaskToExecute] = useState<Task | null>(null);

  const handleStartTask = (task: Task) => {
    setActiveTaskToExecute(task);
  };

  const handleOpenAdmin = () => {
    if (isAdminAuthenticated) {
      setCurrentTab('admin');
    } else {
      setIsAdminLoginOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex font-sans transition-colors selection:bg-emerald-500 selection:text-white pb-20 sm:pb-6">
      
      {/* Cookie Security Diagnostic & Resolution Banner */}
      <CookieSecurityBanner />

      {/* Desktop Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenAdmin={handleOpenAdmin}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
      />

      {/* Right Column (Navbar + Main Content) */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Navigation */}
        <Navbar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenAuth={() => setIsAuthOpen(true)}
          onOpenAdminLogin={handleOpenAdmin}
          onOpenSupport={() => setIsSupportOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 w-full max-w-4xl mx-auto px-3.5 sm:px-6 py-4 sm:py-6">
        {currentTab === 'dashboard' && (
          <DashboardView
            onOpenTasks={() => setCurrentTab('tasks')}
            onOpenWallet={() => setCurrentTab('wallet')}
            onOpenMembership={() => setCurrentTab('membership')}
            onOpenGoogleTasks={() => setIsGoogleTasksOpen(true)}
            onOpenVipTasks={() => setCurrentTab('vip_tasks')}
            onOpenGames={() => setCurrentTab('games')}
            onOpenDownloadApp={() => setCurrentTab('download_app')}
            onStartTask={handleStartTask}
            onOpenReferrals={() => setCurrentTab('referrals')}
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenInvestments={() => setCurrentTab('investments')}
            onOpenAiVoice={(query?: string) => {
              setAiVoiceInitialQuery(query || '');
              setIsAiVoiceOpen(true);
            }}
          />
        )}

        {currentTab === 'investments' && (
          <InvestmentDashboardView
            onBackToDashboard={() => setCurrentTab('dashboard')}
            onOpenWallet={() => setCurrentTab('wallet')}
          />
        )}

        {currentTab === 'download_app' && (
          <DownloadAppView onBackToDashboard={() => setCurrentTab('dashboard')} />
        )}

        {currentTab === 'tasks' && (
          <TasksView
            onStartTask={handleStartTask}
            onOpenGoogleTasks={() => setIsGoogleTasksOpen(true)}
          />
        )}

        {currentTab === 'vip_tasks' && (
          <VipTasksView onOpenWallet={() => setCurrentTab('wallet')} />
        )}

        {currentTab === 'games' && <GameZoneView />}

        {currentTab === 'wallet' && (
          <WalletView onOpenInvestments={() => setCurrentTab('investments')} />
        )}

        {currentTab === 'membership' && <MembershipView />}

        {currentTab === 'offers' && (
          <OffersView
            onBackToDashboard={() => setCurrentTab('dashboard')}
            onOpenInvestments={() => setCurrentTab('investments')}
            onOpenTasks={() => setCurrentTab('tasks')}
            onOpenVip={() => setCurrentTab('membership')}
          />
        )}

        {currentTab === 'referrals' && <ReferralView />}

        {currentTab === 'profile' && (
          <ProfileView onOpenGoogleTasks={() => setIsGoogleTasksOpen(true)} />
        )}

        {currentTab === 'admin' && (
          isAdminAuthenticated ? (
            <AdminDashboard onBackToApp={() => setCurrentTab('dashboard')} />
          ) : (
            <div className="p-8 sm:p-10 text-center space-y-4 max-w-md mx-auto my-12 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl text-white animate-in fade-in">
              <div className="w-14 h-14 rounded-2xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center mx-auto shadow-md">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-black text-white">Admin Authentication Required</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  The Admin Dashboard is strictly restricted. Please authenticate with valid administrative credentials to continue.
                </p>
              </div>
              <button
                onClick={() => setIsAdminLoginOpen(true)}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-95 text-white font-black text-xs shadow-lg shadow-purple-600/20 active:scale-95 transition-all cursor-pointer"
              >
                Sign In to Admin Panel
              </button>
            </div>
          )
        )}
      </main>
      </div>

      {/* Floating AI Voice Assistant Button */}
      <div className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40">
        <button
          onClick={() => setIsAiVoiceOpen(true)}
          className="group flex items-center gap-2 px-4 py-3 rounded-full bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white shadow-2xl shadow-indigo-600/50 border border-indigo-400/30 transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
          title="Talk with Earnie AI Voice Assistant"
        >
          <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center animate-pulse">
            <Mic className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-xs font-black tracking-wide hidden sm:inline">Earnie AI Voice</span>
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
        </button>
      </div>

      {/* Mobile Bottom Navigation */}
      {currentTab !== 'admin' && (
        <MobileBottomNav
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
        />
      )}

      {/* Slide-over Notifications Drawer */}
      <NotificationDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
      />

      {/* User Login/Register Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

      {/* Secure Admin Login Modal */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onSuccess={() => setCurrentTab('admin')}
      />

      {/* Interactive Task Execution Modal */}
      <TaskExecutionModal
        task={activeTaskToExecute}
        isOpen={!!activeTaskToExecute}
        onClose={() => setActiveTaskToExecute(null)}
      />

      {/* Google Tasks Sync Modal */}
      <GoogleTasksSyncModal
        isOpen={isGoogleTasksOpen}
        onClose={() => setIsGoogleTasksOpen(false)}
      />

      {/* AI Voice Assistant Modal */}
      <AiVoiceAssistantModal
        isOpen={isAiVoiceOpen}
        onClose={() => {
          setIsAiVoiceOpen(false);
          setAiVoiceInitialQuery('');
        }}
        onNavigate={(tab) => setCurrentTab(tab)}
        initialQuery={aiVoiceInitialQuery}
      />

      {/* Support Team & Helpdesk Modal */}
      <SupportChatModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
      />

    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <SplashScreenController>
        <AppProvider>
          <MainAppContent />
        </AppProvider>
      </SplashScreenController>
    </ErrorBoundary>
  );
}
