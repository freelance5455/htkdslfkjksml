/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { BottomNav, TabType } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { EditorView } from './components/EditorView';
import { VideoSplitterView } from './components/VideoSplitterView';
import { TemplatesView } from './components/TemplatesView';
import { AIToolsView } from './components/AIToolsView';
import { ProjectsView } from './components/ProjectsView';
import { AICommandModal } from './components/AICommandModal';
import { VideoProject, VideoTemplate, AIExecutionPlan } from './types/project';
import {
  getSavedProjects,
  saveProject,
  deleteProject as removeProjectStorage,
  duplicateProject as cloneProjectStorage,
  createDefaultProject
} from './utils/projectStorage';
import { generateSyntheticSampleVideo } from './utils/sampleVideo';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [projects, setProjects] = useState<VideoProject[]>([]);
  const [currentProject, setCurrentProject] = useState<VideoProject>(createDefaultProject);

  const [isLoadingSample, setIsLoadingSample] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);

  // Hidden references for video media & canvas pipeline
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Sync RTL/LTR with HTML document
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Load saved projects on mount
  useEffect(() => {
    const saved = getSavedProjects();
    if (saved.length > 0) {
      setProjects(saved);
      setCurrentProject(saved[0]);
    } else {
      const initial = createDefaultProject();
      saveProject(initial);
      setProjects([initial]);
      setCurrentProject(initial);
    }
  }, []);

  // Update video element source whenever current project videoUrl changes
  useEffect(() => {
    const video = videoRef.current;
    if (video && currentProject.videoUrl) {
      video.src = currentProject.videoUrl;
      video.load();
    }
  }, [currentProject.videoUrl]);

  // Save current project state changes
  const handleUpdateProject = (updated: Partial<VideoProject>) => {
    setCurrentProject((prev) => {
      const next = { ...prev, ...updated, updatedAt: Date.now() };
      saveProject(next);
      setProjects(getSavedProjects());
      return next;
    });
  };

  // Video File Upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const video = videoRef.current || document.createElement('video');
    video.preload = 'metadata';
    video.src = url;

    video.onloadedmetadata = () => {
      const dur = Math.round(video.duration) || 60;
      const w = video.videoWidth || 1280;
      const h = video.videoHeight || 720;
      const aspect = w > h ? '16:9' : '9:16';

      handleUpdateProject({
        name: file.name.replace(/\.[^/.]+$/, ''),
        videoFileName: file.name,
        videoUrl: url,
        duration: dur,
        width: w,
        height: h,
        aspectRatio: aspect as any
      });

      setActiveTab('editor');
    };
  };

  // Generate / Load instant synthetic sample video
  const handleLoadSample = async () => {
    setIsLoadingSample(true);
    try {
      const sample = await generateSyntheticSampleVideo(65, 1280, 720);
      handleUpdateProject({
        name: 'فيديو تجريبي Designo HD',
        videoFileName: 'designo_sample.webm',
        videoUrl: sample.url,
        duration: sample.duration,
        width: 1280,
        height: 720,
        aspectRatio: '9:16',
        blurBackground: true
      });
      setActiveTab('editor');
    } catch (err: any) {
      console.error('Failed to create sample video', err);
    } finally {
      setIsLoadingSample(false);
    }
  };

  // Create new blank project
  const handleNewProject = () => {
    const p = createDefaultProject();
    saveProject(p);
    setProjects(getSavedProjects());
    setCurrentProject(p);
    setActiveTab('editor');
  };

  // Delete project
  const handleDeleteProject = (id: string) => {
    removeProjectStorage(id);
    const remaining = getSavedProjects();
    setProjects(remaining);
    if (currentProject.id === id) {
      if (remaining.length > 0) {
        setCurrentProject(remaining[0]);
      } else {
        const fresh = createDefaultProject();
        saveProject(fresh);
        setProjects([fresh]);
        setCurrentProject(fresh);
      }
    }
  };

  // Duplicate project
  const handleDuplicateProject = (id: string) => {
    const copy = cloneProjectStorage(id);
    if (copy) {
      setProjects(getSavedProjects());
      setCurrentProject(copy);
    }
  };

  // Rename project
  const handleRenameProject = (id: string, newName: string) => {
    if (currentProject.id === id) {
      handleUpdateProject({ name: newName });
    } else {
      const target = projects.find((p) => p.id === id);
      if (target) {
        saveProject({ ...target, name: newName });
        setProjects(getSavedProjects());
      }
    }
  };

  // Apply template
  const handleApplyTemplate = (tpl: VideoTemplate) => {
    handleUpdateProject({
      templateId: tpl.id,
      aspectRatio: tpl.aspectRatio,
      blurBackground: tpl.blurBackground,
      filter: tpl.filter,
      textOverlays: [
        {
          id: 'tpl_title',
          text: tpl.defaultTitle,
          position: tpl.aspectRatio === '9:16' ? 'top' : 'bottom',
          fontSize: 30,
          color: '#ffffff',
          bgColor: tpl.accentColor + 'dd',
          hasBackground: true
        }
      ]
    });
    setActiveTab('editor');
  };

  // Apply AI Execution Plan
  const handleApplyPlan = (plan: AIExecutionPlan) => {
    const updates: Partial<VideoProject> = {};

    if (plan.actions.aspectRatio && plan.actions.aspectRatio !== 'original') {
      updates.aspectRatio = plan.actions.aspectRatio;
    }
    if (plan.actions.blurBackground !== undefined) {
      updates.blurBackground = plan.actions.blurBackground;
    }
    if (plan.actions.filter) {
      updates.filter = plan.actions.filter;
    }
    if (plan.actions.watermarkText) {
      updates.watermarkText = plan.actions.watermarkText;
    }
    if (plan.actions.speed) {
      updates.speed = plan.actions.speed;
    }
    if (plan.actions.volume !== undefined) {
      updates.volume = plan.actions.volume;
    }

    if (plan.actions.split && plan.actions.split.enabled) {
      updates.splitSettings = {
        mode: plan.actions.split.mode === 'count' ? 'count' : 'duration',
        value: plan.actions.split.value || 40
      };
    }

    if (plan.actions.title) {
      updates.textOverlays = [
        {
          id: 'ai_title',
          text: plan.actions.title,
          position: 'top',
          fontSize: 32,
          color: '#ffffff',
          bgColor: 'rgba(124, 58, 237, 0.85)',
          hasBackground: true
        }
      ];
    }

    handleUpdateProject(updates);

    // If split was explicitly requested in the plan, navigate to splitter view
    if (plan.actions.split && plan.actions.split.enabled) {
      setActiveTab('splitter');
    } else {
      setActiveTab('editor');
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0b14] text-[#f1f3f9] flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Hidden Master Video Element for Decoding & Media Streams */}
      <video
        ref={videoRef}
        crossOrigin="anonymous"
        playsInline
        muted={currentProject.isMuted}
        className="hidden"
        onLoadedMetadata={() => {
          const v = videoRef.current;
          if (v && v.duration && isFinite(v.duration) && v.duration > 0) {
            handleUpdateProject({ duration: Math.round(v.duration) });
          }
        }}
      />

      {/* Hidden File Input for Video Selection */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/quicktime,video/x-matroska,video/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Top Navbar */}
      <Navbar
        onNewProject={handleNewProject}
        onLoadSample={handleLoadSample}
        onOpenAICommand={() => setIsAIModalOpen(true)}
        isLoadingSample={isLoadingSample}
        lang={lang}
        onToggleLang={() => setLang(lang === 'ar' ? 'en' : 'ar')}
        currentProjectName={currentProject.name}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <HomeView
            onNewProject={handleNewProject}
            onUploadClick={() => fileInputRef.current?.click()}
            onOpenSplitter={() => setActiveTab('splitter')}
            onOpenTemplates={() => setActiveTab('templates')}
            onOpenEditor={() => setActiveTab('editor')}
            onOpenAICommand={() => setIsAIModalOpen(true)}
            onOpenAITools={() => setActiveTab('ai_tools')}
            onLoadSample={handleLoadSample}
            isLoadingSample={isLoadingSample}
            projects={projects}
            onSelectProject={(p) => {
              setCurrentProject(p);
              setActiveTab('editor');
            }}
            onSelectTemplate={handleApplyTemplate}
            lang={lang}
          />
        )}

        {activeTab === 'editor' && (
          <EditorView
            project={currentProject}
            onUpdateProject={handleUpdateProject}
            videoRef={videoRef}
            canvasRef={canvasRef}
            onOpenAICommand={() => setIsAIModalOpen(true)}
            onNavigateToSplitter={() => setActiveTab('splitter')}
            lang={lang}
          />
        )}

        {activeTab === 'splitter' && (
          <VideoSplitterView
            project={currentProject}
            onUpdateProject={handleUpdateProject}
            videoRef={videoRef}
            lang={lang}
          />
        )}

        {activeTab === 'templates' && (
          <TemplatesView
            onApplyTemplate={handleApplyTemplate}
            lang={lang}
          />
        )}

        {activeTab === 'ai_tools' && (
          <AIToolsView
            project={currentProject}
            onUpdateProject={handleUpdateProject}
            lang={lang}
          />
        )}

        {activeTab === 'projects' && (
          <ProjectsView
            projects={projects}
            onSelectProject={(p) => {
              setCurrentProject(p);
              setActiveTab('editor');
            }}
            onNewProject={handleNewProject}
            onDeleteProject={handleDeleteProject}
            onDuplicateProject={handleDuplicateProject}
            onRenameProject={handleRenameProject}
            lang={lang}
          />
        )}
      </main>

      {/* Mobile-First Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        lang={lang}
      />

      {/* AI Command Center Modal */}
      <AICommandModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        project={currentProject}
        onApplyPlan={handleApplyPlan}
        lang={lang}
      />
    </div>
  );
}
