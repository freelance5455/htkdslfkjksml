import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ChatMessage, 
  NoteItem, 
  ReminderItem, 
  SystemTelemetry, 
  ActiveTab, 
  SupportedLanguage 
} from './types/assistant';
import { Navbar } from './components/Navbar';
import { HologramDisplay } from './components/HologramDisplay';
import { LiveScreenObserverHUD } from './components/LiveScreenObserverHUD';
import { ScreenPermissionModal } from './components/ScreenPermissionModal';
import { AssistantChat } from './components/AssistantChat';
import { DirectVoicePad } from './components/DirectVoicePad';
import { SocialAppAutomation } from './components/SocialAppAutomation';
import { ScreenVisionHUD } from './components/ScreenVisionHUD';
import { VisionStudio } from './components/VisionStudio';
import { NotesManager } from './components/NotesManager';
import { RemindersSchedule } from './components/RemindersSchedule';
import { HardwareTools } from './components/HardwareTools';
import { SettingsView } from './components/SettingsView';
import { soundFx } from './services/soundFx';
import { speechService } from './services/speechService';

export default function App() {
  // User identity & preferences
  const [userName, setUserName] = useState<string>(() => {
    return localStorage.getItem('rb_user_name') || 'Rubel Boss';
  });

  const [language, setLanguage] = useState<SupportedLanguage>(() => {
    return (localStorage.getItem('rb_language') as SupportedLanguage) || 'bn';
  });

  const [autoSpeak, setAutoSpeak] = useState<boolean>(() => {
    const val = localStorage.getItem('rb_auto_speak');
    return val !== null ? val === 'true' : true;
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const val = localStorage.getItem('rb_sound_fx');
    return val !== null ? val === 'true' : true;
  });

  const [speechRate, setSpeechRate] = useState<number>(() => {
    const val = localStorage.getItem('rb_speech_rate');
    return val ? parseFloat(val) : 0.95;
  });

  const [handsFreeVoice, setHandsFreeVoice] = useState<boolean>(() => {
    const val = localStorage.getItem('rb_hands_free');
    return val === 'true';
  });

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('assistant');

  // Assistant status
  const [status, setStatus] = useState<'ready' | 'listening' | 'thinking' | 'speaking'>('ready');
  const [rmsVolume, setRmsVolume] = useState<number>(0);
  const [isTorchActive, setIsTorchActive] = useState<boolean>(false);
  const torchTrackRef = useRef<MediaStreamTrack | null>(null);

  // Global Screen Stream & Observer HUD
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [isScreenCapturing, setIsScreenCapturing] = useState<boolean>(false);
  const [showPermissionModal, setShowPermissionModal] = useState<boolean>(false);
  const hiddenScreenVideoRef = useRef<HTMLVideoElement | null>(null);

  // Messages History
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const initialGreeting =
      language === 'bn'
        ? 'সালাম ও শুভেচ্ছা বস (Rubel Boss)! আমি আপনার ব্যক্তিগত হলোগ্রাফিক এআই অ্যাসিস্ট্যান্ট।\n\n' +
          '✨ **নতুন ফিচারসমূহ:**\n' +
          '• **ডিসপ্লে ওভারভিউ পারমিশন:** স্ক্রিন পারমিশন দিলে আমি আপনার পুরো স্ক্রিন লাইভ দেখে মুখে যা বলবেন তা করে দিতে পারব।\n' +
          '• **মাইক ছাড়াই ডাইরেক্ট ভয়েস:** হেডসেট বা মাইক প্লাগ না করেও নিচে এক ক্লিকে বা লিখে ডাইরেক্ট ভয়েস রান করতে পারবেন।\n' +
          '• **অ্যাপস ও সোশ্যাল অটোমেশন:** ফেসবুক পোস্ট, কমেন্ট, ইউটিউব, টিকটক সরাসরি নিয়ন্ত্রণ করতে পারব।\n' +
          'বলুন বস, আজকে আপনার কী কাজ করে দেব?'
        : 'Greetings Boss (Rubel Boss)! I am your personal holographic AI assistant.\n\n' +
          '✨ **Active Capabilities:**\n' +
          '• **Display Overview Permission:** Grant screen access for me to observe your live screen and execute commands by voice.\n' +
          '• **Direct Voice without mic:** Tap or type direct voice prompts without needing an external microphone.\n' +
          '• **App & Social Automation:** Create posts, comments, and navigate Facebook, YouTube, TikTok.\n' +
          'Standing by for your command, Boss!';

    return [
      {
        id: 'welcome-1',
        role: 'assistant',
        content: initialGreeting,
        timestamp: Date.now(),
      },
    ];
  });

  // Notes
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const raw = localStorage.getItem('rb_notes');
      return raw ? JSON.parse(raw) : [
        {
          id: 'note-default',
          title: 'Rubel Boss AI System Specs',
          content: 'Created by Rubel Boss. Quantum Multimodal Hologram AI with live screen observation, direct voice, and social automation.',
          createdAt: Date.now(),
          tag: 'Directives',
        },
      ];
    } catch {
      return [];
    }
  });

  // Reminders
  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const raw = localStorage.getItem('rb_reminders');
      return raw ? JSON.parse(raw) : [
        {
          id: 'rem-1',
          text: 'Verify display overview permission and screen observer HUD',
          targetTime: 'Today 5:00 PM',
          isCompleted: false,
          createdAt: Date.now(),
        },
      ];
    } catch {
      return [];
    }
  });

  // Telemetry
  const [telemetry, setTelemetry] = useState<SystemTelemetry>({
    batteryLevel: 100,
    isCharging: false,
    powerSource: 'Battery',
    networkOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    latencyMs: 18,
    screenResolution: typeof window !== 'undefined' ? `${window.innerWidth}x${window.innerHeight}` : '1920x1080',
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'RubelBossAI/2.5',
    isTorchActive: false,
  });

  // Sync settings with services
  useEffect(() => {
    soundFx.enabled = soundEnabled;
    speechService.autoSpeak = autoSpeak;
    speechService.speechRate = speechRate;
  }, [soundEnabled, autoSpeak, speechRate]);

  useEffect(() => {
    localStorage.setItem('rb_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('rb_reminders', JSON.stringify(reminders));
  }, [reminders]);

  // Telemetry update
  const probeTelemetry = useCallback(async () => {
    const start = performance.now();
    try {
      await fetch('/api/health');
      const ping = Math.round(performance.now() - start);
      setTelemetry((prev) => ({ ...prev, latencyMs: ping }));
    } catch {
      // ignore
    }

    if ('getBattery' in navigator) {
      try {
        const b = await (navigator as any).getBattery();
        setTelemetry((prev) => ({
          ...prev,
          batteryLevel: Math.round(b.level * 100),
          isCharging: b.charging,
          powerSource: b.charging ? 'Power Adapter' : 'Battery',
        }));
      } catch {
        // ignore
      }
    }

    setTelemetry((prev) => ({
      ...prev,
      screenResolution: `${window.innerWidth}x${window.innerHeight}`,
      networkOnline: navigator.onLine,
    }));
  }, []);

  useEffect(() => {
    probeTelemetry();
    const interval = setInterval(probeTelemetry, 30000);
    return () => clearInterval(interval);
  }, [probeTelemetry]);

  // Global Screen Stream Capture Engine
  const startScreenCaptureStream = async () => {
    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        alert(
          language === 'bn'
            ? 'আপনার ব্রাউজারে ডিসপ্লে ওভারভিউ সাপোর্ট করছে না।'
            : 'Screen sharing is not supported in this browser.'
        );
        return;
      }

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { displaySurface: 'monitor' },
        audio: false,
      });

      setScreenStream(stream);
      setIsScreenCapturing(true);
      soundFx.playCyber('activate');

      const video = document.createElement('video');
      video.srcObject = stream;
      video.autoplay = true;
      video.playsInline = true;
      video.muted = true;
      await video.play();
      hiddenScreenVideoRef.current = video;

      stream.getVideoTracks()[0].onended = () => {
        stopScreenCaptureStream();
      };

      // Add announcement in chat
      const msg: ChatMessage = {
        id: `sys-${Date.now()}`,
        role: 'assistant',
        content:
          language === 'bn'
            ? '👁️ **ডিসপ্লে ওভারভিউ সংযুক্ত হয়েছে!** আমি এখন আপনার স্ক্রিনের সবকিছু দেখতে পাচ্ছি। মুখে যেকোনো আদেশ দিন (যেমন: ফেসবুকে পোস্ট করো, কোড ফিক্স করো, লেখা পড়ে শোনাও)।'
            : '👁️ **Display Overview Connected!** I am now observing your screen in real time. Speak any directive to execute.',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, msg]);
      if (autoSpeak) {
        speechService.speak(msg.content);
      }
    } catch (err: any) {
      console.warn('Screen permission cancelled or failed:', err);
    }
  };

  const stopScreenCaptureStream = () => {
    if (screenStream) {
      screenStream.getTracks().forEach((track) => track.stop());
      setScreenStream(null);
    }
    if (hiddenScreenVideoRef.current) {
      hiddenScreenVideoRef.current = null;
    }
    setIsScreenCapturing(false);
    soundFx.playCyber('alert');
  };

  // Grab instantaneous screen frame as base64
  const grabLiveScreenFrame = (): string | null => {
    if (!hiddenScreenVideoRef.current) return null;
    const video = hiddenScreenVideoRef.current;
    if (!video.videoWidth || !video.videoHeight) return null;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  };

  // Voice Listening Function
  const handleToggleVoice = useCallback((forceStart?: boolean) => {
    if (status === 'listening' && !forceStart) {
      speechService.stopListening();
      setStatus('ready');
      setRmsVolume(0);
      soundFx.playCyber('click');
      return;
    }

    soundFx.playCyber('activate');
    speechService.startListening(language, {
      onStart: () => {
        setStatus('listening');
      },
      onEnd: () => {
        if (status === 'listening') {
          setStatus('ready');
        }
        setRmsVolume(0);
      },
      onVolume: (rms) => {
        setRmsVolume(rms);
      },
      onResult: (transcript) => {
        soundFx.playCyber('click');
        handleSendMessage(transcript);
      },
      onError: (err) => {
        console.warn('Voice error:', err);
        setStatus('ready');
        setRmsVolume(0);
      },
    });
  }, [status, language]);

  // Handle Natural Social Media Command Interceptor
  const handleInterceptSocialAction = (query: string): boolean => {
    const q = query.toLowerCase();

    // 1. Facebook post command
    if (q.includes('ফেসবুকে পোস্ট') || q.includes('পোস্ট করো') || q.includes('post on facebook') || q.includes('facebook post')) {
      const content = query.replace(/(?:ফেসবুকে পোস্ট করো|ফেসবুক পোস্ট|post on facebook|facebook post|ফেসবুকে পোস্ট)\s*:?/i, '').trim();
      const finalCopy = content || 'Rubel Boss AI Assistant is now online with autonomous multimodal screen vision!';
      navigator.clipboard.writeText(finalCopy);
      const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent('https://facebook.com')}&quote=${encodeURIComponent(finalCopy)}`;
      window.open(url, '_blank');
      return true;
    }

    // 2. YouTube play command
    if (q.includes('ইউটিউবে') || q.includes('ইউটিউব চালাও') || q.includes('play on youtube') || q.includes('search youtube')) {
      const content = query.replace(/(?:ইউটিউবে চালাও|ইউটিউব ওপেন|play on youtube|search youtube|ইউটিউবে)\s*:?/i, '').trim();
      const url = content
        ? `https://www.youtube.com/results?search_query=${encodeURIComponent(content)}`
        : 'https://www.youtube.com';
      window.open(url, '_blank');
      return true;
    }

    // 3. TikTok command
    if (q.includes('টিকটক') || q.includes('টিকটকে') || q.includes('tiktok') || q.includes('open tiktok')) {
      const content = query.replace(/(?:টিকটক ওপেন|টিকটকে সার্চ|open tiktok|tiktok)\s*:?/i, '').trim();
      const url = content
        ? `https://www.tiktok.com/search?q=${encodeURIComponent(content)}`
        : 'https://www.tiktok.com';
      window.open(url, '_blank');
      return true;
    }

    return false;
  };

  // Main Send Message & Screen AI Action Processing
  const handleSendMessage = async (text: string, manualImageBase64?: string) => {
    if (!text.trim() && !manualImageBase64) return;

    soundFx.playCyber('send');
    speechService.stopSpeaking();
    speechService.stopListening();

    // Check if user is asking for screen action while screen is connected
    let attachedImage = manualImageBase64;
    if (!attachedImage && isScreenCapturing) {
      const liveFrame = grabLiveScreenFrame();
      if (liveFrame) {
        attachedImage = liveFrame;
      }
    }

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text.trim() || '[Direct Screen Task Request]',
      timestamp: Date.now(),
      imageBase64: attachedImage,
    };

    setMessages((prev) => [...prev, userMessage]);
    setStatus('thinking');

    // Check if social app action was requested
    const wasSocialAction = handleInterceptSocialAction(text);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-8),
          userName,
          imageBase64: attachedImage,
          language,
        }),
      });

      const data = await response.json();
      let replyText = data.reply || 'Task acknowledged.';

      if (wasSocialAction) {
        replyText =
          language === 'bn'
            ? `হুকুম তামিল হলো বস! আপনার নির্দেশ অনুযায়ী টার্গেট অ্যাপটি খোলা হয়েছে এবং কন্টেন্ট ক্লিপবোর্ডে কপি করা হয়েছে।\n\n${replyText}`
            : `Directive executed Boss! The requested app has been launched and content prepared.\n\n${replyText}`;
      }

      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: replyText,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, botMessage]);
      soundFx.playCyber('receive');

      if (autoSpeak) {
        setStatus('speaking');
        speechService.speak(
          replyText,
          () => setStatus('speaking'),
          () => {
            setStatus('ready');
            if (handsFreeVoice) {
              setTimeout(() => {
                handleToggleVoice(true);
              }, 400);
            }
          }
        );
      } else {
        setStatus('ready');
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: `Connection issue: ${err?.message || 'Check server connection'}. Autonomous local engine active.`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errMsg]);
      setStatus('ready');
    }
  };

  const handleSpeakMessage = (text: string) => {
    soundFx.playCyber('click');
    setStatus('speaking');
    speechService.speak(
      text,
      () => setStatus('speaking'),
      () => setStatus('ready')
    );
  };

  const handleStopSpeaking = () => {
    soundFx.playCyber('click');
    speechService.stopSpeaking();
    setStatus('ready');
  };

  const handleClearChat = () => {
    soundFx.playCyber('alert');
    const resetGreeting =
      language === 'bn'
        ? `কথোপকথন মেমরি রিসেট করা হয়েছে, বস (${userName})। আমি সম্পূর্ণ প্রস্তুত।`
        : `Conversation memory reset, Boss (${userName}). Systems online and ready.`;

    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        content: resetGreeting,
        timestamp: Date.now(),
      },
    ]);
  };

  // Torch Toggle
  const handleToggleTorch = async () => {
    soundFx.playCyber('torch');
    const newState = !isTorchActive;
    setIsTorchActive(newState);

    if (newState) {
      try {
        if (navigator.mediaDevices?.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' },
          });
          const track = stream.getVideoTracks()[0];
          torchTrackRef.current = track;
        }
      } catch {
        // Fallback handled in UI
      }
    } else {
      if (torchTrackRef.current) {
        torchTrackRef.current.stop();
        torchTrackRef.current = null;
      }
    }
  };

  // Notes Actions
  const handleAddNote = (title: string, content: string, tag: string = 'General') => {
    soundFx.playCyber('complete');
    const newNote: NoteItem = {
      id: `note-${Date.now()}`,
      title,
      content,
      tag,
      createdAt: Date.now(),
    };
    setNotes((prev) => [newNote, ...prev]);
  };

  const handleDeleteNote = (id: string) => {
    soundFx.playCyber('click');
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  // Reminders Actions
  const handleAddReminder = (text: string, targetTime?: string) => {
    soundFx.playCyber('complete');
    const newRem: ReminderItem = {
      id: `rem-${Date.now()}`,
      text,
      targetTime,
      isCompleted: false,
      createdAt: Date.now(),
    };
    setReminders((prev) => [newRem, ...prev]);
  };

  const handleToggleReminder = (id: string) => {
    soundFx.playCyber('click');
    setReminders((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isCompleted: !r.isCompleted } : r))
    );
  };

  const handleDeleteReminder = (id: string) => {
    soundFx.playCyber('click');
    setReminders((prev) => prev.filter((r) => r.id !== id));
  };

  // Settings Actions
  const handleUpdateUserName = (newName: string) => {
    soundFx.playCyber('complete');
    setUserName(newName);
    localStorage.setItem('rb_user_name', newName);
  };

  const handleToggleLanguage = () => {
    soundFx.playCyber('click');
    const next = language === 'bn' ? 'en' : 'bn';
    setLanguage(next);
    localStorage.setItem('rb_language', next);
  };

  const handleToggleAutoSpeak = () => {
    soundFx.playCyber('click');
    const next = !autoSpeak;
    setAutoSpeak(next);
    localStorage.setItem('rb_auto_speak', String(next));
    if (!next) speechService.stopSpeaking();
  };

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    localStorage.setItem('rb_sound_fx', String(next));
  };

  const handleUpdateSpeechRate = (rate: number) => {
    setSpeechRate(rate);
    localStorage.setItem('rb_speech_rate', String(rate));
  };

  const handleToggleHandsFreeVoice = () => {
    soundFx.playCyber('activate');
    const next = !handsFreeVoice;
    setHandsFreeVoice(next);
    localStorage.setItem('rb_hands_free', String(next));
  };

  // Image/Screen Analysis helper
  const handleAnalyzeImageOrScreen = async (prompt: string, base64: string): Promise<string> => {
    soundFx.playCyber('send');
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: prompt,
        imageBase64: base64,
        userName,
        language,
      }),
    });
    const data = await res.json();
    soundFx.playCyber('receive');
    return data.reply || 'No analysis generated.';
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 flex flex-col cyber-grid">
      {/* Screen Permission Dialog */}
      <ScreenPermissionModal
        isOpen={showPermissionModal}
        onClose={() => setShowPermissionModal(false)}
        onGrantPermission={startScreenCaptureStream}
        language={language}
      />

      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        onTabChange={(tab) => {
          soundFx.playCyber('click');
          setActiveTab(tab);
        }}
        language={language}
        onToggleLanguage={handleToggleLanguage}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 md:p-6 space-y-6">
        {/* Hologram Central Display HUD */}
        <HologramDisplay
          status={status}
          userName={userName}
          rmsVolume={rmsVolume}
          batteryLevel={telemetry.batteryLevel}
          latencyMs={telemetry.latencyMs}
          onMicClick={() => handleToggleVoice()}
          isListening={status === 'listening'}
        />

        {/* Live Screen Observer HUD (Displayed right below Hologram in Assistant tab) */}
        {activeTab === 'assistant' && (
          <LiveScreenObserverHUD
            stream={screenStream}
            isCapturing={isScreenCapturing}
            onRequestPermission={() => setShowPermissionModal(true)}
            onStopCapture={stopScreenCaptureStream}
            onExecuteScreenCommand={(cmd) => handleSendMessage(cmd)}
            language={language}
            isProcessing={status === 'thinking'}
          />
        )}

        {/* Tab Switcher Body */}
        {activeTab === 'assistant' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Main Chat Interface */}
            <div className="lg:col-span-8 h-[600px] md:h-[680px]">
              <AssistantChat
                messages={messages}
                isThinking={status === 'thinking'}
                isListening={status === 'listening'}
                isSpeaking={status === 'speaking'}
                userName={userName}
                language={language}
                onSendMessage={handleSendMessage}
                onToggleVoice={() => handleToggleVoice()}
                onStopSpeaking={handleStopSpeaking}
                onSpeakMessage={handleSpeakMessage}
                onClearChat={handleClearChat}
                onNavigateTab={(tab) => {
                  soundFx.playCyber('click');
                  setActiveTab(tab);
                }}
                onToggleTorch={handleToggleTorch}
                isTorchActive={isTorchActive}
              />
            </div>

            {/* Direct Voice & Command Pad (Right Side Panel) */}
            <div className="lg:col-span-4 space-y-4">
              <DirectVoicePad
                language={language}
                onExecuteCommand={(cmd) => handleSendMessage(cmd)}
                isListening={status === 'listening'}
                handsFreeActive={handsFreeVoice}
                onToggleHandsFree={handleToggleHandsFreeVoice}
              />

              {/* Quick App & Social Media Automation Card */}
              <div 
                onClick={() => {
                  soundFx.playCyber('click');
                  setActiveTab('social');
                }}
                className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0c182d] to-[#1e0e29] border border-cyan-500/40 hover:border-cyan-400 p-5 cursor-pointer transition-all shadow-xl space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono-tech text-fuchsia-300 font-bold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-fuchsia-400 animate-ping" />
                    <span>APP AUTOMATION HUB</span>
                  </span>
                  <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-fuchsia-950 text-fuchsia-300 border border-fuchsia-500/30">
                    DIRECT
                  </span>
                </div>
                <h4 className="font-orbitron font-bold text-sm text-white group-hover:text-cyan-300 transition-colors">
                  {language === 'bn' ? 'ফেসবুক, ইউটিউব ও টিকটক অটোমেশন' : 'Facebook, YouTube & TikTok Actions'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {language === 'bn'
                    ? 'যেকোনো অ্যাপে ডাইরেক্ট পোস্ট করুন, কমেন্ট লিখুন এবং ব্রাউজ করুন।'
                    : 'Dispatch posts, generate comments, and launch social platforms directly.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Social App Automation Tab */}
        {activeTab === 'social' && (
          <SocialAppAutomation
            language={language}
            onExecuteCommand={(cmd) => handleSendMessage(cmd)}
            onSpeak={handleSpeakMessage}
          />
        )}

        {/* Vision & Full Screen HUD Tab */}
        {activeTab === 'vision' && (
          <div className="space-y-8">
            <ScreenVisionHUD
              language={language}
              onAnalyzeScreen={handleAnalyzeImageOrScreen}
              onSpeak={handleSpeakMessage}
            />

            <div className="pt-6 border-t border-cyan-900/40">
              <VisionStudio
                language={language}
                onAnalyze={handleAnalyzeImageOrScreen}
                onSendToChat={(report, img) => {
                  handleSendMessage(`[Vision Scan Report]: ${report}`, img);
                  setActiveTab('assistant');
                }}
                onSpeak={handleSpeakMessage}
              />
            </div>
          </div>
        )}

        {/* Notes Tab */}
        {activeTab === 'notes' && (
          <NotesManager
            notes={notes}
            language={language}
            onAddNote={handleAddNote}
            onDeleteNote={handleDeleteNote}
            onClearNotes={() => setNotes([])}
          />
        )}

        {/* Reminders Tab */}
        {activeTab === 'reminders' && (
          <RemindersSchedule
            reminders={reminders}
            language={language}
            onAddReminder={handleAddReminder}
            onToggleReminder={handleToggleReminder}
            onDeleteReminder={handleDeleteReminder}
          />
        )}

        {/* Hardware & Tools Tab */}
        {activeTab === 'tools' && (
          <HardwareTools
            telemetry={telemetry}
            language={language}
            onRefreshTelemetry={probeTelemetry}
            onToggleTorch={handleToggleTorch}
            isTorchActive={isTorchActive}
          />
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <SettingsView
            userName={userName}
            onUpdateUserName={handleUpdateUserName}
            language={language}
            onToggleLanguage={handleToggleLanguage}
            autoSpeak={autoSpeak}
            onToggleAutoSpeak={handleToggleAutoSpeak}
            soundEnabled={soundEnabled}
            onToggleSound={handleToggleSound}
            speechRate={speechRate}
            onUpdateSpeechRate={handleUpdateSpeechRate}
            handsFreeVoice={handsFreeVoice}
            onToggleHandsFreeVoice={handleToggleHandsFreeVoice}
            onClearHistory={handleClearChat}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-cyan-900/30 bg-[#050811]/90 py-4 text-center text-xs font-mono-tech text-slate-500">
        <p>RUBEL BOSS AI ASSISTANT · MASTERMIND: RUBEL BOSS · QUANTUM MULTIMODAL SYSTEM</p>
      </footer>
    </div>
  );
}
