import React, { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { soundManager } from './audio/soundManager';
import { BossHealthBar } from './components/BossHealthBar';
import { ControlsHelpModal } from './components/ControlsHelpModal';
import { FloatingCombatText } from './components/FloatingCombatText';
import { FruitDealerModal } from './components/FruitDealerModal';
import { GameHUD } from './components/GameHUD';
import { InventoryModal } from './components/InventoryModal';
import { QuestModal } from './components/QuestModal';
import { StatsModal } from './components/StatsModal';
import { VirtualControls } from './components/VirtualControls';
import { GameEngine } from './game/GameEngine';
import { WEAPONS } from './game/worldData';
import { BossTargetInfo, FloatingDamage, FruitType, MinimapData, PlayerStats, Quest, WeaponType } from './types/game';

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Game UI State
  const [stats, setStats] = useState<PlayerStats>({
    level: 1,
    exp: 0,
    maxExp: 100,
    beli: 5000,
    gems: 25,
    statPoints: 0,
    meleeStat: 1,
    defenseStat: 1,
    swordStat: 1,
    fruitStat: 1,
    maxHealth: 100,
    health: 100,
    maxEnergy: 100,
    energy: 100,
    equippedFruit: 'none',
    fruitMastery: 1,
    equippedWeapon: 'combat',
    hasHaki: true,
    hakiActive: false,
    observationActive: false,
    observationDodges: 3,
    maxObservationDodges: 3,
    isBuddhaTransformed: false,
    inventory: [
      { id: 'start_combat', type: 'weapon', itemKey: 'combat', name: 'Brawler Combat' },
    ],
  });

  const [activeQuest, setActiveQuest] = useState<Quest | null>(null);
  const [minimapData, setMinimapData] = useState<MinimapData | null>(null);
  const [bossTarget, setBossTarget] = useState<BossTargetInfo | null>(null);
  const [floatingDamages, setFloatingDamages] = useState<FloatingDamage[]>([]);
  const [interactPrompt, setInteractPrompt] = useState<string | null>(null);
  const [interactAction, setInteractAction] = useState<(() => void) | null>(null);
  const [skillCooldowns, setSkillCooldowns] = useState<Record<string, number>>({});
  const [levelUpNotice, setLevelUpNotice] = useState<number | null>(null);

  // Modals
  const [showStats, setShowStats] = useState(false);
  const [showFruitDealer, setShowFruitDealer] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [showQuests, setShowQuests] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    if (!canvasMountRef.current) return;

    // Expose global hook for 3D NPC interaction
    (window as any).openFruitDealer = () => setShowFruitDealer(true);

    const engine = new GameEngine(canvasMountRef.current, {
      onStatsUpdate: (newStats) => setStats(newStats),
      onQuestUpdate: (newQuest) => setActiveQuest(newQuest ? { ...newQuest } : null),
      onFloatingDamage: (dmg) => setFloatingDamages([dmg]),
      onInteractPrompt: (prompt, action) => {
        setInteractPrompt(prompt);
        setInteractAction(action ? () => action : null);
      },
      onSkillCooldownUpdate: (cds) => setSkillCooldowns(cds),
      onLevelUpNotice: (lvl) => {
        setLevelUpNotice(lvl);
        confetti({ particleCount: 90, spread: 80, origin: { y: 0.4 } });
        setTimeout(() => setLevelUpNotice(null), 3000);
      },
      onMinimapUpdate: (m) => setMinimapData(m),
      onBossTargetUpdate: (t) => setBossTarget(t),
    });

    engineRef.current = engine;

    // Initial background sound on first user touch/key
    const handleFirstInteraction = () => {
      soundManager.startBackgroundMusic();
      window.removeEventListener('pointerdown', handleFirstInteraction);
      window.removeEventListener('keydown', handleFirstInteraction);
    };
    window.addEventListener('pointerdown', handleFirstInteraction);
    window.addEventListener('keydown', handleFirstInteraction);

    // E key handler for interact prompt
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyE' && interactAction) {
        interactAction();
      }
      if (e.code === 'KeyC') {
        setShowStats((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('pointerdown', handleFirstInteraction);
      engine.dispose();
      engineRef.current = null;
    };
  }, [interactAction]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none">
      {/* Three.js Isolated Canvas Mount (per Three.js skill guidelines) */}
      <div ref={canvasMountRef} className="w-full h-full absolute inset-0 z-0" />

      {/* Primary HUD Overlay with 2D Minimap */}
      <GameHUD
        stats={stats}
        activeQuest={activeQuest}
        minimapData={minimapData}
        interactPrompt={interactPrompt}
        skillCooldowns={skillCooldowns}
        onTriggerAttack={() => engineRef.current?.triggerAttack()}
        onTriggerJump={() => engineRef.current?.triggerJump()}
        onTriggerSkill={(key) => engineRef.current?.triggerSkill(key)}
        onTriggerFlashStep={() => engineRef.current?.triggerFlashStep()}
        onToggleHaki={() => engineRef.current?.toggleHaki()}
        onToggleObservation={() => engineRef.current?.toggleObservation()}
        onOpenStats={() => setShowStats(true)}
        onOpenInventory={() => setShowInventory(true)}
        onOpenFruitDealer={() => setShowFruitDealer(true)}
        onOpenQuests={() => setShowQuests(true)}
        onOpenHelp={() => setShowHelp(true)}
      />

      {/* Major Enemy / Boss Targeted Health Bar */}
      <BossHealthBar boss={bossTarget} />

      {/* 3D-Projected Temporary Floating Combat Damage Text Overlays */}
      <FloatingCombatText engine={engineRef.current} items={floatingDamages} />

      {/* Virtual Controls for Android phones & touch devices */}
      <VirtualControls
        onVirtualMove={(x, z) => engineRef.current?.setVirtualMovement(x, z)}
        onTriggerAttack={() => engineRef.current?.triggerAttack()}
        onTriggerJump={() => engineRef.current?.triggerJump()}
        onTriggerFlashStep={() => engineRef.current?.triggerFlashStep()}
        onTriggerSkill={(k) => engineRef.current?.triggerSkill(k)}
        onToggleHaki={() => engineRef.current?.toggleHaki()}
        onToggleObservation={() => engineRef.current?.toggleObservation()}
        hasFruit={stats.equippedFruit !== 'none'}
      />

      {/* Level Up Announcement Banner */}
      {levelUpNotice && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-slate-950 px-8 py-3 rounded-2xl shadow-2xl font-black text-xl tracking-wider uppercase border-2 border-white/80 animate-bounce flex items-center gap-3">
          <span>★ LEVEL UP! LEVEL {levelUpNotice} ★</span>
        </div>
      )}

      {/* Modals */}
      {showStats && (
        <StatsModal
          stats={stats}
          onClose={() => setShowStats(false)}
          onAllocate={(k, pts) => engineRef.current?.allocateStat(k, pts)}
        />
      )}

      {showFruitDealer && (
        <FruitDealerModal
          stats={stats}
          onClose={() => setShowFruitDealer(false)}
          onSpin={() => engineRef.current?.spinFruit() || null}
          onEatDirectly={(fruit) => engineRef.current?.eatFruit(fruit)}
        />
      )}

      {showInventory && (
        <InventoryModal
          stats={stats}
          onClose={() => setShowInventory(false)}
          onEatFruit={(fruit) => engineRef.current?.eatFruit(fruit)}
          onEquipWeapon={(weapon) => engineRef.current?.equipWeapon(weapon)}
          onBuyWeapon={(wKey) => {
            const w = WEAPONS[wKey];
            if (stats.beli >= w.price) {
              stats.beli -= w.price;
              stats.inventory.push({
                id: Math.random().toString(),
                type: 'weapon',
                itemKey: wKey,
                name: w.name,
              });
              engineRef.current?.equipWeapon(wKey);
            }
          }}
        />
      )}

      {showQuests && (
        <QuestModal
          stats={stats}
          activeQuest={activeQuest}
          onClose={() => setShowQuests(false)}
          onAcceptQuest={(q) => {
            engineRef.current?.handleQuestInteraction(q);
            setShowQuests(false);
          }}
        />
      )}

      {showHelp && <ControlsHelpModal onClose={() => setShowHelp(false)} />}
    </div>
  );
}
