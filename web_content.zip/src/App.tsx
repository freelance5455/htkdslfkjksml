import React, { useState, useEffect } from 'react';
import { StudentProfile, ActiveTab, SavedHistoryItem } from './types';
import { OnboardingModal } from './components/OnboardingModal';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { SnapAndSolve } from './components/SnapAndSolve';
import { ParagraphWriter } from './components/ParagraphWriter';
import { EssayWriter } from './components/EssayWriter';
import { GrammarChecker } from './components/GrammarChecker';
import { NotebookHistory } from './components/NotebookHistory';
import { StudyTimerModal } from './components/StudyTimerModal';

const PROFILE_STORAGE_KEY = 'studysnap_student_profile';
const HISTORY_STORAGE_KEY = 'studysnap_notebook_history';

export default function App() {
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isTimerModalOpen, setIsTimerModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [grammarInitialText, setGrammarInitialText] = useState<string>('');
  const [history, setHistory] = useState<SavedHistoryItem[]>([]);

  // Load profile and history from localStorage on initial render
  useEffect(() => {
    try {
      const savedProfile = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (savedProfile) {
        const parsed: StudentProfile = JSON.parse(savedProfile);

        // Check and update study streak based on date
        const today = new Date().toISOString().split('T')[0];
        if (parsed.lastStudyDate && parsed.lastStudyDate !== today) {
          const lastDate = new Date(parsed.lastStudyDate);
          const currentDate = new Date(today);
          const diffDays = Math.round(
            (currentDate.getTime() - lastDate.getTime()) / (1000 * 3600 * 24)
          );

          if (diffDays === 1) {
            parsed.studyStreakDays = (parsed.studyStreakDays || 1) + 1;
          } else if (diffDays > 1) {
            parsed.studyStreakDays = 1;
          }
          parsed.lastStudyDate = today;
          localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(parsed));
        }

        setProfile(parsed);
      } else {
        // Open onboarding modal for new student
        setIsProfileModalOpen(true);
      }

      const savedHistory = localStorage.getItem(HISTORY_STORAGE_KEY);
      if (savedHistory) {
        setHistory(JSON.parse(savedHistory));
      }
    } catch (err) {
      console.warn('Error reading from localStorage:', err);
    }
  }, []);

  const handleSaveProfile = (newProfile: StudentProfile) => {
    setProfile(newProfile);
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(newProfile));
    setIsProfileModalOpen(false);
  };

  const handleUpdateStats = (key: keyof StudentProfile) => {
    if (!profile) return;
    const currentVal = (profile[key] as number) || 0;
    const updated = {
      ...profile,
      [key]: currentVal + 1,
      lastStudyDate: new Date().toISOString().split('T')[0],
    };
    setProfile(updated);
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(updated));
  };

  const handleSaveHistory = (item: Omit<SavedHistoryItem, 'id' | 'timestamp'>) => {
    const newItem: SavedHistoryItem = {
      ...item,
      id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
    };
    const updated = [newItem, ...history];
    setHistory(updated);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
  };

  const handleDeleteHistoryItem = (id: string) => {
    const updated = history.filter((item) => item.id !== id);
    setHistory(updated);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem(HISTORY_STORAGE_KEY);
  };

  const handleSendToGrammar = (text: string) => {
    setGrammarInitialText(text);
    setActiveTab('grammar');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-blue-200">
      {/* Onboarding / Profile Edit Modal */}
      <OnboardingModal
        isOpen={isProfileModalOpen}
        onSaveProfile={handleSaveProfile}
        existingProfile={profile}
        onClose={profile ? () => setIsProfileModalOpen(false) : undefined}
      />

      {/* Focus Timer Modal */}
      <StudyTimerModal
        isOpen={isTimerModalOpen}
        onClose={() => setIsTimerModalOpen(false)}
      />

      {/* Main Navbar */}
      {profile && (
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          profile={profile}
          onOpenProfile={() => setIsProfileModalOpen(true)}
          onOpenTimer={() => setIsTimerModalOpen(true)}
        />
      )}

      {/* Main App Content View */}
      <main className="flex-1 pb-16">
        {!profile ? (
          <div className="max-w-md mx-auto mt-24 text-center p-6 space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto animate-bounce">
              🎓
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              Setting up your Study Space...
            </h2>
            <p className="text-sm text-slate-500">
              Please enter your name, grade, and school to unlock personalized homework and writing tools.
            </p>
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-xl shadow-md hover:bg-blue-700 transition"
            >
              Get Started
            </button>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <Dashboard
                profile={profile}
                setActiveTab={setActiveTab}
                recentHistory={history}
                onOpenProfile={() => setIsProfileModalOpen(true)}
                onOpenTimer={() => setIsTimerModalOpen(true)}
              />
            )}

            {activeTab === 'snap-solve' && (
              <SnapAndSolve
                profile={profile}
                onSaveHistory={handleSaveHistory}
                onUpdateStats={handleUpdateStats}
              />
            )}

            {activeTab === 'paragraph' && (
              <ParagraphWriter
                profile={profile}
                onSaveHistory={handleSaveHistory}
                onUpdateStats={handleUpdateStats}
                setActiveTab={setActiveTab}
                onSendToGrammar={handleSendToGrammar}
              />
            )}

            {activeTab === 'essay' && (
              <EssayWriter
                profile={profile}
                onSaveHistory={handleSaveHistory}
                onUpdateStats={handleUpdateStats}
                setActiveTab={setActiveTab}
                onSendToGrammar={handleSendToGrammar}
              />
            )}

            {activeTab === 'grammar' && (
              <GrammarChecker
                profile={profile}
                initialText={grammarInitialText}
                onSaveHistory={handleSaveHistory}
                onUpdateStats={handleUpdateStats}
              />
            )}

            {activeTab === 'history' && (
              <NotebookHistory
                history={history}
                onClearHistory={handleClearHistory}
                onDeleteItem={handleDeleteHistoryItem}
                setActiveTab={setActiveTab}
                onSendToGrammar={handleSendToGrammar}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white/50 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            StudySnap AI • Designed for student privacy: no passwords, no email storage.
          </p>
          {profile && (
            <p className="font-medium text-slate-600">
              Grade: <span className="text-blue-600 font-bold">{profile.grade}</span> • School: {profile.schoolName}
            </p>
          )}
        </div>
      </footer>
    </div>
  );
}
