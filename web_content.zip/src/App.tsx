import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/chat/Sidebar';
import { ChatInterface } from './components/chat/ChatInterface';
import { ScreenLockModal } from './components/chat/ScreenLockModal';
import { PermissionManagerModal } from './components/chat/PermissionManagerModal';
import { LiveVoiceModal } from './components/chat/LiveVoiceModal';
import { ProductInputSection } from './components/ProductInputSection';
import { BannerStudio } from './components/BannerStudio';
import { ChatMessage, ActionPayload, UserPermissions, ActiveTask } from './types/chat';
import { AdCreativeData, ImageModel, ImageSize, AspectRatio } from './types';
import { PRODUCT_PRESETS } from './data/presets';
import { AlertTriangle, Sparkles, Layers, ChevronRight, Zap, X } from 'lucide-react';

const INITIAL_PRESET = PRODUCT_PRESETS[0];

const INITIAL_CREATIVE: AdCreativeData = {
  brandName: INITIAL_PRESET.brand,
  category: 'Skincare & Beauty',
  primaryHeadline: '72-Hour Cellular Hydration',
  subheadline: 'Cold-pressed Bakuchiol & Rosehip botanical elixir for radiant skin.',
  offerBadge: 'NEW FORMULA • 20% OFF',
  ctaText: 'Shop Serum Now',
  secondaryCtaText: 'Learn More',
  primaryColor: INITIAL_PRESET.primaryColor,
  secondaryColor: '#FDE68A',
  backgroundColor: '#0F172A',
  textColor: '#FFFFFF',
  imagePrompt:
    'A luxury glass cosmetic serum bottle with gold dropper, surrounded by soft organic botanicals and water ripples, clean studio lighting, high-end commercial product photography',
  imageUrl: INITIAL_PRESET.sampleImage,
  productUrl: INITIAL_PRESET.url,
  productDescription: INITIAL_PRESET.description,
  copyVariations: {
    square: {
      headline: '72-Hour Cellular Hydration',
      subhead: 'Cold-pressed Bakuchiol & Rosehip botanical elixir.',
      cta: 'Shop Now',
    },
    leaderboard: {
      headline: 'Lumina Botanical Glow Serum — 20% Off',
      subhead: 'Pure cold-pressed botanical facial oil for lasting radiance.',
      cta: 'Claim 20% Off',
    },
    skyscraper: {
      headline: 'Unlock Radiant Natural Skin',
      subhead: '72-hour deep cellular hydration with 100% vegan organic Bakuchiol & Rosehip.',
      cta: 'Shop Serum',
    },
    story: {
      headline: 'Wake Up to Luminous Skin',
      subhead: 'Clinically proven botanical formula for deep hydration and natural glow.',
      cta: 'Explore Collection',
    },
    socialLandscape: {
      headline: 'The Secret to All-Day Dewy Glow',
      subhead: 'Award-winning cold-pressed facial oil trusted by over 50,000 radiant skin lovers.',
      cta: 'Order Today',
    },
  },
};

const DEFAULT_PERMISSIONS: UserPermissions = {
  whatsapp: true,
  youtube: true,
  deviceControl: true,
  microphone: true,
  geminiAi: true,
  haptics: true,
  alwaysAskBeforeAction: false, // Autonomous by default as requested
};

export default function App() {
  const [activeView, setActiveView] = useState<'chat' | 'banners'>('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isScreenLocked, setIsScreenLocked] = useState(false);
  const [isPermissionsOpen, setIsPermissionsOpen] = useState(false);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);
  const [isTorchActive, setIsTorchActive] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);

  // Active Multi-Turn Task Tracker (e.g. WhatsApp multi-step dialogue)
  const [activeTask, setActiveTask] = useState<ActiveTask | null>(null);

  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Active Timer Reference
  const activeTimerRef = useRef<any>(null);

  // Permissions State
  const [permissions, setPermissions] = useState<UserPermissions>(() => {
    try {
      const saved = localStorage.getItem('ai_user_permissions');
      return saved ? JSON.parse(saved) : DEFAULT_PERMISSIONS;
    } catch {
      return DEFAULT_PERMISSIONS;
    }
  });

  const handleUpdatePermissions = (newPerms: UserPermissions) => {
    setPermissions(newPerms);
    try {
      localStorage.setItem('ai_user_permissions', JSON.stringify(newPerms));
    } catch {}
  };

  // Banner Studio State
  const [creative, setCreative] = useState<AdCreativeData>(INITIAL_CREATIVE);
  const [isBannerLoading, setIsBannerLoading] = useState(false);
  const [bannerLoadingStep, setBannerLoadingStep] = useState('');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [quotaNotice, setQuotaNotice] = useState<string | null>(null);

  // Speak helper
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      window.speechSynthesis.speak(utterance);
    } catch {}
  };

  // Start Real Countdown Timer
  const handleStartTimer = (seconds: number, label: string) => {
    if (activeTimerRef.current) {
      clearTimeout(activeTimerRef.current);
    }

    activeTimerRef.current = setTimeout(() => {
      // Chime or alert
      if ('speechSynthesis' in window) {
        speakText(`Timer complete: ${label}`);
      }
      alert(`⏰ Timer Finished! ${label} has ended.`);
    }, seconds * 1000);
  };

  // Check Real Battery Telemetry
  const handleCheckBattery = async () => {
    if ('getBattery' in navigator) {
      try {
        const battery: any = await (navigator as any).getBattery();
        const level = Math.round(battery.level * 100);
        const charging = battery.charging ? 'Charging' : 'Discharging on Battery';
        const batteryMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          role: 'assistant',
          content: `🔋 Battery Status: Your device is at ${level}% (${charging}). Power telemetry is nominal.`,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, batteryMsg]);
        if (autoSpeak) speakText(`Your battery is at ${level} percent, ${charging}.`);
        return;
      } catch {}
    }

    const fallbackMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'assistant',
      content: `🔋 Device Telemetry: Online status is Active (${navigator.onLine ? 'Connected' : 'Offline'}). Battery API not exposed by this browser platform.`,
      timestamp: Date.now(),
    };
    setMessages((prev) => [...prev, fallbackMsg]);
  };

  // Execute Autonomous Action
  const executeAutonomousAction = (action: ActionPayload) => {
    try {
      if (action.type === 'whatsapp') {
        // Open WhatsApp web or app link directly
        const targetUrl = action.url || 'https://web.whatsapp.com';
        window.open(targetUrl, '_blank', 'noopener,noreferrer');
      } else if (action.type === 'youtube') {
        const targetUrl = action.url || 'https://www.youtube.com';
        window.open(targetUrl, '_blank', 'noopener,noreferrer');
      } else if (action.type === 'device_lock') {
        setIsScreenLocked(true);
      } else if (action.type === 'phone_call' && action.url) {
        window.location.href = action.url;
      } else if (action.type === 'google_search' && action.url) {
        window.open(action.url, '_blank', 'noopener,noreferrer');
      } else if (action.type === 'start_timer' && action.params?.seconds) {
        handleStartTimer(action.params.seconds, action.params.label || 'Timer');
      } else if (action.type === 'battery_status') {
        handleCheckBattery();
      } else if (action.type === 'flashlight') {
        setIsTorchActive(true);
      } else if (action.type === 'generate_image' && action.params?.prompt) {
        handleGenerateImageFromChat(action.params.prompt);
      }
    } catch (e) {
      console.warn('Action execution note:', e);
    }
  };

  // Send Message in AI Assistant Interface
  const handleSendMessage = async (text: string): Promise<string | undefined> => {
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsChatLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.role,
            content: m.content,
          })),
          activeTask,
          autoExecute: true,
        }),
      });

      const data = await response.json().catch(() => ({}));
      const assistantText = data.reply || 'I am processing your command right now.';

      // Update active task if state transitioned
      if (data.nextTask !== undefined) {
        setActiveTask(data.nextTask);
      }

      // Automatically execute autonomous action if present
      if (data.action) {
        executeAutonomousAction(data.action);
      }

      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: assistantText,
        timestamp: Date.now(),
        thinking: data.thinking || undefined,
        action: data.action || undefined,
        actionStatus: data.action ? 'executed' : undefined,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // If Auto-Speak is enabled, vocalize response
      if (autoSpeak) {
        speakText(assistantText);
      }

      // If user prompt asks to switch to banner studio
      if (text.toLowerCase().includes('banner') || text.toLowerCase().includes('ad generator')) {
        setTimeout(() => setActiveView('banners'), 1000);
      }

      return assistantText;
    } catch (err) {
      console.error('Chat error:', err);
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content:
          'I am ready to help. You can command me to open WhatsApp, search YouTube, lock the screen, dial calls, or set timers.',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
      return assistantMsg.content;
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleExecuteAction = (action: ActionPayload) => {
    executeAutonomousAction(action);
    setMessages((prev) =>
      prev.map((m) =>
        m.action?.type === action.type ? { ...m, actionStatus: 'executed' } : m
      )
    );
  };

  const handleDenyAction = (action: ActionPayload) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.action?.type === action.type ? { ...m, actionStatus: 'denied' } : m
      )
    );
  };

  const handleNewChat = () => {
    setMessages([]);
    setActiveTask(null);
    setActiveView('chat');
    setIsSidebarOpen(false);
  };

  const handleQuickAction = (promptText: string) => {
    setActiveView('chat');
    setIsSidebarOpen(false);
    handleSendMessage(promptText);
  };

  // Generate Image from Chat
  const handleGenerateImageFromChat = async (prompt: string) => {
    try {
      const imgRes = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          model: 'gemini-3-pro-image-preview',
          imageSize: '2K',
          aspectRatio: '1:1',
        }),
      });

      const imgData = await imgRes.json().catch(() => ({}));
      if (imgData.imageUrl) {
        setCreative((prev) => ({
          ...prev,
          imageUrl: imgData.imageUrl,
          imagePrompt: prompt,
        }));

        setMessages((prev) => [
          ...prev,
          {
            id: `msg-${Date.now()}`,
            role: 'assistant',
            content: `Image successfully synthesized! You can preview and export it in the Banner Studio.`,
            timestamp: Date.now(),
          },
        ]);
      }
    } catch {}
  };

  // Banner Generation Flow
  const handleGenerateBanners = async (params: {
    productUrl: string;
    productDescription: string;
    brandName: string;
    targetTone: string;
    model: ImageModel;
    imageSize: ImageSize;
    aspectRatio: AspectRatio;
    sampleFallbackImage?: string;
  }) => {
    try {
      setIsBannerLoading(true);
      setErrorMessage(null);
      setQuotaNotice(null);

      setBannerLoadingStep('Analyzing product value proposition & target audience with Gemini...');
      const analyzeRes = await fetch('/api/analyze-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productUrl: params.productUrl,
          productDescription: params.productDescription,
          brandName: params.brandName,
          targetTone: params.targetTone,
        }),
      });

      const analyzeJson = await analyzeRes.json().catch(() => ({}));
      if (!analyzeRes.ok && !analyzeJson.data) {
        throw new Error(analyzeJson.error || 'Failed to analyze product copy.');
      }

      const data = analyzeJson.data;
      if (analyzeJson.quotaNotice) {
        setQuotaNotice(analyzeJson.quotaNotice);
      }

      setBannerLoadingStep(`Synthesizing studio imagery with ${params.model} (${params.imageSize})...`);
      let generatedImageUrl: string | undefined = undefined;

      try {
        const imgRes = await fetch('/api/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: data.imagePrompt,
            model: params.model,
            imageSize: params.imageSize,
            aspectRatio: params.aspectRatio,
          }),
        });

        const imgData = await imgRes.json().catch(() => ({}));
        if (imgRes.ok && imgData.imageUrl) {
          generatedImageUrl = imgData.imageUrl;
        } else if (imgData.quotaExceeded || !imgRes.ok) {
          setQuotaNotice(
            imgData.error ||
              'Gemini image generation service is currently busy. High-resolution styled photography has been set so you can continue customizing and exporting.'
          );
        }
      } catch {
        console.log('[ImageClient] Using fallback styled photography.');
      }

      if (!generatedImageUrl) {
        generatedImageUrl = params.sampleFallbackImage || creative.imageUrl;
      }

      const newCreative: AdCreativeData = {
        brandName: data.brandName || params.brandName || 'Featured Brand',
        category: data.category || 'Retail & E-Commerce',
        primaryHeadline: data.primaryHeadline,
        subheadline: data.subheadline,
        offerBadge: data.offerBadge,
        ctaText: data.ctaText,
        secondaryCtaText: data.secondaryCtaText,
        primaryColor: data.primaryColor || '#2563EB',
        secondaryColor: data.secondaryColor || '#F59E0B',
        backgroundColor: data.backgroundColor || '#0F172A',
        textColor: data.textColor || '#FFFFFF',
        imagePrompt: data.imagePrompt,
        imageUrl: generatedImageUrl,
        productUrl: params.productUrl,
        productDescription: params.productDescription,
        copyVariations: data.copyVariations,
      };

      setCreative(newCreative);
    } catch (err: any) {
      console.error('Generation failed:', err);
      setErrorMessage(err.message || 'An error occurred while generating banners.');
    } finally {
      setIsBannerLoading(false);
      setBannerLoadingStep('');
    }
  };

  const handleRegenerateImage = async (params: {
    model: ImageModel;
    imageSize: ImageSize;
    aspectRatio: AspectRatio;
    prompt: string;
  }) => {
    try {
      setIsGeneratingImage(true);
      setErrorMessage(null);

      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: params.prompt || creative.imagePrompt,
          model: params.model,
          imageSize: params.imageSize,
          aspectRatio: params.aspectRatio,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.success === false) {
        if (data.quotaExceeded) {
          setQuotaNotice(
            data.error || 'Image service is currently experiencing high demand. Please try again shortly.'
          );
          return;
        }
        throw new Error(data.error || 'Failed to generate image.');
      }

      if (data.imageUrl) {
        setCreative((prev) => ({
          ...prev,
          imageUrl: data.imageUrl,
          imagePrompt: params.prompt,
        }));
      }
    } catch (err: any) {
      console.error('Regenerate image failed:', err);
      setErrorMessage(err.message || 'Image generation failed.');
    } finally {
      setIsGeneratingImage(false);
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-white text-gray-900 font-sans selection:bg-gray-200">
      {/* AI Assistant Sidebar */}
      <Sidebar
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
        activeView={activeView}
        onChangeView={setActiveView}
        onNewChat={handleNewChat}
        onOpenPermissions={() => setIsPermissionsOpen(true)}
        onQuickAction={handleQuickAction}
        onLockScreen={() => setIsScreenLocked(true)}
        onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {activeView === 'chat' ? (
          /* Clean ChatGPT/Grok Interface (Light Theme) */
          <ChatInterface
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isChatLoading}
            onExecuteAction={handleExecuteAction}
            onDenyAction={handleDenyAction}
            onLockScreen={() => setIsScreenLocked(true)}
            onGenerateImagePrompt={handleGenerateImageFromChat}
            onStartTimer={handleStartTimer}
            onCheckBattery={handleCheckBattery}
            onToggleTorch={() => setIsTorchActive(true)}
            onOpenSidebar={() => setIsSidebarOpen(true)}
            onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
            permissions={permissions}
            activeTask={activeTask}
            autoSpeak={autoSpeak}
            onToggleAutoSpeak={() => setAutoSpeak(!autoSpeak)}
          />
        ) : (
          /* Banner Ad Studio View */
          <div className="flex-1 overflow-y-auto bg-gray-50/50">
            {/* Banner Studio Header Bar */}
            <div className="sticky top-0 z-20 bg-white/90 backdrop-blur-md border-b border-gray-200 px-4 sm:px-8 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsSidebarOpen(true)}
                  className="lg:hidden p-1.5 rounded-lg text-gray-500 hover:bg-gray-100"
                >
                  <Layers className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setActiveView('chat')}
                  className="text-xs font-semibold text-gray-600 hover:text-gray-900 flex items-center gap-1"
                >
                  ← Back to AI Assistant
                </button>
              </div>
              <span className="text-xs font-bold text-gray-900">
                10 Standard Ad Sizes Studio
              </span>
            </div>

            {/* Quota Notice if any */}
            {quotaNotice && (
              <div className="max-w-7xl mx-auto w-full px-4 sm:px-8 pt-4">
                <div className="bg-amber-50 border border-amber-200 text-amber-900 rounded-xl p-3.5 text-xs flex items-center justify-between gap-3 shadow-2xs">
                  <div className="flex items-center gap-2.5">
                    <Sparkles className="w-4 h-4 text-amber-600 flex-shrink-0" />
                    <span>{quotaNotice}</span>
                  </div>
                  <button
                    onClick={() => setQuotaNotice(null)}
                    className="text-amber-700 hover:text-amber-950 font-bold text-sm px-2"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}

            {/* Error Alert if any */}
            {errorMessage && (
              <div className="max-w-7xl mx-auto w-full px-4 sm:px-8 pt-4">
                <div className="bg-rose-50 border border-rose-200 text-rose-900 rounded-xl p-3.5 text-xs flex items-center justify-between gap-3 shadow-2xs">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                  <button
                    onClick={() => setErrorMessage(null)}
                    className="text-rose-700 hover:text-rose-950 font-bold text-sm px-2"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}

            <main className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-6 space-y-8">
              <ProductInputSection
                onGenerate={handleGenerateBanners}
                isLoading={isBannerLoading}
                loadingStep={bannerLoadingStep}
              />

              <BannerStudio
                creative={creative}
                onUpdateCreative={setCreative}
                onRegenerateImage={handleRegenerateImage}
                isGeneratingImage={isGeneratingImage}
              />
            </main>
          </div>
        )}
      </div>

      {/* Screen Lock Overlay Modal */}
      <ScreenLockModal
        isOpen={isScreenLocked}
        onClose={() => setIsScreenLocked(false)}
      />

      {/* Permissions & Security Manager Modal */}
      <PermissionManagerModal
        isOpen={isPermissionsOpen}
        onClose={() => setIsPermissionsOpen(false)}
        permissions={permissions}
        onUpdatePermissions={handleUpdatePermissions}
      />

      {/* Live Hands-Free Voice Mode Modal */}
      <LiveVoiceModal
        isOpen={isLiveVoiceOpen}
        onClose={() => setIsLiveVoiceOpen(false)}
        onVoiceMessage={handleSendMessage}
        activeTaskDesc={
          activeTask
            ? activeTask.step === 'awaiting_contact'
              ? 'Awaiting contact name or phone number'
              : 'Awaiting message to send'
            : undefined
        }
      />

      {/* Full-Screen Flashlight / Torch Mode */}
      {isTorchActive && (
        <div
          id="screen-torch-overlay"
          className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-between p-8 animate-in fade-in"
          onClick={() => setIsTorchActive(false)}
        >
          <div className="text-gray-400 text-xs font-medium flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-500" />
            <span>Screen Torch Mode Active (Max Luminescence)</span>
          </div>

          <div className="text-center space-y-2">
            <h3 className="text-2xl font-bold text-gray-900">Flashlight On</h3>
            <p className="text-sm text-gray-500">Tap anywhere on the screen to turn off</p>
          </div>

          <button
            onClick={() => setIsTorchActive(false)}
            className="px-6 py-3 rounded-2xl bg-gray-900 text-white font-semibold text-xs flex items-center gap-2 shadow-xl"
          >
            <X className="w-4 h-4" /> Turn Off Flashlight
          </button>
        </div>
      )}
    </div>
  );
}
