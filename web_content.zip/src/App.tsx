/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  MessageSquare,
  Sparkles,
  History,
  Smartphone,
  Gauge,
  AlertCircle,
  Clock,
} from 'lucide-react';

import { ConnectionStatus, AssistantState, ChatMessage, VoiceGender, VoiceOption, QuotaDetails } from './types';
import { LiveAudioPlayer, LiveAudioRecorder } from './utils/audio';
import { VoiceOrb } from './components/VoiceOrb';
import { CallControls } from './components/CallControls';
import { CharacterSelector } from './components/CharacterSelector';
import { TextChatFallback } from './components/TextChatFallback';
import { AndroidGuideModal } from './components/AndroidGuideModal';
import { QuotaInfoModal } from './components/QuotaInfoModal';
import { ConversationHistoryModal } from './components/ConversationHistoryModal';
import { MicPermissionHelper } from './components/MicPermissionHelper';

export default function App() {
  // Voice Character & Call State
  const [characterGender, setCharacterGender] = useState<VoiceGender>('female');
  const [voiceName, setVoiceName] = useState<VoiceOption>('Kore');
  const [isCallActive, setIsCallActive] = useState<boolean>(false);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [assistantState, setAssistantState] = useState<AssistantState>('idle');
  const [isMicMuted, setIsMicMuted] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'call' | 'chat'>('call');

  // Audio Levels
  const [micVolume, setMicVolume] = useState<number>(0);
  const [speakerVolume, setSpeakerVolume] = useState<number>(0);

  // Live Transcriptions & Messages
  const [liveTranscriptionText, setLiveTranscriptionText] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('blame_chat_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals & Errors
  const [isAndroidGuideOpen, setIsAndroidGuideOpen] = useState<boolean>(false);
  const [isQuotaModalOpen, setIsQuotaModalOpen] = useState<boolean>(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState<boolean>(false);
  const [micError, setMicError] = useState<'denied' | 'notfound' | 'error' | null>(null);
  const [globalError, setGlobalError] = useState<string | null>(null);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [quotaDetails, setQuotaDetails] = useState<QuotaDetails | undefined>();

  // References
  const wsRef = useRef<WebSocket | null>(null);
  const playerRef = useRef<LiveAudioPlayer | null>(null);
  const recorderRef = useRef<LiveAudioRecorder | null>(null);
  const rafRef = useRef<number | null>(null);
  const callTimerRef = useRef<any>(null);
  const currentModelReplyRef = useRef<string>('');

  // Persist messages
  useEffect(() => {
    try {
      localStorage.setItem('blame_chat_history', JSON.stringify(messages.slice(-50)));
    } catch (e) {
      // ignore
    }
  }, [messages]);

  // Call duration counter
  useEffect(() => {
    if (isCallActive) {
      callTimerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(callTimerRef.current);
      setCallDuration(0);
    }
    return () => clearInterval(callTimerRef.current);
  }, [isCallActive]);

  const formatCallTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Fetch health check & quotas on mount
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data.quotaInfo) {
          setQuotaDetails(data.quotaInfo);
        }
      })
      .catch((err) => console.warn('Health check warning:', err));
  }, []);

  // Initialize Audio Player
  useEffect(() => {
    const player = new LiveAudioPlayer((isPlaying) => {
      setAssistantState((prev) => {
        if (isPlaying) return 'speaking';
        return prev === 'speaking' ? 'listening' : prev;
      });
    });
    playerRef.current = player;

    return () => {
      player.close();
    };
  }, []);

  // Update volume meters on animation frame
  const updateVolumes = useCallback(() => {
    if (recorderRef.current && isCallActive && !isMicMuted) {
      const vol = recorderRef.current.getVolumeLevel();
      setMicVolume(vol);
    } else {
      setMicVolume(0);
    }

    if (playerRef.current && isCallActive) {
      const vol = playerRef.current.getVolumeLevel();
      setSpeakerVolume(vol);
    } else {
      setSpeakerVolume(0);
    }

    rafRef.current = requestAnimationFrame(updateVolumes);
  }, [isCallActive, isMicMuted]);

  useEffect(() => {
    rafRef.current = requestAnimationFrame(updateVolumes);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [updateVolumes]);

  // Connect to Gemini Live WebSocket
  const connectWebSocket = useCallback((voiceToUse: VoiceOption, genderToUse: VoiceGender) => {
    if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }

    setConnectionStatus('connecting');
    setGlobalError(null);

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/live-ws?voice=${voiceToUse}&gender=${genderToUse}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log('[App] WebSocket connected to server');
      setConnectionStatus('connected');
      setAssistantState('listening');
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === 'ready') {
          console.log('[App] Gemini Live Session is ready:', data);
        } else if (data.type === 'audio' && data.audio) {
          // Play incoming 24kHz model audio
          playerRef.current?.playChunk(data.audio);
          setAssistantState('speaking');
        } else if (data.type === 'transcript_model' && data.text) {
          currentModelReplyRef.current += data.text;
          setLiveTranscriptionText(currentModelReplyRef.current);
        } else if (data.type === 'interrupted') {
          // Immediate barge-in
          playerRef.current?.interrupt();
          setAssistantState('interrupted');
          setTimeout(() => setAssistantState('listening'), 700);
        } else if (data.type === 'turn_complete') {
          // Save model response to messages history
          if (currentModelReplyRef.current.trim()) {
            const reply = currentModelReplyRef.current.trim();
            setMessages((prev) => [
              ...prev,
              {
                id: `model-${Date.now()}`,
                role: 'model',
                text: reply,
                timestamp: Date.now(),
              },
            ]);
            currentModelReplyRef.current = '';
          }
          setAssistantState('listening');
        } else if (data.type === 'error') {
          console.error('[App] Live server error:', data.error);
          setGlobalError(data.error);
          if (data.isQuota) {
            setIsQuotaModalOpen(true);
          }
        }
      } catch (e) {
        console.error('[App] Error parsing WebSocket message:', e);
      }
    };

    ws.onclose = () => {
      setConnectionStatus('disconnected');
      setAssistantState('idle');
      playerRef.current?.interrupt();
    };

    ws.onerror = (err) => {
      console.error('[App] WebSocket error:', err);
      setConnectionStatus('error');
      setGlobalError('Connection to Gemini Live server lost.');
    };
  }, []);

  // Disconnect WebSocket
  const disconnectWebSocket = useCallback(() => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setConnectionStatus('disconnected');
    setAssistantState('idle');
    playerRef.current?.interrupt();
  }, []);

  // Start microphone recorder
  const startRecording = useCallback(async () => {
    if (recorderRef.current && recorderRef.current.isActive()) return;

    try {
      setMicError(null);
      const recorder = new LiveAudioRecorder((base64Pcm) => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && !isMicMuted) {
          wsRef.current.send(
            JSON.stringify({
              type: 'audio',
              data: base64Pcm,
            })
          );
        }
      });

      await recorder.start();
      recorderRef.current = recorder;
    } catch (err: any) {
      console.error('[App] Microphone error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setMicError('denied');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setMicError('notfound');
      } else {
        setMicError('error');
      }
    }
  }, [isMicMuted]);

  // Stop recording
  const stopRecording = useCallback(() => {
    if (recorderRef.current) {
      recorderRef.current.stop();
      recorderRef.current = null;
    }
    setMicVolume(0);
  }, []);

  // Speech Recognition reference for voice calls
  const speechRecognitionRef = useRef<any>(null);

  // Start Call Handler
  const handleStartCall = async () => {
    setIsCallActive(true);
    setLiveTranscriptionText('');

    // CRITICAL: Unlock audio output pipeline on user click gesture so audio is never muted by browser
    await playerRef.current?.initAndUnlock();

    connectWebSocket(voiceName, characterGender);
    await startRecording();

    // Start Web Speech Recognition if available for real-time speech-to-text during call
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US'; // Also understands Urdu/Hindi phonetically

        recognition.onresult = (event: any) => {
          let interimText = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              const cleanText = transcript.trim();
              if (cleanText) {
                setLiveTranscriptionText(cleanText);
                handleSendChatMessage(cleanText);
              }
            } else {
              interimText += transcript;
            }
          }
          if (interimText) {
            setLiveTranscriptionText(interimText);
          }
        };

        recognition.onerror = (e: any) => {
          console.warn('[SpeechRecognition] notice:', e.error);
        };

        recognition.onend = () => {
          // Restart recognition if call is still active
          if (isCallActive) {
            try {
              recognition.start();
            } catch (err) {
              // ignore
            }
          }
        };

        recognition.start();
        speechRecognitionRef.current = recognition;
      } catch (err) {
        console.warn('SpeechRecognition setup notice:', err);
      }
    }
  };

  // End / Cut Call Handler
  const handleEndCall = () => {
    setIsCallActive(false);
    stopRecording();
    disconnectWebSocket();
    setLiveTranscriptionText('');
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
      speechRecognitionRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  // Toggle Mute Handler
  const handleToggleMute = () => {
    const nextMuted = !isMicMuted;
    setIsMicMuted(nextMuted);
    playerRef.current?.setMuted(nextMuted);
    if ('speechSynthesis' in window && nextMuted) {
      window.speechSynthesis.cancel();
    }
  };

  // Interrupt Handler (Barge-in)
  const handleInterrupt = () => {
    playerRef.current?.interrupt();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'interrupt' }));
    }
    setAssistantState('interrupted');
    setTimeout(() => setAssistantState('listening'), 600);
  };

  // Change Character Gender (Female vs Male)
  const handleSelectGender = (gender: VoiceGender) => {
    setCharacterGender(gender);
    const newVoice = gender === 'female' ? 'Kore' : 'Puck';
    setVoiceName(newVoice);

    if (isCallActive) {
      disconnectWebSocket();
      setTimeout(() => {
        connectWebSocket(newVoice, gender);
      }, 300);
    }
  };

  // Send message in text fallback mode with Google Search Grounding
  const handleSendChatMessage = async (text: string) => {
    setIsChatLoading(true);
    setGlobalError(null);
    setAssistantState('thinking');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setLiveTranscriptionText(text);

    // If call is active, also forward text to live session
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text }));
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          gender: characterGender,
          history: messages.slice(-4),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to get answer from Gemini');
      }

      const modelReply = data.reply || '';
      const modelMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: modelReply,
        timestamp: Date.now(),
        sources: data.sources || [],
      };

      setMessages((prev) => [...prev, modelMsg]);
      setLiveTranscriptionText(modelReply);

      // In call mode, speak reply aloud so user always hears Blame!
      if (isCallActive || activeTab === 'call') {
        playTtsAudio(modelReply, modelMsg.id);
      } else {
        setAssistantState('idle');
      }
    } catch (err: any) {
      console.error('[App] Chat error:', err);
      setGlobalError(err.message || 'Error occurred');
      setAssistantState('idle');
      if (err.message?.includes('quota') || err.message?.includes('429')) {
        setIsQuotaModalOpen(true);
      }
    } finally {
      setIsChatLoading(false);
    }
  };

  // Play audio for any message using official Gemini TTS with Web Speech API fallback
  const playTtsAudio = async (text: string, messageId: string) => {
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, isPlaying: true } : m))
    );
    setAssistantState('speaking');

    let audioPlayed = false;

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voiceName }),
      });

      const data = await res.json();
      if (res.ok && data.audio) {
        const audio = new Audio(`data:audio/wav;base64,${data.audio}`);
        audio.onended = () => {
          setMessages((prev) =>
            prev.map((m) => (m.id === messageId ? { ...m, isPlaying: false } : m))
          );
          setAssistantState(isCallActive ? 'listening' : 'idle');
        };
        audio.onerror = () => {
          fallbackBrowserSpeech(text, messageId);
        };
        await audio.play();
        audioPlayed = true;
        return;
      }
    } catch (err) {
      console.warn('[App] Server TTS fallback to Web Speech:', err);
    }

    if (!audioPlayed) {
      fallbackBrowserSpeech(text, messageId);
    }
  };

  // Browser Web Speech API fallback ensuring voice ALWAYS works
  const fallbackBrowserSpeech = (text: string, messageId: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = characterGender === 'female' ? 1.15 : 0.95;
      utterance.onend = () => {
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, isPlaying: false } : m))
        );
        setAssistantState(isCallActive ? 'listening' : 'idle');
      };
      utterance.onerror = () => {
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, isPlaying: false } : m))
        );
        setAssistantState(isCallActive ? 'listening' : 'idle');
      };
      window.speechSynthesis.speak(utterance);
    } else {
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, isPlaying: false } : m))
      );
      setAssistantState(isCallActive ? 'listening' : 'idle');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/80 flex flex-col justify-between max-w-md mx-auto relative shadow-2xl border-x border-slate-100 sm:rounded-3xl sm:my-3 sm:min-h-[94vh] overflow-hidden">
      {/* Top Header (100% English) */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 p-0.5 shadow-xs flex items-center justify-center">
              <span className="text-white font-black text-sm tracking-tighter">BL</span>
            </div>
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white ${
                isCallActive
                  ? 'bg-emerald-500 animate-pulse'
                  : 'bg-slate-300'
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-extrabold text-slate-800 tracking-tight">Blame</h1>
              <span className="text-[10px] font-bold uppercase px-1.5 py-0.2 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                AI Voice
              </span>
            </div>
            {isCallActive ? (
              <div className="flex items-center gap-1 text-[11px] text-emerald-600 font-semibold">
                <Clock className="w-3 h-3" />
                <span>Call Active • {formatCallTime(callDuration)}</span>
              </div>
            ) : (
              <p className="text-[10px] text-slate-400 font-medium">Ready for real-time conversation</p>
            )}
          </div>
        </div>

        {/* Top Actions */}
        <div className="flex items-center gap-1.5">
          {/* Android Guide Button */}
          <button
            onClick={() => setIsAndroidGuideOpen(true)}
            title="Android APK & Testing Guide"
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 hover:text-emerald-600 transition-colors cursor-pointer"
          >
            <Smartphone className="w-4 h-4" />
          </button>

          {/* History Button */}
          <button
            onClick={() => setIsHistoryModalOpen(true)}
            title="Conversation History"
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 hover:text-emerald-600 transition-colors cursor-pointer"
          >
            <History className="w-4 h-4" />
          </button>

          {/* Quota & Cost Transparency Button */}
          <button
            onClick={() => setIsQuotaModalOpen(true)}
            title="API Limits & Cost Info"
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 hover:text-amber-600 transition-colors cursor-pointer"
          >
            <Gauge className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Viewport Container */}
      <main className="flex-1 flex flex-col justify-between overflow-y-auto bg-white">
        {/* Error Banner */}
        {globalError && (
          <div className="m-3 p-3 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-xs text-red-800 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">{globalError}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <button
                  onClick={() => connectWebSocket(voiceName, characterGender)}
                  className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold cursor-pointer text-[11px]"
                >
                  Retry Connection
                </button>
                <button
                  onClick={() => setActiveTab('chat')}
                  className="px-2.5 py-1 bg-white border border-red-200 text-red-700 hover:bg-red-50 rounded-lg font-semibold cursor-pointer text-[11px]"
                >
                  Switch to Text Mode
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Microphone Permission Helper */}
        {micError && (
          <MicPermissionHelper
            errorType={micError}
            onRetry={() => {
              setMicError(null);
              startRecording();
            }}
            onDismiss={() => setMicError(null)}
          />
        )}

        {/* CALL TAB */}
        {activeTab === 'call' && (
          <div className="flex-1 flex flex-col justify-between py-2">
            {/* Character Selector (Female 👩 vs Male 👨) */}
            <CharacterSelector
              gender={characterGender}
              onSelectGender={handleSelectGender}
            />

            {/* Central Big Circle Screen */}
            <div className="flex-1 flex flex-col items-center justify-center">
              <VoiceOrb
                state={assistantState}
                micVolume={micVolume}
                speakerVolume={speakerVolume}
                isCallActive={isCallActive}
                onCircleClick={() => {
                  if (assistantState === 'speaking') {
                    handleInterrupt();
                  } else if (!isCallActive) {
                    handleStartCall();
                  }
                }}
                characterGender={characterGender}
                liveTranscriptionText={liveTranscriptionText}
                isMuted={isMicMuted}
              />
            </div>

            {/* Dedicated Call Action Controls (Start Call, End Call, Mute) */}
            <div className="pb-2">
              <CallControls
                isCallActive={isCallActive}
                isMuted={isMicMuted}
                isSpeaking={assistantState === 'speaking'}
                onStartCall={handleStartCall}
                onEndCall={handleEndCall}
                onToggleMute={handleToggleMute}
                onInterrupt={handleInterrupt}
              />
            </div>
          </div>
        )}

        {/* CHAT TAB (Simultaneous with Call) */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col">
            <TextChatFallback
              messages={messages}
              onSendMessage={handleSendChatMessage}
              onPlayTts={playTtsAudio}
              isLoading={isChatLoading}
              error={globalError}
              onClearError={() => setGlobalError(null)}
              characterGender={characterGender}
            />
          </div>
        )}
      </main>

      {/* Bottom Switcher Navigation Bar (100% English) */}
      <footer className="sticky bottom-0 z-40 bg-white border-t border-slate-200/90 px-4 py-3 pb-safe">
        <div className="flex items-center justify-between gap-3 max-w-sm mx-auto">
          {/* Call Screen Tab Button */}
          <button
            onClick={() => setActiveTab('call')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'call'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Phone className="w-4 h-4" />
            <span>Call Mode</span>
            {isCallActive && (
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            )}
          </button>

          {/* Chat Screen Tab Button */}
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Chat Mode</span>
            {messages.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-[10px] text-slate-700 font-bold">
                {messages.length}
              </span>
            )}
          </button>
        </div>
      </footer>

      {/* Modals */}
      <AndroidGuideModal
        isOpen={isAndroidGuideOpen}
        onClose={() => setIsAndroidGuideOpen(false)}
      />

      <QuotaInfoModal
        isOpen={isQuotaModalOpen}
        onClose={() => setIsQuotaModalOpen(false)}
        quotaDetails={quotaDetails}
      />

      <ConversationHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        messages={messages}
        onClearHistory={() => setMessages([])}
      />
    </div>
  );
}
