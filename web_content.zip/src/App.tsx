import React, { useState } from 'react';
import { StoreProvider, useStore, AppView } from './context/StoreContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Storefront } from './components/Storefront';
import { CheckoutPage } from './components/CheckoutPage';
import { InventoryManager } from './components/InventoryManager';
import { PlansAndCredits } from './components/PlansAndCredits';
import { OrdersList } from './components/OrdersList';
import { MerchantPayouts } from './components/MerchantPayouts';
import { CartDrawer } from './components/CartDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { AddProductModal } from './components/AddProductModal';
import { LiveNotificationToast } from './components/LiveNotificationToast';
import { Product, Plan } from './types';
import { ShieldCheck, Phone, Mail, MapPin } from 'lucide-react';

const AppContent: React.FC = () => {
  const { 
    currentView, 
    setCurrentView, 
    selectedProduct, 
    setSelectedProduct,
    setCheckoutItem,
    purchasePlan,
    addProduct
  } = useStore();

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);

  const handleOpenAddProduct = () => {
    setProductToEdit(null);
    setIsAddProductOpen(true);
  };

  const handleEditProduct = (p: Product) => {
    setProductToEdit(p);
    setIsAddProductOpen(true);
  };

  const handleSelectPlanForCheckout = (plan: Plan) => {
    // When buying a plan, we can either purchase it directly or launch checkout for that amount
    // Let's create a temporary product item for the checkout flow matching screenshot 4 (Mt 97,00 MZN)
    const planProduct: Product = {
      id: `plan-${plan.id}`,
      name: `Plano ${plan.name} EscaleBuilder (${plan.credits} créditos)`,
      slug: `plano-${plan.id}`,
      description: `Recarga de ${plan.credits} créditos (+${plan.bonusCredits} bónus) para criação de eBooks, capas 3D e anúncios.`,
      price: plan.price,
      category: 'ebooks',
      type: 'digital',
      stock: 9999,
      minStockAlert: 10,
      sku: `PLN-${plan.id.toUpperCase()}`,
      image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
      rating: 5.0,
      ratingCount: 88,
      salesCount: 420,
      features: plan.features
    };
    setCheckoutItem(planProduct);
    setCurrentView('checkout');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-emerald-500 selection:text-white">
      
      {/* Sidebar Navigation Drawer */}
      <Sidebar 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
      />

      {/* Main Top Header */}
      <Header 
        onOpenSidebar={() => setIsSidebarOpen(true)}
        onOpenAddProduct={handleOpenAddProduct}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {currentView === 'store' && (
          <Storefront 
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenAddProduct={handleOpenAddProduct}
          />
        )}

        {currentView === 'checkout' && (
          <CheckoutPage 
            onBack={() => setCurrentView('store')}
            onSuccessOrder={() => {}}
          />
        )}

        {currentView === 'inventory' && (
          <InventoryManager 
            onOpenAddProduct={handleOpenAddProduct}
            onEditProduct={handleEditProduct}
          />
        )}

        {currentView === 'plans' && (
          <PlansAndCredits 
            onSelectPlanForCheckout={handleSelectPlanForCheckout}
          />
        )}

        {currentView === 'orders' && (
          <OrdersList />
        )}

        {currentView === 'payouts' && (
          <MerchantPayouts />
        )}
      </main>

      {/* Modals & Overlays */}
      <CartDrawer />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />

      <AddProductModal
        isOpen={isAddProductOpen}
        onClose={() => setIsAddProductOpen(false)}
        productToEdit={productToEdit}
      />

      {/* Global Live Notification Stack */}
      <LiveNotificationToast />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
            
            {/* Brand column */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-base">
                <div className="w-6 h-6 rounded-md bg-emerald-500 flex items-center justify-center text-slate-950 font-black text-xs">
                  E
                </div>
                <span>EscaleBuilder</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Plataforma moçambicana para venda de infoprodutos e artigos comerciais com gateway de pagamento integrado e gestão de estoque em tempo real.
              </p>
            </div>

            {/* Methods */}
            <div className="space-y-2">
              <h4 className="text-white font-semibold text-xs tracking-wider uppercase">
                Pagamentos Aceitos
              </h4>
              <ul className="space-y-1.5 text-[11px]">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <span>M-Pesa (Vodacom Moçambique)</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                  <span>e-Mola (Movitel)</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  <span>Ponto 24 / BIM / BCI / Standard</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>Cartões Visa & Mastercard</span>
                </li>
              </ul>
            </div>

            {/* Quick Links */}
            <div className="space-y-2">
              <h4 className="text-white font-semibold text-xs tracking-wider uppercase">
                Navegação
              </h4>
              <ul className="space-y-1.5 text-[11px]">
                <li>
                  <button onClick={() => setCurrentView('store')} className="hover:text-white transition-colors">
                    Catálogo de Produtos
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView('inventory')} className="hover:text-white transition-colors">
                    Painel de Estoque ao Vivo
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView('payouts')} className="hover:text-white transition-colors font-semibold text-emerald-400">
                    Como Receber (Carteira & Saques)
                  </button>
                </li>
                <li>
                  <button onClick={() => setCurrentView('orders')} className="hover:text-white transition-colors">
                    Histórico de Vendas
                  </button>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div className="space-y-2">
              <h4 className="text-white font-semibold text-xs tracking-wider uppercase">
                Suporte & Operação
              </h4>
              <div className="space-y-1 text-[11px] leading-relaxed">
                <div>Momade Cássimo Sumaila</div>
                <div className="font-mono text-emerald-400">jucunozawayajacob@gmail.com</div>
                <div className="font-mono">+258 84 16 34 528</div>
                <div className="text-slate-500">Maputo, Moçambique</div>
              </div>
            </div>

          </div>

          <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <div>
              © 2026 EscaleBuilder by EscalePay. Todos os direitos reservados.
            </div>
            <div className="flex items-center gap-4">
              <span>Moeda: Metical Moçambicano (MT / MZN)</span>
              <span>·</span>
              <span>Auditoria de Estoque Ativa</span>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
