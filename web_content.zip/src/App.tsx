import { useCallback, useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Flame,
  Hand,
  Layers,
  Play,
  Rocket,
  Scale,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  ACCESSORIES,
  DISCIPLINES,
  DISCIPLINE_LIST,
} from './data/disciplines';
import {
  AccessoryId,
  DisciplineId,
  FloatingPopup,
  GameMode,
  LiveTelemetry,
  RecordEntry,
} from './types/game';
import { KotostArena3D } from './components/KotostArena3D';
import { RecordCertificateModal } from './components/RecordCertificateModal';
import { RecordBookModal } from './components/RecordBookModal';
import { soundEngine } from './utils/soundEngine';

const STORAGE_KEY = 'kotost_guinness_records_v1';

const DEFAULT_RECORDS: Record<DisciplineId, RecordEntry> = {
  chonk: {
    disciplineId: 'chonk',
    bestScore: 42.5,
    isRecordBroken: false,
    brokenAt: null,
    attempts: 0,
    rankTitle: 'Пушистый Юниор',
  },
  jump: {
    disciplineId: 'jump',
    bestScore: 12.0,
    isRecordBroken: false,
    brokenAt: null,
    attempts: 0,
    rankTitle: 'Прыгун с Дивана',
  },
  stack: {
    disciplineId: 'stack',
    bestScore: 3,
    isRecordBroken: false,
    brokenAt: null,
    attempts: 0,
    rankTitle: 'Хранитель Паштета',
  },
};

export function App() {
  const [mode, setMode] = useState<GameMode>('hub');
  const [selectedDiscipline, setSelectedDiscipline] = useState<DisciplineId>('chonk');
  const [accessory, setAccessory] = useState<AccessoryId>('none');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [showRecordBook, setShowRecordBook] = useState<boolean>(false);

  const [records, setRecords] = useState<Record<DisciplineId, RecordEntry>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_RECORDS, ...JSON.parse(saved) };
      }
    } catch {
      // ignore storage errors
    }
    return DEFAULT_RECORDS;
  });

  const [countdownNum, setCountdownNum] = useState<number>(3);
  const [lastScore, setLastScore] = useState<number>(0);
  const [isNewPersonalBest, setIsNewPersonalBest] = useState<boolean>(false);
  const [popups, setPopups] = useState<FloatingPopup[]>([]);

  const [telemetry, setTelemetry] = useState<LiveTelemetry>({
    currentScore: 18,
    targetScore: 150,
    timeLeft: 15,
    combo: 0,
    phaseText: 'ГОТОВ К МИРОВОМУ РЕКОРДУ!',
    subStatusText: '',
  });

  const externalTriggerRef = useRef<{
    triggerPrimaryAction: () => void;
    setHoldState: (holding: boolean) => void;
    steerHorizontal: (dir: number) => void;
    petKotost: () => void;
  } | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    } catch {
      // ignore
    }
  }, [records]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEngine.enabled = next;
  };

  const handleSpawnPopup = useCallback((popup: Omit<FloatingPopup, 'id'>) => {
    const id = Date.now() + Math.random();
    setPopups((prev) => [...prev.slice(-6), { ...popup, id }]);
    setTimeout(() => {
      setPopups((prev) => prev.filter((p) => p.id !== id));
    }, 850);
  }, []);

  const startDisciplineAttempt = (discId: DisciplineId = selectedDiscipline) => {
    setSelectedDiscipline(discId);
    setCountdownNum(3);
    setMode('countdown');
    soundEngine.playCountdownBeep(false);
  };

  // Countdown 3 -> 2 -> 1 -> Playing!
  useEffect(() => {
    if (mode !== 'countdown') return;

    const timer = setInterval(() => {
      setCountdownNum((prev) => {
        if (prev > 1) {
          soundEngine.playCountdownBeep(false);
          return prev - 1;
        } else {
          clearInterval(timer);
          soundEngine.playCountdownBeep(true);
          setMode('playing');
          return 0;
        }
      });
    }, 680);

    return () => clearInterval(timer);
  }, [mode]);

  const handleFinishDiscipline = useCallback(
    (finalScore: number) => {
      const discConfig = DISCIPLINES[selectedDiscipline];
      const prevRec = records[selectedDiscipline];
      const isBest = finalScore > prevRec.bestScore;
      const isWorldRec = finalScore >= discConfig.targetScore;

      setLastScore(finalScore);
      setIsNewPersonalBest(isBest);

      if (isWorldRec) {
        soundEngine.playRecordFanfare();
      } else {
        soundEngine.playMeow(1.0);
      }

      setRecords((prev) => {
        const cur = prev[selectedDiscipline];
        return {
          ...prev,
          [selectedDiscipline]: {
            ...cur,
            bestScore: Math.max(cur.bestScore, finalScore),
            isRecordBroken: cur.isRecordBroken || isWorldRec,
            brokenAt:
              isWorldRec && !cur.brokenAt
                ? new Date().toLocaleDateString('ru-RU')
                : cur.brokenAt,
            attempts: cur.attempts + 1,
          },
        };
      });

      // Automatically equip Golden Crown the first time a World Record is broken!
      if (isWorldRec && accessory === 'none') {
        setAccessory('crown');
      }

      setMode('result');
    },
    [selectedDiscipline, records, accessory]
  );

  const handleNextDiscipline = () => {
    const order: DisciplineId[] = ['chonk', 'jump', 'stack'];
    const nextIdx = (order.indexOf(selectedDiscipline) + 1) % order.length;
    startDisciplineAttempt(order[nextIdx]);
  };

  const currentDiscConfig = DISCIPLINES[selectedDiscipline];
  const brokenCount = Object.values(records).filter((r) => r.isRecordBroken).length;
  const unlockedMap: Record<DisciplineId, boolean> = {
    chonk: records.chonk.isRecordBroken,
    jump: records.jump.isRecordBroken,
    stack: records.stack.isRecordBroken,
  };

  const renderDisciplineIcon = (iconName: 'scale' | 'rocket' | 'layers', className = 'w-5 h-5') => {
    if (iconName === 'scale') return <Scale className={className} />;
    if (iconName === 'rocket') return <Rocket className={className} />;
    return <Layers className={className} />;
  };

  const progressRatio = Math.min(
    100,
    Math.max(4, Math.round((telemetry.currentScore / currentDiscConfig.targetScore) * 100))
  );
  const isLiveRecordBeaten = telemetry.currentScore >= currentDiscConfig.targetScore;

  return (
    <div className="relative w-screen h-screen overflow-hidden select-none">
      {/* 100vw x 100vh Interactive 3D WebGL Stage */}
      <KotostArena3D
        mode={mode}
        discipline={selectedDiscipline}
        accessory={accessory}
        unlockedRecords={unlockedMap}
        onTelemetryUpdate={setTelemetry}
        onSpawnPopup={handleSpawnPopup}
        onFinishDiscipline={handleFinishDiscipline}
        externalTriggerRef={externalTriggerRef}
      />

      {/* Floating 3D Score & Reaction Popups */}
      <div className="fixed inset-0 pointer-events-none z-20 overflow-hidden">
        {popups.map((p) => (
          <div
            key={p.id}
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
            className="absolute -translate-x-1/2 -translate-y-1/2 animate-float-score text-center"
          >
            <div
              className={`font-display font-black text-xl sm:text-2xl uppercase tracking-wide px-3.5 py-1 rounded-2xl shadow-xl border-2 ${
                p.color === 'emerald'
                  ? 'bg-emerald-500 text-slate-950 border-emerald-200'
                  : p.color === 'crimson'
                  ? 'bg-rose-600 text-white border-rose-300'
                  : 'bg-amber-400 text-slate-950 border-amber-100'
              }`}
            >
              {p.text}
            </div>
            {p.subtext && (
              <div className="mt-1 text-xs font-extrabold text-amber-100 bg-slate-950/85 px-2.5 py-0.5 rounded-full inline-block border border-amber-400/40">
                {p.subtext}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ======================================================== */}
      {/* FLOATING ZONE 1: TOP GUINNESS BROADCAST HEADER BAR       */}
      {/* ======================================================== */}
      <header className="fixed top-0 inset-x-0 z-30 p-3 sm:p-4 pointer-events-none">
        <div className="max-w-7xl mx-auto flex items-start justify-between gap-3">
          {/* Left: Official Brand Crest & Wardrobe Switcher */}
          <div className="pointer-events-auto flex flex-col gap-2">
            <div className="guinness-panel rounded-2xl px-3.5 py-2.5 flex items-center gap-3">
              <div
                onClick={() => externalTriggerRef.current?.petKotost()}
                className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-xl overflow-hidden border-2 border-amber-400 shadow-md shrink-0 cursor-pointer group"
                title="Нажмите, чтобы погладить Котость!"
              >
                <img
                  src="/images/kotost-portrait.jpg"
                  alt="Котость"
                  className="w-full h-full object-cover group-hover:scale-110 transition"
                />
                <span className="absolute bottom-0 inset-x-0 bg-amber-500/90 text-[9px] font-black text-slate-950 text-center uppercase">
                  ШАР 3D
                </span>
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <span className="inline-block w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  <span className="text-[10px] sm:text-xs font-extrabold uppercase tracking-widest text-amber-400">
                    ПРЯМОЙ ЭФИР • GWR-3D
                  </span>
                </div>
                <h1 className="font-display text-base sm:text-xl font-black uppercase tracking-tight text-white leading-none">
                  КОТОСТЬ: РЕКОРДЫ ГИННЕССА
                </h1>
              </div>
            </div>

            {/* Accessory Wardrobe Pills (Visible in Hub Mode) */}
            {mode === 'hub' && (
              <div className="guinness-panel rounded-xl px-2.5 py-1.5 flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-extrabold text-amber-300 uppercase px-1">
                  Стиль:
                </span>
                {ACCESSORIES.map((acc) => (
                  <button
                    key={acc.id}
                    onClick={() => {
                      setAccessory(acc.id);
                      soundEngine.playMeow(1.1);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-extrabold transition flex items-center gap-1 cursor-pointer ${
                      accessory === acc.id
                        ? 'bg-amber-400 text-slate-950 shadow'
                        : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                    }`}
                    title={acc.description}
                  >
                    <span>{acc.emoji}</span>
                    <span className="hidden md:inline">{acc.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Center: Live Telemetry Broadcast Scoreboard during Playing / Countdown */}
          {(mode === 'playing' || mode === 'countdown') && (
            <div className="pointer-events-auto guinness-panel rounded-2xl px-4 py-3 w-full max-w-md border-2 border-amber-400/70">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-xs font-extrabold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  {renderDisciplineIcon(currentDiscConfig.iconName, 'w-4 h-4 text-amber-400')}
                  {currentDiscConfig.title}
                </span>

                {telemetry.timeLeft >= 0 && (
                  <span
                    className={`font-mono-num text-sm sm:text-base font-extrabold px-2.5 py-0.5 rounded-lg border ${
                      telemetry.timeLeft <= 4
                        ? 'bg-rose-600/90 text-white border-rose-300 animate-pulse-fast'
                        : 'bg-slate-900 text-amber-300 border-amber-400/40'
                    }`}
                  >
                    ⏱ {telemetry.timeLeft.toFixed(1)} сек
                  </span>
                )}

                {selectedDiscipline === 'stack' && telemetry.livesLeft !== undefined && (
                  <span className="text-xs font-extrabold px-2.5 py-0.5 rounded-lg bg-slate-900 text-rose-400 border border-rose-500/40">
                    {'❤️'.repeat(Math.max(0, telemetry.livesLeft))}
                  </span>
                )}
              </div>

              {/* Current vs World Record Readout */}
              <div className="flex items-baseline justify-between gap-3 my-1">
                <div>
                  <span className="text-[11px] font-bold uppercase text-slate-300 block">
                    Текущий замер:
                  </span>
                  <span
                    className={`font-mono-num text-2xl sm:text-4xl font-black ${
                      isLiveRecordBeaten ? 'text-emerald-400' : 'text-white'
                    }`}
                  >
                    {telemetry.currentScore}{' '}
                    <span className="text-xs sm:text-sm font-bold text-amber-300">
                      {currentDiscConfig.unit}
                    </span>
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[11px] font-bold uppercase text-amber-300/80 block">
                    Мировой Рекорд:
                  </span>
                  <span className="font-mono-num text-lg sm:text-2xl font-extrabold text-amber-400">
                    {currentDiscConfig.targetScore}{' '}
                    <span className="text-xs font-bold">{currentDiscConfig.unit}</span>
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-amber-400/40 p-0.5">
                <div
                  className={`h-full rounded-full transition-all duration-150 ${
                    isLiveRecordBeaten
                      ? 'bg-gradient-to-r from-emerald-400 via-amber-300 to-emerald-500'
                      : 'bg-gradient-to-r from-amber-500 to-yellow-300'
                  }`}
                  style={{ width: `${progressRatio}%` }}
                />
              </div>

              <div className="mt-1.5 flex items-center justify-between text-[11px] font-extrabold">
                <span className={isLiveRecordBeaten ? 'text-emerald-300' : 'text-amber-200'}>
                  {telemetry.phaseText}
                </span>
                {telemetry.combo > 1 && (
                  <span className="inline-flex items-center gap-0.5 text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full">
                    <Flame className="w-3 h-3 text-amber-400" /> КОМБО x{telemetry.combo}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Right: Record Book Modal Button, Sound Toggle, and Exit Attempt */}
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              onClick={() => setShowRecordBook(true)}
              className="btn-navy-arcade px-3.5 py-2.5 rounded-2xl flex items-center gap-2 font-display font-extrabold text-xs sm:text-sm uppercase tracking-wider cursor-pointer"
              title="Открыть Книгу Рекордов Котости"
            >
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Книга Рекордов</span>
              <span className="font-mono-num px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 text-xs font-black">
                {brokenCount}/3
              </span>
            </button>

            <button
              onClick={toggleSound}
              className="btn-navy-arcade p-2.5 rounded-2xl text-amber-300 cursor-pointer"
              title={soundEnabled ? 'Выключить звук' : 'Включить звук'}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>

            {mode === 'playing' && (
              <button
                onClick={() => setMode('hub')}
                className="btn-navy-arcade px-3 py-2.5 rounded-2xl text-xs font-extrabold uppercase text-rose-300 hover:border-rose-400 cursor-pointer"
                title="Вернуться на подиум"
              >
                Выход
              </button>
            )}
          </div>
        </div>
      </header>

      {/* ======================================================== */}
      {/* COUNTDOWN OVERLAY (3 - 2 - 1 - ТЫГЫДЫК!)                 */}
      {/* ======================================================== */}
      {mode === 'countdown' && (
        <div className="fixed inset-0 z-30 pointer-events-none flex flex-col items-center justify-center bg-slate-950/35 backdrop-blur-[2px]">
          <div className="guinness-panel px-8 py-6 rounded-3xl text-center border-2 border-amber-400 animate-bounce">
            <div className="text-xs font-extrabold uppercase tracking-widest text-amber-300 mb-1">
              Судейская готовность • {currentDiscConfig.title}
            </div>
            <div className="font-display text-6xl sm:text-8xl font-black text-amber-400 drop-shadow-lg">
              {countdownNum}
            </div>
            <div className="mt-2 text-xs sm:text-sm font-bold text-white">
              Цель Гиннесса: {currentDiscConfig.targetScore} {currentDiscConfig.unit}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* DISCIPLINE-SPECIFIC LIVE GAUGES OVER 3D STAGE            */}
      {/* ======================================================== */}
      {mode === 'playing' && selectedDiscipline === 'jump' && telemetry.jumpPhase === 'charge' && (
        <div className="fixed right-4 sm:right-8 top-1/2 -translate-y-1/2 z-30 pointer-events-none flex flex-col items-center">
          <div className="guinness-panel p-3 rounded-3xl border-2 border-amber-400 flex flex-col items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-300 text-center">
              ПИК ПРЫЖКА
            </span>
            <div className="relative w-7 h-48 bg-slate-950 rounded-full overflow-hidden border-2 border-slate-700 p-0.5 flex flex-col justify-end">
              {/* Target Green Sweet Spot at top 22% */}
              <div className="absolute top-0 inset-x-0 h-[22%] bg-emerald-500/35 border-b-2 border-emerald-400 z-10" />
              {/* Live oscillating bar */}
              <div
                className={`w-full rounded-full transition-none ${
                  (telemetry.powerGauge ?? 0) >= 0.78
                    ? 'bg-gradient-to-t from-amber-400 to-emerald-400'
                    : 'bg-gradient-to-t from-orange-600 to-amber-400'
                }`}
                style={{ height: `${Math.round((telemetry.powerGauge ?? 0) * 100)}%` }}
              />
            </div>
            <span className="font-mono-num text-xs font-black text-amber-300">
              {Math.round((telemetry.powerGauge ?? 0) * 100)}%
            </span>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* FLOATING ZONE 2: BOTTOM DOCK (HUB SELECTOR OR CONTROLS)  */}
      {/* ======================================================== */}
      <footer className="fixed bottom-0 inset-x-0 z-30 p-3 sm:p-5 pointer-events-none">
        <div className="max-w-5xl mx-auto">
          {mode === 'hub' && (
            <div className="pointer-events-auto flex flex-col gap-3">
              {/* 3 Discipline Selector Pills */}
              <div className="grid grid-cols-3 gap-2.5 sm:gap-4">
                {DISCIPLINE_LIST.map((disc) => {
                  const rec = records[disc.id];
                  const isSelected = selectedDiscipline === disc.id;

                  return (
                    <button
                      key={disc.id}
                      onClick={() => {
                        setSelectedDiscipline(disc.id);
                        soundEngine.playChomp(2);
                      }}
                      className={`text-left rounded-2xl p-3 sm:p-4 transition-all cursor-pointer border-2 relative overflow-hidden ${
                        isSelected
                          ? 'bg-slate-900/95 border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.35)] -translate-y-1'
                          : 'bg-slate-900/75 border-slate-700/80 hover:border-amber-400/50'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span
                          className={`p-1.5 rounded-xl ${
                            isSelected
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-amber-300'
                          }`}
                        >
                          {renderDisciplineIcon(disc.iconName, 'w-4 h-4 sm:w-5 sm:h-5')}
                        </span>

                        {rec.isRecordBroken ? (
                          <span className="inline-flex items-center gap-1 text-[10px] sm:text-xs font-extrabold px-2 py-0.5 rounded-full bg-emerald-500/25 text-emerald-300 border border-emerald-400/50">
                            <CheckCircle2 className="w-3 h-3" /> РЕКОРД
                          </span>
                        ) : (
                          <span className="text-[10px] sm:text-xs font-mono-num font-bold text-amber-300/90 bg-slate-800/90 px-2 py-0.5 rounded-full">
                            Цель: {disc.targetScore} {disc.unit}
                          </span>
                        )}
                      </div>

                      <div className="font-display text-xs sm:text-base font-black uppercase text-white truncate">
                        {disc.shortTitle}
                      </div>

                      <div className="text-[11px] font-mono-num font-bold text-slate-400 mt-0.5 truncate">
                        Топ: {rec.bestScore} {disc.unit}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Selected Discipline Brief & Primary Launch CTA Bar */}
              <div className="guinness-panel rounded-3xl p-3.5 sm:p-4 flex flex-col md:flex-row items-center justify-between gap-3.5">
                <div className="space-y-1 text-center md:text-left flex-1">
                  <div className="flex items-center justify-center md:justify-start gap-2">
                    <span className="text-xs font-mono-num font-extrabold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/40">
                      {currentDiscConfig.code}
                    </span>
                    <span className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
                      Норматив Гиннесса: {currentDiscConfig.targetScore} {currentDiscConfig.unit}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm font-bold text-slate-200 leading-snug">
                    {currentDiscConfig.description}
                  </p>
                </div>

                <div className="flex items-center gap-2.5 w-full md:w-auto justify-center shrink-0">
                  <button
                    onClick={() => externalTriggerRef.current?.petKotost()}
                    className="btn-navy-arcade px-4 py-3.5 rounded-2xl font-display font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                    title="Кликните, чтобы погладить Котость в 3D"
                  >
                    <Hand className="w-4 h-4 text-amber-400" />
                    <span className="hidden sm:inline">Погладить</span>
                  </button>

                  <button
                    onClick={() => startDisciplineAttempt(selectedDiscipline)}
                    className="btn-gold-arcade flex-1 md:flex-initial px-6 sm:px-8 py-3.5 rounded-2xl font-display font-black text-sm sm:text-base uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Play className="w-5 h-5 fill-current" />
                    Побить Рекорд!
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ACTIVE GAMEPLAY TACTILE CONTROLS DOCK */}
          {mode === 'playing' && (
            <div className="pointer-events-auto flex flex-col items-center gap-2.5">
              {/* Sub-status hint pill */}
              {telemetry.subStatusText && (
                <div className="guinness-panel px-4 py-1.5 rounded-full text-xs sm:text-sm font-extrabold text-amber-200 border border-amber-400/50 shadow-lg text-center">
                  {telemetry.subStatusText}
                </div>
              )}

              {/* Discipline 1: Chonk Feeding Button */}
              {selectedDiscipline === 'chonk' && (
                <button
                  onClick={() => externalTriggerRef.current?.triggerPrimaryAction()}
                  className="btn-gold-arcade w-full max-w-md py-4 px-8 rounded-3xl font-display font-black text-lg sm:text-xl uppercase tracking-wider flex items-center justify-center gap-3 cursor-pointer"
                >
                  <Sparkles className="w-6 h-6" />
                  🍖 КОРМИТЬ КОТОСТЬ! [КЛИК / ПРОБЕЛ]
                </button>
              )}

              {/* Discipline 2: Jump Charge or Flight Steering Controls */}
              {selectedDiscipline === 'jump' && (
                <div className="w-full max-w-lg flex items-center justify-center gap-3">
                  {telemetry.jumpPhase === 'charge' ? (
                    <button
                      onPointerDown={() => externalTriggerRef.current?.setHoldState(true)}
                      onPointerUp={() => externalTriggerRef.current?.setHoldState(false)}
                      onClick={() => externalTriggerRef.current?.triggerPrimaryAction()}
                      className="btn-gold-arcade w-full py-4 px-6 rounded-3xl font-display font-black text-base sm:text-xl uppercase tracking-wider flex items-center justify-center gap-2.5 cursor-pointer"
                    >
                      <Rocket className="w-6 h-6" />
                      ЗАЖМИТЕ И ОТПУСТИТЕ НА ПИКЕ! [ПРОБЕЛ]
                    </button>
                  ) : (
                    <div className="flex items-center gap-3 w-full">
                      <button
                        onPointerDown={() => externalTriggerRef.current?.steerHorizontal(-1)}
                        onPointerUp={() => externalTriggerRef.current?.steerHorizontal(0)}
                        onPointerLeave={() => externalTriggerRef.current?.steerHorizontal(0)}
                        className="btn-navy-arcade flex-1 py-4 rounded-2xl font-display font-black text-sm sm:text-base uppercase flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <ChevronLeft className="w-6 h-6 text-amber-400" />
                        Влево [A]
                      </button>
                      <button
                        onPointerDown={() => externalTriggerRef.current?.steerHorizontal(1)}
                        onPointerUp={() => externalTriggerRef.current?.steerHorizontal(0)}
                        onPointerLeave={() => externalTriggerRef.current?.steerHorizontal(0)}
                        className="btn-navy-arcade flex-1 py-4 rounded-2xl font-display font-black text-sm sm:text-base uppercase flex items-center justify-center gap-2 cursor-pointer"
                      >
                        Вправо [D]
                        <ChevronRight className="w-6 h-6 text-amber-400" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Discipline 3: Head-Stacking Drop & Balance Controls */}
              {selectedDiscipline === 'stack' && (
                <div className="w-full max-w-xl flex items-center gap-2.5">
                  <button
                    onPointerDown={() => externalTriggerRef.current?.steerHorizontal(-1)}
                    onPointerUp={() => externalTriggerRef.current?.steerHorizontal(0)}
                    className="btn-navy-arcade px-4 py-4 rounded-2xl font-display font-extrabold text-xs uppercase flex items-center gap-1 cursor-pointer"
                    title="Наклон влево (Клавиша A)"
                  >
                    <ChevronLeft className="w-5 h-5 text-amber-400" />
                    Баланс
                  </button>

                  <button
                    onClick={() => externalTriggerRef.current?.triggerPrimaryAction()}
                    className="btn-crimson-arcade flex-1 py-4 px-6 rounded-3xl font-display font-black text-base sm:text-xl uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Layers className="w-6 h-6" />
                    СБРОСИТЬ НА МАКУШКУ! [ПРОБЕЛ]
                  </button>

                  <button
                    onPointerDown={() => externalTriggerRef.current?.steerHorizontal(1)}
                    onPointerUp={() => externalTriggerRef.current?.steerHorizontal(0)}
                    className="btn-navy-arcade px-4 py-4 rounded-2xl font-display font-extrabold text-xs uppercase flex items-center gap-1 cursor-pointer"
                    title="Наклон вправо (Клавиша D)"
                  >
                    Баланс
                    <ChevronRight className="w-5 h-5 text-amber-400" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </footer>

      {/* ======================================================== */}
      {/* OFFICIAL GUINNESS WORLD RECORD CERTIFICATE MODAL         */}
      {/* ======================================================== */}
      {mode === 'result' && (
        <RecordCertificateModal
          discipline={currentDiscConfig}
          score={lastScore}
          bestScore={records[selectedDiscipline].bestScore}
          isNewPersonalBest={isNewPersonalBest}
          onRetry={() => startDisciplineAttempt(selectedDiscipline)}
          onNextDiscipline={handleNextDiscipline}
          onBackToHub={() => setMode('hub')}
        />
      )}

      {/* ======================================================== */}
      {/* GUINNESS RECORD BOOK / HALL OF FAME MODAL                */}
      {/* ======================================================== */}
      {showRecordBook && (
        <RecordBookModal
          records={records}
          onClose={() => setShowRecordBook(false)}
          onSelectAndPlay={(id) => startDisciplineAttempt(id)}
        />
      )}
    </div>
  );
}

export default App;
