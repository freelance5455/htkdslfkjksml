import { useCallback, useState } from 'react';
import Menu from './components/Menu';
import GameScreen from './components/GameScreen';
import type { Mode } from './game/match';
import type { Difficulty } from './game/bot';
import { loadSettings, saveSettings, loadStats, saveStats } from './game/settings';
import type { Settings, Stats } from './game/settings';

interface Session {
  mode: Mode;
  difficulty: Difficulty;
  key: number;
}

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [stats, setStats] = useState<Stats>(loadStats);
  const [session, setSession] = useState<Session | null>(null);

  const updateSettings = useCallback((s: Settings) => {
    setSettings(s);
    saveSettings(s);
  }, []);

  const onResult = useCallback(
    (winner: number, dealt: number) => {
      if (!session || session.mode !== 'bot') return;
      setStats((prev) => {
        const next: Stats = {
          ...prev,
          wins: prev.wins + (winner === 0 ? 1 : 0),
          losses: prev.losses + (winner === 1 ? 1 : 0),
          draws: prev.draws + (winner === 2 ? 1 : 0),
          best: Math.max(prev.best, dealt),
        };
        saveStats(next);
        return next;
      });
    },
    [session]
  );

  if (session) {
    return (
      <GameScreen
        key={session.key}
        mode={session.mode}
        difficulty={session.difficulty}
        settings={settings}
        onExit={() => setSession(null)}
        onRematch={() => setSession({ ...session, key: session.key + 1 })}
        onResult={onResult}
      />
    );
  }

  return (
    <Menu
      settings={settings}
      stats={stats}
      onSettings={updateSettings}
      onPlay={(mode, difficulty) => setSession({ mode, difficulty, key: Date.now() })}
      onResetStats={() => {
        const z = { wins: 0, losses: 0, draws: 0, best: 0 };
        setStats(z);
        saveStats(z);
      }}
    />
  );
}
