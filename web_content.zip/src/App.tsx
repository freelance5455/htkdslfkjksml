import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { DateTabs } from './components/DateTabs';
import { MatchCard } from './components/MatchCard';
import { ChannelsGrid } from './components/ChannelsGrid';
import { HighlightsGrid } from './components/HighlightsGrid';
import { LiveStreamPlayer } from './components/LiveStreamPlayer';
import { CustomStreamModal } from './components/CustomStreamModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import { useTheme } from './context/ThemeContext';
import { MOCK_MATCHES, MOCK_CHANNELS, MOCK_HIGHLIGHTS } from './data/mockMatches';
import { Match, SportsChannel, HighlightVideo } from './types';
import {
  Tv,
  Radio,
  Flame,
  ShieldCheck,
  Zap,
  Smartphone,
  Wifi,
  Sparkles,
  Info,
  CalendarCheck,
  Layers,
  Sun,
  Moon,
  Clock,
} from 'lucide-react';

export default function App() {
  const { isAuto, isDaytime, deviceTimeStr } = useTheme();
  const [activeTab, setActiveTab] = useState<'matches' | 'channels' | 'highlights'>('matches');
  const [dayGroup, setDayGroup] = useState<'today' | 'tomorrow' | 'yesterday'>('today');
  const [selectedLeague, setSelectedLeague] = useState<string>('all');
  const [onlyLive, setOnlyLive] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected player item
  const [activeStreamItem, setActiveStreamItem] = useState<{
    item: Match | SportsChannel;
    type: 'match' | 'channel';
  } | null>(null);

  const [isCustomModalOpen, setIsCustomModalOpen] = useState<boolean>(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(false);

  // Live count
  const liveCount = useMemo(() => {
    return MOCK_MATCHES.filter((m) => m.status === 'live').length;
  }, []);

  // Available leagues
  const availableLeagues = useMemo(() => {
    const set = new Set<string>();
    MOCK_MATCHES.forEach((m) => {
      set.add(m.tournament.category);
    });
    return Array.from(set);
  }, []);

  // Filtered matches
  const filteredMatches = useMemo(() => {
    return MOCK_MATCHES.filter((m) => {
      // Day filter
      if (m.dayGroup !== dayGroup) return false;

      // Live only
      if (onlyLive && m.status !== 'live') return false;

      // League filter
      if (selectedLeague !== 'all' && m.tournament.category !== selectedLeague) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesHome = m.homeTeam.name.toLowerCase().includes(q);
        const matchesAway = m.awayTeam.name.toLowerCase().includes(q);
        const matchesTour = m.tournament.name.toLowerCase().includes(q);
        const matchesComm = m.commentator.toLowerCase().includes(q);
        const matchesChan = m.channel.toLowerCase().includes(q);
        return matchesHome || matchesAway || matchesTour || matchesComm || matchesChan;
      }

      return true;
    });
  }, [dayGroup, onlyLive, selectedLeague, searchQuery]);

  const handleSelectMatch = (match: Match) => {
    setActiveStreamItem({ item: match, type: 'match' });
  };

  const handleSelectChannel = (channel: SportsChannel) => {
    setActiveStreamItem({ item: channel, type: 'channel' });
  };

  const handlePlayHighlight = (highlight: HighlightVideo) => {
    const highlightChannel: SportsChannel = {
      id: highlight.id,
      name: highlight.title,
      category: 'beIN Sports',
      logo: highlight.thumbnail,
      quality: 'FHD',
      currentShow: `ملخص: ${highlight.tournament} - ${highlight.duration}`,
      viewers: highlight.views,
      videoUrl: highlight.videoUrl,
      servers: [
        {
          id: 'hl-s1',
          name: 'سيرفر الأهداف HD',
          quality: '1080p FHD',
          url: highlight.videoUrl,
        },
      ],
    };
    setActiveStreamItem({ item: highlightChannel, type: 'channel' });
  };

  const handleLaunchCustomStream = (customChannel: SportsChannel) => {
    setActiveStreamItem({ item: customChannel, type: 'channel' });
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-[#080b12] text-slate-900 dark:text-slate-100 flex flex-col font-['Cairo',sans-serif] transition-colors duration-200">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenCustomStream={() => setIsCustomModalOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        liveMatchesCount={liveCount}
      />

      {/* Hero Announcement Banner */}
      <section className="bg-rose-50/90 dark:bg-gradient-to-r dark:from-rose-950/40 dark:via-[#101524] dark:to-rose-950/30 border-b border-rose-200 dark:border-rose-900/30 py-2.5 px-4 transition-colors">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            </span>
            <span className="font-bold text-rose-600 dark:text-rose-400">تنبيه المشاهدين:</span>
            <span className="text-slate-600 dark:text-slate-300">
              سيرفرات IRAQI LIVE VIP جاهزة الآن لنقل قمة اليوم بدون أي إعلانات مزعجة وبجودات متعددة.
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400">
            {/* Automatic theme indicator badge */}
            {isAuto && (
              <div className="hidden md:flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20">
                {isDaytime ? <Sun className="w-3.5 h-3.5 text-amber-500" /> : <Moon className="w-3.5 h-3.5 text-indigo-400" />}
                <span>
                  الوضع التلقائي: {isDaytime ? 'نهاري مضيء ☀️' : 'ليلي مظلم 🌙'} (وقت جهازك: {deviceTimeStr})
                </span>
              </div>
            )}

            <button
              onClick={() => setIsApkModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-sm transition-all cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>تنزيل / تثبيت APK</span>
            </button>

            <span className="hidden sm:flex items-center gap-1">
              <Wifi className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" />
              <span>جودات متعددة</span>
            </span>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* TAB 1: MATCHES */}
        {activeTab === 'matches' && (
          <div>
            {/* Date and Tournament Filters */}
            <DateTabs
              dayGroup={dayGroup}
              setDayGroup={setDayGroup}
              selectedLeague={selectedLeague}
              setSelectedLeague={setSelectedLeague}
              onlyLive={onlyLive}
              setOnlyLive={setOnlyLive}
              liveCount={liveCount}
              availableLeagues={availableLeagues}
            />

            {/* Matches Grid or Empty State */}
            {filteredMatches.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredMatches.map((match) => (
                  <MatchCard
                    key={match.id}
                    match={match}
                    onSelectMatch={handleSelectMatch}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white dark:bg-[#101625] border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center max-w-lg mx-auto space-y-4 shadow-sm dark:shadow-xl my-8">
                <div className="w-16 h-16 rounded-2xl bg-rose-600/10 border border-rose-500/20 text-rose-500 flex items-center justify-center mx-auto">
                  <CalendarCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">لا توجد مباريات مطابقة للبحث</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    جرب تغيير يوم المباريات أو مسح الفلاتر وكلمات البحث للعثور على اللقاءات
                  </p>
                </div>
                <button
                  onClick={() => {
                    setSelectedLeague('all');
                    setOnlyLive(false);
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  إعادة ضبط الفلاتر
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CHANNELS */}
        {activeTab === 'channels' && (
          <ChannelsGrid
            channels={MOCK_CHANNELS}
            onSelectChannel={handleSelectChannel}
          />
        )}

        {/* TAB 3: HIGHLIGHTS */}
        {activeTab === 'highlights' && (
          <HighlightsGrid
            highlights={MOCK_HIGHLIGHTS}
            onPlayHighlight={handlePlayHighlight}
          />
        )}

        {/* Bottom Feature Cards */}
        <section className="mt-14 pt-8 border-t border-slate-200 dark:border-slate-800/80">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white font-['Changa']">
              لماذا يفضل الملايين تطبيق IRAQI LIVE لمتابعة المباريات؟
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              تجربة مشاهدة رياضية متكاملة مصممة خصيصاً للمشجع الرياضي مع وضع مضيء ووضع مظلم تلقائي
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-[#0f1422] p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 shadow-sm dark:shadow-none transition-colors">
              <div className="w-10 h-10 rounded-xl bg-rose-600/10 dark:bg-rose-600/20 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-500/20 dark:border-rose-500/30">
                <Zap className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">سيرفرات VIP فائقة السرعة</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                سيرفرات متعددة وموزعة لضمان استقرار البث حتى أثناء الضغط الجماهيري العالي.
              </p>
            </div>

            <div className="bg-white dark:bg-[#0f1422] p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 shadow-sm dark:shadow-none transition-colors">
              <div className="w-10 h-10 rounded-xl bg-amber-600/10 dark:bg-amber-600/20 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-500/20 dark:border-amber-500/30">
                <Smartphone className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">توفير باقات الإنترنت</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                إمكانية التبديل إلى الجودة الضعيفة أو البث الصوتي فقط لتوفير استهلاك البيانات.
              </p>
            </div>

            <div className="bg-white dark:bg-[#0f1422] p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 shadow-sm dark:shadow-none transition-colors">
              <div className="w-10 h-10 rounded-xl bg-blue-600/10 dark:bg-blue-600/20 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-500/20 dark:border-blue-500/30">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">تشكيلة وإحصائيات تفاعلية</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                رسم تكتيكي للملعب، خطط المدربين، وإحصائيات الاستحواذ والتسديدات لحظة بلحظة.
              </p>
            </div>

            <div className="bg-white dark:bg-[#0f1422] p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 shadow-sm dark:shadow-none transition-colors">
              <div className="w-10 h-10 rounded-xl bg-emerald-600/10 dark:bg-emerald-600/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-500/20 dark:border-emerald-500/30">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">دردشة جماهيرية حية</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                تفاعل فوري مع آلاف المشجعين في شات المباراة الحية مع مؤثرات واحتفالات الأهداف.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Live Stream Player Modal */}
      {activeStreamItem && (
        <LiveStreamPlayer
          item={activeStreamItem.item}
          type={activeStreamItem.type}
          onClose={() => setActiveStreamItem(null)}
        />
      )}

      {/* Custom Stream M3U8 Modal */}
      <CustomStreamModal
        isOpen={isCustomModalOpen}
        onClose={() => setIsCustomModalOpen(false)}
        onLaunchCustomStream={handleLaunchCustomStream}
      />

      {/* APK & PWA Download / Install Modal */}
      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Footer */}
      <footer className="bg-white dark:bg-[#090d16] border-t border-slate-200 dark:border-slate-800/80 py-6 mt-12 text-xs text-slate-500 dark:text-slate-500 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-rose-600 flex items-center justify-center text-white font-black font-['Changa'] text-xs">
              IL
            </div>
            <span className="font-bold text-slate-700 dark:text-slate-300">IRAQI LIVE - تطبيق بث المباريات المباشر</span>
            <span className="text-slate-300 dark:text-slate-600">|</span>
            <span>بث مباشر لمباريات اليوم والقنوات الرياضية</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500 dark:text-slate-400">
            <span>جميع الحقوق محفوظة لمحبي كرة القدم 2026 ©</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

