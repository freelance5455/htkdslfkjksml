import { useEffect } from "react";
import { Calculator } from "@/components/Calculator";

export default function App() {
  useEffect(() => {
    document.title = "الحاسبة الذكية";
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-100 via-teal-50 to-emerald-100 p-2">
      <div className="w-full max-w-sm">
        <header className="mb-2.5 text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-teal-600">
            Smart Calculator
          </p>
          <h1 className="font-serif text-xl font-bold text-slate-800">
            الحاسبة الذكية
          </h1>
        </header>

        <Calculator />

        <p className="mt-2.5 text-center text-xs text-slate-400">
          الأرقام، + − × ÷، Enter للحساب، Esc للمسح
        </p>
      </div>
    </div>
  );
}