import React, { useEffect, useState } from 'react';
import { AudioSettings, GameMode, GameStats, ScreenState } from './types/game';
import {
  clearAllStats,
  hasAnySavedGame,
  loadActiveGame,
  loadSettings,
  loadStats,
  saveSettings,
  saveStats,
} from './services/storage';
import { soundEngine } from './services/soundEngine';
import { CosmicBackground } from './components/CosmicBackground';
import { HomeScreen } from './screens/HomeScreen';
import { GameScreen } from './screens/GameScreen';
import { HowToPlayModal } from './components/Modals/HowToPlayModal';
import { SettingsModal } from './components/Modals/SettingsModal';
import { AchievementsModal } from './components/Modals/AchievementsModal';
import { ModeSelectModal } from './components/Modals/ModeSelectModal';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenState>('HOME');
  const [gameMode, setGameMode] = useState<GameMode>('CLASSIC');
  const [stats, setStats] = useState<GameStats>(loadStats);
  const [settings, setSettings] = useState<AudioSettings>(loadSettings);
  const [hasSavedGame, setHasSavedGame] = useState<boolean>(() => hasAnySavedGame());
  const [resumeSavedGame, setResumeSavedGame] = useState<boolean>(false);
  
  // Modals
  const [showHowToPlay, setShowHowToPlay] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [settingsTab, setSettingsTab] = useState<'themes' | 'audio'>('themes');
  const [showAchievements, setShowAchievements] = useState<boolean>(false);
  const [showModeSelect, setShowModeSelect] = useState<boolean>(false);

  // Initialize and synchronize audio settings
  useEffect(() => {
    soundEngine.setSfxEnabled(settings.sfxEnabled);
    soundEngine.setSfxVolume(settings.sfxVolume);
    soundEngine.setMusicEnabled(settings.musicEnabled);
    soundEngine.setMusicVolume(settings.musicVolume);
    saveSettings(settings);
  }, [settings]);

  // Synchronize stats
  const handleUpdateStats = (newStats: GameStats) => {
    setStats(newStats);
    saveStats(newStats);
  };

  const handleUpdateSettings = (newSettings: AudioSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const handleClearStats = () => {
    clearAllStats();
    const emptyStats: GameStats = {
      highScore: 0,
      rushHighScore: 0,
      bombHighScore: 0,
      gamesPlayed: 0,
      totalLinesCleared: 0,
      highestCombo: 0,
      totalBlocksPlaced: 0,
      bombsDefused: 0,
      perfectClears: 0,
      achievements: stats.achievements.map((a) => ({ ...a, unlocked: false })),
    };
    setStats(emptyStats);
    setHasSavedGame(false);
  };

  const handleStartNewGame = (mode: GameMode = 'CLASSIC') => {
    soundEngine.playClick();
    if (settings.musicEnabled) {
      soundEngine.startMusic();
    }
    setGameMode(mode);
    setResumeSavedGame(false);
    setShowModeSelect(false);
    setCurrentScreen('PLAY');
  };

  const handleResumeGame = () => {
    soundEngine.playClick();
    if (settings.musicEnabled) {
      soundEngine.startMusic();
    }
    // Check which mode has saved game
    const savedRush = loadActiveGame('RUSH');
    const savedBomb = loadActiveGame('BOMB');
    const targetMode: GameMode = savedRush ? 'RUSH' : savedBomb ? 'BOMB' : 'CLASSIC';

    setGameMode(targetMode);
    setResumeSavedGame(true);
    setCurrentScreen('PLAY');
  };

  const handleGoHome = () => {
    soundEngine.playClick();
    setHasSavedGame(hasAnySavedGame());
    setCurrentScreen('HOME');
  };

  return (
    <div className="relative h-[100dvh] min-h-[100dvh] w-full bg-[#050B14] text-white flex flex-col items-center justify-start overflow-hidden">
      {/* Dynamic Cosmic Stardust & Backdrop */}
      <CosmicBackground />

      {/* Screen Router */}
      {currentScreen === 'HOME' && (
        <HomeScreen
          stats={stats}
          hasSavedGame={hasSavedGame}
          onStartNewGame={handleStartNewGame}
          onResumeGame={handleResumeGame}
          onOpenHowToPlay={() => {
            soundEngine.playClick();
            setShowHowToPlay(true);
          }}
          onOpenSettings={(tab = 'audio') => {
            soundEngine.playClick();
            setSettingsTab(tab);
            setShowSettings(true);
          }}
          onOpenAchievements={() => {
            soundEngine.playClick();
            setShowAchievements(true);
          }}
          onOpenModeSelect={() => {
            soundEngine.playClick();
            setShowModeSelect(true);
          }}
        />
      )}

      {currentScreen === 'PLAY' && (
        <GameScreen
          mode={gameMode}
          stats={stats}
          settings={settings}
          onUpdateStats={handleUpdateStats}
          onUpdateSettings={handleUpdateSettings}
          onGoHome={handleGoHome}
          resumeSavedGame={resumeSavedGame}
        />
      )}

      {/* How To Play Modal */}
      {showHowToPlay && (
        <HowToPlayModal
          onClose={() => {
            soundEngine.playClick();
            setShowHowToPlay(false);
          }}
        />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          stats={stats}
          defaultTab={settingsTab}
          onUpdateSettings={handleUpdateSettings}
          onClearStats={handleClearStats}
          onClose={() => {
            soundEngine.playClick();
            setShowSettings(false);
          }}
        />
      )}

      {/* Achievements Modal */}
      {showAchievements && (
        <AchievementsModal
          achievements={stats.achievements}
          onClose={() => {
            soundEngine.playClick();
            setShowAchievements(false);
          }}
        />
      )}

      {/* Mode Select Modal */}
      {showModeSelect && (
        <ModeSelectModal
          stats={stats}
          onSelectMode={handleStartNewGame}
          onClose={() => {
            soundEngine.playClick();
            setShowModeSelect(false);
          }}
        />
      )}
    </div>
  );
}
