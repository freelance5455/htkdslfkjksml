import { useEffect, useMemo, useState } from 'react';
import { loadPocketwiseSnapshot, savePocketwiseSnapshot } from './storage';
import {
  Activity,
  ArrowDownLeft,
  CalendarCheck,
  CheckCircle2,
  CircleDollarSign,
  Lightbulb,
  ListChecks,
  ArrowUpRight,
  BarChart3,
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  CircleHelp,
  CreditCard,
  Download,
  Filter,
  Home,
  LayoutDashboard,
  Menu,
  Plus,
  Pencil,
  Search,
  BrainCircuit,
  FileJson,
  LockKeyhole,
  Upload,
  History,
  RotateCcw,
  Settings,
  ShieldCheck,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
  Wallet,
  X,
} from 'lucide-react';
import { UserRound } from 'lucide-react';

type Loan = { id: string; person: string; amount: number; repaidAmount?: number; repayments?: { id: string; amount: number; date: string }[]; date: string; dueDate: string; note: string; status: 'outstanding' | 'repaid' };
type AuditRecord = { id: string; date: string; mode: string; report: string; txCount: number };
type CoachTask = { id: string; title: string; detail: string; done: boolean; week: string };
type CoachGoals = { monthlySavingsGoal: number; weeklySpendLimit: number };
type Budget = { id: string; category: string; limit: number };
const incomeCategories = ['Salary', 'Allowance', 'Freelance', 'Business', 'Interest', 'Gift', 'Refund', 'Other'];
type Tx = {
  id: string;
  title: string;
  category: string;
  amount: number;
  type: 'expense' | 'income';
  date: string;
  note?: string;
};
const seed: Tx[] = [
  {
    id: 's1',
    title: 'Monthly allowance',
    category: 'Income',
    amount: 12000,
    type: 'income',
    date: '2026-10-01',
  },
  {
    id: 's2',
    title: 'Groceries',
    category: 'Food',
    amount: 1450,
    type: 'expense',
    date: '2026-10-03',
  },
  {
    id: 's3',
    title: 'Metro & commute',
    category: 'Transport',
    amount: 620,
    type: 'expense',
    date: '2026-10-05',
  },
  {
    id: 's4',
    title: 'Coffee with friends',
    category: 'Food',
    amount: 280,
    type: 'expense',
    date: '2026-10-08',
  },
  {
    id: 's5',
    title: 'Mobile recharge',
    category: 'Bills',
    amount: 299,
    type: 'expense',
    date: '2026-10-10',
  },
  {
    id: 's6',
    title: 'Study supplies',
    category: 'Education',
    amount: 760,
    type: 'expense',
    date: '2026-10-12',
  },
  {
    id: 's7',
    title: 'Freelance task',
    category: 'Income',
    amount: 1800,
    type: 'income',
    date: '2026-10-15',
  },
  {
    id: 's8',
    title: 'Movie night',
    category: 'Entertainment',
    amount: 550,
    type: 'expense',
    date: '2026-10-17',
  },
  {
    id: 's9',
    title: 'Snacks',
    category: 'Food',
    amount: 190,
    type: 'expense',
    date: '2026-10-19',
  },
];
const money = (n: number) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(n);
const baseCats = [
  'Food',
  'Transport',
  'Bills',
  'Education',
  'Shopping',
  'Entertainment',
  'Health',
  'Other',
];
function App() {
  const [txs, setTxs] = useState<Tx[]>(() => {
    try {
      const s = localStorage.getItem('pocketwise-txs');
      return s ? JSON.parse(s) : seed;
    } catch {
      return seed;
    }
  });
  const [page, setPage] = useState('Overview');
  const [showAdd, setShowAdd] = useState(false);
  const [editingTxId, setEditingTxId] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const [period, setPeriod] = useState('This month');
  const [kind, setKind] = useState<'expense' | 'income'>('expense');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food');
  const [customCategories, setCustomCategories] = useState<string[]>(() => { try { const value = JSON.parse(localStorage.getItem('pocketwise-custom-categories') || '[]'); return Array.isArray(value) ? value.filter((c: unknown) => typeof c === 'string') : []; } catch { return []; } });
  const [categoryDraft, setCategoryDraft] = useState('');
  const [categoryNotice, setCategoryNotice] = useState('');
  const [incomeCategory, setIncomeCategory] = useState('Salary');
  const [customIncomeCategory, setCustomIncomeCategory] = useState('');
  const [budgets, setBudgets] = useState<Budget[]>(() => { try { const v = JSON.parse(localStorage.getItem('pocketwise-budgets') || '[]'); return Array.isArray(v) ? v.filter((b: any) => b && typeof b.category === 'string' && Number.isFinite(Number(b.limit)) && Number(b.limit) > 0).map((b: any) => ({ id: String(b.id || crypto.randomUUID()), category: b.category, limit: Number(b.limit) })) : []; } catch { return []; } });
  const [budgetCategory, setBudgetCategory] = useState('Food');
  const [budgetLimit, setBudgetLimit] = useState('');
  const [budgetNotice, setBudgetNotice] = useState('');
  const [editingBudgetId, setEditingBudgetId] = useState<string | null>(null);
  const [editingBudgetLimit, setEditingBudgetLimit] = useState('');
  const [showBudgetForm, setShowBudgetForm] = useState(false);
  const [lendingSearch, setLendingSearch] = useState('');
  const [lendingFilter, setLendingFilter] = useState('All');
  const cats = useMemo(() => [...baseCats, ...customCategories.filter(c => !baseCats.includes(c))], [customCategories]);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState('');
  const [audit, setAudit] = useState('');
  const [auditBusy, setAuditBusy] = useState(false);
  const [auditError, setAuditError] = useState('');
  const [auditMode, setAuditMode] = useState('Full audit');
  const [auditHistory, setAuditHistory] = useState<AuditRecord[]>(() => { try { return JSON.parse(localStorage.getItem('pocketwise-audit-history') || '[]'); } catch { return []; } });
  const [backupMessage, setBackupMessage] = useState('');
  const [backupBusy, setBackupBusy] = useState(false);
  const [storageReady, setStorageReady] = useState(false);
  const [storageStatus, setStorageStatus] = useState('Preparing on-device storage…');
  const [coachGoals, setCoachGoals] = useState<CoachGoals>(() => { try { return JSON.parse(localStorage.getItem('pocketwise-coach-goals') || '{"monthlySavingsGoal":0,"weeklySpendLimit":0}'); } catch { return { monthlySavingsGoal: 0, weeklySpendLimit: 0 }; } });
  const [coachTasks, setCoachTasks] = useState<CoachTask[]>(() => { try { return JSON.parse(localStorage.getItem('pocketwise-coach-tasks') || '[]'); } catch { return []; } });
  const [goalSavingsInput, setGoalSavingsInput] = useState('');
  const [goalWeeklyInput, setGoalWeeklyInput] = useState('');
  const [coachNotice, setCoachNotice] = useState('');
  const [loans, setLoans] = useState<Loan[]>(() => { try { return JSON.parse(localStorage.getItem('pocketwise-loans') || '[]'); } catch { return []; } });
  const [showLoan, setShowLoan] = useState(false);
  const [loanPerson, setLoanPerson] = useState('');
  const [loanAmount, setLoanAmount] = useState('');
  const [loanDate, setLoanDate] = useState(new Date().toISOString().slice(0, 10));
  const [loanDueDate, setLoanDueDate] = useState('');
  const [loanNote, setLoanNote] = useState('');
  const [loanError, setLoanError] = useState('');
  const [menu, setMenu] = useState(false);
  const [profileName, setProfileName] = useState(() => { try { return localStorage.getItem('pocketwise-profile-name') || 'Anurag Mandal'; } catch { return 'Anurag Mandal'; } });
  const [profileNameDraft, setProfileNameDraft] = useState(() => { try { return localStorage.getItem('pocketwise-profile-name') || 'Anurag Mandal'; } catch { return 'Anurag Mandal'; } });
  const [editingProfileName, setEditingProfileName] = useState(false);
  const [profileNotice, setProfileNotice] = useState('');
  useEffect(() => {
    let cancelled = false;
    const fallback = { txs, loans, auditHistory, coachGoals, coachTasks, customCategories };
    loadPocketwiseSnapshot(fallback).then(snapshot => {
      if (cancelled) return;
      if (Array.isArray(snapshot.txs)) setTxs(snapshot.txs as Tx[]);
      if (Array.isArray(snapshot.loans)) setLoans(snapshot.loans as Loan[]);
      if (Array.isArray(snapshot.auditHistory)) setAuditHistory(snapshot.auditHistory as AuditRecord[]);
      if (snapshot.coachGoals) setCoachGoals(snapshot.coachGoals);
      if (Array.isArray(snapshot.coachTasks)) setCoachTasks(snapshot.coachTasks as CoachTask[]);
      if (Array.isArray(snapshot.customCategories)) setCustomCategories(snapshot.customCategories as string[]);
      setStorageStatus('On-device database active · IndexedDB');
      setStorageReady(true);
    }).catch(() => {
      if (cancelled) return;
      setStorageStatus('Browser storage fallback active · export backups regularly');
      setBackupMessage('The on-device database is unavailable. Existing records are still shown; export a backup to protect them.');
      setStorageReady(true);
    });
    return () => { cancelled = true; };
  }, []);
  useEffect(() => {
    try { localStorage.setItem('pocketwise-profile-name', profileName); } catch { /* keep the current in-memory name if storage is unavailable */ }
  }, [profileName]);
  useEffect(() => {
    if (!storageReady) return;
    const snapshot = { txs, loans, auditHistory: auditHistory.slice(0, 12), coachGoals, coachTasks: coachTasks.slice(-40), customCategories };
    try {
      localStorage.setItem('pocketwise-txs', JSON.stringify(txs));
      localStorage.setItem('pocketwise-loans', JSON.stringify(loans));
      localStorage.setItem('pocketwise-audit-history', JSON.stringify(auditHistory.slice(0, 12)));
      localStorage.setItem('pocketwise-coach-goals', JSON.stringify(coachGoals));
      localStorage.setItem('pocketwise-coach-tasks', JSON.stringify(coachTasks.slice(-40)));
      localStorage.setItem('pocketwise-custom-categories', JSON.stringify(customCategories));
      localStorage.setItem('pocketwise-budgets', JSON.stringify(budgets));
    } catch {
      setBackupMessage('Browser storage is full. Export a full backup now to protect your data.');
    }
    savePocketwiseSnapshot(snapshot).then(() => setStorageStatus('On-device database active · IndexedDB')).catch(() => setStorageStatus('Browser storage fallback active · export backups regularly'));
  }, [storageReady, txs, loans, auditHistory, coachGoals, coachTasks, customCategories, budgets]);
  const month = new Date().toISOString().slice(0, 7);
  const visible = useMemo(
    () =>
      txs
        .filter(
          t =>
            (period !== 'This month' || t.date.startsWith(month)) &&
            (filter === 'All' || t.category === filter) &&
            (t.title + ' ' + t.category)
              .toLowerCase()
              .includes(query.toLowerCase())
        )
        .sort((a, b) => b.date.localeCompare(a.date)),
    [txs, period, filter, query, month]
  );
  const monthTx = txs.filter(t => t.date.startsWith(month));
  const todayKey = new Date().toISOString().slice(0, 10);
  const sevenDaysAgo = new Date(); sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
  const weekStartKey = sevenDaysAgo.toISOString().slice(0, 10);
  const weekExpenseTx = txs.filter(t => t.type === 'expense' && t.date >= weekStartKey && t.date <= todayKey);
  const weekSpent = weekExpenseTx.reduce((s, t) => s + t.amount, 0);
  const currentWeekKey = weekStartKey;
  const currentCoachTasks = coachTasks.filter(t => t.week === currentWeekKey);
  const completedCoachTasks = currentCoachTasks.filter(t => t.done).length;
  const income = monthTx
    .filter(t => t.type === 'income')
    .reduce((s, t) => s + t.amount, 0);
  const spent = monthTx
    .filter(t => t.type === 'expense')
    .reduce((s, t) => s + t.amount, 0);
  const balance =
    txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0) -
    txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const categoryTotals = cats
    .map(c => ({
      name: c,
      value: monthTx
        .filter(t => t.type === 'expense' && t.category === c)
        .reduce((s, t) => s + t.amount, 0),
    }))
    .filter(c => c.value > 0)
    .sort((a, b) => b.value - a.value);
  const maxCat = Math.max(1, ...categoryTotals.map(c => c.value));
  const monthly = Array.from({ length: 6 }, (_, i) => {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - 5 + i);
    const key = d.toISOString().slice(0, 7);
    return {
      label: d.toLocaleDateString('en-IN', { month: 'short' }),
      value: txs
        .filter(t => t.date.startsWith(key) && t.type === 'expense')
        .reduce((s, t) => s + t.amount, 0),
    };
  });
  const maxMonth = Math.max(1, ...monthly.map(m => m.value));
  function addCustomCategory(e: React.FormEvent) {
    e.preventDefault();
    const name = categoryDraft.trim().replace(/\s+/g, ' ');
    if (!name) { setCategoryNotice('Enter a category name.'); return; }
    if (name.length > 32) { setCategoryNotice('Keep category names to 32 characters or fewer.'); return; }
    if ([...baseCats, ...customCategories].some(c => c.toLowerCase() === name.toLowerCase())) { setCategoryNotice('That category already exists.'); return; }
    setCustomCategories(prev => [...prev, name]);
    setCategory(name);
    setCategoryDraft('');
    setCategoryNotice('Category added and ready to use.');
  }
  function deleteCustomCategory(name: string) {
    if (txs.some(t => t.category === name)) { setCategoryNotice('This category is used by existing transactions. Reassign those transactions before deleting it.'); return; }
    if (confirm('Delete the custom category “' + name + '”?')) {
      setCustomCategories(prev => prev.filter(c => c !== name));
      if (category === name) setCategory('Food');
      if (filter === name) setFilter('All');
      setCategoryNotice('Category deleted.');
    }
  }
  function saveBudget(e: React.FormEvent) {
    e.preventDefault();
    const limit = Number(budgetLimit);
    if (!budgetCategory || !Number.isFinite(limit) || limit <= 0) { setBudgetNotice('Choose a category and enter a monthly limit greater than ₹0.'); return; }
    setBudgets(prev => { const existing = prev.find(b => b.category === budgetCategory); return existing ? prev.map(b => b.category === budgetCategory ? { ...b, limit } : b) : [...prev, { id: crypto.randomUUID(), category: budgetCategory, limit }]; });
    setBudgetLimit(''); setBudgetNotice('Your personalised monthly budget is saved.'); setShowBudgetForm(false);
  }
  function updateBudget(id: string) {
    const limit = Number(editingBudgetLimit);
    if (!Number.isFinite(limit) || limit <= 0) { setBudgetNotice('Enter a monthly limit greater than ₹0.'); return; }
    setBudgets(prev => prev.map(b => b.id === id ? { ...b, limit } : b));
    setEditingBudgetId(null); setEditingBudgetLimit(''); setBudgetNotice('Budget updated.');
  }
  function deleteBudget(id: string) {
    if (confirm('Delete this budget? Your transactions will not be deleted.')) { setBudgets(prev => prev.filter(b => b.id !== id)); setBudgetNotice('Budget deleted.'); }
  }
  function openNewTransaction() { setEditingTxId(null); setKind('expense'); setTitle(''); setAmount(''); setCategory('Food'); setIncomeCategory('Salary'); setCustomIncomeCategory(''); setNote(''); setDate(new Date().toISOString().slice(0,10)); setError(''); setShowAdd(true); }
  function openEditTransaction(tx: Tx) { setEditingTxId(tx.id); setKind(tx.type); setTitle(tx.title); setAmount(String(tx.amount)); setCategory(cats.includes(tx.category) ? tx.category : 'Other'); setIncomeCategory(incomeCategories.includes(tx.category) ? tx.category : 'Other'); setCustomIncomeCategory(incomeCategories.includes(tx.category) ? '' : tx.category); setNote(tx.note || ''); setDate(tx.date); setError(''); setShowAdd(true); }
  function addTx(e: React.FormEvent) {
    e.preventDefault();
    const n = Number(amount);
    if (!title.trim() || !Number.isFinite(n) || n <= 0) { setError('Enter a description and an amount greater than ₹0.'); return; }
    const record: Tx = { id: editingTxId || crypto.randomUUID(), title: title.trim(), category: kind === 'income' ? (incomeCategory === 'Other' && customIncomeCategory.trim() ? customIncomeCategory.trim() : incomeCategory) : category, amount: n, type: kind, date, note: note.trim() };
    setTxs(prev => editingTxId ? prev.map(t => t.id === editingTxId ? record : t) : [record, ...prev]);
    setTitle(''); setAmount(''); setCustomIncomeCategory(''); setNote(''); setError(''); setEditingTxId(null); setShowAdd(false);
  }
  function removeTx(id: string) {
    if (confirm('Delete this transaction?'))
      setTxs(prev => prev.filter(t => t.id !== id));
  }
  function addLoan(e: React.FormEvent) {
    e.preventDefault();
    const n = Number(loanAmount);
    if (!loanPerson.trim() || !Number.isFinite(n) || n <= 0 || !loanDate) { setLoanError('Enter a person, a valid amount, and the date.'); return; }
    setLoans(prev => [{ id: crypto.randomUUID(), person: loanPerson.trim(), amount: n, repaidAmount: 0, repayments: [], date: loanDate, dueDate: loanDueDate, note: loanNote.trim(), status: 'outstanding' }, ...prev]);
    setLoanPerson(''); setLoanAmount(''); setLoanDueDate(''); setLoanNote(''); setLoanError(''); setShowLoan(false);
  }
  function toggleLoan(id: string) { setLoans(prev => prev.map(l => l.id === id ? (l.status === 'repaid' ? { ...l, status: 'outstanding', repaidAmount: 0, repayments: [] } : { ...l, status: 'repaid', repaidAmount: l.amount }) : l)); }
  function recordRepayment(id: string) { const loan = loans.find(l => l.id === id); if (!loan) return; const outstanding = Math.max(0, loan.amount - (loan.repaidAmount || 0)); const raw = prompt('How much did ' + loan.person + ' repay? Outstanding: ' + money(outstanding)); if (raw === null) return; const n = Number(raw); if (!Number.isFinite(n) || n <= 0 || n > outstanding) { alert('Enter a repayment greater than ₹0 and no more than ' + money(outstanding) + '.'); return; } setLoans(prev => prev.map(l => l.id !== id ? l : { ...l, repaidAmount: (l.repaidAmount || 0) + n, repayments: [...(l.repayments || []), { id: crypto.randomUUID(), amount: n, date: new Date().toISOString().slice(0,10) }], status: (l.repaidAmount || 0) + n >= l.amount ? 'repaid' : 'outstanding' })); }
  function deleteLoan(id: string) { if (confirm('Delete this lending record?')) setLoans(prev => prev.filter(l => l.id !== id)); }
  const outstandingLoans = loans.reduce((s, l) => s + Math.max(0, l.amount - (l.repaidAmount ?? (l.status === 'repaid' ? l.amount : 0))), 0);
  async function runAudit(mode = auditMode) {
    setAuditMode(mode);
    setPage('AI Audit');
    setAuditBusy(true);
    setAuditError('');
    setAudit('');
    try {
      // Privacy-first, on-device audit. No transaction data is sent to a third party.
      const relevant = txs;
      const totalIncome = relevant.filter(t => t.type === 'income').reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
      const totalExpenses = relevant.filter(t => t.type === 'expense').reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
      const categorySpend = relevant.filter(t => t.type === 'expense').reduce((acc, t) => {
        const key = t.category || 'Other';
        acc[key] = (acc[key] || 0) + (Number(t.amount) || 0);
        return acc;
      }, {} as Record<string, number>);
      const topCategories = Object.entries(categorySpend).sort((a, b) => b[1] - a[1]).slice(0, 3);
      const net = totalIncome - totalExpenses;
      const savingsRate = totalIncome > 0 ? Math.round((net / totalIncome) * 100) : null;
      const fmt = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
      const categoryLines = topCategories.length
        ? topCategories.map(([name, amount], i) => `${i + 1}. ${name}: ${fmt(amount)} (${totalExpenses > 0 ? Math.round(amount / totalExpenses * 100) : 0}% of recorded expenses)`).join('\n')
        : 'No expense categories recorded yet.';
      const modeAdvice: Record<string, string> = {
        'Full audit': 'Review the largest spending categories and check that all income and expenses have been recorded.',
        'Next-month plan': 'Use the recent recorded spending as a starting point, then set realistic category limits and review them weekly.',
        'Find anomalies': 'Review unusually large entries and possible duplicates manually; this simple local check cannot determine fraud.',
        'Save more': 'Choose one high-spend category and identify one realistic reduction before setting a savings target.',
        'Spending habits': 'Compare category totals across equivalent date ranges before concluding that a habit has changed.',
        'Weekly coach': 'Review the last seven days of entries, correct missing records and choose one small action for the coming week.',
        'Progress check': 'Compare this report with saved reports and confirm completed actions yourself; recommendations do not prove progress.',
        'Monthly review': 'Compare complete months only and check whether income and expense records cover the same period.'
      };
      const report = [
        'QUICK SUMMARY',
        `This on-device summary covers ${relevant.length} recorded transactions and ${loans.length} lending records.`,
        `Recorded income: ${fmt(totalIncome)}\nRecorded expenses: ${fmt(totalExpenses)}\nNet cash flow: ${fmt(net)}`,
        `Savings rate on recorded totals: ${savingsRate === null ? 'Not available (no recorded income)' : `${savingsRate}%`}`,
        '', 'WHAT STANDS OUT', categoryLines,
        '', 'CHECK THESE ITEMS',
        relevant.length ? 'Check for missing entries, duplicates and incorrect dates/categories. These rules do not detect fraud.' : 'Add transactions to get a useful summary.',
        loans.length ? `Lending records: ${loans.length}; outstanding balance: ${fmt(loans.reduce((sum, l) => sum + Math.max(0, l.amount - (l.repaidAmount || 0)), 0))}. Lending is tracked separately from expenses.` : 'No lending records are saved.',
        '', 'ACTION PLAN', modeAdvice[mode] || modeAdvice['Full audit'],
        '', 'IMPORTANT LIMITATIONS',
        'This is a basic rules-based report generated on this device, not an AI-generated financial assessment. It uses only saved records and does not connect to a bank or verify transactions.'
      ].join('\n');
      setAudit(report);
      setAuditHistory(prev => [{ id: crypto.randomUUID(), date: new Date().toISOString(), mode, report, txCount: txs.length }, ...prev].slice(0, 12));
    } catch {
      setAuditError('Could not generate the local report. Please check your saved records and try again.');
    } finally {
      setAuditBusy(false);
    }
  }
  function saveCoachGoals() { const savings = Number(goalSavingsInput); const weekly = Number(goalWeeklyInput); if (goalSavingsInput.trim() && (!Number.isFinite(savings) || savings < 0) || goalWeeklyInput.trim() && (!Number.isFinite(weekly) || weekly < 0)) { setCoachNotice('Enter valid goals of ₹0 or more.'); return; } setCoachGoals({ monthlySavingsGoal: goalSavingsInput.trim() ? savings : coachGoals.monthlySavingsGoal, weeklySpendLimit: goalWeeklyInput.trim() ? weekly : coachGoals.weeklySpendLimit }); setGoalSavingsInput(''); setGoalWeeklyInput(''); setCoachNotice('Your coaching goals are saved on this device.'); }
  function startWeeklyCoach() { const top = categoryTotals[0]; const nextTasks: CoachTask[] = [{ id: crypto.randomUUID(), title: 'Review your spending once this week', detail: 'Compare your recorded spending with your weekly limit and correct missing entries.', done: false, week: currentWeekKey }, { id: crypto.randomUUID(), title: top ? 'Check ' + top.name + ' spending' : 'Categorise new transactions', detail: top ? 'Your largest recorded category this month is ' + top.name + ' at ' + money(top.value) + '. Look for one realistic adjustment.' : 'Add and categorise transactions so the coach has useful evidence.', done: false, week: currentWeekKey }, { id: crypto.randomUUID(), title: 'Review lending and upcoming repayments', detail: 'Check outstanding balances and follow up on any overdue amounts; lending is not an expense.', done: false, week: currentWeekKey }]; setCoachTasks(prev => [...prev.filter(t => t.week !== currentWeekKey), ...nextTasks].slice(-40)); setCoachNotice('Your weekly action checklist is ready. Run the AI coach for a personalised review.'); runAudit('Weekly coach'); }
  function toggleCoachTask(id: string) { setCoachTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t)); }
  function exportFullBackup() { const payload = { app: 'Pocketwise', version: 4, exportedAt: new Date().toISOString(), transactions: txs, lending: loans, customCategories, auditHistory, coachGoals, coachTasks, preferences: { auditMode } }; downloadFile(JSON.stringify(payload, null, 2), 'pocketwise-backup.json', 'application/json'); setBackupMessage('Full backup exported. Keep a copy outside this device.'); }
  async function exportEncryptedBackup() { const pass = prompt('Create a backup password (at least 8 characters). Save it safely; it cannot be recovered.'); if (pass === null) return; if (pass.length < 8) { setBackupMessage('Use a backup password of at least 8 characters.'); return; } setBackupBusy(true); try { const salt = crypto.getRandomValues(new Uint8Array(16)); const iv = crypto.getRandomValues(new Uint8Array(12)); const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']); const key = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt']); const plain = new TextEncoder().encode(JSON.stringify({ app: 'Pocketwise', version: 4, exportedAt: new Date().toISOString(), transactions: txs, lending: loans, customCategories, auditHistory, coachGoals, coachTasks, preferences: { auditMode } })); const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plain); const toB64 = (v: Uint8Array) => btoa(Array.from(v, b => String.fromCharCode(b)).join('')); const packageData = { app: 'Pocketwise encrypted backup', version: 1, kdf: 'PBKDF2-SHA-256', iterations: 250000, cipher: 'AES-GCM-256', salt: toB64(salt), iv: toB64(iv), data: toB64(new Uint8Array(cipher)) }; downloadFile(JSON.stringify(packageData, null, 2), 'pocketwise-encrypted-backup.json', 'application/json'); setBackupMessage('Encrypted backup exported. Without your password, it cannot be restored.'); } catch { setBackupMessage('Could not create the encrypted backup in this browser. Try the regular JSON backup.'); } finally { setBackupBusy(false); } }
  async function importBackup(event: React.ChangeEvent<HTMLInputElement>) { const file = event.target.files?.[0]; if (!file) return; try { const parsed = JSON.parse(await file.text()); let payload = parsed; if (parsed.app === 'Pocketwise encrypted backup') { const pass = prompt('Enter the password used for this encrypted backup.'); if (pass === null) return; const fromB64 = (v: string) => Uint8Array.from(atob(v), c => c.charCodeAt(0)); const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']); const key = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt: fromB64(parsed.salt), iterations: parsed.iterations, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['decrypt']); const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(parsed.iv) }, key, fromB64(parsed.data)); payload = JSON.parse(new TextDecoder().decode(plain)); } if (payload.app !== 'Pocketwise' || !Array.isArray(payload.transactions) || !Array.isArray(payload.lending) || !payload.transactions.every((t: any) => t && typeof t.title === 'string' && Number.isFinite(Number(t.amount)) && Number(t.amount) > 0 && ['income','expense'].includes(t.type) && typeof t.date === 'string') || !payload.lending.every((l: any) => l && typeof l.person === 'string' && Number.isFinite(Number(l.amount)) && Number(l.amount) > 0)) throw new Error('Invalid backup'); if (!confirm('Restore ' + payload.transactions.length + ' transactions, ' + payload.lending.length + ' lending records and ' + (Array.isArray(payload.auditHistory) ? payload.auditHistory.length : 0) + ' saved AI reports? Current data will be replaced.')) return; setTxs(payload.transactions); setLoans(payload.lending.map((l: Loan) => ({ ...l, repaidAmount: l.repaidAmount ?? (l.status === 'repaid' ? l.amount : 0), repayments: l.repayments || [] }))); setCustomCategories(Array.isArray(payload.customCategories) ? payload.customCategories.filter((c: any) => typeof c === 'string' && c.trim() && !baseCats.some(b => b.toLowerCase() === c.toLowerCase())).slice(0, 100) : []); setAuditHistory(Array.isArray(payload.auditHistory) ? payload.auditHistory.slice(0,12) : []); if (payload.coachGoals && Number.isFinite(payload.coachGoals.monthlySavingsGoal) && Number.isFinite(payload.coachGoals.weeklySpendLimit)) setCoachGoals(payload.coachGoals); if (Array.isArray(payload.coachTasks)) setCoachTasks(payload.coachTasks.filter((t: any) => t && typeof t.title === 'string' && typeof t.done === 'boolean').slice(0,40)); if (payload.preferences?.auditMode) setAuditMode(payload.preferences.auditMode); setBackupMessage('Backup restored successfully. Review your totals to confirm everything looks right.'); } catch { setBackupMessage('Restore failed: the file may be invalid or the password may be incorrect. Existing records were not replaced.'); } finally { event.target.value = ''; } }
  function downloadFile(content: string, filename: string, mime: string) { const url = URL.createObjectURL(new Blob([content], { type: mime })); const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
  function exportCsv() {
    const rows = [
      ['Date', 'Description', 'Category', 'Type', 'Amount'],
      ...txs.map(t => [t.date, t.title, t.category, t.type, String(t.amount)]),
    ];
    const csv = rows
      .map(r => r.map(v => '"' + v.replaceAll('"', '""') + '"').join(','))
      .join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'pocketwise-transactions.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  }
  const nav = [
    { name: 'Overview', icon: LayoutDashboard },
    { name: 'Transactions', icon: CreditCard },
    { name: 'Analytics', icon: BarChart3 },
    { name: 'AI Audit', icon: Sparkles },
    { name: 'Coach', icon: BrainCircuit },
    { name: 'Lending', icon: Wallet },
    { name: 'Budgets', icon: Target },
  ];
  return (
    <div className="app-shell">
      <aside className={'sidebar ' + (menu ? 'sidebar-open' : '')}>
        <div className="brand">
          <div className="brand-mark">
            <Wallet size={21} />
          </div>
          <div>
            <b>Pocketwise</b>
            <small>PERSONAL FINANCE</small>
          </div>
          <button
            className="icon-btn close-menu"
            onClick={() => setMenu(false)}
          >
            <X size={18} />
          </button>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav>
          {nav.map(n => (
            <button
              key={n.name}
              className={'nav-item ' + (page === n.name ? 'active' : '')}
              onClick={() => {
                setPage(n.name);
                setMenu(false);
              }}
            >
              <n.icon size={18} />
              <span>{n.name}</span>
              {n.name === 'AI Audit' && <span className="nav-new">AI</span>}
            </button>
          ))}
        </nav>
        <div className="side-bottom">
          <div className="secure-card">
            <div className="secure-icon">
              <ShieldCheck size={18} />
            </div>
            <b>Your money, clearer.</b>
            <p>Private by design. Your entries stay in this browser.</p>
            <span>
              <span className="green-dot" /> Local storage enabled
            </span>
          </div>
          <button className="nav-item" onClick={() => setPage('Settings')}>
            <Settings size={18} />
            Settings
          </button>
          <div className="profile">
            <div className="avatar">P</div>
            <div>
              <b>Personal wallet</b>
              <small>Free workspace</small>
            </div>
            <ChevronDown size={16} />
          </div>
        </div>
      </aside>
      {menu && <div className="scrim" onClick={() => setMenu(false)} />}
      <main className="main">
        <header className="topbar">
          <button
            className="icon-btn mobile-menu"
            onClick={() => setMenu(true)}
          >
            <Menu size={20} />
          </button>
          <div className="crumb">
            Workspace <span>/</span> <b>{page}</b>
          </div>
          <div className="top-actions">
            <div className="date-pill">
              <CalendarDays size={15} />
              {new Date().toLocaleDateString('en-IN', {
                month: 'short',
                year: 'numeric',
              })}
            </div>
            <button className="icon-btn" title="Notifications">
              <Bell size={18} />
              <i />
            </button>
            <div className="avatar small-avatar">P</div>
          </div>
        </header>
        <div className="content">
          {page === 'Overview' && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">YOUR FINANCIAL SNAPSHOT</div>
                  <h1>Your money, at a glance <span className="wave">✦</span></h1>
                  <p className="subheading">A calmer, clearer view of your finances.</p>
                </div>
                <div className="heading-actions">
                  <button className="btn btn-primary add-transaction-cta" onClick={openNewTransaction}>
                    <span className="cta-plus"><Plus size={21} strokeWidth={2.5}/></span>
                    <span className="cta-label"><b>Add transaction</b><small>Record income or an expense</small></span>
                    <ArrowUpRight className="cta-arrow" size={19}/>
                  </button>
                </div>
              </div>
              <div className="hero-card">
                <div className="hero-copy">
                  <div className="hero-label">
                    <span className="hero-dot" /> TOTAL TRACKED BALANCE{' '}
                    <CircleHelp size={14} />
                  </div>
                  <div className="hero-value">{money(balance)}</div>
                  <div className="hero-caption">
                    Across all recorded transactions
                  </div>
                  <div className="hero-foot">
                    <span className="hero-positive">
                      <TrendingUp size={14} />{' '}
                      {income
                        ? Math.round(((income - spent) / income) * 100)
                        : 0}
                      %
                    </span>
                    <span> monthly savings rate</span>
                  </div>
                </div>
                <div className="hero-art">
                  <div className="orbit orbit-one" />
                  <div className="orbit orbit-two" />
                  <div className="art-coin">
                    <Wallet size={30} />
                  </div>
                  <div className="art-spark">✦</div>
                  <div className="art-mini">₹</div>
                </div>
              </div>
              <div className="brain-card"><div className="brain-icon"><BrainCircuit size={23}/></div><div className="brain-copy"><span>POCKETWISE FINANCIAL BRAIN</span><b>{auditHistory.length ? 'Your money story is building.' : 'Your financial memory starts here.'}</b><p>{auditHistory.length ? 'I have ' + auditHistory.length + ' saved local audit reports to compare trends and recommendations.' : 'Run your first audit to save a baseline, then compare future months and track progress.'}</p></div><div className="brain-actions"><button className="btn btn-light" onClick={() => auditHistory[0] ? (setAudit(auditHistory[0].report), setAuditMode(auditHistory[0].mode), setPage('AI Audit')) : runAudit('Full audit')}>{auditHistory.length ? 'View last report' : 'Build baseline'}</button><button className="btn btn-glass" onClick={() => setPage('Coach')}>Open money coach ↗</button></div></div>
              <section className="coach-spotlight"><div className="coach-spotlight-top"><div className="coach-icon"><CalendarCheck size={21}/></div><div className="coach-spotlight-copy"><span>YOUR WEEKLY MONEY CHECK-IN</span><b>{coachGoals.weeklySpendLimit > 0 && weekSpent > coachGoals.weeklySpendLimit ? 'You are above your weekly spending guardrail' : 'Small weekly actions build better money habits'}</b><p>{money(weekSpent)} spent in the last 7 days{coachGoals.weeklySpendLimit > 0 ? ' · ' + money(Math.max(0, coachGoals.weeklySpendLimit-weekSpent)) + ' left in your weekly guardrail' : ' · Set a weekly guardrail to track your pace'}</p></div><button className="btn btn-secondary" onClick={() => setPage('Coach')}>Open coach</button></div><div className="coach-progress"><span style={{width: (coachGoals.weeklySpendLimit > 0 ? Math.min(100, weekSpent/coachGoals.weeklySpendLimit*100) : 0)+'%'}}/></div><div className="coach-foot"><span>{completedCoachTasks}/{currentCoachTasks.length} weekly actions complete</span><button className="text-link" onClick={startWeeklyCoach}>Refresh weekly plan ↗</button></div></section>
              <div className="stat-grid">
                <Stat
                  title="Income this month"
                  value={money(income)}
                  icon={<ArrowDownLeft size={18} />}
                  tone="mint"
                  note="Money coming in"
                />
                <Stat
                  title="Spent this month"
                  value={money(spent)}
                  icon={<ArrowUpRight size={18} />}
                  tone="rose"
                  note="Money going out"
                />
                <Stat
                  title="Net cash flow"
                  value={money(income - spent)}
                  icon={<Activity size={18} />}
                  tone="violet"
                  note={
                    income >= spent
                      ? 'In the positive'
                      : 'Spending exceeds income'
                  }
                />
              </div>
              <div className="section-grid">
                <section className="panel chart-panel">
                  <div className="panel-head">
                    <div>
                      <h2>Spending overview</h2>
                      <p>Six-month expense trend</p>
                    </div>
                    <span className="mini-tag">
                      <span className="green-dot" /> Updated
                    </span>
                  </div>
                  <div className="chart-legend">
                    <span>
                      <i className="legend-dot purple" /> Expenses
                    </span>
                    <span className="chart-unit">Amount in INR</span>
                  </div>
                  <div className="bar-chart">
                    {monthly.map((m, i) => (
                      <div className="bar-column" key={m.label}>
                        <div className="bar-track">
                          <div
                            className={'bar ' + (i === 5 ? 'bar-current' : '')}
                            style={{
                              height:
                                Math.max(4, (m.value / maxMonth) * 100) + '%',
                            }}
                            title={money(m.value)}
                          />
                        </div>
                        <span>{m.label}</span>
                      </div>
                    ))}
                  </div>
                  <div className="chart-foot">
                    <span>Current month</span>
                    <b>{money(spent)}</b>
                  </div>
                </section>
                <section className="panel category-panel">
                  <div className="panel-head">
                    <div>
                      <h2>Where it goes</h2>
                      <p>Spending by category</p>
                    </div>
                    <button
                      className="text-link"
                      onClick={() => setPage('Analytics')}
                    >
                      Details <span>↗</span>
                    </button>
                  </div>
                  {categoryTotals.length ? (
                    <div className="category-list">
                      {categoryTotals.slice(0, 5).map((c, i) => (
                        <div className="category-row" key={c.name}>
                          <div className={'category-icon cat-' + (i % 5)}>
                            {categoryIcon(c.name)}
                          </div>
                          <div className="category-info">
                            <div>
                              <b>{c.name}</b>
                              <span>
                                {Math.round(
                                  (c.value / Math.max(1, spent)) * 100
                                )}
                                %
                              </span>
                            </div>
                            <div className="progress">
                              <i
                                style={{
                                  width: (c.value / maxCat) * 100 + '%',
                                }}
                              />
                            </div>
                          </div>
                          <strong>{money(c.value)}</strong>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <Empty text="Add expenses to see your category breakdown." />
                  )}
                </section>
              </div>
              <section className="panel transactions-panel">
                <div className="panel-head">
                  <div>
                    <h2>Recent transactions</h2>
                    <p>Your latest money moves</p>
                  </div>
                  <button
                    className="text-link"
                    onClick={() => setPage('Transactions')}
                  >
                    View all <span>↗</span>
                  </button>
                </div>
                <TxList
                  txs={txs
                    .slice()
                    .sort((a, b) => b.date.localeCompare(a.date))
                    .slice(0, 5)}
                  onDelete={removeTx}
                  onEdit={openEditTransaction}
                />
              </section>
              <div className="ai-banner">
                <div className="ai-badge">
                  <Sparkles size={21} />
                </div>
                <div>
                  <b>Your personal AI money analyst</b>
                  <p>
                    Spot spending patterns, unusual expenses and practical ways
                    to save.
                  </p>
                </div>
                <button className="btn btn-light" onClick={runAudit}>
                  Run a money audit <ArrowUpRight size={16} />
                </button>
              </div>
            </>
          )}
          {page === 'Transactions' && (
            <>
              <PageHead
                title="Transactions"
                sub="Every rupee, accounted for."
                action={
                  <button
                    className="btn btn-primary"
                    onClick={openNewTransaction}
                  >
                    <Plus size={17} /> Add transaction
                  </button>
                }
              />
              <div className="toolbar">
                <div className="search-box">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    placeholder="Search transactions..."
                  />
                </div>
                <select
                  value={filter}
                  onChange={e => setFilter(e.target.value)}
                >
                  <option>All</option>
                  {['Income', ...cats].map(c => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
                <select
                  value={period}
                  onChange={e => setPeriod(e.target.value)}
                >
                  <option>This month</option>
                  <option>All time</option>
                </select>
                <button className="btn btn-secondary" onClick={exportCsv}>
                  <Download size={16} /> CSV
                </button>
              </div>
              <section className="panel transactions-panel">
                <div className="panel-head">
                  <div>
                    <h2>All transactions</h2>
                    <p>{visible.length} records found</p>
                  </div>
                  <span className="mini-tag">
                    <Filter size={13} /> {filter}
                  </span>
                </div>
                <TxList txs={visible} onDelete={removeTx} />
                {!visible.length && (
                  <Empty text="No transactions match. Try a different search or add a transaction." />
                )}
              </section>
            </>
          )}
          {page === 'Analytics' && (
            <>
              <PageHead
                title="Analytics"
                sub="Patterns, not guesswork. Understand where your money moves."
                action={
                  <button className="btn btn-secondary" onClick={exportCsv}>
                    <Download size={16} /> Export data
                  </button>
                }
              />
              <div className="stat-grid">
                <Stat
                  title="Total income"
                  value={money(income)}
                  icon={<ArrowDownLeft size={18} />}
                  tone="mint"
                  note="Current month"
                />
                <Stat
                  title="Total expenses"
                  value={money(spent)}
                  icon={<ArrowUpRight size={18} />}
                  tone="rose"
                  note="Current month"
                />
                <Stat
                  title="Savings ratio"
                  value={
                    (income
                      ? Math.max(0, ((income - spent) / income) * 100)
                      : 0
                    ).toFixed(0) + '%'
                  }
                  icon={<Target size={18} />}
                  tone="violet"
                  note="Income retained"
                />
              </div>
              <div className="section-grid">
                <section className="panel chart-panel">
                  <div className="panel-head">
                    <div>
                      <h2>Monthly trend</h2>
                      <p>Expense totals by month</p>
                    </div>
                  </div>
                  <div className="bar-chart tall">
                    {monthly.map(m => (
                      <div className="bar-column" key={m.label}>
                        <b className="bar-number">
                          {m.value ? Math.round(m.value / 100) / 10 + 'k' : '—'}
                        </b>
                        <div className="bar-track">
                          <div
                            className="bar"
                            style={{
                              height:
                                Math.max(3, (m.value / maxMonth) * 100) + '%',
                            }}
                          />
                        </div>
                        <span>{m.label}</span>
                      </div>
                    ))}
                  </div>
                </section>
                <section className="panel category-panel">
                  <div className="panel-head">
                    <div>
                      <h2>Category breakdown</h2>
                      <p>Current month expenses</p>
                    </div>
                  </div>
                  {categoryTotals.length ? (
                    categoryTotals.map(c => (
                      <div className="analysis-cat" key={c.name}>
                        <div>
                          <span>{c.name}</span>
                          <b>{money(c.value)}</b>
                        </div>
                        <div className="progress">
                          <i
                            style={{ width: (c.value / maxCat) * 100 + '%' }}
                          />
                        </div>
                      </div>
                    ))
                  ) : (
                    <Empty text="Add expenses to unlock your breakdown." />
                  )}
                </section>
              </div>
              <section className="panel analysis-extra"><div className="panel-head"><div><h2>Money health checks</h2><p>More context for this month's decisions</p></div></div><div className="health-grid"><div><span>Daily spend average</span><b>{money(spent / Math.max(1, new Date().getDate()))}</b><small>Month-to-date estimate</small></div><div><span>Largest category</span><b>{categoryTotals[0]?.name || 'No data'}</b><small>{categoryTotals[0] ? money(categoryTotals[0].value) + ' spent' : 'Add expenses to compare'}</small></div><div><span>Previous month</span><b>{money(txs.filter(t => t.type === 'expense' && t.date.startsWith((() => { const d=new Date(); d.setDate(1); d.setMonth(d.getMonth()-1); return d.toISOString().slice(0,7); })())).reduce((s,t)=>s+t.amount,0))}</b><small>Use as a month-to-month baseline</small></div><div><span>Money lent separately</span><b>{money(outstandingLoans)}</b><small>Excluded from spending analytics</small></div></div></section>
              <section className="panel insight-panel">
                <div className="insight-icon">
                  <Sparkles size={18} />
                </div>
                <div>
                  <h2>Want deeper insights?</h2>
                  <p>
                    Ask AI to review your transactions for unusual patterns,
                    recurring costs and realistic savings opportunities.
                  </p>
                </div>
                <button className="btn btn-primary" onClick={runAudit}>
                  Analyse my spending
                </button>
              </section>
            </>
          )}
          {page === 'Coach' && (
            <>
              <PageHead title="Your proactive money coach" sub="Build better habits with weekly check-ins, goals, and actions you can actually complete." action={<button className="btn btn-primary" onClick={startWeeklyCoach} disabled={auditBusy}><Sparkles size={16}/>{auditBusy ? 'Preparing…' : 'Run weekly check-in'}</button>} />
              <section className="coach-hero"><div className="coach-hero-orb"><BrainCircuit size={27}/></div><div className="coach-hero-copy"><span>POCKETWISE COACH · YOUR PERSONAL FINANCE ROUTINE</span><h2>Progress, not perfection.</h2><p>The coach uses your recorded transactions, previous reports, goals, and action checklist to suggest practical next steps. It never moves money or changes your records.</p><div className="coach-hero-actions"><button className="btn btn-light" onClick={() => runAudit('Weekly coach')} disabled={auditBusy}><Sparkles size={15}/> Generate AI review</button><button className="btn btn-glass" onClick={() => runAudit('Progress check')} disabled={auditBusy}><Activity size={15}/> Check progress</button></div></div></section>
              <div className="coach-metric-grid"><div className="coach-metric"><span><CalendarCheck size={15}/> LAST 7 DAYS</span><b>{money(weekSpent)}</b><small>{weekExpenseTx.length} recorded expense entries</small></div><div className="coach-metric"><span><CircleDollarSign size={15}/> MONTHLY SAVINGS GOAL</span><b>{coachGoals.monthlySavingsGoal ? money(coachGoals.monthlySavingsGoal) : 'Not set'}</b><small>{income >= spent ? money(income-spent)+' current net cash flow' : money(spent-income)+' cash-flow gap this month'}</small></div><div className="coach-metric"><span><ListChecks size={15}/> WEEKLY FOLLOW-THROUGH</span><b>{currentCoachTasks.length ? Math.round(completedCoachTasks/currentCoachTasks.length*100)+'%' : '—'}</b><small>{completedCoachTasks} of {currentCoachTasks.length} actions checked off</small></div></div>
              <div className="section-grid coach-layout"><section className="panel coach-goals-panel"><div className="panel-head"><div><h2><Target size={17}/> Your guardrails</h2><p>Set your own goals; leave a field blank to keep its current value.</p></div></div><form className="coach-goal-form" onSubmit={e => { e.preventDefault(); saveCoachGoals(); }}><label>Monthly savings goal (₹)<input type="number" min="0" step="1" value={goalSavingsInput} onChange={e=>setGoalSavingsInput(e.target.value)} placeholder={coachGoals.monthlySavingsGoal ? String(coachGoals.monthlySavingsGoal) : 'e.g. 2000'}/></label><label>Weekly spending guardrail (₹)<input type="number" min="0" step="1" value={goalWeeklyInput} onChange={e=>setGoalWeeklyInput(e.target.value)} placeholder={coachGoals.weeklySpendLimit ? String(coachGoals.weeklySpendLimit) : 'e.g. 1500'}/></label><button className="btn btn-primary" type="submit"><Check size={15}/> Save goals</button>{coachNotice && <p className="coach-notice" role="status">{coachNotice}</p>}</form><div className="coach-guardrail"><div className="guardrail-label"><span>Weekly spending pace</span><b>{coachGoals.weeklySpendLimit > 0 ? Math.round(weekSpent/coachGoals.weeklySpendLimit*100)+'%' : 'Set a limit'}</b></div><div className="coach-progress"><span className={coachGoals.weeklySpendLimit > 0 && weekSpent > coachGoals.weeklySpendLimit ? 'over-limit' : ''} style={{width:(coachGoals.weeklySpendLimit>0?Math.min(100,weekSpent/coachGoals.weeklySpendLimit*100):0)+'%'}}/></div><small>{coachGoals.weeklySpendLimit > 0 ? (weekSpent > coachGoals.weeklySpendLimit ? 'Over guardrail by '+money(weekSpent-coachGoals.weeklySpendLimit) : money(coachGoals.weeklySpendLimit-weekSpent)+' remaining') : 'A guardrail makes the weekly review more useful.'}</small></div></section>
              <section className="panel coach-actions-panel"><div className="panel-head"><div><h2><ListChecks size={17}/> Weekly action checklist</h2><p>Mark actions complete as you follow through.</p></div><span className="mini-tag">{completedCoachTasks}/{currentCoachTasks.length}</span></div>{currentCoachTasks.length ? <div className="coach-task-list">{currentCoachTasks.map(task => <label key={task.id} className={'coach-task '+(task.done?'is-done':'')}><input type="checkbox" checked={task.done} onChange={() => toggleCoachTask(task.id)}/><span className="coach-task-check"><CheckCircle2 size={17}/></span><span className="coach-task-text"><b>{task.title}</b><small>{task.detail}</small></span></label>)}</div> : <div className="coach-empty"><div className="coach-empty-icon"><ListChecks size={22}/></div><b>Your first weekly plan is one tap away</b><p>Generate a coach check-in to create a practical checklist and a personalised AI review.</p><button className="btn btn-primary" onClick={startWeeklyCoach} disabled={auditBusy}>Create weekly plan</button></div>}</section></div>
              <section className="panel coach-insights-panel"><div className="panel-head"><div><h2><Lightbulb size={17}/> Latest coaching insight</h2><p>Based on your most recent saved report.</p></div><button className="btn btn-secondary" onClick={() => auditHistory[0] ? (setAudit(auditHistory[0].report),setAuditMode(auditHistory[0].mode),setPage('AI Audit')) : runAudit('Weekly coach')}>{auditHistory.length ? 'Open latest report' : 'Generate first insight'}</button></div>{auditHistory.length ? <div className="coach-latest-report"><span className="coach-report-label">{auditHistory[0].mode} · {new Date(auditHistory[0].date).toLocaleDateString('en-IN',{dateStyle:'medium'})}</span><p>{auditHistory[0].report.slice(0,700)}{auditHistory[0].report.length>700?'…':''}</p></div> : <p className="coach-muted">No coaching report yet. Run a weekly check-in to get your first personalised review.</p>}</section>
              <p className="disclaimer">Coaching suggestions are educational estimates based on the records you enter. They are not financial advice. Missing transactions can change the results; lending principal is tracked separately from expenses.</p>
            </>
          )}
          {page === 'AI Audit' && (
            <>
              <PageHead
                title="AI money audit"
                sub="A second set of eyes on your spending — powered by AI."
                action={
                  <button
                    className="btn btn-primary"
                    onClick={runAudit}
                    disabled={auditBusy}
                  >
                    <Sparkles size={16} />
                    {auditBusy ? 'Analysing…' : 'Run new audit'}
                  </button>
                }
              />
              <div className="audit-hero">
                <div className="audit-orb">
                  <Sparkles size={28} />
                </div>
                <div>
                  <span className="audit-kicker">POCKETWISE INTELLIGENCE</span>
                  <h2>Make your money make sense.</h2>
                  <p>
                    Review your transaction data for spending patterns,
                    potential anomalies, and practical ways to improve cash
                    flow.
                  </p>
                </div>
              </div>
              <div className="audit-grid">
                <div className="audit-feature">
                  <div className="feature-icon purple-bg">
                    <Activity size={18} />
                  </div>
                  <b>Pattern detection</b>
                  <p>
                    Find your biggest spending categories and changes over time.
                  </p>
                </div>
                <div className="audit-feature">
                  <div className="feature-icon mint-bg">
                    <ShieldCheck size={18} />
                  </div>
                  <b>Unusual activity</b>
                  <p>Flag transactions that may deserve a second look.</p>
                </div>
                <div className="audit-feature">
                  <div className="feature-icon amber-bg">
                    <Target size={18} />
                  </div>
                  <b>Action plan</b>
                  <p>Get realistic, prioritised savings suggestions.</p>
                </div>
              </div>
              <div className="audit-mode-tabs">{['Full audit','Next-month plan','Find anomalies','Save more','Spending habits'].map(mode => <button key={mode} className={auditMode === mode ? 'active' : ''} onClick={() => setAuditMode(mode)}>{mode}</button>)}</div>
              <div className="brain-memory-strip"><BrainCircuit size={17}/><span><b>Financial brain memory</b> · {auditHistory.length} reports saved locally. New audits can compare recent findings and past plans.</span><button className="text-link" onClick={() => auditHistory[0] ? setAudit(auditHistory[0].report) : runAudit('Full audit')}>Latest memory ↗</button></div>
              <section className="panel audit-result">
                <div className="panel-head">
                  <div>
                    <h2>
                      <Sparkles size={17} /> Your audit report
                    </h2>
                    <p>Based on {txs.length} recorded transactions</p>
                  </div>
                  <span className="mini-tag">AI assisted</span>
                </div>
                {auditBusy ? (
                  <div className="loading-state">
                    <div className="spinner" />
                    <b>Reviewing your money patterns…</b>
                    <p>Comparing categories, cash flow and unusual entries.</p>
                  </div>
                ) : auditError ? (
                  <div className="error-state">
                    <p>{auditError}</p>
                    <button className="btn btn-secondary" onClick={runAudit}>
                      Try again
                    </button>
                  </div>
                ) : audit ? (
                  <div className="audit-sections">{audit.split(/\n(?=(?:QUICK SUMMARY|WHAT STANDS OUT|CHECK THESE ITEMS|ACTION PLAN|NEXT-MONTH PLAN|PRIORITY ACTIONS|POTENTIAL ANOMALIES|SAVINGS OPPORTUNITIES|SPENDING HABITS|IMPORTANT LIMITATIONS|\d+\.)\s*:??)/i).filter(s=>s.trim()).map((section,i)=>{const lines=section.trim().split('\n'); const heading=lines[0].replace(/^#+\s*/,'').replace(/:$/,''); return <details className="audit-report-section" key={i} open={i===0}><summary><span className="report-number">{String(i+1).padStart(2,'0')}</span><b>{heading}</b><ChevronDown size={16}/></summary><div className="report-body">{lines.slice(1).join('\n').trim() || section.trim()}</div></details>})}<div className="audit-next-step"><Sparkles size={18}/><div><b>Turn this report into a plan</b><p>Choose a focus to refresh the report using your current transactions and lending records.</p></div><button className="btn btn-primary" onClick={()=>runAudit('Next-month plan')}>Build next-month plan</button></div></div>
                ) : (
                  <div className="empty-audit">
                    <div className="ai-badge">
                      <Sparkles size={22} />
                    </div>
                    <h3>Your financial check-up is ready</h3>
                    <p>
                      Run an audit to receive personalised observations and
                      practical next steps from your recorded data.
                    </p>
                    <button className="btn btn-primary" onClick={() => runAudit(auditMode)}>
                      <Sparkles size={16} /> Start {auditMode.toLowerCase()}
                    </button>
                  </div>
                )}
                {auditHistory.length > 0 && <div className="audit-history"><div className="panel-head"><div><h2><History size={16}/> Recent reports</h2><p>Stored on this device · newest first</p></div></div>{auditHistory.slice(0,5).map(item => <button className="history-item" key={item.id} onClick={() => { setAudit(item.report); setAuditMode(item.mode); }}><span className="history-dot"><BrainCircuit size={15}/></span><span className="history-copy"><b>{item.mode}</b><small>{new Date(item.date).toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'})} · {item.txCount} transactions</small></span><span className="history-open">Open ↗</span></button>)}</div>}
                <p className="disclaimer">
                  AI insights are estimates, not professional financial advice.
                  Verify flagged transactions yourself; the AI does not move
                  money or change records.
                </p>
              </section>
            </>
          )}
          {page === 'Lending' && (
            <>
              <PageHead title="Lending & repayments" sub="Track money you lend to people separately from everyday expenses." action={<button className="btn btn-primary" onClick={() => setShowLoan(true)}><Plus size={17}/> Record money lent</button>} />
              <div className="lending-toolbar"><div className="search-box"><Search size={17}/><input value={lendingSearch} onChange={e=>setLendingSearch(e.target.value)} placeholder="Search people or notes…"/></div><select value={lendingFilter} onChange={e=>setLendingFilter(e.target.value)}><option>All</option><option>Outstanding</option><option>Overdue</option><option>Repaid</option></select><button className="btn btn-primary lending-add" onClick={()=>setShowLoan(true)}><Plus size={17}/> Add lending</button></div>
              <div className="stat-grid">
                <Stat title="Still owed to you" value={money(outstandingLoans)} icon={<ArrowDownLeft size={18}/>} tone="violet" note="Outstanding principal, not an expense" />
                <Stat title="Open records" value={String(loans.filter(l => l.status === 'outstanding').length)} icon={<Activity size={18}/>} tone="mint" note="People who still owe you" />
                <Stat title="Repaid records" value={String(loans.filter(l => l.status === 'repaid').length)} icon={<Check size={18}/>} tone="rose" note="Marked as returned" />
              </div>
              <section className="panel transactions-panel">
                <div className="panel-head"><div><h2>People & repayments</h2><p>{loans.length} lending records · tracked separately from expenses</p></div><span className="mini-tag">Not an expense</span></div>
                {loans.filter(l => { const repaid = Math.min(l.amount, l.repaidAmount ?? (l.status === 'repaid' ? l.amount : 0)); const due = Math.max(0,l.amount-repaid); const overdue = due>0 && !!l.dueDate && l.dueDate<todayKey; const match=(l.person+' '+l.note).toLowerCase().includes(lendingSearch.toLowerCase()); return match && (lendingFilter==='All' || (lendingFilter==='Repaid' ? due===0 : lendingFilter==='Overdue' ? overdue : due>0)); }).length ? <div className="tx-list">{loans.filter(l => { const repaid=Math.min(l.amount,l.repaidAmount ?? (l.status==='repaid'?l.amount:0)); const due=Math.max(0,l.amount-repaid); const overdue=due>0 && !!l.dueDate && l.dueDate<todayKey; return (l.person+' '+l.note).toLowerCase().includes(lendingSearch.toLowerCase()) && (lendingFilter==='All' || (lendingFilter==='Repaid'?due===0:lendingFilter==='Overdue'?overdue:due>0)); }).slice().sort((a,b)=>b.date.localeCompare(a.date)).map(l => { const repaid=Math.min(l.amount,l.repaidAmount ?? (l.status==='repaid'?l.amount:0)); const due=Math.max(0,l.amount-repaid); const overdue=due>0 && !!l.dueDate && l.dueDate<todayKey; return <div className="loan-row" key={l.id}><div className={'tx-icon '+(due===0?'tx-income':'tx-expense')}><Wallet size={18}/></div><div className="tx-details"><b>{l.person}</b><span>Lent {new Date(l.date+'T12:00:00').toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})}{l.dueDate?' · Due '+new Date(l.dueDate+'T12:00:00').toLocaleDateString('en-IN',{day:'numeric',month:'short'}):''}</span>{l.note&&<small>{l.note}</small>}<span className={overdue?'loan-overdue':''}>{overdue?'Overdue · follow up':due===0?'Fully repaid':repaid>0?money(repaid)+' repaid · '+money(due)+' remaining':'Awaiting repayment'}</span><div className="loan-progress"><i style={{width:(repaid/Math.max(1,l.amount)*100)+'%'}}/></div></div><strong>{money(due)}<small className="loan-original"> of {money(l.amount)}</small></strong><div className="loan-actions">{due>0&&<button className="btn btn-secondary" onClick={()=>recordRepayment(l.id)}>＋ Repayment</button>}{due>0&&<button className="btn btn-secondary" onClick={()=>toggleLoan(l.id)}>Mark repaid</button>}{due===0&&<button className="btn btn-secondary" onClick={()=>toggleLoan(l.id)}>Reopen</button>}<button className="delete-btn" title="Delete record" onClick={()=>deleteLoan(l.id)}><Trash2 size={15}/></button></div></div>; })}</div> : <Empty text={loans.length ? 'No lending records match these filters. Try another search or status.' : 'No lending records yet. Tap Add lending to record money you lend.'}/>}
              </section>
              <p className="disclaimer">Lending principal and partial repayments are tracked separately and do not become expense or income entries automatically.</p>
            </>
          )}
          {page === 'Budgets' && (
            <>
              <PageHead title="Budgets" sub="Give every category a clear spending limit." action={<button className="btn btn-primary" onClick={()=>setShowBudgetForm(v=>!v)}><Plus size={18}/>{showBudgetForm?'Close':'Add budget'}</button>} />
              <div className="budget-intro"><Target size={24}/><div><b>Your personalised monthly budgets</b><p>Set limits that fit your income and priorities. Budgets are saved on this device and can be changed or removed any time.</p></div></div>
              {showBudgetForm && <section className="panel budget-builder budget-builder-open"><div className="panel-head"><div><h2><Plus size={18}/> Create a budget</h2><p>Set a monthly cap and track spending as you go.</p></div></div><form className="budget-create-form" onSubmit={saveBudget}><label>Expense category<select value={budgetCategory} onChange={e=>setBudgetCategory(e.target.value)}>{cats.map(c=><option key={c} value={c}>{c}</option>)}</select></label><label>Monthly limit (₹)<input type="number" min="1" step="1" value={budgetLimit} onChange={e=>setBudgetLimit(e.target.value)} placeholder="e.g. 2500" required/></label><button className="btn btn-primary" type="submit"><Check size={16}/> Save budget</button></form><p className="budget-helper">Already have this category? Saving updates its limit instead of creating a duplicate.</p>{budgetNotice&&<div className="backup-message" role="status">{budgetNotice}</div>}</section>}
              {budgets.length>0 && <section className="budget-summary-strip"><div><span>Monthly budget total</span><b>{money(budgets.reduce((s,b)=>s+b.limit,0))}</b></div><div><span>Tracked spending</span><b>{money(budgets.reduce((s,b)=>s+monthTx.filter(t=>t.type==='expense'&&t.category===b.category).reduce((a,t)=>a+t.amount,0),0))}</b></div><div><span>Categories tracked</span><b>{budgets.length}</b></div></section>}
              {budgets.length ? <div className="budget-list">{budgets.map((b, i) => { const value = monthTx.filter(t => t.type === 'expense' && t.category === b.category).reduce((sum, t) => sum + t.amount, 0); const remaining = b.limit - value; return <div className="panel budget-card" key={b.id}><div className={'category-icon cat-' + (i % 5)}>{categoryIcon(b.category)}</div><div className="budget-main"><div className="budget-label"><b>{b.category}</b><span>{money(value)} <small>of {money(b.limit)}</small></span></div><div className="progress"><i className={remaining < 0 ? 'over-budget' : ''} style={{width: Math.min(100, value / b.limit * 100) + '%'}}/></div><small>{remaining < 0 ? 'Over budget by ' + money(-remaining) : money(remaining) + ' remaining this month'}</small>{editingBudgetId === b.id && <div className="budget-edit-row"><label>New monthly limit (₹)<input type="number" min="1" step="1" value={editingBudgetLimit} onChange={e => setEditingBudgetLimit(e.target.value)}/></label><button className="btn btn-primary" type="button" onClick={() => updateBudget(b.id)}>Save change</button><button className="btn btn-secondary" type="button" onClick={() => {setEditingBudgetId(null); setEditingBudgetLimit('');}}>Cancel</button></div>}<div className="budget-actions"><button className="btn btn-secondary" type="button" onClick={() => {setEditingBudgetId(b.id); setEditingBudgetLimit(String(b.limit));}}>Edit limit</button><button className="btn btn-danger" type="button" onClick={() => deleteBudget(b.id)}><Trash2 size={14}/> Delete budget</button></div></div></div>;})}</div> : <section className="panel budget-empty"><Target size={25}/><b>No personalised budgets yet</b><p>Create your first monthly budget above. For example, set Food to ₹2,500 and Transport to ₹1,000—or use amounts that match your finances.</p></section>}
            </>
          )}
          {page === 'Profile' && (
            <>
              <section className="profile-hero panel"><div className="profile-cover-glow"/><div className="profile-avatar-large">{(profileName.trim() || 'P').slice(0,1).toUpperCase()}</div><div className="profile-hero-copy"><span className="eyebrow">YOUR POCKETWISE</span><h1>{profileName}</h1><p>Your money, your goals, all in one place.</p><div className="profile-tags"><span><ShieldCheck size={13}/> Private on this device</span><span><Wallet size={13}/> Personal finance</span></div></div><button className="btn btn-secondary profile-settings-btn" onClick={()=>{setProfileNameDraft(profileName);setEditingProfileName(v=>!v);setProfileNotice('');}}><UserRound size={16}/> {editingProfileName?'Close':'Edit profile'}</button></section>
              {editingProfileName && <section className="panel profile-name-editor"><div className="profile-editor-icon"><UserRound size={20}/></div><div className="profile-editor-copy"><h2>What should we call you?</h2><p>Your display name is used on your Profile page and stays saved on this device.</p><form className="profile-name-form" onSubmit={e=>{e.preventDefault();const next=profileNameDraft.trim();if(!next){setProfileNotice('Please enter a name.');return;}setProfileName(next);setProfileNameDraft(next);setEditingProfileName(false);setProfileNotice('Your profile name has been updated.');}}><label htmlFor="profile-name-input">Display name</label><input id="profile-name-input" value={profileNameDraft} onChange={e=>setProfileNameDraft(e.target.value)} maxLength={48} placeholder="Enter your name" required/><button className="btn btn-primary" type="submit"><Check size={16}/> Save name</button></form>{profileNotice&&<p className="profile-notice" role="status">{profileNotice}</p>}</div></section>}
              {!editingProfileName && profileNotice && <p className="profile-notice" role="status">{profileNotice}</p>}
              <div className="profile-stats-grid"><div className="panel profile-stat"><span>Tracked balance</span><b>{money(balance)}</b><small>Across all recorded transactions</small></div><div className="panel profile-stat"><span>Monthly income</span><b>{money(income)}</b><small>Money recorded this month</small></div><div className="panel profile-stat"><span>Monthly expenses</span><b>{money(spent)}</b><small>{income>=spent?'Within recorded cash flow':'Above recorded income'}</small></div><div className="panel profile-stat"><span>Still owed to you</span><b>{money(outstandingLoans)}</b><small>Tracked separately from expenses</small></div></div>
              <section className="panel profile-links"><div className="panel-head"><div><h2>Your finance tools</h2><p>Jump directly to the part of PocketWise you need.</p></div></div><div className="profile-tool-grid"><button onClick={()=>setPage('AI Audit')}><span className="profile-tool-icon"><Sparkles size={19}/></span><span><b>AI Money Audit</b><small>{auditHistory.length} saved reports</small></span><ArrowUpRight size={16}/></button><button onClick={()=>setPage('Coach')}><span className="profile-tool-icon"><BrainCircuit size={19}/></span><span><b>Money Coach</b><small>Goals and weekly actions</small></span><ArrowUpRight size={16}/></button><button onClick={()=>setPage('Lending')}><span className="profile-tool-icon"><Wallet size={19}/></span><span><b>Lending & repayments</b><small>{loans.length} records</small></span><ArrowUpRight size={16}/></button><button onClick={()=>setPage('Budgets')}><span className="profile-tool-icon"><Target size={19}/></span><span><b>Budgets</b><small>{budgets.length} active category limits</small></span><ArrowUpRight size={16}/></button></div></section>
              <section className="panel profile-data-card"><div><span className="profile-tool-icon"><ShieldCheck size={20}/></span><div><h2>Data safety & privacy</h2><p>{storageStatus}. Your records are stored on this device; they do not automatically sync between devices.</p></div></div><div className="backup-actions"><button className="btn btn-primary" onClick={exportFullBackup}><FileJson size={16}/> Export backup</button><button className="btn btn-secondary" onClick={()=>setPage('Settings')}>Privacy & settings <ArrowUpRight size={15}/></button></div></section>
            </>
          )}
          {page === 'Settings' && (
            <>
              <PageHead title="Settings" sub="Simple controls for your profile, privacy and data." />
              <section className="panel settings-panel">
                <div className="settings-welcome"><span className="settings-welcome-icon"><Settings size={20}/></span><div><h2>Make PocketWise yours</h2><p>Choose a setting below. Your changes stay on this device.</p></div></div>
                <div className="settings-divider" />
                <h2><UserRound size={16}/> Profile name</h2><p>Choose the name shown on your Profile page.</p><form className="settings-profile-form" onSubmit={e=>{e.preventDefault();const next=profileNameDraft.trim();if(!next)return;setProfileName(next);setProfileNameDraft(next);setProfileNotice('Profile name saved.');}}><input aria-label="Profile display name" value={profileNameDraft} onChange={e=>setProfileNameDraft(e.target.value)} maxLength={48} placeholder="Your display name" required/><button className="btn btn-primary" type="submit"><Check size={15}/> Save name</button></form>
                <details className="settings-accordion"><summary><span className="settings-row-icon"><ShieldCheck size={17}/></span><span><b>Backup & privacy</b><small>Export, restore and protect your records</small></span><ChevronDown size={17}/></summary><div className="settings-accordion-body">
                <h2><ShieldCheck size={16}/> Data safety & privacy</h2>
                <p>{storageStatus}. Financial records stay on this device and are not automatically synced. Clearing app/browser storage or uninstalling an APK can erase local records. Export backups regularly and keep encrypted backup passwords safe.</p>
                <div className="backup-actions"><button className="btn btn-primary" onClick={exportFullBackup}><FileJson size={16}/> Export full backup</button><button className="btn btn-secondary" onClick={exportEncryptedBackup} disabled={backupBusy}><LockKeyhole size={16}/>{backupBusy ? 'Encrypting…' : 'Encrypted backup'}</button><label className="btn btn-secondary upload-backup"><Upload size={16}/> Restore backup<input type="file" accept="application/json,.json" onChange={importBackup} /></label></div>
                {backupMessage && <div className="backup-message" role="status">{backupMessage}</div>}
                <p className="backup-note">A full backup includes transactions, lending records, custom categories, coach goals and actions, settings, and saved AI reports. Encrypted backups use AES-GCM with a password-derived key. Restore replaces current records only after validation and confirmation. On-device storage is not cloud sync; uninstalling the Android app may remove its private app data.</p>
                <button className="btn btn-secondary" onClick={exportCsv}><Download size={16} /> Export transactions as CSV</button>
                </div></details>
                <details className="settings-accordion"><summary><span className="settings-row-icon"><ListChecks size={17}/></span><span><b>Expense categories</b><small>Add or remove categories used in transactions</small></span><ChevronDown size={17}/></summary><div className="settings-accordion-body">
                <h2><ListChecks size={16}/> Expense categories</h2>
                <p>Create categories that match your life. They will appear in the transaction form, filters and analytics, and are included in backups.</p>
                <form className="category-create-form" onSubmit={addCustomCategory}>
                  <label htmlFor="custom-category-name">New category name</label>
                  <div className="category-create-row"><input id="custom-category-name" value={categoryDraft} onChange={e => setCategoryDraft(e.target.value)} maxLength={32} placeholder="e.g. Pets, Gifts, Subscriptions" /><button className="btn btn-primary" type="submit"><Plus size={15}/> Add category</button></div>
                </form>
                {categoryNotice && <div className="backup-message" role="status">{categoryNotice}</div>}
                <div className="custom-category-list">{customCategories.length ? customCategories.map(c => <div className="custom-category-item" key={c}><span><span className="category-dot"/>{c}</span><button className="btn btn-secondary category-delete" onClick={() => deleteCustomCategory(c)} type="button"><Trash2 size={14}/> Delete</button></div>) : <p className="category-empty">No custom categories yet. Your default categories are ready to use.</p>}</div>
                </div></details>
                <details className="settings-accordion"><summary><span className="settings-row-icon"><History size={17}/></span><span><b>AI report history</b><small>{auditHistory.length} saved reports</small></span><ChevronDown size={17}/></summary><div className="settings-accordion-body">
                <h2><History size={16}/> Financial brain memory</h2><p>{auditHistory.length} saved audit reports on this device. These help Pocketwise compare earlier recommendations with newer reports; they are not synced to another device.</p><div className="backup-actions"><button className="btn btn-secondary" onClick={() => { if (confirm('Clear saved AI audit history? Transactions and lending records will stay.')) setAuditHistory([]); }}><RotateCcw size={15}/> Clear AI history</button></div>
                </div></details>
                <details className="settings-accordion"><summary><span className="settings-row-icon"><CircleHelp size={17}/></span><span><b>About PocketWise</b><small>App information and reset options</small></span><ChevronDown size={17}/></summary><div className="settings-accordion-body">
                <h2>About Pocketwise</h2>
                <p>Pocketwise is a personal expense and lending tracker designed to support mindful money decisions.</p>
                <div className="creator-credit"><span>Created by</span><strong>Anurag Mandal</strong><small>Thank you for using Pocketwise.</small></div>
                <div className="settings-divider" />
                <h2>Reset sample data</h2>
                <p>
                  Replace your current list with sample transactions to explore
                  the dashboard.
                </p>
                <button
                  className="btn btn-secondary"
                  onClick={() => {
                    if (confirm('Replace all transactions with sample data?'))
                      setTxs(seed);
                  }}
                >
                  Restore sample data
                </button>
                <div className="settings-divider" />
                <h2>Clear all data</h2>
                <p>
                  This permanently removes the transactions saved in this
                  browser.
                </p>
                <button className="btn btn-danger" onClick={() => { if (confirm('Delete all saved transactions? This cannot be undone.')) setTxs([]); }}><Trash2 size={15}/> Clear transactions</button>
                </div></details>
              </section>
            </>
          )}
        </div>
        <footer>
          © 2026 Pocketwise <span>Created by Anurag Mandal · Made for mindful money decisions.</span>
        </footer>
      </main>
      <nav className="bottom-nav" aria-label="Main navigation">
        {[{ name: 'Overview', label: 'Home', icon: Home }, { name: 'Transactions', label: 'Transactions', icon: ArrowUpRight }, { name: 'Analytics', label: 'Analytics', icon: BarChart3 }, { name: 'Budgets', label: 'Budgets', icon: Target }, { name: 'Profile', label: 'Profile', icon: Settings }].map(item => (
          <button key={item.name} className={page === item.name ? 'bottom-nav-item active' : 'bottom-nav-item'} onClick={() => setPage(item.name)} aria-current={page === item.name ? 'page' : undefined}>
            <item.icon size={20} strokeWidth={1.8} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      {showLoan && <div className="modal-backdrop" onClick={() => setShowLoan(false)}><div className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><div><h2>Record money lent</h2><p>This is tracked separately, not as an expense.</p></div><button className="icon-btn" onClick={() => setShowLoan(false)}><X size={18}/></button></div><form onSubmit={addLoan}><label>Person's name<input value={loanPerson} onChange={e=>setLoanPerson(e.target.value)} placeholder="e.g. Rahul" autoFocus/></label><label>Amount lent (₹)<input value={loanAmount} onChange={e=>setLoanAmount(e.target.value)} type="number" min="0.01" step="0.01" placeholder="0.00"/></label><label>Date lent<input type="date" value={loanDate} onChange={e=>setLoanDate(e.target.value)} required/></label><label>Repayment due date (optional)<input type="date" value={loanDueDate} onChange={e=>setLoanDueDate(e.target.value)}/></label><label>Note (optional)<input value={loanNote} onChange={e=>setLoanNote(e.target.value)} placeholder="Reason, promise, reminder..."/></label>{loanError && <div className="form-error">{loanError}</div>}<button className="btn btn-primary submit-btn" type="submit"><Check size={16}/> Save lending record</button></form></div></div>}
      {showAdd && (
        <div className="modal-backdrop transaction-backdrop" onClick={() => setShowAdd(false)}>
          <div className="modal transaction-modal" onClick={e => e.stopPropagation()}>
            <div className="transaction-modal-glow"/>
            <div className="modal-head transaction-modal-head">
              <div className="transaction-modal-title">
                <span className="transaction-modal-icon">{kind === 'income' ? <ArrowDownLeft size={21}/> : <CreditCard size={21}/>}</span>
                <div><h2>{editingTxId ? 'Edit transaction' : 'New transaction'}</h2>
                <p>{editingTxId ? 'Update the details of this record.' : 'Every rupee, clearly recorded.'}</p></div>
              </div>
              <button className="icon-btn" onClick={() => setShowAdd(false)}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={addTx}>
              <div className="segmented transaction-type-switch">
                <button
                  type="button"
                  className={
                    kind === 'expense' ? 'selected expense-selected' : ''
                  }
                  onClick={() => {
                    setKind('expense');
                    setCategory('Food');
                  }}
                >
                  Expense
                </button>
                <button
                  type="button"
                  className={
                    kind === 'income' ? 'selected income-selected' : ''
                  }
                  onClick={() => setKind('income')}
                >
                  Income
                </button>
              </div>
              <label>
                Description
                <input
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Groceries"
                  autoFocus
                />
              </label>
              <label className="amount-field-label">Amount (₹)
                <div className={'transaction-amount-input '+(kind==='income'?'is-income':'is-expense')}><span>₹</span><input value={amount} onChange={e=>setAmount(e.target.value)} type="number" min="0.01" step="0.01" placeholder="0.00" inputMode="decimal"/></div>
              </label>
              <div className="quick-amounts" aria-label="Quick amount"><span>Quick add</span>{[100,500,1000,2000].map(v=><button type="button" key={v} onClick={()=>setAmount(String(v))}>₹{v.toLocaleString('en-IN')}</button>)}</div>
              {kind === 'expense' ? (
                <label>Category<select value={category} onChange={e => setCategory(e.target.value)}>{cats.map(c => <option key={c}>{c}</option>)}</select></label>
              ) : (
                <>
                  <label>Income category<select value={incomeCategory} onChange={e => setIncomeCategory(e.target.value)}>{incomeCategories.map(c => <option key={c}>{c}</option>)}{customCategories.map(c => <option key={'custom-income-' + c} value={c}>{c}</option>)}</select></label>
                  {incomeCategory === 'Other' && <label>Custom income category<input value={customIncomeCategory} onChange={e => setCustomIncomeCategory(e.target.value)} maxLength={32} placeholder="e.g. Scholarship, prize money" /></label>}
                </>
              )}
              <label>
                Date
                <input
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  type="date"
                  required
                />
              </label>
              <label>Note <span className="optional-label">Optional</span><input value={note} onChange={e=>setNote(e.target.value)} maxLength={120} placeholder="Add a reminder or extra detail"/></label>
              {error && <div className="form-error">{error}</div>}
              <button className="btn btn-primary submit-btn transaction-save-btn" type="submit"><Check size={17}/>{editingTxId ? 'Save changes' : 'Save transaction'}<ArrowUpRight size={17}/></button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
function Stat({
  title,
  value,
  icon,
  tone,
  note,
}: {
  title: string;
  value: string;
  icon: React.ReactNode;
  tone: string;
  note: string;
}) {
  return (
    <div className="stat-card">
      <div className="stat-top">
        <span>{title}</span>
        <div className={'stat-icon ' + tone}>{icon}</div>
      </div>
      <strong>{value}</strong>
      <small>{note}</small>
    </div>
  );
}
function PageHead({
  title,
  sub,
  action,
}: {
  title: string;
  sub: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">POCKETWISE / FINANCE</div>
        <h1>{title}</h1>
        <p className="subheading">{sub}</p>
      </div>
      {action && <div className="heading-actions">{action}</div>}
    </div>
  );
}
function TxList({ txs, onDelete, onEdit }: { txs: Tx[]; onDelete: (id: string) => void; onEdit: (tx: Tx) => void; }) {
  return (
    <div className="tx-list">
      {txs.map(t => (
        <div className="tx-row" key={t.id}>
          <div
            className={
              'tx-icon ' + (t.type === 'income' ? 'tx-income' : 'tx-expense')
            }
          >
            {t.type === 'income' ? (
              <ArrowDownLeft size={18} />
            ) : (
              categoryIcon(t.category)
            )}
          </div>
          <div className="tx-details">
            <b>{t.title}</b>
            <span>
              {t.category} <i />{' '}
              {new Date(t.date + 'T12:00:00').toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'short',
              })}
            </span>
          </div>
          <strong className={t.type === 'income' ? 'amount-in' : 'amount-out'}>
            {t.type === 'income' ? '+' : '−'}
            {money(t.amount)}
          </strong>
          <button className="edit-tx-btn" title="Edit transaction" aria-label={'Edit '+t.title} onClick={() => onEdit(t)}><Pencil size={15}/></button>
          <button
            className="delete-btn"
            title="Delete transaction"
            onClick={() => onDelete(t.id)}
          >
            <Trash2 size={15} />
          </button>
        </div>
      ))}
    </div>
  );
}
function Empty({ text }: { text: string }) {
  return (
    <div className="empty-state">
      <div>
        <Wallet size={20} />
      </div>
      <p>{text}</p>
    </div>
  );
}
function categoryIcon(c: string) {
  const s = c.toLowerCase();
  if (s === 'food') return '◉';
  if (s === 'transport') return '↗';
  if (s === 'bills') return '▤';
  if (s === 'education') return '▣';
  if (s === 'shopping') return '◇';
  if (s === 'entertainment') return '♫';
  if (s === 'health') return '＋';
  return '•';
}
export default App;
