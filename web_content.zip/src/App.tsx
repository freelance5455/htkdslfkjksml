import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { AgeDashboard } from './components/AgeDashboard';
import { BirthInputPanel, type PresetOption } from './components/BirthInputPanel';
import { TopBar } from './components/TopBar';
import { calculateAgeAnalytics, padTwo } from './utils/ageCalculations';

function formatDateInput(date: Date): string {
  return `${date.getFullYear()}-${padTwo(date.getMonth() + 1)}-${padTwo(date.getDate())}`;
}

function formatTimeInput(date: Date): string {
  return `${padTwo(date.getHours())}:${padTwo(date.getMinutes())}`;
}

function parseDateAndTime(dateStr: string, timeStr: string): Date | null {
  if (!dateStr) return null;
  const parts = dateStr.split('-').map(Number);
  if (parts.length !== 3 || parts.some(Number.isNaN)) return null;
  const [year, month, day] = parts;
  const [hour = 0, minute = 0] = (timeStr || '00:00').split(':').map(Number);
  const dt = new Date(year, month - 1, day, hour, minute, 0, 0);
  if (Number.isNaN(dt.getTime())) return null;
  return dt;
}

export default function App() {
  const initialNow = useMemo(() => new Date(), []);
  const maxDate = formatDateInput(initialNow);

  const [dob, setDob] = useState('2000-05-15');
  const [tob, setTob] = useState('00:00');
  const [mode, setMode] = useState<'live' | 'custom'>('live');
  const [targetDate, setTargetDate] = useState(formatDateInput(initialNow));
  const [targetTime, setTargetTime] = useState(formatTimeInput(initialNow));

  const [committedBirthDate, setCommittedBirthDate] = useState<Date>(() =>
    new Date(2000, 4, 15, 0, 0, 0, 0),
  );
  const [nowTick, setNowTick] = useState<Date>(() => new Date());
  const [error, setError] = useState<string | null>(null);
  const [activePreset, setActivePreset] = useState<string | null>('2000-05-15');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const showToast = useCallback((message: string) => {
    setToastMessage(message);
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (mode !== 'live') return;
    setNowTick(new Date());
    const id = window.setInterval(() => {
      setNowTick(new Date());
    }, 1000);
    return () => window.clearInterval(id);
  }, [mode]);

  const referenceDate = useMemo(() => {
    if (mode === 'live') return nowTick;
    return parseDateAndTime(targetDate, targetTime) ?? nowTick;
  }, [mode, nowTick, targetDate, targetTime]);

  const validateAndCommit = useCallback(
    (nextDob: string, nextTob: string, nextMode: 'live' | 'custom', nextTargetD: string, nextTargetT: string) => {
      setError(null);
      if (!nextDob) {
        setError('Please select your date of birth.');
        return false;
      }

      const year = Number(nextDob.split('-')[0]);
      if (Number.isNaN(year) || year < 1900) {
        setError('Please enter a birth year from 1900 onward.');
        return false;
      }

      const candidateBirth = parseDateAndTime(nextDob, nextTob);
      if (!candidateBirth) {
        setError('Please enter a valid date and time of birth.');
        return false;
      }

      const ref =
        nextMode === 'live'
          ? new Date()
          : parseDateAndTime(nextTargetD, nextTargetT);

      if (!ref) {
        setError('Please enter a valid target reference date.');
        return false;
      }

      if (candidateBirth.getTime() > ref.getTime()) {
        setError(
          nextMode === 'live'
            ? 'Date of birth cannot be in the future.'
            : 'Date of birth cannot be later than the selected target date.',
        );
        return false;
      }

      setCommittedBirthDate(candidateBirth);
      if (nextMode === 'live') {
        setNowTick(new Date());
      }
      return true;
    },
    [],
  );

  const handleDobChange = (value: string) => {
    setDob(value);
    setActivePreset(null);
    if (value) {
      validateAndCommit(value, tob, mode, targetDate, targetTime);
    }
  };

  const handleTobChange = (value: string) => {
    setTob(value);
    validateAndCommit(dob, value, mode, targetDate, targetTime);
  };

  const handleModeChange = (nextMode: 'live' | 'custom') => {
    setMode(nextMode);
    if (nextMode === 'custom') {
      const now = new Date();
      const d = formatDateInput(now);
      const t = formatTimeInput(now);
      setTargetDate(d);
      setTargetTime(t);
      validateAndCommit(dob, tob, nextMode, d, t);
    } else {
      validateAndCommit(dob, tob, nextMode, targetDate, targetTime);
    }
  };

  const handleTargetDateChange = (value: string) => {
    setTargetDate(value);
    if (value) {
      validateAndCommit(dob, tob, mode, value, targetTime);
    }
  };

  const handleTargetTimeChange = (value: string) => {
    setTargetTime(value);
    validateAndCommit(dob, tob, mode, targetDate, value);
  };

  const handleSelectPreset = (preset: PresetOption) => {
    setDob(preset.dob);
    setTob(preset.tob);
    setActivePreset(preset.dob);
    if (validateAndCommit(preset.dob, preset.tob, mode, targetDate, targetTime)) {
      showToast(`Loaded ${preset.label} preset`);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const ok = validateAndCommit(dob, tob, mode, targetDate, targetTime);
    if (ok) {
      const overviewEl = document.getElementById('overview');
      if (overviewEl && window.innerWidth < 1024) {
        overviewEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      showToast('Age analytics updated');
    }
  };

  const handleResetToday = () => {
    const now = new Date();
    const d = formatDateInput(now);
    const t = formatTimeInput(now);
    setTargetDate(d);
    setTargetTime(t);
    validateAndCommit(dob, tob, mode, d, t);
  };

  const analytics = useMemo(
    () => calculateAgeAnalytics(committedBirthDate, referenceDate),
    [committedBirthDate, referenceDate],
  );

  const copySummaryToClipboard = useCallback(async (toastLabel: string) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(analytics.summaryText);
      } else {
        const ta = document.createElement('textarea');
        ta.value = analytics.summaryText;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }
      showToast(toastLabel);
    } catch {
      showToast('Unable to copy automatically');
    }
  }, [analytics.summaryText, showToast]);

  const handleShare = useCallback(async () => {
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share({
          title: 'ChronoAge Pro — My Exact Age',
          text: analytics.summaryText,
        });
        return;
      } catch {
        // User cancelled or share failed; fall back to clipboard
      }
    }
    await copySummaryToClipboard('Summary copied for sharing');
  }, [analytics.summaryText, copySummaryToClipboard]);

  return (
    <div className="min-h-screen flex flex-col">
      <TopBar onShare={handleShare} />

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 sm:px-6 py-6 sm:py-9">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 lg:gap-8 items-start">
          <div className="lg:col-span-4">
            <BirthInputPanel
              dob={dob}
              tob={tob}
              maxDate={maxDate}
              mode={mode}
              targetDate={targetDate}
              targetTime={targetTime}
              error={error}
              activePreset={activePreset}
              onDobChange={handleDobChange}
              onTobChange={handleTobChange}
              onModeChange={handleModeChange}
              onTargetDateChange={handleTargetDateChange}
              onTargetTimeChange={handleTargetTimeChange}
              onSelectPreset={handleSelectPreset}
              onSubmit={handleSubmit}
              onCopy={() => copySummaryToClipboard('Age summary copied to clipboard')}
              onResetToday={handleResetToday}
            />
          </div>

          <div className="lg:col-span-8">
            <AgeDashboard analytics={analytics} mode={mode} />
          </div>
        </div>
      </main>

      <footer className="border-t border-white/[0.06] py-6 text-center text-xs text-slate-500">
        ChronoAge Pro · Precision Chronological &amp; Planetary Age Calculator
      </footer>

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-indigo-400/40 bg-[#151C2E]/95 px-4 py-2.5 text-xs font-semibold text-white shadow-xl backdrop-blur-md"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
