/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import {
  Wallet,
  PiggyBank,
  QrCode,
  ArrowDownLeft,
  ArrowLeftRight,
  Trophy,
  History,
  CreditCard,
  User,
  School,
  Lock,
  ArrowRight,
  TrendingUp,
  Store,
  Sparkles,
  CheckCircle2,
  Calendar,
  UtensilsCrossed,
  BookOpen,
  Coins,
  ShieldCheck,
  ChevronRight,
  RotateCcw,
  Shirt,
} from 'lucide-react';

import {
  DEFAULT_STUDENT_PROFILE,
  INITIAL_LEADERBOARD,
  INITIAL_TRANSACTIONS,
  QRIS_MERCHANTS,
} from './data/mockData';
import { StudentProfile, Transaction, WalletBalance } from './types';
import { formatNumber, formatRupiah, triggerConfetti } from './utils/formatters';

import { ProfileSetupModal } from './components/ProfileSetupModal';
import { PinVerificationModal } from './components/PinVerificationModal';
import { TopUpModal } from './components/TopUpModal';
import { QrisModal } from './components/QrisModal';
import { TransferSavingsModal } from './components/TransferSavingsModal';
import { StudentCardModal } from './components/StudentCardModal';
import { ReceiptModal } from './components/ReceiptModal';
import { LeaderboardView } from './components/LeaderboardView';
import { HistoryView } from './components/HistoryView';

export default function App() {
  // 1. Student Profile State
  const [profile, setProfile] = useState<StudentProfile>(() => {
    try {
      const saved = localStorage.getItem('sakusiswa_profile');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return DEFAULT_STUDENT_PROFILE;
  });

  // 2. Wallet & Savings Balances
  const [balances, setBalances] = useState<WalletBalance>(() => {
    try {
      const saved = localStorage.getItem('sakusiswa_balances');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      wallet: 75000,
      savings: 1250000,
    };
  });

  // 3. Transactions
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('sakusiswa_transactions');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_TRANSACTIONS;
  });

  // Active navigation view: 'home' | 'leaderboard' | 'history'
  const [activeView, setActiveView] = useState<'home' | 'leaderboard' | 'history'>('home');

  // Modals state
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isTopUpModalOpen, setIsTopUpModalOpen] = useState(false);
  const [isQrisModalOpen, setIsQrisModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isStudentCardOpen, setIsStudentCardOpen] = useState(false);
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<Transaction | null>(null);

  // PIN Verification Modal State
  const [pinModalState, setPinModalState] = useState<{
    isOpen: boolean;
    amount?: number;
    title?: string;
    onAuthorize: () => void;
  }>({
    isOpen: false,
    onAuthorize: () => {},
  });

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('sakusiswa_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('sakusiswa_balances', JSON.stringify(balances));
  }, [balances]);

  useEffect(() => {
    localStorage.setItem('sakusiswa_transactions', JSON.stringify(transactions));
  }, [transactions]);

  // PIN verification trigger helper
  const requestPinAuth = (
    amount: number | undefined,
    onAuthorize: () => void,
    title = 'Masukkan PIN Transaksi Siswa'
  ) => {
    setPinModalState({
      isOpen: true,
      amount,
      title,
      onAuthorize: () => {
        setPinModalState((prev) => ({ ...prev, isOpen: false }));
        onAuthorize();
      },
    });
  };

  // Top Up Handler
  const handleSuccessTopUp = (tx: Transaction) => {
    setTransactions((prev) => [tx, ...prev]);

    if (tx.destination === 'savings') {
      setBalances((prev) => ({ ...prev, savings: prev.savings + tx.amount }));
    } else {
      setBalances((prev) => ({ ...prev, wallet: prev.wallet + tx.amount }));
    }

    triggerConfetti();
    setSelectedReceiptTx(tx);
  };

  // QRIS Payment Handler
  const handleSuccessQrisPayment = (tx: Transaction) => {
    setTransactions((prev) => [tx, ...prev]);
    setBalances((prev) => ({ ...prev, wallet: prev.wallet - tx.amount }));
    setSelectedReceiptTx(tx);
  };

  // QRIS Receive Handler
  const handleSuccessQrisReceive = (tx: Transaction) => {
    setTransactions((prev) => [tx, ...prev]);
    setBalances((prev) => ({ ...prev, wallet: prev.wallet + tx.amount }));
    triggerConfetti();
    setSelectedReceiptTx(tx);
  };

  // Transfer between wallet and savings
  const handleSuccessTransfer = (tx: Transaction, newBalances: WalletBalance) => {
    setTransactions((prev) => [tx, ...prev]);
    setBalances(newBalances);
    triggerConfetti();
    setSelectedReceiptTx(tx);
  };

  // Reset demo data
  const handleResetData = () => {
    if (window.confirm('Reset seluruh data transaksi dan saldo ke kondisi awal demo?')) {
      setProfile(DEFAULT_STUDENT_PROFILE);
      setBalances({ wallet: 75000, savings: 1250000 });
      setTransactions(INITIAL_TRANSACTIONS);
      localStorage.clear();
    }
  };

  // User rank in school leaderboard
  const userRank = React.useMemo(() => {
    const list = [...INITIAL_LEADERBOARD, { savingsAmount: balances.savings }];
    list.sort((a, b) => b.savingsAmount - a.savingsAmount);
    const index = list.findIndex((item) => item.savingsAmount === balances.savings);
    return index !== -1 ? index + 1 : 1;
  }, [balances.savings]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans pb-24 md:pb-12">
      {/* ============================================================
          TOP BAR CONTRACT (§2)
          [Brand title, one line] — [4–5 nav links, 1–2 word labels] — [1 primary action]
      ============================================================ */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
          {/* Zone 1: Brand title wordmark */}
          <div
            onClick={() => setActiveView('home')}
            className="flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-extrabold tracking-tight text-slate-900 block leading-tight">
                SakuSiswa
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold uppercase tracking-wider block">
                Dompet Digital Sekolah
              </span>
            </div>
          </div>

          {/* Zone 2: 4-5 concise single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-semibold text-slate-600">
            <button
              onClick={() => setActiveView('home')}
              className={`hover:text-emerald-600 transition-colors whitespace-nowrap shrink-0 ${
                activeView === 'home' ? 'text-emerald-600 border-b-2 border-emerald-600 pb-0.5' : ''
              }`}
            >
              Beranda
            </button>
            <button
              onClick={() => setIsQrisModalOpen(true)}
              className="hover:text-emerald-600 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <QrCode className="w-4 h-4 text-rose-500" />
              <span>QRIS</span>
            </button>
            <button
              onClick={() => setIsTopUpModalOpen(true)}
              className="hover:text-emerald-600 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
              <span>Top Up</span>
            </button>
            <button
              onClick={() => setActiveView('leaderboard')}
              className={`hover:text-emerald-600 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                activeView === 'leaderboard'
                  ? 'text-emerald-600 border-b-2 border-emerald-600 pb-0.5'
                  : ''
              }`}
            >
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>Leaderboard</span>
            </button>
            <button
              onClick={() => setActiveView('history')}
              className={`hover:text-emerald-600 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                activeView === 'history' ? 'text-emerald-600 border-b-2 border-emerald-600 pb-0.5' : ''
              }`}
            >
              <History className="w-4 h-4 text-slate-500" />
              <span>Riwayat</span>
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setIsProfileModalOpen(true)}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-800 transition-colors whitespace-nowrap shrink-0"
              title="Pengaturan Profil, Umur, dan PIN"
            >
              <img
                src={profile.avatar}
                alt={profile.name}
                className="w-6 h-6 rounded-lg object-cover"
              />
              <span className="hidden sm:inline truncate max-w-[110px]">{profile.name}</span>
              <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100 px-1 py-0.2 rounded">
                PIN
              </span>
            </button>

            <button
              type="button"
              onClick={() => setIsTopUpModalOpen(true)}
              className="px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Top Up</span>
            </button>
          </div>
        </div>
      </header>

      {/* ============================================================
          MAIN BODY CONTAINER
      ============================================================ */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 pt-6 flex-1">
        {/* VIEW 1: BERANDA (HOME DASHBOARD) */}
        {activeView === 'home' && (
          <div className="space-y-6">
            {/* Top Student Welcome Strip */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-3xl p-5 shadow-xs">
              <div className="flex items-center gap-3.5">
                <div className="relative">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-emerald-500 shadow-sm bg-slate-100">
                    <img
                      src={profile.avatar}
                      alt={profile.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5 border border-white">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                      Halo, {profile.name}!
                    </h2>
                    <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                      {profile.age} Tahun
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {profile.grade} • {profile.school} • NISN: {profile.nisn}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  type="button"
                  onClick={() => setIsStudentCardOpen(true)}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Kartu Pelajar</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsProfileModalOpen(true)}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
                >
                  Edit Data & PIN
                </button>
              </div>
            </div>

            {/* Main Wallet Cards & Balance Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Card 1 & 2: Big Dual-Balance Hub */}
              <div className="lg:col-span-2 relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-850 to-emerald-950 p-6 sm:p-8 text-white shadow-xl border border-slate-800">
                {/* Background graphic asset with fallback */}
                <img
                  src="/src/assets/images/student_card_mesh_1794268821451.jpg"
                  alt="Card Backdrop"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-screen pointer-events-none"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />

                <div className="relative z-10 flex flex-col justify-between h-full space-y-6">
                  {/* Top Bar inside Card */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
                        <Wallet className="w-4 h-4" />
                      </div>
                      <span className="text-xs uppercase font-mono tracking-widest text-emerald-300 font-bold">
                        Saldo Rekening Siswa
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-full">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>PIN Proteksi 6-Digit</span>
                    </div>
                  </div>

                  {/* Dual Balances: Dompet Saku + Tabungan Siswa */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                    {/* Saldo Dompet Saku */}
                    <div className="p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-300">Dompet Saku Harian</span>
                        <span className="text-[10px] font-mono text-emerald-400 font-semibold">
                          Uang Jajan
                        </span>
                      </div>
                      <h3 className="text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-tight">
                        {formatRupiah(balances.wallet)}
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Bisa dipakai bayar QRIS kantin & kas kelas
                      </p>
                    </div>

                    {/* Tabungan Siswa */}
                    <div className="p-4 bg-emerald-500/10 backdrop-blur-md rounded-2xl border border-emerald-500/20">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-emerald-300 font-semibold">
                          Tabungan Siswa (Celengan)
                        </span>
                        <span className="text-[10px] font-mono text-amber-300 font-bold bg-amber-500/20 px-1.5 py-0.5 rounded">
                          Rank #{userRank}
                        </span>
                      </div>
                      <h3 className="text-2xl sm:text-3xl font-extrabold font-mono text-amber-300 tracking-tight">
                        {formatRupiah(balances.savings)}
                      </h3>
                      <p className="text-[11px] text-slate-300 mt-1">
                        Dihitung pada Leaderboard Tabungan Sekolah
                      </p>
                    </div>
                  </div>

                  {/* Primary Quick Action Buttons */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsTopUpModalOpen(true)}
                      className="py-3 px-3 bg-emerald-500 hover:bg-emerald-600 active:scale-98 text-slate-950 font-extrabold text-xs rounded-2xl shadow-lg shadow-emerald-500/20 transition-all flex flex-col items-center justify-center gap-1.5"
                    >
                      <ArrowDownLeft className="w-5 h-5" />
                      <span>Top Up Saldo</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsQrisModalOpen(true)}
                      className="py-3 px-3 bg-rose-600 hover:bg-rose-700 active:scale-98 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-rose-600/20 transition-all flex flex-col items-center justify-center gap-1.5"
                    >
                      <QrCode className="w-5 h-5" />
                      <span>Pindai QRIS</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsTransferModalOpen(true)}
                      className="py-3 px-3 bg-white/10 hover:bg-white/20 active:scale-98 text-white font-bold text-xs rounded-2xl border border-white/20 backdrop-blur-md transition-all flex flex-col items-center justify-center gap-1.5"
                    >
                      <ArrowLeftRight className="w-5 h-5 text-indigo-300" />
                      <span>Atur Tabungan</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsStudentCardOpen(true)}
                      className="py-3 px-3 bg-white/10 hover:bg-white/20 active:scale-98 text-white font-bold text-xs rounded-2xl border border-white/20 backdrop-blur-md transition-all flex flex-col items-center justify-center gap-1.5"
                    >
                      <CreditCard className="w-5 h-5 text-emerald-300" />
                      <span>Kartu Siswa</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Card 3: School Leaderboard Snapshot Widget */}
              <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                        <Trophy className="w-4 h-4" />
                      </div>
                      <h3 className="text-sm font-extrabold text-slate-900">Top Tabungan Siswa</h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveView('leaderboard')}
                      className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-0.5"
                    >
                      <span>Lihat Semua</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-slate-500 mb-4">
                    Peringkat siswa dengan tabungan tertinggi di {profile.school}.
                  </p>

                  {/* Leaderboard Top 3 Mini List */}
                  <div className="space-y-3">
                    {INITIAL_LEADERBOARD.slice(0, 3).map((item, idx) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-50 border border-slate-100"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span
                            className={`w-6 h-6 rounded-lg font-mono text-xs font-bold flex items-center justify-center shrink-0 ${
                              idx === 0
                                ? 'bg-amber-400 text-slate-950'
                                : idx === 1
                                ? 'bg-slate-300 text-slate-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            #{idx + 1}
                          </span>
                          <img
                            src={item.avatar}
                            alt={item.name}
                            className="w-8 h-8 rounded-lg object-cover shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-slate-900 truncate">{item.name}</p>
                            <p className="text-[10px] text-slate-400 truncate">{item.grade}</p>
                          </div>
                        </div>

                        <span className="text-xs font-bold font-mono text-slate-900 shrink-0">
                          {formatRupiah(item.savingsAmount)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Your Position Banner */}
                <div className="mt-5 p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-800 font-bold block">
                      Posisi Anda Saat Ini
                    </span>
                    <span className="text-xs font-extrabold text-slate-900 font-mono">
                      Peringkat #{userRank} Sekolah
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsTransferModalOpen(true)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-xl transition-colors shadow-xs"
                  >
                    Naikkan Tabungan
                  </button>
                </div>
              </div>
            </div>

            {/* Quick School Merchants & Preset QRIS */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Kantin & Koperasi Sekolah
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Bayar jajan & perlengkapan sekolah cepat dengan satu kali pindai QRIS
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsQrisModalOpen(true)}
                  className="px-3.5 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Buka Scanner QRIS</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                {QRIS_MERCHANTS.map((merchant) => (
                  <button
                    key={merchant.id}
                    type="button"
                    onClick={() => setIsQrisModalOpen(true)}
                    className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl text-left transition-all group flex flex-col justify-between"
                  >
                    <div className="w-9 h-9 rounded-xl bg-white shadow-xs flex items-center justify-center mb-2 group-hover:scale-105 transition-transform text-slate-700">
                      {merchant.iconName === 'UtensilsCrossed' && (
                        <UtensilsCrossed className="w-4 h-4 text-amber-600" />
                      )}
                      {merchant.iconName === 'BookOpen' && (
                        <BookOpen className="w-4 h-4 text-indigo-600" />
                      )}
                      {merchant.iconName === 'Coins' && (
                        <Coins className="w-4 h-4 text-emerald-600" />
                      )}
                      {merchant.iconName === 'Shirt' && (
                        <Shirt className="w-4 h-4 text-sky-600" />
                      )}
                      {merchant.iconName === 'CupSoda' && (
                        <UtensilsCrossed className="w-4 h-4 text-rose-600" />
                      )}
                      {merchant.iconName === 'Printer' && (
                        <BookOpen className="w-4 h-4 text-purple-600" />
                      )}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-900 truncate">{merchant.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{merchant.category}</p>
                      <p className="text-xs font-bold text-rose-600 font-mono mt-1">
                        {formatRupiah(merchant.defaultAmount)}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Recent Transactions Preview */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Riwayat Terkini</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Transaksi masuk, bayar kantin, dan transfer tabungan terbaru
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView('history')}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-0.5"
                >
                  <span>Buka Semua Riwayat</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {transactions.slice(0, 4).map((tx) => {
                  const isIncome =
                    tx.type === 'topup' || tx.type === 'qris_receive' || tx.type === 'to_wallet';

                  return (
                    <div
                      key={tx.id}
                      onClick={() => setSelectedReceiptTx(tx)}
                      className="py-3 px-2 flex items-center justify-between gap-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                            isIncome
                              ? 'bg-emerald-50 text-emerald-600'
                              : 'bg-rose-50 text-rose-600'
                          }`}
                        >
                          {isIncome ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : (
                            <QrCode className="w-4 h-4" />
                          )}
                        </div>

                        <div className="min-w-0">
                          <p className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {tx.title}
                          </p>
                          <p className="text-[11px] text-slate-500 font-mono">
                            {tx.timestamp} • {tx.sourceAccount}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`text-xs sm:text-sm font-bold font-mono ${
                            isIncome ? 'text-emerald-600' : 'text-slate-900'
                          }`}
                        >
                          {isIncome ? '+' : '-'}{formatRupiah(tx.amount)}
                        </span>
                        <span className="text-[10px] text-emerald-600 block">Berhasil</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Footer Utilities */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
              <span>SakuSiswa • Sistem Dompet & Tabungan Siswa Digital Resmi</span>
              <button
                type="button"
                onClick={handleResetData}
                className="hover:text-rose-500 flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Data Demo Awal</span>
              </button>
            </div>
          </div>
        )}

        {/* VIEW 2: LEADERBOARD TABUNGAN */}
        {activeView === 'leaderboard' && (
          <LeaderboardView
            currentProfile={profile}
            currentSavings={balances.savings}
            onOpenTransferSavings={() => setIsTransferModalOpen(true)}
            onOpenTopUp={() => setIsTopUpModalOpen(true)}
          />
        )}

        {/* VIEW 3: HISTORI TRANSAKSI */}
        {activeView === 'history' && (
          <HistoryView
            transactions={transactions}
            onSelectTransaction={(tx) => setSelectedReceiptTx(tx)}
          />
        )}
      </main>

      {/* ============================================================
          MOBILE BOTTOM NAVIGATION (Fixed Bottom Tab Bar §3)
          3-5 destinations: Beranda, QRIS, Top Up, Leaderboard, Riwayat
      ============================================================ */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-md border-t border-slate-200 px-2 py-2">
        <div className="grid grid-cols-5 items-center">
          <button
            type="button"
            onClick={() => setActiveView('home')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeView === 'home' ? 'text-emerald-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Wallet className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">Beranda</span>
          </button>

          <button
            type="button"
            onClick={() => setIsQrisModalOpen(true)}
            className="flex flex-col items-center justify-center py-1 text-slate-500 hover:text-rose-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <QrCode className="w-4 h-4" />
            </div>
            <span className="text-[10px] mt-0.5">QRIS</span>
          </button>

          <button
            type="button"
            onClick={() => setIsTopUpModalOpen(true)}
            className="flex flex-col items-center justify-center py-1 text-slate-500 hover:text-emerald-600 transition-colors"
          >
            <div className="w-7 h-7 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
            <span className="text-[10px] mt-0.5">Top Up</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('leaderboard')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeView === 'leaderboard' ? 'text-emerald-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Trophy className="w-5 h-5 text-amber-500" />
            <span className="text-[10px] mt-0.5">Juara</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('history')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeView === 'history' ? 'text-emerald-600 font-bold' : 'text-slate-500'
            }`}
          >
            <History className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">Riwayat</span>
          </button>
        </div>
      </nav>

      {/* ============================================================
          ALL MODAL DIALOGS
      ============================================================ */}
      {/* 1. Pengisian Data Siswa & PIN Modal */}
      <ProfileSetupModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentProfile={profile}
        onSaveProfile={(updated) => setProfile(updated)}
      />

      {/* 2. Top Up Modal (with mandatory rekening / GoPay / DANA input) */}
      <TopUpModal
        isOpen={isTopUpModalOpen}
        onClose={() => setIsTopUpModalOpen(false)}
        onRequestPin={(amount, onAuth) =>
          requestPinAuth(amount, onAuth, 'Konfirmasi PIN Top Up')
        }
        onSuccessTopUp={handleSuccessTopUp}
      />

      {/* 3. QRIS Modal (Scan to Pay & QRIS Siswa) */}
      <QrisModal
        isOpen={isQrisModalOpen}
        onClose={() => setIsQrisModalOpen(false)}
        studentProfile={profile}
        walletBalance={balances.wallet}
        onRequestPin={(amount, onAuth) =>
          requestPinAuth(amount, onAuth, 'Konfirmasi PIN Bayar QRIS')
        }
        onSuccessPayment={handleSuccessQrisPayment}
        onSuccessReceive={handleSuccessQrisReceive}
      />

      {/* 4. Transfer Savings Modal */}
      <TransferSavingsModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        balances={balances}
        onRequestPin={(amount, onAuth) =>
          requestPinAuth(amount, onAuth, 'Konfirmasi PIN Tabungan')
        }
        onSuccessTransfer={handleSuccessTransfer}
      />

      {/* 5. Student Card Modal */}
      <StudentCardModal
        isOpen={isStudentCardOpen}
        onClose={() => setIsStudentCardOpen(false)}
        profile={profile}
        balances={balances}
      />

      {/* 6. Receipt Modal */}
      <ReceiptModal
        isOpen={Boolean(selectedReceiptTx)}
        onClose={() => setSelectedReceiptTx(null)}
        transaction={selectedReceiptTx}
      />

      {/* 7. PIN Verification Keypad Modal */}
      <PinVerificationModal
        isOpen={pinModalState.isOpen}
        onClose={() => setPinModalState((prev) => ({ ...prev, isOpen: false }))}
        onSuccess={pinModalState.onAuthorize}
        correctPin={profile.pin}
        title={pinModalState.title}
        amountToAuthorize={pinModalState.amount}
      />
    </div>
  );
}
