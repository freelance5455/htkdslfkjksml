import { useEffect, useRef, useState } from "react";
import { GameSound } from "./game/Sound";
import { MiniFootGame } from "./game/MiniFootGame";
import type { GamePhase, GameResult, HudData, SoundCue } from "./game/MiniFootGame";

const STORAGE_KEY = "minifoot-local-legends-v1";
const FIELD_WIDTH = 600;
const FIELD_HEIGHT = 760;

interface ScoreEntry {
  id: string;
  name: string;
  goals: number;
  against: number;
  points: number;
  playedAt: number;
}

interface FinishedMatch extends GameResult {
  id: string;
}

function readScores(): ScoreEntry[] {
  try {
    const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "[]") as unknown;
    if (!Array.isArray(saved)) return [];
    return saved
      .filter(
        (item): item is ScoreEntry =>
          item !== null &&
          typeof item === "object" &&
          typeof item.id === "string" &&
          typeof item.name === "string" &&
          typeof item.goals === "number" &&
          typeof item.points === "number" &&
          typeof item.playedAt === "number",
      )
      .sort((a, b) => b.points - a.points || b.goals - a.goals || b.playedAt - a.playedAt)
      .slice(0, 5);
  } catch {
    return [];
  }
}

function formatTime(seconds: number) {
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function formatPoints(points: number) {
  return String(points).padStart(4, "0");
}

function BallMark({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <circle cx="20" cy="20" r="17" fill="#E4FB8B" />
      <circle cx="20" cy="20" r="16" stroke="#102C31" strokeWidth="2.2" />
      <path d="m20 12 7.5 5.4-2.8 8.6h-9.4l-2.8-8.6L20 12Z" fill="#102C31" />
      <path
        d="m20 12 .3-8M27.5 17.4l7.8-2.2M24.7 26l4.6 7M15.3 26l-4.6 7M12.5 17.4l-7.8-2.2"
        stroke="#102C31"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

function TrophyIcon() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M8 20h8m-4-4v4M6 4h12v5a6 6 0 0 1-12 0V4Zm0 2H3v2a4 4 0 0 0 4 4m11-6h3v2a4 4 0 0 1-4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SoundIcon({ muted }: { muted: boolean }) {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M11 5 6.5 9H3v6h3.5l4.5 4V5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      {muted ? (
        <path d="m16 9 5 6m0-6-5 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      ) : (
        <path d="M15 9a4 4 0 0 1 0 6m3-9a8 8 0 0 1 0 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      )}
    </svg>
  );
}

function PauseIcon({ paused }: { paused: boolean }) {
  return paused ? (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="m8 5 11 7-11 7V5Z" fill="currentColor" />
    </svg>
  ) : (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="5" y="4" width="5" height="16" rx="1" fill="currentColor" />
      <rect x="14" y="4" width="5" height="16" rx="1" fill="currentColor" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M5 5 19 19M19 5 5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function ScoreRows({ scores, compact = false }: { scores: ScoreEntry[]; compact?: boolean }) {
  if (scores.length === 0) {
    return (
      <div className={`empty-scores ${compact ? "empty-scores-compact" : ""}`}>
        <span className="empty-scores-symbol">*</span>
        <p>No legends yet.<br />The first spot is yours.</p>
      </div>
    );
  }

  return (
    <div className="score-list">
      {scores.map((score, index) => (
        <div className="score-list-row" key={score.id}>
          <span className="score-rank">{String(index + 1).padStart(2, "0")}</span>
          <span className="score-name">{score.name}</span>
          {!compact && <span className="score-goals">{score.goals} {score.goals === 1 ? "GOAL" : "GOALS"}</span>}
          <strong className="score-points">{formatPoints(score.points)}</strong>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<MiniFootGame | null>(null);
  const soundRef = useRef<GameSound | null>(null);
  const keysRef = useRef(new Set<string>());
  const touchVectorRef = useRef({ x: 0, y: 0 });
  const joystickPointerRef = useRef<number | null>(null);
  const joystickRef = useRef<HTMLDivElement>(null);
  const joystickThumbRef = useRef<HTMLDivElement>(null);

  const [phase, setPhase] = useState<GamePhase>("menu");
  const [hud, setHud] = useState<HudData>({ home: 0, away: 0, time: 60, points: 0 });
  const [scores, setScores] = useState<ScoreEntry[]>(readScores);
  const [result, setResult] = useState<FinishedMatch | null>(null);
  const [initials, setInitials] = useState("YOU");
  const [leaderboardOpen, setLeaderboardOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [goalPulse, setGoalPulse] = useState(0);

  if (!soundRef.current) soundRef.current = new GameSound();

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(scores));
    } catch {
      // Private browsing can make storage unavailable; the current session still works.
    }
  }, [scores]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !ctx) return;

    const game = new MiniFootGame({
      onHud: setHud,
      onGoal: () => setGoalPulse((current) => current + 1),
      onSound: (cue: SoundCue) => {
        soundRef.current?.play(cue);
        if (cue === "goal" || cue === "kick") {
          navigator.vibrate?.(cue === "goal" ? [35, 45, 55] : 14);
        }
      },
      onEnd: (match) => {
        const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const entry: ScoreEntry = {
          id,
          name: "YOU",
          goals: match.home,
          against: match.away,
          points: match.points,
          playedAt: Date.now(),
        };
        setScores((previous) =>
          [...previous, entry]
            .sort((a, b) => b.points - a.points || b.goals - a.goals || b.playedAt - a.playedAt)
            .slice(0, 5),
        );
        setInitials("YOU");
        setResult({ ...match, id });
        setPhase("gameover");
      },
    });
    gameRef.current = game;

    // Cap DPR for crisp graphics without wasting fill-rate on high-density phones.
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.max(1, Math.round(rect.width * dpr));
      const height = Math.max(1, Math.round(rect.height * dpr));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      ctx.setTransform(width / FIELD_WIDTH, 0, 0, height / FIELD_HEIGHT, 0, 0);
    };

    const observer = new ResizeObserver(resizeCanvas);
    observer.observe(canvas);
    resizeCanvas();

    let animationFrame = 0;
    let previousTime = performance.now();
    const frame = (now: number) => {
      const dt = Math.min(Math.max((now - previousTime) / 1000, 0), 0.033);
      previousTime = now;
      const keys = keysRef.current;
      const keyboardX = Number(keys.has("d") || keys.has("arrowright")) - Number(keys.has("a") || keys.has("arrowleft"));
      const keyboardY = Number(keys.has("s") || keys.has("arrowdown")) - Number(keys.has("w") || keys.has("arrowup"));
      const input = keyboardX || keyboardY ? { x: keyboardX, y: keyboardY } : touchVectorRef.current;
      game.update(dt, input);
      game.draw(ctx);
      animationFrame = requestAnimationFrame(frame);
    };
    animationFrame = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(animationFrame);
      observer.disconnect();
      gameRef.current = null;
    };
  }, []);

  function clearInput() {
    keysRef.current.clear();
    touchVectorRef.current = { x: 0, y: 0 };
    joystickPointerRef.current = null;
    joystickThumbRef.current?.style.setProperty("transform", "translate(-50%, -50%)");
    joystickRef.current?.classList.remove("engaged");
  }

  function startMatch() {
    clearInput();
    setLeaderboardOpen(false);
    setResult(null);
    gameRef.current?.start();
    setPhase("playing");
  }

  function pauseMatch() {
    gameRef.current?.pause();
    clearInput();
    setPhase("paused");
  }

  function resumeMatch() {
    gameRef.current?.resume();
    setPhase("playing");
  }

  function openLeaderboard() {
    if (gameRef.current?.phase === "playing") pauseMatch();
    setLeaderboardOpen(true);
  }

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      const movement = ["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(key);
      const gamePhase = gameRef.current?.phase;

      if (leaderboardOpen) {
        if (key === "escape" || key === "enter") {
          event.preventDefault();
          setLeaderboardOpen(false);
        }
        return;
      }

      if (event.target instanceof HTMLInputElement) return;
      if (gamePhase === "playing" && (movement || key === " ")) event.preventDefault();
      if (movement) keysRef.current.add(key);
      if (event.repeat) return;

      if (key === " " && gamePhase === "playing") gameRef.current?.requestKick();
      if (key === "p" || key === "escape") {
        if (gamePhase === "playing") pauseMatch();
        else if (gamePhase === "paused") resumeMatch();
      }
      if (key === "enter") {
        if (gamePhase === "menu" || gamePhase === "gameover") startMatch();
        else if (gamePhase === "paused") resumeMatch();
      }
      if (key === "r" && gamePhase === "gameover") startMatch();
    };

    const onKeyUp = (event: KeyboardEvent) => keysRef.current.delete(event.key.toLowerCase());
    const onBlur = () => {
      if (gameRef.current?.phase === "playing") pauseMatch();
      else clearInput();
    };
    const onVisibilityChange = () => {
      if (document.hidden && gameRef.current?.phase === "playing") pauseMatch();
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [leaderboardOpen]);

  function updateJoystick(clientX: number, clientY: number) {
    const pad = joystickRef.current;
    if (!pad) return;
    const rect = pad.getBoundingClientRect();
    const max = rect.width * 0.32;
    let x = clientX - (rect.left + rect.width / 2);
    let y = clientY - (rect.top + rect.height / 2);
    const length = Math.hypot(x, y);
    if (length > max) {
      x = (x / length) * max;
      y = (y / length) * max;
    }
    touchVectorRef.current = { x: x / max, y: y / max };
    joystickThumbRef.current?.style.setProperty("transform", `translate(-50%, -50%) translate(${x}px, ${y}px)`);
  }

  function releaseJoystick(pointerId: number) {
    if (joystickPointerRef.current !== pointerId) return;
    joystickPointerRef.current = null;
    touchVectorRef.current = { x: 0, y: 0 };
    joystickThumbRef.current?.style.setProperty("transform", "translate(-50%, -50%)");
    joystickRef.current?.classList.remove("engaged");
  }

  function updateInitials(value: string) {
    const clean = value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 3);
    setInitials(clean);
    if (result) {
      setScores((previous) => previous.map((entry) => entry.id === result.id ? { ...entry, name: clean || "YOU" } : entry));
    }
  }

  const place = result ? scores.findIndex((score) => score.id === result.id) + 1 : 0;
  const resultLine = result
    ? result.home > result.away
      ? "That was a tiny masterclass."
      : result.home === result.away
        ? "Nothing between you this time."
        : "The comeback starts right now."
    : "";

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="wordmark" aria-label="Minifoot">
            <BallMark size={31} />
            <span>mini<span className="wordmark-accent">foot.</span></span>
          </div>
          <span className="topbar-tagline">THE ONE-MINUTE FOOTBALL GAME</span>
          <div className="topbar-actions">
            <button className="leaderboard-trigger" type="button" onClick={openLeaderboard} aria-label="Open local leaderboard">
              <TrophyIcon /><span>LEADERBOARD</span>
            </button>
            <button
              className="icon-button"
              type="button"
              onClick={() => setMuted((current) => {
                soundRef.current?.setEnabled(current);
                return !current;
              })}
              aria-label={muted ? "Turn sound on" : "Mute sound"}
              title={muted ? "Turn sound on" : "Mute sound"}
            >
              <SoundIcon muted={muted} />
            </button>
            {(phase === "playing" || phase === "paused") && (
              <button
                className="icon-button"
                type="button"
                onClick={phase === "playing" ? pauseMatch : resumeMatch}
                aria-label={phase === "playing" ? "Pause game" : "Resume game"}
                title={phase === "playing" ? "Pause game" : "Resume game"}
              >
                <PauseIcon paused={phase === "paused"} />
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="main-stage">
        <div className="frame-column">
          <div className="arena-frame">
            <div className="match-hud" aria-live="polite">
              <div className="team-score team-score-home">
                <span className="team-dot" />
                <div className="team-score-content">
                  <span className="team-label">YOU</span>
                  <strong key={`home-${hud.home}-${goalPulse}`} className="score-digit">{hud.home}</strong>
                </div>
              </div>
              <div className="match-clock">
                <span className="clock-label">MATCH CLOCK</span>
                <strong className={hud.time <= 10 && phase === "playing" ? "clock-time clock-urgent" : "clock-time"}>{formatTime(hud.time)}</strong>
                <span className="clock-points">{formatPoints(hud.points)} PTS</span>
              </div>
              <div className="team-score team-score-away">
                <div className="team-score-content">
                  <span className="team-label">RIVAL</span>
                  <strong key={`away-${hud.away}-${goalPulse}`} className="score-digit">{hud.away}</strong>
                </div>
                <span className="team-dot" />
              </div>
            </div>

            <div className="pitch-viewport">
              <canvas ref={canvasRef} width={FIELD_WIDTH} height={FIELD_HEIGHT} aria-label="Minifoot soccer field with player, rival, and ball" />

              {phase === "playing" && (
                <div className="touch-controls" aria-label="Touch game controls">
                  <div className="touch-control-group">
                    <div
                      ref={joystickRef}
                      className="joystick"
                      role="button"
                      tabIndex={-1}
                      aria-label="Drag to move your player"
                      onPointerDown={(event) => {
                        event.preventDefault();
                        joystickPointerRef.current = event.pointerId;
                        event.currentTarget.setPointerCapture(event.pointerId);
                        event.currentTarget.classList.add("engaged");
                        updateJoystick(event.clientX, event.clientY);
                      }}
                      onPointerMove={(event) => {
                        if (joystickPointerRef.current === event.pointerId) updateJoystick(event.clientX, event.clientY);
                      }}
                      onPointerUp={(event) => releaseJoystick(event.pointerId)}
                      onPointerCancel={(event) => releaseJoystick(event.pointerId)}
                    >
                      <div className="joystick-cross joystick-cross-horizontal" />
                      <div className="joystick-cross joystick-cross-vertical" />
                      <div ref={joystickThumbRef} className="joystick-thumb" />
                    </div>
                    <span>MOVE</span>
                  </div>
                  <div className="touch-control-group kick-group">
                    <button
                      className="kick-button"
                      type="button"
                      aria-label="Kick the ball"
                      onPointerDown={(event) => {
                        event.preventDefault();
                        gameRef.current?.requestKick();
                      }}
                    >
                      <BallMark size={27} />
                      <span>KICK</span>
                    </button>
                  </div>
                </div>
              )}

              {phase === "menu" && (
                <div className="screen-overlay start-screen">
                  <div className="start-content">
                    <div className="start-emblem"><BallMark size={47} /></div>
                    <p className="overlay-kicker">WELCOME TO THE LITTLE LEAGUE</p>
                    <h1 className="start-title"><span>MINI</span><span>FOOT<b>.</b></span></h1>
                    <p className="start-copy">One minute. One tiny pitch. All heart.</p>
                    <button className="primary-button" type="button" onClick={startMatch}>
                      <span>KICK OFF</span><ArrowIcon />
                    </button>
                    <p className="start-hint hint-keyboard">WASD / ARROWS TO MOVE <span>/</span> SPACE TO SHOOT</p>
                    <p className="start-hint hint-touch">DRAG TO MOVE <span>/</span> TAP TO KICK</p>
                  </div>
                </div>
              )}

              {phase === "paused" && (
                <div className="screen-overlay state-screen">
                  <div className="state-content">
                    <p className="overlay-kicker">TAKE A BREATHER</p>
                    <h2 className="state-title">PAUSED<b>.</b></h2>
                    <p className="state-copy">The clock can wait. Your rival can too.</p>
                    <button className="primary-button" type="button" onClick={resumeMatch}>
                      <span>RESUME GAME</span><ArrowIcon />
                    </button>
                    <button className="text-button" type="button" onClick={startMatch}>RESTART MATCH</button>
                    <p className="state-shortcut">PRESS P OR ESC TO RESUME</p>
                  </div>
                </div>
              )}

              {phase === "gameover" && result && (
                <div className="screen-overlay state-screen end-screen">
                  <div className="state-content end-content">
                    <p className="overlay-kicker">THE FINAL WHISTLE</p>
                    <h2 className="state-title">FULL TIME<b>.</b></h2>
                    <p className="state-copy">{resultLine}</p>
                    <div className="final-score"><span>YOU <strong>{result.home}</strong></span><i>:</i><span><strong>{result.away}</strong> RIVAL</span></div>
                    <div className="final-points"><strong>{formatPoints(result.points)}</strong><span>POINTS{place === 1 && result.points > 0 ? <em>NEW BEST!</em> : place > 0 ? <em>RANK #{place}</em> : null}</span></div>
                    <div className="name-entry">
                      <label htmlFor="player-initials">YOUR INITIALS</label>
                      <input
                        id="player-initials"
                        value={initials}
                        maxLength={3}
                        onChange={(event) => updateInitials(event.target.value)}
                        aria-label="Your three-letter initials for the local leaderboard"
                      />
                      <span>{place > 0 ? "AUTO-SAVED" : "TOP 5 ONLY"}</span>
                    </div>
                    <button className="primary-button" type="button" onClick={startMatch}>
                      <span>REMATCH</span><ArrowIcon />
                    </button>
                    <button className="text-button" type="button" onClick={openLeaderboard}>VIEW LEADERBOARD</button>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="arena-caption"><span>01 / STREET LEAGUE</span><span>SMALL PITCH. BIG MOMENTS.</span></div>
        </div>

        <aside className="sideline" aria-label="Game information and local high scores">
          <div className="sideline-topline"><span className="live-indicator" /> THE LITTLE LEAGUE <span> / 01</span></div>
          <h2>SMALL FIELD.<br /><em>LOUD MOMENTS.</em></h2>
          <p className="sideline-description">Beat the rival, stack your goals, and make every second count.</p>

          <div className="sideline-section controls-section">
            <div className="sideline-heading"><span>THE MOVES</span><span>DESKTOP</span></div>
            <div className="control-row"><div className="key-pair"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></div><span>MOVE</span></div>
            <div className="control-row"><div className="key-pair"><kbd className="space-key">SPACE</kbd></div><span>SHOOT</span></div>
            <div className="control-row"><div className="key-pair"><kbd>P</kbd></div><span>PAUSE</span></div>
          </div>

          <div className="sideline-section legends-section">
            <div className="sideline-heading"><span>LOCAL LEGENDS</span><button type="button" onClick={openLeaderboard}>VIEW ALL +</button></div>
            <ScoreRows scores={scores.slice(0, 3)} compact />
          </div>

          <p className="sideline-footer">60 SECONDS. INFINITE REMATCHES.</p>
        </aside>
      </main>

      {leaderboardOpen && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setLeaderboardOpen(false);
          }}
        >
          <section className="leaderboard-modal" role="dialog" aria-modal="true" aria-labelledby="leaderboard-title">
            <div className="modal-topline"><span>THE LITTLE LEAGUE / HALL OF FAME</span><button className="modal-close" type="button" onClick={() => setLeaderboardOpen(false)} aria-label="Close leaderboard"><CloseIcon /></button></div>
            <div className="modal-title-row"><TrophyIcon /><h2 id="leaderboard-title">LOCAL LEGENDS<span>.</span></h2></div>
            <p className="modal-description">Your five best runs, saved right here on this device.</p>
            <div className="score-list-heading"><span>RANK</span><span>PLAYER</span><span>GOALS</span><span>POINTS</span></div>
            <ScoreRows scores={scores} />
            <div className="modal-footer"><span>PLAY BIG. STAY LITTLE.</span><BallMark size={24} /></div>
          </section>
        </div>
      )}
    </div>
  );
}