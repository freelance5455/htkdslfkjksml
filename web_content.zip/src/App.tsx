import { useCallback, useEffect, useRef, useState } from "react";
import {
  createArenaRenderer,
  createRuntime,
  resetRuntime,
  roundLength,
  stepRuntime,
  type ArenaRenderer,
  type CombatEvent,
  type GameMode,
  type GameResult,
  type GameRuntime,
} from "./game/arena";

interface ScoreRecord {
  score: number;
  combo: number;
  createdAt: string;
}

interface HudState {
  playerHp: number;
  enemyHp: number;
  score: number;
  time: number;
  combo: number;
}

const RECORDS_KEY = "koocheh-fight.records.v1";
const FA_NUMBER = new Intl.NumberFormat("fa-IR");
const TWO_DIGITS = new Intl.NumberFormat("fa-IR", { minimumIntegerDigits: 2, useGrouping: false });

function loadRecords(): ScoreRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const stored: unknown = JSON.parse(window.localStorage.getItem(RECORDS_KEY) ?? "[]");
    if (!Array.isArray(stored)) return [];
    return stored
      .filter(
        (entry): entry is ScoreRecord =>
          typeof entry === "object" &&
          entry !== null &&
          typeof (entry as ScoreRecord).score === "number" &&
          typeof (entry as ScoreRecord).combo === "number" &&
          typeof (entry as ScoreRecord).createdAt === "string",
      )
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  } catch {
    return [];
  }
}

function formatTime(seconds: number): string {
  const safeSeconds = Math.max(0, Math.ceil(seconds));
  return `${TWO_DIGITS.format(Math.floor(safeSeconds / 60))}:${TWO_DIGITS.format(safeSeconds % 60)}`;
}

function recordDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleDateString("fa-IR", { day: "numeric", month: "short" });
}

function Icon({ name, size = 18 }: { name: "sound" | "mute" | "pause" | "play" | "restart" | "trophy" | "arrow"; size?: number }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  if (name === "sound") {
    return <svg {...common}><path d="M4 10v4h3l4 3V7l-4 3H4Z" /><path d="M15 9.5a4 4 0 0 1 0 5" /><path d="M17.5 7a7.5 7.5 0 0 1 0 10" /></svg>;
  }
  if (name === "mute") {
    return <svg {...common}><path d="M4 10v4h3l4 3V7l-4 3H4Z" /><path d="m16 9 5 6" /><path d="m21 9-5 6" /></svg>;
  }
  if (name === "pause") {
    return <svg {...common}><path d="M8 5h3v14H8zM15 5h3v14h-3z" fill="currentColor" stroke="none" /></svg>;
  }
  if (name === "play") {
    return <svg {...common}><path d="m8 5 11 7-11 7V5Z" fill="currentColor" stroke="none" /></svg>;
  }
  if (name === "restart") {
    return <svg {...common}><path d="M20 7v5h-5" /><path d="M19.1 12a7.1 7.1 0 1 1-2.1-5" /></svg>;
  }
  if (name === "trophy") {
    return <svg {...common}><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4Z" /><path d="M7 7H4v2a4 4 0 0 0 4 4M17 7h3v2a4 4 0 0 1-4 4" /></svg>;
  }
  return <svg {...common}><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
}

function playImpactSound(audioRef: React.MutableRefObject<AudioContext | null>, event: CombatEvent): void {
  if (typeof window === "undefined") return;
  try {
    const AudioContextClass = window.AudioContext;
    if (!AudioContextClass) return;
    const context = audioRef.current ?? new AudioContextClass();
    audioRef.current = context;
    if (context.state === "suspended") void context.resume();

    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const now = context.currentTime;
    const blocked = event.kind === "block";
    oscillator.type = blocked ? "triangle" : "sawtooth";
    oscillator.frequency.setValueAtTime(blocked ? 260 : event.playerAttack ? 145 : 125, now);
    oscillator.frequency.exponentialRampToValueAtTime(blocked ? 120 : 62, now + 0.12);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(blocked ? 0.085 : 0.14, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.14);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.15);
  } catch {
    // Audio is optional; the visual hit feedback remains available.
  }
}

function App() {
  const arenaHostRef = useRef<HTMLDivElement>(null);
  const runtimeRef = useRef<GameRuntime>(createRuntime());
  const modeRef = useRef<GameMode>("menu");
  const heldInputsRef = useRef(new Set<string>());
  const pressedInputsRef = useRef(new Set<string>());
  const audioRef = useRef<AudioContext | null>(null);
  const soundRef = useRef(true);
  const recordsRef = useRef<ScoreRecord[]>([]);

  const [mode, setMode] = useState<GameMode>("menu");
  const [soundOn, setSoundOn] = useState(true);
  const [winner, setWinner] = useState<GameResult | null>(null);
  const [showRecords, setShowRecords] = useState(false);
  const [graphicsError, setGraphicsError] = useState(false);
  const [records, setRecords] = useState<ScoreRecord[]>(() => loadRecords());
  const [hud, setHud] = useState<HudState>({
    playerHp: 100,
    enemyHp: 100,
    score: 0,
    time: roundLength(),
    combo: 0,
  });
  recordsRef.current = records;

  const changeMode = useCallback((next: GameMode) => {
    modeRef.current = next;
    setMode(next);
  }, []);

  const clearInputs = useCallback(() => {
    heldInputsRef.current.clear();
    pressedInputsRef.current.clear();
  }, []);

  const unlockAudio = useCallback(() => {
    if (!soundRef.current || typeof window === "undefined" || !window.AudioContext) return;
    try {
      const context = audioRef.current ?? new window.AudioContext();
      audioRef.current = context;
      if (context.state === "suspended") void context.resume();
    } catch {
      // Some browsers do not allow Web Audio; play continues without sound.
    }
  }, []);

  const startGame = useCallback(() => {
    resetRuntime(runtimeRef.current);
    clearInputs();
    setWinner(null);
    setShowRecords(false);
    setHud({ playerHp: 100, enemyHp: 100, score: 0, time: roundLength(), combo: 0 });
    changeMode("playing");
    unlockAudio();
  }, [changeMode, clearInputs, unlockAudio]);

  const finishGame = useCallback((result: GameResult) => {
    if (modeRef.current !== "playing") return;
    const runtime = runtimeRef.current;
    if (result === "player") {
      runtime.score += Math.ceil(runtime.time) * 28 + runtime.bestCombo * 75;
    }
    const entry: ScoreRecord = {
      score: runtime.score,
      combo: runtime.bestCombo,
      createdAt: new Date().toISOString(),
    };
    const nextRecords = [...recordsRef.current, entry]
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
    recordsRef.current = nextRecords;
    setRecords(nextRecords);
    try {
      window.localStorage.setItem(RECORDS_KEY, JSON.stringify(nextRecords));
    } catch {
      // The round still ends cleanly if browser storage is unavailable.
    }
    setWinner(result);
    setShowRecords(true);
    setHud({
      playerHp: runtime.player.hp,
      enemyHp: runtime.enemy.hp,
      score: runtime.score,
      time: runtime.time,
      combo: runtime.bestCombo,
    });
    clearInputs();
    changeMode("gameover");
  }, [changeMode, clearInputs]);

  const togglePause = useCallback(() => {
    if (modeRef.current === "playing") {
      clearInputs();
      changeMode("paused");
      return;
    }
    if (modeRef.current === "paused") {
      changeMode("playing");
      unlockAudio();
    }
  }, [changeMode, clearInputs, unlockAudio]);

  const toggleSound = useCallback(() => {
    const next = !soundRef.current;
    soundRef.current = next;
    setSoundOn(next);
    if (next) unlockAudio();
  }, [unlockAudio]);

  useEffect(() => {
    const keyMap: Record<string, string> = {
      arrowleft: "left",
      a: "left",
      arrowright: "right",
      d: "right",
      j: "punch",
      z: "punch",
      k: "kick",
      x: "kick",
      l: "guard",
      c: "guard",
      shift: "guard",
      " ": "jump",
    };

    const onKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      const target = event.target;
      if (target instanceof HTMLElement && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;

      if (["arrowleft", "arrowright", " "].includes(key)) event.preventDefault();
      if ((key === "p" || key === "escape") && !event.repeat) {
        togglePause();
        return;
      }
      if (key === "enter" && !event.repeat) {
        if (modeRef.current === "menu" || modeRef.current === "gameover") startGame();
        else if (modeRef.current === "paused") togglePause();
        return;
      }
      if (modeRef.current !== "playing") return;

      const action = keyMap[key];
      if (!action) return;
      if (!heldInputsRef.current.has(action)) pressedInputsRef.current.add(action);
      heldInputsRef.current.add(action);
    };

    const onKeyUp = (event: KeyboardEvent) => {
      const action = keyMap[event.key.toLowerCase()];
      if (action) heldInputsRef.current.delete(action);
    };

    const onVisibilityChange = () => {
      if (document.hidden && modeRef.current === "playing") {
        clearInputs();
        changeMode("paused");
      }
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [changeMode, clearInputs, startGame, togglePause]);

  useEffect(() => {
    const host = arenaHostRef.current;
    if (!host) return;

    let arena: ArenaRenderer;
    try {
      arena = createArenaRenderer(host);
    } catch {
      setGraphicsError(true);
      return;
    }

    let frameId = 0;
    let previous = performance.now();
    let hudElapsed = 0;
    const frame = (now: number) => {
      const dt = Math.min((now - previous) / 1000, 0.04);
      previous = now;
      const runtime = runtimeRef.current;

      if (modeRef.current === "playing") {
        const pressed = [...pressedInputsRef.current];
        pressedInputsRef.current.clear();
        const result = stepRuntime(runtime, dt, heldInputsRef.current, pressed);
        runtime.events.forEach((event) => {
          if (soundRef.current) playImpactSound(audioRef, event);
          if (event.kind === "hit" && typeof navigator !== "undefined" && "vibrate" in navigator) {
            navigator.vibrate?.(12);
          }
        });
        if (result) finishGame(result);
      } else {
        runtime.visualTime += dt;
      }

      arena.render(runtime, modeRef.current);
      hudElapsed += dt;
      if (hudElapsed >= 0.1) {
        hudElapsed = 0;
        setHud({
          playerHp: runtime.player.hp,
          enemyHp: runtime.enemy.hp,
          score: runtime.score,
          time: runtime.time,
          combo: runtime.combo,
        });
      }
      frameId = window.requestAnimationFrame(frame);
    };

    frameId = window.requestAnimationFrame(frame);
    return () => {
      window.cancelAnimationFrame(frameId);
      arena.dispose();
    };
  }, [finishGame]);

  const bindTouchControl = (action: string) => ({
    onPointerDown: (event: React.PointerEvent<HTMLButtonElement>) => {
      event.preventDefault();
      if (modeRef.current !== "playing") return;
      event.currentTarget.setPointerCapture(event.pointerId);
      if (!heldInputsRef.current.has(action)) pressedInputsRef.current.add(action);
      heldInputsRef.current.add(action);
      event.currentTarget.classList.add("is-held");
    },
    onPointerUp: (event: React.PointerEvent<HTMLButtonElement>) => {
      heldInputsRef.current.delete(action);
      event.currentTarget.classList.remove("is-held");
    },
    onPointerCancel: (event: React.PointerEvent<HTMLButtonElement>) => {
      heldInputsRef.current.delete(action);
      event.currentTarget.classList.remove("is-held");
    },
    onLostPointerCapture: (event: React.PointerEvent<HTMLButtonElement>) => {
      heldInputsRef.current.delete(action);
      event.currentTarget.classList.remove("is-held");
    },
  });

  const topScore = records[0]?.score ?? 0;
  const outcomeTitle = winner === "player" ? "پیروز شدی!" : winner === "enemy" ? "ساسی مانکن پیروز شد" : "مساوی شد!";

  return (
    <main className="app-shell" dir="rtl">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="app-frame">
        <header className="topbar">
          <div className="brand-lockup">
            <div className="brand-mark" aria-hidden="true">
              <span />
              <span />
              <i />
            </div>
            <div className="brand-copy">
              <h1>کوچه‌فایت</h1>
              <span>ARENA / TEHRAN AFTER DARK</span>
            </div>
          </div>
          <div className="topbar-actions" dir="ltr">
            <div className="round-tag"><span className="status-light" /> ARCADE 01</div>
            <button className="icon-button" type="button" onClick={toggleSound} aria-label={soundOn ? "خاموش کردن صدا" : "روشن کردن صدا"} title={soundOn ? "صدا روشن" : "صدا خاموش"}>
              <Icon name={soundOn ? "sound" : "mute"} />
            </button>
            {(mode === "playing" || mode === "paused") && (
              <button className="icon-button pause-top" type="button" onClick={togglePause} aria-label={mode === "playing" ? "توقف بازی" : "ادامه بازی"} title={mode === "playing" ? "توقف" : "ادامه"}>
                <Icon name={mode === "playing" ? "pause" : "play"} />
              </button>
            )}
          </div>
        </header>

        <section className="match-hud" aria-label="وضعیت مبارزه" dir="ltr">
          <div className="fighter-slot player-slot" dir="rtl">
            <div className="fighter-name-row">
              <span className="corner-index player-index">01</span>
              <div className="fighter-name-copy">
                <strong>امیر تتلو</strong>
                <span>شخصیت تو <i className="fighter-dot player-dot" /></span>
              </div>
              <span className="fighter-role">PLAYER</span>
            </div>
            <div className="health-track" aria-label={`سلامت بازیکن ${Math.round(hud.playerHp)} درصد`}>
              <span className="health-fill player-fill" style={{ width: `${hud.playerHp}%` }} />
            </div>
            <div className="health-caption"><span>سلامت</span><span>{FA_NUMBER.format(Math.ceil(hud.playerHp))}%</span></div>
          </div>

          <div className="match-clock" dir="rtl">
            <span className="round-number">ROUND 01</span>
            <strong>{formatTime(hud.time)}</strong>
            <span className="score-readout"><b>{FA_NUMBER.format(hud.score)}</b> امتیاز</span>
          </div>

          <div className="fighter-slot enemy-slot" dir="rtl">
            <div className="fighter-name-row">
              <span className="corner-index enemy-index">02</span>
              <div className="fighter-name-copy">
                <strong>ساسی مانکن</strong>
                <span><i className="fighter-dot enemy-dot" /> رقیب هوش مصنوعی</span>
              </div>
              <span className="fighter-role">CPU</span>
            </div>
            <div className="health-track enemy-health" aria-label={`سلامت حریف ${Math.round(hud.enemyHp)} درصد`}>
              <span className="health-fill enemy-fill" style={{ width: `${hud.enemyHp}%` }} />
            </div>
            <div className="health-caption"><span>سلامت</span><span>{FA_NUMBER.format(Math.ceil(hud.enemyHp))}%</span></div>
          </div>
        </section>

        <section className="arena-section" aria-label="میدان مبارزه سه‌بعدی">
          <div className={`arena-frame ${mode === "playing" ? "is-live" : ""}`}>
            <div className="arena-canvas" ref={arenaHostRef} />
            <div className="arena-vignette" />
            <div className="arena-edge top-edge" />
            <div className="arena-corner-mark mark-left" />
            <div className="arena-corner-mark mark-right" />

            {graphicsError && (
              <div className="graphics-warning" role="status">
                مرورگر شما رندر سه‌بعدی را پشتیبانی نمی‌کند. WebGL را فعال کنید و دوباره صفحه را باز کنید.
              </div>
            )}

            {mode !== "playing" && (
              <div className={`screen-overlay overlay-${mode}`}>
                {mode === "menu" && (
                  <div className="overlay-content intro-content" dir="rtl">
                    <div className="overlay-kicker"><span /> FIRST ROUND <b>·</b> TEHRAN, 02:17 AM</div>
                    <h2>شبِ مبارزه شروع می‌شود</h2>
                    <p><strong>امیر تتلو</strong><span className="vs-word"> در برابر </span><strong>ساسی مانکن</strong>؛ دو آواتار خیالی، یک رینگ نئونی.</p>
                    <button className="primary-action" type="button" onClick={startGame}>
                      <span>شروع مبارزه</span><Icon name="arrow" size={19} />
                    </button>
                    <div className="overlay-help"><span>رکورد محلی</span><b>{FA_NUMBER.format(topScore)}</b><i /> <span>برای شروع، Enter</span></div>
                  </div>
                )}

                {mode === "paused" && (
                  <div className="overlay-content pause-content" dir="rtl">
                    <div className="overlay-kicker"><span /> ROUND PAUSED</div>
                    <h2>یه نفس تازه کن</h2>
                    <p>رینگ منتظرته. هر وقت آماده‌ای ادامه بده.</p>
                    <div className="overlay-actions">
                      <button className="primary-action" type="button" onClick={togglePause}><Icon name="play" size={17} /><span>ادامه مبارزه</span></button>
                      <button className="secondary-action" type="button" onClick={startGame}><Icon name="restart" size={17} /><span>شروع دوباره</span></button>
                    </div>
                  </div>
                )}

                {mode === "gameover" && (
                  <div className="overlay-content result-content" dir="rtl">
                    <div className="overlay-kicker"><span /> ROUND COMPLETE</div>
                    <h2>{outcomeTitle}</h2>
                    <div className="final-score"><span>امتیاز این راند</span><strong>{FA_NUMBER.format(hud.score)}</strong></div>
                    <div className="result-records">
                      <div className="records-heading"><Icon name="trophy" size={15} /><span>رکوردهای محلی</span></div>
                      {records.length === 0 ? <p className="empty-records">هنوز رکوردی ثبت نشده</p> : records.slice(0, 3).map((record, index) => (
                        <div className="mini-record-row" key={`${record.createdAt}-${index}`}>
                          <span className="mini-rank">{FA_NUMBER.format(index + 1)}</span>
                          <span className="mini-record-date">{recordDate(record.createdAt)}</span>
                          <strong>{FA_NUMBER.format(record.score)}</strong>
                        </div>
                      ))}
                    </div>
                    <div className="overlay-actions result-actions">
                      <button className="primary-action" type="button" onClick={startGame}><Icon name="restart" size={17} /><span>یه راند دیگه</span></button>
                      <button className="secondary-action" type="button" onClick={() => { resetRuntime(runtimeRef.current); setHud({ playerHp: 100, enemyHp: 100, score: 0, time: roundLength(), combo: 0 }); setShowRecords(false); setWinner(null); changeMode("menu"); }}><span>صفحه شروع</span></button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          <div className="arena-caption" dir="rtl">
            <span className="caption-live"><i /> {mode === "playing" ? "مبارزه زنده" : mode === "paused" ? "بازی متوقف" : mode === "gameover" ? "پایان راند" : "آماده ورود به رینگ"}</span>
            <span className="caption-combo">{hud.combo > 1 ? <><b>COMBO × {FA_NUMBER.format(hud.combo)}</b><span>ضربه پشت سر هم</span></> : <><b>BEST {FA_NUMBER.format(topScore)}</b><span>رکورد محلی</span></>}</span>
          </div>
        </section>

        <section className="touch-controls" aria-label="کنترل لمسی بازی" dir="ltr">
          <div className="control-cluster movement-cluster">
            <span className="cluster-label">MOVE</span>
            <div className="control-buttons">
              <button className="touch-button move-button" type="button" aria-label="حرکت به چپ" {...bindTouchControl("left")}><span className="arrow-glyph left-arrow" /></button>
              <button className="touch-button move-button" type="button" aria-label="حرکت به راست" {...bindTouchControl("right")}><span className="arrow-glyph right-arrow" /></button>
              <button className="touch-button jump-button" type="button" aria-label="پرش" {...bindTouchControl("jump")}><span className="arrow-glyph up-arrow" /><small>پرش</small></button>
            </div>
          </div>
          <div className="control-separator" />
          <div className="control-cluster action-cluster">
            <span className="cluster-label">FIGHT</span>
            <div className="control-buttons">
              <button className="touch-button attack-button punch-button" type="button" aria-label="مشت" {...bindTouchControl("punch")}><b>J</b><small>مشت</small></button>
              <button className="touch-button attack-button kick-button" type="button" aria-label="لگد" {...bindTouchControl("kick")}><b>K</b><small>لگد</small></button>
              <button className="touch-button attack-button guard-button" type="button" aria-label="دفاع" {...bindTouchControl("guard")}><b>L</b><small>دفاع</small></button>
            </div>
          </div>
        </section>

        <footer className="game-footer" dir="rtl">
          <div className="footer-record">
            <Icon name="trophy" size={16} />
            <span>بهترین رکورد</span>
            <strong>{FA_NUMBER.format(topScore)}</strong>
          </div>
          <button className={`leaderboard-toggle ${showRecords ? "is-open" : ""}`} type="button" onClick={() => setShowRecords((open) => !open)} aria-expanded={showRecords}>
            {showRecords ? "بستن جدول" : "جدول رکوردها"}<span className="toggle-chevron">⌄</span>
          </button>
          <div className="keyboard-hint" dir="ltr">
            <span>MOVE</span> A / D <i /> <span>PUNCH</span> J <i /> <span>KICK</span> K <i /> <span>GUARD</span> L <i /> <span>JUMP</span> SPACE
          </div>
        </footer>

        {showRecords && (
          <section className="leaderboard-panel" aria-label="جدول رکوردهای محلی">
            <div className="leaderboard-title">
              <span className="leaderboard-overline">LOCAL ARCADE RECORDS</span>
              <h2>جدول رکوردها</h2>
            </div>
            <div className="leaderboard-table" role="table" aria-label="رکوردهای برتر">
              <div className="leaderboard-row table-head" role="row">
                <span role="columnheader">رتبه</span><span role="columnheader">بازیکن</span><span role="columnheader">امتیاز</span><span role="columnheader">بهترین کمبو</span><span role="columnheader">تاریخ</span>
              </div>
              {records.length === 0 ? (
                <div className="leaderboard-empty">هنوز رکوردی ثبت نشده؛ اولین مبارزه مال توست.</div>
              ) : records.map((record, index) => (
                <div className={`leaderboard-row ${index === 0 ? "top-record" : ""}`} role="row" key={`${record.createdAt}-${index}`}>
                  <span className="rank-cell" role="cell">{FA_NUMBER.format(index + 1)}</span>
                  <span className="player-cell" role="cell">بازیکن</span>
                  <strong role="cell">{FA_NUMBER.format(record.score)}</strong>
                  <span role="cell">× {FA_NUMBER.format(record.combo)}</span>
                  <span role="cell">{recordDate(record.createdAt)}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        <div className="page-note" dir="rtl">
          <span>آواتارها خیالی‌اند؛ رقابت برای سرگرمی است.</span>
          <span>ذخیره رکورد فقط روی همین دستگاه</span>
        </div>
      </div>
    </main>
  );
}

export default App;