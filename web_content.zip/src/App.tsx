import React, { useState, useEffect } from 'react';
import { Agent, ThemeMode, LanguageCode } from './types';
import { TRANSLATIONS } from './translations';
import { LockScreen } from './components/LockScreen';
import { AnniversaryBanner } from './components/AnniversaryBanner';
import { RgbLogStream } from './components/RgbLogStream';
import { TrendingRadarTab } from './components/TrendingRadarTab';
import { ChatTab } from './components/ChatTab';
import { ViralityCalculatorTab } from './components/ViralityCalculatorTab';
import { PythonStudioTab } from './components/PythonStudioTab';
import { PhotoStudioTab } from './components/PhotoStudioTab';
import { SettingsModal } from './components/SettingsModal';
import { AgentManagerModal } from './components/AgentManagerModal';
import { ViralSamratLogo } from './components/ViralSamratLogo';
import { 
  Flame, 
  MessageSquare, 
  Gauge, 
  Code2, 
  Settings, 
  Bot, 
  Smartphone, 
  Maximize2, 
  Lock, 
  Sparkles,
  Wifi,
  Battery,
  ShieldCheck,
  RefreshCw,
  PartyPopper,
  Crown,
  ImagePlus
} from 'lucide-react';

const DEFAULT_AGENTS: Agent[] = [
  {
    id: 'agent-1',
    name: 'ViralSamrat AI (वायरल सम्राट)',
    role: 'The YouTube Trend King • Real-time Radar, Bhavishya Waves & 4K Photo Studio',
    avatar: '👑',
    color: 'cyan',
    customInstructions: 'You are ViralSamrat AI, the undisputed YouTube Trend King. Always provide elite retention tactics, high-CTR thumbnail ideas, and generate stunning photo creations whenever requested.',
    isDefault: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'agent-2',
    name: 'Shorts 60s Dopamine Hacker',
    role: 'Specialist in 3-second visual hooks, rapid pacing, and infinite loop scripts',
    avatar: '🔥',
    color: 'pink',
    customInstructions: 'Every tip must focus on the first 3 seconds and the seamless end-to-beginning loop of YouTube Shorts.',
    isDefault: false,
    isCustom: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'agent-3',
    name: 'Audio & Song Trend Hunter',
    role: 'Detects viral Bollywood phonk, slowed+reverb tracks, and audio wave spikes',
    avatar: '🎵',
    color: 'emerald',
    customInstructions: 'Analyze audio pacing, BPM for Shorts, and advise creators on which background songs are getting algorithm boost.',
    isDefault: false,
    isCustom: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'agent-4',
    name: 'Bhavishya / Future Wave AI',
    role: 'Predicts what topics and meme formats will blow up in the next 14 to 30 days',
    avatar: '🔮',
    color: 'amber',
    customInstructions: 'Provide predictive analysis on upcoming seasonal surges, tech breakthroughs, and emerging creator formats.',
    isDefault: false,
    isCustom: false,
    createdAt: new Date().toISOString(),
  }
];

export default function App() {
  // App Lock & Passcode State (default password is '7860')
  const [isLocked, setIsLocked] = useState(true);
  const [passcode, setPasscode] = useState('7860');
  const [isLockEnabled, setIsLockEnabled] = useState(true);

  // App Configuration
  const [theme, setTheme] = useState<ThemeMode>('cyber-rgb');
  const [language, setLanguage] = useState<LanguageCode>('hinglish');
  const [isMobileFrame, setIsMobileFrame] = useState(false);

  // Tab State
  const [activeTab, setActiveTab] = useState<'radar' | 'chat' | 'photo' | 'virality' | 'python'>('radar');

  // Agents State
  const [agents, setAgents] = useState<Agent[]>(() => {
    try {
      const saved = localStorage.getItem('viralpulse_agents');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_AGENTS;
  });
  const [activeAgentId, setActiveAgentId] = useState<string>('agent-1');

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAgentManagerOpen, setIsAgentManagerOpen] = useState(false);
  const [externalPrompt, setExternalPrompt] = useState<string | undefined>(undefined);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Save agents to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('viralpulse_agents', JSON.stringify(agents));
    } catch (e) {
      console.error('Failed to save agents:', e);
    }
  }, [agents]);

  // Save preferences
  useEffect(() => {
    try {
      const savedPref = localStorage.getItem('viralpulse_pref');
      if (savedPref) {
        const parsed = JSON.parse(savedPref);
        if (parsed.theme) setTheme(parsed.theme);
        if (parsed.language) setLanguage(parsed.language);
        if (parsed.passcode) setPasscode(parsed.passcode);
        if (parsed.isLockEnabled !== undefined) {
          setIsLockEnabled(parsed.isLockEnabled);
          setIsLocked(parsed.isLockEnabled);
        }
        if (parsed.isMobileFrame !== undefined) setIsMobileFrame(parsed.isMobileFrame);
      }
    } catch {
      // ignore
    }
  }, []);

  const savePreferences = (updated: Partial<{
    theme: ThemeMode;
    language: LanguageCode;
    passcode: string;
    isLockEnabled: boolean;
    isMobileFrame: boolean;
  }>) => {
    try {
      const current = { theme, language, passcode, isLockEnabled, isMobileFrame, ...updated };
      localStorage.setItem('viralpulse_pref', JSON.stringify(current));
    } catch {
      // ignore
    }
  };

  const handleThemeChange = (newTheme: ThemeMode) => {
    setTheme(newTheme);
    savePreferences({ theme: newTheme });
  };

  const handleLanguageChange = (newLang: LanguageCode) => {
    setLanguage(newLang);
    savePreferences({ language: newLang });
  };

  const handlePasscodeChange = (newPin: string) => {
    setPasscode(newPin);
    savePreferences({ passcode: newPin });
  };

  const handleToggleLock = (enabled: boolean) => {
    setIsLockEnabled(enabled);
    savePreferences({ isLockEnabled: enabled });
  };

  const handleToggleMobileFrame = (enabled: boolean) => {
    setIsMobileFrame(enabled);
    savePreferences({ isMobileFrame: enabled });
  };

  // Agent Creation
  const handleCreateAgent = (newAgentData: Omit<Agent, 'id' | 'createdAt'>) => {
    const newAgent: Agent = {
      ...newAgentData,
      id: `custom-agent-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    const updated = [...agents, newAgent];
    setAgents(updated);
    setActiveAgentId(newAgent.id);
  };

  // Agent Deletion
  const handleDeleteAgent = (agentId: string) => {
    const updated = agents.filter(a => a.id !== agentId);
    setAgents(updated);
    // Remove chat history for deleted agent
    try {
      localStorage.removeItem(`viralpulse_chat_${agentId}`);
    } catch {
      // ignore
    }
    if (activeAgentId === agentId) {
      setActiveAgentId(updated[0]?.id || 'agent-1');
    }
  };

  // Quick switch to chat when user clicks "Ask Agent About This"
  const handleAskAboutTrend = (trendTopic: string) => {
    setExternalPrompt(trendTopic);
    setActiveTab('chat');
  };

  const activeAgent = agents.find(a => a.id === activeAgentId) || agents[0];

  // Theme container classes
  const getThemeClass = () => {
    switch (theme) {
      case 'black-white':
        return 'grayscale contrast-125 bg-black text-white font-mono';
      case 'clean-light':
        return 'bg-zinc-100 text-zinc-900';
      case 'midnight-dark':
        return 'bg-slate-950 text-slate-100';
      case 'cyber-rgb':
      default:
        return 'bg-zinc-950 text-zinc-100';
    }
  };

  return (
    <div className={`min-h-screen ${getThemeClass()} flex items-center justify-center transition-colors duration-300 relative overflow-x-hidden selection:bg-cyan-500 selection:text-black`}>
      {/* Background ambient lighting for Cyber RGB theme */}
      {theme === 'cyber-rgb' && (
        <>
          <div className="fixed -top-40 -left-40 w-96 h-96 rounded-full bg-cyan-500/10 blur-[120px] pointer-events-none" />
          <div className="fixed -bottom-40 -right-40 w-96 h-96 rounded-full bg-pink-500/10 blur-[120px] pointer-events-none" />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-purple-500/5 blur-[160px] pointer-events-none" />
        </>
      )}

      {/* Passcode Lock Screen (Default PIN: 7860) */}
      {isLocked && isLockEnabled && (
        <LockScreen
          passcode={passcode}
          onUnlock={() => setIsLocked(false)}
          language={language}
        />
      )}

      {/* Main Container: Mobile Frame vs Full Screen View */}
      <div
        className={`w-full transition-all duration-300 ${
          isMobileFrame
            ? 'max-w-[440px] my-6 rounded-[44px] p-3 border-4 border-zinc-700 bg-zinc-900 shadow-2xl ring-8 ring-zinc-800/80 relative'
            : 'max-w-6xl p-4 sm:p-6 my-auto'
        }`}
      >
        {/* Mobile Phone Mockup Chassis Header (Punch hole camera + status bar) */}
        {isMobileFrame && (
          <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 mb-2 text-zinc-400 text-xs font-mono select-none">
            <span className="font-bold text-white text-[11px]">11:06</span>
            <div className="w-16 h-4 bg-black rounded-full flex items-center justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-zinc-800" />
            </div>
            <div className="flex items-center gap-1.5">
              <Wifi className="w-3 h-3 text-cyan-400" />
              <Battery className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>
        )}

        {/* Outer App Shell with optional RGB border */}
        <div
          className={`rounded-3xl ${
            theme === 'cyber-rgb' ? 'p-[1.5px] rgb-gradient-border shadow-2xl' : 'border border-white/10'
          }`}
        >
          <div className={`rounded-[22px] ${theme === 'clean-light' ? 'bg-white' : 'bg-zinc-950/95'} p-4 sm:p-6 backdrop-blur-2xl overflow-hidden`}>
            
            {/* Top Navigation Bar */}
            <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10 mb-4">
              <div className="flex items-center gap-3">
                <ViralSamratLogo size="md" showText={false} />
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                      <span className={theme === 'cyber-rgb' ? 'rgb-text font-extrabold' : ''}>
                        {t.appTitle}
                      </span>
                    </h1>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      APK v3.2 PRO
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    {t.appSubtitle}
                  </p>
                </div>
              </div>

              {/* Header Right Actions */}
              <div className="flex items-center gap-2 self-end sm:self-auto">
                {/* Active Agent Badge */}
                <button
                  onClick={() => setIsAgentManagerOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-zinc-200 border border-white/10 flex items-center gap-1.5 transition-all"
                >
                  <Bot className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="max-w-[120px] truncate">{activeAgent.name}</span>
                  <RefreshCw className="w-3 h-3 text-zinc-500" />
                </button>

                {/* Lock quick button */}
                {isLockEnabled && (
                  <button
                    onClick={() => setIsLocked(true)}
                    title="Lock App"
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white border border-white/10 transition-colors"
                  >
                    <Lock className="w-4 h-4" />
                  </button>
                )}

                {/* Mobile / Fullscreen Toggle */}
                <button
                  onClick={() => handleToggleMobileFrame(!isMobileFrame)}
                  title="Toggle Mobile Chassis View"
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white border border-white/10 transition-colors hidden sm:flex"
                >
                  {isMobileFrame ? <Maximize2 className="w-4 h-4" /> : <Smartphone className="w-4 h-4 text-cyan-400" />}
                </button>

                {/* Settings Gear */}
                <button
                  onClick={() => setIsSettingsOpen(true)}
                  title={t.tabSettings}
                  className="p-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 transition-all"
                >
                  <Settings className="w-4 h-4" />
                </button>
              </div>
            </header>

            {/* Special Happy Anniversary Banner */}
            <AnniversaryBanner language={language} />

            {/* Dynamic RGB Cyber Log Viewer */}
            <RgbLogStream />

            {/* Navigation Tab Bar */}
            <nav className="flex items-center gap-1.5 p-1 bg-zinc-900/80 rounded-2xl border border-white/5 mb-5 overflow-x-auto scrollbar-none">
              <button
                onClick={() => setActiveTab('radar')}
                className={`flex-1 min-w-[110px] py-2.5 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 flex items-center justify-center gap-2 ${
                  activeTab === 'radar'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md shadow-rose-500/20'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Flame className="w-4 h-4" />
                <span>{t.tabRadar}</span>
              </button>

              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 min-w-[110px] py-2.5 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 flex items-center justify-center gap-2 ${
                  activeTab === 'chat'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/20'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>{t.tabChat}</span>
              </button>

              <button
                onClick={() => setActiveTab('photo')}
                className={`flex-1 min-w-[110px] py-2.5 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 flex items-center justify-center gap-2 ${
                  activeTab === 'photo'
                    ? 'bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 text-white shadow-md shadow-pink-500/20'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <ImagePlus className="w-4 h-4" />
                <span>{t.tabPhoto}</span>
              </button>

              <button
                onClick={() => setActiveTab('virality')}
                className={`flex-1 min-w-[110px] py-2.5 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 flex items-center justify-center gap-2 ${
                  activeTab === 'virality'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-black shadow-md shadow-emerald-500/20'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Gauge className="w-4 h-4" />
                <span>{t.tabVirality}</span>
              </button>

              <button
                onClick={() => setActiveTab('python')}
                className={`flex-1 min-w-[110px] py-2.5 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 flex items-center justify-center gap-2 ${
                  activeTab === 'python'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-md shadow-amber-500/20'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Code2 className="w-4 h-4" />
                <span>{t.tabPython}</span>
              </button>
            </nav>

            {/* Active Tab View Body */}
            <main className="transition-all duration-300">
              <div key={activeTab} className="animate-fade-in-up">
                {activeTab === 'radar' && (
                  <TrendingRadarTab
                    language={language}
                    onAskAboutTrend={handleAskAboutTrend}
                  />
                )}

                {activeTab === 'chat' && (
                  <ChatTab
                    agent={activeAgent}
                    language={language}
                    onOpenAgentManager={() => setIsAgentManagerOpen(true)}
                    externalPrompt={externalPrompt}
                    onClearExternalPrompt={() => setExternalPrompt(undefined)}
                  />
                )}

                {activeTab === 'photo' && (
                  <PhotoStudioTab language={language} />
                )}

                {activeTab === 'virality' && (
                  <ViralityCalculatorTab language={language} />
                )}

                {activeTab === 'python' && (
                  <PythonStudioTab language={language} />
                )}
              </div>
            </main>

            {/* APK Footer / System Status */}
            <footer className="mt-8 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-zinc-500">
              <div className="flex items-center gap-2 font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>STATUS: YOUTUBE ALGORITHM RADAR CONNECTED</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Security: <strong className="text-emerald-400 font-mono">ACTIVE</strong></span>
                <span>•</span>
                <span>Language: <strong className="text-zinc-300 uppercase">{language}</strong></span>
              </div>
            </footer>
          </div>
        </div>

        {/* Mobile Mockup Home Bottom Indicator */}
        {isMobileFrame && (
          <div className="flex items-center justify-center pt-3 pb-1">
            <div className="w-32 h-1 bg-white/30 rounded-full" />
          </div>
        )}
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        theme={theme}
        onThemeChange={handleThemeChange}
        language={language}
        onLanguageChange={handleLanguageChange}
        passcode={passcode}
        onPasscodeChange={handlePasscodeChange}
        isLockEnabled={isLockEnabled}
        onToggleLock={handleToggleLock}
        isMobileFrame={isMobileFrame}
        onToggleMobileFrame={handleToggleMobileFrame}
      />

      {/* Agent Manager Modal */}
      <AgentManagerModal
        isOpen={isAgentManagerOpen}
        onClose={() => setIsAgentManagerOpen(false)}
        agents={agents}
        activeAgentId={activeAgentId}
        onSelectAgent={setActiveAgentId}
        onCreateAgent={handleCreateAgent}
        onDeleteAgent={handleDeleteAgent}
        language={language}
      />
    </div>
  );
}
