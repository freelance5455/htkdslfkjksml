import React, { useState, useEffect } from 'react';
import { Activity, ActivityCategory, AppState, PhotoRecord, UserProfile, WeightRecord } from './types';
import { loadAppState, saveAppState } from './utils/storage';
import { calculateDailyProgress, calculateDayNumber, calculateStreak, formatDate } from './utils/tracker';
import { sendLocalNotification } from './utils/notifications';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { HomeView } from './views/HomeView';
import { CategoriesView } from './views/CategoriesView';
import { TransformationView } from './views/TransformationView';
import { CalendarView } from './views/CalendarView';
import { StatsView } from './views/StatsView';
import { AddActivityModal } from './components/AddActivityModal';
import { WorkoutTimerModal } from './components/WorkoutTimerModal';
import { DailyCelebrationModal } from './components/DailyCelebrationModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  const [state, setState] = useState<AppState>(() => loadAppState());
  const [activeTab, setActiveTab] = useState<TabType>('routine');
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<ActivityCategory>('workout');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);

  const [isTimerOpen, setIsTimerOpen] = useState(false);
  const [timerExerciseName, setTimerExerciseName] = useState('Rest Period');
  const [timerSeconds, setTimerSeconds] = useState(60);

  const [isCelebrationOpen, setIsCelebrationOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Synchronize dark mode class on <html>
  useEffect(() => {
    if (state.profile.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.profile.darkMode]);

  // Persist state updates
  const updateState = (newState: AppState) => {
    setState(newState);
    saveAppState(newState);
  };

  const todayStr = formatDate(new Date());
  const activeDateStr = state.activeDate || todayStr;

  const dayNumber = calculateDayNumber(state.profile.startDate, activeDateStr);
  const streak = calculateStreak(state.history, state.activities, todayStr);
  const todayProgress = calculateDailyProgress(
    state.activities,
    state.history[todayStr],
    todayStr
  );

  // Background reminder scheduler
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMinutes = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentHours}:${currentMinutes}`;
      const today = formatDate(now);

      const dayRecord = state.history[today];
      state.activities.forEach((act) => {
        if (act.reminderEnabled && act.scheduledTime === currentTimeStr) {
          const isDone = dayRecord?.tasks?.[act.id]?.completed;
          if (!isDone) {
            sendLocalNotification(`GlowUp 90: ${act.name}`, {
              body: `Scheduled for ${act.scheduledTime}. Keep up your 90-day transformation!`,
            });
          }
        }
      });
    }, 30000);

    return () => clearInterval(interval);
  }, [state.activities, state.history]);

  // Handle task completion toggle
  const handleToggleTask = (activityId: string, targetDateStr: string = activeDateStr) => {
    const history = { ...state.history };
    const dayRecord = history[targetDateStr] || {
      date: targetDateStr,
      tasks: {},
      waterConsumedMl: 0,
      waterGoalMl: state.profile.waterGoalMl,
    };

    const currentTask = dayRecord.tasks[activityId];
    const isNowCompleted = !currentTask?.completed;

    dayRecord.tasks = {
      ...dayRecord.tasks,
      [activityId]: {
        activityId,
        completed: isNowCompleted,
        completedAt: isNowCompleted ? new Date().toLocaleTimeString() : undefined,
      },
    };

    history[targetDateStr] = dayRecord;

    const newState = { ...state, history };
    updateState(newState);

    // If today reached 100% completion, trigger celebration!
    if (targetDateStr === todayStr && isNowCompleted) {
      const newProgress = calculateDailyProgress(state.activities, dayRecord, targetDateStr);
      if (newProgress.total > 0 && newProgress.percentage === 100) {
        setIsCelebrationOpen(true);
      }
    }
  };

  // Water intake
  const handleAddWater = (amountMl: number) => {
    const history = { ...state.history };
    const dayRecord = history[activeDateStr] || {
      date: activeDateStr,
      tasks: {},
      waterConsumedMl: 0,
      waterGoalMl: state.profile.waterGoalMl,
    };

    dayRecord.waterConsumedMl = (dayRecord.waterConsumedMl || 0) + amountMl;
    history[activeDateStr] = dayRecord;

    updateState({ ...state, history });
  };

  // Sleep schedule
  const handleUpdateSleep = (bedtime: string, wakeTime: string) => {
    const history = { ...state.history };
    const dayRecord = history[activeDateStr] || {
      date: activeDateStr,
      tasks: {},
      waterConsumedMl: 0,
      waterGoalMl: state.profile.waterGoalMl,
    };

    dayRecord.sleepBedtime = bedtime;
    dayRecord.sleepWakeTime = wakeTime;
    history[activeDateStr] = dayRecord;

    updateState({ ...state, history });
  };

  // Activity CRUD
  const handleSaveActivity = (activity: Activity) => {
    const exists = state.activities.some((a) => a.id === activity.id);
    let updatedActivities: Activity[];
    if (exists) {
      updatedActivities = state.activities.map((a) => (a.id === activity.id ? activity : a));
    } else {
      updatedActivities = [...state.activities, activity];
    }
    updateState({ ...state, activities: updatedActivities });
  };

  const handleDeleteActivity = (id: string) => {
    const updatedActivities = state.activities.filter((a) => a.id !== id);
    updateState({ ...state, activities: updatedActivities });
  };

  // Weight entry
  const handleAddWeight = (record: WeightRecord) => {
    const updatedWeights = [...state.weightHistory, record];
    const updatedProfile = {
      ...state.profile,
      currentWeightKg: record.weightKg,
    };
    updateState({
      ...state,
      weightHistory: updatedWeights,
      profile: updatedProfile,
    });
  };

  // Photo entry
  const handleAddPhoto = (photo: PhotoRecord) => {
    const updatedPhotos = [...state.photos, photo];
    updateState({
      ...state,
      photos: updatedPhotos,
    });
  };

  // Profile update
  const handleUpdateProfile = (profile: UserProfile) => {
    updateState({
      ...state,
      profile,
    });
  };

  // Reset today's checklist without erasing history
  const handleResetTodayChecklist = () => {
    const history = { ...state.history };
    if (history[todayStr]) {
      history[todayStr] = {
        ...history[todayStr],
        tasks: {},
      };
      updateState({ ...state, history });
    }
  };

  const handleSelectDate = (dateStr: string) => {
    updateState({ ...state, activeDate: dateStr });
    setActiveTab('calendar');
  };

  const handleOpenTimer = (exerciseName: string, restSecs: number) => {
    setTimerExerciseName(exerciseName);
    setTimerSeconds(restSecs);
    setIsTimerOpen(true);
  };

  const handleEditActivity = (activity: Activity) => {
    setEditingActivity(activity);
    setIsAddModalOpen(true);
  };

  const handleCategoryShortcut = (cat: ActivityCategory) => {
    setSelectedCategoryTab(cat);
    setActiveTab('categories');
  };

  return (
    <div className="min-h-screen bg-[#FAFAFC] dark:bg-[#0B0C10] text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Header */}
      <Header
        profile={state.profile}
        dayNumber={dayNumber}
        streak={streak}
        activeDateStr={activeDateStr}
        onOpenAddModal={() => {
          setEditingActivity(null);
          setIsAddModalOpen(true);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onToggleDarkMode={() => {
          handleUpdateProfile({
            ...state.profile,
            darkMode: !state.profile.darkMode,
          });
        }}
      />

      {/* Main View Container */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 py-5">
        {activeTab === 'routine' && (
          <HomeView
            state={state}
            activeDateStr={activeDateStr}
            dayNumber={dayNumber}
            streak={streak}
            onToggleTask={handleToggleTask}
            onAddWater={handleAddWater}
            onOpenTimer={handleOpenTimer}
            onEditActivity={handleEditActivity}
            onOpenAddModal={() => {
              setEditingActivity(null);
              setIsAddModalOpen(true);
            }}
            onSelectCategoryTab={handleCategoryShortcut}
          />
        )}

        {activeTab === 'categories' && (
          <CategoriesView
            state={state}
            activeDateStr={activeDateStr}
            initialCategory={selectedCategoryTab}
            onToggleTask={handleToggleTask}
            onAddWater={handleAddWater}
            onOpenTimer={handleOpenTimer}
            onEditActivity={handleEditActivity}
            onOpenAddModal={() => {
              setEditingActivity(null);
              setIsAddModalOpen(true);
            }}
            onUpdateSleep={handleUpdateSleep}
          />
        )}

        {activeTab === 'transform' && (
          <TransformationView
            state={state}
            dayNumber={dayNumber}
            onSelectDate={handleSelectDate}
            onAddWeight={handleAddWeight}
            onAddPhoto={handleAddPhoto}
          />
        )}

        {activeTab === 'calendar' && (
          <CalendarView
            state={state}
            activeDateStr={activeDateStr}
            onSelectDate={(dStr) => updateState({ ...state, activeDate: dStr })}
            onToggleTask={handleToggleTask}
          />
        )}

        {activeTab === 'analytics' && (
          <StatsView
            state={state}
            dayNumber={dayNumber}
            streak={streak}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        pendingCount={todayProgress.remaining}
      />

      {/* Modals & Dialogs */}
      <AddActivityModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingActivity(null);
        }}
        onSave={handleSaveActivity}
        onDelete={handleDeleteActivity}
        editingActivity={editingActivity}
      />

      <WorkoutTimerModal
        isOpen={isTimerOpen}
        onClose={() => setIsTimerOpen(false)}
        defaultSeconds={timerSeconds}
        exerciseName={timerExerciseName}
      />

      <DailyCelebrationModal
        isOpen={isCelebrationOpen}
        dayNumber={dayNumber}
        streak={streak}
        onClose={() => setIsCelebrationOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        state={state}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateProfile={handleUpdateProfile}
        onResetTodayChecklist={handleResetTodayChecklist}
        onRestoreState={updateState}
      />
    </div>
  );
}
