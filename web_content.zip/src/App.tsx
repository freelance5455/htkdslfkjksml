/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Search,
  Loader2,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  X,
  ArrowRight,
  ArrowLeft,
  SlidersHorizontal,
  MapPin,
} from 'lucide-react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { StoreDataProvider, useStoreData } from './context/StoreDataContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { CustomerAccountView } from './components/CustomerAccountView';
import { AdminLoginView } from './components/AdminLoginView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { DEFAULT_CATEGORIES } from './lib/catalogDefaults';
import { isFirebaseConfigured } from './lib/firebase';
import { formatCurrency, getEffectivePrice } from './lib/formatters';
import { AppView, Product } from './types/store';

function ToastStack() {
  const { toasts, dismissToast } = useStoreData();
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-50 space-y-2 max-w-sm w-[calc(100vw-2rem)] pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 shadow-lg border text-xs font-medium ${
            t.type === 'error'
              ? 'bg-red-950 text-white border-red-800'
              : 'bg-[#0A0A0A] text-white border-neutral-800'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {t.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0 text-red-300" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            )}
            <span className="truncate">{t.message}</span>
          </div>
          <button
            type="button"
            onClick={() => dismissToast(t.id)}
            aria-label="Dismiss notification"
            className="text-neutral-400 hover:text-white cursor-pointer shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}

function StorefrontApp() {
  const { isAdmin, authLoading } = useAuth();
  const { products, categories, catalogLoading, settings, notify } = useStoreData();
  const { addToCart, openCart } = useCart();

  const [currentView, setCurrentView] = useState<AppView>('home');
  const [viewHistory, setViewHistory] = useState<AppView[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const catalogRef = useRef<HTMLElement | null>(null);

  const scrollToCatalog = () => {
    setTimeout(() => {
      catalogRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      const targetView = (event.state?.view as AppView) || 'home';
      setCurrentView(targetView);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleNavigate = (view: AppView) => {
    if (view !== currentView) {
      setViewHistory((prev) => [...prev.slice(-15), currentView]);
      try {
        window.history.pushState({ view }, '');
      } catch {
        // Ignore if history pushState is restricted
      }
    }
    setCurrentView(view);
    if (
      view === 'home' ||
      view === 'men' ||
      view === 'women' ||
      view === 'new-arrivals' ||
      view === 'best-sellers'
    ) {
      setSelectedCategory('All');
    }
  };

  const handleGoBack = () => {
    if (viewHistory.length > 0) {
      const prevView = viewHistory[viewHistory.length - 1];
      setViewHistory((prev) => prev.slice(0, -1));
      setCurrentView(prevView);
    } else {
      setCurrentView('home');
    }
  };

  const handleAddToCart = (
    product: Product,
    size: string,
    color: string,
    qty = 1
  ) => {
    const res = addToCart(product, size, color, qty);
    if (res.ok) {
      notify(`Added "${product.name}" (${size}) to your bag.`, 'success');
      openCart();
    } else {
      notify(res.message || 'Could not add item to bag.', 'error');
    }
  };

  const handleBuyNow = (
    product: Product,
    size: string,
    color: string,
    qty = 1
  ) => {
    const res = addToCart(product, size, color, qty);
    if (res.ok) {
      setCheckoutOpen(true);
    } else {
      notify(res.message || 'Could not proceed to checkout.', 'error');
    }
  };

  const activeCategoryNames = useMemo(() => {
    const list =
      categories.length > 0
        ? categories.filter((c) => c.isActive).map((c) => c.name)
        : DEFAULT_CATEGORIES.map((c) => c.name);
    return ['All', ...list];
  }, [categories]);

  const filteredProducts = useMemo(() => {
    const activeOnly = products.filter((p) => p.isActive);

    const byCollection = activeOnly.filter((p) => {
      if (currentView === 'men') {
        return p.gender === 'Men' || p.gender === 'Unisex' || p.category === "Men's Fashion";
      }
      if (currentView === 'women') {
        return p.gender === 'Women' || p.gender === 'Unisex' || p.category === "Women's Fashion";
      }
      if (currentView === 'new-arrivals') return p.isNewArrival;
      if (currentView === 'best-sellers') return p.isBestSeller;
      return true;
    });

    const byCategory = byCollection.filter((p) => {
      if (selectedCategory === 'All') return true;
      if (selectedCategory === "Men's Fashion") {
        return p.category === "Men's Fashion" || p.gender === 'Men';
      }
      if (selectedCategory === "Women's Fashion") {
        return p.category === "Women's Fashion" || p.gender === 'Women';
      }
      return p.category.toLowerCase() === selectedCategory.toLowerCase();
    });

    const q = searchQuery.trim().toLowerCase();
    const bySearch = byCategory.filter((p) => {
      if (!q) return true;
      const numericQuery = Number(q.replace(/[^0-9.]/g, ''));
      const eff = getEffectivePrice(p);
      const matchesPrice =
        !isNaN(numericQuery) &&
        numericQuery > 0 &&
        (String(eff).includes(q) || String(p.price).includes(q) || eff <= numericQuery);

      return (
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.gender.toLowerCase().includes(q) ||
        matchesPrice
      );
    });

    if (sortOrder === 'price-asc') {
      return [...bySearch].sort((a, b) => getEffectivePrice(a) - getEffectivePrice(b));
    }
    if (sortOrder === 'price-desc') {
      return [...bySearch].sort((a, b) => getEffectivePrice(b) - getEffectivePrice(a));
    }
    return bySearch;
  }, [products, currentView, selectedCategory, searchQuery, sortOrder]);

  if (!isFirebaseConfigured) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="max-w-lg w-full border border-neutral-200 p-8">
          <h1 className="font-display text-3xl font-semibold mb-3">
            Fashion Hub Firebase Setup Required
          </h1>
          <p className="text-sm text-neutral-600 mb-4">
            Firebase configuration is missing or using placeholder values in{' '}
            <code className="font-mono text-xs bg-neutral-100 px-1.5 py-0.5">
              firebase-applet-config.json
            </code>
            . Please refer to{' '}
            <code className="font-mono text-xs bg-neutral-100 px-1.5 py-0.5">
              FIREBASE_SETUP_GUIDE.md
            </code>{' '}
            to connect your Firebase project.
          </p>
        </div>
      </div>
    );
  }

  // Dedicated Admin Dashboard Route
  if (currentView === 'admin-dashboard') {
    if (authLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-neutral-500" />
        </div>
      );
    }
    if (!isAdmin) {
      return (
        <AdminLoginView
          onSuccess={() => handleNavigate('admin-dashboard')}
          onBackToStore={handleGoBack}
        />
      );
    }
    return (
      <>
        <AdminDashboardView
          onBackToStore={() => handleNavigate('home')}
          onLogoutComplete={() => handleNavigate('home')}
        />
        <ToastStack />
      </>
    );
  }

  const sectionMeta =
    currentView === 'men'
      ? {
          kicker: 'Menswear Edit',
          title: "Men's Collection",
          subtitle: 'Tailored overshirts, selvedge denim, and architectural essentials.',
        }
      : currentView === 'women'
      ? {
          kicker: 'Womenswear Edit',
          title: "Women's Collection",
          subtitle: 'Mulberry silk dresses, handloom couture, and fluid tailoring.',
        }
      : currentView === 'new-arrivals'
      ? {
          kicker: 'Latest Drop',
          title: 'New Arrivals',
          subtitle: 'Fresh seasonal silhouettes crafted for the modern wardrobe.',
        }
      : currentView === 'best-sellers'
      ? {
          kicker: 'Most Requested',
          title: 'Best Sellers',
          subtitle: 'Signature Fashion Hub garments loved by our community.',
        }
      : {
          kicker: 'Fashion Hub Atelier',
          title: 'Curated Collection',
          subtitle: 'Discover refined contemporary essentials across every category.',
        };

  const storeAddress = settings.storeAddress || 'Assam Badarpur Fashion Hub';

  return (
    <div className="min-h-screen w-full flex flex-col bg-white text-[#0A0A0A]">
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onFocusCatalog={scrollToCatalog}
      />

      <main className="flex-1 w-full">
        {currentView === 'account' ? (
          <CustomerAccountView
            onBackToShop={handleGoBack}
            onOpenAdminLogin={() => handleNavigate('admin-login')}
          />
        ) : currentView === 'admin-login' ? (
          <AdminLoginView
            onSuccess={() => handleNavigate('admin-dashboard')}
            onBackToStore={handleGoBack}
          />
        ) : (
          <>
            {currentView === 'home' && (
              <HeroSection
                onShopNow={scrollToCatalog}
                onExploreNewArrivals={() => {
                  handleNavigate('new-arrivals');
                  scrollToCatalog();
                }}
              />
            )}

            {/* Full-Width Catalog Section */}
            <section
              ref={catalogRef}
              className="w-full px-4 sm:px-8 lg:px-12 py-10 sm:py-14"
            >
              {currentView !== 'home' && (
                <div className="mb-5">
                  <button
                    type="button"
                    onClick={handleGoBack}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>
                </div>
              )}

              {/* Collection Header & Search Toolbar */}
              <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-neutral-200">
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-neutral-500 mb-1.5">
                    {sectionMeta.kicker}
                  </p>
                  <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0A0A0A]">
                    {sectionMeta.title}
                  </h2>
                  <p className="text-xs text-neutral-500 mt-1.5">
                    {sectionMeta.subtitle}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <div className="relative min-w-[260px] sm:w-80">
                    <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search name, category, type, or max price..."
                      className="w-full pl-10 pr-8 py-2.5 text-xs border border-neutral-300 rounded-full bg-white focus:border-[#0A0A0A] focus:outline-none"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        aria-label="Clear search"
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-[#0A0A0A] cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="relative flex items-center">
                    <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-500 absolute left-3.5 pointer-events-none" />
                    <select
                      aria-label="Sort products"
                      value={sortOrder}
                      onChange={(e) =>
                        setSortOrder(
                          e.target.value as 'featured' | 'price-asc' | 'price-desc'
                        )
                      }
                      className="pl-9 pr-4 py-2.5 text-xs font-medium border border-neutral-300 rounded-full bg-white focus:border-[#0A0A0A] focus:outline-none cursor-pointer"
                    >
                      <option value="featured">Sort: Featured</option>
                      <option value="price-asc">Price: Low to High</option>
                      <option value="price-desc">Price: High to Low</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Interactive Category Filter Bar */}
              <div className="py-6 flex items-center gap-2 overflow-x-auto no-scrollbar">
                {activeCategoryNames.map((cat) => {
                  const active = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#0A0A0A] text-white font-semibold'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>

              {/* Full-Screen Product Grid (4 columns on wide desktop) */}
              {catalogLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                    <div key={n} className="border border-neutral-200 animate-pulse">
                      <div className="aspect-[3/4] bg-neutral-100" />
                      <div className="p-5 space-y-3">
                        <div className="h-3 w-24 bg-neutral-100" />
                        <div className="h-4 w-3/4 bg-neutral-100" />
                        <div className="h-4 w-20 bg-neutral-100" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : products.length === 0 ? (
                <div className="border border-neutral-200 bg-neutral-50/60 p-10 sm:p-14 text-center max-w-2xl mx-auto my-8">
                  <p className="text-xs uppercase tracking-[0.2em] text-neutral-500 mb-2">
                    Firestore Catalog Initialized
                  </p>
                  <h3 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A] mb-3">
                    No Products Published Yet
                  </h3>
                  <p className="text-sm text-neutral-600 mb-6">
                    Sign in to the Admin Portal to automatically publish the curated Fashion Hub fashion collection or add your own items with Firebase Storage imagery.
                  </p>
                  <button
                    type="button"
                    onClick={() => setCurrentView(isAdmin ? 'admin-dashboard' : 'admin-login')}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isAdmin ? 'Open Admin Dashboard' : 'Sign in to Admin Portal'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              ) : filteredProducts.length === 0 ? (
                <div className="py-16 text-center border border-neutral-200">
                  <p className="font-display text-2xl font-semibold mb-2">
                    No matching garments found
                  </p>
                  <p className="text-xs text-neutral-500 mb-5">
                    Try adjusting your search keywords, switching collection tabs, or resetting filters.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentView('home');
                      setSelectedCategory('All');
                      setSearchQuery('');
                    }}
                    className="px-6 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold cursor-pointer"
                  >
                    View All Products
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-2">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onSelectProduct={setSelectedProduct}
                      onAddToCart={(p, size, color) => handleAddToCart(p, size, color, 1)}
                      onBuyNow={(p, size, color) => handleBuyNow(p, size, color, 1)}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Full-Width Editorial Craftsmanship & Flagship Address Strip */}
            <section className="w-full border-t border-neutral-200 bg-neutral-50/70">
              <div className="w-full px-4 sm:px-8 lg:px-12 py-14 grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <p className="text-xs uppercase tracking-wider text-neutral-500 mb-2">
                    01 · Flagship Storefront
                  </p>
                  <h3 className="font-display text-xl font-semibold mb-2">
                    {storeAddress}
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Boiled Italian merino, 22-momme mulberry silk, and handloom textiles curated at {storeAddress}.
                  </p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-neutral-500 mb-2">
                    02 · Direct Fulfillment
                  </p>
                  <h3 className="font-display text-xl font-semibold mb-2">
                    Verified Delivery & Tracking
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Complimentary express shipping above {formatCurrency(settings.freeShippingThreshold)} with Cash on Delivery and live order tracking from confirmation to doorstep.
                  </p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-neutral-500 mb-2">
                    03 · Concierge Support
                  </p>
                  <h3 className="font-display text-xl font-semibold mb-2">
                    Client Wardrobe Care
                  </h3>
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    Dedicated sizing assistance and seamless order management through your Fashion Hub customer account.
                  </p>
                </div>
              </div>
            </section>
          </>
        )}
      </main>

      {/* Clean Full-Width Footer */}
      <footer className="w-full border-t border-neutral-200 bg-white pb-20 md:pb-0">
        <div className="w-full px-4 sm:px-8 lg:px-12 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <p className="font-display text-xl font-semibold tracking-[0.14em]">
              {settings.storeName || 'Fashion Hub'}
            </p>
            <p className="text-xs text-neutral-700 font-medium mt-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#0A0A0A] shrink-0" />
              <span>{storeAddress}</span>
            </p>
            <p className="text-xs text-neutral-500 mt-1">
              {settings.supportEmail} · © {new Date().getFullYear()} Fashion Hub Fashion Store
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-neutral-600">
            <button
              type="button"
              onClick={() => handleNavigate('home')}
              className="hover:text-[#0A0A0A] cursor-pointer"
            >
              Collection
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('account')}
              className="hover:text-[#0A0A0A] cursor-pointer"
            >
              My Orders
            </button>
            <button
              type="button"
              onClick={() =>
                handleNavigate(isAdmin ? 'admin-dashboard' : 'admin-login')
              }
              className="inline-flex items-center gap-1.5 text-[#0A0A0A] font-semibold hover:underline cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{isAdmin ? 'Admin Dashboard' : 'Admin Panel'}</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
      />

      <CartDrawer onProceedToCheckout={() => setCheckoutOpen(true)} />

      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        onOrderComplete={() => setCurrentView('account')}
      />

      <ToastStack />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <StoreDataProvider>
          <CartProvider>
            <StorefrontApp />
          </CartProvider>
        </StoreDataProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
