import { useCallback, useEffect, useState } from 'react';
import { FacilityView } from './components/FacilityView';
import { JournalView } from './components/JournalView';
import { LocationView } from './components/LocationView';
import { MarketView } from './components/MarketView';
import { MobileBottomNav } from './components/MobileBottomNav';
import { SaveView } from './components/SaveView';
import { NavTab, TopBar } from './components/TopBar';
import {
  acceptMarketListing,
  advanceSimulation,
  applyPlayerInteractionAction,
  createInitialGameState,
  enterLocation,
  initiateManualInteraction,
  moveDogToLocation,
  placeFoodInBowl,
  placeWaterInBowl,
  refuseMarketListing,
  renameDog,
  repairPenObject,
  sellOrRehomeDog,
  toggleConfirmTraitInJournal,
  updateDogNotes,
} from './engine/simulation';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { GameState, HabitatLocationId, LocationId } from './types/kennel';

const STORAGE_KEY = 'dingo_ledger_save_v1';

function loadSavedState(): GameState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialGameState();
    const parsed = JSON.parse(raw) as GameState;
    if (!parsed || !Array.isArray(parsed.dogs) || !parsed.bowls) {
      return createInitialGameState();
    }
    // Catch up offline elapsed time gently if simulation wasn't paused
    if (!parsed.isPaused && typeof parsed.lastSavedAtMs === 'number') {
      const elapsedSec = Math.floor((Date.now() - parsed.lastSavedAtMs) / 1000);
      if (elapsedSec > 2) {
        return advanceSimulation(parsed, Math.min(elapsedSec, 600));
      }
    }
    return parsed;
  } catch {
    return createInitialGameState();
  }
}

export default function App() {
  const [state, setState] = useState<GameState>(() => loadSavedState());
  const [activeTab, setActiveTab] = useState<NavTab>('location');
  const isOnline = useOnlineStatus();

  const persistState = useCallback((next: GameState) => {
    try {
      const stamped = { ...next, lastSavedAtMs: Date.now() };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stamped));
    } catch {
      // Ignore quota errors cleanly
    }
  }, []);

  // Real-time 1-second simulation heartbeat
  useEffect(() => {
    if (state.isPaused) return;
    const timer = window.setInterval(() => {
      setState((prev) => advanceSimulation(prev, 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [state.isPaused]);

  // Periodic local auto-save every 10 seconds
  useEffect(() => {
    const saver = window.setInterval(() => {
      setState((prev) => {
        persistState(prev);
        return prev;
      });
    }, 10000);
    return () => window.clearInterval(saver);
  }, [persistState]);

  const updateAndSave = useCallback(
    (updater: (prev: GameState) => GameState) => {
      setState((prev) => {
        const next = updater(prev);
        persistState(next);
        return next;
      });
    },
    [persistState]
  );

  const handleEnterLocation = (loc: LocationId) => {
    updateAndSave((prev) => enterLocation(prev, loc));
    setActiveTab('location');
  };

  const handleObserveLocation = (loc: HabitatLocationId | null) => {
    setState((prev) => ({ ...prev, observingLocation: loc }));
  };

  const handleSelectDogJournal = (dogId: string) => {
    setState((prev) => ({ ...prev, journalSelectedDogId: dogId }));
    setActiveTab('journal');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F5F0] text-[#1C1B18]">
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        simClockSec={state.simClockSec}
        dayCount={state.dayCount}
        isPaused={state.isPaused}
        onTogglePause={() =>
          updateAndSave((prev) => ({ ...prev, isPaused: !prev.isPaused }))
        }
        playerLocation={state.playerLocation}
      />

      {!isOnline && (
        <div className="bg-[#EFECE4] border-b border-[#DFDBD0] px-4 py-1.5 text-center text-xs text-[#5C584F]">
          Offline Mode — Running locally from cached assets and device storage.
        </div>
      )}

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-5 sm:py-7 pb-20 md:pb-10">
        {activeTab === 'facility' && (
          <FacilityView
            state={state}
            onEnterLocation={handleEnterLocation}
            onObserveLocation={handleObserveLocation}
            onSelectDogJournal={handleSelectDogJournal}
          />
        )}

        {activeTab === 'location' && (
          <LocationView
            state={state}
            onEnterLocation={handleEnterLocation}
            onPlaceFood={(loc) => updateAndSave((prev) => placeFoodInBowl(prev, loc))}
            onPlaceWater={(loc) => updateAndSave((prev) => placeWaterInBowl(prev, loc))}
            onMoveDog={(dogId, dest) =>
              updateAndSave((prev) => moveDogToLocation(prev, dogId, dest))
            }
            onInitiateInteraction={(dogId) =>
              updateAndSave((prev) => initiateManualInteraction(prev, dogId))
            }
            onPlayerAction={(action) =>
              updateAndSave((prev) => applyPlayerInteractionAction(prev, action))
            }
            onRepairPenObject={(objectId) =>
              updateAndSave((prev) => repairPenObject(prev, objectId))
            }
            onSelectDogJournal={handleSelectDogJournal}
            onOpenFacility={() => setActiveTab('facility')}
          />
        )}

        {activeTab === 'market' && (
          <MarketView
            state={state}
            onAcceptListing={(listingId, dest, customName) =>
              updateAndSave((prev) => acceptMarketListing(prev, listingId, dest, customName))
            }
            onRefuseListing={(listingId) =>
              updateAndSave((prev) => refuseMarketListing(prev, listingId))
            }
            onSellOrRehome={(dogId) =>
              updateAndSave((prev) => sellOrRehomeDog(prev, dogId))
            }
          />
        )}

        {activeTab === 'journal' && (
          <JournalView
            state={state}
            onSelectDog={(dogId) =>
              setState((prev) => ({ ...prev, journalSelectedDogId: dogId }))
            }
            onRenameDog={(dogId, newName) =>
              updateAndSave((prev) => renameDog(prev, dogId, newName))
            }
            onUpdateNotes={(dogId, notes) =>
              updateAndSave((prev) => updateDogNotes(prev, dogId, notes))
            }
            onToggleTrait={(dogId, trait) =>
              updateAndSave((prev) => toggleConfirmTraitInJournal(prev, dogId, trait))
            }
          />
        )}

        {activeTab === 'save' && (
          <SaveView
            state={state}
            onManualSave={() =>
              updateAndSave((prev) => ({ ...prev, lastSavedAtMs: Date.now() }))
            }
            onImportState={(parsed) => {
              const stamped = { ...parsed, lastSavedAtMs: Date.now() };
              persistState(stamped);
              setState(stamped);
            }}
            onResetKennel={() => {
              const fresh = createInitialGameState();
              persistState(fresh);
              setState(fresh);
            }}
          />
        )}
      </main>

      <MobileBottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        hasActiveInteraction={!!state.activeInteraction}
      />
    </div>
  );
}
