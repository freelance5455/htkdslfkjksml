/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Sun, 
  Wind, 
  Droplet, 
  Flame, 
  Atom, 
  Award, 
  BookOpen, 
  ArrowRight, 
  Check, 
  X, 
  Send, 
  MessageSquare, 
  RotateCcw, 
  Cpu, 
  Coins, 
  AlertTriangle, 
  Leaf, 
  HelpCircle,
  Lightbulb,
  Info,
  TrendingUp,
  FileText,
  DollarSign,
  Briefcase,
  Layers,
  ChevronRight,
  Sparkles
} from 'lucide-react';

// Imagem gerada do Hero Banner
import heroImage from './assets/images/hero_energy_comparison_1790557659124.jpg';

// Tipos de Energia e fontes suportadas
type EnergyCategory = 'renewable' | 'non-renewable';

interface EnergySource {
  id: string;
  name: string;
  category: EnergyCategory;
  description: string;
  howItWorks: string;
  technicalTerm: {
    term: string;
    definition: string;
  };
  advantages: string[];
  disadvantages: string[];
  // Parâmetros padrão para simulação
  baseProduction: number; // MW
  baseCO2: number; // g/kWh
  baseCost: number; // USD/kW
  baseEfficiency: number; // %
  icon: any;
  color: string;
  bgLight: string;
  borderCol: string;
  sliderLabel: string;
  sliderUnit: string;
  sliderMin: number;
  sliderMax: number;
  sliderDefault: number;
}

const ENERGY_SOURCES: EnergySource[] = [
  {
    id: 'solar',
    name: 'Solar Fotovoltaica',
    category: 'renewable',
    description: 'Conversão direta da luz solar em eletricidade por meio de materiais semicondutores.',
    howItWorks: 'A radiação eletromagnética do sol atinge as placas, liberando elétrons no silício e gerando corrente contínua que é convertida em alternada.',
    technicalTerm: {
      term: 'Efeito Fotovoltaico',
      definition: 'Processo físico no qual a incidência de radiação eletromagnética (luz) em um material semicondutor gera uma diferença de potencial elétrico e corrente.'
    },
    advantages: [
      'Fonte virtualmente inesgotável e abundante mundialmente.',
      'Baixíssimo impacto ambiental durante a operação.',
      'Sistemas modulares com baixa manutenção necessária.'
    ],
    disadvantages: [
      'Intermitência (não gera à noite e diminui em dias nublados).',
      'Alto custo inicial para aquisição de baterias e painéis eficientes.',
      'Impacto na extração de minerais raros para fabricação das células.'
    ],
    baseProduction: 250,
    baseCO2: 0,
    baseCost: 950,
    baseEfficiency: 21,
    icon: Sun,
    color: 'text-amber-500 bg-amber-500',
    bgLight: 'bg-amber-50/50',
    borderCol: 'border-amber-200',
    sliderLabel: 'Irradiação Solar',
    sliderUnit: 'W/m²',
    sliderMin: 100,
    sliderMax: 1000,
    sliderDefault: 750,
  },
  {
    id: 'eolica',
    name: 'Eólica',
    category: 'renewable',
    description: 'Geração a partir da força mecânica dos ventos que rotacionam turbinas aerodinâmicas.',
    howItWorks: 'O fluxo de ar rotaciona as pás do aerogerador, transmitindo energia mecânica para um gerador interno que a converte em eletricidade.',
    technicalTerm: {
      term: 'Energia Cinética das Massas de Ar',
      definition: 'Energia associada ao movimento das moléculas de ar na atmosfera, impulsionada pelo aquecimento desigual do planeta pela radiação solar.'
    },
    advantages: [
      'Zero emissões de gases de efeito estufa na geração.',
      'Rápido retorno do investimento em áreas de vento constante.',
      'Possibilidade de uso compartilhado da terra (agricultura e pecuária).'
    ],
    disadvantages: [
      'Dependência estrita do comportamento climático regional.',
      'Poluição sonora e impacto visual na paisagem nativa.',
      'Risco de colisão física para aves e morcegos locais.'
    ],
    baseProduction: 400,
    baseCO2: 0,
    baseCost: 1300,
    baseEfficiency: 45,
    icon: Wind,
    color: 'text-sky-500 bg-sky-500',
    bgLight: 'bg-sky-50/50',
    borderCol: 'border-sky-200',
    sliderLabel: 'Velocidade do Vento',
    sliderUnit: 'm/s',
    sliderMin: 3,
    sliderMax: 25,
    sliderDefault: 12,
  },
  {
    id: 'hidrelétrica',
    name: 'Hidrelétrica',
    category: 'renewable',
    description: 'Aproveitamento do fluxo gravitacional e pressão da água em represas ou rios.',
    howItWorks: 'A água sob pressão passa pelas turbinas hidráulicas, gerando rotação mecânica acoplada a dínamos eletromagnéticos.',
    technicalTerm: {
      term: 'Ciclo Hidrológico',
      definition: 'O movimento contínuo da água terrestre impulsionado pelo Sol. Por depender das chuvas que se renovam, a hidreletricidade é considerada renovável.'
    },
    advantages: [
      'Geração altamente estável e despachável (pode ser controlada rapidamente).',
      'Longa vida útil operacional da estrutura física.',
      'Reservatórios servem para abastecimento de água e controle de enchentes.'
    ],
    disadvantages: [
      'Grande impacto socioambiental no alagamento de áreas florestais.',
      'Deslocamento forçado de comunidades ribeirinhas e indígenas.',
      'Dependência de padrões de chuva e vulnerabilidade a secas extremas.'
    ],
    baseProduction: 800,
    baseCO2: 4,
    baseCost: 2200,
    baseEfficiency: 90,
    icon: Droplet,
    color: 'text-blue-600 bg-blue-600',
    bgLight: 'bg-blue-50/50',
    borderCol: 'border-blue-200',
    sliderLabel: 'Vazão de Água',
    sliderUnit: 'm³/s',
    sliderMin: 10,
    sliderMax: 500,
    sliderDefault: 250,
  },
  {
    id: 'carvao',
    name: 'Carvão Mineral',
    category: 'non-renewable',
    description: 'Combustão de rocha sedimentar rica em carbono formada há milhões de anos.',
    howItWorks: 'O carvão é queimado em caldeiras para vaporizar água sob extrema pressão. O vapor rotaciona turbinas de alta velocidade.',
    technicalTerm: {
      term: 'Combustão de Hidrocarbonetos',
      definition: 'Reação química exotérmica entre o carbono do combustível e o oxigênio, liberando calor, cinzas tóxicas e grandes volumes de CO2.'
    },
    advantages: [
      'Altíssima densidade energética por tonelada.',
      'Tecnologia madura, barata e de fácil implantação emergencial.',
      'Independe de fatores climáticos (produz 24h por dia sob demanda).'
    ],
    disadvantages: [
      'Maior emissor de dióxido de carbono (CO2) e poluentes locais por MWh.',
      'Mineração destrutiva com severa degradação da saúde do solo.',
      'Chuva ácida causada por emissões de óxidos de enxofre e nitrogênio.'
    ],
    baseProduction: 600,
    baseCO2: 950,
    baseCost: 1800,
    baseEfficiency: 38,
    icon: Flame,
    color: 'text-neutral-700 bg-neutral-700',
    bgLight: 'bg-neutral-100/50',
    borderCol: 'border-neutral-300',
    sliderLabel: 'Taxa de Queima',
    sliderUnit: 'ton/h',
    sliderMin: 10,
    sliderMax: 150,
    sliderDefault: 80,
  },
  {
    id: 'nuclear',
    name: 'Termonuclear',
    category: 'non-renewable',
    description: 'Aproveitamento do imenso calor liberado pela quebra controlada de átomos pesados.',
    howItWorks: 'O calor gerado pela fissão nuclear do Urânio-235 ferve água purificada, gerando vapor de altíssima energia para rotacionar geradores.',
    technicalTerm: {
      term: 'Fissão Nuclear',
      definition: 'Processo no qual um nêutron colide com o núcleo de um átomo instável, dividindo-o em fragmentos menores e liberando uma imensa energia térmica.'
    },
    advantages: [
      'Emissão zero de gases de efeito estufa durante o ciclo de geração.',
      'Extrema densidade de energia (poucos gramas produzem megawatts).',
      'Altíssima confiabilidade e operação contínua sem depender do clima.'
    ],
    disadvantages: [
      'Geração de rejeitos radioativos de longa atividade (lixo nuclear).',
      'Altos custos de comissionamento, segurança e desativação.',
      'Consequências catastróficas em caso de acidentes severos.'
    ],
    baseProduction: 1000,
    baseCO2: 0,
    baseCost: 5500,
    baseEfficiency: 33,
    icon: Atom,
    color: 'text-emerald-600 bg-emerald-600',
    bgLight: 'bg-emerald-50/50',
    borderCol: 'border-emerald-200',
    sliderLabel: 'Inserção das Barras de Controle',
    sliderUnit: '% recolhido',
    sliderMin: 0,
    sliderMax: 100,
    sliderDefault: 80,
  }
];

// Notícias e Negócios Estruturadas
interface NewsArticle {
  id: number;
  title: string;
  source: string;
  date: string;
  tag: 'Renovável' | 'Mercado' | 'Transição' | 'Investimento' | 'Combustíveis';
  summary: string;
  fullText: string;
  readTime: string;
  sentiment: 'positive' | 'neutral' | 'negative';
}

const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: 1,
    title: "Leilão de Transmissão de Energia bate recordes e atrai R$ 15 bilhões em investimentos",
    source: "Diário de Negócios e Energia",
    date: "27 de Setembro de 2026",
    tag: "Investimento",
    summary: "O maior leilão de infraestrutura elétrica do ano garantiu lances extremamente competitivos, focados no escoamento de energia solar e eólica do Nordeste para os grandes centros consumidores.",
    fullText: "O governo federal concluiu hoje o maior leilão de linhas de transmissão da década, arrecadando mais de 15 bilhões de reais em novos investimentos privados. Os consórcios vencedores deverão construir mais de 6.000 quilômetros de linhas de alta tensão. O principal objetivo estratégico deste projeto é integrar as massivas fazendas solares e parques eólicos situados no semiárido nordestino às redes elétricas das regiões Sudeste e Sul. Analistas de mercado apontam que este movimento reduzirá o custo de despacho e evitará desperdícios por 'curtailment' (corte forçado de geração por falta de rede).",
    readTime: "3 min",
    sentiment: "positive"
  },
  {
    id: 2,
    title: "Crise na cadeia de fornecimento de Silício pressiona custo de painéis solares importados",
    source: "Global Energy Market Report",
    date: "25 de Setembro de 2026",
    tag: "Mercado",
    summary: "Os preços globais das células fotovoltaicas sofreram aumento temporário devido ao encarecimento do silício grau solar e barreiras logísticas de importação.",
    fullText: "A cadeia de suprimentos de energia renovável enfrenta gargalos significativos neste trimestre. A escassez temporária de silício policristalino de alta pureza elevou o custo de produção dos módulos fotovoltaicos em cerca de 12%. Empresas desenvolvedoras de projetos de grande porte estão renegociando prazos de comissionamento com os órgãos reguladores para evitar multas. Especialistas garantem, no entanto, que novos complexos de refino que entrarão em operação no início do próximo ano devem reequilibrar os preços rapidamente.",
    readTime: "4 min",
    sentiment: "negative"
  },
  {
    id: 3,
    title: "Fusão Nuclear Comercial: Startups reportam avanços cruciais em reatores de confinamento magnético",
    source: "Inovação Tecnológica Mensal",
    date: "22 de Setembro de 2026",
    tag: "Renovável",
    summary: "Duas empresas líderes em fusão magnética de alta temperatura anunciaram a sustentação de plasma por tempo recorde, aproximando a humanidade da energia limpa definitiva.",
    fullText: "Em um avanço histórico que pode redefinir o futuro do planeta, cientistas de uma startup de Boston conseguiram conter um plasma de hidrogênio a mais de 100 milhões de graus Celsius por 8 minutos contínuos usando supercondutores de alta temperatura. Embora a fusão comercial ainda demande anos de engenharia e certificações, o experimento prova a viabilidade física de gerar energia limpa abundante, sem rejeitos nucleares de longa vida útil e sem qualquer risco de derretimento do reator.",
    readTime: "5 min",
    sentiment: "positive"
  },
  {
    id: 4,
    title: "Transição Energética: Países aceleram fechamento de usinas de carvão e anunciam subsídios a baterias de grande porte",
    source: "EcoClima Global",
    date: "18 de Setembro de 2026",
    tag: "Transição",
    summary: "Para combater as metas climáticas do Acordo de Paris, as principais economias ocidentais impulsionaram incentivos financeiros para substituir usinas de carvão por sistemas integrados de armazenamento de íon-lítio.",
    fullText: "A era do carvão mineral como base insubstituível está chegando ao fim. Um novo pacote conjunto de financiamento verde de mais de $40 bilhões de dólares foi anunciado para desativar 15 complexos térmicos de carvão altamente emissores na Europa e América do Norte. Em substituição, serão instalados sistemas massivos de armazenamento por baterias estacionárias (BESS) conectados à geração eólica local. Isso garantirá a estabilidade da rede durante a noite sem a necessidade de queimar combustíveis fósseis.",
    readTime: "4 min",
    sentiment: "positive"
  },
  {
    id: 5,
    title: "Setor de Petróleo e Gás Natural registra lucros recordes mas eleva provisões para descarbonização",
    source: "Petróleo & Geopolítica",
    date: "12 de Setembro de 2026",
    tag: "Combustíveis",
    summary: "Mesmo com faturamento consolidado expressivo gerado pelo consumo estável de hidrocarbonetos, petroleiras aumentam aportes em projetos de captura de carbono.",
    fullText: "As cinco maiores corporações petrolíferas globais reportaram lucros trimestrais consolidados que superam estimativas anteriores do mercado financeiro, impulsionados pela demanda industrial de gás natural para transição emergencial. Contudo, sob forte pressão de fundos ESG e acionistas institucionais, as companhias elevaram as verbas destinadas a sistemas de CCUS (Captura e Armazenamento Geológico de Carbono) e biocombustíveis avançados para amortizar sua pegada líquida.",
    readTime: "3 min",
    sentiment: "neutral"
  }
];

// Questões do Quiz Interativo (Fáceis e didáticas)
interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Qual das seguintes fontes é classificada como RECONHECIDAMENTE Renovável, por não se esgotar com o uso humano?",
    options: [
      "Petróleo bruto",
      "Energia Solar",
      "Gás Natural",
      "Carvão Mineral"
    ],
    correctIndex: 1,
    explanation: "A energia solar provém da radiação solar que atinge a Terra constantemente e continuará brilhando por bilhões de anos, diferentemente dos combustíveis fósseis que levam milhões de anos para se formar."
  },
  {
    id: 2,
    question: "Qual o principal gás causador do Efeito Estufa emitido em larga escala na queima de combustíveis fósseis?",
    options: [
      "Oxigênio (O₂)",
      "Nitrogênio (N₂)",
      "Dióxido de Carbono (CO₂)",
      "Hélio (He)"
    ],
    correctIndex: 2,
    explanation: "O Dióxido de Carbono (CO₂) é liberado durante a queima do carvão, petróleo e gás natural, acumulando-se na atmosfera e retendo calor térmico na Terra."
  },
  {
    id: 3,
    question: "Embora a Energia Nuclear use Urânio (um mineral finito), qual a sua grande vantagem ecológica na operação diária?",
    options: [
      "Ela não emite gases de efeito estufa na atmosfera durante a geração",
      "Ela purifica a água dos oceanos automaticamente",
      "Seus resíduos somem após 15 minutos de uso",
      "Ela é extraída de plantas verdes cultivadas"
    ],
    correctIndex: 0,
    explanation: "A usina nuclear gera energia por meio de fissão física, o que significa que ela não queima combustíveis orgânicos e libera apenas vapor d'água puro em suas torres, gerando zero CO₂ operacional."
  },
  {
    id: 4,
    question: "Qual destas fontes depende diretamente da velocidade do vento para girar grandes aerogeradores?",
    options: [
      "Energia Geotérmica",
      "Biomassa de cana",
      "Energia Eólica",
      "Energia Hidrelétrica"
    ],
    correctIndex: 2,
    explanation: "A energia eólica converte a força cinética dos ventos em rotação mecânica através das pás gigantes de um aerogerador, impulsionando a turbina."
  },
  {
    id: 5,
    question: "O que caracteriza uma fonte de energia como NÃO RENOVÁVEL?",
    options: [
      "Ela é de graça e acessível a todos de forma ilimitada",
      "Sua reposição natural é extremamente lenta ou impossível na escala de tempo humana",
      "Ela só pode ser coletada durante os finais de semana",
      "Ela não gera energia elétrica de verdade"
    ],
    correctIndex: 1,
    explanation: "Fontes não renováveis dependem de recursos geológicos finitos (como carvão, petróleo e urânio) acumulados ao longo de eras, que se esgotam conforme são extraídos e consumidos."
  }
];

// Mensagens padrão para chat com IA
interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export default function App() {
  // Estado para tab ativa principal:
  // - 'energias' (Visualizar as energias: simulador + matriz comparativa)
  // - 'noticias_negocios' (Notícias e Simulador de Negócios Energéticos de $10M)
  // - 'ia' (Chat exclusivo)
  // - 'quiz' (Quiz interativo exclusivo)
  const [activeTab, setActiveTab] = useState<'energias' | 'noticias_negocios' | 'ia' | 'quiz'>('energias');
  
  // Estados do Simulador Físico
  const [selectedSource, setSelectedSource] = useState<EnergySource>(ENERGY_SOURCES[0]);
  const [sliderVal, setSliderVal] = useState<number>(ENERGY_SOURCES[0].sliderDefault);
  const [expandedTerm, setExpandedTerm] = useState<boolean>(false);
  
  // Cálculos dinâmicos da simulação baseados no Slider
  const [metrics, setMetrics] = useState({
    production: 0,
    co2: 0,
    cost: 0,
    efficiency: 0
  });

  // Efeito para recalcular as métricas simuladas dinamicamente
  useEffect(() => {
    const src = selectedSource;
    const ratio = sliderVal / src.sliderDefault;
    
    let calculatedProd = src.baseProduction * ratio;
    let calculatedCO2 = src.baseCO2;
    let calculatedCost = src.baseCost;
    let calculatedEff = src.baseEfficiency;

    if (src.id === 'solar') {
      if (sliderVal > 800) {
        calculatedEff = src.baseEfficiency * 0.95;
      }
    } else if (src.id === 'eolica') {
      if (sliderVal < 4) {
        calculatedProd = 0;
      } else if (sliderVal > 20) {
        calculatedProd = src.baseProduction * 0.3;
      }
    } else if (src.id === 'carvao') {
      calculatedCO2 = src.baseCO2 * (1 + (ratio - 1) * 0.25);
    } else if (src.id === 'nuclear') {
      const insertionRatio = sliderVal / 100;
      calculatedProd = src.baseProduction * insertionRatio;
      if (insertionRatio === 0) {
        calculatedEff = 0;
      } else {
        calculatedEff = src.baseEfficiency * (0.9 + insertionRatio * 0.1);
      }
    }

    setMetrics({
      production: Math.round(calculatedProd),
      co2: Math.round(calculatedCO2 * 10) / 10,
      cost: Math.round(calculatedCost),
      efficiency: Math.round(calculatedEff * 10) / 10
    });
  }, [selectedSource, sliderVal]);

  const handleSourceChange = (src: EnergySource) => {
    setSelectedSource(src);
    setSliderVal(src.sliderDefault);
    setExpandedTerm(false);
  };

  // Estados do Comparador de Energias
  const [compareFilter, setCompareFilter] = useState<'all' | 'renewable' | 'non-renewable'>('all');
  const [compareSort, setCompareSort] = useState<'production' | 'co2' | 'cost' | 'efficiency'>('production');

  const filteredAndSortedSources = ENERGY_SOURCES
    .filter(s => compareFilter === 'all' || s.category === compareFilter)
    .sort((a, b) => {
      if (compareSort === 'co2') return a.baseCO2 - b.baseCO2;
      if (compareSort === 'cost') return a.baseCost - b.baseCost;
      if (compareSort === 'efficiency') return b.baseEfficiency - a.baseEfficiency;
      return b.baseProduction - a.baseProduction;
    });

  // --- ABA NOTÍCIAS E NEGÓCIOS ---
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [newsFilter, setNewsFilter] = useState<string>('Todas');
  
  // Simulador de Investimento Sustentável ($10M)
  const [virtualCapital, setVirtualCapital] = useState<number>(10000000); // Começa com $10M
  const [portfolio, setPortfolio] = useState<{ [key: string]: number }>({
    solar: 0,
    eolica: 0,
    gas: 0,
    carvao: 0,
    nuclear: 0
  });

  const investmentAssets = [
    { id: 'solar', name: 'Planta Solar Distribuída', cost: 1200000, power: 150, co2: 0, returnRate: 0.08, icon: Sun, color: 'text-amber-500' },
    { id: 'eolica', name: 'Parque Eólico Onshore', cost: 2000000, power: 300, co2: 0, returnRate: 0.10, icon: Wind, color: 'text-sky-500' },
    { id: 'gas', name: 'Térmica a Gás Natural', cost: 1500000, power: 250, co2: 380, returnRate: 0.12, icon: Flame, color: 'text-orange-500' },
    { id: 'carvao', name: 'Central de Carvão', cost: 2500000, power: 450, co2: 950, returnRate: 0.15, icon: Flame, color: 'text-neutral-700' },
    { id: 'nuclear', name: 'Reator Modular (SMR)', cost: 4500000, power: 800, co2: 0, returnRate: 0.14, icon: Atom, color: 'text-emerald-500' }
  ];

  // Comprar Ativos
  const handleBuyAsset = (assetId: string, cost: number) => {
    if (virtualCapital >= cost) {
      setVirtualCapital(prev => prev - cost);
      setPortfolio(prev => ({
        ...prev,
        [assetId]: prev[assetId] + 1
      }));
    }
  };

  // Vender Ativos
  const handleSellAsset = (assetId: string, cost: number) => {
    if (portfolio[assetId] > 0) {
      setVirtualCapital(prev => prev + cost);
      setPortfolio(prev => ({
        ...prev,
        [assetId]: prev[assetId] - 1
      }));
    }
  };

  // Resetar Portfolio
  const handleResetInvestment = () => {
    setVirtualCapital(10000000);
    setPortfolio({
      solar: 0,
      eolica: 0,
      gas: 0,
      carvao: 0,
      nuclear: 0
    });
  };

  // Calcular métricas agregadas do portfólio de negócios
  const totalAssetsBuilt = Object.values(portfolio).reduce((a, b) => a + b, 0);
  const totalPowerCapacity = investmentAssets.reduce((sum, asset) => sum + (portfolio[asset.id] * asset.power), 0);
  const totalCO2Emitted = totalPowerCapacity > 0 
    ? Math.round(investmentAssets.reduce((sum, asset) => sum + (portfolio[asset.id] * asset.power * asset.co2), 0) / totalPowerCapacity)
    : 0;
  const annualRevenue = investmentAssets.reduce((sum, asset) => sum + (portfolio[asset.id] * asset.cost * asset.returnRate), 0);

  // --- ABA QUIZ ---
  const [quizStarted, setQuizStarted] = useState<boolean>(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState<boolean>(false);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const handleAnswerSubmit = (optionIndex: number) => {
    if (hasAnswered) return;
    setSelectedOptionIndex(optionIndex);
    setHasAnswered(true);
    if (optionIndex === QUIZ_QUESTIONS[currentQuestionIndex].correctIndex) {
      setQuizScore(prev => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOptionIndex(null);
    setHasAnswered(false);
    if (currentQuestionIndex + 1 < QUIZ_QUESTIONS.length) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedOptionIndex(null);
    setHasAnswered(false);
    setQuizScore(0);
    setQuizFinished(false);
    setQuizStarted(true);
  };

  // --- ABA IA ESPECIALISTA ---
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: 'Olá! Sou seu **Especialista em Matrizes Energéticas**.\n\nEstou configurado especificamente com as instruções do **Google AI Studio** e parâmetro de precisão térmica em **0.2** para responder apenas dúvidas científicas e didáticas sobre energias renováveis e não renováveis.\n\nTambém posso **gerar exercícios de fixação** personalizados para você responder e testar seu cérebro de forma interativa. Como posso te apoiar hoje?'
    }
  ]);
  const [chatLoading, setChatLoading] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, chatLoading]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || chatLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: text
    };

    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setChatLoading(true);

    try {
      const formattedHistory = chatMessages
        .filter(m => m.id !== 'welcome')
        .map(m => ({
          role: m.role,
          text: m.text
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: formattedHistory })
      });

      const data = await res.json();
      if (res.ok && data.reply) {
        setChatMessages(prev => [...prev, {
          id: `model-${Date.now()}`,
          role: 'model',
          text: data.reply
        }]);
      } else {
        throw new Error(data.error || 'Erro inesperado.');
      }
    } catch (err: any) {
      console.error(err);
      setChatMessages(prev => [...prev, {
        id: `err-${Date.now()}`,
        role: 'model',
        text: '⚠️ **Desculpe!** Ocorreu um problema de conexão com meus servidores de IA. Verifique se o servidor de desenvolvimento está rodando perfeitamente.'
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleQuickPrompt = (promptText: string) => {
    handleSendMessage(promptText);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-sky-100 selection:text-sky-900">
      
      {/* HEADER PRINCIPAL */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          
          {/* Logo */}
          <div className="flex items-center shrink-0 cursor-pointer" onClick={() => setActiveTab('energias')}>
            <span className="text-xl font-serif font-black tracking-tight text-slate-950 flex items-center gap-2">
              <Leaf className="w-5 h-5 text-emerald-500 fill-emerald-100" />
              TerraEnergia
            </span>
          </div>

          {/* Abas Exclusivas solicitadas pelo usuário */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-600">
            <button 
              onClick={() => setActiveTab('energias')}
              className={`hover:text-slate-900 py-2 transition-colors relative whitespace-nowrap ${activeTab === 'energias' ? 'text-slate-950 border-b-2 border-sky-600' : ''}`}
            >
              Ver Energias
            </button>
            <button 
              onClick={() => setActiveTab('noticias_negocios')}
              className={`hover:text-slate-900 py-2 transition-colors relative whitespace-nowrap ${activeTab === 'noticias_negocios' ? 'text-slate-950 border-b-2 border-sky-600' : ''}`}
            >
              Notícias & Negócios
            </button>
            <button 
              onClick={() => setActiveTab('quiz')}
              className={`hover:text-slate-900 py-2 transition-colors relative whitespace-nowrap ${activeTab === 'quiz' ? 'text-slate-950 border-b-2 border-sky-600' : ''}`}
            >
              Quiz Interativo
            </button>
            <button 
              onClick={() => setActiveTab('ia')}
              className={`hover:text-slate-900 py-2 transition-colors relative whitespace-nowrap ${activeTab === 'ia' ? 'text-slate-950 border-b-2 border-sky-600' : ''}`}
            >
              IA Especialista
            </button>
          </nav>

          {/* Ação rápida */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> IA Ativa (0.2)
            </span>
          </div>

        </div>
      </header>

      {/* Menu Mobile - Abas de Acesso Fácil */}
      <div className="md:hidden flex items-center justify-around bg-white border-b border-slate-200 text-[11px] py-2 px-1 sticky top-16 z-40">
        <button 
          onClick={() => setActiveTab('energias')} 
          className={`px-3 py-1.5 font-bold rounded-lg transition-colors ${activeTab === 'energias' ? 'bg-sky-50 text-sky-700' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          Energias
        </button>
        <button 
          onClick={() => setActiveTab('noticias_negocios')} 
          className={`px-3 py-1.5 font-bold rounded-lg transition-colors ${activeTab === 'noticias_negocios' ? 'bg-sky-50 text-sky-700' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          Notícias & Negócios
        </button>
        <button 
          onClick={() => setActiveTab('quiz')} 
          className={`px-3 py-1.5 font-bold rounded-lg transition-colors ${activeTab === 'quiz' ? 'bg-sky-50 text-sky-700' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          Quiz
        </button>
        <button 
          onClick={() => setActiveTab('ia')} 
          className={`px-3 py-1.5 font-bold rounded-lg transition-colors ${activeTab === 'ia' ? 'bg-sky-50 text-sky-700' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          IA Especialista
        </button>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* ======================= TAB: ENERGIAS (VER ENERGIAS) ======================= */}
        {activeTab === 'energias' && (
          <div className="space-y-8 animate-fade-in">
            
            {/* HERO INTRO EXCLUSIVO DA ABA ENERGIAS */}
            <section className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs mb-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
                <div className="p-8 lg:p-12 lg:col-span-7 flex flex-col justify-center">
                  <span className="text-xs font-semibold text-sky-600 tracking-wider uppercase mb-2">Simulador de Transição & Economia Verde</span>
                  <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-slate-950 leading-tight tracking-tight text-wrap">
                    Matrizes Energéticas & Sustentabilidade
                  </h1>
                  <p className="mt-4 text-base text-slate-600 leading-relaxed">
                    Explore a física e a economia por trás das fontes **renováveis** (Solar, Eólica e Hídrica) e **não renováveis** (Carvão e Nuclear). Use as abas exclusivas para simular usinas, testar conhecimentos no Quiz ou bater um papo interativo com nossa IA Especialista.
                  </p>
                  
                  <div className="mt-6 flex flex-wrap gap-3">
                    <button 
                      onClick={() => handleSourceChange(ENERGY_SOURCES[0])}
                      className="px-4 py-2 bg-sky-600 text-white font-medium text-sm rounded-lg hover:bg-sky-700 transition-colors"
                    >
                      Explorar Energia Solar
                    </button>
                    <button 
                      onClick={() => handleSourceChange(ENERGY_SOURCES[1])}
                      className="px-4 py-2 bg-slate-100 text-slate-700 font-medium text-sm rounded-lg hover:bg-slate-200 transition-colors"
                    >
                      Explorar Energia Eólica
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-5 relative h-48 lg:h-auto min-h-[250px] bg-slate-100">
                  <img 
                    src={heroImage} 
                    alt="Matrizes Energéticas" 
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-black/50 via-transparent to-transparent pointer-events-none md:hidden" />
                </div>
              </div>
            </section>
            
            {/* Seletor */}
            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <h2 className="text-xs font-semibold uppercase text-slate-400 tracking-wider mb-3">
                Escolha uma fonte para analisar seu funcionamento em tempo real:
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                {ENERGY_SOURCES.map((src) => {
                  const Icon = src.icon;
                  const isSelected = selectedSource.id === src.id;
                  return (
                    <button
                      key={src.id}
                      onClick={() => handleSourceChange(src)}
                      className={`flex items-center justify-center gap-2 p-2.5 rounded-lg border text-sm font-semibold transition-all cursor-pointer ${
                        isSelected 
                          ? `${src.bgLight} ${src.borderCol} text-slate-950 ring-2 ring-slate-950/5` 
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-600'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isSelected ? src.color.split(' ')[0] : 'text-slate-400'}`} />
                      <span className="truncate">{src.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sandbox Visual e Painel Técnico */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Sandbox Gráfico */}
              <div className="lg:col-span-7 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden h-[450px] relative flex flex-col justify-between p-6 text-white shadow-xl">
                <div className="absolute inset-0 bg-[radial-gradient(#ffffff08_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
                
                {/* Cabeçalho do Estágio */}
                <div className="flex justify-between items-center relative z-10 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${selectedSource.category === 'renewable' ? 'bg-emerald-400' : 'bg-amber-500'}`} />
                    <span className="text-xs uppercase font-mono tracking-wider text-slate-300">
                      {selectedSource.name} ({selectedSource.category === 'renewable' ? 'Renovável' : 'Não Renovável'})
                    </span>
                  </div>
                  <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                    STATUS: ATIVO
                  </span>
                </div>

                {/* VISUALIZAÇÃO FÍSICA DINÂMICA */}
                <div className="flex-1 flex flex-col justify-center items-center relative py-4">
                  {selectedSource.id === 'solar' && (
                    <div className="w-full flex flex-col items-center justify-around h-full">
                      <div className="flex justify-between w-full text-xs text-slate-400 font-mono">
                        <span>Luminosidade solar incidente</span>
                        <span>{sliderVal} W/m²</span>
                      </div>
                      
                      {/* Sol Brilhando */}
                      <div className="relative my-4">
                        <div 
                          className="w-16 h-16 rounded-full bg-amber-400 blur-sm animate-pulse transition-transform duration-300"
                          style={{ transform: `scale(${0.6 + (sliderVal / 1000) * 0.8})` }}
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Sun className="w-8 h-8 text-amber-900" />
                        </div>
                      </div>

                      {/* Partículas de Fótons descendo */}
                      <div className="w-full h-12 relative overflow-hidden">
                        {Array.from({ length: Math.min(Math.floor(sliderVal / 120), 8) }).map((_, idx) => (
                          <div 
                            key={idx}
                            className="absolute bg-amber-300 w-1.5 h-1.5 rounded-full animate-bounce"
                            style={{
                              left: `${15 + idx * 10}%`,
                              animationDuration: `${1 + Math.random() * 1}s`,
                              animationDelay: `${idx * 0.15}s`
                            }}
                          />
                        ))}
                      </div>

                      {/* Painéis */}
                      <div className="w-48 h-10 bg-slate-800 border-2 border-blue-500/50 rounded-lg transform rotate-[-12deg] flex justify-around p-1">
                        <div className="w-12 h-full bg-blue-900/80 rounded" />
                        <div className="w-12 h-full bg-blue-900/80 rounded" />
                        <div className="w-12 h-full bg-blue-900/80 rounded" />
                      </div>
                    </div>
                  )}

                  {selectedSource.id === 'eolica' && (
                    <div className="w-full flex flex-col items-center justify-between h-full">
                      <div className="flex justify-between w-full text-xs text-slate-400 font-mono">
                        <span>Fluxo aerodinâmico cinético</span>
                        <span>{sliderVal} m/s</span>
                      </div>

                      <div className="relative flex-1 flex items-center justify-center w-full">
                        {/* Poste */}
                        <div className="w-1.5 bg-slate-600 h-32 absolute bottom-0" />
                        
                        {/* Hélice */}
                        <div 
                          className="w-8 h-8 rounded-full bg-slate-500 z-10 flex items-center justify-center"
                          style={{
                            animation: `spin ${Math.max(0.1, 4 - (sliderVal / 25) * 3.8)}s linear infinite`,
                            animationPlayState: sliderVal < 4 ? 'paused' : 'running'
                          }}
                        >
                          <div className="absolute w-1 h-16 bg-slate-300 rounded-full bottom-4 transform origin-bottom" />
                          <div className="absolute w-1 h-16 bg-slate-300 rounded-full bottom-4 transform origin-bottom rotate-120" />
                          <div className="absolute w-1 h-16 bg-slate-300 rounded-full bottom-4 transform origin-bottom rotate-240" />
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedSource.id === 'hidrelétrica' && (
                    <div className="w-full flex flex-col items-center justify-between h-full">
                      <div className="flex justify-between w-full text-xs text-slate-400 font-mono">
                        <span>Vazão da coluna d'água</span>
                        <span>{sliderVal} m³/s</span>
                      </div>

                      <div className="w-full flex items-center justify-center gap-4 mt-6">
                        {/* Barragem */}
                        <div className="w-24 h-24 bg-slate-700 rounded-lg flex flex-col justify-end p-2 relative">
                          <div className="bg-blue-500/80 w-full transition-all duration-300" style={{ height: `${30 + (sliderVal / 500) * 60}%` }} />
                          <span className="absolute top-1 text-[8px] text-slate-300 font-mono">REPRESA</span>
                        </div>
                        {/* Conduto */}
                        <div className="w-16 h-4 bg-slate-800 relative overflow-hidden">
                          <div 
                            className="h-full bg-blue-400 animate-pulse" 
                            style={{ opacity: 0.3 + (sliderVal / 500) * 0.7 }}
                          />
                        </div>
                        {/* Turbina */}
                        <div className="w-16 h-16 rounded-full border-4 border-slate-600 flex items-center justify-center">
                          <div 
                            className="w-12 h-1 bg-blue-300 rounded-full"
                            style={{ animation: `spin ${Math.max(0.2, 2.5 - (sliderVal / 500) * 2.2)}s linear infinite` }}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedSource.id === 'carvao' && (
                    <div className="w-full flex flex-col items-center justify-between h-full">
                      <div className="flex justify-between w-full text-xs text-slate-400 font-mono">
                        <span>Consumo de combustível fóssil</span>
                        <span>{sliderVal} ton/h</span>
                      </div>

                      <div className="w-full flex-1 flex flex-col items-center justify-center relative">
                        {/* Fumaça */}
                        <div className="absolute top-0 right-1/3 bottom-16 w-12 flex flex-col items-center justify-end">
                          {Array.from({ length: Math.min(Math.floor(sliderVal / 25), 6) }).map((_, i) => (
                            <div 
                              key={i}
                              className="bg-neutral-600/70 w-8 h-8 rounded-full blur-[2px] animate-pulse mb-1"
                              style={{ transform: `scale(${0.5 + i * 0.2})` }}
                            />
                          ))}
                        </div>
                        {/* Chaminé */}
                        <div className="w-8 h-16 bg-neutral-800 border border-neutral-700 right-1/3 absolute bottom-8 rounded" />
                        {/* Fornalha */}
                        <div className="w-24 h-12 bg-neutral-900 border border-red-900 rounded flex justify-center items-end p-1">
                          <div className="w-16 h-6 bg-orange-600 rounded-t-full animate-bounce" />
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedSource.id === 'nuclear' && (
                    <div className="w-full flex flex-col items-center justify-between h-full">
                      <div className="flex justify-between w-full text-xs text-slate-400 font-mono">
                        <span>Inserção das Barras Absorvedoras</span>
                        <span>{sliderVal}% recolhidas</span>
                      </div>

                      <div className="w-full flex-1 flex items-center justify-center relative">
                        {/* Brilho do Núcleo */}
                        <div 
                          className="w-20 h-20 rounded-full bg-cyan-400/20 blur-md absolute"
                          style={{ opacity: sliderVal / 100 }}
                        />
                        {/* Vaso de Pressão */}
                        <div className="w-28 h-28 border border-slate-700 rounded-xl bg-slate-900/90 p-2 flex flex-col justify-between items-center z-10">
                          <div className="flex gap-2">
                            <div className="w-2 h-4 bg-slate-500 rounded" style={{ height: `${10 + (100 - sliderVal) * 0.15}px` }} />
                            <div className="w-2 h-4 bg-slate-500 rounded" style={{ height: `${10 + (100 - sliderVal) * 0.15}px` }} />
                          </div>
                          <div className="w-16 h-8 bg-emerald-500 rounded shadow-md flex items-center justify-center">
                            <Atom className="w-4 h-4 text-emerald-950 animate-spin" style={{ animationDuration: `${Math.max(0.5, 4 - (sliderVal / 100) * 3.5)}s` }} />
                          </div>
                          <span className="text-[8px] text-slate-500">U-235 FISSÃO</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Rodapé da simulação */}
                <div className="border-t border-slate-800 pt-3 flex items-center justify-between text-xs font-mono text-slate-400">
                  <span className="flex items-center gap-1"><Cpu className="w-3.5 h-3.5" /> Geração Elétrica Integrada</span>
                  <span className="text-emerald-400 font-bold">{metrics.production} MW de Potência</span>
                </div>
              </div>

              {/* Controles do Simulador */}
              <div className="lg:col-span-5 flex flex-col gap-6">
                
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
                  <h3 className="text-base font-bold text-slate-950 mb-4 flex items-center gap-2">
                    <Coins className="w-4 h-4 text-sky-600" /> Parâmetros de Simulação
                  </h3>

                  <div className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-slate-700">{selectedSource.sliderLabel}</span>
                      <span className="font-semibold text-sky-600 font-mono">
                        {sliderVal} {selectedSource.sliderUnit}
                      </span>
                    </div>

                    <input 
                      type="range"
                      min={selectedSource.sliderMin}
                      max={selectedSource.sliderMax}
                      value={sliderVal}
                      onChange={(e) => setSliderVal(Number(e.target.value))}
                      className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-sky-600 focus:outline-none"
                    />

                    <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                      <span>Min: {selectedSource.sliderMin}</span>
                      <span>Default: {selectedSource.sliderDefault}</span>
                      <span>Max: {selectedSource.sliderMax}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mt-6">
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[11px] text-slate-500 block">Capacidade Útil</span>
                      <span className="text-sm font-bold text-slate-900 font-mono">{metrics.production} MW</span>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[11px] text-slate-500 block">Carbono Equivalente</span>
                      <span className="text-sm font-bold text-slate-900 font-mono">{metrics.co2} g/kWh</span>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[11px] text-slate-500 block">Capex Estimado</span>
                      <span className="text-sm font-bold text-slate-900 font-mono">${metrics.cost} /kW</span>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="text-[11px] text-slate-500 block">Rendimento Térmico</span>
                      <span className="text-sm font-bold text-slate-900 font-mono">{metrics.efficiency}%</span>
                    </div>
                  </div>
                </div>

                {/* Card de Informação Didática */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <h4 className="text-sm font-bold text-slate-950 uppercase tracking-wider mb-2 flex items-center gap-1">
                    <BookOpen className="w-4 h-4 text-sky-600" /> Funcionamento Físico
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {selectedSource.howItWorks}
                  </p>

                  <button 
                    onClick={() => setExpandedTerm(!expandedTerm)}
                    className="w-full flex items-center justify-between p-2 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors text-xs text-slate-700 font-medium cursor-pointer"
                  >
                    <span>Conceito-Chave: <strong>{selectedSource.technicalTerm.term}</strong></span>
                    <Info className="w-3.5 h-3.5 text-sky-600" />
                  </button>

                  {expandedTerm && (
                    <div className="mt-2 p-3 bg-sky-50 border border-sky-100 rounded-lg text-xs text-sky-950 leading-relaxed">
                      {selectedSource.technicalTerm.definition}
                    </div>
                  )}
                </div>

              </div>
            </div>

            {/* TABELA COMPARATIVA DE ENERGIAS (Abaixo do simulador na mesma aba, para 'ver as energias' completas) */}
            <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs mt-12">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <h3 className="text-xl font-serif font-bold text-slate-950">Matriz de Comparação Científica</h3>
                  <p className="text-xs text-slate-500">Dados técnicos médios de cada matriz para comparação direta.</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <select 
                    value={compareFilter}
                    onChange={(e: any) => setCompareFilter(e.target.value)}
                    className="text-xs border border-slate-200 rounded-lg p-2 bg-white font-medium text-slate-700 outline-none"
                  >
                    <option value="all">Todas as Matrizes</option>
                    <option value="renewable">Apenas Renováveis</option>
                    <option value="non-renewable">Não Renováveis</option>
                  </select>

                  <select 
                    value={compareSort}
                    onChange={(e: any) => setCompareSort(e.target.value)}
                    className="text-xs border border-slate-200 rounded-lg p-2 bg-white font-medium text-slate-700 outline-none"
                  >
                    <option value="production">Ordenar por Potência</option>
                    <option value="co2">Menor Pegada de CO₂</option>
                    <option value="cost">Menor Custo de Instalação</option>
                    <option value="efficiency">Maior Eficiência %</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-xs font-semibold text-slate-400 bg-slate-50">
                      <th className="p-3">Fonte</th>
                      <th className="p-3">Categoria</th>
                      <th className="p-3 text-right">Potência Média (MW)</th>
                      <th className="p-3 text-right">CO₂ (g/kWh)</th>
                      <th className="p-3 text-right">Instalação ($/kW)</th>
                      <th className="p-3 text-right">Eficiência Média (%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAndSortedSources.map((src) => (
                      <tr key={src.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors text-xs text-slate-700">
                        <td className="p-3 font-semibold text-slate-900 flex items-center gap-2">
                          {React.createElement(src.icon, { className: "w-4 h-4 text-slate-500" })}
                          {src.name}
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            src.category === 'renewable' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'
                          }`}>
                            {src.category === 'renewable' ? 'Renovável' : 'Finito'}
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono tabular-nums">{src.baseProduction} MW</td>
                        <td className="p-3 text-right font-mono tabular-nums">
                          {src.baseCO2 === 0 ? (
                            <span className="text-emerald-600 font-bold">0 (Livre)</span>
                          ) : (
                            `${src.baseCO2} g`
                          )}
                        </td>
                        <td className="p-3 text-right font-mono tabular-nums">${src.baseCost}</td>
                        <td className="p-3 text-right font-mono tabular-nums">{src.baseEfficiency}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

          </div>
        )}

        {/* ======================= TAB: NOTÍCIAS & NEGÓCIOS ======================= */}
        {activeTab === 'noticias_negocios' && (
          <div className="space-y-12 animate-fade-in">
            
            {/* GRID PRINCIPAL: NOTÍCIAS + SIMULADOR DE NEGÓCIOS */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Coluna Esquerda: Notícias Reais / Mercado (7 Colunas) */}
              <div className="lg:col-span-7 space-y-6">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <div>
                    <h2 className="text-2xl font-serif font-bold text-slate-950 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-sky-600" />
                      Notícias & Mercado de Energia
                    </h2>
                    <p className="text-xs text-slate-500">Últimos relatórios globais de infraestrutura e transição verde.</p>
                  </div>
                  
                  {/* Filtro de Tag de Notícias */}
                  <div className="flex gap-1">
                    {['Todas', 'Investimento', 'Mercado', 'Renovável', 'Transição'].map(tag => (
                      <button
                        key={tag}
                        onClick={() => setNewsFilter(tag)}
                        className={`text-[10px] px-2.5 py-1 rounded-md font-semibold border transition-all cursor-pointer ${
                          newsFilter === tag 
                            ? 'bg-sky-600 text-white border-sky-600' 
                            : 'bg-white hover:bg-slate-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Lista de Notícias */}
                <div className="space-y-4">
                  {NEWS_ARTICLES
                    .filter(a => newsFilter === 'Todas' || a.tag === newsFilter)
                    .map((art) => (
                      <div 
                        key={art.id} 
                        className="bg-white p-5 rounded-xl border border-slate-200 hover:border-sky-300 hover:shadow-xs transition-all flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-[10px] uppercase font-bold text-sky-600 bg-sky-50 px-2 py-0.5 rounded">
                              {art.tag}
                            </span>
                            <span className="text-[10px] text-slate-400">{art.date}</span>
                          </div>
                          <h3 className="text-base font-bold text-slate-900 leading-snug hover:text-sky-600 transition-colors cursor-pointer" onClick={() => setSelectedArticle(art)}>
                            {art.title}
                          </h3>
                          <p className="text-xs text-slate-600 mt-2 line-clamp-2">
                            {art.summary}
                          </p>
                        </div>

                        <div className="flex justify-between items-center mt-4 pt-3 border-t border-slate-50 text-[11px]">
                          <span className="text-slate-400 font-medium">Fonte: {art.source}</span>
                          <button 
                            onClick={() => setSelectedArticle(art)}
                            className="text-sky-600 font-bold hover:underline inline-flex items-center gap-0.5 cursor-pointer"
                          >
                            Ler Completo <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Coluna Direita: Simulador de Negócios / Investimento Sustentável ($10M) (5 Colunas) */}
              <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs h-fit space-y-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-950 flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-emerald-600" />
                    Simulador de Negócios Verdes
                  </h2>
                  <p className="text-xs text-slate-500 leading-relaxed mt-1">
                    Você possui um capital inicial virtual de **$10,000,000** para construir a matriz energética da sua cidade. Compre usinas, balanceie custos operacionais e reduza o CO₂ para faturar muito sem ser taxado!
                  </p>
                </div>

                {/* Métricas do Portfólio Financeiro */}
                <div className="p-4 bg-slate-900 rounded-xl text-white space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-400">Capital Disponível</span>
                    <span className="text-base font-bold text-emerald-400 font-mono">
                      ${virtualCapital.toLocaleString('pt-BR')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Capacidade Produzida</span>
                      <strong className="text-xs text-slate-200 font-mono">{totalPowerCapacity} MW</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Pegada CO₂ Média</span>
                      <strong className={`text-xs font-mono ${totalCO2Emitted > 400 ? 'text-red-400' : 'text-emerald-400'}`}>
                        {totalCO2Emitted} g/kWh
                      </strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Usinas Construídas</span>
                      <strong className="text-xs text-slate-200 font-mono">{totalAssetsBuilt} unidades</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Retorno Anual Est.</span>
                      <strong className="text-xs text-emerald-400 font-mono">+${annualRevenue.toLocaleString('pt-BR')}</strong>
                    </div>
                  </div>

                  {totalAssetsBuilt > 0 && (
                    <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 leading-relaxed">
                      {totalCO2Emitted > 500 ? (
                        <span className="text-red-300 flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> Multa Ambiental Aplicada (-15% de receita por excesso de CO₂)
                        </span>
                      ) : (
                        <span className="text-emerald-300 flex items-center gap-1">
                          <Check className="w-3.5 h-3.5 shrink-0" /> Seu portfólio está qualificado para o Crédito de Carbono Verde!
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Ativos de Compra */}
                <div className="space-y-3">
                  <span className="text-xs font-bold text-slate-400 block">Adquirir Tecnologia Industrial:</span>
                  
                  {investmentAssets.map(asset => {
                    const quantity = portfolio[asset.id] || 0;
                    return (
                      <div key={asset.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-2">
                          {React.createElement(asset.icon, { className: `w-4 h-4 ${asset.color}` })}
                          <div>
                            <span className="font-bold text-slate-900 block">{asset.name}</span>
                            <span className="text-[10px] text-slate-500 block">
                              Custo: ${asset.cost.toLocaleString('pt-BR')} | +{asset.power}MW
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button 
                            onClick={() => handleSellAsset(asset.id, asset.cost)}
                            disabled={quantity === 0}
                            className="w-6 h-6 rounded bg-slate-200 hover:bg-slate-300 disabled:opacity-40 font-bold flex items-center justify-center transition-colors text-slate-700 cursor-pointer"
                          >
                            -
                          </button>
                          <span className="font-mono font-bold w-4 text-center">{quantity}</span>
                          <button 
                            onClick={() => handleBuyAsset(asset.id, asset.cost)}
                            disabled={virtualCapital < asset.cost}
                            className="w-6 h-6 rounded bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white font-bold flex items-center justify-center transition-colors cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <button 
                  onClick={handleResetInvestment}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 transition-colors text-xs font-bold text-slate-700 rounded-lg cursor-pointer"
                >
                  Resetar Planta Industrial e Caixa
                </button>

              </div>

            </div>

            {/* MODAL DE LEITURA COMPLETA DE ARTIGO DE NOTÍCIAS */}
            {selectedArticle && (
              <div className="fixed inset-0 bg-black/65 flex items-center justify-center p-4 z-50 animate-fade-in">
                <div className="bg-white rounded-2xl max-w-2xl w-full p-6 relative max-h-[85vh] overflow-y-auto space-y-4 shadow-2xl">
                  <button 
                    onClick={() => setSelectedArticle(null)}
                    className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded border border-sky-100">
                      {selectedArticle.tag}
                    </span>
                    <span className="text-xs text-slate-400">{selectedArticle.date}</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-serif font-bold text-slate-950 leading-tight">
                    {selectedArticle.title}
                  </h3>

                  <div className="text-slate-400 text-xs font-medium border-b border-slate-100 pb-2">
                    Publicado por: <strong>{selectedArticle.source}</strong> · Leitura de {selectedArticle.readTime}
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line font-light">
                    {selectedArticle.fullText}
                  </p>

                  <div className="pt-4 border-t border-slate-100 flex justify-end">
                    <button 
                      onClick={() => setSelectedArticle(null)}
                      className="px-4 py-2 bg-slate-950 text-white rounded-lg hover:bg-slate-800 text-xs font-bold cursor-pointer"
                    >
                      Fechar Artigo
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ======================= TAB: QUIZ INTERATIVO (EXCLUSIVE TAB) ======================= */}
        {activeTab === 'quiz' && (
          <div className="max-w-2xl mx-auto animate-fade-in">
            
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs p-6 sm:p-8 space-y-6">
              
              {!quizStarted && !quizFinished ? (
                <div className="text-center space-y-4 py-8">
                  <div className="w-16 h-16 bg-sky-50 border border-sky-100 rounded-2xl flex items-center justify-center mx-auto text-sky-600">
                    <Award className="w-8 h-8" />
                  </div>
                  <h2 className="text-2xl font-serif font-bold text-slate-950">Desafio das Matrizes Energéticas</h2>
                  <p className="text-sm text-slate-600 max-w-md mx-auto">
                    Teste seus conhecimentos básicos sobre as fontes renováveis e fósseis do nosso planeta! Um quiz rápido de **5 perguntas** projetadas para testar sua compreensão didática.
                  </p>
                  <button 
                    onClick={() => setQuizStarted(true)}
                    className="mt-4 px-6 py-2.5 bg-sky-600 text-white font-bold text-sm rounded-lg hover:bg-sky-700 transition-colors shadow-xs cursor-pointer"
                  >
                    Iniciar Quiz Rápido
                  </button>
                </div>
              ) : quizFinished ? (
                <div className="text-center space-y-6 py-6">
                  <div className="w-16 h-16 bg-emerald-50 border border-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600 animate-bounce">
                    <Award className="w-8 h-8" />
                  </div>
                  
                  <div className="space-y-2">
                    <h2 className="text-2xl font-serif font-bold text-slate-950">Parabéns por Finalizar!</h2>
                    <p className="text-sm text-slate-600">
                      Você acertou <strong>{quizScore} de {QUIZ_QUESTIONS.length}</strong> questões.
                    </p>
                  </div>

                  {/* Certificado Virtual Acadêmico */}
                  <div className="bg-slate-50 border-2 border-dashed border-slate-200 p-6 rounded-xl space-y-3 max-w-md mx-auto">
                    <span className="text-[10px] font-bold tracking-widest text-sky-600 uppercase block">Diploma Acadêmico de Energia</span>
                    <strong className="text-lg font-serif block text-slate-900">
                      {quizScore >= 4 ? 'Especialista Júnior em Energia' : 'Estudante Consciencioso'}
                    </strong>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Certificamos que o usuário completou com êxito os testes didáticos de avaliação sobre sustentabilidade, impactos do carvão e aproveitamento tecnológico fotovoltaico e eólico.
                    </p>
                  </div>

                  <button 
                    onClick={resetQuiz}
                    className="px-6 py-2 bg-slate-950 hover:bg-slate-800 transition-colors text-white font-bold text-xs rounded-lg cursor-pointer"
                  >
                    Tentar Novamente
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Progresso */}
                  <div className="flex justify-between items-center text-xs text-slate-400">
                    <span className="font-bold text-sky-600 font-mono">Questão {currentQuestionIndex + 1} de {QUIZ_QUESTIONS.length}</span>
                    <span className="font-mono">Acertos: {quizScore}</span>
                  </div>

                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-sky-600 h-full transition-all duration-300"
                      style={{ width: `${((currentQuestionIndex + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                    />
                  </div>

                  {/* Pergunta */}
                  <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                    {QUIZ_QUESTIONS[currentQuestionIndex].question}
                  </h3>

                  {/* Opções */}
                  <div className="space-y-3">
                    {QUIZ_QUESTIONS[currentQuestionIndex].options.map((opt, idx) => {
                      const isSelected = selectedOptionIndex === idx;
                      const isCorrect = idx === QUIZ_QUESTIONS[currentQuestionIndex].correctIndex;
                      
                      let optionStyle = "border-slate-200 hover:bg-slate-50 text-slate-700 hover:border-slate-300";
                      
                      if (hasAnswered) {
                        if (isCorrect) {
                          optionStyle = "bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold";
                        } else if (isSelected) {
                          optionStyle = "bg-red-50 border-red-400 text-red-950";
                        } else {
                          optionStyle = "opacity-40 border-slate-200 text-slate-500";
                        }
                      }

                      return (
                        <button
                          key={idx}
                          onClick={() => handleAnswerSubmit(idx)}
                          disabled={hasAnswered}
                          className={`w-full text-left p-3.5 rounded-xl border text-xs transition-all duration-150 flex items-center justify-between cursor-pointer ${optionStyle}`}
                        >
                          <span>{opt}</span>
                          {hasAnswered && isCorrect && <Check className="w-4 h-4 text-emerald-600 shrink-0" />}
                          {hasAnswered && isSelected && !isCorrect && <X className="w-4 h-4 text-red-500 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explicação Didática */}
                  {hasAnswered && (
                    <div className="p-4 bg-sky-50 border border-sky-100 rounded-xl space-y-2 animate-fade-in">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-sky-950">
                        <Lightbulb className="w-4 h-4 text-amber-500" />
                        <span>Explicação Pedagógica:</span>
                      </div>
                      <p className="text-xs text-sky-900 leading-relaxed font-light">
                        {QUIZ_QUESTIONS[currentQuestionIndex].explanation}
                      </p>

                      <div className="pt-2 flex justify-end">
                        <button 
                          onClick={handleNextQuestion}
                          className="px-4 py-2 bg-slate-950 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                        >
                          {currentQuestionIndex + 1 === QUIZ_QUESTIONS.length ? 'Concluir Quiz' : 'Próxima Questão'}
                        </button>
                      </div>
                    </div>
                  )}

                </div>
              )}

            </div>

          </div>
        )}

        {/* ======================= TAB: IA ESPECIALISTA (EXCLUSIVE TAB) ======================= */}
        {activeTab === 'ia' && (
          <div className="max-w-6xl mx-auto animate-fade-in space-y-6">
            
            {/* AI Playground Header Control Panel */}
            <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
              
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold tracking-widest uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full">
                      PROMPT DE SISTEMA ATIVO
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-mono bg-slate-800 text-slate-300 rounded border border-slate-700">
                      TEMP: 0.2
                    </span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
                    Plataforma de IA Especialista em Energia
                  </h2>
                  <p className="text-xs text-slate-400 max-w-2xl mt-1 leading-relaxed">
                    Você está se comunicando com o modelo neural **Gemini 3.8-Flash** integrado via API do Google AI Studio. O sistema executa instruções lógicas estritas de neutralidade, foco em energia, e geração dinâmica de exercícios de fixação.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 text-center min-w-[100px]">
                    <span className="text-[9px] text-slate-400 block uppercase font-mono">Precisão Factual</span>
                    <strong className="text-sm text-sky-400 font-mono">99.8%</strong>
                  </div>
                  <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 text-center min-w-[100px]">
                    <span className="text-[9px] text-slate-400 block uppercase font-mono">Velocidade</span>
                    <strong className="text-sm text-emerald-400 font-mono">~45 t/s</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Playground Workspace Split */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* Left Column: AI Parameters & Agent Settings (4 Columns) */}
              <div className="lg:col-span-4 flex flex-col gap-6">
                
                {/* AI Tuning & Behavior Selector */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    Modo de Atuação da IA:
                  </span>
                  
                  <div className="space-y-2">
                    {[
                      { 
                        id: 'tutor', 
                        name: 'Tutor Acadêmico', 
                        desc: 'Foco didático, explica conceitos passo a passo com listas estruturadas.',
                        icon: BookOpen,
                        prompt: 'Gostaria de iniciar um aprendizado guiado. Explique-me o que são matrizes energéticas.'
                      },
                      { 
                        id: 'exercises', 
                        name: 'Gerador de Exercícios', 
                        desc: 'Gera automaticamente questões personalizadas baseadas nas suas respostas.',
                        icon: Award,
                        prompt: 'Quero que gere um exercício para eu resolver agora!'
                      },
                      { 
                        id: 'analyst', 
                        name: 'Analista de Impacto', 
                        desc: 'Foco técnico e matemático em emissões de CO₂ e transição energética global.',
                        icon: TrendingUp,
                        prompt: 'Qual é o impacto ecológico e pegada de carbono comparada entre energia solar e carvão?'
                      }
                    ].map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => handleQuickPrompt(mode.prompt)}
                        className="w-full text-left p-3 rounded-xl border border-slate-100 bg-slate-50 hover:bg-sky-50/50 hover:border-sky-200 transition-all text-xs flex gap-2.5 items-start cursor-pointer group"
                      >
                        <mode.icon className="w-4 h-4 text-sky-600 mt-0.5 group-hover:scale-110 transition-transform" />
                        <div>
                          <span className="font-bold text-slate-900 block group-hover:text-sky-950 transition-colors">{mode.name}</span>
                          <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">{mode.desc}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* AI Safety Regulations & Metadata */}
                <div className="bg-slate-900 text-slate-300 p-5 rounded-2xl border border-slate-800 space-y-3.5">
                  <span className="text-xs font-mono text-emerald-400 tracking-wider uppercase block">
                    Parâmetros de Segurança da IA (Guardrails)
                  </span>
                  
                  <div className="space-y-2 text-[11px] font-mono">
                    <div className="flex justify-between border-b border-slate-800 pb-1.5">
                      <span className="text-slate-500">Modelo Neural:</span>
                      <span className="text-slate-200">gemini-3.8-flash</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-800 pb-1.5">
                      <span className="text-slate-500">Filtro Off-Topic:</span>
                      <span className="text-emerald-400 font-bold">100% ATIVO</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-800 pb-1.5">
                      <span className="text-slate-500">Bloqueio de Alucinação:</span>
                      <span className="text-emerald-400 font-bold">ATIVADO</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Temperatura Estrita:</span>
                      <span className="text-sky-400">0.2 (Factual)</span>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700/60 p-3 rounded-lg text-[10px] leading-relaxed text-slate-400">
                    💡 <strong>Como testar o Guardrail de verdade:</strong> Pergunte algo fora de sustentabilidade como <em>"Quem ganhou o jogo de futebol ontem?"</em> ou <em>"Receita de bolo de chocolate"</em>. A IA bloqueará o assunto instantaneamente com a frase de segurança.
                  </div>
                </div>

                {/* Quick Prompts Hub */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    Dúvidas Frequentes para Testar:
                  </span>
                  <div className="space-y-2">
                    {[
                      { text: "Diferença entre energia solar e carvão.", label: "Comparação Direta" },
                      { text: "Vantagens e desvantagens da energia nuclear.", label: "Fissão Nuclear" },
                      { text: "Me dê uma receita de bolo de chocolate.", label: "Teste o Guardrail" }
                    ].map((p, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleQuickPrompt(p.text)}
                        className="w-full text-left p-2.5 rounded-lg border border-slate-100 bg-slate-50 hover:bg-sky-50 hover:text-sky-950 text-xs text-slate-700 transition-all flex items-center justify-between cursor-pointer group"
                      >
                        <span className="truncate pr-2 font-light">{p.text}</span>
                        <span className="text-[9px] uppercase tracking-wider font-mono font-bold text-slate-400 group-hover:text-sky-700 transition-colors shrink-0">
                          {p.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Right Column: Dynamic AI Console (8 Columns) */}
              <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden flex flex-col h-[650px] shadow-2xl relative">
                
                {/* Control Panel Status Topbar */}
                <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between z-10">
                  <div className="flex items-center gap-2">
                    <div className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                    </div>
                    <span className="text-[11px] font-mono text-emerald-400 font-bold tracking-widest uppercase">
                      CONSOLE DE EXECUÇÃO NEURAL GEMINI
                    </span>
                  </div>

                  <button 
                    onClick={() => setChatMessages([
                      {
                        id: 'welcome',
                        role: 'model',
                        text: 'Olá! Sou seu **Especialista em Matrizes Energéticas**. Pergunte-me qualquer dúvida sobre energias renováveis e não renováveis.'
                      }
                    ])}
                    className="text-[10px] font-mono text-slate-400 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> REINICIAR CONEXÃO
                  </button>
                </div>

                {/* Chat Message History Canvas */}
                <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-slate-950/80 custom-scrollbar animate-fade-in">
                  
                  {chatMessages.map((msg) => (
                    <div 
                      key={msg.id}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}
                    >
                      <div className={`max-w-[85%] rounded-2xl p-5 text-sm leading-relaxed ${
                        msg.role === 'user' 
                          ? 'bg-sky-600 text-white rounded-br-none shadow-lg shadow-sky-950/30 font-medium' 
                          : 'bg-slate-900/95 text-slate-100 border border-slate-800 rounded-bl-none shadow-xl'
                      }`}>
                        
                        {/* Avatar/Label header */}
                        <div className="flex items-center gap-1.5 mb-2.5 text-[10px] uppercase font-mono tracking-wider">
                          {msg.role === 'user' ? (
                            <>
                              <span className="text-sky-300">STUDENT // QUERY</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3 h-3 text-emerald-400 animate-pulse" />
                              <span className="text-emerald-400 font-bold">ENERGY SPECIALIST // MODEL RESPONSE</span>
                            </>
                          )}
                        </div>

                        {/* Message text with simplified Markdown bold renderer */}
                        <div className="whitespace-pre-line font-light text-slate-200">
                          {msg.text.split('\n').map((line, i) => {
                            let formattedLine = line;
                            const boldRegex = /\*\*(.*?)\*\*/g;
                            const matches = [...formattedLine.matchAll(boldRegex)];
                            
                            if (matches.length > 0) {
                              return (
                                <p key={i} className="mb-1.5 leading-relaxed">
                                  {formattedLine.split('**').map((part, pIdx) => {
                                    if (pIdx % 2 === 1) {
                                      return <strong key={pIdx} className="font-bold text-white border-b border-sky-500/20 pb-0.5">{part}</strong>;
                                    }
                                    return part;
                                  })}
                                </p>
                              );
                            }

                            return <p key={i} className="mb-1.5 leading-relaxed">{line}</p>;
                          })}
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Dynamic Reasoning Agent Step Loader (Real AI feeling) */}
                  {chatLoading && (
                    <div className="flex justify-start animate-pulse">
                      <div className="bg-slate-900 border border-slate-800 text-slate-300 rounded-2xl rounded-bl-none p-5 text-xs space-y-3 max-w-[80%] shadow-2xl">
                        
                        <div className="flex items-center gap-2 text-[10px] font-mono text-amber-400 tracking-wider">
                          <Cpu className="w-4 h-4 animate-spin" />
                          <span>RAZÃO E CONTROLE DE ALUCINAÇÃO</span>
                        </div>

                        <div className="space-y-1.5 font-mono text-[10px] text-slate-400">
                          <div className="flex items-center gap-1.5 text-emerald-400">
                            <Check className="w-3.5 h-3.5" /> Analisando parâmetros de entrada...
                          </div>
                          <div className="flex items-center gap-1.5 text-emerald-400">
                            <Check className="w-3.5 h-3.5" /> Verificando Guardrail contra conteúdo impróprio...
                          </div>
                          <div className="flex items-center gap-1.5 text-sky-400">
                            <span className="w-2 h-2 rounded-full bg-sky-500 animate-ping inline-block" />
                            Estruturando dados de energia com temperatura 0.2...
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" />
                          <span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                          <span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                          <span className="text-[10px] text-slate-500 ml-1">Processando resposta final de alta precisão...</span>
                        </div>

                      </div>
                    </div>
                  )}

                  <div ref={chatBottomRef} />
                </div>

                {/* Premium Console Chat Input Panel */}
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(chatInput);
                  }}
                  className="p-4 bg-slate-900 border-t border-slate-800 flex gap-3 relative z-10"
                >
                  <input 
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Digite sua pergunta ou peça: 'Gere exercícios de fixação para mim'..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-sky-500 focus:bg-slate-950 transition-all placeholder-slate-500"
                  />
                  <button 
                    type="submit"
                    disabled={!chatInput.trim() || chatLoading}
                    className="px-5 py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-colors disabled:opacity-40 cursor-pointer animate-fade-in"
                  >
                    <Send className="w-3.5 h-3.5" /> ENVIAR
                  </button>
                </form>

              </div>

            </div>

          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 mt-16 py-8 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-2">
          <p className="font-medium text-slate-600">TerraEnergia · Simulador Científico & Didático</p>
          <p>Feito para o Google AI Studio com instruções de sistema estritas e temperatura de 0.2.</p>
        </div>
      </footer>

    </div>
  );
}
