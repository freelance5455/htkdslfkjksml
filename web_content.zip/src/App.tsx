import React, { useState } from 'react';
import { GameProvider, useGame } from './context/GameContext';
import { AndroidFrame } from './components/AndroidFrame';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { BadgeModal } from './components/BadgeModal';
import { QuestMapScreen } from './components/screens/QuestMapScreen';
import { QuizScreen } from './components/screens/QuizScreen';
import { PlateBlitzScreen } from './components/screens/PlateBlitzScreen';
import { FoodLabScreen } from './components/screens/FoodLabScreen';
import { CodexScreen } from './components/screens/CodexScreen';
import { RewardsShopScreen } from './components/screens/RewardsShopScreen';
import { WifiOff } from 'lucide-react';

const GameContent: React.FC = () => {
  const { newBadgeUnlocked, clearNewBadge } = useGame();
  const [activeScreen, setActiveScreen] = useState<string>('quest_map');
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleStartQuiz = (group: string) => {
    setSelectedGroup(group);
    setActiveScreen('quiz');
  };

  const handleOpenCodex = (group: string) => {
    setSelectedGroup(group);
    setActiveScreen('codex');
  };

  return (
    <>
      {/* Offline Toast */}
      {!isOnline && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 rounded-full bg-amber-500 px-4 py-1.5 text-xs font-bold text-slate-950 shadow-xl border border-amber-300 animate-pulse">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode — Game and sound engine work 100% offline!</span>
        </div>
      )}

      {/* Main Android Frame */}
      <AndroidFrame
        activeScreen={activeScreen}
        onNavigate={(screen) => setActiveScreen(screen)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isPhoneFrame={isPhoneFrame}
        onToggleFrame={() => setIsPhoneFrame((prev) => !prev)}
      >
        {activeScreen === 'quest_map' && (
          <QuestMapScreen
            onStartQuiz={handleStartQuiz}
            onOpenCodex={handleOpenCodex}
            onOpenBlitz={() => setActiveScreen('blitz')}
            onOpenLab={() => setActiveScreen('lab')}
          />
        )}

        {activeScreen === 'quiz' && (
          <QuizScreen
            initialGroup={selectedGroup}
            onBackToMap={() => setActiveScreen('quest_map')}
          />
        )}

        {activeScreen === 'blitz' && (
          <PlateBlitzScreen onBackToMap={() => setActiveScreen('quest_map')} />
        )}

        {activeScreen === 'lab' && <FoodLabScreen />}

        {activeScreen === 'codex' && (
          <CodexScreen
            initialGroup={selectedGroup}
            onLaunchQuiz={(group) => {
              setSelectedGroup(group);
              setActiveScreen('quiz');
            }}
          />
        )}

        {activeScreen === 'shop' && <RewardsShopScreen />}
      </AndroidFrame>

      {/* APK Installation Options Modal */}
      <AndroidInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* Badge Unlock Celebration Modal */}
      <BadgeModal badge={newBadgeUnlocked} onClose={clearNewBadge} />
    </>
  );
};

export default function App() {
  return (
    <GameProvider>
      <GameContent />
    </GameProvider>
  );
}
