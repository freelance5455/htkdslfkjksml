/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useState } from 'react';
import { AddWorkerModal } from './components/AddWorkerModal';
import { AttendanceRegister } from './components/AttendanceRegister';
import { BulkImportModal } from './components/BulkImportModal';
import { DepartmentModal } from './components/DepartmentModal';
import { HomeDashboard } from './components/HomeDashboard';
import type { AppState, AttendanceMark, Department, ShiftType, Worker } from './types/attendance';
import {
  computeGlobalOverview,
  getTodayDateString,
  loadState,
  mergeWorkers,
  removeWorkerFromDepartment,
  saveState,
  submitDepartmentAttendance,
  toggleWorkerAttendance,
} from './utils/attendanceLogic';

export default function App() {
  const [state, setState] = useState<AppState>(() => loadState());
  const [activeDepartmentId, setActiveDepartmentId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(() => getTodayDateString());
  const [selectedShift, setSelectedShift] = useState<ShiftType>('day');

  // Modal states
  const [isDeptModalOpen, setIsDeptModalOpen] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState<Department | null>(null);
  const [isAddWorkerOpen, setIsAddWorkerOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  const todayDate = getTodayDateString();

  useEffect(() => {
    saveState(state);
  }, [state]);

  const overview = useMemo(
    () => computeGlobalOverview(state, todayDate, selectedShift),
    [state, todayDate, selectedShift],
  );

  const activeDepartment = useMemo(
    () => state.departments.find((d) => d.id === activeDepartmentId) ?? null,
    [state.departments, activeDepartmentId],
  );

  const handleSaveDepartment = ({ name, supervisor }: { name: string; supervisor: string }) => {
    if (editingDepartment) {
      setState((prev) => ({
        ...prev,
        departments: prev.departments.map((d) =>
          d.id === editingDepartment.id ? { ...d, name, supervisor } : d,
        ),
      }));
    } else {
      const newDept: Department = {
        id: `dept-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        name,
        supervisor,
        workers: [],
        attendanceByDate: {},
      };
      setState((prev) => ({
        ...prev,
        departments: [...prev.departments, newDept],
      }));
    }
  };

  const handleToggleMark = (workerId: string, mark: AttendanceMark) => {
    if (!activeDepartment) return;
    setState((prev) => ({
      ...prev,
      departments: prev.departments.map((dept) =>
        dept.id === activeDepartment.id
          ? toggleWorkerAttendance(dept, selectedDate, workerId, mark, selectedShift)
          : dept,
      ),
    }));
  };

  const handleSubmitAttendance = () => {
    if (!activeDepartment) return;
    setState((prev) => ({
      ...prev,
      departments: prev.departments.map((dept) =>
        dept.id === activeDepartment.id
          ? submitDepartmentAttendance(dept, selectedDate, new Date().toISOString(), selectedShift)
          : dept,
      ),
    }));
  };

  const handleAddWorker = (worker: Worker) => {
    if (!activeDepartment) return;
    setState((prev) => ({
      ...prev,
      departments: prev.departments.map((dept) =>
        dept.id === activeDepartment.id
          ? {
              ...dept,
              workers: [...dept.workers, worker],
            }
          : dept,
      ),
    }));
  };

  const handleBulkImportWorkers = (workers: Worker[], mode: 'append' | 'replace') => {
    if (!activeDepartment) return;
    setState((prev) => ({
      ...prev,
      departments: prev.departments.map((dept) =>
        dept.id === activeDepartment.id
          ? {
              ...dept,
              workers: mergeWorkers(dept.workers, workers, mode),
            }
          : dept,
      ),
    }));
  };

  const handleDeleteWorker = (workerId: string) => {
    if (!activeDepartment) return;
    setState((prev) => ({
      ...prev,
      departments: prev.departments.map((dept) =>
        dept.id === activeDepartment.id
          ? removeWorkerFromDepartment(dept, workerId)
          : dept,
      ),
    }));
  };

  return (
    <>
      {activeDepartment ? (
        <AttendanceRegister
          department={activeDepartment}
          selectedDate={selectedDate}
          selectedShift={selectedShift}
          onChangeDate={setSelectedDate}
          onChangeShift={setSelectedShift}
          onBack={() => setActiveDepartmentId(null)}
          onToggleMark={handleToggleMark}
          onSubmitAttendance={handleSubmitAttendance}
          onOpenAddWorker={() => setIsAddWorkerOpen(true)}
          onOpenBulkImport={() => setIsBulkImportOpen(true)}
          onDeleteWorker={handleDeleteWorker}
        />
      ) : (
        <HomeDashboard
          departments={state.departments}
          overview={overview}
          todayDate={todayDate}
          selectedShift={selectedShift}
          onChangeShift={setSelectedShift}
          onSelectDepartment={(deptId) => {
            setSelectedDate(getTodayDateString());
            setActiveDepartmentId(deptId);
          }}
          onOpenAddDepartment={() => {
            setEditingDepartment(null);
            setIsDeptModalOpen(true);
          }}
          onOpenEditDepartment={(dept) => {
            setEditingDepartment(dept);
            setIsDeptModalOpen(true);
          }}
        />
      )}

      <DepartmentModal
        isOpen={isDeptModalOpen}
        editingDepartment={editingDepartment}
        onClose={() => {
          setIsDeptModalOpen(false);
          setEditingDepartment(null);
        }}
        onSave={handleSaveDepartment}
      />

      {activeDepartment && (
        <>
          <AddWorkerModal
            isOpen={isAddWorkerOpen}
            existingWorkers={activeDepartment.workers}
            onClose={() => setIsAddWorkerOpen(false)}
            onAdd={handleAddWorker}
          />
          <BulkImportModal
            isOpen={isBulkImportOpen}
            onClose={() => setIsBulkImportOpen(false)}
            onImport={handleBulkImportWorkers}
          />
        </>
      )}
    </>
  );
}
