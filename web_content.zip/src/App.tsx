import React, { useState, useEffect, useCallback, useRef } from "react";
import { GameCanvas } from "./components/GameCanvas";
import { HUD } from "./components/HUD";
import { Hotbar } from "./components/Hotbar";
import { CraftingMenu } from "./components/CraftingMenu";
import { ShopModal } from "./components/ShopModal";
import { BioscienceJournalModal } from "./components/BioscienceJournalModal";
import { HelpModal } from "./components/HelpModal";
import { LandModal } from "./components/LandModal";
import { UiCustomizeModal } from "./components/UiCustomizeModal";
import { TouchControls } from "./components/TouchControls";
import { BackpackModal } from "./components/BackpackModal";
import { SettingsModal } from "./components/SettingsModal";
import { generateWorld, GameWorldData } from "./game/world";
import {
  INITIAL_HOTBAR_ITEMS,
  INITIAL_ACHIEVEMENTS,
  ROADMAP_STAGES,
  DAY_DURATION_SECONDS,
  SEASONS_DATA,
} from "./game/constants";
import {
  Item,
  Recipe,
  GroundDrop,
  Tree,
  FarmTile,
  Player,
  Dog,
  WeatherType,
  SeasonType,
  LandPlot,
  Achievement,
  RoadmapStage,
  GameStats,
  UiCustomizationSettings,
  CampfireData,
  BuildingStructure,
  MonsterDog,
} from "./types";
import { sound } from "./audio";

export default function App() {
  // Game World State
  const [worldData, setWorldData] = useState<GameWorldData>(() => {
    const generated = generateWorld();
    generated.player = {
      ...generated.player,
      z: 0,
      vz: 0,
      isJumping: false,
      isSprinting: false,
      stamina: 100,
      maxStamina: 100,
      walkFrame: 0,
      handAnim: 0,
    };
    return generated;
  });

  // Hotbar (7 slots) & Backpack Inventory (24 slots)
  const [hotbar, setHotbar] = useState<Item[]>(() => [...INITIAL_HOTBAR_ITEMS]);
  const [activeSlot, setActiveSlot] = useState<number>(0);
  const [backpack, setBackpack] = useState<Item[]>(() => [
    ...INITIAL_HOTBAR_ITEMS,
    {
      id: "wood_log",
      name: "Seasoned Wood Logs",
      bengaliName: "শুকনো কাঠের গুঁড়ি",
      type: "resource",
      description: "Wood timber for crafting tools and repairing village fences.",
      icon: "🪵",
      count: 6,
      value: 10,
    },
    {
      id: "bio_fertilizer",
      name: "Organic Taro Compost Fertilizer",
      bengaliName: "জৈব কচু কম্পোস্ট সার",
      type: "consumable",
      description: "Enriched organic compost. Accelerates crop growth by 150%.",
      icon: "🧪",
      count: 4,
      value: 22,
    },
    {
      id: "dog_treat",
      name: "Mustakim's Artisan Dog Biscuits",
      bengaliName: "মুস্তাকিমের স্পেশাল বিস্কুট",
      type: "consumable",
      description: "Delicious pet treat. Turns the fearful black dog into Tojo's loyal companion!",
      icon: "🦴",
      count: 3,
      value: 20,
    },
  ]);

  // Time, Day & Season Cycle
  const [gameTimeSeconds, setGameTimeSeconds] = useState<number>(0);
  const [weather, setWeather] = useState<WeatherType>("clear");
  const [season, setSeason] = useState<SeasonType>("spring");
  // Developer Mustakim stays permanently!
  const mustakimArrived = true;
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [nearDog, setNearDog] = useState<boolean>(false);
  const [inDeepKochubon, setInDeepKochubon] = useState<boolean>(false);
  const [inCampfireZone, setInCampfireZone] = useState<boolean>(true);

  // Landscape Mode Viewport Detection
  const [isLandscape, setIsLandscape] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth > window.innerHeight;
    }
    return true;
  });

  useEffect(() => {
    const handleOrientationChange = () => {
      setIsLandscape(window.innerWidth > window.innerHeight);
    };
    window.addEventListener("resize", handleOrientationChange);
    window.addEventListener("orientationchange", handleOrientationChange);
    return () => {
      window.removeEventListener("resize", handleOrientationChange);
      window.removeEventListener("orientationchange", handleOrientationChange);
    };
  }, []);

  // UI Customization Settings
  const [uiSettings, setUiSettings] = useState<UiCustomizationSettings>(() => ({
    hudScale: "compact",
    hotbarScale: "compact",
    controllerSize: "small",
    controllerOpacity: 0.85,
    showDpad: true,
    autoLandscapeSmall: true,
    showHandButton: true,
    showSprintButton: true,
    showJumpButton: true,
    isMinimalMode: false,
  }));

  // Real-time 60 FPS counter
  const [fps, setFps] = useState<number>(60);

  // Toggle Minimalist Mode
  const toggleMinimalMode = useCallback(() => {
    setUiSettings((s) => ({ ...s, isMinimalMode: !s.isMinimalMode }));
  }, []);

  // Stats, Achievements & Roadmap
  const [gameStats, setGameStats] = useState<GameStats>({
    treesCut: 0,
    daysSurvived: 1,
    cropsHarvested: 0,
    dogsBefriended: 0,
    landBought: 0,
    toolsCrafted: 0,
    treasuresDug: 0,
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => [
    ...INITIAL_ACHIEVEMENTS,
  ]);

  const [roadmapStages, setRoadmapStages] = useState<RoadmapStage[]>(() => [
    ...ROADMAP_STAGES,
  ]);

  // Modals
  const [isBackpackOpen, setIsBackpackOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isCraftingOpen, setIsCraftingOpen] = useState<boolean>(false);
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [isScienceOpen, setIsScienceOpen] = useState<boolean>(false);
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isLandOpen, setIsLandOpen] = useState<boolean>(false);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState<boolean>(false);
  const [helpDefaultTab, setHelpDefaultTab] = useState<"roadmap" | "awards" | "guide">("roadmap");

  // Notifications
  const [notification, setNotification] = useState<{
    text: string;
    subtext?: string;
  } | null>(null);

  // Fullscreen Toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement
        .requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(() => {});
    } else {
      document
        .exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(() => {});
    }
  };

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === "INPUT" ||
        document.activeElement?.tagName === "TEXTAREA"
      ) {
        return;
      }

      const key = e.key.toLowerCase();
      if (key === "t") {
        handleDogSit();
      } else if (key === "b") {
        setIsBackpackOpen((prev) => !prev);
      } else if (key === "c") {
        setIsCraftingOpen((prev) => !prev);
      } else if (key === "o") {
        setIsSettingsOpen((prev) => !prev);
      } else if (key === "h") {
        setHelpDefaultTab("roadmap");
        setIsHelpOpen((prev) => !prev);
      } else if (key === "l") {
        setIsLandOpen((prev) => !prev);
      } else if (key === "j") {
        setIsScienceOpen((prev) => !prev);
      } else if (key === "m") {
        toggleMinimalMode();
      } else if (key === "f") {
        toggleFullscreen();
      } else if (e.key === "Escape") {
        if (
          isBackpackOpen ||
          isSettingsOpen ||
          isCraftingOpen ||
          isShopOpen ||
          isScienceOpen ||
          isHelpOpen ||
          isLandOpen ||
          isCustomizeOpen
        ) {
          setIsBackpackOpen(false);
          setIsSettingsOpen(false);
          setIsCraftingOpen(false);
          setIsShopOpen(false);
          setIsScienceOpen(false);
          setIsHelpOpen(false);
          setIsLandOpen(false);
          setIsCustomizeOpen(false);
        } else {
          setIsSettingsOpen(true);
        }
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [
    isBackpackOpen,
    isSettingsOpen,
    isCraftingOpen,
    isShopOpen,
    isScienceOpen,
    isHelpOpen,
    isLandOpen,
    isCustomizeOpen,
    toggleMinimalMode,
  ]);

  // Day calculations
  const gameDay = Math.floor(gameTimeSeconds / DAY_DURATION_SECONDS) + 1;
  const dayTimeProgress = (gameTimeSeconds % DAY_DURATION_SECONDS) / DAY_DURATION_SECONDS;

  // Four-Season Cycle: changes every 3 in-game days
  useEffect(() => {
    const seasonsList: SeasonType[] = ["spring", "summer", "monsoon", "winter"];
    const seasonIndex = Math.floor((gameDay - 1) / 3) % seasonsList.length;
    const nextSeason = seasonsList[seasonIndex];
    if (nextSeason !== season) {
      setSeason(nextSeason);
      sound.playMustakimBell();
      setNotification({
        text: `🍂 নতুন ঋতু আগমন: ${SEASONS_DATA[nextSeason].bengaliName}!`,
        subtext: SEASONS_DATA[nextSeason].description,
      });
      setTimeout(() => setNotification(null), 5000);
    }
  }, [gameDay, season]);

  // Weather Engine
  useEffect(() => {
    const weatherInterval = setInterval(() => {
      const seasonChances = SEASONS_DATA[season].weatherChance;
      const rand = Math.random();

      let nextWeather: WeatherType = "clear";
      if (rand < seasonChances.rain) {
        nextWeather = "rain";
      } else if (rand < seasonChances.rain + seasonChances.fog) {
        nextWeather = "fog";
      } else {
        nextWeather = "clear";
      }

      setWeather(nextWeather);
      if (nextWeather === "rain") {
        sound.playWater();
        setNotification({
          text: "🌧️ বৃষ্টি শুরু হয়েছে!",
          subtext: "কচুবনের সকল চাষের জমি স্বয়ংক্রিয় সিক্ত হচ্ছে।",
        });
        setTimeout(() => setNotification(null), 4000);
      } else if (nextWeather === "fog") {
        setNotification({
          text: "🌫️ ঘন কুয়াশা নেমে এসেছে...",
          subtext: "দৃষ্টিসীমা হ্রাস পেয়েছে, সাবধানে চলাচল করুন।",
        });
        setTimeout(() => setNotification(null), 4000);
      }
    }, 45000);

    return () => clearInterval(weatherInterval);
  }, [season]);

  // Timer Tick
  useEffect(() => {
    const interval = setInterval(() => {
      setGameTimeSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    setGameStats((prev) => {
      if (gameDay > prev.daysSurvived) {
        return { ...prev, daysSurvived: gameDay };
      }
      return prev;
    });
  }, [gameDay]);

  // Update and evaluate Achievements
  useEffect(() => {
    setAchievements((prev) =>
      prev.map((ach) => {
        let current = ach.currentCount;
        if (ach.id === "ach_trees_10" || ach.id === "ach_trees_100") {
          current = gameStats.treesCut;
        } else if (ach.id === "ach_survive_5" || ach.id === "ach_survive_10") {
          current = gameStats.daysSurvived;
        } else if (ach.id === "ach_crops_50") {
          current = gameStats.cropsHarvested;
        } else if (ach.id === "ach_befriend_dogs") {
          current = gameStats.dogsBefriended;
        } else if (ach.id === "ach_buy_land") {
          current = gameStats.landBought;
        }

        const isUnlocked = current >= ach.targetCount;
        if (isUnlocked && !ach.isUnlocked) {
          sound.playHarvest();
          setNotification({
            text: `🏆 মাইলফলক অর্জিত: ${ach.bengaliTitle}!`,
            subtext: `পুরস্কার দাবি করতে [রোডম্যাপ] ট্যাবে যান (+${ach.rewardCoins} Tk)।`,
          });
          setTimeout(() => setNotification(null), 5000);
        }

        return {
          ...ach,
          currentCount: current,
          isUnlocked,
        };
      })
    );
  }, [gameStats]);

  // Evaluate Roadmap Progression
  useEffect(() => {
    setRoadmapStages((prev) =>
      prev.map((stage, idx) => {
        let current = 0;
        if (stage.id === "roadmap_stage_1") current = gameStats.daysSurvived;
        else if (stage.id === "roadmap_stage_2") current = gameStats.dogsBefriended;
        else if (stage.id === "roadmap_stage_3") current = gameStats.treesCut;
        else if (stage.id === "roadmap_stage_4") current = gameStats.cropsHarvested;
        else if (stage.id === "roadmap_stage_5") current = gameStats.landBought;
        else if (stage.id === "roadmap_stage_6") current = gameStats.daysSurvived;

        const isUnlocked = idx === 0 || prev[idx - 1]?.isCompleted;
        const reachedTarget = current >= stage.targetValue;

        return {
          ...stage,
          currentValue: current,
          isUnlocked,
          isCompleted: stage.isCompleted || (reachedTarget && stage.isCompleted),
        };
      })
    );
  }, [gameStats]);

  const handleToggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    sound.isMuted = nextMute;
  };

  const handleTreeCutCount = useCallback(() => {
    setGameStats((prev) => ({ ...prev, treesCut: prev.treesCut + 1 }));
  }, []);

  const handleBefriendDog = useCallback((_dogId: string) => {
    setGameStats((prev) => ({
      ...prev,
      dogsBefriended: Math.min(3, prev.dogsBefriended + 1),
    }));
  }, []);

  // Jump trigger
  const handleJump = useCallback(() => {
    setWorldData((prev) => {
      if (prev.player.isJumping) return prev;
      sound.playJump();
      return {
        ...prev,
        player: {
          ...prev.player,
          isJumping: true,
          vz: 135,
          z: 2,
        },
      };
    });
  }, []);

  // Sprint toggle
  const handleSprintToggle = useCallback(() => {
    setWorldData((prev) => {
      const nextSprint = !prev.player.isSprinting;
      return {
        ...prev,
        player: {
          ...prev.player,
          isSprinting: nextSprint,
        },
      };
    });
  }, []);

  // Collect Item Drop (Adds to Hotbar or Backpack)
  const handleCollectDrop = useCallback((drop: GroundDrop) => {
    setWorldData((prev) => ({
      ...prev,
      groundDrops: prev.groundDrops.filter((d) => d.id !== drop.id),
    }));

    if (drop.item.id.startsWith("crop_")) {
      setGameStats((prev) => ({
        ...prev,
        cropsHarvested: prev.cropsHarvested + drop.item.count,
      }));
    } else if (drop.item.id === "dog_gift_coin") {
      setGameStats((prev) => ({
        ...prev,
        treasuresDug: prev.treasuresDug + 1,
      }));
    }

    // Add to Hotbar if slot available
    setHotbar((prevHotbar) => {
      const existingIdx = prevHotbar.findIndex((item) => item && item.id === drop.item.id);
      if (existingIdx !== -1) {
        const copy = [...prevHotbar];
        copy[existingIdx] = {
          ...copy[existingIdx],
          count: copy[existingIdx].count + drop.item.count,
        };
        return copy;
      }

      const emptyIdx = prevHotbar.findIndex((item) => !item);
      if (emptyIdx !== -1 && emptyIdx < 7) {
        const copy = [...prevHotbar];
        copy[emptyIdx] = drop.item;
        return copy;
      }

      if (prevHotbar.length < 7) {
        return [...prevHotbar, drop.item];
      }
      return prevHotbar;
    });

    // Also stack or store into Backpack
    setBackpack((prevBackpack) => {
      const bIdx = prevBackpack.findIndex((item) => item.id === drop.item.id);
      if (bIdx !== -1) {
        const copy = [...prevBackpack];
        copy[bIdx] = {
          ...copy[bIdx],
          count: copy[bIdx].count + drop.item.count,
        };
        return copy;
      }
      return [...prevBackpack, drop.item];
    });
  }, []);

  // Equip Item from Backpack into Hotbar Slot (1-7)
  const handleEquipToHotbar = useCallback((item: Item, slotIndex: number) => {
    if (slotIndex < 0 || slotIndex >= 7) return;

    setHotbar((prevHotbar) => {
      const copy = [...prevHotbar];
      while (copy.length <= slotIndex) {
        copy.push(INITIAL_HOTBAR_ITEMS[0]);
      }
      copy[slotIndex] = { ...item };
      return copy;
    });

    setNotification({
      text: `🎒 হটবার স্লট #${slotIndex + 1}-এ রাখা হয়েছে:`,
      subtext: `${item.icon} ${item.bengaliName}`,
    });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  // Use Consumable from Backpack
  const handleUseBackpackItem = useCallback((item: Item) => {
    sound.playHarvest();

    if (item.id === "energy_tonic") {
      setWorldData((prev) => ({
        ...prev,
        player: {
          ...prev.player,
          speed: prev.player.speed * 1.25,
          isSprinting: true,
        },
      }));
      setNotification({
        text: "⚡ মুস্তাকিমের স্পিড টনিক পান করেছেন!",
        subtext: "তোজোর গতি +২৫% বৃদ্ধি পেয়েছে!",
      });
    } else if (item.id.includes("dog")) {
      // Feed nearby dog
      setWorldData((prev) => {
        let fedAny = false;
        const nextDogs = prev.dogs.map((d) => {
          const dist = Math.hypot(d.x - prev.player.x, d.y - prev.player.y);
          if (dist < 180 && !fedAny) {
            fedAny = true;
            return {
              ...d,
              state: "pet" as const,
              fearLevel: 0,
              loyalty: 100,
              isFriend: true,
              speechBubble: "ঘেউ! সুস্বাদু ট্রিট!",
              bubbleTimer: 4,
            };
          }
          return d;
        });
        if (fedAny) {
          sound.playDogHappyBark();
          setGameStats((s) => ({ ...s, dogsBefriended: Math.min(3, s.dogsBefriended + 1) }));
        }
        return { ...prev, dogs: nextDogs };
      });
      setNotification({
        text: "🦴 কুকুরকে খাবার দেওয়া হয়েছে!",
        subtext: "কুকুরটির ভরসা ও আনন্দ শতভাগ পূর্ণ হয়েছে।",
      });
    } else if (item.id === "bio_fertilizer") {
      setWorldData((prev) => {
        const nextFarm = new Map(prev.farmTiles);
        nextFarm.forEach((tile, key) => {
          if (tile.cropType && tile.growthStage < 4) {
            tile.growthStage = Math.min(4, tile.growthStage + 2);
          }
        });
        return { ...prev, farmTiles: nextFarm };
      });
      setNotification({
        text: "🧪 জৈব সার প্রয়োগ করা হয়েছে!",
        subtext: "সকল ফসলের বৃদ্ধি দ্রুত তরান্বিত হয়েছে।",
      });
    }

    // Deduct count
    setBackpack((prev) =>
      prev
        .map((i) => (i.id === item.id ? { ...i, count: i.count - 1 } : i))
        .filter((i) => i.count > 0 || i.type === "tool")
    );
    setHotbar((prev) =>
      prev
        .map((i) => (i.id === item.id ? { ...i, count: i.count - 1 } : i))
        .filter((i) => i.count > 0 || i.type === "tool")
    );
    setTimeout(() => setNotification(null), 3500);
  }, []);

  // Drop item from backpack to ground
  const handleDropItem = useCallback((item: Item) => {
    sound.playLand();
    const p = worldData.player;
    const newDrop: GroundDrop = {
      id: `drop_${Date.now()}`,
      x: p.x + (p.facing === "right" ? 36 : p.facing === "left" ? -36 : 0),
      y: p.y + (p.facing === "down" ? 36 : p.facing === "up" ? -36 : 0),
      item: { ...item, count: 1 },
      lifespan: 9999,
    };

    setWorldData((prev) => ({
      ...prev,
      groundDrops: [...prev.groundDrops, newDrop],
    }));

    setBackpack((prev) =>
      prev
        .map((i) => (i.id === item.id ? { ...i, count: i.count - 1 } : i))
        .filter((i) => i.count > 0 || i.type === "tool")
    );
  }, [worldData.player]);

  // Handle Buy Land Plot
  const handleBuyLandPlot = useCallback((plot: LandPlot) => {
    if (worldData.player.coins < plot.cost) {
      sound.playDogWhimper();
      setNotification({
        text: "❌ পর্যাপ্ত টাকা নেই!",
        subtext: `এই জমি কেনার জন্য ${plot.cost} Tk প্রয়োজন।`,
      });
      setTimeout(() => setNotification(null), 3000);
      return;
    }

    sound.playHarvest();
    setWorldData((prev) => {
      const nextTiles = prev.tiles.map((row) => [...row]);

      if (plot.id === "land_north_marsh") {
        for (let c = 0; c <= 24; c++) {
          if (nextTiles[7][c] === "fence") nextTiles[7][c] = "grass";
        }
      } else if (plot.id === "land_south_woods") {
        for (let c = 0; c <= 30; c++) {
          if (nextTiles[24][c] === "fence") nextTiles[24][c] = "grass";
        }
      }

      const nextPlots = prev.landPlots.map((p) =>
        p.id === plot.id ? { ...p, isUnlocked: true } : p
      );

      return {
        ...prev,
        tiles: nextTiles,
        landPlots: nextPlots,
        player: {
          ...prev.player,
          coins: prev.player.coins - plot.cost,
        },
      };
    });

    setGameStats((prev) => ({ ...prev, landBought: prev.landBought + 1 }));

    setNotification({
      text: `🎉 নতুন জমি কেনা সম্পন্ন: ${plot.bengaliName}!`,
      subtext: "সীমানা প্রাচীর খুলে গেছে! তোজো ও কুকুরগুলো এখন সেখানে যেতে পারবে।",
    });
    setTimeout(() => setNotification(null), 5000);
    setIsLandOpen(false);
  }, [worldData.player.coins]);

  // Claim Achievement Reward
  const handleClaimAchievement = (achId: string) => {
    const ach = achievements.find((a) => a.id === achId);
    if (!ach || !ach.isUnlocked || ach.isClaimed) return;

    sound.playCoin();
    setWorldData((prev) => ({
      ...prev,
      player: {
        ...prev.player,
        coins: prev.player.coins + ach.rewardCoins,
      },
    }));

    setAchievements((prev) =>
      prev.map((a) => (a.id === achId ? { ...a, isClaimed: true } : a))
    );

    setNotification({
      text: `🎁 পুরস্কৃত হয়েছেন: +${ach.rewardCoins} Tk!`,
      subtext: ach.bengaliTitle,
    });
    setTimeout(() => setNotification(null), 3500);
  };

  // Claim Roadmap Stage
  const handleClaimRoadmapStage = (stageId: string) => {
    const stage = roadmapStages.find((s) => s.id === stageId);
    if (!stage || stage.isCompleted) return;

    sound.playHarvest();
    setWorldData((prev) => ({
      ...prev,
      player: {
        ...prev.player,
        coins: prev.player.coins + stage.rewardCoins,
      },
    }));

    setRoadmapStages((prev) =>
      prev.map((s) => (s.id === stageId ? { ...s, isCompleted: true } : s))
    );

    setNotification({
      text: `👑 রোডম্যাপ লক্ষ্য সম্পন্ন: +${stage.rewardCoins} Tk!`,
      subtext: `${stage.bengaliTitle} • ${stage.unlockedPerk}`,
    });
    setTimeout(() => setNotification(null), 4500);
  };

  // Crafting Recipe Handler
  const handleCraftRecipe = useCallback((recipe: Recipe) => {
    setHotbar((prevHotbar) => {
      let updated = [...prevHotbar];
      recipe.ingredients.forEach((ing) => {
        let remaining = ing.count;
        updated = updated.map((item) => {
          if (item && item.id === ing.itemId && remaining > 0) {
            const deduct = Math.min(item.count, remaining);
            remaining -= deduct;
            return { ...item, count: item.count - deduct };
          }
          return item;
        });
      });
      updated = updated.filter((i) => i.count > 0 || i.type === "tool");

      if (recipe.category === "tools") {
        const oldToolIdx = updated.findIndex((i) =>
          recipe.resultItem.id.startsWith("stick")
            ? i.id.startsWith("stick")
            : i.id.startsWith("axe")
        );
        if (oldToolIdx !== -1) {
          updated[oldToolIdx] = recipe.resultItem;
        } else {
          updated.push(recipe.resultItem);
        }
      } else {
        const existingIdx = updated.findIndex((i) => i.id === recipe.resultItem.id);
        if (existingIdx !== -1) {
          updated[existingIdx] = {
            ...updated[existingIdx],
            count: updated[existingIdx].count + recipe.resultItem.count,
          };
        } else {
          updated.push(recipe.resultItem);
        }
      }
      return updated;
    });

    // Also add to backpack
    setBackpack((prevBackpack) => {
      const existingIdx = prevBackpack.findIndex((i) => i.id === recipe.resultItem.id);
      if (existingIdx !== -1) {
        const copy = [...prevBackpack];
        copy[existingIdx] = {
          ...copy[existingIdx],
          count: copy[existingIdx].count + recipe.resultItem.count,
        };
        return copy;
      }
      return [...prevBackpack, recipe.resultItem];
    });

    setGameStats((prev) => ({ ...prev, toolsCrafted: prev.toolsCrafted + 1 }));

    setNotification({
      text: `✨ তৈরি হয়েছে: ${recipe.bengaliName}!`,
      subtext: recipe.description,
    });
    setTimeout(() => setNotification(null), 3500);
  }, []);

  // Handle Shop Buy (From Mustakim Developer Store)
  const handleBuyItem = useCallback((item: Item, cost: number) => {
    setWorldData((prev) => ({
      ...prev,
      player: {
        ...prev.player,
        coins: Math.max(0, prev.player.coins - cost),
      },
    }));

    // Add to Hotbar if slot available
    setHotbar((prevHotbar) => {
      const idx = prevHotbar.findIndex((i) => i.id === item.id);
      if (idx !== -1) {
        const copy = [...prevHotbar];
        copy[idx] = { ...copy[idx], count: copy[idx].count + (item.count || 1) };
        return copy;
      }
      if (prevHotbar.length < 7) {
        return [...prevHotbar, { ...item }];
      }
      return prevHotbar;
    });

    // Add to Backpack
    setBackpack((prevBackpack) => {
      const idx = prevBackpack.findIndex((i) => i.id === item.id);
      if (idx !== -1) {
        const copy = [...prevBackpack];
        copy[idx] = { ...copy[idx], count: copy[idx].count + (item.count || 1) };
        return copy;
      }
      return [...prevBackpack, { ...item }];
    });

    setNotification({
      text: `🛒 কেনা হয়েছে: ${item.bengaliName}!`,
      subtext: `-${cost} Tk খরচ হয়েছে (দেপলোপার মুস্তাকিমের দোকান)`,
    });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  // Handle Shop Sell
  const handleSellItem = useCallback((item: Item, count: number, earnings: number) => {
    setWorldData((prev) => ({
      ...prev,
      player: {
        ...prev.player,
        coins: prev.player.coins + earnings,
      },
    }));

    setHotbar((prevHotbar) => prevHotbar.filter((i) => i.id !== item.id));
    setBackpack((prevBackpack) => prevBackpack.filter((i) => i.id !== item.id));

    setNotification({
      text: `💰 বিক্রি সম্পন্ন: +${earnings} Tk!`,
      subtext: `${count} টি ${item.bengaliName} বিক্রি হয়েছে।`,
    });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  // Pet nearest dog
  const handlePetNearestDog = () => {
    window.dispatchEvent(new MouseEvent("click"));
  };

  // Dog Sit Command (Toggled via Sit button or T key)
  const handleDogSit = useCallback(() => {
    window.dispatchEvent(new CustomEvent("game-dog-sit"));
  }, []);

  // Updaters for Canvas
  const updatePlayer = useCallback((updater: (prev: Player) => Player) => {
    setWorldData((prev) => ({ ...prev, player: updater(prev.player) }));
  }, []);

  const updateCampfire = useCallback((updater: (prev: CampfireData) => CampfireData) => {
    setWorldData((prev) => ({
      ...prev,
      campfire: prev.campfire ? updater(prev.campfire) : prev.campfire,
    }));
  }, []);

  const updateStructures = useCallback(
    (updater: (prev: BuildingStructure[]) => BuildingStructure[]) => {
      setWorldData((prev) => ({
        ...prev,
        structures: updater(prev.structures || []),
      }));
    },
    []
  );

  // Dedicated Hand Quick Action
  const handleHandAction = useCallback(() => {
    const handIdx = hotbar.findIndex((item) => item.id === "hand_empty");
    if (handIdx !== -1 && activeSlot !== handIdx) {
      setActiveSlot(handIdx);
      updatePlayer((p) => ({ ...p, equippedSlot: handIdx }));
      sound.playHandWave();
    }
    window.dispatchEvent(new KeyboardEvent("keydown", { code: "Space", key: " " }));
  }, [hotbar, activeSlot, updatePlayer]);

  const updateDogs = useCallback((updater: (prev: Dog[]) => Dog[]) => {
    setWorldData((prev) => ({ ...prev, dogs: updater(prev.dogs) }));
  }, []);

  const updateTrees = useCallback((updater: (prev: Tree[]) => Tree[]) => {
    setWorldData((prev) => ({ ...prev, trees: updater(prev.trees) }));
  }, []);

  const updateFarmTiles = useCallback(
    (updater: (prev: Map<string, FarmTile>) => Map<string, FarmTile>) => {
      setWorldData((prev) => ({ ...prev, farmTiles: updater(prev.farmTiles) }));
    },
    []
  );

  const isHoldingHand = hotbar[activeSlot]?.id === "hand_empty";
  const isCompactHotbar =
    (uiSettings.autoLandscapeSmall && isLandscape) || uiSettings.hotbarScale === "compact";

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-stone-950 font-sans select-none flex flex-col justify-between">
      {/* Heads-up Display with Streamlined Clean Landscape layout */}
      <HUD
        player={worldData.player}
        gameDay={gameDay}
        dayTime={dayTimeProgress}
        weather={weather}
        season={season}
        settings={uiSettings}
        isLandscape={isLandscape}
        isHoldingHand={isHoldingHand}
        fps={fps}
        inDeepKochubon={inDeepKochubon}
        inCampfireZone={inCampfireZone}
        onOpenBackpack={() => setIsBackpackOpen(true)}
        onOpenCrafting={() => setIsCraftingOpen(true)}
        onOpenShop={() => setIsShopOpen(true)}
        onOpenAwards={() => {
          setHelpDefaultTab("roadmap");
          setIsHelpOpen(true);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Top Banner Notification */}
      {notification && !uiSettings.isMinimalMode && (
        <div className="absolute top-10 left-1/2 -translate-x-1/2 z-40 bg-stone-900/95 border border-amber-500 text-stone-100 px-3 py-1 rounded-xl shadow-2xl flex flex-col items-center gap-0.5 pointer-events-none max-w-xs sm:max-w-sm text-center">
          <span className="font-bold text-amber-300 font-['Hind_Siliguri'] text-xs">
            {notification.text}
          </span>
          {notification.subtext && (
            <span className="text-[10px] text-stone-300 font-['Hind_Siliguri']">
              {notification.subtext}
            </span>
          )}
        </div>
      )}

      {/* Fullscreen 2D Viewport */}
      <div className="flex-1 w-full h-full relative">
        <GameCanvas
          tiles={worldData.tiles}
          trees={worldData.trees}
          farmTiles={worldData.farmTiles}
          player={worldData.player}
          dogs={worldData.dogs}
          groundDrops={worldData.groundDrops}
          landPlots={worldData.landPlots}
          campfire={worldData.campfire}
          structures={worldData.structures}
          monster={worldData.monster}
          hotbar={hotbar}
          activeSlot={activeSlot}
          mustakimArrived={mustakimArrived}
          weather={weather}
          season={season}
          gameDay={gameDay}
          dayTime={dayTimeProgress}
          isMinimalMode={uiSettings.isMinimalMode}
          onUpdatePlayer={updatePlayer}
          onUpdateDogs={updateDogs}
          onUpdateTrees={updateTrees}
          onUpdateFarmTiles={updateFarmTiles}
          onUpdateCampfire={updateCampfire}
          onUpdateStructures={updateStructures}
          onCollectDrop={handleCollectDrop}
          onOpenShop={() => setIsShopOpen(true)}
          onOpenCrafting={() => setIsCraftingOpen(true)}
          onOpenScience={() => setIsScienceOpen(true)}
          onBuyLand={handleBuyLandPlot}
          onAddFloatingText={() => {}}
          onBefriendDog={handleBefriendDog}
          onTreeCutCount={handleTreeCutCount}
          onNearDogChange={(isNear) => setNearDog(isNear)}
          onZoneChange={(inDeep, inCamp) => {
            setInDeepKochubon(inDeep);
            setInCampfireZone(inCamp);
          }}
          onDogSit={handleDogSit}
          onFpsUpdate={setFps}
        />
      </div>

      {/* Hotbar in Bottom Center (7 slots) */}
      <Hotbar
        hotbar={hotbar}
        activeSlot={activeSlot}
        isCompact={isCompactHotbar || uiSettings.isMinimalMode}
        onSelectSlot={(slot) => {
          setActiveSlot(slot);
          updatePlayer((p) => ({ ...p, equippedSlot: slot }));
        }}
      />

      {/* Landscape Virtual Touch Controller */}
      <TouchControls
        isVisible={uiSettings.showDpad}
        settings={uiSettings}
        equippedToolIcon={hotbar[activeSlot]?.icon || "⚡"}
        isSprinting={worldData.player.isSprinting}
        isJumping={worldData.player.isJumping}
        isBareHand={isHoldingHand}
        nearDog={nearDog}
        onSprintToggle={handleSprintToggle}
        onJump={handleJump}
        onHandAction={handleHandAction}
        onPetDog={handlePetNearestDog}
        onDogSit={handleDogSit}
        onDirectionPress={(dir) => {
          window.dispatchEvent(
            new KeyboardEvent("keydown", {
              key: dir === "up" ? "w" : dir === "down" ? "s" : dir === "left" ? "a" : "d",
            })
          );
        }}
        onDirectionRelease={(dir) => {
          window.dispatchEvent(
            new KeyboardEvent("keyup", {
              key: dir === "up" ? "w" : dir === "down" ? "s" : dir === "left" ? "a" : "d",
            })
          );
        }}
        onAction={() => {
          window.dispatchEvent(new KeyboardEvent("keydown", { code: "Space", key: " " }));
        }}
      />

      {/* MODALS */}
      {/* 1. Full Backpack Inventory Modal [B] */}
      <BackpackModal
        isOpen={isBackpackOpen}
        onClose={() => setIsBackpackOpen(false)}
        inventory={backpack}
        hotbar={hotbar}
        activeSlot={activeSlot}
        onEquipToHotbar={handleEquipToHotbar}
        onUseItem={handleUseBackpackItem}
        onDropItem={handleDropItem}
      />

      {/* 2. Unified Settings Modal [O / Esc] */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={uiSettings}
        onUpdateSettings={setUiSettings}
        isLandscape={isLandscape}
        isFullscreen={isFullscreen}
        onToggleFullscreen={toggleFullscreen}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenLand={() => setIsLandOpen(true)}
        onOpenScience={() => setIsScienceOpen(true)}
        onOpenHelp={() => {
          setHelpDefaultTab("guide");
          setIsHelpOpen(true);
        }}
        onOpenAwards={() => {
          setHelpDefaultTab("roadmap");
          setIsHelpOpen(true);
        }}
      />

      {/* 3. Crafting Menu [C] */}
      <CraftingMenu
        isOpen={isCraftingOpen}
        onClose={() => setIsCraftingOpen(false)}
        inventory={backpack}
        onCraftRecipe={handleCraftRecipe}
      />

      {/* 4. Developer Mustakim Store (Permanent) */}
      <ShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        player={worldData.player}
        inventory={backpack}
        onBuyItem={handleBuyItem}
        onSellItem={handleSellItem}
      />

      {/* 5. Bioscience Journal [J] */}
      <BioscienceJournalModal
        isOpen={isScienceOpen}
        onClose={() => setIsScienceOpen(false)}
      />

      {/* 6. Roadmap & Awards Modal [H] */}
      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        achievements={achievements}
        roadmapStages={roadmapStages}
        onClaimAchievement={handleClaimAchievement}
        onClaimRoadmapStage={handleClaimRoadmapStage}
        defaultTab={helpDefaultTab}
      />

      {/* 7. Land Expansion Modal [L] */}
      <LandModal
        isOpen={isLandOpen}
        onClose={() => setIsLandOpen(false)}
        player={worldData.player}
        landPlots={worldData.landPlots}
        onBuyPlot={handleBuyLandPlot}
      />

      {/* 8. UI Customize Modal [U] */}
      <UiCustomizeModal
        isOpen={isCustomizeOpen}
        onClose={() => setIsCustomizeOpen(false)}
        settings={uiSettings}
        isLandscape={isLandscape}
        onUpdateSettings={setUiSettings}
      />
    </div>
  );
}
