import React, { useCallback, useEffect, useState } from 'react';
import {
  Bell,
  Code2,
  CreditCard,
  Crown,
  FolderCode,
  Hammer,
  LayoutDashboard,
  Menu,
  MonitorSmartphone,
  Moon,
  Settings,
  Shield,
  Smartphone,
  Sun,
  UserRound,
  X,
} from 'lucide-react';
import { AccountView } from './components/AccountView';
import { AdminCodeExplorer } from './components/AdminCodeExplorer';
import { AdminView } from './components/AdminView';
import { ApkSettingsView } from './components/ApkSettingsView';
import { AuthView } from './components/AuthView';
import { BrandLogo } from './components/BrandLogo';
import { BuildPipelineView } from './components/BuildPipelineView';
import { DashboardView } from './components/DashboardView';
import { LandingView } from './components/LandingView';
import { NotificationsView } from './components/NotificationsView';
import { PaymentHistoryView } from './components/PaymentHistoryView';
import { PreBuildModal } from './components/PreBuildModal';
import { PremiumView } from './components/PremiumView';
import { PreviewView } from './components/PreviewView';
import { ProjectsView } from './components/ProjectsView';
import { SettingsView } from './components/SettingsView';
import { UploadCreateModal } from './components/UploadCreateModal';
import {
  ApiError,
  apiRequest,
  downloadWithAuth,
  getStoredTheme,
  setAuthToken,
  setStoredTheme,
} from './lib/api';
import type {
  BuildJob,
  MembershipInfo,
  NavSection,
  PaymentProviderStatus,
  PaymentRecord,
  ProjectDetail,
  ProjectSummary,
  SubscriptionPlan,
  SystemCapabilities,
  SystemLimitsRow,
  ThemeMode,
  UserAccount,
} from './types/studio';

export default function App() {
  const [initializing, setInitializing] = useState(true);
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const initial = getStoredTheme();
    setStoredTheme(initial);
    return initial;
  });

  const [authScreen, setAuthScreen] = useState<'login' | 'register' | 'forgot' | null>(null);
  const [user, setUser] = useState<UserAccount | null>(null);
  const [membership, setMembership] = useState<MembershipInfo | null>(null);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  const [section, setSection] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectDetail | null>(null);

  const [builds, setBuilds] = useState<BuildJob[]>([]);
  const [activeBuild, setActiveBuild] = useState<BuildJob | null>(null);

  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [limits, setLimits] = useState<SystemLimitsRow[]>([]);
  const [paymentProvider, setPaymentProvider] = useState<PaymentProviderStatus | null>(null);
  const [capabilities, setCapabilities] = useState<SystemCapabilities | null>(null);

  const [uploadModalMode, setUploadModalMode] = useState<'html' | 'zip' | 'create' | null>(null);
  const [preBuildProject, setPreBuildProject] = useState<ProjectSummary | null>(null);
  const [upgradeNotice, setUpgradeNotice] = useState<string | null>(null);
  const [entrySelectPrompt, setEntrySelectPrompt] = useState<{
    projectId: string;
    htmlFiles: string[];
  } | null>(null);
  const [globalError, setGlobalError] = useState<string | null>(null);

  const applyTheme = useCallback((next: ThemeMode) => {
    setTheme(next);
    setStoredTheme(next);
  }, []);

  const handleToggleTheme = useCallback(() => {
    const next: ThemeMode = theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    if (user) {
      void apiRequest('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ themePref: next }),
      }).catch(() => undefined);
    }
  }, [theme, user, applyTheme]);

  const loadPublicMeta = useCallback(async () => {
    try {
      const [plansRes, capsRes] = await Promise.all([
        apiRequest<{
          plans: SubscriptionPlan[];
          limits: SystemLimitsRow[];
          paymentProvider: PaymentProviderStatus;
        }>('/api/plans'),
        apiRequest<{
          capabilities: SystemCapabilities;
          paymentProvider: PaymentProviderStatus;
        }>('/api/system/capabilities'),
      ]);
      setPlans(plansRes.plans);
      setLimits(plansRes.limits);
      setPaymentProvider(plansRes.paymentProvider);
      setCapabilities(capsRes.capabilities);
    } catch {
      // ignore initial meta error
    }
  }, []);

  const refreshProjectsAndBuilds = useCallback(async () => {
    const [projRes, buildRes] = await Promise.all([
      apiRequest<{ projects: ProjectSummary[] }>('/api/projects'),
      apiRequest<{ builds: BuildJob[] }>('/api/builds'),
    ]);
    setProjects(projRes.projects);
    setBuilds(buildRes.builds);
    setSelectedProjectId((prev) => {
      if (prev && projRes.projects.some((p) => p.id === prev)) return prev;
      return projRes.projects[0]?.id || null;
    });
  }, []);

  const refreshSelectedProject = useCallback(async (id: string) => {
    try {
      const res = await apiRequest<{ project: ProjectDetail }>(`/api/projects/${id}`);
      setSelectedProject(res.project);
    } catch {
      setSelectedProject(null);
    }
  }, []);

  const refreshMembership = useCallback(async () => {
    const me = await apiRequest<{
      user: UserAccount;
      membership: MembershipInfo;
      payments: PaymentRecord[];
      unreadNotifications?: number;
    }>('/api/auth/me');
    setUser(me.user);
    setMembership(me.membership);
    setPayments(me.payments || []);
    setUnreadNotifications(me.unreadNotifications || 0);
    if (me.user.themePref === 'light' || me.user.themePref === 'dark') {
      applyTheme(me.user.themePref);
    }
    await loadPublicMeta();
  }, [loadPublicMeta, applyTheme]);

  useEffect(() => {
    const boot = async () => {
      await loadPublicMeta();
      try {
        await refreshMembership();
        await refreshProjectsAndBuilds();
      } catch {
        setAuthToken(null);
      } finally {
        setInitializing(false);
      }
    };
    void boot();
  }, [loadPublicMeta, refreshMembership, refreshProjectsAndBuilds]);

  useEffect(() => {
    if (selectedProjectId && user) {
      void refreshSelectedProject(selectedProjectId);
    } else {
      setSelectedProject(null);
    }
  }, [selectedProjectId, user, refreshSelectedProject]);

  // Poll active build while queued or running
  useEffect(() => {
    if (!activeBuild) return;
    if (activeBuild.status !== 'queued' && activeBuild.status !== 'running') return;

    const timer = setInterval(async () => {
      try {
        const res = await apiRequest<{ build: BuildJob }>(
          `/api/build/${activeBuild.id}/status`
        );
        setActiveBuild(res.build);
        if (res.build.status !== 'queued' && res.build.status !== 'running') {
          await refreshProjectsAndBuilds();
          await refreshMembership();
        }
      } catch {
        // stop polling on error
      }
    }, 1200);

    return () => clearInterval(timer);
  }, [activeBuild, refreshProjectsAndBuilds, refreshMembership]);

  const handleAuthenticated = async (payload: {
    user: UserAccount;
    membership: MembershipInfo;
    payments: PaymentRecord[];
    unreadNotifications?: number;
  }) => {
    setUser(payload.user);
    setMembership(payload.membership);
    setPayments(payload.payments);
    setUnreadNotifications(payload.unreadNotifications || 0);
    if (payload.user.themePref === 'light' || payload.user.themePref === 'dark') {
      applyTheme(payload.user.themePref);
    }
    setAuthScreen(null);
    setSection('dashboard');
    await Promise.all([loadPublicMeta(), refreshProjectsAndBuilds()]);
  };

  const handleLogout = async () => {
    try {
      await apiRequest('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    setAuthToken(null);
    setUser(null);
    setMembership(null);
    setProjects([]);
    setBuilds([]);
    setSelectedProject(null);
    setSelectedProjectId(null);
    setActiveBuild(null);
    setUnreadNotifications(0);
    setAuthScreen(null);
  };

  const handleRequireUpgrade = (message: string) => {
    setUploadModalMode(null);
    setUpgradeNotice(message);
    setSection('premium');
  };

  const executeBuild = async (projectId: string) => {
    setGlobalError(null);
    try {
      const res = await apiRequest<{ buildId: string }>('/api/build', {
        method: 'POST',
        body: JSON.stringify({ projectId }),
      });
      const statusRes = await apiRequest<{ build: BuildJob }>(`/api/build/${res.buildId}/status`);
      setActiveBuild(statusRes.build);
      setPreBuildProject(null);
      setSection('build');
      await refreshProjectsAndBuilds();
      await refreshMembership();
    } catch (err) {
      if (err instanceof ApiError && err.upgradeRequired) {
        setPreBuildProject(null);
        handleRequireUpgrade(err.message);
        return;
      }
      setGlobalError(err instanceof Error ? err.message : 'Derleme başlatılamadı.');
    }
  };

  const openPreBuildModal = (projectOrId: string | ProjectSummary) => {
    const target =
      typeof projectOrId === 'string'
        ? projects.find((p) => p.id === projectOrId) ||
          (selectedProject && selectedProject.id === projectOrId ? selectedProject : null)
        : projectOrId;
    if (!target) {
      setUploadModalMode('create');
      return;
    }
    setSelectedProjectId(target.id);
    setPreBuildProject(target);
  };

  const handleSeedSampleApp = async () => {
    setGlobalError(null);
    try {
      const res = await apiRequest<{ project: ProjectDetail }>('/api/projects/seed-sample', {
        method: 'POST',
      });
      await refreshProjectsAndBuilds();
      await refreshMembership();
      setSelectedProjectId(res.project.id);
      setSelectedProject(res.project);
      setSection('preview');
    } catch (err) {
      if (err instanceof ApiError && err.upgradeRequired) {
        handleRequireUpgrade(err.message);
        return;
      }
      setGlobalError(err instanceof Error ? err.message : 'Örnek uygulama eklenemedi.');
    }
  };

  const handleCancelBuild = async (buildId: string) => {
    try {
      await apiRequest(`/api/build/${buildId}/cancel`, { method: 'POST' });
      const res = await apiRequest<{ build: BuildJob }>(`/api/build/${buildId}/status`);
      setActiveBuild(res.build);
      await refreshProjectsAndBuilds();
    } catch (err) {
      setGlobalError(err instanceof Error ? err.message : 'Derleme iptal edilemedi.');
    }
  };

  const handleDownloadBuild = async (buildId: string) => {
    try {
      await downloadWithAuth(`/api/build/${buildId}/download`, `android-build-${buildId}.apk`);
    } catch (err) {
      setGlobalError(err instanceof Error ? err.message : 'Dosya indirilemedi.');
    }
  };

  const handleInspectBuild = async (buildId: string) => {
    try {
      const res = await apiRequest<{ build: BuildJob }>(`/api/build/${buildId}/status`);
      setActiveBuild(res.build);
      setSection('build');
    } catch (err) {
      setGlobalError(err instanceof Error ? err.message : 'Derleme günlüğü yüklenemedi.');
    }
  };

  if (initializing) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#0B1020] text-slate-600 dark:text-[#94A3B8] flex items-center justify-center text-sm">
        HTML TO APK STUDIO başlatılıyor...
      </div>
    );
  }

  if (!user || !membership) {
    if (authScreen) {
      return (
        <AuthView
          initialMode={authScreen}
          theme={theme}
          onToggleTheme={handleToggleTheme}
          onBackHome={() => setAuthScreen(null)}
          onAuthenticated={handleAuthenticated}
        />
      );
    }
    return (
      <LandingView
        plans={plans}
        capabilities={capabilities}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onOpenAuth={(mode) => setAuthScreen(mode)}
      />
    );
  }

  const sidebarItems: Array<{
    id: NavSection;
    label: string;
    Icon: React.FC<{ className?: string }>;
    badge?: number;
  }> = [
    { id: 'dashboard', label: 'Ana Panel', Icon: LayoutDashboard },
    { id: 'projects', label: 'Projelerim', Icon: FolderCode },
    { id: 'preview', label: 'Canlı Önizleme', Icon: MonitorSmartphone },
    { id: 'settings', label: 'APK Yapılandırma', Icon: Smartphone },
    { id: 'build', label: 'Derleme Hattı', Icon: Hammer },
    { id: 'premium', label: 'Premium', Icon: Crown },
    { id: 'payments', label: 'Ödemeler', Icon: CreditCard },
    {
      id: 'notifications',
      label: 'Bildirimler',
      Icon: Bell,
      badge: unreadNotifications > 0 ? unreadNotifications : undefined,
    },
    { id: 'account-settings', label: 'Ayarlar', Icon: Settings },
    { id: 'account', label: 'Hesabım', Icon: UserRound },
  ];

  if (user.role === 'admin') {
    sidebarItems.push({ id: 'admin', label: 'Yönetici Paneli', Icon: Shield });
    sidebarItems.push({ id: 'admin-code', label: 'Kaynak Kodları', Icon: Code2 });
  }

  const primaryBuildTarget = selectedProjectId || projects[0]?.id || null;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-[#0B1020] dark:text-[#F8FAFC] flex flex-col pb-16 lg:pb-0">
      {/* 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-30 h-14 bg-white/95 dark:bg-[#0B1020]/95 backdrop-blur border-b border-slate-200 dark:border-white/[0.08] px-4 lg:px-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            className="lg:hidden p-1.5 rounded-lg text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white"
            aria-label="Menüyü Aç"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <button
            type="button"
            onClick={() => setSection('dashboard')}
            className="shrink-0"
          >
            <BrandLogo variant="horizontal" size="sm" showSlogan={false} />
          </button>
        </div>

        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-600 dark:text-[#94A3B8]">
          {(
            [
              { id: 'dashboard', label: 'Ana Sayfa' },
              { id: 'projects', label: 'Projelerim' },
              { id: 'settings', label: 'APK Oluştur' },
              { id: 'premium', label: 'Premium' },
              { id: 'account', label: 'Hesabım' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSection(item.id)}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                section === item.id
                  ? 'text-slate-900 dark:text-[#F8FAFC] border-b-2 border-[#6366F1]'
                  : 'hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleToggleTheme}
            aria-label="Tema Değiştir"
            className="p-2 rounded-lg border border-slate-200 dark:border-white/[0.08] bg-slate-100 dark:bg-[#111827] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={() => setSection('notifications')}
            aria-label="Bildirimler"
            className="relative p-2 rounded-lg border border-slate-200 dark:border-white/[0.08] bg-slate-100 dark:bg-[#111827] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifications > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-[#6366F1] text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                {unreadNotifications > 9 ? '9+' : unreadNotifications}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              if (primaryBuildTarget) {
                openPreBuildModal(primaryBuildTarget);
              } else {
                setUploadModalMode('create');
              }
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white transition-colors whitespace-nowrap shrink-0"
          >
            <Hammer className="w-3.5 h-3.5" />
            <span>APK Oluştur</span>
          </button>
        </div>
      </header>

      {/* Workspace Body: Sidebar + Viewport */}
      <div className="flex-1 flex">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex w-60 shrink-0 flex-col justify-between border-r border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#111827] p-4">
          <div className="space-y-1">
            {sidebarItems.map(({ id, label, Icon, badge }) => {
              const active = section === id;
              const isPrem = id === 'premium';
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSection(id)}
                  className={`w-full flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? isPrem
                        ? 'bg-[#EAB308]/15 text-[#B45309] dark:text-[#EAB308]'
                        : 'bg-[#6366F1] text-white'
                      : isPrem
                      ? 'text-[#B45309] dark:text-[#EAB308] hover:bg-[#EAB308]/10'
                      : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/[0.04]'
                  }`}
                >
                  <span className="inline-flex items-center gap-3 min-w-0">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{label}</span>
                  </span>
                  {badge !== undefined && (
                    <span
                      className={`text-[10px] font-bold tabular-nums px-1.5 py-0.5 rounded-md ${
                        active
                          ? 'bg-white/20 text-white'
                          : 'bg-[#6366F1]/15 text-[#6366F1] dark:text-[#818CF8]'
                      }`}
                    >
                      {badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-white/[0.08]">
            <button
              type="button"
              onClick={() => setSection('account')}
              className="w-full text-left p-3 rounded-xl bg-slate-50 dark:bg-[#151D2E] hover:border-[#6366F1] border border-slate-200 dark:border-white/[0.08] transition-colors flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg overflow-hidden bg-[#6366F1]/15 flex items-center justify-center shrink-0">
                {user.avatarUrl ? (
                  <img
                    src={user.avatarUrl}
                    alt={user.username}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <UserRound className="w-4 h-4 text-[#6366F1]" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                  {user.username}
                </div>
                <div className="mt-0.5 text-[11px] text-slate-500 dark:text-[#94A3B8] truncate">
                  {membership.planName}
                  {membership.isPremium && !membership.isLifetime
                    ? ` · ${membership.remainingDays ?? 0}g`
                    : membership.isLifetime
                    ? ' · Süresiz'
                    : ''}
                </div>
              </div>
            </button>
          </div>
        </aside>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden bg-black/70 backdrop-blur-sm">
            <div className="w-64 h-full bg-white dark:bg-[#111827] border-r border-slate-200 dark:border-white/[0.08] p-4 flex flex-col justify-between overflow-y-auto">
              <div className="space-y-1">
                <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-200 dark:border-white/[0.08]">
                  <BrandLogo variant="horizontal" size="sm" showSlogan={false} />
                  <button
                    type="button"
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-1 text-slate-500 dark:text-[#94A3B8]"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {sidebarItems.map(({ id, label, Icon, badge }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      setSection(id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium ${
                      section === id
                        ? 'bg-[#6366F1] text-white'
                        : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <span className="inline-flex items-center gap-3">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{label}</span>
                    </span>
                    {badge !== undefined && (
                      <span className="text-[10px] font-bold tabular-nums">{badge}</span>
                    )}
                  </button>
                ))}
              </div>
              <div className="pt-4 border-t border-slate-200 dark:border-white/[0.08] text-xs text-slate-500 dark:text-[#94A3B8] truncate">
                {user.email}
              </div>
            </div>
          </div>
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 min-w-0 p-5 lg:p-8 max-w-[1400px] w-full mx-auto">
          {globalError && (
            <div className="mb-6 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-600 dark:text-red-300 flex items-center justify-between gap-4">
              <span>{globalError}</span>
              <button
                type="button"
                onClick={() => setGlobalError(null)}
                className="font-semibold hover:underline"
              >
                Kapat
              </button>
            </div>
          )}

          {section === 'dashboard' && (
            <DashboardView
              projects={projects}
              builds={builds}
              membership={membership}
              capabilities={capabilities}
              selectedProjectId={selectedProjectId}
              onSelectProject={setSelectedProjectId}
              onNavigate={setSection}
              onOpenUploadModal={(mode) => setUploadModalMode(mode)}
              onInstantHtmlToApk={async (fileList) => {
                setGlobalError(null);
                try {
                  const form = new FormData();
                  const filesArr = Array.from(fileList);
                  for (const f of filesArr) {
                    form.append('files', f);
                  }
                  const res = await apiRequest<{ project: ProjectSummary }>(
                    '/api/projects/upload',
                    {
                      method: 'POST',
                      body: form,
                    }
                  );
                  await refreshProjectsAndBuilds();
                  await refreshMembership();
                  setSelectedProjectId(res.project.id);
                  openPreBuildModal(res.project);
                } catch (err) {
                  if (err instanceof ApiError && err.upgradeRequired) {
                    handleRequireUpgrade(err.message);
                    return;
                  }
                  setGlobalError(
                    err instanceof Error ? err.message : 'HTML yükleme başarısız oldu.'
                  );
                }
              }}
              onSeedSampleApp={handleSeedSampleApp}
              onStartQuickBuild={(id) => openPreBuildModal(id)}
              onDownloadBuild={(id) => void handleDownloadBuild(id)}
              onInspectBuild={(id) => void handleInspectBuild(id)}
            />
          )}

          {section === 'projects' && (
            <ProjectsView
              projects={projects}
              selectedProject={selectedProject}
              onSelectProject={setSelectedProjectId}
              onRefreshProjects={refreshProjectsAndBuilds}
              onRefreshSelected={refreshSelectedProject}
              onOpenUploadModal={(mode) => setUploadModalMode(mode)}
              onNavigate={setSection}
              onStartBuild={(id) => openPreBuildModal(id)}
            />
          )}

          {section === 'preview' && (
            <PreviewView
              projects={projects}
              selectedProject={selectedProject}
              onSelectProject={setSelectedProjectId}
            />
          )}

          {section === 'settings' && (
            <ApkSettingsView
              projects={projects}
              selectedProject={selectedProject}
              membership={membership}
              onSelectProject={setSelectedProjectId}
              onRefreshSelected={refreshSelectedProject}
              onStartBuild={(id) => openPreBuildModal(id)}
              onRequireUpgrade={handleRequireUpgrade}
            />
          )}

          {section === 'build' && (
            <BuildPipelineView
              projects={projects}
              builds={builds}
              activeBuild={activeBuild}
              selectedProjectId={selectedProjectId}
              membership={membership}
              capabilities={capabilities}
              onSelectProject={setSelectedProjectId}
              onStartBuild={(id) => openPreBuildModal(id)}
              onCancelBuild={(id) => void handleCancelBuild(id)}
              onDownloadBuild={(id) => void handleDownloadBuild(id)}
              onSelectBuild={setActiveBuild}
            />
          )}

          {section === 'premium' && (
            <PremiumView
              plans={plans}
              limits={limits}
              membership={membership}
              paymentProvider={paymentProvider}
              upgradeNotice={upgradeNotice}
              onDismissNotice={() => setUpgradeNotice(null)}
              onMembershipUpdated={refreshMembership}
            />
          )}

          {section === 'payments' && (
            <PaymentHistoryView
              payments={payments}
              membership={membership}
              onNavigate={setSection}
            />
          )}

          {section === 'notifications' && (
            <NotificationsView
              onNavigate={setSection}
              onUnreadCountChange={setUnreadNotifications}
            />
          )}

          {section === 'account-settings' && (
            <SettingsView
              user={user}
              theme={theme}
              onSetTheme={applyTheme}
              onUserUpdated={setUser}
              onNavigate={setSection}
            />
          )}

          {section === 'account' && (
            <AccountView
              user={user}
              membership={membership}
              payments={payments}
              builds={builds}
              onNavigate={setSection}
              onUserUpdated={setUser}
              onDownloadBuild={(id) => void handleDownloadBuild(id)}
              onLogout={() => void handleLogout()}
            />
          )}

          {section === 'admin' && user.role === 'admin' && (
            <AdminView onMembershipUpdated={refreshMembership} />
          )}

          {section === 'admin-code' && user.role === 'admin' && <AdminCodeExplorer />}
        </main>
      </div>

      {/* Compact Mobile Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 h-14 bg-white/95 dark:bg-[#111827]/95 backdrop-blur border-t border-slate-200 dark:border-white/[0.08] grid grid-cols-5">
        {(
          [
            { id: 'dashboard', label: 'Panel', Icon: LayoutDashboard },
            { id: 'projects', label: 'Projeler', Icon: FolderCode },
            { id: 'build', label: 'APK', Icon: Hammer },
            { id: 'premium', label: 'Premium', Icon: Crown },
            { id: 'account', label: 'Hesabım', Icon: UserRound },
          ] as const
        ).map(({ id, label, Icon }) => {
          const active = section === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setSection(id)}
              className={`flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
                active
                  ? 'text-[#6366F1]'
                  : 'text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate">{label}</span>
            </button>
          );
        })}
      </nav>

      {/* Upload / Create Modal */}
      {uploadModalMode && (
        <UploadCreateModal
          initialMode={uploadModalMode}
          maxUploadMb={membership.limits.maxUploadMb}
          onClose={() => setUploadModalMode(null)}
          onRequireUpgrade={handleRequireUpgrade}
          onProjectCreated={async (proj, entryOpts) => {
            setUploadModalMode(null);
            await refreshProjectsAndBuilds();
            await refreshMembership();
            setSelectedProjectId(proj.id);
            if (entryOpts?.needsSelection && entryOpts.htmlFiles.length > 1) {
              setEntrySelectPrompt({ projectId: proj.id, htmlFiles: entryOpts.htmlFiles });
            } else {
              setSection('projects');
            }
          }}
        />
      )}

      {/* Entry HTML Picker Modal */}
      {entrySelectPrompt && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Giriş HTML Dosyasını Seçin
            </h3>
            <p className="text-xs text-slate-600 dark:text-[#94A3B8]">
              Projede kök dizinde <code className="font-mono">index.html</code> bulunamadı ancak
              birden fazla HTML dosyası tespit edildi. Android WebView’ın açacağı giriş sayfasını
              seçin:
            </p>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {entrySelectPrompt.htmlFiles.map((hf) => (
                <button
                  key={hf}
                  type="button"
                  onClick={async () => {
                    await apiRequest(`/api/projects/${entrySelectPrompt.projectId}/entry`, {
                      method: 'PUT',
                      body: JSON.stringify({ entryFile: hf }),
                    });
                    await refreshSelectedProject(entrySelectPrompt.projectId);
                    await refreshProjectsAndBuilds();
                    setEntrySelectPrompt(null);
                    setSection('preview');
                  }}
                  className="w-full text-left px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#0B1020] hover:border-[#6366F1] border border-slate-200 dark:border-white/[0.08] text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                >
                  {hf}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Pre-Build Logo & App Identity Modal */}
      {preBuildProject && (
        <PreBuildModal
          project={preBuildProject}
          membership={membership}
          onClose={() => setPreBuildProject(null)}
          onRequireUpgrade={handleRequireUpgrade}
          onConfigSaved={async () => {
            await refreshProjectsAndBuilds();
            await refreshSelectedProject(preBuildProject.id);
          }}
          onConfirmBuild={executeBuild}
        />
      )}
    </div>
  );
}
