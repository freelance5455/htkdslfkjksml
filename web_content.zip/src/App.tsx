import React, { useState, useEffect } from 'react';
import { AndroidFrame } from './components/common/AndroidFrame';
import { M3TopAppBar } from './components/navigation/M3TopAppBar';
import { M3BottomNavigation, MainTab } from './components/navigation/M3BottomNavigation';
import { HomeView, FeatureToolId } from './components/views/HomeView';
import { TextToDocumentView } from './components/views/TextToDocumentView';
import { ImageToTextView } from './components/views/ImageToTextView';
import { PdfToImageView } from './components/views/PdfToImageView';
import { WordToImageView } from './components/views/WordToImageView';
import { ImageToDocumentView } from './components/views/ImageToDocumentView';
import { AiFormattingAssistantView } from './components/views/AiFormattingAssistantView';
import { DocumentMergeView } from './components/views/DocumentMergeView';
import { BackgroundRemovalView } from './components/views/BackgroundRemovalView';
import { FilesView } from './components/views/FilesView';
import { SettingsView } from './components/views/SettingsView';
import { AppThemeSettings, StoredDocument, DocumentStyleSettings } from './types';
import { getStoredDocuments, toggleDocumentFavorite, saveStoredDocument } from './services/storageService';
import { parseDocxFile } from './utils/docxProcessor';
import { extractTextFromPdf } from './utils/pdfProcessor';

export default function App() {
  const [themeSettings, setThemeSettings] = useState<AppThemeSettings>({
    isDark: false,
    primaryColor: '#1972E8',
    deviceMode: 'phone',
    soundFeedback: false
  });

  const [currentTab, setCurrentTab] = useState<MainTab>('home');
  const [activeFeature, setActiveFeature] = useState<FeatureToolId | null>(null);

  // Transfer data between views
  const [formatterInitialText, setFormatterInitialText] = useState<string | undefined>(undefined);
  const [formatterInitialSettings, setFormatterInitialSettings] = useState<Partial<DocumentStyleSettings> | undefined>(undefined);

  // Stored documents list
  const [documents, setDocuments] = useState<StoredDocument[]>([]);

  useEffect(() => {
    // Sync dark class on root
    if (themeSettings.isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [themeSettings.isDark]);

  useEffect(() => {
    setDocuments(getStoredDocuments());
  }, []);

  const refreshDocuments = () => {
    setDocuments(getStoredDocuments());
  };

  const handleToggleFavorite = (id: string) => {
    toggleDocumentFavorite(id);
    refreshDocuments();
  };

  // Quick import handler from home screen
  const handleQuickImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const nameLower = file.name.toLowerCase();

    if (nameLower.endsWith('.docx')) {
      const parsed = await parseDocxFile(file);
      setFormatterInitialText(parsed.text);
      setActiveFeature('text_to_doc');
    } else if (nameLower.endsWith('.pdf')) {
      setActiveFeature('pdf_to_image');
    } else if (nameLower.endsWith('.png') || nameLower.endsWith('.jpg') || nameLower.endsWith('.jpeg')) {
      setActiveFeature('image_to_text');
    } else {
      const text = await file.text();
      setFormatterInitialText(text);
      setActiveFeature('text_to_doc');
    }
  };

  const handleOpenDocument = (doc: StoredDocument) => {
    if (doc.type === 'docx' || doc.type === 'txt') {
      setActiveFeature('text_to_doc');
    } else if (doc.type === 'pdf') {
      setActiveFeature('pdf_to_image');
    } else if (doc.type === 'png' || doc.type === 'jpg') {
      setActiveFeature('remove_bg');
    }
  };

  // Header Title derivation
  const getHeaderTitle = () => {
    if (activeFeature) {
      switch (activeFeature) {
        case 'text_to_doc':
          return 'Text to Document';
        case 'image_to_text':
          return 'Image to Text (OCR)';
        case 'ocr_to_doc':
          return 'OCR to Document';
        case 'pdf_to_image':
          return 'PDF to Image';
        case 'word_to_image':
          return 'Word to Image';
        case 'image_to_doc':
          return 'Image to Document';
        case 'ai_formatter':
          return 'AI Document Formatter';
        case 'merge_docs':
          return 'Merge Documents';
        case 'remove_bg':
          return 'Remove Background';
        case 'replace_bg_color':
          return 'Replace Background Color';
      }
    }

    switch (currentTab) {
      case 'home':
        return 'DocuForge';
      case 'files':
        return 'Document Files';
      case 'tools':
        return 'Studio Tools';
      case 'settings':
        return 'Settings';
    }
  };

  const getHeaderSubtitle = () => {
    if (activeFeature) return 'Studio Workspace';
    switch (currentTab) {
      case 'home':
        return 'Document & Image Studio';
      case 'files':
        return `${documents.length} Saved Files`;
      case 'tools':
        return 'All 10 Core Features';
      case 'settings':
        return 'Preferences & System';
    }
  };

  const totalBytes = documents.reduce((acc, d) => acc + (d.sizeBytes || 0), 0);

  return (
    <AndroidFrame themeSettings={themeSettings}>
      {/* Top App Bar */}
      <M3TopAppBar
        title={getHeaderTitle()}
        subtitle={getHeaderSubtitle()}
        showBack={!!activeFeature}
        onBack={() => {
          setActiveFeature(null);
          setFormatterInitialText(undefined);
          setFormatterInitialSettings(undefined);
        }}
        themeSettings={themeSettings}
        onToggleTheme={() =>
          setThemeSettings((prev) => ({ ...prev, isDark: !prev.isDark }))
        }
        onToggleDeviceMode={() =>
          setThemeSettings((prev) => ({
            ...prev,
            deviceMode: prev.deviceMode === 'phone' ? 'full' : 'phone'
          }))
        }
      />

      {/* Main View Area */}
      <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
        {/* If inside an active tool feature */}
        {activeFeature === 'text_to_doc' && (
          <TextToDocumentView
            onBack={() => {
              setActiveFeature(null);
              setFormatterInitialText(undefined);
              setFormatterInitialSettings(undefined);
            }}
            initialText={formatterInitialText}
            initialSettings={formatterInitialSettings}
            onSaveDocument={() => refreshDocuments()}
          />
        )}

        {activeFeature === 'image_to_text' && (
          <ImageToTextView
            onBack={() => setActiveFeature(null)}
            onNavigateToDocumentFormatter={(text) => {
              setFormatterInitialText(text);
              setActiveFeature('text_to_doc');
            }}
          />
        )}

        {activeFeature === 'ocr_to_doc' && (
          <ImageToTextView
            onBack={() => setActiveFeature(null)}
            onNavigateToDocumentFormatter={(text) => {
              setFormatterInitialText(text);
              setActiveFeature('text_to_doc');
            }}
          />
        )}

        {activeFeature === 'pdf_to_image' && (
          <PdfToImageView onBack={() => setActiveFeature(null)} />
        )}

        {activeFeature === 'word_to_image' && (
          <WordToImageView onBack={() => setActiveFeature(null)} />
        )}

        {activeFeature === 'image_to_doc' && (
          <ImageToDocumentView
            onBack={() => setActiveFeature(null)}
            onSendToFullEditor={(text) => {
              setFormatterInitialText(text);
              setActiveFeature('text_to_doc');
            }}
          />
        )}

        {activeFeature === 'ai_formatter' && (
          <AiFormattingAssistantView
            onBack={() => setActiveFeature(null)}
            onApplyAndCreateDocument={(text, styles) => {
              setFormatterInitialText(text);
              setFormatterInitialSettings(styles);
              setActiveFeature('text_to_doc');
            }}
          />
        )}

        {activeFeature === 'merge_docs' && (
          <DocumentMergeView onBack={() => setActiveFeature(null)} />
        )}

        {(activeFeature === 'remove_bg' || activeFeature === 'replace_bg_color') && (
          <BackgroundRemovalView onBack={() => setActiveFeature(null)} />
        )}

        {/* Primary Bottom Tabs (shown when not in a tool workspace) */}
        {!activeFeature && currentTab === 'home' && (
          <HomeView
            onSelectFeature={(toolId) => {
              setFormatterInitialText(undefined);
              setFormatterInitialSettings(undefined);
              setActiveFeature(toolId);
            }}
            recentDocuments={documents}
            onToggleFavorite={handleToggleFavorite}
            onOpenDocument={handleOpenDocument}
            onQuickImport={handleQuickImport}
          />
        )}

        {!activeFeature && currentTab === 'files' && (
          <FilesView
            documents={documents}
            onRefresh={refreshDocuments}
            onOpenDocument={handleOpenDocument}
          />
        )}

        {!activeFeature && currentTab === 'tools' && (
          <HomeView
            onSelectFeature={(toolId) => {
              setFormatterInitialText(undefined);
              setFormatterInitialSettings(undefined);
              setActiveFeature(toolId);
            }}
            recentDocuments={documents}
            onToggleFavorite={handleToggleFavorite}
            onOpenDocument={handleOpenDocument}
            onQuickImport={handleQuickImport}
          />
        )}

        {!activeFeature && currentTab === 'settings' && (
          <SettingsView
            themeSettings={themeSettings}
            onUpdateThemeSettings={(update) =>
              setThemeSettings((prev) => ({ ...prev, ...update }))
            }
            documentCount={documents.length}
            totalSizeBytes={totalBytes}
            onHistoryCleared={refreshDocuments}
          />
        )}
      </div>

      {/* Material 3 Bottom Navigation Bar */}
      {!activeFeature && (
        <M3BottomNavigation
          currentTab={currentTab}
          onTabChange={(tab) => setCurrentTab(tab)}
          accentColor={themeSettings.primaryColor}
        />
      )}
    </AndroidFrame>
  );
}
