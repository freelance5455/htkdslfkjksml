/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  addDoc,
  collection,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Bell,
  BookOpen,
  Building2,
  Download,
  Globe,
  Home,
  MessageCircle,
  Moon,
  Shield,
  Sparkles,
  Sun,
  User as UserIcon,
  Users,
  WifiOff,
  X,
} from 'lucide-react';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { AIAssistantModal } from './components/AIAssistantModal';
import { AuthScreen } from './components/AuthScreen';
import { CallOverlay, type ActiveCallSession } from './components/CallOverlay';
import { ChatsTab } from './components/ChatsTab';
import { DownloadAppModal } from './components/DownloadAppModal';
import { FeedTab } from './components/FeedTab';
import { FriendsTab } from './components/FriendsTab';
import { LibraryTab } from './components/LibraryTab';
import { NotificationsModal } from './components/NotificationsModal';
import { ProfileTab } from './components/ProfileTab';
import { TevetaCollegeNoticeModal } from './components/TevetaCollegeNoticeModal';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { usePWAInstall } from './hooks/usePWAInstall';
import { auth, db, handleFirestoreError, OperationType, OWNER_ADMIN_EMAIL } from './lib/firebase';
import { TRANSLATIONS } from './lib/i18n';
import { BUILTIN_COURSES, TEVETA_COLLEGES } from './lib/tevetaCatalog';
import type {
  LanguageCode,
  LibraryMaterial,
  NotificationItem,
  ThemeMode,
  UserPrivateInfo,
  UserProfile,
  UserRole,
} from './types';

type MainTab = 'home' | 'friends' | 'chats' | 'library' | 'profile';

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
};

export default function App() {
  const isOnline = useOnlineStatus();
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [privateInfo, setPrivateInfo] = useState<UserPrivateInfo | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  const [pendingRegDraft, setPendingRegDraft] = useState<{
    fullName: string;
    username: string;
    phone: string;
    college: string;
    course: string;
    level: string;
    role: UserRole;
  } | null>(null);

  const [activeTab, setActiveTab] = useState<MainTab>('home');
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [theme, setTheme] = useState<ThemeMode>('light');

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  // Modals & Cross-tab shortcuts
  const [aiOpen, setAiOpen] = useState(false);
  const [aiInitialContext, setAiInitialContext] = useState('');
  const [aiInitialSubject, setAiInitialSubject] = useState('');
  const [aiInitialCourse, setAiInitialCourse] = useState('');
  const [adminOpen, setAdminOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [selectedPeerForChat, setSelectedPeerForChat] = useState<UserProfile | null>(null);
  const [collegeNoticeOpen, setCollegeNoticeOpen] = useState(false);
  const [downloadOpen, setDownloadOpen] = useState(false);
  const [libraryCollegeFilter, setLibraryCollegeFilter] = useState('All');
  const [noticeDismissed, setNoticeDismissed] = useState(() => {
    try {
      return localStorage.getItem('tevet_power_college_notice_v1_dismissed') === '1';
    } catch {
      return false;
    }
  });

  const handleDismissCollegeNotice = () => {
    setNoticeDismissed(true);
    try {
      localStorage.setItem('tevet_power_college_notice_v1_dismissed', '1');
    } catch {
      // Ignore storage write error
    }
  };

  // Real-time WebSocket presence, typing, and WebRTC signaling
  const wsRef = useRef<WebSocket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const [onlineUids, setOnlineUids] = useState<string[]>([]);
  const [typingByChatId, setTypingByChatId] = useState<Record<string, boolean>>({});
  const [callSession, setCallSession] = useState<ActiveCallSession | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  // Sync Tailwind .dark class on <html>
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  // Bootstrap & listen to user profile, private info, admin status, and notifications
  useEffect(() => {
    if (!firebaseUser) {
      setProfile(null);
      setPrivateInfo(null);
      setIsAdmin(false);
      setNotifications([]);
      return;
    }

    const uid = firebaseUser.uid;
    const isOwnerEmail =
      firebaseUser.email === OWNER_ADMIN_EMAIL && firebaseUser.emailVerified;

    const ensureUserDocs = async () => {
      try {
        const userRef = doc(db, 'users', uid);
        const snap = await getDoc(userRef);
        if (!snap.exists()) {
          const baseName =
            pendingRegDraft?.fullName ||
            firebaseUser.displayName ||
            firebaseUser.email?.split('@')[0] ||
            'TEVETA Learner';
          const cleanUser =
            pendingRegDraft?.username ||
            `${baseName.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 14) || 'learner'}_${uid.slice(0, 4)}`;

          await setDoc(userRef, {
            uid,
            fullName: baseName,
            username: cleanUser,
            photoUrl: firebaseUser.photoURL || '',
            coverUrl: '/src/assets/images/cover_solar_campus_1794522898351.jpg',
            bio: 'TEVETA Malawi technical learner on TEVET POWER APP.',
            location: 'Malawi',
            college: pendingRegDraft?.college || TEVETA_COLLEGES[0],
            course: pendingRegDraft?.course || BUILTIN_COURSES[0].name,
            level: pendingRegDraft?.level || 'Level 1',
            role: isOwnerEmail ? 'admin' : pendingRegDraft?.role || 'student',
            isOnline: true,
            followersCount: 0,
            followingCount: 0,
            blockedUids: [],
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        const privRef = doc(db, 'users', uid, 'private', 'info');
        const privSnap = await getDoc(privRef);
        if (!privSnap.exists()) {
          await setDoc(privRef, {
            uid,
            email: firebaseUser.email || '',
            phone: pendingRegDraft?.phone || '',
            language,
            theme,
            profileVisibility: 'public',
            messagePermission: 'friends',
            subscriptionStatus: 'free',
            subscriptionExpiresAt: null,
            updatedAt: serverTimestamp(),
          });
        }

        const adminDoc = await getDoc(doc(db, 'admins', uid));
        setIsAdmin(isOwnerEmail || adminDoc.exists());
      } catch (err) {
        console.error('Profile bootstrap note:', err);
      }
    };

    void ensureUserDocs();

    const unsubProfile = onSnapshot(
      doc(db, 'users', uid),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as UserProfile;
          setProfile(data);
          if (data.role === 'admin' || isOwnerEmail) {
            setIsAdmin(true);
          }
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}`)
    );

    const unsubPriv = onSnapshot(
      doc(db, 'users', uid, 'private', 'info'),
      (snap) => {
        if (snap.exists()) {
          const priv = snap.data() as UserPrivateInfo;
          setPrivateInfo(priv);
          if (priv.language) setLanguage(priv.language);
          if (priv.theme) setTheme(priv.theme);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}/private/info`)
    );

    const unsubNotifs = onSnapshot(
      query(
        collection(db, 'notifications'),
        where('recipientUid', '==', uid),
        orderBy('createdAt', 'desc')
      ),
      (snap) => {
        setNotifications(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<NotificationItem, 'id'>) }))
        );
      },
      () => {
        // Fallback if composite index is building
      }
    );

    return () => {
      unsubProfile();
      unsubPriv();
      unsubNotifs();
    };
  }, [firebaseUser, pendingRegDraft]);

  // WebRTC Cleanup
  const cleanupCallMedia = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((tr) => tr.stop());
      localStreamRef.current = null;
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    setLocalStream(null);
    setRemoteStream(null);
    setCallSession(null);
  }, []);

  // Connect WebSocket signaling & presence
  useEffect(() => {
    if (!profile) return;
    let closedByEffect = false;

    const connectWs = () => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        ws.send(JSON.stringify({ type: 'auth', uid: profile.uid }));
      };

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(String(event.data)) as Record<string, unknown>;
          if (msg.type === 'presence:list' && Array.isArray(msg.onlineUids)) {
            setOnlineUids(msg.onlineUids as string[]);
          } else if (msg.type === 'chat:typing' && typeof msg.chatId === 'string') {
            setTypingByChatId((prev) => ({
              ...prev,
              [String(msg.chatId)]: Boolean(msg.isTyping),
            }));
          } else if (msg.type === 'call:offer' && typeof msg.fromUid === 'string') {
            setCallSession({
              callId: String(msg.callId || Date.now()),
              peerUid: String(msg.fromUid),
              peerName: String(msg.callerName || 'Learner'),
              callType: msg.callType === 'video' ? 'video' : 'voice',
              direction: 'incoming',
              status: 'ringing',
              offerSdp: msg.sdp as RTCSessionDescriptionInit,
            });
          } else if (msg.type === 'call:answer' && pcRef.current && msg.sdp) {
            await pcRef.current.setRemoteDescription(
              new RTCSessionDescription(msg.sdp as RTCSessionDescriptionInit)
            );
            setCallSession((prev) => (prev ? { ...prev, status: 'connected' } : null));
          } else if (msg.type === 'call:ice' && pcRef.current && msg.candidate) {
            await pcRef.current.addIceCandidate(
              new RTCIceCandidate(msg.candidate as RTCIceCandidateInit)
            );
          } else if (
            msg.type === 'call:reject' ||
            msg.type === 'call:hangup' ||
            msg.type === 'call:unavailable'
          ) {
            cleanupCallMedia();
          }
        } catch {
          // Ignore malformed WS message
        }
      };

      ws.onclose = () => {
        if (!closedByEffect) {
          window.setTimeout(connectWs, 3000);
        }
      };
    };

    connectWs();

    return () => {
      closedByEffect = true;
      wsRef.current?.close();
    };
  }, [profile, cleanupCallMedia]);

  const sendTyping = (toUid: string, chatId: string, isTyping: boolean) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'chat:typing', toUid, chatId, isTyping }));
    }
  };

  const createPeerConnection = (peerUid: string, callId: string) => {
    const pc = new RTCPeerConnection(RTC_CONFIG);
    const remote = new MediaStream();
    setRemoteStream(remote);

    pc.ontrack = (ev) => {
      ev.streams[0]?.getTracks().forEach((tr) => remote.addTrack(tr));
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'call:ice',
            toUid: peerUid,
            callId,
            candidate: ev.candidate.toJSON(),
          })
        );
      }
    };

    pcRef.current = pc;
    return pc;
  };

  const handleStartCall = async (peer: UserProfile, callType: 'voice' | 'video') => {
    if (!profile) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: callType === 'video' ? { facingMode } : false,
      });
      localStreamRef.current = stream;
      setLocalStream(stream);

      const callDoc = await addDoc(collection(db, 'calls'), {
        callerUid: profile.uid,
        callerName: profile.fullName,
        calleeUid: peer.uid,
        calleeName: peer.fullName,
        callType,
        status: 'ringing',
        durationSeconds: 0,
        createdAt: serverTimestamp(),
      });

      setCallSession({
        callId: callDoc.id,
        peerUid: peer.uid,
        peerName: peer.fullName,
        callType,
        direction: 'outgoing',
        status: 'ringing',
      });

      const pc = createPeerConnection(peer.uid, callDoc.id);
      stream.getTracks().forEach((tr) => pc.addTrack(tr, stream));
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      wsRef.current?.send(
        JSON.stringify({
          type: 'call:offer',
          toUid: peer.uid,
          callId: callDoc.id,
          callerName: profile.fullName,
          callType,
          sdp: offer,
        })
      );
    } catch {
      cleanupCallMedia();
    }
  };

  const handleAcceptCall = async () => {
    if (!callSession || !callSession.offerSdp) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: callSession.callType === 'video' ? { facingMode } : false,
      });
      localStreamRef.current = stream;
      setLocalStream(stream);

      const pc = createPeerConnection(callSession.peerUid, callSession.callId);
      stream.getTracks().forEach((tr) => pc.addTrack(tr, stream));
      await pc.setRemoteDescription(new RTCSessionDescription(callSession.offerSdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      wsRef.current?.send(
        JSON.stringify({
          type: 'call:answer',
          toUid: callSession.peerUid,
          callId: callSession.callId,
          sdp: answer,
        })
      );

      setCallSession((prev) => (prev ? { ...prev, status: 'connected' } : null));
      await updateDoc(doc(db, 'calls', callSession.callId), { status: 'active' });
    } catch {
      cleanupCallMedia();
    }
  };

  const handleRejectCall = async () => {
    if (!callSession) return;
    wsRef.current?.send(
      JSON.stringify({
        type: 'call:reject',
        toUid: callSession.peerUid,
        callId: callSession.callId,
      })
    );
    try {
      await updateDoc(doc(db, 'calls', callSession.callId), { status: 'rejected' });
    } catch {
      // Ignore log update failure
    }
    cleanupCallMedia();
  };

  const handleHangupCall = async () => {
    if (!callSession) return;
    wsRef.current?.send(
      JSON.stringify({
        type: 'call:hangup',
        toUid: callSession.peerUid,
        callId: callSession.callId,
      })
    );
    try {
      await updateDoc(doc(db, 'calls', callSession.callId), { status: 'ended' });
    } catch {
      // Ignore log update failure
    }
    cleanupCallMedia();
  };

  const handleSwitchCamera = async () => {
    if (!callSession || callSession.callType !== 'video' || !pcRef.current) return;
    const nextFacing = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextFacing);
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: nextFacing },
        audio: false,
      });
      const newTrack = newStream.getVideoTracks()[0];
      const sender = pcRef.current.getSenders().find((s) => s.track?.kind === 'video');
      if (sender && newTrack) {
        await sender.replaceTrack(newTrack);
        localStreamRef.current?.getVideoTracks().forEach((tr) => tr.stop());
        if (localStreamRef.current) {
          const updated = new MediaStream([
            ...localStreamRef.current.getAudioTracks(),
            newTrack,
          ]);
          localStreamRef.current = updated;
          setLocalStream(updated);
        }
      }
    } catch {
      // Single camera device
    }
  };

  const openAiWithMaterial = (mat: LibraryMaterial, selectedExcerpt?: string) => {
    setAiInitialCourse(mat.courseName || profile?.course || BUILTIN_COURSES[0].name);
    setAiInitialSubject(mat.subject);
    setAiInitialContext(selectedExcerpt || mat.contentMarkdown);
    setAiOpen(true);
  };

  const openAiWithText = (text: string) => {
    setAiInitialCourse(profile?.course || BUILTIN_COURSES[0].name);
    setAiInitialSubject('General');
    setAiInitialContext(text);
    setAiOpen(true);
  };

  const t = TRANSLATIONS[language];
  const unreadCount = notifications.filter((n) => !n.read).length;

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-2">
          <img
            src="/src/assets/images/tevet_app_logo_1794522896439.jpg"
            alt="TEVET POWER APP"
            className="w-14 h-14 rounded-2xl mx-auto"
          />
          <p className="font-display font-bold text-sm text-blue-700 dark:text-blue-400">
            TEVET POWER APP
          </p>
        </div>
      </div>
    );
  }

  if (!firebaseUser || !profile) {
    return (
      <AuthScreen
        language={language}
        setLanguage={setLanguage}
        theme={theme}
        setTheme={setTheme}
        onPendingRegistrationProfile={setPendingRegDraft}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      {/* Offline Connectivity Banner */}
      {!isOnline && (
        <div className="bg-amber-500 text-white text-xs font-medium px-4 py-1.5 flex items-center justify-center gap-2">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode — Saved TEVETA library notes remain accessible.</span>
        </div>
      )}

      {/* Top Navigation Bar (Clean 3-Zone Contract, 56px height) */}
      <header className="sticky top-0 z-30 h-14 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 shrink-0">
            <img
              src="/src/assets/images/tevet_app_logo_1794522896439.jpg"
              alt="TEVET POWER APP"
              className="w-8 h-8 rounded-lg object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="font-display font-bold text-base tracking-tight text-blue-700 dark:text-blue-400 whitespace-nowrap">
              {t.appName}
            </span>
          </div>

          {/* Desktop Inline Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-400">
            {(
              [
                { id: 'home', label: t.tabs.home },
                { id: 'friends', label: t.tabs.friends },
                { id: 'chats', label: t.tabs.chats },
                { id: 'library', label: t.tabs.library },
                { id: 'profile', label: t.tabs.profile },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                  activeTab === item.id
                    ? 'border-blue-700 text-blue-700 dark:text-blue-400 font-semibold'
                    : 'border-transparent hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Compact Header Shortcuts */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setDownloadOpen(true)}
              className="min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isInstalled ? 'App' : 'Download'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setAiInitialContext('');
                setAiOpen(true);
              }}
              className="min-h-[38px] px-3 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.actions.aiAssistant}</span>
            </button>

            <button
              type="button"
              onClick={() => setNotificationsOpen(true)}
              aria-label="Notifications"
              className="relative min-h-[38px] min-w-[38px] rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {unreadCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setLanguage(language === 'en' ? 'ny' : 'en')}
              title="Switch English / Chichewa"
              className="hidden sm:flex min-h-[38px] px-2.5 rounded-xl border border-slate-200 dark:border-slate-700 items-center gap-1 text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{language.toUpperCase()}</span>
            </button>

            <button
              type="button"
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              aria-label="Toggle Light/Dark Mode"
              className="hidden sm:flex min-h-[38px] min-w-[38px] rounded-xl border border-slate-200 dark:border-slate-700 items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Responsive Desktop + Mobile Main Workspace */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-5 pb-24 lg:pb-8 grid lg:grid-cols-12 gap-6 items-start">
        {/* Left Sidebar (Desktop Only) */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-20 space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center font-display font-bold text-sm overflow-hidden shrink-0">
                {profile.photoUrl ? (
                  <img src={profile.photoUrl} alt={profile.fullName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  profile.fullName.slice(0, 2).toUpperCase()
                )}
              </div>
              <div className="min-w-0">
                <p className="font-display font-semibold text-sm truncate">{profile.fullName}</p>
                <p className="text-xs text-slate-500 truncate">
                  {profile.course || 'TEVETA Learner'}
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {profile.college || 'Malawi Technical College'} · {profile.level || 'Level 1'}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-2 space-y-1">
            {(
              [
                { id: 'home', label: t.tabs.home, Icon: Home },
                { id: 'friends', label: t.tabs.friends, Icon: Users },
                { id: 'chats', label: t.tabs.chats, Icon: MessageCircle },
                { id: 'library', label: t.tabs.library, Icon: BookOpen },
                { id: 'profile', label: t.tabs.profile, Icon: UserIcon },
              ] as const
            ).map(({ id, label, Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`w-full min-h-[42px] px-3.5 py-2 rounded-xl text-sm font-medium flex items-center gap-3 transition-colors cursor-pointer ${
                  activeTab === id
                    ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 font-semibold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            ))}

            <button
              type="button"
              onClick={() => setCollegeNoticeOpen(true)}
              className="w-full min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-3 text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 cursor-pointer"
            >
              <Building2 className="w-4 h-4 shrink-0" />
              <span className="truncate">{t.studentNotice.badgeLabel}</span>
            </button>

            {isAdmin && (
              <button
                type="button"
                onClick={() => setAdminOpen(true)}
                className="w-full min-h-[42px] px-3.5 py-2 rounded-xl text-sm font-semibold flex items-center gap-3 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 cursor-pointer"
              >
                <Shield className="w-4 h-4" />
                <span>{t.actions.adminPanel}</span>
              </button>
            )}
          </div>
        </aside>

        {/* Main Center Stage */}
        <main className="lg:col-span-6 min-w-0 space-y-4">
          {!noticeDismissed && (
            <section className="bg-blue-50/90 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-2xl p-4 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-700 text-white flex items-center justify-center shrink-0">
                  <Building2 className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-blue-700 dark:text-blue-300">
                    {t.studentNotice.badgeLabel}
                  </p>
                  <h2 className="font-display font-bold text-sm text-slate-900 dark:text-white leading-snug">
                    {t.studentNotice.headline}
                  </h2>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {t.studentNotice.summary}
                  </p>
                  <div className="pt-1 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setCollegeNoticeOpen(true)}
                      className="min-h-[34px] px-3 py-1 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold cursor-pointer"
                    >
                      {t.studentNotice.viewCollegesBtn}
                    </button>
                    <button
                      type="button"
                      onClick={handleDismissCollegeNotice}
                      className="min-h-[34px] px-3 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-900 cursor-pointer"
                    >
                      {t.studentNotice.dismissBtn}
                    </button>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleDismissCollegeNotice}
                aria-label="Dismiss student notice"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-blue-100 dark:hover:bg-blue-900/50 cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </section>
          )}

          {activeTab === 'home' && (
            <FeedTab
              profile={profile}
              isAdmin={isAdmin}
              language={language}
              onlineUids={onlineUids}
              onAskAiAboutText={openAiWithText}
            />
          )}
          {activeTab === 'friends' && (
            <FriendsTab
              profile={profile}
              language={language}
              onlineUids={onlineUids}
              onStartChat={(peer) => {
                setSelectedPeerForChat(peer);
                setActiveTab('chats');
              }}
              onStartCall={handleStartCall}
            />
          )}
          {activeTab === 'chats' && (
            <ChatsTab
              profile={profile}
              language={language}
              onlineUids={onlineUids}
              typingByChatId={typingByChatId}
              selectedPeerForChat={selectedPeerForChat}
              onClearSelectedPeer={() => setSelectedPeerForChat(null)}
              onSendTyping={sendTyping}
              onStartCall={handleStartCall}
            />
          )}
          {activeTab === 'library' && (
            <LibraryTab
              language={language}
              isAdmin={isAdmin}
              selectedCollegeFilter={libraryCollegeFilter}
              onCollegeFilterChange={setLibraryCollegeFilter}
              onOpenCollegeNotice={() => setCollegeNoticeOpen(true)}
              onAskAiAboutMaterial={openAiWithMaterial}
              onOpenAdminUpload={() => setAdminOpen(true)}
            />
          )}
          {activeTab === 'profile' && (
            <ProfileTab
              profile={profile}
              privateInfo={privateInfo}
              isAdmin={isAdmin}
              language={language}
              setLanguage={setLanguage}
              theme={theme}
              setTheme={setTheme}
              onOpenAdmin={() => setAdminOpen(true)}
              onOpenDownloadModal={() => setDownloadOpen(true)}
              onOpenCollegeNotice={() => setCollegeNoticeOpen(true)}
            />
          )}
        </main>

        {/* Right Contextual Rail (Desktop Only) */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-20 space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="font-display font-semibold text-sm">TEVET AI Study Tutor</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Get step-by-step calculations, Chichewa or English explanations, diagram help, and practice quizzes tailored to {profile.course || 'your trade'}.
            </p>
            <button
              type="button"
              onClick={() => {
                setAiInitialContext('');
                setAiOpen(true);
              }}
              className="w-full min-h-[40px] rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Open TEVET AI</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2">
            <h3 className="font-display font-semibold text-sm">Membership Status</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Current plan: <strong className="uppercase text-slate-900 dark:text-white">{privateInfo?.subscriptionStatus || 'free'}</strong>
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Monthly Access: MWK 1,000 / 30 days via Airtel Money or TNM Mpamba.
            </p>
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className="text-xs font-semibold text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
            >
              Manage Membership →
            </button>
          </div>
        </aside>
      </div>

      {/* Fixed 5-Tab Bottom Navigation Bar (Mobile / Tablet) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 pb-safe bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 items-center">
        {(
          [
            { id: 'home', label: t.tabs.home, Icon: Home },
            { id: 'friends', label: t.tabs.friends, Icon: Users },
            { id: 'chats', label: t.tabs.chats, Icon: MessageCircle },
            { id: 'library', label: t.tabs.library, Icon: BookOpen },
            { id: 'profile', label: t.tabs.profile, Icon: UserIcon },
          ] as const
        ).map(({ id, label, Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setActiveTab(id)}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                active
                  ? 'text-blue-700 dark:text-blue-400 font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] tracking-tight">{label}</span>
            </button>
          );
        })}
      </nav>

      {/* Modals & Call Overlay */}
      <AIAssistantModal
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        profile={profile}
        language={language}
        initialContext={aiInitialContext}
        initialSubject={aiInitialSubject}
        initialCourse={aiInitialCourse}
      />

      {isAdmin && (
        <AdminDashboardModal
          open={adminOpen}
          onClose={() => setAdminOpen(false)}
          adminProfile={profile}
        />
      )}

      <NotificationsModal
        open={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        notifications={notifications}
      />

      <TevetaCollegeNoticeModal
        open={collegeNoticeOpen}
        onClose={() => setCollegeNoticeOpen(false)}
        language={language}
        onSelectCollege={(col) => {
          setLibraryCollegeFilter(col);
          setActiveTab('library');
        }}
      />

      <DownloadAppModal
        open={downloadOpen}
        onClose={() => setDownloadOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        isIOS={isIOS}
        onInstallPWA={install}
      />

      <CallOverlay
        session={callSession}
        localStream={localStream}
        remoteStream={remoteStream}
        onAccept={() => void handleAcceptCall()}
        onReject={() => void handleRejectCall()}
        onHangup={() => void handleHangupCall()}
        onSwitchCamera={() => void handleSwitchCamera()}
      />
    </div>
  );
}
