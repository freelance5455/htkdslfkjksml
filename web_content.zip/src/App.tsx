/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Header } from './components/Header.tsx';
import { Footer } from './components/Footer.tsx';
import { HomeView } from './components/HomeView.tsx';
import { TournamentsView } from './components/TournamentsView.tsx';
import { MatchRoomView } from './components/MatchRoomView.tsx';
import { WalletView } from './components/WalletView.tsx';
import { PlayerProfileView } from './components/PlayerProfileView.tsx';
import { Modals } from './components/Modals.tsx';
import { AuthModal } from './components/AuthModal.tsx';

function MainContent() {
  const { currentTab } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#10131a] text-[#e1e2eb] selection:bg-[#ff5e00] selection:text-[#531900]">
      <Header />
      <main className="w-full pt-20 flex-1 flex flex-col">
        {currentTab === 'home' && <HomeView />}
        {currentTab === 'tournaments' && <TournamentsView />}
        {currentTab === 'match-room' && <MatchRoomView />}
        {currentTab === 'wallet' && <WalletView />}
        {currentTab === 'player-profile' && <PlayerProfileView />}
        {currentTab === 'auth' && <TournamentsView />}
      </main>
      <Footer />
      <Modals />
      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
