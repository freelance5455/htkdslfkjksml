/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Conversation, Message, Theme } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { ChatInput } from './components/ChatInput';
import { CreatorModal } from './components/CreatorModal';
import { speakText } from './utils/speech';

const STORAGE_KEY_CONVERSATIONS = 'bill_ai_conversations_v2';
const STORAGE_KEY_ACTIVE_ID = 'bill_ai_active_id_v2';
const STORAGE_KEY_THEME = 'bill_ai_theme_v2';
const STORAGE_KEY_AUTOSPEAK = 'bill_ai_autospeak_v2';

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CONVERSATIONS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load conversations from storage', e);
    }
    const initialId = Date.now().toString();
    return [
      {
        id: initialId,
        title: 'Суҳбати нав',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    ];
  });

  const [activeConversationId, setActiveConversationId] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
    return saved || (conversations[0]?.id ?? '');
  });

  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_THEME) as Theme;
    return saved === 'light' ? 'light' : 'dark';
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCreatorModalOpen, setIsCreatorModalOpen] = useState(false);
  const [isAutoSpeak, setIsAutoSpeak] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEY_AUTOSPEAK) === 'true';
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync theme with HTML document
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEY_THEME, theme);
  }, [theme]);

  // Persist conversations
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CONVERSATIONS, JSON.stringify(conversations));
    } catch (e) {
      console.error('Failed to save conversations', e);
    }
  }, [conversations]);

  // Persist active ID
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeConversationId);
  }, [activeConversationId]);

  // Persist AutoSpeak preference
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_AUTOSPEAK, isAutoSpeak ? 'true' : 'false');
  }, [isAutoSpeak]);

  const activeConversation =
    conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const messages = activeConversation?.messages || [];

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleToggleAutoSpeak = () => {
    setIsAutoSpeak((prev) => !prev);
  };

  const handleNewChat = () => {
    const newId = Date.now().toString();
    const newConv: Conversation = {
      id: newId,
      title: 'Суҳбати нав',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newId);
    setInput('');
  };

  const handleClearChat = () => {
    if (!activeConversation) return;
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id
          ? { ...c, messages: [], updatedAt: Date.now() }
          : c
      )
    );
  };

  const handleDeleteConversation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = conversations.filter((c) => c.id !== id);
    if (filtered.length === 0) {
      const newId = Date.now().toString();
      const freshConv: Conversation = {
        id: newId,
        title: 'Суҳбати нав',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setConversations([freshConv]);
      setActiveConversationId(newId);
    } else {
      setConversations(filtered);
      if (activeConversationId === id) {
        setActiveConversationId(filtered[0].id);
      }
    }
  };

  const handleExportChat = () => {
    if (!activeConversation || activeConversation.messages.length === 0) return;

    let textContent = `=== Bill AI - Суҳбат бо зеҳни сунъӣ ===\n`;
    textContent += `Созандаи ягонаи Bill AI: Мирзоев Билолиддин\n`;
    textContent += `Сана: ${new Date().toLocaleString()}\n`;
    textContent += `Сарлавҳа: ${activeConversation.title}\n`;
    textContent += `---------------------------------------------------\n\n`;

    activeConversation.messages.forEach((msg) => {
      const sender = msg.role === 'user' ? 'Корбар' : 'Bill AI (Созанда: Мирзоев Билолиддин)';
      const time = new Date(msg.timestamp).toLocaleTimeString();
      textContent += `[${time}] ${sender}:\n${msg.content}\n\n`;
    });

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bill-ai-chat-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const messageContent = (textToSend ?? input).trim();
    if (!messageContent || isLoading) return;

    setInput('');

    const userMessageId = `user-${Date.now()}`;
    const userMessage: Message = {
      id: userMessageId,
      role: 'user',
      content: messageContent,
      timestamp: Date.now(),
    };

    const assistantMessageId = `assistant-${Date.now() + 1}`;
    const initialAssistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now() + 1,
    };

    // Update conversation title if this is the first message
    const updatedTitle =
      messages.length === 0
        ? messageContent.slice(0, 32) + (messageContent.length > 32 ? '...' : '')
        : activeConversation.title;

    const newMessages = [...messages, userMessage, initialAssistantMessage];

    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id
          ? {
              ...c,
              title: updatedTitle,
              messages: newMessages,
              updatedAt: Date.now(),
            }
          : c
      )
    );

    setIsLoading(true);

    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    try {
      // Send conversation to backend
      const payloadMessages = [...messages, userMessage].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          stream: true,
        }),
        signal: abortController.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Хатогӣ дар сервер: ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedContent = '';

      if (reader) {
        let done = false;
        let buffer = '';

        while (!done) {
          const { value, done: streamDone } = await reader.read();
          done = streamDone;

          if (value) {
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
              const trimmed = line.trim();
              if (trimmed.startsWith('data: ')) {
                const dataStr = trimmed.replace('data: ', '');
                if (dataStr === '[DONE]') {
                  done = true;
                  break;
                }
                try {
                  const parsed = JSON.parse(dataStr);
                  if (parsed.error) {
                    accumulatedContent += `\n\n*(Хатогӣ: ${parsed.error})*`;
                  } else if (parsed.text) {
                    accumulatedContent += parsed.text;
                  }

                  // Update UI with accumulated content
                  setConversations((prev) =>
                    prev.map((c) =>
                      c.id === activeConversation.id
                        ? {
                            ...c,
                            messages: c.messages.map((m) =>
                              m.id === assistantMessageId
                                ? { ...m, content: accumulatedContent }
                                : m
                            ),
                          }
                        : c
                    )
                  );
                } catch (e) {
                  console.error('Error parsing SSE data', e);
                }
              }
            }
          }
        }
      }

      if (isAutoSpeak && accumulatedContent) {
        speakText(accumulatedContent);
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Chat generation aborted by user');
      } else {
        console.error('Chat error:', err);
        const errorText =
          err?.message ||
          'Ҳангоми пайвастшавӣ ба сервер хатогӣ рух дод. Лутфан калиди GEMINI_API_KEY ва пайвасти интернетро санҷед.';

        setConversations((prev) =>
          prev.map((c) =>
            c.id === activeConversation.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          content:
                            m.content ||
                            `Мутаассифона хатогӣ рух дод: ${errorText}\n\nЁдовар мешавем: Созандаи Bill AI Мирзоев Билолиддин мебошад.`,
                        }
                      : m
                  ),
                }
              : c
          )
        );
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
  };

  const handleRegenerate = () => {
    if (isLoading || messages.length === 0) return;

    // Find the last user message
    let lastUserIndex = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'user') {
        lastUserIndex = i;
        break;
      }
    }

    if (lastUserIndex === -1) return;

    const lastUserPrompt = messages[lastUserIndex].content;
    const truncatedMessages = messages.slice(0, lastUserIndex);

    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id ? { ...c, messages: truncatedMessages } : c
      )
    );

    handleSendMessage(lastUserPrompt);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 antialiased select-text">
      {/* Sidebar */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={setActiveConversationId}
        onNewChat={handleNewChat}
        onDeleteConversation={handleDeleteConversation}
        onQuickPrompt={(prompt) => handleSendMessage(prompt)}
        onOpenCreatorModal={() => setIsCreatorModalOpen(true)}
      />

      {/* Main chat layout */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-white dark:bg-slate-900/60 transition-colors">
        <Header
          theme={theme}
          onToggleTheme={handleToggleTheme}
          onNewChat={handleNewChat}
          onClearChat={handleClearChat}
          onExportChat={handleExportChat}
          onOpenCreatorModal={() => setIsCreatorModalOpen(true)}
          isSidebarOpen={isSidebarOpen}
          onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
          isAutoSpeak={isAutoSpeak}
          onToggleAutoSpeak={handleToggleAutoSpeak}
          hasMessages={messages.length > 0}
        />

        <main className="flex-1 flex flex-col overflow-hidden relative">
          <ChatArea
            messages={messages}
            isLoading={isLoading}
            onSendPrompt={(p) => handleSendMessage(p)}
            onRegenerate={handleRegenerate}
            onOpenCreatorModal={() => setIsCreatorModalOpen(true)}
          />

          <ChatInput
            input={input}
            setInput={setInput}
            onSend={handleSendMessage}
            onStop={handleStop}
            isLoading={isLoading}
          />
        </main>
      </div>

      {/* Creator Information Modal */}
      <CreatorModal
        isOpen={isCreatorModalOpen}
        onClose={() => setIsCreatorModalOpen(false)}
        onAskCreatorQuestion={(q) => handleSendMessage(q)}
      />
    </div>
  );
}
