import { useEffect, useState, type ComponentType, type ReactNode } from "react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type PanelType = "wifi" | "bluetooth" | "services" | null;
type ServiceKey = "streaming" | "voice" | "chromecast" | "miracast" | "update";
type UpdateStatus = "idle" | "checking" | "downloading" | "done";
type IconProps = { className?: string };
type LogoProps = { className?: string };

interface AppDef {
  id: string;
  name: string;
  desc: string;
  tile: string;
  Logo: ComponentType<LogoProps>;
}

interface Network {
  id: string;
  name: string;
  secured: boolean;
  signal: number;
}

interface BtDevice {
  id: string;
  name: string;
  type: "audio" | "gamepad" | "phone";
  connected: boolean;
}

interface VoiceCommand {
  phrase: string;
  run: () => void;
}

/* ------------------------------------------------------------------ */
/*  Icons                                                              */
/* ------------------------------------------------------------------ */

function Svg({ className = "h-6 w-6", children }: { className?: string; children: ReactNode }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

function WifiIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M2 8.8a15 15 0 0 1 20 0" />
      <path d="M5.5 12.4a10 10 0 0 1 13 0" />
      <path d="M9 16a5 5 0 0 1 6 0" />
      <circle cx="12" cy="19.5" r="0.8" fill="currentColor" />
    </Svg>
  );
}

function BluetoothIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="m7 7 10 10-5 5V2l5 5L7 17" />
    </Svg>
  );
}

function MicIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="9" y="2" width="6" height="12" rx="3" />
      <path d="M5 10a7 7 0 0 0 14 0" />
      <path d="M12 17v5" />
    </Svg>
  );
}

function CastIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M2 16.1A5 5 0 0 1 5.9 20" />
      <path d="M2 12.05A9 9 0 0 1 9.95 20" />
      <path d="M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6" />
      <path d="M2 20h.01" />
    </Svg>
  );
}

function SlidersIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6" />
    </Svg>
  );
}

function CloseIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </Svg>
  );
}

function CheckIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M20 6 9 17l-5-5" />
    </Svg>
  );
}

function LockIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="4" y="11" width="16" height="10" rx="2" />
      <path d="M8 11V7a4 4 0 0 1 8 0v4" />
    </Svg>
  );
}

function ShieldIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </Svg>
  );
}

function PlayIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <circle cx="12" cy="12" r="10" />
      <path d="m10 8 6 4-6 4z" />
    </Svg>
  );
}

function ScreenIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="2" y="3" width="20" height="14" rx="2" />
      <path d="M8 21h8M12 17v4" />
    </Svg>
  );
}

function RefreshIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M21 12a9 9 0 1 1-2.6-6.4" />
      <path d="M21 4v5h-5" />
    </Svg>
  );
}

function ChevronLeftIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="m15 18-6-6 6-6" />
    </Svg>
  );
}

function AlertIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </Svg>
  );
}

function HeadphonesIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <path d="M3 14v-2a9 9 0 0 1 18 0v2" />
      <rect x="3" y="14" width="4" height="6" rx="1" />
      <rect x="17" y="14" width="4" height="6" rx="1" />
    </Svg>
  );
}

function GamepadIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="2" y="7" width="20" height="10" rx="5" />
      <path d="M7 12h4M9 10v4" />
      <path d="M15.5 11h.01M17.5 13h.01" />
    </Svg>
  );
}

function PhoneIcon({ className }: IconProps) {
  return (
    <Svg className={className}>
      <rect x="7" y="2" width="10" height="20" rx="2" />
      <path d="M11 18h2" />
    </Svg>
  );
}

/* ------------------------------------------------------------------ */
/*  App logos (used in the dock and launch screens)                    */
/* ------------------------------------------------------------------ */

function YouTubeLogo({ className = "h-12 w-12" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <rect x="1.5" y="5" width="21" height="14" rx="4" fill="#fff" />
      <path d="M10 9.3v5.4l4.6-2.7z" fill="#dc2626" />
    </svg>
  );
}

function SpotifyLogo({ className = "h-12 w-12" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <g fill="none" stroke="#000" strokeLinecap="round">
        <path d="M4.5 9.2c4.7-1.4 10.4-1 14.4 1.4" strokeWidth="2.2" />
        <path d="M5.2 12.9c4-1.2 8.8-.8 12.1 1.1" strokeWidth="2" />
        <path d="M6 16.3c3.3-1 6.9-.7 9.6.9" strokeWidth="1.8" />
      </g>
    </svg>
  );
}

function BrowserLogo({ className = "h-12 w-12" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <g fill="none" stroke="#fff" strokeWidth="1.8">
        <circle cx="12" cy="12" r="9.5" />
        <ellipse cx="12" cy="12" rx="4" ry="9.5" />
        <path d="M2.5 12h19" />
      </g>
    </svg>
  );
}

function JioHotstarLogo({ className = "h-12 w-12" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <polygon
        points="12,2.5 14.9,9 21.8,9.4 16.4,13.8 18.2,20.5 12,16.7 5.8,20.5 7.6,13.8 2.2,9.4 9.1,9"
        fill="#fff"
      />
    </svg>
  );
}

function MeldLogo({ className = "h-12 w-12" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="9.5" cy="12" r="6" fill="#fff" fillOpacity="0.95" />
      <circle cx="14.5" cy="12" r="6" fill="#fff" fillOpacity="0.5" />
    </svg>
  );
}

function NetMirrorLogo({ className = "h-12 w-12" }: LogoProps) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <rect x="2" y="3.5" width="20" height="13" rx="2" fill="none" stroke="#fff" strokeWidth="1.8" />
      <path d="M8 20h8M12 16.5V20" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
      <text x="12" y="10.5" textAnchor="middle" dominantBaseline="middle" fontSize="6" fontWeight="800" fill="#ef4444">
        NM
      </text>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  Static data                                                        */
/* ------------------------------------------------------------------ */

const APPS: AppDef[] = [
  {
    id: "youtube",
    name: "YouTube",
    desc: "Videos, shows, music and live streams picked for you.",
    tile: "bg-gradient-to-br from-red-500 to-red-700",
    Logo: YouTubeLogo,
  },
  {
    id: "spotify",
    name: "Spotify",
    desc: "Your favourite music, podcasts and playlists on the big screen.",
    tile: "bg-gradient-to-br from-green-400 to-emerald-600",
    Logo: SpotifyLogo,
  },
  {
    id: "browser",
    name: "Browser",
    desc: "Browse the web, search and open your bookmarks with the remote.",
    tile: "bg-gradient-to-br from-sky-400 to-blue-700",
    Logo: BrowserLogo,
  },
  {
    id: "jiohotstar",
    name: "JioHotstar",
    desc: "Movies, web series, live sports and TV channels in one place.",
    tile: "bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-600",
    Logo: JioHotstarLogo,
  },
  {
    id: "meld",
    name: "Meld",
    desc: "Discover curated shows, clips and entertainment every day.",
    tile: "bg-gradient-to-br from-fuchsia-500 to-violet-700",
    Logo: MeldLogo,
  },
  {
    id: "netmirror",
    name: "NetMirror",
    desc: "Mirror your phone or laptop screen to the TV wirelessly.",
    tile: "bg-gradient-to-br from-zinc-700 to-black",
    Logo: NetMirrorLogo,
  },
];

const appById = (id: string) => APPS.find((a) => a.id === id) ?? APPS[0];

const NETWORKS: Network[] = [
  { id: "n1", name: "ImpexHome_5G", secured: true, signal: 4 },
  { id: "n2", name: "ImpexHome_2.4G", secured: true, signal: 3 },
  { id: "n3", name: "Guest_Network", secured: false, signal: 2 },
  { id: "n4", name: "Neighbour_WiFi", secured: true, signal: 1 },
];

const PAIRED_DEVICES: BtDevice[] = [
  { id: "b1", name: "Impex Soundbar", type: "audio", connected: true },
  { id: "b2", name: "Wireless Headphones", type: "audio", connected: false },
  { id: "b3", name: "Pro Gamepad", type: "gamepad", connected: false },
];

const NEARBY_DEVICES: BtDevice[] = [
  { id: "b4", name: "JBL Flip 6", type: "audio", connected: false },
  { id: "b5", name: "Android Phone", type: "phone", connected: false },
];

const SERVICES: { key: ServiceKey; label: string; desc: string; icon: ComponentType<IconProps> }[] = [
  { key: "streaming", label: "Streaming", desc: "Stream apps and 4K content", icon: PlayIcon },
  { key: "voice", label: "Voice", desc: "Control the TV with your voice", icon: MicIcon },
  { key: "chromecast", label: "Chromecast", desc: "Cast from phones and tablets", icon: CastIcon },
  { key: "miracast", label: "Miracast", desc: "Wireless screen mirroring", icon: ScreenIcon },
  { key: "update", label: "Update Service", desc: "Keeps IMPEX OS up to date", icon: RefreshIcon },
];

const PANEL_TITLES: Record<NonNullable<PanelType>, string> = {
  wifi: "Wi-Fi & Network",
  bluetooth: "Bluetooth",
  services: "Services",
};

/* ------------------------------------------------------------------ */
/*  Small UI building blocks                                           */
/* ------------------------------------------------------------------ */

function Signal({ level }: { level: number }) {
  return (
    <span className="flex h-4 items-end gap-0.5" aria-label={`Signal ${level} of 4`}>
      {[1, 2, 3, 4].map((i) => (
        <span
          key={i}
          className={`w-1 rounded-sm ${i <= level ? "bg-white" : "bg-white/20"}`}
          style={{ height: `${i * 25}%` }}
        />
      ))}
    </span>
  );
}

function Toggle({
  checked,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean;
  onChange: () => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={onChange}
      className={`relative h-8 w-14 shrink-0 rounded-full transition disabled:cursor-not-allowed disabled:opacity-40 ${
        checked ? "bg-emerald-500" : "bg-white/20"
      }`}
    >
      <span
        className={`absolute left-1 top-1 h-6 w-6 rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-6" : ""
        }`}
      />
    </button>
  );
}

function StatusButton({
  icon,
  label,
  value,
  active,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={`${label}: ${value}`}
      className={`flex items-center gap-3 rounded-full border px-4 py-2.5 text-left transition hover:bg-white/15 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 ${
        active ? "border-cyan-400/40 bg-white/10" : "border-white/10 bg-white/5"
      }`}
    >
      <span className={active ? "text-cyan-300" : "text-slate-500"}>{icon}</span>
      <span className="leading-tight">
        <span className="block text-[11px] uppercase tracking-wider text-slate-400">{label}</span>
        <span className="block max-w-[150px] truncate text-sm font-medium text-white">{value}</span>
      </span>
    </button>
  );
}

function RoundButton({
  label,
  onClick,
  highlight = false,
  children,
}: {
  label: string;
  onClick: () => void;
  highlight?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={`flex h-12 w-12 items-center justify-center rounded-full border transition hover:bg-white/15 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 ${
        highlight ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-300" : "border-white/10 bg-white/5 text-white"
      }`}
    >
      {children}
    </button>
  );
}

function QuickTile({
  icon,
  title,
  value,
  sub,
  onClick,
}: {
  icon: ReactNode;
  title: string;
  value: string;
  sub: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col justify-between rounded-3xl border border-white/10 bg-white/5 p-5 text-left transition hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
    >
      <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-cyan-300">{icon}</span>
      <span className="mt-4 block">
        <span className="block text-xs uppercase tracking-wider text-slate-400">{title}</span>
        <span className="block text-2xl font-semibold">{value}</span>
        <span className="block truncate text-sm text-slate-400">{sub}</span>
      </span>
    </button>
  );
}

function DeviceIcon({ type }: { type: BtDevice["type"] }) {
  if (type === "audio") return <HeadphonesIcon className="h-5 w-5" />;
  if (type === "gamepad") return <GamepadIcon className="h-5 w-5" />;
  return <PhoneIcon className="h-5 w-5" />;
}

function SectionTitle({ children }: { children: ReactNode }) {
  return (
    <h3 className="mb-3 mt-8 text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">{children}</h3>
  );
}

/* ------------------------------------------------------------------ */
/*  Main App                                                           */
/* ------------------------------------------------------------------ */

export default function App() {
  const [now, setNow] = useState(() => new Date());
  const [focusIndex, setFocusIndex] = useState(0);
  const [panel, setPanel] = useState<PanelType>(null);
  const [activeApp, setActiveApp] = useState<AppDef | null>(null);
  const [appReady, setAppReady] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [voiceText, setVoiceText] = useState("");
  const [toast, setToast] = useState<string | null>(null);

  const [wifiOn, setWifiOn] = useState(true);
  const [networkId, setNetworkId] = useState("n1");
  const [dnsFiltering, setDnsFiltering] = useState(false);

  const [btOn, setBtOn] = useState(true);
  const [btScanning, setBtScanning] = useState(false);
  const [btDevices, setBtDevices] = useState<BtDevice[]>(PAIRED_DEVICES);

  const [services, setServices] = useState<Record<ServiceKey, boolean>>({
    streaming: true,
    voice: true,
    chromecast: true,
    miracast: false,
    update: true,
  });
  const [updateStatus, setUpdateStatus] = useState<UpdateStatus>("idle");
  const [updateProgress, setUpdateProgress] = useState(0);

  // Clock
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(t);
  }, []);

  // Toast auto-hide
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  // Launch screen: switch from "launching" to "ready"
  useEffect(() => {
    if (!activeApp) return;
    const t = setTimeout(() => setAppReady(true), 1200);
    return () => {
      clearTimeout(t);
      setAppReady(false);
    };
  }, [activeApp]);

  // Remote-control style keyboard support (arrows / Enter / Esc)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (activeApp) setActiveApp(null);
        else if (voiceOpen) setVoiceOpen(false);
        else setPanel(null);
        return;
      }
      if (activeApp || voiceOpen || panel) return;
      if (e.key === "ArrowRight") setFocusIndex((i) => (i + 1) % APPS.length);
      if (e.key === "ArrowLeft") setFocusIndex((i) => (i - 1 + APPS.length) % APPS.length);
      if (e.key === "Enter") launchApp(APPS[focusIndex]);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  /* ---------- derived values ---------- */

  const network = NETWORKS.find((n) => n.id === networkId) ?? NETWORKS[0];
  const connectedCount = btOn ? btDevices.filter((d) => d.connected).length : 0;
  const activeServices = Object.values(services).filter(Boolean).length;
  const castReady = services.chromecast || services.miracast;
  const focusedApp = APPS[focusIndex];
  const timeText = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const dateText = now.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" });

  /* ---------- handlers ---------- */

  const launchApp = (app: AppDef) => {
    setPanel(null);
    setVoiceOpen(false);
    setActiveApp(app);
  };

  // Returns why an app can't run right now (or null if it can)
  const getBlock = (app: AppDef): { message: string; target: PanelType } | null => {
    if (!wifiOn) return { message: "No internet connection. Turn on Wi-Fi to continue.", target: "wifi" };
    if (app.id !== "browser" && !services.streaming)
      return { message: "The streaming service is turned off. Turn it on to use this app.", target: "services" };
    if (app.id === "netmirror" && !castReady)
      return { message: "NetMirror needs Chromecast or Miracast. Turn one on in Services.", target: "services" };
    return null;
  };

  const toggleService = (key: ServiceKey) => {
    const label = SERVICES.find((s) => s.key === key)?.label ?? key;
    const next = !services[key];
    setServices((prev) => ({ ...prev, [key]: next }));
    setToast(`${label} ${next ? "turned on" : "turned off"}`);
  };

  const checkForUpdates = () => {
    if (!services.update || updateStatus === "checking" || updateStatus === "downloading") return;
    setUpdateStatus("checking");
    setTimeout(() => {
      setUpdateStatus("downloading");
      setUpdateProgress(0);
      let p = 0;
      const iv = setInterval(() => {
        p += 8;
        if (p >= 100) {
          clearInterval(iv);
          setUpdateProgress(100);
          setUpdateStatus("done");
        } else {
          setUpdateProgress(p);
        }
      }, 150);
    }, 1200);
  };

  const scanDevices = () => {
    setBtScanning(true);
    setTimeout(() => {
      setBtDevices((prev) => [...prev, ...NEARBY_DEVICES.filter((n) => !prev.some((p) => p.id === n.id))]);
      setBtScanning(false);
      setToast("Scan complete");
    }, 1800);
  };

  const toggleDevice = (id: string) =>
    setBtDevices((prev) => prev.map((d) => (d.id === id ? { ...d, connected: !d.connected } : d)));

  const openVoice = () => {
    if (!services.voice) {
      setPanel("services");
      setToast("Voice is off. Turn it on here.");
      return;
    }
    setVoiceText("");
    setVoiceBusy(false);
    setVoiceOpen(true);
  };

  const VOICE_COMMANDS: VoiceCommand[] = [
    { phrase: "Open YouTube", run: () => launchApp(appById("youtube")) },
    { phrase: "Play music on Spotify", run: () => launchApp(appById("spotify")) },
    {
      phrase: "Turn on Bluetooth",
      run: () => {
        setBtOn(true);
        setToast("Bluetooth turned on");
      },
    },
    {
      phrase: "Turn off Wi-Fi",
      run: () => {
        setWifiOn(false);
        setToast("Wi-Fi turned off");
      },
    },
    {
      phrase: "Check for updates",
      run: () => {
        setPanel("services");
        checkForUpdates();
      },
    },
  ];

  const runVoice = (cmd: VoiceCommand) => {
    setVoiceBusy(true);
    setVoiceText(cmd.phrase);
    setTimeout(() => {
      setVoiceOpen(false);
      setVoiceBusy(false);
      setVoiceText("");
      cmd.run();
    }, 900);
  };

  const blocked = activeApp ? getBlock(activeApp) : null;

  const updateMessage = !services.update
    ? "Update service is turned off"
    : updateStatus === "checking"
      ? "Checking for updates…"
      : updateStatus === "downloading"
        ? `Downloading update… ${updateProgress}%`
        : updateStatus === "done"
          ? "Your TV is up to date"
          : "Tap below to check for the latest software";

  /* ---------- render ---------- */

  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 font-sans text-white">
      {/* Decorative ambient glow */}
      <div className="pointer-events-none absolute -left-40 -top-40 h-[520px] w-[520px] rounded-full bg-cyan-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -right-40 h-[520px] w-[520px] rounded-full bg-purple-500/10 blur-3xl" />

      {/* ============ HEADER ============ */}
      <header className="relative z-10 flex items-center justify-between px-10 pt-7">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 text-xl font-black shadow-lg shadow-cyan-500/30">
            I
          </div>
          <div>
            <p className="text-lg font-bold tracking-[0.3em]">IMPEX</p>
            <p className="text-[11px] uppercase tracking-widest text-slate-400">Smart TV</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {castReady && (
            <div className="hidden items-center gap-2 rounded-full bg-emerald-500/15 px-3 py-2 text-xs font-medium text-emerald-300 md:flex">
              <CastIcon className="h-4 w-4" />
              Cast ready
            </div>
          )}

          {/* Wi-Fi and Bluetooth buttons sit side by side */}
          <StatusButton
            label="Wi-Fi"
            value={wifiOn ? network.name : "Off"}
            active={wifiOn}
            onClick={() => setPanel("wifi")}
            icon={<WifiIcon className="h-5 w-5" />}
          />
          <StatusButton
            label="Bluetooth"
            value={btOn ? (connectedCount ? `${connectedCount} connected` : "On") : "Off"}
            active={btOn}
            onClick={() => setPanel("bluetooth")}
            icon={<BluetoothIcon className="h-5 w-5" />}
          />

          <RoundButton label="Voice assistant" onClick={openVoice} highlight={services.voice}>
            <MicIcon className="h-5 w-5" />
          </RoundButton>
          <RoundButton label="Services" onClick={() => setPanel("services")}>
            <SlidersIcon className="h-5 w-5" />
          </RoundButton>

          <div className="ml-3 border-l border-white/10 pl-5 text-right">
            <p className="text-2xl font-semibold tabular-nums">{timeText}</p>
            <p className="text-xs text-slate-400">{dateText}</p>
          </div>
        </div>
      </header>

      {/* ============ HERO + QUICK TILES ============ */}
      <main className="relative z-10 grid min-h-0 flex-1 grid-cols-3 gap-6 px-10 pt-8">
        <section className={`relative col-span-2 overflow-hidden rounded-[2rem] p-10 shadow-2xl ${focusedApp.tile}`}>
          <div key={focusedApp.id} className="animate-fade-up relative z-10 flex h-full flex-col justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.25em] text-white/70">Selected app</p>
              <h1 className="mt-3 text-6xl font-bold tracking-tight">{focusedApp.name}</h1>
              <p className="mt-4 max-w-md text-lg text-white/85">{focusedApp.desc}</p>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => launchApp(focusedApp)}
                className="rounded-full bg-white px-8 py-3.5 font-semibold text-slate-900 shadow-lg transition hover:scale-105"
              >
                Open {focusedApp.name}
              </button>
              <span className="text-sm text-white/70">Press Enter to open</span>
            </div>
          </div>
          <focusedApp.Logo className="pointer-events-none absolute -bottom-12 -right-12 h-72 w-72 opacity-20" />
        </section>

        <section className="grid grid-cols-2 grid-rows-2 gap-5">
          <QuickTile
            icon={<WifiIcon className="h-5 w-5" />}
            title="Network"
            value={wifiOn ? "Online" : "Offline"}
            sub={wifiOn ? network.name : "Wi-Fi is off"}
            onClick={() => setPanel("wifi")}
          />
          <QuickTile
            icon={<BluetoothIcon className="h-5 w-5" />}
            title="Bluetooth"
            value={btOn ? "On" : "Off"}
            sub={`${connectedCount} device${connectedCount === 1 ? "" : "s"} connected`}
            onClick={() => setPanel("bluetooth")}
          />
          <QuickTile
            icon={<ShieldIcon className="h-5 w-5" />}
            title="Router DNS filtering"
            value={dnsFiltering ? "On" : "Off"}
            sub={dnsFiltering ? "Filtering active" : "No filtering"}
            onClick={() => setPanel("wifi")}
          />
          <QuickTile
            icon={<SlidersIcon className="h-5 w-5" />}
            title="Services"
            value={`${activeServices}/${SERVICES.length}`}
            sub="services active"
            onClick={() => setPanel("services")}
          />
        </section>
      </main>

      {/* ============ DOCK ============ */}
      <footer className="relative z-10 px-10 pb-8 pt-8">
        <div className="mb-4 flex items-center justify-between px-2">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-slate-400">Dock</p>
          <p className="text-xs text-slate-500">6 apps · ← → to move · Enter to open</p>
        </div>

        <div className="mx-auto flex items-end justify-center gap-5 rounded-[2rem] border border-white/10 bg-white/10 px-8 py-6 backdrop-blur-xl">
          {APPS.map((app, i) => {
            const focused = i === focusIndex;
            return (
              <button
                key={app.id}
                aria-label={`Open ${app.name}`}
                onMouseEnter={() => setFocusIndex(i)}
                onFocus={() => setFocusIndex(i)}
                onClick={() => launchApp(app)}
                className={`flex flex-col items-center gap-3 transition-transform duration-200 focus:outline-none ${
                  focused ? "-translate-y-2 scale-110" : "opacity-75 hover:opacity-100"
                }`}
              >
                <span
                  className={`flex h-24 w-24 items-center justify-center rounded-2xl shadow-xl transition ${app.tile} ${
                    focused ? "ring-4 ring-white shadow-white/20" : ""
                  }`}
                >
                  <app.Logo className="h-12 w-12" />
                </span>
                <span className={`text-sm font-medium ${focused ? "text-white" : "text-slate-400"}`}>{app.name}</span>
              </button>
            );
          })}
        </div>

        {/* Service status chips */}
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          {SERVICES.map((s) => (
            <button
              key={s.key}
              onClick={() => setPanel("services")}
              className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/10"
            >
              <span className={`h-2 w-2 rounded-full ${services[s.key] ? "bg-emerald-400" : "bg-slate-600"}`} />
              {s.label}
            </button>
          ))}
        </div>
      </footer>

      {/* ============ SIDE PANELS ============ */}
      {panel && (
        <div className="fixed inset-0 z-40 flex justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setPanel(null)} />
          <aside className="animate-slide-in relative flex h-full w-[460px] max-w-full flex-col overflow-y-auto border-l border-white/10 bg-slate-900 p-8 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-semibold">{PANEL_TITLES[panel]}</h2>
              <button
                onClick={() => setPanel(null)}
                aria-label="Close panel"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"
              >
                <CloseIcon className="h-5 w-5" />
              </button>
            </div>

            {/* ---- Wi-Fi ---- */}
            {panel === "wifi" && (
              <>
                <div className="flex items-center justify-between rounded-2xl bg-white/5 p-5">
                  <div>
                    <p className="font-semibold">Wi-Fi</p>
                    <p className="text-sm text-slate-400">{wifiOn ? `Connected to ${network.name}` : "Turned off"}</p>
                  </div>
                  <Toggle
                    label="Wi-Fi"
                    checked={wifiOn}
                    onChange={() => {
                      setWifiOn(!wifiOn);
                      setToast(wifiOn ? "Wi-Fi turned off" : "Wi-Fi turned on");
                    }}
                  />
                </div>

                <SectionTitle>Available networks</SectionTitle>
                <ul className="space-y-3">
                  {NETWORKS.map((n) => {
                    const isCurrent = n.id === networkId;
                    return (
                      <li key={n.id}>
                        <button
                          disabled={!wifiOn}
                          onClick={() => {
                            setNetworkId(n.id);
                            setToast(`Connected to ${n.name}`);
                          }}
                          className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left transition disabled:opacity-40 ${
                            isCurrent ? "border-cyan-400/50 bg-cyan-400/10" : "border-white/10 bg-white/5 hover:bg-white/10"
                          }`}
                        >
                          <span className="flex items-center gap-3">
                            <WifiIcon className="h-5 w-5 text-slate-300" />
                            <span>
                              <span className="block font-medium">{n.name}</span>
                              <span className="flex items-center gap-1 text-xs text-slate-400">
                                {n.secured ? (
                                  <>
                                    <LockIcon className="h-3 w-3" /> Secured
                                  </>
                                ) : (
                                  "Open network"
                                )}
                              </span>
                            </span>
                          </span>
                          <span className="flex items-center gap-3">
                            <Signal level={n.signal} />
                            {isCurrent && <CheckIcon className="h-5 w-5 text-cyan-300" />}
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>

                <SectionTitle>Router</SectionTitle>
                <div className="rounded-2xl bg-white/5 p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ShieldIcon className="h-5 w-5 text-slate-300" />
                      <div>
                        <p className="font-semibold">DNS filtering</p>
                        <p className="text-sm text-slate-400">Router DNS filtering: {dnsFiltering ? "On" : "Off"}</p>
                      </div>
                    </div>
                    <Toggle
                      label="Router DNS filtering"
                      checked={dnsFiltering}
                      onChange={() => {
                        setDnsFiltering(!dnsFiltering);
                        setToast(dnsFiltering ? "DNS filtering off" : "DNS filtering on");
                      }}
                    />
                  </div>
                </div>
              </>
            )}

            {/* ---- Bluetooth ---- */}
            {panel === "bluetooth" && (
              <>
                <div className="flex items-center justify-between rounded-2xl bg-white/5 p-5">
                  <div>
                    <p className="font-semibold">Bluetooth</p>
                    <p className="text-sm text-slate-400">{btOn ? "Visible to nearby devices" : "Turned off"}</p>
                  </div>
                  <Toggle
                    label="Bluetooth"
                    checked={btOn}
                    onChange={() => {
                      setBtOn(!btOn);
                      setToast(btOn ? "Bluetooth turned off" : "Bluetooth turned on");
                    }}
                  />
                </div>

                <button
                  disabled={!btOn || btScanning}
                  onClick={scanDevices}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-white/10 py-3 font-medium transition hover:bg-white/15 disabled:opacity-40"
                >
                  <RefreshIcon className={`h-4 w-4 ${btScanning ? "animate-spin" : ""}`} />
                  {btScanning ? "Scanning…" : "Scan for devices"}
                </button>

                <SectionTitle>Devices</SectionTitle>
                <ul className="space-y-3">
                  {btDevices.map((d) => (
                    <li key={d.id} className="flex items-center justify-between rounded-2xl bg-white/5 p-4">
                      <div className="flex items-center gap-3">
                        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-cyan-300">
                          <DeviceIcon type={d.type} />
                        </span>
                        <div>
                          <p className="font-medium">{d.name}</p>
                          <p className="text-xs text-slate-400">
                            {!btOn ? "Bluetooth off" : d.connected ? "Connected" : "Paired"}
                          </p>
                        </div>
                      </div>
                      <button
                        disabled={!btOn}
                        onClick={() => toggleDevice(d.id)}
                        className={`rounded-full px-4 py-1.5 text-sm font-medium transition disabled:opacity-40 ${
                          d.connected ? "bg-white/10 hover:bg-white/20" : "bg-cyan-500 text-slate-900 hover:bg-cyan-400"
                        }`}
                      >
                        {d.connected ? "Disconnect" : "Connect"}
                      </button>
                    </li>
                  ))}
                </ul>
              </>
            )}

            {/* ---- Services ---- */}
            {panel === "services" && (
              <>
                <p className="text-sm text-slate-400">Turn TV features on or off.</p>
                <ul className="mt-6 space-y-3">
                  {SERVICES.map((s) => {
                    const Icon = s.icon;
                    const on = services[s.key];
                    return (
                      <li key={s.key} className="flex items-center justify-between rounded-2xl bg-white/5 p-4">
                        <div className="flex items-center gap-4">
                          <span
                            className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                              on ? "bg-emerald-500/20 text-emerald-300" : "bg-white/10 text-slate-400"
                            }`}
                          >
                            <Icon className="h-5 w-5" />
                          </span>
                          <div>
                            <p className="font-medium">{s.label}</p>
                            <p className="text-xs text-slate-400">{s.desc}</p>
                          </div>
                        </div>
                        <Toggle label={s.label} checked={on} onChange={() => toggleService(s.key)} />
                      </li>
                    );
                  })}
                </ul>

                <SectionTitle>Software update</SectionTitle>
                <div className="rounded-2xl bg-white/5 p-5">
                  <p className="font-semibold">IMPEX OS 4.2.1</p>
                  <p className="text-sm text-slate-400">{updateMessage}</p>
                  {updateStatus === "downloading" && (
                    <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-200"
                        style={{ width: `${updateProgress}%` }}
                      />
                    </div>
                  )}
                  <button
                    disabled={!services.update || updateStatus === "checking" || updateStatus === "downloading"}
                    onClick={checkForUpdates}
                    className="mt-4 w-full rounded-2xl bg-white/10 py-3 font-medium transition hover:bg-white/15 disabled:opacity-40"
                  >
                    {updateStatus === "checking" || updateStatus === "downloading"
                      ? "Please wait…"
                      : updateStatus === "done"
                        ? "Check again"
                        : "Check for updates"}
                  </button>
                </div>

                <SectionTitle>About</SectionTitle>
                <dl className="space-y-3 rounded-2xl bg-white/5 p-5 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-slate-400">Model</dt>
                    <dd className="font-medium">Impex Smart TV</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-slate-400">Dock size</dt>
                    <dd className="font-medium">6 apps</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-slate-400">Router DNS filtering</dt>
                    <dd className="font-medium">{dnsFiltering ? "On" : "Off"}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-slate-400">Software</dt>
                    <dd className="font-medium">IMPEX OS 4.2.1</dd>
                  </div>
                </dl>
              </>
            )}
          </aside>
        </div>
      )}

      {/* ============ VOICE OVERLAY ============ */}
      {voiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6 backdrop-blur-sm">
          <div className="animate-fade-up relative w-full max-w-lg rounded-[2rem] border border-white/10 bg-slate-900 p-8 text-center shadow-2xl">
            <button
              onClick={() => setVoiceOpen(false)}
              aria-label="Close voice assistant"
              className="absolute right-5 top-5 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"
            >
              <CloseIcon className="h-5 w-5" />
            </button>

            <div className="relative mx-auto flex h-24 w-24 items-center justify-center">
              {!voiceBusy && <span className="absolute inset-0 animate-ping rounded-full bg-cyan-400/30" />}
              <span
                className={`relative flex h-16 w-16 items-center justify-center rounded-full bg-cyan-500 text-slate-900 ${
                  voiceBusy ? "animate-pulse" : ""
                }`}
              >
                <MicIcon className="h-7 w-7" />
              </span>
            </div>

            <h2 className="mt-6 text-2xl font-semibold">{voiceBusy ? `"${voiceText}"` : "How can I help?"}</h2>
            <p className="mt-2 text-sm text-slate-400">{voiceBusy ? "Working on it…" : "Tap a command to try it"}</p>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {VOICE_COMMANDS.map((cmd) => (
                <button
                  key={cmd.phrase}
                  disabled={voiceBusy}
                  onClick={() => runVoice(cmd)}
                  className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm transition hover:bg-white/15 disabled:opacity-40"
                >
                  {cmd.phrase}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ============ APP LAUNCH / PLAYBACK SCREEN ============ */}
      {activeApp && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950 animate-fade-up">
          <div className={`absolute inset-0 opacity-25 ${activeApp.tile}`} />
          <div className="relative flex h-full flex-col p-10">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setActiveApp(null)}
                className="flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 font-medium transition hover:bg-white/20"
              >
                <ChevronLeftIcon className="h-5 w-5" />
                Back
              </button>
              <p className="text-lg font-semibold">{activeApp.name}</p>
            </div>

            <div className="flex flex-1 items-center justify-center">
              {!appReady ? (
                <div className="text-center">
                  <span
                    className={`mx-auto flex h-32 w-32 animate-pulse items-center justify-center rounded-3xl shadow-2xl ${activeApp.tile}`}
                  >
                    <activeApp.Logo className="h-16 w-16" />
                  </span>
                  <p className="mt-6 text-lg text-slate-300">Launching {activeApp.name}…</p>
                </div>
              ) : blocked ? (
                <div className="max-w-lg animate-fade-up rounded-3xl border border-amber-400/30 bg-slate-900/80 p-8 text-center backdrop-blur">
                  <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/15 text-amber-300">
                    <AlertIcon className="h-8 w-8" />
                  </span>
                  <h2 className="mt-5 text-2xl font-semibold">Can't open {activeApp.name}</h2>
                  <p className="mt-2 text-slate-300">{blocked.message}</p>
                  <button
                    onClick={() => {
                      const target = blocked.target;
                      setActiveApp(null);
                      setPanel(target);
                    }}
                    className="mt-6 rounded-full bg-white px-6 py-3 font-semibold text-slate-900 transition hover:scale-105"
                  >
                    Fix in settings
                  </button>
                </div>
              ) : (
                <div className="w-full max-w-5xl animate-fade-up">
                  {activeApp.id === "browser" && (
                    <div className="mb-8 flex items-center gap-3 rounded-full border border-white/10 bg-white/10 px-6 py-4 text-slate-300">
                      <span className="text-slate-400">🔍</span>
                      Search or enter address
                    </div>
                  )}
                  <h2 className="mb-5 text-2xl font-semibold">
                    {activeApp.id === "browser" ? "Bookmarks" : `Featured on ${activeApp.name}`}
                  </h2>
                  <div className="grid grid-cols-4 gap-5">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                      <div
                        key={n}
                        className="flex aspect-video items-end rounded-2xl border border-white/10 bg-white/10 p-4 backdrop-blur"
                      >
                        <span className="text-sm font-medium text-white/90">
                          {activeApp.id === "browser" ? `Bookmark ${n}` : `Title ${n}`}
                        </span>
                      </div>
                    ))}
                  </div>
                  <p className="mt-6 text-xs text-slate-400">Demo preview. Content is simulated.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ============ TOAST ============ */}
      {toast && (
        <div className="pointer-events-none fixed bottom-6 left-1/2 z-[60] -translate-x-1/2 animate-fade-up rounded-full bg-white px-6 py-3 text-sm font-medium text-slate-900 shadow-2xl">
          {toast}
        </div>
      )}
    </div>
  );
}
