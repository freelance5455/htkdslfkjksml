import React, { useState, useEffect } from 'react';
import {
  ClassInfo,
  ClassSyllabus,
  Language,
  ParchiExam,
  Student,
} from './types';
import {
  INITIAL_CLASSES,
  INITIAL_STUDENTS,
  INITIAL_SYLLABUS,
  INITIAL_PARCHI_EXAMS,
} from './data/initialData';
import { translations } from './utils/translations';
import { Navbar } from './components/Navbar';
import { HomeOverviewView } from './components/HomeOverviewView';
import { ClassScheduleView } from './components/ClassScheduleView';
import { StudentDirectoryView } from './components/StudentDirectoryView';
import { AttendanceWhatsAppView } from './components/AttendanceWhatsAppView';
import { FeeTrackerView } from './components/FeeTrackerView';
import { SyllabusView } from './components/SyllabusView';
import { ParchiMakerView } from './components/ParchiMakerView';
import { GraduatesView } from './components/GraduatesView';
import { CenterMediaView } from './components/CenterMediaView';
import { GoogleDriveSyncView } from './components/GoogleDriveSyncView';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
} from './services/googleDriveService';
import { User } from 'firebase/auth';

export default function App() {
  // 1. Language state (en, ps, ur)
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('rahbar_lang');
    return (saved as Language) || 'en';
  });

  // 2. Active Tab
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [syllabusTargetLevel, setSyllabusTargetLevel] = useState<string | undefined>(undefined);

  // 3. Classes Data
  const [classes, setClasses] = useState<ClassInfo[]>(() => {
    const saved = localStorage.getItem('rahbar_classes');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_CLASSES;
  });

  // 4. Students Data
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('rahbar_students');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_STUDENTS;
  });

  // 5. Syllabus
  const [syllabusList] = useState<ClassSyllabus[]>(INITIAL_SYLLABUS);

  // 6. Test Papers (Parchi)
  const [parchis, setParchis] = useState<ParchiExam[]>(() => {
    const saved = localStorage.getItem('rahbar_parchis');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_PARCHI_EXAMS;
  });

  // 7. Center Branding & Media
  const [centerLogoUrl, setCenterLogoUrl] = useState<string>(() => {
    return (
      localStorage.getItem('rahbar_logo') ||
      'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=300&q=80'
    );
  });

  const [centerVideoUrl, setCenterVideoUrl] = useState<string>(() => {
    return (
      localStorage.getItem('rahbar_video') ||
      'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
    );
  });

  // 8. Google Drive Auth
  const [googleUser, setGoogleUser] = useState<User | null>(null);

  // Persist State to localStorage
  useEffect(() => {
    localStorage.setItem('rahbar_lang', lang);
    document.documentElement.dir = lang === 'en' ? 'ltr' : 'rtl';
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('rahbar_classes', JSON.stringify(classes));
  }, [classes]);

  useEffect(() => {
    localStorage.setItem('rahbar_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('rahbar_parchis', JSON.stringify(parchis));
  }, [parchis]);

  useEffect(() => {
    localStorage.setItem('rahbar_logo', centerLogoUrl);
  }, [centerLogoUrl]);

  useEffect(() => {
    localStorage.setItem('rahbar_video', centerVideoUrl);
  }, [centerVideoUrl]);

  // Initialize Firebase Auth listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (user) => setGoogleUser(user),
      () => setGoogleUser(null)
    );
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Handlers for Google Auth
  const handleGoogleSignIn = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
      }
    } catch (e: any) {
      alert(`Google Sign-In: ${e.message || 'Error occurred'}`);
    }
  };

  const handleGoogleSignOut = async () => {
    await logoutGoogle();
    setGoogleUser(null);
  };

  // Student Actions
  const handleAddStudent = (newStudent: Omit<Student, 'id'>) => {
    const student: Student = {
      ...newStudent,
      id: 'std_' + Date.now(),
    };
    setStudents((prev) => [student, ...prev]);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === updatedStudent.id ? updatedStudent : s))
    );
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== studentId));
  };

  const handleToggleFeeStatus = (studentId: string) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const nextStatus = s.feeStatus === 'paid' ? 'unpaid' : 'paid';
          return {
            ...s,
            feeStatus: nextStatus,
            feePaidDate:
              nextStatus === 'paid'
                ? new Date().toISOString().split('T')[0]
                : undefined,
          };
        }
        return s;
      })
    );
  };

  const handleGraduateStudent = (
    studentId: string,
    gradDate: string,
    gradTime: string
  ) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          return {
            ...s,
            isGraduated: true,
            graduationDate: gradDate,
            graduationTime: gradTime,
            graduationRemarks:
              s.graduationRemarks ||
              'Successfully completed English Language Diploma at Rahbar English Center.',
          };
        }
        return s;
      })
    );
  };

  const handleUpdateAttendance = (
    studentId: string,
    date: string,
    status: 'present' | 'absent' | 'leave'
  ) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const existing = s.attendanceHistory || [];
          const recordIndex = existing.findIndex((r) => r.date === date);
          let updatedHistory = [...existing];
          if (recordIndex >= 0) {
            updatedHistory[recordIndex] = {
              ...updatedHistory[recordIndex],
              status,
            };
          } else {
            updatedHistory.push({ date, status });
          }

          // Recount days attended
          const presentDays = updatedHistory.filter(
            (r) => r.status === 'present'
          ).length;

          return {
            ...s,
            attendanceHistory: updatedHistory,
            monthlyAttendancePresentDays: Math.min(
              s.monthlyTotalWorkingDays,
              Math.max(1, presentDays)
            ),
          };
        }
        return s;
      })
    );
  };

  const handleMarkWhatsappSent = (studentId: string, date: string) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const updatedHistory = (s.attendanceHistory || []).map((r) => {
            if (r.date === date) {
              return {
                ...r,
                notifiedWhatsApp: true,
                notifiedAt: new Date().toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
              };
            }
            return r;
          });
          return { ...s, attendanceHistory: updatedHistory };
        }
        return s;
      })
    );
  };

  const handleUpdateClassPhoto = (classId: string, newUrl: string) => {
    setClasses((prev) =>
      prev.map((c) => (c.id === classId ? { ...c, imageUrl: newUrl } : c))
    );
  };

  const handleSaveParchi = (parchi: ParchiExam) => {
    setParchis((prev) => {
      const idx = prev.findIndex((p) => p.id === parchi.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = parchi;
        return next;
      }
      return [parchi, ...prev];
    });
  };

  const handleNavigateToSyllabus = (levelId: string) => {
    setSyllabusTargetLevel(levelId);
    setCurrentTab('syllabus');
  };

  const t = translations[lang];

  return (
    <div
      dir={lang === 'en' ? 'ltr' : 'rtl'}
      className={`min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans transition-all`}
    >
      {/* Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        lang={lang}
        setLang={setLang}
        googleUser={googleUser}
        onGoogleSignIn={handleGoogleSignIn}
        onGoogleSignOut={handleGoogleSignOut}
        centerLogoUrl={centerLogoUrl}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-8">
        {currentTab === 'home' && (
          <HomeOverviewView
            students={students}
            classes={classes}
            lang={lang}
            onNavigate={setCurrentTab}
            centerLogoUrl={centerLogoUrl}
          />
        )}

        {currentTab === 'classes' && (
          <ClassScheduleView
            classes={classes}
            lang={lang}
            onUpdateClassPhoto={handleUpdateClassPhoto}
            onNavigateToSyllabus={handleNavigateToSyllabus}
          />
        )}

        {currentTab === 'students' && (
          <StudentDirectoryView
            students={students}
            classes={classes}
            lang={lang}
            onAddStudent={handleAddStudent}
            onUpdateStudent={handleUpdateStudent}
            onDeleteStudent={handleDeleteStudent}
            onToggleFeeStatus={handleToggleFeeStatus}
            onGraduateStudent={handleGraduateStudent}
          />
        )}

        {currentTab === 'attendance' && (
          <AttendanceWhatsAppView
            students={students}
            classes={classes}
            lang={lang}
            onUpdateAttendance={handleUpdateAttendance}
            onMarkWhatsappSent={handleMarkWhatsappSent}
          />
        )}

        {currentTab === 'fees' && (
          <FeeTrackerView
            students={students}
            classes={classes}
            lang={lang}
            onToggleFeeStatus={handleToggleFeeStatus}
          />
        )}

        {currentTab === 'syllabus' && (
          <SyllabusView
            syllabusList={syllabusList}
            lang={lang}
            defaultLevelId={syllabusTargetLevel}
          />
        )}

        {currentTab === 'parchi' && (
          <ParchiMakerView
            classes={classes}
            lang={lang}
            parchis={parchis}
            onSaveParchi={handleSaveParchi}
            isGoogleDriveConnected={!!googleUser}
            onConnectGoogle={handleGoogleSignIn}
          />
        )}

        {currentTab === 'graduates' && (
          <GraduatesView
            students={students}
            classes={classes}
            lang={lang}
          />
        )}

        {currentTab === 'media' && (
          <CenterMediaView
            lang={lang}
            centerVideoUrl={centerVideoUrl}
            onUpdateVideoUrl={setCenterVideoUrl}
            centerLogoUrl={centerLogoUrl}
            onUpdateLogoUrl={setCenterLogoUrl}
          />
        )}

        {currentTab === 'drive' && (
          <GoogleDriveSyncView
            lang={lang}
            googleUser={googleUser}
            onGoogleSignIn={handleGoogleSignIn}
            onGoogleSignOut={handleGoogleSignOut}
            students={students}
            classes={classes}
            parchis={parchis}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="no-print bg-slate-950 text-slate-400 border-t border-slate-800 text-xs py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <img
              src={centerLogoUrl}
              alt="Logo"
              className="w-8 h-8 rounded-lg object-cover ring-1 ring-emerald-500"
            />
            <div>
              <span className="font-extrabold text-white block">
                {t.centerName}
              </span>
              <span className="text-[11px] text-slate-500">
                {t.address} | Balochistan, Pakistan
              </span>
            </div>
          </div>

          <div className="text-[11px] text-slate-500">
            Elementary A to Advanced English Diploma • All Rights Reserved © 2026
          </div>
        </div>
      </footer>
    </div>
  );
}
