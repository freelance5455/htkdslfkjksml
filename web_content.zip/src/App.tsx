import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Scanner from './components/Scanner';
import AILearningHub from './components/AILearningHub';
import ExamCenter from './components/ExamCenter';
import HomeworkSolver from './components/HomeworkSolver';
import GovtExamHub from './components/GovtExamHub';
import SavedContent from './components/SavedContent';
import ProfileView from './components/ProfileView';
import OnboardingModal from './components/OnboardingModal';
import GlobalSearchModal from './components/GlobalSearchModal';
import NotificationBell from './components/NotificationBell';
import NotificationCenterModal from './components/NotificationCenterModal';
import ForegroundNotificationBanner from './components/ForegroundNotificationBanner';
import LanguageSelectionModal from './components/LanguageSelectionModal';
import SplashScreen from './components/SplashScreen';
import LearnIcon from './components/LearnIcon';
import { t, ALL_SUPPORTED_LANGUAGES } from './lib/translations';
import {
  initForegroundNotificationWatcher,
  registerDeviceWithServer
} from './services/notificationService';

import { 
  StudyPlanItem, 
  ProgressReport, 
  ExamType, 
  Language, 
  UserProfile, 
  SavedItem 
} from './types';
import { 
  INITIAL_STUDY_PLAN,
  INITIAL_STUDY_PLAN_EN,
  INDIAN_LANGUAGES, 
  DEFAULT_USER_PROFILE 
} from './presets';
import { 
  Sparkles, 
  GraduationCap, 
  ClipboardList, 
  Heart, 
  Camera, 
  Home, 
  User, 
  Award,
  HelpCircle,
  Building2,
  Bookmark,
  UserCheck,
  BookOpen,
  Globe
} from 'lucide-react';

export default function App() {
  // User Profile state with LocalStorage persistence
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('edumind_user_profile');
      if (saved) {
        const parsed = JSON.parse(saved);
        const hasActivePro = parsed.isPro === true && localStorage.getItem('edumind_is_pro') === 'true';
        return {
          ...DEFAULT_USER_PROFILE,
          ...parsed,
          isPro: hasActivePro,
          role: parsed.role || (localStorage.getItem('edumind_admin_token') ? 'admin' : 'user')
        };
      }
    } catch (e) {}
    return DEFAULT_USER_PROFILE;
  });

  const [savedItems, setSavedItems] = useState<SavedItem[]>(() => {
    try {
      const saved = localStorage.getItem('edumind_saved_items');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('edumind_language');
      if (saved && ALL_SUPPORTED_LANGUAGES.some(l => l.code === saved)) {
        return saved as Language;
      }
    } catch (e) {}
    return 'en';
  });

  const [currentTab, setTab] = useState<string>('dashboard');
  const [examPrep, setExamPrep] = useState<ExamType>(userProfile.targetExam as ExamType || 'SSC CHSL');
  const [studyPlan, setStudyPlan] = useState<StudyPlanItem[]>(() => {
    try {
      const savedLang = localStorage.getItem('edumind_language');
      return savedLang === 'bn' ? INITIAL_STUDY_PLAN : INITIAL_STUDY_PLAN_EN;
    } catch (e) {
      return INITIAL_STUDY_PLAN_EN;
    }
  });
  const [isGeneratingPlan, setIsGeneratingPlan] = useState<boolean>(false);
  const [activeVoiceTeacher, setActiveVoiceTeacher] = useState<boolean>(false);
  
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [showOnboarding, setShowOnboarding] = useState<boolean>(!userProfile.onboardingCompleted);
  const [showGlobalSearch, setShowGlobalSearch] = useState<boolean>(false);
  const [showNotificationCenter, setShowNotificationCenter] = useState<boolean>(false);
  const [showLanguageModal, setShowLanguageModal] = useState<boolean>(false);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(0);
  const [hasNewAlertAnimation, setHasNewAlertAnimation] = useState<boolean>(false);

  // Stats tracking
  const [progress, setProgress] = useState<ProgressReport>({
    studyTimeMinutes: 45,
    questionsAsked: 12,
    quizzesTaken: 4,
    averageScore: 85,
    completedTasks: 1,
    weakTopics: [],
    completedChapters: []
  });

  // Persistence effects
  useEffect(() => {
    try {
      localStorage.setItem('edumind_user_profile', JSON.stringify(userProfile));
    } catch (e) {}
  }, [userProfile]);

  useEffect(() => {
    try {
      localStorage.setItem('edumind_saved_items', JSON.stringify(savedItems));
    } catch (e) {}
  }, [savedItems]);

  useEffect(() => {
    try {
      localStorage.setItem('edumind_language', language);
    } catch (e) {}

    // Synchronize default initial study plan if user hasn't generated a custom one
    setStudyPlan(prev => {
      const isInitialEn = prev.some(p => p.id === 'p1' && p.day === 'Monday');
      const isInitialBn = prev.some(p => p.id === 'p1' && p.day === 'সোমবার');
      if (isInitialEn || isInitialBn) {
        return language === 'bn' ? INITIAL_STUDY_PLAN : INITIAL_STUDY_PLAN_EN;
      }
      return prev;
    });
  }, [language]);

  // Sync profile targetExam with state
  useEffect(() => {
    if (userProfile.targetExam) {
      setExamPrep(userProfile.targetExam as ExamType);
    }
    // Verify Pro validity on mount
    if (userProfile.isPro && userProfile.proExpiryDate) {
      if (new Date(userProfile.proExpiryDate).getTime() < Date.now()) {
        setUserProfile(prev => ({ ...prev, isPro: false }));
        try {
          localStorage.removeItem('edumind_is_pro');
        } catch (e) {}
      }
    }
  }, [userProfile.targetExam]);

  // Push Notification & Device Token Registration & Foreground Watcher
  useEffect(() => {
    const currentUserId = userProfile.id || userProfile.phone || userProfile.email || 'guest_user';
    const currentExam = userProfile.targetExam || examPrep;

    // Register device token with server
    registerDeviceWithServer({
      userId: currentUserId,
      examTarget: currentExam,
      language
    });

    // Start background watcher for new alerts and unread count badge
    const cleanupWatcher = initForegroundNotificationWatcher({
      userId: currentUserId,
      userExam: currentExam,
      userLanguage: language,
      onCountUpdate: (count) => {
        setUnreadNotificationsCount(prev => {
          if (count > prev && prev !== 0) {
            setHasNewAlertAnimation(true);
            setTimeout(() => setHasNewAlertAnimation(false), 4000);
          }
          return count;
        });
      }
    });

    return () => {
      cleanupWatcher();
    };
  }, [userProfile.id, userProfile.phone, userProfile.email, userProfile.targetExam, examPrep, language]);

  // Progress Handlers
  const handleIncrementQuestion = () => {
    setProgress(prev => ({
      ...prev,
      questionsAsked: prev.questionsAsked + 1,
      studyTimeMinutes: prev.studyTimeMinutes + 5
    }));
  };

  const handleIncrementScan = () => {
    setProgress(prev => ({
      ...prev,
      questionsAsked: prev.questionsAsked + 1,
      studyTimeMinutes: prev.studyTimeMinutes + 10
    }));
  };

  const handleIncrementQuiz = (score: number) => {
    setProgress(prev => {
      const newQuizzesTaken = prev.quizzesTaken + 1;
      const newAvg = Math.round(((prev.averageScore * prev.quizzesTaken) + score) / newQuizzesTaken);
      return {
        ...prev,
        quizzesTaken: newQuizzesTaken,
        averageScore: newAvg,
        studyTimeMinutes: prev.studyTimeMinutes + 15
      };
    });
  };

  const handleRemoveSavedItem = (id: string) => {
    setSavedItems(prev => prev.filter(i => i.id !== id));
  };

  // AI Planner generation
  const handleGeneratePlan = async (subjects: string[], hours: number) => {
    setIsGeneratingPlan(true);
    try {
      const response = await fetch('/api/gemini/planner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subjects,
          examPrep,
          hoursPerDay: hours,
          language
        })
      });

      if (!response.ok) throw new Error('Failed to generate plan');

      const data = await response.json();
      if (data.routine) {
        const mapped: StudyPlanItem[] = data.routine.map((item: any, idx: number) => ({
          id: `gen-${idx}-${Date.now()}`,
          day: item.day,
          time: item.time,
          subject: item.subject,
          topic: item.topic,
          completed: false
        }));
        setStudyPlan(mapped);
      }
    } catch (err) {
      console.error('Planner Generation Error:', err);
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  // Speech Synthesis
  const handleReadAloud = (text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    const synth = window.speechSynthesis;

    if (activeVoiceTeacher) {
      synth.cancel();
      setActiveVoiceTeacher(false);
      return;
    }

    const cleanText = text.replace(/[*#_`~]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 800));
    utterance.lang = language === 'bn' ? 'bn-IN' : language === 'hi' ? 'hi-IN' : 'en-US';

    utterance.onstart = () => setActiveVoiceTeacher(true);
    utterance.onend = () => setActiveVoiceTeacher(false);
    utterance.onerror = () => setActiveVoiceTeacher(false);

    synth.cancel();
    synth.speak(utterance);
  };

  const handleOnboardingComplete = (updated: UserProfile) => {
    setUserProfile({ ...updated, onboardingCompleted: true });
    setLanguage(updated.preferredLanguage || language);
    if (updated.targetExam) setExamPrep(updated.targetExam as ExamType);
    setShowOnboarding(false);
  };

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-100 overflow-hidden font-sans">
      
      {/* ONBOARDING MODAL */}
      {showOnboarding && (
        <OnboardingModal
          language={language}
          initialProfile={userProfile}
          onComplete={handleOnboardingComplete}
        />
      )}

      {/* GLOBAL SEARCH MODAL */}
      {showGlobalSearch && (
        <GlobalSearchModal
          language={language}
          onClose={() => setShowGlobalSearch(false)}
          onSelectAction={(tab) => setTab(tab)}
        />
      )}

      {/* DESKTOP SIDEBAR */}
      <Sidebar 
        currentTab={currentTab} 
        setTab={setTab} 
        language={language} 
        setLanguage={setLanguage}
        onOpenSearch={() => setShowGlobalSearch(true)}
        userProfile={userProfile}
        unreadNotificationsCount={unreadNotificationsCount}
        onOpenNotifications={() => setShowNotificationCenter(true)}
        onOpenLanguageModal={() => setShowLanguageModal(true)}
      />

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
        
        {/* MOBILE HEADER: StudySkill AI → Language → 🔔 Notification */}
        <header className="md:hidden bg-slate-900 text-white px-4 py-3 flex items-center justify-between border-b border-slate-800 shadow-md">
          {/* Brand Logo & Target Exam */}
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-gradient-to-tr from-indigo-600 to-purple-600 rounded-lg shadow-sm">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold font-display leading-none flex items-center gap-1">
                <span>Study</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">Skill</span>
                <span className="ml-0.5 px-1 py-0.2 text-[9px] font-black rounded bg-gradient-to-r from-indigo-500 to-purple-600 text-white">AI</span>
              </h1>
              <span className="text-[9px] text-indigo-300 leading-none block mt-0.5">
                {userProfile.targetExam || examPrep || 'All-In-One Platform'}
              </span>
            </div>
          </div>

          {/* Top Bar Right: Language Button → 🔔 Notification Bell */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowLanguageModal(true)}
              className="bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-indigo-500/50 text-slate-200 rounded-lg px-2.5 py-1 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-all shadow-xs"
              title={language === 'bn' ? 'ভাষা পরিবর্তন করুন' : language === 'hi' ? 'भाषा बदलें' : 'Change Language'}
            >
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span className="max-w-[75px] truncate font-semibold">
                {ALL_SUPPORTED_LANGUAGES.find(l => l.code === language)?.nativeName || 'Language'}
              </span>
            </button>

            {/* Notification Bell (Replaces profile avatar in top bar) */}
            <NotificationBell
              unreadCount={unreadNotificationsCount}
              onClick={() => setShowNotificationCenter(true)}
              hasNewNotification={hasNewAlertAnimation}
            />
          </div>
        </header>

        {/* MOBILE 5-ITEM BOTTOM NAVIGATION BAR */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-2 py-1.5 flex justify-around items-center z-40 text-white h-16 shadow-2xl">
          {[
            { id: 'dashboard', label: t('nav.home', language), icon: Home },
            { id: 'classroom', label: t('nav.learn', language), isLearn: true },
            { id: 'scanner', label: t('nav.scan', language), icon: Camera, isScanner: true },
            { id: 'examprep', label: t('nav.exam', language), icon: ClipboardList },
            { id: 'profile', label: t('nav.profile', language), icon: User }
          ].map(item => {
            const isActive = currentTab === item.id;
            const isProfile = item.id === 'profile';

            if (item.isScanner) {
              return (
                <button 
                  key={item.id}
                  onClick={() => setTab(item.id)} 
                  className={`flex flex-col items-center justify-center gap-0.5 text-[10px] transition-all cursor-pointer flex-1 py-1 group ${
                    isActive ? 'scale-105' : 'hover:scale-105'
                  }`}
                >
                  <div className="relative flex items-center justify-center">
                    {/* Glowing pulsating radiant neon halo */}
                    <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-pink-500 opacity-90 blur-xs group-hover:opacity-100 transition duration-300 animate-pulse" />
                    
                    <div className={`relative w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white shadow-lg shadow-indigo-500/50 border border-white/40 transition-all active:scale-95 ${
                      isActive ? 'ring-2 ring-cyan-300 ring-offset-1 ring-offset-slate-900 shadow-cyan-500/50' : ''
                    }`}>
                      <Camera className="w-4.5 h-4.5 text-white drop-shadow-md" />
                      {/* Luminous live optic indicator */}
                      <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-cyan-300 shadow-xs shadow-cyan-300 animate-ping" />
                      <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-cyan-300" />
                    </div>
                  </div>
                  <span className={`truncate max-w-[56px] font-black transition-colors ${
                    isActive ? 'text-cyan-300 font-extrabold' : 'text-indigo-200 group-hover:text-white'
                  }`}>
                    {item.label}
                  </span>
                </button>
              );
            }

            return (
              <button 
                key={item.id}
                onClick={() => setTab(item.id)} 
                className={`flex flex-col items-center justify-center gap-0.5 text-[10px] transition-all cursor-pointer flex-1 py-1 ${
                  isActive ? 'text-indigo-400 font-extrabold scale-105' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isProfile && userProfile.photoUrl ? (
                  <img
                    src={userProfile.photoUrl}
                    alt={userProfile.name}
                    className={`w-5 h-5 rounded-full object-cover border ${
                      isActive ? 'border-indigo-400 ring-1 ring-indigo-400' : 'border-slate-700'
                    }`}
                  />
                ) : item.isLearn ? (
                  <LearnIcon size={20} active={isActive} />
                ) : item.icon ? (
                  <item.icon className={`w-5 h-5 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                ) : null}
                <span className="truncate max-w-[56px]">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* DYNAMIC VIEWS RENDERING */}
        <main className="flex-1 overflow-hidden pb-16 md:pb-0 flex flex-col">
          {currentTab === 'dashboard' && (
            <Dashboard 
              language={language}
              progress={progress}
              studyPlan={studyPlan}
              setStudyPlan={setStudyPlan}
              examPrep={examPrep}
              setExamPrep={setExamPrep}
              onNavigate={setTab}
              onGeneratePlan={handleGeneratePlan}
              isGeneratingPlan={isGeneratingPlan}
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              onOpenOnboarding={() => setShowOnboarding(true)}
            />
          )}

          {currentTab === 'scanner' && (
            <Scanner 
              language={language} 
              onIncrementScan={handleIncrementScan}
              userProfile={userProfile}
              setUserProfile={setUserProfile}
            />
          )}

          {currentTab === 'homework' && (
            <HomeworkSolver
              language={language}
              targetExam={examPrep}
            />
          )}

          {/* 🌟 AI LEARNING HUB (শিক্ষা) */}
          {currentTab === 'classroom' && (
            <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
              <AILearningHub
                language={language}
                targetExam={examPrep}
                setTargetExam={(ex) => setExamPrep(ex as ExamType)}
                userProfile={userProfile}
                setUserProfile={setUserProfile}
                onIncrementQuestion={handleIncrementQuestion}
                onNavigateToTab={setTab}
              />
            </div>
          )}

          {currentTab === 'examprep' && (
            <ExamCenter 
              language={language}
              examPrep={examPrep}
              setExamPrep={setExamPrep}
              onIncrementQuiz={handleIncrementQuiz}
              userProfile={userProfile}
            />
          )}

          {currentTab === 'govthub' && (
            <GovtExamHub
              language={language}
              targetExam={examPrep}
              setTargetExam={(ex) => setExamPrep(ex as ExamType)}
              onIncrementQuiz={handleIncrementQuiz}
            />
          )}

          {currentTab === 'saved' && (
            <SavedContent
              language={language}
              savedItems={savedItems}
              onRemoveItem={handleRemoveSavedItem}
            />
          )}

          {currentTab === 'profile' && (
            <ProfileView
              language={language}
              setLanguage={setLanguage}
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              progress={progress}
              onOpenOnboarding={() => setShowOnboarding(true)}
              onNavigateToTab={setTab}
            />
          )}
        </main>

        <footer className="hidden md:flex bg-slate-900 border-t border-slate-800 px-6 py-2.5 items-center justify-between text-[11px] text-slate-400 font-semibold select-none">
          <span>
            StudySkill AI — {language === 'bn' ? 'বই দেখুন, গল্প শুনুন, সহজে শিখুন' : 'All-In-One AI Education & Exam Preparation Platform'}
          </span>
          <span className="flex items-center gap-1">
            Made for student success <Heart className="w-3 h-3 text-rose-500 fill-current" />
          </span>
        </footer>

      </div>

      {/* FOREGROUND REAL-TIME NOTIFICATION BANNER */}
      <ForegroundNotificationBanner
        language={language}
        onNavigateTab={(targetTab) => setTab(targetTab)}
        onOpenNotificationCenter={() => setShowNotificationCenter(true)}
      />

      {/* DEDICATED NOTIFICATION CENTER MODAL */}
      <NotificationCenterModal
        isOpen={showNotificationCenter}
        onClose={() => setShowNotificationCenter(false)}
        language={language}
        userId={userProfile.id || userProfile.phone || userProfile.email || 'guest_user'}
        userExam={userProfile.targetExam || examPrep}
        onNavigateTab={(targetTab) => setTab(targetTab)}
        onUnreadCountChange={(count) => setUnreadNotificationsCount(count)}
      />

      {/* DEDICATED LANGUAGE SELECTION MODAL */}
      <LanguageSelectionModal
        isOpen={showLanguageModal}
        onClose={() => setShowLanguageModal(false)}
        currentLanguage={language}
        onSelectLanguage={(lang) => {
          setLanguage(lang);
          setUserProfile(prev => ({ ...prev, preferredLanguage: lang }));
        }}
        userProfile={userProfile}
        setUserProfile={setUserProfile}
      />

      {/* 3-SECOND BRANDED SPLASH SCREEN ON APP STARTUP */}
      {showSplash && (
        <SplashScreen
          language={language}
          onFinish={() => setShowSplash(false)}
        />
      )}

    </div>
  );
}
