import { useCallback, useEffect, useState } from 'react';
import {
  ClanDashboardState,
  PlayerProfile,
  SyncProgressInfo,
  SyncRunSummary,
  UpgradeEvent,
  VillageId,
} from './shared/cocData';
import { AppTab, SidebarNav, TopBar } from './components/TopBar';
import { OverviewView } from './components/OverviewView';
import { ActiveUpgradesView } from './components/ActiveUpgradesView';
import { VillagesView } from './components/VillagesView';
import { ClanStatsView } from './components/ClanStatsView';
import { TownHallGroupsView } from './components/TownHallGroupsView';
import { PlayersAndInspectorView } from './components/PlayersAndInspectorView';
import { WarsView } from './components/WarsView';
import { CapitalView } from './components/CapitalView';
import { RankingsView } from './components/RankingsView';
import { HistoryView } from './components/HistoryView';
import { UpgradeHistoryView } from './components/UpgradeHistoryView';
import { DonationsView } from './components/DonationsView';
import { EventsCenterView } from './components/EventsCenterView';
import { SettingsView } from './components/SettingsView';
import { ClanConnectModal } from './components/ClanConnectModal';
import { JsonImportModal } from './components/JsonImportModal';
import { apiFetchJson } from './utils/apiClient';

export default function App() {
  const [state, setState] = useState<ClanDashboardState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<AppTab>('overview');
  const [selectedVillage, setSelectedVillage] = useState<VillageId>('home');
  const [selectedTh, setSelectedTh] = useState<number | 'all'>('all');
  const [selectedPlayerTag, setSelectedPlayerTag] = useState<string>('');
  const [profileOpenTrigger, setProfileOpenTrigger] = useState(0);
  const [externalPlayer, setExternalPlayer] = useState<PlayerProfile | null>(null);

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState<SyncProgressInfo | null>(null);
  const [lastSyncSummary, setLastSyncSummary] = useState<SyncRunSummary | null>(null);
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [liveNotice, setLiveNotice] = useState<string | null>(null);
  const [liveError, setLiveError] = useState<string | null>(null);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [isJsonImportOpen, setIsJsonImportOpen] = useState(false);
  const [jsonImportTargetTag, setJsonImportTargetTag] = useState<string>('');

  const fetchState = useCallback(async () => {
    try {
      const data = await apiFetchJson<ClanDashboardState>('/api/state');
      setState(data);
      setSelectedPlayerTag((prev) => prev || data.players[0]?.tag || '');
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Не удалось загрузить состояние приложения');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [fetchState]);

  // Server-Sent Events stream for background auto-sync & live progress updates
  useEffect(() => {
    const evtSource = new EventSource('/api/stream');

    evtSource.addEventListener('sync_progress', (e) => {
      try {
        const progress = JSON.parse((e as MessageEvent).data) as SyncProgressInfo;
        setSyncProgress(progress);
      } catch {
        // ignore malformed progress payload
      }
    });

    evtSource.addEventListener('state_update', (e) => {
      try {
        const payload = JSON.parse((e as MessageEvent).data) as {
          reason?: string;
          events?: UpgradeEvent[];
          summary?: SyncRunSummary;
          state?: ClanDashboardState;
        };
        if (payload.state) {
          setState(payload.state);
        }
        if (payload.summary) {
          setLastSyncSummary(payload.summary);
        }
        if (payload.reason === 'scheduled_sync' && payload.state?.clan) {
          const found = payload.summary?.upgradesFound ?? 0;
          setLiveNotice(
            found > 0
              ? `Автопроверка клана ${payload.state.clan.name}: обнаружено улучшений — ${found}`
              : `Автопроверка клана ${payload.state.clan.name}: новых улучшений не обнаружено`
          );
        } else if (payload.events && payload.events.length > 0) {
          const latest = payload.events[0];
          const inst = latest.instanceNumber ? ` #${latest.instanceNumber}` : '';
          setLiveNotice(
            `${latest.playerName} (TH${latest.townHallLevel}): ${latest.apiName || latest.itemNameRu}${inst} ${latest.fromLevel} → ${latest.toLevel}`
          );
        }
      } catch {
        // ignore malformed stream payload
      }
    });

    return () => {
      evtSource.close();
    };
  }, []);

  useEffect(() => {
    if (!liveNotice) return;
    const t = setTimeout(() => setLiveNotice(null), 5000);
    return () => clearTimeout(t);
  }, [liveNotice]);

  const handleSyncTick = async () => {
    setIsSyncing(true);
    setLiveError(null);
    setSyncProgress({
      inProgress: true,
      stage: 'fetching_clan',
      statusText: 'Запрос списка участников клана из Supercell API...',
      checkedMembers: 0,
      totalMembers: state?.players.length ?? 0,
      upgradesFound: 0,
      errorsCount: 0,
      startedAt: new Date().toISOString(),
    });
    try {
      const data = await apiFetchJson<{
        state?: ClanDashboardState;
        summary?: SyncRunSummary;
      }>('/api/sync/tick', {
        method: 'POST',
        timeoutMs: 60000,
      });
      if (data.state) {
        setState(data.state);
      }
      if (data.summary) {
        setLastSyncSummary(data.summary);
        const { checkedMembers, upgradesFound } = data.summary;
        setLiveNotice(
          upgradesFound > 0
            ? `Проверка завершена. Проверено участников: ${checkedMembers}. Обнаружено улучшений: ${upgradesFound}.`
            : `Проверка завершена. Проверено участников: ${checkedMembers}. Новых улучшений не обнаружено.`
        );
      } else if (data.state) {
        setLiveNotice(`Проверка клана ${data.state.clan?.name ?? ''} завершена.`);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Ошибка синхронизации с сервером';
      setLiveError(msg);
      setLastSyncSummary({
        checkedMembers: 0,
        totalMembers: state?.players.length ?? 0,
        upgradesFound: 0,
        errorsCount: 1,
        completedAt: new Date().toISOString(),
        newUpgrades: [],
        errorMessage: msg,
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleClanConnected = (nextState: ClanDashboardState, customNotice?: string) => {
    setState(nextState);
    setSelectedTh('all');
    setExternalPlayer(null);
    setSelectedPlayerTag(nextState.players[0]?.tag ?? '');
    setLastSyncSummary(null);
    if (customNotice) {
      setLiveNotice(customNotice);
    } else if (nextState.clan) {
      setLiveNotice(`Клан ${nextState.clan.name} (${nextState.clan.tag}) загружен из Supercell API`);
    }
  };

  const openMemberInspector = (tag: string) => {
    setExternalPlayer(null);
    setSelectedPlayerTag(tag);
    setProfileOpenTrigger((prev) => prev + 1);
    setActiveTab('player');
  };

  const openExternalPlayer = (player: PlayerProfile) => {
    setExternalPlayer(player);
    setActiveTab('player');
  };

  const openThGroup = (th: number) => {
    setSelectedTh(th);
    setActiveTab('groups');
  };

  const openVillage = (village: VillageId) => {
    setSelectedVillage(village);
    setActiveTab('villages');
  };

  const openJsonImport = (playerTag?: string) => {
    setJsonImportTargetTag(playerTag ?? '');
    setIsJsonImportOpen(true);
  };

  const unreadEventsCount = (state?.clanEvents ?? []).filter((e) => !e.read).length;
  const activeUpgradesCount = (state?.activeUpgrades ?? []).filter((a) => a.status === 'in_progress').length;

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col">
      <TopBar
        activeTab={activeTab}
        clanName={state?.clan?.name}
        clanTag={state?.clan?.tag}
        hasClan={Boolean(state?.clan)}
        unreadEventsCount={unreadEventsCount}
        activeUpgradesCount={activeUpgradesCount}
        onSelectTab={setActiveTab}
        onSyncTick={handleSyncTick}
        onOpenSearch={() => setIsConnectModalOpen(true)}
        isSyncing={isSyncing}
      />

      <div className="flex flex-1">
        <SidebarNav
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          clanName={state?.clan?.name}
          clanTag={state?.clan?.tag}
          membersCount={state?.clan?.membersCount}
          unreadEventsCount={unreadEventsCount}
          activeUpgradesCount={activeUpgradesCount}
        />

        <div className="flex-1 min-w-0 flex flex-col">
          {liveNotice && (
            <div className="mx-auto mt-4 w-full max-w-[1360px] px-4 sm:px-6">
              <div className="flex items-center justify-between gap-4 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-xs text-emerald-300">
                <span>
                  <strong className="font-semibold">Данные обновлены из Supercell API:</strong> {liveNotice}
                </span>
                <button
                  type="button"
                  onClick={() => setLiveNotice(null)}
                  className="text-emerald-400 hover:text-emerald-200 shrink-0"
                >
                  Скрыть
                </button>
              </div>
            </div>
          )}

          {liveError && (
            <div className="mx-auto mt-4 w-full max-w-[1360px] px-4 sm:px-6">
              <div className="flex items-center justify-between gap-4 rounded-md border border-rose-500/40 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-300">
                <span>{liveError}</span>
                <button
                  type="button"
                  onClick={() => setLiveError(null)}
                  className="text-rose-300 hover:text-rose-100 shrink-0"
                >
                  Скрыть
                </button>
              </div>
            </div>
          )}

          <main className="mx-auto w-full max-w-[1360px] flex-1 px-4 py-6 sm:px-6">
            {loading ? (
              <div className="space-y-6 animate-pulse">
                <div className="h-16 rounded-lg bg-[#121824] border border-slate-800" />
                <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="h-24 rounded-lg bg-[#121824] border border-slate-800" />
                  ))}
                </div>
                <div className="h-80 rounded-lg bg-[#121824] border border-slate-800" />
              </div>
            ) : error || !state ? (
              <div className="rounded-lg border border-rose-500/40 bg-[#121824] p-8 text-center">
                <p className="text-sm text-rose-300">{error || 'Данные недоступны'}</p>
                <button
                  type="button"
                  onClick={fetchState}
                  className="mt-4 rounded-md bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400"
                >
                  Повторить загрузку
                </button>
              </div>
            ) : (
              <>
                {activeTab === 'overview' && (
                  <OverviewView
                    state={state}
                    nowMs={nowMs}
                    isSyncing={isSyncing}
                    onSyncNow={handleSyncTick}
                    onOpenJsonImport={openJsonImport}
                    onOpenVillage={openVillage}
                    onSelectPlayer={openMemberInspector}
                    onSelectThGroup={openThGroup}
                    onSelectTab={setActiveTab}
                    onOpenClanConnect={() => setIsConnectModalOpen(true)}
                    onClanConnected={(nextState) => handleClanConnected(nextState)}
                    onOpenExternalPlayer={openExternalPlayer}
                  />
                )}

                {activeTab === 'active_upgrades' && (
                  <ActiveUpgradesView
                    state={state}
                    nowMs={nowMs}
                    isSyncing={isSyncing}
                    syncProgress={syncProgress}
                    lastSyncSummary={lastSyncSummary}
                    onSyncNow={handleSyncTick}
                    onOpenJsonImport={openJsonImport}
                    onSelectPlayer={openMemberInspector}
                    onSelectVillage={openVillage}
                  />
                )}

                {activeTab === 'villages' && (
                  <VillagesView
                    state={state}
                    selectedVillage={selectedVillage}
                    nowMs={nowMs}
                    isSyncing={isSyncing}
                    onSelectVillage={setSelectedVillage}
                    onSyncNow={handleSyncTick}
                    onOpenJsonImport={openJsonImport}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'clan_stats' && (
                  <ClanStatsView
                    state={state}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'groups' && (
                  <TownHallGroupsView
                    state={state}
                    selectedTh={selectedTh}
                    onSelectTh={setSelectedTh}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'player' && (
                  <PlayersAndInspectorView
                    state={state}
                    selectedPlayerTag={selectedPlayerTag}
                    profileOpenTrigger={profileOpenTrigger}
                    externalPlayer={externalPlayer}
                    nowMs={nowMs}
                    onSelectPlayer={(tag) => {
                      setExternalPlayer(null);
                      setSelectedPlayerTag(tag);
                    }}
                    onClearExternalPlayer={() => setExternalPlayer(null)}
                    onOpenJsonImport={openJsonImport}
                    onOpenSettingsImport={() => setActiveTab('settings')}
                    onOpenGlobalSearch={() => setIsConnectModalOpen(true)}
                  />
                )}

                {activeTab === 'upgrade_history' && (
                  <UpgradeHistoryView
                    state={state}
                    nowMs={nowMs}
                    isSyncing={isSyncing}
                    syncProgress={syncProgress}
                    lastSyncSummary={lastSyncSummary}
                    onSyncNow={handleSyncTick}
                    onOpenJsonImport={openJsonImport}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'donations' && (
                  <DonationsView
                    state={state}
                    nowMs={nowMs}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'events' && (
                  <EventsCenterView
                    state={state}
                    nowMs={nowMs}
                    onSelectPlayer={openMemberInspector}
                    onStateUpdated={(nextState) => setState(nextState)}
                  />
                )}

                {activeTab === 'wars' && (
                  <WarsView
                    state={state}
                    nowMs={nowMs}
                    initialMode="regular"
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'cwl' && (
                  <WarsView
                    state={state}
                    nowMs={nowMs}
                    initialMode="cwl"
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'capital' && (
                  <CapitalView
                    state={state}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'rankings' && (
                  <RankingsView
                    state={state}
                    nowMs={nowMs}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'history' && (
                  <HistoryView
                    state={state}
                    nowMs={nowMs}
                    onSelectPlayer={openMemberInspector}
                  />
                )}

                {activeTab === 'settings' && (
                  <SettingsView
                    state={state}
                    isSyncing={isSyncing}
                    onSyncNow={handleSyncTick}
                    onStateUpdated={(nextState, customNotice) =>
                      handleClanConnected(nextState, customNotice)
                    }
                    onOpenClanConnect={() => setIsConnectModalOpen(true)}
                  />
                )}
              </>
            )}
          </main>

          <footer className="border-t border-slate-800/70 py-4 text-center text-xs text-slate-500">
            Clash Analytics · Аналитическая платформа Clash of Clans на основе официального Supercell API v1
          </footer>
        </div>
      </div>

      <ClanConnectModal
        isOpen={isConnectModalOpen}
        currentClanTag={state?.clan?.tag ?? ''}
        hasApiToken={Boolean(state?.hasApiToken)}
        onClose={() => setIsConnectModalOpen(false)}
        onConnected={(nextState) => handleClanConnected(nextState)}
        onOpenExternalPlayer={openExternalPlayer}
      />

      {state && (
        <JsonImportModal
          isOpen={isJsonImportOpen}
          state={state}
          initialTargetTag={jsonImportTargetTag}
          onClose={() => setIsJsonImportOpen(false)}
          onImported={(nextState, msg) => {
            setState(nextState);
            setLiveNotice(msg);
          }}
        />
      )}
    </div>
  );
}
