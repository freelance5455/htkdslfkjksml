import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  Layers,
  Folder,
  Mountain,
  Grid,
  Sliders,
  Palette,
  Sparkles,
  Network,
  Terminal,
  Activity,
  FileCode,
  Volume2,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Play,
  Square,
  Smartphone,
  Eye,
  Crosshair,
} from 'lucide-react';
import {
  ProjectData,
  SceneData,
  EngineObject,
  ObjectType,
  TransformGizmoMode,
  ViewportMode,
  ConsoleLog,
  Vector3D,
} from './types';
import { createInitialProject, createDemoScene, createDefaultMaterial } from './scene/defaultScene';
import { ViewportEngine, ViewportStats } from './renderer/viewportEngine';
import { TopMenuBar } from './ui/TopMenuBar';
import { ViewportToolbar } from './ui/ViewportToolbar';
import { SceneGraph } from './ui/SceneGraph';
import { AssetBrowser } from './ui/AssetBrowser';
import { TerrainEditor } from './ui/TerrainEditor';
import { WorldStreamingPanel } from './ui/WorldStreamingPanel';
import { Inspector } from './ui/Inspector';
import { MaterialEditor } from './ui/MaterialEditor';
import { ParticleEditor } from './ui/ParticleEditor';
import { VisualScriptEditor } from './ui/VisualScriptEditor';
import { ConsolePanel } from './ui/ConsolePanel';
import { ProfilerPanel } from './ui/ProfilerPanel';
import { ScriptCodeEditor } from './ui/ScriptCodeEditor';
import { AudioManagerPanel } from './ui/AudioManagerPanel';
import { TouchControls } from './ui/TouchControls';
import { Modals } from './ui/Modals';
import { audioSystem } from './audio/audioManager';

export default function App() {
  // 1. Core State
  const [project, setProject] = useState<ProjectData>(() => {
    const saved = localStorage.getItem('daviengine_project_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return createInitialProject();
      }
    }
    return createInitialProject();
  });

  const [activeSceneId, setActiveSceneId] = useState<string>(project.currentSceneId);
  const activeScene = project.scenes.find((s) => s.id === activeSceneId) || project.scenes[0];

  const [selectedObjectId, setSelectedObjectId] = useState<string | null>('player_character');
  const selectedObject = activeScene.objects.find((o) => o.id === selectedObjectId) || null;

  // 2. Viewport & Tool State
  const [gizmoMode, setGizmoMode] = useState<TransformGizmoMode>('translate');
  const [viewportMode, setViewportMode] = useState<ViewportMode>('material');
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [snapEnabled, setSnapEnabled] = useState<boolean>(false);
  const [isGameMode, setIsGameMode] = useState<boolean>(false);

  // 3. UI Panel Tabs
  const [leftTab, setLeftTab] = useState<'hierarchy' | 'assets' | 'terrain' | 'streaming'>('hierarchy');
  const [rightTab, setRightTab] = useState<'inspector' | 'materials' | 'particles' | 'visualscript'>('inspector');
  const [bottomTab, setBottomTab] = useState<'console' | 'profiler' | 'scripts' | 'audio'>('console');
  const [showBottomPanel, setShowBottomPanel] = useState<boolean>(true);
  const [showLeftPanel, setShowLeftPanel] = useState<boolean>(true);
  const [showRightPanel, setShowRightPanel] = useState<boolean>(true);
  const [isMobileLayout, setIsMobileLayout] = useState<boolean>(false);

  // 4. Modals
  const [activeModal, setActiveModal] = useState<'project' | 'shortcuts' | 'about' | 'build' | null>(null);

  // 5. Console Logs & Profiler Metrics
  const [logs, setLogs] = useState<ConsoleLog[]>([
    {
      id: 'log_init',
      timestamp: new Date().toLocaleTimeString(),
      level: 'success',
      message: 'DAVIENGINE 0.1.0 initialized successfully. WebGL rasterizer active.',
      source: 'Kernel',
    },
    {
      id: 'log_scene',
      timestamp: new Date().toLocaleTimeString(),
      level: 'info',
      message: 'Demo Archipelago Valley 01 scene mounted with procedural terrain & lighting.',
      source: 'SceneLoader',
    },
  ]);

  const [viewportStats, setViewportStats] = useState<ViewportStats>({
    fps: 60,
    frameTime: 16.6,
    triangles: 1420,
    drawCalls: 18,
    objectsCount: activeScene.objects.length,
    memoryGeometries: 12,
    memoryTextures: 4,
    webglVersion: 'WebGL 2.0 (High Performance)',
  });

  const addLog = (message: string, level: ConsoleLog['level'] = 'info') => {
    setLogs((prev) => [
      ...prev.slice(-80),
      {
        id: `log_${Date.now()}_${Math.random()}`,
        timestamp: new Date().toLocaleTimeString(),
        level,
        message,
      },
    ]);
  };

  // 6. Viewport Engine Ref
  const viewportContainerRef = useRef<HTMLDivElement | null>(null);
  const viewportEngineRef = useRef<ViewportEngine | null>(null);

  // Auto-detect mobile screen on mount
  useEffect(() => {
    if (window.innerWidth < 768) {
      setIsMobileLayout(true);
      setShowLeftPanel(false);
      setShowRightPanel(false);
      setShowBottomPanel(false);
    }
  }, []);

  // Initialize Viewport Engine
  useEffect(() => {
    if (!viewportContainerRef.current) return;

    const engine = new ViewportEngine(viewportContainerRef.current);
    viewportEngineRef.current = engine;

    engine.onSelectObject = (id) => {
      setSelectedObjectId(id);
    };

    engine.onObjectTransformChange = (id, transform) => {
      setProject((prevProj) => {
        const nextScenes = prevProj.scenes.map((sc) => {
          if (sc.id !== activeSceneId) return sc;
          return {
            ...sc,
            objects: sc.objects.map((o) => (o.id === id ? { ...o, transform } : o)),
          };
        });
        return { ...prevProj, scenes: nextScenes };
      });
    };

    engine.onStatsUpdate = (stats) => {
      setViewportStats(stats);
    };

    engine.loadScene(activeScene);

    return () => {
      engine.destroy();
      viewportEngineRef.current = null;
    };
  }, []);

  // Sync scene data to Viewport Engine when activeScene changes
  useEffect(() => {
    if (viewportEngineRef.current) {
      viewportEngineRef.current.loadScene(activeScene);
    }
  }, [activeSceneId]);

  // Sync Selection in Engine
  useEffect(() => {
    if (viewportEngineRef.current) {
      viewportEngineRef.current.selectObject(selectedObjectId);
    }
  }, [selectedObjectId]);

  // Sync Gizmo Mode
  useEffect(() => {
    if (viewportEngineRef.current) {
      viewportEngineRef.current.setGizmoMode(gizmoMode);
    }
  }, [gizmoMode]);

  // Sync Viewport Shading Mode
  useEffect(() => {
    if (viewportEngineRef.current) {
      viewportEngineRef.current.setViewportMode(viewportMode);
    }
  }, [viewportMode]);

  // Keyboard Shortcuts Handler (W, E, R, F, Ctrl+S)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in text input or textarea
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }

      // Game Mode Key input
      if (isGameMode && viewportEngineRef.current) {
        if (e.code === 'Escape') {
          handleToggleGameMode();
          return;
        }
        if (e.code === 'KeyW' || e.code === 'ArrowUp') viewportEngineRef.current.inputMove.forward = 1;
        if (e.code === 'KeyS' || e.code === 'ArrowDown') viewportEngineRef.current.inputMove.forward = -1;
        if (e.code === 'KeyA' || e.code === 'ArrowLeft') viewportEngineRef.current.inputMove.right = -1;
        if (e.code === 'KeyD' || e.code === 'ArrowRight') viewportEngineRef.current.inputMove.right = 1;
        if (e.code === 'Space') {
          viewportEngineRef.current.inputMove.jump = true;
          audioSystem.playSound('synth_jump', { pitch: 1.1, volume: 0.4 });
        }
        if (e.code === 'KeyE' || e.code === 'KeyF' || e.code === 'Enter') {
          viewportEngineRef.current.fireActionPulse();
          audioSystem.playSound('synth_laser', { pitch: 1.2, volume: 0.5 });
          addLog('Player triggered pulse wave!', 'info');
        }
        return;
      }

      if (e.key === 'w' || e.key === 'W') {
        setGizmoMode('translate');
      } else if (e.key === 'e' || e.key === 'E') {
        setGizmoMode('rotate');
      } else if (e.key === 'r' || e.key === 'R') {
        setGizmoMode('scale');
      } else if (e.key === 'f' || e.key === 'F') {
        viewportEngineRef.current?.focusSelected();
      } else if (e.key === 'g' || e.key === 'G') {
        setShowGrid((prev) => {
          const next = !prev;
          if (viewportEngineRef.current) {
            viewportEngineRef.current.showGrid = next;
            if (viewportEngineRef.current.gridHelper) {
              viewportEngineRef.current.gridHelper.visible = next;
            }
          }
          return next;
        });
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 'd' || e.key === 'D')) {
        e.preventDefault();
        if (selectedObjectId) {
          handleDuplicateObject(selectedObjectId);
        }
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedObjectId) {
          handleDeleteObject(selectedObjectId);
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSaveScene();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (isGameMode && viewportEngineRef.current) {
        if (e.code === 'KeyW' || e.code === 'KeyS' || e.code === 'ArrowUp' || e.code === 'ArrowDown') {
          viewportEngineRef.current.inputMove.forward = 0;
        }
        if (e.code === 'KeyA' || e.code === 'KeyD' || e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
          viewportEngineRef.current.inputMove.right = 0;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isGameMode]);

  // Handle Save Scene
  const handleSaveScene = () => {
    localStorage.setItem('daviengine_project_v1', JSON.stringify(project));
    addLog(`Project "${project.name}" and scene "${activeScene.name}" saved to local storage.`, 'success');
    audioSystem.playSound('synth_bell', { pitch: 1.4, volume: 0.4 });
  };

  // Toggle Game Mode (Play / Stop)
  const handleToggleGameMode = () => {
    const nextMode = !isGameMode;
    setIsGameMode(nextMode);
    if (viewportEngineRef.current) {
      viewportEngineRef.current.setGameMode(nextMode);
    }
    if (nextMode) {
      addLog('Game Mode STARTED. Player simulation & 3rd-person tracking active.', 'info');
    } else {
      addLog('Game Mode STOPPED. Returned to Editor mode.', 'info');
    }
  };

  // Scene & Object Actions
  const handleAddObject = (type: ObjectType, customName?: string) => {
    const id = `${type}_${Math.random().toString(36).substring(2, 7)}`;
    const capitalized = type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ');

    const newObj: EngineObject = {
      id,
      name: customName || `${capitalized} ${activeScene.objects.length + 1}`,
      type,
      visible: true,
      locked: false,
      parentId: null,
      transform: {
        position: { x: (Math.random() - 0.5) * 6, y: 1.5, z: (Math.random() - 0.5) * 6 },
        rotation: { x: 0, y: 0, z: 0 },
        scale: { x: 1, y: 1, z: 1 },
      },
      material: createDefaultMaterial(type.startsWith('light') ? '#facc15' : '#06b6d4', `${capitalized} Material`),
      physics: {
        enabled: true,
        type: 'dynamic',
        mass: 10,
        friction: 0.6,
        bounciness: 0.2,
        useGravity: true,
        colliderType: 'box',
      },
    };

    if (type.startsWith('light')) {
      newObj.lighting = {
        type: type === 'light_spot' ? 'spot' : type === 'light_point' ? 'point' : 'directional',
        color: '#ffffff',
        intensity: 2.0,
        distance: 25,
        castShadow: true,
      };
    }

    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => (s.id === activeSceneId ? { ...s, objects: [...s.objects, newObj] } : s)),
    }));

    if (viewportEngineRef.current) {
      viewportEngineRef.current.addObjectToScene(newObj);
      viewportEngineRef.current.selectObject(id);
    }
    setSelectedObjectId(id);
    addLog(`Created primitive: ${newObj.name} (${type})`, 'success');
  };

  const handleDeleteObject = (id: string) => {
    const target = activeScene.objects.find((o) => o.id === id);
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) =>
        s.id === activeSceneId ? { ...s, objects: s.objects.filter((o) => o.id !== id) } : s
      ),
    }));

    if (viewportEngineRef.current) {
      viewportEngineRef.current.removeObjectFromScene(id);
    }
    if (selectedObjectId === id) {
      setSelectedObjectId(null);
    }
    addLog(`Deleted object "${target?.name || id}"`, 'warn');
  };

  const handleDuplicateObject = (id: string) => {
    const target = activeScene.objects.find((o) => o.id === id);
    if (!target) return;

    const dupId = `${target.type}_${Math.random().toString(36).substring(2, 7)}`;
    const cloned: EngineObject = {
      ...JSON.parse(JSON.stringify(target)),
      id: dupId,
      name: `${target.name} (Copy)`,
      transform: {
        ...target.transform,
        position: {
          x: target.transform.position.x + 1.5,
          y: target.transform.position.y,
          z: target.transform.position.z + 1.5,
        },
      },
    };

    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => (s.id === activeSceneId ? { ...s, objects: [...s.objects, cloned] } : s)),
    }));

    if (viewportEngineRef.current) {
      viewportEngineRef.current.addObjectToScene(cloned);
      viewportEngineRef.current.selectObject(dupId);
    }
    setSelectedObjectId(dupId);
    addLog(`Duplicated object "${target.name}" -> "${cloned.name}"`, 'info');
  };

  const handleToggleVisibility = (id: string) => {
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === id ? { ...o, visible: !o.visible } : o)),
        };
      }),
    }));
    const mesh = viewportEngineRef.current?.scene.getObjectByName(id);
    if (mesh) mesh.visible = !mesh.visible;
  };

  const handleToggleLock = (id: string) => {
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === id ? { ...o, locked: !o.locked } : o)),
        };
      }),
    }));
  };

  const handleUpdateObjectTransform = (transform: EngineObject['transform']) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, transform } : o)),
        };
      }),
    }));

    if (viewportEngineRef.current && selectedObject) {
      viewportEngineRef.current.updateObjectTransform({ ...selectedObject, transform });
    }
  };

  const handleUpdateObjectMaterial = (material: EngineObject['material']) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, material } : o)),
        };
      }),
    }));

    if (viewportEngineRef.current && selectedObject) {
      viewportEngineRef.current.updateObjectMaterial({ ...selectedObject, material });
    }
  };

  const handleUpdateObjectLighting = (lighting: NonNullable<EngineObject['lighting']>) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, lighting } : o)),
        };
      }),
    }));
    if (viewportEngineRef.current && selectedObject) {
      viewportEngineRef.current.updateObjectLighting({ ...selectedObject, lighting });
    }
  };

  const handleUpdateObjectAI = (ai: NonNullable<EngineObject['ai']>) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, ai } : o)),
        };
      }),
    }));
    addLog(`Configured AI behavior: ${ai.type.toUpperCase()}`, 'info');
  };

  const handleUpdateObjectAudio = (audio: NonNullable<EngineObject['audio']>) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, audio } : o)),
        };
      }),
    }));
    addLog(`Configured Audio Source: ${audio.clipName} (${Math.round(audio.volume * 100)}%)`, 'info');
  };

  const handleUpdateObjectPhysics = (physics: NonNullable<EngineObject['physics']>) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, physics } : o)),
        };
      }),
    }));
  };

  const handleUpdateObjectName = (name: string) => {
    if (!selectedObjectId) return;
    setProject((prev) => ({
      ...prev,
      scenes: prev.scenes.map((s) => {
        if (s.id !== activeSceneId) return s;
        return {
          ...s,
          objects: s.objects.map((o) => (o.id === selectedObjectId ? { ...o, name } : o)),
        };
      }),
    }));
  };

  // Export / Import Project JSON
  const handleExportProject = () => {
    const jsonStr = JSON.stringify(project, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name.toLowerCase().replace(/\s+/g, '_')}_daviengine.json`;
    a.click();
    URL.revokeObjectURL(url);
    addLog(`Exported project package: ${a.download}`, 'success');
  };

  const handleImportProject = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const parsed = JSON.parse(evt.target?.result as string);
          if (parsed.scenes && parsed.id) {
            setProject(parsed);
            setActiveSceneId(parsed.currentSceneId || parsed.scenes[0].id);
            addLog(`Project "${parsed.name}" successfully imported!`, 'success');
          }
        } catch {
          addLog('Failed to parse project JSON file.', 'error');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const handleCreateScene = (name: string) => {
    const newScene: SceneData = {
      id: `scene_${Math.random().toString(36).substring(2, 7)}`,
      name,
      createdAt: new Date().toISOString(),
      fogColor: '#0f172a',
      fogDensity: 0.01,
      ambientLightColor: '#60a5fa',
      ambientLightIntensity: 0.7,
      skyColor: '#0284c7',
      groundColor: '#1e293b',
      gravity: -9.81,
      objects: [
        {
          id: `sun_${Date.now()}`,
          name: 'Sun Directional Light',
          type: 'light_directional',
          visible: true,
          locked: false,
          parentId: null,
          transform: {
            position: { x: 10, y: 20, z: 10 },
            rotation: { x: -45, y: 45, z: 0 },
            scale: { x: 1, y: 1, z: 1 },
          },
          material: createDefaultMaterial('#ffffff', 'Sun'),
          lighting: {
            type: 'directional',
            color: '#ffffff',
            intensity: 1.5,
            distance: 100,
            castShadow: true,
          },
        },
        {
          id: `ground_${Date.now()}`,
          name: 'Ground Plane',
          type: 'plane',
          visible: true,
          locked: false,
          parentId: null,
          transform: {
            position: { x: 0, y: 0, z: 0 },
            rotation: { x: -90, y: 0, z: 0 },
            scale: { x: 30, y: 30, z: 1 },
          },
          material: createDefaultMaterial('#334155', 'Floor'),
        },
      ],
    };

    setProject((prev) => ({
      ...prev,
      scenes: [...prev.scenes, newScene],
      currentSceneId: newScene.id,
    }));
    setActiveSceneId(newScene.id);
    addLog(`Created scene "${name}"`, 'success');
  };

  // Console CLI Command Handler
  const handleExecuteCommand = (cmd: string) => {
    addLog(`> ${cmd}`, 'info');
    const lower = cmd.toLowerCase().trim();

    if (lower === 'help') {
      addLog('Commands: spawn <cube|sphere|light>, clear, play, stop, save, stats, reset', 'info');
    } else if (lower.startsWith('spawn ')) {
      const type = lower.replace('spawn ', '').trim() as ObjectType;
      handleAddObject(type || 'cube');
    } else if (lower === 'clear') {
      setLogs([]);
    } else if (lower === 'play') {
      if (!isGameMode) handleToggleGameMode();
    } else if (lower === 'stop') {
      if (isGameMode) handleToggleGameMode();
    } else if (lower === 'save') {
      handleSaveScene();
    } else if (lower === 'stats') {
      setBottomTab('profiler');
      setShowBottomPanel(true);
    } else if (lower === 'reset') {
      viewportEngineRef.current?.setCameraView('reset');
    } else {
      addLog(`Unknown command: "${cmd}". Type "help" for a list of commands.`, 'warn');
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0d1117] text-slate-200 overflow-hidden font-sans select-none">
      {/* 1. TOP MENU BAR */}
      <TopMenuBar
        project={project}
        activeScene={activeScene}
        isGameMode={isGameMode}
        onToggleGameMode={handleToggleGameMode}
        onSaveScene={handleSaveScene}
        onOpenProjectModal={() => setActiveModal('project')}
        onSelectScene={(id) => setActiveSceneId(id)}
        onCreateNewScene={() => setActiveModal('project')}
        onExportProject={handleExportProject}
        onImportProject={handleImportProject}
        onOpenModal={(m) => setActiveModal(m)}
        bottomPanelTab={bottomTab}
        setBottomPanelTab={(tab) => setBottomTab(tab)}
        showBottomPanel={showBottomPanel}
        setShowBottomPanel={setShowBottomPanel}
        isMobileLayout={isMobileLayout}
        setIsMobileLayout={setIsMobileLayout}
      />

      {/* 2. MAIN WORKSPACE (Left Panel + 3D Viewport + Right Panel) */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* LEFT PANEL */}
        {showLeftPanel && !isGameMode && (
          <aside className="w-64 md:w-72 bg-[#11161f] border-r border-[#21262d] flex flex-col shrink-0 z-20">
            {/* Left Tabs Bar */}
            <div className="h-9 bg-[#0d1117] border-b border-[#21262d] flex items-center px-1 space-x-1">
              <button
                onClick={() => setLeftTab('hierarchy')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  leftTab === 'hierarchy'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Scene Graph Hierarchy"
              >
                <Layers className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Hierarchy</span>
              </button>

              <button
                onClick={() => setLeftTab('assets')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  leftTab === 'assets'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Asset Browser"
              >
                <Folder className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Assets</span>
              </button>

              <button
                onClick={() => setLeftTab('terrain')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  leftTab === 'terrain'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Terrain Sculptor"
              >
                <Mountain className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Terrain</span>
              </button>

              <button
                onClick={() => setLeftTab('streaming')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  leftTab === 'streaming'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="World Streaming Grid"
              >
                <Grid className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">World</span>
              </button>
            </div>

            {/* Left Content */}
            <div className="flex-1 overflow-hidden">
              {leftTab === 'hierarchy' && (
                <SceneGraph
                  objects={activeScene.objects}
                  selectedObjectId={selectedObjectId}
                  onSelectObject={(id) => setSelectedObjectId(id)}
                  onFocusObject={() => viewportEngineRef.current?.focusSelected()}
                  onAddObject={handleAddObject}
                  onDeleteObject={handleDeleteObject}
                  onDuplicateObject={handleDuplicateObject}
                  onToggleVisibility={handleToggleVisibility}
                  onToggleLock={handleToggleLock}
                />
              )}
              {leftTab === 'assets' && (
                <AssetBrowser onSpawnAsset={(type, name) => handleAddObject(type, name)} />
              )}
              {leftTab === 'terrain' && (
                <TerrainEditor
                  onRegenerateTerrain={(hScale, rough) => {
                    const terrainObj = activeScene.objects.find((o) => o.type === 'terrain');
                    if (terrainObj) {
                      handleUpdateObjectTransform({
                        ...terrainObj.transform,
                        scale: { ...terrainObj.transform.scale, y: hScale },
                      });
                      addLog(`Terrain re-meshed with scale ${hScale}m`, 'info');
                    }
                  }}
                  onUpdateWaterHeight={(h) => {
                    const waterObj = activeScene.objects.find((o) => o.type === 'water');
                    if (waterObj) {
                      handleUpdateObjectTransform({
                        ...waterObj.transform,
                        position: { ...waterObj.transform.position, y: h },
                      });
                    }
                  }}
                  onAddFoliage={(type) => {
                    handleAddObject(type === 'trees' ? 'cylinder' : 'sphere');
                  }}
                />
              )}
              {leftTab === 'streaming' && <WorldStreamingPanel />}
            </div>
          </aside>
        )}

        {/* Toggle Left Panel Button */}
        {!isGameMode && (
          <button
            onClick={() => setShowLeftPanel(!showLeftPanel)}
            className="absolute left-0 top-12 z-30 bg-[#161b22] border-r border-y border-[#30363d] text-slate-400 hover:text-white p-1 rounded-r opacity-60 hover:opacity-100"
            title={showLeftPanel ? 'Collapse Left Panel' : 'Expand Left Panel'}
          >
            {showLeftPanel ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        )}

        {/* CENTER: 3D VIEWPORT CANVAS */}
        <main className="flex-1 flex flex-col relative overflow-hidden bg-black">
          {/* Viewport Toolbar */}
          {!isGameMode && (
            <ViewportToolbar
              gizmoMode={gizmoMode}
              onSetGizmoMode={setGizmoMode}
              viewportMode={viewportMode}
              onSetViewportMode={setViewportMode}
              showGrid={showGrid}
              onToggleGrid={() => {
                const next = !showGrid;
                setShowGrid(next);
                if (viewportEngineRef.current) {
                  viewportEngineRef.current.showGrid = next;
                  if (viewportEngineRef.current.gridHelper) {
                    viewportEngineRef.current.gridHelper.visible = next;
                  }
                }
              }}
              snapEnabled={snapEnabled}
              onToggleSnap={() => {
                setSnapEnabled(!snapEnabled);
                if (viewportEngineRef.current) {
                  viewportEngineRef.current.snapEnabled = !snapEnabled;
                }
              }}
              onCameraView={(preset) => viewportEngineRef.current?.setCameraView(preset)}
              onFocusSelected={() => viewportEngineRef.current?.focusSelected()}
              selectedObjectId={selectedObjectId}
            />
          )}

          {/* Three.js Container */}
          <div ref={viewportContainerRef} className="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing">
            {/* Game Mode Live HUD Overlay */}
            {isGameMode && (
              <div className="absolute top-4 left-4 z-20 pointer-events-none flex flex-col space-y-2">
                <div className="bg-black/60 backdrop-blur border border-emerald-500/40 rounded-lg px-3 py-2 text-white font-mono text-xs flex items-center space-x-3 shadow-lg">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <div>
                    <div className="font-bold text-emerald-400">DAVIENGINE RUNTIME ACTIVE</div>
                    <div className="text-[10px] text-slate-300">Avatar: DAVI-01 Robot Scout</div>
                  </div>
                </div>

                <div className="bg-black/50 backdrop-blur border border-slate-700/60 rounded px-2.5 py-1.5 text-[10px] font-mono text-slate-300">
                  Controls: <strong>WASD / Arrows</strong> to Walk, <strong>Space</strong> to Jump
                </div>
              </div>
            )}

            {/* Mobile Touch Joystick & Action buttons in Game Mode */}
            {isGameMode && (
              <TouchControls
                onMoveChange={(move) => {
                  if (viewportEngineRef.current) {
                    viewportEngineRef.current.inputMove.forward = move.forward;
                    viewportEngineRef.current.inputMove.right = move.right;
                  }
                }}
                onJump={() => {
                  if (viewportEngineRef.current) {
                    viewportEngineRef.current.inputMove.jump = true;
                  }
                }}
                onAction={() => {
                  viewportEngineRef.current?.fireActionPulse();
                  audioSystem.playSound('synth_laser', { pitch: 1.2, volume: 0.5 });
                  addLog('Player fired laser beacon pulse!', 'info');
                }}
              />
            )}
          </div>
        </main>

        {/* Toggle Right Panel Button */}
        {!isGameMode && (
          <button
            onClick={() => setShowRightPanel(!showRightPanel)}
            className="absolute right-0 top-12 z-30 bg-[#161b22] border-l border-y border-[#30363d] text-slate-400 hover:text-white p-1 rounded-l opacity-60 hover:opacity-100"
            title={showRightPanel ? 'Collapse Right Panel' : 'Expand Right Panel'}
          >
            {showRightPanel ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        )}

        {/* RIGHT PANEL (Inspector / Material / Particle / Script Nodes) */}
        {showRightPanel && !isGameMode && (
          <aside className="w-68 md:w-80 bg-[#11161f] border-l border-[#21262d] flex flex-col shrink-0 z-20">
            {/* Right Tabs Bar */}
            <div className="h-9 bg-[#0d1117] border-b border-[#21262d] flex items-center px-1 space-x-1">
              <button
                onClick={() => setRightTab('inspector')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  rightTab === 'inspector'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Object Inspector"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Inspector</span>
              </button>

              <button
                onClick={() => setRightTab('materials')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  rightTab === 'materials'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="PBR Material Lab"
              >
                <Palette className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Materials</span>
              </button>

              <button
                onClick={() => setRightTab('particles')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  rightTab === 'particles'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Particle Lab"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Particles</span>
              </button>

              <button
                onClick={() => setRightTab('visualscript')}
                className={`flex-1 py-1 px-1.5 rounded text-[11px] font-medium flex items-center justify-center space-x-1 transition-colors ${
                  rightTab === 'visualscript'
                    ? 'bg-[#161b22] text-cyan-300 border border-[#30363d]'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Visual Script Graph"
              >
                <Network className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Graph</span>
              </button>
            </div>

            {/* Right Content */}
            <div className="flex-1 overflow-hidden">
              {rightTab === 'inspector' && (
                <Inspector
                  selectedObject={selectedObject}
                  onUpdateTransform={handleUpdateObjectTransform}
                  onUpdateMaterial={handleUpdateObjectMaterial}
                  onUpdateLighting={handleUpdateObjectLighting}
                  onUpdatePhysics={handleUpdateObjectPhysics}
                  onUpdateAI={handleUpdateObjectAI}
                  onUpdateAudio={handleUpdateObjectAudio}
                  onUpdateName={handleUpdateObjectName}
                />
              )}
              {rightTab === 'materials' && (
                <MaterialEditor
                  currentMaterial={selectedObject?.material || createDefaultMaterial()}
                  onApplyMaterial={(mat) => handleUpdateObjectMaterial(mat)}
                />
              )}
              {rightTab === 'particles' && <ParticleEditor />}
              {rightTab === 'visualscript' && <VisualScriptEditor />}
            </div>
          </aside>
        )}
      </div>

      {/* 3. BOTTOM PANEL (Console | Profiler | Scripts | Audio) */}
      {showBottomPanel && !isGameMode && (
        <footer className="h-48 md:h-52 bg-[#0d1117] border-t border-[#21262d] flex flex-col shrink-0 z-30">
          {/* Bottom Tabs Bar */}
          <div className="h-8 bg-[#161b22] border-b border-[#21262d] flex items-center justify-between px-2">
            <div className="flex items-center space-x-1">
              <button
                onClick={() => setBottomTab('console')}
                className={`flex items-center space-x-1 px-3 py-1 rounded-t text-[11px] font-semibold transition-colors border-t border-x ${
                  bottomTab === 'console'
                    ? 'bg-[#0d1117] border-[#30363d] text-cyan-300'
                    : 'bg-[#161b22] border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>Console</span>
              </button>

              <button
                onClick={() => setBottomTab('profiler')}
                className={`flex items-center space-x-1 px-3 py-1 rounded-t text-[11px] font-semibold transition-colors border-t border-x ${
                  bottomTab === 'profiler'
                    ? 'bg-[#0d1117] border-[#30363d] text-cyan-300'
                    : 'bg-[#161b22] border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>Profiler ({viewportStats.fps} FPS)</span>
              </button>

              <button
                onClick={() => setBottomTab('scripts')}
                className={`flex items-center space-x-1 px-3 py-1 rounded-t text-[11px] font-semibold transition-colors border-t border-x ${
                  bottomTab === 'scripts'
                    ? 'bg-[#0d1117] border-[#30363d] text-cyan-300'
                    : 'bg-[#161b22] border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-amber-400" />
                <span>Script Editor</span>
              </button>

              <button
                onClick={() => setBottomTab('audio')}
                className={`flex items-center space-x-1 px-3 py-1 rounded-t text-[11px] font-semibold transition-colors border-t border-x ${
                  bottomTab === 'audio'
                    ? 'bg-[#0d1117] border-[#30363d] text-cyan-300'
                    : 'bg-[#161b22] border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                <span>Audio Mixer</span>
              </button>
            </div>

            {/* Minimize / Hide Button */}
            <button
              onClick={() => setShowBottomPanel(false)}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-[#21262d]"
              title="Minimize Bottom Panel"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Bottom Panel Content */}
          <div className="flex-1 overflow-hidden">
            {bottomTab === 'console' && (
              <ConsolePanel
                logs={logs}
                onClearLogs={() => setLogs([])}
                onExecuteCommand={handleExecuteCommand}
              />
            )}
            {bottomTab === 'profiler' && <ProfilerPanel stats={viewportStats} />}
            {bottomTab === 'scripts' && (
              <ScriptCodeEditor
                onRunScript={(name, code) => {
                  addLog(`Compiled script: ${name}`, 'success');
                  try {
                    addLog(`[Script Runner] Executing ${name} logic block...`, 'info');
                  } catch (e: any) {
                    addLog(`Error executing script: ${e?.message}`, 'error');
                  }
                }}
              />
            )}
            {bottomTab === 'audio' && <AudioManagerPanel />}
          </div>
        </footer>
      )}

      {/* 4. MODALS */}
      <Modals
        activeModal={activeModal}
        onClose={() => setActiveModal(null)}
        project={project}
        onUpdateProjectName={(name) => setProject((prev) => ({ ...prev, name }))}
        onSelectScene={(sceneId) => {
          setActiveSceneId(sceneId);
          setProject((prev) => ({ ...prev, currentSceneId: sceneId }));
        }}
        onCreateScene={handleCreateScene}
        onDuplicateProject={() => {
          const dup = { ...project, name: `${project.name} (Copy)` };
          setProject(dup);
          addLog(`Project duplicated: ${dup.name}`, 'success');
        }}
        onExportProject={handleExportProject}
        onImportProject={handleImportProject}
      />
    </div>
  );
}
