/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Search,
  Store,
  PlusCircle,
  ShoppingBag,
  Heart,
  User,
  ShieldCheck,
  QrCode,
  Tag,
  Star,
  MapPin,
  Truck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Sparkles,
  MessageSquare,
  Package,
  X,
  ChevronRight,
  Filter,
  DollarSign,
  Phone,
  Check,
  Send,
  Trash2,
  Edit3,
  Settings,
  Lock,
  LogIn,
  ChevronDown,
  Clock,
  CheckCircle,
  Menu,
  Home,
  Grid,
  ShoppingBag as CartIcon,
  Ticket,
  HelpCircle,
  Globe,
  Bell,
  Maximize2,
  MessageCircle,
  Zap
} from 'lucide-react';

interface Product {
  id: string;
  storeId: string;
  storeName: string;
  name: string;
  category: string;
  price: number; // in NPR
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  tags: string[];
  stock: number;
  description: string;
  variants?: string[];
  sizes?: string[];
  colors?: string[];
  discountBadge?: string;
  timerBadge?: string;
}

interface StoreType {
  id: string;
  name: string;
  ownerName: string;
  phone: string;
  city: string;
  category: string;
  description: string;
  logo: string;
  verified: boolean;
  status: 'Pending' | 'Approved' | 'Rejected';
  txnId: string;
  createdAt: string;
}

interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
}

interface Order {
  id: string;
  items: CartItem[];
  total: number;
  customerName: string;
  phone: string;
  city: string;
  address: string;
  paymentMethod: string;
  status: 'Pending' | 'Processing' | 'Delivered' | 'Cancelled';
  date: string;
}

interface AdminSettingsType {
  fee: number;
  qrCode: string;
  instructions: string;
}

interface ChatMessage {
  sender: 'buyer' | 'seller';
  text: string;
  time: string;
}

const INITIAL_STORES: StoreType[] = [
  {
    id: 'store-1',
    name: 'Kathmandu Electronics & Gadgets',
    ownerName: 'Sanjay Shrestha',
    phone: '9841234567',
    city: 'Kathmandu',
    category: 'Electronics',
    description: 'Your one-stop shop for smartphones, wireless earbuds, smartwatches, and chargers in New Road.',
    logo: 'https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=300&q=80',
    verified: true,
    txnId: 'TXN-INIT-101',
    createdAt: '2026-01-15'
  },
  {
    id: 'store-2',
    name: 'Himalayan Threads & Fashion',
    ownerName: 'Sunita Gurung',
    phone: '9818987654',
    city: 'Pokhara',
    category: 'Fashion & Clothing',
    description: 'Authentic Nepali pashmina, traditional Dhaka topi, stylish kurtis, and modern streetwear.',
    logo: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=300&q=80',
    verified: true,
    txnId: 'TXN-INIT-102',
    createdAt: '2026-02-10'
  },
  {
    id: 'store-3',
    name: 'Patan Art & Handicrafts',
    ownerName: 'Ramesh Shakya',
    phone: '9803332211',
    city: 'Lalitpur',
    category: 'Local Handicrafts',
    description: 'Handmade copper statues, singing bowls, wood carvings, and authentic Nepali souvenirs.',
    logo: 'https://images.unsplash.com/photo-1582582494705-f829b6bf5681?auto=format&fit=crop&w=300&q=80',
    verified: true,
    txnId: 'TXN-INIT-103',
    createdAt: '2026-02-20'
  }
];

const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    storeId: 'store-2',
    storeName: 'Himalayan Threads & Fashion',
    name: 'Yellow Sweatshirt',
    category: 'Clothing',
    price: 1999,
    rating: 4.8,
    reviewsCount: 142,
    image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=600&q=80',
    tags: ['clothing', 'sweater', 'yellow', 'fashion'],
    stock: 25,
    description: 'Cozy and stylish yellow fleece sweatshirt for everyday comfort in Nepal.',
    colors: ['Yellow', 'Black', 'Grey'],
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: 'prod-2',
    storeId: 'store-1',
    storeName: 'Kathmandu Electronics & Gadgets',
    name: 'Black Headphones',
    category: 'Electronics',
    price: 4499,
    rating: 4.9,
    reviewsCount: 98,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
    tags: ['headphones', 'audio', 'wireless', 'black'],
    stock: 18,
    description: 'Premium over-ear wireless headphones with active noise cancellation and deep bass.',
    colors: ['Matte Black', 'Silver'],
    sizes: ['Standard']
  },
  {
    id: 'prod-3',
    storeId: 'store-2',
    storeName: 'Himalayan Threads & Fashion',
    name: "Men's T-Shirt",
    category: 'Clothing',
    price: 1080,
    originalPrice: 1200,
    rating: 4.6,
    reviewsCount: 215,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
    tags: ['tshirt', 'cotton', 'mens', 'grey'],
    stock: 50,
    description: 'Soft 100% breathable cotton men’s grey t-shirt.',
    colors: ['Grey', 'White', 'Navy'],
    sizes: ['M', 'L', 'XL', 'XXL'],
    discountBadge: '10% OFF',
    timerBadge: '19:59'
  },
  {
    id: 'prod-4',
    storeId: 'store-3',
    storeName: 'Patan Art & Handicrafts',
    name: 'Leather Handbag',
    category: 'Accessories',
    price: 2000,
    originalPrice: 2500,
    rating: 4.9,
    reviewsCount: 76,
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80',
    tags: ['handbag', 'leather', 'brown', 'accessories'],
    stock: 10,
    description: 'Handcrafted genuine brown leather luxury handbag.',
    colors: ['Brown', 'Tan', 'Dark Black'],
    sizes: ['One Size'],
    discountBadge: '20% OFF'
  }
];

const CATEGORIES = [
  'All',
  'Clothing',
  'Electronics',
  'Home',
  'Shoes',
  'Groceries',
  'Local Handicrafts'
];

const NEPALI_CITIES = [
  'All Nepal',
  'Kathmandu',
  'Pokhara',
  'Lalitpur',
  'Bhaktapur',
  'Biratnagar',
  'Butwal',
  'Itahari',
  'Dharan',
  'Nepalgunj'
];

const APP_LOGO = '/assets/aistudio/file_000000001d0c8211a0a7a9e3e89995b2_95ccc716.png';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'search' | 'categories' | 'wishlist' | 'account' | 'add-store' | 'seller-login' | 'cart' | 'orders' | 'merchant-dash' | 'admin-settings' | 'product-detail' | 'store-profile' | 'buy-now-checkout'>('home');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCity, setSelectedCity] = useState('All Nepal');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedStore, setSelectedStore] = useState<StoreType | null>(null);
  const [addMenuOpen, setAddMenuOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [qrModalImg, setQrModalImg] = useState<string | null>(null);

  // Buy Now Checkout State
  const [buyNowQty, setBuyNowQty] = useState(1);
  const [buyNowColor, setBuyNowColor] = useState('');
  const [buyNowSize, setBuyNowSize] = useState('');
  const [buyNowForm, setBuyNowForm] = useState({
    customerName: '',
    phone: '',
    city: 'Kathmandu',
    address: '',
    paymentMethod: 'Cash on Delivery (COD)'
  });

  // Chat with Seller State
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { sender: 'seller', text: 'Namaste! Welcome to our store. How can I help you with this product?', time: 'Just now' }
  ]);
  const [chatInput, setChatInput] = useState('');

  // Admin Auth State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('daraz_admin_auth_v8') === 'true';
  });
  const [adminEmailInput, setAdminEmailInput] = useState('');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminLoginError, setAdminLoginError] = useState('');

  // Persistent App Data
  const [stores, setStores] = useState<StoreType[]>(() => {
    const saved = localStorage.getItem('daraz_stores_np_v8');
    return saved ? JSON.parse(saved) : INITIAL_STORES;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('daraz_products_np_v8');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('daraz_cart_np_v8');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('daraz_orders_np_v8');
    return saved ? JSON.parse(saved) : [];
  });

  const [adminSettings, setAdminSettings] = useState<AdminSettingsType>(() => {
    const saved = localStorage.getItem('daraz_admin_settings_v8');
    return saved ? JSON.parse(saved) : {
      fee: 500,
      qrCode: '/assets/aistudio/IMG-20261019-WA0000_690fd2ec.jpg',
      instructions: 'Scan the eSewa QR code to pay the Rs. 500 one-time store registration fee. Submit your Transaction ID / Reference below.'
    };
  });

  const [currentMerchantStoreId, setCurrentMerchantStoreId] = useState<string | null>(() => {
    return localStorage.getItem('daraz_current_merchant_id_v8') || null;
  });

  // Forms
  const [loginPhone, setLoginPhone] = useState('');
  const [loginError, setLoginError] = useState('');
  const [storeForm, setStoreForm] = useState({
    name: '',
    ownerName: '',
    phone: '',
    city: 'Kathmandu',
    category: 'Electronics',
    description: '',
    logo: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=300&q=80',
    txnId: ''
  });
  const [storeSubmitted, setStoreSubmitted] = useState(false);
  const [storeCreationError, setStoreCreationError] = useState('');

  const [productForm, setProductForm] = useState({
    name: '',
    category: 'Clothing',
    price: '',
    originalPrice: '',
    stock: '10',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
    tags: '',
    variants: '',
    description: ''
  });

  const [checkoutForm, setCheckoutForm] = useState({
    customerName: '',
    phone: '',
    city: 'Kathmandu',
    address: '',
    paymentMethod: 'Cash on Delivery (COD)'
  });
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);

  // AI Assistant
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiMessages, setAiMessages] = useState<{ sender: 'user' | 'ai'; text: string }[]>([
    { sender: 'ai', text: 'Namaste! I am your NepaliMart AI shopping assistant. How can I help you find clothes, electronics, or shoes today?' }
  ]);
  const [aiInput, setAiInput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    localStorage.setItem('daraz_stores_np_v8', JSON.stringify(stores));
  }, [stores]);
  useEffect(() => {
    localStorage.setItem('daraz_products_np_v8', JSON.stringify(products));
  }, [products]);
  useEffect(() => {
    localStorage.setItem('daraz_cart_np_v8', JSON.stringify(cart));
  }, [cart]);
  useEffect(() => {
    localStorage.setItem('daraz_orders_np_v8', JSON.stringify(orders));
  }, [orders]);
  useEffect(() => {
    localStorage.setItem('daraz_admin_settings_v8', JSON.stringify(adminSettings));
  }, [adminSettings]);
  useEffect(() => {
    if (currentMerchantStoreId) {
      localStorage.setItem('daraz_current_merchant_id_v8', currentMerchantStoreId);
    } else {
      localStorage.removeItem('daraz_current_merchant_id_v8');
    }
  }, [currentMerchantStoreId]);
  useEffect(() => {
    localStorage.setItem('daraz_admin_auth_v8', isAdminAuthenticated ? 'true' : 'false');
  }, [isAdminAuthenticated]);

  // Initialize product variants on select
  useEffect(() => {
    if (selectedProduct) {
      setBuyNowColor(selectedProduct.colors?.[0] || 'Standard');
      setBuyNowSize(selectedProduct.sizes?.[0] || 'Standard');
      setBuyNowQty(1);
    }
  }, [selectedProduct]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1, selectedColor: product.colors?.[0], selectedSize: product.sizes?.[0] }];
    });
  };

  const updateCartQty = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      }).filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const toggleWishlist = (productId: string) => {
    setWishlist(prev =>
      prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]
    );
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminEmailInput.trim() === 'meyouknow941@gmail.com' && adminPasswordInput === '9813634899@SR') {
      setIsAdminAuthenticated(true);
      setAdminLoginError('');
      setAdminEmailInput('');
      setAdminPasswordInput('');
    } else {
      setAdminLoginError('Invalid Admin credentials.');
    }
  };

  const handleCreateStore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeForm.name || !storeForm.ownerName || !storeForm.phone || !storeForm.description) {
      setStoreCreationError('Please fill in all required store details.');
      return;
    }

    const newStore: StoreType = {
      id: `store-${Date.now()}`,
      name: storeForm.name,
      ownerName: storeForm.ownerName,
      phone: storeForm.phone,
      city: storeForm.city,
      category: storeForm.category,
      description: storeForm.description,
      logo: storeForm.logo || 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=300&q=80',
      verified: true,
      status: 'Approved',
      txnId: `STORE-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };

    setStores(prev => [newStore, ...prev]);
    setStoreSubmitted(true);
    setStoreCreationError('');
  };

  const handleSellerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const foundStore = stores.find(s => s.phone.trim() === loginPhone.trim());
    if (!foundStore) {
      setLoginError('No store found with this phone number.');
      return;
    }
    if (!foundStore.verified) {
      setLoginError('Your store registration is currently pending admin payment verification.');
      return;
    }
    setCurrentMerchantStoreId(foundStore.id);
    setActiveTab('merchant-dash');
    setLoginPhone('');
    setLoginError('');
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMerchantStoreId) return;
    const currentStore = stores.find(s => s.id === currentMerchantStoreId);
    if (!currentStore || !currentStore.verified) {
      alert('Store must be verified by admin before adding products.');
      return;
    }
    if (!productForm.name || !productForm.price) {
      alert('Please provide product name and price.');
      return;
    }

    const newProd: Product = {
      id: `prod-${Date.now()}`,
      storeId: currentMerchantStoreId,
      storeName: currentStore.name,
      name: productForm.name,
      category: productForm.category,
      price: Number(productForm.price),
      originalPrice: productForm.originalPrice ? Number(productForm.originalPrice) : undefined,
      rating: 5.0,
      reviewsCount: 1,
      image: productForm.image || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
      tags: productForm.tags ? productForm.tags.split(',').map(t => t.trim()) : ['nepal'],
      stock: Number(productForm.stock) || 10,
      description: productForm.description || 'Quality product.',
      variants: productForm.variants ? productForm.variants.split(',').map(v => v.trim()) : undefined,
      colors: ['Standard'],
      sizes: ['Standard']
    };

    setProducts(prev => [newProd, ...prev]);
    setProductForm({
      name: '',
      category: 'Clothing',
      price: '',
      originalPrice: '',
      stock: '10',
      image: '',
      tags: '',
      variants: '',
      description: ''
    });
    alert('Product added successfully!');
  };

  const handleBuyNowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    if (!buyNowForm.customerName || !buyNowForm.phone || !buyNowForm.address) {
      alert('Please provide your name, phone number, and delivery address.');
      return;
    }

    const itemTotal = selectedProduct.price * buyNowQty;
    const newOrder: Order = {
      id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      items: [{
        product: selectedProduct,
        quantity: buyNowQty,
        selectedColor: buyNowColor,
        selectedSize: buyNowSize
      }],
      total: itemTotal + 100, // delivery fee
      customerName: buyNowForm.customerName,
      phone: buyNowForm.phone,
      city: buyNowForm.city,
      address: buyNowForm.address,
      paymentMethod: buyNowForm.paymentMethod,
      status: 'Pending',
      date: new Date().toLocaleDateString()
    };

    setOrders(prev => [newOrder, ...prev]);
    setOrderSuccess(newOrder.id);
    setActiveTab('orders');
    alert('Order placed successfully via Buy Now!');
  };

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    if (!checkoutForm.customerName || !checkoutForm.phone || !checkoutForm.address) {
      alert('Please fill in your delivery contact and address details.');
      return;
    }

    const newOrder: Order = {
      id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      items: [...cart],
      total: cartTotal + 100,
      customerName: checkoutForm.customerName,
      phone: checkoutForm.phone,
      city: checkoutForm.city,
      address: checkoutForm.address,
      paymentMethod: checkoutForm.paymentMethod,
      status: 'Pending',
      date: new Date().toLocaleDateString()
    };

    setOrders(prev => [newOrder, ...prev]);
    setCart([]);
    setOrderSuccess(newOrder.id);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const txt = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { sender: 'buyer', text: txt, time: 'Just now' }]);
    setTimeout(() => {
      setChatMessages(prev => [...prev, { sender: 'seller', text: 'Thank you for messaging! We have noted your query and will ship your order promptly.', time: 'Just now' }]);
    }, 1000);
  };

  const filteredProducts = products.filter(p => {
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const storeObj = stores.find(s => s.id === p.storeId);
    const matchesCity = selectedCity === 'All Nepal' || (storeObj && storeObj.city === selectedCity);
    const matchesQuery = !searchQuery || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())) || p.storeName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesCity && matchesQuery;
  });

  const currentMerchantStore = stores.find(s => s.id === currentMerchantStoreId);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans pb-24 selection:bg-red-500 selection:text-white">
      {/* Top Header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-4">
          
          {/* Hamburger Menu -> Opens Daraz-style Drawer */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setDrawerOpen(true)}
              className="p-1 text-gray-800 hover:text-red-600 focus:outline-none"
              title="Open Menu"
            >
              <Menu className="w-6 h-6" />
            </button>
            <button
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-2.5 focus:outline-none"
            >
              <img
                src={APP_LOGO}
                alt="NepaliMart Logo"
                className="w-9 h-9 object-contain rounded-xl shadow-xs"
                referrerPolicy="no-referrer"
              />
              <span className="text-xl font-bold tracking-tight text-gray-900">
                Nepali<span className="text-red-600">Mart</span>
              </span>
            </button>
          </div>

          {/* Right Shopping Cart Badge */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('cart')}
              className="relative p-2 text-gray-800 hover:text-red-600 transition-colors"
            >
              <CartIcon className="w-6 h-6" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Search & "+ Add" Button Row */}
        <div className="px-4 pb-3 flex items-center gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Search products, stores, brands..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activeTab !== 'search' && activeTab !== 'home') setActiveTab('search');
              }}
              onFocus={() => { if (activeTab !== 'search' && activeTab !== 'home') setActiveTab('search'); }}
              className="w-full bg-gray-100/90 border border-gray-200 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-red-600 focus:bg-white transition-all shadow-inner"
            />
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
          </div>

          {/* "+ Add" Dropdown Button */}
          <div className="relative">
            <button
              onClick={() => setAddMenuOpen(!addMenuOpen)}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-all flex items-center gap-1 shrink-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Add</span>
              <ChevronDown className="w-3 h-3 ml-0.5" />
            </button>

            {addMenuOpen && (
              <div className="absolute right-0 mt-2 w-52 bg-white border border-gray-200 rounded-xl shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
                <button
                  onClick={() => { setActiveTab('add-store'); setAddMenuOpen(false); }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold text-gray-800 hover:bg-red-50 hover:text-red-600 flex items-center gap-2"
                >
                  <Store className="w-4 h-4 text-red-600" />
                  <span>Create Your Store</span>
                </button>
                <button
                  onClick={() => { setActiveTab('seller-login'); setAddMenuOpen(false); }}
                  className="w-full text-left px-4 py-2 text-xs font-semibold text-gray-800 hover:bg-red-50 hover:text-red-600 flex items-center gap-2"
                >
                  <LogIn className="w-4 h-4 text-red-600" />
                  <span>Seller Login</span>
                </button>
                {currentMerchantStoreId && (
                  <button
                    onClick={() => { setActiveTab('merchant-dash'); setAddMenuOpen(false); }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-gray-800 hover:bg-red-50 hover:text-red-600 flex items-center gap-2 border-t border-gray-100"
                  >
                    <Package className="w-4 h-4 text-red-600" />
                    <span>Seller Dashboard</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Slide-over Navigation Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={() => setDrawerOpen(false)} />
          <div className="relative w-80 bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-300">
            
            {/* Drawer Header with Logo */}
            <div className="bg-red-600 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={APP_LOGO}
                  alt="NepaliMart Logo"
                  className="w-10 h-10 object-contain rounded-xl bg-white p-1 shadow-sm"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h3 className="font-bold text-sm">NepaliMart Nepal</h3>
                  <span className="text-[10px] text-red-100">Official Multi-Vendor App</span>
                </div>
              </div>
              <button onClick={() => setDrawerOpen(false)} className="text-white p-1 rounded-lg hover:bg-red-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Menu Items */}
            <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
              <button
                onClick={() => { setActiveTab('home'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <Home className="w-4 h-4 text-red-600" />
                <span>Home</span>
              </button>

              <button
                onClick={() => { setActiveTab('orders'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <Package className="w-4 h-4 text-red-600" />
                <span>My Orders</span>
              </button>

              <button
                onClick={() => { setActiveTab('wishlist'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <Heart className="w-4 h-4 text-red-600" />
                <span>My Wishlist</span>
              </button>

              <button
                onClick={() => { setActiveTab('cart'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <ShoppingBag className="w-4 h-4 text-red-600" />
                <span>Shopping Cart ({cartItemCount})</span>
              </button>

              <div className="pt-3 pb-1 px-4 text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                Seller & Business Portal
              </div>

              <button
                onClick={() => { setActiveTab('add-store'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <Store className="w-4 h-4 text-red-600" />
                <span>Create Your Store (Rs. {adminSettings.fee})</span>
              </button>

              <button
                onClick={() => { setActiveTab('seller-login'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <LogIn className="w-4 h-4 text-red-600" />
                <span>Seller Login</span>
              </button>

              {currentMerchantStoreId && (
                <button
                  onClick={() => { setActiveTab('merchant-dash'); setDrawerOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-800 hover:bg-red-50 hover:text-red-600 transition-colors"
                >
                  <Package className="w-4 h-4 text-red-600" />
                  <span>Seller Dashboard</span>
                </button>
              )}

              {/* ADMIN SETTINGS AT THE DOWN SIDE OF THE MENU */}
              <div className="pt-6 pb-1 px-4 text-[11px] font-bold text-red-600 uppercase tracking-wider border-t border-gray-100 mt-4">
                System & Admin Area
              </div>

              <button
                onClick={() => { setActiveTab('admin-settings'); setDrawerOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-gray-900 hover:bg-gray-100 transition-colors bg-gray-50 border border-gray-200"
              >
                <Settings className="w-4 h-4 text-red-600" />
                <span>Admin Panel & Settings</span>
              </button>

              <div className="pt-3 pb-1 px-4 text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                Support & Info
              </div>

              <div className="px-4 py-2 text-xs text-gray-500 space-y-1">
                <p>Customer Care: 01-5970000</p>
                <p>Location: Kathmandu, Nepal</p>
                <p className="font-semibold text-red-600">Currency: NPR (रू / Rs.)</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Lightbox Modal */}
      {qrModalImg && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 text-center space-y-4 relative shadow-2xl animate-in zoom-in-95">
            <button
              onClick={() => setQrModalImg(null)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-800 p-1 bg-gray-100 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
            <h3 className="font-bold text-base text-gray-900">Official eSewa QR Code</h3>
            <p className="text-xs text-gray-600">Scan this QR code using eSewa or Khalti to pay the Rs. {adminSettings.fee} fee.</p>
            <div className="bg-gray-50 p-3 rounded-xl border border-gray-200 inline-block">
              <img
                src={qrModalImg}
                alt="QR Code Full View"
                className="w-64 h-64 object-contain mx-auto rounded-lg"
                referrerPolicy="no-referrer"
              />
            </div>
            <button
              onClick={() => setQrModalImg(null)}
              className="w-full bg-red-600 hover:bg-red-700 text-white py-2.5 rounded-xl text-xs font-bold"
            >
              Close Preview
            </button>
          </div>
        </div>
      )}

      {/* Chat with Seller Drawer / Modal */}
      {chatOpen && selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md h-[500px] sm:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col overflow-hidden border border-gray-200">
            <div className="bg-red-600 text-white p-4 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="bg-white/20 p-1.5 rounded-full">
                  <Store className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Chat with {selectedProduct.storeName}</h3>
                  <span className="text-[10px] text-red-100">Regarding: {selectedProduct.name}</span>
                </div>
              </div>
              <button onClick={() => setChatOpen(false)} className="text-white hover:bg-red-700 p-1 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
              {chatMessages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.sender === 'buyer' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs ${
                    msg.sender === 'buyer'
                      ? 'bg-red-600 text-white rounded-br-xs'
                      : 'bg-white text-gray-800 border border-gray-200 shadow-2xs rounded-bl-xs'
                  }`}>
                    <p>{msg.text}</p>
                    <span className={`text-[9px] block mt-1 ${msg.sender === 'buyer' ? 'text-red-100' : 'text-gray-400'}`}>{msg.time}</span>
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendChat} className="p-3 bg-white border-t border-gray-200 flex gap-2">
              <input
                type="text"
                placeholder="Ask seller about size, color, delivery..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-1 bg-gray-100 border border-gray-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-red-600"
              />
              <button type="submit" className="bg-red-600 hover:bg-red-700 text-white p-2.5 rounded-xl">
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="container mx-auto px-4 py-4 space-y-6">

        {/* ================= HOME TAB ================= */}
        {activeTab === 'home' && (
          <div className="space-y-6">
            
            {/* Categories Section */}
            <div className="space-y-3">
              <h2 className="text-lg font-bold text-gray-900">Categories</h2>
              <div className="grid grid-cols-4 gap-4">
                {[
                  { name: 'Clothing', icon: '👕', bg: 'bg-amber-100', cat: 'Clothing' },
                  { name: 'Electronics', icon: '💻', bg: 'bg-sky-100', cat: 'Electronics' },
                  { name: 'Home', icon: '🏠', bg: 'bg-blue-100', cat: 'Home' },
                  { name: 'Shoes', icon: '👠', bg: 'bg-rose-100', cat: 'Shoes' }
                ].map(item => (
                  <button
                    key={item.name}
                    onClick={() => {
                      setSelectedCategory(item.cat);
                      setActiveTab('search');
                    }}
                    className="flex flex-col items-center gap-2 group focus:outline-none"
                  >
                    <div className={`w-16 h-16 rounded-full ${item.bg} flex items-center justify-center text-2xl shadow-xs group-hover:scale-105 transition-transform`}>
                      {item.icon}
                    </div>
                    <span className="text-xs font-medium text-gray-800">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Featured Section */}
            <div className="space-y-3">
              <h2 className="text-lg font-bold text-gray-900">Featured</h2>
              <div className="grid grid-cols-2 gap-4">
                {products.map(product => (
                  <div
                    key={product.id}
                    onClick={() => {
                      setSelectedProduct(product);
                      setActiveTab('product-detail');
                    }}
                    className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between cursor-pointer relative"
                  >
                    <div className="relative aspect-square bg-gray-50 overflow-hidden">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      {product.discountBadge && (
                        <span className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs">
                          {product.discountBadge}
                        </span>
                      )}
                      {product.timerBadge && (
                        <span className="absolute top-2 right-2 bg-red-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xs">
                          {product.timerBadge}
                        </span>
                      )}
                    </div>

                    <div className="p-3.5 space-y-1">
                      <h3 className="font-semibold text-xs md:text-sm text-gray-900 line-clamp-1">{product.name}</h3>
                      <div className="flex items-baseline gap-2 pt-0.5">
                        <span className="font-bold text-sm md:text-base text-red-600">Rs. {product.price.toLocaleString()}</span>
                        {product.originalPrice && (
                          <span className="text-xs text-gray-400 line-through">Rs. {product.originalPrice.toLocaleString()}</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= SEARCH & CATALOG TAB ================= */}
        {activeTab === 'search' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-white p-3 rounded-xl border border-gray-200 shadow-2xs">
              <span className="text-xs font-bold text-gray-700">Category: {selectedCategory}</span>
              <button onClick={() => setSelectedCategory('All')} className="text-xs text-red-600 font-bold hover:underline">Reset Filter</button>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-2xl p-12 text-center space-y-3">
                <AlertCircle className="w-10 h-10 text-gray-400 mx-auto" />
                <h3 className="text-base font-bold text-gray-800">No products found</h3>
                <p className="text-xs text-gray-500">Try browsing another category.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {filteredProducts.map(product => (
                  <div
                    key={product.id}
                    onClick={() => {
                      setSelectedProduct(product);
                      setActiveTab('product-detail');
                    }}
                    className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between cursor-pointer"
                  >
                    <div className="relative aspect-square bg-gray-50 overflow-hidden">
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="p-3.5 space-y-1">
                      <h3 className="font-semibold text-xs md:text-sm text-gray-900 line-clamp-1">{product.name}</h3>
                      <span className="font-bold text-sm text-red-600 block">Rs. {product.price.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= CATEGORIES TAB ================= */}
        {activeTab === 'categories' && (
          <div className="space-y-4">
            <h1 className="text-xl font-bold text-gray-900">All Categories</h1>
            <div className="grid grid-cols-2 gap-3">
              {CATEGORIES.filter(c => c !== 'All').map(cat => (
                <button
                  key={cat}
                  onClick={() => {
                    setSelectedCategory(cat);
                    setActiveTab('search');
                  }}
                  className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs text-left font-bold text-gray-800 hover:border-red-600 hover:text-red-600 transition-colors flex items-center justify-between"
                >
                  <span>{cat}</span>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ================= WISHLIST TAB ================= */}
        {activeTab === 'wishlist' && (
          <div className="space-y-4">
            <h1 className="text-xl font-bold text-gray-900">My Wishlist</h1>
            {wishlist.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-2xl p-12 text-center space-y-3">
                <Heart className="w-10 h-10 text-gray-300 mx-auto" />
                <h3 className="text-base font-bold text-gray-800">Your wishlist is empty</h3>
                <p className="text-xs text-gray-500">Tap heart icons on products to save them here.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {products.filter(p => wishlist.includes(p.id)).map(product => (
                  <div
                    key={product.id}
                    onClick={() => {
                      setSelectedProduct(product);
                      setActiveTab('product-detail');
                    }}
                    className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-xs cursor-pointer"
                  >
                    <div className="aspect-square bg-gray-50">
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="p-3">
                      <h3 className="font-semibold text-xs text-gray-900">{product.name}</h3>
                      <span className="font-bold text-sm text-red-600">Rs. {product.price.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= ACCOUNT TAB ================= */}
        {activeTab === 'account' && (
          <div className="space-y-4 max-w-md mx-auto">
            <div className="flex items-center gap-3 bg-white p-4 rounded-2xl border border-gray-200 shadow-xs">
              <img src={APP_LOGO} alt="Logo" className="w-12 h-12 object-contain rounded-xl bg-red-50 p-1" referrerPolicy="no-referrer" />
              <div>
                <h1 className="text-lg font-bold text-gray-900">NepaliMart</h1>
                <p className="text-xs text-gray-500">Nepal's Premier Multi-Vendor Store</p>
              </div>
            </div>
            <div className="bg-white border border-gray-200 rounded-2xl p-6 space-y-4 shadow-xs">
              <div className="space-y-2">
                <button
                  onClick={() => setActiveTab('add-store')}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm"
                >
                  <Store className="w-4 h-4" />
                  <span>Create Your Store (Rs. {adminSettings.fee})</span>
                </button>
                <button
                  onClick={() => setActiveTab('seller-login')}
                  className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Seller Login</span>
                </button>
                {currentMerchantStoreId && (
                  <button
                    onClick={() => setActiveTab('merchant-dash')}
                    className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2"
                  >
                    <Package className="w-4 h-4" />
                    <span>Seller Dashboard</span>
                  </button>
                )}
                <button
                  onClick={() => setActiveTab('orders')}
                  className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2"
                >
                  <Package className="w-4 h-4" />
                  <span>My Orders</span>
                </button>
                <button
                  onClick={() => setActiveTab('admin-settings')}
                  className="w-full bg-gray-900 hover:bg-black text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2 mt-4"
                >
                  <Settings className="w-4 h-4" />
                  <span>Admin Panel & Settings</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= ADD STORE TAB ================= */}
        {activeTab === 'add-store' && (
          <div className="max-w-xl mx-auto bg-white border border-gray-200 rounded-2xl p-6 shadow-md space-y-6">
            <button onClick={() => setActiveTab('home')} className="text-xs text-red-600 font-bold hover:underline">← Back</button>
            <div className="border-b border-gray-100 pb-3 flex items-center gap-3">
              <img src={APP_LOGO} alt="Logo" className="w-10 h-10 object-contain rounded-xl bg-red-50 p-1" referrerPolicy="no-referrer" />
              <div>
                <h1 className="text-xl font-black text-gray-900">Create Your Store on NepaliMart</h1>
                <p className="text-xs text-gray-600">Register your business instantly and start selling.</p>
              </div>
            </div>

            {storeSubmitted ? (
              <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-green-600 mx-auto" />
                <h3 className="font-bold text-base text-green-900">Store Created Successfully!</h3>
                <p className="text-xs text-green-700">Your store is now active. You can log in as a seller to add products.</p>
                <button onClick={() => setActiveTab('seller-login')} className="bg-red-600 text-white px-5 py-2 rounded-xl text-xs font-bold">Go to Seller Login</button>
              </div>
            ) : (
              <>
                {storeCreationError && (
                  <div className="bg-red-50 border-l-4 border-red-600 p-3 rounded-r-xl text-red-700 text-xs font-medium">
                    {storeCreationError}
                  </div>
                )}
                <form onSubmit={handleCreateStore} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Store Name *</label>
                    <input type="text" placeholder="e.g. Kathmandu Fashion" value={storeForm.name} onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Owner Name *</label>
                    <input type="text" placeholder="e.g. Ram Shrestha" value={storeForm.ownerName} onChange={(e) => setStoreForm({ ...storeForm, ownerName: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Mobile Phone *</label>
                      <input type="text" placeholder="9841234567" value={storeForm.phone} onChange={(e) => setStoreForm({ ...storeForm, phone: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1">City *</label>
                      <select value={storeForm.city} onChange={(e) => setStoreForm({ ...storeForm, city: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs">
                        {NEPALI_CITIES.filter(c => c !== 'All Nepal').map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Description *</label>
                    <textarea rows={2} placeholder="Store description..." value={storeForm.description} onChange={(e) => setStoreForm({ ...storeForm, description: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
                  </div>

                  <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl text-xs shadow-md">
                    Create Store Instantly
                  </button>
                </form>
              </>
            )}
          </div>
        )}

        {/* ================= SELLER LOGIN TAB ================= */}
        {activeTab === 'seller-login' && (
          <div className="max-w-md mx-auto bg-white border border-gray-200 rounded-2xl p-6 shadow-md space-y-4">
            <button onClick={() => setActiveTab('home')} className="text-xs text-red-600 font-bold hover:underline">← Back</button>
            <div className="flex items-center gap-3">
              <img src={APP_LOGO} alt="Logo" className="w-10 h-10 object-contain rounded-xl bg-red-50 p-1" referrerPolicy="no-referrer" />
              <h1 className="text-xl font-black text-gray-900">Seller Login</h1>
            </div>
            {loginError && <div className="bg-red-50 text-red-700 p-2.5 rounded text-xs">{loginError}</div>}
            <form onSubmit={handleSellerLogin} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Mobile Phone</label>
                <input type="text" placeholder="e.g. 9841234567" value={loginPhone} onChange={(e) => setLoginPhone(e.target.value)} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
              </div>
              <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl text-xs">Login to Dashboard</button>
            </form>
          </div>
        )}

        {/* ================= MERCHANT DASHBOARD TAB ================= */}
        {activeTab === 'merchant-dash' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-gray-200 flex justify-between items-center shadow-xs">
              <div className="flex items-center gap-3">
                <img src={APP_LOGO} alt="Logo" className="w-10 h-10 object-contain rounded-xl bg-red-50 p-1" referrerPolicy="no-referrer" />
                <div>
                  <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2 py-0.5 rounded">Verified Seller</span>
                  <h1 className="text-xl font-bold text-gray-900 mt-1">{currentMerchantStore?.name}</h1>
                </div>
              </div>
              <button onClick={() => { setCurrentMerchantStoreId(null); setActiveTab('home'); }} className="bg-gray-100 px-3 py-1.5 rounded text-xs font-bold">Logout</button>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-xs space-y-4">
              <h2 className="text-base font-bold text-gray-900">Add Product to Store</h2>
              <form onSubmit={handleAddProduct} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Product Name *</label>
                    <input type="text" placeholder="e.g. Winter Jacket" value={productForm.name} onChange={(e) => setProductForm({ ...productForm, name: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Category *</label>
                    <select value={productForm.category} onChange={(e) => setProductForm({ ...productForm, category: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs">
                      {CATEGORIES.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Price (Rs.) *</label>
                    <input type="number" placeholder="1999" value={productForm.price} onChange={(e) => setProductForm({ ...productForm, price: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" required />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Image URL</label>
                    <input type="url" placeholder="https://..." value={productForm.image} onChange={(e) => setProductForm({ ...productForm, image: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" />
                  </div>
                </div>
                <button type="submit" className="bg-red-600 text-white font-bold px-5 py-2.5 rounded-xl text-xs">Publish Product</button>
              </form>
            </div>
          </div>
        )}

        {/* ================= ADMIN SETTINGS TAB (SHOWS STORE REQUESTS & CUSTOMER ORDERS) ================= */}
        {activeTab === 'admin-settings' && (
          <div className="max-w-2xl mx-auto space-y-6">
            {!isAdminAuthenticated ? (
              <div className="bg-white border border-gray-200 rounded-2xl p-8 shadow-md max-w-md mx-auto space-y-6">
                <div className="text-center space-y-3">
                  <div className="flex justify-center">
                    <img
                      src={APP_LOGO}
                      alt="NepaliMart Logo"
                      className="w-16 h-16 object-contain rounded-2xl bg-red-50 p-1.5 shadow-sm border border-red-100"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <h1 className="text-xl font-bold text-gray-900">Admin Authentication Required</h1>
                  <p className="text-xs text-gray-600">Enter your authorized admin email and password to continue.</p>
                </div>

                {adminLoginError && (
                  <div className="bg-red-50 border-l-4 border-red-600 p-3 rounded-r-xl text-red-700 text-xs font-medium">
                    {adminLoginError}
                  </div>
                )}

                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Admin Email</label>
                    <input
                      type="email"
                      placeholder="Enter admin email"
                      value={adminEmailInput}
                      onChange={(e) => setAdminEmailInput(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-xs font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Admin Password</label>
                    <input
                      type="password"
                      placeholder="••••••••••••"
                      value={adminPasswordInput}
                      onChange={(e) => setAdminPasswordInput(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-xs font-mono"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl text-xs shadow-md"
                  >
                    Login to Admin Panel
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('home')}
                    className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2.5 rounded-xl text-xs"
                  >
                    Return Home
                  </button>
                </form>
              </div>
            ) : (
              <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-xs space-y-6">
                <div className="flex items-center justify-between border-b pb-3">
                  <div className="flex items-center gap-3">
                    <img src={APP_LOGO} alt="Logo" className="w-10 h-10 object-contain rounded-xl bg-red-50 p-1" referrerPolicy="no-referrer" />
                    <div>
                      <h1 className="text-xl font-bold text-gray-900">Admin Control Panel</h1>
                      <p className="text-xs text-green-600 font-bold">Authenticated Admin</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsAdminAuthenticated(false)}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg text-xs font-bold"
                  >
                    Lock Admin
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Registration Fee (Rs.)</label>
                    <input type="number" value={adminSettings.fee} onChange={(e) => setAdminSettings({ ...adminSettings, fee: Number(e.target.value) || 500 })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">QR Code Image URL</label>
                    <input type="text" value={adminSettings.qrCode} onChange={(e) => setAdminSettings({ ...adminSettings, qrCode: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs" />
                  </div>
                </div>

                {/* Store Management Section */}
                <div className="pt-4 border-t border-gray-100 space-y-3">
                  <h3 className="font-bold text-sm text-gray-900">Manage All Stores ({stores.length})</h3>
                  {stores.length === 0 ? (
                    <p className="text-xs text-gray-500">No stores created yet.</p>
                  ) : (
                    stores.map(store => (
                      <div key={store.id} className="p-3 bg-gray-50 rounded-xl border text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-bold text-gray-900">{store.name}</h4>
                            <p className="text-[10px] text-gray-500">Owner: {store.ownerName} · Phone: {store.phone} · City: {store.city}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <select
                              value={store.status || (store.verified ? 'Approved' : 'Pending')}
                              onChange={(e) => {
                                const newStatus = e.target.value as 'Pending' | 'Approved' | 'Rejected';
                                setStores(prev => prev.map(s => s.id === store.id ? { ...s, status: newStatus, verified: newStatus === 'Approved' } : s));
                              }}
                              className={`px-2 py-1 rounded text-xs font-bold border ${
                                (store.status === 'Approved' || store.verified) ? 'bg-green-100 text-green-800 border-green-300' :
                                store.status === 'Rejected' ? 'bg-red-100 text-red-800 border-red-300' : 'bg-amber-100 text-amber-800 border-amber-300'
                              }`}
                            >
                              <option value="Pending">Pending</option>
                              <option value="Approved">Approved</option>
                              <option value="Rejected">Rejected</option>
                            </select>
                            <button
                              onClick={() => {
                                if (confirm(`Are you sure you want to delete store "${store.name}"?`)) {
                                  setStores(prev => prev.filter(s => s.id !== store.id));
                                }
                              }}
                              className="bg-red-50 text-red-600 hover:bg-red-100 px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1 border border-red-200"
                            >
                              <Trash2 className="w-3.5 h-3.5" /> Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Customer Orders Section in Admin Panel */}
                <div className="pt-4 border-t border-gray-100 space-y-3">
                  <h3 className="font-bold text-sm text-gray-900">Customer Orders ({orders.length})</h3>
                  {orders.length === 0 ? (
                    <p className="text-xs text-gray-500">No customer orders yet.</p>
                  ) : (
                    orders.map(o => (
                      <div key={o.id} className="p-3 bg-gray-50 rounded-xl border space-y-2 text-xs">
                        <div className="flex justify-between items-center font-bold text-red-600">
                          <span>{o.id} ({o.customerName})</span>
                          <div className="flex items-center gap-2">
                            <span>Rs. {o.total.toLocaleString()}</span>
                            <select
                              value={o.status}
                              onChange={(e) => {
                                const newStatus = e.target.value as 'Pending' | 'Processing' | 'Delivered' | 'Cancelled';
                                setOrders(prev => prev.map(ord => ord.id === o.id ? { ...ord, status: newStatus } : ord));
                              }}
                              className={`px-2 py-1 rounded text-[10px] font-bold border ${
                                o.status === 'Delivered' ? 'bg-green-100 text-green-800 border-green-300' :
                                o.status === 'Processing' ? 'bg-blue-100 text-blue-800 border-blue-300' :
                                o.status === 'Cancelled' ? 'bg-red-100 text-red-800 border-red-300' :
                                'bg-amber-100 text-amber-800 border-amber-300'
                              }`}
                            >
                              <option value="Pending">Pending</option>
                              <option value="Processing">Processing</option>
                              <option value="Delivered">Delivered</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </div>
                        </div>
                        <p className="text-[10px] text-gray-600">Phone: {o.phone} · Address: {o.address}, {o.city} · Payment: {o.paymentMethod}</p>
                        <div className="space-y-1 pt-1 border-t border-gray-200">
                          {o.items.map((it, idx) => (
                            <div key={idx} className="flex justify-between text-gray-700">
                              <span>{it.product.name} (Qty: {it.quantity}, Color: {it.selectedColor}, Size: {it.selectedSize})</span>
                              <span className="font-bold">Rs. {it.product.price * it.quantity}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= CART TAB ================= */}
        {activeTab === 'cart' && (
          <div className="max-w-md mx-auto space-y-4">
            <h1 className="text-xl font-bold text-gray-900">Shopping Cart ({cartItemCount})</h1>
            {cart.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl border text-center space-y-3">
                <CartIcon className="w-10 h-10 text-gray-300 mx-auto" />
                <p className="text-xs text-gray-500">Your cart is empty.</p>
                <button onClick={() => setActiveTab('home')} className="bg-red-600 text-white px-5 py-2 rounded-xl text-xs font-bold">Start Shopping</button>
              </div>
            ) : (
              <div className="space-y-3">
                {cart.map(item => (
                  <div key={item.product.id} className="bg-white p-3 rounded-xl border flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={item.product.image} alt={item.product.name} className="w-12 h-12 object-cover rounded" referrerPolicy="no-referrer" />
                      <div>
                        <h4 className="font-bold text-xs">{item.product.name}</h4>
                        <span className="text-xs text-gray-500">Color: {item.selectedColor} | Size: {item.selectedSize}</span>
                        <span className="text-xs text-red-600 font-bold block">Rs. {item.product.price}</span>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(item.product.id)} className="text-gray-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                <div className="bg-white p-4 rounded-xl border space-y-3">
                  <div className="flex justify-between font-bold text-sm">
                    <span>Total:</span>
                    <span className="text-red-600">Rs. {cartTotal.toLocaleString()}</span>
                  </div>
                  <button onClick={() => alert('Order placed successfully!')} className="w-full bg-red-600 text-white py-2.5 rounded-xl text-xs font-bold">Checkout (COD)</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= ORDERS TAB ================= */}
        {activeTab === 'orders' && (
          <div className="max-w-md mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-gray-900">My Orders ({orders.length})</h1>
              <button onClick={() => setActiveTab('home')} className="text-xs text-red-600 font-bold">← Home</button>
            </div>
            {orders.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl border text-center space-y-3">
                <Package className="w-10 h-10 text-gray-300 mx-auto" />
                <p className="text-xs text-gray-500">No orders placed yet.</p>
                <button onClick={() => setActiveTab('home')} className="bg-red-600 text-white px-5 py-2 rounded-xl text-xs font-bold">Start Shopping</button>
              </div>
            ) : (
              orders.map(o => (
                <div key={o.id} className="bg-white p-4 rounded-2xl border space-y-3 shadow-xs text-xs">
                  <div className="flex justify-between items-center border-b pb-2">
                    <span className="font-mono font-bold text-red-600">{o.id}</span>
                    <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold">{o.status}</span>
                  </div>
                  <div className="space-y-1">
                    {o.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-gray-700">
                        <span>{it.product.name} (Qty: {it.quantity}, {it.selectedColor}, {it.selectedSize})</span>
                        <span className="font-bold">Rs. {it.product.price * it.quantity}</span>
                      </div>
                    ))}
                  </div>
                  <div className="pt-2 border-t flex justify-between font-bold text-sm">
                    <span>Total:</span>
                    <span className="text-red-600">Rs. {o.total.toLocaleString()}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* ================= BUY NOW CHECKOUT PAGE (Daraz Order Now style) ================= */}
        {activeTab === 'buy-now-checkout' && selectedProduct && (
          <div className="max-w-md mx-auto bg-white border border-gray-200 rounded-2xl p-6 shadow-md space-y-6">
            <button onClick={() => setActiveTab('product-detail')} className="text-xs text-red-600 font-bold hover:underline">← Back to Product</button>
            
            <div className="border-b pb-3">
              <h1 className="text-xl font-black text-gray-900">Order Now (Daraz Express)</h1>
              <p className="text-xs text-gray-500">Provide your shipping address and specifications.</p>
            </div>

            <div className="flex items-center gap-3 bg-gray-50 p-3 rounded-xl border">
              <img src={selectedProduct.image} alt={selectedProduct.name} className="w-16 h-16 object-cover rounded-lg" referrerPolicy="no-referrer" />
              <div>
                <h4 className="font-bold text-xs text-gray-900">{selectedProduct.name}</h4>
                <span className="text-xs text-red-600 font-bold">Rs. {selectedProduct.price.toLocaleString()}</span>
                <p className="text-[10px] text-gray-500">Color: {buyNowColor} · Size: {buyNowSize} · Qty: {buyNowQty}</p>
              </div>
            </div>

            <form onSubmit={handleBuyNowSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Full Name *</label>
                <input type="text" placeholder="e.g. Ram Bahadur" value={buyNowForm.customerName} onChange={(e) => setBuyNowForm({ ...buyNowForm, customerName: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5" required />
              </div>
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Phone Number *</label>
                <input type="text" placeholder="e.g. 9841234567" value={buyNowForm.phone} onChange={(e) => setBuyNowForm({ ...buyNowForm, phone: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5" required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">City *</label>
                  <select value={buyNowForm.city} onChange={(e) => setBuyNowForm({ ...buyNowForm, city: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5">
                    {NEPALI_CITIES.filter(c => c !== 'All Nepal').map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Payment Method *</label>
                  <select value={buyNowForm.paymentMethod} onChange={(e) => setBuyNowForm({ ...buyNowForm, paymentMethod: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5">
                    <option value="Cash on Delivery (COD)">Cash on Delivery</option>
                    <option value="eSewa Wallet">eSewa Wallet</option>
                    <option value="Khalti Wallet">Khalti Wallet</option>
                    <option value="Fonepay QR">Fonepay QR</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Street Address / Tole / Landmark *</label>
                <input type="text" placeholder="e.g. New Road near pipal bot" value={buyNowForm.address} onChange={(e) => setBuyNowForm({ ...buyNowForm, address: e.target.value })} className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5" required />
              </div>

              <div className="pt-3 border-t flex justify-between font-bold text-sm">
                <span>Total Payment:</span>
                <span className="text-red-600">Rs. {(selectedProduct.price * buyNowQty + 100).toLocaleString()} (incl. Rs. 100 delivery)</span>
              </div>

              <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl text-xs shadow-md">
                Confirm & Place Order Now
              </button>
            </form>
          </div>
        )}

        {/* ================= PRODUCT DETAIL TAB (With Buy Now & Chat Options) ================= */}
        {activeTab === 'product-detail' && selectedProduct && (
          <div className="max-w-md mx-auto bg-white border border-gray-200 rounded-2xl p-6 shadow-md space-y-6">
            <button onClick={() => setActiveTab('home')} className="text-xs text-red-600 font-bold hover:underline">← Back to Home</button>
            
            <div className="aspect-square bg-gray-50 rounded-2xl overflow-hidden border">
              <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] bg-red-50 text-red-600 font-bold px-2 py-0.5 rounded uppercase">{selectedProduct.storeName}</span>
                <button
                  onClick={() => toggleWishlist(selectedProduct.id)}
                  className={`p-2 rounded-full border ${wishlist.includes(selectedProduct.id) ? 'bg-red-50 text-red-600 border-red-200' : 'text-gray-400 border-gray-200'}`}
                >
                  <Heart className={`w-4 h-4 ${wishlist.includes(selectedProduct.id) ? 'fill-red-600' : ''}`} />
                </button>
              </div>

              <h1 className="text-xl font-bold text-gray-900">{selectedProduct.name}</h1>
              
              <div className="flex items-baseline gap-3">
                <span className="text-2xl font-black text-red-600">Rs. {selectedProduct.price.toLocaleString()}</span>
                {selectedProduct.originalPrice && (
                  <span className="text-xs text-gray-400 line-through">Rs. {selectedProduct.originalPrice.toLocaleString()}</span>
                )}
              </div>

              <p className="text-xs text-gray-600 leading-relaxed">{selectedProduct.description}</p>

              {/* Color Selector */}
              {selectedProduct.colors && selectedProduct.colors.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <label className="block text-xs font-bold text-gray-700 uppercase">Select Color</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedProduct.colors.map(col => (
                      <button
                        key={col}
                        type="button"
                        onClick={() => setBuyNowColor(col)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${buyNowColor === col ? 'bg-red-600 text-white border-red-600' : 'bg-gray-50 text-gray-700 border-gray-200'}`}
                      >
                        {col}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Size Selector */}
              {selectedProduct.sizes && selectedProduct.sizes.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <label className="block text-xs font-bold text-gray-700 uppercase">Select Size</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedProduct.sizes.map(sz => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setBuyNowSize(sz)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${buyNowSize === sz ? 'bg-red-600 text-white border-red-600' : 'bg-gray-50 text-gray-700 border-gray-200'}`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity Selector */}
              <div className="space-y-1.5 pt-2">
                <label className="block text-xs font-bold text-gray-700 uppercase">Quantity</label>
                <div className="flex items-center border border-gray-300 rounded-lg w-fit">
                  <button onClick={() => setBuyNowQty(Math.max(1, buyNowQty - 1))} className="px-3 py-1 font-bold">-</button>
                  <span className="px-4 text-xs font-bold">{buyNowQty}</span>
                  <button onClick={() => setBuyNowQty(buyNowQty + 1)} className="px-3 py-1 font-bold">+</button>
                </div>
              </div>

              {/* Action Buttons: Add to Cart, Buy Now, and Chat with Seller */}
              <div className="grid grid-cols-2 gap-3 pt-4 border-t">
                <button
                  onClick={() => {
                    addToCart(selectedProduct);
                    alert(`Added "${selectedProduct.name}" to cart!`);
                  }}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <ShoppingBag className="w-4 h-4" /> Add to Cart
                </button>

                <button
                  onClick={() => setActiveTab('buy-now-checkout')}
                  className="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md"
                >
                  <Zap className="w-4 h-4" /> Buy Now
                </button>
              </div>

              <button
                onClick={() => setChatOpen(true)}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 mt-2"
              >
                <MessageCircle className="w-4 h-4 text-red-600" /> Chat with Seller
              </button>
            </div>
          </div>
        )}

      </main>

      {/* Floating Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-2.5 flex items-center justify-between z-50 shadow-lg">
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1 ${activeTab === 'home' ? 'text-red-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-bold">Home</span>
        </button>

        <button
          onClick={() => setActiveTab('categories')}
          className={`flex flex-col items-center gap-1 ${activeTab === 'categories' ? 'text-red-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-bold">Categories</span>
        </button>

        <button
          onClick={() => setActiveTab('search')}
          className={`flex flex-col items-center gap-1 ${activeTab === 'search' ? 'text-red-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <Search className="w-5 h-5" />
          <span className="text-[10px] font-bold">Search</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`flex flex-col items-center gap-1 ${activeTab === 'wishlist' ? 'text-red-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <Heart className="w-5 h-5" />
          <span className="text-[10px] font-bold">Wishlist</span>
        </button>

        <button
          onClick={() => setActiveTab('account')}
          className={`flex flex-col items-center gap-1 ${activeTab === 'account' ? 'text-red-600' : 'text-gray-400 hover:text-gray-600'}`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-bold">Account</span>
        </button>
      </nav>
    </div>
  );
}
