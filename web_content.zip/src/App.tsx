import React, { useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  Wifi, 
  WifiOff, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  Code2, 
  Info, 
  Cloud, 
  HardDrive,
  Mic2,
  Sliders,
  Globe2,
  ChevronRight,
  Battery,
  Signal,
  Smartphone
} from 'lucide-react';

import { 
  Language, 
  PersonaId, 
  VoiceSettings, 
  EngineMode, 
  AudioGeneration, 
  DeveloperApiKey, 
  ExportFormat,
  UserProfile,
  CustomVoice,
  CloudAccount,
  CloudUploadRecord,
  CloudStorageProvider
} from './types/tts';
import { SUPPORTED_LANGUAGES } from './constants/languages';
import { VOICE_PERSONAS } from './constants/personas';
import { offlineAudioEngine } from './utils/offlineAudioSynth';
import { 
  base64WavToAudioBuffer, 
  audioBufferToWavBlob, 
  audioBufferToMp3Blob, 
  base64WavToMp3Blob, 
  downloadBlob 
} from './utils/audioEncoder';
import { uploadToCloudService } from './utils/cloudStorage';
import { signInWithGoogle, getGoogleAccessToken, initGoogleAuth } from './utils/googleDrive';

import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { StudioEditor } from './components/StudioEditor';
import { VoiceControls } from './components/VoiceControls';
import { AudioPlayerVisualizer } from './components/AudioPlayerVisualizer';
import { ShareModal } from './components/ShareModal';
import { DeveloperApiModal } from './components/DeveloperApiModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { CustomVoiceModal } from './components/CustomVoiceModal';
import { CloudStorageModal } from './components/CloudStorageModal';

const DEFAULT_SETTINGS: VoiceSettings = {
  speed: 1.0,
  pitch: 0,
  stability: 75,
  clarity: 88,
  effects: {
    alienModulation: false,
    arenaEcho: false,
    subBassPunch: false,
    whisperFilter: false,
  },
};

const DEFAULT_USER: UserProfile = {
  id: 'usr_sabari',
  email: 'sabarisupercontact@gmail.com',
  name: 'Sabari',
  avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Sabari',
  preferredLanguage: 'ta-IN',
  preferredPersona: 'female',
  playbackSpeed: 1.0,
  voiceSettings: DEFAULT_SETTINGS,
  preferredCloudStorage: 'google-drive',
  autoCloudUpload: false,
  createdAt: 1700000000000,
};

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('sk_tts_dark_mode');
      if (saved !== null) return saved === 'true';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return true;
  });

  // Mobile Frame preview mode on desktop
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(false);

  // Navigation tab for mobile
  const [currentTab, setCurrentTab] = useState<'studio' | 'voices' | 'history' | 'cloud' | 'api'>('studio');

  // Engine mode
  const [engineMode, setEngineMode] = useState<EngineMode>('neural');
  const [isOnline, setIsOnline] = useState<boolean>(true);

  // User Account & Session - Kept permanently signed in
  const [user, setUser] = useState<UserProfile>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('sk_user_profile');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed && parsed.email) return parsed;
        }
      } catch (e) {
        // Ignored
      }
    }
    return DEFAULT_USER;
  });
  const [authToken, setAuthToken] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('sk_auth_token');
      if (saved) return saved;
      const initialToken = 'sk_usr_sabari_persistent_token';
      localStorage.setItem('sk_auth_token', initialToken);
      return initialToken;
    }
    return 'sk_usr_sabari_persistent_token';
  });

  // Custom Voices
  const [customVoices, setCustomVoices] = useState<CustomVoice[]>([]);

  // Cloud Storage Accounts & Uploads
  const [cloudAccounts, setCloudAccounts] = useState<CloudAccount[]>([
    {
      provider: 'google-drive',
      name: 'Google Drive',
      connected: true,
      accountEmail: 'sabarisupercontact@gmail.com',
      folderName: '/SK Text to Speech/Audio',
      icon: 'HardDrive',
      lastSync: Date.now(),
    },
    {
      provider: 'dropbox',
      name: 'Dropbox',
      connected: false,
      folderName: '/Apps/SK_TTS_Exports',
      icon: 'Box',
    },
    {
      provider: 'onedrive',
      name: 'Microsoft OneDrive',
      connected: false,
      folderName: '/Documents/SK_TTS_Audio',
      icon: 'Cloud',
    },
  ]);
  const [cloudUploads, setCloudUploads] = useState<CloudUploadRecord[]>([]);
  const [isSavingToCloud, setIsSavingToCloud] = useState<boolean>(false);

  // Studio selections
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(() => {
    return SUPPORTED_LANGUAGES[0];
  });
  const [selectedPersona, setSelectedPersona] = useState<PersonaId>('female');
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(DEFAULT_SETTINGS);
  const [text, setText] = useState<string>(() => {
    return SUPPORTED_LANGUAGES[0].sampleTexts[0].text;
  });

  // Audio Playback & Synthesis States
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);
  const [currentAudioBlob, setCurrentAudioBlob] = useState<Blob | null>(null);
  const [currentAudioBase64, setCurrentAudioBase64] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [statusNotification, setStatusNotification] = useState<{
    type: 'success' | 'info' | 'warning';
    message: string;
    actionUrl?: string;
    actionLabel?: string;
  } | null>(null);

  // History State
  const [history, setHistory] = useState<AudioGeneration[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('sk_tts_history');
        if (saved) return JSON.parse(saved);
      } catch (e) {
        // Ignored
      }
    }
    return [];
  });

  // Developer API Keys State
  const [apiKeys, setApiKeys] = useState<DeveloperApiKey[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('sk_tts_api_keys');
        if (saved) return JSON.parse(saved);
      } catch (e) {
        // Ignored
      }
    }
    return [
      {
        id: 'key_1',
        name: 'Default Production Key',
        key: `sk_live_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 8)}`,
        createdAt: Date.now(),
        requestCount: 0,
        rateLimit: 120,
      },
    ];
  });

  // Modals
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [isApiModalOpen, setIsApiModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isCustomVoiceModalOpen, setIsCustomVoiceModalOpen] = useState<boolean>(false);
  const [isCloudModalOpen, setIsCloudModalOpen] = useState<boolean>(false);

  const [activeShareItem, setActiveShareItem] = useState<{
    text: string;
    languageName: string;
    personaName: string;
    audioBlob: Blob | null;
    audioUrl: string | null;
  } | null>(null);

  // Sync dark mode class and color scheme
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
      localStorage.setItem('sk_tts_dark_mode', 'true');
      const themeMeta = document.querySelector('meta[name="theme-color"]');
      if (themeMeta) themeMeta.setAttribute('content', '#09090b');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
      localStorage.setItem('sk_tts_dark_mode', 'false');
      const themeMeta = document.querySelector('meta[name="theme-color"]');
      if (themeMeta) themeMeta.setAttribute('content', '#ffffff');
    }
  }, [darkMode]);

  // Keep user profile permanently persisted in localStorage
  useEffect(() => {
    if (user && typeof window !== 'undefined') {
      try {
        localStorage.setItem('sk_user_profile', JSON.stringify(user));
      } catch (e) {
        // Ignored
      }
    }
  }, [user]);

  // Keep auth token permanently persisted in localStorage
  useEffect(() => {
    if (authToken && typeof window !== 'undefined') {
      try {
        localStorage.setItem('sk_auth_token', authToken);
      } catch (e) {
        // Ignored
      }
    }
  }, [authToken]);

  // Load user profile & session on start
  useEffect(() => {
    const initSession = async () => {
      let token = authToken || (typeof window !== 'undefined' ? localStorage.getItem('sk_auth_token') : null) || 'sk_usr_sabari_persistent_token';
      
      try {
        const res = await fetch('/api/auth/me', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        const data = await res.json();
        if (data.success && data.user) {
          applyUserProfile(data.user);
        } else {
          // Attempt automatic background login for Sabari
          const guestRes = await fetch('/api/auth/guest-login', { method: 'POST' });
          const guestData = await guestRes.json();
          if (guestData.success && guestData.user) {
            token = guestData.token;
            setAuthToken(guestData.token);
            applyUserProfile(guestData.user);
          }
        }
      } catch (e) {
        // Ignored - client remains signed in with local persistent state
      }

      if (token) {
        try {
          const [voicesRes, cloudAccRes, cloudUpRes] = await Promise.all([
            fetch('/api/user/custom-voices', { headers: { 'Authorization': `Bearer ${token}` } }),
            fetch('/api/user/cloud-accounts', { headers: { 'Authorization': `Bearer ${token}` } }),
            fetch('/api/user/cloud-uploads', { headers: { 'Authorization': `Bearer ${token}` } }),
          ]);
          const voicesData = await voicesRes.json();
          const cloudAccData = await cloudAccRes.json();
          const cloudUpData = await cloudUpRes.json();

          if (voicesData?.success && Array.isArray(voicesData.voices) && voicesData.voices.length > 0) {
            setCustomVoices(voicesData.voices);
          }
          if (cloudAccData?.success && Array.isArray(cloudAccData.accounts)) {
            setCloudAccounts(cloudAccData.accounts);
          }
          if (cloudUpData?.success && Array.isArray(cloudUpData.uploads)) {
            setCloudUploads(cloudUpData.uploads);
          }
        } catch (e) {
          // Ignored
        }
      }
    };

    initSession();
  }, []);

  const applyUserProfile = (userProfile: UserProfile) => {
    setUser(userProfile);
    if (userProfile.preferredLanguage) {
      const matched = SUPPORTED_LANGUAGES.find((l) => l.code === userProfile.preferredLanguage);
      if (matched) setSelectedLanguage(matched);
    }
    if (userProfile.preferredPersona) {
      setSelectedPersona(userProfile.preferredPersona);
    }
    if (userProfile.voiceSettings) {
      setVoiceSettings({
        ...userProfile.voiceSettings,
        speed: userProfile.playbackSpeed || userProfile.voiceSettings.speed || 1.0,
      });
    }
  };

  // Network listener
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => {
      setIsOnline(false);
      setEngineMode('offline');
      showNotification('info', 'Offline mode active. Zero-latency on-device synthesis ready.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('sk_tts_history', JSON.stringify(history.slice(0, 30)));
    } catch (e) {
      // Ignored
    }
  }, [history]);

  // Save API keys to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('sk_tts_api_keys', JSON.stringify(apiKeys));
    } catch (e) {
      // Ignored
    }
  }, [apiKeys]);

  const showNotification = (
    type: 'success' | 'info' | 'warning', 
    message: string, 
    actionUrl?: string, 
    actionLabel?: string
  ) => {
    setStatusNotification({ type, message, actionUrl, actionLabel });
    setTimeout(() => {
      setStatusNotification(null);
    }, 4500);
  };

  // Switch persona updates default pitch/speed
  const handleSelectPersona = (personaId: PersonaId) => {
    setSelectedPersona(personaId);
    const persona = VOICE_PERSONAS.find((p) => p.id === personaId);
    if (persona) {
      setVoiceSettings((prev) => ({
        ...prev,
        speed: persona.defaultSpeed,
        pitch: persona.defaultPitch,
        effects: {
          ...prev.effects,
          alienModulation: persona.dspEffects.ringMod || false,
          subBassPunch: persona.dspEffects.subHarmonics || false,
          arenaEcho: persona.dspEffects.echo || false,
          whisperFilter: !!persona.dspEffects.highpassFilter,
        },
      }));
    }
  };

  const handleSelectLanguage = (lang: Language) => {
    setSelectedLanguage(lang);
    if (lang.sampleTexts.length > 0 && !text) {
      setText(lang.sampleTexts[0].text);
    }
  };

  // Custom Voice Selection
  const handleSelectCustomVoice = (cv: CustomVoice) => {
    setSelectedPersona(cv.basePersona);
    const lang = SUPPORTED_LANGUAGES.find((l) => l.code === cv.languageCode) || selectedLanguage;
    setSelectedLanguage(lang);
    setVoiceSettings({
      speed: cv.speed,
      pitch: cv.pitch,
      stability: cv.stability,
      clarity: cv.clarity,
      effects: cv.effects,
    });
    if (cv.sampleText) {
      setText(cv.sampleText);
    }
    showNotification('info', `Voice Model: "${cv.name}" loaded`);
  };

  // Safety watchdog: ensure isSynthesizing can NEVER remain stuck
  useEffect(() => {
    if (isSynthesizing) {
      const timer = setTimeout(() => {
        setIsSynthesizing(false);
      }, 28000);
      return () => clearTimeout(timer);
    }
  }, [isSynthesizing]);

  // Cancel any active synthesis immediately
  const handleCancelSynthesis = () => {
    setIsSynthesizing(false);
    offlineAudioEngine.stop();
    setIsPlaying(false);
    showNotification('info', 'Synthesis cancelled. Switched to offline ready state.');
  };

  // 1-Click option for creating a new TTS, including Soda voice!
  const handleCreateNewTTS = (option: 'soda' | 'blank' | PersonaId) => {
    offlineAudioEngine.stop();
    setIsPlaying(false);
    setIsSynthesizing(false);
    setCurrentAudioUrl(null);
    setCurrentAudioBlob(null);
    setCurrentAudioBase64(null);
    setAudioDuration(0);

    if (option === 'soda') {
      handleSelectPersona('soda');
      const sodaSample = selectedLanguage.sampleTexts.find(
        (s) =>
          s.title.includes('சோடா') ||
          s.title.includes('Soda') ||
          s.title.includes('సోడా') ||
          s.title.includes('സോഡ') ||
          s.title.includes('ಸೋಡಾ') ||
          s.title.includes('सोडा')
      );
      if (sodaSample) {
        setText(sodaSample.text);
      } else {
        setText(
          `🥤 Fizzy Soda Voice! Experience crisp, energetic pop audio with SK text to speech in ${selectedLanguage.name}!`
        );
      }
      showNotification('success', '🥤 Soda Voice Loaded! Ready to generate fizzy pop TTS.');
    } else if (option === 'blank') {
      setText('');
      showNotification('info', 'Fresh blank canvas ready. Enter your text.');
    } else {
      handleSelectPersona(option);
      if (selectedLanguage.sampleTexts.length > 0) {
        setText(selectedLanguage.sampleTexts[0].text);
      }
      const pObj = VOICE_PERSONAS.find((p) => p.id === option);
      showNotification('info', `New TTS created with ${pObj?.name || option} voice.`);
    }
  };

  // Synthesize and play logic with automatic fast fallback & timeout guard
  const handleSynthesizeAndPlay = async () => {
    if (!text.trim()) {
      showNotification('warning', 'Please enter some text first.');
      return;
    }

    setIsSynthesizing(true);
    offlineAudioEngine.stop();
    setIsPlaying(false);

    const personaObj = VOICE_PERSONAS.find((p) => p.id === selectedPersona) || VOICE_PERSONAS[0];
    let synthesizedSuccessfully = false;

    try {
      // Case 1: SK Neural Cloud AI Engine
      if (engineMode === 'neural' && isOnline) {
        try {
          const abortController = new AbortController();
          const timeoutId = setTimeout(() => abortController.abort(), 25000);

          const response = await fetch('/api/tts/synthesize', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              text,
              language: selectedLanguage.code,
              persona: selectedPersona,
              speed: voiceSettings.speed,
              pitch: voiceSettings.pitch,
            }),
            signal: abortController.signal,
          });

          clearTimeout(timeoutId);
          const data = await response.json();

          if (data.success && data.data?.audioBase64) {
            const base64Audio = data.data.audioBase64;
            setCurrentAudioBase64(base64Audio);

            const ctx = offlineAudioEngine.getAudioContext();
            const buffer = await base64WavToAudioBuffer(base64Audio, ctx);
            const wavBlob = audioBufferToWavBlob(buffer);
            const blobUrl = URL.createObjectURL(wavBlob);

            setCurrentAudioBlob(wavBlob);
            setCurrentAudioUrl(blobUrl);
            setAudioDuration(buffer.duration);
            setIsPlaying(true);

            const genId = `gen_${Date.now()}`;
            const newHistoryItem: AudioGeneration = {
              id: genId,
              text,
              language: selectedLanguage.code,
              languageName: selectedLanguage.name,
              persona: selectedPersona,
              personaName: personaObj.name,
              engine: 'neural',
              speed: voiceSettings.speed,
              pitch: voiceSettings.pitch,
              audioUrl: blobUrl,
              audioBlob: wavBlob,
              duration: buffer.duration,
              createdAt: Date.now(),
              fileSizeEstimate: `${(wavBlob.size / 1024).toFixed(1)} KB`,
            };

            setHistory((prev) => [newHistoryItem, ...prev]);

            if (authToken) {
              fetch('/api/user/history', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${authToken}`,
                },
                body: JSON.stringify(newHistoryItem),
              }).catch(() => {});
            }

            if (user?.autoCloudUpload) {
              handleSaveToCloud(user.preferredCloudStorage || 'google-drive', 'mp3', newHistoryItem);
            }

            confetti({
              particleCount: 20,
              spread: 40,
              origin: { y: 0.8 },
            });

            showNotification('success', `Voice synthesized in ${data.data.latencyMs}ms`);
            synthesizedSuccessfully = true;
          } else {
            console.warn('[Cloud TTS Notice]', data.error);
            showNotification('info', data.error ? `${data.error}` : 'Cloud response delayed. Using native device voice.');
          }
        } catch (err: any) {
          console.warn('[Cloud TTS Request Error]', err?.message || err);
          showNotification('info', 'Active speech synthesis in progress on device.');
        }
      }

      // Case 2: Offline Native Engine (100% Client-Side Web Speech API)
      if (!synthesizedSuccessfully) {
        // Stop any conflicting HTML5 audio playback so buzzing oscillator is not played!
        setCurrentAudioUrl(null);
        setCurrentAudioBlob(null);

        offlineAudioEngine.speak(
          text,
          selectedLanguage.code,
          selectedPersona,
          voiceSettings,
          () => setIsPlaying(true),
          () => setIsPlaying(false),
          () => setIsPlaying(false)
        );

        const genId = `gen_${Date.now()}`;
        const newHistoryItem: AudioGeneration = {
          id: genId,
          text,
          language: selectedLanguage.code,
          languageName: selectedLanguage.name,
          persona: selectedPersona,
          personaName: personaObj.name,
          engine: 'offline',
          speed: voiceSettings.speed,
          pitch: voiceSettings.pitch,
          audioUrl: '',
          audioBlob: undefined,
          duration: Math.max(1.5, (text.split(/\s+/).length / 2.5)),
          createdAt: Date.now(),
          fileSizeEstimate: 'Offline Stream',
        };

        setHistory((prev) => [newHistoryItem, ...prev]);
        showNotification('success', `Speaking via device voice in ${selectedLanguage.name}`);
      }
    } catch (err: any) {
      showNotification('warning', 'Could not generate speech.');
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handlePlay = () => {
    if (currentAudioUrl) {
      setIsPlaying(true);
    } else {
      handleSynthesizeAndPlay();
    }
  };

  const handlePause = () => {
    setIsPlaying(false);
    offlineAudioEngine.pause();
  };

  const handleStop = () => {
    setIsPlaying(false);
    offlineAudioEngine.stop();
  };

  const handleReplay = () => {
    offlineAudioEngine.stop();
    if (currentAudioUrl) {
      setIsPlaying(false);
      setTimeout(() => setIsPlaying(true), 100);
    } else {
      handleSynthesizeAndPlay();
    }
  };

  // Direct Cloud Storage Export Handler
  const handleSaveToCloud = async (
    provider: CloudStorageProvider = 'google-drive', 
    format: ExportFormat = 'mp3',
    item?: AudioGeneration
  ) => {
    setIsSavingToCloud(true);
    let targetBlob = item?.audioBlob || currentAudioBlob;
    let targetBase64 = currentAudioBase64;
    let targetUrl = item?.audioUrl || currentAudioUrl;

    // Check if voice has been synthesized; if not, synthesize it first!
    if (!targetBlob && !targetBase64) {
      showNotification('info', `Synthesizing voice before saving to ${provider === 'google-drive' ? 'Google Drive' : 'Cloud'}...`);
      try {
        const exportData = await offlineAudioEngine.exportOfflineAudio(
          text,
          selectedPersona,
          voiceSettings
        );
        targetBlob = exportData.wavBlob;
        targetUrl = URL.createObjectURL(exportData.wavBlob);
        setCurrentAudioBlob(exportData.wavBlob);
        setCurrentAudioUrl(targetUrl);
        setAudioDuration(exportData.duration);
      } catch (synthErr) {
        console.warn('Could not auto-synthesize before saving to cloud', synthErr);
      }
    }

    // Convert to MP3 if requested and target is WAV
    if (format === 'mp3' && targetBlob) {
      try {
        if (targetBase64) {
          targetBlob = await base64WavToMp3Blob(targetBase64, 192);
        } else {
          const ctx = offlineAudioEngine.getAudioContext();
          const arrayBuf = await targetBlob.arrayBuffer();
          const audioBuf = await ctx.decodeAudioData(arrayBuf);
          targetBlob = await audioBufferToMp3Blob(audioBuf, 192);
        }
      } catch (mp3Err) {
        console.warn('Transcode to MP3 skipped, preserving original blob', mp3Err);
      }
    }

    const targetItem = item || {
      text,
      language: selectedLanguage.code,
      languageName: selectedLanguage.name,
      persona: selectedPersona,
      audioBlob: targetBlob,
      audioUrl: targetUrl,
      id: `gen_${Date.now()}`,
    };

    const sanitizedLang = targetItem.languageName.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const fileName = `sk_tts_${sanitizedLang}_${targetItem.persona}_${Date.now()}.${format}`;

    try {
      // If saving to Google Drive, ensure Google OAuth access token is active
      if (provider === 'google-drive') {
        let gToken = await getGoogleAccessToken();
        if (!gToken) {
          try {
            const authResult = await signInWithGoogle();
            if (authResult?.accessToken) {
              gToken = authResult.accessToken;
              setCloudAccounts((prev) =>
                prev.map((acc) =>
                  acc.provider === 'google-drive'
                    ? { ...acc, connected: true, accountEmail: authResult.user.email || acc.accountEmail }
                    : acc
                )
              );
              showNotification('success', `Google Drive connected: ${authResult.user.email}`);
            }
          } catch (authErr: any) {
            // Non-critical, fallback will handle audio save locally
          }
        }
      }

      const record = await uploadToCloudService(
        authToken,
        provider,
        fileName,
        format,
        targetBlob,
        targetBase64,
        targetItem.id
      );

      setCloudUploads((prev) => [record, ...prev.filter((r) => r.id !== record.id)]);

      // Directly trigger file download into user's downloads / Google Drive folder
      if (targetBlob) {
        downloadBlob(targetBlob, fileName);
      }

      confetti({
        particleCount: 20,
        spread: 45,
        origin: { y: 0.8 },
      });

      const providerName = provider === 'google-drive' ? 'Google Drive' : provider === 'dropbox' ? 'Dropbox' : 'OneDrive';
      showNotification(
        'success',
        `Saved & synced ${fileName} to ${providerName}!`,
        record.fileUrl,
        'Open Audio'
      );
    } catch (err: any) {
      showNotification('warning', `Could not save to ${provider}: ${err?.message || 'Error'}`);
    } finally {
      setIsSavingToCloud(false);
    }
  };

  const handleDeleteUploadRecord = (id: string) => {
    setCloudUploads((prev) => prev.filter((u) => u.id !== id));
    try {
      const stored = JSON.parse(localStorage.getItem('sk_cloud_uploads') || '[]');
      localStorage.setItem('sk_cloud_uploads', JSON.stringify(stored.filter((u: any) => u.id !== id)));
      if (authToken) {
        fetch(`/api/user/cloud-upload/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${authToken}` },
        }).catch(() => {});
      }
      showNotification('info', 'File removed from cloud history.');
    } catch (e) {
      // Ignored
    }
  };

  // Export handling
  const handleExport = async (format: ExportFormat) => {
    if (!currentAudioBlob) {
      await handleSynthesizeAndPlay();
    }

    const personaName = VOICE_PERSONAS.find((p) => p.id === selectedPersona)?.name || selectedPersona;
    const sanitizedLang = selectedLanguage.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const filename = `sk_tts_${sanitizedLang}_${selectedPersona}_${Date.now()}.${format}`;

    showNotification('info', `Preparing ${format.toUpperCase()}...`);

    try {
      if (format === 'wav') {
        if (currentAudioBlob) {
          downloadBlob(currentAudioBlob, filename);
          showNotification('success', `Exported WAV`);
        }
      } else if (format === 'mp3') {
        if (currentAudioBase64) {
          const mp3Blob = await base64WavToMp3Blob(currentAudioBase64, 192);
          downloadBlob(mp3Blob, filename);
          showNotification('success', `Exported MP3`);
        } else if (currentAudioBlob) {
          const ctx = offlineAudioEngine.getAudioContext();
          const arrayBuf = await currentAudioBlob.arrayBuffer();
          const audioBuf = await ctx.decodeAudioData(arrayBuf);
          const mp3Blob = await audioBufferToMp3Blob(audioBuf, 192);
          downloadBlob(mp3Blob, filename);
          showNotification('success', `Exported MP3`);
        }
      }
    } catch (err: any) {
      if (currentAudioBlob) downloadBlob(currentAudioBlob, `${filename}.wav`);
    }
  };

  const handleExportHistoryItem = async (item: AudioGeneration, format: ExportFormat) => {
    const filename = `sk_tts_${item.languageName.toLowerCase()}_${item.persona}_${Date.now()}.${format}`;
    if (item.audioBlob) {
      if (format === 'wav') {
        downloadBlob(item.audioBlob, filename);
      } else {
        const ctx = offlineAudioEngine.getAudioContext();
        const arrayBuf = await item.audioBlob.arrayBuffer();
        const audioBuf = await ctx.decodeAudioData(arrayBuf);
        const mp3Blob = await audioBufferToMp3Blob(audioBuf, 192);
        downloadBlob(mp3Blob, filename);
      }
      showNotification('success', `Exported ${filename}`);
    }
  };

  const handlePlayHistoryItem = (item: AudioGeneration) => {
    setText(item.text);
    setSelectedPersona(item.persona);
    const lang = SUPPORTED_LANGUAGES.find((l) => l.code === item.language) || selectedLanguage;
    setSelectedLanguage(lang);
    setCurrentAudioUrl(item.audioUrl);
    setCurrentAudioBlob(item.audioBlob || null);
    setAudioDuration(item.duration);
    setIsPlaying(true);
    setCurrentTab('studio');
  };

  const handleOpenShareCurrent = () => {
    const persona = VOICE_PERSONAS.find((p) => p.id === selectedPersona)?.name || selectedPersona;
    setActiveShareItem({
      text,
      languageName: selectedLanguage.name,
      personaName: persona,
      audioBlob: currentAudioBlob,
      audioUrl: currentAudioUrl,
    });
    setIsShareModalOpen(true);
  };

  const handleOpenShareHistory = (item: AudioGeneration) => {
    setActiveShareItem({
      text: item.text,
      languageName: item.languageName,
      personaName: item.personaName,
      audioBlob: item.audioBlob || null,
      audioUrl: item.audioUrl,
    });
    setIsShareModalOpen(true);
  };

  const handleGenerateApiKey = (name = 'Mobile App Key') => {
    const newKey: DeveloperApiKey = {
      id: `key_${Date.now()}`,
      name,
      key: `sk_live_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 8)}`,
      createdAt: Date.now(),
      requestCount: 0,
      rateLimit: 120,
    };
    setApiKeys((prev) => [newKey, ...prev]);
    showNotification('success', 'Generated developer API key');
    return newKey;
  };

  const handleRevokeApiKey = (id: string) => {
    setApiKeys((prev) => prev.filter((k) => k.id !== id));
    showNotification('info', 'API key revoked');
  };

  const handleAuthSuccess = (authenticatedUser: UserProfile, token: string) => {
    applyUserProfile(authenticatedUser);
    setAuthToken(token);
    localStorage.setItem('sk_auth_token', token);
    localStorage.setItem('sk_user_profile', JSON.stringify(authenticatedUser));
    showNotification('success', `Welcome, ${authenticatedUser.name}!`);
  };

  const handleLogout = () => {
    applyUserProfile(DEFAULT_USER);
    setAuthToken('sk_usr_sabari_persistent_token');
    localStorage.setItem('sk_auth_token', 'sk_usr_sabari_persistent_token');
    localStorage.setItem('sk_user_profile', JSON.stringify(DEFAULT_USER));
    setIsProfileModalOpen(false);
    showNotification('info', 'Session refreshed. You remain signed in as Sabari.');
  };

  const handleSaveCustomVoice = async (voiceData: Omit<CustomVoice, 'id' | 'userId' | 'createdAt'>) => {
    if (authToken) {
      try {
        const res = await fetch('/api/user/custom-voices', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`,
          },
          body: JSON.stringify(voiceData),
        });
        const data = await res.json();
        if (data.success && data.voice) {
          setCustomVoices((prev) => [data.voice, ...prev]);
        }
      } catch (e) {
        // Fallback local
      }
    } else {
      const fallbackVoice: CustomVoice = {
        ...voiceData,
        id: `cv_${Date.now()}`,
        userId: 'guest',
        createdAt: Date.now(),
      };
      setCustomVoices((prev) => [fallbackVoice, ...prev]);
    }
    showNotification('success', `Saved "${voiceData.name}"!`);
  };

  const handleToggleCloudConnect = async (provider: CloudStorageProvider, connected: boolean, email?: string) => {
    let resolvedEmail = email;

    if (provider === 'google-drive' && connected) {
      try {
        const authResult = await signInWithGoogle();
        if (authResult?.user?.email) {
          resolvedEmail = authResult.user.email;
          showNotification('success', `Google Drive authorized: ${resolvedEmail}`);
        } else {
          // User closed popup without signing in
          showNotification('info', 'Google Drive sign-in was not completed.');
          return;
        }
      } catch (authErr: any) {
        showNotification('info', 'Google Drive authorization was closed.');
        return;
      }
    }

    if (authToken) {
      try {
        const res = await fetch('/api/user/cloud-connect', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`,
          },
          body: JSON.stringify({ provider, connected, email: resolvedEmail }),
        });
        const data = await res.json();
        if (data.success && data.accounts) {
          setCloudAccounts(data.accounts);
        }
      } catch (e) {
        // Fallback
      }
    } else {
      setCloudAccounts((prev) =>
        prev.map((acc) => (acc.provider === provider ? { ...acc, connected, accountEmail: resolvedEmail || acc.accountEmail } : acc))
      );
    }
    showNotification(
      'success',
      `${connected ? 'Connected' : 'Disconnected'} ${provider === 'google-drive' ? 'Google Drive' : provider === 'dropbox' ? 'Dropbox' : 'OneDrive'}.`
    );
  };

  const activePersonaObj = VOICE_PERSONAS.find((p) => p.id === selectedPersona) || VOICE_PERSONAS[0];

  // Mobile App Content Body
  const renderAppContent = () => {
    return (
      <div className="flex-1 flex flex-col min-h-full pb-20 sm:pb-24">
        {/* App Header */}
        <Header
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          engineMode={engineMode}
          onToggleEngine={setEngineMode}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
          historyCount={history.length}
          onOpenApiKeyModal={() => setIsApiModalOpen(true)}
          user={user}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenProfileModal={() => setIsProfileModalOpen(true)}
          onOpenCloudModal={() => setIsCloudModalOpen(true)}
          onOpenCustomVoiceModal={() => setIsCustomVoiceModalOpen(true)}
          isMobileFrame={isMobileFrame}
          onToggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
          onOpenShareModal={() => setIsShareModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 w-full max-w-md md:max-w-xl mx-auto px-3.5 sm:px-4 py-3 sm:py-4 space-y-4">
          
          {/* TAB 1: STUDIO */}
          {currentTab === 'studio' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              
              {/* Quick Language Carousel */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between px-0.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1">
                    <Globe2 className="w-3 h-3 text-violet-500" />
                    Target Language
                  </span>
                  <span className="text-[11px] font-semibold text-violet-600 dark:text-violet-400">
                    {selectedLanguage.flag} {selectedLanguage.nativeName}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => handleSelectLanguage(l)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all touch-press flex items-center gap-1.5 ${
                        selectedLanguage.code === l.code
                          ? 'bg-violet-600 text-white shadow-xs'
                          : 'bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300'
                      }`}
                    >
                      <span>{l.flag}</span>
                      <span>{l.nativeName}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Text Studio Editor */}
              <StudioEditor
                text={text}
                onChangeText={setText}
                selectedLanguage={selectedLanguage}
                speed={voiceSettings.speed}
                selectedPersona={selectedPersona}
                onCreateNewTTS={handleCreateNewTTS}
              />

              {/* Active Voice Persona Quick Switch Bar */}
              <div className="p-3 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-2 shadow-xs">
                <div className="flex items-center gap-2.5 truncate">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    selectedPersona === 'soda' ? 'bg-amber-500/15 text-amber-500' : 'bg-violet-500/10 text-violet-500'
                  }`}>
                    {selectedPersona === 'soda' ? <span className="text-base">🥤</span> : <Mic2 className="w-4 h-4" />}
                  </div>
                  <div className="truncate">
                    <div className="text-xs font-bold text-zinc-900 dark:text-white truncate flex items-center gap-1.5">
                      <span>{activePersonaObj.name}</span>
                      {selectedPersona === 'soda' && (
                        <span className="text-[9px] bg-amber-400/30 text-amber-900 dark:text-amber-200 px-1.5 py-0.2 rounded-full uppercase font-extrabold">
                          Fizzy Pop
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {activePersonaObj.tagline}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleCreateNewTTS('soda')}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1 touch-press transition-all ${
                      selectedPersona === 'soda'
                        ? 'bg-amber-500 text-white shadow-xs'
                        : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 hover:bg-amber-100 border border-amber-200 dark:border-amber-800'
                    }`}
                    title="Load Soda Voice persona"
                  >
                    <span>🥤</span>
                    <span className="hidden sm:inline">Soda Voice</span>
                  </button>

                  <button
                    onClick={() => setCurrentTab('voices')}
                    className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 text-xs font-bold shrink-0 flex items-center gap-1 touch-press"
                  >
                    <span>Change</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Quick Speed Pills */}
              <div className="p-3 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-2 shadow-xs">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-zinc-700 dark:text-zinc-300 flex items-center gap-1">
                    <Sliders className="w-3 h-3 text-amber-500" />
                    Speech Speed
                  </span>
                  <span className="font-mono font-bold text-violet-600 dark:text-violet-400">
                    {voiceSettings.speed.toFixed(2)}x
                  </span>
                </div>

                <div className="flex items-center justify-between gap-1">
                  {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((preset) => (
                    <button
                      key={preset}
                      onClick={() => setVoiceSettings({ ...voiceSettings, speed: preset })}
                      className={`flex-1 py-1 rounded-lg text-xs font-bold transition-all touch-press ${
                        Math.abs(voiceSettings.speed - preset) < 0.03
                          ? 'bg-violet-600 text-white shadow-xs'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400'
                      }`}
                    >
                      {preset}x
                    </button>
                  ))}
                </div>
              </div>

              {/* Audio Player & Visualizer */}
              <AudioPlayerVisualizer
                isPlaying={isPlaying}
                isSynthesizing={isSynthesizing}
                onPlay={handlePlay}
                onPause={handlePause}
                onStop={handleStop}
                onReplay={handleReplay}
                onSynthesizeAndPlay={handleSynthesizeAndPlay}
                onCancelSynthesis={handleCancelSynthesis}
                audioBlob={currentAudioBlob}
                audioUrl={currentAudioUrl}
                duration={audioDuration}
                engineMode={engineMode}
                onExport={handleExport}
                onOpenShare={handleOpenShareCurrent}
                languageName={selectedLanguage.name}
                personaName={activePersonaObj.name}
                onSaveToCloud={handleSaveToCloud}
                isSavingToCloud={isSavingToCloud}
              />
            </div>
          )}

          {/* TAB 2: VOICES & TUNING */}
          {currentTab === 'voices' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-white dark:bg-zinc-900 rounded-3xl p-4 sm:p-5 border border-zinc-200 dark:border-zinc-800 shadow-sm">
                <VoiceControls
                  selectedLanguage={selectedLanguage}
                  onSelectLanguage={handleSelectLanguage}
                  selectedPersona={selectedPersona}
                  onSelectPersona={handleSelectPersona}
                  settings={voiceSettings}
                  onChangeSettings={setVoiceSettings}
                  onResetSettings={() => setVoiceSettings(DEFAULT_SETTINGS)}
                  customVoices={customVoices}
                  onSelectCustomVoice={handleSelectCustomVoice}
                  onOpenCustomVoiceModal={() => setIsCustomVoiceModalOpen(true)}
                  onCreateNewTTS={handleCreateNewTTS}
                />
              </div>
            </div>
          )}

          {/* TAB 3: CLOUD STORAGE */}
          {currentTab === 'cloud' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="p-4 bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 space-y-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-extrabold text-zinc-900 dark:text-white flex items-center gap-2">
                      <Cloud className="w-5 h-5 text-cyan-500" />
                      <span>Cloud Storage Services</span>
                    </h3>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                      Export synthesized audio directly to Google Drive, Dropbox, or OneDrive
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2.5">
                  {cloudAccounts.map((acc) => (
                    <div
                      key={acc.provider}
                      className="p-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-950/40 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <div className="p-2 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 shadow-xs">
                          {acc.provider === 'google-drive' ? (
                            <HardDrive className="w-4 h-4 text-emerald-500" />
                          ) : acc.provider === 'dropbox' ? (
                            <Cloud className="w-4 h-4 text-blue-500" />
                          ) : (
                            <Cloud className="w-4 h-4 text-sky-500" />
                          )}
                        </div>
                        <div className="truncate">
                          <div className="text-xs font-bold text-zinc-900 dark:text-white">
                            {acc.name}
                          </div>
                          <div className="text-[10px] text-zinc-400 truncate">
                            {acc.folderName}
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => handleToggleCloudConnect(acc.provider, acc.connected)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all touch-press ${
                          acc.connected
                            ? 'bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
                            : 'bg-violet-600 text-white'
                        }`}
                      >
                        {acc.connected ? 'Connected' : 'Connect'}
                      </button>
                    </div>
                  ))}
                </div>

                {/* Auto Cloud Sync Toggle */}
                <div className="p-3 rounded-2xl bg-violet-500/5 dark:bg-violet-950/20 border border-violet-500/20 flex items-center justify-between">
                  <div className="pr-2">
                    <span className="text-xs font-bold text-zinc-900 dark:text-white block">
                      Auto-Upload to Cloud
                    </span>
                    <span className="text-[10px] text-zinc-500">
                      Sync every audio clip to {user?.preferredCloudStorage || 'Google Drive'} automatically
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={user?.autoCloudUpload || false}
                    onChange={(e) => {
                      if (user) {
                        const updated = { ...user, autoCloudUpload: e.target.checked };
                        setUser(updated);
                        if (authToken) {
                          fetch('/api/user/profile', {
                            method: 'PUT',
                            headers: {
                              'Content-Type': 'application/json',
                              'Authorization': `Bearer ${authToken}`,
                            },
                            body: JSON.stringify({ autoCloudUpload: e.target.checked }),
                          }).catch(() => {});
                        }
                      } else {
                        setIsAuthModalOpen(true);
                      }
                    }}
                    className="w-4 h-4 accent-violet-600 rounded cursor-pointer"
                  />
                </div>

                {/* Recent Uploads */}
                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                    Uploaded Audio Files ({cloudUploads.length})
                  </h4>
                  {cloudUploads.length === 0 ? (
                    <div className="text-center py-6 text-xs text-zinc-400 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl">
                      No files uploaded yet. Synthesize audio in Studio and tap &quot;Cloud&quot; to export.
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-56 overflow-y-auto">
                      {cloudUploads.map((u) => (
                        <div
                          key={u.id}
                          className="p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-950/50 flex items-center justify-between text-xs"
                        >
                          <div className="truncate pr-2">
                            <div className="font-bold text-zinc-800 dark:text-zinc-200 truncate">
                              {u.fileName}
                            </div>
                            <div className="text-[10px] text-zinc-400">
                              {u.fileSize} · {new Date(u.uploadedAt).toLocaleTimeString()}
                            </div>
                          </div>
                          <a
                            href={u.fileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 rounded-lg bg-violet-600 text-white font-bold text-[11px] shrink-0"
                          >
                            Open
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: HISTORY */}
          {currentTab === 'history' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <HistoryDrawer
                history={history}
                onPlayItem={handlePlayHistoryItem}
                onDeleteItem={(id) => setHistory((prev) => prev.filter((item) => item.id !== id))}
                onClearHistory={() => setHistory([])}
                onOpenShare={handleOpenShareHistory}
                onExportItem={handleExportHistoryItem}
                onSaveToCloud={(item, provider) => handleSaveToCloud(provider, 'mp3', item)}
                onClose={() => setCurrentTab('studio')}
              />
            </div>
          )}

          {/* TAB 5: DEVELOPER API */}
          {currentTab === 'api' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="p-4 bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 space-y-4 shadow-sm">
                <div>
                  <h3 className="text-base font-extrabold text-zinc-900 dark:text-white flex items-center gap-2">
                    <Code2 className="w-5 h-5 text-emerald-500" />
                    <span>Developer API v1</span>
                  </h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                    Integrate SK TTS into mobile apps, backend servers, and web applications
                  </p>
                </div>

                <div className="p-3 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-2">
                  <span className="text-[10px] uppercase font-bold text-zinc-400">Your Active API Key</span>
                  <div className="font-mono text-xs text-violet-600 dark:text-violet-400 break-all bg-white dark:bg-zinc-900 p-2 rounded-xl border border-zinc-200 dark:border-zinc-800">
                    {apiKeys[0]?.key || 'sk_live_demo_key'}
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(apiKeys[0]?.key || '');
                        showNotification('success', 'API Key copied to clipboard');
                      }}
                      className="flex-1 py-1.5 rounded-xl bg-violet-600 text-white font-bold text-xs"
                    >
                      Copy API Key
                    </button>
                    <button
                      onClick={() => setIsApiModalOpen(true)}
                      className="px-3 py-1.5 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-bold text-xs"
                    >
                      Full Sandbox
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 text-xs space-y-2">
                  <div className="font-bold text-zinc-800 dark:text-zinc-200">cURL Quick Request</div>
                  <pre className="p-2.5 rounded-xl bg-zinc-950 text-zinc-200 text-[11px] font-mono overflow-x-auto whitespace-pre">
{`curl -X POST "${typeof window !== 'undefined' ? window.location.origin : ''}/api/v1/tts/synthesize" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${apiKeys[0]?.key}" \\
  -d '{"text":"வணக்கம்","language":"ta-IN"}'`}
                  </pre>
                </div>
              </div>
            </div>
          )}

        </main>

        {/* Mobile Bottom Navigation Bar (always accessible) */}
        <MobileBottomNav
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          historyCount={history.length}
          userAvatar={user?.avatar}
          onOpenProfile={() => setIsProfileModalOpen(true)}
        />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-black text-zinc-900 dark:text-zinc-100 flex flex-col items-center justify-start font-sans antialiased">
      
      {/* Toast Notification */}
      {statusNotification && (
        <div className="fixed top-16 left-4 right-4 z-50 max-w-sm mx-auto animate-in fade-in slide-in-from-top-4">
          <div
            className={`p-3 rounded-2xl shadow-xl border flex items-center justify-between gap-2.5 text-xs font-semibold ${
              statusNotification.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/95 text-emerald-800 dark:text-emerald-200 border-emerald-500/30'
                : statusNotification.type === 'warning'
                ? 'bg-amber-50 dark:bg-amber-950/95 text-amber-800 dark:text-amber-200 border-amber-500/30'
                : 'bg-violet-50 dark:bg-violet-950/95 text-violet-800 dark:text-violet-200 border-violet-500/30'
            }`}
          >
            <div className="flex items-center gap-2">
              {statusNotification.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
              {statusNotification.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />}
              {statusNotification.type === 'info' && <Info className="w-4 h-4 text-violet-500 shrink-0" />}
              <span>{statusNotification.message}</span>
            </div>

            {statusNotification.actionUrl && (
              <a
                href={statusNotification.actionUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2 py-0.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-500 shrink-0"
              >
                {statusNotification.actionLabel || 'View'}
              </a>
            )}
          </div>
        </div>
      )}

      {/* Main Container: Mobile phone mockup frame when on desktop with toggle, or natural 100% full-screen mobile */}
      {isMobileFrame ? (
        <div className="my-auto py-4 sm:py-8 flex flex-col items-center">
          {/* Realistic iPhone Titanium Frame */}
          <div className="w-[390px] h-[844px] bg-white dark:bg-zinc-950 rounded-[50px] shadow-2xl border-[10px] border-zinc-800 dark:border-zinc-800 relative flex flex-col overflow-hidden ring-1 ring-zinc-300 dark:ring-zinc-700">
            
            {/* iPhone Dynamic Island */}
            <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-50 flex items-center justify-between px-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-zinc-900 border border-zinc-700"></div>
              <div className="w-2 h-2 rounded-full bg-blue-950/80"></div>
            </div>

            {/* Simulated Mobile Status Bar */}
            <div className="w-full pt-3 px-6 pb-1 flex items-center justify-between text-[11px] font-bold text-zinc-900 dark:text-zinc-200 select-none z-40">
              <span>9:41</span>
              <div className="flex items-center gap-1.5">
                <Signal className="w-3 h-3" />
                <span className="text-[10px]">5G</span>
                <Battery className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* App Body inside iPhone */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col">
              {renderAppContent()}
            </div>

            {/* iOS Home Indicator Bar */}
            <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-32 h-1 bg-zinc-400 dark:bg-zinc-600 rounded-full z-50 pointer-events-none"></div>
          </div>
        </div>
      ) : (
        <div className="w-full flex-1 flex flex-col bg-zinc-50 dark:bg-zinc-950">
          {renderAppContent()}
        </div>
      )}

      {/* Modals */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        text={activeShareItem?.text || text}
        languageName={activeShareItem?.languageName || selectedLanguage.name}
        personaName={activeShareItem?.personaName || activePersonaObj.name}
        audioBlob={activeShareItem?.audioBlob || currentAudioBlob}
        audioUrl={activeShareItem?.audioUrl || currentAudioUrl}
      />

      <DeveloperApiModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
        apiKeys={apiKeys}
        onGenerateKey={handleGenerateApiKey}
        onRevokeKey={handleRevokeApiKey}
        defaultLanguage={selectedLanguage}
        defaultPersona={selectedPersona}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      {user && (
        <UserProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          user={user}
          token={authToken}
          onUpdateUser={setUser}
          onLogout={handleLogout}
          onOpenCloudSettings={() => setIsCloudModalOpen(true)}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
        />
      )}

      <CustomVoiceModal
        isOpen={isCustomVoiceModalOpen}
        onClose={() => setIsCustomVoiceModalOpen(false)}
        onSaveVoice={handleSaveCustomVoice}
        initialLanguage={selectedLanguage}
      />

      <CloudStorageModal
        isOpen={isCloudModalOpen}
        onClose={() => setIsCloudModalOpen(false)}
        accounts={cloudAccounts}
        uploads={cloudUploads}
        onToggleConnect={handleToggleCloudConnect}
        onUploadTestFile={(provider) => handleSaveToCloud(provider, 'mp3')}
      />

    </div>
  );
}
