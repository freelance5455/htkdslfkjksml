import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Battery,
  Calculator,
  Camera,
  CloudSun,
  Clock,
  Globe,
  History,
  MessageSquare,
  MessageSquarePlus,
  Mic,
  MicOff,
  Search,
  Send,
  Settings,
  Square,
  Trash2,
  Volume2,
  VolumeX,
  WifiOff,
  Wrench,
  X,
  Youtube,
} from 'lucide-react';
import { AICoreVisualizer } from './components/AICoreVisualizer';
import { ConversationPanel } from './components/ConversationPanel';
import { PWAInstallButton } from './components/PWAInstallButton';
import { SettingsView } from './components/SettingsView';
import { UtilitiesView } from './components/UtilitiesView';
import { useBatteryMonitor } from './hooks/useBatteryMonitor';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { useVoiceAssistant } from './hooks/useVoiceAssistant';
import { routeAssistantCommand } from './services/commandRouter';
import {
  clearAllChatSessions,
  loadActiveSessionId,
  loadSessions,
  loadSettings,
  resetAllSettings,
  saveActiveSessionId,
  saveSessions,
  saveSettings,
} from './services/storage';
import type {
  AppTab,
  AssistantState,
  ChatMessage,
  ChatSession,
  GroundingSource,
  SpeechLanguage,
  UserSettings,
  UtilityPanelId,
} from './types';

function createSession(title = 'New Conversation'): ChatSession {
  const now = Date.now();
  return {
    id: `session-${now}-${Math.random().toString(36).slice(2, 7)}`,
    title,
    createdAt: now,
    updatedAt: now,
    messages: [],
  };
}

function getTimeGreeting(name: string, nickname: string): string {
  const hour = new Date().getHours();
  const who = nickname.trim() ? `, ${nickname.trim()}` : '';
  if (hour >= 5 && hour < 12) return `Good morning${who}. ${name} is ready.`;
  if (hour >= 12 && hour < 17) return `Good afternoon${who}. How can I help?`;
  if (hour >= 17 && hour < 22) return `Good evening${who}. Ready when you are.`;
  return `Late night mode${who}. ${name} is standing by.`;
}

function triggerHaptic(pattern: number | number[]): void {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch {
    // Ignore blocked or unsupported Vibration API calls
  }
}

const QUICK_COMMANDS: Array<{
  label: string;
  command: string;
  icon: React.ReactNode;
}> = [
  { label: 'Time', command: 'Time batao', icon: <Clock className="h-3.5 w-3.5" /> },
  { label: 'Weather', command: 'Weather batao', icon: <CloudSun className="h-3.5 w-3.5" /> },
  { label: 'Battery', command: 'Meri battery kitni hai', icon: <Battery className="h-3.5 w-3.5" /> },
  { label: 'YouTube', command: 'YouTube kholo', icon: <Youtube className="h-3.5 w-3.5" /> },
  { label: 'Calculator', command: 'Calculator kholo', icon: <Calculator className="h-3.5 w-3.5" /> },
  { label: 'Camera', command: 'Camera kholo', icon: <Camera className="h-3.5 w-3.5" /> },
];

const COMMON_COMMAND_SUGGESTIONS: string[] = [
  'Time batao',
  'Aaj ki date batao',
  'Weather batao',
  'Meri battery kitni hai',
  'YouTube kholo',
  'Google kholo',
  'Maps kholo',
  'Calculator kholo',
  'Camera kholo',
  'Timer kholo',
  'Stopwatch kholo',
  'Notes kholo',
  'Save note ',
  'Mujhe search karke batao ',
  'Naya chat shuru karo',
  'Meri baat sunna band karo',
];

interface InputSuggestion {
  text: string;
  kind: 'Command' | 'Recent' | 'Follow-up';
}

export default function App() {
  const [settings, setSettings] = useState<UserSettings>(() => loadSettings());
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const existing = loadSessions();
    return existing.length > 0 ? existing : [createSession()];
  });
  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    const savedId = loadActiveSessionId();
    const existing = loadSessions();
    if (savedId && existing.some((s) => s.id === savedId)) {
      return savedId;
    }
    return existing[0]?.id ?? '';
  });

  const [activeTab, setActiveTab] = useState<AppTab>('assistant');
  const [activeUtility, setActiveUtility] = useState<UtilityPanelId>('clock');
  const [inputValue, setInputValue] = useState('');
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [highlightedSuggestion, setHighlightedSuggestion] = useState(-1);
  const [suggestionsHidden, setSuggestionsHidden] = useState(false);
  const [webSearchMode, setWebSearchMode] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [showHistoryDrawer, setShowHistoryDrawer] = useState(false);
  const [historyQuery, setHistoryQuery] = useState('');
  const [nowClock, setNowClock] = useState(() => new Date());
  const [handsFreeSessionActive, setHandsFreeSessionActive] = useState(false);

  const isOnline = useOnlineStatus();
  const batteryStatus = useBatteryMonitor();
  const isLowPowerActive =
    settings.lowPowerMode &&
    (batteryStatus.supported
      ? batteryStatus.level !== null && batteryStatus.level < 20
      : true);

  const inputRef = useRef<HTMLInputElement | null>(null);
  const preVoiceInputRef = useRef('');
  const isSubmittingRef = useRef(false);
  const restartMicTimeoutRef = useRef<number | null>(null);
  const handsFreeSessionRef = useRef(false);
  const settingsRef = useRef(settings);
  const activeTabRef = useRef(activeTab);
  const submitQueryRef = useRef<
    (
      rawText: string,
      forceWebSearch?: boolean,
      submitOpts?: { fromVoice?: boolean },
    ) => Promise<void>
  >(async () => {});
  const startListeningRef = useRef<() => Promise<boolean>>(async () => false);

  handsFreeSessionRef.current = handsFreeSessionActive;
  settingsRef.current = settings;
  activeTabRef.current = activeTab;

  const clearRestartMicTimer = useCallback(() => {
    if (restartMicTimeoutRef.current !== null) {
      window.clearTimeout(restartMicTimeoutRef.current);
      restartMicTimeoutRef.current = null;
    }
  }, []);

  const scheduleHandsFreeMicRestart = useCallback(() => {
    clearRestartMicTimer();
    if (
      !handsFreeSessionRef.current ||
      !settingsRef.current.handsFreeMode ||
      activeTabRef.current !== 'assistant' ||
      isSubmittingRef.current
    ) {
      return;
    }
    restartMicTimeoutRef.current = window.setTimeout(() => {
      restartMicTimeoutRef.current = null;
      if (
        handsFreeSessionRef.current &&
        settingsRef.current.handsFreeMode &&
        activeTabRef.current === 'assistant' &&
        !isSubmittingRef.current
      ) {
        preVoiceInputRef.current = '';
        void startListeningRef.current();
      }
    }, 350);
  }, [clearRestartMicTimer]);

  const voice = useVoiceAssistant({
    speechLanguage: settings.speechLanguage,
    voiceEnabled: settings.voiceEnabled,
    speechSpeed: settings.speechSpeed,
    handsFreeMode: settings.handsFreeMode,
    onLiveTranscript: (text) => {
      setSuggestionsHidden(true);
      setHighlightedSuggestion(-1);
      if (settingsRef.current.handsFreeMode) {
        setInputValue(text);
      } else {
        const prefix = preVoiceInputRef.current.trim();
        setInputValue(prefix ? `${prefix} ${text}` : text);
      }
    },
    onAutoSend: (transcript) => {
      const trimmed = transcript.trim();
      if (!trimmed || isSubmittingRef.current) return;
      setSuggestionsHidden(true);
      setHighlightedSuggestion(-1);
      void submitQueryRef.current(trimmed, false, { fromVoice: true });
    },
    onSpeakEnd: () => {
      scheduleHandsFreeMicRestart();
    },
  });

  startListeningRef.current = voice.startListening;

  useEffect(() => {
    return () => {
      clearRestartMicTimer();
    };
  }, [clearRestartMicTimer]);

  // Stop hands-free session when Hands-Free Mode is disabled in Settings
  useEffect(() => {
    if (!settings.handsFreeMode) {
      setHandsFreeSessionActive(false);
      handsFreeSessionRef.current = false;
      clearRestartMicTimer();
    }
  }, [settings.handsFreeMode, clearRestartMicTimer]);

  // Stop hands-free loop when leaving Assistant tab
  useEffect(() => {
    if (activeTab !== 'assistant' && handsFreeSessionActive) {
      setHandsFreeSessionActive(false);
      handsFreeSessionRef.current = false;
      clearRestartMicTimer();
      voice.stopListening();
    }
  }, [activeTab, handsFreeSessionActive, clearRestartMicTimer, voice]);

  // If a speech recognition error stops listening (e.g. permission denied, network, no-speech), exit active hands-free loop
  useEffect(() => {
    if (voice.voiceError) {
      setHandsFreeSessionActive(false);
      handsFreeSessionRef.current = false;
      clearRestartMicTimer();
    }
  }, [voice.voiceError, clearRestartMicTimer]);

  // Live digital clock in header (paused in Low Power Mode to stop 1s background polling)
  useEffect(() => {
    setNowClock(new Date());
    if (isLowPowerActive) {
      const onVisibility = () => {
        if (document.visibilityState === 'visible') {
          setNowClock(new Date());
        }
      };
      document.addEventListener('visibilitychange', onVisibility);
      return () => document.removeEventListener('visibilitychange', onVisibility);
    }
    const id = window.setInterval(() => setNowClock(new Date()), 1000);
    return () => window.clearInterval(id);
  }, [isLowPowerActive]);

  // Ensure activeSessionId always points to a valid session
  useEffect(() => {
    if (!sessions.some((s) => s.id === activeSessionId)) {
      const firstId = sessions[0]?.id;
      if (firstId) {
        setActiveSessionId(firstId);
        saveActiveSessionId(firstId);
      }
    }
  }, [activeSessionId, sessions]);

  // Persist sessions
  useEffect(() => {
    saveSessions(sessions);
  }, [sessions]);

  // Sync recognized final speech transcript into editable input box when Hands-Free Mode is OFF
  useEffect(() => {
    if (voice.finalTranscript) {
      const prefix = preVoiceInputRef.current.trim();
      setInputValue(prefix ? `${prefix} ${voice.finalTranscript}` : voice.finalTranscript);
      preVoiceInputRef.current = '';
      voice.clearTranscript();
      inputRef.current?.focus();
    }
  }, [voice.finalTranscript, voice.clearTranscript]);

  const activeSession = useMemo(
    () => sessions.find((s) => s.id === activeSessionId) ?? sessions[0],
    [sessions, activeSessionId],
  );

  const filteredSessions = useMemo(() => {
    const q = historyQuery.trim().toLowerCase();
    if (!q) {
      return sessions.map((session) => ({ session, matchedSnippet: null as string | null }));
    }
    return sessions
      .map((session) => {
        const titleMatch = session.title.toLowerCase().includes(q);
        const matchingMessage = session.messages.find((m) =>
          m.text.toLowerCase().includes(q),
        );
        if (!titleMatch && !matchingMessage) {
          return null;
        }
        return {
          session,
          matchedSnippet: matchingMessage ? matchingMessage.text : null,
        };
      })
      .filter(
        (item): item is { session: ChatSession; matchedSnippet: string | null } =>
          item !== null,
      );
  }, [historyQuery, sessions]);

  const inputSuggestions = useMemo<InputSuggestion[]>(() => {
    if (
      suggestionsHidden ||
      !isInputFocused ||
      isThinking ||
      voice.isListening ||
      voice.autoSendPending
    ) {
      return [];
    }

    const query = inputValue.trim().toLowerCase();
    const candidates: InputSuggestion[] = [];
    const seen = new Set<string>();

    const pushCandidate = (text: string, kind: InputSuggestion['kind']) => {
      const normalized = text.trim().toLowerCase();
      if (!normalized || seen.has(normalized)) return;
      if (query && normalized === query) return;
      seen.add(normalized);
      candidates.push({ text, kind });
    };

    // 1. Contextual follow-ups based on recent messages in the active conversation
    const sessionMessages = activeSession?.messages ?? [];
    const lastAssistant = [...sessionMessages]
      .reverse()
      .find((m) => m.role === 'assistant' && !m.isError);
    const lastUser = [...sessionMessages]
      .reverse()
      .find((m) => m.role === 'user');

    if (lastAssistant) {
      const replyLower = lastAssistant.text.toLowerCase();
      if (lastAssistant.knowledgeMode === 'live-web') {
        pushCandidate('Iske bare mein aur latest details batao', 'Follow-up');
      }
      if (/weather|mausam|°c|humidity|forecast/.test(replyLower)) {
        pushCandidate('Kal ka weather kaisa rahega?', 'Follow-up');
      }
      if (/battery|charging/.test(replyLower)) {
        pushCandidate('Time batao', 'Follow-up');
      }
      if (lastAssistant.knowledgeMode !== 'local-command') {
        pushCandidate('Isko aur simple Hinglish mein samjhao', 'Follow-up');
        pushCandidate('Iska short bullet-point summary do', 'Follow-up');
        pushCandidate('Iske real-life examples batao', 'Follow-up');
      }
    }

    if (lastUser && /explain|kya hai|samjhao|what is/i.test(lastUser.text)) {
      pushCandidate('Iska practical example dekar samjhao', 'Follow-up');
    }

    // 2. Previous user interactions across sessions
    for (const session of sessions) {
      for (let i = session.messages.length - 1; i >= 0; i--) {
        const msg = session.messages[i];
        if (msg.role === 'user' && msg.text.length <= 90) {
          pushCandidate(msg.text, 'Recent');
        }
      }
    }

    // 3. Common supported commands
    for (const cmd of COMMON_COMMAND_SUGGESTIONS) {
      pushCandidate(cmd, 'Command');
    }

    if (!query) {
      return sessionMessages.length > 0
        ? candidates.filter((c) => c.kind === 'Follow-up').slice(0, 3)
        : [];
    }

    const prefixMatches: InputSuggestion[] = [];
    const substringMatches: InputSuggestion[] = [];
    for (const item of candidates) {
      const lower = item.text.toLowerCase();
      if (lower.startsWith(query)) {
        prefixMatches.push(item);
      } else if (lower.includes(query)) {
        substringMatches.push(item);
      }
    }

    return [...prefixMatches, ...substringMatches].slice(0, 4);
  }, [
    activeSession?.messages,
    inputValue,
    isInputFocused,
    isThinking,
    sessions,
    suggestionsHidden,
  ]);

  const applySuggestion = useCallback((suggestionText: string) => {
    setInputValue(suggestionText);
    setHighlightedSuggestion(-1);
    if (!suggestionText.endsWith(' ')) {
      setSuggestionsHidden(true);
    }
    inputRef.current?.focus();
  }, []);

  const assistantState: AssistantState =
    voice.isListening || voice.autoSendPending
      ? 'LISTENING'
      : isThinking
        ? 'THINKING'
        : voice.isSpeaking
          ? 'SPEAKING'
          : 'IDLE';

  const updateSettings = useCallback((patch: Partial<UserSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  }, []);

  const appendMessage = useCallback(
    (sessionId: string, msg: ChatMessage) => {
      if (msg.role === 'assistant' && !msg.isError) {
        triggerHaptic([14, 36, 18]);
      }
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== sessionId) return s;
          const nextMessages = [...s.messages, msg];
          const nextTitle =
            s.messages.length === 0 && msg.role === 'user'
              ? msg.text.slice(0, 38) + (msg.text.length > 38 ? '…' : '')
              : s.title;
          return {
            ...s,
            title: nextTitle,
            updatedAt: Date.now(),
            messages: nextMessages,
          };
        }),
      );
    },
    [],
  );

  const stopAllVoiceActivity = useCallback(() => {
    setHandsFreeSessionActive(false);
    handsFreeSessionRef.current = false;
    clearRestartMicTimer();
    voice.stopListening();
    voice.stopSpeaking();
  }, [clearRestartMicTimer, voice]);

  const startVoiceSession = useCallback(async () => {
    clearRestartMicTimer();
    const isHandsFree = settingsRef.current.handsFreeMode;
    if (isHandsFree) {
      preVoiceInputRef.current = '';
      setInputValue('');
      setHandsFreeSessionActive(true);
      handsFreeSessionRef.current = true;
    } else {
      preVoiceInputRef.current = inputValue.trim();
      setHandsFreeSessionActive(false);
      handsFreeSessionRef.current = false;
    }
    const started = await voice.startListening();
    if (!started) {
      setHandsFreeSessionActive(false);
      handsFreeSessionRef.current = false;
    }
  }, [clearRestartMicTimer, inputValue, voice]);

  const startNewChat = useCallback(() => {
    stopAllVoiceActivity();
    const fresh = createSession();
    setSessions((prev) => [fresh, ...prev].slice(0, 25));
    setActiveSessionId(fresh.id);
    saveActiveSessionId(fresh.id);
    setActiveTab('assistant');
    setShowHistoryDrawer(false);
  }, [stopAllVoiceActivity]);

  const clearCurrentChat = useCallback(() => {
    stopAllVoiceActivity();
    if (!activeSession) return;
    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id
          ? { ...s, title: 'New Conversation', updatedAt: Date.now(), messages: [] }
          : s,
      ),
    );
  }, [activeSession, stopAllVoiceActivity]);

  const handleClearAllChats = useCallback(() => {
    stopAllVoiceActivity();
    clearAllChatSessions();
    const fresh = createSession();
    setSessions([fresh]);
    setActiveSessionId(fresh.id);
    saveActiveSessionId(fresh.id);
  }, [stopAllVoiceActivity]);

  const handleResetSettings = useCallback(() => {
    const defaults = resetAllSettings();
    setSettings(defaults);
  }, []);

  const openUtility = useCallback((utilityId: UtilityPanelId) => {
    setActiveUtility(utilityId);
    setActiveTab('utilities');
  }, []);

  const sendToGemini = useCallback(
    async (
      sessionId: string,
      historyForApi: Array<{ role: 'user' | 'assistant'; text: string }>,
      forceWebSearch: boolean,
    ): Promise<boolean> => {
      if (!navigator.onLine) {
        appendMessage(sessionId, {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Internet connection is offline right now. Reconnect to chat with AI or search the web. Local tools like Time, Date, Battery, Calculator, Notes, Timer, and Stopwatch still work offline.',
          timestamp: Date.now(),
          isError: true,
        });
        return false;
      }

      let didStartSpeaking = false;
      setIsThinking(true);
      try {
        const resp = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: historyForApi,
            assistantName: settings.assistantName || 'JARVIS',
            userNickname: settings.userNickname,
            preferredLanguage: settings.preferredLanguage,
            responseLength: settings.responseLength,
            webSearch: forceWebSearch,
            localTimeString: new Date().toLocaleString('en-IN'),
          }),
        });

        const data = (await resp.json()) as {
          text?: string;
          error?: string;
          usedWebSearch?: boolean;
          knowledgeMode?: 'live-web' | 'ai-knowledge';
          sources?: GroundingSource[];
        };

        if (!resp.ok || !data.text) {
          appendMessage(sessionId, {
            id: `err-${Date.now()}`,
            role: 'assistant',
            text:
              data.error ??
              'Could not get a response from the AI service right now. Please try again.',
            timestamp: Date.now(),
            isError: true,
          });
          return false;
        }

        appendMessage(sessionId, {
          id: `ai-${Date.now()}`,
          role: 'assistant',
          text: data.text,
          timestamp: Date.now(),
          knowledgeMode: data.knowledgeMode ?? (data.usedWebSearch ? 'live-web' : 'ai-knowledge'),
          sources: data.sources ?? [],
        });

        if (settings.voiceEnabled) {
          didStartSpeaking = voice.speakText(data.text);
        }
      } catch {
        appendMessage(sessionId, {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Network error while contacting the AI server. Please check your internet connection.',
          timestamp: Date.now(),
          isError: true,
        });
      } finally {
        setIsThinking(false);
      }
      return didStartSpeaking;
    },
    [
      appendMessage,
      settings.assistantName,
      settings.preferredLanguage,
      settings.responseLength,
      settings.userNickname,
      settings.voiceEnabled,
      voice,
    ],
  );

  const submitQuery = useCallback(
    async (
      rawText: string,
      forceWebSearch = false,
      submitOpts?: { fromVoice?: boolean },
    ) => {
      const trimmed = rawText.trim();
      if (!trimmed || isThinking || isSubmittingRef.current) return;

      isSubmittingRef.current = true;
      clearRestartMicTimer();
      preVoiceInputRef.current = '';

      let didStartSpeaking = false;
      let shouldSuppressAutoRestart = false;

      try {
        const targetSession = activeSession ?? createSession();
        if (!activeSession) {
          setSessions([targetSession]);
          setActiveSessionId(targetSession.id);
        }

        setActiveTab('assistant');
        setInputValue('');
        voice.clearTranscript();
        voice.setVoiceError(null);

        const userMsg: ChatMessage = {
          id: `usr-${Date.now()}`,
          role: 'user',
          text: trimmed,
          timestamp: Date.now(),
        };
        appendMessage(targetSession.id, userMsg);

        // Route through safe command router first unless explicit web search button was clicked
        if (!forceWebSearch) {
          setIsThinking(true);
          let commandResult: Awaited<ReturnType<typeof routeAssistantCommand>>;
          try {
            commandResult = await routeAssistantCommand(trimmed);
          } finally {
            setIsThinking(false);
          }

          if (commandResult.handled) {
            if (commandResult.triggerStopVoice) {
              shouldSuppressAutoRestart = true;
              stopAllVoiceActivity();
            }

            if (commandResult.triggerNewChat) {
              const fresh = createSession();
              const confirmMsg: ChatMessage = {
                id: `cmd-${Date.now()}`,
                role: 'assistant',
                text: commandResult.replyText ?? 'Nayi conversation shuru kar di hai.',
                timestamp: Date.now(),
                knowledgeMode: 'local-command',
              };
              fresh.messages = [confirmMsg];
              triggerHaptic([14, 36, 18]);
              setSessions((prev) => [fresh, ...prev].slice(0, 25));
              setActiveSessionId(fresh.id);
              saveActiveSessionId(fresh.id);
              if (settings.voiceEnabled && confirmMsg.text) {
                didStartSpeaking = voice.speakText(confirmMsg.text);
              }
              return;
            }

            if (commandResult.triggerSearchQuery) {
              const searchQueryHistory = [
                ...targetSession.messages
                  .filter((m) => !m.isError)
                  .map((m) => ({ role: m.role, text: m.text })),
                { role: 'user' as const, text: commandResult.triggerSearchQuery },
              ];
              didStartSpeaking = await sendToGemini(targetSession.id, searchQueryHistory, true);
              return;
            }

            if (commandResult.openUtility) {
              setActiveUtility(commandResult.openUtility);
              // Switch to utility tab if user explicitly asked to open calculator/camera/timer/stopwatch/notes
              if (
                !commandResult.actionCard ||
                commandResult.openUtility === 'calculator' ||
                commandResult.openUtility === 'timer' ||
                commandResult.openUtility === 'stopwatch' ||
                commandResult.openUtility === 'notes' ||
                commandResult.openUtility === 'camera'
              ) {
                shouldSuppressAutoRestart = true;
                setHandsFreeSessionActive(false);
                handsFreeSessionRef.current = false;
                setActiveTab('utilities');
              }
            }

            if (commandResult.replyText) {
              appendMessage(targetSession.id, {
                id: `cmd-${Date.now()}`,
                role: 'assistant',
                text: commandResult.replyText,
                timestamp: Date.now(),
                knowledgeMode: 'local-command',
                actionCard: commandResult.actionCard,
              });
              if (settings.voiceEnabled && !commandResult.triggerStopVoice) {
                didStartSpeaking = voice.speakText(commandResult.replyText);
              }
            }
            return;
          }
        }

        const historyForApi = [
          ...targetSession.messages
            .filter((m) => !m.isError)
            .map((m) => ({ role: m.role, text: m.text })),
          { role: 'user' as const, text: trimmed },
        ];

        didStartSpeaking = await sendToGemini(
          targetSession.id,
          historyForApi,
          forceWebSearch || webSearchMode,
        );
        if (forceWebSearch) {
          setWebSearchMode(false);
        }
      } finally {
        isSubmittingRef.current = false;
        if (
          submitOpts?.fromVoice &&
          !didStartSpeaking &&
          !shouldSuppressAutoRestart &&
          handsFreeSessionRef.current &&
          settingsRef.current.handsFreeMode
        ) {
          scheduleHandsFreeMicRestart();
        }
      }
    },
    [
      activeSession,
      appendMessage,
      clearRestartMicTimer,
      isThinking,
      scheduleHandsFreeMicRestart,
      sendToGemini,
      settings.voiceEnabled,
      stopAllVoiceActivity,
      voice,
      webSearchMode,
    ],
  );

  submitQueryRef.current = submitQuery;

  const handleCoreTap = () => {
    if (
      voice.isSpeaking ||
      voice.isListening ||
      voice.autoSendPending ||
      handsFreeSessionActive
    ) {
      triggerHaptic([12, 28, 12]);
      stopAllVoiceActivity();
      return;
    }
    triggerHaptic(18);
    void startVoiceSession();
  };

  const brightnessClass =
    settings.themeBrightness === 'dim'
      ? 'brightness-90'
      : settings.themeBrightness === 'high'
        ? 'brightness-110 contrast-105'
        : '';

  const clockStr = nowClock.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
  const dateStr = nowClock.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });

  const displayName = settings.assistantName.trim() || 'JARVIS';
  const greeting = getTimeGreeting(displayName, settings.userNickname);

  return (
    <div
      className={`flex h-[100dvh] w-full flex-col overflow-hidden bg-[#040812] text-slate-100 hud-grid-bg ${brightnessClass}`}
    >
      {/* Compact Top HUD Bar */}
      <header className="shrink-0 border-b border-sky-400/15 bg-[#050b19]/90 backdrop-blur-md">
        <div className="mx-auto flex h-[52px] max-w-7xl items-center justify-between gap-3 px-3 sm:px-5">
          {/* Left: Brand */}
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src="/icon.svg"
              alt=""
              className="h-7 w-7 shrink-0 rounded-lg"
            />
            <span className="font-display text-base sm:text-lg font-semibold tracking-wide text-cyan-100 truncate">
              {displayName}
            </span>
          </div>

          {/* Center: Live Clock & Date */}
          <div className="hidden xs:flex sm:flex items-center gap-2 text-xs text-slate-300 font-mono tabular-nums whitespace-nowrap shrink-0">
            <span className="text-cyan-200 font-medium">{clockStr}</span>
            <span aria-hidden="true" className="text-sky-500/40">
              ·
            </span>
            <span className="text-slate-400 font-sans">{dateStr}</span>
          </div>

          {/* Right: Quick Controls */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => setShowHistoryDrawer((v) => !v)}
              aria-label="Chat history"
              title="Chat history"
              className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-300 hover:bg-sky-500/15 hover:text-cyan-200 transition-colors"
            >
              <History className="h-4.5 w-4.5" />
            </button>
            <button
              type="button"
              onClick={startNewChat}
              aria-label="New conversation"
              title="New conversation"
              className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-300 hover:bg-sky-500/15 hover:text-cyan-200 transition-colors"
            >
              <MessageSquarePlus className="h-4.5 w-4.5" />
            </button>
            <button
              type="button"
              onClick={clearCurrentChat}
              aria-label="Clear current chat"
              title="Clear current chat"
              className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-300 hover:bg-rose-500/15 hover:text-rose-200 transition-colors"
            >
              <Trash2 className="h-4.5 w-4.5" />
            </button>
            <button
              type="button"
              onClick={() =>
                setActiveTab((prev) => (prev === 'settings' ? 'assistant' : 'settings'))
              }
              aria-label="Open settings"
              title="Settings"
              className={`flex h-11 w-11 items-center justify-center rounded-xl transition-colors ${
                activeTab === 'settings'
                  ? 'bg-cyan-500/20 text-cyan-200'
                  : 'text-slate-300 hover:bg-sky-500/15 hover:text-cyan-200'
              }`}
            >
              <Settings className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Offline Banner */}
      {!isOnline && (
        <div className="shrink-0 border-b border-amber-400/25 bg-amber-950/50 px-4 py-2 text-center text-xs text-amber-200 flex items-center justify-center gap-2">
          <WifiOff className="h-3.5 w-3.5 shrink-0" />
          <span>Offline Mode — Local commands and utilities remain available.</span>
        </div>
      )}

      {/* Main Responsive Workspace */}
      <main className="relative flex-1 min-h-0 mx-auto w-full max-w-7xl flex flex-col lg:grid lg:grid-cols-[360px_1fr] lg:gap-4 lg:p-4 overflow-hidden">
        {/* Desktop Left HUD Column (Core, Greeting, Clock, Quick Commands, Session Switcher) */}
        <aside className="hidden lg:flex flex-col justify-between rounded-2xl border border-sky-400/20 bg-[#071022]/90 p-5 overflow-y-auto custom-scrollbar">
          <div className="space-y-5">
            <div className="text-center">
              <p className="text-xs font-medium text-cyan-300/90">{greeting}</p>
              <p className="mt-1 font-mono text-xs text-slate-400 tabular-nums">
                {clockStr} · {dateStr}
              </p>
            </div>

            <AICoreVisualizer
              state={assistantState}
              audioActivity={voice.audioActivity}
              assistantName={displayName}
              onCoreTap={handleCoreTap}
              lowPowerActive={isLowPowerActive}
            />

            {/* Voice Quick Controls */}
            <div className="flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() =>
                  updateSettings({ voiceEnabled: !settings.voiceEnabled })
                }
                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-sky-400/20 bg-[#0b1730] px-3 text-xs font-medium text-slate-200 hover:border-cyan-400/40"
              >
                {settings.voiceEnabled ? (
                  <Volume2 className="h-4 w-4 text-cyan-300" />
                ) : (
                  <VolumeX className="h-4 w-4 text-slate-400" />
                )}
                <span>{settings.voiceEnabled ? 'Voice On' : 'Voice Muted'}</span>
              </button>

              {(voice.isSpeaking ||
                voice.isListening ||
                voice.autoSendPending ||
                handsFreeSessionActive) && (
                <button
                  type="button"
                  onClick={stopAllVoiceActivity}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-rose-500/20 border border-rose-400/35 px-3 text-xs font-semibold text-rose-200 hover:bg-rose-500/30"
                >
                  <Square className="h-3.5 w-3.5 fill-current" />
                  <span>Stop Voice</span>
                </button>
              )}
            </div>

            {/* Quick Commands */}
            <div>
              <h2 className="mb-2 text-xs font-semibold text-slate-400">
                Quick Commands
              </h2>
              <div className="grid grid-cols-2 gap-2">
                {QUICK_COMMANDS.map((qc) => (
                  <button
                    key={qc.label}
                    type="button"
                    onClick={() => void submitQuery(qc.command)}
                    className="flex min-h-[44px] items-center gap-2 rounded-xl border border-sky-400/15 bg-[#0a152b] px-3 text-xs font-medium text-sky-100 hover:border-cyan-400/40 hover:bg-[#0e1e3d] transition-colors whitespace-nowrap"
                  >
                    <span className="text-cyan-300">{qc.icon}</span>
                    <span className="truncate">{qc.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-sky-400/15 space-y-2.5">
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  { id: 'assistant', label: 'Chat' },
                  { id: 'utilities', label: 'Tools' },
                  { id: 'settings', label: 'Settings' },
                ] as Array<{ id: AppTab; label: string }>
              ).map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setActiveTab(t.id)}
                  className={`min-h-[44px] rounded-xl text-xs font-semibold transition-colors ${
                    activeTab === t.id
                      ? 'bg-cyan-500 text-[#040812]'
                      : 'border border-sky-400/15 bg-[#0a152b] text-slate-300 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            <PWAInstallButton />
          </div>
        </aside>

        {/* Right / Main Viewport */}
        <section className="flex flex-1 min-h-0 flex-col lg:rounded-2xl lg:border lg:border-sky-400/20 lg:bg-[#071022]/85 overflow-hidden">
          {activeTab === 'assistant' && (
            <>
              {/* Mobile Core + Greeting + Quick Commands Strip */}
              <div className="lg:hidden shrink-0 border-b border-sky-400/15 bg-[#060d1e]/85 px-3 pt-2.5 pb-2.5 space-y-2">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <p className="text-cyan-200/90 font-medium truncate">{greeting}</p>
                  <button
                    type="button"
                    onClick={() =>
                      updateSettings({ voiceEnabled: !settings.voiceEnabled })
                    }
                    aria-label={settings.voiceEnabled ? 'Mute voice output' : 'Enable voice output'}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-sky-400/20 bg-[#0b162d] text-cyan-300"
                  >
                    {settings.voiceEnabled ? (
                      <Volume2 className="h-4 w-4" />
                    ) : (
                      <VolumeX className="h-4 w-4 text-slate-400" />
                    )}
                  </button>
                </div>

                <div className="flex items-center justify-center">
                  <AICoreVisualizer
                    state={assistantState}
                    audioActivity={voice.audioActivity}
                    assistantName={displayName}
                    onCoreTap={handleCoreTap}
                    compact
                    lowPowerActive={isLowPowerActive}
                  />
                </div>

                {/* Horizontal Quick Command Strip */}
                <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar pb-0.5">
                  {QUICK_COMMANDS.map((qc) => (
                    <button
                      key={qc.label}
                      type="button"
                      onClick={() => void submitQuery(qc.command)}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sky-400/20 bg-[#0a152b] px-3 py-1.5 text-xs font-medium text-sky-100 whitespace-nowrap shrink-0 active:scale-[0.97]"
                    >
                      <span className="text-cyan-300">{qc.icon}</span>
                      <span>{qc.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Conversation Messages */}
              <ConversationPanel
                messages={activeSession?.messages ?? []}
                assistantName={displayName}
                isThinking={isThinking}
                lowPowerActive={isLowPowerActive}
                onSelectPrompt={(p) => void submitQuery(p)}
                onOpenUtility={openUtility}
                onSpeakMessage={(text) => voice.speakText(text)}
              />

              {/* Voice Recognition Status, Interim Preview & Error Banner */}
              {(voice.isListening ||
                voice.autoSendPending ||
                isThinking ||
                voice.isSpeaking ||
                voice.interimTranscript ||
                voice.voiceError) && (
                <div className="shrink-0 border-t border-sky-400/15 bg-[#071124] px-3 py-2 text-xs space-y-1">
                  {voice.voiceError && (
                    <div className="flex items-center justify-between gap-2 text-rose-200">
                      <span>{voice.voiceError}</span>
                      <button
                        type="button"
                        onClick={() => voice.setVoiceError(null)}
                        className="p-1 text-rose-300 hover:text-white"
                        aria-label="Dismiss voice error"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                  {(voice.isListening || voice.autoSendPending || isThinking || voice.isSpeaking) && (
                    <div className="flex items-center justify-between gap-2 text-cyan-200">
                      <span className="truncate">
                        {voice.autoSendPending
                          ? `LISTENING · Sending in 1.2s… Keep speaking to cancel`
                          : voice.isListening
                            ? voice.interimTranscript
                              ? `LISTENING · "${voice.interimTranscript}"`
                              : settings.handsFreeMode
                                ? `LISTENING (${settings.speechLanguage}) · Hands-Free auto-send ON`
                                : `LISTENING (${settings.speechLanguage}) · Tap mic again when done`
                            : isThinking
                              ? `PROCESSING · Sending your command to ${displayName}…`
                              : `SPEAKING · ${displayName} is responding…`}
                      </span>
                      {(voice.isListening ||
                        voice.autoSendPending ||
                        voice.isSpeaking ||
                        handsFreeSessionActive) && (
                        <button
                          type="button"
                          onClick={stopAllVoiceActivity}
                          className="shrink-0 rounded-lg bg-rose-500/20 px-2.5 py-1 font-medium text-rose-200"
                        >
                          Stop
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Thumb-Zone Input & Voice Dock */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSuggestionsHidden(true);
                  setHighlightedSuggestion(-1);
                  void submitQuery(inputValue, false);
                }}
                className="shrink-0 border-t border-sky-400/15 bg-[#050c1b]/95 px-2.5 sm:px-4 py-2.5 space-y-2"
              >
                {/* Auto-Suggestions Tray */}
                {inputSuggestions.length > 0 && (
                  <div
                    role="listbox"
                    aria-label="Command and follow-up suggestions"
                    className="rounded-xl border border-sky-400/20 bg-[#081329] divide-y divide-sky-400/10 overflow-hidden"
                  >
                    {inputSuggestions.map((item, idx) => {
                      const active = idx === highlightedSuggestion;
                      return (
                        <button
                          key={`${item.kind}-${item.text}`}
                          type="button"
                          role="option"
                          aria-selected={active}
                          onMouseDown={(e) => {
                            e.preventDefault();
                            applySuggestion(item.text);
                          }}
                          className={`flex min-h-[42px] w-full items-center justify-between gap-3 px-3 py-2 text-left text-xs transition-colors ${
                            active
                              ? 'bg-cyan-500/20 text-cyan-100'
                              : 'text-slate-200 hover:bg-sky-500/10'
                          }`}
                        >
                          <span className="truncate">{item.text}</span>
                          <span className="shrink-0 text-[11px] font-medium text-sky-300/75">
                            {item.kind}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
                {/* Voice Language + Web Search + Stop Voice utility row */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <select
                      aria-label="Voice recognition language"
                      value={settings.speechLanguage}
                      onChange={(e) =>
                        updateSettings({
                          speechLanguage: e.target.value as SpeechLanguage,
                        })
                      }
                      className="min-h-[36px] rounded-lg border border-sky-400/20 bg-[#0a152b] px-2.5 text-xs font-medium text-sky-200 focus:border-cyan-400 focus:outline-none"
                    >
                      <option value="en-IN">EN-IN</option>
                      <option value="hi-IN">HI-IN</option>
                      <option value="en-US">EN-US</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => {
                        if (inputValue.trim()) {
                          void submitQuery(inputValue, true);
                        } else {
                          setWebSearchMode((v) => !v);
                        }
                      }}
                      className={`inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-2.5 text-xs font-medium whitespace-nowrap transition-colors ${
                        webSearchMode
                          ? 'border-cyan-400/60 bg-cyan-500/20 text-cyan-200'
                          : 'border-sky-400/20 bg-[#0a152b] text-slate-300 hover:text-cyan-200'
                      }`}
                    >
                      <Globe className="h-3.5 w-3.5" />
                      <span>
                        {inputValue.trim()
                          ? 'Search Internet'
                          : webSearchMode
                            ? 'Web Search: ON'
                            : 'Search Internet'}
                      </span>
                    </button>
                  </div>

                  {(voice.isSpeaking ||
                    voice.isListening ||
                    voice.autoSendPending ||
                    handsFreeSessionActive) && (
                    <button
                      type="button"
                      onClick={stopAllVoiceActivity}
                      className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-rose-400/40 bg-rose-500/20 px-3 text-xs font-semibold text-rose-200 whitespace-nowrap"
                    >
                      <Square className="h-3 w-3 fill-current" />
                      <span>Stop Voice</span>
                    </button>
                  )}
                </div>

                {/* Main Input Row */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (
                        voice.isListening ||
                        voice.autoSendPending ||
                        voice.isSpeaking ||
                        handsFreeSessionActive
                      ) {
                        triggerHaptic([12, 28, 12]);
                        stopAllVoiceActivity();
                      } else {
                        triggerHaptic(18);
                        void startVoiceSession();
                      }
                    }}
                    aria-label={
                      voice.isListening || voice.autoSendPending || handsFreeSessionActive
                        ? 'Stop listening'
                        : 'Start voice input'
                    }
                    className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border transition-colors ${
                      voice.isListening || voice.autoSendPending || handsFreeSessionActive
                        ? 'border-cyan-300 bg-cyan-500 text-[#040812]'
                        : 'border-sky-400/25 bg-[#0a152b] text-cyan-300 hover:bg-[#112142]'
                    }`}
                  >
                    {voice.isListening || voice.autoSendPending || handsFreeSessionActive ? (
                      <MicOff className="h-5 w-5" />
                    ) : (
                      <Mic className="h-5 w-5" />
                    )}
                  </button>

                  <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onFocus={() => {
                      setIsInputFocused(true);
                      setSuggestionsHidden(false);
                    }}
                    onBlur={() => {
                      setIsInputFocused(false);
                      setHighlightedSuggestion(-1);
                    }}
                    onChange={(e) => {
                      setInputValue(e.target.value);
                      setSuggestionsHidden(false);
                      setHighlightedSuggestion(-1);
                    }}
                    onKeyDown={(e) => {
                      if (inputSuggestions.length === 0) return;
                      if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        setHighlightedSuggestion((prev) =>
                          prev < inputSuggestions.length - 1 ? prev + 1 : 0,
                        );
                      } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        setHighlightedSuggestion((prev) =>
                          prev > 0 ? prev - 1 : inputSuggestions.length - 1,
                        );
                      } else if (e.key === 'Escape') {
                        setSuggestionsHidden(true);
                        setHighlightedSuggestion(-1);
                      } else if (
                        e.key === 'Enter' &&
                        highlightedSuggestion >= 0 &&
                        inputSuggestions[highlightedSuggestion]
                      ) {
                        e.preventDefault();
                        applySuggestion(inputSuggestions[highlightedSuggestion].text);
                      }
                    }}
                    placeholder={
                      webSearchMode
                        ? 'Ask anything to search live on the web…'
                        : `Ask ${displayName} in Hindi, Hinglish, or English…`
                    }
                    className="h-11 flex-1 min-w-0 rounded-xl border border-sky-400/25 bg-[#091326] px-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
                  />

                  <button
                    type="submit"
                    disabled={!inputValue.trim() || isThinking}
                    aria-label="Send message"
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-cyan-500 text-[#040812] hover:bg-cyan-400 disabled:opacity-40 transition-colors"
                  >
                    <Send className="h-4.5 w-4.5" />
                  </button>
                </div>
              </form>
            </>
          )}

          {activeTab === 'utilities' && (
            <UtilitiesView
              activeUtility={activeUtility}
              onSelectUtility={setActiveUtility}
              lowPowerActive={isLowPowerActive}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              settings={settings}
              batteryStatus={batteryStatus}
              isLowPowerActive={isLowPowerActive}
              onUpdateSettings={updateSettings}
              onResetSettings={handleResetSettings}
              onClearAllChats={handleClearAllChats}
            />
          )}
        </section>
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Primary navigation"
        className="lg:hidden shrink-0 border-t border-sky-400/15 bg-[#050b19]/95 backdrop-blur-md pb-safe"
      >
        <div className="grid grid-cols-3 h-14">
          <button
            type="button"
            onClick={() => setActiveTab('assistant')}
            className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
              activeTab === 'assistant' ? 'text-cyan-300' : 'text-slate-400'
            }`}
          >
            <MessageSquare className="h-5 w-5" />
            <span>Assistant</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('utilities')}
            className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
              activeTab === 'utilities' ? 'text-cyan-300' : 'text-slate-400'
            }`}
          >
            <Wrench className="h-5 w-5" />
            <span>Utilities</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
              activeTab === 'settings' ? 'text-cyan-300' : 'text-slate-400'
            }`}
          >
            <Settings className="h-5 w-5" />
            <span>Settings</span>
          </button>
        </div>
      </nav>

      {/* Saved Chat History Drawer */}
      {showHistoryDrawer && (
        <div
          className="fixed inset-0 z-50 flex justify-end bg-black/65 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Saved conversations"
        >
          <div className="flex h-full w-full max-w-xs flex-col border-l border-sky-400/20 bg-[#060e1f] p-4">
            <div className="flex items-center justify-between pb-3 border-b border-sky-400/15">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Chat History
              </h2>
              <button
                type="button"
                onClick={() => {
                  setShowHistoryDrawer(false);
                  setHistoryQuery('');
                }}
                aria-label="Close chat history"
                className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setHistoryQuery('');
                startNewChat();
              }}
              className="mt-3 flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 text-xs font-semibold text-[#040812]"
            >
              <MessageSquarePlus className="h-4 w-4" />
              <span>New Conversation</span>
            </button>

            <div className="relative mt-2.5 mb-3">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <input
                type="search"
                value={historyQuery}
                onChange={(e) => setHistoryQuery(e.target.value)}
                placeholder="Search title or messages…"
                aria-label="Search chat history"
                className="h-11 w-full rounded-xl border border-sky-400/20 bg-[#091326] pl-9 pr-10 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
              />
              {historyQuery && (
                <button
                  type="button"
                  onClick={() => setHistoryQuery('')}
                  aria-label="Clear search"
                  className="absolute right-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:text-slate-100"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
              {filteredSessions.length === 0 ? (
                <div className="rounded-xl border border-sky-400/15 bg-[#091326] p-4 text-center">
                  <p className="text-xs text-slate-300">
                    No conversations match &ldquo;{historyQuery.trim()}&rdquo;.
                  </p>
                  <button
                    type="button"
                    onClick={() => setHistoryQuery('')}
                    className="mt-2.5 inline-flex min-h-[36px] items-center rounded-lg border border-sky-400/25 px-3 text-xs font-medium text-cyan-200 hover:bg-sky-500/15"
                  >
                    Reset search
                  </button>
                </div>
              ) : (
                filteredSessions.map(({ session: s, matchedSnippet }) => {
                  const isActive = s.id === activeSession?.id;
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => {
                        setActiveSessionId(s.id);
                        saveActiveSessionId(s.id);
                        setActiveTab('assistant');
                        setShowHistoryDrawer(false);
                        setHistoryQuery('');
                      }}
                      className={`w-full rounded-xl border p-3 text-left transition-colors ${
                        isActive
                          ? 'border-cyan-400/45 bg-cyan-500/15 text-cyan-100'
                          : 'border-sky-400/15 bg-[#091326] text-slate-300 hover:border-sky-400/30'
                      }`}
                    >
                      <div className="truncate text-xs font-medium">{s.title}</div>
                      {matchedSnippet && (
                        <div className="mt-1 truncate text-[11px] text-cyan-200/80">
                          {matchedSnippet}
                        </div>
                      )}
                      <div className="mt-1 text-[11px] text-slate-400">
                        {s.messages.length} messages ·{' '}
                        {new Date(s.updatedAt).toLocaleDateString()}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
