import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Compass,
  Gamepad2,
  Map as MapIcon,
  Maximize2,
  MessageSquare,
  Pause,
  Play,
  RotateCcw,
  Smartphone,
  Volume2,
  VolumeX,
} from 'lucide-react';
import titleKeyArt from './assets/images/hollowwire_title_keyart_1794793019659.jpg';
import { CommsDrawer } from './components/CommsDrawer';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { TacticalMapModal } from './components/TacticalMapModal';
import { TouchControls } from './components/TouchControls';
import { soundEngine } from './game/audio';
import { HollowwireEngine } from './game/engine';
import { AbilityId, GameScreenState, HudSnapshot } from './game/types';

const INITIAL_HUD: HudSnapshot = {
  hp: 5,
  maxHp: 5,
  flux: 35,
  shards: 0,
  totalShards: 18,
  abilities: [],
  currentSector: 'sunken_conduit',
  currentSectorName: 'Sunken Conduit',
  discoveredSectors: ['sunken_conduit'],
  speed: 0,
  comboCount: 0,
  healProgress: 0,
  activePrompt: null,
  bossActive: false,
  activeBossName: 'ARCHON-IX',
  bossHp: 34,
  bossMaxHp: 34,
  bossPhase2: false,
  bossDefeated: false,
  defeatedBosses: [],
  playerX: 210,
  playerY: 1560,
  elapsedSeconds: 0,
  bannerTitle: null,
  bannerSubtitle: null,
  muted: false,
};

const MODULE_BADGES: Array<{ id: AbilityId; short: string; label: string }> = [
  { id: 'phase_dash', short: 'DASH', label: 'Phase Dash [Shift]' },
  { id: 'grapple_tether', short: 'HOOK', label: 'Grapple Tether [C]' },
  { id: 'aero_thruster', short: '2xJMP', label: 'Aero-Thruster [Double Jump]' },
  { id: 'overdrive_arc', short: 'ARC', label: 'Overdrive Arc [Blade Wave]' },
];

function formatTime(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = Math.floor(totalSeconds % 60);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function detectTouchDevice(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    navigator.maxTouchPoints > 0 ||
    window.matchMedia('(pointer: coarse)').matches
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<HollowwireEngine | null>(null);

  const [screen, setScreen] = useState<GameScreenState>('TITLE_MENU');
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [mapOpen, setMapOpen] = useState(false);
  const [commsOpen, setCommsOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [keyArtFailed, setKeyArtFailed] = useState(false);

  // Combo milestone shake & flash state
  const prevComboRef = useRef(0);
  const [comboFlashKey, setComboFlashKey] = useState(0);
  const [comboFlashing, setComboFlashing] = useState(false);
  const comboFlashTimerRef = useRef<number | null>(null);

  // Horizontal & Phone Controls state
  const [touchEnabled, setTouchEnabled] = useState<boolean>(() => detectTouchDevice());
  const [isPortraitMobile, setIsPortraitMobile] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth < window.innerHeight && window.innerWidth < 900;
  });
  const [forceRotatedLandscape, setForceRotatedLandscape] = useState<boolean>(false);

  // Track viewport orientation & touch capability
  useEffect(() => {
    const updateViewport = () => {
      const portrait = window.innerWidth < window.innerHeight && window.innerWidth < 900;
      setIsPortraitMobile(portrait);
      if (!portrait && forceRotatedLandscape) {
        setForceRotatedLandscape(false);
      }
    };
    updateViewport();
    window.addEventListener('resize', updateViewport);
    window.addEventListener('orientationchange', updateViewport);
    return () => {
      window.removeEventListener('resize', updateViewport);
      window.removeEventListener('orientationchange', updateViewport);
    };
  }, [forceRotatedLandscape]);

  const requestHorizontalLock = useCallback(async () => {
    try {
      const rootEl = document.documentElement;
      if (rootEl.requestFullscreen && !document.fullscreenElement) {
        await rootEl.requestFullscreen();
      }
      const orientation = window.screen?.orientation as unknown as {
        lock?: (mode: string) => Promise<void>;
      };
      if (orientation?.lock) {
        await orientation.lock('landscape');
      }
    } catch {
      // Fallback to CSS horizontal rotation when browser/iframe blocks native orientation lock
      if (window.innerWidth < window.innerHeight) {
        setForceRotatedLandscape(true);
      }
    }
  }, []);

  // Initialize isolated 60fps canvas engine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new HollowwireEngine(
      canvas,
      (nextHud) => setHud(nextHud),
      (nextScreen) => setScreen(nextScreen)
    );
    engineRef.current = engine;
    engine.startLoop();

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // Trigger visual shake & flash when combo counter crosses milestones (10x, 20x, 30x, 50x, etc.)
  useEffect(() => {
    const prev = prevComboRef.current;
    const cur = hud.comboCount;
    prevComboRef.current = cur;

    if (cur > prev && cur >= 10) {
      const prevTier = Math.floor(prev / 10);
      const curTier = Math.floor(cur / 10);
      if (curTier > prevTier) {
        setComboFlashKey((k) => k + 1);
        setComboFlashing(true);
        if (comboFlashTimerRef.current !== null) {
          window.clearTimeout(comboFlashTimerRef.current);
        }
        comboFlashTimerRef.current = window.setTimeout(() => {
          setComboFlashing(false);
        }, 640);
      }
    } else if (cur < 10 && comboFlashing) {
      setComboFlashing(false);
    }
  }, [hud.comboCount, comboFlashing]);

  useEffect(() => {
    return () => {
      if (comboFlashTimerRef.current !== null) {
        window.clearTimeout(comboFlashTimerRef.current);
      }
    };
  }, []);

  // Sync pause state whenever Map or Comms drawer opens during play
  useEffect(() => {
    const engine = engineRef.current;
    if (!engine) return;
    if (screen === 'PLAYING' && (mapOpen || commsOpen)) {
      engine.setScreenState('PAUSED');
    } else if (screen === 'PLAYING' && !mapOpen && !commsOpen) {
      engine.setScreenState('PLAYING');
    }
  }, [mapOpen, commsOpen, screen]);

  const handleStartGame = useCallback(() => {
    setMapOpen(false);
    setCommsOpen(false);
    if (detectTouchDevice() || isPortraitMobile) {
      setTouchEnabled(true);
      if (window.innerWidth < window.innerHeight) {
        void requestHorizontalLock();
      }
    }
    engineRef.current?.startNewRun();
  }, [isPortraitMobile, requestHorizontalLock]);

  const handleResume = useCallback(() => {
    setMapOpen(false);
    setCommsOpen(false);
    setScreen('PLAYING');
    engineRef.current?.setScreenState('PLAYING');
  }, []);

  const handleRespawn = useCallback(() => {
    setMapOpen(false);
    setCommsOpen(false);
    engineRef.current?.respawnAtLastUplink();
  }, []);

  const handleToggleMute = useCallback(() => {
    const next = soundEngine.toggleMute();
    setMuted(next);
  }, []);

  const handleVirtualHeld = useCallback((code: string, active: boolean) => {
    engineRef.current?.setVirtualHeld(code, active);
  }, []);

  const handleTriggerPogo = useCallback(() => {
    engineRef.current?.triggerVirtualPogo();
  }, []);

  // Global Shell shortcuts (Enter/Space on Title, M for Map, Tab for Comms, Esc for Pause)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') {
        if (e.code === 'Escape') {
          setCommsOpen(false);
        }
        return;
      }

      if (screen === 'TITLE_MENU') {
        if (e.code === 'Enter' || e.code === 'Space') {
          e.preventDefault();
          handleStartGame();
        }
        return;
      }

      if (e.code === 'KeyM' && (screen === 'PLAYING' || mapOpen)) {
        e.preventDefault();
        setCommsOpen(false);
        setMapOpen((prev) => !prev);
        return;
      }

      if (e.code === 'Tab' && (screen === 'PLAYING' || commsOpen)) {
        e.preventDefault();
        setMapOpen(false);
        setCommsOpen((prev) => !prev);
        return;
      }

      if (e.code === 'Escape') {
        e.preventDefault();
        if (mapOpen) {
          setMapOpen(false);
        } else if (commsOpen) {
          setCommsOpen(false);
        } else if (screen === 'PLAYING') {
          setScreen('PAUSED');
          engineRef.current?.setScreenState('PAUSED');
        } else if (screen === 'PAUSED') {
          handleResume();
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [screen, mapOpen, commsOpen, handleStartGame, handleResume]);

  const fluxCircumference = 2 * Math.PI * 19;
  const fluxOffset = fluxCircumference * (1 - Math.min(100, Math.max(0, hud.flux)) / 100);
  const showRotatePrompt = isPortraitMobile && !forceRotatedLandscape;

  return (
    <div className="relative h-[100dvh] w-[100dvw] overflow-hidden bg-[#05070d] text-slate-100">
      {/* Portrait-to-Horizontal Guard on Phones */}
      {showRotatePrompt && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#05070d] px-6 text-center">
          <div className="mb-5 flex h-16 w-16 items-center justify-center border border-cyan-500/40 bg-cyan-500/10 text-cyan-300">
            <Smartphone className="h-8 w-8 rotate-90" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-wide text-white">
            Horizontal Mode Recommended
          </h1>
          <p className="mt-2 max-w-xs text-sm text-slate-400">
            Rotate your phone sideways for full-width widescreen parkour, or switch directly into horizontal view now.
          </p>
          <div className="mt-6 flex w-full max-w-xs flex-col gap-3">
            <button
              type="button"
              onClick={() => {
                setTouchEnabled(true);
                void requestHorizontalLock();
              }}
              className="flex h-12 items-center justify-center gap-2 bg-cyan-400 px-5 font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
            >
              <Maximize2 className="h-4 w-4" />
              <span>Enter Horizontal Fullscreen</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTouchEnabled(true);
                setForceRotatedLandscape(true);
              }}
              className="flex h-12 items-center justify-center border border-slate-700 bg-slate-900 px-5 text-sm font-medium text-slate-200 transition-colors hover:border-cyan-400 hover:text-white"
            >
              Play Horizontal Now
            </button>
          </div>
        </div>
      )}

      {/* Main Horizontal Game Viewport Container (auto-rotates 90deg if forced in portrait) */}
      <div
        className="overflow-hidden bg-[#05070d]"
        style={
          forceRotatedLandscape
            ? {
                position: 'fixed',
                top: '50%',
                left: '50%',
                width: '100dvh',
                height: '100dvw',
                transform: 'translate(-50%, -50%) rotate(90deg)',
                transformOrigin: 'center center',
              }
            : {
                position: 'relative',
                width: '100%',
                height: '100%',
              }
        }
      >
        {/* Isolated 60fps Game Viewport */}
        <canvas
          ref={canvasRef}
          className="block h-full w-full cursor-crosshair touch-none"
          aria-label="HOLLOWWIRE game viewport"
        />

        {/* ================================================================= */}
        {/* TITLE SCREEN                                                      */}
        {/* ================================================================= */}
        {screen === 'TITLE_MENU' && (
          <div className="absolute inset-0 z-30 flex items-center bg-[#05070d]">
            {!keyArtFailed ? (
              <img
                src={titleKeyArt}
                alt="Hollowwire cyber-runner overlooking neon subterranean city"
                referrerPolicy="no-referrer"
                onError={() => setKeyArtFailed(true)}
                className="absolute inset-0 h-full w-full object-cover object-right"
              />
            ) : (
              <div className="absolute inset-0 bg-gradient-to-br from-[#060913] via-[#0c1429] to-[#1a0f2e]" />
            )}

            {/* Measured Contrast Scrim keeping calm negative space on left third */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#05070d] via-[#05070d]/85 to-transparent" />

            <div className="relative z-10 flex w-full max-w-2xl flex-col items-start px-6 py-4 pl-[max(1.5rem,env(safe-area-inset-left))] md:px-16 md:py-12">
              <div className="mb-2 flex items-center gap-2.5 md:mb-4 md:gap-3">
                <svg
                  width="28"
                  height="28"
                  viewBox="0 0 36 36"
                  fill="none"
                  className="md:h-9 md:w-9"
                  aria-hidden="true"
                >
                  <polygon
                    points="18,2 34,18 18,34 2,18"
                    stroke="#22d3ee"
                    strokeWidth="2"
                    fill="rgba(34,211,238,0.1)"
                  />
                  <path d="M12 11 L24 18 L12 25 L16 18 Z" fill="#e879f9" />
                </svg>
                <span className="text-[11px] font-medium tracking-widest text-cyan-300/90 md:text-xs">
                  SUBTERRANEAN METROIDVANIA
                </span>
              </div>

              <svg
                viewBox="0 0 520 76"
                className="mb-2 w-full max-w-xs md:mb-4 md:max-w-lg"
                role="img"
                aria-label="HOLLOWWIRE"
              >
                <defs>
                  <linearGradient id="hwTitleGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#f8fafc" />
                    <stop offset="65%" stopColor="#22d3ee" />
                    <stop offset="100%" stopColor="#e879f9" />
                  </linearGradient>
                </defs>
                <text
                  x="0"
                  y="58"
                  fill="url(#hwTitleGrad)"
                  fontFamily="Chakra Petch, sans-serif"
                  fontSize="60"
                  fontWeight="700"
                  letterSpacing="4"
                >
                  HOLLOWWIRE
                </text>
              </svg>

              <p className="mb-4 max-w-md text-xs leading-relaxed text-slate-300 md:mb-8 md:text-base">
                Carve through nine interconnected neon sectors. Chain katana pogos, rail grinds, phase dashes, and grapple slingshots to sever four sector overlords.
              </p>

              <div className="flex flex-wrap items-center gap-3 md:gap-4">
                <button
                  type="button"
                  onClick={handleStartGame}
                  className="flex h-11 items-center gap-2.5 bg-cyan-400 px-6 font-display text-sm font-bold tracking-wide text-slate-950 transition-colors hover:bg-cyan-300 focus-visible:outline-2 focus-visible:outline-white md:h-12 md:px-7 md:text-base whitespace-nowrap shrink-0"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>Start Run</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTouchEnabled((prev) => !prev)}
                  className={`flex h-11 items-center gap-2 border px-3.5 text-xs font-medium transition-colors md:h-12 md:px-4 md:text-sm whitespace-nowrap shrink-0 ${
                    touchEnabled
                      ? 'border-cyan-400/70 bg-cyan-500/15 text-cyan-200'
                      : 'border-slate-700 bg-slate-900/80 text-slate-200 hover:border-cyan-400'
                  }`}
                >
                  <Gamepad2 className="h-4 w-4" />
                  <span>{touchEnabled ? 'Touch Pad On' : 'Touch Pad Off'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleMute}
                  className="flex h-11 items-center gap-2 border border-slate-700 bg-slate-900/80 px-3.5 text-xs font-medium text-slate-200 transition-colors hover:border-cyan-400 hover:text-white md:h-12 md:px-4 md:text-sm whitespace-nowrap shrink-0"
                >
                  {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  <span>{muted ? 'Muted' : 'Audio On'}</span>
                </button>

                <PWAInstallButton />
              </div>

              <p className="mt-5 text-[11px] tracking-wide text-slate-400 md:mt-10 md:text-xs">
                {touchEnabled
                  ? 'Left Pad Move & Slide · Right Cluster Jump, Slash, Pogo, Dash, Grapple & Heal'
                  : 'WASD Move · Space Jump · S Slide · J Slash / Down-Pogo · Shift Dash · C Grapple · E Heal · M Map'}
              </p>
            </div>
          </div>
        )}

        {/* ================================================================= */}
        {/* ACTIVE HUD (Low-Occlusion Perimeter Clusters, Safe-Area Aware)    */}
        {/* ================================================================= */}
        {screen !== 'TITLE_MENU' && (
          <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-2.5 pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] pt-[max(0.6rem,env(safe-area-inset-top))] md:p-5">
            {/* Top Perimeter Row */}
            <div className="flex items-start justify-between gap-2 md:gap-4">
              {/* Top-Left: Flux Vessel, Integrity Pips, Shards, Modules */}
              <div className="flex items-start gap-2.5 md:gap-3.5">
                <div className="relative flex h-10 w-10 items-center justify-center md:h-12 md:w-12">
                  <svg className="h-10 w-10 -rotate-90 md:h-12 md:w-12" viewBox="0 0 48 48">
                    <circle
                      cx="24"
                      cy="24"
                      r="19"
                      fill="rgba(9,13,24,0.88)"
                      stroke="#1e293b"
                      strokeWidth="4"
                    />
                    <circle
                      cx="24"
                      cy="24"
                      r="19"
                      fill="none"
                      stroke={hud.flux >= 33 ? '#22d3ee' : '#64748b'}
                      strokeWidth="4"
                      strokeDasharray={fluxCircumference}
                      strokeDashoffset={fluxOffset}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="font-mono-nums absolute text-[10px] font-bold text-slate-100 md:text-xs">
                    {Math.round(hud.flux)}
                  </span>
                </div>

                <div>
                  <div
                    className="flex items-center gap-1 md:gap-1.5"
                    aria-label={`Integrity ${hud.hp} of ${hud.maxHp}`}
                  >
                    {Array.from({ length: hud.maxHp }).map((_, i) => {
                      const filled = i < hud.hp;
                      return (
                        <svg
                          key={i}
                          width="15"
                          height="18"
                          viewBox="0 0 18 22"
                          className="md:h-[22px] md:w-[18px]"
                        >
                          <polygon
                            points="9,1 17,6 17,16 9,21 1,16 1,6"
                            fill={filled ? '#22d3ee' : 'rgba(15,23,42,0.85)'}
                            stroke={filled ? '#cffafe' : '#334155'}
                            strokeWidth="1.5"
                          />
                        </svg>
                      );
                    })}
                    <span className="font-mono-nums ml-1 text-[11px] font-semibold text-slate-300 md:ml-1.5 md:text-xs">
                      {hud.hp}/{hud.maxHp}
                    </span>
                  </div>

                  <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-300 md:mt-1.5 md:gap-2.5 md:text-xs">
                    <span className="font-mono-nums text-amber-300">
                      {hud.shards} Shards
                    </span>
                    <span className="text-slate-600" aria-hidden="true">·</span>
                    <span className="font-mono-nums text-slate-300">
                      {hud.speed} px/s
                    </span>
                    {hud.comboCount > 1 && (
                      <>
                        <span className="text-slate-600" aria-hidden="true">·</span>
                        <span
                          key={comboFlashKey}
                          className={`font-mono-nums font-bold ${
                            comboFlashing
                              ? 'animate-combo-milestone'
                              : hud.comboCount >= 50
                              ? 'text-amber-300'
                              : hud.comboCount >= 20
                              ? 'text-cyan-300'
                              : hud.comboCount >= 10
                              ? 'text-rose-300'
                              : 'text-fuchsia-300'
                          }`}
                        >
                          {hud.comboCount}x Chain
                        </span>
                      </>
                    )}
                  </div>

                  {hud.abilities.length > 0 && (
                    <div className="mt-1 hidden items-center gap-2 text-[11px] font-semibold text-cyan-300 sm:flex">
                      {MODULE_BADGES.filter((m) => hud.abilities.includes(m.id)).map((m) => (
                        <span key={m.id} title={m.label}>
                          [{m.short}]
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Top-Center: Sector Readout, Boss Bar & Top-Docked Notifications */}
              <div className="flex flex-col items-center text-center">
                <div className="flex items-center gap-1.5 text-[11px] font-medium tracking-wider text-slate-300 md:text-xs">
                  <Compass className="h-3.5 w-3.5 text-cyan-400" />
                  <span className="max-w-[130px] truncate sm:max-w-none">{hud.currentSectorName}</span>
                  <span className="text-slate-600" aria-hidden="true">·</span>
                  <span className="font-mono-nums text-slate-400">
                    {formatTime(hud.elapsedSeconds)}
                  </span>
                </div>

                {hud.bossActive && (
                  <div className="mt-1.5 w-48 sm:w-64 md:mt-2.5 md:w-96">
                    <div className="mb-1 flex items-center justify-between text-[11px] font-bold tracking-wide text-rose-300 md:text-xs">
                      <span>
                        {hud.activeBossName} {hud.bossPhase2 ? '· OVERCLOCK' : ''}
                      </span>
                      <span className="font-mono-nums">
                        {hud.bossHp}/{hud.bossMaxHp}
                      </span>
                    </div>
                    <div className="h-2 w-full border border-rose-500/50 bg-[#090d18] md:h-2.5">
                      <div
                        className="h-full bg-rose-500 transition-[width] duration-150"
                        style={{
                          width: `${Math.max(0, (hud.bossHp / hud.bossMaxHp) * 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                )}

                {hud.bannerTitle && (
                  <div className="mt-2 flex max-w-md flex-col items-center border-y border-cyan-400/40 bg-[#070b16]/90 px-5 py-1.5 text-center md:mt-3 md:px-8 md:py-2">
                    <span className="font-display text-xs font-bold tracking-widest text-cyan-300 md:text-base">
                      {hud.bannerTitle}
                    </span>
                    {hud.bannerSubtitle && (
                      <span className="mt-0.5 text-[10px] text-slate-300 md:text-xs">
                        {hud.bannerSubtitle}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Top-Right: Interactive Utility Controls (min 40-44px hitboxes) */}
              <div className="pointer-events-auto flex items-center gap-1.5 md:gap-2">
                <button
                  type="button"
                  onClick={() => setTouchEnabled((prev) => !prev)}
                  title="Toggle on-screen phone controls"
                  aria-label="Toggle touch controls"
                  className={`flex h-10 w-10 items-center justify-center border transition-colors ${
                    touchEnabled
                      ? 'border-cyan-400/70 bg-cyan-500/15 text-cyan-200'
                      : 'border-slate-700/90 bg-[#090d18]/90 text-slate-300 hover:border-cyan-400 hover:text-white'
                  }`}
                >
                  <Gamepad2 className="h-4 w-4" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCommsOpen(false);
                    setMapOpen((prev) => !prev);
                  }}
                  className="flex h-10 items-center gap-1.5 border border-slate-700/90 bg-[#090d18]/90 px-2.5 text-xs font-semibold text-slate-200 transition-colors hover:border-cyan-400 hover:text-white md:px-3 whitespace-nowrap shrink-0"
                >
                  <MapIcon className="h-3.5 w-3.5 text-cyan-400" />
                  <span className="hidden sm:inline">Map</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMapOpen(false);
                    setCommsOpen((prev) => !prev);
                  }}
                  className="flex h-10 items-center gap-1.5 border border-slate-700/90 bg-[#090d18]/90 px-2.5 text-xs font-semibold text-slate-200 transition-colors hover:border-cyan-400 hover:text-white md:px-3 whitespace-nowrap shrink-0"
                >
                  <MessageSquare className="h-3.5 w-3.5 text-fuchsia-400" />
                  <span className="hidden sm:inline">Comms</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleMute}
                  aria-label={muted ? 'Unmute audio' : 'Mute audio'}
                  className="flex h-10 w-10 items-center justify-center border border-slate-700/90 bg-[#090d18]/90 text-slate-200 transition-colors hover:border-cyan-400 hover:text-white"
                >
                  {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (screen === 'PLAYING') {
                      setScreen('PAUSED');
                      engineRef.current?.setScreenState('PAUSED');
                    } else if (screen === 'PAUSED') {
                      handleResume();
                    }
                  }}
                  aria-label="Pause game"
                  className="flex h-10 w-10 items-center justify-center border border-slate-700/90 bg-[#090d18]/90 text-slate-200 transition-colors hover:border-cyan-400 hover:text-white"
                >
                  <Pause className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Bottom-Center Diegetic Prompt / Heal Progress */}
            <div className="flex flex-col items-center gap-1.5 pb-1">
              {hud.healProgress > 0 && (
                <div className="w-40 border border-cyan-400/50 bg-[#070b16] p-1 md:w-44">
                  <div
                    className="h-1.5 bg-cyan-400"
                    style={{ width: `${Math.min(100, hud.healProgress * 100)}%` }}
                  />
                </div>
              )}
              {hud.activePrompt && (
                <div className="border border-cyan-500/40 bg-[#070b16]/95 px-3.5 py-1 text-[11px] font-medium text-cyan-200 md:px-4 md:py-1.5 md:text-xs">
                  {hud.activePrompt}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================================================================= */}
        {/* MULTI-TOUCH HORIZONTAL PHONE CONTROLS                             */}
        {/* ================================================================= */}
        {screen === 'PLAYING' && touchEnabled && !mapOpen && !commsOpen && (
          <TouchControls
            abilities={hud.abilities}
            flux={hud.flux}
            hasPrompt={Boolean(hud.activePrompt)}
            rotated={forceRotatedLandscape}
            onSetHeld={handleVirtualHeld}
            onTriggerPogo={handleTriggerPogo}
          />
        )}

        {/* ================================================================= */}
        {/* PAUSE / GAME OVER / VICTORY MODALS                                */}
        {/* ================================================================= */}
        {screen === 'PAUSED' && !mapOpen && !commsOpen && (
          <div className="absolute inset-0 z-30 flex items-center justify-center overflow-y-auto bg-black/75 p-4 md:p-6">
            <div className="my-auto w-full max-w-md border border-slate-700 bg-[#090d18] p-5 md:p-7">
              <h2 className="font-display text-xl font-bold text-white md:text-2xl">Paused</h2>
              <p className="mt-1 text-xs text-slate-400">
                <span>{hud.currentSectorName}</span>
                <span className="mx-2" aria-hidden="true">·</span>
                <span>Shards: {hud.shards}</span>
                <span className="mx-2" aria-hidden="true">·</span>
                <span>Modules: {hud.abilities.length}/4</span>
              </p>

              <div className="mt-4 space-y-1.5 border-y border-slate-800 py-3 text-xs text-slate-300 md:mt-5 md:space-y-2 md:py-4">
                <p>Move: A / D or Left Pad · Aim: W / S</p>
                <p>Jump / Wall-Jump / Double-Jump: Space / Jump</p>
                <p>Katana Slash & Down-Pogo: J / Slash / Pogo</p>
                <p>Phase Dash: Shift / Dash · Grapple: C / Hook</p>
                <p>Focus Heal (33 Flux): Hold E / Heal · Map: M · Comms: Tab</p>
              </div>

              <div className="mt-4 flex flex-col gap-2 md:mt-6 md:gap-2.5">
                <button
                  type="button"
                  onClick={handleResume}
                  className="flex h-11 items-center justify-center bg-cyan-400 font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                >
                  Resume Run
                </button>
                <button
                  type="button"
                  onClick={() => setTouchEnabled((prev) => !prev)}
                  className="flex h-10 items-center justify-center gap-2 border border-slate-700 text-xs font-medium text-slate-200 transition-colors hover:border-cyan-400"
                >
                  <Gamepad2 className="h-4 w-4 text-cyan-400" />
                  <span>{touchEnabled ? 'Hide On-Screen Phone Controls' : 'Show On-Screen Phone Controls'}</span>
                </button>
                <PWAInstallButton compact />
                <button
                  type="button"
                  onClick={handleRespawn}
                  className="flex h-10 items-center justify-center border border-slate-700 text-sm font-medium text-slate-200 transition-colors hover:border-cyan-400 hover:text-white"
                >
                  Return to Last Uplink
                </button>
                <button
                  type="button"
                  onClick={handleStartGame}
                  className="flex h-10 items-center justify-center border border-slate-800 text-sm font-medium text-slate-400 transition-colors hover:border-rose-400/50 hover:text-rose-200"
                >
                  Restart Full Run
                </button>
              </div>
            </div>
          </div>
        )}

        {screen === 'GAME_OVER' && (
          <div className="absolute inset-0 z-30 flex items-center justify-center overflow-y-auto bg-black/80 p-4 md:p-6">
            <div className="my-auto w-full max-w-md border border-rose-500/40 bg-[#090d18] p-5 md:p-7">
              <h2 className="font-display text-2xl font-bold text-rose-300">
                Signal Severed
              </h2>
              <p className="mt-2 text-sm text-slate-300">
                Integrity depleted in {hud.currentSectorName}. Your installed modules and discovered map sectors remain intact at your last Uplink Terminal.
              </p>
              <div className="mt-5 flex flex-col gap-2.5 md:mt-6">
                <button
                  type="button"
                  onClick={handleRespawn}
                  className="flex h-11 items-center justify-center bg-cyan-400 font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                >
                  Respawn at Uplink
                </button>
                <button
                  type="button"
                  onClick={handleStartGame}
                  className="flex h-11 items-center justify-center gap-2 border border-slate-700 text-sm font-medium text-slate-200 transition-colors hover:border-slate-500"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Play Again</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {screen === 'VICTORY' && (
          <div className="absolute inset-0 z-30 flex items-center justify-center overflow-y-auto bg-black/80 p-4 md:p-6">
            <div className="my-auto w-full max-w-md border border-cyan-400/50 bg-[#090d18] p-5 md:p-7">
              <h2 className="font-display text-2xl font-bold text-cyan-300">
                Conduit Grid Liberated
              </h2>
              <p className="mt-2 text-sm text-slate-300">
                {hud.defeatedBosses.length}/4 Sector Overlords severed. Continue exploring Void Foundry, Cryo-Abyss, and Zenith Apex at any time.
              </p>
              <div className="mt-4 grid grid-cols-3 gap-3 border-y border-slate-800 py-3 text-center md:mt-5 md:py-4">
                <div>
                  <div className="text-xs text-slate-400">Clear Time</div>
                  <div className="font-mono-nums mt-1 text-lg font-bold text-white">
                    {formatTime(hud.elapsedSeconds)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Shards</div>
                  <div className="font-mono-nums mt-1 text-lg font-bold text-amber-300">
                    {hud.shards}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Modules</div>
                  <div className="font-mono-nums mt-1 text-lg font-bold text-cyan-300">
                    {hud.abilities.length}/4
                  </div>
                </div>
              </div>
              <div className="mt-5 flex flex-col gap-2.5 md:mt-6">
                <button
                  type="button"
                  onClick={handleResume}
                  className="flex h-11 items-center justify-center bg-cyan-400 font-semibold text-slate-950 transition-colors hover:bg-cyan-300"
                >
                  Continue Exploring Sectors
                </button>
                <button
                  type="button"
                  onClick={handleStartGame}
                  className="flex h-11 items-center justify-center gap-2 border border-slate-700 text-sm font-medium text-slate-200 transition-colors hover:border-cyan-400 hover:text-white"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Play Again</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Map & Gemini Tactical Comms Overlays */}
        <TacticalMapModal
          open={mapOpen}
          hud={hud}
          onClose={() => setMapOpen(false)}
        />
        <CommsDrawer
          open={commsOpen}
          hud={hud}
          onClose={() => setCommsOpen(false)}
          onCaptureFrame={() => engineRef.current?.captureSnapshotDataUrl() ?? null}
        />
        <OfflineIndicator />
      </div>
    </div>
  );
}
