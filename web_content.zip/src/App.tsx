import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { AREA_DEFS, buildArea, NPCS_BY_AREA, type BuiltArea } from "./game/data/areas";
import { ITEMS } from "./game/data/items";
import { missionById } from "./game/data/missions";
import { NPCS } from "./game/data/npcs";
import {
  addItem,
  addLog,
  addToast,
  applyChoice,
  applyEffects,
  AREA_NAME,
  checkRequirement,
  clearSave,
  completeMission,
  createInitialState,
  ENDINGS,
  loadGame,
  loadPlayerName,
  loadScores,
  removeItem,
  saveGame,
  savePlayerName,
  saveScore,
} from "./game/engine";
import { initAudio, isMuted, setMuted, setTheme, sfx, startMusic, stopMusic } from "./game/audio";
import { renderScene, setViewSize, solidAt } from "./game/render";
import { Dialogue, type DialogueChoiceView, type DialogueState } from "./components/Dialogue";
import { Hud } from "./components/Hud";
import { InventoryPanel, JournalPanel, MapPanel, RelationsPanel } from "./components/Panels";
import { EndScreen, GameOverScreen, PauseOverlay, StartScreen } from "./components/Screens";
import { TouchControls, type ActionName } from "./components/TouchControls";
import type { Choice, Ending, GameState, Mission, StatKey } from "./game/types";

type PanelKind = "inventory" | "relations" | "journal" | "map" | "pause";

const STAT_NAMES: Record<StatKey, string> = {
  influence: "Influência",
  reputation: "Reputação",
  intelligence: "Inteligência",
  wealth: "Riqueza",
  power: "Poder",
};

function reqHint(ch: Choice): string | undefined {
  const req = ch.req;
  if (!req) return undefined;
  const parts: string[] = [];
  if (req.item) parts.push(`requer ${ITEMS[req.item]?.name ?? req.item}`);
  if (req.flag) parts.push("requer uma decisão anterior");
  if (req.npcTrust) parts.push(`requer confiança ${req.npcTrust.min}+`);
  if (req.stat) {
    (Object.keys(req.stat) as StatKey[]).forEach((k) => parts.push(`${STAT_NAMES[k]} ${req.stat![k]}+`));
  }
  return parts.length ? parts.join(" · ") : undefined;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameState | null>(null);
  const areasRef = useRef<Map<string, BuiltArea>>(new Map());
  const keysRef = useRef<Set<string>>(new Set());
  const touchRef = useRef({ x: 0, y: 0 });
  const shakeRef = useRef(0);
  const flashRef = useRef<{ a: number; c: string } | null>(null);
  const rafRef = useRef(0);
  const lastRef = useRef(0);
  const npcAnimRef = useRef<Map<string, { frame: number; dir: string; t: number }>>(new Map());
  const nearRef = useRef<string | null>(null);
  const pendingRef = useRef<{ mission: Mission; choice: Choice | null } | null>(null);
  const screenRef = useRef<"start" | "game">("start");
  const dialogueRef = useRef<DialogueState | null>(null);
  const panelRef = useRef<PanelKind | null>(null);
  const rewardRef = useRef(false);
  const overRef = useRef(false);
  const endRef = useRef(false);
  const apiRef = useRef<Record<string, any>>({});

  const [screen, setScreen] = useState<"start" | "game">("start");
  const [dialogue, setDialogue] = useState<DialogueState | null>(null);
  const [panel, setPanel] = useState<PanelKind | null>(null);
  const [nearNpc, setNearNpc] = useState<string | null>(null);
  const [reward, setReward] = useState<{ law: number; title: string; insight: string; score: number } | null>(null);
  const [ending, setEnding] = useState<Ending | null>(null);
  const [gameOver, setGameOver] = useState<{ title: string; reason: string } | null>(null);
  const [playerName, setPlayerName] = useState(loadPlayerName());
  const [scores, setScores] = useState(loadScores());
  const [muted, setMutedState] = useState(isMuted());
  const [hasSave, setHasSave] = useState(!!loadGame());
  const [scoreSaved, setScoreSaved] = useState(false);
  const [view, setView] = useState({ w: 480, h: 272 });
  const [, bump] = useReducer((x: number) => x + 1, 0);

  screenRef.current = screen;
  dialogueRef.current = dialogue;
  panelRef.current = panel;
  rewardRef.current = !!reward;
  overRef.current = !!gameOver;
  endRef.current = !!ending;

  /* --------------------------------- view --------------------------------- */

  useEffect(() => {
    const compute = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const portrait = h > w * 1.05;
      const vw = portrait ? 232 : 480;
      const vh = portrait ? 320 : 272;
      setViewSize(vw, vh);
      const c = canvasRef.current;
      if (c && (c.width !== vw || c.height !== vh)) {
        c.width = vw;
        c.height = vh;
      }
      setView({ w: vw, h: vh });
    };
    compute();
    window.addEventListener("resize", compute);
    window.addEventListener("orientationchange", compute);
    return () => {
      window.removeEventListener("resize", compute);
      window.removeEventListener("orientationchange", compute);
    };
  }, []);

  /* ------------------------------ world setup ----------------------------- */

  const getArea = useCallback((id: string) => {
    let a = areasRef.current.get(id);
    if (!a) {
      a = buildArea(id);
      areasRef.current.set(id, a);
    }
    return a;
  }, []);

  const spawnWorldItems = useCallback((g: GameState) => {
    AREA_DEFS.forEach((def) => {
      def.items.forEach((it) => {
        g.worldItems.push({
          id: `${def.id}_${it.id}_${it.x}_${it.y}`,
          item: it.item,
          areaId: def.id,
          x: it.x,
          y: it.y,
        });
      });
    });
  }, []);

  const startGame = useCallback(
    (name: string, loaded?: GameState) => {
      initAudio();
      const g = loaded ?? createInitialState(name || "Sem Nome");
      if (!loaded) spawnWorldItems(g);
      gameRef.current = g;
      setScreen("game");
      screenRef.current = "game";
      setDialogue(null);
      setPanel(null);
      setEnding(g.ending ?? null);
      setGameOver(g.gameOver ?? null);
      setHasSave(!!loadGame());
      setTheme(getArea(g.player.areaId).def.music);
      startMusic();
      bump();
    },
    [getArea, spawnWorldItems]
  );

  const restart = useCallback(() => {
    clearSave();
    setHasSave(false);
    setScoreSaved(false);
    setEnding(null);
    setGameOver(null);
    setReward(null);
    setDialogue(null);
    setPanel(null);
    startGame(playerName || "Sem Nome");
  }, [playerName, startGame]);

  const toTitle = useCallback(() => {
    stopMusic();
    setScreen("start");
    screenRef.current = "start";
    setEnding(null);
    setGameOver(null);
    setReward(null);
    setDialogue(null);
    setPanel(null);
    setScores(loadScores());
    setHasSave(!!loadGame());
    bump();
  }, []);

  /* ------------------------------- helpers -------------------------------- */

  const toast = useCallback((text: string, tone: "good" | "bad" | "info" | "gold") => {
    const g = gameRef.current;
    if (!g) return;
    addToast(g, text, tone);
  }, []);

  const shake = useCallback((amount: number) => {
    shakeRef.current = Math.max(shakeRef.current, amount);
  }, []);

  const burst = useCallback((x: number, y: number, color: string, n = 18, glow = true) => {
    const g = gameRef.current;
    if (!g) return;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 0.4 + Math.random() * 1.6;
      g.particles.push({
        x: x * 16 + 8,
        y: y * 16 + 8,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - 0.6,
        life: 0.6 + Math.random() * 0.7,
        maxLife: 1.3,
        size: glow ? 2 : 1,
        color,
        gravity: 0.02,
        glow,
      });
    }
  }, []);

  const floater = useCallback((x: number, y: number, text: string, color: string) => {
    const g = gameRef.current;
    if (!g) return;
    g.floaters.push({ id: Math.random(), text, color, x: x * 16, y: y * 16, life: 60, maxLife: 60 });
  }, []);

  const npcDef = useCallback((id: string) => NPCS.find((n) => n.id === id), []);

  /* ------------------------------ mission flow ---------------------------- */

  const openNode = useCallback(
    (mission: Mission, nodeId: string, extra: string[] = []) => {
      const node = mission.nodes[nodeId];
      const g = gameRef.current;
      if (!node || !g) return;
      const def = npcDef(node.speaker);
      if (!def) return;
      const choices: DialogueChoiceView[] = node.choices.map((ch) => ({
        text: ch.text,
        disabled: !checkRequirement(g, ch),
        hint: reqHint(ch),
      }));
      setDialogue({
        mode: "mission",
        nodeId,
        npcId: def.id,
        npcName: def.name,
        npcTitle: def.title,
        title: `Lei ${mission.id} · ${mission.lawTitle}`,
        portrait: { ...def.palette, crown: def.crown, hood: def.hood },
        lines: [...extra, ...node.lines],
        choices,
      });
      setPanel(null);
      sfx.talk();
    },
    [npcDef]
  );

  const finishMission = useCallback(
    (mission: Mission, failed: boolean) => {
      const g = gameRef.current;
      if (!g) return;
      completeMission(g, mission, failed);
      setDialogue(null);
      if (failed) {
        shake(7);
        sfx.bad();
        toast("A corte vai lembrar deste fracasso.", "bad");
      } else {
        sfx.power();
        sfx.coin();
        shake(4);
        flashRef.current = { a: 0.45, c: "#f7e3a8" };
        burst(g.player.x, g.player.y, "#f7e3a8", 34);
        burst(g.player.x, g.player.y, "#e8c06a", 22);
        floater(g.player.x, g.player.y - 1, `+${mission.reward.score}`, "#f7e3a8");
        setReward({
          law: mission.id,
          title: mission.lawTitle,
          insight: mission.lawText,
          score: mission.reward.score,
        });
        saveGame(g);
        setHasSave(true);
      }
      if (g.ending) setEnding(g.ending);
      if (g.stats.reputation <= 0) {
        setGameOver({
          title: "O REI EXPULSOU VOCÊ",
          reason:
            "Sua reputação chegou abaixo de zero. Nas ruas se fala do seu nome sem orgulho, e no castelo se fala dele sem você. O reino tem memória longa — e acabou de usar a sua.",
        });
      }
      bump();
    },
    [burst, floater, shake, toast]
  );

  const advanceStep = useCallback(
    (mission: Mission) => {
      const g = gameRef.current;
      if (!g) return;
      const nextIdx = g.missionStep + 1;
      if (nextIdx >= mission.steps.length) {
        finishMission(mission, false);
        return;
      }
      g.missionStep = nextIdx;
      const step = mission.steps[nextIdx];
      if (step.kind === "dialogue") {
        openNode(mission, step.node);
      } else {
        setDialogue(null);
        if (step.kind === "collect") {
          const held = g.inventory
            .filter((i) => i.id === step.item)
            .reduce((a, b) => a + b.count, 0);
          if (held >= step.count) {
            advanceStep(mission);
            return;
          }
          const have = g.inventory.find((i) => i.id === step.item);
          const inWorld = g.worldItems.some((w) => w.item === step.item);
          if (!have && !inWorld) {
            const def = AREA_DEFS.find((d) => d.items.some((i) => i.item === step.item));
            const spot = def?.items.find((i) => i.item === step.item);
            if (def && spot)
              g.worldItems.push({
                id: `respawn_${step.item}_${Math.random()}`,
                item: step.item,
                areaId: def.id,
                x: spot.x,
                y: spot.y,
              });
          }
        }
        toast(step.hint, "info");
      }
      bump();
    },
    [finishMission, openNode, toast]
  );

  const onChoose = useCallback(
    (idx: number) => {
      const d = dialogueRef.current;
      const g = gameRef.current;
      if (!d || !g) return;
      if (d.mode === "chat") {
        setDialogue(null);
        return;
      }
      const mission = g.currentMission !== null ? missionById(g.currentMission) : null;
      if (!mission) return;
      const node = d.nodeId ? mission.nodes[d.nodeId] : undefined;
      const choice = node?.choices[idx];
      if (!choice) return;
      if (!checkRequirement(g, choice)) return;
      sfx.click();
      const res = applyChoice(g, mission, choice);
      pendingRef.current = { mission, choice };
      if (choice.shake) shake(choice.shake);
      if (res.failed) {
        sfx.bad();
        shake(6);
      } else {
        sfx.good();
        burst(g.player.x, g.player.y, "#8fe0a0", 12);
      }
      setDialogue({
        mode: "mission",
        nodeId: d.nodeId,
        npcId: d.npcId,
        npcName: d.npcName,
        npcTitle: d.npcTitle,
        title: d.title,
        portrait: d.portrait,
        lines: [res.outcome],
        awaiting: true,
      });
      bump();
    },
    [burst, shake]
  );

  const onContinue = useCallback(() => {
    const p = pendingRef.current;
    if (!p) return;
    pendingRef.current = null;
    const { mission, choice } = p;
    if (!choice) {
      advanceStep(mission);
      return;
    }
    if (choice.next && mission.nodes[choice.next]) {
      openNode(mission, choice.next);
      return;
    }
    if (choice.end === "mission" || choice.end === "fail") {
      finishMission(mission, choice.end === "fail");
      return;
    }
    advanceStep(mission);
  }, [advanceStep, finishMission, openNode]);

  /* ------------------------------ interaction ----------------------------- */

  const npcsInArea = useCallback(
    (areaId: string) =>
      (NPCS_BY_AREA[areaId] ?? [])
        .map((n) => ({ ...n, def: npcDef(n.id) }))
        .filter((n) => !!n.def),
    [npcDef]
  );

  const nearestNpc = useCallback(() => {
    const g = gameRef.current;
    if (!g) return null;
    const list = npcsInArea(g.player.areaId);
    let best: { def: (typeof NPCS)[number]; x: number; y: number; dist: number } | null = null;
    for (const n of list) {
      const d = Math.hypot(n.x - g.player.x, n.y - g.player.y);
      if (d < 2.2 && (!best || d < best.dist))
        best = { def: n.def!, x: n.x, y: n.y, dist: d };
    }
    return best;
  }, [npcsInArea]);

  const chatWith = useCallback(
    (npcId: string) => {
      const def = npcDef(npcId);
      const g = gameRef.current;
      if (!def || !g) return;
      const st = g.npcs[npcId];
      const lines = [
        def.bio,
        st && st.trust > 60
          ? "Falei com o rei sobre você. Disse coisas boas. Não faça por merecer."
          : st && st.trust < 15
            ? "Não sei quem você é, e hoje não pretendo descobrir."
            : "Anoto tudo o que você diz. É o meu ofício, e ninguém paga mal um ofício bem feito.",
      ];
      setDialogue({
        mode: "chat",
        npcId: def.id,
        npcName: def.name,
        npcTitle: def.title,
        portrait: { ...def.palette, crown: def.crown, hood: def.hood },
        lines,
        choices: [{ text: "Encerrar a conversa" }],
      });
      setPanel(null);
      sfx.talk();
    },
    [npcDef]
  );

  const interact = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    if (dialogueRef.current) return;
    const found = nearestNpc();
    if (!found) {
      toast("Não há ninguém por perto.", "info");
      return;
    }
    const npc = found.def;
    const mission = g.currentMission !== null ? missionById(g.currentMission) : null;
    if (mission && !g.completedMissions.includes(mission.id)) {
      const step = mission.steps[g.missionStep];
      if (step && step.kind === "talk" && step.npc === npc.id) {
        const def = npc;
        pendingRef.current = { mission, choice: null };
        setDialogue({
          mode: "chat",
          npcId: def.id,
          npcName: def.name,
          npcTitle: def.title,
          portrait: { ...def.palette, crown: def.crown, hood: def.hood },
          lines: [def.bio, "Falei. Agora vá e faça o que precisa ser feito."],
          awaiting: true,
        });
        return;
      }
      if (mission.giverNpc === npc.id && mission.areaId === g.player.areaId) {
        g.missionStep = 0;
        addLog(g, `Lei ${mission.id}: ${mission.title}`, "info", mission.id);
        const step0 = mission.steps[0];
        if (step0.kind === "dialogue") openNode(mission, step0.node, [mission.brief]);
        else advanceStep(mission);
        sfx.click();
        return;
      }
    }
    chatWith(npc.id);
  }, [advanceStep, chatWith, nearestNpc, npcDef, openNode, toast]);

  /* ------------------------------- movement ------------------------------- */

  const travelTo = useCallback(
    (areaId: string) => {
      const g = gameRef.current;
      if (!g) return;
      if (!g.unlockedAreas.includes(areaId)) {
        toast("Essa região ainda está bloqueada.", "bad");
        return;
      }
      const area = getArea(areaId);
      let sx = Math.floor(area.def.w / 2);
      let sy = Math.floor(area.def.h / 2);
      outer: for (let r = 0; r < Math.max(area.def.w, area.def.h); r++) {
        for (let dy = -r; dy <= r; dy++) {
          for (let dx = -r; dx <= r; dx++) {
            const nx = sx + dx;
            const ny = sy + dy;
            if (nx < 1 || ny < 1 || nx >= area.def.w - 1 || ny >= area.def.h - 1) continue;
            if (!solidAt(area, nx, ny)) {
              sx = nx;
              sy = ny;
              break outer;
            }
          }
        }
      }
      g.player.areaId = areaId;
      g.player.x = sx;
      g.player.y = sy;
      if (!g.discoveredAreas.includes(areaId)) g.discoveredAreas.push(areaId);
      setTheme(area.def.music);
      sfx.portal();
      flashRef.current = { a: 0.6, c: "#8fd8ff" };
      setPanel(null);
      bump();
    },
    [getArea, toast]
  );

  const useItem = useCallback(
    (id: string) => {
      const g = gameRef.current;
      if (!g) return;
      const def = ITEMS[id];
      if (!def?.use) return;
      applyEffects(g, def.use.effects);
      if (def.use.consume) removeItem(g, id, 1);
      toast(def.use.text, "good");
      sfx.good();
      bump();
    },
    [toast]
  );

  /* --------------------------------- loop --------------------------------- */

  useEffect(() => {
    const loop = (now: number) => {
      rafRef.current = requestAnimationFrame(loop);
      const g = gameRef.current;
      if (!g || screenRef.current !== "game") return;
      const dt = Math.min(64, now - lastRef.current || 16);
      lastRef.current = now;
      g.time += dt / 1000;

      const api = apiRef.current;
      const area = getArea(g.player.areaId);
      const blocked =
        !!dialogueRef.current || !!panelRef.current || rewardRef.current || overRef.current || endRef.current;

      let vx = touchRef.current.x;
      let vy = touchRef.current.y;
      if (keysRef.current.has("a") || keysRef.current.has("arrowleft")) vx -= 1;
      if (keysRef.current.has("d") || keysRef.current.has("arrowright")) vx += 1;
      if (keysRef.current.has("w") || keysRef.current.has("arrowup")) vy -= 1;
      if (keysRef.current.has("s") || keysRef.current.has("arrowdown")) vy += 1;
      const len = Math.hypot(vx, vy);
      if (len > 1) {
        vx /= len;
        vy /= len;
      }

      const moving = len > 0.08 && !blocked;
      if (moving) {
        const speed = 0.062;
        const nx = g.player.x + vx * speed * (dt / 16);
        const ny = g.player.y + vy * speed * (dt / 16);
        if (!solidAt(area, Math.round(nx), Math.round(g.player.y))) g.player.x = nx;
        if (!solidAt(area, Math.round(g.player.x), Math.round(ny))) g.player.y = ny;
        if (Math.abs(vx) > Math.abs(vy)) g.player.facing = vx > 0 ? "right" : "left";
        else g.player.facing = vy > 0 ? "down" : "up";
        g.player.anim = (g.player.anim + 1) % 4;
      }
      g.player.moving = moving;

      npcAnimRef.current.forEach((a) => {
        a.t += dt;
        if (a.t > 420) {
          a.t = 0;
          a.frame = (a.frame + 1) % 4;
          if (Math.random() < 0.3) a.dir = ["up", "down", "left", "right"][Math.floor(Math.random() * 4)];
        }
      });

      for (let i = g.particles.length - 1; i >= 0; i--) {
        const p = g.particles[i];
        p.life -= dt / 1000;
        p.x += p.vx * (dt / 16);
        p.y += p.vy * (dt / 16);
        p.vy += p.gravity * (dt / 16);
        if (p.life <= 0) g.particles.splice(i, 1);
      }
      for (let i = g.floaters.length - 1; i >= 0; i--) {
        const f = g.floaters[i];
        f.life -= 1;
        f.y -= 0.4;
        if (f.life <= 0) g.floaters.splice(i, 1);
      }

      // toasts expire
      const nowTs = Date.now();
      g.toasts = g.toasts.filter((t) => nowTs - t.at < 3600);

      // pick ups
      for (let i = g.worldItems.length - 1; i >= 0; i--) {
        const it = g.worldItems[i];
        if (it.areaId !== g.player.areaId) continue;
        if (Math.hypot(it.x - g.player.x, it.y - g.player.y) < 1.05) {
          addItem(g, it.item, 1);
          g.worldItems.splice(i, 1);
          const def = ITEMS[it.item];
          toast(`Você recolheu: ${def?.name ?? it.item}`, "gold");
          sfx.coin();
          api.burst?.(it.x, it.y, "#f7e3a8", 12);
          const mission = g.currentMission !== null ? missionById(g.currentMission) : null;
          if (mission) {
            const step = mission.steps[g.missionStep];
            if (step && step.kind === "collect" && step.item === it.item) {
              const total = g.inventory
                .filter((x) => x.id === step.item)
                .reduce((a, b) => a + b.count, 0);
              if (total >= step.count) api.advanceStep?.(mission);
            }
          }
          api.bump?.();
        }
      }

      // portals
      for (const pt of area.portals) {
        if (Math.round(g.player.x) === pt.x && Math.round(g.player.y) === pt.y) {
          if (!g.unlockedAreas.includes(pt.toArea)) {
            toast(`${AREA_NAME[pt.toArea] ?? pt.toArea} está bloqueada.`, "bad");
            g.player.x = pt.x === 0 ? pt.x + 1 : pt.x - 1;
          } else {
            api.travelTo?.(pt.toArea);
          }
        }
      }

      // visit step
      const mission = g.currentMission !== null ? missionById(g.currentMission) : null;
      if (mission) {
        const step = mission.steps[g.missionStep];
        if (step && step.kind === "visit" && step.areaId === g.player.areaId) {
          toast(`Você chegou: ${step.hint}`, "good");
          sfx.good();
          api.advanceStep?.(mission);
        }
      }

      const npc = api.nearestNpc?.();
      const name = npc ? npc.def.name : null;
      if (name !== nearRef.current) {
        nearRef.current = name;
        setNearNpc(name);
      }

      if (shakeRef.current > 0) shakeRef.current *= 0.86;
      if (flashRef.current) {
        flashRef.current.a -= dt / 420;
        if (flashRef.current.a <= 0) flashRef.current = null;
      }

      const ctx = canvasRef.current?.getContext("2d");
      if (ctx) {
        const npcPositions: Record<string, any> = {};
        NPCS.forEach((n) => {
          if (n.areaId !== g.player.areaId) return;
          let a = npcAnimRef.current.get(n.id);
          if (!a) {
            a = { frame: 0, dir: "down", t: 0 };
            npcAnimRef.current.set(n.id, a);
          }
          npcPositions[n.id] = {
            x: n.x,
            y: n.y,
            dir: a.dir,
            frame: a.frame,
            palette: n.palette,
            crown: n.crown,
            hood: n.hood,
          };
        });
        const mNow = g.currentMission !== null ? missionById(g.currentMission) : null;
        const spot = mNow
          ? (NPCS_BY_AREA[g.player.areaId] ?? []).find((n) => n.id === mNow.giverNpc)
          : undefined;
        const marker = spot ? { x: spot.x, y: spot.y } : null;
        renderScene({
          ctx,
          state: g,
          area,
          npcPositions,
          time: g.time * 1000,
          shake: shakeRef.current,
          flash: flashRef.current,
          marker,
        });
      }
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [getArea]);

  useEffect(() => {
    apiRef.current = {
      advanceStep,
      travelTo,
      nearestNpc,
      burst,
      bump,
      toast,
      interact,
      finishMission,
      openNode,
      continueDialogue: onContinue,
    };
  });

  /* --------------------- hooks nativos (Android WebView) ------------------- */

  useEffect(() => {
    const w = window as any;
    // chamado quando o app vai para segundo plano: salva o progresso e silencia a musica
    w.__gamePause = () => {
      const g = gameRef.current;
      if (g) saveGame(g);
      stopMusic();
    };
    // chamado quando o app volta para foreground
    w.__gameResume = () => {
      if (screenRef.current === "game") {
        setMutedState(isMuted());
        startMusic();
      }
    };
    // botao voltar do Android: fecha dialogos/paineis antes de sair do app
    w.__gameBack = () => {
      if (dialogueRef.current) {
        setDialogue(null);
        pendingRef.current = null;
        return true;
      }
      if (panelRef.current) {
        setPanel(null);
        return true;
      }
      if (reward) {
        setReward(null);
        return true;
      }
      return false;
    };
    return () => {
      delete w.__gamePause;
      delete w.__gameResume;
      delete w.__gameBack;
    };
  }, [reward]);

  /* ------------------------------- keyboard ------------------------------- */

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      keysRef.current.add(k);
      if (gameRef.current && screenRef.current === "game") {
        if (k === "e" || k === " ") apiRef.current.interact?.();
        else if (k === "i") setPanel((p) => (p === "inventory" ? null : "inventory"));
        else if (k === "r") setPanel((p) => (p === "relations" ? null : "relations"));
        else if (k === "j") setPanel((p) => (p === "journal" ? null : "journal"));
        else if (k === "m") setPanel((p) => (p === "map" ? null : "map"));
        else if (k === "escape") {
          if (dialogueRef.current?.awaiting) apiRef.current.continueDialogue?.();
          else if (dialogueRef.current) setDialogue(null);
          else setPanel((p) => (p === null ? "pause" : null));
        }
      } else if (screenRef.current === "start" && k === "enter") {
        startGame(playerName);
      }
    };
    const up = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase());
    const blur = () => keysRef.current.clear();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
    };
  }, [playerName, startGame]);

  /* -------------------------------- panels -------------------------------- */

  const openPanel = useCallback((p: Exclude<PanelKind, "pause">) => {
    setPanel((cur) => (cur === p ? null : p));
    sfx.click();
  }, []);

  const onTouchAction = useCallback(
    (a: ActionName) => {
      sfx.click();
      if (a === "interact") apiRef.current.interact?.();
      else if (a === "pause") setPanel((p) => (p === "pause" ? null : "pause"));
      else openPanel(a);
    },
    [openPanel]
  );

  const toggleMute = useCallback(() => {
    const m = !muted;
    setMutedState(m);
    setMuted(m);
  }, [muted]);

  /* -------------------------------- render -------------------------------- */

  const g = gameRef.current;
  const objective = (() => {
    if (!g) return "";
    const mission = g.currentMission !== null ? missionById(g.currentMission) : null;
    if (!mission) return "";
    const step = mission.steps[g.missionStep];
    if (!step) return "";
    if (step.kind === "collect" || step.kind === "visit" || step.kind === "talk") return step.hint;
    const giver = npcDef(mission.giverNpc);
    if (giver) {
      if (giver.areaId === g.player.areaId) return `Converse com ${giver.name}.`;
      return `Procure ${giver.name} em ${AREA_NAME[giver.areaId] ?? giver.areaId}.`;
    }
    return "Escolha o que dizer. Cada palavra tem peso.";
  })();

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#07050c]">
      <div className="absolute inset-0 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={view.w}
          height={view.h}
          className="max-h-full max-w-full border-2 border-[#241a33] shadow-[0_0_60px_rgba(0,0,0,0.9)]"
          style={{ width: `min(100%, calc(100vh * ${(view.w / view.h).toFixed(4)}))`, height: "auto" }}
        />
      </div>
      <div className="pointer-events-none absolute inset-0 vignette" />

      {screen === "game" && g && (
        <>
          <Hud
            state={g}
            objective={objective}
            onOpen={openPanel}
            onInteract={() => apiRef.current.interact?.()}
            nearNpc={nearNpc}
            muted={muted}
            onToggleMute={toggleMute}
          />

          <div className="pointer-events-none absolute left-1/2 top-[148px] z-30 flex -translate-x-1/2 flex-col items-center gap-1 sm:top-20">
            {g.toasts.slice(-4).map((t) => (
              <div
                key={t.id}
                className={`toast-anim border px-3 py-1 text-[12px] ${
                  t.tone === "good"
                    ? "border-[#3f7a52] bg-[#16281c] text-[#9fe0b0]"
                    : t.tone === "bad"
                      ? "border-[#7a2630] bg-[#2a1218] text-[#e8a0a8]"
                      : t.tone === "gold"
                        ? "border-[#8a6a2f] bg-[#2a2110] text-[#f7e3a8]"
                        : "border-[#3a2b4c] bg-[#1a1326] text-[#c9bcd8]"
                }`}
              >
                {t.text}
              </div>
            ))}
          </div>

          {dialogue && (
            <Dialogue
              d={dialogue}
              onChoose={onChoose}
              onContinue={onContinue}
              onClose={() => {
                setDialogue(null);
                pendingRef.current = null;
              }}
            />
          )}

          {!dialogue && !panel && !reward && (
            <TouchControls
              onMove={(x, y) => {
                touchRef.current.x = x;
                touchRef.current.y = y;
              }}
              onAction={onTouchAction}
            />
          )}

          {panel === "inventory" && (
            <InventoryPanel state={g} onClose={() => setPanel(null)} onUse={useItem} />
          )}
          {panel === "relations" && <RelationsPanel state={g} onClose={() => setPanel(null)} />}
          {panel === "journal" && <JournalPanel state={g} onClose={() => setPanel(null)} />}
          {panel === "map" && <MapPanel state={g} onClose={() => setPanel(null)} onTravel={travelTo} />}
          {panel === "pause" && (
            <PauseOverlay
              state={g}
              muted={muted}
              onToggleMute={toggleMute}
              onResume={() => setPanel(null)}
              onSave={() => {
                if (saveGame(g)) {
                  setHasSave(true);
                  toast("Jogo salvo.", "good");
                }
              }}
              onLoad={() => {
                const loaded = loadGame();
                if (loaded) {
                  gameRef.current = loaded;
                  setPanel(null);
                  setDialogue(null);
                  setTheme(getArea(loaded.player.areaId).def.music);
                  toast("Jogo carregado.", "good");
                  bump();
                }
              }}
              onRestart={restart}
              onTitle={toTitle}
            />
          )}

          {reward && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
              <div className="panel pop w-full max-w-md p-6 text-center">
                <div className="mono text-[10px] uppercase tracking-[0.4em] text-[#e8c06a]">
                  Lei {reward.law} dominada
                </div>
                <h2 className="gold glow-gold mt-2 text-2xl font-bold">{reward.title}</h2>
                <p className="mt-3 border-l-2 border-[#e8c06a] pl-3 text-left text-[13px] italic leading-relaxed text-[#d8cbe4]">
                  {reward.insight}
                </p>
                <div className="mono mt-3 text-[13px] text-[#e8c06a]">+{reward.score} pontos de poder</div>
                <button
                  className="btn btn-primary mt-4 w-full py-2"
                  onClick={() => {
                    setReward(null);
                    bump();
                  }}
                >
                  Continuar a jornada
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {screen === "start" && (
        <StartScreen
          name={playerName}
          setName={(n) => {
            setPlayerName(n);
            savePlayerName(n);
          }}
          hasSave={hasSave}
          scores={scores}
          onStart={() => startGame(playerName || "Sem Nome")}
          onContinue={() => {
            const loaded = loadGame();
            if (loaded) startGame(loaded.playerName, loaded);
          }}
        />
      )}

      {ending && g && (
        <EndScreen
          ending={ending}
          state={g}
          saved={scoreSaved}
          onSaveScore={(name) => {
            saveScore({
              name: name || "Sem Nome",
              score: g.score,
              ending: ENDINGS[ending].title,
              laws: g.completedMissions.length,
              date: Date.now(),
            });
            setScores(loadScores());
            setScoreSaved(true);
          }}
          onRestart={restart}
          onTitle={toTitle}
        />
      )}

      {gameOver && g && (
        <GameOverScreen
          title={gameOver.title}
          reason={gameOver.reason}
          score={g.score}
          onRestart={restart}
          onTitle={toTitle}
        />
      )}
    </div>
  );
}
