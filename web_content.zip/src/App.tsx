import { useCallback, useEffect, useRef, useState } from 'react';
import GameCanvas from './components/GameCanvas';
import StartScreen from './components/StartScreen';
import PauseOverlay from './components/PauseOverlay';
import GameOverScreen from './components/GameOverScreen';
import type { Engine } from './game/engine';
import type { EngineEvent, GameStats, HighScoreEntry } from './game/types';
import { audio } from './game/audio';
import { getBestScore, loadMuted, loadName, loadScores, saveMuted, saveName, saveScore } from './game/storage';

type Screen = 'menu' | 'playing' | 'paused' | 'gameover';

export default function App() {
  const engineRef = useRef<Engine | null>(null);
  const [screen, setScreenState] = useState<Screen>('menu');
  const screenRef = useRef<Screen>('menu');
  const setScreen = useCallback((s: Screen) => {
    screenRef.current = s;
    setScreenState(s);
  }, []);

  const [scores, setScores] = useState<HighScoreEntry[]>(() => loadScores());
  const [name, setName] = useState(() => loadName());
  const nameRef = useRef(name);
  nameRef.current = name;
  const [muted, setMuted] = useState(() => loadMuted());
  const [result, setResult] = useState<GameStats | null>(null);
  const [lastRank, setLastRank] = useState(-1);
  const [isNewBest, setIsNewBest] = useState(false);
  const [pauseScore, setPauseScore] = useState(0);

  useEffect(() => {
    audio.setMuted(muted);
    saveMuted(muted);
  }, [muted]);

  const startGame = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    audio.unlock();
    e.start();
    setScreen('playing');
  }, [setScreen]);

  const pauseGame = useCallback(() => {
    const e = engineRef.current;
    if (!e || screenRef.current !== 'playing' || e.phase !== 'running') return;
    e.pause();
    setPauseScore(e.score);
    setScreen('paused');
  }, [setScreen]);

  const resumeGame = useCallback(() => {
    const e = engineRef.current;
    if (!e || screenRef.current !== 'paused') return;
    audio.unlock();
    e.resume();
    setScreen('playing');
  }, [setScreen]);

  const quitToMenu = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    e.toAttract();
    setScreen('menu');
  }, [setScreen]);

  const handleEvent = useCallback(
    (ev: EngineEvent) => {
      const s = screenRef.current;
      if (ev.type === 'gameover') {
        const stats = ev.stats;
        const prevBest = getBestScore();
        let rank = -1;
        let next = loadScores();
        if (stats.score > 0) {
          const saved = saveScore({
            name: (nameRef.current || 'YOU').trim() || 'YOU',
            score: stats.score,
            correct: stats.correct,
            answered: stats.answered,
            distance: stats.distance,
            maxCombo: stats.maxCombo,
            date: Date.now(),
          });
          rank = saved.rank;
          next = saved.scores;
        }
        setScores(next);
        setLastRank(rank);
        setIsNewBest(stats.score > prevBest && stats.score > 0);
        setResult(stats);
        setScreen('gameover');
      } else if (ev.type === 'togglePause') {
        if (s === 'playing') pauseGame();
        else if (s === 'paused') resumeGame();
      } else if (ev.type === 'primary') {
        if (s === 'menu' || s === 'gameover') startGame();
        else if (s === 'paused') resumeGame();
      }
    },
    [pauseGame, resumeGame, startGame, setScreen],
  );

  // Auto-pause when the tab is hidden or the window loses focus.
  useEffect(() => {
    const onHide = () => {
      if (document.hidden) pauseGame();
    };
    const onBlur = () => pauseGame();
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('blur', onBlur);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('blur', onBlur);
    };
  }, [pauseGame]);

  const onNameChange = (n: string) => {
    setName(n);
    saveName(n);
  };

  const toggleMute = () => setMuted((m) => !m);

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-night font-body text-white select-none">
      <GameCanvas
        onReady={(e) => {
          engineRef.current = e;
        }}
        onEvent={handleEvent}
      />

      {screen === 'playing' && (
        <button
          type="button"
          onClick={pauseGame}
          aria-label="Pause"
          className="absolute right-3 top-[max(0.75rem,env(safe-area-inset-top))] z-20 flex h-11 w-11 items-center justify-center rounded-full border-2 border-gold-dark bg-parchment/90 text-ink shadow-lg transition-transform active:scale-95 sm:right-5 sm:top-5"
        >
          <span className="flex gap-1" aria-hidden>
            <span className="block h-4 w-1.5 rounded-sm bg-ink" />
            <span className="block h-4 w-1.5 rounded-sm bg-ink" />
          </span>
        </button>
      )}

      {screen === 'menu' && (
        <StartScreen onStart={startGame} scores={scores} name={name} onNameChange={onNameChange} muted={muted} onToggleMute={toggleMute} />
      )}

      {screen === 'paused' && (
        <PauseOverlay
          score={pauseScore}
          onResume={resumeGame}
          onRestart={startGame}
          onQuit={quitToMenu}
          muted={muted}
          onToggleMute={toggleMute}
        />
      )}

      {screen === 'gameover' && result && (
        <GameOverScreen stats={result} scores={scores} rank={lastRank} isNewBest={isNewBest} onRestart={startGame} onMenu={quitToMenu} />
      )}
    </div>
  );
}
