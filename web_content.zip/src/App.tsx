import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  ChatSession,
  ChatMessage,
  ChatSettings,
  MessageImage,
  StorageStats,
  SessionTokenStats,
} from './types/index.ts';
import {
  loadSettings,
  saveSettings,
  loadSessions,
  saveSessions,
  createNewSession,
  getStorageStats,
  exportSessionAsMarkdown,
  downloadFile,
} from './utils/storage.ts';
import { Header } from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { ChatMessageItem } from './components/ChatMessageItem.tsx';
import { ChatInput } from './components/ChatInput.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { StorageModal } from './components/StorageModal.tsx';
import { SearchModal } from './components/SearchModal.tsx';
import { ResponseHistoryModal } from './components/ResponseHistoryModal.tsx';
import { Bot, Sparkles, MessageSquarePlus, ShieldCheck } from 'lucide-react';

// Helper to calculate real-time session token stats from message history
function calculateSessionTokens(msgs: ChatMessage[]): SessionTokenStats {
  let totalIn = 0;
  let totalOut = 0;
  let lastIn = 0;
  let lastOut = 0;
  for (const m of msgs) {
    if (m.role === 'user') {
      const count =
        m.inputTokens ||
        Math.max(
          1,
          Math.round(m.content.split(/\s+/).filter(Boolean).length * 1.35) +
            (m.images?.length ? m.images.length * 258 : 0)
        );
      totalIn += count;
      lastIn = count;
    } else if (m.role === 'model') {
      const outCount =
        m.outputTokens ||
        m.tokensEstimate ||
        Math.max(1, Math.round(m.content.split(/\s+/).filter(Boolean).length * 1.3));
      const inCount = m.inputTokens || 0;
      totalOut += outCount;
      if (inCount > 0) {
        totalIn += inCount;
        lastIn = inCount;
      }
      lastOut = outCount;
    }
  }
  return {
    totalInputTokens: totalIn,
    totalOutputTokens: totalOut,
    totalTokens: totalIn + totalOut,
    lastInputTokens: lastIn,
    lastOutputTokens: lastOut,
  };
}

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [globalSettings, setGlobalSettings] = useState<ChatSettings>(loadSettings);
  const [storageStats, setStorageStats] = useState<StorageStats>(getStorageStats);

  // UI state
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isStorageOpen, setIsStorageOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Response History Modal state (JanitorAI style)
  const [historyModalMessageId, setHistoryModalMessageId] = useState<string | null>(null);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync fullscreen state with document
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Auto-request fullscreen on first user interaction if fullScreenMode is enabled
  useEffect(() => {
    if (globalSettings.fullScreenMode === false) return;

    const handleAutoFullscreen = () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      }
    };

    window.addEventListener('click', handleAutoFullscreen, { once: true });
    return () => window.removeEventListener('click', handleAutoFullscreen);
  }, [globalSettings.fullScreenMode]);

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleToggleChatWidth = () => {
    const current = effectiveSettings.chatWidth || 'full';
    const nextWidth: 'standard' | 'full' = current === 'full' ? 'standard' : 'full';
    const updated: ChatSettings = { ...globalSettings, chatWidth: nextWidth };
    setGlobalSettings(updated);
    saveSettings(updated);
  };

  // Initialize sessions on mount & normalize alternatives
  useEffect(() => {
    const loaded = loadSessions();
    if (loaded.length > 0) {
      const normalized = loaded.map((sess) => ({
        ...sess,
        messages: sess.messages.map((m) => {
          if (m.role === 'model') {
            const alts =
              m.alternatives && m.alternatives.length > 0
                ? m.alternatives
                : m.content
                ? [m.content]
                : [];
            const activeIdx =
              typeof m.activeAlternativeIndex === 'number'
                ? m.activeAlternativeIndex
                : Math.max(0, alts.length - 1);
            return {
              ...m,
              alternatives: alts,
              activeAlternativeIndex: activeIdx,
            };
          }
          return m;
        }),
      }));
      setSessions(normalized);
      setCurrentSessionId(normalized[0].id);
    } else {
      const initialSession = createNewSession();
      setSessions([initialSession]);
      setCurrentSessionId(initialSession.id);
      saveSessions([initialSession]);
    }
    setStorageStats(getStorageStats());
  }, []);

  // Update storage stats whenever sessions change
  useEffect(() => {
    setStorageStats(getStorageStats());
  }, [sessions]);

  // Current session object with real-time calculated token stats
  const currentSession = useMemo<ChatSession | null>(() => {
    const s = sessions.find((item) => item.id === currentSessionId);
    if (!s) return null;
    return {
      ...s,
      tokenStats: calculateSessionTokens(s.messages),
    };
  }, [sessions, currentSessionId]);

  // Effective settings: merged global settings with per-session custom override (if any)
  const effectiveSettings = useMemo(() => {
    if (currentSession?.customSettings && Object.keys(currentSession.customSettings).length > 0) {
      return { ...globalSettings, ...currentSession.customSettings };
    }
    return globalSettings;
  }, [globalSettings, currentSession]);

  // Auto-scroll to bottom of messages
  const scrollToBottom = useCallback((smooth = true) => {
    if (effectiveSettings.autoScroll) {
      messagesEndRef.current?.scrollIntoView({
        behavior: smooth ? 'smooth' : 'auto',
      });
    }
  }, [effectiveSettings.autoScroll]);

  useEffect(() => {
    scrollToBottom(false);
  }, [currentSessionId]);

  useEffect(() => {
    scrollToBottom(true);
  }, [currentSession?.messages?.length]);

  // Global Keyboard shortcuts: Ctrl+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Session Management Actions
  const handleNewSession = () => {
    const newSession = createNewSession();
    const updated = [newSession, ...sessions];
    setSessions(updated);
    setCurrentSessionId(newSession.id);
    saveSessions(updated);
  };

  const handleSelectSession = (id: string) => {
    if (isStreaming) {
      handleStopStreaming();
    }
    setCurrentSessionId(id);
  };

  const handleDeleteSession = (id: string) => {
    const remaining = sessions.filter((s) => s.id !== id);
    if (remaining.length === 0) {
      const fresh = createNewSession();
      setSessions([fresh]);
      setCurrentSessionId(fresh.id);
      saveSessions([fresh]);
    } else {
      setSessions(remaining);
      if (currentSessionId === id) {
        setCurrentSessionId(remaining[0].id);
      }
      saveSessions(remaining);
    }
  };

  const handleTogglePinSession = (id: string) => {
    const updated = sessions.map((s) =>
      s.id === id ? { ...s, pinned: !s.pinned } : s
    );
    setSessions(updated);
    saveSessions(updated);
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    const updated = sessions.map((s) =>
      s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s
    );
    setSessions(updated);
    saveSessions(updated);
  };

  const handleExportSession = (session: ChatSession) => {
    const md = exportSessionAsMarkdown(session, effectiveSettings.botName);
    const safeTitle = session.title.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 30);
    downloadFile(md, `${safeTitle || 'percakapan'}.md`, 'text/markdown');
  };

  // Delete message inside current session
  const handleDeleteMessage = (messageId: string) => {
    if (!currentSession) return;
    const updatedMessages = currentSession.messages.filter((m) => m.id !== messageId);
    const updatedSession = { ...currentSession, messages: updatedMessages, updatedAt: Date.now() };
    const updatedSessions = sessions.map((s) =>
      s.id === currentSession.id ? updatedSession : s
    );
    setSessions(updatedSessions);
    saveSessions(updatedSessions);
  };

  // Clear all data (Factory Reset)
  const handleClearAllData = () => {
    const freshSession = createNewSession();
    setSessions([freshSession]);
    setCurrentSessionId(freshSession.id);
    saveSessions([freshSession]);
    setStorageStats(getStorageStats());
  };

  // Stop Streaming
  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
    setStreamingMessageId(null);
  };

  // Core stream runner: streams AI generation into a specific model message & alternative slot
  const executeChatStream = async (
    targetSessionId: string,
    historyToSend: ChatMessage[],
    botMessageId: string,
    targetAltIndex: number
  ) => {
    setIsStreaming(true);
    setStreamingMessageId(botMessageId);

    const startTime = performance.now();
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    try {
      const windowSize = effectiveSettings.contextWindow;
      const boundedHistory =
        windowSize > 0 && historyToSend.length > windowSize
          ? historyToSend.slice(-windowSize)
          : historyToSend;

      const payload = {
        messages: boundedHistory,
        model: effectiveSettings.model,
        systemInstruction: effectiveSettings.systemInstruction,
        userPersona: effectiveSettings.userPersona || '',
        userName: effectiveSettings.userName || 'Saya',
        temperature: effectiveSettings.temperature,
        topP: effectiveSettings.topP,
        topK: effectiveSettings.topK,
        maxOutputTokens: effectiveSettings.maxOutputTokens || undefined,
        thinkingLevel: effectiveSettings.thinkingLevel || undefined,
        safetyFilterEnabled: effectiveSettings.safetyFilterEnabled,
        safetyThreshold: effectiveSettings.safetyThreshold,
        antiRefusalBypassEnabled: effectiveSettings.antiRefusalBypassEnabled !== false,
        provider: effectiveSettings.provider || 'gemini',
        openRouterApiKey: effectiveSettings.openRouterApiKey || '',
        openRouterModel: effectiveSettings.openRouterModel || '',
      };

      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: abortController.signal,
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || `Server merespons kode status: ${response.status}`);
      }

      if (!response.body) {
        throw new Error('Respons stream tidak tersedia dari server.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let buffer = '';
      let streamInputTokens = 0;
      let streamOutputTokens = 0;

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const dataStr = trimmed.slice(5).trim();

          if (dataStr === '[DONE]') {
            break;
          }

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.error) {
              throw new Error(parsed.error);
            }
            if (parsed.usageMetadata) {
              streamInputTokens = parsed.usageMetadata.promptTokenCount || streamInputTokens;
              streamOutputTokens = parsed.usageMetadata.candidatesTokenCount || streamOutputTokens;
            }
            if (parsed.text) {
              accumulatedText += parsed.text;

              // Incremental UI update
              setSessions((prevSessions) => {
                return prevSessions.map((s) => {
                  if (s.id !== targetSessionId) return s;
                  const msgs = s.messages.map((m) => {
                    if (m.id === botMessageId) {
                      const alts = m.alternatives ? [...m.alternatives] : [accumulatedText];
                      alts[targetAltIndex] = accumulatedText;
                      return {
                        ...m,
                        content: accumulatedText,
                        alternatives: alts,
                        activeAlternativeIndex: targetAltIndex,
                        isError: false,
                        inputTokens: streamInputTokens || undefined,
                        outputTokens:
                          streamOutputTokens ||
                          Math.round(accumulatedText.split(/\s+/).filter(Boolean).length * 1.3),
                      };
                    }
                    return m;
                  });
                  return {
                    ...s,
                    messages: msgs,
                    updatedAt: Date.now(),
                    tokenStats: calculateSessionTokens(msgs),
                  };
                });
              });
            }
          } catch (e: any) {
            if (e.message && e.message !== 'Unexpected end of JSON input') {
              throw e;
            }
          }
        }
      }

      const durationMs = Math.round(performance.now() - startTime);
      const fallbackOutputTokens = Math.round(
        accumulatedText.split(/\s+/).filter(Boolean).length * 1.3
      );
      const finalInputTokens =
        streamInputTokens ||
        Math.round(
          boundedHistory.reduce(
            (acc, m) => acc + m.content.split(/\s+/).filter(Boolean).length * 1.35,
            0
          )
        );
      const finalOutputTokens = streamOutputTokens || fallbackOutputTokens;

      // Final state save
      setSessions((prevSessions) => {
        const finalized = prevSessions.map((s) => {
          if (s.id !== targetSessionId) return s;
          const msgs = s.messages.map((m) => {
            if (m.id === botMessageId) {
              const alts = m.alternatives && m.alternatives.length > 0 ? [...m.alternatives] : [accumulatedText];
              alts[targetAltIndex] = accumulatedText;
              return {
                ...m,
                content: accumulatedText,
                alternatives: alts,
                activeAlternativeIndex: targetAltIndex,
                durationMs,
                isError: false,
                tokensEstimate: finalOutputTokens,
                inputTokens: finalInputTokens,
                outputTokens: finalOutputTokens,
                totalTokens: finalInputTokens + finalOutputTokens,
              };
            }
            return m;
          });
          return {
            ...s,
            messages: msgs,
            updatedAt: Date.now(),
            tokenStats: calculateSessionTokens(msgs),
          };
        });
        saveSessions(finalized);
        return finalized;
      });
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream dihentikan oleh pengguna.');
      } else {
        console.warn('Chat request failed:', err.message || err);
        const errorText = err.message || 'Gagal memuat tanggapan dari Gemini API.';

        setSessions((prevSessions) => {
          const errorFinalized = prevSessions.map((s) => {
            if (s.id !== targetSessionId) return s;
            const msgs = s.messages.map((m) => {
              if (m.id === botMessageId) {
                return {
                  ...m,
                  content: errorText,
                  isError: true,
                };
              }
              return m;
            });
            return { ...s, messages: msgs, updatedAt: Date.now() };
          });
          saveSessions(errorFinalized);
          return errorFinalized;
        });
      }
    } finally {
      setIsStreaming(false);
      setStreamingMessageId(null);
      abortControllerRef.current = null;
    }
  };

  // Send Message / AI Generation (New User Message turn)
  const handleSendMessage = async (
    content: string,
    images: MessageImage[] = [],
    isRegenerate = false,
    customMessagesList?: ChatMessage[]
  ) => {
    if ((!content.trim() && images.length === 0 && !isRegenerate) || isStreaming) return;

    const targetSession: ChatSession = currentSession ? { ...currentSession } : createNewSession();
    let allSessions = [...sessions];

    if (!currentSession) {
      allSessions = [targetSession, ...sessions];
    }

    const now = Date.now();
    let currentSessionMessages = customMessagesList || [...targetSession.messages];

    // If new user message
    if (!isRegenerate && content.trim()) {
      const userMessage: ChatMessage = {
        id: `msg_${now}_${Math.random().toString(36).substring(2, 7)}`,
        role: 'user',
        content,
        timestamp: now,
        images: images.length > 0 ? images : undefined,
      };
      currentSessionMessages.push(userMessage);

      // Auto-title session if it's the first message and title is default
      if (
        targetSession.messages.length === 0 &&
        (targetSession.title === 'Percakapan Baru' || targetSession.title === 'Obrolan Baru')
      ) {
        const cleanTitle = content.trim().slice(0, 32);
        if (cleanTitle) {
          targetSession.title = cleanTitle;
        }
      }
    }

    // Create placeholder for AI model response with JanitorAI alternatives support
    const botMessageId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const botMessage: ChatMessage = {
      id: botMessageId,
      role: 'model',
      content: '',
      timestamp: Date.now(),
      alternatives: [''],
      activeAlternativeIndex: 0,
    };
    currentSessionMessages.push(botMessage);

    // Update session in state immediately
    const updatedSession: ChatSession = {
      ...targetSession,
      messages: currentSessionMessages,
      updatedAt: Date.now(),
    };

    const nextSessions = allSessions.map((s) =>
      s.id === updatedSession.id ? updatedSession : s
    );
    setSessions(nextSessions);
    saveSessions(nextSessions);

    const historyToConsider = currentSessionMessages.slice(0, -1);
    await executeChatStream(updatedSession.id, historyToConsider, botMessageId, 0);
  };

  // JanitorAI-style: Generate an alternative response (Swipe) for any bot message without deleting past responses
  const handleRegenerateSwipe = async (botMessageId: string) => {
    if (!currentSession || isStreaming) return;

    const botIndex = currentSession.messages.findIndex((m) => m.id === botMessageId);
    if (botIndex === -1) return;

    const targetBotMsg = currentSession.messages[botIndex];
    const existingAlts =
      targetBotMsg.alternatives && targetBotMsg.alternatives.length > 0
        ? [...targetBotMsg.alternatives]
        : targetBotMsg.content
        ? [targetBotMsg.content]
        : [];

    // Append new empty slot for this new swipe
    existingAlts.push('');
    const newAltIndex = existingAlts.length - 1;

    // Update target message with new alternative slot
    const updatedMsgs = currentSession.messages.map((m, idx) => {
      if (idx === botIndex) {
        return {
          ...m,
          content: '',
          alternatives: existingAlts,
          activeAlternativeIndex: newAltIndex,
          isError: false,
          timestamp: Date.now(),
        };
      }
      return m;
    });

    const updatedSession = { ...currentSession, messages: updatedMsgs, updatedAt: Date.now() };
    const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
    setSessions(nextSessions);
    saveSessions(nextSessions);

    // Pass conversation history up to the bot message (i.e. all context up to the prompting user message)
    const historyToSend = currentSession.messages.slice(0, botIndex);
    await executeChatStream(updatedSession.id, historyToSend, botMessageId, newAltIndex);
  };

  // Switch model and immediately generate a new swipe
  const handleSwitchModelAndRetry = (newModel: string) => {
    const updatedSettings = {
      ...globalSettings,
      model: newModel,
      provider: 'gemini' as const,
    };
    setGlobalSettings(updatedSettings);
    saveSettings(updatedSettings);

    if (currentSession && currentSession.messages.length > 0) {
      const lastMsg = currentSession.messages[currentSession.messages.length - 1];
      if (lastMsg.role === 'model') {
        handleRegenerateSwipe(lastMsg.id);
      }
    }
  };

  // Switch alternative (swipe) index for a message
  const handleSwitchAlternative = (messageId: string, altIndex: number) => {
    if (!currentSession) return;
    const updatedMsgs = currentSession.messages.map((m) => {
      if (m.id === messageId) {
        const alts =
          m.alternatives && m.alternatives.length > 0
            ? m.alternatives
            : m.content
            ? [m.content]
            : [];
        if (alts[altIndex] !== undefined) {
          return {
            ...m,
            content: alts[altIndex],
            alternatives: alts,
            activeAlternativeIndex: altIndex,
          };
        }
      }
      return m;
    });
    const updatedSession = { ...currentSession, messages: updatedMsgs, updatedAt: Date.now() };
    const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
    setSessions(nextSessions);
    saveSessions(nextSessions);
  };

  // Delete specific alternative from response history
  const handleDeleteAlternative = (messageId: string, altIndex: number) => {
    if (!currentSession) return;
    const updatedMsgs = currentSession.messages.map((m) => {
      if (m.id === messageId) {
        const alts =
          m.alternatives && m.alternatives.length > 0
            ? [...m.alternatives]
            : m.content
            ? [m.content]
            : [];
        if (alts.length <= 1) return m; // maintain at least 1 alternative
        alts.splice(altIndex, 1);
        const curIdx = m.activeAlternativeIndex ?? 0;
        const newActiveIdx = Math.max(
          0,
          Math.min(curIdx >= altIndex ? curIdx - 1 : curIdx, alts.length - 1)
        );
        return {
          ...m,
          alternatives: alts,
          activeAlternativeIndex: newActiveIdx,
          content: alts[newActiveIdx],
        };
      }
      return m;
    });
    const updatedSession = { ...currentSession, messages: updatedMsgs, updatedAt: Date.now() };
    const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
    setSessions(nextSessions);
    saveSessions(nextSessions);
  };

  // Edit alternative text from inside ResponseHistoryModal
  const handleEditAlternativeInModal = (
    messageId: string,
    altIndex: number,
    newContent: string
  ) => {
    if (!currentSession) return;
    const updatedMsgs = currentSession.messages.map((m) => {
      if (m.id === messageId) {
        const alts =
          m.alternatives && m.alternatives.length > 0
            ? [...m.alternatives]
            : m.content
            ? [m.content]
            : [];
        alts[altIndex] = newContent;
        const curActive = m.activeAlternativeIndex ?? 0;
        return {
          ...m,
          alternatives: alts,
          content: curActive === altIndex ? newContent : m.content,
          timestamp: Date.now(),
        };
      }
      return m;
    });
    const updatedSession = { ...currentSession, messages: updatedMsgs, updatedAt: Date.now() };
    const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
    setSessions(nextSessions);
    saveSessions(nextSessions);
  };

  // Add a manual alternative to response history
  const handleAddManualAlternative = (messageId: string, content: string) => {
    if (!currentSession) return;
    const updatedMsgs = currentSession.messages.map((m) => {
      if (m.id === messageId) {
        const alts =
          m.alternatives && m.alternatives.length > 0
            ? [...m.alternatives]
            : m.content
            ? [m.content]
            : [];
        alts.push(content);
        const newActiveIdx = alts.length - 1;
        return {
          ...m,
          alternatives: alts,
          activeAlternativeIndex: newActiveIdx,
          content: content,
          timestamp: Date.now(),
        };
      }
      return m;
    });
    const updatedSession = { ...currentSession, messages: updatedMsgs, updatedAt: Date.now() };
    const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
    setSessions(nextSessions);
    saveSessions(nextSessions);
  };

  // Edit user message (options: just save text OR save & regenerate from here)
  const handleEditUserMessage = (
    messageIndex: number,
    newContent: string,
    shouldRegenerate: boolean
  ) => {
    if (!currentSession || isStreaming) return;
    const msgs = [...currentSession.messages];
    const targetMsg = msgs[messageIndex];
    if (!targetMsg) return;

    targetMsg.content = newContent;
    targetMsg.timestamp = Date.now();

    if (shouldRegenerate) {
      const truncated = msgs.slice(0, messageIndex + 1);
      handleSendMessage('', [], false, truncated);
    } else {
      const updatedSession = {
        ...currentSession,
        messages: msgs,
        updatedAt: Date.now(),
      };
      const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
      setSessions(nextSessions);
      saveSessions(nextSessions);
    }
  };

  // Edit bot response directly (Option 1: Overwrite current version, Option 2: Save as new alternative version)
  const handleEditModelMessage = (
    messageId: string,
    newContent: string,
    mode: 'overwrite' | 'new_alternative' = 'overwrite'
  ) => {
    if (!currentSession) return;
    const updatedMsgs = currentSession.messages.map((m) => {
      if (m.id === messageId) {
        const alts =
          m.alternatives && m.alternatives.length > 0
            ? [...m.alternatives]
            : m.content
            ? [m.content]
            : [];
        let activeIdx = m.activeAlternativeIndex ?? Math.max(0, alts.length - 1);
        if (activeIdx < 0 || activeIdx >= alts.length) {
          activeIdx = Math.max(0, alts.length - 1);
        }

        if (mode === 'new_alternative') {
          // Append as a brand new version (JanitorAI style)
          alts.push(newContent);
          activeIdx = alts.length - 1;
        } else {
          // Overwrite the current active version
          if (alts.length === 0) {
            alts.push(newContent);
            activeIdx = 0;
          } else {
            alts[activeIdx] = newContent;
          }
        }

        return {
          ...m,
          content: newContent,
          alternatives: alts,
          activeAlternativeIndex: activeIdx,
          timestamp: Date.now(),
        };
      }
      return m;
    });

    const updatedSession = {
      ...currentSession,
      messages: updatedMsgs,
      updatedAt: Date.now(),
    };

    const nextSessions = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
    setSessions(nextSessions);
    saveSessions(nextSessions);
  };

  // Find active message for ResponseHistoryModal
  const historyModalMessage = useMemo(() => {
    if (!historyModalMessageId || !currentSession) return null;
    return currentSession.messages.find((m) => m.id === historyModalMessageId) || null;
  }, [historyModalMessageId, currentSession]);

  return (
    <div className="flex h-screen h-dvh w-screen w-full bg-slate-950 text-slate-100 overflow-hidden select-none">
      {/* Sidebar Drawer */}
      <Sidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        storageStats={storageStats}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        onTogglePinSession={handleTogglePinSession}
        onRenameSession={handleRenameSession}
        onExportSession={handleExportSession}
        onOpenStorage={() => setIsStorageOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Chat Workspace */}
      <div className="relative flex-1 flex flex-col h-full min-w-0 bg-slate-950 overflow-hidden">
        {/* Dynamic Background Wallpaper */}
        {effectiveSettings.backgroundEnabled && effectiveSettings.backgroundImageUrl && (
          <div
            className="absolute inset-0 pointer-events-none bg-center bg-cover bg-no-repeat transition-all duration-700 z-0"
            style={{
              backgroundImage: `url(${effectiveSettings.backgroundImageUrl})`,
              opacity: effectiveSettings.backgroundOpacity ?? 0.25,
              filter: `blur(${effectiveSettings.backgroundBlur ?? 2}px)`,
              transform: 'scale(1.04)',
            }}
          />
        )}

        {/* Header */}
        <Header
          currentSession={currentSession}
          settings={globalSettings}
          effectiveSettings={effectiveSettings}
          isStreaming={isStreaming}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
          chatWidth={effectiveSettings.chatWidth || 'full'}
          onToggleChatWidth={handleToggleChatWidth}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenStorage={() => setIsStorageOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
          onNewChat={handleNewSession}
          onUpdateSessionSettings={(updated) => {
            if (!currentSession) return;
            const newOverride = { ...(currentSession.customSettings || {}), ...updated };
            const updatedSession = { ...currentSession, customSettings: newOverride };
            const updatedSessions = sessions.map((s) =>
              s.id === currentSession.id ? updatedSession : s
            );
            setSessions(updatedSessions);
            saveSessions(updatedSessions);
          }}
        />

        {/* Chat Messages Container */}
        <div className="relative z-10 flex-1 overflow-y-auto min-h-0 select-text">
          {!currentSession || currentSession.messages.length === 0 ? (
            /* Empty State Hero */
            <div className="h-full flex flex-col items-center justify-center p-6 text-center max-w-xl mx-auto">
              <div className="w-16 h-16 rounded-2xl overflow-hidden bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center text-white shadow-xl shadow-indigo-600/25 mb-4">
                {effectiveSettings.botAvatar &&
                (effectiveSettings.botAvatar.startsWith('data:') ||
                  effectiveSettings.botAvatar.startsWith('http')) ? (
                  <img
                    src={effectiveSettings.botAvatar}
                    alt="Bot Avatar"
                    className="w-full h-full object-cover"
                  />
                ) : effectiveSettings.botAvatar ? (
                  <span className="text-3xl">{effectiveSettings.botAvatar}</span>
                ) : (
                  <Bot className="w-8 h-8" />
                )}
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                NexusAI Chatbot Cerdas &amp; Privat
              </h1>
              <p className="text-slate-400 text-xs sm:text-sm mt-2 max-w-md leading-relaxed">
                Pengaturan parameter sepenuhnya berada di tangan Anda: sesuaikan model Gemini,
                temperatur kreativitas, instruksi sistem persona, serta riwayat tanggapan multi-versi.
              </p>

              <div className="mt-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>100% Data Disimpan Lokal di Browser Anda</span>
              </div>
            </div>
          ) : (
            /* Rendered Messages */
            <div className="py-4 space-y-2.5">
              {currentSession.messages.map((message, idx) => (
                <ChatMessageItem
                  key={message.id}
                  message={message}
                  settings={effectiveSettings}
                  isStreaming={isStreaming && streamingMessageId === message.id}
                  onDelete={() => handleDeleteMessage(message.id)}
                  onRegenerate={
                    message.role === 'model'
                      ? () => handleRegenerateSwipe(message.id)
                      : undefined
                  }
                  onRegenerateSwipe={
                    message.role === 'model'
                      ? () => handleRegenerateSwipe(message.id)
                      : undefined
                  }
                  onSwitchModelAndRetry={handleSwitchModelAndRetry}
                  onEditUser={
                    message.role === 'user'
                      ? (newContent, shouldRegenerate) =>
                          handleEditUserMessage(idx, newContent, shouldRegenerate)
                      : undefined
                  }
                  onEditModelMessage={
                    message.role === 'model'
                      ? (messageId, newContent, mode) =>
                          handleEditModelMessage(messageId, newContent, mode)
                      : undefined
                  }
                  onSwitchAlternative={handleSwitchAlternative}
                  onOpenHistoryModal={(msg) => {
                    setHistoryModalMessageId(msg.id);
                    setIsHistoryModalOpen(true);
                  }}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Bar Section */}
        <ChatInput
          onSendMessage={handleSendMessage}
          onStopStreaming={handleStopStreaming}
          isStreaming={isStreaming}
          settings={effectiveSettings}
          onOpenSettings={() => setIsSettingsOpen(true)}
          hasMessages={Boolean(currentSession && currentSession.messages.length > 0)}
        />
      </div>

      {/* JanitorAI Response History Modal */}
      <ResponseHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => {
          setIsHistoryModalOpen(false);
          setHistoryModalMessageId(null);
        }}
        message={historyModalMessage}
        onSelectAlternative={handleSwitchAlternative}
        onDeleteAlternative={handleDeleteAlternative}
        onEditAlternative={handleEditAlternativeInModal}
        onAddManualAlternative={handleAddManualAlternative}
        onRegenerateNewAlternative={handleRegenerateSwipe}
        isStreaming={isStreaming}
        botName={effectiveSettings.botName}
        botAvatar={effectiveSettings.botAvatar}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        globalSettings={globalSettings}
        currentSession={currentSession}
        onSaveGlobal={(newSettings) => {
          setGlobalSettings(newSettings);
          saveSettings(newSettings);
        }}
        onSaveSessionOverride={(override) => {
          if (!currentSession) return;
          const updatedSession = {
            ...currentSession,
            customSettings: override || undefined,
            updatedAt: Date.now(),
          };
          const updatedSessions = sessions.map((s) =>
            s.id === currentSession.id ? updatedSession : s
          );
          setSessions(updatedSessions);
          saveSessions(updatedSessions);
        }}
      />

      {/* Local Storage Manager Modal */}
      <StorageModal
        isOpen={isStorageOpen}
        onClose={() => setIsStorageOpen(false)}
        storageStats={storageStats}
        currentSession={currentSession}
        onRefreshData={() => {
          setSessions(loadSessions());
          setGlobalSettings(loadSettings());
          setStorageStats(getStorageStats());
        }}
        onClearAllData={handleClearAllData}
      />

      {/* Global Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        sessions={sessions}
        onSelectSession={handleSelectSession}
      />
    </div>
  );
}
