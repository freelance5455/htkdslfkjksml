import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft, ArrowRight, Bell, BookOpen, Bookmark, BookMarked, CheckCircle2,
  ChevronRight, CircleHelp, ClipboardList, Download, FileText, GraduationCap,
  Home as HomeIcon, Info, Library, Menu, Play, Search, Share2, ShieldCheck,
  Sparkles, Trophy, UserRound, Video, X, Settings, LogOut, LockKeyhole,
  Clock3, BarChart3, Languages, History, Map, Landmark, WalletCards
} from "lucide-react";

const subjects = [
  { name: "History", topics: 120, icon: Landmark, tone: "orange" },
  { name: "Geography", topics: 95, icon: Map, tone: "green" },
  { name: "Polity", topics: 80, icon: Library, tone: "blue" },
  { name: "Economics", topics: 70, icon: BarChart3, tone: "yellow" },
  { name: "Education", topics: 60, icon: GraduationCap, tone: "purple" },
  { name: "Odia", topics: 50, icon: Languages, tone: "brown" },
  { name: "English", topics: 40, icon: BookOpen, tone: "teal" },
];

const notes = [
  ["Ancient India Notes", "PDF · 2.4 MB", "History"],
  ["Medieval India Notes", "PDF · 1.8 MB", "History"],
  ["Modern India Notes", "PDF · 2.1 MB", "History"],
  ["Indian Polity Notes", "PDF · 1.6 MB", "Polity"],
  ["Indian Economy Notes", "PDF · 1.9 MB", "Economics"],
  ["Geography Notes", "PDF · 2.2 MB", "Geography"],
  ["Education Notes", "PDF · 1.5 MB", "Education"],
] as const;

const videos = [
  ["Maurya Empire", "25:36", "History"],
  ["Delhi Sultanate", "31:20", "History"],
  ["Indian Constitution", "20:15", "Polity"],
  ["Economic Reforms", "22:10", "Economics"],
  ["Resources in India", "19:45", "Geography"],
] as const;

const tests = [
  ["Full Length Test", "20 Tests", ClipboardList],
  ["Subject Wise Test", "8 Subjects", CheckCircle2],
  ["Chapter Wise Test", "150+ Tests", BookOpen],
  ["Previous Year Papers", "10 Papers", FileText],
  ["Practice Test", "Unlimited", Sparkles],
] as const;

type Page = "home" | "courses" | "notes" | "tests" | "videos" | "about" | "bookmarks" | "downloads" | "purchase" | "privacy" | "settings" | "topic" | "test" | "video";

function App() {
  const [page, setPage] = useState<Page>("home");
  const [splash, setSplash] = useState(true);
  const [drawer, setDrawer] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState("History");
  const [selectedTitle, setSelectedTitle] = useState("");
  const [noteTab, setNoteTab] = useState("All");
  const [videoTab, setVideoTab] = useState("All");
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [toast, setToast] = useState("");
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [downloads, setDownloads] = useState<string[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => setSplash(false), 1800);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  const go = (next: Page) => {
    setPage(next);
    setDrawer(false);
    setSearchOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const showToast = (message: string) => setToast(message);
  const toggleBookmark = (title: string) => {
    setBookmarks((old) => old.includes(title) ? old.filter(x => x !== title) : [...old, title]);
    showToast(bookmarks.includes(title) ? "Removed from bookmarks" : "Added to bookmarks");
  };
  const downloadNote = (title: string) => {
    setDownloads((old) => old.includes(title) ? old : [...old, title]);
    showToast(`${title} saved to Downloads`);
  };
  const shareApp = async () => {
    const data = { title: "TGT Pathshala", text: "TGT Pathshala – Your Success, Our Mission" };
    try {
      if (navigator.share) await navigator.share(data);
      else await navigator.clipboard.writeText("TGT Pathshala – Your Success, Our Mission");
      showToast("Share information copied");
    } catch { showToast("Share cancelled"); }
  };

  if (splash) return <Splash />;

  const content = (() => {
    switch (page) {
      case "home": return <Home go={go} setSubject={setSelectedSubject} />;
      case "courses": return <Courses onSubject={(s) => { setSelectedSubject(s); go("topic"); }} />;
      case "topic": return <TopicList subject={selectedSubject} go={go} setTitle={setSelectedTitle} />;
      case "notes": return <Notes tab={noteTab} setTab={setNoteTab} query={query} bookmarks={bookmarks} toggleBookmark={toggleBookmark} download={downloadNote} />;
      case "tests": return <Tests go={go} setTitle={setSelectedTitle} />;
      case "test": return <TestPaper title={selectedTitle || "Full Length Test"} go={go} showToast={showToast} />;
      case "videos": return <Videos tab={videoTab} setTab={setVideoTab} go={go} setTitle={setSelectedTitle} />;
      case "video": return <VideoPlayer title={selectedTitle || "Video Lecture"} go={go} />;
      case "about": return <About />;
      case "bookmarks": return <Bookmarks items={bookmarks} go={go} />;
      case "downloads": return <Downloads items={downloads} />;
      case "purchase": return <Purchase showToast={showToast} />;
      case "privacy": return <Privacy />;
      case "settings": return <SettingsPage showToast={showToast} />;
      default: return <Home go={go} setSubject={setSelectedSubject} />;
    }
  })();

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="icon-btn" aria-label="menu" onClick={() => setDrawer(true)}><Menu size={23}/></button>
        <button className="brand" onClick={() => go("home")}><span className="brand-mark">TGT</span><span>TGT Pathshala</span></button>
        <div className="top-actions">
          {searchOpen && <input autoFocus value={query} onChange={e => setQuery(e.target.value)} className="top-search" placeholder="Search notes..." />}
          <button className="icon-btn" onClick={() => setSearchOpen(v => !v)}><Search size={20}/></button>
          <button className="icon-btn" onClick={() => showToast("No new notifications")}><Bell size={20}/></button>
        </div>
      </header>
      <main className="main-content">{content}</main>
      <nav className="bottom-nav">
        <NavButton active={page === "home"} icon={HomeIcon} label="Home" onClick={() => go("home")} />
        <NavButton active={page === "courses" || page === "topic"} icon={BookOpen} label="Courses" onClick={() => go("courses")} />
        <NavButton active={page === "notes"} icon={FileText} label="PDF Notes" onClick={() => go("notes")} />
        <NavButton active={page === "tests" || page === "test"} icon={ClipboardList} label="Tests" onClick={() => go("tests")} />
        <NavButton active={page === "videos" || page === "video"} icon={Video} label="Videos" onClick={() => go("videos")} />
      </nav>
      {drawer && <Drawer close={() => setDrawer(false)} go={go} share={shareApp} />}
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

function Splash() {
  return <div className="splash"><div className="splash-logo"><GraduationCap size={55}/><b>TGT</b><span>PATHSHALA</span></div><h1>TGT Pathshala</h1><p>Your Success, Our Mission</p><div className="loader"/><small>Loading...</small></div>;
}

function NavButton({active, icon: Icon, label, onClick}:{active:boolean;icon:any;label:string;onClick:()=>void}) {
  return <button className={`nav-item ${active ? "active" : ""}`} onClick={onClick}><Icon size={20}/><span>{label}</span></button>;
}

function Home({go,setSubject}:{go:(p:Page)=>void;setSubject:(s:string)=>void}) {
  const openSubject = (s:string) => { setSubject(s); go("topic"); };
  return <div>
    <section className="hero-card"><div className="student-art"><GraduationCap size={72}/></div><div><h2>Welcome to<br/>TGT Pathshala</h2><p>Best Platform for<br/>TGT Exam Preparation</p></div></section>
    <div className="quick-grid">
      <Quick icon={BookOpen} label="Courses" tone="blue" onClick={() => go("courses")}/>
      <Quick icon={FileText} label="PDF Notes" tone="pink" onClick={() => go("notes")}/>
      <Quick icon={ClipboardList} label="Test Series" tone="green" onClick={() => go("tests")}/>
      <Quick icon={Video} label="Video Lectures" tone="purple" onClick={() => go("videos")}/>
      <Quick icon={WalletCards} label="Purchase Course" tone="orange" onClick={() => go("purchase")}/>
      <Quick icon={Bookmark} label="Bookmarks" tone="teal" onClick={() => go("bookmarks")}/>
    </div>
    <SectionTitle title="Popular Subjects" action="View All" onClick={() => go("courses")}/>
    <div className="subject-mini-grid">{subjects.slice(0,6).map(s => <button key={s.name} className="subject-mini" onClick={() => openSubject(s.name)}><span className={`subject-icon ${s.tone}`}><s.icon size={20}/></span><b>{s.name}</b><small>{s.topics} Topics</small></button>)}</div>
    <div className="update-card"><span className="new-badge">NEW</span><div><b>Latest Update</b><p>New History Notes Added</p></div><ChevronRight/></div>
  </div>;
}

function Quick({icon:Icon,label,tone,onClick}:{icon:any;label:string;tone:string;onClick:()=>void}) { return <button className="quick" onClick={onClick}><span className={`quick-icon ${tone}`}><Icon size={25}/></span><b>{label}</b></button>; }
function SectionTitle({title,action,onClick}:{title:string;action?:string;onClick?:()=>void}) { return <div className="section-title"><h3>{title}</h3>{action && <button onClick={onClick}>{action} <ChevronRight size={16}/></button>}</div>; }

function PageTitle({title,subtitle,go}:{title:string;subtitle?:string;go?:()=>void}) { return <div className="page-title">{go && <button className="back-btn" onClick={go}><ArrowLeft size={21}/></button>}<div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div></div>; }

function Courses({onSubject}:{onSubject:(s:string)=>void}) { return <div><PageTitle title="Courses" subtitle="All subjects / courses"/><div className="course-list">{subjects.map(s => <button className="course-card" key={s.name} onClick={() => onSubject(s.name)}><span className={`subject-icon big ${s.tone}`}><s.icon size={25}/></span><div><b>{s.name}</b><small>{s.topics} Topics</small></div><ChevronRight/></button>)}</div></div>; }

function TopicList({subject,go,setTitle}:{subject:string;go:(p:Page)=>void;setTitle:(s:string)=>void}) {
  const topicNames = Array.from({length:10}, (_,i) => `${subject} – Topic ${i+1}`);
  return <div><PageTitle title={subject} subtitle="Choose a topic" go={() => go("courses")}/><div className="topic-list">{topicNames.map((t,i)=><button key={t} className="topic-card" onClick={() => {setTitle(t);go("notes");}}><span>{i+1}</span><div><b>{t}</b><small>Study material, notes & practice</small></div><ChevronRight/></button>)}</div><div className="info-box">Tap any topic to open its study material. Real PDFs can be connected later.</div></div>;
}

function Notes({tab,setTab,query,bookmarks,toggleBookmark,download}:{tab:string;setTab:(s:string)=>void;query:string;bookmarks:string[];toggleBookmark:(s:string)=>void;download:(s:string)=>void}) {
  const tabs=["All","History","Geography","Polity","Economics","Education"];
  const filtered=notes.filter(n=>(tab==="All"||n[2]===tab)&&(!query||n[0].toLowerCase().includes(query.toLowerCase())));
  return <div><PageTitle title="PDF Notes" subtitle="Notes with download option"/><div className="tabs">{tabs.map(t=><button className={tab===t?"selected":""} key={t} onClick={()=>setTab(t)}>{t}</button>)}</div><div className="note-list">{filtered.map(([title,meta,cat])=><div className="note-card" key={title}><span className="pdf-icon">PDF</span><div><b>{title}</b><small>{meta} · {cat}</small></div><button onClick={()=>toggleBookmark(title)} title="bookmark"><Bookmark size={19} fill={bookmarks.includes(title)?"currentColor":"none"}/></button><button onClick={()=>download(title)} title="download"><Download size={19}/></button></div>)}</div>{filtered.length===0&&<Empty icon={FileText} text="No notes found"/>}</div>;
}

function Tests({go,setTitle}:{go:(p:Page)=>void;setTitle:(s:string)=>void}) { return <div><PageTitle title="Test Series" subtitle="Practice and improve your score"/><div className="stats"><Stat label="Total Test" value="50"/><Stat label="Attempted" value="12"/><Stat label="Score" value="82%"/></div><div className="test-list">{tests.map(([title,meta,Icon])=><button className="test-card" key={title} onClick={()=>{setTitle(title);go("test")}}><span className="test-icon"><Icon size={22}/></span><div><b>{title}</b><small>{meta}</small></div><ChevronRight/></button>)}</div></div>; }
function Stat({label,value}:{label:string;value:string}) { return <div className="stat"><small>{label}</small><b>{value}</b></div>; }

function TestPaper({title,go,showToast}:{title:string;go:(p:Page)=>void;showToast:(s:string)=>void}) { const [selected,setSelected]=useState<number|null>(null); const [submitted,setSubmitted]=useState(false); const options=["Akbar","Ashoka","Chandragupta Maurya","Harsha"]; return <div><PageTitle title={title} subtitle="Practice Test · 10 Questions" go={()=>go("tests")}/><div className="question-card"><span className="question-no">Question 1 of 10</span><h3>Who is known as the founder of the Maurya Empire?</h3>{options.map((o,i)=><button className={`option ${selected===i?"chosen":""}`} key={o} onClick={()=>setSelected(i)}><span>{String.fromCharCode(65+i)}</span>{o}</button>)}{submitted&&<div className="answer">Correct answer: Chandragupta Maurya</div>}<button className="primary-btn" disabled={selected===null} onClick={()=>{setSubmitted(true);showToast("Answer submitted")}}>Submit Answer</button></div></div>; }

function Videos({tab,setTab,go,setTitle}:{tab:string;setTab:(s:string)=>void;go:(p:Page)=>void;setTitle:(s:string)=>void}) { const tabs=["All","History","Geography","Polity","Economics"]; const filtered=videos.filter(v=>tab==="All"||v[2]===tab); return <div><PageTitle title="Video Lectures" subtitle="Video lectures by topics"/><div className="tabs">{tabs.map(t=><button className={tab===t?"selected":""} key={t} onClick={()=>setTab(t)}>{t}</button>)}</div><div className="video-list">{filtered.map(([title,time,cat],i)=><button className="video-card" key={title} onClick={()=>{setTitle(title);go("video")}}><div className="thumb"><Play fill="white" size={27}/><span>{time}</span></div><div><b>{title}</b><small>by Saroj Sir · {cat}</small></div><ChevronRight/></button>)}</div></div>; }
function VideoPlayer({title,go}:{title:string;go:(p:Page)=>void}) { return <div><PageTitle title="Video Lecture" subtitle={title} go={()=>go("videos")}/><div className="player"><Play size={55} fill="white"/><span>Video Preview</span></div><div className="content-card"><h3>{title}</h3><p>This is the lecture screen. Connect your own MP4 file or YouTube video here when you add the real course content.</p><button className="primary-btn" onClick={()=>alert("Video URL can be connected in the project code.")}>Open Video</button></div></div>; }

function About() { return <div><PageTitle title="About Us" subtitle="About TGT Pathshala"/><div className="about-card"><div className="about-logo"><GraduationCap size={44}/><b>TGT</b><span>PATHSHALA</span></div><h2>TGT Pathshala</h2><p>Your Success, Our Mission</p><p>TGT Pathshala is a complete platform for TGT exam preparation. Add quality content, PDF notes, test series and video lectures for students.</p><ul><li><ShieldCheck/> Quality Content</li><li><Clock3/> Regular Updates</li><li><UserRound/> Expert Guidance</li><li><CheckCircle2/> Student Friendly</li></ul></div></div>; }

function Bookmarks({items,go}:{items:string[];go:(p:Page)=>void}) { return <div><PageTitle title="Bookmarks" subtitle="Your saved study material" go={()=>go("home")}/>{items.length ? <div className="note-list">{items.map(x=><div className="note-card" key={x}><span className="pdf-icon"><Bookmark size={20}/></span><div><b>{x}</b><small>Saved bookmark</small></div><ChevronRight/></div>)}</div>:<Empty icon={Bookmark} text="No bookmarks yet"/>}</div>; }
function Downloads({items}:{items:string[]}) { return <div><PageTitle title="Downloads" subtitle="Saved files"/>{items.length ? <div className="note-list">{items.map(x=><div className="note-card" key={x}><span className="pdf-icon"><Download size={20}/></span><div><b>{x}</b><small>Available offline</small></div></div>)}</div>:<Empty icon={Download} text="No downloads yet"/>}</div>; }
function Purchase({showToast}:{showToast:(s:string)=>void}) { return <div><PageTitle title="Purchase Course" subtitle="Premium preparation"/><div className="premium-card"><Trophy size={42}/><h2>TGT Complete Course</h2><p>All subjects · Notes · Tests · Video Lectures</p><div className="price">₹999 <small>one time</small></div><button className="primary-btn" onClick={()=>showToast("Payment gateway can be connected here")}>Purchase Now</button></div><div className="content-card"><b>Included</b><p>Complete syllabus, chapter-wise material, practice tests and video lectures. This demo is ready for connecting your payment system.</p></div></div>; }
function Privacy() { return <div><PageTitle title="Privacy Policy"/><div className="content-card"><h3>Privacy Policy</h3><p>TGT Pathshala should clearly explain what student data is collected, why it is used, and how it is protected. Replace this demo text with your final policy before publishing.</p><p>No personal information is required to browse the demo content.</p></div></div>; }
function SettingsPage({showToast}:{showToast:(s:string)=>void}) { const [notif,setNotif]=useState(true); return <div><PageTitle title="Settings"/><div className="settings-list"><button onClick={()=>{setNotif(!notif);showToast(`Notifications ${!notif?"enabled":"disabled"}`)}}><Bell/> Notifications <span className={`switch ${notif?"on":""}`}/></button><button onClick={()=>showToast("Language: English") }><Languages/> Language <ChevronRight/></button><button onClick={()=>showToast("Theme: Light") }><Settings/> Theme <span>Light</span></button><button onClick={()=>showToast("Account settings opened") }><UserRound/> Account <ChevronRight/></button></div></div>; }

function Drawer({close,go,share}:{close:()=>void;go:(p:Page)=>void;share:()=>void}) { const items:[[Page,string,any]] = [["home","Home",HomeIcon],["courses","Courses",BookOpen],["notes","PDF Notes",FileText],["tests","Test Series",ClipboardList],["videos","Video Lectures",Video],["bookmarks","Bookmarks",Bookmark],["downloads","Downloads",Download],["purchase","Purchase Course",WalletCards],["about","About Us",Info],["settings","Settings",Settings],["privacy","Privacy Policy",LockKeyhole]]; return <><div className="drawer-backdrop" onClick={close}/><aside className="drawer"><div className="drawer-head"><button className="icon-btn light" onClick={close}><X/></button><div className="drawer-brand"><span className="brand-mark">TGT</span><div><b>TGT Pathshala</b><small>Your Success, Our Mission</small></div></div></div><div className="drawer-menu">{items.map(([p,label,Icon])=><button key={p} onClick={()=>go(p)}><Icon size={18}/>{label}</button>)}<button onClick={share}><Share2 size={18}/>Share App</button><button onClick={()=>close()}><LogOut size={18}/>Exit</button></div></aside></>; }
function Empty({icon:Icon,text}:{icon:any;text:string}) { return <div className="empty"><Icon size={42}/><b>{text}</b><small>Open another section to explore content.</small></div>; }

export default App;
