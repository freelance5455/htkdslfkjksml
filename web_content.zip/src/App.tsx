import React, { useState } from "react";
import { Header } from "./components/Header";
import { HomeScreen } from "./components/HomeScreen";
import { CalculatorScreen } from "./components/CalculatorScreen";
import { ResultScreen } from "./components/ResultScreen";
import { AiAssistant } from "./components/AiAssistant";
import { RateManagerModal } from "./components/RateManagerModal";
import { ContactModal } from "./components/ContactModal";
import { PWAInstallModal } from "./components/PWAInstallModal";
import { OfflineIndicator } from "./components/OfflineIndicator";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { usePWAInstall } from "./hooks/usePWAInstall";
import { CATEGORIES, INITIAL_RATES, INITIAL_LABOUR_RATES, DEFAULT_CONTACT } from "./data/categories";
import { CalculationResult, ContactInfo } from "./types";
import {
  Home,
  Calculator,
  Sparkles,
  PhoneCall,
  Settings,
  Download,
} from "lucide-react";

type ViewState = "home" | "calculator" | "result";

export default function App() {
  // Rates initialized synchronously to ensure ZERO startup delays
  const [rates, setRates] = useState<Record<string, number | null>>(() => {
    try {
      const saved = localStorage.getItem("ceiling_calc_rates");
      if (saved) {
        return { ...INITIAL_RATES, ...JSON.parse(saved) };
      }
    } catch {}
    return INITIAL_RATES;
  });

  const [labourRates, setLabourRates] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem("ceiling_calc_labour_rates");
      if (saved) {
        return { ...INITIAL_LABOUR_RATES, ...JSON.parse(saved) };
      }
    } catch {}
    return INITIAL_LABOUR_RATES;
  });

  // Contact info
  const [contact, setContact] = useState<ContactInfo>(() => {
    try {
      const saved = localStorage.getItem("ceiling_calc_contact");
      if (saved) {
        return { ...DEFAULT_CONTACT, ...JSON.parse(saved) };
      }
    } catch {}
    return DEFAULT_CONTACT;
  });

  const [view, setView] = useState<ViewState>("home");
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("gypsum_ceiling");
  const [currentResult, setCurrentResult] = useState<CalculationResult | null>(null);

  // Modals
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isRatesOpen, setIsRatesOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);

  // PWA installation hook
  const {
    isInstallable,
    isInstalled,
    isAndroid,
    isIOS,
    isInIframe,
    isSecure,
    diagnosticReason,
    isInstallModalOpen,
    setIsInstallModalOpen,
    triggerInstall,
    openDirectBrowserTab,
  } = usePWAInstall();

  // Save rates to localStorage
  const handleSaveRates = (
    newRates: Record<string, number | null>,
    newLabourRates?: Record<string, number>
  ) => {
    setRates(newRates);
    try {
      localStorage.setItem("ceiling_calc_rates", JSON.stringify(newRates));
    } catch {}

    if (newLabourRates) {
      setLabourRates(newLabourRates);
      try {
        localStorage.setItem("ceiling_calc_labour_rates", JSON.stringify(newLabourRates));
      } catch {}
    }
  };

  const handleResetRatesDefaults = () => {
    setRates(INITIAL_RATES);
    setLabourRates(INITIAL_LABOUR_RATES);
    try {
      localStorage.removeItem("ceiling_calc_rates");
      localStorage.removeItem("ceiling_calc_labour_rates");
    } catch {}
  };

  const handleSaveContact = (newContact: ContactInfo) => {
    setContact(newContact);
    try {
      localStorage.setItem("ceiling_calc_contact", JSON.stringify(newContact));
    } catch {}
  };

  // User selects category from Home
  const handleSelectCategory = (catId: string) => {
    setSelectedCategoryId(catId);
    setView("calculator");
  };

  // Calculation complete -> Show Result Screen
  const handleCalculateComplete = (result: CalculationResult) => {
    setCurrentResult(result);
    setView("result");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // New calculation button
  const handleNewCalculation = () => {
    setView("calculator");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Reset all and go back to home
  const handleResetAll = () => {
    setCurrentResult(null);
    setSelectedCategoryId("gypsum_ceiling");
    setView("home");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans antialiased selection:bg-indigo-200 selection:text-indigo-900">
      {/* Top Navigation Header */}
      <Header
        onOpenRates={() => setIsRatesOpen(true)}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenAi={() => setIsAiOpen(true)}
        onGoHome={() => setView("home")}
        onInstallApp={triggerInstall}
        isInstalled={isInstalled}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 sm:p-6 pb-24 sm:pb-12">
        {view === "home" && (
          <HomeScreen
            categories={CATEGORIES}
            rates={rates}
            onSelectCategory={handleSelectCategory}
            onStartCalculation={() => {
              setSelectedCategoryId("gypsum_ceiling");
              setView("calculator");
            }}
            onOpenAi={() => setIsAiOpen(true)}
            onOpenRates={() => setIsRatesOpen(true)}
            onInstallApp={triggerInstall}
            isInstalled={isInstalled}
          />
        )}

        {view === "calculator" && (
          <CalculatorScreen
            categories={CATEGORIES}
            rates={rates}
            selectedCategoryId={selectedCategoryId}
            onBack={() => setView("home")}
            onCalculateComplete={handleCalculateComplete}
            onOpenRates={() => setIsRatesOpen(true)}
          />
        )}

        {view === "result" && currentResult && (
          <ResultScreen
            result={currentResult}
            contact={contact}
            onNewCalculation={handleNewCalculation}
            onReset={handleResetAll}
            onOpenAi={() => setIsAiOpen(true)}
            onBack={() => setView("calculator")}
            onInstallApp={triggerInstall}
            isInstalled={isInstalled}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-white/95 backdrop-blur-md border-t border-slate-200 py-2 px-3 sm:hidden shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {/* Home */}
          <button
            onClick={() => setView("home")}
            className={`flex flex-col items-center justify-center p-1.5 rounded-xl transition-all ${
              view === "home"
                ? "text-indigo-600 font-bold"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 font-medium">Home</span>
          </button>

          {/* Calculator */}
          <button
            onClick={() => setView("calculator")}
            className={`flex flex-col items-center justify-center p-1.5 rounded-xl transition-all ${
              view === "calculator" || view === "result"
                ? "text-indigo-600 font-bold"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Calculator className="w-5 h-5 stroke-[2.2]" />
            <span className="text-[10px] mt-0.5 font-medium">Calculate</span>
          </button>

          {/* AI Voice Assistant */}
          <button
            onClick={() => setIsAiOpen(true)}
            className="flex flex-col items-center justify-center p-2 bg-indigo-600 text-white rounded-2xl font-bold shadow-md shadow-indigo-600/30 active:scale-95 transition-transform"
          >
            <Sparkles className="w-4 h-4 fill-white" />
            <span className="text-[10px] mt-0.5">Smart AI</span>
          </button>

          {/* Install App button if not installed */}
          {!isInstalled && (
            <button
              onClick={triggerInstall}
              className="flex flex-col items-center justify-center p-1.5 text-amber-600 font-bold hover:text-amber-700 rounded-xl transition-all"
            >
              <Download className="w-5 h-5 stroke-[2.5]" />
              <span className="text-[10px] mt-0.5 font-bold">Install</span>
            </button>
          )}

          {/* Rates */}
          <button
            onClick={() => setIsRatesOpen(true)}
            className="flex flex-col items-center justify-center p-1.5 text-slate-500 hover:text-slate-800 rounded-xl transition-all"
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 font-medium">Rates</span>
          </button>

          {/* Contact */}
          <button
            onClick={() => setIsContactOpen(true)}
            className="flex flex-col items-center justify-center p-1.5 text-slate-500 hover:text-slate-800 rounded-xl transition-all"
          >
            <PhoneCall className="w-5 h-5 text-emerald-600" />
            <span className="text-[10px] mt-0.5 font-medium">Contact</span>
          </button>
        </div>
      </nav>

      {/* AI Assistant Modal */}
      <ErrorBoundary fallbackTitle="AI Assistant">
        <AiAssistant
          rates={rates}
          categories={CATEGORIES}
          isOpen={isAiOpen}
          onClose={() => setIsAiOpen(false)}
        />
      </ErrorBoundary>

      {/* Rate Manager Modal */}
      <ErrorBoundary fallbackTitle="Rate Settings">
        <RateManagerModal
          categories={CATEGORIES}
          rates={rates}
          labourRates={labourRates}
          isOpen={isRatesOpen}
          onClose={() => setIsRatesOpen(false)}
          onSaveRates={handleSaveRates}
          onResetDefaults={handleResetRatesDefaults}
        />
      </ErrorBoundary>

      {/* Contact Info Modal */}
      <ErrorBoundary fallbackTitle="Contact Details">
        <ContactModal
          contact={contact}
          isOpen={isContactOpen}
          onClose={() => setIsContactOpen(false)}
          onSaveContact={handleSaveContact}
        />
      </ErrorBoundary>

      {/* PWA Install Modal Guide */}
      <ErrorBoundary fallbackTitle="App Installer">
        <PWAInstallModal
          isOpen={isInstallModalOpen}
          onClose={() => setIsInstallModalOpen(false)}
          isInstallable={isInstallable}
          onAutoInstall={triggerInstall}
          isIOS={isIOS}
          isAndroid={isAndroid}
          isInIframe={isInIframe}
          isSecure={isSecure}
          diagnosticReason={diagnosticReason}
          onOpenDirectTab={openDirectBrowserTab}
        />
      </ErrorBoundary>

      {/* Offline Status Floating Indicator */}
      <OfflineIndicator />
    </div>
  );
}
