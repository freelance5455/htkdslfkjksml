import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { SideDrawer } from './components/SideDrawer';
import { SearchModal } from './components/SearchModal';
import { HomeView } from './components/HomeView';
import { CategoryBrowseView } from './components/CategoryBrowseView';
import { CartView } from './components/CartView';
import { MyBooksView } from './components/MyBooksView';
import { UserProfileModal } from './components/UserProfileModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { ExamUpdatesView } from './components/ExamUpdatesView';
import { CurrentAffairsView } from './components/CurrentAffairsView';
import { EbookDetailsModal } from './components/EbookDetailsModal';
import { InteractiveReaderModal } from './components/InteractiveReaderModal';
import { CheckoutModal } from './components/CheckoutModal';
import { AuthModal } from './components/AuthModal';
import { MockTestModal } from './components/MockTestModal';
import { Footer } from './components/Footer';
import { CheckCircle2, AlertCircle, Info, Sparkles } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeTab, toastMessage } = useApp();
  const [searchModalOpen, setSearchModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      {/* Toast Notification Bar */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 max-w-sm bg-[#0B192C] text-white p-3.5 rounded-2xl shadow-2xl border border-[#1E3E62] flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          {toastMessage.type === 'success' && (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          )}
          {toastMessage.type === 'error' && (
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
          )}
          {toastMessage.type === 'info' && (
            <Info className="w-5 h-5 text-amber-400 shrink-0" />
          )}
          <p className="text-xs font-semibold leading-snug">{toastMessage.text}</p>
        </div>
      )}

      {/* Header */}
      <Header onOpenSearch={() => setSearchModalOpen(true)} />

      {/* Main Active Page View */}
      <main className="flex-1">
        {activeTab === 'home' && <HomeView onOpenSearch={() => setSearchModalOpen(true)} />}
        {activeTab === 'categories' && <CategoryBrowseView />}
        {activeTab === 'free-pdfs' && <CategoryBrowseView />}
        {activeTab === 'my-books' && <MyBooksView />}
        {activeTab === 'cart' && <CartView />}
        {activeTab === 'profile' && <UserProfileModal />}
        {activeTab === 'admin' && <AdminPanelModal />}
        {activeTab === 'exam-updates' && <ExamUpdatesView />}
        {activeTab === 'current-affairs' && <CurrentAffairsView />}
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />

      {/* Overlays and Modals */}
      <SideDrawer />
      <SearchModal isOpen={searchModalOpen} onClose={() => setSearchModalOpen(false)} />
      <EbookDetailsModal />
      <InteractiveReaderModal />
      <CheckoutModal />
      <AuthModal />
      <MockTestModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
