import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ModePills, AppMode } from './components/ModePills';
import { CalculatorView } from './components/CalculatorView';
import { AiSolverView } from './components/AiSolverView';
import { FinanceSuiteView } from './components/FinanceSuiteView';
import { FormulaMasterView } from './components/FormulaMasterView';
import { UnitConverterView } from './components/UnitConverterView';
import { HistoryDrawer } from './components/HistoryDrawer';
import { Toast, ToastMessage } from './components/Toast';
import { audioService } from './services/audioService';
import { historyStorage } from './services/historyStorage';
import { Wifi, Signal, Battery, Smartphone } from 'lucide-react';

export default function App() {
  const [currentMode, setCurrentMode] = useState<AppMode>('calc');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [historyOpen, setHistoryOpen] = useState<boolean>(false);
  const [historyCount, setHistoryCount] = useState<number>(0);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [phoneFrameMode, setPhoneFrameMode] = useState<boolean>(false);
  const [calculatorInput, setCalculatorInput] = useState<string | null>(null);
  const [currentTimeStr, setCurrentTimeStr] = useState<string>('12:00');

  // Clock for Android status bar
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  // Update history count
  const updateHistoryCount = () => {
    setHistoryCount(historyStorage.getAll().length);
  };

  useEffect(() => {
    updateHistoryCount();
  }, []);

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    audioService.setSoundEnabled(next);
    showToast(next ? 'Sound Enabled' : 'Sound Muted', 'info');
  };

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({
      id: Date.now().toString(),
      text,
      type,
    });
  };

  const handleSendToCalculator = (val: string) => {
    setCalculatorInput(val);
    setCurrentMode('calc');
  };

  return (
    <div className="min-h-screen bg-[#050508] text-amber-50 flex items-center justify-center p-0 sm:p-4 selection:bg-amber-500 selection:text-black">
      {/* Toast Notification */}
      <Toast toast={toast} onClose={() => setToast(null)} />

      {/* Main Container or Android Smartphone Frame */}
      <div
        className={`w-full transition-all duration-300 relative flex flex-col overflow-hidden ${
          phoneFrameMode
            ? 'max-w-[420px] h-[92vh] max-h-[890px] rounded-[48px] border-[8px] border-[#1f2333] shadow-[0_0_60px_rgba(245,158,11,0.15),0_25px_50px_rgba(0,0,0,0.9)] ring-1 ring-amber-500/30'
            : 'max-w-md min-h-screen sm:min-h-[820px] sm:max-h-[880px] sm:rounded-3xl sm:border sm:border-amber-500/25 sm:shadow-[0_0_50px_rgba(0,0,0,0.9)]'
        } bg-[#080a11]`}
      >
        {/* Android Punch-Hole Camera & Status Bar (in Phone Frame Mode or on mobile) */}
        {phoneFrameMode && (
          <div className="relative pt-2 px-6 flex items-center justify-between text-[11px] font-mono text-zinc-400 select-none bg-[#0a0c13] border-b border-zinc-900/60 z-30">
            <span>{currentTimeStr}</span>
            {/* Front Camera Punch-Hole */}
            <div className="w-3.5 h-3.5 rounded-full bg-black border border-zinc-800 shadow-inner flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-zinc-900" />
            </div>
            <div className="flex items-center gap-1.5 text-zinc-400">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <Battery className="w-3.5 h-3.5 text-amber-400" />
            </div>
          </div>
        )}

        {/* Master Header */}
        <Header
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          onOpenHistory={() => setHistoryOpen(true)}
          historyCount={historyCount}
          phoneFrameMode={phoneFrameMode}
          onTogglePhoneFrame={() => setPhoneFrameMode(!phoneFrameMode)}
        />

        {/* Mode Navigation Pills */}
        <ModePills currentMode={currentMode} onChangeMode={setCurrentMode} />

        {/* Dynamic View Body */}
        <main className="flex-1 overflow-hidden flex flex-col relative bg-radial from-[#121524]/40 via-[#090b12] to-[#06070a]">
          {currentMode === 'calc' && (
            <CalculatorView
              onShowToast={showToast}
              externalInput={calculatorInput}
              onClearExternalInput={() => setCalculatorInput(null)}
            />
          )}

          {currentMode === 'ai' && (
            <AiSolverView
              onShowToast={showToast}
              onSendToCalculator={handleSendToCalculator}
            />
          )}

          {currentMode === 'finance' && (
            <FinanceSuiteView
              onShowToast={showToast}
              onSendToCalculator={handleSendToCalculator}
            />
          )}

          {currentMode === 'formula' && (
            <FormulaMasterView
              onShowToast={showToast}
              onSendToCalculator={handleSendToCalculator}
            />
          )}

          {currentMode === 'units' && (
            <UnitConverterView
              onShowToast={showToast}
              onSendToCalculator={handleSendToCalculator}
            />
          )}
        </main>

        {/* Android Home Navigation Bar Pill (Phone Mode) */}
        {phoneFrameMode && (
          <div className="py-2 flex items-center justify-center bg-[#07080d] border-t border-zinc-900/60 select-none">
            <div className="w-32 h-1 bg-zinc-600 rounded-full" />
          </div>
        )}
      </div>

      {/* History Drawer */}
      <HistoryDrawer
        isOpen={historyOpen}
        onClose={() => setHistoryOpen(false)}
        onRecallExpression={(expr) => {
          handleSendToCalculator(expr);
        }}
        onShowToast={showToast}
        onHistoryUpdated={updateHistoryCount}
      />
    </div>
  );
}
