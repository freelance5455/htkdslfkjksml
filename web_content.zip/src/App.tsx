import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'motion/react';
import { ChevronUp, ChevronDown, Plus, Menu } from 'lucide-react';
import {
  CalendarViewMode,
  CalendarDay,
  HebrewEvent,
  UserSettings,
  SyncState,
  LocationPreset,
  ZmanItem,
} from './types';
import {
  DEFAULT_SETTINGS,
  DEFAULT_SAMPLE_EVENTS,
  LOCATION_PRESETS,
  getCalendarMonthDays,
  getCalendarWeekDays,
  getCalendarDay,
  calculateZmanim,
  getNextHebrewHolidayCountdown,
  UpcomingHolidayCountdown,
} from './services/hebrewCalendarService';
import {
  loadLocalEvents,
  saveLocalEvents,
  loadLocalSettings,
  saveLocalSettings,
} from './services/syncService';
import { scheduleNotificationChecks } from './services/notificationService';

// UI Components
import { Header } from './components/Header';
import { CalendarMonthView } from './components/CalendarMonthView';
import { CalendarWeekView } from './components/CalendarWeekView';
import { CalendarDayView } from './components/CalendarDayView';
import { CalendarAgendaView } from './components/CalendarAgendaView';
import { EventModal } from './components/EventModal';
import { EventsManagerModal } from './components/EventsManagerModal';
import { HomeScreenWidget, FloatingQuickWidget } from './components/HomeScreenWidget';
import { HolidayAlertsModal } from './components/HolidayAlertsModal';
import { MultiDeviceSyncModal } from './components/MultiDeviceSyncModal';
import { DateConverterModal } from './components/DateConverterModal';
import { ZmanimModal } from './components/ZmanimModal';
import { ManualLocationModal } from './components/ManualLocationModal';
import { SettingsModal } from './components/SettingsModal';
import { DailyVerseCard } from './components/DailyVerseCard';
import { StandaloneWidgetView } from './components/StandaloneWidgetView';
import { getTranslations } from './services/i18n';

export const App: React.FC = () => {
  // Settings & Dark Mode
  const [settings, setSettings] = useState<UserSettings>(() => loadLocalSettings());
  const [events, setEvents] = useState<HebrewEvent[]>(() => loadLocalEvents());

  const t = getTranslations(settings.language || 'en');
  const isRtl = (settings.language || 'en') === 'he';

  // Navigation & View Mode
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<CalendarViewMode>('month');
  const [isStandaloneWidgetMode, setIsStandaloneWidgetMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const params = new URLSearchParams(window.location.search);
    return params.get('mode') === 'widget' || params.get('widget') === 'true';
  });

  // Selected Day for Detail drawer or Day View
  const [selectedDayDate, setSelectedDayDate] = useState<Date>(new Date());

  // Multi-Device Sync State
  const [syncState, setSyncState] = useState<SyncState>({
    roomId: null,
    roomPin: null,
    status: 'idle',
    lastSyncedAt: null,
    deviceName:
      typeof navigator !== 'undefined' && navigator.userAgent.includes('Mobile')
        ? 'Mobile Device'
        : 'Desktop Browser',
    isConnected: false,
  });

  // Modal Visibility States
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<HebrewEvent | null>(null);
  const [eventModalDefaultDay, setEventModalDefaultDay] = useState<CalendarDay | undefined>(undefined);

  const [isEventsManagerOpen, setIsEventsManagerOpen] = useState(false);
  const [isWidgetModalOpen, setIsWidgetModalOpen] = useState(false);
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isConverterModalOpen, setIsConverterModalOpen] = useState(false);
  const [isZmanimModalOpen, setIsZmanimModalOpen] = useState(false);
  const [isManualLocationModalOpen, setIsManualLocationModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [showFooterDropdown, setShowFooterDropdown] = useState(false);

  // Floating Home Screen Quick Widget state
  const [floatingWidgetPinned, setFloatingWidgetPinned] = useState<boolean>(() => {
    const stored = localStorage.getItem('hebrew_cal_floating_widget');
    return stored ? JSON.parse(stored) : false;
  });

  // Minimize Next Zman & Next Holiday controller states
  const [isNextZmanMinimized, setIsNextZmanMinimized] = useState<boolean>(() => {
    return localStorage.getItem('hebrew_cal_minimize_next_zman') === 'true';
  });

  const [isNextHolidayMinimized, setIsNextHolidayMinimized] = useState<boolean>(() => {
    return localStorage.getItem('hebrew_cal_minimize_next_holiday') === 'true';
  });

  const handleToggleMinimizeNextZman = useCallback(() => {
    setIsNextZmanMinimized((prev) => {
      const nextVal = !prev;
      localStorage.setItem('hebrew_cal_minimize_next_zman', String(nextVal));
      return nextVal;
    });
  }, []);

  const handleToggleMinimizeNextHoliday = useCallback(() => {
    setIsNextHolidayMinimized((prev) => {
      const nextVal = !prev;
      localStorage.setItem('hebrew_cal_minimize_next_holiday', String(nextVal));
      return nextVal;
    });
  }, []);

  // Save settings & synchronize RTL/LTR direction & dark mode
  useEffect(() => {
    saveLocalSettings(settings);

    // Sync RTL/LTR and language attributes on HTML root
    const lang = settings.language || 'en';
    document.documentElement.dir = lang === 'he' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;

    // Dark mode toggle on root HTML and body
    if (settings.darkMode !== false) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      document.body.classList.add('dark');
      document.body.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
      document.body.classList.remove('dark');
      document.body.classList.add('light');
    }
  }, [settings]);

  // Save events effect
  useEffect(() => {
    saveLocalEvents(events);
  }, [events]);

  // Save pinned widget state
  useEffect(() => {
    localStorage.setItem('hebrew_cal_floating_widget', JSON.stringify(floatingWidgetPinned));
  }, [floatingWidgetPinned]);

  // Active Location Preset
  const currentLocation = useMemo<LocationPreset>(() => {
    return (
      LOCATION_PRESETS.find((l) => l.id === settings.location.id) || settings.location || LOCATION_PRESETS[0]
    );
  }, [settings.location]);

  // Computed Today & Selected Day
  const todayDay = useMemo<CalendarDay>(() => {
    return getCalendarDay(new Date(), currentLocation, events);
  }, [currentLocation, events]);

  const selectedDay = useMemo<CalendarDay>(() => {
    return getCalendarDay(selectedDayDate, currentLocation, events);
  }, [selectedDayDate, currentLocation, events]);

  // Month & Week View Computed Days
  const monthDays = useMemo<CalendarDay[]>(() => {
    return getCalendarMonthDays(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      currentLocation,
      events
    );
  }, [currentDate, currentLocation, events]);

  const weekDays = useMemo<CalendarDay[]>(() => {
    return getCalendarWeekDays(currentDate, currentLocation, events);
  }, [currentDate, currentLocation, events]);

  // Clock state to refresh Zmanim and countdowns every minute
  const [nowState, setNowState] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setNowState(new Date());
    }, 60000); // 1 minute
    return () => clearInterval(timer);
  }, []);

  // Next Zman calculation for today (updates dynamically every minute)
  const nextZman = useMemo<ZmanItem | null>(() => {
    const zmanim = calculateZmanim(nowState, currentLocation);
    return zmanim.nextZman;
  }, [currentLocation, nowState]);

  // Next major Hebrew holiday countdown
  const nextHoliday = useMemo<UpcomingHolidayCountdown | null>(() => {
    return getNextHebrewHolidayCountdown(nowState, currentLocation.isIsrael);
  }, [nowState, currentLocation]);

  // Setup Notification Engine (checks every minute)
  useEffect(() => {
    const cleanup = scheduleNotificationChecks(events, currentLocation, settings);
    return () => cleanup();
  }, [events, currentLocation, settings]);

  // Handle URL shortcut parameters for PWA widgets & shortcuts
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const view = params.get('view');
    const mode = params.get('mode');
    const widget = params.get('widget');

    if (mode === 'widget' || widget === 'true') {
      setIsStandaloneWidgetMode(true);
    } else if (view === 'zmanim') {
      setIsZmanimModalOpen(true);
    } else if (view === 'holiday' || view === 'alerts') {
      setIsAlertsModalOpen(true);
    } else if (view === 'converter') {
      setIsConverterModalOpen(true);
    } else if (view === 'events') {
      setIsEventsManagerOpen(true);
    } else if (view === 'widget-guide') {
      setIsWidgetModalOpen(true);
    }
  }, []);

  // Handler for Updating Settings
  const handleUpdateSettings = useCallback((newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({
      ...prev,
      ...newSettings,
    }));
  }, []);

  // Event Handlers
  const handleOpenAddEvent = (defaultDay?: CalendarDay) => {
    setEditingEvent(null);
    setEventModalDefaultDay(defaultDay || selectedDay);
    setIsEventModalOpen(true);
  };

  const handleOpenEditEvent = (ev: HebrewEvent) => {
    setEditingEvent(ev);
    setIsEventModalOpen(true);
  };

  const handleSaveEvent = (savedEvent: HebrewEvent) => {
    setEvents((prev) => {
      const idx = prev.findIndex((e) => e.id === savedEvent.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = savedEvent;
        return next;
      } else {
        return [savedEvent, ...prev];
      }
    });
  };

  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
  };

  const handleImportEvents = (imported: HebrewEvent[]) => {
    setEvents((prev) => {
      const existingIds = new Set(prev.map((e) => e.id));
      const newItems = imported.filter((item) => !existingIds.has(item.id));
      return [...newItems, ...prev];
    });
  };

  // Day Selection
  const handleSelectDay = (day: CalendarDay) => {
    setSelectedDayDate(day.gregorianDate);
    setCurrentDate(day.gregorianDate);
  };

  const handleSelectDate = (date: Date) => {
    setSelectedDayDate(date);
    setCurrentDate(date);
  };

  // If in standalone widget mode, display focused widget view
  if (isStandaloneWidgetMode) {
    return (
      <StandaloneWidgetView
        todayDay={todayDay}
        location={currentLocation}
        nextZman={nextZman}
        nextHoliday={nextHoliday}
        settings={settings}
        onOpenFullApp={() => setIsStandaloneWidgetMode(false)}
      />
    );
  }

  return (
    <div
      id="hebrew-calendar-app"
      className="min-h-screen bg-[#0F0F0F] text-[#D1D1D1] transition-colors duration-200 flex flex-col font-sans selection:bg-[#C5A267] selection:text-[#0F0F0F]"
    >
      {/* Primary Navigation & Control Header */}
      <Header
        currentDate={currentDate}
        onDateChange={setCurrentDate}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        eventsCount={events.length}
        todayDay={todayDay}
        nextZman={nextZman}
        onOpenEventsModal={() => setIsEventsManagerOpen(true)}
        onOpenWidgetModal={() => setIsWidgetModalOpen(true)}
        onOpenAlertsModal={() => setIsAlertsModalOpen(true)}
        onOpenSyncModal={() => setIsSyncModalOpen(true)}
        onOpenConverterModal={() => setIsConverterModalOpen(true)}
        onOpenZmanimModal={() => setIsZmanimModalOpen(true)}
        onOpenManualLocationModal={() => setIsManualLocationModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
      />

      {/* Main App Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 lg:p-6">
        {/* Combined Next Holiday (Top) & Next Zman (Bottom) Overview Widget */}
        {(nextHoliday || nextZman) && (
          <div className="mb-5 p-3.5 sm:p-4 rounded-xl bg-gradient-to-r from-[#1E1912] via-[#161616] to-[#121212] border border-[#C5A267]/30 shadow-lg flex flex-col gap-3 animate-in fade-in slide-in-from-top-3 duration-200">
            {/* Line 1: Next Holiday (On Top) */}
            {nextHoliday && (
              <>
                {!isNextHolidayMinimized ? (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 group transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-[#C5A267]/15 border border-[#C5A267]/30 flex items-center justify-center text-lg shrink-0">
                        🍯
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-[#C5A267] uppercase tracking-[0.15em] block">
                          {settings.language === 'he' ? 'החג הבא' : 'UPCOMING HEBREW HOLIDAY'}
                        </span>
                        <span className="text-sm font-semibold text-white flex items-center gap-2">
                          <span className="font-serif-hebrew text-base text-[#E5C287] font-bold" dir="rtl">
                            {nextHoliday.nameHe}
                          </span>
                          {/* In Hebrew mode: NO English translation */}
                          {settings.language !== 'he' && (
                            <>
                              <span className="text-[#888888] font-light">•</span>
                              <span className="text-[#D1D1D1]">{nextHoliday.name}</span>
                            </>
                          )}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 self-end sm:self-auto">
                      <div className="text-right">
                        <span className="text-[11px] text-[#888888] block">
                          {settings.language === 'he' ? 'תאריך לועזי' : 'Gregorian Date'}
                        </span>
                        <span className="text-xs font-medium text-[#D1D1D1]">
                          {nextHoliday.gregorianDate.toLocaleDateString(settings.language === 'he' ? 'he-IL' : 'en-US', {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                      </div>
                      <div className="px-3 py-1.5 bg-[#C5A267] text-[#0F0F0F] rounded-lg font-bold shadow-md flex items-center gap-1.5 min-w-[70px] justify-center">
                        <span className="text-base font-mono font-black">{nextHoliday.daysRemaining}</span>
                        <span className="text-[10px] uppercase font-semibold">
                          {nextHoliday.daysRemaining === 1 
                            ? (settings.language === 'he' ? 'יום' : 'day') 
                            : (settings.language === 'he' ? 'ימים' : 'days')}
                        </span>
                      </div>
                      {/* Minimize Button directly on the Holiday Row */}
                      <button
                        id="widget-minimize-next-holiday-btn"
                        onClick={handleToggleMinimizeNextHoliday}
                        className="p-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-[#888888] hover:text-[#C5A267] transition-colors"
                        title={settings.language === 'he' ? 'מזער את שורת החג הבא' : 'Minimize Next Holiday line'}
                      >
                        <ChevronUp className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between py-0.5 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-base">🍯</span>
                      <span className="text-[11px] text-[#888888]">
                        {settings.language === 'he' ? 'החג הבא (ממוזער):' : 'Next Holiday (Minimized):'}{' '}
                        <strong className="text-[#E5C287] font-serif-hebrew font-bold mr-1">
                          {nextHoliday.nameHe}
                        </strong>
                        <span className="text-[#D1D1D1]">
                          ({settings.language === 'he' 
                            ? `בעוד ${nextHoliday.daysRemaining} ${nextHoliday.daysRemaining === 1 ? 'יום' : 'ימים'}`
                            : `in ${nextHoliday.daysRemaining} ${nextHoliday.daysRemaining === 1 ? 'day' : 'days'}`})
                        </span>
                      </span>
                    </div>
                    <button
                      id="widget-expand-next-holiday-btn"
                      onClick={handleToggleMinimizeNextHoliday}
                      className="flex items-center gap-1 text-[11px] font-medium text-[#C5A267] hover:underline px-2 py-0.5 rounded hover:bg-[#222222] transition-colors"
                      title={settings.language === 'he' ? 'הרחב תצוגת חג הבא' : 'Expand Next Holiday'}
                    >
                      <span>{settings.language === 'he' ? 'הרחב' : 'Expand'}</span>
                      <ChevronDown className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </>
            )}

            {/* Line 2: Next Halachic Zman (On Bottom) or Minimized View */}
            {nextZman && (
              <>
                {/* Subtle Divider between Holiday and Zman */}
                {nextHoliday && (
                  <div className="border-t border-[#2A2A2A]/80 my-0.5" />
                )}

                {!isNextZmanMinimized ? (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 group transition-all">
                    <div 
                      onClick={() => setIsZmanimModalOpen(true)}
                      className="flex items-center gap-3 cursor-pointer hover:opacity-95 flex-1"
                      title={settings.language === 'he' ? 'לחץ לצפייה בכל זמני היום לפי ההלכה' : 'Click to view all daily Halachic times'}
                    >
                      <div className="w-9 h-9 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-lg shrink-0">
                        ⏳
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-[0.15em] block">
                            {settings.language === 'he' ? 'הזמן ההלכתי הבא' : 'NEXT HALACHIC ZMAN'}
                          </span>
                          <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                        </div>
                        <span className="text-sm font-semibold text-white flex items-center gap-2">
                          <span className="font-serif-hebrew text-base text-[#E5C287] font-bold" dir="rtl">
                            {nextZman.hebrewTitle}
                          </span>
                          {/* In Hebrew mode: NO English translation */}
                          {settings.language !== 'he' && (
                            <>
                              <span className="text-[#888888] font-light">•</span>
                              <span className="text-[#D1D1D1]">{nextZman.title}</span>
                            </>
                          )}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0 self-end sm:self-auto">
                      <div 
                        onClick={() => setIsZmanimModalOpen(true)}
                        className="text-right cursor-pointer"
                      >
                        <span className="text-[11px] text-[#888888] block">
                          {settings.language === 'he' ? 'שעה מדויקת' : 'Exact Time'}
                        </span>
                        <span className="text-xs font-mono font-bold text-white">
                          {nextZman.formattedTime}
                        </span>
                      </div>
                      {nextZman.timeRemaining && (
                        <div 
                          onClick={() => setIsZmanimModalOpen(true)}
                          className="px-3 py-1.5 bg-[#252525] border border-[#3A3A3A] group-hover:border-[#C5A267] text-[#C5A267] rounded-lg font-bold shadow-md flex items-center gap-1.5 min-w-[70px] justify-center transition-colors cursor-pointer"
                        >
                          <span className="text-xs font-mono">
                            {settings.language === 'he' 
                              ? nextZman.timeRemaining.replace('in ', 'בעוד ').replace('m', " דק'").replace('h', " שע'") 
                              : nextZman.timeRemaining}
                          </span>
                        </div>
                      )}
                      {/* Minimize Button directly on the Widget */}
                      <button
                        id="widget-minimize-next-zman-btn"
                        onClick={handleToggleMinimizeNextZman}
                        className="p-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-[#888888] hover:text-[#C5A267] transition-colors"
                        title={settings.language === 'he' ? 'מזער את שורת הזמן ההלכתי' : 'Minimize Next Zman line'}
                      >
                        <ChevronUp className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between py-0.5 text-xs">
                    <div 
                      onClick={() => setIsZmanimModalOpen(true)}
                      className="flex items-center gap-2 cursor-pointer group"
                    >
                      <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
                      <span className="text-[11px] text-[#888888] group-hover:text-[#D1D1D1] transition-colors">
                        {settings.language === 'he' ? 'זמן הבא (ממוזער):' : 'Next Zman (Minimized):'}{' '}
                        <strong className="text-[#E5C287] font-serif-hebrew font-bold mr-1">
                          {nextZman.hebrewTitle}
                        </strong>
                        <span className="font-mono text-[#D1D1D1]">({nextZman.formattedTime})</span>
                      </span>
                    </div>
                    <button
                      id="widget-expand-next-zman-btn"
                      onClick={handleToggleMinimizeNextZman}
                      className="flex items-center gap-1 text-[11px] font-medium text-[#C5A267] hover:underline px-2 py-0.5 rounded hover:bg-[#222222] transition-colors"
                      title={settings.language === 'he' ? 'הרחב תצוגת זמן הלכתי' : 'Expand Next Zman'}
                    >
                      <span>{settings.language === 'he' ? 'הרחב' : 'Expand'}</span>
                      <ChevronDown className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Dynamic View Mode Renderer */}
        {viewMode === 'month' && (
          <CalendarMonthView
            currentDate={currentDate}
            days={monthDays}
            onSelectDay={(day) => {
              handleSelectDay(day);
              setViewMode('day');
            }}
            onOpenAddEvent={handleOpenAddEvent}
            selectedDate={selectedDayDate}
            location={currentLocation}
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onDateChange={setCurrentDate}
            upcomingHoliday={nextHoliday}
          />
        )}

        {viewMode === 'week' && (
          <CalendarWeekView
            currentDate={currentDate}
            days={weekDays}
            onSelectDay={handleSelectDay}
            onOpenAddEvent={handleOpenAddEvent}
            selectedDate={selectedDayDate}
            location={currentLocation}
            onDateChange={setCurrentDate}
            settings={settings}
          />
        )}

        {viewMode === 'day' && (
          <CalendarDayView
            currentDate={currentDate}
            onDateChange={(date) => {
              setCurrentDate(date);
              setSelectedDayDate(date);
            }}
            day={selectedDay}
            location={currentLocation}
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onOpenAddEvent={handleOpenAddEvent}
          />
        )}

        {viewMode === 'agenda' && (
          <CalendarAgendaView
            currentDate={currentDate}
            location={currentLocation}
            events={events}
            onSelectDate={(d) => {
              handleSelectDate(d);
              setViewMode('day');
            }}
            onOpenAddEvent={() => handleOpenAddEvent()}
          />
        )}
      </main>

      {/* Footer Branding & Fast Links */}
      <footer className="mt-auto border-t border-[#2A2A2A] bg-[#161616] py-4 px-6 text-xs text-[#888888]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[#C5A267] font-bold font-serif-hebrew">
              {t.appName}
            </span>
            <span>•</span>
            <span className="text-[#888888]">{t.appSubtitle}</span>
          </div>

          {/* Bottom Dropdown Menu */}
          <div className="relative">
            <button
              id="footer-dropdown-btn"
              onClick={() => setShowFooterDropdown(!showFooterDropdown)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-semibold text-[#C5A267] transition-colors"
            >
              <Menu className="w-3.5 h-3.5" />
              <span>{settings.language === 'he' ? 'כלים מהירים' : 'Quick Tools'}</span>
              <ChevronUp className="w-3.5 h-3.5" />
            </button>

            {showFooterDropdown && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowFooterDropdown(false)} 
                />
                <div className="absolute bottom-full right-0 sm:right-auto sm:left-0 mb-2 w-48 bg-[#161616] rounded-xl shadow-2xl border border-[#2A2A2A] py-1.5 z-50 animate-in fade-in slide-in-from-bottom-2 duration-150">
                  <button
                    onClick={() => {
                      setIsConverterModalOpen(true);
                      setShowFooterDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    {t.dateConverter}
                  </button>
                  <button
                    onClick={() => {
                      setIsZmanimModalOpen(true);
                      setShowFooterDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    {t.todayZmanim}
                  </button>
                  <button
                    onClick={() => {
                      setIsWidgetModalOpen(true);
                      setShowFooterDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    {t.homeWidget}
                  </button>
                  <button
                    onClick={() => {
                      setIsSyncModalOpen(true);
                      setShowFooterDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-[#D1D1D1] hover:bg-[#202020] transition-colors"
                  >
                    {t.syncDevices}
                  </button>
                  <button
                    onClick={() => {
                      setIsSettingsModalOpen(true);
                      setShowFooterDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-[#C5A267] font-semibold hover:bg-[#202020] transition-colors border-t border-[#2A2A2A] mt-1 pt-2"
                  >
                    {t.settings}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </footer>

      {/* Floating Movable Draggable Add Event Button */}
      <motion.button
        drag
        dragMomentum={false}
        dragElastic={0.1}
        dragConstraints={{
          left: -1200,
          right: 50,
          top: -1200,
          bottom: 50,
        }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => handleOpenAddEvent()}
        style={{ touchAction: 'none' }}
        className="fixed bottom-20 right-6 z-50 w-14 h-14 bg-[#C5A267] hover:bg-[#B38F56] text-[#0F0F0F] rounded-full flex items-center justify-center shadow-[0_8px_30px_rgb(0,0,0,0.5)] border border-[#E5C287]/40 cursor-grab active:cursor-grabbing text-2xl font-bold transition-colors select-none"
        title={t.addEvent}
        id="draggable-add-event-fab"
      >
        <Plus className="w-6 h-6" />
      </motion.button>

      {/* Floating Home Screen Quick Access Widget (If Pinned) */}
      {floatingWidgetPinned && (
        <FloatingQuickWidget
          todayDay={todayDay}
          nextZman={nextZman}
          nextHoliday={nextHoliday}
          settings={settings}
          location={currentLocation}
          onOpenApp={() => setIsWidgetModalOpen(true)}
          onClose={() => setFloatingWidgetPinned(false)}
        />
      )}

      {/* Modals & Dialogs */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={() => setIsEventModalOpen(false)}
        onSaveEvent={handleSaveEvent}
        existingEvent={editingEvent}
        defaultDay={eventModalDefaultDay}
        settings={settings}
      />

      <EventsManagerModal
        isOpen={isEventsManagerOpen}
        onClose={() => setIsEventsManagerOpen(false)}
        events={events}
        onAddEvent={() => {
          setIsEventsManagerOpen(false);
          handleOpenAddEvent();
        }}
        onEditEvent={(ev) => {
          setIsEventsManagerOpen(false);
          handleOpenEditEvent(ev);
        }}
        onDeleteEvent={handleDeleteEvent}
        onImportEvents={handleImportEvents}
        location={currentLocation}
        settings={settings}
      />

      <HomeScreenWidget
        isOpen={isWidgetModalOpen}
        onClose={() => setIsWidgetModalOpen(false)}
        todayDay={todayDay}
        location={currentLocation}
        nextZman={nextZman}
        nextHoliday={nextHoliday}
        settings={settings}
        floatingPinned={floatingWidgetPinned}
        onToggleFloating={() => setFloatingWidgetPinned(!floatingWidgetPinned)}
        onOpenStandaloneWidget={() => setIsStandaloneWidgetMode(true)}
      />

      <HolidayAlertsModal
        isOpen={isAlertsModalOpen}
        onClose={() => setIsAlertsModalOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        todayDay={todayDay}
        location={currentLocation}
      />

      <MultiDeviceSyncModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
        syncState={syncState}
        onUpdateSyncState={setSyncState}
        events={events}
        onSetEvents={setEvents}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        location={currentLocation}
      />

      <DateConverterModal
        isOpen={isConverterModalOpen}
        onClose={() => setIsConverterModalOpen(false)}
        location={currentLocation}
        onSelectDate={handleSelectDate}
      />

      <ZmanimModal
        isOpen={isZmanimModalOpen}
        onClose={() => setIsZmanimModalOpen(false)}
        date={currentDate}
        location={currentLocation}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        day={selectedDay}
      />

      <ManualLocationModal
        isOpen={isManualLocationModalOpen}
        onClose={() => setIsManualLocationModalOpen(false)}
        currentLocation={currentLocation}
        onSaveLocation={(newLoc) => {
          handleUpdateSettings({ location: newLoc });
        }}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />
    </div>
  );
};

export default App;

