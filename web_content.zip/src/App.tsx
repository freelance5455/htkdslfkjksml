/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HashRouter } from 'react-router-dom';
import { ScreenType } from './types';
import { DeviceFrame } from './components/DeviceFrame';
import { BottomNav } from './components/BottomNav';
import { AuthProvider, useAuth } from './context/AuthContext';
import { recordFeatureAccess } from './services/historyService';

// Main Screens
import { SplashScreen } from './screens/SplashScreen';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { LoginScreen } from './screens/auth/LoginScreen';
import { RegisterScreen } from './screens/auth/RegisterScreen';
import { HealthProfileSetupScreen } from './screens/auth/HealthProfileSetupScreen';
import { HomeScreen } from './screens/HomeScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { SettingsScreen } from './screens/SettingsScreen';

// Modals
import { ForgotPasswordModal } from './components/modals/ForgotPasswordModal';

// Feature Placeholder Screens
import { MedicineScannerScreen } from './screens/features/MedicineScannerScreen';
import { MedicalReportAnalyzerScreen } from './screens/features/MedicalReportAnalyzerScreen';
import { DiseaseTrackerScreen } from './screens/features/DiseaseTrackerScreen';
import { MedicineReminderScreen } from './screens/features/MedicineReminderScreen';
import { HealthEducationScreen } from './screens/features/HealthEducationScreen';
import { EmergencyServicesScreen } from './screens/features/EmergencyServicesScreen';
import { HealthServicesScreen } from './screens/features/HealthServicesScreen';
import { SymptomGuideScreen } from './screens/features/SymptomGuideScreen';

function AppContent() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [screenStack, setScreenStack] = useState<ScreenType[]>(['home']);
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);

  const { isLoggedIn } = useAuth();

  // Track real feature access in user history when a feature is actually opened/used
  useEffect(() => {
    if (currentScreen && currentScreen.startsWith('feature-')) {
      recordFeatureAccess(currentScreen);
    }
  }, [currentScreen]);

  const navigateTo = (newScreen: ScreenType) => {
    setScreenStack((prev) => [...prev, newScreen]);
    setCurrentScreen(newScreen);
  };

  const goBack = () => {
    if (screenStack.length > 1) {
      const updatedStack = [...screenStack];
      updatedStack.pop();
      const prevScreen = updatedStack[updatedStack.length - 1];
      setScreenStack(updatedStack);
      setCurrentScreen(prevScreen || 'home');
    } else {
      setCurrentScreen('home');
    }
  };

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return (
          <SplashScreen
            onFinish={() => {
              if (isLoggedIn) {
                setCurrentScreen('home');
              } else {
                setCurrentScreen('welcome');
              }
            }}
          />
        );

      case 'welcome':
        return (
          <WelcomeScreen
            onExplore={() => navigateTo('home')}
            onLogin={() => navigateTo('login')}
            onRegister={() => navigateTo('register')}
          />
        );

      case 'login':
        return (
          <LoginScreen
            onNavigate={navigateTo}
            onOpenForgotPassword={() => setIsForgotPasswordOpen(true)}
          />
        );

      case 'register':
        return <RegisterScreen onNavigate={navigateTo} />;

      case 'health-profile-setup':
        return <HealthProfileSetupScreen onNavigate={navigateTo} />;

      case 'home':
        return <HomeScreen onNavigate={navigateTo} />;

      case 'history':
        return <HistoryScreen onNavigate={navigateTo} />;

      case 'profile':
        return <ProfileScreen onNavigate={navigateTo} />;

      case 'settings':
        return <SettingsScreen onBack={goBack} />;

      // Feature Placeholder Screens
      case 'feature-medicine':
        return <MedicineScannerScreen onBack={goBack} />;

      case 'feature-report':
        return <MedicalReportAnalyzerScreen onBack={goBack} />;

      case 'feature-tracker':
        return <DiseaseTrackerScreen onBack={goBack} />;

      case 'feature-reminder':
        return <MedicineReminderScreen onBack={goBack} />;

      case 'feature-education':
        return <HealthEducationScreen onBack={goBack} />;

      case 'feature-emergency':
        return <EmergencyServicesScreen onBack={goBack} />;

      case 'feature-services':
        return <HealthServicesScreen onBack={goBack} />;

      case 'feature-symptom-guide':
        return <SymptomGuideScreen onBack={goBack} />;

      default:
        return <HomeScreen onNavigate={navigateTo} />;
    }
  };

  return (
    <DeviceFrame>
      <div className="flex-1 flex flex-col relative w-full h-full overflow-y-auto">
        {renderActiveScreen()}

        {/* Bottom Navigation for Core Views */}
        <BottomNav currentScreen={currentScreen} onNavigate={navigateTo} />

        {/* Forgot Password Modal */}
        <ForgotPasswordModal
          isOpen={isForgotPasswordOpen}
          onClose={() => setIsForgotPasswordOpen(false)}
          onSuccess={() => navigateTo('login')}
        />
      </div>
    </DeviceFrame>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </HashRouter>
  );
}
