import React, { useState, useEffect } from 'react';
import { SFXEvent, ViewTab } from './types';
import { getEventsFromStorage } from './services/storage';
import { AndroidEmulator } from './components/AndroidEmulator';
import { ApkBuilderGuide } from './components/ApkBuilderGuide';
import { CalendarView } from './components/CalendarView';
import { StatsBar } from './components/StatsBar';
import { InvoiceModal } from './components/InvoiceModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { 
  Smartphone, 
  Download, 
  Calendar, 
  Sparkles, 
  Layers, 
  Code2, 
  ShieldCheck 
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ViewTab>('simulator');
  const [events, setEvents] = useState<SFXEvent[]>([]);
  const [activeSlipEvent, setActiveSlipEvent] = useState<SFXEvent | null>(null);

  const refreshEvents = () => {
    setEvents(getEventsFromStorage());
  };

  useEffect(() => {
    refreshEvents();
  }, []);

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-3">
          
          {/* Brand & Subtitle */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#0f4c81] to-[#1e6cb3] flex items-center justify-center text-white shadow-md shadow-blue-900/20">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-base sm:text-lg tracking-tight text-[#0f4c81]">
                  HI-TECH SFX
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-sky-100 text-[#0f4c81] border border-sky-200">
                  Android APK
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Offline Event Date & Data Manager • SQLite
              </p>
            </div>
          </div>

          {/* Tab Navigation & PWA Install Button */}
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <nav className="flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold text-slate-600">
              <button
                onClick={() => setActiveTab('simulator')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'simulator'
                    ? 'bg-white text-[#0f4c81] shadow-xs'
                    : 'hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>Live App</span>
              </button>

              <button
                onClick={() => setActiveTab('apk-builder')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'apk-builder'
                    ? 'bg-[#0f4c81] text-white shadow-xs'
                    : 'hover:text-slate-900'
                }`}
              >
                <Download className="w-4 h-4 text-amber-300" />
                <span>Build APK</span>
              </button>

              <button
                onClick={() => {
                  refreshEvents();
                  setActiveTab('calendar');
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'calendar'
                    ? 'bg-white text-[#0f4c81] shadow-xs'
                    : 'hover:text-slate-900'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Schedule</span>
              </button>
            </nav>

            <PWAInstallButton />
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 space-y-6">
        
        {/* Top business statistics bar */}
        <StatsBar 
          events={events} 
          onRefresh={refreshEvents} 
        />

        {/* Tab 1: Live Interactive Android Emulator */}
        {activeTab === 'simulator' && (
          <div className="space-y-4">
            <div className="text-center max-w-md mx-auto space-y-1">
              <span className="text-xs font-bold text-[#0f4c81] tracking-wider uppercase">
                Interactive Android Emulator
              </span>
              <p className="text-xs text-slate-500">
                Running the exact Java code &amp; SQLite database logic of <code className="font-mono text-slate-700 bg-white px-1 py-0.5 rounded border border-slate-200">MainActivity.java</code>
              </p>
            </div>

            <AndroidEmulator 
              onOpenSlip={ev => setActiveSlipEvent(ev)} 
            />
          </div>
        )}

        {/* Tab 2: APK Builder Guide & Project ZIP Downloader */}
        {activeTab === 'apk-builder' && (
          <ApkBuilderGuide />
        )}

        {/* Tab 3: Visual Event Calendar */}
        {activeTab === 'calendar' && (
          <CalendarView 
            events={events} 
            onSelectEvent={ev => {
              setActiveSlipEvent(ev);
            }} 
          />
        )}
      </main>

      {/* Booking Voucher Slip Modal */}
      <InvoiceModal 
        event={activeSlipEvent} 
        onClose={() => setActiveSlipEvent(null)} 
      />

      {/* Offline Status Toast */}
      <OfflineIndicator />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200/80 py-4 text-center text-xs text-slate-500">
        <p>
          HI-TECH SFX Event Manager • Package <code className="font-mono text-slate-700">com.hitech.sfx.eventmanager</code> • Native Android &amp; PWA
        </p>
      </footer>
    </div>
  );
}
