/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NavTab, Language, SolvedOpportunity, JobApplication, UserProfileData, SystemStatus } from './types';
import { StorageService } from './services/storage';
import { AndroidShell } from './components/AndroidShell';
import { ProblemSolver } from './components/ProblemSolver';
import { FindJobs } from './components/FindJobs';
import { BusinessOpportunities } from './components/BusinessOpportunities';
import { UserProfile } from './components/UserProfile';
import { FirebaseStatusModal } from './components/FirebaseStatusModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('solver');
  const [language, setLanguage] = useState<Language>(() => StorageService.getLanguage());
  const [userProfile, setUserProfile] = useState<UserProfileData>(() => StorageService.getUserProfile());
  const [savedOpportunities, setSavedOpportunities] = useState<SolvedOpportunity[]>(() =>
    StorageService.getSolvedProblems()
  );
  const [applications, setApplications] = useState<JobApplication[]>(() =>
    StorageService.getApplications()
  );
  const [savedBlueprintIds, setSavedBlueprintIds] = useState<string[]>(() =>
    StorageService.getSavedBlueprints()
  );
  const [isFirebaseModalOpen, setIsFirebaseModalOpen] = useState(false);
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);

  // Fetch server status on mount
  useEffect(() => {
    fetch('/api/system/status')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) setSystemStatus(data);
      })
      .catch((err) => console.log('Status fetch skipped:', err));
  }, []);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    StorageService.setLanguage(lang);
    const updated = { ...userProfile, preferredLanguage: lang };
    setUserProfile(updated);
    StorageService.saveUserProfile(updated);
  };

  const handleSaveOpportunity = (opp: SolvedOpportunity) => {
    const updated = StorageService.saveSolvedProblem(opp);
    setSavedOpportunities(updated);
  };

  const handleDeleteOpportunity = (id: string) => {
    const updated = StorageService.deleteSolvedProblem(id);
    setSavedOpportunities(updated);
  };

  const handleApplyJob = (application: JobApplication) => {
    const updated = StorageService.saveApplication(application);
    setApplications(updated);
  };

  const handleToggleSaveBlueprint = (id: string) => {
    const updated = StorageService.toggleSaveBlueprint(id);
    setSavedBlueprintIds(updated);
  };

  const handleUpdateProfile = (updated: UserProfileData) => {
    setUserProfile(updated);
    StorageService.saveUserProfile(updated);
  };

  const appliedJobIds = applications.map((a) => a.jobId);
  const savedOpportunityIds = savedOpportunities.map((o) => o.id);

  return (
    <div className="font-sans antialiased text-slate-900 bg-slate-900 min-h-screen">
      <AndroidShell
        activeTab={activeTab}
        onTabChange={setActiveTab}
        language={language}
        onLanguageChange={handleLanguageChange}
        onOpenFirebaseStatus={() => setIsFirebaseModalOpen(true)}
        systemStatus={systemStatus}
        savedCount={savedOpportunities.length}
        applicationCount={applications.length}
      >
        {activeTab === 'solver' && (
          <ProblemSolver
            language={language}
            onSaveOpportunity={handleSaveOpportunity}
            savedIds={savedOpportunityIds}
            onOpenBusinessPlanModal={(_title, _desc) => {
              setActiveTab('business');
            }}
          />
        )}

        {activeTab === 'jobs' && (
          <FindJobs
            language={language}
            onApplyJob={handleApplyJob}
            appliedJobIds={appliedJobIds}
            userProfile={userProfile}
          />
        )}

        {activeTab === 'business' && (
          <BusinessOpportunities
            language={language}
            savedBlueprintIds={savedBlueprintIds}
            onToggleSaveBlueprint={handleToggleSaveBlueprint}
          />
        )}

        {activeTab === 'profile' && (
          <UserProfile
            profile={userProfile}
            onUpdateProfile={handleUpdateProfile}
            language={language}
            onLanguageChange={handleLanguageChange}
            savedOpportunities={savedOpportunities}
            onDeleteOpportunity={handleDeleteOpportunity}
            applications={applications}
            systemStatus={systemStatus}
            onOpenFirebaseStatus={() => setIsFirebaseModalOpen(true)}
          />
        )}
      </AndroidShell>

      {/* Firebase & System Configuration Status Modal */}
      <FirebaseStatusModal
        isOpen={isFirebaseModalOpen}
        onClose={() => setIsFirebaseModalOpen(false)}
        language={language}
        systemStatus={systemStatus}
      />
    </div>
  );
}
