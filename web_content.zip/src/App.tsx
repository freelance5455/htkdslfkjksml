import { Suspense, useEffect } from "react";
import { Scene } from "./three/Scene";
import { Hud } from "./components/Hud";
import { Shop } from "./components/Shop";
import { Panel } from "./components/Panel";
import { Phone } from "./components/Phone";
import { store, useStore } from "./lib/store";

/** Keeps timers (sleep, click lock, jail) ticking even when the canvas idles. */
function useClock() {
  useEffect(() => {
    const id = window.setInterval(() => {
      store.tick();
      store.marsTick();
    }, 250);
    return () => window.clearInterval(id);
  }, []);
}

function Loader() {
  return (
    <div className="absolute inset-0 grid place-items-center">
      <div className="flex flex-col items-center gap-3">
        <span className="animate-floaty text-4xl">🥚</span>
        <span className="text-xs font-bold text-amber-900/50">داره جوجه می‌شه…</span>
      </div>
    </div>
  );
}

export default function App() {
  useClock();
  const map = useStore((s) => s.map);
  void map;

  return (
    /* the 3D skydome paints the background now, so the page only needs a
       matching base colour for the brief moment before the canvas mounts */
    <div
      className="relative h-[100dvh] w-full overflow-hidden select-none"
      style={{ background: "#0E0820" }}
    >
      <Suspense fallback={<Loader />}>
        <Scene />
      </Suspense>
      <Hud />
      <Shop />
      <Panel />
      <Phone />
    </div>
  );
}
