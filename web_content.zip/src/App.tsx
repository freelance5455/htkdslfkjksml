/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameCanvas } from './components/GameCanvas.tsx';
import { HUD } from './components/HUD.tsx';
import { TouchControls } from './components/TouchControls.tsx';
import { MenuModal } from './components/MenuModal.tsx';
import { GameOverModal } from './components/GameOverModal.tsx';
import { LeaderboardModal } from './components/LeaderboardModal.tsx';
import { CARS, CAR_LIST } from './data/cars.ts';
import { TRACKS } from './data/tracks.ts';
import { CarModel, GameStatus, TrackId } from './types.ts';
import { retroAudio } from './audio/retroAudio.ts';
import { getCrtPreference, getHighScores, setCrtPreference } from './utils/storage.ts';

export default function App() {
  const [gameStatus, setGameStatus] = useState<GameStatus>('MENU');
  const [selectedCar, setSelectedCar] = useState<CarModel>(CARS.r5 || CAR_LIST[0]);
  const [selectedTrackId, setSelectedTrackId] = useState<TrackId>('sahara');
  const [isCrtEnabled, setIsCrtEnabled] = useState<boolean>(getCrtPreference());
  const [isMuted, setIsMuted] = useState<boolean>(retroAudio.getIsMuted());
  const [isMusicMuted, setIsMusicMuted] = useState<boolean>(retroAudio.getIsMusicMuted());
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);

  // Phone tilt motion steering state
  const [isTiltEnabled, setIsTiltEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('chamsou_race_tilt') === 'true';
    } catch {
      return false;
    }
  });
  const [tiltAngle, setTiltAngle] = useState<number>(0);
  const tiltAngleRef = useRef<number>(0);

  // Live HUD metrics
  const [score, setScore] = useState<number>(0);
  const [speed, setSpeed] = useState<number>(0);
  const [health, setHealth] = useState<number>(100);
  const [nitro, setNitro] = useState<number>(50);
  const [isNitroActive, setIsNitroActive] = useState<boolean>(false);

  // Run Summary for Game Over
  const [lastRunStats, setLastRunStats] = useState({
    finalScore: 0,
    distanceKm: 0,
    topSpeedKmh: 0,
    powerupsCount: 0
  });

  // Calculate highest score in local storage
  const [highScore, setHighScore] = useState<number>(() => {
    const scores = getHighScores();
    return scores.length > 0 ? scores[0].score : 0;
  });

  // Keys state stored in mutable ref for zero-latency 60fps canvas sampling
  const activeKeysRef = useRef<Record<string, boolean>>({
    up: false,
    down: false,
    left: false,
    right: false,
    gas: false,
    brake: false,
    nitro: false
  });

  const hornTriggerRef = useRef<number>(0);

  // Sync Master Audio Mute
  const handleToggleMute = useCallback(() => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    retroAudio.setMuted(newMuted);
  }, [isMuted]);

  // Sync Background Music Mute
  const handleToggleMusic = useCallback(() => {
    const newMusicMuted = !isMusicMuted;
    setIsMusicMuted(newMusicMuted);
    retroAudio.setMusicMuted(newMusicMuted);
  }, [isMusicMuted]);

  // Sync CRT Scanlines
  const handleToggleCrt = useCallback(() => {
    const nextVal = !isCrtEnabled;
    setIsCrtEnabled(nextVal);
    setCrtPreference(nextVal);
  }, [isCrtEnabled]);

  // Toggle Phone Tilt Motion Steering with iOS permission support
  const handleToggleTilt = useCallback(async () => {
    if (
      typeof DeviceOrientationEvent !== 'undefined' &&
      typeof (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission === 'function'
    ) {
      try {
        const permission = await (DeviceOrientationEvent as unknown as { requestPermission: () => Promise<string> }).requestPermission();
        if (permission === 'granted') {
          setIsTiltEnabled(true);
          try {
            localStorage.setItem('chamsou_race_tilt', 'true');
          } catch {
            // ignore
          }
          return;
        }
      } catch (err) {
        console.warn('Orientation permission error:', err);
      }
    }

    setIsTiltEnabled((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('chamsou_race_tilt', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  // Listen to Phone Gyroscope / DeviceOrientation
  useEffect(() => {
    const onOrientation = (e: DeviceOrientationEvent) => {
      if (e.gamma !== null && e.gamma !== undefined) {
        let angle = e.gamma;
        // Adjust for landscape if rotated
        if (typeof window !== 'undefined' && 'orientation' in window) {
          const winOrient = (window as unknown as { orientation: number }).orientation;
          if (winOrient === 90) angle = e.beta || 0;
          else if (winOrient === -90) angle = -(e.beta || 0);
        }
        tiltAngleRef.current = angle;
        setTiltAngle(angle);
      }
    };

    if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
      window.addEventListener('deviceorientation', onOrientation);
    }
    return () => {
      if (typeof window !== 'undefined' && 'DeviceOrientationEvent' in window) {
        window.removeEventListener('deviceorientation', onOrientation);
      }
    };
  }, []);

  // Quick Horn
  const handleHorn = useCallback(() => {
    hornTriggerRef.current = Date.now();
    retroAudio.playHorn();
  }, []);

  // Keyboard Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Audio warmup on first keystroke
      retroAudio.init();

      const k = e.key.toLowerCase();

      // LEFT: A or ArrowLeft (steers left)
      if (k === 'arrowleft' || k === 'a') activeKeysRef.current.left = true;
      // RIGHT: D or ArrowRight (steers right)
      if (k === 'arrowright' || k === 'd') activeKeysRef.current.right = true;
      // FORWARD / GAS: W or ArrowUp or Space
      if (k === 'arrowup' || k === 'w') activeKeysRef.current.up = true;
      if (k === ' ') {
        e.preventDefault();
        activeKeysRef.current.gas = true;
      }
      // BRAKE / REVERSE: S or ArrowDown or Shift
      if (k === 'arrowdown' || k === 's') activeKeysRef.current.down = true;
      if (k === 'shift') {
        e.preventDefault();
        activeKeysRef.current.brake = true;
      }

      // Actions
      if (k === 'n') activeKeysRef.current.nitro = true;
      if (k === 'h') handleHorn();
      if (k === 'p' || k === 'escape') {
        if (gameStatus === 'PLAYING') {
          retroAudio.pauseMusic();
          setGameStatus('PAUSED');
        } else if (gameStatus === 'PAUSED') {
          retroAudio.resumeMusic();
          setGameStatus('PLAYING');
        }
      }
      if (k === 'm') handleToggleMute();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') activeKeysRef.current.left = false;
      if (k === 'arrowright' || k === 'd') activeKeysRef.current.right = false;
      if (k === 'arrowup' || k === 'w') activeKeysRef.current.up = false;
      if (k === ' ') activeKeysRef.current.gas = false;
      if (k === 'arrowdown' || k === 's') activeKeysRef.current.down = false;
      if (k === 'shift') activeKeysRef.current.brake = false;
      if (k === 'n') activeKeysRef.current.nitro = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameStatus, handleHorn, handleToggleMute]);

  // Touch control changes
  const handleTouchControl = useCallback((key: 'up' | 'down' | 'left' | 'right' | 'gas' | 'brake' | 'nitro', active: boolean) => {
    activeKeysRef.current[key] = active;
  }, []);

  // Start Game
  const handleStartGame = useCallback(() => {
    retroAudio.init();
    retroAudio.playStartFanfare();
    retroAudio.startMusic(); // Start light background music
    setScore(0);
    setSpeed(0);
    setHealth(100);
    setNitro(50);
    setIsNitroActive(false);
    activeKeysRef.current = {
      up: false,
      down: false,
      left: false,
      right: false,
      gas: false,
      brake: false,
      nitro: false
    };
    setGameStatus('PLAYING');
  }, []);

  // Pause Toggle
  const handleTogglePause = useCallback(() => {
    if (gameStatus === 'PLAYING') {
      retroAudio.pauseMusic();
      setGameStatus('PAUSED');
    } else if (gameStatus === 'PAUSED') {
      retroAudio.resumeMusic();
      setGameStatus('PLAYING');
    }
  }, [gameStatus]);

  // Game Over Handler
  const handleGameOver = useCallback((finalScore: number, distanceKm: number, topSpeedKmh: number, powerupsCount: number) => {
    retroAudio.stopMusic();
    setLastRunStats({
      finalScore,
      distanceKm,
      topSpeedKmh,
      powerupsCount
    });
    setGameStatus('GAMEOVER');
    if (finalScore > highScore) {
      setHighScore(finalScore);
    }
    retroAudio.playGameOverJingle();
  }, [highScore]);

  // HUD Update Callback from Game Loop
  const handleUpdateHUD = useCallback((data: { score: number; speed: number; health: number; nitro: number; isNitroActive: boolean }) => {
    setScore(data.score);
    setSpeed(data.speed);
    setHealth(data.health);
    setNitro(data.nitro);
    setIsNitroActive(data.isNitroActive);
  }, []);

  const currentTrack = TRACKS[selectedTrackId] || TRACKS.sahara;

  return (
    <div 
      dir="ltr"
      className="w-screen h-screen bg-[#07070b] flex items-center justify-center overflow-hidden p-0 sm:p-2 select-none"
    >
      {/* Outer Arcade Cabinet Frame */}
      <div className="relative w-full h-full max-w-2xl max-h-[960px] bg-black border-2 sm:border-4 border-[#d4a017] rounded-none sm:rounded-2xl shadow-[0_0_35px_rgba(212,160,23,0.55)] flex flex-col items-center justify-center overflow-hidden">
        
        {/* Game Canvas */}
        <GameCanvas
          playerCar={selectedCar}
          track={currentTrack}
          isRunning={gameStatus === 'PLAYING' || gameStatus === 'PAUSED'}
          isPaused={gameStatus === 'PAUSED'}
          onGameOver={handleGameOver}
          onUpdateHUD={handleUpdateHUD}
          activeKeysRef={activeKeysRef}
          hornTriggerRef={hornTriggerRef}
          tiltAngleRef={tiltAngleRef}
          isTiltEnabled={isTiltEnabled}
        />

        {/* In-Game HUD */}
        {(gameStatus === 'PLAYING' || gameStatus === 'PAUSED') && (
          <HUD
            score={score}
            highScore={highScore}
            speed={speed}
            maxSpeed={selectedCar.maxSpeed}
            health={health}
            nitro={nitro}
            isNitroActive={isNitroActive}
            track={currentTrack}
            isPaused={gameStatus === 'PAUSED'}
            isMuted={isMuted}
            isMusicMuted={isMusicMuted}
            isCrtEnabled={isCrtEnabled}
            isTiltEnabled={isTiltEnabled}
            tiltAngle={tiltAngle}
            onTogglePause={handleTogglePause}
            onToggleMute={handleToggleMute}
            onToggleMusic={handleToggleMusic}
            onToggleTilt={handleToggleTilt}
            onToggleCrt={handleToggleCrt}
            onShowLeaderboard={() => setShowLeaderboard(true)}
            onHorn={handleHorn}
          />
        )}

        {/* Touch Controls (Mobile Virtual Gamepad with Circular Buttons & Gas on Left) */}
        {(gameStatus === 'PLAYING' || gameStatus === 'PAUSED') && (
          <TouchControls
            onControlChange={handleTouchControl}
            onHorn={handleHorn}
            onToggleTilt={handleToggleTilt}
            isTiltEnabled={isTiltEnabled}
            tiltAngle={tiltAngle}
            nitro={nitro}
            isNitroActive={isNitroActive}
          />
        )}

        {/* Pause Overlay */}
        {gameStatus === 'PAUSED' && (
          <div className="absolute inset-0 bg-black/75 backdrop-blur-sm z-30 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-black font-press-start text-amber-400 mb-2">PAUSED</h2>
            <p className="text-sm font-cairo text-gray-300 mb-6">اللعبة متوقفة مؤقتاً</p>
            <button
              onClick={handleTogglePause}
              className="bg-amber-500 hover:bg-amber-400 text-black font-bold font-press-start px-8 py-3.5 rounded-full border-2 border-white shadow-xl active:scale-95 transition-transform cursor-pointer"
            >
              ▶ استئناف / RESUME
            </button>
          </div>
        )}

        {/* Start / Menu Modal */}
        {gameStatus === 'MENU' && (
          <MenuModal
            selectedCar={selectedCar}
            selectedTrackId={selectedTrackId}
            highScore={highScore}
            isMuted={isMuted}
            isCrtEnabled={isCrtEnabled}
            onSelectCar={setSelectedCar}
            onSelectTrack={setSelectedTrackId}
            onStartGame={handleStartGame}
            onToggleMute={handleToggleMute}
            onToggleCrt={handleToggleCrt}
            onShowLeaderboard={() => setShowLeaderboard(true)}
          />
        )}

        {/* Game Over Modal */}
        {gameStatus === 'GAMEOVER' && (
          <GameOverModal
            score={lastRunStats.finalScore}
            highScore={highScore}
            distanceKm={lastRunStats.distanceKm}
            topSpeedKmh={lastRunStats.topSpeedKmh}
            powerupsCount={lastRunStats.powerupsCount}
            car={selectedCar}
            track={currentTrack}
            onRestart={handleStartGame}
            onGoToMenu={() => setGameStatus('MENU')}
            onShowLeaderboard={() => setShowLeaderboard(true)}
          />
        )}

        {/* Leaderboard Modal */}
        {showLeaderboard && (
          <LeaderboardModal onClose={() => setShowLeaderboard(false)} />
        )}

        {/* Optional CRT Scanlines & Curved Screen Vignette */}
        {isCrtEnabled && (
          <div className="absolute inset-0 crt-overlay crt-vignette pointer-events-none z-50" />
        )}
      </div>
    </div>
  );
}
