import { useEffect, useState } from 'react';
import { ApkBuilderWorkspace } from './components/ApkBuilderWorkspace';
import { ExamKioskMode } from './components/ExamKioskMode';
import { DEFAULT_EXAMBRO_CONFIG, ExambroConfig } from './types/exambro';

const STORAGE_KEY = 'exambro_mts_inayatul_marzuki_config_v1';

export default function App() {
  const [config, setConfig] = useState<ExambroConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as ExambroConfig;
        return {
          ...DEFAULT_EXAMBRO_CONFIG,
          ...parsed,
          security: {
            ...DEFAULT_EXAMBRO_CONFIG.security,
            ...(parsed.security || {}),
          },
        };
      }
    } catch {
      // Ignore invalid localStorage
    }
    return DEFAULT_EXAMBRO_CONFIG;
  });

  const [isExamMode, setIsExamMode] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    } catch {
      // Ignore storage quota errors
    }
  }, [config]);

  return (
    <>
      <ApkBuilderWorkspace
        config={config}
        onChangeConfig={setConfig}
        onLaunchExamMode={() => setIsExamMode(true)}
      />

      {isExamMode && (
        <ExamKioskMode
          config={config}
          onExit={() => setIsExamMode(false)}
        />
      )}
    </>
  );
}
