import React, { useState, useEffect } from 'react';
import { auth, db, onAuthStateChanged, syncUserProfile, signOut } from './firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { UserProfile } from './types';
import { LandingPage } from './components/LandingPage';
import { Navigation, ActiveTab } from './components/Navigation';
import { RoomsView } from './components/RoomsView';
import { PostsView } from './components/PostsView';
import { ChatsView } from './components/ChatsView';
import { ProfileView } from './components/ProfileView';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>('profile');

  // Listen to Firebase Auth state change
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      console.log('Auth state changed, user:', user ? user.uid : 'null');
      if (user) {
        try {
          const profile = await syncUserProfile(user);
          setCurrentUser(profile);
        } catch (err) {
          console.error('Failed to sync profile from auth change:', err);
          // Fallback minimal profile to maintain continuity
          setCurrentUser({
            uid: user.uid,
            displayName: user.displayName || 'عضو زهرة شات',
            username: user.email?.split('@')[0] || `zahra_${user.uid.slice(0, 6)}`,
            email: user.email || '',
            photoURL: user.photoURL || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
            flowersCount: 0,
            coins: 0,
            friendsCount: 0,
            followersCount: 0,
            followingCount: 0,
            badge: 'عضو مميز 🌸',
            level: 1,
            createdAt: new Date().toISOString()
          });
        }
      } else {
        setCurrentUser(null);
      }
      setAuthLoading(false);
    });

    return () => unsub();
  }, []);

  // Keep balances and profile in sync with Firestore in real time
  // (admin approvals, gifts, purchases from other devices, etc.)
  const currentUid = currentUser?.uid;
  useEffect(() => {
    if (!currentUid) return;
    const unsub = onSnapshot(
      doc(db, 'users', currentUid),
      (snap) => {
        if (snap.exists()) {
          setCurrentUser((prev) => (prev ? { ...prev, ...(snap.data() as UserProfile) } : prev));
        }
      },
      (err) => console.error('Profile listener error:', err)
    );
    return () => unsub();
  }, [currentUid]);

  const handleUpdateFlowers = (amount: number) => {
    if (!currentUser) return;
    setCurrentUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        flowersCount: Math.max(0, (prev.flowersCount || 0) + amount)
      };
    });
  };

  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
    if (!currentUser) return;
    setCurrentUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        ...updated
      };
    });
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign out error:', err);
    } finally {
      setCurrentUser(null);
      setActiveTab('profile');
    }
  };

  // Auth Checking Loading Screen
  if (authLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4">
        <div className="relative w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-amber-400 via-rose-500 to-fuchsia-600 animate-spin">
          <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
            <span className="text-xl">🌸</span>
          </div>
        </div>
        <p className="mt-4 text-xs font-semibold text-rose-600 animate-pulse font-['Cairo']">
          جاري تحميل زهرة شات...
        </p>
      </div>
    );
  }

  // If user is not authenticated: Show Landing Page
  if (!currentUser) {
    return (
      <LandingPage 
        onAuthSuccess={(profile) => {
          setCurrentUser(profile);
          setActiveTab('profile');
        }} 
      />
    );
  }

  // Once authenticated: Render Zahra Chat full application (Rooms, Posts, Profile)
  return (
    <div className={`min-h-screen font-['Cairo'] selection:bg-pink-500 selection:text-white flex flex-col ${
      'bg-white text-slate-800'
    }`}>
      {/* Top Header & Bottom Navigation */}
      <Navigation 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        currentUser={currentUser} 
      />

      {/* Main Content Area */}
      <main className={`flex-1 w-full ${
        activeTab === 'profile' ? 'p-0' : 'max-w-4xl mx-auto px-4 pt-6'
      }`}>
        {activeTab === 'rooms' && (
          <RoomsView 
            currentUser={currentUser} 
            onUpdateUserFlowers={handleUpdateFlowers}
          />
        )}

        {activeTab === 'chats' && (
          <div className="pt-4">
            <ChatsView 
              currentUser={currentUser} 
              onNavigateToRooms={() => setActiveTab('rooms')}
            />
          </div>
        )}

        {activeTab === 'posts' && (
          <PostsView 
            currentUser={currentUser} 
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView 
            currentUser={currentUser} 
            onUpdateProfile={handleUpdateProfile}
            onLogout={handleLogout}
            onNavigateToPosts={() => setActiveTab('posts')}
            onNavigateToRooms={() => setActiveTab('rooms')}
            onNavigateToChats={() => setActiveTab('chats')}
              />
        )}
      </main>

    </div>
  );
}
