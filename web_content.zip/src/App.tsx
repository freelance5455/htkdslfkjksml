import { useState, useEffect, useCallback } from 'react';
import { Display } from './components/Display';
import { Keypad } from './components/Keypad';
import { HistoryDrawer } from './components/HistoryDrawer';
import { QuickConverters } from './components/QuickConverters';
import { ApkExportModal } from './components/ApkExportModal';
import { Language, NumeralSystem, HistoryItem } from './types/calculator';
import { evaluateExpression } from './utils/math';
import { soundFx } from './utils/audio';
import { 
  History, 
  Volume2, 
  VolumeX, 
  Globe, 
  HelpCircle,
  Calculator as CalcIcon,
  Sparkles,
  Smartphone
} from 'lucide-react';

export default function App() {
  // App preferences
  const [language, setLanguage] = useState<Language>('ur');
  const [numeralSystem, setNumeralSystem] = useState<NumeralSystem>('western');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'standard' | 'tools'>('standard');
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);
  const [showApkModal, setShowApkModal] = useState<boolean>(false);

  // Calculator State
  const [expression, setExpression] = useState<string>('');
  const [currentValue, setCurrentValue] = useState<string>('0');
  const [isNewNumber, setIsNewNumber] = useState<boolean>(true);
  const [activeKey, setActiveKey] = useState<string | null>(null);

  // History list
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('calc_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('calc_history', JSON.stringify(history));
    } catch {
      // Ignore storage errors
    }
  }, [history]);

  // Sync soundFx toggle
  useEffect(() => {
    soundFx.enabled = soundEnabled;
  }, [soundEnabled]);

  const isUrdu = language === 'ur';

  // Calculator actions
  const handleDigit = useCallback((digit: string) => {
    soundFx.playClick('number');
    setCurrentValue((prev) => {
      if (isNewNumber || prev === '0' || prev === 'Error') {
        setIsNewNumber(false);
        return digit;
      }
      // Cap max display length
      if (prev.replace(/[^0-9]/g, '').length >= 16) {
        return prev;
      }
      return prev + digit;
    });
  }, [isNewNumber]);

  const handleDecimal = useCallback(() => {
    soundFx.playClick('number');
    setCurrentValue((prev) => {
      if (isNewNumber || prev === 'Error') {
        setIsNewNumber(false);
        return '0.';
      }
      if (prev.includes('.')) {
        return prev;
      }
      return prev + '.';
    });
  }, [isNewNumber]);

  const handleOperator = useCallback((op: '+' | '-' | '×' | '÷') => {
    soundFx.playClick('operator');
    setExpression((prevExpr) => {
      let currentValToUse = currentValue;
      if (currentValToUse === 'Error') currentValToUse = '0';

      // If user is just changing the operator at the end of expression
      if (isNewNumber && prevExpr && /[+\-×÷]$/.test(prevExpr)) {
        return prevExpr.slice(0, -1) + op;
      }

      // If there's already an ongoing expression and user enters next operator,
      // evaluate live interim result if desired or accumulate
      if (prevExpr && !isNewNumber) {
        const fullExpr = `${prevExpr} ${currentValToUse}`;
        const evalRes = evaluateExpression(fullExpr);
        if (evalRes.success) {
          setCurrentValue(evalRes.result);
          setIsNewNumber(true);
          return `${evalRes.result} ${op}`;
        }
      }

      setIsNewNumber(true);
      return `${currentValToUse} ${op}`;
    });
  }, [currentValue, isNewNumber]);

  const handleEquals = useCallback(() => {
    soundFx.playClick('equals');
    if (!expression && currentValue) {
      return;
    }

    const fullExpr = expression ? `${expression} ${currentValue}` : currentValue;
    const res = evaluateExpression(fullExpr);

    if (res.success) {
      setCurrentValue(res.result);
      // Add to history
      const newItem: HistoryItem = {
        id: Date.now().toString(),
        expression: fullExpr,
        result: res.result,
        timestamp: Date.now(),
      };
      setHistory((prev) => [newItem, ...prev.slice(0, 49)]); // keep up to 50
      setExpression('');
      setIsNewNumber(true);
    } else {
      setCurrentValue('Error');
      setExpression('');
      setIsNewNumber(true);
    }
  }, [expression, currentValue]);

  const handleClear = useCallback(() => {
    soundFx.playClick('action');
    setCurrentValue('0');
    setExpression('');
    setIsNewNumber(true);
  }, []);

  const handleBackspace = useCallback(() => {
    soundFx.playClick('action');
    setCurrentValue((prev) => {
      if (prev === '0' || prev === 'Error' || isNewNumber) {
        return '0';
      }
      if (prev.length <= 1 || (prev.length === 2 && prev.startsWith('-'))) {
        return '0';
      }
      return prev.slice(0, -1);
    });
  }, [isNewNumber]);

  const handleToggleSign = useCallback(() => {
    soundFx.playClick('action');
    setCurrentValue((prev) => {
      if (prev === '0' || prev === 'Error') return '0';
      if (prev.startsWith('-')) return prev.slice(1);
      return '-' + prev;
    });
  }, []);

  const handlePercent = useCallback(() => {
    soundFx.playClick('action');
    setCurrentValue((prev) => {
      if (prev === 'Error') return '0';
      const num = parseFloat(prev);
      if (isNaN(num)) return '0';
      return (num / 100).toString();
    });
  }, []);

  const handleParenthesis = useCallback(() => {
    soundFx.playClick('operator');
    // Balance open/close parenthesis
    setExpression((prev) => {
      const openCount = (prev.match(/\(/g) || []).length;
      const closeCount = (prev.match(/\)/g) || []).length;

      if (openCount > closeCount && !isNewNumber) {
        // Close it
        setIsNewNumber(true);
        return `${prev} ${currentValue}) `;
      } else {
        // Open it
        setIsNewNumber(true);
        return prev ? `${prev} (` : '(';
      }
    });
  }, [currentValue, isNewNumber]);

  // Physical keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an input field (e.g. quick converter inputs)
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      const key = e.key;
      setActiveKey(key);
      setTimeout(() => setActiveKey(null), 150);

      if (/^[0-9]$/.test(key)) {
        e.preventDefault();
        handleDigit(key);
      } else if (key === '.') {
        e.preventDefault();
        handleDecimal();
      } else if (key === '+' || key === '-') {
        e.preventDefault();
        handleOperator(key as '+' | '-');
      } else if (key === '*') {
        e.preventDefault();
        handleOperator('×');
      } else if (key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (key === 'Escape' || key.toLowerCase() === 'c') {
        e.preventDefault();
        handleClear();
      } else if (key === '%') {
        e.preventDefault();
        handlePercent();
      } else if (key === '(' || key === ')') {
        e.preventDefault();
        handleParenthesis();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDigit, handleDecimal, handleOperator, handleEquals, handleBackspace, handleClear, handlePercent, handleParenthesis]);

  return (
    <div 
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start pb-12 selection:bg-amber-500/20"
      dir={isUrdu ? 'rtl' : 'ltr'}
    >
      {/* Top Navbar Contract: Brand Wordmark | Nav Links | Action */}
      <header className="w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Brand Wordmark (Zone 1) */}
          <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-md shadow-amber-500/10">
              <CalcIcon className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-base sm:text-lg tracking-tight text-slate-100">
                {isUrdu ? 'سادہ کیلکولیٹر' : 'Simple Calculator'}
              </span>
            </div>
          </div>

          {/* Quick Controls & Nav Links (Zone 2) */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Numeral System Toggle: 123 vs ۱۲۳ */}
            <button
              type="button"
              onClick={() => setNumeralSystem(prev => prev === 'western' ? 'eastern' : 'western')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 ${
                numeralSystem === 'eastern'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
              title={isUrdu ? 'ہندسوں کی صورت بدلیں (123 یا ۱۲۳)' : 'Toggle numerals (123 / ۱۲۳)'}
            >
              <span>{numeralSystem === 'eastern' ? '۱۲۳ اردو' : '123 Eng'}</span>
            </button>

            {/* Language Toggle: Urdu / English */}
            <button
              type="button"
              onClick={() => setLanguage(prev => prev === 'ur' ? 'en' : 'ur')}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 transition-colors flex items-center gap-1.5"
              title="Change Language / زبان تبدیل کریں"
            >
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <span>{isUrdu ? 'English' : 'اردو'}</span>
            </button>

            {/* Sound Mute/Unmute */}
            <button
              type="button"
              onClick={() => setSoundEnabled(prev => !prev)}
              className={`p-2 rounded-xl text-xs border transition-colors ${
                soundEnabled 
                  ? 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800' 
                  : 'bg-slate-900/40 text-slate-500 border-slate-800/40 hover:text-slate-400'
              }`}
              title={soundEnabled ? (isUrdu ? 'آواز بند کریں' : 'Mute sound') : (isUrdu ? 'آواز آن کریں' : 'Enable sound')}
              aria-label="Toggle Sound"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* APK Export Trigger */}
            <button
              type="button"
              onClick={() => setShowApkModal(true)}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-amber-500/15 border border-amber-500/30 text-amber-300 hover:bg-amber-500/25 transition-all flex items-center gap-1.5"
              title={isUrdu ? 'Android APK فائلز اور آف لائن سورس کوڈ' : 'Android APK Files & Offline Source Code'}
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{isUrdu ? 'APK کوڈ' : 'APK Code'}</span>
            </button>

            {/* History Trigger (Zone 3 Primary action) */}
            <button
              type="button"
              onClick={() => setShowHistory(true)}
              className="relative px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-100 transition-all flex items-center gap-1.5 border border-slate-700/60"
              title={isUrdu ? 'سابقہ حسابات دیکھیں' : 'View History'}
            >
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{isUrdu ? 'تاریخچہ' : 'History'}</span>
              {history.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-bold flex items-center justify-center">
                  {history.length > 9 ? '9+' : history.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="w-full max-w-4xl px-4 sm:px-6 pt-6 sm:pt-8 flex flex-col items-center">
        {/* Intro Tagline */}
        <div className="text-center mb-6 max-w-lg">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-100 mb-2">
            {isUrdu ? 'بنیادی حسابی عمل کے لیے آسان کیلکولیٹر' : 'Simple & Fast Arithmetic Calculator'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            {isUrdu 
              ? 'جمع، تفریق، ضرب، تقسیم اور فیصد کا فوری اور درست حساب۔ کی بورڈ سے بھی استعمال کیا جا سکتا ہے۔'
              : 'Add, subtract, multiply, divide, and percentages with instant tactile accuracy.'}
          </p>
        </div>

        {/* Tab Switcher: Standard Calculator vs Quick Tools */}
        <div className="w-full max-w-md flex items-center p-1 bg-slate-900 border border-slate-800 rounded-2xl mb-6 shadow-sm">
          <button
            type="button"
            onClick={() => setActiveTab('standard')}
            className={`flex-1 py-2.5 px-4 text-xs sm:text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 ${
              activeTab === 'standard'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <CalcIcon className="w-4 h-4" />
            <span>{isUrdu ? 'معیاری کیلکولیٹر' : 'Standard Calculator'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tools')}
            className={`flex-1 py-2.5 px-4 text-xs sm:text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 ${
              activeTab === 'tools'
                ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{isUrdu ? 'رعایت و اکائیاں' : 'Discounts & Units'}</span>
          </button>
        </div>

        {/* Calculator Body or Quick Tools */}
        {activeTab === 'standard' ? (
          <div className="w-full max-w-md bg-slate-900/80 border border-slate-800/90 rounded-3xl p-4 sm:p-5 shadow-2xl backdrop-blur-sm space-y-4">
            {/* Screen Display */}
            <Display
              expression={expression}
              currentValue={currentValue}
              numeralSystem={numeralSystem}
              language={language}
              onBackspace={handleBackspace}
              onClear={handleClear}
            />

            {/* Tactile Keypad */}
            <Keypad
              onDigit={handleDigit}
              onOperator={handleOperator}
              onDecimal={handleDecimal}
              onPercent={handlePercent}
              onParenthesis={handleParenthesis}
              onToggleSign={handleToggleSign}
              onClear={handleClear}
              onEquals={handleEquals}
              numeralSystem={numeralSystem}
              language={language}
              activeKey={activeKey}
            />
          </div>
        ) : (
          <div className="w-full max-w-md">
            <QuickConverters language={language} numeralSystem={numeralSystem} />
          </div>
        )}

        {/* Helpful Arithmetic Info Cards */}
        <div className="w-full max-w-2xl mt-10 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 text-center">
            <span className="text-xl font-bold font-mono text-amber-400 block mb-0.5">+</span>
            <span className="text-xs font-semibold text-slate-200 block">{isUrdu ? 'جمع (Addition)' : 'Addition (+)'}</span>
            <span className="text-[11px] text-slate-400 mt-1 block">{isUrdu ? 'دو یا زائد اعداد کا مجموعہ' : 'Sum of numbers'}</span>
          </div>

          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 text-center">
            <span className="text-xl font-bold font-mono text-amber-400 block mb-0.5">−</span>
            <span className="text-xs font-semibold text-slate-200 block">{isUrdu ? 'تفریق (Subtraction)' : 'Subtraction (−)'}</span>
            <span className="text-[11px] text-slate-400 mt-1 block">{isUrdu ? 'ایک عدد سے دوسرا گھٹانا' : 'Difference'}</span>
          </div>

          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 text-center">
            <span className="text-xl font-bold font-mono text-amber-400 block mb-0.5">×</span>
            <span className="text-xs font-semibold text-slate-200 block">{isUrdu ? 'ضرب (Multiplication)' : 'Multiplication (×)'}</span>
            <span className="text-[11px] text-slate-400 mt-1 block">{isUrdu ? 'بار بار جمع کا عمل' : 'Product'}</span>
          </div>

          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 text-center">
            <span className="text-xl font-bold font-mono text-amber-400 block mb-0.5">÷</span>
            <span className="text-xs font-semibold text-slate-200 block">{isUrdu ? 'تقسیم (Division)' : 'Division (÷)'}</span>
            <span className="text-[11px] text-slate-400 mt-1 block">{isUrdu ? 'برابر حصوں میں تقسیم' : 'Quotient'}</span>
          </div>
        </div>

        {/* Keyboard hints banner */}
        <div className="w-full max-w-2xl mt-6 flex items-center justify-between p-3.5 bg-slate-900/40 border border-slate-800/60 rounded-2xl text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-slate-500 shrink-0" />
            <span>
              {isUrdu 
                ? 'کی بورڈ سے نمبر، جمع، نفی، ضرب، تقسیم، Enter اور Backspace براہ راست کام کرتے ہیں'
                : 'Keyboard numbers, +, -, *, /, Enter and Backspace work seamlessly'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowHelp(prev => !prev)}
            className="text-amber-400 hover:text-amber-300 font-medium underline underline-offset-2 shrink-0 px-2"
          >
            {showHelp ? (isUrdu ? 'چھپائیں' : 'Hide') : (isUrdu ? 'شارٹ کٹس' : 'Shortcuts')}
          </button>
        </div>

        {/* Detailed Keyboard Shortcuts helper */}
        {showHelp && (
          <div className="w-full max-w-2xl mt-3 p-4 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-slate-300 grid grid-cols-2 sm:grid-cols-4 gap-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg">
              <span>{isUrdu ? 'برابر کا نشان' : 'Equals'}</span>
              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 font-mono text-[11px] text-amber-300">Enter / =</kbd>
            </div>
            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg">
              <span>{isUrdu ? 'صاف کریں' : 'Clear All'}</span>
              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 font-mono text-[11px] text-rose-300">Esc / C</kbd>
            </div>
            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg">
              <span>{isUrdu ? 'ایک ہندسہ مٹائیں' : 'Backspace'}</span>
              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 font-mono text-[11px]">⌫</kbd>
            </div>
            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg">
              <span>{isUrdu ? 'ضرب اور تقسیم' : 'Multiply & Divide'}</span>
              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 font-mono text-[11px] text-amber-300">* /</kbd>
            </div>
          </div>
        )}
      </main>

      {/* History Modal / Drawer */}
      <HistoryDrawer
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        history={history}
        onSelectHistory={(item) => {
          setCurrentValue(item.result);
          setIsNewNumber(true);
        }}
        onClearHistory={() => setHistory([])}
        language={language}
        numeralSystem={numeralSystem}
      />

      {/* APK Export & Offline Source Modal */}
      <ApkExportModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
        language={language}
      />
    </div>
  );
}
