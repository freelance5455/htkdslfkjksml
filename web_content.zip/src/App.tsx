import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { Dashboard } from './components/dashboard/Dashboard';
import { StudyPlanner } from './components/study/StudyPlanner';
import { WeeklySchedule } from './components/schedule/WeeklySchedule';
import { CalendarView } from './components/calendar/CalendarView';
import { PrayerTimesView } from './components/prayers/PrayerTimesView';
import { AdhkarView } from './components/adhkar/AdhkarView';
import { AlarmsView } from './components/alarms/AlarmsView';
import { MedicationTracker } from './components/medications/MedicationTracker';
import { ProgressStats } from './components/stats/ProgressStats';
import { FocusTimer } from './components/focus/FocusTimer';
import { SettingsView } from './components/settings/SettingsView';
import { QuranVerseModal } from './components/quran/QuranVerseModal';
import { AuthModal } from './components/auth/AuthModal';
import { AndroidApkModal } from './components/android/AndroidApkModal';

const MainLayout: React.FC = () => {
  const { activeTab, setActiveTab, showQuranModal, setShowQuranModal } = useApp();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-[#fff6f8] dark:bg-[#12080f] text-slate-900 dark:text-rose-50 transition-colors">
      {/* Quran Verse Pop-up modal */}
      <QuranVerseModal
        isOpen={showQuranModal}
        onClose={() => setShowQuranModal(false)}
      />

      {/* Email Link & Cloud Sync Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />

      {/* Android APK & PWA Download Modal */}
      <AndroidApkModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
      />

      {/* Top Header */}
      <Header
        onOpenQuickStudy={() => setActiveTab('pomodoro')}
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenApkModal={() => setShowApkModal(true)}
      />

      {/* Main App Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col lg:flex-row">
        {/* Navigation Sidebar (Desktop) */}
        <Sidebar
          onOpenAuth={() => setShowAuthModal(true)}
          onOpenApkModal={() => setShowApkModal(true)}
        />

        {/* Dynamic Viewport Canvas */}
        <main className="flex-1 p-3 sm:p-6 lg:p-8 pb-24 lg:pb-8 overflow-y-auto">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'calendar' && <CalendarView />}
          {activeTab === 'study' && <StudyPlanner />}
          {activeTab === 'schedule' && <WeeklySchedule />}
          {activeTab === 'prayers' && <PrayerTimesView />}
          {activeTab === 'adhkar' && <AdhkarView />}
          {activeTab === 'alarms' && <AlarmsView />}
          {activeTab === 'meds' && <MedicationTracker />}
          {activeTab === 'stats' && <ProgressStats />}
          {activeTab === 'pomodoro' && <FocusTimer />}
          {activeTab === 'settings' && (
            <SettingsView
              onOpenAuth={() => setShowAuthModal(true)}
              onOpenApkModal={() => setShowApkModal(true)}
            />
          )}
        </main>
      </div>

      {/* Android Mobile Bottom Navigation Dock */}
      <MobileBottomNav
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenApkModal={() => setShowApkModal(true)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
