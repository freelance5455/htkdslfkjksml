/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { GameHUD } from './components/GameHUD';
import { Modals } from './components/Modals';
import { TitleScreen } from './components/TitleScreen';
import { sound } from './game/audio';
import { GameEngine } from './game/engine';
import { SaveSystem } from './game/saveSystem';
import {
  ActiveMonsterState,
  ArmorDef,
  GameSaveData,
  PlayerStats,
  QuestDef,
  RegionId,
  WeaponDef,
} from './game/types';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [gameState, setGameState] = useState<'title' | 'playing' | 'paused' | 'gameover'>('title');
  const [saveData, setSaveData] = useState<GameSaveData>(() => SaveSystem.load());
  const [playerStats, setPlayerStats] = useState<PlayerStats | null>(null);
  const [targetMonster, setTargetMonster] = useState<ActiveMonsterState | null>(null);
  const [currentRegion, setCurrentRegion] = useState<RegionId>('settlement');
  const [notification, setNotification] = useState<string | null>(null);
  const [notificationTimeout, setNotificationTimeout] = useState<NodeJS.Timeout | null>(null);

  // Modals state
  const [activeModal, setActiveModal] = useState<
    'forge' | 'camp' | 'quest' | 'bestiary' | 'inventory' | 'settings' | 'pause' | 'victory' | 'defeat' | null
  >(null);
  const [victoryDetails, setVictoryDetails] = useState<{
    quest: QuestDef;
    monsterId: string;
    timeSec: number;
    carves: string[];
  } | null>(null);
  const [defeatReason, setDefeatReason] = useState<string | null>(null);

  // Show notification helper
  const triggerNotification = (msg: string) => {
    setNotification(msg);
    if (notificationTimeout) clearTimeout(notificationTimeout);
    const timeout = setTimeout(() => setNotification(null), 3000);
    setNotificationTimeout(timeout);
  };

  // Mount Game Engine Once
  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    // Set high-DPI responsive canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initialize Engine
    const engine = new GameEngine(
      canvas,
      {
        onStateUpdate: (stats, monster) => {
          setPlayerStats({ ...stats });
          setTargetMonster(monster);
          if (engineRef.current) {
            setCurrentRegion(engineRef.current.world.currentRegion);
          }
        },
        onHuntComplete: (quest, monsterId, timeSec, carves) => {
          setVictoryDetails({ quest, monsterId, timeSec, carves });
          setActiveModal('victory');
          setGameState('gameover');
          document.body.dataset.state = 'gameover';
        },
        onHuntFailed: (reason) => {
          setDefeatReason(reason);
          setActiveModal('defeat');
          setGameState('gameover');
          document.body.dataset.state = 'gameover';
        },
        onPartBrokenBanner: (monsterName, partName) => {
          triggerNotification(`BROKEN: ${monsterName}'s ${partName}!`);
        },
        onNotification: (msg) => {
          triggerNotification(msg);
        },
      },
      saveData
    );

    engineRef.current = engine;

    // Check ?autostart=1
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      setGameState('playing');
      document.body.dataset.state = 'playing';
      engine.start();
    } else {
      document.body.dataset.state = 'title';
    }

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      engine.stop();
    };
  }, []);

  // Update body dataset state
  useEffect(() => {
    document.body.dataset.state = gameState;
  }, [gameState]);

  // Global Keyboard shortcuts (Escape for pause, M for mute)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState === 'title') return;

      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (activeModal) {
          setActiveModal(null);
          setGameState('playing');
        } else {
          setActiveModal('pause');
          setGameState('paused');
        }
      } else if (e.code === 'KeyM') {
        const nextMute = !sound.getMuted();
        sound.setMuted(nextMute);
        triggerNotification(nextMute ? 'Audio Muted' : 'Audio Unmuted');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, activeModal]);

  const handleStartGame = () => {
    setGameState('playing');
    document.body.dataset.state = 'playing';
    if (engineRef.current) {
      engineRef.current.start();
    }
  };

  const handleResetSave = () => {
    SaveSystem.reset();
    window.location.reload();
  };

  const handleFastTravel = (regionId: RegionId) => {
    if (engineRef.current) {
      engineRef.current.loadRegion(regionId);
      setCurrentRegion(regionId);
    }
  };

  const handleEquipWeapon = (weaponId: string) => {
    if (engineRef.current) {
      engineRef.current.playerStats.equippedWeaponId = weaponId;
      engineRef.current.saveData.equippedWeaponId = weaponId;
      SaveSystem.save(engineRef.current.saveData);
      setPlayerStats({ ...engineRef.current.playerStats });
      triggerNotification(`Equipped ${weaponId}`);
    }
  };

  const handleCraftWeapon = (weapon: WeaponDef) => {
    if (!engineRef.current) return;
    const engine = engineRef.current;

    // Deduct materials & currency
    engine.playerStats.zenny -= weapon.cost;
    weapon.materials.forEach((mat) => {
      const slot = engine.playerStats.pouch.find((s) => s.itemId === mat.itemId);
      if (slot) slot.count -= mat.count;
    });

    if (!engine.saveData.craftedEquipment.includes(weapon.id)) {
      engine.saveData.craftedEquipment.push(weapon.id);
    }
    engine.playerStats.equippedWeaponId = weapon.id;
    engine.saveData.equippedWeaponId = weapon.id;
    engine.saveData.zenny = engine.playerStats.zenny;
    SaveSystem.save(engine.saveData);

    setSaveData({ ...engine.saveData });
    setPlayerStats({ ...engine.playerStats });
    triggerNotification(`Forged & Equipped ${weapon.name}!`);
  };

  const handleCraftArmor = (armor: ArmorDef) => {
    if (!engineRef.current) return;
    const engine = engineRef.current;

    // Deduct
    engine.playerStats.zenny -= armor.cost;
    armor.materials.forEach((mat) => {
      const slot = engine.playerStats.pouch.find((s) => s.itemId === mat.itemId);
      if (slot) slot.count -= mat.count;
    });

    if (!engine.saveData.craftedEquipment.includes(armor.id)) {
      engine.saveData.craftedEquipment.push(armor.id);
    }
    engine.playerStats.equippedArmor[armor.slot] = armor.id;
    engine.recalculateArmorStats();
    engine.saveData.equippedArmor[armor.slot] = armor.id;
    engine.saveData.zenny = engine.playerStats.zenny;
    SaveSystem.save(engine.saveData);

    setSaveData({ ...engine.saveData });
    setPlayerStats({ ...engine.playerStats });
    triggerNotification(`Equipped ${armor.name}!`);
  };

  const handleAcceptQuest = (quest: QuestDef) => {
    if (engineRef.current) {
      engineRef.current.activeQuest = quest;
      engineRef.current.saveData.activeQuestId = quest.id;
      engineRef.current.questFinished = false;
      engineRef.current.huntTimer = 0;
      SaveSystem.save(engineRef.current.saveData);

      // Travel to quest region if not currently there
      if (engineRef.current.world.currentRegion !== quest.region) {
        engineRef.current.loadRegion(quest.region);
        setCurrentRegion(quest.region);
      }
      triggerNotification(`Accepted Quest: ${quest.title}`);
    }
  };

  const handleRestAtCamp = () => {
    if (engineRef.current) {
      engineRef.current.playerStats.hp = engineRef.current.playerStats.maxHp;
      engineRef.current.playerStats.stamina = engineRef.current.playerStats.maxStamina;
      setPlayerStats({ ...engineRef.current.playerStats });
      triggerNotification('Rested at Camp. Vitality and Stamina restored!');
    }
  };

  const handleSaveGame = () => {
    if (engineRef.current) {
      SaveSystem.save(engineRef.current.saveData);
      triggerNotification('Progress saved successfully to Local Storage.');
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none">
      {/* Isolated Canvas Viewport for 60fps simulation */}
      <canvas
        ref={canvasRef}
        onPointerDown={(e) => {
          if (engineRef.current && gameState === 'playing') {
            engineRef.current.input.mousePos.x = e.clientX;
            engineRef.current.input.mousePos.y = e.clientY;
            engineRef.current.input.mouseDown = true;
            engineRef.current.input.mouseJustPressed = true;
            engineRef.current.input.triggerVirtualButton('attack', true);
            setTimeout(() => {
              engineRef.current?.input.triggerVirtualButton('attack', false);
            }, 80);
          }
        }}
        className="absolute inset-0 block w-full h-full cursor-crosshair touch-none"
      />

      {/* Title Screen Overlay */}
      {gameState === 'title' && (
        <TitleScreen
          saveData={saveData}
          onStartGame={handleStartGame}
          onResetSave={handleResetSave}
          onOpenSettings={() => setActiveModal('settings')}
        />
      )}

      {/* World-Matched Game HUD */}
      {gameState !== 'title' && playerStats && (
        <GameHUD
          stats={playerStats}
          currentRegion={currentRegion}
          targetMonster={targetMonster}
          notification={notification}
          onOpenModal={(modal) => {
            setActiveModal(modal);
            setGameState('paused');
          }}
          onUseItem={() => engineRef.current?.useCurrentPouchItem()}
          onCycleItem={(dir) => {
            if (engineRef.current && playerStats.pouch.length > 0) {
              const nextIdx =
                (playerStats.selectedPouchIndex + dir + playerStats.pouch.length) %
                playerStats.pouch.length;
              engineRef.current.playerStats.selectedPouchIndex = nextIdx;
              setPlayerStats({ ...engineRef.current.playerStats });
            }
          }}
          onToggleLockOn={() => engineRef.current?.toggleLockOn()}
          onInteract={() => engineRef.current?.interactNearby()}
          onTouchAction={(action, isDown) => {
            engineRef.current?.input.triggerVirtualButton(action, isDown);
          }}
          onJoystickTouch={(active, dx, dy) => {
            if (engineRef.current) {
              engineRef.current.input.joystick.active = active;
              engineRef.current.input.joystick.dx = dx;
              engineRef.current.input.joystick.dy = dy;
            }
          }}
        />
      )}

      {/* Modals & Overlays */}
      <Modals
        activeModal={activeModal}
        saveData={saveData}
        playerStats={playerStats || engineRef.current?.playerStats || ({} as PlayerStats)}
        currentRegion={currentRegion}
        victoryDetails={victoryDetails}
        defeatReason={defeatReason}
        onClose={() => {
          setActiveModal(null);
          setGameState('playing');
        }}
        onFastTravel={handleFastTravel}
        onEquipWeapon={handleEquipWeapon}
        onCraftWeapon={handleCraftWeapon}
        onCraftArmor={handleCraftArmor}
        onAcceptQuest={handleAcceptQuest}
        onRestAtCamp={handleRestAtCamp}
        onSaveGame={handleSaveGame}
        onReturnToTitle={() => {
          setActiveModal(null);
          setGameState('title');
          engineRef.current?.stop();
        }}
        onUpdateSettings={(settings) => {
          if (engineRef.current) {
            engineRef.current.saveData.settings = settings;
            SaveSystem.save(engineRef.current.saveData);
            setSaveData({ ...engineRef.current.saveData });
          }
        }}
      />
    </div>
  );
}
