import { useState, useEffect } from 'react';
import {
  Language,
  Currency,
  UserProfile,
  FlightOffer,
  HotelOffer,
  HotelRoom,
  WalletDocument,
} from './types';
import {
  initialUser,
  sampleFlights,
  sampleHotels,
  sampleVisaCountries,
  sampleActiveTrip,
  sampleWalletDocuments,
  sampleDevisList,
  sampleAgencyClients,
  sampleNotifications,
} from './data/mockData';
import { MobileShell } from './components/layout/MobileShell';
import { SplashScreen } from './components/splash/SplashScreen';
import { OnboardingScreen } from './components/onboarding/OnboardingScreen';
import { HomeScreen } from './components/home/HomeScreen';
import { ExploreScreen } from './components/explore/ExploreScreen';
import { AIAssistantScreen } from './components/assistant/AIAssistantScreen';
import { FlightSearchScreen } from './components/flights/FlightSearchScreen';
import { HotelSearchScreen } from './components/hotels/HotelSearchScreen';
import { VisaCenterScreen } from './components/visa/VisaCenterScreen';
import { MyTripsScreen } from './components/trips/MyTripsScreen';
import { TravelWalletScreen } from './components/wallet/TravelWalletScreen';
import { AirportARScreen } from './components/ar/AirportARScreen';
import { NotificationsScreen } from './components/notifications/NotificationsScreen';
import { ProfileScreen } from './components/profile/ProfileScreen';
import { AgencyDashboard } from './components/agency/AgencyDashboard';
import { TripGuardianModal } from './components/guardian/TripGuardianModal';
import { AuthModal } from './components/auth/AuthModal';
import { FlutterArchitectureDoc } from './components/docs/FlutterArchitectureDoc';
import { SuccessAnimation } from './components/common/SuccessAnimation';
import { BiometricAuthModal } from './components/auth/BiometricAuthModal';
import { SmartPackingAssistant } from './components/packing/SmartPackingAssistant';
import { AppImportExportModal } from './components/common/AppImportExportModal';
import { AndroidApkModal } from './components/common/AndroidApkModal';
import { AppExportData } from './utils/appImportExport';
import { isSectionLocked, lockSection, ProtectedSection } from './utils/biometrics';
import confetti from 'canvas-confetti';

export default function App() {
  // Query parameters support (e.g. ?autostart=1 skips splash & onboarding)
  const queryParams = new URLSearchParams(window.location.search);
  const autostart = queryParams.get('autostart') === '1';

  // Lifecycle States
  const [showSplash, setShowSplash] = useState(!autostart);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [currentTab, setCurrentTab] = useState<string>('home');

  // User & Settings
  const [user, setUser] = useState<UserProfile>(initialUser);
  const [language, setLanguage] = useState<Language>(initialUser.language);
  const [currency, setCurrency] = useState<Currency>(initialUser.currency);

  // Data Store
  const [flights] = useState<FlightOffer[]>(sampleFlights);
  const [hotels] = useState<HotelOffer[]>(sampleHotels);
  const [visaCountries] = useState(sampleVisaCountries);
  const [activeTrip, setActiveTrip] = useState(sampleActiveTrip);
  const [walletDocs, setWalletDocs] = useState<WalletDocument[]>(sampleWalletDocuments);
  const [agencyDevis, setAgencyDevis] = useState(sampleDevisList);
  const [agencyClients, setAgencyClients] = useState(sampleAgencyClients);
  const [notifications, setNotifications] = useState(sampleNotifications);

  // Modals & Feedback
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showGuardianModal, setShowGuardianModal] = useState(false);
  const [successState, setSuccessState] = useState<{
    isOpen: boolean;
    title: string;
    subtitle?: string;
    actionText?: string;
    onAction?: () => void;
  }>({
    isOpen: false,
    title: '',
  });

  // Biometric Security Guard State (Securing Wallet and Profile)
  const [biometricTarget, setBiometricTarget] = useState<ProtectedSection | null>(null);
  const [showBiometricModal, setShowBiometricModal] = useState(false);
  const [showImportExportModal, setShowImportExportModal] = useState(false);
  const [showAndroidApkModal, setShowAndroidApkModal] = useState(false);

  const handleImportData = (importedData: AppExportData) => {
    if (importedData.activeTrip) {
      setActiveTrip(importedData.activeTrip);
    }
    if (importedData.walletDocuments && importedData.walletDocuments.length > 0) {
      setWalletDocs(importedData.walletDocuments);
    }
    if (importedData.user) {
      setUser(prev => ({ ...prev, ...importedData.user }));
    }
  };

  const handleNavigateTab = (tab: string) => {
    if (tab === 'wallet' && isSectionLocked('wallet')) {
      setBiometricTarget('wallet');
      setShowBiometricModal(true);
      return;
    }
    if (tab === 'profile' && isSectionLocked('profile')) {
      setBiometricTarget('profile');
      setShowBiometricModal(true);
      return;
    }
    setCurrentTab(tab);
  };

  const handleBiometricSuccess = () => {
    setShowBiometricModal(false);
    if (biometricTarget) {
      setCurrentTab(biometricTarget);
      setBiometricTarget(null);
    }
  };

  const handleBiometricCancel = () => {
    setShowBiometricModal(false);
    setBiometricTarget(null);
  };

  const handleLockVault = () => {
    lockSection('wallet');
    setCurrentTab('home');
  };

  const handleLockAllSections = () => {
    lockSection();
    setCurrentTab('home');
  };

  // Synchronize HTML direction (RTL for Arabic, LTR for FR/EN)
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  // Booking handlers
  const handleBookFlight = (flight: FlightOffer) => {
    const newDoc: WalletDocument = {
      id: `doc-${Date.now()}`,
      title: `تذكرة طيران ${flight.airline} (${flight.fromCode} → ${flight.toCode})`,
      category: 'ticket',
      documentNumber: `ETK-${flight.flightNumber}-${Date.now().toString().slice(-6)}`,
      passengerName: user.fullName.toUpperCase(),
      issueDate: 'اليوم',
      qrCodeData: `FLIGHT:${flight.flightNumber}:${flight.fromCode}:${flight.toCode}`,
      offlineReady: true,
      fileSize: '1.1 MB',
    };
    setWalletDocs(prev => [newDoc, ...prev]);

    // Add notification
    const notif = {
      id: `notif-${Date.now()}`,
      title: 'تم إصدار تذكرة طيران جديدة',
      message: `تم حجز رحلتك مع ${flight.airline} (${flight.fromCode} → ${flight.toCode}) بنجاح.`,
      category: 'booking' as const,
      timestamp: 'الآن',
      isRead: false,
      actionRoute: 'wallet',
    };
    setNotifications(prev => [notif, ...prev]);

    // Trigger Success Animation
    setSuccessState({
      isOpen: true,
      title: language === 'ar' ? 'تم تأكيد حجز الرحلة بنجاح!' : 'Flight Booked Successfully!',
      subtitle: language === 'ar'
        ? `تم إصدار تذكرتك على متن ${flight.airline} وحفظها في محفظة TAKI-GO الإلكترونية للاستخدام دون إنترنت (Offline).`
        : `Your ticket for ${flight.airline} is issued and saved to your Travel Wallet.`,
      actionText: language === 'ar' ? 'عرض التذكرة في محفظتي' : 'View in Travel Wallet',
      onAction: () => handleNavigateTab('wallet'),
    });
  };

  const handleBookHotel = (hotel: HotelOffer, room: HotelRoom) => {
    const newDoc: WalletDocument = {
      id: `doc-${Date.now()}`,
      title: `قسيمة إقامة: ${hotel.name}`,
      category: 'hotel_voucher',
      documentNumber: `VCH-${hotel.id.toUpperCase()}-${Date.now().toString().slice(-4)}`,
      passengerName: user.fullName.toUpperCase(),
      issueDate: 'اليوم',
      qrCodeData: `HOTEL:${hotel.name}:${room.name}`,
      offlineReady: true,
      fileSize: '1.4 MB',
    };
    setWalletDocs(prev => [newDoc, ...prev]);

    const notif = {
      id: `notif-${Date.now()}`,
      title: 'تم تأكيد حجز الفندق',
      message: `تم حجز غرفتك في ${hotel.name} وحفظ القسيمة في محفظتك الإلكترونية.`,
      category: 'booking' as const,
      timestamp: 'الآن',
      isRead: false,
      actionRoute: 'wallet',
    };
    setNotifications(prev => [notif, ...prev]);

    // Trigger Success Animation
    setSuccessState({
      isOpen: true,
      title: language === 'ar' ? 'تم تأكيد حجز الفندق بنجاح!' : 'Hotel Reservation Confirmed!',
      subtitle: language === 'ar'
        ? `تم تأكيد إقامتك في ${hotel.name} وحفظ قسيمة الفندق (Voucher) في محفظتك.`
        : `Your reservation at ${hotel.name} is confirmed and saved in your wallet.`,
      actionText: language === 'ar' ? 'عرض القسيمة في محفظتي' : 'View Hotel Voucher',
      onAction: () => handleNavigateTab('wallet'),
    });
  };

  const handleBookAIPlan = (planDetails: { destination: string; budget: number }) => {
    const notif = {
      id: `notif-${Date.now()}`,
      title: 'تم حجز برنامج الذكاء الاصطناعي',
      message: `تم إرسال طلب برنامج ${planDetails.destination} إلى وكيل Tourism By Taki لمتابعة الإجراءات.`,
      category: 'booking' as const,
      timestamp: 'الآن',
      isRead: false,
      actionRoute: 'trips',
    };
    setNotifications(prev => [notif, ...prev]);

    // Trigger Success Animation
    setSuccessState({
      isOpen: true,
      title: language === 'ar' ? 'تم تصميم وحجز البرنامج بنجاح!' : 'Travel Plan Confirmed!',
      subtitle: language === 'ar'
        ? `تم اعتماد برنامج ${planDetails.destination} وإضافته إلى جدول رحلاتك القادمة.`
        : `Custom itinerary for ${planDetails.destination} added to your upcoming trips.`,
      actionText: language === 'ar' ? 'استعراض جدول الرحلة' : 'View Itinerary',
      onAction: () => setCurrentTab('trips'),
    });
  };

  const handleRequestVisaAssistance = (countryName: string) => {
    const notif = {
      id: `notif-${Date.now()}`,
      title: 'طلب مساعدة تأشيرة قيد المتابعة',
      message: `تم استلام طلب مساعدتك في استخراج تأشيرة ${countryName}. سيتواصل معك مستشار الوكالة.`,
      category: 'visa' as const,
      timestamp: 'الآن',
      isRead: false,
    };
    setNotifications(prev => [notif, ...prev]);

    // Trigger Success Animation
    setSuccessState({
      isOpen: true,
      title: language === 'ar' ? `تم تسجيل طلب تأشيرة ${countryName}!` : `Visa Request Received!`,
      subtitle: language === 'ar'
        ? `تم فتح ملف طلبك بنجاح لدى قسم التأشيرات في Tourism By Taki. سيتصل بك مستشارنا عبر الهاتف أو واتساب لمراجعة الوثائق.`
        : `Your visa dossier for ${countryName} has been opened at Tourism By Taki concierge.`,
      actionText: language === 'ar' ? 'تتبع الإشعارات والملف' : 'Track Status',
      onAction: () => setCurrentTab('notifications'),
    });
  };

  const handleSendBroadcast = (title: string, message: string) => {
    const notif = {
      id: `notif-${Date.now()}`,
      title,
      message,
      category: 'flight_alert' as const,
      timestamp: 'الآن',
      isRead: false,
    };
    setNotifications(prev => [notif, ...prev]);
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <>
      {/* 1. Splash Screen */}
      {showSplash && (
        <SplashScreen
          language={language}
          onFinish={() => {
            setShowSplash(false);
            setShowOnboarding(true);
          }}
        />
      )}

      {/* 2. Onboarding Screen */}
      {showOnboarding && !showSplash && (
        <OnboardingScreen
          language={language}
          onComplete={() => setShowOnboarding(false)}
        />
      )}

      {/* 3. Main App Container */}
      {!showSplash && !showOnboarding && (
        <MobileShell
          currentTab={currentTab}
          onSelectTab={handleNavigateTab}
          language={language}
          currency={currency}
          user={user}
          onOpenAndroidApk={() => setShowAndroidApkModal(true)}
        >
          {currentTab === 'home' && (
            <HomeScreen
              user={user}
              upcomingTrip={activeTrip}
              unreadNotificationsCount={unreadCount}
              language={language}
              currency={currency}
              onNavigateTab={handleNavigateTab}
              onOpenNotifications={() => setCurrentTab('notifications')}
              onOpenProfile={() => handleNavigateTab('profile')}
              onOpenGuardian={() => setShowGuardianModal(true)}
              onOpenAndroidApk={() => setShowAndroidApkModal(true)}
            />
          )}

          {currentTab === 'explore' && (
            <ExploreScreen
              language={language}
              currency={currency}
              onSelectCityAction={(cityName) => setCurrentTab('flights')}
            />
          )}

          {currentTab === 'assistant' && (
            <AIAssistantScreen
              language={language}
              currency={currency}
              onBookPlan={handleBookAIPlan}
            />
          )}

          {currentTab === 'flights' && (
            <FlightSearchScreen
              flights={flights}
              language={language}
              currency={currency}
              onBookFlight={handleBookFlight}
            />
          )}

          {currentTab === 'hotels' && (
            <HotelSearchScreen
              hotels={hotels}
              language={language}
              currency={currency}
              onBookHotel={handleBookHotel}
            />
          )}

          {currentTab === 'visa' && (
            <VisaCenterScreen
              countries={visaCountries}
              language={language}
              currency={currency}
              onRequestAssistance={handleRequestVisaAssistance}
            />
          )}

          {currentTab === 'trips' && (
            <MyTripsScreen
              trip={activeTrip}
              language={language}
              currency={currency}
              onOpenWallet={() => handleNavigateTab('wallet')}
              onOpenPacking={() => handleNavigateTab('packing')}
            />
          )}

          {currentTab === 'packing' && (
            <SmartPackingAssistant
              initialDestination={activeTrip?.destinationCity || 'إسطنبول (Istanbul)'}
              initialDuration={7}
              language={language}
              onClose={() => handleNavigateTab('home')}
            />
          )}

          {currentTab === 'wallet' && (
            <TravelWalletScreen
              documents={walletDocs}
              language={language}
              onLockVault={handleLockVault}
            />
          )}

          {currentTab === 'ar' && (
            <AirportARScreen
              language={language}
            />
          )}

          {currentTab === 'notifications' && (
            <NotificationsScreen
              notifications={notifications}
              language={language}
              onSelectAction={(route) => handleNavigateTab(route)}
            />
          )}

          {currentTab === 'profile' && (
            <ProfileScreen
              user={user}
              language={language}
              currency={currency}
              onUpdateLanguage={setLanguage}
              onUpdateCurrency={setCurrency}
              onOpenAgencyMode={() => setCurrentTab('agency')}
              onOpenAuthEdit={() => setShowAuthModal(true)}
              onOpenWallet={() => handleNavigateTab('wallet')}
              onOpenTrips={() => setCurrentTab('trips')}
              onLogout={() => {
                setUser({ ...user, isLoggedIn: false });
                setShowAuthModal(true);
              }}
              onLockAllSections={handleLockAllSections}
              onOpenImportExport={() => setShowImportExportModal(true)}
              onOpenAndroidApk={() => setShowAndroidApkModal(true)}
            />
          )}

          {currentTab === 'agency' && (
            <AgencyDashboard
              clients={agencyClients}
              devisList={agencyDevis}
              language={language}
              currency={currency}
              onSendBroadcast={handleSendBroadcast}
              onCloseAgencyMode={() => setCurrentTab('home')}
            />
          )}

          {currentTab === 'architecture' && (
            <FlutterArchitectureDoc
              language={language}
            />
          )}
        </MobileShell>
      )}

      {/* Global Modals */}
      <TripGuardianModal
        isOpen={showGuardianModal}
        onClose={() => setShowGuardianModal(false)}
        trip={activeTrip}
        language={language}
      />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        currentUser={user}
        onUpdateUser={setUser}
        language={language}
      />

      {/* Biometric Security Guard Modal */}
      <BiometricAuthModal
        section={biometricTarget || 'wallet'}
        isOpen={showBiometricModal}
        onSuccess={handleBiometricSuccess}
        onCancel={handleBiometricCancel}
        lang={language}
      />

      {/* App Import & Export Modal */}
      <AppImportExportModal
        isOpen={showImportExportModal}
        onClose={() => setShowImportExportModal(false)}
        language={language}
        user={user}
        activeTrip={activeTrip}
        walletDocuments={walletDocs}
        onImportData={handleImportData}
      />

      {/* Android APK & PWA Installer Modal */}
      <AndroidApkModal
        isOpen={showAndroidApkModal}
        onClose={() => setShowAndroidApkModal(false)}
        language={language}
      />

      {/* Generic Framer-Motion Neon Success Animation */}
      <SuccessAnimation
        isOpen={successState.isOpen}
        title={successState.title}
        subtitle={successState.subtitle}
        actionText={successState.actionText}
        onAction={successState.onAction}
        onClose={() => setSuccessState(prev => ({ ...prev, isOpen: false }))}
      />
    </>
  );
}
