import { AppProvider, useApp, type Screen } from "./context/AppContext";
import { Home, Briefcase, Map as MapIcon, Wallet, User, Users, Receipt } from "lucide-react";
import { ToastStack, DemoBadge } from "./components/ui";
import { BottomNav } from "./components/widgets";
import {
  SplashScreen,
  LandingScreen,
  AuthScreen,
  RoleSelectScreen,
  WorkerOnboardingScreen,
  ContractorOnboardingScreen,
} from "./screens/Onboarding";
import {
  WorkerHomeScreen,
  JobDiscoveryScreen,
  JobDetailScreen,
  WorkerMapScreen,
  WorkerProfileScreen,
  ShramScoreScreen,
  EarningsScreen,
} from "./screens/WorkerScreens";
import {
  ContractorHomeScreen,
  PostJobScreen,
  WorkerMatchingScreen,
  ContractorDashboardScreen,
  WorkersDirectoryScreen,
  ContractorPaymentsScreen,
} from "./screens/ContractorScreens";
import { ActiveJobScreen, CompletionScreen, PaymentGatewayScreen, RateScreen } from "./screens/JobFlow";
import {
  NotificationsScreen,
  SafetyScreen,
  SearchScreen,
  AdminDashboardScreen,
  ImpactDashboardScreen,
  SettingsScreen,
  DemoCenterScreen,
} from "./screens/MoreScreens";
import { BVentureDemoScreen } from "./screens/BVentureDemo";

const workerTabs = [
  { key: "worker-home", label: "Home", icon: <Home size={20} /> },
  { key: "job-discovery", label: "Jobs", icon: <Briefcase size={20} /> },
  { key: "worker-map", label: "Map", icon: <MapIcon size={20} /> },
  { key: "earnings", label: "Earnings", icon: <Wallet size={20} /> },
  { key: "worker-profile", label: "Profile", icon: <User size={20} /> },
];

const contractorTabs = [
  { key: "contractor-home", label: "Home", icon: <Home size={20} /> },
  { key: "contractor-dashboard", label: "Jobs", icon: <Briefcase size={20} /> },
  { key: "workers-directory", label: "Workers", icon: <Users size={20} /> },
  { key: "contractor-payments", label: "Payments", icon: <Receipt size={20} /> },
  { key: "settings", label: "Profile", icon: <User size={20} /> },
];

const tabScreenKeys = new Set([...workerTabs, ...contractorTabs].map((t) => t.key));

function ScreenRouter() {
  const { screen } = useApp();
  switch (screen as Screen) {
    case "splash":
      return <SplashScreen />;
    case "landing":
      return <LandingScreen />;
    case "auth":
      return <AuthScreen />;
    case "role-select":
      return <RoleSelectScreen />;
    case "onboarding-worker":
      return <WorkerOnboardingScreen />;
    case "onboarding-contractor":
      return <ContractorOnboardingScreen />;
    case "worker-home":
      return <WorkerHomeScreen />;
    case "job-discovery":
      return <JobDiscoveryScreen />;
    case "job-detail":
      return <JobDetailScreen />;
    case "worker-map":
      return <WorkerMapScreen />;
    case "worker-profile":
      return <WorkerProfileScreen />;
    case "shram-score":
      return <ShramScoreScreen />;
    case "earnings":
      return <EarningsScreen />;
    case "contractor-home":
      return <ContractorHomeScreen />;
    case "post-job":
      return <PostJobScreen />;
    case "worker-matching":
      return <WorkerMatchingScreen />;
    case "contractor-dashboard":
      return <ContractorDashboardScreen />;
    case "workers-directory":
      return <WorkersDirectoryScreen />;
    case "contractor-payments":
      return <ContractorPaymentsScreen />;
    case "active-job":
      return <ActiveJobScreen />;
    case "completion":
      return <CompletionScreen />;
    case "payment-gateway":
      return <PaymentGatewayScreen />;
    case "rate":
      return <RateScreen />;
    case "notifications":
      return <NotificationsScreen />;
    case "safety":
      return <SafetyScreen />;
    case "search":
      return <SearchScreen />;
    case "admin-dashboard":
      return <AdminDashboardScreen />;
    case "impact-dashboard":
      return <ImpactDashboardScreen />;
    case "sustainability":
      return <ImpactDashboardScreen />;
    case "settings":
      return <SettingsScreen />;
    case "demo-center":
      return <DemoCenterScreen />;
    case "bventure-demo":
      return <BVentureDemoScreen />;
    default:
      return <LandingScreen />;
  }
}

function AppShell() {
  const { screen, role, navigate, replace, toasts, dismissToast } = useApp();
  const showTabs = role && tabScreenKeys.has(screen);
  const tabs = role === "contractor" ? contractorTabs : workerTabs;

  return (
    <div className="min-h-screen w-full flex justify-center bg-ink/5 dark:bg-black">
      <div className="app-shell relative w-full min-h-screen bg-offwhite dark:bg-ink text-ink dark:text-offwhite flex flex-col shadow-2xl">
        {showTabs && (
          <div className="pointer-events-none fixed z-[60] w-full max-w-[480px] -translate-x-1/2 left-1/2" style={{ bottom: 86 }}>
            <div className="pointer-events-auto flex justify-end pr-4">
              <button onClick={() => navigate("demo-center")}>
                <DemoBadge className="shadow-lg" />
              </button>
            </div>
          </div>
        )}
        <div className="flex-1">
          <ScreenRouter />
        </div>
        {showTabs && (
          <BottomNav items={tabs} active={screen} onSelect={(k) => replace(k as Screen)} />
        )}
        <ToastStack toasts={toasts} onDismiss={dismissToast} />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
