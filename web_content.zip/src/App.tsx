import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { AnalyticsView } from './components/AnalyticsView';
import { BarcodeLabelSheet } from './components/BarcodeSVG';
import { CategoriesView } from './components/CategoriesView';
import { CustomersView } from './components/CustomersView';
import { DashboardView } from './components/DashboardView';
import { ExpensesSuppliersView } from './components/ExpensesSuppliersView';
import { Icon, IconName } from './components/Icon';
import { POSView } from './components/POSView';
import { ProductsView } from './components/ProductsView';
import { ReportsView } from './components/ReportsView';
import { SalesHistoryView } from './components/SalesHistoryView';
import { SettingsView } from './components/SettingsView';
import { Modal, ReceiptContent } from './components/SharedUI';
import { SheetContent } from './components/SheetPrintPreview';
import { StockMovementView } from './components/StockMovementView';
import { EN_TRANSLATIONS } from './translations';
import type {
  Category,
  Customer,
  Expense,
  MovementType,
  PrintMode,
  Product,
  ReportPayload,
  Sale,
  SalesStatementPayload,
  StockMovement,
  StoreData,
  StoreSettings,
  Supplier,
  ToastMessage,
  ViewId,
} from './types';
import {
  DEFAULT_DATA,
  fmtDateTime,
  fmtDuration,
  formatLiveClock,
  loadInitialState,
  splitSessionByDay,
  STORAGE_KEY,
  toDateKey,
  uid,
  useNowMs,
} from './utils';

const HeaderClockPill: React.FC<{ settings: StoreSettings; title: string; onClick: () => void }> = ({ settings, title, onClick }) => {
  const nowMs = useNowMs(true, 1000);
  const { timeText, dateText } = formatLiveClock(nowMs, settings);
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className="btn-dark px-2.5 sm:px-3.5 py-1.5 text-[11px] sm:text-xs font-mono tabular-nums"
    >
      <span>{timeText}</span>
      {dateText && <span className="hidden md:inline font-sans font-medium text-slate-300">· {dateText}</span>}
    </button>
  );
};

const ShopTimerButton: React.FC<{
  activeOpenedAt?: string | null;
  pastTodayMs: number;
  title: string;
  onClick: () => void;
}> = ({ activeOpenedAt, pastTodayMs, title, onClick }) => {
  const nowMs = useNowMs(!!activeOpenedAt, 1000);
  const todayKey = toDateKey(new Date());
  const activeMs =
    activeOpenedAt && toDateKey(activeOpenedAt) === todayKey
      ? Math.max(0, nowMs - new Date(activeOpenedAt).getTime())
      : 0;
  const totalMs = pastTodayMs + activeMs;
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap tabular-nums border ${
        activeOpenedAt
          ? 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100'
          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-[0_1px_2px_rgba(15,23,42,0.05)]'
      }`}
    >
      <Icon name="clock" className="w-3.5 h-3.5 shrink-0" />
      <span className="font-mono font-bold">{fmtDuration(totalMs)}</span>
    </button>
  );
};

const SessionModalLiveDuration: React.FC<{
  activeOpenedAt?: string | null;
  pastTodayMs: number;
  label: string;
}> = ({ activeOpenedAt, pastTodayMs, label }) => {
  const nowMs = useNowMs(!!activeOpenedAt, 1000);
  const todayKey = toDateKey(new Date());
  const activeMs =
    activeOpenedAt && toDateKey(activeOpenedAt) === todayKey
      ? Math.max(0, nowMs - new Date(activeOpenedAt).getTime())
      : 0;
  return (
    <div>
      <span className="font-semibold text-slate-700">{label}: </span>
      <span className="font-mono font-bold text-blue-600 tabular-nums">{fmtDuration(pastTodayMs + activeMs)}</span>
    </div>
  );
};

const ActiveSessionLiveRow: React.FC<{ openedAt: string; activeNowLabel: string }> = ({ openedAt, activeNowLabel }) => {
  const nowMs = useNowMs(true, 1000);
  return (
    <tr className="bg-emerald-50/60">
      <td className="px-3 py-2.5 font-medium">{fmtDateTime(openedAt)}</td>
      <td className="px-3 py-2.5 font-bold text-emerald-700">{activeNowLabel}</td>
      <td className="px-3 py-2.5 text-right font-mono font-bold text-emerald-700">
        {fmtDuration(Math.max(0, nowMs - new Date(openedAt).getTime()))}
      </td>
    </tr>
  );
};

export default function App() {
  const [data, setData] = useState<StoreData>(loadInitialState);
  const [view, setView] = useState<ViewId>('dashboard');
  const [analyticsInitialTab, setAnalyticsInitialTab] = useState<'sales' | 'time'>('sales');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [receiptSale, setReceiptSale] = useState<Sale | null>(null);
  const [printMode, setPrintMode] = useState<PrintMode>(null);
  const [sessionModalOpen, setSessionModalOpen] = useState(false);

  const t = EN_TRANSLATIONS;

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // Ignore quota errors
    }
  }, [data]);

  // Lightweight 24h midnight rollover check (runs every 15s only while shop is open, zero unnecessary root re-renders)
  useEffect(() => {
    if (!data.activeSession) return;

    const checkMidnightRollover = () => {
      const currentNow = Date.now();
      if (!data.activeSession) return;
      const openedDateKey = toDateKey(data.activeSession.openedAt);
      const todayKey = toDateKey(currentNow);
      if (openedDateKey !== todayKey) {
        const nowDate = new Date(currentNow);
        const startOfToday = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
        const completedSegments = splitSessionByDay(
          data.activeSession.openedAt,
          new Date(startOfToday.getTime() - 1).toISOString()
        );
        setData((prev) => {
          if (!prev.activeSession || toDateKey(prev.activeSession.openedAt) === todayKey) return prev;
          return {
            ...prev,
            shopSessions: [...completedSegments.reverse(), ...(prev.shopSessions || [])],
            activeSession: {
              id: uid(),
              openedAt: startOfToday.toISOString(),
            },
          };
        });
      }
    };

    checkMidnightRollover();
    const id = window.setInterval(checkMidnightRollover, 15000);
    return () => window.clearInterval(id);
  }, [data.activeSession]);

  const notify = useCallback((msg: string, type: 'success' | 'error' = 'success') => {
    const id = Date.now();
    setToast({ msg, type, id });
    setTimeout(() => setToast((prev) => (prev && prev.id === id ? null : prev)), 3000);
  }, []);

  const toggleShop = () => {
    if (data.activeSession) {
      const closedAt = new Date().toISOString();
      const segments = splitSessionByDay(data.activeSession.openedAt, closedAt);
      setData((prev) => ({
        ...prev,
        activeSession: null,
        shopSessions: [...segments.reverse(), ...(prev.shopSessions || [])],
      }));
    } else {
      setData((prev) => ({
        ...prev,
        activeSession: { id: uid(), openedAt: new Date().toISOString() },
      }));
    }
  };

  const pastTodayDurationMs = useMemo(() => {
    const today = toDateKey(new Date());
    return (data.shopSessions || [])
      .filter((s) => (s.dateKey || toDateKey(s.openedAt)) === today)
      .reduce((sum, s) => sum + (s.durationMs || 0), 0);
  }, [data.shopSessions]);

  const roundQty = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);

  const handleCompleteSale = (saleObj: Sale) => {
    setData((prev) => {
      const newMovements: StockMovement[] = saleObj.items.map((it) => {
        const p = prev.products.find((pr) => pr.id === it.productId);
        const prevQty = p ? p.quantity : 0;
        const nextQty = roundQty(prevQty - it.qty);
        return {
          id: uid(),
          date: saleObj.date,
          productId: it.productId,
          productName: it.name,
          type: 'sale',
          prevQty,
          delta: -Math.round(it.qty * 1000) / 1000,
          newQty: nextQty,
          reason: saleObj.invoiceNo,
        };
      });
      return {
        ...prev,
        products: prev.products.map((p) => {
          const sold = saleObj.items.find((i) => i.productId === p.id);
          return sold ? { ...p, quantity: roundQty(p.quantity - sold.qty) } : p;
        }),
        customers: prev.customers.map((c) =>
          c.id === saleObj.customerId
            ? {
                ...c,
                totalSpent: (c.totalSpent || 0) + saleObj.grandTotal,
                dueBalance: (c.dueBalance || 0) + saleObj.dueAmount,
              }
            : c
        ),
        sales: [saleObj, ...prev.sales],
        movements: [...newMovements, ...prev.movements],
      };
    });
    notify(t.saleCompleted);
    setReceiptSale(saleObj);
  };

  const handleEditSale = (oldSale: Sale, updatedSale: Sale) => {
    setData((prev) => {
      const editMovements: StockMovement[] = [];
      const nextProducts = prev.products.map((p) => {
        const oldQty = oldSale.items.find((i) => i.productId === p.id)?.qty || 0;
        const newQty = updatedSale.items.find((i) => i.productId === p.id)?.qty || 0;
        const diff = Math.round((oldQty - newQty) * 1000) / 1000;
        if (diff === 0) return p;
        const afterQty = roundQty(p.quantity + diff);
        editMovements.push({
          id: uid(),
          date: new Date().toISOString(),
          productId: p.id,
          productName: p.name,
          type: 'adjustment',
          prevQty: p.quantity,
          delta: diff,
          newQty: afterQty,
          reason: `Edited ${oldSale.invoiceNo}`,
        });
        return { ...p, quantity: afterQty };
      });

      const nextCustomers = prev.customers.map((c) => {
        let totalSpent = c.totalSpent || 0;
        let dueBalance = c.dueBalance || 0;
        if (c.id === oldSale.customerId) {
          totalSpent = Math.max(0, totalSpent - oldSale.grandTotal);
          dueBalance = Math.max(0, dueBalance - oldSale.dueAmount);
        }
        if (c.id === updatedSale.customerId) {
          totalSpent += updatedSale.grandTotal;
          dueBalance += updatedSale.dueAmount;
        }
        return { ...c, totalSpent, dueBalance };
      });

      return {
        ...prev,
        products: nextProducts,
        customers: nextCustomers,
        sales: prev.sales.map((s) => (s.id === updatedSale.id ? updatedSale : s)),
        movements: [...editMovements, ...prev.movements],
      };
    });
    notify(t.saleUpdated);
  };

  const handleDeleteSale = (saleId: string) => {
    setData((prev) => {
      const sale = prev.sales.find((s) => s.id === saleId);
      if (!sale) return prev;
      const returnMovements: StockMovement[] = sale.items.map((it) => {
        const p = prev.products.find((pr) => pr.id === it.productId);
        const prevQty = p ? p.quantity : 0;
        return {
          id: uid(),
          date: new Date().toISOString(),
          productId: it.productId,
          productName: it.name,
          type: 'sale_return',
          prevQty,
          delta: Math.round(it.qty * 1000) / 1000,
          newQty: roundQty(prevQty + it.qty),
          reason: `Deleted ${sale.invoiceNo}`,
        };
      });
      return {
        ...prev,
        products: prev.products.map((p) => {
          const sold = sale.items.find((i) => i.productId === p.id);
          return sold ? { ...p, quantity: roundQty(p.quantity + sold.qty) } : p;
        }),
        customers: prev.customers.map((c) =>
          c.id === sale.customerId
            ? {
                ...c,
                totalSpent: Math.max(0, (c.totalSpent || 0) - sale.grandTotal),
                dueBalance: Math.max(0, (c.dueBalance || 0) - sale.dueAmount),
              }
            : c
        ),
        sales: prev.sales.filter((s) => s.id !== saleId),
        movements: [...returnMovements, ...prev.movements],
      };
    });
  };

  const handleTouchRecentCategory = useCallback((catName: string) => {
    const clean = catName.trim();
    if (!clean || clean === 'all') return;
    setData((prev) => {
      const existing = prev.recentCategories || [];
      if (existing[0] && existing[0].toLowerCase() === clean.toLowerCase()) return prev;
      const filtered = existing.filter((c) => c.toLowerCase() !== clean.toLowerCase());
      return {
        ...prev,
        recentCategories: [clean, ...filtered].slice(0, 24),
      };
    });
  }, []);

  const handleSaveProduct = (prod: Product, isEdit: boolean) => {
    setData((prev) => {
      const catClean = (prod.category || '').trim();
      const catExists = prev.categories.some((c) => c.name.toLowerCase() === catClean.toLowerCase());
      const nextCategories =
        catClean && !catExists
          ? [...prev.categories, { id: uid(), name: catClean, models: prod.model ? [prod.model] : [] }]
          : prev.categories;
      const nextRecent = catClean
        ? [catClean, ...(prev.recentCategories || []).filter((c) => c.toLowerCase() !== catClean.toLowerCase())].slice(0, 24)
        : prev.recentCategories;
      return {
        ...prev,
        categories: nextCategories,
        recentCategories: nextRecent,
        products: isEdit ? prev.products.map((p) => (p.id === prod.id ? prod : p)) : [prod, ...prev.products],
      };
    });
    notify(t.productSaved);
  };

  const handleQuickCreateProduct = (prod: Product, recordStockIn: boolean) => {
    setData((prev) => {
      const catClean = (prod.category || '').trim();
      const catExists = prev.categories.some((c) => c.name.toLowerCase() === catClean.toLowerCase());
      const nextCategories =
        catClean && !catExists
          ? [...prev.categories, { id: uid(), name: catClean, models: prod.model ? [prod.model] : [] }]
          : prev.categories;
      const nextRecent = catClean
        ? [catClean, ...(prev.recentCategories || []).filter((c) => c.toLowerCase() !== catClean.toLowerCase())].slice(0, 24)
        : prev.recentCategories;
      const nextMovements =
        recordStockIn && prod.quantity > 0
          ? [
              {
                id: uid(),
                date: new Date().toISOString(),
                productId: prod.id,
                productName: prod.name,
                type: 'stock_in' as MovementType,
                prevQty: 0,
                delta: prod.quantity,
                newQty: prod.quantity,
                reason: prod.barcode ? `Opening Stock (${prod.barcode})` : 'Opening Stock',
              },
              ...prev.movements,
            ]
          : prev.movements;
      return {
        ...prev,
        categories: nextCategories,
        recentCategories: nextRecent,
        products: [prod, ...prev.products],
        movements: nextMovements,
      };
    });
    notify(t.productSaved);
  };

  const handleDeleteProduct = (id: string) => {
    setData((prev) => ({ ...prev, products: prev.products.filter((p) => p.id !== id) }));
  };

  const handleRecordMovement = ({
    productId,
    type,
    delta,
    reason,
  }: {
    productId: string;
    type: MovementType;
    delta: number;
    reason: string;
  }) => {
    setData((prev) => {
      const p = prev.products.find((pr) => pr.id === productId);
      if (!p) return prev;
      const cleanDelta = Math.round(delta * 1000) / 1000;
      const prevQty = p.quantity;
      const newQty = roundQty(prevQty + cleanDelta);
      const mv: StockMovement = {
        id: uid(),
        date: new Date().toISOString(),
        productId,
        productName: p.name,
        type,
        prevQty,
        delta: cleanDelta,
        newQty,
        reason,
      };
      return {
        ...prev,
        products: prev.products.map((pr) => (pr.id === productId ? { ...pr, quantity: newQty } : pr)),
        movements: [mv, ...prev.movements],
      };
    });
    notify(t.stockUpdated);
  };

  const handleSaveCustomer = (cust: Customer, isEdit: boolean) => {
    setData((prev) => ({
      ...prev,
      customers: isEdit ? prev.customers.map((c) => (c.id === cust.id ? cust : c)) : [...prev.customers, cust],
    }));
    notify(t.customerSaved);
  };

  const handleDeleteCustomer = (id: string) => {
    if (id === 'walk-in') {
      notify(t.walkInProtected, 'error');
      return;
    }
    setData((prev) => ({ ...prev, customers: prev.customers.filter((c) => c.id !== id) }));
  };

  const handleCollectDue = (custId: string, amount: number) => {
    setData((prev) => ({
      ...prev,
      customers: prev.customers.map((c) =>
        c.id === custId ? { ...c, dueBalance: Math.max(0, (c.dueBalance || 0) - amount) } : c
      ),
    }));
    notify(t.dueCollected);
  };

  const handleSaveExpense = (exp: Expense, isEdit: boolean) => {
    setData((prev) => ({
      ...prev,
      expenses: isEdit
        ? (prev.expenses || []).map((x) => (x.id === exp.id ? exp : x))
        : [exp, ...(prev.expenses || [])],
    }));
    notify(t.expenseSaved);
  };

  const handleDeleteExpense = (id: string) => {
    setData((prev) => ({ ...prev, expenses: (prev.expenses || []).filter((x) => x.id !== id) }));
  };

  const handleSaveSupplier = (sup: Supplier, isEdit: boolean) => {
    setData((prev) => ({
      ...prev,
      suppliers: isEdit
        ? (prev.suppliers || []).map((s) => (s.id === sup.id ? sup : s))
        : [sup, ...(prev.suppliers || [])],
    }));
    notify(t.supplierSaved);
  };

  const handleDeleteSupplier = (id: string) => {
    setData((prev) => ({ ...prev, suppliers: (prev.suppliers || []).filter((s) => s.id !== id) }));
  };

  const handlePaySupplier = (supId: string, amount: number) => {
    setData((prev) => ({
      ...prev,
      suppliers: (prev.suppliers || []).map((s) =>
        s.id === supId ? { ...s, duePayable: Math.max(0, (s.duePayable || 0) - amount) } : s
      ),
    }));
    notify(t.supplierPaid);
  };

  const handleSaveCategory = (cat: Category, isEdit?: boolean) => {
    setData((prev) => ({
      ...prev,
      categories: isEdit ? prev.categories.map((c) => (c.id === cat.id ? cat : c)) : [...prev.categories, cat],
    }));
    notify(t.categorySaved);
  };

  const handleDeleteCategory = (id: string) => {
    setData((prev) => ({ ...prev, categories: prev.categories.filter((c) => c.id !== id) }));
  };

  const handleSaveSettings = (newSettings: StoreSettings) => {
    const walkInLabel = (newSettings.defaultWalkInName || 'Walk-in Customer').trim();
    setData((prev) => ({
      ...prev,
      settings: { ...newSettings, defaultWalkInName: walkInLabel, language: 'en' },
      customers: prev.customers.map((c) => (c.id === 'walk-in' ? { ...c, name: walkInLabel } : c)),
    }));
    notify(t.settingsSaved);
  };

  const handleResetStorage = (mode: 'empty' | 'demo') => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore storage removal errors
    }
    if (mode === 'empty') {
      setData({
        ...DEFAULT_DATA,
        settings: { ...DEFAULT_DATA.settings },
        categories: DEFAULT_DATA.categories.map((c) => ({ ...c, models: [...c.models] })),
        recentCategories: [],
        categoriesSeededV3: true,
        products: [],
        customers: [{ ...DEFAULT_DATA.customers[0], totalSpent: 0, dueBalance: 0 }],
        suppliers: [],
        expenses: [],
        sales: [],
        movements: [],
        shopSessions: [],
        activeSession: null,
      });
    } else {
      setData(DEFAULT_DATA);
    }
    notify(t.storageResetSuccess);
  };

  const triggerPrintReceipt = (sale: Sale) => {
    setPrintMode({ type: 'receipt', sale });
    setTimeout(() => window.print(), 100);
  };

  const triggerPrintReport = (report: ReportPayload) => {
    setPrintMode({ type: 'report', report });
    setTimeout(() => window.print(), 100);
  };

  const triggerPrintStatement = (statement: SalesStatementPayload) => {
    setPrintMode({ type: 'statement', statement });
    setTimeout(() => window.print(), 100);
  };

  const triggerPrintLabels = (labelData: { items: Product[]; showPrice: boolean; showStore: boolean }) => {
    setPrintMode({ type: 'labels', ...labelData });
    setTimeout(() => window.print(), 100);
  };

  const navGroups: { title: string; items: { id: ViewId; label: string; icon: IconName }[] }[] = [
    {
      title: 'Sales & POS',
      items: [
        { id: 'dashboard', label: t.nav_dashboard, icon: 'dashboard' },
        { id: 'pos', label: t.nav_pos, icon: 'pos' },
        { id: 'sales', label: t.nav_sales, icon: 'sales' },
      ],
    },
    {
      title: 'Inventory',
      items: [
        { id: 'products', label: t.nav_products, icon: 'products' },
        { id: 'stock', label: t.nav_stock, icon: 'stock' },
        { id: 'categories', label: t.nav_categories, icon: 'categories' },
      ],
    },
    {
      title: 'Accounts & Insights',
      items: [
        { id: 'customers', label: t.nav_customers, icon: 'customers' },
        { id: 'expenses', label: t.nav_expenses, icon: 'expenses' },
        { id: 'analytics', label: t.nav_analytics, icon: 'analytics' },
        { id: 'reports', label: t.nav_reports, icon: 'reports' },
      ],
    },
    {
      title: 'System',
      items: [{ id: 'settings', label: t.nav_settings, icon: 'settings' }],
    },
  ];

  const allNavItems = navGroups.flatMap((g) => g.items);
  const currentTitle = allNavItems.find((n) => n.id === view)?.label || t.appName;

  const mobileTabs: { id: ViewId; shortLabel: string; icon: IconName }[] = [
    { id: 'dashboard', shortLabel: 'Home', icon: 'dashboard' },
    { id: 'pos', shortLabel: 'POS', icon: 'pos' },
    { id: 'products', shortLabel: 'Stock', icon: 'products' },
    { id: 'sales', shortLabel: 'Sales', icon: 'sales' },
  ];

  return (
    <>
      <div id="app-root" className="min-h-screen flex bg-[#f4f5f7]">
        {sidebarOpen && <div className="fixed inset-0 z-30 bg-slate-950/50 lg:hidden" onClick={() => setSidebarOpen(false)} />}

        <aside
          className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-slate-950 text-slate-300 flex flex-col transition-transform duration-200 shrink-0 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="px-5 py-4 border-b border-slate-800/80 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {data.settings.storeLogo ? (
                <img src={data.settings.storeLogo} alt="Store logo" className="w-9 h-9 rounded-xl object-contain bg-white p-1 shrink-0" />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-extrabold text-base shrink-0">
                  {(data.settings.storeName || 'M')[0].toUpperCase()}
                </div>
              )}
              <div className="min-w-0">
                <h1 className="font-extrabold text-white text-sm truncate">{data.settings.storeName || t.appName}</h1>
                <p className="text-[11px] text-slate-400 truncate">{t.posSubtitle}</p>
              </div>
            </div>
            <button type="button" onClick={() => setSidebarOpen(false)} className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white">
              <Icon name="x" className="w-4 h-4" />
            </button>
          </div>

          <nav className="flex-1 px-3 py-4 space-y-5 overflow-y-auto custom-scrollbar">
            {navGroups.map((group) => (
              <div key={group.title} className="space-y-1">
                <p className="px-3 text-[11px] font-semibold text-slate-500">{group.title}</p>
                {group.items.map((item) => {
                  const active = view === item.id;
                  return (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => {
                        if (item.id === 'analytics') setAnalyticsInitialTab('sales');
                        setView(item.id);
                        setSidebarOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap ${
                        active
                          ? 'bg-blue-600 text-white font-semibold shadow-[inset_0_1px_0_rgba(255,255,255,0.2),0_2px_8px_rgba(37,99,235,0.35)]'
                          : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                      }`}
                    >
                      <Icon name={item.icon} className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>
        </aside>

        <div className="flex-1 flex flex-col min-w-0 pb-16 lg:pb-0">
          {/* Clean Single-Row Top Header */}
          <header className="bg-white/95 backdrop-blur-sm border-b border-slate-200/90 px-3.5 sm:px-6 py-3 flex items-center justify-between gap-3 sticky top-0 z-20">
            <div className="flex items-center gap-2 min-w-0">
              <button
                type="button"
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden btn-secondary p-2 shrink-0"
                aria-label="Open menu"
              >
                <Icon name="menu" className="w-4 h-4" />
              </button>
              {view !== 'dashboard' && (
                <button
                  type="button"
                  onClick={() => setView('dashboard')}
                  className="btn-secondary px-2.5 py-1.5 text-xs shrink-0"
                  title="Back to Home"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>{t.backHome}</span>
                </button>
              )}
              <h2 className="text-base sm:text-xl font-extrabold text-slate-950 truncate">{currentTitle}</h2>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {data.settings.showClock !== false && (
                <HeaderClockPill settings={data.settings} title={t.clockSettings} onClick={() => setView('settings')} />
              )}

              <ShopTimerButton
                activeOpenedAt={data.activeSession?.openedAt || null}
                pastTodayMs={pastTodayDurationMs}
                title={t.sessionHistory}
                onClick={() => setSessionModalOpen(true)}
              />

              <button
                type="button"
                onClick={toggleShop}
                className={`px-3 py-1.5 text-xs ${data.activeSession ? 'btn-emerald' : 'btn-dark'}`}
              >
                <span>{data.activeSession ? t.closeShop : t.openShop}</span>
              </button>
            </div>
          </header>

          <main className="flex-1 p-4 sm:p-6 max-w-[1440px] w-full mx-auto">
            {view === 'dashboard' && (
              <DashboardView
                data={data}
                t={t}
                onNavigate={setView}
                onViewReceipt={setReceiptSale}
              />
            )}
            {view === 'pos' && (
              <POSView
                data={data}
                t={t}
                onCompleteSale={handleCompleteSale}
                onQuickCreateProduct={handleQuickCreateProduct}
                onTouchRecentCategory={handleTouchRecentCategory}
                notify={notify}
              />
            )}
            {view === 'products' && (
              <ProductsView
                data={data}
                t={t}
                onSaveProduct={handleSaveProduct}
                onDeleteProduct={handleDeleteProduct}
                onPrintLabels={triggerPrintLabels}
                onPrintReport={triggerPrintReport}
                notify={notify}
              />
            )}
            {view === 'stock' && (
              <StockMovementView
                data={data}
                t={t}
                onRecordMovement={handleRecordMovement}
                onQuickCreateProduct={handleQuickCreateProduct}
                notify={notify}
              />
            )}
            {view === 'customers' && (
              <CustomersView
                data={data}
                t={t}
                onSaveCustomer={handleSaveCustomer}
                onDeleteCustomer={handleDeleteCustomer}
                onCollectDue={handleCollectDue}
                notify={notify}
              />
            )}
            {view === 'sales' && (
              <SalesHistoryView
                data={data}
                t={t}
                onViewReceipt={setReceiptSale}
                onEditSale={handleEditSale}
                onDeleteSale={handleDeleteSale}
                notify={notify}
              />
            )}
            {view === 'expenses' && (
              <ExpensesSuppliersView
                data={data}
                t={t}
                onSaveExpense={handleSaveExpense}
                onDeleteExpense={handleDeleteExpense}
                onSaveSupplier={handleSaveSupplier}
                onDeleteSupplier={handleDeleteSupplier}
                onPaySupplier={handlePaySupplier}
                notify={notify}
              />
            )}
            {view === 'analytics' && <AnalyticsView key={analyticsInitialTab} data={data} t={t} initialTab={analyticsInitialTab} />}
            {view === 'reports' && (
              <ReportsView data={data} t={t} onPrintReport={triggerPrintReport} onPrintStatement={triggerPrintStatement} />
            )}
            {view === 'categories' && (
              <CategoriesView data={data} t={t} onSaveCategory={handleSaveCategory} onDeleteCategory={handleDeleteCategory} />
            )}
            {view === 'settings' && (
              <SettingsView
                data={data}
                t={t}
                onSaveSettings={handleSaveSettings}
                onRestoreBackup={setData}
                onResetStorage={handleResetStorage}
                notify={notify}
              />
            )}
          </main>
        </div>

        {/* Mobile Bottom Navigation Bar */}
        <nav className="lg:hidden fixed bottom-0 inset-x-0 z-20 bg-white/95 backdrop-blur-sm border-t border-slate-200 px-2 py-1 grid grid-cols-5 gap-1">
          {mobileTabs.map((tab) => {
            const active = view === tab.id;
            return (
              <button
                type="button"
                key={tab.id}
                onClick={() => setView(tab.id)}
                className={`flex flex-col items-center justify-center py-1.5 rounded-xl text-[11px] font-semibold ${
                  active ? 'text-blue-600 bg-blue-50' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon name={tab.icon} className="w-4 h-4 mb-0.5" />
                <span>{tab.shortLabel}</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setSidebarOpen(true)}
            className="flex flex-col items-center justify-center py-1.5 rounded-xl text-[11px] font-semibold text-slate-500 hover:text-slate-800"
          >
            <Icon name="menu" className="w-4 h-4 mb-0.5" />
            <span>More</span>
          </button>
        </nav>
      </div>

      {/* Receipt Preview Modal */}
      <Modal open={!!receiptSale} onClose={() => setReceiptSale(null)} title={t.viewReceipt} maxWidth="max-w-md">
        {receiptSale && (
          <div className="space-y-4">
            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 p-2">
              <ReceiptContent sale={receiptSale} settings={data.settings} t={t} />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setReceiptSale(null)} className="btn-secondary px-4 py-2 text-sm">
                {t.close}
              </button>
              <button type="button" onClick={() => triggerPrintReceipt(receiptSale)} className="btn-primary px-5 py-2 text-sm">
                <Icon name="print" className="w-4 h-4" />
                <span>{t.print}</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Shop Sessions History Modal */}
      <Modal open={sessionModalOpen} onClose={() => setSessionModalOpen(false)} title={t.sessionHistory} maxWidth="max-w-2xl">
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-sm">
            <SessionModalLiveDuration
              activeOpenedAt={data.activeSession?.openedAt || null}
              pastTodayMs={pastTodayDurationMs}
              label={t.todayHours}
            />
            <button
              type="button"
              onClick={() => {
                setSessionModalOpen(false);
                setAnalyticsInitialTab('time');
                setView('analytics');
              }}
              className="btn-primary px-3.5 py-1.5 text-xs"
            >
              {t.timeAnalysisTab} →
            </button>
          </div>
          <p className="text-xs text-slate-500">{t.auto24hNote}</p>
          {!data.activeSession && (data.shopSessions || []).length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">{t.noSessions}</p>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-xs text-left tabular-nums">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-2.5 whitespace-nowrap">{t.openedAt}</th>
                    <th className="px-3 py-2.5 whitespace-nowrap">{t.closedAt}</th>
                    <th className="px-3 py-2.5 text-right whitespace-nowrap">{t.duration}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {data.activeSession && (
                    <ActiveSessionLiveRow openedAt={data.activeSession.openedAt} activeNowLabel={t.activeNow} />
                  )}
                  {(data.shopSessions || []).map((s) => (
                    <tr key={s.id}>
                      <td className="px-3 py-2.5">{fmtDateTime(s.openedAt)}</td>
                      <td className="px-3 py-2.5">{fmtDateTime(s.closedAt)}</td>
                      <td className="px-3 py-2.5 text-right font-mono font-semibold">{fmtDuration(s.durationMs || 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </Modal>

      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-20 lg:bottom-5 right-4 sm:right-5 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-bold text-white transition-all ${
            toast.type === 'error' ? 'bg-rose-600' : 'bg-emerald-600'
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* Dedicated Print Root */}
      <div id="print-root" className="p-4 bg-white text-slate-900">
        {printMode?.type === 'receipt' && <ReceiptContent sale={printMode.sale} settings={data.settings} t={t} />}
        {printMode?.type === 'labels' && (
          <BarcodeLabelSheet
            items={printMode.items}
            settings={data.settings}
            showPrice={printMode.showPrice}
            showStore={printMode.showStore}
          />
        )}
        {printMode?.type === 'statement' && (
          <SheetContent target={{ kind: 'statement', statement: printMode.statement }} settings={data.settings} />
        )}
        {printMode?.type === 'report' && (
          <SheetContent target={{ kind: 'report', report: printMode.report }} settings={data.settings} />
        )}
      </div>
    </>
  );
}
