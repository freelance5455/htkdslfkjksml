import { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Coins,
  Download,
  FileCode2,
  Globe,
  KeyRound,
  Layers,
  Loader2,
  PackageCheck,
  ShieldCheck,
  Sliders,
  Sparkles,
} from 'lucide-react';
import type {
  ApkBuildConfig,
  BuildArtifactSummary,
  UrlInspectionResult,
} from './types/apk';
import {
  HTML_STARTER_TEMPLATES,
  templateToAssetFiles,
} from './lib/templates';
import { renderMonogramIconBase64 } from './lib/iconCanvas';
import { compileApkOfflineInBrowser } from './lib/offlineBuilder';
import { useOnlineStatus } from './hooks/usePWAInstall';
import { SourceConfigSection } from './components/SourceConfigSection';
import {
  IdentityIconSection,
  PermissionsSdkSection,
  RuntimeConfigSection,
  SigningConfigSection,
} from './components/IdentityAndRuntimeSections';
import { SplashScreenSection } from './components/SplashScreenSection';
import { MonetizationEventsSection } from './components/MonetizationEventsSection';
import { DeveloperLinksSection } from './components/DeveloperLinksSection';
import { DevicePreviewPanel } from './components/DevicePreviewPanel';
import { BuildHistoryView } from './components/BuildHistoryView';
import { SigningGuideView } from './components/SigningGuideView';
import {
  OfflineStatusBanner,
  PWAInstallButton,
} from './components/PWAInstallButton';

type TopView = 'builder' | 'templates' | 'history' | 'guide';
type BuilderStep =
  | 'source'
  | 'identity'
  | 'splash'
  | 'runtime'
  | 'permissions'
  | 'monetization'
  | 'developer'
  | 'signing';

const DEFAULT_RAW_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My HTML App</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, sans-serif; }
    body { background: #f8fafc; color: #0f172a; padding: 24px; min-height: 100vh; display: flex; flex-direction: column; gap: 16px; }
    .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 18px; }
    h1 { font-size: 20px; font-weight: 700; }
    p { font-size: 14px; color: #475569; margin-top: 6px; line-height: 1.5; }
    button { margin-top: 12px; background: #16a34a; color: #fff; border: 0; padding: 10px 16px; border-radius: 8px; font-weight: 600; font-size: 14px; cursor: pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Instant HTML-to-APK</h1>
    <p>Edit this HTML directly and click Build APK to package it into an offline Android app.</p>
    <button onclick="document.getElementById('out').textContent='Running inside Android WebView!'">Test Interaction</button>
    <p id="out" style="font-weight:600;color:#16a34a;"></p>
  </div>
</body>
</html>`;

const DEFAULT_CONFIG: ApkBuildConfig = {
  sourceMode: 'url',
  websiteUrl: 'https://example.com',
  rawHtmlCode: DEFAULT_RAW_HTML,
  htmlEntryFile: 'index.html',
  htmlFiles: templateToAssetFiles(HTML_STARTER_TEMPLATES[0]),
  appName: 'Example Web App',
  packageId: 'com.example.webapp',
  versionName: '1.0.0',
  versionCode: 1,
  minSdkVersion: 24,
  targetSdkVersion: 34,
  themeColor: '#16A34A',
  statusBarStyle: 'light',
  orientation: 'unspecified',
  fullscreen: false,
  enableJavaScript: true,
  enableDomStorage: true,
  enableZoomControls: true,
  pullToRefresh: true,
  allowCleartextTraffic: false,
  customUserAgent: '',
  permissions: ['INTERNET', 'ACCESS_NETWORK_STATE'],
  signingOrg: 'Web2APK Studio',
  signingAlias: 'release-key',
  splash: {
    enabled: true,
    backgroundColor: '#0F172A',
    textColor: '#FFFFFF',
    headline: 'Example Web App',
    tagline: 'Loading experience...',
    durationMs: 1400,
    showSpinner: true,
    logoScale: 'md',
  },
  enablePlayBilling: false,
  enableRemoveAds: false,
  removeAdsSku: 'remove_ads_lifetime',
  removeAdsPrice: '$2.99',
  currencyName: 'Coins',
  billingProducts: [
    {
      sku: 'coins_500',
      type: 'consumable',
      label: '500 Coins',
      priceDisplay: '$0.99',
      currencyAmount: 500,
    },
    {
      sku: 'pro_upgrade',
      type: 'inapp',
      label: 'Pro Unlock',
      priceDisplay: '$4.99',
    },
  ],
  enableAdMob: false,
  adMobAppId: 'ca-app-pub-3940256099942544~3347511713',
  adMobBannerUnitId: 'ca-app-pub-3940256099942544/6300978111',
  adMobInterstitialUnitId: 'ca-app-pub-3940256099942544/1033173712',
  adMobRewardedUnitId: 'ca-app-pub-3940256099942544/5224354917',
  showBottomBanner: true,
  enableLaunchEvents: true,
  enableFirebaseAnalytics: false,
  launchWebhookUrl: '',
  customLaunchEvents: ['app_open', 'session_start'],
  developer: {
    developerName: 'Web2APK Studio Developer',
    supportEmail: 'support@example.com',
    websiteUrl: 'https://example.com',
    privacyPolicyUrl: 'https://example.com/privacy',
    termsUrl: '',
    githubUrl: '',
    xTwitterUrl: '',
    youtubeUrl: '',
    discordUrl: '',
    instagramUrl: '',
    tiktokUrl: '',
    includeAboutPageInAssets: true,
  },
};

const BUILDER_STEPS: {
  id: BuilderStep;
  label: string;
  title: string;
  icon: typeof FileCode2;
}[] = [
  {
    id: 'source',
    label: '01. Source Input',
    title: 'Website URL, HTML Code or Bundle',
    icon: FileCode2,
  },
  {
    id: 'identity',
    label: '02. Identity & Icon',
    title: 'Application Identity & Launcher Icon',
    icon: Layers,
  },
  {
    id: 'splash',
    label: '03. Splash Screen',
    title: 'Launch Splash Screen Editor',
    icon: Sparkles,
  },
  {
    id: 'runtime',
    label: '04. WebView Runtime',
    title: 'WebView Engine & Behavior',
    icon: Sliders,
  },
  {
    id: 'permissions',
    label: '05. Permissions & SDK',
    title: 'Android SDK Targets & Permissions',
    icon: ShieldCheck,
  },
  {
    id: 'monetization',
    label: '06. Monetization & Store',
    title: 'Remove Ads, Products, Currency & Events',
    icon: Coins,
  },
  {
    id: 'developer',
    label: '07. Developer & Links',
    title: 'Developer Profile, Socials & Support',
    icon: Globe,
  },
  {
    id: 'signing',
    label: '08. Signing & Output',
    title: 'Certificate Signing & Export',
    icon: KeyRound,
  },
];

export default function App() {
  const isOnline = useOnlineStatus();
  const [topView, setTopView] = useState<TopView>('builder');
  const [activeStep, setActiveStep] = useState<BuilderStep>('source');
  const [config, setConfig] = useState<ApkBuildConfig>(DEFAULT_CONFIG);
  const [splashNonce, setSplashNonce] = useState(0);

  const [inspection, setInspection] = useState<UrlInspectionResult | null>(null);
  const [inspecting, setInspecting] = useState(false);
  const [inspectError, setInspectError] = useState<string | null>(null);

  const [building, setBuilding] = useState(false);
  const [buildError, setBuildError] = useState<string | null>(null);
  const [builds, setBuilds] = useState<BuildArtifactSummary[]>([]);
  const [latestBuild, setLatestBuild] = useState<BuildArtifactSummary | null>(null);

  useEffect(() => {
    if (!isOnline) return;
    fetch('/api/builds')
      .then((res) => (res.ok ? res.json() : []))
      .then((data: BuildArtifactSummary[]) => {
        if (Array.isArray(data) && data.length > 0) {
          setBuilds(data);
          setLatestBuild(data[0]);
        }
      })
      .catch(() => {
        // Offline or server unavailable
      });
  }, [isOnline]);

  const previewIconUrl = useMemo(() => {
    if (config.iconBase64Png) {
      return `data:image/png;base64,${config.iconBase64Png}`;
    }
    return '';
  }, [config.iconBase64Png]);

  const updateConfig = (patch: Partial<ApkBuildConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
  };

  const handleInspectUrl = async () => {
    if (!isOnline) {
      setInspectError(
        'URL inspection requires an internet connection. You can still build URL wrapper APKs offline or switch to Paste HTML Code / HTML Bundle mode.'
      );
      return;
    }
    setInspecting(true);
    setInspectError(null);
    try {
      const res = await fetch('/api/inspect-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: config.websiteUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setInspectError(data.error || 'Could not inspect URL.');
        return;
      }
      const info = data as UrlInspectionResult;
      setInspection(info);

      setConfig((prev) => ({
        ...prev,
        websiteUrl: info.finalUrl,
        appName: info.title || prev.appName,
        packageId: info.suggestedPackageId || prev.packageId,
        themeColor: info.themeColor || prev.themeColor,
        allowCleartextTraffic: !info.isHttps,
        iconBase64Png: info.faviconBase64Png || prev.iconBase64Png,
        splash: {
          ...prev.splash,
          headline: info.title || prev.splash.headline,
        },
      }));
    } catch {
      setInspectError('Network error while inspecting target website.');
    } finally {
      setInspecting(false);
    }
  };

  const handleBuildApk = async () => {
    setBuilding(true);
    setBuildError(null);
    setTopView('builder');

    const resolvedIcon =
      config.iconBase64Png ||
      renderMonogramIconBase64(config.appName, config.themeColor, 192);

    const payload: ApkBuildConfig = {
      ...config,
      iconBase64Png: resolvedIcon,
    };

    try {
      let artifact: BuildArtifactSummary | null = null;

      if (isOnline) {
        try {
          const res = await fetch('/api/build', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
          const data = await res.json();
          if (!res.ok) {
            setBuildError(data.error || 'APK compilation failed.');
            return;
          }
          artifact = data as BuildArtifactSummary;
        } catch {
          artifact = await compileApkOfflineInBrowser(payload);
        }
      } else {
        artifact = await compileApkOfflineInBrowser(payload);
      }

      if (artifact) {
        setLatestBuild(artifact);
        setBuilds((prev) => [
          artifact!,
          ...prev.filter((b) => b.id !== artifact!.id),
        ]);
      }
    } catch (err) {
      setBuildError(
        err instanceof Error ? err.message : 'APK compilation failed.'
      );
    } finally {
      setBuilding(false);
    }
  };

  const handleApplyTemplate = (templateId: string) => {
    const tpl = HTML_STARTER_TEMPLATES.find((t) => t.id === templateId);
    if (!tpl) return;
    setConfig((prev) => ({
      ...prev,
      sourceMode: 'html',
      htmlFiles: templateToAssetFiles(tpl),
      htmlEntryFile: tpl.entryFile,
      appName: tpl.name,
      packageId: tpl.packageId,
      themeColor: tpl.themeColor,
      iconBase64Png: renderMonogramIconBase64(tpl.name, tpl.themeColor, 192),
      splash: {
        ...prev.splash,
        headline: tpl.name,
        backgroundColor: tpl.themeColor,
      },
    }));
    setTopView('builder');
    setActiveStep('source');
  };

  const currentStepMeta =
    BUILDER_STEPS.find((s) => s.id === activeStep) || BUILDER_STEPS[0];

  const latestFilenameSlug = latestBuild
    ? latestBuild.appName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'app'
    : 'app';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Three-Zone Top Bar Contract */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-[1440px] mx-auto px-6 h-14 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setTopView('builder')}
            className="text-base font-display font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Web2APK Studio
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            {(
              [
                { id: 'builder', label: 'Builder' },
                { id: 'templates', label: 'Templates' },
                { id: 'history', label: 'Build History' },
                { id: 'guide', label: 'Signing Guide' },
              ] as const
            ).map((nav) => (
              <button
                key={nav.id}
                type="button"
                onClick={() => setTopView(nav.id)}
                className={`py-1 whitespace-nowrap shrink-0 transition-colors hover:text-slate-900 ${
                  topView === nav.id
                    ? 'text-slate-900 underline underline-offset-8 decoration-2 decoration-emerald-600'
                    : ''
                }`}
              >
                {nav.label}
              </button>
            ))}
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => void handleBuildApk()}
              disabled={building}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0"
            >
              {building ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Compiling APK
                </>
              ) : (
                <>
                  <PackageCheck className="w-3.5 h-3.5" />
                  Build APK
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-[1440px] w-full mx-auto px-6 py-6">
        <OfflineStatusBanner />

        {/* Mobile Nav Fallback */}
        <div className="flex md:hidden items-center gap-1 p-1 bg-slate-200/70 rounded-lg mb-5 overflow-x-auto">
          {(
            [
              { id: 'builder', label: 'Builder' },
              { id: 'templates', label: 'Templates' },
              { id: 'history', label: 'History' },
              { id: 'guide', label: 'Guide' },
            ] as const
          ).map((nav) => (
            <button
              key={nav.id}
              type="button"
              onClick={() => setTopView(nav.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                topView === nav.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600'
              }`}
            >
              {nav.label}
            </button>
          ))}
        </div>

        {/* Compiled Artifact Banner */}
        {latestBuild && topView === 'builder' && (
          <div className="mb-6 bg-white border border-emerald-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-display font-semibold text-slate-900">
                  {latestBuild.appName} v{latestBuild.versionName} compiled and signed
                </div>
                <div className="text-xs text-slate-600 mt-0.5 font-mono tabular-nums flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span>{latestBuild.packageId}</span>
                  <span aria-hidden="true">·</span>
                  <span>{(latestBuild.apkSizeBytes / 1024).toFixed(1)} KB APK</span>
                  <span aria-hidden="true">·</span>
                  <span>SHA-256 {latestBuild.sha256.slice(0, 14)}...</span>
                  {latestBuild.builtOffline && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>Compiled locally offline</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <a
                href={latestBuild.apkBlobUrl || `/api/builds/${latestBuild.id}/apk`}
                download={`${latestFilenameSlug}-v${latestBuild.versionName}.apk`}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" />
                Download .APK ({(latestBuild.apkSizeBytes / 1024).toFixed(1)} KB)
              </a>
              <a
                href={
                  latestBuild.gradleBlobUrl ||
                  `/api/builds/${latestBuild.id}/gradle`
                }
                download={`${latestFilenameSlug}-android-studio.zip`}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" />
                Android Studio .ZIP ({(latestBuild.gradleSizeBytes / 1024).toFixed(1)} KB)
              </a>
            </div>
          </div>
        )}

        {buildError && topView === 'builder' && (
          <div className="mb-6 p-4 rounded-xl border border-red-200 bg-red-50 text-sm text-red-700">
            {buildError}
          </div>
        )}

        {topView === 'builder' && (
          <div className="grid grid-cols-1 lg:grid-cols-[240px_minmax(0,1fr)_370px] gap-6 items-start">
            {/* Left Workspace Sidebar */}
            <aside className="bg-white border border-slate-200 rounded-xl p-2 space-y-1">
              {BUILDER_STEPS.map((step) => {
                const Icon = step.icon;
                const active = activeStep === step.id;
                return (
                  <button
                    key={step.id}
                    type="button"
                    onClick={() => setActiveStep(step.id)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-left text-xs font-medium transition-colors ${
                      active
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{step.label}</span>
                  </button>
                );
              })}

              <div className="pt-3 mt-3 border-t border-slate-100 px-3 pb-2 text-[11px] text-slate-500 space-y-1 tabular-nums">
                <div className="font-medium text-slate-700 truncate">
                  {config.appName}
                </div>
                <div className="font-mono truncate">{config.packageId}</div>
                <div>
                  {config.sourceMode === 'url'
                    ? 'Website URL Wrapper'
                    : config.sourceMode === 'code'
                      ? 'Direct HTML Code'
                      : `${config.htmlFiles.length} Offline Asset${
                          config.htmlFiles.length === 1 ? '' : 's'
                        }`}
                </div>
                <div className="pt-2">
                  <PWAInstallButton />
                </div>
              </div>
            </aside>

            {/* Center Configuration Editor */}
            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-slate-500">
                    Workspace / Android Builder / {currentStepMeta.label}
                  </div>
                  <h1 className="text-base font-display font-semibold text-slate-900 mt-0.5">
                    {currentStepMeta.title}
                  </h1>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {activeStep !== 'signing' ? (
                    <button
                      type="button"
                      onClick={() => {
                        const idx = BUILDER_STEPS.findIndex(
                          (s) => s.id === activeStep
                        );
                        if (idx >= 0 && idx < BUILDER_STEPS.length - 1) {
                          setActiveStep(BUILDER_STEPS[idx + 1].id);
                        }
                      }}
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200/70 transition-colors whitespace-nowrap"
                    >
                      Next Step
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void handleBuildApk()}
                      disabled={building}
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 rounded-md hover:bg-emerald-700 disabled:opacity-60 transition-colors whitespace-nowrap"
                    >
                      {building ? 'Compiling...' : 'Compile Signed APK'}
                    </button>
                  )}
                </div>
              </div>

              <div className="p-6">
                {activeStep === 'source' && (
                  <SourceConfigSection
                    config={config}
                    inspection={inspection}
                    inspecting={inspecting}
                    inspectError={inspectError}
                    onChange={updateConfig}
                    onInspectUrl={() => void handleInspectUrl()}
                  />
                )}
                {activeStep === 'identity' && (
                  <IdentityIconSection
                    config={config}
                    previewIconUrl={previewIconUrl}
                    onChange={updateConfig}
                  />
                )}
                {activeStep === 'splash' && (
                  <SplashScreenSection
                    config={config}
                    previewIconUrl={previewIconUrl}
                    onChange={updateConfig}
                    onTriggerSplashPreview={() => setSplashNonce((n) => n + 1)}
                  />
                )}
                {activeStep === 'runtime' && (
                  <RuntimeConfigSection
                    config={config}
                    onChange={updateConfig}
                  />
                )}
                {activeStep === 'permissions' && (
                  <PermissionsSdkSection
                    config={config}
                    onChange={updateConfig}
                  />
                )}
                {activeStep === 'monetization' && (
                  <MonetizationEventsSection
                    config={config}
                    onChange={updateConfig}
                  />
                )}
                {activeStep === 'developer' && (
                  <DeveloperLinksSection
                    config={config}
                    onChange={updateConfig}
                  />
                )}
                {activeStep === 'signing' && (
                  <SigningConfigSection
                    config={config}
                    onChange={updateConfig}
                  />
                )}
              </div>
            </section>

            {/* Right Live Android Device Preview & Inspector */}
            <DevicePreviewPanel
              config={config}
              inspection={inspection}
              latestBuild={latestBuild}
              previewIconUrl={previewIconUrl}
              splashNonce={splashNonce}
            />
          </div>
        )}

        {topView === 'templates' && (
          <section className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="max-w-2xl mb-6">
              <h1 className="text-lg font-display font-semibold text-slate-900">
                Offline HTML5 Starter Bundles
              </h1>
              <p className="text-sm text-slate-600 mt-1">
                Load a complete multi-file HTML, CSS, and JavaScript starter app into the builder to test offline APK compilation and live Android WebView execution.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {HTML_STARTER_TEMPLATES.map((tpl) => (
                <div
                  key={tpl.id}
                  className="p-5 rounded-xl border border-slate-200 flex flex-col justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-display font-bold text-sm shrink-0"
                        style={{ backgroundColor: tpl.themeColor }}
                      >
                        {tpl.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h2 className="text-sm font-display font-semibold text-slate-900">
                          {tpl.name}
                        </h2>
                        <div className="text-xs font-mono text-slate-500">
                          {tpl.packageId}
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {tpl.summary}
                    </p>
                    <div className="mt-3 text-xs text-slate-500 font-mono">
                      {tpl.files.length} bundled file{tpl.files.length === 1 ? '' : 's'} · Entry {tpl.entryFile}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleApplyTemplate(tpl.id)}
                    className="w-full py-2 px-4 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap"
                  >
                    Load into APK Builder
                  </button>
                </div>
              ))}
            </div>
          </section>
        )}

        {topView === 'history' && (
          <BuildHistoryView
            builds={builds}
            onStartNewBuild={() => setTopView('builder')}
            onClearHistory={() => {
              setBuilds([]);
              setLatestBuild(null);
            }}
          />
        )}

        {topView === 'guide' && <SigningGuideView />}
      </main>
    </div>
  );
}
