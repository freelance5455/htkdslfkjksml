import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BoardTile, 
  GameMode, 
  LevelConfig, 
  PlayerStats, 
  CollectionItem 
} from './types';
import { generateLevel } from './game/levelGenerator';
import { generateLongArrowLevel } from './game/longArrowGenerator';
import { checkEscapePath, getRotatedDirection, findSolvableHint } from './game/pathSolver';
import { audioManager } from './services/audioManager';
import { voiceManager } from './services/voiceManager';
import { hapticManager } from './services/hapticManager';
import { saveManager } from './services/saveManager';
import { adManager, AdReward, AdType } from './services/adManager';

import { MainMenu } from './components/MainMenu';
import { GameBoard } from './components/GameBoard';
import { GameHud } from './components/GameHud';
import { WinModal } from './components/WinModal';
import { FailModal } from './components/FailModal';
import { TimesUpModal } from './components/TimesUpModal';
import { CollectionModal } from './components/CollectionModal';
import { SettingsModal } from './components/SettingsModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { AdModal } from './components/AdModal';
import { BannerAd } from './components/BannerAd';

type AppScreen = 'MENU' | 'GAMEPLAY' | 'COLLECTION';

/**
 * Dynamically resolves arrow color theme to match the current level's design
 * when the premium "DESIGN MATCH" theme is equipped.
 */
function getDesignMatchSkin(designName: string): string {
  const lower = (designName || '').toLowerCase();
  if (lower.includes('earth') || lower.includes('planet') || lower.includes('saturn') || lower.includes('ocean')) return 'cyan';
  if (lower.includes('duck') || lower.includes('bird') || lower.includes('rooster') || lower.includes('sun')) return 'gold';
  if (lower.includes('house') || lower.includes('castle') || lower.includes('fortress')) return 'brown';
  if (lower.includes('heart') || lower.includes('flower') || lower.includes('cherry')) return 'coral';
  if (lower.includes('tree') || lower.includes('cactus') || lower.includes('leaf') || lower.includes('frog') || lower.includes('turtle')) return 'lime';
  if (lower.includes('car') || lower.includes('airplane') || lower.includes('rocket') || lower.includes('robot')) return 'silver';
  if (lower.includes('cat') || lower.includes('lion') || lower.includes('dog') || lower.includes('fox')) return 'orange';
  if (lower.includes('dragon') || lower.includes('ghost') || lower.includes('sword') || lower.includes('alien')) return 'violet';
  if (lower.includes('person') || lower.includes('star') || lower.includes('crown')) return 'magenta';
  if (lower.includes('elephant') || lower.includes('penguin')) return 'navy';
  return 'teal';
}

export default function App() {
  // Persistence states
  const [stats, setStats] = useState<PlayerStats>(() => saveManager.loadStats());
  const [settings, setSettings] = useState(() => saveManager.loadSettings());

  // Screen routing & Game Mode
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('MENU');
  const [gameMode, setGameMode] = useState<GameMode>('SHORT_ARROW');

  // Modals
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showDailyRewardModal, setShowDailyRewardModal] = useState(false);
  const [showWinModal, setShowWinModal] = useState(false);
  const [showFailModal, setShowFailModal] = useState(false);
  const [showTimesUpModal, setShowTimesUpModal] = useState(false);

  // AdMob Modal state
  const [adModalState, setAdModalState] = useState<{
    showing: boolean;
    type: AdType;
    reward: AdReward | null;
  }>({ showing: false, type: 'rewarded', reward: null });

  // Active level & gameplay states
  const [currentLevelNumber, setCurrentLevelNumber] = useState(1);
  const [levelConfig, setLevelConfig] = useState<LevelConfig>(() => generateLevel(1));
  const [tiles, setTiles] = useState<BoardTile[]>([]);
  const [moveHistory, setMoveHistory] = useState<BoardTile[][]>([]);
  const [movesCount, setMovesCount] = useState(0);
  const [timeSeconds, setTimeSeconds] = useState(0);
  const [timedChallengeCountdown, setTimedChallengeCountdown] = useState<number>(60);
  const [blockedTileId, setBlockedTileId] = useState<string | null>(null);

  // Combo system
  const [comboCount, setComboCount] = useState(1);
  const [maxCombo, setMaxCombo] = useState(1);
  const [comboReactionText, setComboReactionText] = useState<string | null>(null);
  const lastEscapeTimeRef = useRef<number>(0);
  const comboTimerRef = useRef<any>(null);

  // Level Win stats
  const [lastCoinsEarned, setLastCoinsEarned] = useState(25);
  const [lastEarnedStars, setLastEarnedStars] = useState(3);

  // Save on stats or settings update
  useEffect(() => {
    saveManager.saveStats(stats);
  }, [stats]);

  useEffect(() => {
    saveManager.saveSettings(settings);
    audioManager.setMusicEnabled(settings.musicEnabled);
  }, [settings]);

  // Subscribe to AdManager events
  useEffect(() => {
    return adManager.subscribe((isShowing, adType) => {
      if (isShowing && adType) {
        setAdModalState({
          showing: true,
          type: adType,
          reward: adManager.getPendingReward(),
        });
      } else {
        setAdModalState({ showing: false, type: 'rewarded', reward: null });
      }
    });
  }, []);

  // Show App Open Ad on launch
  useEffect(() => {
    if (!adManager.hasAppOpenShown()) {
      adManager.showAppOpenAd();
    }
  }, []);

  // Regular elapsed timer
  useEffect(() => {
    if (currentScreen !== 'GAMEPLAY' || showWinModal || showFailModal || showTimesUpModal || adModalState.showing) return;
    const interval = setInterval(() => {
      setTimeSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [currentScreen, showWinModal, showFailModal, showTimesUpModal, adModalState.showing]);

  // Universal countdown timer running on EVERY level
  useEffect(() => {
    if (
      currentScreen !== 'GAMEPLAY' ||
      showWinModal ||
      showTimesUpModal ||
      adModalState.showing
    ) {
      return;
    }

    const timer = setInterval(() => {
      setTimedChallengeCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Play audio warning & trigger Time's Up modal
          audioManager.playSfx('blocked', settings.soundEnabled);
          hapticManager.vibrate('blocked', settings.vibrationEnabled);
          setShowTimesUpModal(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentScreen, showWinModal, showTimesUpModal, adModalState.showing, settings.soundEnabled, settings.vibrationEnabled]);

  // Daily reward check
  const todayDateStr = new Date().toISOString().split('T')[0];
  const canClaimDaily = stats.lastDailyRewardDate !== todayDateStr;

  // Start a specific level in either SHORT_ARROW or LONG_ARROW mode
  const startLevel = useCallback((levelNum: number, mode: GameMode = 'SHORT_ARROW') => {
    const cfg = mode === 'LONG_ARROW' 
      ? generateLongArrowLevel(levelNum)
      : generateLevel(levelNum);

    setLevelConfig(cfg);
    setTiles(JSON.parse(JSON.stringify(cfg.tiles)));
    setCurrentLevelNumber(levelNum);
    setGameMode(mode);
    setMovesCount(0);
    setTimeSeconds(0);
    // Visible countdown timer initialized for every level
    setTimedChallengeCountdown(cfg.timeLimit || (mode === 'LONG_ARROW' ? 60 : 75));
    setMoveHistory([]);
    setComboCount(1);
    setMaxCombo(1);
    setComboReactionText(null);
    setShowWinModal(false);
    setShowFailModal(false);
    setShowTimesUpModal(false);
    setCurrentScreen('GAMEPLAY');
  }, []);

  // Handle tile tap interaction
  const handleTileTap = (tile: BoardTile) => {
    if (tile.isEscaping || adModalState.showing || showTimesUpModal) return;

    // Check escape path
    const checkResult = checkEscapePath(tile, tiles, levelConfig.gridWidth, levelConfig.gridHeight);

    if (checkResult.canEscape) {
      // 1. Success escape!
      audioManager.playSfx('escape', settings.soundEnabled, comboCount);
      hapticManager.vibrate('escape', settings.vibrationEnabled);

      // Record snapshot for Undo
      setMoveHistory((prev) => [...prev, JSON.parse(JSON.stringify(tiles))]);
      setMovesCount((m) => m + 1);

      // Handle Combo timing (chain within 1800ms)
      const now = Date.now();
      let currentCombo = 1;
      if (now - lastEscapeTimeRef.current < 1800) {
        currentCombo = comboCount + 1;
        audioManager.playSfx('combo', settings.soundEnabled, currentCombo);
        hapticManager.vibrate('combo', settings.vibrationEnabled);

        if (currentCombo >= 3) {
          voiceManager.speak('combo', settings.voiceEnabled);
        } else if (currentCombo === 2) {
          voiceManager.speak('good_move', settings.voiceEnabled);
        }

        const praises = ['Nice!', 'Great!', 'Awesome!', 'AMAZING!', 'FANTASTIC!'];
        const reaction = praises[Math.min(currentCombo - 2, praises.length - 1)];
        setComboReactionText(reaction);
      } else {
        setComboReactionText(null);
      }

      lastEscapeTimeRef.current = now;
      setComboCount(currentCombo);
      setMaxCombo((prev) => Math.max(prev, currentCombo));

      if (comboTimerRef.current) clearTimeout(comboTimerRef.current);
      comboTimerRef.current = setTimeout(() => {
        setComboCount(1);
        setComboReactionText(null);
      }, 2200);

      // Trigger escape animation
      setTiles((prev) =>
        prev.map((t) => (t.id === tile.id ? { ...t, isEscaping: true } : t))
      );

      // Remove from board after escape slide completes
      setTimeout(() => {
        setTiles((prev) => {
          const updated = prev.filter((t) => t.id !== tile.id);
          const remainingArrows = updated.filter((t) => t.type === 'ARROW');
          if (remainingArrows.length === 0) {
            handleLevelWin(movesCount + 1, currentCombo);
          }

          return updated;
        });
      }, 420);
    } else {
      // 2. Blocked interaction
      if (tile.isRotator) {
        const nextDir = getRotatedDirection(tile.direction || 'UP');
        audioManager.playSfx('rotate', settings.soundEnabled);
        setTiles((prev) =>
          prev.map((t) => (t.id === tile.id ? { ...t, direction: nextDir } : t))
        );
      } else {
        audioManager.playSfx('blocked', settings.soundEnabled);
        hapticManager.vibrate('blocked', settings.vibrationEnabled);
        setBlockedTileId(tile.id);
        setTimeout(() => setBlockedTileId(null), 250);
      }
    }
  };

  // Level Win handler
  const handleLevelWin = (finalMoves: number, comboPeak: number) => {
    let stars = 1;
    if (finalMoves <= levelConfig.starThresholds.threeStarMoves) {
      stars = 3;
    } else if (finalMoves <= levelConfig.starThresholds.twoStarMoves) {
      stars = 2;
    }

    // Award coin rewards
    const baseCoins = 50;
    const starCoins = stars * 15;
    const comboCoins = Math.min(comboPeak * 5, 30);
    const totalCoins = baseCoins + starCoins + comboCoins;

    setLastCoinsEarned(totalCoins);
    setLastEarnedStars(stars);

    audioManager.playSfx('win', settings.soundEnabled);
    hapticManager.vibrate('win', settings.vibrationEnabled);

    if (stars === 3) {
      voiceManager.speak('three_stars', settings.voiceEnabled);
    } else {
      voiceManager.speak('level_complete', settings.voiceEnabled);
    }

    // Update player stats for the corresponding gameplay mode
    setStats((prev) => {
      const isLong = gameMode === 'LONG_ARROW';
      const completedRecord = isLong ? { ...prev.completedLongLevels } : { ...prev.completedShortLevels };
      const existing = completedRecord[currentLevelNumber];
      const bestStars = existing ? Math.max(existing.stars, stars) : stars;
      const bestMoves = existing ? Math.min(existing.bestMoves, finalMoves) : finalMoves;
      const bestTime = existing ? Math.min(existing.bestTime, timeSeconds) : timeSeconds;

      completedRecord[currentLevelNumber] = { stars: bestStars, bestMoves, bestTime };

      const nextShortHighest = !isLong 
        ? Math.max(prev.highestShortArrowLevel || 1, currentLevelNumber + 1)
        : prev.highestShortArrowLevel;

      const nextLongHighest = isLong 
        ? Math.max(prev.highestLongArrowLevel || 1, currentLevelNumber + 1)
        : prev.highestLongArrowLevel;

      return {
        ...prev,
        coins: prev.coins + totalCoins,
        highestShortArrowLevel: nextShortHighest,
        highestLongArrowLevel: nextLongHighest,
        completedShortLevels: isLong ? prev.completedShortLevels : completedRecord,
        completedLongLevels: isLong ? completedRecord : prev.completedLongLevels,
        highestUnlockedLevel: nextShortHighest,
      };
    });

    // Display win modal
    setTimeout(() => {
      setShowWinModal(true);
    }, 380);
  };

  // Rewarded Video: Extra Undo
  const handleFreeUndoAd = () => {
    adManager.showRewardedAd({ type: 'undo', amount: 3 }, (success, reward) => {
      if (success && reward) {
        audioManager.playSfx('coin', settings.soundEnabled);
        setStats((prev) => ({ ...prev, undosRemaining: prev.undosRemaining + reward.amount }));
      }
    });
  };

  // Undo move
  const handleUndo = () => {
    if (moveHistory.length === 0) return;
    if (stats.undosRemaining <= 0) {
      handleFreeUndoAd();
      return;
    }

    audioManager.playSfx('undo', settings.soundEnabled);
    const lastState = moveHistory[moveHistory.length - 1];
    setTiles(lastState);
    setMoveHistory((prev) => prev.slice(0, -1));
    setMovesCount((m) => Math.max(0, m - 1));
    setStats((prev) => ({ ...prev, undosRemaining: Math.max(0, prev.undosRemaining - 1) }));
  };

  // Rewarded Video: Extra Hint
  const handleFreeHintAd = () => {
    adManager.showRewardedAd({ type: 'hint', amount: 2 }, (success, reward) => {
      if (success && reward) {
        audioManager.playSfx('coin', settings.soundEnabled);
        setStats((prev) => ({ ...prev, hintsRemaining: prev.hintsRemaining + reward.amount }));
      }
    });
  };

  // Hint solver
  const handleHint = () => {
    if (stats.hintsRemaining <= 0) {
      handleFreeHintAd();
      return;
    }

    const hintTileId = findSolvableHint(tiles, levelConfig.gridWidth, levelConfig.gridHeight);
    if (!hintTileId) return;

    audioManager.playSfx('hint', settings.soundEnabled);
    voiceManager.speak('good_move', settings.voiceEnabled);

    setTiles((prev) =>
      prev.map((t) => (t.id === hintTileId ? { ...t, isHinted: true } : t))
    );

    setTimeout(() => {
      setTiles((prev) =>
        prev.map((t) => (t.id === hintTileId ? { ...t, isHinted: false } : t))
      );
    }, 3000);

    setStats((prev) => ({ ...prev, hintsRemaining: Math.max(0, prev.hintsRemaining - 1) }));
  };

  // Rewarded Video: Free Coins
  const handleWatchAdForCoins = () => {
    adManager.showRewardedAd({ type: 'coins', amount: 100 }, (success, reward) => {
      if (success && reward) {
        audioManager.playSfx('coin', settings.soundEnabled);
        setStats((prev) => ({ ...prev, coins: prev.coins + reward.amount }));
      }
    });
  };

  // Time's Up: Watch Ad to Continue with +30s
  const handleWatchAdForTimedContinue = () => {
    adManager.showRewardedAd({ type: 'time_extension', amount: 30 }, (success, reward) => {
      if (success && reward) {
        audioManager.playSfx('coin', settings.soundEnabled);
        setTimedChallengeCountdown((prev) => prev + reward.amount);
        setShowTimesUpModal(false);
      }
    });
  };

  // Reset puzzle with timer reset
  const handleReset = () => {
    audioManager.playSfx('click', settings.soundEnabled);
    startLevel(currentLevelNumber, gameMode);
  };

  // Next level transition: automatically generates and starts the next level in current mode!
  const handleNextLevel = () => {
    setShowWinModal(false);

    adManager.onLevelCompleted(currentLevelNumber, () => {
      startLevel(currentLevelNumber + 1, gameMode);
    });
  };

  // Daily Reward Claim
  const handleClaimDailyReward = (day: number) => {
    const coinsByDay = [50, 100, 150, 200, 250, 300, 500];
    const coinReward = coinsByDay[day - 1] || 100;

    audioManager.playSfx('coin', settings.soundEnabled);
    setStats((prev) => ({
      ...prev,
      coins: prev.coins + coinReward,
      dailyRewardStreak: prev.dailyRewardStreak + 1,
      lastDailyRewardDate: todayDateStr,
      hintsRemaining: day === 3 ? prev.hintsRemaining + 2 : prev.hintsRemaining,
    }));
  };

  // Compute effective skin: if DESIGN MATCH is equipped, match the current design!
  const effectiveArrowSkin = useMemo(() => {
    if (stats.equippedArrowSkin === 'design_match') {
      return getDesignMatchSkin(levelConfig.name || levelConfig.themeDescription || '');
    }
    return stats.equippedArrowSkin;
  }, [stats.equippedArrowSkin, levelConfig.name, levelConfig.themeDescription]);

  return (
    <div className="w-full h-full h-[100dvh] bg-slate-950 flex items-center justify-center overflow-hidden font-sans">
      {/* 9:16 Responsive Mobile Container Frame - supports small, medium, and large phone screens */}
      <div className="w-full max-w-md h-full h-[100dvh] sm:h-[95vh] sm:max-h-[920px] bg-slate-50 dark:bg-slate-900 flex flex-col relative overflow-hidden shadow-2xl sm:rounded-[36px] sm:border-8 sm:border-slate-800">
        
        {/* Main Screen Switcher */}
        {currentScreen === 'MENU' && (
          <MainMenu
            stats={stats}
            language={settings.language}
            onPlayShortArrow={() => startLevel(stats.highestShortArrowLevel || 1, 'SHORT_ARROW')}
            onPlayLongArrow={() => startLevel(stats.highestLongArrowLevel || 1, 'LONG_ARROW')}
            onOpenShop={() => setCurrentScreen('COLLECTION')}
            onOpenSettings={() => setShowSettingsModal(true)}
            onWatchAdForCoins={handleWatchAdForCoins}
          />
        )}

        {currentScreen === 'GAMEPLAY' && (
          <div className="w-full h-full flex flex-col justify-between bg-slate-50 dark:bg-slate-900 overflow-hidden relative">
            <GameHud
              levelName={levelConfig.name}
              language={settings.language}
              worldName={
                gameMode === 'LONG_ARROW'
                  ? `Long Arrow • Level ${levelConfig.levelNumber}`
                  : `Short Arrow • Level ${levelConfig.levelNumber}`
              }
              moves={movesCount}
              targetMoves={levelConfig.targetMoves}
              remainingArrows={tiles.filter((t) => t.type === 'ARROW' && !t.isEscaping).length}
              coins={stats.coins}
              hintsRemaining={stats.hintsRemaining}
              undosRemaining={stats.undosRemaining}
              comboCount={comboCount}
              comboReactionText={comboReactionText}
              tutorialText={levelConfig.tutorialText}
              soundEnabled={settings.soundEnabled}
              isTimedMode={true}
              timeRemaining={timedChallengeCountdown}
              onToggleSound={() =>
                setSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))
              }
              onBack={() => setCurrentScreen('MENU')}
              onUndo={handleUndo}
              onHint={handleHint}
              onReset={handleReset}
              onFreeHintAd={handleFreeHintAd}
              onFreeUndoAd={handleFreeUndoAd}
            />

            {/* Interactive Puzzle Board */}
            <GameBoard
              tiles={tiles}
              gridWidth={levelConfig.gridWidth}
              gridHeight={levelConfig.gridHeight}
              arrowSkin={effectiveArrowSkin}
              boardTheme={stats.equippedBoardTheme}
              onTileTap={handleTileTap}
              blockedTileId={blockedTileId}
            />

            {/* Real AdMob Horizontal Banner Ad docked at bottom of Gameplay */}
            <BannerAd />
          </div>
        )}

        {currentScreen === 'COLLECTION' && (
          <CollectionModal
            stats={stats}
            language={settings.language}
            onEquipSkin={(skinId) =>
              setStats((prev) => ({ ...prev, equippedArrowSkin: skinId }))
            }
            onBuyItem={(item: CollectionItem) => {
              if (stats.coins >= item.cost) {
                audioManager.playSfx('coin', settings.soundEnabled);
                setStats((prev) => ({
                  ...prev,
                  coins: prev.coins - item.cost,
                  unlockedSkins: [...prev.unlockedSkins, item.id],
                }));
              }
            }}
            onWatchAdForCoins={handleWatchAdForCoins}
            onBack={() => setCurrentScreen('MENU')}
          />
        )}

        {/* Level Complete Win Modal */}
        <AnimatePresence>
          {showWinModal && (
            <WinModal
              levelNumber={currentLevelNumber}
              language={settings.language}
              stars={lastEarnedStars}
              moves={movesCount}
              bestMoves={
                (gameMode === 'LONG_ARROW'
                  ? stats.completedLongLevels[currentLevelNumber]?.bestMoves
                  : stats.completedShortLevels[currentLevelNumber]?.bestMoves) || movesCount
              }
              timeSeconds={timeSeconds}
              maxCombo={maxCombo}
              coinsEarned={lastCoinsEarned}
              onNextLevel={handleNextLevel}
              onReplay={() => {
                setShowWinModal(false);
                startLevel(currentLevelNumber, gameMode);
              }}
              onHome={() => {
                setShowWinModal(false);
                setCurrentScreen('MENU');
              }}
            />
          )}
        </AnimatePresence>

        {/* Universal Time's Up Modal */}
        <AnimatePresence>
          {showTimesUpModal && (
            <TimesUpModal
              language={settings.language}
              onRetry={() => {
                setShowTimesUpModal(false);
                startLevel(currentLevelNumber, gameMode);
              }}
              onWatchAdToContinue={handleWatchAdForTimedContinue}
              onHome={() => {
                setShowTimesUpModal(false);
                setCurrentScreen('MENU');
              }}
            />
          )}
        </AnimatePresence>

        {/* Fail Modal */}
        <AnimatePresence>
          {showFailModal && (
            <FailModal
              language={settings.language}
              hintsRemaining={stats.hintsRemaining}
              onRetry={() => {
                setShowFailModal(false);
                handleReset();
              }}
              onUseHint={() => {
                setShowFailModal(false);
                handleHint();
              }}
              onHome={() => {
                setShowFailModal(false);
                setCurrentScreen('MENU');
              }}
            />
          )}
        </AnimatePresence>

        {/* Daily Streak Reward Modal */}
        <AnimatePresence>
          {showDailyRewardModal && (
            <DailyRewardModal
              currentStreak={stats.dailyRewardStreak}
              canClaimToday={canClaimDaily}
              onClaim={handleClaimDailyReward}
              onClose={() => setShowDailyRewardModal(false)}
            />
          )}
        </AnimatePresence>

        {/* Settings Modal */}
        <AnimatePresence>
          {showSettingsModal && (
            <SettingsModal
              settings={settings}
              onUpdateSettings={setSettings}
              onResetProgress={() => {
                const fresh = saveManager.resetAllProgress();
                setStats(fresh.stats);
                setSettings(fresh.settings);
                setShowSettingsModal(false);
              }}
              onClose={() => setShowSettingsModal(false)}
            />
          )}
        </AnimatePresence>

        {/* Google AdMob Full Screen Modal (App Open, Interstitial, Rewarded Video) */}
        <AnimatePresence>
          {adModalState.showing && (
            <AdModal
              type={adModalState.type}
              reward={adModalState.reward}
              onComplete={(success) => {
                adManager.completeAd(success);
              }}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
