import { useCallback, useEffect, useRef, useState } from 'react';
import {
  BankTransaction,
  CarControlMode,
  CharacterCustomization,
  CharacterId,
  GamePhase,
  HudSnapshot,
  MissionDef,
  PhoneModelId,
  PlaceDef,
  RecordedClipDraft,
  SaveData,
  VehicleTuning,
  VehicleType,
  WeatherType,
  YouTubeChannel,
  YouTubeVideo,
} from './types/game';
import {
  CHARACTER_PROFILES,
  DEFAULT_SAVE_DATA,
  KARACHI_DISTRICTS,
  KARACHI_PLACES,
  PHONE_MODELS,
  VEHICLE_SPECS,
} from './data/karachiWorldData';
import { KarachiGameEngine } from './engine/GameEngine';
import { soundEngine } from './audio/soundEngine';
import { TitleScreen } from './components/TitleScreen';
import { GameHUD } from './components/GameHUD';
import { MobileControls } from './components/MobileControls';
import { PhoneTab, SmartphoneModal } from './components/SmartphoneModal';
import { ShopModal } from './components/ShopModal';
import { PauseMenu } from './components/PauseMenu';
import { OfflineIndicator } from './components/PWAInstallButton';

const SAVE_KEY = 'gkc1_grand_karachi_save_v1';

function loadSaveData(): { data: SaveData; exists: boolean } {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { data: DEFAULT_SAVE_DATA, exists: false };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    const rawOwnedProps = parsed.ownedProperties || DEFAULT_SAVE_DATA.ownedProperties;
    const ownedProperties = rawOwnedProps.includes('home_starter')
      ? rawOwnedProps
      : ['home_starter', ...rawOwnedProps];
    return {
      exists: true,
      data: {
        ...DEFAULT_SAVE_DATA,
        ...parsed,
        ownedProperties,
        phoneModel: parsed.phoneModel || DEFAULT_SAVE_DATA.phoneModel,
        phoneThemeColor: parsed.phoneThemeColor || DEFAULT_SAVE_DATA.phoneThemeColor,
        carControlMode: parsed.carControlMode || DEFAULT_SAVE_DATA.carControlMode,
        vehicleTuning: parsed.vehicleTuning || {},
        bankBalance: typeof parsed.bankBalance === 'number' ? parsed.bankBalance : DEFAULT_SAVE_DATA.bankBalance,
        bankAccountNo: parsed.bankAccountNo || DEFAULT_SAVE_DATA.bankAccountNo,
        bankLoan: typeof parsed.bankLoan === 'number' ? parsed.bankLoan : 0,
        bankTransactions: parsed.bankTransactions || DEFAULT_SAVE_DATA.bankTransactions,
        customizations: {
          ...DEFAULT_SAVE_DATA.customizations,
          ...(parsed.customizations || {}),
        },
        youtube: {
          ...DEFAULT_SAVE_DATA.youtube,
          ...(parsed.youtube || {}),
        },
        stats: {
          ...DEFAULT_SAVE_DATA.stats,
          ...(parsed.stats || {}),
        },
      },
    };
  } catch {
    return { data: DEFAULT_SAVE_DATA, exists: false };
  }
}

const INITIAL_HUD: HudSnapshot = {
  health: 100,
  maxHealth: 100,
  stamina: 100,
  cash: DEFAULT_SAVE_DATA.cash,
  wantedLevel: 0,
  wantedCooldown: 0,
  district: KARACHI_DISTRICTS[0],
  speedKmh: 0,
  inVehicle: null,
  vehicleName: null,
  isSwimming: false,
  cameraMode: 'third_person',
  timeOfDay: DEFAULT_SAVE_DATA.timeOfDay,
  weather: DEFAULT_SAVE_DATA.weather,
  playerX: DEFAULT_SAVE_DATA.playerPos.x,
  playerZ: DEFAULT_SAVE_DATA.playerPos.z,
  playerYaw: Math.PI,
  isRecordingVideo: false,
  recordingSeconds: 0,
  nearbyPrompt: null,
  activeMission: null,
  waypoint: null,
  radarBlips: [],
};

export function App() {
  const initial = useRef(loadSaveData());
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<KarachiGameEngine | null>(null);

  const [phase, setPhase] = useState<GamePhase>('title');
  const [save, setSave] = useState<SaveData>(initial.current.data);
  const [hasSavedProgress, setHasSavedProgress] = useState<boolean>(initial.current.exists);
  const [hud, setHud] = useState<HudSnapshot>({
    ...INITIAL_HUD,
    cash: initial.current.data.cash,
  });
  const [muted, setMuted] = useState(false);
  const [phoneOpen, setPhoneOpen] = useState(false);
  const [phoneTab, setPhoneTab] = useState<PhoneTab>('youtube');
  const [pendingDraft, setPendingDraft] = useState<RecordedClipDraft | null>(null);
  const [activePlace, setActivePlace] = useState<PlaceDef | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [mobileControlsEnabled, setMobileControlsEnabled] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth < 860;
  });

  const toastTimerRef = useRef<number | null>(null);
  const phaseRef = useRef<GamePhase>(phase);
  phaseRef.current = phase;
  const saveRef = useRef<SaveData>(save);
  saveRef.current = save;

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(null), 3200);
  }, []);

  const persistSave = useCallback(
    (nextSave: SaveData, notify = false) => {
      const pos = engineRef.current?.getPlayerPosition() || nextSave.playerPos;
      // Strip transient blob videoUrls when persisting to localStorage
      const cleanVideos = nextSave.youtube.videos.map((v) => ({
        ...v,
        videoUrl: undefined,
      }));
      const toStore: SaveData = {
        ...nextSave,
        playerPos: pos,
        youtube: {
          ...nextSave.youtube,
          videos: cleanVideos,
        },
      };
      try {
        localStorage.setItem(SAVE_KEY, JSON.stringify(toStore));
        setHasSavedProgress(true);
        if (notify) showToast('Game saved to device storage');
      } catch {
        // Ignore storage quota errors
      }
    },
    [showToast]
  );

  // Sync cash and vehicle tuning into engine whenever save updates
  useEffect(() => {
    engineRef.current?.setCash(save.cash);
  }, [save.cash]);

  useEffect(() => {
    engineRef.current?.setVehicleTuningMap(save.vehicleTuning);
  }, [save.vehicleTuning]);

  // Mount isolated Three.js engine once
  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    const initSave = initial.current.data;
    const engine = new KarachiGameEngine(
      mountEl,
      initSave.activeCharacter,
      initSave.customizations[initSave.activeCharacter],
      initSave.cash,
      initSave.playerPos,
      initSave.timeOfDay,
      initSave.weather,
      {
        onHudUpdate: (snapshot) => setHud(snapshot),
        onOpenPlace: (place) => setActivePlace(place),
        onMissionComplete: (mission) => {
          soundEngine.playCash();
          setSave((prev) => {
            const completedMissions = prev.completedMissions.includes(mission.id)
              ? prev.completedMissions
              : [...prev.completedMissions, mission.id];
            const updated: SaveData = {
              ...prev,
              cash: prev.cash + mission.rewardCash,
              completedMissions,
              stats: {
                ...prev.stats,
                missionsCompleted: completedMissions.length,
                earningsTotal: prev.stats.earningsTotal + mission.rewardCash,
              },
            };
            persistSave(updated, false);
            return updated;
          });
          showToast(`Mission Complete! +Rs. ${mission.rewardCash.toLocaleString()}`);
        },
        onMissionFailed: (reason) => {
          showToast(`Mission Failed: ${reason}`);
        },
        onWasted: () => {
          setPhase('wasted');
          setPhoneOpen(false);
          setActivePlace(null);
        },
        onNotification: (text) => showToast(text),
        onTogglePause: () => {
          setPhoneOpen(false);
          setActivePlace(null);
          setPhase((curr) => {
            const next = curr === 'playing' ? 'paused' : curr === 'paused' ? 'playing' : curr;
            engineRef.current?.setPhase(next);
            return next;
          });
        },
        onTogglePhone: () => {
          setPhoneOpen((open) => !open);
        },
      }
    );

    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [persistSave, showToast]);

  // Passive income from owned houses/businesses AND published YouTube videos!
  useEffect(() => {
    if (phase !== 'playing') return;
    const interval = window.setInterval(() => {
      const ownedIds = saveRef.current.ownedProperties;
      let tickIncome = 0;
      ownedIds.forEach((id) => {
        const p = KARACHI_PLACES.find((pl) => pl.id === id);
        if (p?.incomePerMin) {
          tickIncome += Math.round(p.incomePerMin / 3);
        }
      });

      const hasVideos = saveRef.current.youtube.videos.length > 0;
      const bankBal = saveRef.current.bankBalance;
      const bankInterest = bankBal >= 500 ? Math.min(5000, Math.round(bankBal * 0.02)) : 0;

      if (tickIncome > 0 || hasVideos || bankInterest > 0) {
        setSave((prev) => {
          const ytMult = PHONE_MODELS[prev.phoneModel]?.ytMultiplier ?? 1;
          let addedViews = 0;
          const updatedVideos = prev.youtube.videos.map((v) => {
            const newViews = Math.floor((40 + Math.random() * 140) * ytMult);
            const adCash = Math.round(newViews * 2.5 * ytMult);
            addedViews += newViews;
            return {
              ...v,
              views: v.views + newViews,
              likes: v.likes + Math.floor(newViews * 0.14),
              unclaimedCash: v.unclaimedCash + adCash,
            };
          });
          const newSubs = Math.floor(addedViews / 45);
          const nextTx = bankInterest > 0
            ? [
                {
                  id: `tx_${Date.now()}`,
                  label: 'K-Bank 2% Savings Profit',
                  amount: bankInterest,
                  type: 'interest' as const,
                  time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                },
                ...prev.bankTransactions,
              ].slice(0, 12)
            : prev.bankTransactions;

          return {
            ...prev,
            cash: prev.cash + tickIncome,
            bankBalance: prev.bankBalance + bankInterest,
            bankTransactions: nextTx,
            youtube: {
              ...prev.youtube,
              subscribers: prev.youtube.subscribers + newSubs,
              totalViews: prev.youtube.totalViews + addedViews,
              videos: updatedVideos,
            },
            stats: {
              ...prev.stats,
              earningsTotal: prev.stats.earningsTotal + tickIncome + bankInterest,
            },
          };
        });
        if (tickIncome > 0) {
          showToast(`Property Payout: +Rs. ${tickIncome.toLocaleString()}`);
        }
      }
    }, 20000);
    return () => window.clearInterval(interval);
  }, [phase, showToast]);

  const handleStart = useCallback((continueSave: boolean) => {
    soundEngine.unlock();
    if (!continueSave) {
      setSave(DEFAULT_SAVE_DATA);
      engineRef.current?.setCash(DEFAULT_SAVE_DATA.cash);
      engineRef.current?.switchCharacter(
        DEFAULT_SAVE_DATA.activeCharacter,
        DEFAULT_SAVE_DATA.customizations[DEFAULT_SAVE_DATA.activeCharacter]
      );
      engineRef.current?.setTimeOfDay(DEFAULT_SAVE_DATA.timeOfDay, true);
      engineRef.current?.setWeather(DEFAULT_SAVE_DATA.weather);
      localStorage.removeItem(SAVE_KEY);
      setHasSavedProgress(false);
    }
    setPhase('playing');
    engineRef.current?.setPhase('playing');
  }, []);

  const handleSwitchCharacter = useCallback(
    (id: CharacterId) => {
      setSave((prev) => {
        const updated = { ...prev, activeCharacter: id };
        engineRef.current?.switchCharacter(id, updated.customizations[id]);
        persistSave(updated, false);
        return updated;
      });
      showToast(`Switched to ${CHARACTER_PROFILES[id].name}`);
    },
    [persistSave, showToast]
  );

  const handleUpdateCustomization = useCallback(
    (custom: CharacterCustomization) => {
      setSave((prev) => {
        const updated: SaveData = {
          ...prev,
          customizations: {
            ...prev.customizations,
            [prev.activeCharacter]: custom,
          },
        };
        engineRef.current?.switchCharacter(prev.activeCharacter, custom);
        persistSave(updated, false);
        return updated;
      });
    },
    [persistSave]
  );

  const handleBuyOrSummonVehicle = useCallback(
    (type: VehicleType) => {
      const spec = VEHICLE_SPECS[type];
      setSave((prev) => {
        if (prev.ownedVehicles.includes(type)) {
          engineRef.current?.summonVehicleNearPlayer(type);
          return prev;
        }
        if (prev.cash < spec.price) {
          showToast('Not enough cash for this vehicle');
          return prev;
        }
        soundEngine.playCash();
        const updated: SaveData = {
          ...prev,
          cash: prev.cash - spec.price,
          ownedVehicles: [...prev.ownedVehicles, type],
        };
        persistSave(updated, false);
        engineRef.current?.summonVehicleNearPlayer(type);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleBuyProperty = useCallback(
    (placeId: string) => {
      const place = KARACHI_PLACES.find((p) => p.id === placeId);
      if (!place || !place.price) return;
      setSave((prev) => {
        if (prev.ownedProperties.includes(placeId) || prev.cash < place.price!) {
          return prev;
        }
        soundEngine.playCash();
        const updated: SaveData = {
          ...prev,
          cash: prev.cash - place.price!,
          ownedProperties: [...prev.ownedProperties, placeId],
        };
        persistSave(updated, false);
        showToast(`Purchased ${place.name}!`);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleRunQuickJob = useCallback(
    (jobTitle: string, reward: number) => {
      soundEngine.playCash();
      setSave((prev) => {
        const updated: SaveData = {
          ...prev,
          cash: prev.cash + reward,
          stats: { ...prev.stats, earningsTotal: prev.stats.earningsTotal + reward },
        };
        persistSave(updated, false);
        return updated;
      });
      showToast(`${jobTitle} completed (+Rs. ${reward.toLocaleString()})`);
    },
    [persistSave, showToast]
  );

  const handleEatMeal = useCallback(
    (cost: number, label: string) => {
      setSave((prev) => {
        if (prev.cash < cost) return prev;
        soundEngine.playCash();
        engineRef.current?.restoreFullHealth();
        showToast(`Enjoyed ${label} — Health 100%`);
        return { ...prev, cash: prev.cash - cost };
      });
    },
    [showToast]
  );

  const handleRestAtHome = useCallback(
    (placeName: string) => {
      engineRef.current?.restoreFullHealth();
      persistSave(saveRef.current, false);
      soundEngine.playPhonePing();
      showToast(`Rested at ${placeName} — Health 100% & Saved`);
    },
    [persistSave, showToast]
  );

  const handleBuyPhone = useCallback(
    (modelId: PhoneModelId) => {
      const model = PHONE_MODELS[modelId];
      if (!model) return;
      setSave((prev) => {
        if (prev.phoneModel === modelId || prev.cash < model.price) return prev;
        soundEngine.playCash();
        const updated: SaveData = {
          ...prev,
          cash: prev.cash - model.price,
          phoneModel: modelId,
        };
        persistSave(updated, false);
        showToast(`Equipped ${model.name} (${model.ytMultiplier}x YouTube Bonus)`);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleSetPhoneColor = useCallback(
    (color: string) => {
      setSave((prev) => {
        const updated: SaveData = { ...prev, phoneThemeColor: color };
        persistSave(updated, false);
        return updated;
      });
      soundEngine.playPhonePing();
      showToast('K-Phone frame color updated!');
    },
    [persistSave, showToast]
  );

  const handleUpgradeVehicle = useCallback(
    (type: VehicleType, patch: Partial<VehicleTuning>, cost: number, label: string) => {
      setSave((prev) => {
        if (prev.cash < cost) {
          showToast('Not enough cash for upgrade');
          return prev;
        }
        const current: VehicleTuning = prev.vehicleTuning[type] || {
          color: VEHICLE_SPECS[type].defaultColor,
          engineLevel: 1,
          handlingLevel: 1,
        };
        const nextTuning: VehicleTuning = {
          ...current,
          ...patch,
          engineLevel: Math.min(3, patch.engineLevel ?? current.engineLevel),
          handlingLevel: Math.min(3, patch.handlingLevel ?? current.handlingLevel),
        };
        soundEngine.playCash();
        const updated: SaveData = {
          ...prev,
          cash: prev.cash - cost,
          vehicleTuning: {
            ...prev.vehicleTuning,
            [type]: nextTuning,
          },
        };
        engineRef.current?.setVehicleTuningMap(updated.vehicleTuning);
        persistSave(updated, false);
        showToast(label);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleChangeCarControlMode = useCallback(
    (mode: CarControlMode) => {
      setSave((prev) => {
        const updated: SaveData = { ...prev, carControlMode: mode };
        persistSave(updated, false);
        return updated;
      });
      const label = mode === 'buttons' ? 'Arrows' : mode === 'wheel' ? 'Steering Wheel' : 'Analog Stick';
      showToast(`Car Controls: ${label}`);
    },
    [persistSave, showToast]
  );

  const handleGoHome = useCallback(() => {
    soundEngine.playPhonePing();
    engineRef.current?.teleportToHome(26, -64);
  }, []);

  // YouTube Studio Handlers
  const handleUpdateYouTubeChannel = useCallback(
    (patch: Partial<YouTubeChannel>) => {
      setSave((prev) => {
        const updated: SaveData = {
          ...prev,
          youtube: {
            ...prev.youtube,
            ...patch,
          },
        };
        persistSave(updated, false);
        return updated;
      });
      showToast('YouTube Channel updated!');
    },
    [persistSave, showToast]
  );

  const handleCaptureProfilePhoto = useCallback(() => {
    const snap = engineRef.current?.captureFrameDataUrl() || '';
    if (snap) {
      soundEngine.playPhonePing();
      showToast('Snapped real 3D game photo for Channel!');
    }
    return snap;
  }, [showToast]);

  const handleStartRecording = useCallback(() => {
    setPhoneOpen(false);
    engineRef.current?.startVideoRecording();
  }, []);

  const handleStopRecording = useCallback(async () => {
    const draft = await engineRef.current?.stopVideoRecording();
    if (draft) {
      setPendingDraft(draft);
      setPhoneTab('youtube');
      setPhoneOpen(true);
      soundEngine.playPhonePing();
    }
  }, []);

  const handlePublishVideo = useCallback(
    (title: string, category: YouTubeVideo['category'], draft: RecordedClipDraft) => {
      const ytMult = PHONE_MODELS[saveRef.current.phoneModel]?.ytMultiplier ?? 1;
      const initialViews = Math.round(
        (450 + draft.actionScore * 24 + saveRef.current.youtube.subscribers * 1.4) * ytMult
      );
      const initialLikes = Math.round(initialViews * 0.16);
      const instantPayout = Math.round(initialViews * 3.5);
      const gainedSubs = Math.max(15, Math.round(initialViews / 18));

      const newVideo: YouTubeVideo = {
        id: `vid_${Date.now()}`,
        title,
        category,
        thumbnailDataUrl: draft.thumbnailDataUrl,
        videoUrl: draft.videoUrl,
        durationSec: draft.durationSec,
        views: initialViews,
        likes: initialLikes,
        earnedCash: instantPayout,
        unclaimedCash: 0,
        publishedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        district: draft.district,
      };

      soundEngine.playCash();
      setSave((prev) => {
        const updated: SaveData = {
          ...prev,
          cash: prev.cash + instantPayout,
          youtube: {
            ...prev.youtube,
            created: true,
            subscribers: prev.youtube.subscribers + gainedSubs,
            totalViews: prev.youtube.totalViews + initialViews,
            totalEarned: prev.youtube.totalEarned + instantPayout,
            videos: [newVideo, ...prev.youtube.videos],
          },
          stats: {
            ...prev.stats,
            earningsTotal: prev.stats.earningsTotal + instantPayout,
          },
        };
        persistSave(updated, false);
        return updated;
      });
      setPendingDraft(null);
      showToast(`Published! ${initialViews.toLocaleString()} views · +Rs. ${instantPayout.toLocaleString()}`);
    },
    [persistSave, showToast]
  );

  const handleClaimYouTubeRevenue = useCallback(() => {
    setSave((prev) => {
      const unclaimed = prev.youtube.videos.reduce((s, v) => s + v.unclaimedCash, 0);
      if (unclaimed <= 0) return prev;
      soundEngine.playCash();
      const updatedVideos = prev.youtube.videos.map((v) => ({
        ...v,
        earnedCash: v.earnedCash + v.unclaimedCash,
        unclaimedCash: 0,
      }));
      const updated: SaveData = {
        ...prev,
        cash: prev.cash + unclaimed,
        youtube: {
          ...prev.youtube,
          totalEarned: prev.youtube.totalEarned + unclaimed,
          videos: updatedVideos,
        },
        stats: {
          ...prev.stats,
          earningsTotal: prev.stats.earningsTotal + unclaimed,
        },
      };
      persistSave(updated, false);
      showToast(`Collected YouTube AdSense: +Rs. ${unclaimed.toLocaleString()}`);
      return updated;
    });
  }, [persistSave, showToast]);

  const handleBankDeposit = useCallback(
    (amount: number) => {
      if (amount <= 0) return;
      setSave((prev) => {
        const amt = Math.min(prev.cash, amount);
        if (amt <= 0) return prev;
        soundEngine.playCash();
        const tx: BankTransaction = {
          id: `tx_${Date.now()}`,
          label: 'Cash Deposit to K-Bank',
          amount: amt,
          type: 'deposit',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        const updated: SaveData = {
          ...prev,
          cash: prev.cash - amt,
          bankBalance: prev.bankBalance + amt,
          bankTransactions: [tx, ...prev.bankTransactions].slice(0, 12),
        };
        persistSave(updated, false);
        showToast(`Deposited Rs. ${amt.toLocaleString()} to K-Bank`);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleBankWithdraw = useCallback(
    (amount: number) => {
      if (amount <= 0) return;
      setSave((prev) => {
        const amt = Math.min(prev.bankBalance, amount);
        if (amt <= 0) return prev;
        soundEngine.playCash();
        const tx: BankTransaction = {
          id: `tx_${Date.now()}`,
          label: 'ATM Cash Withdrawal',
          amount: amt,
          type: 'withdraw',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        const updated: SaveData = {
          ...prev,
          cash: prev.cash + amt,
          bankBalance: prev.bankBalance - amt,
          bankTransactions: [tx, ...prev.bankTransactions].slice(0, 12),
        };
        persistSave(updated, false);
        showToast(`Withdrew Rs. ${amt.toLocaleString()} to Pocket`);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleBankTakeLoan = useCallback(
    (amount: number) => {
      setSave((prev) => {
        if (prev.bankLoan >= 200000) return prev;
        const amt = Math.min(amount, 200000 - prev.bankLoan);
        soundEngine.playCash();
        const tx: BankTransaction = {
          id: `tx_${Date.now()}`,
          label: 'K-Bank Instant Loan Approved',
          amount: amt,
          type: 'loan',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        const updated: SaveData = {
          ...prev,
          bankBalance: prev.bankBalance + amt,
          bankLoan: prev.bankLoan + amt,
          bankTransactions: [tx, ...prev.bankTransactions].slice(0, 12),
        };
        persistSave(updated, false);
        showToast(`Loan +Rs. ${amt.toLocaleString()} credited to K-Bank!`);
        return updated;
      });
    },
    [persistSave, showToast]
  );

  const handleBankRepayLoan = useCallback(() => {
    setSave((prev) => {
      if (prev.bankLoan <= 0) return prev;
      const fromBank = Math.min(prev.bankBalance, prev.bankLoan);
      const remaining = prev.bankLoan - fromBank;
      const fromCash = Math.min(prev.cash, remaining);
      const totalPaid = fromBank + fromCash;
      if (totalPaid <= 0) return prev;
      soundEngine.playCash();
      const tx: BankTransaction = {
        id: `tx_${Date.now()}`,
        label: 'K-Bank Loan Repayment',
        amount: totalPaid,
        type: 'repay',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const updated: SaveData = {
        ...prev,
        bankBalance: prev.bankBalance - fromBank,
        cash: prev.cash - fromCash,
        bankLoan: prev.bankLoan - totalPaid,
        bankTransactions: [tx, ...prev.bankTransactions].slice(0, 12),
      };
      persistSave(updated, false);
      showToast(`Repaid Rs. ${totalPaid.toLocaleString()} toward Bank Loan`);
      return updated;
    });
  }, [persistSave, showToast]);

  const handleRespawnHospital = useCallback(() => {
    setSave((prev) => ({
      ...prev,
      cash: Math.max(0, prev.cash - 2500),
    }));
    engineRef.current?.respawnAtHospital();
    setPhase('playing');
    showToast('Discharged from Jinnah Saddar Hospital');
  }, [showToast]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black">
      {/* Isolated WebGL Viewport Container */}
      <div ref={canvasMountRef} className="fixed inset-0 z-0" />

      {/* Title Screen */}
      {phase === 'title' && (
        <TitleScreen hasSavedProgress={hasSavedProgress} onStart={handleStart} />
      )}

      {/* Active Gameplay HUD & Touch Controls */}
      {phase === 'playing' && (
        <>
          <GameHUD
            hud={hud}
            activeChar={save.activeCharacter}
            muted={muted}
            mobileControlsEnabled={mobileControlsEnabled}
            onToggleMute={() => {
              const next = !muted;
              setMuted(next);
              soundEngine.setMuted(next);
            }}
            onCycleCamera={() => {
              const mode = engineRef.current?.cycleCameraMode();
              if (mode) showToast(`Camera: ${mode.replace('_', ' ')}`);
            }}
            onOpenPhone={() => {
              setPhoneTab('missions');
              setPhoneOpen((o) => !o);
            }}
            onOpenYouTube={() => {
              setPhoneTab('youtube');
              setPhoneOpen(true);
            }}
            onStopRecording={handleStopRecording}
            onSwitchCharacter={handleSwitchCharacter}
            onPause={() => {
              setPhase('paused');
              engineRef.current?.setPhase('paused');
            }}
            onToggleMobileControls={() => setMobileControlsEnabled((v) => !v)}
            onActionInteract={() => engineRef.current?.triggerInteract()}
            onActionEnterExit={() => engineRef.current?.triggerEnterExit()}
          />

          {mobileControlsEnabled && !phoneOpen && !activePlace && (
            <MobileControls
              hud={hud}
              carControlMode={save.carControlMode}
              onChangeCarControlMode={handleChangeCarControlMode}
              onJoystick={(x, y) => engineRef.current?.setTouchJoystick(x, y)}
              onSteer={(s) => engineRef.current?.setTouchSteer(s)}
              onPedals={(g, b) => engineRef.current?.setTouchPedals(g, b)}
              onHandbrake={(h) => engineRef.current?.setTouchHandbrake(h)}
              onBoost={(b) => engineRef.current?.setTouchBoost(b)}
              onSprint={(s) => engineRef.current?.setTouchSprint(s)}
              onJump={() => engineRef.current?.triggerJump()}
              onEnterExit={() => engineRef.current?.triggerEnterExit()}
              onInteract={() => engineRef.current?.triggerInteract()}
              onHorn={() => engineRef.current?.triggerHorn()}
              onRecenterCamera={() => engineRef.current?.recenterCamera()}
            />
          )}
        </>
      )}

      {/* Interactive K-Phone Smartphone (with YouTube Studio, K-Bank, Missions, Map, Garage, Life, Style, World) */}
      {phase === 'playing' && phoneOpen && (
        <SmartphoneModal
          save={save}
          hud={hud}
          initialTab={phoneTab}
          pendingDraft={pendingDraft}
          onClose={() => setPhoneOpen(false)}
          onStartMission={(m: MissionDef) => engineRef.current?.startMission(m)}
          onAbortMission={() => engineRef.current?.abortMission()}
          onSetWaypoint={(x, z, label) => engineRef.current?.setWaypoint(x, z, label)}
          onClearWaypoint={() => engineRef.current?.clearWaypoint()}
          onBuyOrSummonVehicle={handleBuyOrSummonVehicle}
          onBuyProperty={handleBuyProperty}
          onRunQuickJob={handleRunQuickJob}
          onSwitchCharacter={handleSwitchCharacter}
          onUpdateCustomization={handleUpdateCustomization}
          onSetTime={(h, auto) => engineRef.current?.setTimeOfDay(h, auto)}
          onSetWeather={(w: WeatherType) => engineRef.current?.setWeather(w)}
          onSaveGame={() => persistSave(save, true)}
          onResetSave={() => {
            localStorage.removeItem(SAVE_KEY);
            setSave(DEFAULT_SAVE_DATA);
            setHasSavedProgress(false);
            showToast('Save data reset');
          }}
          onUpdateYouTubeChannel={handleUpdateYouTubeChannel}
          onCaptureProfilePhoto={handleCaptureProfilePhoto}
          onStartRecording={handleStartRecording}
          onStopRecording={handleStopRecording}
          onPublishVideo={handlePublishVideo}
          onDiscardDraft={() => setPendingDraft(null)}
          onClaimYouTubeRevenue={handleClaimYouTubeRevenue}
          onChangeCarControlMode={handleChangeCarControlMode}
          onGoHome={handleGoHome}
          onBankDeposit={handleBankDeposit}
          onBankWithdraw={handleBankWithdraw}
          onBankTakeLoan={handleBankTakeLoan}
          onBankRepayLoan={handleBankRepayLoan}
        />
      )}

      {/* Shop / Dealership / K-Bank / Phone Shop / Home / Mall / Restaurant / Property Modal */}
      {phase === 'playing' && activePlace && (
        <ShopModal
          place={activePlace}
          save={save}
          onClose={() => setActivePlace(null)}
          onBuyOrSummonVehicle={handleBuyOrSummonVehicle}
          onUpgradeVehicle={handleUpgradeVehicle}
          onBuyPhone={handleBuyPhone}
          onSetPhoneColor={handleSetPhoneColor}
          onBuyProperty={handleBuyProperty}
          onEatMeal={handleEatMeal}
          onRestAtHome={handleRestAtHome}
          onUpdateCustomization={handleUpdateCustomization}
          onBankDeposit={handleBankDeposit}
          onBankWithdraw={handleBankWithdraw}
          onBankTakeLoan={handleBankTakeLoan}
          onBankRepayLoan={handleBankRepayLoan}
        />
      )}

      {/* Pause & Wasted Overlays */}
      <PauseMenu
        phase={phase}
        onResume={() => {
          setPhase('playing');
          engineRef.current?.setPhase('playing');
        }}
        onSaveGame={() => persistSave(save, true)}
        onRespawnHospital={handleRespawnHospital}
        onExitToTitle={() => {
          persistSave(save, false);
          setPhase('title');
          engineRef.current?.setPhase('title');
        }}
      />

      {/* Non-intrusive Toast Notification */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg bg-slate-950/95 border border-amber-400/70 text-xs md:text-sm font-bold text-white shadow-xl pointer-events-none">
          {toast}
        </div>
      )}

      {/* PWA Offline Indicator */}
      <OfflineIndicator />
    </div>
  );
}

export default App;
