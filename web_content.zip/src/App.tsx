import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Plus,
  Trash2,
  Edit2,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Search,
  Menu,
  X,
  Download,
  Settings,
  Sparkles,
  ChevronDown,
  User as UserIcon,
  RotateCw,
  Smartphone,
  Shield,
  FileCode,
  Palette,
  Sun,
  Moon,
  Coffee,
  CheckCircle2,
} from 'lucide-react';
import { Chat, Message, NeuralModeId, User as UserType } from './types';
import { NEURAL_MODES, QUICK_PROMPTS } from './constants/modes';
import { THEMES, ThemeId } from './constants/themes';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { speakText, stopSpeaking, isSpeechRecognitionSupported, createSpeechRecognizer } from './utils/audio';

export default function App() {
  // Theme state (Claude Dark, Light, Sepia, Midnight)
  const [activeTheme, setActiveTheme] = useState<ThemeId>(() => {
    return (localStorage.getItem('sosiska_theme') as ThemeId) || 'dark';
  });
  const [themeDropdownOpen, setThemeDropdownOpen] = useState(false);

  // Auth state
  const [user, setUser] = useState<UserType | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('sosiska_token'));
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [pwaModalOpen, setPwaModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'login' | 'register'>('register');

  // Chats state
  const [chats, setChats] = useState<Array<{ id: string; title: string; mode: NeuralModeId; updatedAt: string; messageCount: number }>>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingChats, setLoadingChats] = useState(false);

  // Input & Generation state
  const [inputMessage, setInputMessage] = useState('');
  const [currentMode, setCurrentMode] = useState<NeuralModeId>('classic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [modeDropdownOpen, setModeDropdownOpen] = useState(false);

  // Audio states
  const [isSpeakingMsgId, setIsSpeakingMsgId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);

  // UI state
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editingTitleText, setEditingTitleText] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Apply theme class to body and container
  useEffect(() => {
    localStorage.setItem('sosiska_theme', activeTheme);
    const rootClass = THEMES[activeTheme]?.className || '';
    document.body.className = `${rootClass} transition-colors duration-300`;
  }, [activeTheme]);

  // Check auth on load
  useEffect(() => {
    const storedToken = localStorage.getItem('sosiska_token');
    if (!storedToken) {
      setAuthModalOpen(true);
      return;
    }

    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${storedToken}` },
    })
      .then((res) => {
        if (!res.ok) throw new Error('Token expired');
        return res.json();
      })
      .then((data) => {
        setUser(data.user);
        setToken(storedToken);
      })
      .catch(() => {
        localStorage.removeItem('sosiska_token');
        setUser(null);
        setToken(null);
        setAuthModalOpen(true);
      });
  }, []);

  // Fetch chats list when token is valid
  const loadChats = async (selectLatest = false) => {
    if (!token) return;
    setLoadingChats(true);
    try {
      const res = await fetch('/api/chats', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return;
      const data = await res.json();
      setChats(data.chats || []);

      if (data.chats && data.chats.length > 0) {
        if (selectLatest || !activeChatId) {
          loadChatMessages(data.chats[0].id);
        }
      } else {
        setActiveChat(null);
        setActiveChatId(null);
      }
    } catch (err) {
      console.error('Failed to load chats:', err);
    } finally {
      setLoadingChats(false);
    }
  };

  useEffect(() => {
    if (token && user) {
      loadChats(true);
    }
  }, [token, user?.id]);

  // Load specific chat messages
  const loadChatMessages = async (chatId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/chats/${chatId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return;
      const data = await res.json();
      setActiveChat(data.chat);
      setActiveChatId(data.chat.id);
      if (data.chat.mode) {
        setCurrentMode(data.chat.mode);
      }
      if (window.innerWidth < 768) {
        setSidebarOpen(false);
      }
    } catch (err) {
      console.error('Failed to load chat details:', err);
    }
  };

  // Scroll to bottom on messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChat?.messages, isGenerating]);

  // Handle auto-resize textarea
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputMessage(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  };

  // Create new chat
  const handleCreateNewChat = async (mode: NeuralModeId = currentMode) => {
    if (!token) return;
    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title: 'Новый диалог',
          mode,
        }),
      });
      if (!res.ok) return;
      const data = await res.json();
      const newChat = data.chat;
      setChats((prev) => [
        {
          id: newChat.id,
          title: newChat.title,
          mode: newChat.mode,
          updatedAt: newChat.updatedAt,
          messageCount: 0,
        },
        ...prev,
      ]);
      setActiveChat(newChat);
      setActiveChatId(newChat.id);
      setCurrentMode(newChat.mode);
      if (window.innerWidth < 768) setSidebarOpen(false);
      textareaRef.current?.focus();
    } catch (err) {
      console.error('Failed to create new chat:', err);
    }
  };

  // Rename chat
  const handleSaveRename = async (chatId: string) => {
    if (!token || !editingTitleText.trim()) {
      setEditingChatId(null);
      return;
    }
    try {
      const res = await fetch(`/api/chats/${chatId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ title: editingTitleText.trim() }),
      });
      if (res.ok) {
        setChats((prev) =>
          prev.map((c) => (c.id === chatId ? { ...c, title: editingTitleText.trim() } : c))
        );
        if (activeChat && activeChat.id === chatId) {
          setActiveChat({ ...activeChat, title: editingTitleText.trim() });
        }
      }
    } catch (e) {
      console.error('Error renaming chat:', e);
    } finally {
      setEditingChatId(null);
    }
  };

  // Delete chat
  const handleDeleteChat = async (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!token) return;
    if (!confirm('Вы уверены, что хотите удалить этот диалог?')) return;

    try {
      const res = await fetch(`/api/chats/${chatId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const remaining = chats.filter((c) => c.id !== chatId);
        setChats(remaining);
        if (activeChatId === chatId) {
          if (remaining.length > 0) {
            loadChatMessages(remaining[0].id);
          } else {
            setActiveChat(null);
            setActiveChatId(null);
          }
        }
      }
    } catch (err) {
      console.error('Error deleting chat:', err);
    }
  };

  // Send message with streaming response
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isGenerating || !token) return;

    setInputMessage('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    const tempUserMsgId = `temp_${Date.now()}`;
    const userMsg: Message = {
      id: tempUserMsgId,
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toISOString(),
      mode: currentMode,
    };

    const tempAssistantMsgId = `temp_ai_${Date.now()}`;
    const placeholderAssistantMsg: Message = {
      id: tempAssistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: new Date().toISOString(),
      mode: currentMode,
    };

    if (activeChat) {
      setActiveChat({
        ...activeChat,
        messages: [...activeChat.messages, userMsg, placeholderAssistantMsg],
      });
    } else {
      setActiveChat({
        id: 'pending',
        userId: user?.id || '',
        title: text.slice(0, 30),
        mode: currentMode,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [userMsg, placeholderAssistantMsg],
      });
    }

    setIsGenerating(true);

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          chatId: activeChatId,
          message: text.trim(),
          mode: currentMode,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Ошибка связи с сервером');
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('Потоковое чтение недоступно');

      const decoder = new TextDecoder('utf-8');
      let streamBuffer = '';
      let accumulatedText = '';
      let assignedChatId = activeChatId;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        streamBuffer += decoder.decode(value, { stream: true });
        const lines = streamBuffer.split('\n\n');
        streamBuffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const jsonStr = line.replace('data: ', '').trim();
          if (!jsonStr) continue;

          try {
            const data = JSON.parse(jsonStr);

            if (data.type === 'start') {
              assignedChatId = data.chatId;
              setActiveChatId(data.chatId);
            } else if (data.type === 'chunk') {
              accumulatedText += data.text;
              setActiveChat((prev) => {
                if (!prev) return null;
                const updated = [...prev.messages];
                const last = updated[updated.length - 1];
                if (last && last.role === 'assistant') {
                  last.content = accumulatedText;
                }
                return { ...prev, id: assignedChatId || prev.id, messages: updated };
              });
            } else if (data.type === 'done') {
              if (data.chatTitle) {
                setActiveChat((prev) => (prev ? { ...prev, title: data.chatTitle } : null));
              }
              loadChats();
            } else if (data.type === 'error') {
              setActiveChat((prev) => {
                if (!prev) return null;
                const updated = [...prev.messages];
                const last = updated[updated.length - 1];
                if (last && last.role === 'assistant') {
                  last.content = `⚠️ Ошибка: ${data.error}`;
                  last.error = true;
                }
                return { ...prev, messages: updated };
              });
            }
          } catch (parseErr) {
            console.error('Error parsing SSE stream line:', parseErr);
          }
        }
      }
    } catch (err: any) {
      console.error('Streaming error:', err);
      setActiveChat((prev) => {
        if (!prev) return null;
        const updated = [...prev.messages];
        const last = updated[updated.length - 1];
        if (last && last.role === 'assistant') {
          last.content = `⚠️ Ошибка: ${err.message || 'Сбой сети'}`;
          last.error = true;
        }
        return { ...prev, messages: updated };
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleToggleSpeak = (msgId: string, text: string) => {
    if (isSpeakingMsgId === msgId) {
      stopSpeaking();
      setIsSpeakingMsgId(null);
    } else {
      setIsSpeakingMsgId(msgId);
      speakText(
        text,
        () => setIsSpeakingMsgId(null),
        () => setIsSpeakingMsgId(null)
      );
    }
  };

  const handleToggleVoiceRecord = () => {
    if (!isSpeechRecognitionSupported()) {
      alert('Голосовой ввод не поддерживается вашим браузером.');
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      const recognizer = createSpeechRecognizer(
        (transcript) => {
          setInputMessage((prev) => (prev ? `${prev} ${transcript}` : transcript));
        },
        (error) => {
          console.warn('Voice recognition error:', error);
          setIsRecording(false);
        },
        () => {
          setIsRecording(false);
        }
      );

      if (recognizer) {
        recognitionRef.current = recognizer;
        recognizer.start();
        setIsRecording(true);
      }
    }
  };

  const handleCopyMessage = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handleExportChat = () => {
    if (!activeChat || activeChat.messages.length === 0) return;
    const title = activeChat.title || 'Sosiska-Chat';
    let md = `# ${title}\n\n*Диалог с нейросетью Sosiska AI*\n\n---\n\n`;

    activeChat.messages.forEach((m) => {
      const sender = m.role === 'user' ? (user?.displayName || 'Вы') : 'Sosiska AI';
      md += `### ${sender}:\n\n${m.content}\n\n---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.toLowerCase().replace(/[^a-zа-я0-9]/gi, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Get Claude-style greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    const name = user?.displayName ? `, ${user.displayName}` : '';
    if (hour >= 5 && hour < 12) return `Доброе утро${name}`;
    if (hour >= 12 && hour < 18) return `Добрый день${name}`;
    if (hour >= 18 && hour < 23) return `Добрый вечер${name}`;
    return `Доброй ночи${name}`;
  };

  const filteredChats = chats.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeModeConfig = NEURAL_MODES[currentMode] || NEURAL_MODES.classic;
  const currentThemeConfig = THEMES[activeTheme] || THEMES.dark;

  return (
    <div className={`flex h-screen w-screen overflow-hidden ${currentThemeConfig.className} bg-[var(--bg-main)] text-[var(--text-primary)] transition-colors duration-300 font-sans`}>
      {/* ================= CLAUDE-STYLE SIDEBAR ================= */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-72 md:w-80 bg-[var(--bg-surface)] border-r border-[var(--border-subtle)] flex flex-col transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Brand header */}
        <div className="p-4 border-b border-[var(--border-subtle)] flex items-center justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer group" onClick={() => handleCreateNewChat()}>
            <img
              src="/sosiska-logo.png"
              alt="Sosiska AI"
              className="w-9 h-9 rounded-xl object-cover shadow-sm group-hover:scale-105 transition-transform shrink-0 border border-[var(--accent-border)]"
            />
            <div>
              <div className="flex items-center gap-2 font-claude-serif text-lg font-bold text-[var(--text-primary)] tracking-tight">
                <span>Sosiska AI</span>
                <span className="w-2 h-2 rounded-full bg-[var(--accent-terracotta)] animate-pulse" />
              </div>
              <p className="text-[11px] text-[var(--text-muted)] font-medium">Claude Edition</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setSidebarOpen(false)}
              className="md:hidden p-1.5 text-[var(--text-muted)] hover:text-[var(--text-primary)] rounded-lg hover:bg-[var(--bg-card)] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Claude "+ New Chat" Button */}
        <div className="p-3">
          <button
            onClick={() => handleCreateNewChat()}
            className="w-full py-2.5 px-3.5 bg-[var(--bg-card)] hover:bg-[var(--border-subtle)] text-[var(--text-primary)] font-medium text-xs rounded-xl border border-[var(--border-subtle)] shadow-sm flex items-center justify-between transition-all cursor-pointer group"
          >
            <span className="flex items-center gap-2">
              <Plus className="w-4 h-4 text-[var(--accent-terracotta)] transition-transform group-hover:rotate-90" />
              <span>Новый диалог</span>
            </span>
            <span className="text-[10px] text-[var(--text-muted)] font-mono">⌘K</span>
          </button>
        </div>

        {/* Search input */}
        <div className="px-3 pb-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск по диалогам..."
              className="w-full pl-8 pr-3 py-1.5 bg-[var(--bg-card)]/70 border border-[var(--border-subtle)] rounded-lg text-xs text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:border-[var(--accent-terracotta)]"
            />
          </div>
        </div>

        {/* Chat sessions list */}
        <div className="flex-1 overflow-y-auto px-2 space-y-1 py-1">
          {loadingChats ? (
            <div className="p-4 text-center text-xs text-[var(--text-muted)] animate-pulse">
              Загрузка диалогов...
            </div>
          ) : filteredChats.length === 0 ? (
            <div className="p-6 text-center text-xs text-[var(--text-muted)]">
              {searchQuery ? 'Ничего не найдено' : 'Нет сохраненных диалогов'}
            </div>
          ) : (
            filteredChats.map((chatItem) => {
              const isActive = chatItem.id === activeChatId;
              const modeMeta = NEURAL_MODES[chatItem.mode] || NEURAL_MODES.classic;

              return (
                <div
                  key={chatItem.id}
                  onClick={() => loadChatMessages(chatItem.id)}
                  className={`group relative flex items-center justify-between p-2.5 rounded-xl text-xs cursor-pointer transition-all ${
                    isActive
                      ? 'bg-[var(--bg-card)] text-[var(--text-primary)] font-medium border border-[var(--border-subtle)] shadow-sm'
                      : 'text-[var(--text-secondary)] hover:bg-[var(--bg-card)]/50 hover:text-[var(--text-primary)]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <span className="text-sm shrink-0">{modeMeta.icon}</span>

                    {editingChatId === chatItem.id ? (
                      <input
                        type="text"
                        autoFocus
                        value={editingTitleText}
                        onChange={(e) => setEditingTitleText(e.target.value)}
                        onBlur={() => handleSaveRename(chatItem.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveRename(chatItem.id);
                          if (e.key === 'Escape') setEditingChatId(null);
                        }}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full bg-[var(--bg-main)] border border-[var(--accent-terracotta)] rounded px-1.5 py-0.5 text-xs text-[var(--text-primary)] focus:outline-none"
                      />
                    ) : (
                      <div className="truncate">
                        <span className="truncate block">{chatItem.title}</span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="hidden group-hover:flex items-center gap-1 shrink-0 ml-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingChatId(chatItem.id);
                        setEditingTitleText(chatItem.title);
                      }}
                      title="Переименовать"
                      className="p-1 text-[var(--text-muted)] hover:text-[var(--text-primary)] rounded cursor-pointer"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => handleDeleteChat(chatItem.id, e)}
                      title="Удалить"
                      className="p-1 text-[var(--text-muted)] hover:text-rose-400 rounded cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-[var(--border-subtle)] bg-[var(--bg-surface)] space-y-2">
          {user ? (
            <div
              onClick={() => setProfileModalOpen(true)}
              className="flex items-center justify-between p-2 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--border-subtle)] border border-[var(--border-subtle)] transition-all cursor-pointer group shadow-sm"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-[var(--accent-bg)] border border-[var(--accent-border)] flex items-center justify-center text-lg shrink-0">
                  {user.avatar || '👤'}
                </div>
                <div className="truncate text-left">
                  <div className="text-xs font-semibold text-[var(--text-primary)] truncate group-hover:text-[var(--accent-terracotta)] transition-colors">
                    {user.displayName}
                  </div>
                  <div className="text-[10px] text-[var(--text-muted)] truncate">@{user.username}</div>
                </div>
              </div>
              <Settings className="w-4 h-4 text-[var(--text-muted)] group-hover:text-[var(--text-primary)] transition-colors" />
            </div>
          ) : (
            <button
              onClick={() => {
                setAuthInitialMode('register');
                setAuthModalOpen(true);
              }}
              className="w-full py-2 px-3 bg-[var(--accent-terracotta)] hover:bg-[var(--accent-terracotta-hover)] text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Регистрация в Sosiska</span>
            </button>
          )}

          {/* Admin Panel button */}
          <button
            onClick={() => setAdminModalOpen(true)}
            className="w-full py-1.5 px-2.5 rounded-xl bg-[var(--bg-card)]/50 hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-muted)] hover:text-rose-400 text-xs font-medium transition-all flex items-center justify-between cursor-pointer group"
          >
            <span className="flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-rose-500 group-hover:scale-110 transition-transform" />
              <span>Админ-панель</span>
            </span>
            <span className="text-[10px] text-[var(--text-muted)] group-hover:text-rose-400 font-medium">
              Вход
            </span>
          </button>
        </div>
      </aside>

      {/* Mobile backdrop */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm md:hidden"
        />
      )}

      {/* ================= MAIN CHAT VIEW ================= */}
      <main className="flex-1 flex flex-col h-full md:pl-80 bg-[var(--bg-main)] transition-colors duration-300">
        {/* Top Header */}
        <header className="h-14 border-b border-[var(--border-subtle)] bg-[var(--bg-main)]/90 backdrop-blur-md px-4 flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 -ml-1 text-[var(--text-muted)] hover:text-[var(--text-primary)] rounded-lg cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Neural Mode Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setModeDropdownOpen(!modeDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] text-xs font-medium cursor-pointer transition-all shadow-sm"
              >
                <span>{activeModeConfig.icon}</span>
                <span className="font-semibold text-[var(--text-primary)]">{activeModeConfig.name}</span>
                <ChevronDown className="w-3 h-3 text-[var(--text-muted)]" />
              </button>

              {/* Dropdown Menu */}
              {modeDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setModeDropdownOpen(false)} />
                  <div className="absolute left-0 top-full mt-2 w-72 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-2 z-40 space-y-1">
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--text-muted)] px-2 py-1">
                      Режимы Sosiska AI:
                    </div>
                    {Object.values(NEURAL_MODES).map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => {
                          setCurrentMode(mode.id);
                          setModeDropdownOpen(false);
                          if (activeChat) {
                            setActiveChat({ ...activeChat, mode: mode.id });
                          }
                        }}
                        className={`w-full flex items-start gap-2.5 p-2 rounded-xl text-left transition-all cursor-pointer ${
                          currentMode === mode.id
                            ? 'bg-[var(--accent-bg)] border border-[var(--accent-border)]'
                            : 'hover:bg-[var(--bg-card)]'
                        }`}
                      >
                        <span className="text-xl shrink-0 p-1 rounded-lg bg-[var(--bg-card)]">
                          {mode.icon}
                        </span>
                        <div>
                          <div className="text-xs font-semibold text-[var(--text-primary)] flex items-center gap-1.5">
                            <span>{mode.name}</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-[var(--bg-card)] text-[var(--text-secondary)]">
                              {mode.badge}
                            </span>
                          </div>
                          <div className="text-[11px] text-[var(--text-muted)] leading-tight mt-0.5">
                            {mode.description}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Right Header Toolbar (Themes, Admin, 1-HTML, APK, Export) */}
          <div className="flex items-center gap-1.5">
            {/* Theme Switcher Popover */}
            <div className="relative">
              <button
                onClick={() => setThemeDropdownOpen(!themeDropdownOpen)}
                className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-primary)] text-xs font-medium transition-all cursor-pointer shadow-sm"
                title="Сменить тему оформления (Claude стили)"
              >
                <span>{currentThemeConfig.icon}</span>
                <span className="hidden sm:inline">{currentThemeConfig.name}</span>
                <ChevronDown className="w-3 h-3 text-[var(--text-muted)]" />
              </button>

              {themeDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setThemeDropdownOpen(false)} />
                  <div className="absolute right-0 top-full mt-2 w-52 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl shadow-2xl p-2 z-40 space-y-1">
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--text-muted)] px-2 py-1">
                      Темы оформления:
                    </div>
                    {Object.values(THEMES).map((th) => (
                      <button
                        key={th.id}
                        onClick={() => {
                          setActiveTheme(th.id);
                          setThemeDropdownOpen(false);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded-xl text-xs text-left transition-all cursor-pointer ${
                          activeTheme === th.id
                            ? 'bg-[var(--accent-bg)] text-[var(--accent-terracotta)] font-semibold border border-[var(--accent-border)]'
                            : 'hover:bg-[var(--bg-card)] text-[var(--text-primary)]'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-4 h-4 rounded-full border border-neutral-600 flex items-center justify-center text-[10px]" style={{ backgroundColor: th.bgPreview }}>
                            {th.icon}
                          </span>
                          <span>{th.name}</span>
                        </div>
                        {activeTheme === th.id && <CheckCircle2 className="w-3.5 h-3.5 text-[var(--accent-terracotta)]" />}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Admin Panel button */}
            <button
              onClick={() => setAdminModalOpen(true)}
              className="p-2 text-[var(--text-muted)] hover:text-rose-400 hover:bg-[var(--bg-surface)] rounded-xl transition-colors cursor-pointer text-xs"
              title="Панель администратора"
            >
              <Shield className="w-4 h-4 text-rose-500" />
            </button>

            {/* Download single HTML file */}
            <a
              href="/sosiska.html"
              download="sosiska.html"
              className="hidden sm:flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] text-xs font-medium transition-all cursor-pointer shadow-sm"
              title="Скачать отдельный 1 HTML-файл"
            >
              <FileCode className="w-3.5 h-3.5 text-[var(--accent-terracotta)]" />
              <span>1 файл HTML</span>
            </a>

            {/* Install APK Button */}
            <button
              onClick={() => setPwaModalOpen(true)}
              className="p-2 text-[var(--text-muted)] hover:text-[var(--accent-terracotta)] hover:bg-[var(--bg-surface)] rounded-xl transition-colors cursor-pointer text-xs"
              title="Установить APK / WebApp на телефон"
            >
              <Smartphone className="w-4 h-4 text-[var(--accent-terracotta)]" />
            </button>

            {activeChat && activeChat.messages.length > 0 && (
              <button
                onClick={handleExportChat}
                title="Экспорт (.md)"
                className="p-2 text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-surface)] rounded-xl transition-colors cursor-pointer text-xs"
              >
                <Download className="w-4 h-4" />
              </button>
            )}
          </div>
        </header>

        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto px-4 py-6 md:px-8 space-y-6">
          {(!activeChat || activeChat.messages.length === 0) ? (
            /* Claude Signature Empty State & Greeting Dashboard */
            <div className="max-w-2xl mx-auto pt-10 pb-16 text-center animate-message">
              {/* Terracotta mascot logo */}
              <div className="relative inline-block mb-4">
                <img
                  src="/sosiska-logo.png"
                  alt="Sosiska AI"
                  className="w-16 h-16 rounded-3xl object-cover shadow-xl border border-[var(--accent-border)] mx-auto glow-claude"
                />
              </div>

              {/* Claude Editorial Greeting */}
              <h1 className="font-claude-serif text-3xl md:text-4xl font-normal text-[var(--text-primary)] tracking-tight">
                {getGreeting()}
              </h1>
              <p className="text-sm md:text-base text-[var(--text-secondary)] max-w-md mx-auto mt-2 leading-relaxed">
                Чем я могу помочь вам сегодня? Выберите режим или задайте любой вопрос.
              </p>

              {/* Mode Badges */}
              <div className="flex flex-wrap items-center justify-center gap-2 mt-6">
                {Object.values(NEURAL_MODES).map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setCurrentMode(m.id)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all cursor-pointer flex items-center gap-1.5 shadow-sm ${
                      currentMode === m.id
                        ? 'bg-[var(--accent-bg)] border-[var(--accent-border)] text-[var(--accent-terracotta)] font-semibold scale-105'
                        : 'bg-[var(--bg-surface)] border-[var(--border-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-strong)]'
                    }`}
                  >
                    <span>{m.icon}</span>
                    <span>{m.name}</span>
                  </button>
                ))}
              </div>

              {/* Claude Prompt Action Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-8 text-left">
                {QUICK_PROMPTS.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setCurrentMode(q.mode);
                      handleSendMessage(q.prompt);
                    }}
                    className="p-4 rounded-2xl bg-[var(--bg-surface)] hover:bg-[var(--bg-card)] border border-[var(--border-subtle)] hover:border-[var(--accent-border)] transition-all cursor-pointer group text-left shadow-sm"
                  >
                    <div className="text-xl mb-1.5">{q.icon}</div>
                    <div className="text-xs font-semibold text-[var(--text-primary)] group-hover:text-[var(--accent-terracotta)] transition-colors">
                      {q.title}
                    </div>
                    <div className="text-[11px] text-[var(--text-secondary)] mt-0.5 line-clamp-2">
                      {q.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Render Messages in Claude Style */
            <div className="max-w-3xl mx-auto space-y-6">
              {activeChat.messages.map((message) => {
                const isAssistant = message.role === 'assistant';
                const isSpeaking = isSpeakingMsgId === message.id;

                return (
                  <div
                    key={message.id}
                    className={`flex gap-3 md:gap-4 animate-message ${
                      isAssistant ? 'items-start' : 'items-start flex-row-reverse'
                    }`}
                  >
                    {/* Avatar */}
                    <div className="shrink-0 mt-0.5">
                      {isAssistant ? (
                        <img
                          src="/sosiska-logo.png"
                          alt="Sosiska AI"
                          className="w-8 h-8 rounded-xl object-cover border border-[var(--accent-border)] shadow-sm shrink-0"
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-xl bg-[var(--bg-card)] border border-[var(--border-subtle)] flex items-center justify-center text-base shadow-sm">
                          {user?.avatar || '👤'}
                        </div>
                      )}
                    </div>

                    {/* Message Bubble Container */}
                    <div
                      className={`flex flex-col max-w-[85%] md:max-w-[82%] ${
                        isAssistant ? 'items-start' : 'items-end'
                      }`}
                    >
                      {/* Meta header */}
                      <div className="flex items-center gap-2 mb-1 px-1">
                        <span className="text-xs font-medium text-[var(--text-secondary)]">
                          {isAssistant ? 'Sosiska AI' : (user?.displayName || 'Вы')}
                        </span>
                        {isAssistant && message.mode && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[var(--bg-surface)] text-[var(--text-muted)] border border-[var(--border-subtle)]">
                            {NEURAL_MODES[message.mode]?.name || message.mode}
                          </span>
                        )}
                        <span className="text-[10px] text-[var(--text-muted)]">
                          {new Date(message.timestamp).toLocaleTimeString('ru-RU', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      {/* Content Container (Claude-style clean bubble for user, open prose for assistant) */}
                      <div
                        className={`rounded-2xl px-4 py-3 text-sm md:text-[15px] leading-relaxed shadow-sm transition-all ${
                          isAssistant
                            ? message.error
                              ? 'bg-rose-950/30 border border-rose-800/50 text-rose-300'
                              : 'bg-[var(--bg-surface)]/80 border border-[var(--border-subtle)] text-[var(--text-primary)] rounded-tl-sm'
                            : 'bg-[var(--bg-card)] border border-[var(--border-subtle)] text-[var(--text-primary)] rounded-tr-sm shadow'
                        }`}
                      >
                        {isAssistant ? (
                          message.content ? (
                            <div>
                              <MarkdownRenderer content={message.content} />
                              {isGenerating && activeChat.messages[activeChat.messages.length - 1]?.id === message.id && (
                                <span className="cursor-blink" />
                              )}
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 py-1 text-xs text-[var(--accent-terracotta)] animate-pulse">
                              <span className="w-2 h-2 rounded-full bg-[var(--accent-terracotta)] animate-ping" />
                              <span className="font-claude-serif italic">Sosiska думает и формулирует ответ...</span>
                            </div>
                          )
                        ) : (
                          <div className="whitespace-pre-wrap break-words">{message.content}</div>
                        )}
                      </div>

                      {/* Assistant toolbar (Copy, Speak) */}
                      {isAssistant && message.content && (
                        <div className="flex items-center gap-1 mt-1 px-1 opacity-70 hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleCopyMessage(message.id, message.content)}
                            className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-surface)] transition-colors cursor-pointer"
                            title="Копировать текст"
                          >
                            {copiedMsgId === message.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <button
                            onClick={() => handleToggleSpeak(message.id, message.content)}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              isSpeaking
                                ? 'text-[var(--accent-terracotta)] bg-[var(--accent-bg)]'
                                : 'text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-surface)]'
                            }`}
                            title={isSpeaking ? 'Остановить чтение' : 'Озвучить ответ'}
                          >
                            {isSpeaking ? (
                              <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                            ) : (
                              <Volume2 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* ================= CLAUDE FLOATING INPUT CAPSULE ================= */}
        <div className="p-3 md:p-5 bg-gradient-to-t from-[var(--bg-main)] via-[var(--bg-main)]/90 to-transparent shrink-0">
          <div className="max-w-3xl mx-auto">
            <div className="relative bg-[var(--bg-surface)] border border-[var(--border-subtle)] focus-within:border-[var(--accent-terracotta)] focus-within:ring-2 focus-within:ring-[var(--accent-border)] rounded-[26px] shadow-xl transition-all p-2.5 sm:p-3">
              {/* Voice recording banner */}
              {isRecording && (
                <div className="mb-2 px-3 py-1.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between animate-pulse">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    <span>Слушаю вас... Говорите в микрофон</span>
                  </div>
                  <button onClick={handleToggleVoiceRecord} className="underline text-[11px] cursor-pointer">
                    Остановить
                  </button>
                </div>
              )}

              {/* Textarea */}
              <textarea
                ref={textareaRef}
                rows={1}
                value={inputMessage}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder={`Напишите сообщение Sosiska AI в режиме ${activeModeConfig.name}...`}
                disabled={isGenerating}
                className="w-full bg-transparent text-sm md:text-base text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none resize-none px-2 py-1 max-h-48 leading-relaxed"
              />

              {/* Bottom Capsule Controls */}
              <div className="flex items-center justify-between pt-1.5 border-t border-[var(--border-subtle)]/60 mt-1">
                {/* Left tools: Mode pill + Voice */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setModeDropdownOpen(true)}
                    className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-xl bg-[var(--bg-card)] hover:bg-[var(--border-subtle)] border border-[var(--border-subtle)] text-[var(--text-secondary)] transition-colors cursor-pointer shadow-sm"
                  >
                    <span>{activeModeConfig.icon}</span>
                    <span className="font-medium text-[var(--text-primary)]">{activeModeConfig.name}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleToggleVoiceRecord}
                    className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                      isRecording
                        ? 'bg-rose-500 text-white animate-pulse shadow-md'
                        : 'text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-card)]'
                    }`}
                    title={isRecording ? 'Выключить микрофон' : 'Голосовой ввод'}
                  >
                    {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </button>
                </div>

                {/* Claude-style Terracotta Send Button */}
                <button
                  type="button"
                  disabled={!inputMessage.trim() || isGenerating}
                  onClick={() => handleSendMessage()}
                  className="w-8 h-8 rounded-full bg-[var(--accent-terracotta)] hover:bg-[var(--accent-terracotta-hover)] disabled:opacity-30 disabled:hover:bg-[var(--accent-terracotta)] text-white flex items-center justify-center transition-all cursor-pointer shadow-md"
                >
                  {isGenerating ? (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5 ml-0.5" />
                  )}
                </button>
              </div>
            </div>

            <p className="text-center text-[10px] text-[var(--text-muted)] mt-2">
              Sosiska AI Claude Edition • Сообщения анимированы • 4 стилизованные темы
            </p>
          </div>
        </div>
      </main>

      {/* ================= MODALS ================= */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => {
          if (user) setAuthModalOpen(false);
        }}
        canClose={!!user}
        initialMode={authInitialMode}
        onAuthSuccess={(newToken, newUser) => {
          setToken(newToken);
          setUser(newUser);
          setAuthModalOpen(false);
        }}
      />

      {user && (
        <ProfileModal
          isOpen={profileModalOpen}
          onClose={() => setProfileModalOpen(false)}
          user={user}
          onUpdateUser={(updated) => setUser(updated)}
          onLogout={() => {
            localStorage.removeItem('sosiska_token');
            setUser(null);
            setToken(null);
            setProfileModalOpen(false);
            setAuthInitialMode('login');
            setAuthModalOpen(true);
          }}
        />
      )}

      <PWAInstallModal
        isOpen={pwaModalOpen}
        onClose={() => setPwaModalOpen(false)}
      />

      <AdminPanelModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        onUserDeleted={(deletedUserId) => {
          if (user?.id === deletedUserId) {
            setUser(null);
            setToken(null);
            localStorage.removeItem('sosiska_token');
            setActiveChat(null);
            setChats([]);
            setAuthModalOpen(true);
          } else {
            loadChats();
          }
        }}
      />
    </div>
  );
}
