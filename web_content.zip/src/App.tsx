import React, { useState, useEffect, useRef } from 'react';
import {
  Upload,
  BookOpen,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Trash2,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  HardDrive
} from 'lucide-react';
import { EpubReader } from './components/EpubReader';
import { SavedBookRecord } from './types/epub';
import { epubStorage } from './services/epubStorage';
import { createSampleEpub } from './utils/sampleEpub';

export default function App() {
  const [activeBook, setActiveBook] = useState<SavedBookRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastProgressPct, setLastProgressPct] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check for any stored book on startup from IndexedDB
  const loadExistingBook = async () => {
    try {
      setLoading(true);
      const saved = await epubStorage.getActiveBook();
      if (saved) {
        setActiveBook(saved);
        const progress = await epubStorage.getProgress(saved.id);
        if (progress) {
          setLastProgressPct(progress.percentage);
        }
      }
    } catch (err) {
      console.warn('Error loading active book from storage:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExistingBook();
  }, []);

  // Handle local EPUB file selection from device storage
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset input value so selecting the same file again triggers change
    e.target.value = '';

    // Verify .epub extension or mime type
    const isEpub =
      file.name.toLowerCase().endsWith('.epub') ||
      file.type === 'application/epub+zip';

    if (!isEpub) {
      setErrorMessage('Por favor selecciona un archivo con extensión .epub.');
      return;
    }

    try {
      setIsProcessingFile(true);
      setErrorMessage(null);

      // Read file locally as ArrayBuffer (completely client-side, zero server calls)
      const arrayBuffer = await file.arrayBuffer();

      // Create saved book record
      const cleanTitle = file.name.replace(/\.epub$/i, '').trim();
      const newBook: SavedBookRecord = {
        id: `book_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        fileName: file.name,
        title: cleanTitle,
        author: 'Autor local',
        buffer: arrayBuffer,
        savedAt: Date.now(),
        fileSize: file.size,
      };

      // Save to IndexedDB
      await epubStorage.saveBook(newBook);

      // Open reader immediately
      setActiveBook(newBook);
      setLastProgressPct(0);
    } catch (err: any) {
      console.error('Error procesando archivo EPUB:', err);
      setErrorMessage(
        err?.message || 'Error al leer el archivo desde el dispositivo.'
      );
    } finally {
      setIsProcessingFile(false);
    }
  };

  // Generate and load integrated sample EPUB for rapid testing
  const handleLoadSampleBook = async () => {
    try {
      setIsProcessingFile(true);
      setErrorMessage(null);

      const buffer = await createSampleEpub();

      const sampleBook: SavedBookRecord = {
        id: 'sample_epub_test_001',
        fileName: 'El-Arte-de-la-Lectura-Digital.epub',
        title: 'El Arte de la Lectura Digital (Ejemplo)',
        author: 'Biblioteca Técnica',
        buffer,
        savedAt: Date.now(),
        fileSize: buffer.byteLength,
      };

      await epubStorage.saveBook(sampleBook);
      setActiveBook(sampleBook);
      setLastProgressPct(0);
    } catch (err: any) {
      console.error('Error generando libro de prueba:', err);
      setErrorMessage('No se pudo generar el libro de ejemplo.');
    } finally {
      setIsProcessingFile(false);
    }
  };

  // Clear current book from device storage
  const handleDeleteCurrentBook = async () => {
    if (!activeBook) return;
    try {
      await epubStorage.deleteBook(activeBook.id);
      setActiveBook(null);
      setLastProgressPct(null);
    } catch (err) {
      console.error('Error eliminando libro:', err);
    }
  };

  // When a book is currently active and opened, render full-screen EPUB reader
  if (activeBook && !isProcessingFile) {
    return (
      <EpubReader
        bookId={activeBook.id}
        bookBuffer={activeBook.buffer}
        bookTitle={activeBook.title}
        bookAuthor={activeBook.author}
        fileName={activeBook.fileName}
        onClose={() => {
          // Re-fetch progress to update the landing page preview
          epubStorage.getProgress(activeBook.id).then((p) => {
            if (p) setLastProgressPct(p.percentage);
          });
          setActiveBook(null);
        }}
      />
    );
  }

  // Formatting file size
  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col justify-between p-4 sm:p-8 font-sans selection:bg-blue-600/30 selection:text-white">
      {/* Hidden file input strictly accepting .epub files */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".epub,application/epub+zip"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* --- HEADER --- */}
      <header className="max-w-xl mx-auto w-full pt-4 pb-6 text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-3xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shadow-xl shadow-blue-950/20">
          <BookOpen className="w-8 h-8" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Prueba EPUB
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-2 max-w-md mx-auto leading-relaxed">
          Prueba técnica para comprobar que el lector de archivos .EPUB funciona
          correctamente al compilar la web en APK para Android.
        </p>
      </header>

      {/* --- MAIN ACTION AREA --- */}
      <main className="max-w-xl mx-auto w-full space-y-6 flex-1 flex flex-col justify-center">
        {/* Error notification */}
        {errorMessage && (
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/25 flex items-start gap-3 text-red-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <div className="flex-1">
              <p className="font-semibold text-red-200">Error al procesar</p>
              <p className="mt-0.5">{errorMessage}</p>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-400 hover:text-white text-xs font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Previous Saved Book Card (If available in local IndexedDB) */}
        {activeBook && !isProcessingFile && (
          <div className="p-5 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl flex flex-col gap-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <span className="text-[10px] uppercase font-bold tracking-wider text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-full border border-blue-500/20">
                  Libro guardado en memoria local
                </span>
                <h2 className="text-base font-bold text-white mt-1.5 truncate">
                  {activeBook.title}
                </h2>
                <p className="text-xs text-zinc-400">
                  {activeBook.fileName} • {formatBytes(activeBook.fileSize)}
                </p>
              </div>

              {lastProgressPct !== null && (
                <div className="px-3 py-1.5 rounded-2xl bg-zinc-800 border border-zinc-700 text-center shrink-0">
                  <span className="text-xs font-bold text-white block">
                    {lastProgressPct}%
                  </span>
                  <span className="text-[9px] text-zinc-400 block">leído</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-zinc-800/80">
              <button
                onClick={() => setActiveBook(activeBook)}
                className="flex-1 h-11 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 transition-all"
              >
                <span>Continuar leyendo</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleDeleteCurrentBook}
                className="h-11 px-3.5 bg-zinc-800 hover:bg-red-500/20 text-zinc-400 hover:text-red-300 rounded-2xl border border-zinc-700/60 transition-all flex items-center justify-center"
                title="Eliminar este libro de la memoria del dispositivo"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* BIG IMPORT BUTTON (Main User Requirement) */}
        <div className="p-6 rounded-3xl bg-zinc-900/60 border border-zinc-800/80 text-center flex flex-col items-center">
          <div className="w-14 h-14 rounded-2xl bg-zinc-800/80 border border-zinc-700/60 flex items-center justify-center text-blue-400 mb-4">
            <Upload className="w-7 h-7" />
          </div>

          <h2 className="text-lg font-bold text-white">Selecciona tu archivo</h2>
          <p className="text-xs text-zinc-400 mt-1 max-w-sm">
            Toca el botón para elegir cualquier libro en formato <strong>.epub</strong> almacenado en tu dispositivo móvil o equipo.
          </p>

          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessingFile}
            className="w-full max-w-sm mt-5 py-4 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:scale-98 text-white rounded-2xl font-bold text-base shadow-xl shadow-blue-950/50 flex items-center justify-center gap-3 transition-all disabled:opacity-50 cursor-pointer"
          >
            {isProcessingFile ? (
              <>
                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Procesando EPUB...</span>
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                <span>Importar EPUB</span>
              </>
            )}
          </button>

          {/* Alternative: Sample EPUB */}
          <div className="mt-4 pt-4 border-t border-zinc-800/60 w-full max-w-sm flex flex-col items-center">
            <button
              onClick={handleLoadSampleBook}
              disabled={isProcessingFile}
              className="text-xs text-zinc-400 hover:text-blue-400 flex items-center gap-1.5 font-medium py-1 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>O probar con libro de muestra integrado</span>
            </button>
          </div>
        </div>

        {/* Technical Architecture Check Card */}
        <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-800/60 text-xs space-y-2">
          <p className="font-semibold text-zinc-300 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Especificaciones técnicas y compatibilidad con APK:</span>
          </p>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-zinc-400 pt-1">
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Selector de archivos nativo (.epub)</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Motor EPUB compatible con Web y APK</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Resaltado canónico de texto (CFI)</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Almacenamiento IndexedDB 100% local</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Sin servidores ni cuentas externas</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Persistencia al cerrar y reabrir</span>
            </li>
          </ul>
        </div>
      </main>

      {/* --- FOOTER --- */}
      <footer className="max-w-xl mx-auto w-full pt-6 pb-2 text-center text-[11px] text-zinc-500 flex items-center justify-center gap-4">
        <span className="flex items-center gap-1">
          <Smartphone className="w-3.5 h-3.5" />
          Android APK Ready
        </span>
        <span>•</span>
        <span className="flex items-center gap-1">
          <HardDrive className="w-3.5 h-3.5" />
          Almacenamiento Offline
        </span>
      </footer>
    </div>
  );
}
