import { useState, useEffect } from 'react';
import {
  Moon,
  Sun,
  Home,
  Calendar,
  DollarSign,
  Briefcase,
  Users,
  Mic,
  Wifi,
  WifiOff,
  Maximize2,
  Smartphone,
  LogOut,
  Sparkles,
  Wallet,
  LandPlot,
  Bug,
  Ship,
} from 'lucide-react';
import { ViewId, Language, Theme, UserProfile } from './types';
import { DEMO_USERS } from './data/mockData';
import IntroAnimation from './components/IntroAnimation';
import OnboardingView from './components/OnboardingView';
import LoginPage from './components/LoginPage';
import {
  HomeView,
  CalendarView,
  MarketView,
  BuyersView,
  CommunityView,
} from './components/DashboardViews';
import WalletView from './components/WalletView';
import FarmRecordsView from './components/FarmRecordsView';
import PestDoctorView from './components/PestDoctorView';
import HarvestAggregationPoolsView from './components/HarvestAggregationPoolsView';
import VoiceCommandModal from './components/VoiceCommandModal';

export default function App() {
  const [view, setView] = useState<ViewId>('view-splash');
  const [language, setLanguage] = useState<Language>('sw');
  const [theme, setTheme] = useState<Theme>('light');
  const [currentUser, setCurrentUser] = useState<UserProfile>(DEMO_USERS[0]);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [isFullscreenPhone, setIsFullscreenPhone] = useState<boolean>(false);
  const [isVoiceOpen, setIsVoiceOpen] = useState<boolean>(false);

  // Apply dark mode attribute to root element
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    setIsOnline(navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const isSw = language === 'sw';

  // Toggle theme
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  // Switch language
  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    document.documentElement.setAttribute('lang', lang);
  };

  // Navigation tabs for the stage sidebar
  const stageTabs: { id: ViewId; sw: string; en: string }[] = [
    { id: 'view-splash', sw: 'Utangulizi (Intro)', en: 'Intro Animation' },
    { id: 'view-onboarding', sw: 'Jinsi Inavyofanya Kazi', en: 'How it Works' },
    { id: 'view-login', sw: 'Kuingia (Login)', en: 'Login Page' },
    { id: 'view-home', sw: 'Nyumbani', en: 'Home Dashboard' },
    { id: 'view-wallet', sw: 'Pochi ya Mkulima (Wallet)', en: 'Farmer Wallet' },
    { id: 'view-calendar', sw: 'Kalenda ya Mazao', en: 'Crop Calendar' },
    { id: 'view-market', sw: 'Bei za Soko & Masoko ya Nje', en: 'Market Prices & Exports' },
    { id: 'view-farm-records', sw: 'Kumbukumbu & Dhamana ya Shamba', en: 'Farm Records & Credit Dossier' },
    { id: 'view-pest-doctor', sw: 'Daktari wa Mimea & Wadudu (Pest Doctor)', en: 'Crop Doctor & Pest Diagnostics' },
    { id: 'view-aggregation-pools', sw: 'Uuzaji wa Pamoja (AMCOS Pools)', en: 'Harvest Aggregation Pools' },
    { id: 'view-buyers', sw: 'Wanunuzi & Madalali', en: 'Buyers & Brokers' },
    { id: 'view-community', sw: 'Jumuiya ya Wakulima', en: 'Community' },
  ];

  // Whether the current view is chrome-less (splash, onboarding, login)
  const isChromeLess =
    view === 'view-splash' || view === 'view-onboarding' || view === 'view-login';

  return (
    <div className="min-h-screen w-full bg-[var(--bg)] text-[var(--ink)] flex flex-col items-center justify-start p-3 sm:p-6 lg:p-8 transition-colors duration-300">
      {/* Top Global Utility Bar */}
      <header className="w-full max-w-5xl flex items-center justify-between pb-4 border-b border-[var(--line)] mb-6 gap-3 flex-wrap">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-amber-300 flex items-center justify-center font-display font-bold text-base shadow-sm">
            A
          </div>
          <div>
            <div className="font-display font-bold text-lg text-[var(--ink)] leading-tight">
              Ardhi
            </div>
            <div className="text-[11px] text-[var(--ink-soft)]">
              {isSw ? 'Mwenzi wa Mkulima wa Kila Siku' : 'Daily Farmer Companion'}
            </div>
          </div>
        </div>

        {/* Global Controls: Layout Mode, Network Simulator, Theme, Language */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Layout Toggle */}
          <button
            id="layout-toggle-btn"
            onClick={() => setIsFullscreenPhone(!isFullscreenPhone)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-[var(--paper)] border border-[var(--line)] hover:border-[var(--forest)] text-[var(--ink)] transition-colors"
          >
            {isFullscreenPhone ? (
              <>
                <Smartphone className="w-3.5 h-3.5 text-[var(--forest)]" />
                <span>{isSw ? 'Mwonekano wa Hatua' : 'Studio Stage View'}</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-[var(--forest)]" />
                <span>{isSw ? 'Simu Kamili' : 'Focus Phone'}</span>
              </>
            )}
          </button>

          {/* Network Simulator Toggle */}
          <button
            id="network-toggle-btn"
            onClick={() => setIsOnline(!isOnline)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
              isOnline
                ? 'bg-[var(--paper)] text-[var(--forest)] border-[var(--line)]'
                : 'bg-amber-600/15 text-amber-700 dark:text-amber-300 border-amber-500/30'
            }`}
            title={isSw ? 'Bofya kubadilisha hali ya mtandao' : 'Click to toggle network state'}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5" />
                <span>Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5" />
                <span>Offline (Cache)</span>
              </>
            )}
          </button>

          {/* Theme Toggle */}
          <button
            id="global-theme-toggle"
            onClick={toggleTheme}
            className="p-2 rounded-full bg-[var(--paper)] border border-[var(--line)] hover:border-[var(--forest)] text-[var(--ink)] transition-colors"
            title={theme === 'light' ? 'Njia ya Giza' : 'Njia ya Mwanga'}
          >
            {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-300" />}
          </button>

          {/* Language Toggle */}
          <div className="flex bg-[var(--paper)] p-1 rounded-full border border-[var(--line)]">
            <button
              id="lang-sw-btn"
              onClick={() => handleLanguageChange('sw')}
              className={`px-2.5 py-1 rounded-full text-xs font-bold transition-all ${
                isSw
                  ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-sm'
                  : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
              }`}
            >
              SW
            </button>
            <button
              id="lang-en-btn"
              onClick={() => handleLanguageChange('en')}
              className={`px-2.5 py-1 rounded-full text-xs font-bold transition-all ${
                !isSw
                  ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-sm'
                  : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
              }`}
            >
              EN
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Stage */}
      <main className="w-full max-w-5xl flex gap-8 items-start justify-center flex-wrap lg:flex-nowrap">
        {/* Left Side Presentation Column (Visible in Stage Mode) */}
        {!isFullscreenPhone && (
          <aside className="w-full lg:w-80 flex-shrink-0 pt-2 space-y-5">
            <div>
              <span className="text-xs font-bold tracking-wider uppercase text-[var(--soil)] flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                {isSw ? 'Mfano wa Mwonekano' : 'Application Showcase'}
              </span>
              <h1 className="font-display text-3xl font-bold text-[var(--ink)] mt-1 mb-2">
                Ardhi
              </h1>
              <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                {isSw
                  ? 'Mwenzi wa mkulima wa kila siku — kalenda ya kupanda na kuvuna, hali ya hewa, bei za soko zinazobadilika, wanunuzi wenye uhakika, na jumuiya ya wakulima duniani kote.'
                  : 'Daily companion for smallholder farmers — planting calendars, local weather forecasts, real-time commodity prices, verified buyers, and knowledge sharing.'}
              </p>
            </div>

            {/* Screen Navigation Tabs */}
            <nav className="flex flex-col gap-1 border-l-2 border-[var(--line)] pl-3">
              {stageTabs.map((tab) => {
                const isActive = view === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`stage-tab-${tab.id}`}
                    onClick={() => setView(tab.id)}
                    className={`text-left py-1.5 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[var(--forest)] text-[#F7F4E9] font-bold shadow-sm'
                        : 'text-[var(--ink-soft)] hover:text-[var(--ink)] hover:bg-[var(--paper)]'
                    }`}
                  >
                    {isSw ? tab.sw : tab.en}
                  </button>
                );
              })}
            </nav>

            {/* Quick Highlights Card */}
            <div className="p-4 rounded-2xl bg-[var(--paper)] border border-[var(--line)] text-xs space-y-2">
              <div className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{isSw ? 'Maboresho na Vipengele Vipya:' : 'Key Features & Enhancements:'}</span>
              </div>
              <ul className="text-[11px] text-[var(--ink-soft)] space-y-1.5 list-disc list-inside">
                <li>
                  <strong className="text-[var(--ink)]">
                    {isSw ? 'Masoko ya Kimataifa & Ramani ya Dunia' : 'Global Export Insights & Corridors'}:
                  </strong>{' '}
                  {isSw
                    ? 'Ramani shirikishi ya masoko ya China, EU, Marekani, India, viashiria vya bei (EPI), na ushauri wa AI kuhusu nchi yenye faida kubwa.'
                    : 'Interactive world trade corridors (China, EU, US, India), Export Price Index (EPI), FCL container specs, and AI profit ranking.'}
                </li>
                <li>
                  <strong className="text-[var(--ink)]">
                    {isSw ? 'Kumbukumbu, Pembejeo & Dhamana ya Mkopo' : 'Farm Logs, Inputs & Credit Dossier'}:
                  </strong>{' '}
                  {isSw
                    ? 'Utunzaji wa kumbukumbu za shamba, soko la moja kwa moja la pembejeo za TOSCI/TFRA, na ripoti ya uzalishaji kama dhamana ya benki.'
                    : 'Farm plots & activity logs, TOSCI/TFRA accredited direct inputs store, and verified bank collateral credit dossier for CRDB/NMB/TADB.'}
                </li>
                <li>
                  <strong className="text-[var(--ink)]">
                    {isSw ? 'Pochi ya Mkulima (Wallet)' : 'Farmer Digital Wallet'}:
                  </strong>{' '}
                  {isSw
                    ? 'Kununua pembejeo zilizoidhinishwa, kutuma pesa kwa wakulima wengine, na kuweka fedha.'
                    : 'Directly buy farm inputs, transfer money to helpers/brokers, and top up via mobile money.'}
                </li>
              </ul>
            </div>
          </aside>
        )}

        {/* Right / Center Column: Mobile Device Simulation Frame */}
        <div className="flex flex-col items-center">
          {/* Phone Bezel */}
          <div
            id="mobile-phone-device"
            className="w-[360px] sm:w-[380px] h-[750px] bg-[var(--paper)] rounded-[46px] border border-[var(--line)] shadow-2xl p-3 flex flex-col relative overflow-hidden transition-all duration-300"
            style={{
              boxShadow: '0 30px 60px -25px rgba(20, 32, 26, 0.35)',
            }}
          >
            {/* Phone Screen Area */}
            <div className="w-full h-full rounded-[34px] overflow-hidden bg-[var(--bg)] flex flex-col relative">
              {/* Internal Floating Top Controls (Theme & Lang inside device) */}
              <div className="absolute top-2.5 right-3.5 z-40 flex items-center gap-1.5 pointer-events-auto">
                <button
                  id="phone-theme-toggle"
                  onClick={toggleTheme}
                  className="w-7 h-7 rounded-full bg-black/40 backdrop-blur-md text-[#F7F4E9] flex items-center justify-center text-xs shadow-sm hover:bg-black/60 transition-colors"
                  aria-label="Toggle theme"
                >
                  {theme === 'light' ? '🌙' : '☀️'}
                </button>
                <div className="flex bg-black/40 backdrop-blur-md rounded-full p-0.5 border border-white/10">
                  <button
                    onClick={() => handleLanguageChange('sw')}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold transition-colors ${
                      isSw ? 'bg-[var(--paper)] text-[var(--forest-dark)]' : 'text-white/70'
                    }`}
                  >
                    SW
                  </button>
                  <button
                    onClick={() => handleLanguageChange('en')}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold transition-colors ${
                      !isSw ? 'bg-[var(--paper)] text-[var(--forest-dark)]' : 'text-white/70'
                    }`}
                  >
                    EN
                  </button>
                </div>
              </div>

              {/* Status Bar (Hidden on Splash / Onboarding / Login for immersive feel) */}
              {!isChromeLess && (
                <div
                  id="phone-status-bar"
                  className="h-9 px-5 flex items-center justify-between text-[11px] font-semibold text-[var(--ink-soft)] flex-shrink-0 bg-[var(--bg)] z-30"
                >
                  <span>9:41</span>
                  <div className="flex items-center gap-2">
                    <span className="font-display text-xs text-[var(--forest)] font-bold">Ardhi</span>
                    {!isOnline && (
                      <span className="w-2 h-2 rounded-full bg-amber-500" title="Offline mode" />
                    )}
                  </div>
                </div>
              )}

              {/* Offline Banner when disconnected */}
              {!isOnline && !isChromeLess && (
                <div
                  id="offline-banner-pill"
                  className="mx-4 my-1 p-2 rounded-xl bg-[var(--soil)] text-[#F7F4E9] text-[11px] font-medium flex items-center gap-2 shadow-sm"
                >
                  <WifiOff className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">
                    {isSw
                      ? 'Nje ya mtandao — unaona data iliyohifadhiwa'
                      : 'Offline — viewing locally cached farm data'}
                  </span>
                </div>
              )}

              {/* Screen Body Views */}
              <div className="flex-1 overflow-y-auto no-scrollbar relative">
                {view === 'view-splash' && (
                  <IntroAnimation
                    language={language}
                    onComplete={() => setView('view-onboarding')}
                    onSkipToLogin={() => setView('view-login')}
                  />
                )}

                {view === 'view-onboarding' && (
                  <OnboardingView
                    language={language}
                    onFinish={() => setView('view-login')}
                  />
                )}

                {view === 'view-login' && (
                  <LoginPage
                    language={language}
                    onLoginSuccess={(user) => {
                      setCurrentUser(user);
                      setView('view-home');
                    }}
                    onBackToIntro={() => setView('view-splash')}
                  />
                )}

                {view === 'view-home' && (
                  <div className="p-4">
                    <HomeView
                      language={language}
                      user={currentUser}
                      onNavigateToWallet={() => setView('view-wallet')}
                      onNavigateToPestDoctor={() => setView('view-pest-doctor')}
                      onNavigateToAggregationPools={() => setView('view-aggregation-pools')}
                    />
                  </div>
                )}

                {view === 'view-wallet' && (
                  <div className="p-4">
                    <WalletView language={language} user={currentUser} />
                  </div>
                )}

                {view === 'view-calendar' && (
                  <div className="p-4">
                    <CalendarView language={language} user={currentUser} />
                  </div>
                )}

                {view === 'view-market' && (
                  <div className="p-4">
                    <MarketView
                      language={language}
                      user={currentUser}
                      onNavigateToWallet={() => setView('view-wallet')}
                      onNavigateToBuyers={() => setView('view-buyers')}
                      onNavigateToAggregationPools={() => setView('view-aggregation-pools')}
                    />
                  </div>
                )}

                {view === 'view-buyers' && (
                  <div className="p-4">
                    <BuyersView language={language} user={currentUser} />
                  </div>
                )}

                {view === 'view-farm-records' && (
                  <div className="p-4">
                    <FarmRecordsView
                      language={language}
                      user={currentUser}
                      onNavigateToWallet={() => setView('view-wallet')}
                      onNavigateToMarket={() => setView('view-market')}
                      onNavigateToPestDoctor={() => setView('view-pest-doctor')}
                    />
                  </div>
                )}

                {view === 'view-pest-doctor' && (
                  <div className="p-4">
                    <PestDoctorView
                      language={language}
                      user={currentUser}
                      onNavigateToInputsStore={() => setView('view-farm-records')}
                      onNavigateToFarmRecords={() => setView('view-farm-records')}
                    />
                  </div>
                )}

                {view === 'view-aggregation-pools' && (
                  <div className="p-4">
                    <HarvestAggregationPoolsView
                      language={language}
                      user={currentUser}
                      onNavigateToWallet={() => setView('view-wallet')}
                      onNavigateToBuyers={() => setView('view-buyers')}
                    />
                  </div>
                )}

                {view === 'view-community' && (
                  <div className="p-4">
                    <CommunityView language={language} user={currentUser} />
                  </div>
                )}
              </div>

              {/* Floating Voice Command Mic Button (Shown on Dashboard Home) */}
              {view === 'view-home' && (
                <button
                  id="floating-mic-button"
                  onClick={() => setIsVoiceOpen(true)}
                  className="absolute right-4 bottom-20 z-30 w-12 h-12 rounded-full bg-[var(--forest)] text-[#F7F4E9] shadow-lg shadow-[var(--forest)]/40 flex items-center justify-center hover:scale-105 active:scale-95 transition-all cursor-pointer"
                  title={isSw ? 'Amri ya Sauti' : 'Voice Command'}
                >
                  <Mic className="w-5 h-5" />
                </button>
              )}

              {/* Bottom Navigation Bar (Hidden during Intro, Onboarding, Login) */}
              {!isChromeLess && (
                <nav
                  id="phone-bottom-nav"
                  className="h-16 border-t border-[var(--line)] bg-[var(--paper)] flex items-center justify-around px-0.5 flex-shrink-0 z-20"
                >
                  {[
                    { id: 'view-home' as ViewId, icon: Home, sw: 'Nyumbani', en: 'Home' },
                    { id: 'view-farm-records' as ViewId, icon: LandPlot, sw: 'Shamba', en: 'Farm' },
                    { id: 'view-pest-doctor' as ViewId, icon: Bug, sw: 'Daktari', en: 'Doctor' },
                    { id: 'view-aggregation-pools' as ViewId, icon: Ship, sw: 'AMCOS', en: 'Pools' },
                    { id: 'view-market' as ViewId, icon: DollarSign, sw: 'Masoko', en: 'Prices' },
                    { id: 'view-wallet' as ViewId, icon: Wallet, sw: 'Pochi', en: 'Wallet' },
                  ].map((tab) => {
                    const isActive = view === tab.id;
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        id={`bottom-nav-${tab.id}`}
                        onClick={() => setView(tab.id)}
                        className={`flex flex-col items-center justify-center gap-0.5 py-1 px-1 rounded-xl transition-colors cursor-pointer ${
                          isActive
                            ? 'text-[var(--forest)] font-bold'
                            : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
                        <span className="text-[8.5px] font-medium leading-tight truncate max-w-[48px]">{isSw ? tab.sw : tab.en}</span>
                      </button>
                    );
                  })}
                </nav>
              )}
            </div>
          </div>

          {/* Device Controls Footer: Replay Intro, Reset to Login, or Logout */}
          <div className="mt-4 flex items-center gap-3 text-xs">
            <button
              onClick={() => setView('view-splash')}
              className="px-3 py-1.5 rounded-full bg-[var(--paper)] border border-[var(--line)] text-[var(--ink-soft)] hover:text-[var(--ink)] hover:border-[var(--forest)] font-semibold transition-colors flex items-center gap-1.5"
            >
              <span>🎬 {isSw ? 'Tazama Utangulizi' : 'Play Intro'}</span>
            </button>
            <button
              onClick={() => setView('view-login')}
              className="px-3 py-1.5 rounded-full bg-[var(--paper)] border border-[var(--line)] text-[var(--ink-soft)] hover:text-[var(--ink)] hover:border-[var(--forest)] font-semibold transition-colors flex items-center gap-1.5"
            >
              <span>🔐 {isSw ? 'Ukurasa wa Kuingia' : 'Login Page'}</span>
            </button>
            {!isChromeLess && (
              <button
                onClick={() => setView('view-login')}
                className="px-3 py-1.5 rounded-full bg-[var(--paper)] border border-[var(--line)] text-[var(--soil)] font-semibold transition-colors flex items-center gap-1"
                title={isSw ? 'Ondoka kwenye akaunti' : 'Sign out'}
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{isSw ? 'Ondoka' : 'Log out'}</span>
              </button>
            )}
          </div>
        </div>
      </main>

      {/* Voice Assistant Simulation Dialog */}
      <VoiceCommandModal
        language={language}
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
      />
    </div>
  );
}
