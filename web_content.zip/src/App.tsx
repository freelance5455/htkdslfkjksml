import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Film,
  LayoutGrid,
  Calculator,
  Image as ImageIcon,
  Bookmark,
  Camera,
  Scissors,
  Phone,
  Package,
  Settings,
  Wifi,
  WifiOff,
  Menu,
  X,
  Plus,
  Download,
  UploadCloud,
  FileArchive
} from 'lucide-react';
import {
  AppSettings,
  CalculationHistoryItem,
  LogoItem,
  MemoryItem,
  SplitAppType,
  VideoItem,
} from './types';
import {
  defaultSettings,
  loadCalculations,
  loadLogos,
  loadMemories,
  loadSettings,
  loadVideos,
  saveSettings,
} from './utils/storage';
import { downloadApkBlob, downloadZipBlob } from './utils/downloadHelper';

import { JulliCompanion } from './components/JulliCompanion';
import { LogoDesigner } from './components/LogoDesigner';
import { VideoStudio } from './components/VideoStudio';
import { SplitScreenWorkspace } from './components/SplitScreenWorkspace';
import { SmartCalculator } from './components/SmartCalculator';
import { MediaGallery } from './components/MediaGallery';
import { MemoryNotes } from './components/MemoryNotes';
import { SettingsModal } from './components/SettingsModal';
import { ApkStorageModal } from './components/ApkStorageModal';
import { CameraModal } from './components/CameraModal';
import { CallDialerModal } from './components/CallDialerModal';
import { ScreenshotModal } from './components/ScreenshotModal';

export default function App() {
  // Navigation & View mode
  const [activeTab, setActiveTab] = useState<'logo' | 'animate' | 'split' | 'calculator' | 'gallery' | 'notes'>('logo');

  // Stored application states
  const [settings, setSettings] = useState<AppSettings>(loadSettings);
  const [savedLogos, setSavedLogos] = useState<LogoItem[]>(loadLogos);
  const [savedVideos, setSavedVideos] = useState<VideoItem[]>(loadVideos);
  const [memories, setMemories] = useState<MemoryItem[]>(loadMemories);
  const [calculations, setCalculations] = useState<CalculationHistoryItem[]>(loadCalculations);

  // Active items
  const [activeLogoForAnimation, setActiveLogoForAnimation] = useState<LogoItem | null>(() => {
    const list = loadLogos();
    return list.length > 0 ? list[0] : null;
  });

  // Modals state
  const [showSettings, setShowSettings] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [showScreenshotModal, setShowScreenshotModal] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Online / Offline Status
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [networkBanner, setNetworkBanner] = useState<string | null>(null);

  useEffect(() => {
    // Register PWA service worker if available
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then((reg) => {
        reg.update().catch(() => {});
      }).catch((e) => {
        console.warn('ServiceWorker registration error:', e);
      });
    }


    // Network status listeners
    const handleOnline = () => {
      setIsOnline(true);
      setNetworkBanner('Aapka device Online aa gaya hai! Sabhi Gemini 4K AI models & Cloud services ab active hain.');
      setTimeout(() => setNetworkBanner(null), 5000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setNetworkBanner('Aapka device Offline mode me hai. Basic Calculator (+ - × ÷) aur local memories offline available hain.');
      setTimeout(() => setNetworkBanner(null), 5000);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Handler when a logo is generated or selected to animate
  const handleAnimateLogo = (logo: LogoItem) => {
    setActiveLogoForAnimation(logo);
    setActiveTab('animate');
  };

  // Handler when a new logo is created
  const handleLogoCreated = (logo: LogoItem) => {
    setSavedLogos((prev) => [logo, ...prev.filter((l) => l.id !== logo.id)]);
    setActiveLogoForAnimation(logo);
  };

  // Handler when a new video is generated
  const handleVideoCreated = (video: VideoItem) => {
    setSavedVideos((prev) => [video, ...prev.filter((v) => v.id !== video.id)]);
  };

  // Handler for adding memory
  const handleAddMemory = (memory: MemoryItem) => {
    setMemories((prev) => [memory, ...prev.filter((m) => m.id !== memory.id)]);
  };

  const handleDeleteMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  // Handler for calculation history
  const handleAddCalculation = (calc: CalculationHistoryItem) => {
    setCalculations((prev) => [calc, ...prev]);
  };

  // Render components for split screen or main tab
  const renderLogoDesigner = () => (
    <LogoDesigner
      settings={settings}
      onAnimateLogo={handleAnimateLogo}
      onLogoCreated={handleLogoCreated}
      savedLogos={savedLogos}
    />
  );

  const renderVideoStudio = () => (
    <VideoStudio
      settings={settings}
      activeLogo={activeLogoForAnimation}
      onVideoCreated={handleVideoCreated}
      savedVideos={savedVideos}
    />
  );

  const renderCalculator = () => (
    <SmartCalculator
      calculationHistory={calculations}
      onAddCalculation={handleAddCalculation}
      isGlobalOffline={!isOnline || settings.offlineMode}
    />
  );

  const renderJulliChat = () => (
    <div className="p-4 space-y-4">
      <div className="p-4 bg-gradient-to-r from-purple-950/40 to-slate-900 border border-purple-500/30 rounded-2xl">
        <h3 className="font-bold text-white text-base flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-pink-400" />
          Hey Julli Assistant Workspace
        </h3>
        <p className="text-xs text-slate-300 mt-1">
          Say "Hey Julli" or interact with the floating companion in the bottom corner to ask questions, design logos, or operate phone apps.
        </p>
      </div>
      <MemoryNotes
        memories={memories}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
      />
    </div>
  );

  const renderGallery = () => (
    <MediaGallery
      logos={savedLogos}
      videos={savedVideos}
      onSelectLogo={(logo) => {
        setActiveLogoForAnimation(logo);
        setActiveTab('logo');
      }}
      onSelectVideo={() => setActiveTab('animate')}
      onAnimateLogo={handleAnimateLogo}
    />
  );

  const renderCamera = () => (
    <div className="p-6 flex flex-col items-center justify-center text-center">
      <div className="w-16 h-16 rounded-2xl bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4">
        <Camera className="w-8 h-8" />
      </div>
      <h3 className="font-bold text-white text-base mb-1">Camera Workspace</h3>
      <p className="text-xs text-slate-400 max-w-sm mb-4">
        Open the device camera to take a photo and send it directly to the Logo Designer or Video Studio.
      </p>
      <button
        onClick={() => setShowCameraModal(true)}
        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30"
      >
        Open Device Camera Now
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Notification / Online-Offline Banner */}
      {networkBanner && (
        <div
          className={`py-2 px-4 text-xs font-semibold text-center flex items-center justify-center gap-2 transition-all ${
            isOnline ? 'bg-emerald-950 text-emerald-200 border-b border-emerald-500/40' : 'bg-amber-950 text-amber-200 border-b border-amber-500/40'
          }`}
        >
          {isOnline ? <Wifi className="w-4 h-4 text-emerald-400" /> : <WifiOff className="w-4 h-4 text-amber-400" />}
          <span>{networkBanner}</span>
        </div>
      )}

      {/* Prominent Direct APK Download Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-indigo-950 to-purple-950 border-b border-purple-500/30 px-3 py-1.5 text-xs flex flex-wrap items-center justify-between gap-2 shadow-md">
        <div className="flex items-center gap-2 text-purple-200">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="text-[11px] sm:text-xs">
            <b>Android APK Ready:</b> BrandMorph_Julli_v1.0.apk (<b>7.10 MB</b> • Signed v1/v2/v3 • Standalone Offline Suite)
          </span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={async () => {
              setNetworkBanner('Downloading BrandMorph_Julli_v1.0.apk (7.10 MB)...');
              const res = await downloadApkBlob();
              if (res.success) {
                setNetworkBanner('Download Shuru ho gaya! 7.10 MB package phone me save ho raha hai. Notification bar se Open karke Install karein.');
              } else {
                setShowApkModal(true);
              }
              setTimeout(() => setNetworkBanner(null), 8000);
            }}
            className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[11px] shadow flex items-center gap-1 transition-transform hover:scale-105 cursor-pointer"
            title="Download verified 7.10 MB binary APK"
          >
            <Download className="w-3.5 h-3.5" />
            1. Direct APK (7.10 MB)
          </button>
          <button
            onClick={async () => {
              setNetworkBanner('Downloading Full Project ZIP (3.08 MB)...');
              const res = await downloadZipBlob();
              if (res.success) {
                setNetworkBanner('BrandMorph_Project.zip download complete!');
              } else {
                setShowApkModal(true);
              }
              setTimeout(() => setNetworkBanner(null), 8000);
            }}
            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] shadow flex items-center gap-1 transition-transform hover:scale-105 cursor-pointer"
            title="Download Complete Project ZIP Archive (3.08 MB)"
          >
            <FileArchive className="w-3.5 h-3.5" />
            2. Full ZIP (3.08 MB)
          </button>
          <button
            onClick={() => setShowApkModal(true)}
            className="px-2.5 py-1 rounded-lg bg-emerald-700/80 hover:bg-emerald-600 text-white font-bold text-[11px] border border-emerald-400/40 shadow flex items-center gap-1 transition-transform hover:scale-105 cursor-pointer"
            title="Upload to Google Drive and copy share link"
          >
            <UploadCloud className="w-3.5 h-3.5 text-emerald-300" />
            3. Drive Share Link
          </button>
        </div>
      </div>

      {/* Primary Top App Bar */}
      <header className="sticky top-0 z-30 bg-slate-950/90 border-b border-slate-800/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          {/* Brand Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-extrabold shadow-lg shadow-indigo-600/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-white text-base tracking-tight">BrandMorph</h1>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-purple-950 text-pink-300 border border-purple-500/30">
                  + Hey Julli
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">AI Logo Designer & Omni Video Animator</p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center bg-slate-900/90 p-1 rounded-2xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('logo')}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'logo'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" /> Logo Designer
            </button>

            <button
              onClick={() => setActiveTab('animate')}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'animate'
                  ? 'bg-pink-600 text-white shadow-md shadow-pink-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" /> Video Studio
            </button>

            <button
              onClick={() => setActiveTab('split')}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'split'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Split Apps
            </button>

            <button
              onClick={() => setActiveTab('calculator')}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'calculator'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" /> Calculator
            </button>

            <button
              onClick={() => setActiveTab('gallery')}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'gallery'
                  ? 'bg-slate-800 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" /> Gallery ({savedLogos.length + savedVideos.length})
            </button>

            <button
              onClick={() => setActiveTab('notes')}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'notes'
                  ? 'bg-slate-800 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" /> Memories
            </button>
          </nav>

          {/* Action Quick Tools & Settings */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Interactive Offline / Online Mode Toggle Button */}
            <button
              onClick={() => {
                const nextOffline = !settings.offlineMode;
                const updated = { ...settings, offlineMode: nextOffline };
                setSettings(updated);
                saveSettings(updated);
                setNetworkBanner(
                  nextOffline
                    ? 'Offline Mode ON: Basic calculations (+ - × ÷) & vector logos local chalenge.'
                    : 'Online Mode ON: Pollinations AI & Gemini Cloud features ab active hain!'
                );
                setTimeout(() => setNetworkBanner(null), 4500);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                !settings.offlineMode && isOnline
                  ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900/60 shadow-sm shadow-emerald-900/20'
                  : 'bg-amber-950/70 text-amber-300 border-amber-500/40 hover:bg-amber-900/60 shadow-sm shadow-amber-900/20'
              }`}
              title="Click to toggle Offline / Online mode"
            >
              {!settings.offlineMode && isOnline ? (
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span className="font-mono text-[11px]">
                {!settings.offlineMode && isOnline ? 'ONLINE' : 'OFFLINE'}
              </span>
            </button>

            {/* Direct Verified APK Download Link & Modal Opener */}
            <button
              onClick={() => setShowApkModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-purple-600/30 transition-all hover:scale-105 shrink-0 cursor-pointer"
              title="Download Genuine Verified Android APK (7.09 MB)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Download APK (7.1 MB)</span>
              <span className="sm:hidden font-mono text-[10px]">APK</span>
            </button>

            {/* Google Drive Upload Trigger */}
            <button
              onClick={() => setShowApkModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 font-bold text-xs shadow-md transition-all hover:scale-105 shrink-0 cursor-pointer"
              title="Save BrandMorph APK to your Google Drive"
            >
              <UploadCloud className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Drive me Bhejo</span>
              <span className="sm:hidden font-mono text-[10px]">Drive</span>
            </button>

            {/* Quick Camera Snapshot Button */}
            <button
              onClick={() => setShowCameraModal(true)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
              title="Camera Snapper"
            >
              <Camera className="w-4 h-4 text-pink-400" />
            </button>

            {/* Quick Screenshot Button */}
            <button
              onClick={() => setShowScreenshotModal(true)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
              title="Take Screenshot"
            >
              <Scissors className="w-4 h-4 text-indigo-400" />
            </button>

            {/* Quick Phone Call Button */}
            <button
              onClick={() => setShowCallModal(true)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
              title="Call Dialer"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
            </button>

            {/* APK Package Storage & Integrity Modal Button */}
            <button
              onClick={() => setShowApkModal(true)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-purple-500/50"
              title="APK Storage & Diagnostic Recheck"
            >
              <Package className="w-4 h-4 text-purple-400" />
            </button>

            {/* Settings (Password-protected API Vault) */}
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
              title="Settings & API Vault"
            >
              <Settings className="w-4 h-4 text-slate-300" />
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-800 bg-slate-950 p-4 space-y-2 animate-in slide-in-from-top duration-200">
            <button
              onClick={() => {
                setShowApkModal(true);
                setMobileMenuOpen(false);
              }}
              className="w-full p-3 rounded-xl font-bold text-xs text-left flex items-center justify-between bg-gradient-to-r from-purple-700 to-indigo-700 text-white shadow-lg shadow-purple-900/40 border border-purple-400/40 cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Download className="w-4 h-4 text-purple-200" />
                Download Android APK (BrandMorph_Julli • 7.09 MB)
              </span>
              <span className="text-[10px] bg-purple-950/80 text-purple-200 border border-purple-400/30 px-2 py-0.5 rounded-full font-mono font-bold">
                APK
              </span>
            </button>
            <button
              onClick={() => {
                setShowApkModal(true);
                setMobileMenuOpen(false);
              }}
              className="w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center justify-between bg-amber-950/90 text-amber-200 border border-amber-500/40 cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <FileArchive className="w-4 h-4 text-amber-400" />
                2. Full Project ZIP (BrandMorph • 3.0 MB)
              </span>
              <span className="text-[10px] bg-amber-900/60 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full font-mono">
                ZIP
              </span>
            </button>
            <button
              onClick={() => {
                setShowApkModal(true);
                setMobileMenuOpen(false);
              }}
              className="w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center justify-between bg-emerald-950/90 text-emerald-200 border border-emerald-500/40 cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <UploadCloud className="w-4 h-4 text-emerald-400" />
                3. APK Google Drive Share Link
              </span>
              <span className="text-[10px] bg-emerald-900/60 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full font-mono">
                DRIVE
              </span>
            </button>
            <button
              onClick={() => {
                setActiveTab('logo');
                setMobileMenuOpen(false);
              }}
              className={`w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center gap-2 ${
                activeTab === 'logo' ? 'bg-indigo-600 text-white' : 'text-slate-300 bg-slate-900'
              }`}
            >
              <Sparkles className="w-4 h-4 text-indigo-400" /> Logo Designer (4K gemini-3-pro-image-preview)
            </button>

            <button
              onClick={() => {
                setActiveTab('animate');
                setMobileMenuOpen(false);
              }}
              className={`w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center gap-2 ${
                activeTab === 'animate' ? 'bg-pink-600 text-white' : 'text-slate-300 bg-slate-900'
              }`}
            >
              <Film className="w-4 h-4 text-pink-400" /> Video Studio (gemini-omni-1.1-flash 16:9 / 9:16)
            </button>

            <button
              onClick={() => {
                setActiveTab('split');
                setMobileMenuOpen(false);
              }}
              className={`w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center gap-2 ${
                activeTab === 'split' ? 'bg-purple-600 text-white' : 'text-slate-300 bg-slate-900'
              }`}
            >
              <LayoutGrid className="w-4 h-4 text-purple-400" /> Split Apps (Do App Ek Saath)
            </button>

            <button
              onClick={() => {
                setActiveTab('calculator');
                setMobileMenuOpen(false);
              }}
              className={`w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center gap-2 ${
                activeTab === 'calculator' ? 'bg-cyan-600 text-white' : 'text-slate-300 bg-slate-900'
              }`}
            >
              <Calculator className="w-4 h-4 text-cyan-400" /> Smart Calculator (Offline +-×÷ + Online π√%^)
            </button>

            <button
              onClick={() => {
                setActiveTab('gallery');
                setMobileMenuOpen(false);
              }}
              className={`w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center gap-2 ${
                activeTab === 'gallery' ? 'bg-slate-800 text-white' : 'text-slate-300 bg-slate-900'
              }`}
            >
              <ImageIcon className="w-4 h-4 text-indigo-400" /> Media Gallery ({savedLogos.length + savedVideos.length})
            </button>

            <button
              onClick={() => {
                setActiveTab('notes');
                setMobileMenuOpen(false);
              }}
              className={`w-full p-2.5 rounded-xl font-bold text-xs text-left flex items-center gap-2 ${
                activeTab === 'notes' ? 'bg-slate-800 text-white' : 'text-slate-300 bg-slate-900'
              }`}
            >
              <Bookmark className="w-4 h-4 text-pink-400" /> Julli Memories ("Yaad Rakhna")
            </button>
          </div>
        )}
      </header>

      {/* Main View Area */}
      <main className="flex-1 overflow-x-hidden">
        {/* Prominent Quick Download Bar for ZIP & APK */}
        <div className="max-w-7xl mx-auto px-4 pt-4 pb-1">
          <div className="p-3 sm:p-4 bg-gradient-to-r from-amber-950/60 via-slate-900 to-purple-950/60 border border-amber-500/40 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
                <FileArchive className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                  Complete Project .ZIP Archive Available
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded font-mono font-bold">
                    3.0 MB
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400">
                  Includes full source code, components, apk.html, and binary APK package
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={async () => {
                  setNetworkBanner('Downloading apk.zip (3.0 MB)...');
                  const res = await downloadZipBlob();
                  if (res.success) {
                    setNetworkBanner('apk.zip download complete!');
                  }
                  setTimeout(() => setNetworkBanner(null), 6000);
                }}
                className="flex-1 sm:flex-initial px-4 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-transform hover:scale-105 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Download .ZIP (3.0 MB)
              </button>

              <button
                onClick={() => setShowApkModal(true)}
                className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 transition-colors cursor-pointer"
              >
                All Download Links
              </button>
            </div>
          </div>
        </div>

        {activeTab === 'logo' && renderLogoDesigner()}
        {activeTab === 'animate' && renderVideoStudio()}
        {activeTab === 'calculator' && renderCalculator()}
        {activeTab === 'gallery' && renderGallery()}
        {activeTab === 'notes' && (
          <div className="p-4 lg:p-6 max-w-4xl mx-auto">
            <MemoryNotes
              memories={memories}
              onAddMemory={handleAddMemory}
              onDeleteMemory={handleDeleteMemory}
            />
          </div>
        )}
        {activeTab === 'split' && (
          <SplitScreenWorkspace
            settings={settings}
            activeLogo={activeLogoForAnimation}
            savedLogos={savedLogos}
            savedVideos={savedVideos}
            renderLogoDesigner={renderLogoDesigner}
            renderVideoStudio={renderVideoStudio}
            renderCalculator={renderCalculator}
            renderJulliChat={renderJulliChat}
            renderGallery={renderGallery}
            renderCamera={renderCamera}
            onCloseSplit={() => setActiveTab('logo')}
          />
        )}
      </main>

      {/* Hey Julli Floating Digital Companion Mascot */}
      <JulliCompanion
        settings={settings}
        onOpenApp={(app) => {
          if (app === 'logo') setActiveTab('logo');
          else if (app === 'animate') setActiveTab('animate');
          else if (app === 'calculator') setActiveTab('calculator');
          else if (app === 'gallery') setActiveTab('gallery');
          else if (app === 'notes') setActiveTab('notes');
        }}
        onTriggerCamera={() => setShowCameraModal(true)}
        onTriggerScreenshot={() => setShowScreenshotModal(true)}
        onTriggerCall={(contact) => setShowCallModal(true)}
        onToggleSplit={() => setActiveTab(activeTab === 'split' ? 'logo' : 'split')}
        memories={memories}
        onAddMemory={handleAddMemory}
        onUseImageAsLogo={(imageUrl, prompt) => {
          const item: LogoItem = {
            id: `poll_${Date.now()}`,
            brandName: prompt.slice(0, 20) || 'Pollinations Logo',
            industry: 'Creative Design',
            style: 'Pollinations AI',
            colors: ['#ec4899', '#6366f1'],
            tagline: 'Generated via Chat',
            description: prompt,
            imageSize: '1K',
            aspectRatio: '1:1',
            imageUrl,
            imageBase64: imageUrl.replace(/^data:image\/[a-z]+;base64,/, ''),
            mimeType: 'image/jpeg',
            timestamp: Date.now(),
            promptUsed: prompt,
            modelUsed: 'Pollinations AI',
          };
          handleLogoCreated(item);
          setActiveTab('logo');
        }}
        onAnimateImage={(imageUrl, prompt) => {
          const item: LogoItem = {
            id: `poll_anim_${Date.now()}`,
            brandName: prompt.slice(0, 20) || 'Pollinations Media',
            industry: 'Creative Design',
            style: 'Pollinations AI',
            colors: ['#ec4899', '#6366f1'],
            tagline: 'Generated via Chat',
            description: prompt,
            imageSize: '1K',
            aspectRatio: '1:1',
            imageUrl,
            imageBase64: imageUrl.replace(/^data:image\/[a-z]+;base64,/, ''),
            mimeType: 'image/jpeg',
            timestamp: Date.now(),
            promptUsed: prompt,
            modelUsed: 'Pollinations AI',
          };
          handleLogoCreated(item);
          setActiveLogoForAnimation(item);
          setActiveTab('animate');
        }}
      />

      {/* Modals */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newSet) => setSettings(newSet)}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showApkModal && (
        <ApkStorageModal onClose={() => setShowApkModal(false)} />
      )}

      {showCameraModal && (
        <CameraModal
          onCapture={(capturedBase64) => {
            const uploadedLogo: LogoItem = {
              id: `cam_${Date.now()}`,
              brandName: 'Camera Snapshot',
              industry: 'Captured Photo',
              style: 'Real Image',
              colors: ['#a855f7'],
              tagline: 'Camera Snap',
              description: 'Photo captured via device camera for animation',
              imageSize: '1K',
              aspectRatio: '1:1',
              imageUrl: capturedBase64,
              imageBase64: capturedBase64.replace(/^data:image\/[a-z]+;base64,/, ''),
              mimeType: 'image/png',
              timestamp: Date.now(),
              promptUsed: 'Camera photo snap',
              modelUsed: 'camera',
            };
            handleLogoCreated(uploadedLogo);
            setActiveTab('animate');
          }}
          onClose={() => setShowCameraModal(false)}
        />
      )}

      {showCallModal && (
        <CallDialerModal onClose={() => setShowCallModal(false)} />
      )}

      {showScreenshotModal && (
        <ScreenshotModal
          onUseAsSource={(dataUrl) => {
            const shotLogo: LogoItem = {
              id: `shot_${Date.now()}`,
              brandName: 'Screen Capture',
              industry: 'UI Screenshot',
              style: 'Screenshot',
              colors: ['#6366f1'],
              tagline: 'Screen Snapshot',
              description: 'Captured screenshot for video animation',
              imageSize: '1K',
              aspectRatio: '1:1',
              imageUrl: dataUrl,
              imageBase64: dataUrl.replace(/^data:image\/[a-z]+;base64,/, ''),
              mimeType: 'image/png',
              timestamp: Date.now(),
              promptUsed: 'Screenshot capture',
              modelUsed: 'screenshot',
            };
            handleLogoCreated(shotLogo);
            setActiveTab('animate');
          }}
          onClose={() => setShowScreenshotModal(false)}
        />
      )}
    </div>
  );
}
