import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/screens/SplashScreen';
import { MainMenuScreen } from './components/screens/MainMenuScreen';
import { ModeSelectScreen } from './components/screens/ModeSelectScreen';
import { AiDifficultyScreen } from './components/screens/AiDifficultyScreen';
import { GameScreen } from './components/screens/GameScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { MultiplayerScreen } from './components/screens/MultiplayerScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { LearnScreen } from './components/screens/LearnScreen';
import { TournamentHubScreen } from './components/screens/TournamentHubScreen';
import { DailyChallengesScreen } from './components/screens/DailyChallengesScreen';
import { LeaderboardScreen } from './components/screens/LeaderboardScreen';
import { ProgressionScreen } from './components/screens/ProgressionScreen';
import { NotificationDrawer } from './components/screens/NotificationDrawer';
import { AdminDashboardModal } from './components/screens/AdminDashboardModal';
import { FairPlayModal } from './components/screens/FairPlayModal';
import { BottomNav, NavTab } from './components/common/BottomNav';
import {
  GameMode,
  AiDifficulty,
  GameSettings,
  UserProfile,
  MatchResult,
  OnlineLobbyPlayer,
  TournamentPairingResult,
} from './types/chess';
import {
  loadProfile,
  saveProfile,
  loadSettings,
  saveSettings,
  recordMatchOutcome,
  DEFAULT_SETTINGS,
  SavedGame,
} from './services/storage';
import { sound } from './services/sound';
import { tournamentService } from './services/tournamentService';
import { achievementService } from './services/achievementService';
import { notificationService } from './services/notificationService';

type ScreenState =
  | 'splash'
  | 'main_menu'
  | 'mode_select'
  | 'ai_difficulty'
  | 'game'
  | 'settings'
  | 'multiplayer'
  | 'profile'
  | 'learn'
  | 'tournaments'
  | 'daily_challenges'
  | 'leaderboard'
  | 'progression';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenState>('splash');
  const [currentTab, setCurrentTab] = useState<NavTab>('home');

  // Modals state
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAdminConsole, setShowAdminConsole] = useState(false);
  const [fairPlayReportTarget, setFairPlayReportTarget] = useState<{
    id: string;
    name: string;
    gameId?: string;
  } | null>(null);

  // Active tournament match linkage
  const [activeTournamentMatch, setActiveTournamentMatch] = useState<{
    tournamentId: string;
    pairingId: string;
  } | null>(null);

  // Persisted state
  const [profile, setProfile] = useState<UserProfile>(() => loadProfile());
  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());

  // Active Game Configuration
  const [activeGameConfig, setActiveGameConfig] = useState<{
    mode: GameMode;
    aiDifficulty?: AiDifficulty;
    timeControlSeconds: number;
    incrementSeconds: number;
    playerSide: 'w' | 'b';
    opponentInfo?: { name: string; avatar: string; rating: number };
    roomId?: string;
    initialFen?: string;
    initialWhiteTime?: number;
    initialBlackTime?: number;
  }>({
    mode: 'ai',
    aiDifficulty: 'medium',
    timeControlSeconds: 600,
    incrementSeconds: 0,
    playerSide: 'w',
  });

  // Keep sound settings synced
  useEffect(() => {
    sound.setSoundEnabled(settings.soundEnabled);
    sound.setMusicEnabled(settings.musicEnabled);
  }, [settings]);

  // Handle bottom navigation tabs
  const handleTabChange = (tab: NavTab) => {
    setCurrentTab(tab);
    if (tab === 'home') {
      setCurrentScreen('main_menu');
    } else if (tab === 'tournaments') {
      setCurrentScreen('tournaments');
    } else if (tab === 'daily') {
      setCurrentScreen('daily_challenges');
    } else if (tab === 'leaderboard') {
      setCurrentScreen('leaderboard');
    } else if (tab === 'progression') {
      setCurrentScreen('progression');
    } else if (tab === 'settings') {
      setCurrentScreen('settings');
    }
  };

  // Quick Play Now action (starts standard AI match or resume)
  const handlePlayNow = () => {
    setActiveTournamentMatch(null);
    setActiveGameConfig({
      mode: 'ai',
      aiDifficulty: 'medium',
      timeControlSeconds: 600,
      incrementSeconds: 0,
      playerSide: 'w',
    });
    setCurrentScreen('game');
  };

  // Start AI Match
  const handleStartAiMatch = (
    difficulty: AiDifficulty,
    timeSeconds: number,
    incrementSeconds: number,
    colorChoice: 'w' | 'b' | 'random'
  ) => {
    setActiveTournamentMatch(null);
    const chosenSide =
      colorChoice === 'random' ? (Math.random() > 0.5 ? 'w' : 'b') : colorChoice;

    setActiveGameConfig({
      mode: 'ai',
      aiDifficulty: difficulty,
      timeControlSeconds: timeSeconds,
      incrementSeconds,
      playerSide: chosenSide,
    });
    setCurrentScreen('game');
  };

  // Start Online or Lobby Match
  const handleStartOnlineMatch = (
    opponent: OnlineLobbyPlayer,
    _isPrivate = false,
    roomId?: string
  ) => {
    setActiveTournamentMatch(null);
    setActiveGameConfig({
      mode: 'online',
      timeControlSeconds: 600,
      incrementSeconds: 0,
      playerSide: Math.random() > 0.5 ? 'w' : 'b',
      opponentInfo: {
        name: opponent.name,
        avatar: opponent.avatar,
        rating: opponent.rating,
      },
      roomId: roomId || `LOBBY-${opponent.id}`,
    });
    setCurrentScreen('game');
  };

  // Start Local Two-Player Match
  const handleStartLocalMatch = () => {
    setActiveTournamentMatch(null);
    setActiveGameConfig({
      mode: 'local',
      timeControlSeconds: 600,
      incrementSeconds: 0,
      playerSide: 'w',
      opponentInfo: {
        name: 'Player 2 (Black)',
        avatar: '👤',
        rating: profile.rating,
      },
    });
    setCurrentScreen('game');
  };

  // Launch official tournament pairing match
  const handleLaunchTournamentMatch = (params: {
    tournamentId: string;
    pairingId: string;
    opponentName: string;
    opponentRating: number;
    playerSide: 'w' | 'b';
    timeControlSeconds: number;
    incrementSeconds: number;
  }) => {
    setActiveTournamentMatch({
      tournamentId: params.tournamentId,
      pairingId: params.pairingId,
    });

    setActiveGameConfig({
      mode: 'online',
      timeControlSeconds: params.timeControlSeconds,
      incrementSeconds: params.incrementSeconds,
      playerSide: params.playerSide,
      opponentInfo: {
        name: params.opponentName,
        avatar: '⚔️',
        rating: params.opponentRating,
      },
      roomId: `TOUR-MATCH-${params.pairingId}`,
    });
    setCurrentScreen('game');
  };

  // Resume saved game in progress
  const handleResumeSavedGame = (saved: SavedGame) => {
    setActiveTournamentMatch(null);
    setActiveGameConfig({
      mode: (saved.gameMode as GameMode) || 'ai',
      aiDifficulty: (saved.difficulty as AiDifficulty) || 'medium',
      timeControlSeconds: saved.timeControlSeconds || 600,
      incrementSeconds: saved.incrementSeconds || 0,
      playerSide: saved.playerColor || 'w',
      initialFen: saved.fen,
      initialWhiteTime: saved.whiteTime,
      initialBlackTime: saved.blackTime,
      opponentInfo: {
        name: saved.gameMode === 'ai' ? `AI (${saved.difficulty || 'Medium'})` : 'Opponent',
        avatar: saved.gameMode === 'ai' ? '🤖' : '👤',
        rating: profile.rating,
      },
    });
    setCurrentScreen('game');
  };

  // Record outcome on finish
  const handleMatchComplete = (result: MatchResult) => {
    const oppRating = activeGameConfig.opponentInfo?.rating || 1200;
    const oppName = activeGameConfig.opponentInfo?.name || 'Opponent';
    const updated = recordMatchOutcome(result, activeGameConfig.playerSide, oppName, oppRating);
    setProfile(updated);

    // If part of an active tournament, record tournament score
    if (activeTournamentMatch) {
      const userWon = result.winner === activeGameConfig.playerSide;
      const isDraw = result.winner === 'draw';

      let tournResult: TournamentPairingResult = 'pending';
      if (activeGameConfig.playerSide === 'w') {
        tournResult = userWon ? '1-0' : isDraw ? '1/2-1/2' : '0-1';
      } else {
        tournResult = userWon ? '0-1' : isDraw ? '1/2-1/2' : '1-0';
      }

      tournamentService.submitPairingResult(
        activeTournamentMatch.tournamentId,
        activeTournamentMatch.pairingId,
        tournResult
      );
    }

    // Award XP progression
    const userWon = result.winner === activeGameConfig.playerSide;
    const isDraw = result.winner === 'draw';
    const xpEarned = userWon ? 50 : isDraw ? 25 : 10;
    achievementService.addXp(xpEarned);

    // Track achievement milestones
    if (userWon) {
      achievementService.unlockAchievement('first_checkmate');
      if (activeGameConfig.mode === 'online') {
        achievementService.unlockAchievement('first_online_win');
        achievementService.incrementProgress('ten_rated_wins', 1);
      }
    }
    achievementService.incrementProgress('hundred_games', 1);
  };

  const handleUpdateSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const handleUpdateProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    saveProfile(newProfile);
  };

  // Show bottom nav on non-game and non-splash screens
  const showBottomNav = currentScreen !== 'splash' && currentScreen !== 'game';

  return (
    <div className="relative min-h-screen w-full bg-[#070B13] text-slate-100 font-['Outfit',sans-serif] selection:bg-amber-400 selection:text-black">
      {/* 1. Splash Screen */}
      {currentScreen === 'splash' && (
        <SplashScreen onFinish={() => setCurrentScreen('main_menu')} />
      )}

      {/* 2. Main Menu Screen */}
      {currentScreen === 'main_menu' && (
        <MainMenuScreen
          onPlayNow={handlePlayNow}
          onResumeGame={handleResumeSavedGame}
          onSelectMode={(mode) => {
            if (mode === 'ai') setCurrentScreen('ai_difficulty');
            else if (mode === 'online') setCurrentScreen('multiplayer');
            else if (mode === 'tournaments') {
              setCurrentTab('tournaments');
              setCurrentScreen('tournaments');
            } else if (mode === 'daily_challenges') {
              setCurrentTab('daily');
              setCurrentScreen('daily_challenges');
            } else if (mode === 'leaderboard') {
              setCurrentTab('leaderboard');
              setCurrentScreen('leaderboard');
            } else if (mode === 'progression') {
              setCurrentTab('progression');
              setCurrentScreen('progression');
            } else if (mode === 'learn') setCurrentScreen('learn');
            else setCurrentScreen('mode_select');
          }}
          onOpenNotifications={() => setShowNotifications(true)}
          onOpenAdminConsole={() => setShowAdminConsole(true)}
        />
      )}

      {/* 3. Choose Game Mode Screen */}
      {currentScreen === 'mode_select' && (
        <ModeSelectScreen
          onBack={() => setCurrentScreen('main_menu')}
          onSelectAi={() => setCurrentScreen('ai_difficulty')}
          onSelectOnline={() => setCurrentScreen('multiplayer')}
          onSelectLocal={handleStartLocalMatch}
          onSelectTournaments={() => {
            setCurrentTab('tournaments');
            setCurrentScreen('tournaments');
          }}
        />
      )}

      {/* 4. Play vs AI Difficulty Selection */}
      {currentScreen === 'ai_difficulty' && (
        <AiDifficultyScreen
          onBack={() => setCurrentScreen('main_menu')}
          onStart={handleStartAiMatch}
        />
      )}

      {/* 5. In-Game 3D Chessboard Screen */}
      {currentScreen === 'game' && (
        <GameScreen
          mode={activeGameConfig.mode}
          aiDifficulty={activeGameConfig.aiDifficulty}
          timeControlSeconds={activeGameConfig.timeControlSeconds}
          incrementSeconds={activeGameConfig.incrementSeconds}
          playerSide={activeGameConfig.playerSide}
          settings={settings}
          userRating={profile.rating}
          userName={profile.name}
          opponentInfo={activeGameConfig.opponentInfo}
          roomId={activeGameConfig.roomId}
          initialFen={activeGameConfig.initialFen}
          initialWhiteTime={activeGameConfig.initialWhiteTime}
          initialBlackTime={activeGameConfig.initialBlackTime}
          onExit={() => {
            if (activeTournamentMatch) {
              setCurrentScreen('tournaments');
            } else {
              setCurrentScreen('main_menu');
            }
          }}
          onMatchComplete={handleMatchComplete}
          onOpenSettings={() => setCurrentScreen('settings')}
        />
      )}

      {/* 6. Settings Screen */}
      {currentScreen === 'settings' && (
        <SettingsScreen
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
        />
      )}

      {/* 7. Multiplayer Lobby Screen */}
      {currentScreen === 'multiplayer' && (
        <MultiplayerScreen
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
          onStartMatch={handleStartOnlineMatch}
        />
      )}

      {/* 8. Profile & Stats Screen */}
      {currentScreen === 'profile' && (
        <ProfileScreen
          profile={profile}
          onUpdateProfile={handleUpdateProfile}
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
        />
      )}

      {/* 9. Learn & Practice Screen */}
      {currentScreen === 'learn' && (
        <LearnScreen
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
        />
      )}

      {/* 10. Tournaments Hub Screen */}
      {currentScreen === 'tournaments' && (
        <TournamentHubScreen
          userProfile={{
            id: 'current-user',
            name: profile.name,
            rating: profile.rating,
            avatar: '👑',
          }}
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
          onLaunchTournamentMatch={handleLaunchTournamentMatch}
        />
      )}

      {/* 11. Daily Challenges Screen */}
      {currentScreen === 'daily_challenges' && (
        <DailyChallengesScreen
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
        />
      )}

      {/* 12. Leaderboard Screen */}
      {currentScreen === 'leaderboard' && (
        <LeaderboardScreen
          userProfile={{
            id: 'current-user',
            name: profile.name,
            avatar: '👑',
            rating: profile.rating,
          }}
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
        />
      )}

      {/* 13. Progression & Achievements Screen */}
      {currentScreen === 'progression' && (
        <ProgressionScreen
          onBack={() => {
            setCurrentTab('home');
            setCurrentScreen('main_menu');
          }}
          onSelectTheme={(themeId) => {
            handleUpdateSettings({ ...settings, boardStyle: themeId as any });
          }}
        />
      )}

      {/* MODAL 1: Notification Drawer */}
      {showNotifications && (
        <NotificationDrawer
          onClose={() => setShowNotifications(false)}
          onNavigate={(screen) => {
            setShowNotifications(false);
            if (screen === 'tournaments') {
              setCurrentTab('tournaments');
              setCurrentScreen('tournaments');
            } else if (screen === 'daily_challenges') {
              setCurrentTab('daily');
              setCurrentScreen('daily_challenges');
            } else if (screen === 'progression') {
              setCurrentTab('progression');
              setCurrentScreen('progression');
            }
          }}
        />
      )}

      {/* MODAL 2: Admin & Fair Play Console */}
      {showAdminConsole && (
        <AdminDashboardModal
          currentUserName={profile.name}
          onClose={() => setShowAdminConsole(false)}
        />
      )}

      {/* MODAL 3: Fair Play Report Submission */}
      {fairPlayReportTarget && (
        <FairPlayModal
          reportedUserId={fairPlayReportTarget.id}
          reportedUserName={fairPlayReportTarget.name}
          gameId={fairPlayReportTarget.gameId}
          currentUserId="current-user"
          currentUserName={profile.name}
          onClose={() => setFairPlayReportTarget(null)}
        />
      )}

      {/* Consistent Bottom Navigation */}
      {showBottomNav && (
        <BottomNav currentTab={currentTab} onTabChange={handleTabChange} />
      )}
    </div>
  );
}
