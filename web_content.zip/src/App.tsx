import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { HomeModule } from './components/HomeModule';
import { FactoryModule } from './components/FactoryModule';
import { PersonalModule } from './components/PersonalModule';
import { ReportsModule } from './components/ReportsModule';
import { SettingsModule } from './components/SettingsModule';
import { DynamicSettingsModule } from './components/DynamicSettingsModule';
import { BackupModule } from './components/BackupModule';
import { RecycleBinModule } from './components/RecycleBinModule';
import { AuditLogModule } from './components/AuditLogModule';
import { CustomModuleView } from './components/CustomModuleView';

const AppRouter: React.FC = () => {
  const { activeSection } = useApp();

  const renderSection = () => {
    if (activeSection === 'dashboard') return <Dashboard />;
    if (activeSection === 'home') return <HomeModule />;
    if (activeSection === 'factory') return <FactoryModule />;
    if (activeSection === 'personal') return <PersonalModule />;
    if (activeSection === 'reports') return <ReportsModule />;
    if (activeSection === 'settings') return <SettingsModule />;
    if (activeSection === 'dynamic_settings') return <DynamicSettingsModule />;
    if (activeSection === 'backup') return <BackupModule />;
    if (activeSection === 'recycle_bin') return <RecycleBinModule />;
    if (activeSection === 'audit_log') return <AuditLogModule />;
    if (activeSection.startsWith('custom:')) {
      return <CustomModuleView moduleId={activeSection.slice(7)} />;
    }
    return <Dashboard />;
  };

  return <Layout>{renderSection()}</Layout>;
};

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
