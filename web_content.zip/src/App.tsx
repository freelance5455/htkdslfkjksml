import React, { useState } from 'react';
import { NavTab, ModelMetadata } from './types';
import { HomeView } from './components/HomeView';
import { ChatPanel } from './components/ChatPanel';
import { CharacterStudioView } from './components/CharacterStudioView';
import { SettingsView } from './components/SettingsView';
import { Navigation } from './components/Navigation';
import { Sparkles, Shield, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [customModelGlb, setCustomModelGlb] = useState<{ buffer: ArrayBuffer; name: string } | null>(null);
  const [characterMeta, setCharacterMeta] = useState<ModelMetadata | null>({
    name: '002 Cyber Companion',
    source: 'procedural-002',
    meshCount: 22,
    vertexCount: 4200,
    triangleCount: 5800,
    animations: ['Idle Float', 'Breathing', 'Horn Glow Pulse', 'Eye Blink'],
    isRigged: true,
    boneCount: 16,
    morphTargetCount: 2,
    hasBlinkSupport: true,
    rigDetails: 'Procedural Anime Avatar with Dynamic Eye & Breath Rigs',
  });

  const handleModelImported = (buffer: ArrayBuffer, name: string) => {
    setCustomModelGlb({ buffer, name });
  };

  const handleClearCustomModel = () => {
    setCustomModelGlb(null);
    setCharacterMeta({
      name: '002 Cyber Companion',
      source: 'procedural-002',
      meshCount: 22,
      vertexCount: 4200,
      triangleCount: 5800,
      animations: ['Idle Float', 'Breathing', 'Horn Glow Pulse', 'Eye Blink'],
      isRigged: true,
      boneCount: 16,
      morphTargetCount: 2,
      hasBlinkSupport: true,
      rigDetails: 'Procedural Anime Avatar with Dynamic Eye & Breath Rigs',
    });
  };

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-[#07070e] text-slate-100 overflow-hidden font-sans">
      {/* Top Cyber Status Bar (Mobile-Friendly Header) */}
      <header className="shrink-0 h-12 bg-[#0a0a14]/90 border-b border-[#ff2d78]/25 backdrop-blur-md px-4 flex items-center justify-between z-30">
        <div className="flex items-center gap-2">
          {/* 002 Cyber Logo Badge */}
          <div className="flex items-center gap-1.5 cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#ff2d78] to-[#9333ea] p-0.5 shadow-[0_0_10px_rgba(255,45,120,0.4)]">
              <div className="w-full h-full rounded-[6px] bg-[#0c0c18] flex items-center justify-center font-cyber font-bold text-xs text-[#ff2d78]">
                02
              </div>
            </div>
            <div>
              <span className="font-cyber font-bold text-sm tracking-wider text-white">002 AI</span>
              <span className="hidden sm:inline text-[10px] text-slate-400 font-mono-code ml-1.5">
                COMPANION PLATFORM
              </span>
            </div>
          </div>
        </div>

        {/* Status Indicator & Sync Rate */}
        <div className="flex items-center gap-2 font-mono-code text-xs">
          <div className="bg-[#121224] border border-[#ff2d78]/30 px-2.5 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />
            <span className="text-[11px] text-slate-200 uppercase font-cyber font-semibold tracking-wider">
              SYNC 98.4%
            </span>
          </div>
        </div>
      </header>

      {/* Main Tab Content Viewport with DOM state preservation */}
      <main className="flex-1 relative overflow-hidden">
        <div className={`h-full w-full ${activeTab === 'home' ? 'block' : 'hidden'}`}>
          <HomeView
            onNavigate={setActiveTab}
            characterMeta={characterMeta}
            onModelLoaded={setCharacterMeta}
            customModel={customModelGlb}
          />
        </div>

        <div className={`h-full w-full ${activeTab === 'chat' ? 'block' : 'hidden'}`}>
          <ChatPanel
            onOpenCharacterStudio={() => setActiveTab('character')}
          />
        </div>

        <div className={`h-full w-full ${activeTab === 'character' ? 'block' : 'hidden'}`}>
          <CharacterStudioView
            modelMeta={characterMeta}
            onModelLoaded={setCharacterMeta}
            customModel={customModelGlb}
            onModelImported={handleModelImported}
            onClearCustomModel={handleClearCustomModel}
          />
        </div>

        <div className={`h-full w-full ${activeTab === 'settings' ? 'block' : 'hidden'}`}>
          <SettingsView />
        </div>
      </main>

      {/* Navigation Bottom Bar */}
      <Navigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
    </div>
  );
}
