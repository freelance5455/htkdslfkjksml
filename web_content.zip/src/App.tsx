import React, { useState, useEffect } from 'react';
import { DAYS_PLAN, DayConfig } from './daysConfig';
import {
  triggerDayCompletedCelebration,
  triggerWeekCompletedCelebration,
} from './utils/confetti';
import { PWAInstallButton } from './components/PWAInstallButton';
import { SettingsModal } from './components/SettingsModal';
import {
  AccentColor,
  UserProfile,
  ACCENT_COLORS,
} from './types/settings';
import {
  Check,
  RotateCcw,
  Sparkles,
  Pencil,
  ChevronUp,
  ChevronDown,
  Trash2,
  Plus,
  Settings,
} from 'lucide-react';

const STORAGE_DAYS_KEY = 'gym_tracker_custom_days_v3';
const STORAGE_COMPLETED_KEY = 'gym_tracker_completed_days_v2';
const STORAGE_THEME_KEY = 'gym_tracker_theme_v1';
const STORAGE_ACCENT_KEY = 'gym_tracker_accent_v1';
const STORAGE_PROFILE_KEY = 'gym_tracker_profile_v1';

export default function App() {
  // Theme state: 'dark' or 'light'
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window === 'undefined') return 'dark';
    try {
      const saved = localStorage.getItem(STORAGE_THEME_KEY);
      if (saved === 'light' || saved === 'dark') return saved;
    } catch {}
    return 'dark';
  });

  // Accent color state
  const [accent, setAccent] = useState<AccentColor>(() => {
    if (typeof window === 'undefined') return 'emerald';
    try {
      const saved = localStorage.getItem(STORAGE_ACCENT_KEY) as AccentColor;
      if (saved && ACCENT_COLORS.some((c) => c.id === saved)) return saved;
    } catch {}
    return 'emerald';
  });

  // Profile state
  const [profile, setProfile] = useState<UserProfile>(() => {
    const defaultProfile: UserProfile = {
      name: 'Champion',
      avatar: '🏋️',
      goal: 'Muscle Gain',
    };
    if (typeof window === 'undefined') return defaultProfile;
    try {
      const saved = localStorage.getItem(STORAGE_PROFILE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return defaultProfile;
  });

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showWeekCompletedModal, setShowWeekCompletedModal] = useState(false);
  const [dayToDelete, setDayToDelete] = useState<DayConfig | null>(null);

  // Clean up any legacy language & streak keys
  useEffect(() => {
    try {
      localStorage.removeItem('gym_tracker_lang_v1');
      localStorage.removeItem('gym_tracker_streak_v1');
    } catch {
      // ignore
    }
    // Ensure document direction is RTL
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'ar';
  }, []);

  // Sync theme
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_THEME_KEY, theme);
    } catch (e) {
      console.error('Failed to save theme:', e);
    }

    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
      document.body.style.backgroundColor = '#0e0f12';
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', '#0e0f12');
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
      document.body.style.backgroundColor = '#f8f9fa';
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', '#f8f9fa');
    }
  }, [theme]);

  // Sync accent color
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_ACCENT_KEY, accent);
    } catch (e) {
      console.error('Failed to save accent:', e);
    }
  }, [accent]);

  // Sync profile
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PROFILE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save profile:', e);
    }
  }, [profile]);

  // Configurable days list (defaulting to the exact requested DAYS_PLAN)
  const [days, setDays] = useState<DayConfig[]>(() => {
    if (typeof window === 'undefined') return DAYS_PLAN;
    try {
      const saved = localStorage.getItem(STORAGE_DAYS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load custom days:', e);
    }
    return DAYS_PLAN;
  });

  // Store array of completed day IDs
  const [completedDays, setCompletedDays] = useState<number[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem(STORAGE_COMPLETED_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Sync days list
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_DAYS_KEY, JSON.stringify(days));
    } catch (e) {
      console.error('Failed to save days to localStorage:', e);
    }
  }, [days]);

  // Sync completed state
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_COMPLETED_KEY, JSON.stringify(completedDays));
    } catch (e) {
      console.error('Failed to save completed state to localStorage:', e);
    }
  }, [completedDays]);

  const isDark = theme === 'dark';
  const currentAccent =
    ACCENT_COLORS.find((c) => c.id === accent) || ACCENT_COLORS[0];

  const totalDays = days.length;
  const completedCount = completedDays.filter((id) =>
    days.some((d) => d.id === id)
  ).length;
  const progressPercent =
    totalDays > 0 ? Math.round((completedCount / totalDays) * 100) : 0;
  const isAllCompleted = completedCount === totalDays && totalDays > 0;

  // First uncompleted day in the table order (the upcoming workout)
  const nextUncompletedDayId =
    days.find((d) => !completedDays.includes(d.id))?.id ?? null;

  // Toggle Day completion
  const handleToggleDay = (dayId: number, e: React.MouseEvent) => {
    if (isEditing) return;

    const isCurrentlyCompleted = completedDays.includes(dayId);

    if (!isCurrentlyCompleted) {
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const originX = (rect.left + rect.width / 2) / window.innerWidth;
      const originY = (rect.top + rect.height / 2) / window.innerHeight;
      triggerDayCompletedCelebration(originX, originY);

      const nextCompleted = [...completedDays, dayId];
      setCompletedDays(nextCompleted);

      // Check if this action completes all days in the week
      const willCompleteWeek =
        days.length > 0 && days.every((d) => nextCompleted.includes(d.id));

      if (willCompleteWeek) {
        setTimeout(() => {
          triggerWeekCompletedCelebration();
          setShowWeekCompletedModal(true);
        }, 220);
      }
    } else {
      setCompletedDays((prev) => prev.filter((id) => id !== dayId));
    }
  };

  // Start new week from completion celebration
  const handleStartNewWeek = () => {
    setCompletedDays([]);
    setShowWeekCompletedModal(false);
  };

  // Update title of a specific day
  const handleUpdateTitle = (dayId: number, newTitle: string) => {
    setDays((prev) =>
      prev.map((d) => (d.id === dayId ? { ...d, title: newTitle } : d))
    );
  };

  // Update description of a specific day
  const handleUpdateDescription = (dayId: number, newDesc: string) => {
    setDays((prev) =>
      prev.map((d) => (d.id === dayId ? { ...d, description: newDesc } : d))
    );
  };

  // Move day up
  const handleMoveDayUp = (index: number) => {
    if (index <= 0) return;
    setDays((prev) => {
      const copy = [...prev];
      const temp = copy[index - 1];
      copy[index - 1] = copy[index];
      copy[index] = temp;
      return copy;
    });
  };

  // Move day down
  const handleMoveDayDown = (index: number) => {
    setDays((prev) => {
      if (index >= prev.length - 1) return prev;
      const copy = [...prev];
      const temp = copy[index + 1];
      copy[index + 1] = copy[index];
      copy[index] = temp;
      return copy;
    });
  };

  // Delete a day
  const handleDeleteDay = (dayId: number) => {
    setDays((prev) => prev.filter((d) => d.id !== dayId));
    setCompletedDays((prev) => prev.filter((id) => id !== dayId));
  };

  const handleConfirmDeleteDay = () => {
    if (dayToDelete) {
      handleDeleteDay(dayToDelete.id);
      setDayToDelete(null);
    }
  };

  // Add a new day
  const handleAddDay = () => {
    const nextId =
      days.length > 0 ? Math.max(...days.map((d) => d.id)) + 1 : 1;
    const newDay: DayConfig = {
      id: nextId,
      title: `Day ${days.length + 1}`,
      description: 'جلسة تدريب مخصصة',
    };
    setDays((prev) => [...prev, newDay]);
  };

  // Reset Week handler
  const handleResetWeek = () => {
    setCompletedDays([]);
    setShowResetConfirm(false);
  };

  return (
    <div
      dir="rtl"
      className={`min-h-screen flex flex-col antialiased transition-colors duration-200 selection:bg-emerald-500/30 selection:text-emerald-200 ${
        isDark ? 'bg-[#0e0f12] text-zinc-100' : 'bg-[#f8f9fa] text-zinc-800'
      }`}
    >
      {/* Header */}
      <header
        className={`sticky top-0 z-30 backdrop-blur-md border-b px-4 pt-3 pb-3.5 transition-colors duration-200 ${
          isDark
            ? 'bg-[#0e0f12]/90 border-white/[0.06]'
            : 'bg-white/90 border-zinc-200/80 shadow-xs'
        }`}
      >
        <div className="max-w-md mx-auto space-y-3">
          {/* Top Brand & Profile Row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {/* Profile Avatar & Nickname button */}
              <button
                type="button"
                onClick={() => setIsSettingsOpen(true)}
                className={`flex items-center gap-2 p-1 pl-2.5 pr-2.5 rounded-2xl border transition-all active:scale-95 ${
                  isDark
                    ? 'bg-zinc-800/90 border-zinc-700/60 hover:border-zinc-500'
                    : 'bg-zinc-100 border-zinc-200 hover:bg-zinc-200/80'
                }`}
                title="الملف الشخصي والإعدادات"
              >
                <span className="text-lg leading-none">{profile.avatar || '🏋️'}</span>
                <span
                  className={`text-xs font-bold tracking-tight max-w-[90px] truncate ${
                    isDark ? 'text-white' : 'text-zinc-900'
                  }`}
                >
                  {profile.name || 'Champion'}
                </span>
              </button>
            </div>

            {/* Header Right Actions */}
            <div className="flex items-center gap-1.5">
              <PWAInstallButton />

              {/* Settings Button */}
              <button
                type="button"
                onClick={() => setIsSettingsOpen(true)}
                className={`flex items-center justify-center w-8 h-8 rounded-full border transition-all active:scale-95 ${
                  isDark
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
                    : 'bg-white border-zinc-200 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 shadow-xs'
                }`}
                title="الإعدادات"
                aria-label="Settings"
              >
                <Settings className="w-4 h-4 text-zinc-400" />
              </button>

              {/* Reset Week button */}
              {!isEditing && (
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold active:scale-95 transition-all ${
                    isDark
                      ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
                      : 'bg-white border-zinc-200 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 shadow-xs'
                  }`}
                  title="إعادة تعيين الأسبوع"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Reset Week</span>
                </button>
              )}

              {/* Edit / Done Toggle Button */}
              {isEditing ? (
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  style={{ backgroundColor: currentAccent.primary }}
                  className="flex items-center gap-1.5 rounded-full text-black px-3.5 py-1.5 text-xs font-bold active:scale-95 transition-all shadow-md"
                >
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                  <span>Done</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold active:scale-95 transition-all ${
                    isDark
                      ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800'
                      : 'bg-white border-zinc-200 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 shadow-xs'
                  }`}
                  title="تعديل الجدول"
                >
                  <Pencil className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Edit</span>
                </button>
              )}
            </div>
          </div>

          {/* Progress Card */}
          <div
            className={`border rounded-2xl p-3 shadow-sm transition-colors ${
              isDark
                ? 'bg-[#14151a] border-zinc-800/80'
                : 'bg-white border-zinc-200/90 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isDark ? 'text-zinc-400' : 'text-zinc-500'
                  }`}
                >
                  Progress
                </span>
                {isAllCompleted && (
                  <span
                    style={{
                      backgroundColor: currentAccent.lightBg,
                      borderColor: currentAccent.border,
                      color: currentAccent.primary,
                    }}
                    className="inline-flex items-center gap-1 rounded-full text-[10px] font-bold px-2 py-0.5 border animate-in fade-in"
                  >
                    <Sparkles className="w-2.5 h-2.5" />
                    أسبوع مكتمل!
                  </span>
                )}
              </div>
              <div className="flex items-baseline gap-1">
                <span
                  className={`text-base font-extrabold font-mono transition-colors ${
                    isDark ? 'text-white' : 'text-zinc-900'
                  }`}
                >
                  {completedCount}
                </span>
                <span className="text-xs text-zinc-400 font-semibold">/</span>
                <span
                  className={`text-xs font-semibold font-mono ${
                    isDark ? 'text-zinc-400' : 'text-zinc-500'
                  }`}
                >
                  {totalDays}
                </span>
              </div>
            </div>

            {/* Smooth animated progress bar */}
            <div
              className={`w-full h-2 rounded-full overflow-hidden p-0.5 transition-colors ${
                isDark ? 'bg-zinc-800/90' : 'bg-zinc-100'
              }`}
            >
              <div
                className="h-full rounded-full transition-all duration-500 ease-out"
                style={{
                  width: `${progressPercent}%`,
                  background: `linear-gradient(to right, ${currentAccent.primary}, #14b8a6)`,
                  boxShadow: `0 0 10px ${currentAccent.primary}66`,
                }}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Weekly Cards (Exact Layout & Visual Balance from Visual Reference) */}
      <main className="flex-1 max-w-md w-full mx-auto px-4 py-4 space-y-3 pb-12">
        {days.map((day: DayConfig, index: number) => {
          const isCompleted = completedDays.includes(day.id);
          const isNext = !isCompleted && day.id === nextUncompletedDayId;

          return (
            <div
              key={day.id}
              onClick={(e) => handleToggleDay(day.id, e)}
              className={`group relative overflow-hidden rounded-3xl p-4 sm:p-4.5 transition-all duration-200 select-none border ${
                isEditing
                  ? isDark
                    ? 'bg-[#15161b] border-zinc-700/80 shadow-md cursor-default'
                    : 'bg-white border-zinc-300 shadow-xs cursor-default'
                  : isCompleted
                  ? isDark
                    ? 'bg-gradient-to-br from-[#15211b] to-[#121418] shadow-[0_4px_20px_rgba(16,185,129,0.08)] cursor-pointer active:scale-[0.985]'
                    : 'bg-gradient-to-br from-emerald-50/70 to-teal-50/40 shadow-xs cursor-pointer active:scale-[0.985]'
                  : isDark
                  ? 'bg-[#15161b] hover:bg-[#181920] border-zinc-800/80 shadow-sm cursor-pointer active:scale-[0.985]'
                  : 'bg-white hover:bg-zinc-50/90 border-zinc-200 shadow-xs cursor-pointer active:scale-[0.985]'
              }`}
              style={{
                borderColor: isCompleted ? currentAccent.border : undefined,
              }}
            >
              {/* Subtle accent bar on right side in RTL */}
              <div
                className="absolute top-0 bottom-0 right-0 w-1 transition-colors duration-300"
                style={{
                  backgroundColor: isCompleted ? currentAccent.primary : 'transparent',
                  boxShadow: isCompleted ? `0 0 8px ${currentAccent.primary}` : undefined,
                }}
              />

              <div className="flex items-center justify-between gap-3">
                {/* Right side: Checkbox & Day info (RTL) */}
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  {/* Square Checkbox Button */}
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all duration-200 shrink-0 ${
                      isEditing
                        ? isDark
                          ? 'bg-zinc-800/90 text-zinc-300 font-bold text-xs border border-zinc-700/60 font-mono'
                          : 'bg-zinc-100 text-zinc-700 font-bold text-xs border border-zinc-200 font-mono'
                        : isCompleted
                        ? 'text-black scale-100'
                        : isNext
                        ? isDark
                          ? 'bg-zinc-800/90 border shadow-xs'
                          : 'bg-zinc-50 border shadow-xs'
                        : isDark
                        ? 'bg-zinc-800/90 text-zinc-500 border border-zinc-700/60 group-hover:border-zinc-500'
                        : 'bg-zinc-100 text-zinc-400 border border-zinc-200 group-hover:border-zinc-300'
                    }`}
                    style={{
                      backgroundColor: isCompleted ? currentAccent.primary : undefined,
                      boxShadow: isCompleted
                        ? `0 0 15px ${currentAccent.primary}77`
                        : undefined,
                      borderColor: isNext ? currentAccent.border : undefined,
                    }}
                  >
                    {isEditing ? (
                      `#${index + 1}`
                    ) : isCompleted ? (
                      <Check className="w-6 h-6 stroke-[3] text-black animate-in zoom-in-75 duration-150" />
                    ) : isNext ? (
                      <span
                        style={{ color: currentAccent.primary }}
                        className="font-black text-lg font-mono animate-in zoom-in-75 duration-150"
                      >
                        !
                      </span>
                    ) : (
                      <div
                        className={`w-4 h-4 rounded-md border-2 ${
                          isDark ? 'border-zinc-600/70' : 'border-zinc-300'
                        }`}
                      />
                    )}
                  </div>

                  {/* Day Content */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[11px] font-bold tracking-wider uppercase ${
                          isDark ? 'text-zinc-400' : 'text-zinc-500'
                        }`}
                      >
                        DAY {index + 1}
                      </span>
                      {!isEditing && isCompleted && (
                        <span
                          style={{
                            color: currentAccent.primary,
                            backgroundColor: currentAccent.lightBg,
                            borderColor: currentAccent.border,
                          }}
                          className="text-[10px] font-bold px-2 py-0.2 rounded-full border animate-in fade-in"
                        >
                          مكتمل ✓
                        </span>
                      )}
                      {!isEditing && isNext && (
                        <span
                          style={{
                            color: currentAccent.primary,
                            backgroundColor: currentAccent.lightBg,
                            borderColor: currentAccent.border,
                          }}
                          className="text-[10px] font-bold px-2 py-0.2 rounded-full border animate-in fade-in font-mono"
                        >
                          !
                        </span>
                      )}
                    </div>

                    {isEditing ? (
                      /* Inline inputs with identical typography */
                      <div className="space-y-1 mt-0.5" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="text"
                          value={day.title}
                          onChange={(e) => handleUpdateTitle(day.id, e.target.value)}
                          placeholder="اسم اليوم"
                          className={`w-full rounded-lg px-2 py-1 text-base font-bold tracking-tight outline-none transition ${
                            isDark
                              ? 'bg-zinc-900/60 border border-zinc-700/70 focus:border-emerald-500 text-white'
                              : 'bg-zinc-50 border border-zinc-300 focus:border-emerald-500 text-zinc-900'
                          }`}
                        />
                        <input
                          type="text"
                          value={day.description}
                          onChange={(e) => handleUpdateDescription(day.id, e.target.value)}
                          placeholder="الوصف"
                          className={`w-full rounded-lg px-2 py-0.5 text-xs font-normal outline-none transition ${
                            isDark
                              ? 'bg-zinc-900/40 border border-zinc-800 focus:border-emerald-500 text-zinc-300'
                              : 'bg-zinc-50 border border-zinc-200 focus:border-emerald-500 text-zinc-600'
                          }`}
                        />
                      </div>
                    ) : (
                      /* Pristine Normal View */
                      <>
                        <h3
                          className={`text-base font-bold truncate mt-0.5 tracking-tight transition-colors ${
                            isCompleted
                              ? isDark
                                ? 'text-zinc-100'
                                : 'text-zinc-900'
                              : isDark
                              ? 'text-white'
                              : 'text-zinc-900'
                          }`}
                        >
                          {day.title}
                        </h3>

                        {day.description && (
                          <p
                            className={`text-xs truncate mt-0.5 font-normal transition-colors ${
                              isDark ? 'text-zinc-400' : 'text-zinc-500'
                            }`}
                          >
                            {day.description}
                          </p>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Opposite edge: Action buttons in edit mode / Status in normal mode */}
                <div className="shrink-0" onClick={(e) => e.stopPropagation()}>
                  {isEditing ? (
                    <div className="flex items-center gap-1">
                      {/* Move Up */}
                      <button
                        type="button"
                        onClick={() => handleMoveDayUp(index)}
                        disabled={index === 0}
                        aria-label="تحريك لأعلى"
                        className={`p-1.5 rounded-lg disabled:opacity-30 disabled:pointer-events-none transition ${
                          isDark
                            ? 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                            : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
                        }`}
                      >
                        <ChevronUp className="w-4 h-4" />
                      </button>

                      {/* Move Down */}
                      <button
                        type="button"
                        onClick={() => handleMoveDayDown(index)}
                        disabled={index === days.length - 1}
                        aria-label="تحريك لأسفل"
                        className={`p-1.5 rounded-lg disabled:opacity-30 disabled:pointer-events-none transition ${
                          isDark
                            ? 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                            : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
                        }`}
                      >
                        <ChevronDown className="w-4 h-4" />
                      </button>

                      {/* Delete Day */}
                      <button
                        type="button"
                        onClick={() => setDayToDelete(day)}
                        aria-label="حذف الخانة"
                        className="p-1.5 rounded-lg text-zinc-400 hover:text-red-500 hover:bg-red-500/10 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="text-xs font-semibold">
                      {isCompleted ? (
                        <span
                          style={{ color: currentAccent.primary }}
                          className="text-[11px] font-bold"
                        >
                          انتهى
                        </span>
                      ) : isNext ? (
                        <span
                          style={{
                            color: currentAccent.primary,
                            backgroundColor: currentAccent.lightBg,
                            borderColor: currentAccent.border,
                          }}
                          className="inline-flex items-center justify-center w-6 h-6 rounded-full border text-xs font-black font-mono animate-in zoom-in-75"
                        >
                          !
                        </span>
                      ) : (
                        <span
                          className={`text-[11px] ${
                            isDark ? 'text-zinc-500' : 'text-zinc-400'
                          }`}
                        >
                          اضغط للإكمال
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Add Day Button (Visible only in Edit Mode) */}
        {isEditing && (
          <button
            type="button"
            onClick={handleAddDay}
            className={`w-full py-3.5 rounded-3xl border border-dashed text-xs font-bold flex items-center justify-center gap-2 active:scale-98 transition animate-in fade-in ${
              isDark
                ? 'border-zinc-700/80 hover:border-emerald-500/60 bg-zinc-900/40 hover:bg-zinc-900 text-zinc-300 hover:text-emerald-400'
                : 'border-zinc-300 hover:border-emerald-500/60 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-emerald-600 shadow-xs'
            }`}
          >
            <Plus className="w-4 h-4 text-emerald-500" />
            <span>+ إضافة خانة جديدة (Add Day)</span>
          </button>
        )}
      </main>

      {/* Week Completed Celebration Modal */}
      {showWeekCompletedModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div
            className="fixed inset-0"
            onClick={() => setShowWeekCompletedModal(false)}
          />
          <div
            className={`relative w-full max-w-sm rounded-3xl p-6 shadow-2xl z-10 text-center animate-in zoom-in-95 duration-200 border ${
              isDark
                ? 'bg-[#16171d] border-emerald-500/30'
                : 'bg-white border-emerald-500/30 shadow-xl'
            }`}
          >
            <div
              style={{
                backgroundColor: currentAccent.lightBg,
                borderColor: currentAccent.border,
                boxShadow: `0 0 20px ${currentAccent.primary}44`,
              }}
              className="w-14 h-14 rounded-2xl mx-auto flex items-center justify-center mb-4 text-2xl border"
            >
              🎉
            </div>

            <h3
              className={`text-lg font-extrabold mb-2 tracking-tight ${
                isDark ? 'text-white' : 'text-zinc-900'
              }`}
            >
              🎉 أحسنت! أنهيت أسبوعك! 💪
            </h3>

            <p
              className={`text-xs leading-relaxed mb-6 ${
                isDark ? 'text-zinc-400' : 'text-zinc-600'
              }`}
            >
              أتممت جميع تمارين هذا الأسبوع بنجاح. يمكنك الآن بدء أسبوع جديد بنفس جدول تمارينك المخصص.
            </p>

            <button
              type="button"
              onClick={handleStartNewWeek}
              style={{
                background: `linear-gradient(to right, ${currentAccent.primary}, #14b8a6)`,
                boxShadow: `0 0 15px ${currentAccent.primary}55`,
              }}
              className="w-full rounded-2xl py-3.5 text-xs font-black text-black transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <span>أسبوع جديد →</span>
            </button>
          </div>
        </div>
      )}

      {/* Reset Week Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-150">
          <div
            className="fixed inset-0"
            onClick={() => setShowResetConfirm(false)}
          />
          <div
            className={`relative w-full max-w-sm rounded-3xl p-6 shadow-2xl z-10 text-center animate-in zoom-in-95 duration-150 border ${
              isDark ? 'bg-[#16171d] border-zinc-800' : 'bg-white border-zinc-200'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-4 bg-amber-500/15 text-amber-500 border border-amber-500/30">
              <RotateCcw className="w-6 h-6" />
            </div>

            <h3
              className={`text-base font-extrabold mb-1.5 ${
                isDark ? 'text-white' : 'text-zinc-900'
              }`}
            >
              Are you sure you want to reset this week?
            </h3>

            <p
              className={`text-xs leading-relaxed mb-6 ${
                isDark ? 'text-zinc-400' : 'text-zinc-600'
              }`}
            >
              إعادة التعيين تمسح علامات الإنجاز فقط وتبدأ أسبوعاً جديداً، دون تغيير أسماء الأيام أو الأوصاف.
            </p>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className={`flex-1 rounded-2xl py-3 text-xs font-bold transition active:scale-95 ${
                  isDark
                    ? 'bg-zinc-800/80 text-zinc-300 hover:bg-zinc-700 hover:text-white'
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200 hover:text-zinc-900'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetWeek}
                className="flex-1 rounded-2xl bg-amber-600 hover:bg-amber-500 py-3 text-xs font-bold text-white transition active:scale-95 shadow-md shadow-amber-900/30"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Day Confirmation Modal */}
      {dayToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-150">
          <div
            className="fixed inset-0"
            onClick={() => setDayToDelete(null)}
          />
          <div
            className={`relative w-full max-w-sm rounded-3xl p-6 shadow-2xl z-10 text-center animate-in zoom-in-95 duration-150 border ${
              isDark ? 'bg-[#16171d] border-zinc-800' : 'bg-white border-zinc-200'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-4 bg-red-500/15 text-red-500 border border-red-500/30">
              <Trash2 className="w-6 h-6" />
            </div>

            <h3
              className={`text-base font-extrabold mb-1.5 ${
                isDark ? 'text-white' : 'text-zinc-900'
              }`}
            >
              Delete this day?
            </h3>

            <p
              className={`text-xs leading-relaxed mb-6 ${
                isDark ? 'text-zinc-400' : 'text-zinc-600'
              }`}
            >
              هل أنت متأكد أنك تريد حذف هذا اليوم؟
            </p>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setDayToDelete(null)}
                className={`flex-1 rounded-2xl py-3 text-xs font-bold transition active:scale-95 ${
                  isDark
                    ? 'bg-zinc-800/80 text-zinc-300 hover:bg-zinc-700 hover:text-white'
                    : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200 hover:text-zinc-900'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteDay}
                className="flex-1 rounded-2xl bg-red-600 hover:bg-red-500 py-3 text-xs font-bold text-white transition active:scale-95 shadow-md shadow-red-900/30"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        theme={theme}
        onThemeChange={setTheme}
        accent={accent}
        onAccentChange={setAccent}
        profile={profile}
        onProfileChange={setProfile}
        onOpenEditSchedule={() => setIsEditing(true)}
        onOpenResetWeek={() => setShowResetConfirm(true)}
      />
    </div>
  );
}
