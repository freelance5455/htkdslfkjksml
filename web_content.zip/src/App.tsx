import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { audioEngine } from './audio/synthEngine';
import { DEFAULT_KITS, cloneKit, makeZone } from './data/defaultKits';
import {
  deleteCustomSound,
  deleteKitFromDb,
  getAllCustomSounds,
  getAllSavedKits,
  loadAppSettings,
  saveAppSettings,
  saveCustomSound,
  saveKitToDb,
} from './storage/octapadDb';
import type {
  BankId,
  KitPreset,
  PadConfig,
  SidebarPosition,
  SidebarRotation,
  StoredSound,
} from './types/octapad';
import { PadSurface } from './components/PadSurface';
import { ControlSidebar } from './components/ControlSidebar';
import { ZoneSoundModal } from './components/ZoneSoundModal';
import { ProMixDrawer } from './components/ProMixDrawer';

interface RecordedEvent {
  padIndex: number;
  zoneId: 'primary' | 'secondary';
  velocity: number;
  offsetMs: number;
}

interface RecordedLoop {
  durationMs: number;
  events: RecordedEvent[];
}

export default function App() {
  const [kits, setKits] = useState<KitPreset[]>(() => DEFAULT_KITS.map((k) => cloneKit(k)));
  const [activeKitId, setActiveKitId] = useState<string>(DEFAULT_KITS[0].id);
  const [activeBank, setActiveBank] = useState<BankId>('A');
  const [sidebarPosition, setSidebarPosition] = useState<SidebarPosition>('right');
  const [sidebarRotation, setSidebarRotation] = useState<SidebarRotation>(0);
  const [customSounds, setCustomSounds] = useState<StoredSound[]>([]);

  const [editZonesMode, setEditZonesMode] = useState(false);
  const [selectedPadIndex, setSelectedPadIndex] = useState(0);
  const [selectedZoneId, setSelectedZoneId] = useState<'primary' | 'secondary'>('primary');
  const [zoneModalOpen, setZoneModalOpen] = useState(false);
  const [zoneModalInitialTab, setZoneModalInitialTab] = useState<'sound' | 'zones'>('sound');
  const [proMixOpen, setProMixOpen] = useState(false);

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  const [activeHits, setActiveHits] = useState<Record<string, number>>({});
  const [loopingZones, setLoopingZones] = useState<Record<string, boolean>>({});

  // Metronome & Live Loop Transport
  const [bpm, setBpm] = useState(120);
  const [metronomeOn, setMetronomeOn] = useState(false);
  const [isRecordingLoop, setIsRecordingLoop] = useState(false);
  const [isPlayingLoop, setIsPlayingLoop] = useState(false);
  const [recordedLoop, setRecordedLoop] = useState<RecordedLoop | null>(null);

  const hitTimeoutsRef = useRef<Record<string, number>>({});
  const recStartRef = useRef<number>(0);
  const recEventsRef = useRef<RecordedEvent[]>([]);
  const loopTimersRef = useRef<number[]>([]);
  const loopIntervalRef = useRef<number | null>(null);

  // Hydrate persisted kits, custom sounds, and settings from IndexedDB
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const [savedKits, storedSounds, settings] = await Promise.all([
          getAllSavedKits(),
          getAllCustomSounds(),
          loadAppSettings(),
        ]);

        if (!mounted) return;

        // Decode custom audio buffers
        for (const sound of storedSounds) {
          try {
            await audioEngine.decodeAndStoreCustomSound(sound);
          } catch {
            // Skip unreadable audio blob
          }
        }
        setCustomSounds(storedSounds);

        // Merge saved edits over default kits + append user custom kits
        const mergedBuiltIns = DEFAULT_KITS.map((def) => {
          const override = savedKits.find((s) => s.id === def.id);
          return override ? override : cloneKit(def);
        });
        const customKits = savedKits.filter(
          (s) => !DEFAULT_KITS.some((d) => d.id === s.id)
        );
        const allMerged = [...mergedBuiltIns, ...customKits];
        setKits(allMerged);

        if (settings) {
          if (allMerged.some((k) => k.id === settings.activeKitId)) {
            setActiveKitId(settings.activeKitId);
          }
          setActiveBank(settings.activeBank || 'A');
          setBpm(settings.bpm || 120);
          if (settings.sidebarPosition) setSidebarPosition(settings.sidebarPosition);
          if (settings.sidebarRotation !== undefined) setSidebarRotation(settings.sidebarRotation);
        }
      } catch {
        // Fallback cleanly to default kits if IndexedDB unavailable
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  const activeKit = useMemo(
    () => kits.find((k) => k.id === activeKitId) ?? kits[0],
    [kits, activeKitId]
  );

  const activePads = useMemo(
    () => (activeBank === 'A' ? activeKit.bankA : activeKit.bankB),
    [activeKit, activeBank]
  );

  // Sync master volume to audio engine
  useEffect(() => {
    audioEngine.setMasterVolume(activeKit.masterVolume);
  }, [activeKit.masterVolume]);

  // Persist active kit/bank/bpm/sidebar selection
  useEffect(() => {
    saveAppSettings({
      activeKitId: activeKit.id,
      activeBank,
      bpm,
      sidebarPosition,
      sidebarRotation,
    }).catch(() => {});
  }, [activeKit.id, activeBank, bpm, sidebarPosition, sidebarRotation]);

  // Listen to browser fullscreen state
  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen may be blocked by iframe permissions; ignore silently
    }
  }, []);

  const flashZone = useCallback((padIndex: number, zoneId: 'primary' | 'secondary') => {
    const key = `${padIndex}-${zoneId}`;
    setActiveHits((prev) => ({ ...prev, [key]: Date.now() }));
    if (hitTimeoutsRef.current[key]) {
      window.clearTimeout(hitTimeoutsRef.current[key]);
    }
    hitTimeoutsRef.current[key] = window.setTimeout(() => {
      setActiveHits((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }, 115);
  }, []);

  const triggerZone = useCallback(
    (padIndex: number, zoneId: 'primary' | 'secondary', velocity = 1.0) => {
      const pad = activePads[padIndex];
      if (!pad) return;
      const effectiveZoneId = pad.splitMode === 'single' ? 'primary' : zoneId;
      const zone = effectiveZoneId === 'secondary' ? pad.zones[1] : pad.zones[0];
      const voiceKey = `${activeKit.id}-${activeBank}-${padIndex}-${effectiveZoneId}`;

      if (zone.playbackMode === 'loop') {
        const hitKey = `${padIndex}-${effectiveZoneId}`;
        setLoopingZones((prev) => ({ ...prev, [hitKey]: !prev[hitKey] }));
      }

      audioEngine.triggerZone(voiceKey, zone, velocity);
      flashZone(padIndex, effectiveZoneId);

      if (isRecordingLoop) {
        recEventsRef.current.push({
          padIndex,
          zoneId: effectiveZoneId,
          velocity,
          offsetMs: performance.now() - recStartRef.current,
        });
      }
    },
    [activePads, activeKit.id, activeBank, flashZone, isRecordingLoop]
  );

  const releaseZone = useCallback(
    (padIndex: number, zoneId: 'primary' | 'secondary') => {
      const pad = activePads[padIndex];
      if (!pad) return;
      const effectiveZoneId = pad.splitMode === 'single' ? 'primary' : zoneId;
      const zone = effectiveZoneId === 'secondary' ? pad.zones[1] : pad.zones[0];
      if (zone.playbackMode === 'gate') {
        const voiceKey = `${activeKit.id}-${activeBank}-${padIndex}-${effectiveZoneId}`;
        audioEngine.releaseGateVoice(voiceKey);
      }
    },
    [activePads, activeKit.id, activeBank]
  );

  // Keyboard drum triggers
  useEffect(() => {
    const downKeys = new Set<string>();
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT')
      ) {
        return;
      }
      const key = e.key.toUpperCase();
      if (downKeys.has(key)) return;
      const matchedPad = activePads.find((p) => p.keyHint.toUpperCase() === key);
      if (matchedPad) {
        downKeys.add(key);
        triggerZone(matchedPad.index, 'primary', 1.0);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toUpperCase();
      downKeys.delete(key);
      const matchedPad = activePads.find((p) => p.keyHint.toUpperCase() === key);
      if (matchedPad) {
        releaseZone(matchedPad.index, 'primary');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [activePads, triggerZone, releaseZone]);

  // Metronome scheduler
  useEffect(() => {
    if (!metronomeOn) return;
    let beat = 0;
    audioEngine.playMetronomeClick(true);
    const intervalMs = (60 / bpm) * 1000;
    const id = window.setInterval(() => {
      beat = (beat + 1) % 4;
      audioEngine.playMetronomeClick(beat === 0);
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [metronomeOn, bpm]);

  // Loop Playback Scheduler
  const clearLoopPlayback = useCallback(() => {
    loopTimersRef.current.forEach((t) => window.clearTimeout(t));
    loopTimersRef.current = [];
    if (loopIntervalRef.current) {
      window.clearInterval(loopIntervalRef.current);
      loopIntervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    clearLoopPlayback();
    if (!isPlayingLoop || !recordedLoop || recordedLoop.events.length === 0) return;

    const scheduleIteration = () => {
      recordedLoop.events.forEach((ev) => {
        const timerId = window.setTimeout(() => {
          triggerZone(ev.padIndex, ev.zoneId, ev.velocity);
        }, ev.offsetMs);
        loopTimersRef.current.push(timerId);
      });
    };

    scheduleIteration();
    loopIntervalRef.current = window.setInterval(
      scheduleIteration,
      Math.max(250, recordedLoop.durationMs)
    );

    return clearLoopPlayback;
  }, [isPlayingLoop, recordedLoop, clearLoopPlayback, triggerZone]);

  const handleToggleRecordLoop = () => {
    if (isRecordingLoop) {
      const durationMs = Math.max(400, performance.now() - recStartRef.current);
      const events = [...recEventsRef.current];
      setIsRecordingLoop(false);
      if (events.length > 0) {
        setRecordedLoop({ durationMs, events });
        setIsPlayingLoop(true);
      }
    } else {
      setIsPlayingLoop(false);
      recEventsRef.current = [];
      recStartRef.current = performance.now();
      setIsRecordingLoop(true);
    }
  };

  const updateActiveKit = useCallback(
    (updater: (k: KitPreset) => KitPreset) => {
      setKits((prev) =>
        prev.map((k) => (k.id === activeKit.id ? updater(k) : k))
      );
      setHasUnsavedChanges(true);
      setJustSaved(false);
    },
    [activeKit.id]
  );

  const updateActivePad = useCallback(
    (padIndex: number, updater: (p: PadConfig) => PadConfig) => {
      updateActiveKit((k) => {
        const bankKey = activeBank === 'A' ? 'bankA' : 'bankB';
        return {
          ...k,
          [bankKey]: k[bankKey].map((p) => (p.index === padIndex ? updater(p) : p)),
        };
      });
    },
    [activeBank, updateActiveKit]
  );

  const handleSaveKit = async () => {
    try {
      await saveKitToDb(activeKit);
      setHasUnsavedChanges(false);
      setJustSaved(true);
      window.setTimeout(() => setJustSaved(false), 1800);
    } catch {
      // ignore storage error
    }
  };

  const handleImportFiles = async (
    files: FileList,
    assignToPadIndex?: number,
    assignToZoneId: 'primary' | 'secondary' = 'primary'
  ) => {
    const fileArray = Array.from(files);
    const newlyStored: StoredSound[] = [];

    for (const file of fileArray) {
      const { buffer, arrayBuffer } = await audioEngine.decodeRawFile(file);
      const cleanName = file.name.replace(/\.[^/.]+$/, '').slice(0, 32);
      const id = `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const stored: StoredSound = {
        id,
        name: cleanName,
        mimeType: file.type || 'audio/wav',
        size: file.size,
        duration: buffer.duration,
        data: arrayBuffer,
        createdAt: Date.now(),
      };
      audioEngine.registerBuffer(id, buffer);
      await saveCustomSound(stored);
      newlyStored.push(stored);
    }

    setCustomSounds((prev) => [...newlyStored, ...prev]);

    // Auto-assign imported sound(s): if 1 file, assign to target pad/zone; if multiple, map sequentially
    if (newlyStored.length > 0 && assignToPadIndex !== undefined) {
      if (newlyStored.length === 1) {
        const sound = newlyStored[0];
        updateActivePad(assignToPadIndex, (pad) => {
          const idx = assignToZoneId === 'secondary' && pad.splitMode !== 'single' ? 1 : 0;
          const nextZones = [...pad.zones] as [typeof pad.zones[0], typeof pad.zones[1]];
          nextZones[idx] = {
            ...nextZones[idx],
            soundId: sound.id,
            soundName: sound.name,
            label: sound.name,
            isCustom: true,
            startOffset: 0,
            endOffset: 1,
          };
          return { ...pad, zones: nextZones };
        });
      } else {
        newlyStored.slice(0, 8).forEach((sound, offset) => {
          const targetIdx = (assignToPadIndex + offset) % 8;
          updateActivePad(targetIdx, (pad) => {
            const nextZones = [...pad.zones] as [typeof pad.zones[0], typeof pad.zones[1]];
            nextZones[0] = {
              ...nextZones[0],
              soundId: sound.id,
              soundName: sound.name,
              label: sound.name,
              isCustom: true,
              startOffset: 0,
              endOffset: 1,
            };
            return { ...pad, zones: nextZones };
          });
        });
      }
    }
  };

  const handleSaveRecordedSound = async (
    blob: Blob,
    name: string,
    padIndex: number,
    zoneId: 'primary' | 'secondary'
  ) => {
    const file = new File([blob], `${name}.webm`, { type: blob.type || 'audio/webm' });
    const { buffer, arrayBuffer } = await audioEngine.decodeRawFile(file);
    const id = `mic-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const stored: StoredSound = {
      id,
      name,
      mimeType: file.type,
      size: arrayBuffer.byteLength,
      duration: buffer.duration,
      data: arrayBuffer,
      createdAt: Date.now(),
    };
    audioEngine.registerBuffer(id, buffer);
    await saveCustomSound(stored);
    setCustomSounds((prev) => [stored, ...prev]);

    updateActivePad(padIndex, (pad) => {
      const idx = zoneId === 'secondary' && pad.splitMode !== 'single' ? 1 : 0;
      const nextZones = [...pad.zones] as [typeof pad.zones[0], typeof pad.zones[1]];
      nextZones[idx] = {
        ...nextZones[idx],
        soundId: stored.id,
        soundName: stored.name,
        label: stored.name,
        isCustom: true,
        startOffset: 0,
        endOffset: 1,
      };
      return { ...pad, zones: nextZones };
    });
  };

  const handleDeleteCustomSound = async (soundId: string) => {
    audioEngine.removeCustomBuffer(soundId);
    await deleteCustomSound(soundId);
    setCustomSounds((prev) => prev.filter((s) => s.id !== soundId));
  };

  const handlePrevKit = () => {
    const idx = kits.findIndex((k) => k.id === activeKit.id);
    const prevIdx = (idx - 1 + kits.length) % kits.length;
    setActiveKitId(kits[prevIdx].id);
    audioEngine.stopAll();
    setLoopingZones({});
  };

  const handleNextKit = () => {
    const idx = kits.findIndex((k) => k.id === activeKit.id);
    const nextIdx = (idx + 1) % kits.length;
    setActiveKitId(kits[nextIdx].id);
    audioEngine.stopAll();
    setLoopingZones({});
  };

  const handleCreateKit = async (name: string, duplicateCurrent: boolean) => {
    const newId = `kit-custom-${Date.now()}`;
    const base = duplicateCurrent
      ? cloneKit(activeKit, newId, name.toUpperCase())
      : {
          ...cloneKit(DEFAULT_KITS[0], newId, name.toUpperCase()),
          category: 'Custom User Kit',
          showLabels: true,
          bankA: Array.from({ length: 8 }, (_, idx) => ({
            ...DEFAULT_KITS[0].bankA[idx],
            splitMode: 'single' as const,
            zones: [
              makeZone('primary', 'ac-kick', { label: `Pad ${idx + 1}` }),
              makeZone('secondary', 'ac-rim', { label: 'Rim' }),
            ] as [ReturnType<typeof makeZone>, ReturnType<typeof makeZone>],
          })),
          bankB: Array.from({ length: 8 }, (_, idx) => ({
            ...DEFAULT_KITS[0].bankB[idx],
            splitMode: 'single' as const,
            zones: [
              makeZone('primary', 'ac-snare', { label: `Pad ${idx + 1} B` }),
              makeZone('secondary', 'ac-rim', { label: 'Rim' }),
            ] as [ReturnType<typeof makeZone>, ReturnType<typeof makeZone>],
          })),
        };
    await saveKitToDb(base);
    setKits((prev) => [...prev, base]);
    setActiveKitId(base.id);
    setHasUnsavedChanges(false);
  };

  const handleDeleteKit = async (kitId: string) => {
    await deleteKitFromDb(kitId);
    setKits((prev) => {
      const next = prev.filter((k) => k.id !== kitId);
      if (activeKitId === kitId && next.length > 0) {
        setActiveKitId(next[0].id);
      }
      return next;
    });
  };

  const handleResetBuiltInKit = async (kitId: string) => {
    const factory = DEFAULT_KITS.find((d) => d.id === kitId);
    if (!factory) return;
    const fresh = cloneKit(factory);
    await saveKitToDb(fresh);
    setKits((prev) => prev.map((k) => (k.id === kitId ? fresh : k)));
    setHasUnsavedChanges(false);
  };

  const handleRotateSidebar = useCallback(() => {
    if (window.innerWidth < 768) {
      setSidebarRotation((prev) => (prev === 0 ? 90 : prev === 90 ? -90 : 0));
    } else {
      setSidebarPosition((prev) =>
        prev === 'right'
          ? 'bottom'
          : prev === 'bottom'
            ? 'left'
            : prev === 'left'
              ? 'top'
              : 'right'
      );
      setSidebarRotation(0);
    }
  }, []);

  const mainFlexDirection =
    sidebarPosition === 'left'
      ? 'flex-col md:flex-row-reverse'
      : sidebarPosition === 'bottom'
        ? 'flex-col'
        : sidebarPosition === 'top'
          ? 'flex-col-reverse'
          : 'flex-col md:flex-row';

  return (
    <main className={`w-full h-[100dvh] bg-[#0E1116] flex ${mainFlexDirection} overflow-hidden`}>
      {/* Main Tactile Octapad Deck */}
      <PadSurface
        kit={activeKit}
        pads={activePads}
        editZonesMode={editZonesMode}
        selectedPadIndex={selectedPadIndex}
        selectedZoneId={selectedZoneId}
        activeHits={activeHits}
        loopingZones={loopingZones}
        onTriggerZone={triggerZone}
        onReleaseZone={releaseZone}
        onSelectZone={(padIdx, zoneId, openEditor) => {
          setSelectedPadIndex(padIdx);
          setSelectedZoneId(zoneId);
          if (openEditor) {
            setZoneModalInitialTab('zones');
            setZoneModalOpen(true);
          }
        }}
        onUpdatePad={updateActivePad}
        onUpdateKitMeta={updateActiveKit}
        onExitEditMode={() => setEditZonesMode(false)}
      />

      {/* Hardware-Style Control Sidebar / Mobile Dock */}
      <ControlSidebar
        kit={activeKit}
        activeBank={activeBank}
        sidebarPosition={sidebarPosition}
        sidebarRotation={sidebarRotation}
        isFullscreen={isFullscreen}
        editZonesMode={editZonesMode}
        justSaved={justSaved}
        hasUnsavedChanges={hasUnsavedChanges}
        onToggleFullscreen={toggleFullscreen}
        onRotateSidebar={handleRotateSidebar}
        onOpenImportSound={() => {
          setZoneModalInitialTab('sound');
          setZoneModalOpen(true);
        }}
        onSaveKit={handleSaveKit}
        onToggleEditZones={() => setEditZonesMode((v) => !v)}
        onOpenProMix={() => setProMixOpen(true)}
        onSelectBank={(bank) => {
          setActiveBank(bank);
          setLoopingZones({});
        }}
        onPrevKit={handlePrevKit}
        onNextKit={handleNextKit}
      />

      {/* Custom Sound & Touch Zone Inspector Modal */}
      <ZoneSoundModal
        isOpen={zoneModalOpen}
        pads={activePads}
        selectedPadIndex={selectedPadIndex}
        selectedZoneId={selectedZoneId}
        layoutType={activeKit.layoutType}
        customSounds={customSounds}
        initialTab={zoneModalInitialTab}
        onClose={() => setZoneModalOpen(false)}
        onSelectPadAndZone={(padIdx, zoneId) => {
          setSelectedPadIndex(padIdx);
          setSelectedZoneId(zoneId);
        }}
        onUpdatePad={updateActivePad}
        onImportFiles={handleImportFiles}
        onSaveRecordedSound={handleSaveRecordedSound}
        onDeleteCustomSound={handleDeleteCustomSound}
      />

      {/* MultiTrack ProMix & Kit Manager Drawer */}
      <ProMixDrawer
        isOpen={proMixOpen}
        kit={activeKit}
        allKits={kits}
        activeBank={activeBank}
        sidebarPosition={sidebarPosition}
        sidebarRotation={sidebarRotation}
        bpm={bpm}
        metronomeOn={metronomeOn}
        isRecordingLoop={isRecordingLoop}
        isPlayingLoop={isPlayingLoop}
        hasRecordedLoop={Boolean(recordedLoop && recordedLoop.events.length > 0)}
        onClose={() => setProMixOpen(false)}
        onSelectKit={(id) => {
          setActiveKitId(id);
          audioEngine.stopAll();
          setLoopingZones({});
        }}
        onUpdateKit={updateActiveKit}
        onUpdatePad={updateActivePad}
        onChangeSidebarPosition={setSidebarPosition}
        onChangeSidebarRotation={setSidebarRotation}
        onCreateKit={handleCreateKit}
        onDeleteKit={handleDeleteKit}
        onResetBuiltInKit={handleResetBuiltInKit}
        onChangeBpm={setBpm}
        onToggleMetronome={() => setMetronomeOn((m) => !m)}
        onToggleRecordLoop={handleToggleRecordLoop}
        onTogglePlayLoop={() => setIsPlayingLoop((p) => !p)}
        onClearLoop={() => {
          setIsPlayingLoop(false);
          setRecordedLoop(null);
        }}
        onStopAllAudio={() => {
          audioEngine.stopAll();
          setLoopingZones({});
        }}
        onAuditionPad={(padIdx) => triggerZone(padIdx, 'primary', 1.0)}
      />
    </main>
  );
}
