/**
 * التمشمش - دفتر الجرد والأرباح لإدارة المبيعات والمشتريات والمخزون للمذاخر والصيدليات
 * @license Apache-2.0
 */

import React, { useEffect, useState, useMemo, useRef } from 'react';
import {
  Home,
  ShoppingCart,
  ShoppingBag,
  Receipt,
  Package,
  CreditCard,
  BarChart3,
  Database,
  Camera,
  Users,
  PackagePlus,
  Printer,
} from 'lucide-react';

import type {
  AppDatabase,
  PurchaseItem,
  SaleItem,
  ExpenseItem,
  DebtPayment,
  MedicineItem,
  ActivityLogItem,
} from './types/pharmacy.ts';
import {
  loadDatabase,
  saveDatabase,
  clearAllData,
  resetToSampleData,
} from './services/storage.ts';
import { calculateMedicineStocks } from './utils/calculations.ts';
import {
  auth,
  onAuthStateChanged,
  signInWithGoogle,
  signOutFromCloud,
  subscribeToCloudWorkspace,
  saveMedicineToCloud,
  savePurchaseToCloud,
  deletePurchaseFromCloud,
  saveSaleToCloud,
  deleteSaleFromCloud,
  saveExpenseToCloud,
  deleteExpenseFromCloud,
  savePaymentToCloud,
  logCloudActivity,
  seedLocalDatabaseToCloud,
  clearAllCloudData,
  clearCloudCollection,
  replaceCloudWithLocalDatabase,
  getEffectiveActorUid,
  type User,
  type CloudCollectionName,
} from './services/firebase.ts';
import {
  buildPrintableFromSalesGroup,
  type PrintableInvoiceConfig,
} from './utils/invoicePrint.ts';

// Tabs & Components
import { HomeTab } from './components/HomeTab.tsx';
import { PurchasesTab } from './components/PurchasesTab.tsx';
import { SalesTab } from './components/SalesTab.tsx';
import { ExpensesTab } from './components/ExpensesTab.tsx';
import { InventoryTab } from './components/InventoryTab.tsx';
import { DebtsTab } from './components/DebtsTab.tsx';
import { ReportTab } from './components/ReportTab.tsx';
import { BackupTab } from './components/BackupTab.tsx';
import { MedicineDetailsScreen } from './components/MedicineDetailsScreen.tsx';
import { BarcodeScannerModal } from './components/BarcodeScannerModal.tsx';
import { PWAInstallButton } from './components/PWAInstallButton.tsx';
import { OfflineIndicator } from './components/OfflineIndicator.tsx';
import { TeamCloudModal } from './components/TeamCloudModal.tsx';
import { MedicinesCatalogModal } from './components/MedicinesCatalogModal.tsx';
import { InvoicePrintModal } from './components/InvoicePrintModal.tsx';

type TabKey =
  | 'home'
  | 'purchases'
  | 'sales'
  | 'expenses'
  | 'inventory'
  | 'debts'
  | 'report'
  | 'backup';

const ACTOR_NAME_KEY = 'meshmesh_actor_name_v1';

export default function App() {
  const [db, setDb] = useState<AppDatabase>(() => loadDatabase());
  const [activeTab, setActiveTab] = useState<TabKey>('home');

  // Cloud & Team State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isCloudConnected, setIsCloudConnected] = useState<boolean>(true);
  const [actorName, setActorName] = useState<string>(() => {
    try {
      return localStorage.getItem(ACTOR_NAME_KEY) || 'د. علي (المدير)';
    } catch {
      return 'د. علي (المدير)';
    }
  });
  const [teamModalOpen, setTeamModalOpen] = useState(false);
  const [catalogModalOpen, setCatalogModalOpen] = useState(false);
  const [printInvoiceConfig, setPrintInvoiceConfig] = useState<PrintableInvoiceConfig | null>(null);
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);
  const [cloudError, setCloudError] = useState<string | null>(null);

  const actorNameRef = useRef<string>(actorName);
  useEffect(() => {
    actorNameRef.current = actorName;
  }, [actorName]);

  // Selected medicine for dedicated Medicine Details Screen
  const [selectedMedicineBarcode, setSelectedMedicineBarcode] = useState<string | null>(null);

  // Barcode scanner modal state
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannerCallback, setScannerCallback] = useState<((code: string) => void) | null>(null);

  // Initial barcode to pass to forms when navigating from details
  const [pendingBarcode, setPendingBarcode] = useState<string | null>(null);

  // Save changes to localStorage whenever db updates
  useEffect(() => {
    saveDatabase(db);
  }, [db]);

  // Listen to optional Firebase Auth state
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      if (user) {
        let savedCustomName: string | null = null;
        try {
          savedCustomName = localStorage.getItem(ACTOR_NAME_KEY);
        } catch {
          // ignore
        }
        if (!savedCustomName && (user.displayName || user.email)) {
          const derived = user.displayName || user.email?.split('@')[0] || 'عضو الفريق';
          setActorName(derived);
          try {
            localStorage.setItem(ACTOR_NAME_KEY, derived);
          } catch {
            // ignore
          }
        }
      }
    });
    return () => unsubAuth();
  }, []);

  // Automatic Real-Time Cloud Sync across iPhone, Android, and Web (Cloud is authoritative so cloud wipes propagate to all devices)
  useEffect(() => {
    const unsubCloud = subscribeToCloudWorkspace(
      (partial) => {
        setDb((prev) => {
          const next = { ...prev };

          if (partial.medicines !== undefined) {
            next.medicines = partial.medicines;
            const overrides: Record<string, number> = {};
            partial.medicines.forEach((m) => {
              overrides[m.barcode] = m.minStockAlert;
            });
            next.minStockOverrides = overrides;
          }
          if (partial.purchases !== undefined) {
            next.purchases = partial.purchases;
          }
          if (partial.sales !== undefined) {
            next.sales = partial.sales;
          }
          if (partial.expenses !== undefined) {
            next.expenses = partial.expenses;
          }
          if (partial.payments !== undefined) {
            next.payments = partial.payments;
          }
          if (partial.activityLogs !== undefined) {
            next.activityLogs = partial.activityLogs;
          }

          return next;
        });
      },
      (connected) => {
        setIsCloudConnected(connected);
        if (connected) {
          setCloudError(null);
        }
      }
    );

    return () => {
      unsubCloud();
    };
  }, []);

  const handleUpdateActorName = (newName: string) => {
    setActorName(newName);
    try {
      localStorage.setItem(ACTOR_NAME_KEY, newName);
    } catch {
      // ignore
    }
  };

  const handleSignIn = async () => {
    setIsCloudSyncing(true);
    setCloudError(null);
    try {
      await signInWithGoogle();
    } catch (err) {
      setCloudError(err instanceof Error ? err.message : 'تعذر تسجيل الدخول إلى السحابة');
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const handleSignOut = async () => {
    await signOutFromCloud();
  };

  const handleSyncLocalToCloud = async () => {
    await seedLocalDatabaseToCloud(db, actorName);
  };

  // Full Cloud Wipe across all devices
  const handleWipeAllCloudData = async () => {
    setIsCloudSyncing(true);
    try {
      const empty = clearAllData();
      setDb(empty);
      await clearAllCloudData();
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Selective Cloud Collection Wipe across all devices
  const handleWipeCloudCollection = async (col: CloudCollectionName) => {
    setIsCloudSyncing(true);
    try {
      setDb((prev) => {
        if (col === 'medicines') return { ...prev, medicines: [], minStockOverrides: {} };
        if (col === 'purchases') return { ...prev, purchases: [] };
        if (col === 'sales') return { ...prev, sales: [] };
        if (col === 'expenses') return { ...prev, expenses: [] };
        if (col === 'payments') return { ...prev, payments: [] };
        if (col === 'activityLogs') return { ...prev, activityLogs: [] };
        return prev;
      });
      await clearCloudCollection(col, actorName, true);
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Reset Sample Data and sync to all devices
  const handleResetSampleToCloud = async () => {
    setIsCloudSyncing(true);
    try {
      const sample = resetToSampleData();
      setDb(sample);
      await replaceCloudWithLocalDatabase(sample, actorName);
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const handleOpenDefaultPrintModal = () => {
    if (db.sales.length > 0) {
      const latestBuyer = db.sales[0].buyer;
      const latestDate = db.sales[0].date;
      const latestSales = db.sales.filter(
        (s) => s.buyer === latestBuyer && s.date === latestDate
      );
      setPrintInvoiceConfig(
        buildPrintableFromSalesGroup({
          date: latestDate,
          buyer: latestBuyer,
          items: latestSales,
          totalAmount: latestSales.reduce((sum, s) => sum + s.totalAmount, 0),
          amountPaid: latestSales.reduce((sum, s) => sum + s.amountPaid, 0),
        })
      );
    } else {
      setPrintInvoiceConfig(
        buildPrintableFromSalesGroup({
          date: new Date().toISOString().split('T')[0],
          buyer: '',
          items: [],
          totalAmount: 0,
          amountPaid: 0,
        })
      );
    }
  };

  // Append local activity log helper
  const appendLocalActivity = (
    actionType: ActivityLogItem['actionType'],
    title: string,
    details: string,
    amount: number
  ) => {
    const newLog: ActivityLogItem = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      actionType,
      title,
      details,
      amount,
      actorUid: getEffectiveActorUid(),
      actorName,
      createdAtMs: Date.now(),
    };
    setDb((prev) => ({
      ...prev,
      activityLogs: [newLog, ...(prev.activityLogs || [])].slice(0, 100),
    }));
  };

  // Dynamic stock calculations
  const stocks = useMemo(() => {
    return calculateMedicineStocks(db.purchases, db.sales, db.minStockOverrides);
  }, [db.purchases, db.sales, db.minStockOverrides]);

  // Open camera scanner helper
  const openScannerWithCallback = (cb: (code: string) => void) => {
    setScannerCallback(() => cb);
    setScannerOpen(true);
  };

  const handleScanResult = (code: string) => {
    if (scannerCallback) {
      scannerCallback(code);
    }
  };

  // Multi-item Purchase Batch Handler
  const handleAddPurchaseBatch = (items: Array<Omit<PurchaseItem, 'id' | 'createdAt'>>) => {
    if (items.length === 0) return;
    const now = Date.now();
    const uid = getEffectiveActorUid();

    const newPurchases: PurchaseItem[] = items.map((item, idx) => ({
      ...item,
      id: `p_${now}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: now + idx,
      addedByUid: uid,
      addedByName: actorName,
    }));

    const updatedMedicines = [...db.medicines];
    const newlyCreatedMeds: MedicineItem[] = [];

    for (const p of newPurchases) {
      const exists = updatedMedicines.some((m) => m.barcode === p.barcode);
      if (!exists && p.barcode) {
        const newMed: MedicineItem = {
          id: `m_${now}_${Math.random().toString(36).substring(2, 6)}`,
          barcode: p.barcode,
          name: p.medicineName,
          unit: 'باكيت',
          minStockAlert: 10,
          addedByUid: uid,
          addedByName: actorName,
        };
        updatedMedicines.push(newMed);
        newlyCreatedMeds.push(newMed);
      }
    }

    setDb((prev) => ({
      ...prev,
      purchases: [...newPurchases, ...prev.purchases],
      medicines: updatedMedicines,
    }));

    const totalInvoiceAmount = newPurchases.reduce((sum, p) => sum + p.totalAmount, 0);
    const logTitle =
      newPurchases.length === 1
        ? `إضافة قائمة شراء: ${newPurchases[0].medicineName}`
        : `إضافة فاتورة شراء (${newPurchases.length} مواد) من ${newPurchases[0].supplier}`;
    const logDetails =
      newPurchases.length === 1
        ? `${newPurchases[0].supplier} (${newPurchases[0].qty} باكيت)`
        : newPurchases.map((p) => `${p.medicineName} (${p.qty})`).join('، ');

    appendLocalActivity('add_purchase', logTitle, logDetails, totalInvoiceAmount);

    for (const p of newPurchases) {
      void savePurchaseToCloud(p, actorName);
    }
    for (const m of newlyCreatedMeds) {
      void saveMedicineToCloud(m, actorName, false);
    }
    void logCloudActivity({
      actionType: 'add_purchase',
      title: logTitle,
      details: logDetails,
      amount: totalInvoiceAmount,
      actorUid: uid,
      actorName,
    });
  };

  const handleAddPurchase = (purchase: Omit<PurchaseItem, 'id' | 'createdAt'>) => {
    handleAddPurchaseBatch([purchase]);
  };

  const handleDeletePurchase = (id: string) => {
    const target = db.purchases.find((p) => p.id === id);
    setDb((prev) => ({
      ...prev,
      purchases: prev.purchases.filter((p) => p.id !== id),
    }));
    if (target) {
      const logTitle = `حذف مادة شراء: ${target.medicineName}`;
      appendLocalActivity('delete_record', logTitle, target.supplier, target.totalAmount);
      void logCloudActivity({
        actionType: 'delete_record',
        title: logTitle,
        details: target.supplier,
        amount: target.totalAmount,
        actorName,
      });
    }
    void deletePurchaseFromCloud(id);
  };

  // Multi-item Sale Batch Handler
  const handleAddSaleBatch = (items: Array<Omit<SaleItem, 'id' | 'createdAt'>>) => {
    if (items.length === 0) return;
    const now = Date.now();
    const uid = getEffectiveActorUid();

    const newSales: SaleItem[] = items.map((item, idx) => ({
      ...item,
      id: `s_${now}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: now + idx,
      addedByUid: uid,
      addedByName: actorName,
    }));

    const updatedMedicines = [...db.medicines];
    const newlyCreatedMeds: MedicineItem[] = [];

    for (const s of newSales) {
      const exists = updatedMedicines.some((m) => m.barcode === s.barcode);
      if (!exists && s.barcode) {
        const newMed: MedicineItem = {
          id: `m_${now}_${Math.random().toString(36).substring(2, 6)}`,
          barcode: s.barcode,
          name: s.medicineName,
          unit: 'باكيت',
          minStockAlert: 10,
          addedByUid: uid,
          addedByName: actorName,
        };
        updatedMedicines.push(newMed);
        newlyCreatedMeds.push(newMed);
      }
    }

    setDb((prev) => ({
      ...prev,
      sales: [...newSales, ...prev.sales],
      medicines: updatedMedicines,
    }));

    const totalInvoiceAmount = newSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const logTitle =
      newSales.length === 1
        ? `إضافة قائمة بيع: ${newSales[0].medicineName}`
        : `إضافة فاتورة بيع (${newSales.length} مواد) إلى ${newSales[0].buyer}`;
    const logDetails =
      newSales.length === 1
        ? `${newSales[0].buyer} (${newSales[0].qty} باكيت)`
        : newSales.map((s) => `${s.medicineName} (${s.qty})`).join('، ');

    appendLocalActivity('add_sale', logTitle, logDetails, totalInvoiceAmount);

    for (const s of newSales) {
      void saveSaleToCloud(s, actorName);
    }
    for (const m of newlyCreatedMeds) {
      void saveMedicineToCloud(m, actorName, false);
    }
    void logCloudActivity({
      actionType: 'add_sale',
      title: logTitle,
      details: logDetails,
      amount: totalInvoiceAmount,
      actorUid: uid,
      actorName,
    });
  };

  const handleAddSale = (sale: Omit<SaleItem, 'id' | 'createdAt'>) => {
    handleAddSaleBatch([sale]);
  };

  const handleDeleteSale = (id: string) => {
    const target = db.sales.find((s) => s.id === id);
    setDb((prev) => ({
      ...prev,
      sales: prev.sales.filter((s) => s.id !== id),
    }));
    if (target) {
      const logTitle = `حذف مادة بيع: ${target.medicineName}`;
      appendLocalActivity('delete_record', logTitle, target.buyer, target.totalAmount);
      void logCloudActivity({
        actionType: 'delete_record',
        title: logTitle,
        details: target.buyer,
        amount: target.totalAmount,
        actorName,
      });
    }
    void deleteSaleFromCloud(id);
  };

  const handleAddExpense = (expense: Omit<ExpenseItem, 'id' | 'createdAt'>) => {
    const uid = getEffectiveActorUid();
    const newItem: ExpenseItem = {
      ...expense,
      id: `e_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      addedByUid: uid,
      addedByName: actorName,
    };

    setDb((prev) => ({
      ...prev,
      expenses: [newItem, ...prev.expenses],
    }));

    const logTitle = `تسجيل مصروف: ${newItem.type}`;
    const logDetails = newItem.note || newItem.type;
    appendLocalActivity('add_expense', logTitle, logDetails, newItem.amount);

    void saveExpenseToCloud(newItem, actorName);
    void logCloudActivity({
      actionType: 'add_expense',
      title: logTitle,
      details: logDetails,
      amount: newItem.amount,
      actorUid: uid,
      actorName,
    });
  };

  const handleDeleteExpense = (id: string) => {
    setDb((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((e) => e.id !== id),
    }));
    void deleteExpenseFromCloud(id);
  };

  const handleAddPayment = (payment: Omit<DebtPayment, 'id' | 'createdAt'>) => {
    const uid = getEffectiveActorUid();
    const newItem: DebtPayment = {
      ...payment,
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      addedByUid: uid,
      addedByName: actorName,
    };

    setDb((prev) => ({
      ...prev,
      payments: [newItem, ...prev.payments],
    }));

    const logTitle = `${newItem.type === 'receipt' ? 'قبض دفعة من' : 'تسديد دفعة إلى'}: ${newItem.partyName}`;
    const logDetails = newItem.note || 'تسديد حساب';
    appendLocalActivity('add_payment', logTitle, logDetails, newItem.amount);

    void savePaymentToCloud(newItem, actorName);
    void logCloudActivity({
      actionType: 'add_payment',
      title: logTitle,
      details: logDetails,
      amount: newItem.amount,
      actorUid: uid,
      actorName,
    });
  };

  const handleAddNewMedicine = (med: Omit<MedicineItem, 'id'>) => {
    handleUpdateMedicineDetails({
      barcode: med.barcode,
      name: med.name,
      scientificName: med.scientificName,
      unit: med.unit || 'باكيت',
      minStockAlert: med.minStockAlert ?? 10,
    });
  };

  const handleUpdateMedicineDetails = (updated: {
    barcode: string;
    name: string;
    scientificName?: string;
    unit: string;
    minStockAlert: number;
  }) => {
    const uid = getEffectiveActorUid();
    const existingMed = db.medicines.find((m) => m.barcode === updated.barcode);
    const targetMed: MedicineItem = existingMed
      ? {
          ...existingMed,
          name: updated.name,
          scientificName: updated.scientificName,
          unit: updated.unit,
          minStockAlert: updated.minStockAlert,
          addedByUid: uid,
          addedByName: actorName,
        }
      : {
          id: `m_${Date.now()}`,
          barcode: updated.barcode,
          name: updated.name,
          scientificName: updated.scientificName,
          unit: updated.unit,
          minStockAlert: updated.minStockAlert,
          addedByUid: uid,
          addedByName: actorName,
        };

    const matchingPurchases = db.purchases
      .filter((p) => p.barcode === updated.barcode && p.medicineName !== updated.name)
      .map((p) => ({ ...p, medicineName: updated.name }));

    const matchingSales = db.sales
      .filter((s) => s.barcode === updated.barcode && s.medicineName !== updated.name)
      .map((s) => ({ ...s, medicineName: updated.name }));

    setDb((prev) => {
      const idx = prev.medicines.findIndex((m) => m.barcode === updated.barcode);
      const newMedicines = [...prev.medicines];
      if (idx >= 0) {
        newMedicines[idx] = targetMed;
      } else {
        newMedicines.push(targetMed);
      }

      const newPurchases = prev.purchases.map((p) =>
        p.barcode === updated.barcode ? { ...p, medicineName: updated.name } : p
      );
      const newSales = prev.sales.map((s) =>
        s.barcode === updated.barcode ? { ...s, medicineName: updated.name } : s
      );

      return {
        ...prev,
        medicines: newMedicines,
        purchases: newPurchases,
        sales: newSales,
        minStockOverrides: {
          ...prev.minStockOverrides,
          [updated.barcode]: updated.minStockAlert,
        },
      };
    });

    const logTitle = `تعريف / تحديث مادة بالنظام: ${updated.name}`;
    const logDetails = `باركود: ${updated.barcode}`;
    appendLocalActivity('edit_medicine', logTitle, logDetails, 0);

    void saveMedicineToCloud(targetMed, actorName, false);
    for (const p of matchingPurchases) {
      void savePurchaseToCloud(p, actorName);
    }
    for (const s of matchingSales) {
      void saveSaleToCloud(s, actorName);
    }
    void logCloudActivity({
      actionType: 'edit_medicine',
      title: logTitle,
      details: logDetails,
      amount: 0,
      actorUid: uid,
      actorName,
    });
  };

  const handleUpdateMinStock = (barcode: string, newMin: number) => {
    setDb((prev) => {
      const newMedicines = prev.medicines.map((m) =>
        m.barcode === barcode ? { ...m, minStockAlert: newMin } : m
      );
      return {
        ...prev,
        medicines: newMedicines,
        minStockOverrides: {
          ...prev.minStockOverrides,
          [barcode]: newMin,
        },
      };
    });

    const existingMed = db.medicines.find((m) => m.barcode === barcode);
    if (existingMed) {
      void saveMedicineToCloud({ ...existingMed, minStockAlert: newMin }, actorName, false);
    }
  };

  // Nav item definitions
  const navTabs: Array<{ id: TabKey; label: string; icon: React.ElementType }> = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'purchases', label: 'المشتريات', icon: ShoppingCart },
    { id: 'sales', label: 'المبيعات', icon: ShoppingBag },
    { id: 'expenses', label: 'المصاريف', icon: Receipt },
    { id: 'inventory', label: 'الجرد', icon: Package },
    { id: 'debts', label: 'الديون', icon: CreditCard },
    { id: 'report', label: 'الأرباح', icon: BarChart3 },
    { id: 'backup', label: 'النسخ', icon: Database },
  ];

  const mobileBottomTabs: Array<{ id: TabKey; label: string; icon: React.ElementType }> = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'sales', label: 'المبيعات', icon: ShoppingBag },
    { id: 'purchases', label: 'المشتريات', icon: ShoppingCart },
    { id: 'inventory', label: 'الجرد', icon: Package },
    { id: 'debts', label: 'الديون', icon: CreditCard },
  ];

  const knownSuppliers = useMemo(
    () => Array.from(new Set(db.purchases.map((p) => p.supplier))).filter(Boolean),
    [db.purchases]
  );
  const knownBuyers = useMemo(
    () => Array.from(new Set(db.sales.map((s) => s.buyer))).filter(Boolean),
    [db.sales]
  );

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-slate-100/80 text-slate-900 font-sans flex flex-col selection:bg-teal-500 selection:text-white">
      {/* Top Application Header with "التمشمش" Branding & Team Cloud Controls */}
      <header className="sticky top-0 z-30 safe-top bg-gradient-to-l from-teal-950 via-teal-900 to-emerald-950 text-white shadow-md border-b border-teal-800/50 print:hidden">
        <div className="max-w-6xl mx-auto px-3 sm:px-6 py-2 flex items-center justify-between gap-2">
          <div
            onClick={() => {
              setSelectedMedicineBarcode(null);
              setActiveTab('home');
            }}
            className="flex items-center gap-2 cursor-pointer group shrink-0"
          >
            <img
              src="/assets/aistudio/meshmesh_512x512_63b0ffb6.png"
              alt="التمشمش"
              className="h-9 w-9 sm:h-10 sm:w-10 rounded-xl object-cover border-2 border-amber-300/70 shadow-sm shrink-0"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base sm:text-lg font-black tracking-tight leading-tight text-white whitespace-nowrap">
                  التمشمش
                </h1>
                <span
                  className={`h-2 w-2 rounded-full shrink-0 ${
                    isCloudConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                  }`}
                  title={isCloudConnected ? 'متصل بالسحابة' : 'وضع محلي'}
                />
              </div>
              <p className="text-[10px] sm:text-[11px] text-teal-200/85 leading-none mt-0.5 truncate max-w-[100px] sm:max-w-none">
                {actorName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            {/* Quick Print Invoice Button */}
            <button
              onClick={handleOpenDefaultPrintModal}
              className="flex items-center gap-1 whitespace-nowrap rounded-xl bg-slate-900/90 hover:bg-slate-800 px-2 sm:px-2.5 py-1.5 text-[11px] sm:text-xs font-black text-amber-300 border border-amber-400/30 transition active:scale-95"
              title="ترتيب وطباعة فاتورة أو طلبية"
            >
              <Printer className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">طباعة فاتورة</span>
              <span className="sm:hidden">طباعة</span>
            </button>

            {/* Team Activity & Full Cloud Control Button */}
            <button
              onClick={() => setTeamModalOpen(true)}
              className="flex items-center gap-1 whitespace-nowrap rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-100 border border-emerald-400/40 px-2 sm:px-2.5 py-1.5 text-[11px] sm:text-xs font-black transition active:scale-95"
              title="التحكم الكامل بالسحابة وسجل الفريق"
            >
              <Users className="h-3.5 w-3.5 shrink-0" />
              <span>السحابة</span>
            </button>

            <PWAInstallButton />

            <button
              onClick={() => {
                openScannerWithCallback((code) => {
                  setSelectedMedicineBarcode(code);
                  setActiveTab('inventory');
                });
              }}
              className="flex items-center gap-1 whitespace-nowrap rounded-xl bg-teal-800/80 hover:bg-teal-800 p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-bold text-teal-100 border border-teal-700/60 transition active:scale-95"
              title="مسح سريع للباركود"
              aria-label="مسح باركود"
            >
              <Camera className="h-4 w-4 shrink-0" />
              <span className="hidden sm:inline">مسح باركود</span>
            </button>
          </div>
        </div>

        {/* Navigation Strip (Scrollable on Mobile & Full on Desktop) */}
        <div className="bg-teal-950/60 border-t border-teal-800/50">
          <div className="max-w-6xl mx-auto px-2.5 sm:px-6 flex items-center gap-1 overflow-x-auto py-1.5 no-scrollbar">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id && !selectedMedicineBarcode;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setSelectedMedicineBarcode(null);
                    setActiveTab(tab.id);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition shrink-0 ${
                    isActive
                      ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                      : 'text-teal-100/85 hover:text-white hover:bg-teal-800/60'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
            <button
              onClick={() => setCatalogModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap text-amber-200 hover:bg-teal-800/60 transition shrink-0"
            >
              <PackagePlus className="h-3.5 w-3.5 shrink-0" />
              <span>تعريف المواد</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-3 sm:px-6 pt-3.5 pb-20 print:hidden">
        {/* Dedicated Medicine Details Screen if active */}
        {selectedMedicineBarcode && stocks[selectedMedicineBarcode] ? (
          <MedicineDetailsScreen
            stock={stocks[selectedMedicineBarcode]}
            medicineItem={db.medicines.find((m) => m.barcode === selectedMedicineBarcode)}
            purchases={db.purchases}
            sales={db.sales}
            onBack={() => setSelectedMedicineBarcode(null)}
            onUpdateMedicine={handleUpdateMedicineDetails}
            onQuickPurchase={(b) => {
              setPendingBarcode(b);
              setSelectedMedicineBarcode(null);
              setActiveTab('purchases');
            }}
            onQuickSale={(b) => {
              setPendingBarcode(b);
              setSelectedMedicineBarcode(null);
              setActiveTab('sales');
            }}
          />
        ) : (
          <>
            {activeTab === 'home' && (
              <HomeTab
                db={db}
                stocks={stocks}
                onNavigateTab={(tab) => {
                  setSelectedMedicineBarcode(null);
                  setActiveTab(tab as TabKey);
                }}
                onOpenSaleModal={() => setActiveTab('sales')}
                onOpenPurchaseModal={() => setActiveTab('purchases')}
                onOpenExpenseModal={() => setActiveTab('expenses')}
                onSelectMedicineDetails={(barcode) => setSelectedMedicineBarcode(barcode)}
                onOpenTeamModal={() => setTeamModalOpen(true)}
                onOpenCatalogModal={() => setCatalogModalOpen(true)}
                onOpenPrintModal={handleOpenDefaultPrintModal}
                isCloudConnected={isCloudConnected}
                actorName={actorName}
              />
            )}

            {activeTab === 'purchases' && (
              <PurchasesTab
                purchases={db.purchases}
                medicines={db.medicines}
                stocks={stocks}
                onAddPurchase={handleAddPurchase}
                onAddPurchaseBatch={handleAddPurchaseBatch}
                onDeletePurchase={handleDeletePurchase}
                onOpenScanner={openScannerWithCallback}
                onOpenCatalogModal={() => setCatalogModalOpen(true)}
                onPrintInvoice={(cfg) => setPrintInvoiceConfig(cfg)}
                initialBarcode={pendingBarcode}
                onClearInitialBarcode={() => setPendingBarcode(null)}
              />
            )}

            {activeTab === 'sales' && (
              <SalesTab
                sales={db.sales}
                medicines={db.medicines}
                stocks={stocks}
                onAddSale={handleAddSale}
                onAddSaleBatch={handleAddSaleBatch}
                onDeleteSale={handleDeleteSale}
                onOpenScanner={openScannerWithCallback}
                onOpenCatalogModal={() => setCatalogModalOpen(true)}
                onPrintInvoice={(cfg) => setPrintInvoiceConfig(cfg)}
                initialBarcode={pendingBarcode}
                onClearInitialBarcode={() => setPendingBarcode(null)}
              />
            )}

            {activeTab === 'expenses' && (
              <ExpensesTab
                expenses={db.expenses}
                onAddExpense={handleAddExpense}
                onDeleteExpense={handleDeleteExpense}
              />
            )}

            {activeTab === 'inventory' && (
              <InventoryTab
                stocks={stocks}
                medicines={db.medicines}
                onSelectMedicine={(barcode) => setSelectedMedicineBarcode(barcode)}
                onAddNewMedicine={handleAddNewMedicine}
                onUpdateMinStock={handleUpdateMinStock}
              />
            )}

            {activeTab === 'debts' && (
              <DebtsTab
                purchases={db.purchases}
                sales={db.sales}
                payments={db.payments}
                onAddPayment={handleAddPayment}
              />
            )}

            {activeTab === 'report' && <ReportTab db={db} />}

            {activeTab === 'backup' && (
              <BackupTab
                db={db}
                onDatabaseReplaced={async (newDb) => {
                  setDb(newDb);
                  await replaceCloudWithLocalDatabase(newDb, actorName);
                }}
                onWipeAllCloudData={handleWipeAllCloudData}
              />
            )}
          </>
        )}
      </main>

      {/* Mobile Bottom Tab Bar (Clean single-row 5-item iOS-style bar with safe-area support) */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] px-2 pt-1.5 safe-bottom print:hidden">
        <div className="grid grid-cols-5 gap-1 max-w-md mx-auto">
          {mobileBottomTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id && !selectedMedicineBarcode;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setSelectedMedicineBarcode(null);
                  setActiveTab(tab.id);
                }}
                className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-1 rounded-xl transition active:scale-95 ${
                  isActive
                    ? 'bg-teal-900 text-white font-black shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100 font-bold'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    isActive ? 'text-amber-300' : 'text-slate-500'
                  }`}
                />
                <span className="text-[10px] leading-tight truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Invoice Arrange & Custom Print Studio Modal */}
      <InvoicePrintModal
        isOpen={Boolean(printInvoiceConfig)}
        onClose={() => setPrintInvoiceConfig(null)}
        initialConfig={printInvoiceConfig}
        knownSuppliers={knownSuppliers}
        knownBuyers={knownBuyers}
        catalogMedicines={db.medicines.map((m) => ({
          barcode: m.barcode,
          name: m.name,
          unitPrice: stocks[m.barcode]?.averageCost || 0,
        }))}
      />

      {/* Medicines Catalog & Barcode Registration Modal */}
      <MedicinesCatalogModal
        isOpen={catalogModalOpen}
        onClose={() => setCatalogModalOpen(false)}
        medicines={db.medicines}
        stocks={stocks}
        purchases={db.purchases}
        sales={db.sales}
        onSaveMedicine={handleUpdateMedicineDetails}
        onOpenScanner={openScannerWithCallback}
      />

      {/* Team Activity & Full Cloud Control Modal */}
      <TeamCloudModal
        isOpen={teamModalOpen}
        onClose={() => setTeamModalOpen(false)}
        currentUser={currentUser}
        isCloudConnected={isCloudConnected}
        actorName={actorName}
        onUpdateActorName={handleUpdateActorName}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onSyncLocalToCloud={handleSyncLocalToCloud}
        onWipeAllCloudData={handleWipeAllCloudData}
        onWipeCloudCollection={handleWipeCloudCollection}
        onResetSampleToCloud={handleResetSampleToCloud}
        db={db}
        activityLogs={db.activityLogs || []}
        isCloudSyncing={isCloudSyncing}
        cloudError={cloudError}
      />

      {/* Global Camera Scanner Modal */}
      <BarcodeScannerModal
        isOpen={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScan={handleScanResult}
      />

      {/* Offline Status Badge */}
      <OfflineIndicator />
    </div>
  );
}
