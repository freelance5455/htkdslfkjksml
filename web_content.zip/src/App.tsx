import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Maximize2,
  Minimize2,
  FolderCode,
  Download,
  Terminal,
  Cpu,
  ShieldAlert,
} from 'lucide-react';
import { JarvisSettings, ScreenType, AndroidNotification, DEFAULT_SETTINGS, CapturedNotification } from './types';
import { AndroidDeviceFrame } from './components/AndroidDeviceFrame';
import { MainScreenView } from './components/MainScreenView';
import { SettingsScreenView } from './components/SettingsScreenView';
import { JarvisCallView } from './components/JarvisCallView';
import { CodeExplorerModal } from './components/CodeExplorerModal';
import { playJarvisChime, speakJarvis } from './utils/audioSynthesizer';

const SETTINGS_STORAGE_KEY = 'jarvis_native_settings_v1';

export default function App() {
  // Screen routing state
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('main');

  // Device settings (stored locally on device in localStorage)
  const [settings, setSettings] = useState<JarvisSettings>(() => {
    try {
      const stored = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
      }
    } catch {
      // LocalStorage error fallback
    }
    return DEFAULT_SETTINGS;
  });

  // UI state
  const [isFullScreenMode, setIsFullScreenMode] = useState(false);
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
  const [activeNotification, setActiveNotification] = useState<AndroidNotification | null>(null);
  const [currentTime, setCurrentTime] = useState('07:00');
  const [isMorningBriefingTrigger, setIsMorningBriefingTrigger] = useState(false);

  // Save settings whenever they change
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Storage error fallback
    }
  }, [settings]);

  // Update clock every minute
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const mins = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  // Daily Morning Briefing Scheduler simulation (AlarmManager simulation in browser)
  useEffect(() => {
    if (!settings.isDailyBriefingEnabled) return;

    if (currentTime === settings.morningBriefingTime && currentScreen !== 'call') {
      const triggerKey = `jarvis_briefing_fired_${new Date().toDateString()}_${currentTime}`;
      if (!sessionStorage.getItem(triggerKey)) {
        sessionStorage.setItem(triggerKey, 'true');
        setIsMorningBriefingTrigger(true);
        setCurrentScreen('call');
      }
    }
  }, [currentTime, settings.isDailyBriefingEnabled, settings.morningBriefingTime, currentScreen]);

  const updateSettings = (partial: Partial<JarvisSettings>) => {
    setSettings(prev => ({ ...prev, ...partial }));
  };

  const handleTriggerMorningBriefing = () => {
    setIsMorningBriefingTrigger(true);
    setCurrentScreen('call');
  };

  const handleTriggerTestCall = () => {
    setIsMorningBriefingTrigger(false);
    setCurrentScreen('call');
  };

  // Trigger test notification for Requirement 5
  const triggerTestNotification = () => {
    playJarvisChime();
    const testNotif: AndroidNotification = {
      id: Date.now().toString(),
      app: 'WhatsApp VIP',
      title: 'Dr. Banner',
      body: 'Sir, the laboratory diagnostic telemetry data is ready for your review.',
      time: 'Just now',
    };
    setActiveNotification(testNotif);

    // If notification access is granted, capture locally on device
    if (settings.isNotificationAccessGranted) {
      const captured: CapturedNotification = {
        id: `notif-live-${Date.now()}`,
        app: 'WhatsApp',
        packageName: 'com.whatsapp',
        category: 'Messaging',
        title: 'Dr. Banner',
        text: 'Sir, the laboratory diagnostic telemetry data is ready for your review.',
        timestamp: Date.now(),
        timeReceived: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        importance: 'high',
      };
      setSettings(prev => ({
        ...prev,
        capturedNotifications: [captured, ...prev.capturedNotifications.slice(0, 19)],
      }));
    }

    // If auto-read is enabled in settings and access is granted, read immediately
    if (settings.readNotificationsOnArrival && settings.isNotificationAccessGranted) {
      setTimeout(() => {
        speakJarvis(
          `Priority notification from ${testNotif.title}: ${testNotif.body}`,
          settings.voicePitch,
          settings.voiceSpeed,
          settings.voicePersonality
        );
      }, 600);
    }
  };

  const handleReadNotificationAloud = (notification: AndroidNotification) => {
    speakJarvis(
      `Notification from ${notification.app}. Sender: ${notification.title}. Message: ${notification.body}`,
      settings.voicePitch,
      settings.voiceSpeed,
      settings.voicePersonality
    );
  };

  return (
    <div className="min-h-screen w-full bg-[#05070B] text-slate-100 flex flex-col font-sans select-none overflow-x-hidden">
      {/* Top Workspace Toolbar */}
      <header className="w-full h-14 bg-[#0A0E17]/90 backdrop-blur-md border-b border-slate-800/80 px-4 md:px-8 flex items-center justify-between shrink-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#00E5FF]/10 border border-[#00E5FF]/40 flex items-center justify-center text-[#00E5FF]">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm tracking-wider text-white">JARVIS</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/30 font-semibold">
                NATIVE ANDROID
              </span>
              <span className="hidden sm:inline-block text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                JETPACK COMPOSE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden md:block">
              Personal AI Voice Assistant • Local DataStore Persistence • Zero Subscriptions
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* View Code / Export Project Button */}
          <button
            id="btn-open-code-explorer"
            onClick={() => setIsCodeModalOpen(true)}
            className="px-3 py-1.5 rounded-lg bg-[#131B2E] hover:bg-[#1C2640] border border-[#00E5FF]/40 text-[#00E5FF] text-xs font-mono font-medium flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <FolderCode className="w-4 h-4" />
            <span className="hidden sm:inline">EXPLORE KOTLIN CODE & ZIP</span>
            <span className="sm:hidden">CODE</span>
          </button>

          {/* Toggle Device Frame / Full View */}
          <button
            id="btn-toggle-frame-mode"
            onClick={() => setIsFullScreenMode(!isFullScreenMode)}
            className="p-2 rounded-lg bg-[#131B2E] hover:bg-[#1C2640] border border-slate-700 text-slate-300 hover:text-white transition-colors"
            title={isFullScreenMode ? 'Switch to Phone Mockup' : 'Switch to Full Screen View'}
          >
            {isFullScreenMode ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Smartphone className="w-4 h-4 text-[#00E5FF]" />
            )}
          </button>
        </div>
      </header>

      {/* Main Interactive Stage */}
      <main className="flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden relative">
        <AndroidDeviceFrame
          activeNotification={activeNotification}
          onDismissNotification={() => setActiveNotification(null)}
          onReadNotificationAloud={handleReadNotificationAloud}
          isFullScreenMode={isFullScreenMode}
          currentTime={currentTime}
        >
          {/* Screen Router */}
          {currentScreen === 'main' && (
            <MainScreenView
              settings={settings}
              onNavigateToSettings={() => setCurrentScreen('settings')}
              onTriggerTestCall={handleTriggerTestCall}
            />
          )}

          {currentScreen === 'settings' && (
            <SettingsScreenView
              settings={settings}
              onUpdateSettings={updateSettings}
              onNavigateBack={() => setCurrentScreen('main')}
              onTriggerTestCall={handleTriggerTestCall}
              onTriggerMorningBriefing={handleTriggerMorningBriefing}
              onRunFullMorningTest={handleTriggerMorningBriefing}
              onTriggerTestNotification={triggerTestNotification}
            />
          )}

          {currentScreen === 'call' && (
            <JarvisCallView
              settings={settings}
              isMorningBriefing={isMorningBriefingTrigger}
              onCompleteBriefing={timestamp => {
                updateSettings({ lastBriefingCompletedTimestamp: timestamp });
              }}
              onEndCall={() => {
                setIsMorningBriefingTrigger(false);
                setCurrentScreen('main');
              }}
            />
          )}
        </AndroidDeviceFrame>
      </main>

      {/* Android Studio Code Explorer & Project Downloader Modal */}
      <CodeExplorerModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
    </div>
  );
}
