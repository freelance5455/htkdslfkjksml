import React, { useState, useEffect } from 'react';
import { Product, CartItem, Order, CustomerProfile, Review, RoomChecklistItem, CurrencyCode, User } from './types';
import { INITIAL_PRODUCTS, INITIAL_REVIEWS, INITIAL_ROOM_CHECKLIST } from './data/products';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ProductFormModal } from './components/ProductFormModal';
import { AuthModal } from './components/AuthModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistModal } from './components/WishlistModal';
import { OrderHistoryModal } from './components/OrderHistoryModal';
import { RoomPlannerModal } from './components/RoomPlannerModal';
import { WindowsGuideModal } from './components/WindowsGuideModal';
import { BackupRestoreModal } from './components/BackupRestoreModal';
import { HeritageSection } from './components/HeritageSection';
import { Footer } from './components/Footer';
import { downloadProjectZip } from './utils/zipExporter';
import { Check, Download, Package, Upload, Lock, ShieldCheck } from 'lucide-react';

export default function App() {
  // Current logged in user (retrieved from localStorage if previously authenticated)
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('bue_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Local storage state initialization
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('bue_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('bue_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('bue_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('bue_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [profile, setProfile] = useState<CustomerProfile>(() => {
    try {
      const saved = localStorage.getItem('bue_profile');
      return saved ? JSON.parse(saved) : {
        fullName: 'Prince Ukasha',
        email: 'princeukasha86@gmail.com',
        phone: '+92 300 1234567',
        address: 'Bait Sanctuary Villa 12, Pine Avenue',
        city: 'Lahore',
        country: 'Pakistan',
        postalCode: '54000',
        notes: 'Please ring bell upon arrival'
      };
    } catch {
      return {
        fullName: 'Prince Ukasha',
        email: 'princeukasha86@gmail.com',
        phone: '+92 300 1234567',
        address: 'Bait Sanctuary Villa 12, Pine Avenue',
        city: 'Lahore',
        country: 'Pakistan',
        postalCode: '54000',
        notes: ''
      };
    }
  });

  const [currency, setCurrency] = useState<CurrencyCode>(() => {
    try {
      const saved = localStorage.getItem('bue_currency');
      return (saved as CurrencyCode) || 'USD';
    } catch {
      return 'USD';
    }
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('bue_reviews');
      return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  });

  const [checklist, setChecklist] = useState<RoomChecklistItem[]>(() => {
    try {
      const saved = localStorage.getItem('bue_checklist');
      return saved ? JSON.parse(saved) : INITIAL_ROOM_CHECKLIST;
    } catch {
      return INITIAL_ROOM_CHECKLIST;
    }
  });

  // Modal & Navigation states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  // Open Sign In option immediately when the app is open
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(true);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutDiscount, setCheckoutDiscount] = useState(0);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isOrderHistoryOpen, setIsOrderHistoryOpen] = useState(false);
  const [isRoomPlannerOpen, setIsRoomPlannerOpen] = useState(false);
  const [isWindowsGuideOpen, setIsWindowsGuideOpen] = useState(false);
  const [isBackupOpen, setIsBackupOpen] = useState(false);

  // Added to cart feedback
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const isOwner = currentUser?.role === 'owner';

  // Sync to LocalStorage
  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem('bue_user', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('bue_user');
      }
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [currentUser]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_products', JSON.stringify(products));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_orders', JSON.stringify(orders));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_profile', JSON.stringify(profile));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_currency', currency);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [currency]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_reviews', JSON.stringify(reviews));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [reviews]);

  useEffect(() => {
    try {
      localStorage.setItem('bue_checklist', JSON.stringify(checklist));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [checklist]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2800);
  };

  // Auth Operations
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'owner') {
      showToast(`Welcome, Prince Ukasha! Image upload & owner controls unlocked.`);
    } else {
      showToast(`Welcome back, ${user.name}!`);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showToast('Signed out. You are now in visitor view.');
  };

  const handleOpenUploadModal = () => {
    if (isOwner) {
      setProductToEdit(null);
      setIsUploadModalOpen(true);
    } else {
      showToast('Owner authorization required. Only Prince Ukasha can add images.');
      setIsAuthModalOpen(true);
    }
  };

  // Product Customization & Upload Operations (Owner Protected)
  const handleSaveProduct = (product: Product) => {
    if (!isOwner) {
      showToast('Permission denied. Please sign in as store owner.');
      setIsAuthModalOpen(true);
      return;
    }

    setProducts((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.map((p) => (p.id === product.id ? product : p));
      } else {
        return [product, ...prev];
      }
    });
    showToast(`"${product.name}" published to store!`);
  };

  const handleDeleteProduct = (productId: string) => {
    if (!isOwner) {
      showToast('Permission denied. Please sign in as store owner.');
      setIsAuthModalOpen(true);
      return;
    }

    setProducts((prev) => prev.filter((p) => p.id !== productId));
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    setWishlistIds((prev) => prev.filter((id) => id !== productId));
    if (selectedProduct?.id === productId) {
      setSelectedProduct(null);
    }
    showToast('Product removed from store.');
  };

  const handleClearDemoProducts = () => {
    if (!isOwner) {
      showToast('Permission denied.');
      return;
    }
    const onlyCustom = products.filter((p) => !p.id.startsWith('bue-'));
    setProducts(onlyCustom);
    setCart((prev) => prev.filter((item) => !item.product.id.startsWith('bue-')));
    setWishlistIds((prev) => prev.filter((id) => !id.startsWith('bue-')));
    showToast('Demo products cleared. Store now displays only your uploaded items!');
  };

  const handleResetDemoProducts = () => {
    if (!isOwner) {
      showToast('Permission denied.');
      return;
    }
    const customItems = products.filter((p) => !p.id.startsWith('bue-'));
    setProducts([...customItems, ...INITIAL_PRODUCTS]);
    showToast('Sample products restored.');
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });

    setRecentlyAddedId(product.id);
    setTimeout(() => setRecentlyAddedId(null), 1800);
    showToast(`Added ${product.name} to your Sanctuary Bag`);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Item removed from bag');
  };

  // Wishlist operations
  const handleToggleWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      if (prev.includes(productId)) {
        showToast('Removed from wishlist');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to wishlist');
        return [...prev, productId];
      }
    });
  };

  // Order placement
  const handleOrderCompleted = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCart([]); // Clear cart
    showToast(`Order #${newOrder.trackingNumber} successfully recorded!`);
  };

  // Review submission
  const handleAddReview = (newReview: Omit<Review, 'id' | 'date'>) => {
    const fullReview: Review = {
      ...newReview,
      id: `rev-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      })
    };
    setReviews((prev) => [fullReview, ...prev]);
    showToast('Thank you! Your verified review has been published.');
  };

  // Room Planner operations
  const handleToggleChecklistItem = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const handleAddCustomChecklistItem = (room: any, name: string, costUsd: number) => {
    const newItem: RoomChecklistItem = {
      id: `chk-custom-${Date.now()}`,
      room,
      name,
      checked: true,
      estimatedCostUsd: costUsd
    };
    setChecklist((prev) => [...prev, newItem]);
    showToast(`Added "${name}" to ${room} checklist`);
  };

  const handleRemoveChecklistItem = (id: string) => {
    setChecklist((prev) => prev.filter((item) => item.id !== id));
  };

  const handleAddCheckedItemsToCart = (checkedItems: RoomChecklistItem[]) => {
    checkedItems.forEach((item) => {
      const matchProduct = item.productId
        ? products.find((p) => p.id === item.productId)
        : null;

      if (matchProduct) {
        handleAddToCart(matchProduct, 1);
      } else {
        const customItemProduct: Product = {
          id: `custom-bundle-${item.id}`,
          name: `${item.room} Essential: ${item.name}`,
          category: 'Living & Storage',
          room: item.room,
          priceUsd: item.estimatedCostUsd,
          rating: 5.0,
          reviewsCount: 1,
          image: '/src/assets/images/hero_home_essentials_1792296360356.jpg',
          description: `Custom curated essential tailored for your ${item.room} sanctuary.`,
          materials: 'Artisanal Natural Finish',
          dimensions: 'Standard Architectural Fit',
          inStock: true,
          stockCount: 10,
          careInstructions: 'Spot clean gently with warm water.',
          features: ['Custom room specification']
        };
        handleAddToCart(customItemProduct, 1);
      }
    });

    setIsCartOpen(true);
    showToast(`Added ${checkedItems.length} room essentials to your bag!`);
  };

  // ZIP download handler
  const handleDownloadZip = async () => {
    showToast('Packaging complete project files into ZIP...');
    try {
      await downloadProjectZip();
      showToast('Project ZIP downloaded successfully!');
    } catch (err) {
      console.error(err);
      showToast('Error generating ZIP file.');
    }
  };

  // Export / Import Data
  const handleExportData = () => {
    const payload = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      products,
      cart,
      wishlistIds,
      orders,
      profile,
      currency,
      reviews,
      checklist
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bait-ul-ukasha-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Local data & custom products exported to JSON!');
  };

  const handleImportData = (importedData: any): boolean => {
    if (!importedData || typeof importedData !== 'object') return false;
    try {
      if (Array.isArray(importedData.products)) setProducts(importedData.products);
      if (Array.isArray(importedData.cart)) setCart(importedData.cart);
      if (Array.isArray(importedData.wishlistIds)) setWishlistIds(importedData.wishlistIds);
      if (Array.isArray(importedData.orders)) setOrders(importedData.orders);
      if (importedData.profile) setProfile(importedData.profile);
      if (importedData.currency) setCurrency(importedData.currency);
      if (Array.isArray(importedData.reviews)) setReviews(importedData.reviews);
      if (Array.isArray(importedData.checklist)) setChecklist(importedData.checklist);
      return true;
    } catch {
      return false;
    }
  };

  const handleResetData = () => {
    setProducts(INITIAL_PRODUCTS);
    setCart([]);
    setWishlistIds([]);
    setOrders([]);
    setReviews(INITIAL_REVIEWS);
    setChecklist(INITIAL_ROOM_CHECKLIST);
    showToast('Local data restored to clean default state.');
  };

  const wishlistProducts = products.filter((p) => wishlistIds.includes(p.id));

  const scrollToCatalog = () => {
    document.getElementById('catalog-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToHeritage = () => {
    document.getElementById('heritage-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const hasDemoProducts = products.some((p) => p.id.startsWith('bue-'));

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-800 font-sans selection:bg-stone-300 selection:text-stone-900">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#2D2A26] text-white text-xs font-medium py-3 px-4 rounded-xl shadow-xl flex items-center gap-2.5 animate-in slide-in-from-bottom-3 duration-200 border border-stone-700">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Navigation Header */}
      <Header
        cartCount={cart.reduce((total, item) => total + item.quantity, 0)}
        wishlistCount={wishlistIds.length}
        activeCurrency={currency}
        currentUser={currentUser}
        onCurrencyChange={setCurrency}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenWindowsGuide={() => setIsWindowsGuideOpen(true)}
        onOpenBackup={() => setIsBackupOpen(true)}
        onOpenRoomPlanner={() => setIsRoomPlannerOpen(true)}
        onOpenUploadProduct={handleOpenUploadModal}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onDownloadZip={handleDownloadZip}
        onScrollToCatalog={scrollToCatalog}
        onScrollToHeritage={scrollToHeritage}
      />

      {/* Main Page Content */}
      <main className="flex-1">
        <Hero
          onExploreCatalog={scrollToCatalog}
          onOpenRoomPlanner={() => setIsRoomPlannerOpen(true)}
        />

        {/* Catalog Section with Search, Filtering, and Protected Controls */}
        <ProductGrid
          products={products}
          activeCurrency={currency}
          wishlistIds={wishlistIds}
          isOwner={isOwner}
          onToggleWishlist={handleToggleWishlist}
          onSelectProduct={(p) => setSelectedProduct(p)}
          onAddToCart={(p) => handleAddToCart(p, 1)}
          addedProductId={recentlyAddedId}
          onOpenUploadModal={handleOpenUploadModal}
          onEditProduct={(p) => {
            if (isOwner) {
              setProductToEdit(p);
              setIsUploadModalOpen(true);
            } else {
              setIsAuthModalOpen(true);
            }
          }}
          onDeleteProduct={handleDeleteProduct}
          onClearDemoProducts={handleClearDemoProducts}
          onResetDemoProducts={handleResetDemoProducts}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          hasDemoProducts={hasDemoProducts}
        />

        {/* Floating Quick Action for Windows & Source Code */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
          <div className="bg-gradient-to-r from-[#322E2B] to-[#24211E] text-[#FAF8F5] rounded-2xl p-6 sm:p-8 shadow-lg border border-stone-700/60 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-1.5 text-center md:text-left">
              <span className="text-[11px] uppercase tracking-widest text-amber-200 font-semibold">
                Self-Contained & Installable Application
              </span>
              <h3 className="font-serif text-2xl font-normal text-white">
                Download Bait ul Ukasha to run offline on Windows
              </h3>
              <p className="text-xs text-stone-300 max-w-xl">
                {isOwner
                  ? 'Owner access active: You can upload your own products, save your orders, and manage inventory right from your hard drive.'
                  : 'Zero third-party cloud dependence. Save your orders, cart, and room designs right on your hard drive with automated batch file launching.'}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              {isOwner ? (
                <button
                  onClick={handleOpenUploadModal}
                  className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all shadow-sm"
                >
                  <Upload className="w-4 h-4 text-stone-900" />
                  <span>Upload Product</span>
                </button>
              ) : (
                <button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="px-4 py-2.5 bg-stone-100 hover:bg-white text-stone-900 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all shadow-sm"
                >
                  <Lock className="w-4 h-4 text-stone-800" />
                  <span>Owner Sign In</span>
                </button>
              )}
              <button
                onClick={handleDownloadZip}
                className="px-5 py-2.5 bg-white hover:bg-stone-100 text-stone-900 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all shadow-sm"
              >
                <Download className="w-4 h-4 text-stone-800" />
                <span>Download Source ZIP</span>
              </button>
              <button
                onClick={() => setIsWindowsGuideOpen(true)}
                className="px-5 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all"
              >
                <span>Read Windows Guide</span>
              </button>
              {orders.length > 0 && (
                <button
                  onClick={() => setIsOrderHistoryOpen(true)}
                  className="px-4 py-2.5 bg-stone-800/80 hover:bg-stone-700 text-stone-200 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer border border-stone-600"
                >
                  <Package className="w-4 h-4" />
                  <span>My Orders ({orders.length})</span>
                </button>
              )}
            </div>
          </div>
        </section>

        {/* Heritage & Brand Philosophy */}
        <HeritageSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenWindowsGuide={() => setIsWindowsGuideOpen(true)}
        onOpenBackup={() => setIsBackupOpen(true)}
        onOpenRoomPlanner={() => setIsRoomPlannerOpen(true)}
        onDownloadZip={handleDownloadZip}
        onScrollToCatalog={scrollToCatalog}
        onScrollToHeritage={scrollToHeritage}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        currentUser={currentUser}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />

      {/* Product Upload & Edit Modal (Owner protected) */}
      <ProductFormModal
        isOpen={isUploadModalOpen}
        productToEdit={productToEdit}
        activeCurrency={currency}
        onClose={() => {
          setIsUploadModalOpen(false);
          setProductToEdit(null);
        }}
        onSaveProduct={handleSaveProduct}
      />

      <ProductDetailModal
        product={selectedProduct}
        activeCurrency={currency}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        reviews={reviews}
        onClose={() => setSelectedProduct(null)}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onAddReview={handleAddReview}
      />

      <CartDrawer
        isOpen={isCartOpen}
        cart={cart}
        activeCurrency={currency}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onOpenCheckout={(disc) => {
          setCheckoutDiscount(disc);
          setIsCheckoutOpen(true);
        }}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        cart={cart}
        discountPercent={checkoutDiscount}
        activeCurrency={currency}
        savedProfile={profile}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderCompleted={handleOrderCompleted}
        onSaveProfile={setProfile}
      />

      <WishlistModal
        isOpen={isWishlistOpen}
        wishlistProducts={wishlistProducts}
        activeCurrency={currency}
        onClose={() => setIsWishlistOpen(false)}
        onRemoveFromWishlist={handleToggleWishlist}
        onMoveToCart={(p) => handleAddToCart(p, 1)}
      />

      <OrderHistoryModal
        isOpen={isOrderHistoryOpen}
        orders={orders}
        activeCurrency={currency}
        onClose={() => setIsOrderHistoryOpen(false)}
      />

      <RoomPlannerModal
        isOpen={isRoomPlannerOpen}
        checklist={checklist}
        activeCurrency={currency}
        products={products}
        onClose={() => setIsRoomPlannerOpen(false)}
        onToggleItem={handleToggleChecklistItem}
        onAddCustomItem={handleAddCustomChecklistItem}
        onRemoveItem={handleRemoveChecklistItem}
        onAddCheckedToCart={handleAddCheckedItemsToCart}
      />

      <WindowsGuideModal
        isOpen={isWindowsGuideOpen}
        onClose={() => setIsWindowsGuideOpen(false)}
        onDownloadZip={handleDownloadZip}
      />

      <BackupRestoreModal
        isOpen={isBackupOpen}
        onClose={() => setIsBackupOpen(false)}
        onExportData={handleExportData}
        onImportData={handleImportData}
        onResetData={handleResetData}
      />
    </div>
  );
}
