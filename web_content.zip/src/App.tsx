import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { InvestorToolbar } from './components/InvestorToolbar';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServiceCardsSection } from './components/ServiceCardsSection';
import { ProcessStepsSection } from './components/ProcessStepsSection';
import { FeaturedHospitalsSection } from './components/FeaturedHospitalsSection';
import { HealingDestinationsSection } from './components/HealingDestinationsSection';
import { ContactSection } from './components/ContactSection';
import { RequestFormView } from './components/RequestFormView';
import { MedicalSectorView } from './views/MedicalSectorView';
import { RehabSectorView } from './views/RehabSectorView';
import { TourismSectorView } from './views/TourismSectorView';
import { ReceptionSectorView } from './views/ReceptionSectorView';
import { PatientTrackingView } from './views/PatientTrackingView';
import { InternationalSectorView } from './views/InternationalSectorView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { AboutView } from './views/AboutView';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';

import { WelcomeScreen } from './components/WelcomeScreen';

const MainAppContent: React.FC = () => {
  const { currentView } = useApp();

  if (currentView === 'welcome') {
    return (
      <div className="min-h-screen flex flex-col bg-slate-950">
        <InvestorToolbar />
        <WelcomeScreen />
        <Toast />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      {/* 1. Investor Demo Utility Bar */}
      <InvestorToolbar />

      {/* 2. Regulatory & Transparency Banner */}
      <DisclaimerBanner />

      {/* 3. Luxury Medical Navbar */}
      <Navbar />

      {/* 4. Active Interactive View */}
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            <HeroSection />
            <ServiceCardsSection />
            <ProcessStepsSection />
            <FeaturedHospitalsSection />
            <HealingDestinationsSection />
            <ContactSection />
          </>
        )}

        {currentView === 'medical' && <MedicalSectorView />}
        {currentView === 'rehab' && <RehabSectorView />}
        {currentView === 'tourism' && <TourismSectorView />}
        {currentView === 'reception' && <ReceptionSectorView />}
        {currentView === 'tracking' && <PatientTrackingView />}
        {currentView === 'international' && <InternationalSectorView />}
        {currentView === 'request-form' && <RequestFormView />}
        {currentView === 'admin' && <AdminDashboardView />}
        {currentView === 'about' && <AboutView />}
      </main>

      {/* 5. Comprehensive Footer */}
      <Footer />

      {/* 6. Real-time Toast Notifications */}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
