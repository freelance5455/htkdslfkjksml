import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  createDefaultProgression,
  DEFAULT_PROFILES,
  DEFAULT_SETTINGS,
  Profile,
  ProfileProgression,
  ScreenReaderVoiceId,
  SystemPhase,
  SystemSettings,
  WALLPAPER_OPTIONS,
} from './types/system';
import { soundEngine } from './audio/soundEngine';
import { screenReader } from './audio/screenReader';
import { StartupSequence } from './components/StartupSequence';
import { ProfileSelection } from './components/ProfileSelection';
import { HomeScreen } from './components/HomeScreen';

const PROFILES_STORAGE_KEY = 'retro_game_system_profiles_v2';
const ACCESSIBILITY_STORAGE_KEY = 'retro_game_system_accessibility_v1';
const LEGACY_PROFILES_KEY = 'retro_game_system_profiles_v1';
const LEGACY_SETTINGS_KEY = 'retro_game_system_settings_v1';

interface AccessibilityConfig {
  screenReaderEnabled: boolean;
  screenReaderVolume: number;
  screenReaderVoiceId: ScreenReaderVoiceId;
  screenReaderRate: number;
  screenReaderHintsEnabled: boolean;
}

function sanitizeAccessibility(
  raw?: Partial<AccessibilityConfig> | null
): AccessibilityConfig {
  return {
    screenReaderEnabled:
      typeof raw?.screenReaderEnabled === 'boolean'
        ? raw.screenReaderEnabled
        : DEFAULT_SETTINGS.screenReaderEnabled,
    screenReaderVolume:
      typeof raw?.screenReaderVolume === 'number' && !Number.isNaN(raw.screenReaderVolume)
        ? Math.max(0, Math.min(1, raw.screenReaderVolume))
        : DEFAULT_SETTINGS.screenReaderVolume,
    screenReaderVoiceId: 'maya-us',
    screenReaderRate:
      typeof raw?.screenReaderRate === 'number' && !Number.isNaN(raw.screenReaderRate)
        ? Math.max(0.75, Math.min(1.35, raw.screenReaderRate))
        : DEFAULT_SETTINGS.screenReaderRate,
    screenReaderHintsEnabled:
      typeof raw?.screenReaderHintsEnabled === 'boolean'
        ? raw.screenReaderHintsEnabled
        : DEFAULT_SETTINGS.screenReaderHintsEnabled,
  };
}

function sanitizeSettings(
  raw?: Partial<SystemSettings> | null,
  accessibility?: AccessibilityConfig
): SystemSettings {
  const validWallpaper =
    raw?.wallpaperId && WALLPAPER_OPTIONS.some((w) => w.id === raw.wallpaperId)
      ? raw.wallpaperId
      : DEFAULT_SETTINGS.wallpaperId;

  const baseAcc = accessibility ?? sanitizeAccessibility(raw);

  return {
    ...DEFAULT_SETTINGS,
    ...(raw ?? {}),
    wallpaperId: validWallpaper,
    ...baseAcc,
  };
}

function sanitizeProgression(
  raw: Partial<ProfileProgression> | undefined,
  wallpaperId: SystemSettings['wallpaperId']
): ProfileProgression {
  const base = createDefaultProgression(wallpaperId);
  if (!raw) return base;
  return {
    ...base,
    ...raw,
    level: Math.max(1, Number(raw.level) || 1),
    xp: Math.max(0, Number(raw.xp) || 0),
    xpToNext: Math.max(100, Number(raw.xpToNext) || 100),
    sessionsCount: Math.max(1, Number(raw.sessionsCount) || 1),
    wallpapersTried:
      Array.isArray(raw.wallpapersTried) && raw.wallpapersTried.length > 0
        ? raw.wallpapersTried
        : [wallpaperId],
    unlockedMilestones:
      Array.isArray(raw.unlockedMilestones) && raw.unlockedMilestones.length > 0
        ? raw.unlockedMilestones
        : base.unlockedMilestones,
    installedGameIds: Array.isArray(raw.installedGameIds) ? raw.installedGameIds : [],
    lastActiveAt: typeof raw.lastActiveAt === 'string' ? raw.lastActiveAt : base.lastActiveAt,
  };
}

function awardXp(
  prog: ProfileProgression,
  amount: number,
  milestone?: string
): ProfileProgression {
  let level = prog.level;
  let xp = prog.xp + amount;
  let xpToNext = prog.xpToNext;

  while (xp >= xpToNext) {
    xp -= xpToNext;
    level += 1;
    xpToNext = Math.round(xpToNext * 1.35);
  }

  const unlockedMilestones =
    milestone && !prog.unlockedMilestones.includes(milestone)
      ? [...prog.unlockedMilestones, milestone]
      : prog.unlockedMilestones;

  return {
    ...prog,
    level,
    xp,
    xpToNext,
    unlockedMilestones,
    lastActiveAt: new Date().toISOString(),
  };
}

function loadInitialAccessibility(): AccessibilityConfig {
  try {
    const raw = localStorage.getItem(ACCESSIBILITY_STORAGE_KEY);
    if (raw) {
      return sanitizeAccessibility(JSON.parse(raw) as Partial<AccessibilityConfig>);
    }
  } catch {
    // Fallback cleanly to calm US English African American female voice default
  }
  return sanitizeAccessibility(DEFAULT_SETTINGS);
}

function loadInitialProfiles(accessibility: AccessibilityConfig): Profile[] {
  try {
    const rawV2 = localStorage.getItem(PROFILES_STORAGE_KEY);
    if (rawV2) {
      const parsed = JSON.parse(rawV2) as Partial<Profile>[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((p, idx) => {
          const settings = sanitizeSettings(p.settings, accessibility);
          return {
            id: p.id || `profile-${idx}`,
            name: p.name || 'Player',
            avatarUrl: p.avatarUrl || DEFAULT_PROFILES[0].avatarUrl,
            gamesCount: Number(p.gamesCount) || 0,
            createdAt: p.createdAt || new Date().toISOString(),
            settings,
            progression: sanitizeProgression(p.progression, settings.wallpaperId),
          };
        });
      }
    }

    // Migrate v1 profiles/settings if present
    const rawLegacyProfiles = localStorage.getItem(LEGACY_PROFILES_KEY);
    const rawLegacySettings = localStorage.getItem(LEGACY_SETTINGS_KEY);
    const legacySettings = rawLegacySettings
      ? sanitizeSettings(JSON.parse(rawLegacySettings) as Partial<SystemSettings>, accessibility)
      : sanitizeSettings(DEFAULT_SETTINGS, accessibility);

    if (rawLegacyProfiles) {
      const parsed = JSON.parse(rawLegacyProfiles) as Partial<Profile>[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((p, idx) => {
          const settings =
            idx === 0
              ? { ...legacySettings }
              : sanitizeSettings(DEFAULT_SETTINGS, accessibility);
          return {
            id: p.id || `profile-${idx}`,
            name: p.name || 'Player',
            avatarUrl: p.avatarUrl || DEFAULT_PROFILES[0].avatarUrl,
            gamesCount: Number(p.gamesCount) || 0,
            createdAt: new Date().toISOString(),
            settings,
            progression: createDefaultProgression(settings.wallpaperId),
          };
        });
      }
    }
  } catch {
    // Fallback cleanly to defaults
  }

  return DEFAULT_PROFILES.map((p) => ({
    ...p,
    settings: sanitizeSettings(p.settings, accessibility),
    progression: { ...p.progression },
  }));
}

export default function App() {
  const [phase, setPhase] = useState<SystemPhase>('STARTUP');
  const [profileFromBoot, setProfileFromBoot] = useState(true);
  const [startupRunId, setStartupRunId] = useState(0);

  // Single atomic initial load for system-locked Accessibility + per-profile data
  const [initialState] = useState(() => {
    const accessibility = loadInitialAccessibility();
    const initialProfiles = loadInitialProfiles(accessibility);
    return {
      accessibility,
      profiles: initialProfiles,
      activeProfileId: initialProfiles[0]?.id ?? DEFAULT_PROFILES[0].id,
    };
  });

  const [accessibility, setAccessibility] = useState<AccessibilityConfig>(
    initialState.accessibility
  );
  const [profiles, setProfiles] = useState<Profile[]>(initialState.profiles);
  const [activeProfileId, setActiveProfileId] = useState<string>(initialState.activeProfileId);
  const [audioUnlocked, setAudioUnlocked] = useState(false);
  const [isPortrait, setIsPortrait] = useState(
    typeof window !== 'undefined' ? window.innerHeight > window.innerWidth : false
  );
  const [isFullscreen, setIsFullscreen] = useState(false);

  const activeProfile = useMemo(
    () => profiles.find((p) => p.id === activeProfileId) ?? profiles[0] ?? DEFAULT_PROFILES[0],
    [profiles, activeProfileId]
  );

  // System-level accessibility voice stays locked across Boot, Profile Select, Home, Overlays & Profiles
  const activeSettings = useMemo<SystemSettings>(
    () => ({
      ...activeProfile.settings,
      ...accessibility,
    }),
    [activeProfile.settings, accessibility]
  );

  // Sync audio & screen reader configuration whenever active profile or accessibility config changes
  useEffect(() => {
    soundEngine.updateSettings(activeSettings);
    screenReader.updateSettings({
      enabled: accessibility.screenReaderEnabled,
      volume: accessibility.screenReaderVolume,
      masterVolume: activeSettings.masterVolume,
      voiceId: accessibility.screenReaderVoiceId,
      rate: accessibility.screenReaderRate,
      hintsEnabled: accessibility.screenReaderHintsEnabled,
    });
  }, [activeSettings, accessibility]);

  // Persist system accessibility voice settings independently so switching screens/profiles never resets voice
  useEffect(() => {
    try {
      localStorage.setItem(ACCESSIBILITY_STORAGE_KEY, JSON.stringify(accessibility));
    } catch {
      // Ignore storage quota errors
    }
  }, [accessibility]);

  // Persist all profiles (each with its own wallpaper, audio & progression)
  useEffect(() => {
    try {
      localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
    } catch {
      // Ignore storage quota errors
    }
  }, [profiles]);

  const handleUnlockAudio = useCallback(() => {
    soundEngine.unlock().then((unlocked) => {
      setAudioUnlocked(unlocked);
      if (unlocked && phase === 'PROFILE_SELECT') {
        soundEngine.startMusic('profile');
      } else if (unlocked && phase === 'HOME') {
        soundEngine.startMusic('home');
      }
    });
  }, [phase]);

  const phaseRef = useRef<SystemPhase>(phase);
  phaseRef.current = phase;

  useEffect(() => {
    const unsub = soundEngine.subscribe(setAudioUnlocked);
    soundEngine.unlock();

    const onGesture = () => {
      soundEngine.unlock().then((unlocked) => {
        setAudioUnlocked(unlocked);
        if (unlocked) {
          if (phaseRef.current === 'PROFILE_SELECT') {
            soundEngine.startMusic('profile');
          } else if (phaseRef.current === 'HOME') {
            soundEngine.startMusic('home');
          }
          window.removeEventListener('pointerdown', onGesture);
          window.removeEventListener('keydown', onGesture);
        }
      });
    };

    window.addEventListener('pointerdown', onGesture, { passive: true });
    window.addEventListener('keydown', onGesture, { passive: true });

    return () => {
      unsub();
      window.removeEventListener('pointerdown', onGesture);
      window.removeEventListener('keydown', onGesture);
    };
  }, []);

  // Enforce landscape mode on resize & try native orientation lock when supported
  useEffect(() => {
    const handleResize = () => {
      setIsPortrait(window.innerHeight > window.innerWidth);
    };
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };

    const orientation = screen?.orientation as ScreenOrientation & {
      lock?: (orientation: string) => Promise<void>;
    };
    if (orientation && typeof orientation.lock === 'function') {
      orientation.lock('landscape').catch(() => {
        // Fallback CSS landscape rotation handles restricted iframes cleanly
      });
    }

    window.addEventListener('resize', handleResize);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const handleToggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        const orientation = screen?.orientation as ScreenOrientation & {
          lock?: (orientation: string) => Promise<void>;
        };
        if (orientation && typeof orientation.lock === 'function') {
          orientation.lock('landscape').catch(() => {});
        }
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Ignore fullscreen rejection in restricted iframes
    }
  }, []);

  const handleStartupComplete = useCallback(() => {
    setProfileFromBoot(true);
    setPhase('PROFILE_SELECT');
    soundEngine.startMusic('profile');
  }, []);

  const handleSelectProfile = useCallback((selected: Profile) => {
    setProfiles((prev) =>
      prev.map((p) => {
        if (p.id !== selected.id) return p;
        const nextSessions = p.progression.sessionsCount + 1;
        const milestone = nextSessions >= 3 ? 'Returning Legend' : undefined;
        const nextProg = awardXp(
          { ...p.progression, sessionsCount: nextSessions },
          15,
          milestone
        );
        return { ...p, progression: nextProg };
      })
    );
    setActiveProfileId(selected.id);
    setPhase('HOME');
    soundEngine.startMusic('home');
  }, []);

  const handleAddProfile = useCallback(
    (name: string, avatarUrl: string): Profile => {
      const freshSettings: SystemSettings = {
        ...DEFAULT_SETTINGS,
        ...accessibility,
      };
      const created: Profile = {
        id: `profile-${Date.now()}`,
        name,
        avatarUrl,
        gamesCount: 0,
        createdAt: new Date().toISOString(),
        settings: freshSettings,
        progression: createDefaultProgression(freshSettings.wallpaperId),
      };
      setProfiles((prev) => [...prev, created]);
      return created;
    },
    [accessibility]
  );

  const handleUpdateActiveProfileSettings = useCallback(
    (next: SystemSettings) => {
      const nextAccessibility = sanitizeAccessibility({
        screenReaderEnabled: next.screenReaderEnabled,
        screenReaderVolume: next.screenReaderVolume,
        screenReaderVoiceId: next.screenReaderVoiceId,
        screenReaderRate: next.screenReaderRate,
        screenReaderHintsEnabled: next.screenReaderHintsEnabled,
      });

      // Keep chosen accessibility voice & options locked consistently system-wide
      setAccessibility(nextAccessibility);

      setProfiles((prev) =>
        prev.map((p) => {
          // Sync system accessibility fields across all profiles while keeping theme/audio/progression per-profile
          if (p.id !== activeProfileId) {
            return {
              ...p,
              settings: {
                ...p.settings,
                ...nextAccessibility,
              },
            };
          }

          let nextProg = p.progression;
          if (next.wallpaperId !== p.settings.wallpaperId) {
            const tried = nextProg.wallpapersTried.includes(next.wallpaperId)
              ? nextProg.wallpapersTried
              : [...nextProg.wallpapersTried, next.wallpaperId];
            nextProg = awardXp(
              { ...nextProg, wallpapersTried: tried },
              tried.length > nextProg.wallpapersTried.length ? 20 : 5,
              tried.length >= 3 ? 'Theme Explorer' : 'Theme Stylist'
            );
          } else if (
            next.musicVolume !== p.settings.musicVolume ||
            next.sfxVolume !== p.settings.sfxVolume ||
            next.screenReaderVoiceId !== p.settings.screenReaderVoiceId
          ) {
            nextProg = awardXp(nextProg, 5, 'Audio Architect');
          }

          return {
            ...p,
            settings: {
              ...next,
              ...nextAccessibility,
            },
            progression: nextProg,
          };
        })
      );
    },
    [activeProfileId]
  );

  const handleRecordProfileProgress = useCallback(
    (xpAmount: number, milestone?: string) => {
      setProfiles((prev) =>
        prev.map((p) => {
          if (p.id !== activeProfileId) return p;
          return {
            ...p,
            progression: awardXp(p.progression, xpAmount, milestone),
          };
        })
      );
    },
    [activeProfileId]
  );

  const handleSwitchProfile = useCallback(() => {
    soundEngine.playBack();
    setProfileFromBoot(false);
    setPhase('PROFILE_SELECT');
    soundEngine.startMusic('profile');
  }, []);

  const handleReplayStartup = useCallback(() => {
    screenReader.stop();
    soundEngine.stopMusic();
    setStartupRunId((prev) => prev + 1);
    setProfileFromBoot(true);
    setPhase('STARTUP');
  }, []);

  const activeWallpaper =
    WALLPAPER_OPTIONS.find((w) => w.id === activeSettings.wallpaperId) ?? WALLPAPER_OPTIONS[0];

  const landscapeContainerStyle: React.CSSProperties = isPortrait
    ? {
        width: '100vh',
        height: '100vw',
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%) rotate(90deg)',
        transformOrigin: 'center center',
      }
    : {
        width: '100vw',
        height: '100vh',
        position: 'fixed',
        inset: 0,
      };

  return (
    <div className="w-screen h-screen bg-[#020308] overflow-hidden relative">
      <div style={landscapeContainerStyle} className="overflow-hidden bg-[#060911]">
        {phase === 'STARTUP' && (
          <StartupSequence
            key={startupRunId}
            onComplete={handleStartupComplete}
            audioUnlocked={audioUnlocked}
            onUnlockAudio={handleUnlockAudio}
          />
        )}

        {phase === 'PROFILE_SELECT' && (
          <ProfileSelection
            profiles={profiles}
            activeProfileId={activeProfileId}
            onSelectProfile={handleSelectProfile}
            onAddProfile={handleAddProfile}
            onUnlockAudio={handleUnlockAudio}
            isRotatedPortrait={isPortrait}
            fromBoot={profileFromBoot}
          />
        )}

        {phase === 'HOME' && (
          <HomeScreen
            key={activeProfile.id}
            profile={activeProfile}
            wallpaper={activeWallpaper}
            settings={activeSettings}
            onUpdateSettings={handleUpdateActiveProfileSettings}
            onRecordProgress={handleRecordProfileProgress}
            onSwitchProfile={handleSwitchProfile}
            onReplayStartup={handleReplayStartup}
            onToggleFullscreen={handleToggleFullscreen}
            isFullscreen={isFullscreen}
            isRotatedPortrait={isPortrait}
            onUnlockAudio={handleUnlockAudio}
          />
        )}
      </div>
    </div>
  );
}
