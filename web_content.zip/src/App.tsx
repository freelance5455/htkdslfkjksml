/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Transaction,
  Category,
  MonthlyBudget,
  ShoppingItem,
  SecuritySettings,
  AppSettings,
  NavigationTab,
  Account,
  UserProfile,
  AuditHistoryLog,
  FinancialGoal,
} from './types';
import {
  storage,
  DEFAULT_SECURITY_SETTINGS,
  DEFAULT_APP_SETTINGS,
  DEFAULT_USER_PROFILE,
} from './utils/storage';
import { MobileContainer } from './components/MobileContainer';
import { DashboardView } from './components/views/DashboardView';
import { ReportsView } from './components/views/ReportsView';
import { BudgetView } from './components/views/BudgetView';
import { ShoppingListView } from './components/views/ShoppingListView';
import { SecurityAndBackupView } from './components/views/SecurityAndBackupView';
import { SettingsView } from './components/views/SettingsView';
import { ThemeView } from './components/views/ThemeView';
import { LanguageView } from './components/views/LanguageView';
import { LoanView } from './components/views/LoanView';
import { AddTransactionModal } from './components/AddTransactionModal';
import { EditTransactionModal } from './components/EditTransactionModal';
import { BudgetModal } from './components/BudgetModal';
import { ManageCategoriesModal } from './components/ManageCategoriesModal';
import { AppLockModal } from './components/AppLock';
import { WelcomeOnboardingModal } from './components/WelcomeOnboardingModal';
import { PasswordVerifyModal } from './components/PasswordVerifyModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { getCurrentMonthFormatted } from './utils/formatters';
import { applyThemeCssVariables } from './utils/theme';
import { cloudSyncService } from './utils/cloudSync';

export default function App() {
  // Application Data States
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [budgets, setBudgets] = useState<MonthlyBudget[]>([]);
  const [shoppingItems, setShoppingItems] = useState<ShoppingItem[]>([]);
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>(
    DEFAULT_SECURITY_SETTINGS
  );
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_USER_PROFILE);
  const [auditLogs, setAuditLogs] = useState<AuditHistoryLog[]>([]);
  const [goals, setGoals] = useState<FinancialGoal[]>([]);

  // Active View Tab State
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');

  // Modal Open States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [isCategoriesModalOpen, setIsCategoriesModalOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [deletingTransaction, setDeletingTransaction] = useState<Transaction | null>(null);
  const [isDeleteVerifyModalOpen, setIsDeleteVerifyModalOpen] = useState(false);

  // Security Lock State
  const [isLocked, setIsLocked] = useState(false);

  // Typing state for ShoppingListView Add New Item form (prevents navigation bar from rising with keyboard)
  const [isAddItemTyping, setIsAddItemTyping] = useState(false);

  // Initial Load from Storage
  useEffect(() => {
    const loadedTx = storage.getTransactions();
    const loadedCat = storage.getCategories();
    const loadedBudgets = storage.getBudgets();
    const loadedShopping = storage.getShoppingItems();
    const loadedSec = storage.getSecuritySettings();
    let loadedSet = storage.getAppSettings();
    const loadedAcc = storage.getAccounts();
    const loadedProfile = storage.getUserProfile();
    const loadedLogs = storage.getAuditLogs();
    const loadedGoals = storage.getGoals();

    const balancedAcc = storage.calculateAccountBalances(loadedAcc, loadedTx);

    setTransactions(loadedTx);
    setCategories(loadedCat);
    setBudgets(loadedBudgets);
    setGoals(loadedGoals);
    setShoppingItems(loadedShopping);
    setSecuritySettings(loadedSec);
    setAppSettings(loadedSet);
    setAccounts(balancedAcc);
    setUserProfile(loadedProfile);
    setAuditLogs(loadedLogs);
    applyThemeCssVariables(loadedSet);

    // First time open setup check: ensure initial open is with light theme and English
    if (!loadedProfile.isProfileCompleted && !loadedProfile.firstName) {
      setIsOnboardingOpen(true);
      if (loadedSet.themeMode !== 'light' || loadedSet.language !== 'en') {
        loadedSet = {
          ...loadedSet,
          themeMode: 'light',
          language: 'en',
          useBanglaDigits: false,
        };
        storage.saveAppSettings(loadedSet);
        setAppSettings(loadedSet);
        applyThemeCssVariables(loadedSet);
      }
    }

    // If PIN or Pattern enabled, lock on app launch
    const isSecurityActive =
      (loadedSec.isPinEnabled && !!loadedSec.pinHash) ||
      (loadedSec.isPatternEnabled && !!loadedSec.patternHash);
    if (isSecurityActive) {
      setIsLocked(true);
    }

    // Auto-sync from cloud on app launch if user has an active User ID
    if (loadedProfile.userId && loadedProfile.cloudPassword) {
      cloudSyncService.pullSync(loadedProfile).then((res) => {
        if (res.success && res.data) {
          const freshTx = storage.getTransactions();
          const freshCat = storage.getCategories();
          const freshBudgets = storage.getBudgets();
          const freshShopping = storage.getShoppingItems();
          const freshAcc = storage.getAccounts();
          const freshProfile = storage.getUserProfile();
          const freshGoals = storage.getGoals();
          const freshLogs = storage.getAuditLogs();
          const balancedFreshAcc = storage.calculateAccountBalances(freshAcc, freshTx);
          setTransactions(freshTx);
          setCategories(freshCat);
          setBudgets(freshBudgets);
          setShoppingItems(freshShopping);
          setAccounts(balancedFreshAcc);
          setUserProfile(freshProfile);
          setGoals(freshGoals);
          setAuditLogs(freshLogs);
        }
      }).catch((err) => {
        console.warn('Background pull sync on launch warning:', err);
      });
    }
  }, []);

  // Auto-lock on inactivity timer if configured
  useEffect(() => {
    const isSecurityActive =
      (securitySettings.isPinEnabled && !!securitySettings.pinHash) ||
      (securitySettings.isPatternEnabled && !!securitySettings.patternHash);

    if (!isSecurityActive || securitySettings.autoLockMinutes <= 0 || isLocked) {
      return;
    }

    let timer: NodeJS.Timeout;
    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        setIsLocked(true);
      }, securitySettings.autoLockMinutes * 60 * 1000);
    };

    const events = ['mousedown', 'mousemove', 'keydown', 'touchstart', 'scroll'];
    events.forEach((ev) => window.addEventListener(ev, resetTimer, { passive: true }));
    resetTimer();

    return () => {
      clearTimeout(timer);
      events.forEach((ev) => window.removeEventListener(ev, resetTimer));
    };
  }, [securitySettings, isLocked]);

  // Dynamically ensure theme CSS variables and font attributes are synced across the entire document
  useEffect(() => {
    applyThemeCssVariables(appSettings);
    if (typeof document !== 'undefined') {
      const root = document.documentElement;
      root.classList.toggle('dark', appSettings.themeMode !== 'light');
      if (appSettings.fontFamily) {
        root.setAttribute('data-font', appSettings.fontFamily);
      } else {
        root.removeAttribute('data-font');
      }
      if (appSettings.fontSize) {
        root.setAttribute('data-font-size', appSettings.fontSize);
      } else {
        root.removeAttribute('data-font-size');
      }
      if (appSettings.fontWeight) {
        root.setAttribute('data-font-weight', appSettings.fontWeight);
      } else {
        root.removeAttribute('data-font-weight');
      }
    }
  }, [
    appSettings.themeMode,
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage,
    appSettings.themeShade,
    appSettings.fontFamily,
    appSettings.fontSize,
    appSettings.fontWeight,
  ]);

  // Get current active month budget object
  const currentMonthKey = getCurrentMonthFormatted();
  const currentBudget =
    budgets.find((b) => b.month === currentMonthKey) ||
    budgets[0] || {
      month: currentMonthKey,
      totalLimit: 50000,
      alertThreshold: 80,
      categoryLimits: [],
    };

  // Compute expenses so far for budget check
  const currentMonthExpensesSoFar = transactions
    .filter((tx) => tx.type === 'expense' && tx.date && tx.date.startsWith(currentMonthKey))
    .reduce((sum, tx) => sum + tx.amount, 0);

  // Transaction Handlers
  const handleSaveTransaction = (txData: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTx: Transaction = {
      ...txData,
      id: `tx_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      createdAt: Date.now(),
    };

    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const updated = [newTx, ...baseTxs];
    setTransactions(updated);
    storage.saveTransactions(updated);

    // Recalculate account balances using latest accounts from storage
    const latestStoredAccounts = storage.getAccounts();
    const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
    const balanced = storage.calculateAccountBalances(baseAccounts, updated);
    setAccounts(balanced);
    storage.saveAccounts(balanced);
    triggerBackgroundSync();
  };

  const handleSaveEditedTransaction = (updatedTx: Transaction) => {
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const previous = baseTxs.find((t) => t.id === updatedTx.id);
    const updated = baseTxs.map((t) => (t.id === updatedTx.id ? updatedTx : t));
    setTransactions(updated);
    storage.saveTransactions(updated);

    // Recalculate account balances
    const latestStoredAccounts = storage.getAccounts();
    const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
    const balanced = storage.calculateAccountBalances(baseAccounts, updated);
    setAccounts(balanced);
    storage.saveAccounts(balanced);
    triggerBackgroundSync();

    // Add Audit Log
    storage.addAuditLog({
      action: 'EDIT',
      targetType: 'transaction',
      targetId: updatedTx.id,
      summaryBangla: `লেনদেন সংশোধন: ${previous?.amount || 0} ৳ ➔ ${updatedTx.amount} ৳ (${updatedTx.note || 'নোট নেই'})`,
      summaryEnglish: `Transaction modified: ${previous?.amount || 0} ➔ ${updatedTx.amount} (${updatedTx.note || 'No note'})`,
      previousSnapshot: previous,
      newSnapshot: updatedTx,
    });
    setAuditLogs(storage.getAuditLogs());
    setEditingTransaction(null);
  };

  const handleRequestDeleteTransaction = (tx: Transaction) => {
    setDeletingTransaction(tx);
    setIsDeleteVerifyModalOpen(true);
  };

  const handleConfirmDeleteTransaction = () => {
    if (!deletingTransaction) return;
    const txToDelete = deletingTransaction;
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const updated = baseTxs.filter((tx) => tx.id !== txToDelete.id);
    setTransactions(updated);
    storage.saveTransactions(updated);

    // Recalculate account balances
    const latestStoredAccounts = storage.getAccounts();
    const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
    const balanced = storage.calculateAccountBalances(baseAccounts, updated);
    setAccounts(balanced);
    storage.saveAccounts(balanced);

    // Add Audit Log
    storage.addAuditLog({
      action: 'DELETE',
      targetType: 'transaction',
      targetId: txToDelete.id,
      summaryBangla: `লেনদেন মুছে ফেলা হয়েছে: ${txToDelete.type === 'income' ? 'আয়' : txToDelete.type === 'expense' ? 'খরচ' : 'ট্রান্সফার'} ${txToDelete.amount} ৳ (${txToDelete.note || 'নোট নেই'})`,
      summaryEnglish: `Transaction deleted: ${txToDelete.type} ${txToDelete.amount} (${txToDelete.note || 'No note'})`,
      previousSnapshot: txToDelete,
    });
    setAuditLogs(storage.getAuditLogs());
    setDeletingTransaction(null);
    setIsDeleteVerifyModalOpen(false);
    triggerBackgroundSync();
  };

  const handleDeleteTransactionDirect = (id: string) => {
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const target = baseTxs.find((t) => t.id === id);
    if (target) {
      handleRequestDeleteTransaction(target);
    } else {
      const updated = baseTxs.filter((tx) => tx.id !== id);
      setTransactions(updated);
      storage.saveTransactions(updated);
      const latestStoredAccounts = storage.getAccounts();
      const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
      const balanced = storage.calculateAccountBalances(baseAccounts, updated);
      setAccounts(balanced);
      storage.saveAccounts(balanced);
    }
  };

  // Account Handlers
  const handleAddAccount = (newAccData: Omit<Account, 'id'>): Account => {
    const newAcc: Account = {
      ...newAccData,
      id: `acc_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      currentBalance: newAccData.openingBalance || 0,
    };
    const latestStoredAccounts = storage.getAccounts();
    const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
    const updatedList = [...baseAccounts, newAcc];
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const balanced = storage.calculateAccountBalances(updatedList, baseTxs);
    setAccounts(balanced);
    storage.saveAccounts(balanced);
    return newAcc;
  };

  const handleUpdateAccount = (updatedAcc: Account) => {
    const latestStoredAccounts = storage.getAccounts();
    const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
    const updatedList = baseAccounts.map((a) => (a.id === updatedAcc.id ? updatedAcc : a));
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const balanced = storage.calculateAccountBalances(updatedList, baseTxs);
    setAccounts(balanced);
    storage.saveAccounts(balanced);
  };

  const handleDeleteAccount = (id: string) => {
    const latestStoredAccounts = storage.getAccounts();
    const baseAccounts = latestStoredAccounts.length > 0 ? latestStoredAccounts : accounts;
    const updatedList = baseAccounts.filter((a) => a.id !== id);
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const balanced = storage.calculateAccountBalances(updatedList, baseTxs);
    setAccounts(balanced);
    storage.saveAccounts(balanced);
  };

  // Trigger automatic cloud sync when changes occur
  const triggerBackgroundSync = (overrideProfile?: UserProfile) => {
    const prof = overrideProfile || userProfile;
    if (prof.userId && prof.cloudPassword) {
      cloudSyncService.pushSync(prof).catch((err) => {
        console.warn('Auto cloud sync failed:', err);
      });
    }
  };

  const handleSaveOpeningBalances = (updatedAccounts: Account[]) => {
    const latestStoredTxs = storage.getTransactions();
    const baseTxs = latestStoredTxs.length > 0 ? latestStoredTxs : transactions;
    const balanced = storage.calculateAccountBalances(updatedAccounts, baseTxs);
    setAccounts(balanced);
    storage.saveAccounts(balanced);
    triggerBackgroundSync();
  };

  const handleSaveUserProfile = (profile: UserProfile) => {
    setUserProfile(profile);
    storage.saveUserProfile(profile);
    triggerBackgroundSync(profile);
  };

  const handleOnboardingComplete = (
    profile: UserProfile,
    openingAccounts?: Account[],
    selectedLanguage?: 'bn' | 'en',
    isSyncedLogin?: boolean
  ) => {
    setUserProfile(profile);
    storage.saveUserProfile(profile);

    if (isSyncedLogin) {
      // Reload all state from storage since cloudSyncService.login restored all cloud records
      const loadedTx = storage.getTransactions();
      const loadedCat = storage.getCategories();
      const loadedBudgets = storage.getBudgets();
      const loadedShopping = storage.getShoppingItems();
      const loadedSec = storage.getSecuritySettings();
      let loadedSet = storage.getAppSettings();
      const loadedAcc = storage.getAccounts();
      const loadedLogs = storage.getAuditLogs();
      const loadedGoals = storage.getGoals();

      const balancedAcc = storage.calculateAccountBalances(loadedAcc, loadedTx);
      setTransactions(loadedTx);
      setCategories(loadedCat);
      setBudgets(loadedBudgets);
      setGoals(loadedGoals);
      setShoppingItems(loadedShopping);
      setSecuritySettings(loadedSec);
      setAppSettings(loadedSet);
      setAccounts(balancedAcc);
      setAuditLogs(loadedLogs);
      applyThemeCssVariables(loadedSet);
    } else {
      if (openingAccounts && openingAccounts.length > 0) {
        const balanced = storage.calculateAccountBalances(openingAccounts, transactions);
        setAccounts(balanced);
        storage.saveAccounts(balanced);
      }
      triggerBackgroundSync(profile);
    }

    if (selectedLanguage) {
      setAppSettings((prevSettings) => {
        const updatedSettings: AppSettings = {
          ...prevSettings,
          language: selectedLanguage,
          useBanglaDigits: selectedLanguage === 'bn',
        };
        storage.saveAppSettings(updatedSettings);
        applyThemeCssVariables(updatedSettings);
        return updatedSettings;
      });
    }
    setIsOnboardingOpen(false);
  };

  const handleClearHistory = () => {
    storage.clearAuditLogs();
    setAuditLogs([]);
  };

  // Category Handlers
  const handleAddCategory = (newCatData: Omit<Category, 'id'>) => {
    const newCat: Category = {
      ...newCatData,
      id: `cat_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    };
    const updated = [...categories, newCat];
    setCategories(updated);
    storage.saveCategories(updated);
  };

  const handleDeleteCategory = (id: string) => {
    const updated = categories.filter((c) => c.id !== id);
    setCategories(updated);
    storage.saveCategories(updated);
  };

  const handleUpdateCategory = (updatedCat: Category) => {
    const updated = categories.map((c) => (c.id === updatedCat.id ? updatedCat : c));
    setCategories(updated);
    storage.saveCategories(updated);
  };

  // Budget Handler
  const handleSaveBudget = (updatedBudget: MonthlyBudget) => {
    const existingIndex = budgets.findIndex((b) => b.month === updatedBudget.month);
    let updatedList: MonthlyBudget[] = [];
    if (existingIndex >= 0) {
      updatedList = [...budgets];
      updatedList[existingIndex] = updatedBudget;
    } else {
      updatedList = [...budgets, updatedBudget];
    }
    setBudgets(updatedList);
    storage.saveBudgets(updatedList);
  };

  // Financial Goals Handler
  const handleSaveGoals = (updatedGoals: FinancialGoal[]) => {
    setGoals(updatedGoals);
    storage.saveGoals(updatedGoals);
  };

  // Shopping List Handlers
  const handleAddShoppingItem = (itemData: Omit<ShoppingItem, 'id'>) => {
    const newItem: ShoppingItem = {
      ...itemData,
      id: `shop_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    };
    const updated = [newItem, ...shoppingItems];
    setShoppingItems(updated);
    storage.saveShoppingItems(updated);
  };

  const handleToggleBoughtItem = (id: string) => {
    const updated = shoppingItems.map((item) =>
      item.id === id ? { ...item, isBought: !item.isBought } : item
    );
    setShoppingItems(updated);
    storage.saveShoppingItems(updated);
  };

  const handleDeleteShoppingItem = (id: string) => {
    const updated = shoppingItems.filter((i) => i.id !== id);
    setShoppingItems(updated);
    storage.saveShoppingItems(updated);
  };

  // Convert bought shopping item to transaction expense
  const handleConvertShoppingToTransaction = (item: ShoppingItem) => {
    // Find or fallback to grocery category
    const groceryCat = categories.find((c) => c.id === 'exp_grocery') || categories[0];

    const amount = item.actualPrice || item.estimatedPrice || 0;
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      type: 'expense',
      amount,
      categoryId: groceryCat.id,
      paymentMethod: 'cash',
      date: new Date().toISOString().split('T')[0],
      note: `বাজারের খরচ: ${item.title} (${item.quantity})`,
      createdAt: Date.now(),
    };

    const updatedTxs = [newTx, ...transactions];
    setTransactions(updatedTxs);
    storage.saveTransactions(updatedTxs);

    // Update shopping item to reflect converted state
    const updatedShopping = shoppingItems.map((i) =>
      i.id === item.id ? { ...i, convertedToTransactionId: newTx.id } : i
    );
    setShoppingItems(updatedShopping);
    storage.saveShoppingItems(updatedShopping);

    alert(`" ${item.title}" সাফল্যজনকভাবে ৳ ${amount} টাকার খরচে যোগ করা হয়েছে!`);
  };

  // Security Handlers
  const handleUpdateSecurity = (newSec: SecuritySettings) => {
    setSecuritySettings(newSec);
    storage.saveSecuritySettings(newSec);
  };

  const handleUpdateSettings = (newSet: AppSettings) => {
    setAppSettings(newSet);
    storage.saveAppSettings(newSet);
    applyThemeCssVariables(newSet);
  };

  // Reset All Data
  const handleResetAllData = () => {
    localStorage.clear();
    const initTx = storage.getTransactions();
    const initCat = storage.getCategories();
    const initBud = storage.getBudgets();
    const initShop = storage.getShoppingItems();
    const initAcc = storage.getAccounts();
    const initProfile = storage.getUserProfile();
    setTransactions(initTx);
    setCategories(initCat);
    setBudgets(initBud);
    setShoppingItems(initShop);
    setAccounts(initAcc);
    setUserProfile(initProfile);
    setAuditLogs([]);
    alert(
      appSettings.language === 'en'
        ? 'All data has been deleted and reset successfully!'
        : 'সমস্ত ডেটা রিমুভ করে রিসেট করা হয়েছে!'
    );
  };

  const handleReloadImportedData = () => {
    const loadedTx = storage.getTransactions();
    const loadedAcc = storage.getAccounts();
    setTransactions(loadedTx);
    setCategories(storage.getCategories());
    setBudgets(storage.getBudgets());
    setShoppingItems(storage.getShoppingItems());
    setAppSettings(storage.getAppSettings());
    setUserProfile(storage.getUserProfile());
    setAuditLogs(storage.getAuditLogs());
    setAccounts(storage.calculateAccountBalances(loadedAcc, loadedTx));
  };

  return (
    <>
      <MobileContainer
        activeTab={activeTab}
        onTabChange={(tab) => {
          setIsAddItemTyping(false);
          setActiveTab(tab);
        }}
        onOpenAddModal={() => setIsAddModalOpen(true)}
        onOpenManageCategories={() => setIsCategoriesModalOpen(true)}
        onLockApp={() => setIsLocked(true)}
        isPinEnabled={securitySettings.isPinEnabled}
        appSettings={appSettings}
        hideBottomNav={activeTab === 'shopping' && isAddItemTyping}
      >
        {activeTab === 'dashboard' && (
          <DashboardView
            transactions={transactions}
            categories={categories}
            budget={currentBudget}
            accounts={accounts}
            onOpenAddModal={() => setIsAddModalOpen(true)}
            onOpenBudgetModal={() => setIsBudgetModalOpen(true)}
            onDeleteTransaction={handleDeleteTransactionDirect}
            onEditTransaction={(tx) => setEditingTransaction(tx)}
            onRequestDeleteTransaction={handleRequestDeleteTransaction}
            useBanglaDigits={appSettings.useBanglaDigits}
            appSettings={appSettings}
            onNavigateToReports={() => setActiveTab('reports')}
            onNavigateToLoan={() => setActiveTab('loan')}
          />
        )}

        {activeTab === 'loan' && (
          <LoanView
            accounts={accounts}
            transactions={transactions}
            categories={categories}
            appSettings={appSettings}
            useBanglaDigits={appSettings.useBanglaDigits}
            onBack={() => setActiveTab('dashboard')}
            onAddAccount={handleAddAccount}
            onUpdateAccount={handleUpdateAccount}
            onDeleteAccount={handleDeleteAccount}
            onAddTransaction={handleSaveTransaction}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView
            transactions={transactions}
            categories={categories}
            accounts={accounts}
            useBanglaDigits={appSettings.useBanglaDigits}
            appSettings={appSettings}
            onBack={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'budget' && (
          <BudgetView
            transactions={transactions}
            categories={categories}
            budgets={budgets}
            currentBudget={currentBudget}
            onSaveBudget={handleSaveBudget}
            onOpenBudgetModal={() => setIsBudgetModalOpen(true)}
            useBanglaDigits={appSettings.useBanglaDigits}
            appSettings={appSettings}
            goals={goals}
            onSaveGoals={handleSaveGoals}
            onNavigateToReports={() => setActiveTab('reports')}
          />
        )}

        {activeTab === 'shopping' && (
          <ShoppingListView
            items={shoppingItems}
            categories={categories}
            onAddItem={handleAddShoppingItem}
            onToggleBought={handleToggleBoughtItem}
            onDeleteItem={handleDeleteShoppingItem}
            onConvertToTransaction={handleConvertShoppingToTransaction}
            useBanglaDigits={appSettings.useBanglaDigits}
            appSettings={appSettings}
            onUpdateSettings={handleUpdateSettings}
            onAddItemFormTyping={setIsAddItemTyping}
          />
        )}

        {activeTab === 'security' && (
          <SecurityAndBackupView
            securitySettings={securitySettings}
            appSettings={appSettings}
            onUpdateSecurity={handleUpdateSecurity}
            onUpdateSettings={handleUpdateSettings}
            onDataImported={handleReloadImportedData}
            onLockNow={() => setIsLocked(true)}
            onBackToSettings={() => setActiveTab('settings')}
            onResetAllData={handleResetAllData}
          />
        )}

        {activeTab === 'theme' && (
          <ThemeView
            appSettings={appSettings}
            onUpdateSettings={handleUpdateSettings}
            onBackToSettings={() => setActiveTab('settings')}
          />
        )}

        {activeTab === 'language' && (
          <LanguageView
            appSettings={appSettings}
            onUpdateSettings={handleUpdateSettings}
            onBackToSettings={() => setActiveTab('settings')}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            appSettings={appSettings}
            onUpdateSettings={handleUpdateSettings}
            onResetAllData={handleResetAllData}
            onOpenManageCategories={() => setIsCategoriesModalOpen(true)}
            onNavigateToSecurity={() => setActiveTab('security')}
            onNavigateToTheme={() => setActiveTab('theme')}
            onNavigateToLanguage={() => setActiveTab('language')}
            transactions={transactions}
            categories={categories}
            securitySettings={securitySettings}
            onUpdateSecurity={handleUpdateSecurity}
            onLockNow={() => setIsLocked(true)}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
            onDataImported={handleReloadImportedData}
            userProfile={userProfile}
            onSaveUserProfile={handleSaveUserProfile}
            accounts={accounts}
            onSaveOpeningBalances={handleSaveOpeningBalances}
            auditLogs={auditLogs}
            onClearHistory={handleClearHistory}
          />
        )}
      </MobileContainer>

      {/* Offline Status Indicator */}
      <OfflineIndicator isLight={appSettings.themeMode === 'light'} />

      {/* Modals */}
      <AddTransactionModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        categories={categories}
        accounts={accounts}
        onSave={handleSaveTransaction}
        onAddAccount={handleAddAccount}
        currentExpenseSoFar={currentMonthExpensesSoFar}
        totalBudgetLimit={currentBudget.totalLimit}
        useBanglaDigits={appSettings.useBanglaDigits}
        appSettings={appSettings}
      />

      {editingTransaction && (
        <EditTransactionModal
          isOpen={!!editingTransaction}
          onClose={() => setEditingTransaction(null)}
          transaction={editingTransaction}
          categories={categories}
          accounts={accounts}
          userProfile={userProfile}
          onSave={handleSaveEditedTransaction}
          onAddAccount={handleAddAccount}
          useBanglaDigits={appSettings.useBanglaDigits}
          appSettings={appSettings}
        />
      )}

      <PasswordVerifyModal
        isOpen={isDeleteVerifyModalOpen}
        onClose={() => {
          setIsDeleteVerifyModalOpen(false);
          setDeletingTransaction(null);
        }}
        userProfile={userProfile}
        title={
          appSettings.language === 'en'
            ? userProfile.profilePassword
              ? 'Verify PIN to Delete'
              : 'Confirm Delete Transaction'
            : userProfile.profilePassword
            ? 'মুছে ফেলার জন্য পিন নিশ্চিত করুন'
            : 'লেনদেন মুছে ফেলতে নিশ্চিত করুন'
        }
        description={
          appSettings.language === 'en'
            ? userProfile.profilePassword
              ? 'Enter your profile security PIN to permanently delete this transaction.'
              : 'Are you sure you want to permanently delete this transaction?'
            : userProfile.profilePassword
            ? 'এই লেনদেনটি স্থায়ীভাবে মুছে ফেলতে আপনার নিরাপত্তা পিন দিন।'
            : 'আপনি কি নিশ্চিতভাবে এই লেনদেনটি স্থায়ীভাবে মুছে ফেলতে চান?'
        }
        onVerified={handleConfirmDeleteTransaction}
        onSaveNewPassword={(newPin) => {
          const updated = { ...userProfile, profilePassword: newPin };
          handleSaveUserProfile(updated);
        }}
        appSettings={appSettings}
      />

      <BudgetModal
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
        currentBudget={currentBudget}
        expenseCategories={categories.filter((c) => c.type === 'expense')}
        onSaveBudget={handleSaveBudget}
        useBanglaDigits={appSettings.useBanglaDigits}
        appSettings={appSettings}
      />

      <ManageCategoriesModal
        isOpen={isCategoriesModalOpen}
        onClose={() => setIsCategoriesModalOpen(false)}
        categories={categories}
        onAddCategory={handleAddCategory}
        onUpdateCategory={handleUpdateCategory}
        onDeleteCategory={handleDeleteCategory}
        accounts={accounts}
        onAddAccount={handleAddAccount}
        onUpdateAccount={handleUpdateAccount}
        onDeleteAccount={handleDeleteAccount}
        appSettings={appSettings}
      />

      <WelcomeOnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onComplete={handleOnboardingComplete}
        appSettings={appSettings}
        onUpdateSettings={handleUpdateSettings}
      />

      <AppLockModal
        isLocked={isLocked}
        securitySettings={securitySettings}
        onUnlock={() => setIsLocked(false)}
        appSettings={appSettings}
      />
    </>
  );
}
