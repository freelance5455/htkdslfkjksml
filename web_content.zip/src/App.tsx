import React, { useState, useEffect } from 'react';
import { Tab, PrivacyConfig, Bookmark, DownloadFile, PageContent } from './types/browser';
import { BUILTIN_PAGES, DEFAULT_BOOKMARKS, MOCK_DOWNLOADS } from './data/mockWeb';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { AndroidGestureBar } from './components/AndroidGestureBar';
import { AddressBar } from './components/AddressBar';
import { ShieldSheet } from './components/ShieldSheet';
import { FireAnimation } from './components/FireAnimation';
import { TabSwitcher } from './components/TabSwitcher';
import { MenuSheet } from './components/MenuSheet';
import { SettingsSheet } from './components/SettingsSheet';
import { BookmarksSheet } from './components/BookmarksSheet';
import { DownloadsSheet } from './components/DownloadsSheet';
import { TorCircuitModal } from './components/TorCircuitModal';
import { WebCanvas } from './components/WebCanvas';
import { AndroidFrame } from './components/AndroidFrame';

const createInitialTab = (): Tab => ({
  id: 'tab-init-1',
  title: 'Aegis Privacy',
  url: 'aegis://home',
  isIncognito: true,
  themeColor: '#090d16',
  trackersBlocked: 0,
  cookiesBlocked: 0,
  fingerprintsBlocked: 0,
  isSecure: true,
  isLoading: false,
  history: ['aegis://home'],
  historyIndex: 0,
  readerMode: false,
  desktopMode: false,
  scriptsEnabled: true,
  shieldsEnabled: true,
});

export default function App() {
  const [tabs, setTabs] = useState<Tab[]>([createInitialTab()]);
  const [activeTabId, setActiveTabId] = useState<string>('tab-init-1');
  const [isDeviceMode, setIsDeviceMode] = useState<boolean>(true);

  // Sheets & Dialogs
  const [isShieldOpen, setIsShieldOpen] = useState(false);
  const [isFireOpen, setIsFireOpen] = useState(false);
  const [isTabsOpen, setIsTabsOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);
  const [isDownloadsOpen, setIsDownloadsOpen] = useState(false);
  const [isTorCircuitOpen, setIsTorCircuitOpen] = useState(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Bookmarks & Downloads
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(DEFAULT_BOOKMARKS);
  const [downloads, setDownloads] = useState<DownloadFile[]>(MOCK_DOWNLOADS);

  // Global Config
  const [config, setConfig] = useState<PrivacyConfig>({
    shieldsActive: true,
    blockTrackers: true,
    blockFingerprinting: true,
    blockThirdPartyCookies: true,
    blockScripts: false,
    enforceHttps: true,
    blockPopups: true,
    gpcSignal: true,
    dohProvider: 'Cloudflare (1.1.1.1)',
    torRouting: false,
    clearOnExit: true,
    biometricLock: false,
    searchEngine: 'DuckDuckGo',
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2800);
  };

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  // Clean URL utility (strips tracking telemetry query params)
  const sanitizeUrl = (rawUrl: string): string => {
    try {
      if (!rawUrl.startsWith('http://') && !rawUrl.startsWith('https://')) {
        // Check if query or domain
        if (rawUrl.includes('.') && !rawUrl.includes(' ')) {
          rawUrl = `https://${rawUrl}`;
        } else {
          return `https://duckduckgo.com/?q=${encodeURIComponent(rawUrl)}`;
        }
      }
      const parsed = new URL(rawUrl);
      const trackingParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid', 'msclkid', 'mc_cid', 'yclid'];
      trackingParams.forEach((param) => parsed.searchParams.delete(param));
      return parsed.toString();
    } catch {
      return rawUrl;
    }
  };

  // Navigate Handler
  const handleNavigate = (inputUrl: string) => {
    const cleanUrl = sanitizeUrl(inputUrl);

    // Identify page content
    let matchedContent: PageContent | undefined = undefined;
    let pageTitle = 'Web Page';
    let trackersCount = 0;
    let fingerprintsCount = 0;
    let cookiesCount = 0;

    // Check predefined pages
    for (const [key, val] of Object.entries(BUILTIN_PAGES)) {
      if (cleanUrl.includes(key)) {
        matchedContent = val;
        pageTitle = val.title;
        break;
      }
    }

    if (!matchedContent) {
      if (cleanUrl === 'aegis://home' || cleanUrl === 'about:blank') {
        pageTitle = 'Aegis Privacy';
      } else {
        // Generic page with tracker simulation
        try {
          const u = new URL(cleanUrl);
          pageTitle = u.hostname.replace(/^www\./, '');
        } catch {
          pageTitle = cleanUrl;
        }

        trackersCount = 5;
        fingerprintsCount = 2;
        cookiesCount = 3;

        matchedContent = {
          title: pageTitle,
          url: cleanUrl,
          summary: 'Web page isolated in Aegis ephemeral sandbox. Trackers stripped.',
          sections: [
            {
              heading: 'Aegis Sandbox Protection',
              paragraphs: [
                `This domain (${cleanUrl}) was requested with strict HTTPS enforcement and encrypted DNS (${config.dohProvider}).`,
                'Third-party analytics beacons, cross-site identity cookies, and canvas fingerprinting probes were stripped prior to execution.',
              ],
            },
          ],
        };
      }
    } else {
      trackersCount = 0;
      fingerprintsCount = 0;
      cookiesCount = 0;
    }

    // Update active tab state with smooth simulated loading
    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === activeTabId) {
          const newHistory = [...t.history.slice(0, t.historyIndex + 1), cleanUrl];
          return {
            ...t,
            url: cleanUrl,
            title: pageTitle,
            isLoading: true,
            content: matchedContent,
            trackersBlocked: trackersCount,
            fingerprintsBlocked: fingerprintsCount,
            cookiesBlocked: cookiesCount,
            history: newHistory,
            historyIndex: newHistory.length - 1,
          };
        }
        return t;
      })
    );

    // Turn off loading indicator after brief delay
    setTimeout(() => {
      setTabs((prev) =>
        prev.map((t) => (t.id === activeTabId ? { ...t, isLoading: false } : t))
      );
    }, 450);
  };

  // Tab management
  const handleNewTab = () => {
    const newId = `tab-${Date.now()}`;
    const newTab: Tab = {
      id: newId,
      title: 'Aegis Privacy',
      url: 'aegis://home',
      isIncognito: true,
      themeColor: '#090d16',
      trackersBlocked: 0,
      cookiesBlocked: 0,
      fingerprintsBlocked: 0,
      isSecure: true,
      isLoading: false,
      history: ['aegis://home'],
      historyIndex: 0,
      readerMode: false,
      desktopMode: false,
      scriptsEnabled: true,
      shieldsEnabled: true,
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newId);
    showToast('New private tab opened');
  };

  const handleCloseTab = (idToClose: string) => {
    if (tabs.length === 1) {
      // If last tab, reset to home
      handleExecuteBurn();
      return;
    }
    const remaining = tabs.filter((t) => t.id !== idToClose);
    setTabs(remaining);
    if (activeTabId === idToClose) {
      setActiveTabId(remaining[remaining.length - 1].id);
    }
    showToast('Tab closed & isolated storage purged');
  };

  const handleCloseAllTabs = () => {
    setIsTabsOpen(false);
    setIsFireOpen(true);
  };

  // Back and Home Navigation
  const handleBack = () => {
    if (activeTab.historyIndex > 0) {
      const prevUrl = activeTab.history[activeTab.historyIndex - 1];
      setTabs((prev) =>
        prev.map((t) => {
          if (t.id === activeTabId) {
            return {
              ...t,
              url: prevUrl,
              historyIndex: t.historyIndex - 1,
            };
          }
          return t;
        })
      );
    } else {
      handleNavigate('aegis://home');
    }
  };

  const handleHome = () => {
    handleNavigate('aegis://home');
  };

  // The Fire Shredder Action
  const handleExecuteBurn = () => {
    const initial = createInitialTab();
    setTabs([initial]);
    setActiveTabId(initial.id);
    showToast('All tabs, cookies & browsing memory incinerated 🔥');
  };

  // Clean Share
  const handleShareCleanLink = () => {
    const clean = sanitizeUrl(activeTab.url);
    if (navigator.clipboard) {
      navigator.clipboard.writeText(clean).catch(() => {});
    }
    showToast('Clean link copied (tracking tags stripped) 🛡️');
  };

  // Add to Bookmarks
  const handleAddBookmark = () => {
    if (bookmarks.some((b) => b.url === activeTab.url)) {
      showToast('Page already bookmarked');
      return;
    }
    const newBm: Bookmark = {
      id: `bm-${Date.now()}`,
      title: activeTab.title || 'Saved Page',
      url: activeTab.url,
      icon: 'Bookmark',
      category: 'Saved',
    };
    setBookmarks((prev) => [newBm, ...prev]);
    showToast('Bookmark encrypted & saved locally');
  };

  return (
    <AndroidFrame
      isDeviceMode={isDeviceMode}
      onToggleDeviceMode={() => setIsDeviceMode(!isDeviceMode)}
      onQuickBurn={() => setIsFireOpen(true)}
      toastMessage={toastMessage}
    >
      {/* Android 14/15 Top Status Bar */}
      <AndroidStatusBar
        isShieldActive={activeTab.shieldsEnabled}
        isTorActive={config.torRouting}
        isIncognito={activeTab.isIncognito}
      />

      {/* Main Web Canvas Viewport */}
      <WebCanvas
        currentTab={activeTab}
        bookmarks={bookmarks}
        onNavigate={handleNavigate}
        onOpenShield={() => setIsShieldOpen(true)}
        onTriggerFire={() => setIsFireOpen(true)}
      />

      {/* Android Ergonomic Bottom Address Bar */}
      <AddressBar
        currentTab={activeTab}
        tabCount={tabs.length}
        onNavigate={handleNavigate}
        onRefresh={() => handleNavigate(activeTab.url)}
        onOpenShield={() => setIsShieldOpen(true)}
        onOpenTabs={() => setIsTabsOpen(true)}
        onOpenMenu={() => setIsMenuOpen(true)}
        onTriggerFire={() => setIsFireOpen(true)}
      />

      {/* Android System Navigation Gesture Bar */}
      <AndroidGestureBar
        onBack={handleBack}
        onHome={handleHome}
        onOverview={() => setIsTabsOpen(true)}
        canGoBack={activeTab.historyIndex > 0 || activeTab.url !== 'aegis://home'}
      />

      {/* Sheets and Overlays */}
      <ShieldSheet
        isOpen={isShieldOpen}
        onClose={() => setIsShieldOpen(false)}
        currentTab={activeTab}
        onToggleShields={(tabId, enabled) => {
          setTabs((prev) =>
            prev.map((t) => (t.id === tabId ? { ...t, shieldsEnabled: enabled } : t))
          );
          showToast(enabled ? 'Shields enabled for site' : 'Shields paused for compatibility');
        }}
        onToggleScripts={(tabId, enabled) => {
          setTabs((prev) =>
            prev.map((t) => (t.id === tabId ? { ...t, scriptsEnabled: enabled } : t))
          );
          showToast(enabled ? 'JavaScript enabled' : 'JavaScript blocked');
        }}
      />

      <FireAnimation
        isOpen={isFireOpen}
        onClose={() => setIsFireOpen(false)}
        onConfirmBurn={handleExecuteBurn}
        tabCount={tabs.length}
      />

      <TabSwitcher
        isOpen={isTabsOpen}
        onClose={() => setIsTabsOpen(false)}
        tabs={tabs}
        activeTabId={activeTabId}
        onSelectTab={(id) => setActiveTabId(id)}
        onCloseTab={handleCloseTab}
        onNewTab={() => {
          handleNewTab();
          setIsTabsOpen(false);
        }}
        onCloseAll={handleCloseAllTabs}
      />

      <MenuSheet
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        currentTab={activeTab}
        onNewTab={handleNewTab}
        onRefresh={() => handleNavigate(activeTab.url)}
        onToggleReader={() => {
          setTabs((prev) =>
            prev.map((t) =>
              t.id === activeTabId ? { ...t, readerMode: !t.readerMode } : t
            )
          );
          showToast(!activeTab.readerMode ? 'Reader mode enabled' : 'Standard mode restored');
        }}
        onToggleDesktop={() => {
          setTabs((prev) =>
            prev.map((t) =>
              t.id === activeTabId ? { ...t, desktopMode: !t.desktopMode } : t
            )
          );
          showToast(!activeTab.desktopMode ? 'Requesting Desktop site' : 'Mobile site active');
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenBookmarks={() => setIsBookmarksOpen(true)}
        onOpenDownloads={() => setIsDownloadsOpen(true)}
        onOpenTorCircuit={() => setIsTorCircuitOpen(true)}
        onShareLink={handleShareCleanLink}
        onAddBookmark={handleAddBookmark}
        onFindInPage={() => showToast('Find in page: Search triggered in current DOM')}
      />

      <SettingsSheet
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onUpdateConfig={(newConfig) => {
          setConfig((prev) => ({ ...prev, ...newConfig }));
          showToast('Privacy preferences updated');
        }}
        onClearAllData={handleExecuteBurn}
      />

      <BookmarksSheet
        isOpen={isBookmarksOpen}
        onClose={() => setIsBookmarksOpen(false)}
        bookmarks={bookmarks}
        onSelectBookmark={handleNavigate}
        onDeleteBookmark={(id) => {
          setBookmarks((prev) => prev.filter((b) => b.id !== id));
          showToast('Bookmark deleted');
        }}
      />

      <DownloadsSheet
        isOpen={isDownloadsOpen}
        onClose={() => setIsDownloadsOpen(false)}
        downloads={downloads}
        onDeleteDownload={(id) => {
          setDownloads((prev) => prev.filter((d) => d.id !== id));
          showToast('File removed from sandbox');
        }}
      />

      <TorCircuitModal
        isOpen={isTorCircuitOpen}
        onClose={() => setIsTorCircuitOpen(false)}
        destinationUrl={activeTab.url}
      />
    </AndroidFrame>
  );
}
