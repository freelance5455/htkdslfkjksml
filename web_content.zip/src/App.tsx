import { useCallback, useMemo, useState } from "react";
import {
  CARS,
  DEFAULT_CAR_ID,
  allRecords,
  carById,
  loadStored,
  saveStored,
  sortRecords,
  STORAGE,
  type DriverRecord,
  type RunResult,
} from "./data/game";
import { Circuit } from "./components/Circuit";
import { FieldNotes } from "./components/FieldNotes";
import { Footer } from "./components/Footer";
import { GameStage, type SubmitInfo } from "./components/GameStage";
import { Garage } from "./components/Garage";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Story } from "./components/Story";
import { Marquee, Reveal, SectionIntro, Pill } from "./components/ui";

function readCar(): string {
  const stored = loadStored<string>(STORAGE.car, DEFAULT_CAR_ID);
  return CARS.some((car) => car.id === stored) ? stored : DEFAULT_CAR_ID;
}

function readRecords(): DriverRecord[] {
  const stored = loadStored<DriverRecord[]>(STORAGE.records, []);
  if (!Array.isArray(stored)) return [];
  return sortRecords(
    stored.filter(
      (record) =>
        record &&
        typeof record.distance === "number" &&
        typeof record.score === "number" &&
        typeof record.carName === "string" &&
        Boolean(record.local),
    ),
  );
}

function readSound(): boolean {
  const stored = loadStored<boolean>(STORAGE.sound, true);
  return typeof stored === "boolean" ? stored : true;
}

export default function App() {
  const [carId, setCarId] = useState<string>(readCar);
  const [localRecords, setLocalRecords] = useState<DriverRecord[]>(readRecords);
  const [soundOn, setSoundOn] = useState<boolean>(readSound);

  const car = carById(carId);
  const records = useMemo(() => allRecords(localRecords), [localRecords]);
  const personalBest = useMemo(
    () => localRecords.reduce((best, record) => Math.max(best, record.distance), 0),
    [localRecords],
  );

  const selectCar = useCallback((id: string) => {
    setCarId(id);
    saveStored(STORAGE.car, id);
  }, []);

  const toggleSound = useCallback(() => {
    setSoundOn((previous) => {
      saveStored(STORAGE.sound, !previous);
      return !previous;
    });
  }, []);

  const launchGame = useCallback(() => {
    const target = document.getElementById("play");
    target?.scrollIntoView({ behavior: "smooth", block: "start" });
    window.setTimeout(() => {
      window.dispatchEvent(new Event("vanta:start"));
    }, 620);
  }, []);

  const submitRun = useCallback(
    (result: RunResult): SubmitInfo => {
      const record: DriverRecord = {
        id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        driver: "You",
        carId: result.carId,
        carName: result.carName,
        distance: result.distance,
        score: result.score,
        topSpeed: result.topSpeed,
        date: new Date().toISOString(),
        local: true,
      };
      const next = sortRecords([...localRecords, record]);
      const ranked = allRecords(next);
      const foundRank = ranked.findIndex((entry) => entry.id === record.id) + 1;
      const info: SubmitInfo = {
        rank: foundRank > 0 ? foundRank : ranked.length,
        total: ranked.length,
      };
      setLocalRecords(next);
      saveStored(STORAGE.records, next);
      saveStored(STORAGE.best, Math.max(personalBest, record.distance));
      return info;
    },
    [localRecords, personalBest],
  );

  return (
    <div className="relative min-h-screen overflow-x-clip bg-ink-950">
      <Header onStart={launchGame} />

      <main>
        <Hero personalBest={personalBest} onStart={launchGame} />

        <Marquee
          accent
          items={[
            "Top speed 200 km/h",
            "Four lanes",
            "Endless highway",
            "Chain near misses",
            "Three strikes",
            "Own the night",
          ]}
        />

        <section id="play" className="relative scroll-mt-20 overflow-hidden py-16 sm:py-24">
          <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(70%_50%_at_50%_20%,rgba(201,250,60,0.05),transparent_70%)]" />
          <div className="mx-auto max-w-[1360px] px-4 sm:px-6 lg:px-10">
            <SectionIntro
              label="The game // live"
              title={
                <>
                  Take the wheel.
                  <br />
                  <span className="font-serif font-normal italic text-volt">Lose the city.</span>
                </>
              }
              copy={
                <>
                  A four-lane endless runner at up to 200 km/h. Traffic, charge pickups and a wall of ghost records stand between you and the coast. Every 750 metres the sector climbs — and the gaps get meaner.
                </>
              }
              aside={
                <div className="flex flex-wrap items-center gap-2.5">
                  <Pill tone="ghost">
                    <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> Runs in your browser
                  </Pill>
                  <span className="inline-flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">
                    <span className="h-1 w-1 rounded-full bg-moss-500/60" /> No download
                  </span>
                  <span className="inline-flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">
                    <span className="h-1 w-1 rounded-full bg-moss-500/60" /> Keyboard or touch
                  </span>
                  <span className="inline-flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">
                    <span className="h-1 w-1 rounded-full bg-moss-500/60" /> Best with sound
                  </span>
                </div>
              }
            />

            <Reveal className="mt-8">
              <GameStage
                car={car}
                records={records}
                personalBest={personalBest}
                soundOn={soundOn}
                onToggleSound={toggleSound}
                onSubmitRun={submitRun}
                onOpenGarage={() => document.getElementById("garage")?.scrollIntoView({ behavior: "smooth" })}
                onOpenCircuit={() => document.getElementById("circuit")?.scrollIntoView({ behavior: "smooth" })}
              />
            </Reveal>

            <Reveal>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {[
                  ["01", "Chase distance", "Every metre is score. The wall only cares how far you got."],
                  ["02", "Stay sharp", "Three shields. Hits scrub speed and cost a sector's grace."],
                  ["03", "Spend the boost", "Nitro burns brighter than fear — save it for a clear straight."],
                ].map(([number, title, copy]) => (
                  <div key={number} className="flex items-start gap-3 rounded-xl border border-white/8 bg-white/2 px-3.5 py-3">
                    <span className="font-mono text-[9px] font-semibold text-volt">{number}</span>
                    <div>
                      <p className="text-[12px] font-medium text-bone">{title}</p>
                      <p className="mt-0.5 text-[11px] leading-relaxed text-moss-500">{copy}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        <Story />
        <Garage equippedId={carId} onEquip={selectCar} onDrive={(id) => { selectCar(id); launchGame(); }} />
        <Circuit records={records} personalBest={personalBest} onStart={launchGame} />
        <FieldNotes onStart={launchGame} />

        <Marquee
          slow
          items={[
            "Night Spec · GT-R",
            "Phantom RS",
            "Ember GT",
            "Highway division",
            "Colombo · 2026",
            "The night shift",
          ]}
        />
      </main>

      <Footer personalBest={personalBest} onStart={launchGame} />
    </div>
  );
}
