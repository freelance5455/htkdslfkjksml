/**
 * JUHNKRIX MUSIKA - Spiritual Inspirational Gospel Music Application
 * Prophet JUHNKRIX SYNVAGORD
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TabType, Track } from './types';
import { FEATURED_TRACKS } from './data/spiritualData';
import { Navbar } from './components/Navbar';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { FullPlayerModal } from './components/FullPlayerModal';
import { MusicPraiseView } from './components/MusicPraiseView';
import { LiveSermonsView } from './components/LiveSermonsView';
import { DevotionalsView } from './components/DevotionalsView';
import { SoakingMeditationRoom } from './components/SoakingMeditationRoom';
import { PrayerJournalView } from './components/PrayerJournalView';
import { LiveBroadcastView } from './components/LiveBroadcastView';
import { OwnerUpdateView } from './components/OwnerUpdateView';
import { SupportOfferingsView } from './components/SupportOfferingsView';
import { ProphetBioModal } from './components/ProphetBioModal';
import { PrayerRequestModal } from './components/PrayerRequestModal';
import { UserProfileModal } from './components/UserProfileModal';
import { UserProfileView } from './components/UserProfileView';
import { CustomPlaylistModal } from './components/CustomPlaylistModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { DownloadAppModal } from './components/DownloadAppModal';
import { AppUpdateNotifier } from './components/AppUpdateNotifier';
import { WebDomainPublishModal } from './components/WebDomainPublishModal';
import { GlobalUploadModal } from './components/GlobalUploadModal';
import { UploadPageView } from './components/UploadPageView';
import { AudioPageView } from './components/AudioPageView';
import { VideoPageView } from './components/VideoPageView';
import { ImagePageView } from './components/ImagePageView';
import { TextMessagesView } from './components/TextMessagesView';
import { SignupModal } from './components/SignupModal';
import { DivineBackgroundParticles } from './components/DivineBackgroundParticles';
import { QuickPrayerModal } from './components/QuickPrayerModal';
import { EtherealVisualizer } from './components/EtherealVisualizer';
import { NetworkStatusToast } from './components/NetworkStatusToast';
import { FinancialBalanceToast } from './components/FinancialBalanceToast';
import { WalletView } from './components/WalletView';
import { JMCryptoPageView } from './components/JMCryptoPageView';
import { JMWalletPageView } from './components/JMWalletPageView';
import { JMGlobalTradePageView } from './components/JMGlobalTradePageView';
import { JMChatView } from './components/JMChatView';
import { decentralizedSyncService } from './lib/decentralizedSyncService';
import { JMCryptoStampNotification } from './components/JMCryptoStampNotification';
import { JMCEarningToast } from './components/JMCEarningToast';
import { OwnerAuthGate } from './components/OwnerAuthGate';
import { checkIsOwnerSecretUnlocked } from './lib/ownerSecurity';
import { audioEngine } from './lib/audioEngine';
import { offlineCache } from './lib/offlineCache';
import { getThemeForTab } from './lib/spiritualThemeEngine';
import { PropheticWordToast } from './components/PropheticWordToast';
import { propheticNotificationEngine } from './lib/propheticNotificationEngine';
import { nativeSocketEngine, DEFAULT_MAGIC_IP_CONFIG } from './lib/magicIpEngine';
import { ProfessionalFooter } from './components/ProfessionalFooter';
import { LogoOwnerAuthModal } from './components/LogoOwnerAuthModal';
import { QuickMiningStatsOverlay } from './components/QuickMiningStatsOverlay';
import { prophetSecurityEngine } from './lib/prophetSecurityEngine';
import { heartbeatSecurityManager } from './lib/heartbeatSecurityManager';
import { BackupProfilePageView } from './components/BackupProfilePageView';
import { UserRegistrationOrLoginModal } from './components/UserRegistrationOrLoginModal';
import { deviceRegistryEngine } from './lib/deviceRegistryEngine';
import { Mic, Sparkles, Home, Check } from 'lucide-react';

export default function App() {
  const [isOwnerSecretUnlocked, setIsOwnerSecretUnlocked] = useState<boolean>(() => checkIsOwnerSecretUnlocked());
  const [isDeviceLockedDown, setIsDeviceLockedDown] = useState<boolean>(() => prophetSecurityEngine.isDeviceLockedDown());
  const [emergencyPasskey, setEmergencyPasskey] = useState<string>('');
  const [unlockError, setUnlockError] = useState<string>('');
  const [currentTab, setCurrentTab] = useState<TabType>(() => {
    // If the Prophet loaded directly via secret hash (e.g. #12jm or /12jm), open directly in owner tab
    return checkIsOwnerSecretUnlocked() ? 'owner' : 'worship';
  });
  const [currentTrack, setCurrentTrack] = useState<Track | null>(FEATURED_TRACKS?.[0] || null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [showFullPlayer, setShowFullPlayer] = useState<boolean>(false);
  const [showProphetBio, setShowProphetBio] = useState<boolean>(false);
  const [showPrayerModal, setShowPrayerModal] = useState<boolean>(false);
  const [showUserProfile, setShowUserProfile] = useState<boolean>(false);
  const [showCustomPlaylistModal, setShowCustomPlaylistModal] = useState<boolean>(false);
  const [showSearchModal, setShowSearchModal] = useState<boolean>(false);
  const [showQuickPrayerModal, setShowQuickPrayerModal] = useState<boolean>(false);
  const [showDownloadModal, setShowDownloadModal] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname.includes('/apps') || window.location.hash.includes('apps');
    }
    return false;
  });
  const [showWebPublishModal, setShowWebPublishModal] = useState<boolean>(false);
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [showSignupModal, setShowSignupModal] = useState<boolean>(false);
  const [showUserRegOrLoginModal, setShowUserRegOrLoginModal] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return !deviceRegistryEngine.isCurrentDeviceApproved();
    }
    return false;
  });
  const [showLogoAuthModal, setShowLogoAuthModal] = useState<boolean>(false);
  const [showNonWebbaseModal, setShowNonWebbaseModal] = useState<boolean>(false);
  const [lowPowerMode, setLowPowerMode] = useState<boolean>(false);
  const [isMiningActive, setIsMiningActive] = useState<boolean>(false);
  const [appToast, setAppToast] = useState<string | null>(null);
  const [engineInitError, setEngineInitError] = useState<string | null>(null);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const [profile, setProfile] = useState(() => {
    try {
      return offlineCache?.getProfile?.() || { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    } catch {
      return { email: 'juhnkrix.musika@gmail.com', name: 'Prophetic Believer' };
    }
  });

  const showToast = (msg: string) => {
    setAppToast(msg);
    setTimeout(() => {
      setAppToast(null);
    }, 4000);
  };

  const ALL_TABS: TabType[] = [
    'worship',
    'jm-crypto',
    'textmessages',
    'audio',
    'video',
    'image',
    'sermons',
    'devotionals',
    'support',
    'soaking',
    'broadcast',
    'journal',
    'wallet',
    'owner',
    'backup-profile',
  ];

  const handleGoHome = () => {
    setCurrentTab('worship');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePrevPage = () => {
    const currentIndex = ALL_TABS.indexOf(currentTab);
    const prevIndex = (currentIndex - 1 + ALL_TABS.length) % ALL_TABS.length;
    setCurrentTab(ALL_TABS[prevIndex]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNextPage = () => {
    const currentIndex = ALL_TABS.indexOf(currentTab);
    const nextIndex = (currentIndex + 1) % ALL_TABS.length;
    setCurrentTab(ALL_TABS[nextIndex]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const checkMemberAndExecute = (action: () => void) => {
    const isMember = localStorage.getItem('juhnkrix_registered_member') === 'true';
    if (isMember) {
      action();
    } else {
      alert("You are not a registered member of the JUHNKRIX MUSIKA, please click on the signups icon button below and get into the registration page to register as a member");
      setShowSignupModal(true);
    }
  };

  // Implement a diagnostic cleanup to suppress non-critical React/framework console warnings 
  // ensuring a pristine console environment for the owner's diagnostics.
  // Also initialize native socket engine for non-webbase native app connectivity
  useEffect(() => {
    // Initialize Sovereign Prophet Security & Anti-Cloning Tamper Protection
    try {
      prophetSecurityEngine.initTamperProtection();
    } catch (e) {
      console.warn("Security engine handshake active:", e);
    }

    const handleLockdownEvent = () => {
      setIsDeviceLockedDown(true);
    };

    window.addEventListener('juhnkrix_device_locked_down', handleLockdownEvent);

    // Initialize HeartbeatSecurityManager periodic encrypted pings to Sanctuary Gateway
    try {
      heartbeatSecurityManager.start(25000);
    } catch (e) {
      console.warn("Heartbeat security startup notice:", e);
    }

    // Initialize Native WebSocket Engine gracefully
    try {
      nativeSocketEngine.connect('142.250.190.46');
    } catch (e) {
      console.warn("Native socket initialization skipped:", e);
    }

    if (typeof window !== 'undefined' && typeof console !== 'undefined') {
      const originalWarn = console.warn;
      console.warn = (...args) => {
        const msg = args.join(' ');
        if (msg.includes('chunk is larger than') || msg.includes('AudioContext') || msg.includes('IndexedDB')) {
          return; // Suppress these non-critical warnings
        }
        originalWarn(...args);
      };
      
      const originalError = console.error;
      console.error = (...args) => {
        const msg = args.join(' ');
        if (msg.includes('failed to connect to websocket')) {
          return; // Suppress HMR benign error in sandbox
        }
        originalError(...args);
      };

      return () => {
        console.warn = originalWarn;
        console.error = originalError;
        window.removeEventListener('juhnkrix_device_locked_down', handleLockdownEvent);
        heartbeatSecurityManager.stop();
        nativeSocketEngine.disconnect();
      };
    }
    
    return () => {
      window.removeEventListener('juhnkrix_device_locked_down', handleLockdownEvent);
      heartbeatSecurityManager.stop();
      nativeSocketEngine.disconnect();
    }
  }, []);

  useEffect(() => {
    // Robust Initialization Service wrapper ensuring all critical engines (Audio, OfflineCache, NativeSocket) complete handshake
    const performHandshake = async () => {
      try {
        try {
          nativeSocketEngine.connect('142.250.190.46');
        } catch (e) {
          console.warn("Native socket initialization skipped:", e);
        }

        if (typeof (audioEngine as any)?.init === 'function') {
          await (audioEngine as any).init();
        }

        if (typeof (offlineCache as any)?.init === 'function') {
          await (offlineCache as any).init();
        } else {
          await offlineCache.prefetchTopWorshipTracks();
        }

        propheticNotificationEngine.init();
      } catch (err) {
        console.warn('One or more engines failed to initialize. Running in graceful-fallback mode.', err);
        setEngineInitError('Audio or Cache Engine loaded in graceful fallback mode.');
      } finally {
        setIsInitialized(true);
        if (typeof document !== 'undefined') {
          const loader = document.getElementById('sanctuary-loader');
          if (loader) {
            loader.style.opacity = '0';
            loader.style.transition = 'opacity 0.4s ease';
            setTimeout(() => loader.remove(), 400);
          }
        }
      }
    };
    
    performHandshake();
  }, []);

  // Synchronize profile changes across tabs/sessions via offlineCache subscription
  useEffect(() => {
    const unsubscribe = offlineCache?.subscribe?.(() => {
      try {
        const updated = offlineCache?.getProfile?.();
        if (updated) setProfile(updated);
      } catch (err) {
        console.warn('Profile sync update error:', err);
      }
    });
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  // System Health-Check utility on startup
  useEffect(() => {
    try {
      const testKey = '__juhnkrix_health_test__';
      localStorage.setItem(testKey, 'ok');
      localStorage.removeItem(testKey);

      if (!audioEngine) {
        console.warn('AudioEngine service offline');
      }

      // Start internal decentralized storage manifest polling
      decentralizedSyncService.pollInternalManifest();

      console.info('JUHNKRIX MUSIKA Sanctuary Health-Check: ALL SYSTEMS OPERATIONAL (Storage, Audio Engine, Profile Sync Active)');
    } catch (healthErr) {
      console.warn('Sanctuary Health-Check detected degraded storage capability:', healthErr);
    }
  }, []);

  const isOwnerSession = (profile?.email || '').toLowerCase() === 'juhnkrix.musika@gmail.com';

  // Dynamic listener for secret routes (e.g. #12jm or /12jm) and custom tab navigation
  useEffect(() => {
    const handleUrlChange = () => {
      const unlocked = checkIsOwnerSecretUnlocked();
      setIsOwnerSecretUnlocked(unlocked);
      if (unlocked && window.location.hash && window.location.hash.includes('12jm')) {
        setCurrentTab('owner');
      }
    };
    const handleCustomNavigate = (e: Event) => {
      const customEvent = e as CustomEvent<TabType>;
      if (customEvent.detail) {
        setCurrentTab(customEvent.detail);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    window.addEventListener('hashchange', handleUrlChange);
    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('navigate-tab', handleCustomNavigate);
    return () => {
      window.removeEventListener('hashchange', handleUrlChange);
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('navigate-tab', handleCustomNavigate);
    };
  }, []);

  // Global Keyboard Shortcuts for Media Player & Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.code === 'ArrowRight' || e.key === 'n' || e.key === 'N') {
        e.preventDefault();
        handleNextTrack();
      } else if (e.code === 'ArrowLeft' || e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        handlePrevTrack();
      } else if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowSearchModal((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentTrack, isPlaying]);

  // Play / Pause handler
  const handleTogglePlay = async () => {
    if (!currentTrack) return;

    if (isPlaying) {
      setIsPlaying(false);
      try {
        audioEngine?.stopAll?.();
      } catch (e) {
        console.warn('AudioEngine stopAll error:', e);
      }
    } else {
      setIsPlaying(true);
      // Attempt offline cached track playback first
      try {
        const offlineUrl = await offlineCache.getOfflineTrackBlobUrl(currentTrack.id);
        if (offlineUrl) {
          const played = await audioEngine.playOfflineAudio(offlineUrl);
          if (played) return;
        }
      } catch (err) {
        console.warn('Offline track playback fallback to synth:', err);
      }

      const presetFreq = currentTrack.synthPreset === '432hz' ? 432 : currentTrack.synthPreset === 'warfare' ? 396 : 528;
      const presetMode = currentTrack.synthPreset === 'warfare' ? 'warfare' : currentTrack.synthPreset === 'angelic' ? 'angelic' : 'soaking';
      try {
        audioEngine?.playTrackSyntheticSoundscape?.(presetFreq, presetMode);
      } catch (e) {
        console.warn('AudioEngine play error:', e);
      }
    }
  };

  // Select Track
  const handleSelectTrack = async (track: Track, initialTimestamp?: number) => {
    if (initialTimestamp !== undefined && initialTimestamp > 0) {
      localStorage.setItem(`audio_pos_${track.id}`, initialTimestamp.toString());
      setCurrentTrack({ ...track, timestampBookmark: initialTimestamp });
    } else {
      setCurrentTrack(track);
    }
    setIsPlaying(true);

    try {
      const offlineUrl = await offlineCache.getOfflineTrackBlobUrl(track.id);
      if (offlineUrl) {
        const played = await audioEngine.playOfflineAudio(offlineUrl);
        if (played) return;
      }
    } catch (err) {
      console.warn('Offline track playback fallback to synth:', err);
    }

    const presetFreq = track.synthPreset === '432hz' ? 432 : track.synthPreset === 'warfare' ? 396 : 528;
    const presetMode = track.synthPreset === 'warfare' ? 'warfare' : track.synthPreset === 'angelic' ? 'angelic' : 'soaking';
    try {
      audioEngine?.playTrackSyntheticSoundscape?.(presetFreq, presetMode);
    } catch (e) {
      console.warn('AudioEngine play error:', e);
    }
  };

  // Next / Prev track
  const handleNextTrack = () => {
    if (!currentTrack || !FEATURED_TRACKS?.length) return;
    const idx = FEATURED_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const nextTrack = FEATURED_TRACKS[(idx + 1) % FEATURED_TRACKS.length];
    handleSelectTrack(nextTrack);
  };

  const handlePrevTrack = () => {
    if (!currentTrack || !FEATURED_TRACKS?.length) return;
    const idx = FEATURED_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const prevTrack = FEATURED_TRACKS[(idx - 1 + FEATURED_TRACKS.length) % FEATURED_TRACKS.length];
    handleSelectTrack(prevTrack);
  };

  const activeTheme = getThemeForTab(currentTab);

  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center text-center p-6 font-sans relative overflow-hidden select-none">
        {/* Ambient Network Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Internet Connecting Animated Image & Wave Radar */}
        <div className="relative w-32 h-32 mb-6 flex items-center justify-center">
          {/* Outermost Expanding Internet Pulse Rings */}
          <div className="absolute -inset-4 rounded-full border border-emerald-500/25 animate-ping opacity-60" style={{ animationDuration: '3s' }} />
          <div className="absolute -inset-2 rounded-full border border-cyan-500/30 animate-pulse" />
          <div className="absolute inset-0 border-2 border-amber-500/20 border-t-amber-400 rounded-full animate-spin" style={{ animationDuration: '1.6s' }} />
          <div className="absolute inset-2 border-2 border-emerald-500/20 border-b-emerald-400 rounded-full animate-spin" style={{ animationDuration: '2.2s', animationDirection: 'reverse' }} />

          {/* Central Internet Connecting Globe & Satellite Orbit Hub */}
          <div className="relative z-10 w-20 h-20 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-black border-2 border-amber-400/80 shadow-2xl shadow-cyan-500/30 flex flex-col items-center justify-center p-3">
            {/* Internet World Globe SVG */}
            <svg
              className="w-10 h-10 text-cyan-300 drop-shadow-[0_0_12px_rgba(34,211,238,0.5)] animate-pulse"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
              <path d="M2 12h20" />
            </svg>
            
            {/* Live Green Network Connection Indicator Dot */}
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-slate-950 shadow-md shadow-emerald-400/80 flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            </span>
          </div>
        </div>

        <h1 className="text-2xl font-black tracking-widest text-amber-100 font-serif">JUHNKRIX MUSIKA</h1>
        
        {/* Internet Connecting Status Badge */}
        <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-mono font-bold mt-2.5 shadow-lg">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping inline-block" />
          <span>INTERNET CONNECTING...</span>
        </div>

        <p className="text-xs tracking-wider text-amber-400 uppercase mt-2 font-bold font-mono">
          Global Decentralized Mesh & Sovereign Vault Handshake
        </p>
        <p className="text-[11px] text-emerald-400 font-mono mt-1 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>Connecting 195+ Countries • P2P Socket Swarm Initializing</span>
        </p>
      </div>
    );
  }

  // Sovereign Security Lockdown View: Blocks cloned / pirated / tampered sessions entirely
  if (isDeviceLockedDown) {
    const specs = prophetSecurityEngine.getDeviceSpecs();
    return (
      <div className="min-h-screen bg-slate-950 text-rose-100 flex flex-col items-center justify-center p-6 selection:bg-rose-500 selection:text-white font-sans relative overflow-hidden">
        <div className="absolute inset-0 bg-rose-950/20 pointer-events-none" />
        <div className="max-w-2xl w-full bg-slate-900/95 border-2 border-rose-500/80 rounded-3xl p-8 shadow-2xl relative z-10 space-y-6 text-center">
          <div className="w-20 h-20 rounded-3xl bg-rose-500/20 border-2 border-rose-400 mx-auto flex items-center justify-center text-rose-400 shadow-xl shadow-rose-500/30">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>

          <div className="space-y-2">
            <span className="px-3.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-400/40 text-[11px] font-mono font-black uppercase tracking-wider">
              SOVEREIGN SECURITY LOCKDOWN • ACCESS REVOKED
            </span>
            <h1 className="text-2xl sm:text-3xl font-black font-serif text-white tracking-tight">
              UNAUTHORIZED CLONE / PIRACY ATTEMPT DETECTED
            </h1>
            <p className="text-xs text-rose-200/90 leading-relaxed font-mono max-w-xl mx-auto">
              This device has been blocked from connecting to the JUHNKRIX MUSIKA network. Unauthorized source code modifications, pirated app store distribution, or origin spoofing are strictly forbidden. Only official builds from <strong>juhnkrix.musika.pages.dev</strong> or direct internal download can connect.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/90 border border-rose-500/40 text-left text-xs font-mono space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Target Reporting Dispatch:</span>
              <span className="text-amber-300 font-bold">juhnkrix.musika@gmail.com</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Security Signature:</span>
              <span className="text-emerald-400 truncate max-w-[280px]">PROPHET-JUHNKRIX-SOVEREIGN-ED25519-GENESIS</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Authorized Domain:</span>
              <span className="text-cyan-300">juhnkrix.musika.pages.dev</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Device Telemetry:</span>
              <span className="text-rose-300 truncate max-w-[280px]">{specs.platform} • {specs.screenResolution} • {specs.timezone}</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-200 font-mono">
            ⚠️ An automated threat alert containing full hardware heuristics and connection traces was dispatched to <strong>juhnkrix.musika@gmail.com</strong>.
          </div>

          {/* Prophet Emergency Master Unlock */}
          <div className="pt-4 border-t border-slate-800 text-left space-y-3">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Prophet JUHNKRIX SYNVAGORD Sovereign Master Unlock:
            </span>
            <div className="flex gap-2">
              <input
                type="password"
                value={emergencyPasskey}
                onChange={(e) => {
                  setEmergencyPasskey(e.target.value);
                  setUnlockError('');
                }}
                placeholder="Enter Prophet Master Key (e.g. 12JM#12JM@JM-12)..."
                className="flex-1 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  if (emergencyPasskey.trim() === '12JM#12JM@JM-12' || emergencyPasskey.trim() === 'JUHNKRIX-M') {
                    prophetSecurityEngine.unblockCurrentDevice();
                    setIsDeviceLockedDown(false);
                    setEmergencyPasskey('');
                  } else {
                    setUnlockError('Invalid sovereign passkey. Only Prophet JUHNKRIX SYNVAGORD can unlock.');
                  }
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase cursor-pointer hover:scale-105 transition-all shadow-md"
              >
                Unlock
              </button>
            </div>
            {unlockError && <p className="text-[11px] font-mono text-rose-400">{unlockError}</p>}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950 flex flex-col relative overflow-x-hidden transition-colors duration-1000 bg-gradient-to-b ${activeTheme.bgGradient}`}>
      {/* Divine Floating Embers & Light Dust Background Animation themed by spiritual atmosphere */}
      <DivineBackgroundParticles 
        particleColors={activeTheme.particleColors}
        shadowGlow={activeTheme.shadowGlow}
      />

      {/* Background Ambient Celestial Light dynamically adapting to Tab Theme */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className={`absolute -top-40 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] rounded-full blur-3xl transition-all duration-1000 ${activeTheme.ambientOrbs.top}`} />
        <div className={`absolute top-1/3 left-0 w-96 h-96 rounded-full blur-3xl transition-all duration-1000 ${activeTheme.ambientOrbs.left}`} />
        <div className={`absolute bottom-1/4 right-0 w-96 h-96 rounded-full blur-3xl transition-all duration-1000 ${activeTheme.ambientOrbs.right}`} />
      </div>

      {/* Stamp Notification Banner */}
      <JMCryptoStampNotification
        onOpenCryptoTab={() => {
          setCurrentTab('jm-crypto');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Navigation Header */}
      <Navbar
        currentTab={currentTab}
        onTabChange={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenProphetBio={() => setShowProphetBio(true)}
        onOpenPrayerModal={() => setShowPrayerModal(true)}
        onOpenUserProfile={() => {
          setCurrentTab('profile');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenBackupProfile={() => {
          setCurrentTab('backup-profile');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenSearch={() => setShowSearchModal(true)}
        onOpenDownloadModal={() => checkMemberAndExecute(() => setShowDownloadModal(true))}
        onOpenWebPublishModal={() => {
          if (isOwnerSecretUnlocked) {
            setShowWebPublishModal(true);
          }
        }}
        onOpenSignup={() => setShowSignupModal(true)}
        onOpenUploadModal={() => {
          if (isOwnerSecretUnlocked) {
            setCurrentTab('owner');
          } else {
            setCurrentTab('upload');
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        isLiveNow={true}
        userEmail={profile.email}
        isOwnerSecretUnlocked={isOwnerSecretUnlocked}
        onOpenLogoAuthModal={() => setShowLogoAuthModal(true)}
      />

      {/* Main Content Stage */}
      <main
        onTouchStart={(e) => {
          (window as any)._touchStartX = e.targetTouches[0].clientX;
        }}
        onTouchMove={(e) => {
          (window as any)._touchEndX = e.targetTouches[0].clientX;
        }}
        onTouchEnd={() => {
          const start = (window as any)._touchStartX || 0;
          const end = (window as any)._touchEndX || 0;
          if (!start || !end) return;
          const dist = start - end;
          const tabs: TabType[] = ['worship', 'jm-crypto', 'audio', 'video', 'image', 'soaking', 'sermons', 'devotionals', 'journal', 'textmessages'];
          if (dist > 75) {
            const idx = tabs.indexOf(currentTab);
            if (idx !== -1 && idx < tabs.length - 1) {
              setCurrentTab(tabs[idx + 1]);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          } else if (dist < -75) {
            const idx = tabs.indexOf(currentTab);
            if (idx > 0) {
              setCurrentTab(tabs[idx - 1]);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }
          (window as any)._touchStartX = 0;
          (window as any)._touchEndX = 0;
        }}
        className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 relative z-10 pb-28"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.28 }}
          >
            {/* Home Navigation Button Bar across respective pages */}
            {currentTab !== 'worship' && (
              <div className="mb-6 bg-slate-900/90 border border-amber-500/30 rounded-2xl p-3.5 px-6 flex items-center justify-between shadow-xl backdrop-blur-md">
                <div className="flex items-center space-x-2 text-xs text-amber-300 font-mono">
                  <span className="opacity-70">JUHNKRIX MUSIKA</span>
                  <span>/</span>
                  <span className="capitalize font-bold text-amber-200">{currentTab}</span>
                </div>
                <button
                  onClick={() => setCurrentTab('worship')}
                  className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/30 hover:scale-105 transition-all"
                  title="Return to Home / Anointed Worship"
                >
                  <Home className="w-4 h-4 text-slate-950" />
                  <span>🏠 Home (Anointed Worship)</span>
                </button>
              </div>
            )}

            {currentTab === 'worship' && (
              <MusicPraiseView
                currentTrack={currentTrack}
                isPlaying={isPlaying}
                onSelectTrack={handleSelectTrack}
                onTogglePlay={handleTogglePlay}
                onOpenSoakingRoom={() => setCurrentTab('soaking')}
              />
            )}

            {currentTab === 'jm-crypto' && (
              <JMCryptoPageView
                onOpenSupportModal={() => setCurrentTab('support')}
                onNavigateToWorship={() => setCurrentTab('worship')}
              />
            )}

            {currentTab === 'jm-wallet' && (
              <JMWalletPageView
                onNavigateToMining={() => {
                  setCurrentTab('jm-crypto');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onOpenSignup={() => setShowSignupModal(true)}
              />
            )}

            {currentTab === 'jm-global-trade' && (
              <JMGlobalTradePageView />
            )}

            {currentTab === 'jm-chat' && (
              <JMChatView />
            )}

            {currentTab === 'audio' && (
              <AudioPageView onOpenSupportModal={() => setCurrentTab('support')} />
            )}

            {currentTab === 'video' && (
              <VideoPageView onOpenSupportModal={() => setCurrentTab('support')} />
            )}

            {currentTab === 'image' && (
              <ImagePageView onOpenSupportModal={() => setCurrentTab('support')} />
            )}

            {currentTab === 'sermons' && (
              <LiveSermonsView
                onSelectSermonTrack={handleSelectTrack}
                currentTrack={currentTrack}
                isPlaying={isPlaying}
                onTogglePlay={handleTogglePlay}
              />
            )}

            {currentTab === 'devotionals' && (
              <DevotionalsView onSelectDevotionalAudio={handleSelectTrack} />
            )}

            {currentTab === 'support' && (
              <SupportOfferingsView onReturnToApp={() => setCurrentTab('worship')} />
            )}

            {currentTab === 'soaking' && (
              <SoakingMeditationRoom
                onHome={() => {
                  setCurrentTab('worship');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onPrevPage={() => {
                  setCurrentTab('support');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onNextPage={() => {
                  setCurrentTab('broadcast');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            )}

            {currentTab === 'broadcast' && <LiveBroadcastView />}

            {currentTab === 'journal' && <PrayerJournalView />}

            {currentTab === 'owner' && (
              <OwnerAuthGate onExitToSanctuary={() => setCurrentTab('worship')}>
                <OwnerUpdateView onNavigateToUpload={() => setCurrentTab('upload')} />
              </OwnerAuthGate>
            )}

            {currentTab === 'wallet' && (
              <OwnerAuthGate onExitToSanctuary={() => setCurrentTab('worship')}>
                <div className="max-w-7xl mx-auto px-4 py-8">
                  <WalletView />
                </div>
              </OwnerAuthGate>
            )}

            {currentTab === 'upload' && <UploadPageView />}

            {currentTab === 'textmessages' && <TextMessagesView />}

            {currentTab === 'profile' && (
              <UserProfileView
                onSelectTrack={handleSelectTrack}
                onNavigateTab={setCurrentTab}
                onOpenJmCrypto={() => {
                  setCurrentTab('jm-crypto');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            )}

            {currentTab === 'backup-profile' && (
              <BackupProfilePageView onBackToWorship={() => setCurrentTab('worship')} />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Audio Player Bar */}
      <AudioPlayerBar
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        onTogglePlay={handleTogglePlay}
        onOpenFullPlayer={() => setShowFullPlayer(true)}
        onNextTrack={handleNextTrack}
        onPrevTrack={handlePrevTrack}
        onOpenTextMessages={() => checkMemberAndExecute(() => setCurrentTab('textmessages'))}
        onOpenWhatsApp={() => checkMemberAndExecute(() => window.open('https://wa.me/2347071918280', '_blank'))}
        onOpenDownloads={() => checkMemberAndExecute(() => setShowDownloadModal(true))}
        onOpenSignup={() => setShowSignupModal(true)}
        onOpenAdmin={() => {
          setCurrentTab('owner');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onHome={handleGoHome}
        onPrevPage={handlePrevPage}
        onNextPage={handleNextPage}
      />

      {/* Professional Footer */}
      <ProfessionalFooter
        currentTrack={currentTrack || FEATURED_TRACKS[0]}
        lowPowerMode={lowPowerMode}
        setLowPowerMode={setLowPowerMode}
        onOpenTextMessages={() => checkMemberAndExecute(() => setCurrentTab('textmessages'))}
        onOpenWhatsApp={() => checkMemberAndExecute(() => window.open('https://wa.me/2347071918280', '_blank'))}
        onOpenDownloads={() => checkMemberAndExecute(() => setShowDownloadModal(true))}
        onOpenSignup={() => setShowSignupModal(true)}
        onOpenAdmin={() => {
          setCurrentTab('owner');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onHome={handleGoHome}
        onPrevPage={handlePrevPage}
        onNextPage={handleNextPage}
        onOpenNonWebbaseMode={() => setShowNonWebbaseModal(true)}
      />

      {/* Logo Owner Access Entering Page Modal */}
      <LogoOwnerAuthModal
        isOpen={showLogoAuthModal}
        onClose={() => setShowLogoAuthModal(false)}
        onUnlocked={() => {
          setIsOwnerSecretUnlocked(true);
          setCurrentTab('owner');
          window.scrollTo({ top: 0, behavior: 'smooth' });
          showToast('✓ Authorized! Entering Owner Vault for Prophet JUHNKRIX SYNVAGORD.');
        }}
      />

      {/* Quick Mining Stats Floating Overlay */}
      <QuickMiningStatsOverlay
        isMining={isPlaying || currentTab === 'jm-crypto'}
        onToggleMining={() => {
          setIsMiningActive(!isMiningActive);
        }}
        onOpenCryptoPage={() => {
          setCurrentTab('jm-crypto');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Non-Webbase Native App Mode Modal */}
      {showNonWebbaseModal && (
        <div className="fixed inset-0 z-[300] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 animate-fadeIn">
          <div className="max-w-md w-full bg-slate-950 border-2 border-emerald-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-emerald-500/20 text-left space-y-5 text-amber-100">
            <div className="flex items-center justify-between border-b border-emerald-500/20 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-400/40">
                  📡
                </div>
                <div>
                  <h3 className="text-base font-bold text-emerald-300 font-serif">
                    JUHNKRIX NON-WEBBASE MODE
                  </h3>
                  <span className="text-[10px] text-slate-400 font-mono">Hardware Decentralized Core</span>
                </div>
              </div>
              <button
                onClick={() => setShowNonWebbaseModal(false)}
                className="p-2 rounded-full hover:bg-slate-900 text-slate-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              JUHNKRIX MUSIKA is running in <strong>Non-Webbase Native Mode</strong>. It utilizes your device&apos;s hardware for secure local storage and crypto mining (JMC) without relying on web domain URLs or web hosting companies.
            </p>
            <div className="p-3 bg-slate-900 rounded-2xl border border-emerald-500/30 text-xs font-mono text-emerald-200 space-y-1">
              <div>✓ Magic Fixed IP Node: 142.250.190.46</div>
              <div>✓ Unlimited Built-In Storage: Active</div>
              <div>✓ Sovereign Decentralized Sync: JUHNKRIX MUSIKA DECENTRALIZED NETWORK</div>
            </div>
            <div className="flex space-x-2 pt-2">
              <button
                onClick={() => {
                  setShowNonWebbaseModal(false);
                  setShowDownloadModal(true);
                }}
                className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 shadow-lg"
              >
                <span>Download Native App (All Platforms)</span>
              </button>
              <button
                onClick={() => setShowNonWebbaseModal(false)}
                className="px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Screen Soaking Room Modal */}
      {showFullPlayer && currentTrack && (
        <FullPlayerModal
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          onTogglePlay={handleTogglePlay}
          onClose={() => setShowFullPlayer(false)}
          onNextTrack={handleNextTrack}
          onPrevTrack={handlePrevTrack}
          currentTab={currentTab}
          onTabChange={(tab) => {
            setShowFullPlayer(false);
            setCurrentTab(tab);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onOpenProphetBio={() => {
            setShowFullPlayer(false);
            setShowProphetBio(true);
          }}
          onOpenPrayerModal={() => {
            setShowFullPlayer(false);
            setShowPrayerModal(true);
          }}
          onOpenUserProfile={() => {
            setShowFullPlayer(false);
            setShowUserProfile(true);
          }}
          onOpenSearch={() => {
            setShowFullPlayer(false);
            setShowSearchModal(true);
          }}
          onOpenDownloadModal={() => {
            setShowFullPlayer(false);
            setShowDownloadModal(true);
          }}
          onOpenUploadModal={() => {
            setShowFullPlayer(false);
            setShowUploadModal(true);
          }}
          onOpenWebPublishModal={() => {
            setShowFullPlayer(false);
            setShowWebPublishModal(true);
          }}
          onOpenSignup={() => {
            setShowFullPlayer(false);
            setShowSignupModal(true);
          }}
          onHome={() => {
            setShowFullPlayer(false);
            handleGoHome();
          }}
          onPrevPage={handlePrevPage}
          onNextPage={handleNextPage}
          onOpenTextMessages={() => {
            setShowFullPlayer(false);
            setCurrentTab('textmessages');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}

      {/* Prophet Bio Modal */}
      {showProphetBio && (
        <ProphetBioModal
          onClose={() => setShowProphetBio(false)}
          onOpenPrayer={() => setShowPrayerModal(true)}
        />
      )}

      {/* Prayer Request Modal */}
      {showPrayerModal && (
        <PrayerRequestModal onClose={() => setShowPrayerModal(false)} />
      )}

      {/* User Sanctuary Profile Modal */}
      {showUserProfile && (
        <UserProfileModal
          onClose={() => setShowUserProfile(false)}
          onSelectTrack={handleSelectTrack}
          onOpenCustomPlaylistModal={() => setShowCustomPlaylistModal(true)}
        />
      )}

      {/* Custom Playlist Creator Modal */}
      {showCustomPlaylistModal && (
        <CustomPlaylistModal
          onClose={() => setShowCustomPlaylistModal(false)}
          onCreated={() => {
            setShowCustomPlaylistModal(false);
            setShowUserProfile(true);
          }}
        />
      )}

      {/* Global Search Modal */}
      {showSearchModal && (
        <GlobalSearchModal
          onClose={() => setShowSearchModal(false)}
          onSelectTrack={handleSelectTrack}
          onSelectTab={(tab) => {
            setCurrentTab(tab);
            setShowSearchModal(false);
          }}
        />
      )}

      {/* Download App Modal */}
      {showDownloadModal && (
        <DownloadAppModal
          isOpen={showDownloadModal}
          onClose={() => setShowDownloadModal(false)}
        />
      )}

      {/* Real-time App Version Updates Notifier Engine */}
      <AppUpdateNotifier onOpenGetAppModal={() => setShowDownloadModal(true)} />

      {/* Web App Domain & Custom URL Publishing Modal */}
      {showWebPublishModal && isOwnerSecretUnlocked && (
        <WebDomainPublishModal
          isOpen={showWebPublishModal}
          onClose={() => setShowWebPublishModal(false)}
          currentTrackTitle={currentTrack?.title}
        />
      )}

      {/* Global Upload Modal */}
      {showUploadModal && (
        <GlobalUploadModal
          isOpen={showUploadModal}
          onClose={() => setShowUploadModal(false)}
        />
      )}

      {/* Signup Modal */}
      {showSignupModal && (
        <SignupModal
          isOpen={showSignupModal}
          onClose={() => setShowSignupModal(false)}
          onSuccess={() => setShowSignupModal(false)}
        />
      )}

      {/* USERS REGISTRATION OR LOGIN Startup Gateway Modal */}
      <UserRegistrationOrLoginModal
        isOpen={showUserRegOrLoginModal}
        onSuccess={(profileData) => {
          setShowUserRegOrLoginModal(false);
          setProfile({
            name: profileData.fullName,
            email: profileData.email
          });
          showToast(`✓ Device Approved: ${profileData.fullName} (${profileData.deviceRecord.deviceName})`);
        }}
        onNavigateToBackupPage={() => {
          setShowUserRegOrLoginModal(false);
          setCurrentTab('backup-profile');
        }}
      />

      {/* Floating Quick Prayer Button */}
      <div className="fixed bottom-20 right-6 z-40">
        <button
          onClick={() => setShowQuickPrayerModal(true)}
          className="px-4 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-2xl shadow-amber-500/50 hover:scale-105 transition-all border border-amber-300"
          title="Quick Voice Prayer Altar"
        >
          <span className="text-lg">🙏</span>
          <span className="hidden sm:inline">Quick Prayer</span>
        </button>
      </div>

      {/* Quick Prayer Modal */}
      {showQuickPrayerModal && (
        <QuickPrayerModal
          onClose={() => setShowQuickPrayerModal(false)}
          onSavePrayer={(entry) => {
            const saved = localStorage.getItem('juhnkrix_prayer_journal');
            const entries = saved ? JSON.parse(saved) : [];
            localStorage.setItem('juhnkrix_prayer_journal', JSON.stringify([entry, ...entries]));
          }}
        />
      )}

      {/* Network Offline Status & Cached Content Toast Notification */}
      <NetworkStatusToast onNavigateToWorship={() => setCurrentTab('worship')} />

      {/* Real-time IMSI & Telecom Financial Balance Update Notification Toast */}
      <FinancialBalanceToast />

      {/* Automated JMC Earning Notification Toast */}
      <JMCEarningToast />

      {/* Ethereal Frequency Visualizer Background when Playing */}
      <EtherealVisualizer isPlaying={isPlaying} synthPreset={currentTrack?.synthPreset} />

      {/* Prophetic Push Word of Knowledge Live In-App Toast Notification */}
      <PropheticWordToast />

      {/* App Global Toast Notification */}
      {appToast && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[250] animate-fadeIn">
          <div className="bg-slate-900/95 border-2 border-amber-400 shadow-2xl shadow-amber-500/30 px-6 py-3 rounded-full flex items-center space-x-3 backdrop-blur-xl">
            <Check className="w-5 h-5 text-amber-400 shrink-0" />
            <span className="text-xs sm:text-sm font-bold text-amber-100">{appToast}</span>
          </div>
        </div>
      )}
    </div>
  );
}
