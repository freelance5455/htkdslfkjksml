import React, { useState, useEffect } from 'react';
import { LoadingScreen } from './components/LoadingScreen';
import { MainLobby } from './components/MainLobby';
import { TarneebGame } from './components/TarneebGame';
import { AuthModal } from './components/AuthModal';
import { GamesModal } from './components/modals/GamesModal';
import { SocialModal } from './components/modals/SocialModal';
import { CreateRoomModal } from './components/modals/CreateRoomModal';
import { SpectatorModal } from './components/modals/SpectatorModal';
import { TournamentsModal } from './components/modals/TournamentsModal';
import { StoreModal } from './components/modals/StoreModal';
import { InventoryModal } from './components/modals/InventoryModal';
import { RealMoneyWalletModal } from './components/modals/RealMoneyWalletModal';
import { CustomerSupportModal } from './components/modals/CustomerSupportModal';
import { DailyBonusModal } from './components/modals/DailyBonusModal';
import { BecomeCashierModal } from './components/modals/BecomeCashierModal';
import { CashierDeskModal } from './components/modals/CashierDeskModal';
import { AdminPanel } from './components/admin/AdminPanel';
import { UserProfile, RoomConfig, CashierRequest, SupportTicket } from './types';
import { soundFX } from './utils/soundEffects';
import { testConnection } from './firebase';
import { INITIAL_SUPPORT_TICKETS } from './utils/defaultSupportTickets';

export default function App() {
  // Navigation screen
  const [currentScreen, setCurrentScreen] = useState<'loading' | 'lobby' | 'tarneeb_match'>('loading');

  useEffect(() => {
    testConnection().then((res) => {
      console.log('Firebase connection on boot:', res);
    });
  }, []);

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [gamesModalOpen, setGamesModalOpen] = useState(false);
  const [socialModalOpen, setSocialModalOpen] = useState(false);
  const [createRoomModalOpen, setCreateRoomModalOpen] = useState(false);
  const [spectatorModalOpen, setSpectatorModalOpen] = useState(false);
  const [tournamentsModalOpen, setTournamentsModalOpen] = useState(false);
  const [storeModalOpen, setStoreModalOpen] = useState(false);
  const [inventoryModalOpen, setInventoryModalOpen] = useState(false);
  const [adminPanelOpen, setAdminPanelOpen] = useState(false);
  const [realMoneyWalletOpen, setRealMoneyWalletOpen] = useState(false);
  const [customerSupportModalOpen, setCustomerSupportModalOpen] = useState(false);
  const [dailyBonusModalOpen, setDailyBonusModalOpen] = useState(false);
  const [becomeCashierModalOpen, setBecomeCashierModalOpen] = useState(false);
  const [cashierDeskModalOpen, setCashierDeskModalOpen] = useState(false);
  const [appNotification, setAppNotification] = useState<string | null>(null);

  const handleLogout = () => {
    showAppNotification('👋 تم تسجيل الخروج من الحساب');
    setAuthModalOpen(true);
  };

  // Customer Support Tickets global state
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(INITIAL_SUPPORT_TICKETS);

  // Auto-launch luxurious Daily Bonus Popup upon first login of the day
  useEffect(() => {
    if (currentScreen === 'lobby') {
      const today = new Date().toISOString().split('T')[0];
      if (currentUser.lastDailyBonusClaimDate !== today) {
        const timer = setTimeout(() => {
          setDailyBonusModalOpen(true);
        }, 700);
        return () => clearTimeout(timer);
      }
    }
  }, [currentScreen]);

  const showAppNotification = (msg: string) => {
    setAppNotification(msg);
    setTimeout(() => setAppNotification(null), 3500);
  };

  // Current logged in player profile with activated Real Money & KYC status
  const [currentUser, setCurrentUser] = useState<UserProfile>({
    id: '78453',
    name: 'Player 1',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
    title: 'الماستر الملكي 👑',
    level: 14,
    xp: 4250,
    nextLevelXp: 5000,
    coins: 5400,
    gems: 125,
    realCashBalance: 1250, // Real Money cash balance ($1,250 USD)
    kycVerified: true, // Age 18+ and identity verified
    vipLevel: 1,
    isVip: true,
    accountGroup: {
      groupId: 'grp-78453',
      accountsCount: 1,
      maxAllowed: 4,
      accountIndex: 1,
    },
    role: 'OWNER', // Grants Owner privileges to review Admin Panel effortlessly
  });

  // Cashier queue for Real Money deposits and withdrawals
  const [cashierRequests, setCashierRequests] = useState<CashierRequest[]>([
    {
      id: 'REQ-1092',
      playerId: '78453',
      playerName: 'Player 1',
      type: 'DEPOSIT',
      amount: 250,
      currency: 'USD',
      method: 'USDT_TRC20',
      walletAddressOrAccount: 'TTabeonaRoyalTreasury99Emerald88xQ7',
      txHashOrReceipt: '9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b',
      status: 'APPROVED',
      timestamp: '2026-10-09 17:40:12',
      processedBy: 'CASHIER_04',
      notes: 'تم تأكيد الإيداع عبر شبكة TRC-20 واعتماد الرصيد',
    },
    {
      id: 'REQ-1093',
      playerId: '62194',
      playerName: 'سامي (Sami)',
      type: 'WITHDRAWAL',
      amount: 150,
      currency: 'USD',
      method: 'USDT_TRC20',
      walletAddressOrAccount: 'TSamiWinner99Vault2026TRC20',
      status: 'PENDING',
      timestamp: '2026-10-09 18:15:30',
      notes: 'طلب سحب أرباح طرنيب سوق 41 إلى محفظة بايننس',
    },
    {
      id: 'REQ-1094',
      playerId: '49201',
      playerName: 'أحمد (Ahmed)',
      type: 'DEPOSIT',
      amount: 500,
      currency: 'USD',
      method: 'CASHIER_DIRECT',
      walletAddressOrAccount: 'كاشير دبي المعتمد #02',
      txHashOrReceipt: 'CASHIER_RECEIPT_DXB_9921',
      status: 'PENDING',
      timestamp: '2026-10-09 18:22:04',
      notes: 'إيداع نقدي مباشر عبر فرع الكاشير',
    },
  ]);

  const handleStartTarneebMatch = () => {
    setCurrentScreen('tarneeb_match');
  };

  const handleExitMatch = () => {
    setCurrentScreen('lobby');
  };

  const handleSendGift = (targetPlayer: string, amount: number, type: 'COINS' | 'GEMS') => {
    setCurrentUser((prev) => ({
      ...prev,
      coins: type === 'COINS' ? Math.max(0, prev.coins - amount) : prev.coins,
      gems: type === 'GEMS' ? Math.max(0, prev.gems - amount) : prev.gems,
    }));
  };

  const handleBuyStoreItem = (item: any) => {
    if (item.amount && item.id.startsWith('cp')) {
      setCurrentUser((prev) => ({ ...prev, coins: prev.coins + item.amount }));
    } else if (item.amount && item.id.startsWith('gp')) {
      setCurrentUser((prev) => ({ ...prev, gems: prev.gems + item.amount }));
    } else if (item.priceCoins) {
      setCurrentUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - item.priceCoins) }));
    }
  };

  const handleDepositSubmit = (req: Omit<CashierRequest, 'id' | 'timestamp' | 'status'>) => {
    const newReq: CashierRequest = {
      ...req,
      id: `REQ-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'PENDING',
    };
    setCashierRequests([newReq, ...cashierRequests]);
  };

  const handleWithdrawalSubmit = (req: Omit<CashierRequest, 'id' | 'timestamp' | 'status'>) => {
    const newReq: CashierRequest = {
      ...req,
      id: `REQ-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'PENDING',
    };
    // Deduct immediately on submit and credit back if rejected
    setCurrentUser((prev) => ({
      ...prev,
      realCashBalance: Math.max(0, prev.realCashBalance - req.amount),
    }));
    setCashierRequests([newReq, ...cashierRequests]);
  };

  const handleApproveCashierRequest = (reqId: string) => {
    const req = cashierRequests.find((r) => r.id === reqId);
    if (!req) return;

    soundFX.playVictoryFanfare();

    setCashierRequests((prev) =>
      prev.map((r) => (r.id === reqId ? { ...r, status: 'APPROVED', processedBy: 'OWNER_ROOT' } : r))
    );

    // If it's a deposit for currentUser, credit realCashBalance
    if (req.type === 'DEPOSIT' && req.playerId === currentUser.id) {
      setCurrentUser((prev) => ({
        ...prev,
        realCashBalance: prev.realCashBalance + req.amount,
      }));
    }
  };

  const handleRejectCashierRequest = (reqId: string) => {
    const req = cashierRequests.find((r) => r.id === reqId);
    if (!req) return;

    soundFX.playButtonClick();

    setCashierRequests((prev) =>
      prev.map((r) => (r.id === reqId ? { ...r, status: 'REJECTED', processedBy: 'OWNER_ROOT' } : r))
    );

    // If withdrawal rejected, refund cash back to player
    if (req.type === 'WITHDRAWAL' && req.playerId === currentUser.id) {
      setCurrentUser((prev) => ({
        ...prev,
        realCashBalance: prev.realCashBalance + req.amount,
      }));
    }
  };

  return (
    <div className="w-screen h-screen overflow-hidden bg-[#040806] text-white">
      {/* 1. Loading Screen */}
      {currentScreen === 'loading' && (
        <LoadingScreen onComplete={() => setCurrentScreen('lobby')} />
      )}

      {/* 2. Main Lobby Screen */}
      {currentScreen === 'lobby' && (
        <MainLobby
          currentUser={currentUser}
          onOpenGames={() => setGamesModalOpen(true)}
          onOpenSocial={() => setSocialModalOpen(true)}
          onOpenCreateRoom={() => setCreateRoomModalOpen(true)}
          onOpenSpectator={() => setSpectatorModalOpen(true)}
          onOpenTournaments={() => setTournamentsModalOpen(true)}
          onOpenStore={() => setStoreModalOpen(true)}
          onOpenInventory={() => setInventoryModalOpen(true)}
          onOpenAdmin={() => setAdminPanelOpen(true)}
          onOpenAuth={() => setAuthModalOpen(true)}
          onOpenRealMoneyWallet={() => setRealMoneyWalletOpen(true)}
          onStartTarneebMatch={handleStartTarneebMatch}
          onOpenSupport={() => setCustomerSupportModalOpen(true)}
          unreadSupportCount={supportTickets.reduce((acc, t) => acc + (t.playerId === currentUser.id ? t.unreadPlayerCount : 0), 0)}
          onOpenDailyBonus={() => setDailyBonusModalOpen(true)}
          onOpenBecomeCashier={() => setBecomeCashierModalOpen(true)}
          onOpenCashierDesk={() => setCashierDeskModalOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {/* 3. Tarneeb Game Screen */}
      {currentScreen === 'tarneeb_match' && (
        <TarneebGame currentUser={currentUser} onExitGame={handleExitMatch} />
      )}

      {/* Modals & Dialogs */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        currentUser={currentUser}
        onUpdateUser={setCurrentUser}
        onLogout={handleLogout}
        showNotification={showAppNotification}
      />

      <GamesModal
        isOpen={gamesModalOpen}
        onClose={() => setGamesModalOpen(false)}
        onSelectGame={(gameId) => {
          if (gameId === 'tarneeb') {
            handleStartTarneebMatch();
          } else {
            showAppNotification(`🎮 سيتم فتح محاكي لعبة ${gameId} في التحديث القادم.`);
          }
        }}
      />

      <SocialModal
        isOpen={socialModalOpen}
        onClose={() => setSocialModalOpen(false)}
        currentUser={currentUser}
        onSendGift={handleSendGift}
      />

      <CreateRoomModal
        isOpen={createRoomModalOpen}
        onClose={() => setCreateRoomModalOpen(false)}
        currentUser={currentUser}
        onStartMatch={(room) => {
          handleStartTarneebMatch();
        }}
      />

      <SpectatorModal
        isOpen={spectatorModalOpen}
        onClose={() => setSpectatorModalOpen(false)}
        onWatchMatch={(matchId) => {
          showAppNotification(`👁️ تم تفعيل وضع المشاهدة للغرفة ${matchId} (الأوراق مخفية للمشاهدين)`);
          handleStartTarneebMatch();
        }}
      />

      <TournamentsModal
        isOpen={tournamentsModalOpen}
        onClose={() => setTournamentsModalOpen(false)}
        onRegisterTournament={(title) => {
          showAppNotification(`🏆 تم تسجيلك بنجاح في بطولة: ${title}`);
        }}
      />

      <StoreModal
        isOpen={storeModalOpen}
        onClose={() => setStoreModalOpen(false)}
        currentUser={currentUser}
        onBuyItem={handleBuyStoreItem}
      />

      <InventoryModal
        isOpen={inventoryModalOpen}
        onClose={() => setInventoryModalOpen(false)}
        currentUser={currentUser}
      />

      {/* Real Money Cash Wallet Modal */}
      <RealMoneyWalletModal
        isOpen={realMoneyWalletOpen}
        onClose={() => setRealMoneyWalletOpen(false)}
        currentUser={currentUser}
        cashierRequests={cashierRequests}
        onSubmitDeposit={handleDepositSubmit}
        onSubmitWithdrawal={handleWithdrawalSubmit}
      />

      {/* Full Admin Control Panel with Cashier Desk */}
      <AdminPanel
        isOpen={adminPanelOpen}
        onClose={() => setAdminPanelOpen(false)}
        currentUser={currentUser}
        onUpdateUser={setCurrentUser}
        cashierRequests={cashierRequests}
        onApproveCashierRequest={handleApproveCashierRequest}
        onRejectCashierRequest={handleRejectCashierRequest}
        supportTickets={supportTickets}
        onUpdateSupportTickets={setSupportTickets}
      />

      {/* Player Customer Support Modal */}
      <CustomerSupportModal
        isOpen={customerSupportModalOpen}
        onClose={() => setCustomerSupportModalOpen(false)}
        currentUser={currentUser}
        tickets={supportTickets}
        onUpdateTickets={setSupportTickets}
      />

      {/* Luxurious Royal Daily Bonus Modal */}
      <DailyBonusModal
        isOpen={dailyBonusModalOpen}
        onClose={() => setDailyBonusModalOpen(false)}
        currentUser={currentUser}
        onUpdateUser={setCurrentUser}
      />

      {/* Become Cashier Upgrade Modal */}
      <BecomeCashierModal
        isOpen={becomeCashierModalOpen}
        onClose={() => setBecomeCashierModalOpen(false)}
        currentUser={currentUser}
        onUpdateUser={setCurrentUser}
        onOpenCashierDesk={() => setCashierDeskModalOpen(true)}
        showNotification={showAppNotification}
      />

      {/* Cashier Workstation Desk Modal */}
      <CashierDeskModal
        isOpen={cashierDeskModalOpen}
        onClose={() => setCashierDeskModalOpen(false)}
        currentUser={currentUser}
        onUpdateUser={setCurrentUser}
        cashierRequests={cashierRequests}
        onApproveRequest={handleApproveCashierRequest}
        onRejectRequest={handleRejectCashierRequest}
        showNotification={showAppNotification}
      />

      {/* Floating System Notification (Eliminates all browser alert dialogs) */}
      {appNotification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-60 px-6 py-3 bg-[#06180f]/95 border-2 border-emerald-400 text-emerald-200 text-xs font-bold rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.5)] flex items-center gap-2 animate-in fade-in slide-in-from-top-3">
          <span>{appNotification}</span>
        </div>
      )}
    </div>
  );
}
