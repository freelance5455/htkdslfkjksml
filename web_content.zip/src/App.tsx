/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Mic,
  Power,
  Volume2,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { LiveSession } from './services/LiveSession';
import { musicPlayer } from './services/MusicPlayer';
import {
  SessionState,
  MoodTheme,
  ExpressionType,
  ExecutedAction,
  NoteItem,
  TimerItem,
} from './types';
import { AudioVisualizer } from './components/AudioVisualizer';
import { ExpressionAvatar } from './components/ExpressionAvatar';
import { ControlsHeader } from './components/ControlsHeader';
import { ToolActionModal } from './components/ToolActionModal';
import { VocalSuggestions } from './components/VocalSuggestions';
import { VoiceWidgets } from './components/VoiceWidgets';

const themeGradients: Record<MoodTheme, string> = {
  'cyber-rose': 'from-zinc-950 via-zinc-900 to-[#180512]',
  'electric-violet': 'from-zinc-950 via-zinc-900 to-[#0e0720]',
  'midnight-emerald': 'from-zinc-950 via-zinc-900 to-[#03150d]',
  'solar-amber': 'from-zinc-950 via-zinc-900 to-[#180c03]',
  'hyper-cyan': 'from-zinc-950 via-zinc-900 to-[#03121a]',
};

const themeAccents: Record<
  MoodTheme,
  {
    glow: string;
    border: string;
    text: string;
    button: string;
    ping: string;
  }
> = {
  'cyber-rose': {
    glow: 'bg-pink-500/20',
    border: 'border-pink-500/40',
    text: 'text-pink-400',
    button: 'from-pink-500 to-rose-600 shadow-pink-500/30',
    ping: 'bg-pink-400',
  },
  'electric-violet': {
    glow: 'bg-purple-500/20',
    border: 'border-purple-500/40',
    text: 'text-purple-400',
    button: 'from-purple-600 to-indigo-600 shadow-purple-500/30',
    ping: 'bg-purple-400',
  },
  'midnight-emerald': {
    glow: 'bg-emerald-500/20',
    border: 'border-emerald-500/40',
    text: 'text-emerald-400',
    button: 'from-emerald-500 to-teal-600 shadow-emerald-500/30',
    ping: 'bg-emerald-400',
  },
  'solar-amber': {
    glow: 'bg-amber-500/20',
    border: 'border-amber-500/40',
    text: 'text-amber-400',
    button: 'from-amber-500 to-orange-600 shadow-amber-500/30',
    ping: 'bg-amber-400',
  },
  'hyper-cyan': {
    glow: 'bg-cyan-500/20',
    border: 'border-cyan-500/40',
    text: 'text-cyan-400',
    button: 'from-cyan-500 to-blue-600 shadow-cyan-500/30',
    ping: 'bg-cyan-400',
  },
};

export default function App() {
  const [sessionState, setSessionState] = useState<SessionState>('disconnected');
  const [moodTheme, setMoodTheme] = useState<MoodTheme>('cyber-rose');
  const [expression, setExpression] = useState<ExpressionType>('neutral');
  const [expressionCommentary, setExpressionCommentary] = useState<string>('');
  const [voice, setVoice] = useState<string>('Aoede');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastAction, setLastAction] = useState<ExecutedAction | null>(null);
  const [allActions, setAllActions] = useState<ExecutedAction[]>([]);

  // Voice control widgets state
  const [timers, setTimers] = useState<TimerItem[]>([]);
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);
  const [musicVibe, setMusicVibe] = useState<string>('lofi');
  const [mathResult, setMathResult] = useState<{ calc: string; result: string } | null>(null);

  const sessionRef = useRef<LiveSession | null>(null);

  // Tick active timers every second
  useEffect(() => {
    const interval = setInterval(() => {
      setTimers((prev) =>
        prev.map((t) => {
          if (!t.active || t.remainingSeconds <= 0) return t;
          return { ...t, remainingSeconds: Math.max(0, t.remainingSeconds - 1) };
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Initialize or get the LiveSession instance
  const getSession = useCallback(() => {
    if (!sessionRef.current) {
      sessionRef.current = new LiveSession({
        onStateChange: (newState) => {
          setSessionState(newState);
        },
        onExpressionChange: (expr, comment) => {
          setExpression(expr);
          setExpressionCommentary(comment || '');
        },
        onThemeChange: (theme) => {
          setMoodTheme(theme);
        },
        onActionExecuted: (action) => {
          setLastAction(action);
          setAllActions((prev) => [action, ...prev]);
        },
        onError: (err) => {
          setErrorMessage(err);
        },
        onVoiceChange: (newVoice) => {
          setVoice(newVoice);
        },
        onTimerCreated: (seconds, label) => {
          const newTimer: TimerItem = {
            id: String(Date.now()),
            label,
            totalSeconds: seconds,
            remainingSeconds: seconds,
            active: true,
            createdAt: Date.now(),
          };
          setTimers((prev) => [newTimer, ...prev]);
        },
        onNoteCreated: (text, category) => {
          const newNote: NoteItem = {
            id: String(Date.now()),
            text,
            category: category || 'General',
            createdAt: Date.now(),
          };
          setNotes((prev) => [newNote, ...prev]);
        },
        onMusicVibe: (vibe, action) => {
          setIsMusicPlaying(action === 'play');
          setMusicVibe(vibe);
        },
        onMathResult: (calc, result) => {
          setMathResult({ calc, result });
        },
        onDownloadZip: () => {
          // Additional notification handled in ToolActionModal
        },
      });
    }
    return sessionRef.current;
  }, []);

  const handleToggleConnect = async () => {
    setErrorMessage(null);
    const session = getSession();

    if (sessionState === 'disconnected' || sessionState === 'error') {
      try {
        await session.connect(voice);
      } catch (err: any) {
        setErrorMessage(err?.message || 'Failed to start voice connection');
      }
    } else if (sessionState === 'speaking') {
      session.sendMessage({ type: 'interrupt' });
    } else {
      session.disconnect();
    }
  };

  const handleToggleMute = () => {
    const session = getSession();
    const nextMuted = !isMuted;
    session.setMute(nextMuted);
    setIsMuted(nextMuted);
  };

  const handleSelectVoice = (newVoice: string) => {
    setVoice(newVoice);
    const session = getSession();
    session.switchVoice(newVoice);
  };

  const handleSelectTheme = (newTheme: MoodTheme) => {
    setMoodTheme(newTheme);
  };

  // Audio query helpers for the visualizer
  const getMicLevel = useCallback(() => {
    return sessionRef.current?.getMicLevel() || 0;
  }, []);

  const getSpeakerLevel = useCallback(() => {
    return sessionRef.current?.getSpeakerLevel() || 0;
  }, []);

  const getMicFrequencies = useCallback((arr: Uint8Array) => {
    sessionRef.current?.getMicFrequencies(arr);
  }, []);

  const getSpeakerFrequencies = useCallback((arr: Uint8Array) => {
    sessionRef.current?.getSpeakerFrequencies(arr);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      sessionRef.current?.disconnect();
      musicPlayer.stop();
    };
  }, []);

  const currentAccent = themeAccents[moodTheme] || themeAccents['cyber-rose'];

  return (
    <div
      className={`min-h-screen w-full bg-gradient-to-b ${themeGradients[moodTheme]} text-white flex flex-col justify-between relative overflow-hidden transition-colors duration-1000 select-none font-sans`}
    >
      {/* Futuristic Background Grid & Ambient Glows */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

      {/* Top Header */}
      <ControlsHeader
        state={sessionState}
        theme={moodTheme}
        voice={voice}
        isMuted={isMuted}
        onThemeSelect={handleSelectTheme}
        onVoiceSelect={handleSelectVoice}
        onToggleMute={handleToggleMute}
      />

      {/* Error Alert Toast */}
      {errorMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md bg-red-950/90 border border-red-500/50 p-3.5 rounded-2xl shadow-2xl backdrop-blur-md flex items-center justify-between gap-3 text-xs text-red-200 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="line-clamp-2">{errorMessage}</p>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="px-2 py-1 bg-red-900/60 hover:bg-red-800 text-white rounded-lg font-medium cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Interactive Stage */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 relative z-10 my-auto">
        {/* Dynamic Expression Avatar */}
        <div className="mb-4">
          <ExpressionAvatar
            expression={expression}
            commentary={expressionCommentary}
            theme={moodTheme}
            isSpeaking={sessionState === 'speaking'}
          />
        </div>

        {/* Central Orb & Visualizer Container */}
        <div className="relative flex items-center justify-center my-2">
          {/* Audio Canvas Visualizer */}
          <AudioVisualizer
            state={sessionState}
            theme={moodTheme}
            getMicLevel={getMicLevel}
            getSpeakerLevel={getSpeakerLevel}
            getMicFrequencies={getMicFrequencies}
            getSpeakerFrequencies={getSpeakerFrequencies}
          />

          {/* Central Action / Mic Button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <button
              onClick={handleToggleConnect}
              className={`group relative w-24 h-24 sm:w-28 sm:h-28 rounded-full flex flex-col items-center justify-center transition-all duration-300 transform active:scale-95 cursor-pointer shadow-2xl ${
                sessionState === 'disconnected' || sessionState === 'error'
                  ? 'bg-gradient-to-tr from-zinc-800 to-zinc-900 border border-white/20 hover:border-pink-500/50 hover:shadow-pink-500/20'
                  : sessionState === 'connecting'
                  ? 'bg-gradient-to-tr from-amber-600 to-amber-800 border border-amber-400/50 animate-pulse'
                  : sessionState === 'speaking'
                  ? `bg-gradient-to-tr ${currentAccent.button} border border-white/40 animate-pulse`
                  : `bg-gradient-to-tr ${currentAccent.button} border border-white/30`
              }`}
              title={
                sessionState === 'disconnected'
                  ? 'Tap to start talking'
                  : sessionState === 'speaking'
                  ? 'Tap to interrupt Roxy'
                  : 'Tap to disconnect'
              }
              aria-label="Toggle voice connection"
            >
              {/* Outer button glow ring */}
              <div
                className={`absolute -inset-1 rounded-full blur-md opacity-70 group-hover:opacity-100 transition-opacity ${
                  sessionState === 'disconnected'
                    ? 'bg-pink-500/30'
                    : sessionState === 'speaking'
                    ? 'bg-pink-500/60 animate-ping'
                    : 'bg-emerald-500/50'
                }`}
              />

              {/* Icon Content */}
              <div className="relative z-10 flex flex-col items-center justify-center">
                {sessionState === 'disconnected' || sessionState === 'error' ? (
                  <>
                    <Power className="w-8 h-8 text-pink-400 group-hover:scale-110 transition-transform mb-1" />
                    <span className="text-[10px] font-bold tracking-wider text-pink-200">
                      START
                    </span>
                  </>
                ) : sessionState === 'connecting' ? (
                  <>
                    <Zap className="w-8 h-8 text-amber-200 animate-spin mb-1" />
                    <span className="text-[9px] font-bold tracking-wider text-amber-200 uppercase">
                      SYNC
                    </span>
                  </>
                ) : sessionState === 'speaking' ? (
                  <>
                    <Volume2 className="w-8 h-8 text-white animate-bounce mb-1" />
                    <span className="text-[9px] font-bold tracking-wider text-white uppercase">
                      INTERRUPT
                    </span>
                  </>
                ) : (
                  <>
                    <Mic className="w-8 h-8 text-white mb-1" />
                    <span className="text-[9px] font-bold tracking-wider text-white uppercase">
                      TALK
                    </span>
                  </>
                )}
              </div>
            </button>
          </div>
        </div>

        {/* Real-time Status Caption */}
        <div className="mt-3 flex flex-col items-center gap-1">
          <p className="text-xs sm:text-sm font-semibold tracking-wide text-zinc-300">
            {sessionState === 'disconnected' && 'Tap the orb to give voice commands in Hindi or English'}
            {sessionState === 'connecting' && 'Opening neural audio socket to Gemini Live...'}
            {sessionState === 'listening' && 'Listening to your voice... Give any command!'}
            {sessionState === 'speaking' && 'Roxy is speaking. Speak to interrupt or tap orb.'}
            {sessionState === 'error' && 'Connection interrupted. Tap to retry.'}
          </p>

          <div className="flex items-center gap-2 text-[10px] text-zinc-400">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              16kHz In
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              24kHz Out
            </span>
            <span>•</span>
            <span className="text-pink-400 font-medium">Full Voice Control Active</span>
          </div>
        </div>
      </main>

      {/* Vocal Suggestions at Bottom */}
      <footer className="w-full pb-4 pt-2">
        <VocalSuggestions
          active={sessionState === 'listening' || sessionState === 'speaking'}
        />
      </footer>

      {/* Action Popups & History Drawer */}
      <ToolActionModal
        lastAction={lastAction}
        allActions={allActions}
        onDismiss={() => setLastAction(null)}
      />

      {/* On-Screen Voice Command Widgets (Timer, Notes, Music, Math) */}
      <VoiceWidgets
        timers={timers}
        notes={notes}
        isMusicPlaying={isMusicPlaying}
        musicVibe={musicVibe}
        mathResult={mathResult}
        onClearTimer={(id) => setTimers((prev) => prev.filter((t) => t.id !== id))}
        onDeleteNote={(id) => setNotes((prev) => prev.filter((n) => n.id !== id))}
        onStopMusic={() => {
          musicPlayer.stop();
          setIsMusicPlaying(false);
        }}
        onDismissMath={() => setMathResult(null)}
      />
    </div>
  );
}
