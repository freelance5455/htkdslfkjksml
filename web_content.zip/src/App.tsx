import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type CSSProperties,
  type ReactNode,
} from "react";

type Tab = "home" | "quran" | "tasbih" | "settings";
type Theme = "light" | "mono" | "dark";
type PrayerKey = "Fajr" | "Dhuhr" | "Asr" | "Maghrib" | "Isha";
type PrayerTimes = Record<PrayerKey, string>;
type AdhanOption = { enabled: boolean; fileName: string; audioUrl?: string };
type AdhanSettings = Record<PrayerKey, AdhanOption>;
type LocationInfo = {
  latitude: number;
  longitude: number;
  label: string;
  source: "device" | "default";
};
type SurahMeta = {
  number: number;
  name: string;
  englishName: string;
  numberOfAyahs: number;
  revelationType: string;
};
type QuranAyah = {
  number: number;
  numberInSurah: number;
  text: string;
  page: number;
  juz?: number;
};
type QuranPage = { number: number; ayahs: QuranAyah[] };
type QuranSurah = { number: number; name: string; ayahs: QuranAyah[] };
type LastRead = { number: number; name: string; page: number };
type StoredAudio = { name: string; blob: Blob };

type IconName =
  | "home"
  | "book"
  | "beads"
  | "settings"
  | "bell"
  | "pin"
  | "refresh"
  | "arrow"
  | "chevron"
  | "bookmark"
  | "play"
  | "pause"
  | "file"
  | "close"
  | "plus"
  | "search"
  | "sun"
  | "contrast"
  | "moon"
  | "trash"
  | "check";

const PRAYERS: { key: PrayerKey; label: string }[] = [
  { key: "Fajr", label: "الفجر" },
  { key: "Dhuhr", label: "الظهر" },
  { key: "Asr", label: "العصر" },
  { key: "Maghrib", label: "المغرب" },
  { key: "Isha", label: "العشاء" },
];

const DEFAULT_LOCATION: LocationInfo = {
  latitude: 30.0444,
  longitude: 31.2357,
  label: "القاهرة، مصر",
  source: "default",
};

const DEFAULT_TIMES: PrayerTimes = {
  Fajr: "04:20",
  Dhuhr: "12:01",
  Asr: "15:30",
  Maghrib: "18:04",
  Isha: "19:34",
};

const DEFAULT_ADHAN_SETTINGS: AdhanSettings = {
  Fajr: { enabled: true, fileName: "" },
  Dhuhr: { enabled: true, fileName: "" },
  Asr: { enabled: true, fileName: "" },
  Maghrib: { enabled: true, fileName: "" },
  Isha: { enabled: true, fileName: "" },
};

const DHIKR_OPTIONS = [
  "سُبْحَانَ الله",
  "الْحَمْدُ لِلَّه",
  "لَا إِلَٰهَ إِلَّا الله",
  "اللهُ أَكْبَر",
];

const FALLBACK_FATIHA: QuranSurah = {
  number: 1,
  name: "الفاتحة",
  ayahs: [
    { number: 1, numberInSurah: 1, text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", page: 1, juz: 1 },
    { number: 2, numberInSurah: 2, text: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", page: 1, juz: 1 },
    { number: 3, numberInSurah: 3, text: "الرَّحْمَٰنِ الرَّحِيمِ", page: 1, juz: 1 },
    { number: 4, numberInSurah: 4, text: "مَالِكِ يَوْمِ الدِّينِ", page: 1, juz: 1 },
    { number: 5, numberInSurah: 5, text: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", page: 1, juz: 1 },
    { number: 6, numberInSurah: 6, text: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", page: 1, juz: 1 },
    {
      number: 7,
      numberInSurah: 7,
      text: "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
      page: 1,
      juz: 1,
    },
  ],
};

const NAV_ITEMS: { id: Tab; label: string; icon: IconName }[] = [
  { id: "home", label: "الرئيسية", icon: "home" },
  { id: "quran", label: "القرآن", icon: "book" },
  { id: "tasbih", label: "التسبيح", icon: "beads" },
  { id: "settings", label: "الإعدادات", icon: "settings" },
];

function readLocal<T>(key: string, fallback: T): T {
  try {
    const saved = window.localStorage.getItem(key);
    return saved === null ? fallback : (JSON.parse(saved) as T);
  } catch {
    return fallback;
  }
}

function writeLocal(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage can be unavailable in private browsing; the app remains usable in memory.
  }
}

function loadAdhanSettings(): AdhanSettings {
  const saved = readLocal<Partial<AdhanSettings>>("sakinah:adhan", {});
  return PRAYERS.reduce((result, prayer) => {
    result[prayer.key] = {
      ...DEFAULT_ADHAN_SETTINGS[prayer.key],
      ...saved[prayer.key],
      audioUrl: undefined,
    };
    return result;
  }, {} as AdhanSettings);
}

function arabicDigits(value: string | number) {
  return String(value).replace(/\d/g, (digit) => "٠١٢٣٤٥٦٧٨٩"[Number(digit)]);
}

function cleanSurahName(name: string) {
  return name.replace(/^\s*(?:سُورَةُ|سورة)\s*/u, "").trim();
}

function removeApiBasmala(text: string) {
  const withoutMarks = (value: string) =>
    value
      .replace(/\uFEFF/g, "")
      .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, "")
      .replace(/ٱ/g, "ا")
      .replace(/\s+/g, " ")
      .trim();
  if (!withoutMarks(text).startsWith("بسم الله الرحمن الرحيم")) return text;
  return text.replace(/^\uFEFF/, "").trim().split(/\s+/).slice(4).join(" ");
}

function prayerMinutes(value: string) {
  const [hours, minutes] = value.split(":").map(Number);
  return Number.isFinite(hours) && Number.isFinite(minutes) ? hours * 60 + minutes : -1;
}

function getUpcomingPrayer(now: Date, times: PrayerTimes) {
  const currentMinute = now.getHours() * 60 + now.getMinutes();
  const nextPrayer = PRAYERS.find((prayer) => prayerMinutes(times[prayer.key]) > currentMinute) ?? PRAYERS[0];
  const [hours, minutes] = times[nextPrayer.key].split(":").map(Number);
  const target = new Date(now);
  target.setHours(hours, minutes, 0, 0);
  if (target <= now) target.setDate(target.getDate() + 1);

  const totalSeconds = Math.max(0, Math.floor((target.getTime() - now.getTime()) / 1000));
  const hoursLeft = Math.floor(totalSeconds / 3600);
  const minutesLeft = Math.floor((totalSeconds % 3600) / 60);
  const secondsLeft = totalSeconds % 60;
  const countdown = [hoursLeft, minutesLeft, secondsLeft]
    .map((part) => String(part).padStart(2, "0"))
    .join(":");

  return { prayer: nextPrayer, countdown: arabicDigits(countdown) };
}

function groupAyahsByPage(ayahs: QuranAyah[]): QuranPage[] {
  const grouped = new Map<number, QuranAyah[]>();
  ayahs.forEach((ayah) => {
    const pageNumber = Number(ayah.page) || 1;
    const pageAyahs = grouped.get(pageNumber) ?? [];
    pageAyahs.push(ayah);
    grouped.set(pageNumber, pageAyahs);
  });
  return [...grouped.entries()]
    .sort(([a], [b]) => a - b)
    .map(([number, pageAyahs]) => ({ number, ayahs: pageAyahs }));
}

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const shapes: Record<IconName, ReactNode> = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9.5V21h14V9.5" /><path d="M9 21v-7h6v7" /></>,
    book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22z" /><path d="M4 5.5v14A2.5 2.5 0 0 1 6.5 17H20" /><path d="M8 7h8M8 10h8" /></>,
    beads: <><circle cx="12" cy="12" r="8.5" /><path d="M12 3.5V1.8M8.7 4.2 7.9 2.7M15.3 4.2l.8-1.5M20.5 12h1.7" /><circle cx="12" cy="12" r="2.2" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7-.2.1-1.3.8-.3 1.8h-2.8l-.3-1.8-1.5-.9-1.7.7-1.4-2.4 1.4-1.2V9l-1.4-1.2 1.4-2.4 1.7.7 1.5-.9.3-1.8h2.8l.3 1.8 1.5.9 1.7-.7 1.4 2.4-1.4 1.2z" transform="translate(-1 0)" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
    pin: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    refresh: <><path d="M20 7v5h-5" /><path d="M4.8 9a7.5 7.5 0 0 1 12.8-2L20 12M4 17v-5h5" /><path d="M19.2 15a7.5 7.5 0 0 1-12.8 2L4 12" /></>,
    arrow: <><path d="M5 12h14" /><path d="m13 5 7 7-7 7" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    bookmark: <><path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4z" /></>,
    play: <path d="m8 5 11 7-11 7z" />,
    pause: <><path d="M8 5v14M16 5v14" /></>,
    file: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6M8 13h8M8 17h8" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.5 4.5" /></>,
    sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
    contrast: <><circle cx="12" cy="12" r="9" /><path d="M12 3a9 9 0 0 0 0 18z" /></>,
    moon: <path d="M20.4 15.4A8.8 8.8 0 0 1 8.6 3.6 8.9 8.9 0 1 0 20.4 15.4Z" />,
    trash: <><path d="M4 7h16M10 11v6M14 11v6" /><path d="m6 7 1 14h10l1-14M9 7V4h6v3" /></>,
    check: <path d="m5 12 4 4L19 6" />,
  };

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {shapes[name]}
    </svg>
  );
}

function Switch({ checked, onClick, label }: { checked: boolean; onClick: () => void; label: string }) {
  return (
    <button
      className={`switch ${checked ? "is-on" : ""}`}
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={onClick}
    >
      <span />
    </button>
  );
}

function BottomNav({ active, onChange }: { active: Tab; onChange: (tab: Tab) => void }) {
  return (
    <nav className="bottom-nav" aria-label="التنقل الرئيسي">
      <div className="bottom-nav-inner">
        {NAV_ITEMS.map((item) => (
          <button
            className={`nav-item ${active === item.id ? "is-active" : ""}`}
            key={item.id}
            type="button"
            aria-current={active === item.id ? "page" : undefined}
            onClick={() => onChange(item.id)}
          >
            <Icon name={item.icon} size={21} />
            <span>{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}

function openAudioDatabase() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    if (!("indexedDB" in window)) {
      reject(new Error("IndexedDB is unavailable"));
      return;
    }
    const request = window.indexedDB.open("sakinah-audio", 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains("adhan")) {
        request.result.createObjectStore("adhan");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open audio storage"));
  });
}

async function saveAudioFile(key: PrayerKey, file: File) {
  const database = await openAudioDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction("adhan", "readwrite");
    transaction.objectStore("adhan").put({ name: file.name, blob: file } satisfies StoredAudio, key);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not save audio"));
  });
  database.close();
}

async function readAudioFile(key: PrayerKey): Promise<StoredAudio | null> {
  const database = await openAudioDatabase();
  const value = await new Promise<StoredAudio | null>((resolve) => {
    const request = database.transaction("adhan", "readonly").objectStore("adhan").get(key);
    request.onsuccess = () => resolve((request.result as StoredAudio | undefined) ?? null);
    request.onerror = () => resolve(null);
  });
  database.close();
  return value;
}

async function deleteAudioFile(key: PrayerKey) {
  const database = await openAudioDatabase();
  await new Promise<void>((resolve) => {
    const transaction = database.transaction("adhan", "readwrite");
    transaction.objectStore("adhan").delete(key);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => resolve();
  });
  database.close();
}

export default function App() {
  const savedTheme = readLocal<Theme>("sakinah:theme", "light");
  const [theme, setTheme] = useState<Theme>(["light", "mono", "dark"].includes(savedTheme) ? savedTheme : "light");
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [now, setNow] = useState(() => new Date());
  const [location, setLocation] = useState<LocationInfo>(() => readLocal("sakinah:location", DEFAULT_LOCATION));
  const [locationStatus, setLocationStatus] = useState("سيُحدَّد موقعك تلقائيًا عند فتح سكينة.");
  const [locationLoading, setLocationLoading] = useState(false);
  const [autoLocation, setAutoLocation] = useState(() => readLocal("sakinah:auto-location", true));
  const [calculationMethod, setCalculationMethod] = useState(() => readLocal("sakinah:method", 5));
  const [prayerRefresh, setPrayerRefresh] = useState(0);
  const [prayerTimes, setPrayerTimes] = useState<PrayerTimes>(DEFAULT_TIMES);
  const [prayerTimesLoading, setPrayerTimesLoading] = useState(true);
  const [prayerTimesError, setPrayerTimesError] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => readLocal("sakinah:notifications", false));
  const [adhanSettings, setAdhanSettings] = useState<AdhanSettings>(loadAdhanSettings);
  const [tasbihCount, setTasbihCount] = useState(() => Math.max(0, readLocal("sakinah:tasbih-count", 0)));
  const [tasbihTarget, setTasbihTarget] = useState(() => readLocal("sakinah:tasbih-target", 33));
  const [selectedDhikr, setSelectedDhikr] = useState(() => readLocal("sakinah:tasbih-dhikr", DHIKR_OPTIONS[0]));
  const [surahs, setSurahs] = useState<SurahMeta[]>(() => readLocal("sakinah:surahs", []));
  const [surahsLoading, setSurahsLoading] = useState(true);
  const [surahsError, setSurahsError] = useState(false);
  const [surahSearch, setSurahSearch] = useState("");
  const [surahReload, setSurahReload] = useState(0);
  const [lastRead, setLastRead] = useState<LastRead>(() =>
    readLocal("sakinah:last-read", { number: 1, name: "الفاتحة", page: 1 }),
  );
  const [readerOpen, setReaderOpen] = useState(false);
  const [selectedSurah, setSelectedSurah] = useState<SurahMeta | null>(null);
  const [readerPages, setReaderPages] = useState<QuranPage[]>([]);
  const [readerPageIndex, setReaderPageIndex] = useState(0);
  const [readerLoading, setReaderLoading] = useState(false);
  const [readerError, setReaderError] = useState(false);
  const [toast, setToast] = useState("");

  const autoLocationStarted = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const surahCache = useRef(new Map<number, QuranSurah>());
  const readerRequestId = useRef(0);
  const requestedPage = useRef(1);
  const touchStartX = useRef<number | null>(null);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => writeLocal("sakinah:theme", theme), [theme]);
  useEffect(() => writeLocal("sakinah:auto-location", autoLocation), [autoLocation]);
  useEffect(() => writeLocal("sakinah:location", location), [location]);
  useEffect(() => writeLocal("sakinah:method", calculationMethod), [calculationMethod]);
  useEffect(() => writeLocal("sakinah:notifications", notificationsEnabled), [notificationsEnabled]);
  useEffect(() => writeLocal("sakinah:tasbih-count", tasbihCount), [tasbihCount]);
  useEffect(() => writeLocal("sakinah:tasbih-target", tasbihTarget), [tasbihTarget]);
  useEffect(() => writeLocal("sakinah:tasbih-dhikr", selectedDhikr), [selectedDhikr]);
  useEffect(() => writeLocal("sakinah:last-read", lastRead), [lastRead]);

  useEffect(() => {
    const preferences = PRAYERS.reduce((result, prayer) => {
      result[prayer.key] = {
        enabled: adhanSettings[prayer.key].enabled,
        fileName: adhanSettings[prayer.key].fileName,
      };
      return result;
    }, {} as Record<PrayerKey, { enabled: boolean; fileName: string }>);
    writeLocal("sakinah:adhan", preferences);
  }, [adhanSettings]);

  useEffect(() => {
    let cancelled = false;
    const restoreAudio = async () => {
      const savedAudio = await Promise.all(PRAYERS.map(async ({ key }) => ({ key, audio: await readAudioFile(key).catch(() => null) })));
      if (cancelled) return;
      setAdhanSettings((current) => {
        const next = { ...current };
        savedAudio.forEach(({ key, audio }) => {
          if (!audio) return;
          if (next[key].audioUrl) URL.revokeObjectURL(next[key].audioUrl);
          next[key] = { ...next[key], fileName: audio.name, audioUrl: URL.createObjectURL(audio.blob) };
        });
        return next;
      });
    };
    void restoreAudio();
    return () => {
      cancelled = true;
    };
  }, []);

  const requestLocation = (showToast = true) => {
    if (!navigator.geolocation) {
      setLocationStatus("المتصفح لا يدعم تحديد الموقع.");
      if (showToast) setToast("تعذّر تحديد الموقع من هذا المتصفح.");
      return;
    }

    setLocationLoading(true);
    setLocationStatus("جارٍ تحديد موقعك...");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coordinates = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          label: "موقعك الحالي",
          source: "device" as const,
        };
        setLocation(coordinates);
        setLocationStatus("تم تحديد موقعك بنجاح، وستُحدَّث المواقيت تلقائيًا.");
        setLocationLoading(false);

        const reverseUrl = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${coordinates.latitude}&longitude=${coordinates.longitude}&localityLanguage=ar`;
        void fetch(reverseUrl)
          .then((response) => response.json())
          .then((place: { city?: string; locality?: string; principalSubdivision?: string; countryName?: string }) => {
            const city = place.city || place.locality || place.principalSubdivision;
            if (!city) return;
            const label = [city, place.countryName].filter(Boolean).join("، ");
            setLocation((current) =>
              current.latitude === coordinates.latitude && current.longitude === coordinates.longitude
                ? { ...current, label }
                : current,
            );
          })
          .catch(() => undefined);

        if (showToast) setToast("تم تحديث موقعك ومواقيت الصلاة.");
      },
      () => {
        setLocationLoading(false);
        setLocationStatus("تعذّر الوصول للموقع؛ نستخدم القاهرة حتى تحدّث موقعك.");
        if (showToast) setToast("اسمح لسكينة بالوصول للموقع من إعدادات المتصفح.");
      },
      { enableHighAccuracy: false, timeout: 12000, maximumAge: 300000 },
    );
  };

  useEffect(() => {
    if (!autoLocation || autoLocationStarted.current) return;
    autoLocationStarted.current = true;
    requestLocation(false);
  }, [autoLocation]);

  useEffect(() => {
    const controller = new AbortController();
    const today = new Date();
    const date = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;
    const url = `https://api.aladhan.com/v1/timings/${date}?latitude=${location.latitude}&longitude=${location.longitude}&method=${calculationMethod}`;
    setPrayerTimesLoading(true);
    setPrayerTimesError(false);

    void fetch(url, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Could not load prayer times");
        return response.json();
      })
      .then((payload: { data?: { timings?: Record<string, string> } }) => {
        const timings = payload.data?.timings;
        if (!timings) throw new Error("Prayer times are missing");
        const normalize = (value: string | undefined, fallback: string) => value?.split(" ")[0]?.slice(0, 5) ?? fallback;
        setPrayerTimes({
          Fajr: normalize(timings.Fajr, DEFAULT_TIMES.Fajr),
          Dhuhr: normalize(timings.Dhuhr, DEFAULT_TIMES.Dhuhr),
          Asr: normalize(timings.Asr, DEFAULT_TIMES.Asr),
          Maghrib: normalize(timings.Maghrib, DEFAULT_TIMES.Maghrib),
          Isha: normalize(timings.Isha, DEFAULT_TIMES.Isha),
        });
      })
      .catch(() => {
        if (!controller.signal.aborted) setPrayerTimesError(true);
      })
      .finally(() => {
        if (!controller.signal.aborted) setPrayerTimesLoading(false);
      });

    return () => controller.abort();
  }, [location.latitude, location.longitude, calculationMethod, prayerRefresh]);

  useEffect(() => {
    if (surahs.length > 0) setSurahsLoading(false);
    const controller = new AbortController();
    setSurahsError(false);
    void fetch("https://api.alquran.cloud/v1/surah", { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Could not load surahs");
        return response.json();
      })
      .then((payload: { data?: SurahMeta[] }) => {
        if (!payload.data?.length) throw new Error("Surah list is empty");
        const normalized = payload.data.map((surah) => ({ ...surah, name: cleanSurahName(surah.name) }));
        setSurahs(normalized);
        writeLocal("sakinah:surahs", normalized);
      })
      .catch(() => {
        if (!controller.signal.aborted) setSurahsError(true);
      })
      .finally(() => {
        if (!controller.signal.aborted) setSurahsLoading(false);
      });
    return () => controller.abort();
  }, [surahReload]);

  useEffect(() => {
    const timers: number[] = [];

    const schedulePrayer = (key: PrayerKey) => {
      const [hours, minutes] = prayerTimes[key].split(":").map(Number);
      if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return;
      const target = new Date();
      target.setHours(hours, minutes, 0, 0);
      if (target <= new Date()) target.setDate(target.getDate() + 1);

      const timer = window.setTimeout(() => {
        const prayer = PRAYERS.find((item) => item.key === key);
        if (notificationsEnabled && "Notification" in window && Notification.permission === "granted") {
          try {
            new Notification(`حان وقت صلاة ${prayer?.label ?? "الصلاة"}`, {
              body: adhanSettings[key].fileName ? "استمع إلى الأذان الذي اخترته." : "أضف صوت الأذان من إعدادات سكينة.",
            });
          } catch {
            // Some browsers require a service worker for notifications; audio can still play.
          }
        }
        if (adhanSettings[key].audioUrl) {
          audioRef.current?.pause();
          audioRef.current = new Audio(adhanSettings[key].audioUrl);
          void audioRef.current.play().catch(() => undefined);
        }
        schedulePrayer(key);
      }, Math.max(0, target.getTime() - Date.now()));
      timers.push(timer);
    };

    PRAYERS.forEach(({ key }) => {
      if (adhanSettings[key].enabled) schedulePrayer(key);
    });
    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [prayerTimes, adhanSettings, notificationsEnabled]);

  useEffect(() => {
    if (!readerOpen) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        readerRequestId.current += 1;
        setReaderOpen(false);
      }
      if (event.key === "ArrowLeft") setReaderPageIndex((index) => Math.min(readerPages.length - 1, index + 1));
      if (event.key === "ArrowRight") setReaderPageIndex((index) => Math.max(0, index - 1));
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [readerOpen, readerPages.length]);

  useEffect(() => {
    if (!readerOpen || !selectedSurah || !readerPages[readerPageIndex]) return;
    const readingPosition = {
      number: selectedSurah.number,
      name: selectedSurah.name,
      page: readerPages[readerPageIndex].number,
    };
    setLastRead(readingPosition);
  }, [readerOpen, selectedSurah, readerPages, readerPageIndex]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const upcoming = useMemo(() => getUpcomingPrayer(now, prayerTimes), [now, prayerTimes]);
  const currentPage = readerPages[readerPageIndex];
  const filteredSurahs = useMemo(() => {
    const query = surahSearch.trim().toLowerCase();
    if (!query) return surahs;
    return surahs.filter((surah) => `${surah.name} ${surah.englishName} ${surah.number}`.toLowerCase().includes(query));
  }, [surahSearch, surahs]);
  const progressInRound = tasbihCount > 0 && tasbihCount % tasbihTarget === 0 ? tasbihTarget : tasbihCount % tasbihTarget;
  const progressDegrees = Math.round((progressInRound / tasbihTarget) * 360);

  const toggleNotifications = async () => {
    if (notificationsEnabled) {
      setNotificationsEnabled(false);
      setToast("أُوقفت إشعارات الصلاة.");
      return;
    }
    if (!("Notification" in window)) {
      setToast("الإشعارات غير مدعومة في هذا المتصفح.");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        setNotificationsEnabled(true);
        setToast("فُعّلت إشعارات الصلاة.");
      } else {
        setToast("اسمح بالإشعارات من إعدادات المتصفح لتفعيلها.");
      }
    } catch {
      setToast("تعذّر تفعيل الإشعارات من هذا المتصفح.");
    }
  };

  const openSurah = async (surah: SurahMeta, startPage = 1) => {
    const requestId = ++readerRequestId.current;
    requestedPage.current = startPage;
    setActiveTab("quran");
    setReaderOpen(true);
    setSelectedSurah(surah);
    setReaderPages([]);
    setReaderPageIndex(0);
    setReaderLoading(true);
    setReaderError(false);

    try {
      let data = surahCache.current.get(surah.number);
      if (!data) {
        const response = await fetch(`https://api.alquran.cloud/v1/surah/${surah.number}/quran-uthmani`);
        if (!response.ok) throw new Error("Could not load surah text");
        const payload = (await response.json()) as { data?: { number: number; name: string; ayahs: QuranAyah[] } };
        if (!payload.data?.ayahs?.length) throw new Error("Surah has no ayahs");
        const ayahs = payload.data.ayahs.map((ayah, index) =>
          index === 0 && surah.number !== 1 && surah.number !== 9
            ? { ...ayah, text: removeApiBasmala(ayah.text) }
            : ayah,
        );
        data = { number: payload.data.number, name: cleanSurahName(surah.name || payload.data.name), ayahs };
        surahCache.current.set(surah.number, data);
      }
      if (readerRequestId.current !== requestId) return;
      const pages = groupAyahsByPage(data.ayahs);
      setSelectedSurah({ ...surah, name: data.name || surah.name });
      setReaderPages(pages);
      const startIndex = Math.max(0, pages.findIndex((page) => page.number === startPage));
      setReaderPageIndex(startIndex);
    } catch {
      if (readerRequestId.current !== requestId) return;
      if (surah.number === 1) {
        const pages = groupAyahsByPage(FALLBACK_FATIHA.ayahs);
        surahCache.current.set(1, FALLBACK_FATIHA);
        setReaderPages(pages);
        setReaderPageIndex(0);
        setSelectedSurah({ ...surah, name: FALLBACK_FATIHA.name });
      } else {
        setReaderError(true);
      }
    } finally {
      if (readerRequestId.current === requestId) setReaderLoading(false);
    }
  };

  const closeReader = () => {
    readerRequestId.current += 1;
    setReaderOpen(false);
  };

  const chooseAudioFile = async (key: PrayerKey, file: File) => {
    const audioUrl = URL.createObjectURL(file);
    setAdhanSettings((current) => {
      if (current[key].audioUrl) URL.revokeObjectURL(current[key].audioUrl);
      return { ...current, [key]: { ...current[key], fileName: file.name, audioUrl } };
    });
    try {
      await saveAudioFile(key, file);
      setToast(`حُفظ ملف أذان ${PRAYERS.find((prayer) => prayer.key === key)?.label}.`);
    } catch {
      setToast("تم اختيار الصوت، لكن تعذّر حفظه بعد إغلاق التطبيق.");
    }
  };

  const removeAudioFile = (key: PrayerKey) => {
    const url = adhanSettings[key].audioUrl;
    if (url) URL.revokeObjectURL(url);
    setAdhanSettings((current) => ({ ...current, [key]: { ...current[key], fileName: "", audioUrl: undefined } }));
    void deleteAudioFile(key).catch(() => undefined);
    setToast("أُزيل ملف الأذان.");
  };

  const testAudio = (key: PrayerKey) => {
    const url = adhanSettings[key].audioUrl;
    if (!url) {
      setToast("اختر ملفًا صوتيًا لتجربة الأذان أولًا.");
      return;
    }
    audioRef.current?.pause();
    audioRef.current = new Audio(url);
    void audioRef.current.play().then(() => setToast("يُشغَّل صوت الأذان الآن.")).catch(() => setToast("تعذّر تشغيل هذا الملف الصوتي."));
  };

  const tapTasbih = () => {
    setTasbihCount((count) => {
      const next = count + 1;
      if (next % tasbihTarget === 0) setToast("أتممتَ التسبيح؛ تقبّل الله منك.");
      return next;
    });
    if ("vibrate" in navigator) navigator.vibrate(18);
  };

  const continueReading = () => {
    const surah =
      surahs.find((item) => item.number === lastRead.number) ??
      ({ number: lastRead.number, name: lastRead.name, englishName: "", numberOfAyahs: 0, revelationType: "" } satisfies SurahMeta);
    void openSurah(surah, lastRead.page);
  };

  const hijriDate = new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(now);
  const gregorianDate = new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(now);
  const greeting = now.getHours() < 11 ? "صباحك سكينة" : now.getHours() < 17 ? "نهارك طمأنينة" : "مساؤك طمأنينة";

  return (
    <div className="app-shell" data-theme={theme} dir="rtl">
      {!readerOpen && (
        <>
          <header className="site-header">
            <div className="site-header-inner">
              <a className="brand" href="#home" onClick={(event) => { event.preventDefault(); setActiveTab("home"); }}>
                <span className="brand-mark" aria-hidden="true">
                  <svg viewBox="0 0 42 42" fill="none">
                    <path d="M28.8 29.4A16.7 16.7 0 0 1 12.6 6.2a15.7 15.7 0 1 0 16.2 23.2Z" />
                    <path d="m28.6 8.4 1.3 3.1 3.4.3-2.6 2.2.8 3.3-2.9-1.8-2.9 1.8.8-3.3-2.6-2.2 3.4-.3 1.3-3.1Z" />
                  </svg>
                </span>
                <span className="brand-copy">
                  <strong>سكينة</strong>
                  <small>مساحةٌ للطمأنينة</small>
                </span>
              </a>
              <div className="header-actions">
                <span className="header-date">{gregorianDate}</span>
                <button
                  className={`header-icon-button ${notificationsEnabled ? "is-enabled" : ""}`}
                  type="button"
                  aria-label="تفعيل إشعارات الصلاة"
                  title="إشعارات الصلاة"
                  onClick={() => void toggleNotifications()}
                >
                  <Icon name="bell" size={19} />
                  {notificationsEnabled && <span className="notification-dot" />}
                </button>
              </div>
            </div>
          </header>

          <main className="page-container">
            {activeTab === "home" && (
              <div className="page-view home-page page-enter">
                <div className="home-intro">
                  <div>
                    <p className="eyebrow">{hijriDate} <span aria-hidden="true">·</span> {gregorianDate}</p>
                    <h1>{greeting}</h1>
                    <p className="intro-note">كل صلاة موعدٌ صغير للعودة إلى السكينة.</p>
                  </div>
                  <button className="location-brief" type="button" onClick={() => requestLocation()}>
                    <Icon name="pin" size={17} />
                    <span>{locationLoading ? "جارٍ تحديد الموقع" : location.label}</span>
                    {locationLoading ? <span className="mini-spinner" /> : <Icon name="refresh" size={15} />}
                  </button>
                </div>

                <section className="prayer-hero" aria-label="الصلاة القادمة">
                  <div className="prayer-hero-content">
                    <p className="hero-eyebrow"><span className="hero-dot" /> الصلاة القادمة</p>
                    <h2>{upcoming.prayer.label}</h2>
                    <p className="hero-at-time">عند {arabicDigits(prayerTimes[upcoming.prayer.key])}</p>
                    <div className="hero-countdown-row">
                      <span className="hero-countdown" aria-live="off">{upcoming.countdown}</span>
                      <span className="hero-countdown-caption">متبقٍ على الأذان</span>
                    </div>
                    <button className="hero-link" type="button" onClick={() => setActiveTab("settings")}>
                      اضبط صوت الأذان
                      <Icon name="arrow" size={17} />
                    </button>
                  </div>
                  <div className="hero-side-note">
                    <span className="hero-side-rule" />
                    <span>وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ</span>
                  </div>
                </section>

                <section className="prayer-schedule" aria-labelledby="prayer-times-title">
                  <div className="section-heading schedule-heading">
                    <div>
                      <p className="eyebrow">{location.label}</p>
                      <h2 id="prayer-times-title">مواقيت الصلاة</h2>
                    </div>
                    <button
                      className="quiet-action"
                      type="button"
                      onClick={() => setPrayerRefresh((value) => value + 1)}
                      disabled={prayerTimesLoading}
                    >
                      <Icon name="refresh" size={16} />
                      {prayerTimesLoading ? "جارٍ التحديث" : "تحديث"}
                    </button>
                  </div>
                  <div className="prayer-times-grid">
                    {PRAYERS.map((prayer) => (
                      <div className={`prayer-time ${upcoming.prayer.key === prayer.key ? "is-next" : ""}`} key={prayer.key}>
                        <span className="prayer-time-name">{prayer.label}</span>
                        <strong>{arabicDigits(prayerTimes[prayer.key])}</strong>
                        {upcoming.prayer.key === prayer.key && <span className="next-mark">الصلاة القادمة</span>}
                      </div>
                    ))}
                  </div>
                  {prayerTimesError && <p className="inline-note">تعذّر تحديث المواقيت؛ قد لا تكون الأوقات المعروضة دقيقة. <button type="button" onClick={() => setPrayerRefresh((value) => value + 1)}>أعد المحاولة</button></p>}
                </section>

                <section className="home-reading-row" aria-label="متابعة القراءة">
                  <div className="home-reading-mark"><Icon name="book" size={22} /></div>
                  <div className="home-reading-copy">
                    <p className="eyebrow">وردُك من القرآن</p>
                    <h2>{lastRead.name}</h2>
                    <p>آخر موضع وصلت إليه · الصفحة {arabicDigits(lastRead.page)}</p>
                  </div>
                  <button className="text-action" type="button" onClick={continueReading}>
                    تابع القراءة <Icon name="arrow" size={17} />
                  </button>
                </section>
              </div>
            )}

            {activeTab === "quran" && (
              <div className="page-view quran-page page-enter">
                <div className="page-heading">
                  <p className="eyebrow">تلاوةٌ على مهل</p>
                  <h1>القرآن الكريم</h1>
                  <p>اختر سورة، واقرأ صفحةً صفحةً كما في المصحف.</p>
                </div>

                <button className="continue-reading" type="button" onClick={continueReading}>
                  <span className="continue-icon"><Icon name="book" size={21} /></span>
                  <span className="continue-copy">
                    <small>تابع من حيث وصلت</small>
                    <strong>سورة {lastRead.name}</strong>
                    <span>الصفحة {arabicDigits(lastRead.page)}</span>
                  </span>
                  <span className="continue-arrow"><Icon name="arrow" size={19} /></span>
                </button>

                <div className="surah-toolbar">
                  <div>
                    <h2>السور</h2>
                    <p>{surahs.length ? `${arabicDigits(surahs.length)} سورة` : ""}</p>
                  </div>
                  <label className="surah-search">
                    <Icon name="search" size={18} />
                    <input
                      type="search"
                      value={surahSearch}
                      onChange={(event) => setSurahSearch(event.target.value)}
                      placeholder="ابحث عن سورة"
                      aria-label="ابحث عن سورة"
                    />
                  </label>
                </div>

                {surahsLoading && !surahs.length && (
                  <div className="loading-line"><span className="spinner" /> جارٍ تحميل فهرس السور</div>
                )}
                {surahsError && (
                  <div className="quran-error" role="status">
                    <span>تعذّر الاتصال بمكتبة القرآن. تحقّق من اتصالك ثم أعد المحاولة.</span>
                    <button type="button" onClick={() => { setSurahsLoading(true); setSurahReload((value) => value + 1); }}>إعادة المحاولة</button>
                  </div>
                )}
                {surahs.length > 0 && (
                  <div className="surah-list">
                    {filteredSurahs.map((surah) => (
                      <button className="surah-row" type="button" key={surah.number} onClick={() => void openSurah(surah)}>
                        <span className="surah-number">{arabicDigits(surah.number)}</span>
                        <span className="surah-details">
                          <strong>{surah.name}</strong>
                          <small>{surah.revelationType === "Meccan" ? "مكية" : "مدنية"} <span>·</span> {arabicDigits(surah.numberOfAyahs)} آية</small>
                        </span>
                        <span className="surah-chevron"><Icon name="chevron" size={17} /></span>
                      </button>
                    ))}
                    {filteredSurahs.length === 0 && <p className="empty-search">لم نعثر على سورة بهذا الاسم.</p>}
                  </div>
                )}
                <p className="quran-source">النص القرآني يُحمّل من مكتبة Quran Cloud عند توفر الإنترنت.</p>
              </div>
            )}

            {activeTab === "tasbih" && (
              <div className="page-view tasbih-page page-enter">
                <div className="page-heading tasbih-heading">
                  <p className="eyebrow">اذكر الله بقلبٍ حاضر</p>
                  <h1>التسبيح</h1>
                  <p>لحظاتٌ قصيرة، وأثرٌ يبقى في القلب.</p>
                </div>

                <div className="tasbih-layout">
                  <div className="tasbih-phrase-area">
                    <p className="eyebrow">الذِّكر المختار</p>
                    <h2 className="selected-dhikr" aria-live="polite">{selectedDhikr}</h2>
                    <div className="dhikr-options" role="group" aria-label="اختر الذكر">
                      {DHIKR_OPTIONS.map((dhikr) => (
                        <button
                          className={`dhikr-option ${selectedDhikr === dhikr ? "is-selected" : ""}`}
                          type="button"
                          key={dhikr}
                          onClick={() => setSelectedDhikr(dhikr)}
                        >
                          {dhikr}
                        </button>
                      ))}
                    </div>
                    <div className="target-control">
                      <span>هدف التسبيح</span>
                      <div className="target-options" role="group" aria-label="عدد التسبيحات في الدورة">
                        {[33, 99, 100].map((target) => (
                          <button
                            className={tasbihTarget === target ? "is-selected" : ""}
                            type="button"
                            key={target}
                            onClick={() => setTasbihTarget(target)}
                          >
                            {arabicDigits(target)}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="counter-area">
                    <p className="counter-prompt">اضغط للتسبيح</p>
                    <button
                      className="counter-ring"
                      type="button"
                      onClick={tapTasbih}
                      style={{ "--progress": `${progressDegrees}deg` } as CSSProperties}
                      aria-label={`سبّح ${selectedDhikr}. العدد الحالي ${progressInRound} من ${tasbihTarget}`}
                    >
                      <span className="counter-inner">
                        <strong key={progressInRound} className="counter-value">{arabicDigits(progressInRound)}</strong>
                        <small>من {arabicDigits(tasbihTarget)}</small>
                      </span>
                    </button>
                    <div className="counter-total">
                      <span>إجمالي التسبيحات</span>
                      <strong>{arabicDigits(tasbihCount)}</strong>
                    </div>
                    <button className="reset-counter" type="button" onClick={() => { setTasbihCount(0); setToast("تم تصفير عدّاد التسبيح."); }}>
                      <Icon name="refresh" size={16} /> تصفير العدّاد
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "settings" && (
              <div className="page-view settings-page page-enter">
                <div className="page-heading">
                  <p className="eyebrow">اجعل سكينة أقرب إليك</p>
                  <h1>الإعدادات</h1>
                  <p>خصّص المواقيت والتنبيهات وطريقة عرض التطبيق.</p>
                </div>

                <section className="settings-section">
                  <div className="settings-section-intro">
                    <h2>الموقع والتنبيهات</h2>
                    <p>تُحسب المواقيت بحسب موقعك وطريقة الحساب التي تختارها.</p>
                  </div>
                  <div className="settings-section-body">
                    <div className="setting-row">
                      <div className="setting-copy">
                        <strong>تحديد الموقع تلقائيًا</strong>
                        <small>{locationStatus}</small>
                      </div>
                      <Switch
                        checked={autoLocation}
                        label="تحديد الموقع تلقائيًا"
                        onClick={() => {
                          const next = !autoLocation;
                          setAutoLocation(next);
                            if (next) {
                              autoLocationStarted.current = true;
                              requestLocation();
                            }
                        }}
                      />
                    </div>
                    <div className="setting-row">
                      <div className="setting-copy">
                        <strong>موقع المواقيت</strong>
                        <small>{location.label}</small>
                      </div>
                      <button className="quiet-action" type="button" onClick={() => requestLocation()} disabled={locationLoading}>
                        <Icon name={locationLoading ? "refresh" : "pin"} size={16} />
                        {locationLoading ? "جارٍ التحديد" : "تحديث موقعي"}
                      </button>
                    </div>
                    <div className="setting-row">
                      <label className="setting-copy" htmlFor="calculation-method">
                        <strong>طريقة حساب المواقيت</strong>
                        <small>قد تختلف الدقائق بين الجهات المعتمدة.</small>
                      </label>
                      <select
                        id="calculation-method"
                        className="settings-select"
                        value={calculationMethod}
                        onChange={(event) => setCalculationMethod(Number(event.target.value))}
                      >
                        <option value={5}>الهيئة المصرية العامة للمساحة</option>
                        <option value={4}>أم القرى</option>
                        <option value={3}>رابطة العالم الإسلامي</option>
                        <option value={2}>الجمعية الإسلامية لأمريكا الشمالية</option>
                      </select>
                    </div>
                    <div className="setting-row">
                      <div className="setting-copy">
                        <strong>إشعارات الصلاة</strong>
                        <small>تظهر التنبيهات عند السماح بها من المتصفح.</small>
                      </div>
                      <Switch checked={notificationsEnabled} label="إشعارات الصلاة" onClick={() => void toggleNotifications()} />
                    </div>
                  </div>
                </section>

                <section className="settings-section">
                  <div className="settings-section-intro">
                    <h2>صوت الأذان</h2>
                    <p>اختر ملفًا صوتيًا من جهازك لكل صلاة، ثم جرّب الصوت قبل حفظ اختيارك.</p>
                  </div>
                  <div className="settings-section-body adhan-settings-body">
                    {PRAYERS.map((prayer) => {
                      const option = adhanSettings[prayer.key];
                      const inputId = `adhan-audio-${prayer.key}`;
                      return (
                        <div className="adhan-row" key={prayer.key}>
                          <div className="adhan-name">
                            <strong>{prayer.label}</strong>
                            <small>{option.fileName || "لم يُختر ملف صوتي"}</small>
                          </div>
                          <div className="adhan-controls">
                            {option.fileName && (
                              <>
                                <button className="audio-control" type="button" onClick={() => testAudio(prayer.key)} aria-label={`تجربة أذان ${prayer.label}`} title="تجربة الصوت">
                                  <Icon name="play" size={15} />
                                </button>
                                <button className="audio-control remove-audio" type="button" onClick={() => removeAudioFile(prayer.key)} aria-label={`إزالة ملف أذان ${prayer.label}`} title="إزالة الملف">
                                  <Icon name="trash" size={15} />
                                </button>
                              </>
                            )}
                            <label className="audio-picker" htmlFor={inputId}>
                              <Icon name="file" size={15} />
                              <span>{option.fileName ? "تغيير الملف" : "اختيار ملف"}</span>
                            </label>
                            <input
                              className="visually-hidden"
                              id={inputId}
                              type="file"
                              accept="audio/*"
                              onChange={(event: ChangeEvent<HTMLInputElement>) => {
                                const file = event.currentTarget.files?.[0];
                                if (file) void chooseAudioFile(prayer.key, file);
                                event.currentTarget.value = "";
                              }}
                            />
                            <Switch
                              checked={option.enabled}
                              label={`تفعيل أذان ${prayer.label}`}
                              onClick={() => setAdhanSettings((current) => ({
                                ...current,
                                [prayer.key]: { ...current[prayer.key], enabled: !current[prayer.key].enabled },
                              }))}
                            />
                          </div>
                        </div>
                      );
                    })}
                    <p className="adhan-footnote">يعمل تشغيل الصوت والتنبيه ما دام التطبيق مفتوحًا في المتصفح.</p>
                  </div>
                </section>

                <section className="settings-section appearance-section">
                  <div className="settings-section-intro">
                    <h2>المظهر</h2>
                    <p>اختر النمط الأريح لعينيك.</p>
                  </div>
                  <div className="settings-section-body">
                    <div className="theme-options" role="radiogroup" aria-label="نمط الألوان">
                      {([
                        { id: "light", label: "فاتح", icon: "sun" as const },
                        { id: "mono", label: "أبيض وأسود", icon: "contrast" as const },
                        { id: "dark", label: "داكن", icon: "moon" as const },
                      ] as { id: Theme; label: string; icon: IconName }[]).map((item) => (
                        <button
                          className={`theme-choice ${theme === item.id ? "is-selected" : ""}`}
                          type="button"
                          role="radio"
                          aria-checked={theme === item.id}
                          key={item.id}
                          onClick={() => setTheme(item.id)}
                        >
                          <span className={`theme-swatch swatch-${item.id}`}><Icon name={item.icon} size={17} /></span>
                          <span>{item.label}</span>
                          {theme === item.id && <Icon name="check" size={16} />}
                        </button>
                      ))}
                    </div>
                  </div>
                </section>

                <footer className="settings-footer">
                  <span>تُحفظ اختياراتك على هذا الجهاز.</span>
                  <strong>تطوير <bdi>YoseFZewail</bdi></strong>
                </footer>
              </div>
            )}
          </main>

          <BottomNav active={activeTab} onChange={setActiveTab} />
        </>
      )}

      {readerOpen && (
        <section className="reader-shell" aria-label="قارئ القرآن" dir="rtl">
          <header className="reader-topbar">
            <button className="reader-icon-button" type="button" onClick={closeReader} aria-label="العودة إلى فهرس القرآن">
              <Icon name="close" size={20} />
            </button>
            <div className="reader-heading">
              <small>المصحف الشريف</small>
              <strong>{selectedSurah ? `سورة ${selectedSurah.name}` : "القرآن الكريم"}</strong>
            </div>
            <button
              className="reader-icon-button"
              type="button"
              aria-label="حفظ موضع القراءة"
              title="حفظ موضع القراءة"
              onClick={() => setToast("حُفظ موضع القراءة.")}
            >
              <Icon name="bookmark" size={19} />
            </button>
          </header>

          <div
            className="reader-sheet-wrap"
            onTouchStart={(event) => { touchStartX.current = event.changedTouches[0]?.clientX ?? null; }}
            onTouchEnd={(event) => {
              const endX = event.changedTouches[0]?.clientX;
              if (touchStartX.current === null || endX === undefined) return;
              const distance = touchStartX.current - endX;
              if (distance > 55) setReaderPageIndex((index) => Math.min(readerPages.length - 1, index + 1));
              if (distance < -55) setReaderPageIndex((index) => Math.max(0, index - 1));
              touchStartX.current = null;
            }}
          >
            {readerLoading ? (
              <div className="reader-message"><span className="spinner" /> جارٍ تجهيز صفحات المصحف</div>
            ) : readerError ? (
              <div className="reader-message reader-error">
                <span>تعذّر تحميل السورة. تأكّد من اتصال الإنترنت ثم حاول مرة أخرى.</span>
                {selectedSurah && <button type="button" onClick={() => void openSurah(selectedSurah, requestedPage.current)}>إعادة المحاولة</button>}
              </div>
            ) : currentPage && selectedSurah ? (
              <article className="reader-sheet">
                <div className="reader-ornament" aria-hidden="true"><span /><span /><span /></div>
                {readerPageIndex === 0 && (
                  <>
                    <div className="reader-surah-heading">
                      <span className="reader-surah-rule" />
                      <h1>سُورَةُ {selectedSurah.name}</h1>
                      <span className="reader-surah-rule" />
                    </div>
                    {selectedSurah.number !== 1 && selectedSurah.number !== 9 && (
                      <p className="reader-basmala">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
                    )}
                  </>
                )}
                <div className="reader-text-wrap">
                  <div className="reader-text" key={currentPage.number}>
                    {currentPage.ayahs.map((ayah) => (
                      <span className="verse-fragment" key={ayah.number}>
                        {ayah.text}
                        <span className="verse-number" aria-label={`الآية ${arabicDigits(ayah.numberInSurah)}`}>{arabicDigits(ayah.numberInSurah)}</span>
                        {" "}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="reader-page-number">{arabicDigits(currentPage.number)}</div>
              </article>
            ) : null}
          </div>

          <footer className="reader-footer">
            <button
              className="reader-page-control"
              type="button"
              disabled={readerPageIndex <= 0 || readerLoading}
              onClick={() => setReaderPageIndex((index) => Math.max(0, index - 1))}
            >
              <Icon name="arrow" size={17} /> السابقة
            </button>
            <div className="reader-progress-wrap">
              <span>{currentPage ? `الصفحة ${arabicDigits(currentPage.number)}` : ""}</span>
              <div className="reader-progress-track"><span style={{ width: `${readerPages.length ? ((readerPageIndex + 1) / readerPages.length) * 100 : 0}%` }} /></div>
            </div>
            <button
              className="reader-page-control"
              type="button"
              disabled={readerPageIndex >= readerPages.length - 1 || readerLoading}
              onClick={() => setReaderPageIndex((index) => Math.min(readerPages.length - 1, index + 1))}
            >
              التالية <Icon name="arrow" size={17} />
            </button>
          </footer>
        </section>
      )}

      {toast && <div className="toast-message" role="status">{toast}</div>}
    </div>
  );
}