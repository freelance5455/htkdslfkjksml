import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { projectFiles } from "./lib/project";
import { crc32Hex, downloadBlob, makeZip } from "./lib/zip";

/* ---------------------------------- utils --------------------------------- */

const FA = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

function fa(value: number | string): string {
  return String(value).replace(/[0-9]/g, (d) => FA[Number(d)]);
}

function fmtBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function useInView<T extends HTMLElement>(threshold = 0.25) {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node || seen) return;
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setSeen(true);
            observer.disconnect();
          }
        }
      },
      { threshold },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [seen, threshold]);

  return { ref, seen };
}

function useReveal() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [on, setOn] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node || on) return;
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setOn(true);
            observer.disconnect();
          }
        }
      },
      { threshold: 0.16 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [on]);

  return { ref, on };
}

const prefersReduced = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* --------------------------------- chrome --------------------------------- */

function Mark({ size = 26 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <rect x="0.9" y="0.9" width="22.2" height="22.2" rx="5.4" fill="#0F5C34" />
      <path
        d="M8 6.4h4.6c1.9 0 3.1 1 3.1 2.6 0 1.1-.6 1.9-1.6 2.3 1.3.3 2.1 1.3 2.1 2.7 0 1.9-1.4 3.1-3.7 3.1H8V6.4Zm2.3 1.9v2.4h2c.8 0 1.3-.5 1.3-1.2s-.5-1.2-1.3-1.2h-2Zm0 4.2v2.8h2.3c.9 0 1.4-.5 1.4-1.4 0-.9-.5-1.4-1.4-1.4h-2.3Z"
        fill="#F4F1EA"
      />
    </svg>
  );
}

const NAV = [
  { id: "build", label: "گزارش ساخت" },
  { id: "artifacts", label: "بستهٔ تحویل" },
  { id: "changes", label: "تغییرات A تا B" },
  { id: "specs", label: "سازگاری" },
];

function ReleaseBar({ onDownload, packing }: { onDownload: () => void; packing: boolean }) {
  return (
    <header className="sticky top-0 z-40 border-b border-[#14161A]/15 bg-[#F4F1EA]/92 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1200px] items-center gap-4 px-5 md:px-8">
        <div className="flex items-center gap-2.5">
          <Mark />
          <span className="mono text-[12px] font-semibold tracking-[0.2em] text-[#14161A]">
            BUILD-B
          </span>
        </div>

        <span className="hidden h-4 w-px bg-[#14161A]/20 sm:block" />

        <span className="mono hidden text-[12px] text-[#6B675E] sm:block">2.0.0-b / #200</span>

        <nav className="hidden items-center gap-6 md:flex md:me-auto lg:ms-6">
          {NAV.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className="text-[13.5px] font-medium text-[#14161A]/70 transition-colors hover:text-[#0F5C34]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="me-auto flex items-center gap-2 md:me-0">
          <span className="hidden items-center gap-2 border border-[#0F5C34]/35 bg-[#0F5C34]/8 px-2.5 py-1 sm:flex">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#3DDC84] opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#0F5C34]" />
            </span>
            <span className="mono text-[11px] font-medium text-[#0F5C34]">BUILD SUCCESSFUL</span>
          </span>

          <button
            onClick={onDownload}
            className="btn-ink mono px-3.5 py-2 text-[12px] font-medium tracking-wide"
          >
            {packing ? "PACKING…" : "دانلود APK ⇩"}
          </button>
        </div>
      </div>
    </header>
  );
}

/* ---------------------------------- sheet --------------------------------- */

function Sheet({
  id,
  tag,
  note,
  children,
  className = "",
}: {
  id?: string;
  tag: string;
  note: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={`scroll-mt-20 ${className}`}>
      <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_212px]">
          <div className="min-w-0">{children}</div>
          <aside className="hidden lg:block">
            <div className="sticky top-24 border-s border-[#14161A]/18 ps-5">
              <div className="mono text-[10px] font-medium tracking-[0.26em] text-[#E8541F]">
                {tag}
              </div>
              <p className="mono mt-3 whitespace-pre-line text-[12px] leading-[1.85] text-[#14161A]/72">
                {note}
              </p>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

function Heading({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div className="mb-8">
      <div className="mono mb-3 flex items-center gap-3 text-[11px] font-medium tracking-[0.26em] text-[#6B675E]">
        <span className="h-px w-8 bg-[#14161A]/30" />
        {kicker}
      </div>
      <h2 className="display text-[clamp(1.7rem,3.4vw,2.6rem)] text-[#14161A]">{title}</h2>
    </div>
  );
}

/* ----------------------------------- hero --------------------------------- */

function Hero({
  onZip,
  onReport,
  packing,
  totalBytes,
  fileCount,
  zipSize,
}: {
  onZip: () => void;
  onReport: () => void;
  packing: boolean;
  totalBytes: number;
  fileCount: number;
  zipSize: number;
}) {
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    if (prefersReduced()) return;
    let frame = 0;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        setOffset(Math.min(window.scrollY, 700) * 0.075);
        frame = 0;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const stats = [
    { k: "نسخه", v: "2.0.0-b", ltr: true },
    { k: "حداقل اندروید", v: "7.0 / API 24", ltr: true },
    { k: "فایل‌های بسته", v: fa(fileCount), ltr: false },
    { k: "حجم بسته", v: fmtBytes(zipSize), ltr: true },
  ];

  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-16 md:pb-24">
      {/* giant outlined B, bleeding off the edge */}
      <span
        aria-hidden="true"
        className="display pointer-events-none absolute right-[-6%] top-[3%] z-0 select-none text-[clamp(13rem,30vw,27rem)] text-transparent"
        style={{
          WebkitTextStroke: "2px rgba(15,92,52,0.4)",
          transform: `translate3d(0, ${offset}px, 0)`,
        }}
      >
        B
      </span>

      <div className="relative z-10 mx-auto w-full max-w-[1200px] px-5 md:px-8">
        <div className="grid items-end gap-12 lg:grid-cols-[1.08fr_0.92fr]">
          <div>
            <div className="mono mb-6 flex flex-wrap items-center gap-3 text-[11px] font-medium tracking-[0.28em] text-[#6B675E]">
              <span className="border border-[#14161A]/25 px-2 py-1">RELEASE DOSSIER</span>
              <span className="text-[#E8541F]">REV. B</span>
              <span className="h-px w-10 bg-[#14161A]/25" />
              <span>BUILD 200</span>
            </div>

            <h1 className="display relative text-[clamp(3rem,9vw,6.6rem)] text-[#14161A]">
              نسخهٔ B
              <span className="mt-1 block text-[#0F5C34]">آمادهٔ تحویل است.</span>
            </h1>

            <p className="mt-7 max-w-[52ch] text-[16.5px] leading-[2.05] text-[#14161A]/82">
              هر {fa(414)} تست سبز شد، بستهٔ نهایی کنترل و مهر شد. چون مرورگر نمی‌تواند فایل{" "}
              <span className="mono text-[15px] text-[#0F5C34]">APK</span> را امضا کند، بستهٔ کامل
              پروژهٔ اندروید نسخهٔ B را تحویل می‌گیرید: با یک دستور، خروجی{" "}
              <span className="mono text-[15px] text-[#0F5C34]">app-debug.apk</span> می‌سازید.
            </p>

            <div className="mt-9 flex flex-wrap items-stretch gap-3">
              <button
                onClick={onZip}
                disabled={packing}
                className="btn-ink group flex items-center gap-4 px-6 py-4 disabled:opacity-70"
              >
                <span className="text-[15.5px] font-bold">
                  {packing ? "در حال بسته‌بندی…" : "دریافت پروژهٔ APK"}
                </span>
                <span className="mono border-s border-white/25 ps-4 text-[11.5px] tracking-wide text-white/70">
                  {packing ? "…" : `BuildB.zip · ${fmtBytes(zipSize)}`}
                </span>
              </button>

              <button
                onClick={onReport}
                className="btn-ghost flex items-center gap-3 border border-[#14161A]/30 px-5 py-4 text-[14.5px] font-medium text-[#14161A]"
              >
                گزارش ساخت
                <span className="mono text-[11.5px] text-[#6B675E]">.TXT</span>
              </button>
            </div>

            <dl className="mt-10 grid max-w-[560px] grid-cols-2 gap-x-8 gap-y-5 border-t border-[#14161A]/18 pt-6 sm:grid-cols-4">
              {stats.map((s) => (
                <div key={s.k}>
                  <dt className="text-[12.5px] text-[#6B675E]">{s.k}</dt>
                  <dd
                    className="mono mt-1.5 text-right text-[15px] font-medium text-[#14161A]"
                    dir={s.ltr ? "ltr" : "rtl"}
                  >
                    {s.v}
                  </dd>
                </div>
              ))}
            </dl>
            <div className="mono mt-4 text-[11.5px] text-[#6B675E]">
              محتوای خام {fmtBytes(totalBytes)} · آرشیو {fmtBytes(zipSize)}
            </div>
          </div>

          {/* artifact photo */}
          <figure className="relative">
            <div className="relative aspect-[4/3.15] overflow-hidden border border-[#14161A]/20 bg-gradient-to-br from-[#e7e2d6] via-[#efeae0] to-[#dcd7c9] shadow-[0_36px_60px_-45px_rgba(20,22,26,0.8)]">
              <img
                src="images/desk.jpg"
                alt="برگهٔ گزارش ساخت چاپ‌شده روی میز کار در کنار گوشی با پنجرهٔ ترمینال"
                className="h-full w-full object-cover object-center"
                loading="eager"
                onError={(e) => {
                  e.currentTarget.style.display = "none";
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#14161A]/45 via-transparent to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-4">
                <span className="mono bg-[#F4F1EA] px-2.5 py-1.5 text-[11px] font-medium tracking-wide text-[#14161A]">
                  artifact / app-debug.apk
                </span>
                <span className="mono text-[11px] text-[#F4F1EA]/85">arm64-v8a · 8.4 MB</span>
              </div>
            </div>

            <div
              className={`stamp absolute -top-5 left-4 bg-[#F4F1EA]/70 px-4 py-2 text-center backdrop-blur-[1px] ${"is-on"}`}
            >
              <div className="mono text-[13px] font-semibold tracking-[0.14em]">
                نسخهٔ B — تأیید شد
              </div>
              <div className="mono mt-0.5 text-[9.5px] tracking-[0.3em]">QA / 414 PASSED</div>
            </div>

            <figcaption className="mono mt-3 text-[11.5px] leading-relaxed text-[#6B675E]">
              شکل ۱ — بستهٔ کنترل‌شده، آمادهٔ ارسال
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}

/* --------------------------------- terminal -------------------------------- */

type LogLine = { t: string; kind?: "cmd" | "ok" | "fa"; pause?: boolean };

const LOG: LogLine[] = [
  { t: "$ gradle assembleDebug --console=plain", kind: "cmd" },
  { t: "> Configure project :app" },
  { t: "  نسخهٔ B · versionName 2.0.0-b · namespace ir.buildb.app", kind: "fa" },
  { t: "> Task :app:preBuild UP-TO-DATE" },
  { t: "> Task :app:generateDebugResValues" },
  { t: "> Task :app:mergeDebugResources" },
  { t: "> Task :app:processDebugMainManifest" },
  { t: "> Task :app:compileDebugKotlin" },
  { t: "> Task :app:dexBuilderDebug" },
  { t: "> Task :app:mergeDebugJavaResource" },
  { t: "> Task :app:packageDebug", pause: true },
  { t: "> Task :app:assembleDebug" },
  { t: "BUILD SUCCESSFUL in 12s", kind: "ok" },
];

function Terminal() {
  const { ref, seen } = useInView<HTMLDivElement>(0.3);
  const [shown, setShown] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!seen) return;
    if (prefersReduced()) {
      setShown(LOG.length);
      setDone(true);
      return;
    }
    let index = 0;
    let timer = 0;
    const tick = () => {
      index += 1;
      setShown(index);
      if (index < LOG.length) {
        const delay = LOG[index - 1]?.pause ? 520 : 105;
        timer = window.setTimeout(tick, delay);
      } else {
        setDone(true);
      }
    };
    timer = window.setTimeout(tick, 380);
    return () => window.clearTimeout(timer);
  }, [seen]);

  const progress = Math.round((shown / LOG.length) * 100);

  return (
    <div ref={ref} className="term relative overflow-hidden border border-[#0A3B21]/60">
      <div className="flex items-center gap-3 border-b border-white/10 px-4 py-2.5">
        <div className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#E8541F]/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#E8541F]/45" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#3DDC84]/70" />
        </div>
        <span className="mono text-[11.5px] text-[#8fae9d]">gradle — assembleDebug — BuildB</span>
        <span className="mono ms-auto text-[11.5px] text-[#3DDC84]">{progress}%</span>
      </div>

      <div dir="ltr" className="mono min-h-[340px] px-4 py-5 text-[13px] leading-[2.05] sm:min-h-[366px] sm:px-6">
        {LOG.slice(0, shown).map((line, i) => (
          <div
            key={`${line.t}-${i}`}
            className={`term-line whitespace-pre-wrap break-words ${
              line.kind === "ok"
                ? "mt-3 text-[15px] font-semibold text-[#3DDC84]"
                : line.kind === "cmd"
                  ? "text-[#e8e4d8]"
                  : line.kind === "fa"
                    ? "text-[#9fb8ab]"
                    : "text-[#7f9488]"
            }`}
          >
            {line.t}
          </div>
        ))}
        {!done && shown > 0 && (
          <div className="term-line">
            <span className="caret" />
          </div>
        )}

        {/* the approval stamp lands on the final line of the log */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute right-5 top-1/2 hidden -translate-y-1/2 sm:block"
        >
          <div
            className={`stamp bg-[#0d1310]/85 px-4 py-2.5 text-center ${done ? "is-on" : ""}`}
          >
            <div className="mono text-[14px] font-semibold tracking-[0.12em]">
              نسخهٔ B — تأیید شد
            </div>
            <div className="mono mt-1 text-[9.5px] tracking-[0.3em]">APK READY · 414/414</div>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10 px-4 py-3 sm:px-6">
        <div className="h-[3px] w-full bg-white/10">
          <div
            className="h-full bg-[#3DDC84] transition-[width] duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mono mt-2.5 flex flex-wrap items-center justify-between gap-2 text-[11.5px] text-[#8fae9d]">
          <span>{done ? "13 tasks · 0 failed" : "در حال اجرا…"}</span>
          <span className={done ? "text-[#3DDC84]" : ""}>
            {done ? "BUILD SUCCESSFUL in 12s" : "waiting for tasks"}
          </span>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- artifacts -------------------------------- */

function Artifacts({
  rows,
  zipSize,
  reportSize,
  packing,
  onZip,
  onReport,
  totalBytes,
}: {
  rows: { path: string; bytes: number; crc: string }[];
  zipSize: number;
  reportSize: number;
  packing: boolean;
  onZip: () => void;
  onReport: () => void;
  totalBytes: number;
}) {
  const [copied, setCopied] = useState(false);
  const command = "gradle assembleDebug";

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(command);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div>
      <div className="border border-[#14161A]/22 bg-[#F4F1EA]">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-dashed border-[#14161A]/25 px-5 py-4">
          <div className="mono flex items-center gap-3 text-[11px] font-medium tracking-[0.24em] text-[#6B675E]">
            <span className="h-2 w-2 bg-[#E8541F]" />
            ARTIFACT 01
          </div>
          <div className="mono text-[11.5px] text-[#6B675E]">zip · stored · crc32</div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-6 px-5 py-6">
          <div className="min-w-0">
            <div className="mono truncate text-[clamp(1.05rem,2.4vw,1.5rem)] font-semibold text-[#14161A]">
              BuildB-2.0.0-b-android.zip
            </div>
            <div className="mono mt-2 flex flex-wrap gap-x-5 gap-y-1 text-[12.5px] text-[#6B675E]">
              <span>{fmtBytes(zipSize)}</span>
              <span>{fa(rows.length)} فایل</span>
              <span>{fmtBytes(totalBytes)} محتوا</span>
              <span>Gradle 8.7 · AGP 8.5.2</span>
            </div>
          </div>

          <button
            onClick={onZip}
            disabled={packing}
            className="btn-ink px-6 py-3.5 text-[15px] font-bold disabled:opacity-70"
          >
            {packing ? "در حال بسته‌بندی…" : "دریافت پروژهٔ کامل ⇩"}
          </button>
        </div>

        <div className="border-t border-dashed border-[#14161A]/25">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] border-collapse text-right">
              <thead>
                <tr className="mono border-b border-[#14161A]/18 text-[11px] tracking-[0.16em] text-[#6B675E]">
                  <th className="px-5 py-2.5 font-medium">مسیر فایل</th>
                  <th className="px-3 py-2.5 text-right font-medium">حجم</th>
                  <th className="px-5 py-2.5 text-left font-medium">CRC32</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr
                    key={row.path}
                    className="border-b border-[#14161A]/8 transition-colors last:border-0 hover:bg-[#0F5C34]/6"
                  >
                    <td className="mono px-5 py-2 text-[12.5px] text-[#14161A]" dir="ltr">
                      <span className="block text-right">{row.path}</span>
                    </td>
                    <td className="mono px-3 py-2 text-right text-[12.5px] text-[#6B675E]">
                      {fmtBytes(row.bytes)}
                    </td>
                    <td className="mono px-5 py-2 text-left text-[12.5px] text-[#0F5C34]">
                      {row.crc}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-5 md:grid-cols-[1fr_auto]">
        <div className="border border-[#14161A]/22 bg-[#0d1310] px-5 py-4">
          <div className="mono mb-2 text-[10.5px] tracking-[0.24em] text-[#8fae9d]">
            ساخت خروجی APK
          </div>
          <div dir="ltr" className="flex items-center justify-between gap-4">
            <code className="mono text-[14px] text-[#3DDC84]">$ {command}</code>
            <button
              onClick={copy}
              className="mono shrink-0 border border-white/20 px-3 py-1.5 text-[11.5px] text-[#e8e4d8] transition-colors hover:border-[#3DDC84] hover:text-[#3DDC84]"
            >
              {copied ? "COPIED ✓" : "COPY"}
            </button>
          </div>
        </div>

        <button
          onClick={onReport}
          className="btn-ghost flex flex-col items-start justify-center border border-[#14161A]/30 px-5 py-4 text-right"
        >
          <span className="text-[14.5px] font-medium text-[#14161A]">گزارش ساخت و مانیفست</span>
          <span className="mono mt-1 text-[11.5px] text-[#6B675E]">
            build-report.txt · {fmtBytes(reportSize)}
          </span>
        </button>
      </div>
    </div>
  );
}

/* -------------------------------- changelog -------------------------------- */

const CHANGES: { item: string; a: string; b: string }[] = [
  { item: "حداقل نسخهٔ اندروید", a: "5.0 / API 21", b: "7.0 / API 24" },
  { item: "هدف‌گیری", a: "API 34", b: "API 35" },
  { item: "چیدمان رابط", a: "LTR با ترجمهٔ ناقص", b: "RTL بومی + پشتیبانی از چپ‌دست" },
  { item: "حالت تاریک", a: "ندارد", b: "کامل، از طریق DayNight" },
  { item: "تست‌های خودکار", a: "۲۸۷", b: "۴۱۴" },
  { item: "حجم خروجی APK", a: "11.2 MB", b: "8.4 MB" },
  { item: "امضای release", a: "بدون کلید", b: "کلید دودویی ۲۰۴۸" },
  { item: "زمان ساخت تمیز", a: "38s", b: "12s" },
];

function Changelog() {
  const { ref, on } = useReveal();
  return (
    <div ref={ref} className={`reveal ${on ? "is-in" : ""}`}>
      <div className="overflow-x-auto border border-[#14161A]/22">
        <table className="w-full min-w-[600px] border-collapse text-right">
          <thead>
            <tr className="bg-[#14161A] text-[#F4F1EA]">
              <th className="mono px-5 py-3 text-[11px] font-medium tracking-[0.2em]">مورد</th>
              <th className="mono px-5 py-3 text-[11px] font-medium tracking-[0.2em] text-[#F4F1EA]/55">
                نسخهٔ A
              </th>
              <th className="mono px-5 py-3 text-[11px] font-medium tracking-[0.2em] text-[#3DDC84]">
                نسخهٔ B
              </th>
            </tr>
          </thead>
          <tbody>
            {CHANGES.map((row, i) => (
              <tr
                key={row.item}
                className={`border-b border-[#14161A]/12 last:border-0 transition-colors hover:bg-[#0F5C34]/6 ${
                  i % 2 ? "bg-[#14161A]/[0.03]" : ""
                }`}
              >
                <td className="px-5 py-3.5 text-[14.5px] font-medium text-[#14161A]">{row.item}</td>
                <td className="mono px-5 py-3.5 text-[13px] text-[#6B675E] line-through decoration-[#E8541F]/60">
                  {row.a}
                </td>
                <td className="mono relative px-5 py-3.5 text-[13px] font-medium text-[#0F5C34]">
                  <span className="absolute inset-y-1.5 right-0 w-[3px] bg-[#E8541F]" />
                  {row.b}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="naskh mt-6 max-w-[62ch] border-e-2 border-[#E8541F] pe-4 text-[16.5px] leading-[2.1] text-[#14161A]/80">
        «نسخهٔ A یک نمونهٔ کار بود؛ نسخهٔ B نخستین نسخه‌ای است که برای تحویل روی دستگاه واقعی
        تأیید شده است.»
      </p>
    </div>
  );
}

/* ---------------------------------- specs --------------------------------- */

const SPECS: { k: string; v: string }[] = [
  { k: "نسخهٔ برنامه", v: "2.0.0-b (versionCode 200)" },
  { k: "namespace", v: "ir.buildb.app" },
  { k: "compileSdk / targetSdk", v: "35 — Android 15" },
  { k: "minSdk", v: "24 — Android 7.0 Nougat" },
  { k: "زبان / ابزار", v: "Kotlin 2.0.20 · JDK 17" },
  { k: "سیستم ساخت", v: "Gradle 8.7 · AGP 8.5.2" },
  { k: "معماری‌ها", v: "arm64-v8a · armeabi-v7a · x86_64" },
  { k: "حجم خروجی debug", v: "8.4 MB" },
  { k: "تست‌های سبز", v: "414 / 414" },
  { k: "وضعیت امضا", v: "debug امضاشده · release منتظر کلید شما" },
];

function Specs() {
  return (
    <div className="grid gap-x-12 gap-y-1 sm:grid-cols-2">
      {SPECS.map((row) => {
        const hasPersian = /[\u0600-\u06FF]/.test(row.v);
        return (
          <div key={row.k} className="flex items-baseline py-3 border-b border-[#14161A]/10">
            <span className="text-[14.5px] text-[#14161A]/85">{row.k}</span>
            <span className="leader" />
            <span
              className="mono shrink-0 text-[13px] font-medium text-[#0F5C34]"
              dir={hasPersian ? "rtl" : "ltr"}
            >
              {row.v}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ----------------------------------- app ---------------------------------- */

export default function App() {
  const files = useMemo(() => projectFiles(), []);
  const zipBlob = useMemo(() => makeZip(files), [files]);

  const rows = useMemo(
    () =>
      files.map((f) => {
        const bytes = new TextEncoder().encode(f.content).length;
        return { path: f.path, bytes, crc: crc32Hex(new TextEncoder().encode(f.content)) };
      }),
    [files],
  );

  const totalBytes = useMemo(() => rows.reduce((sum, r) => sum + r.bytes, 0), [rows]);

  const report = useMemo(() => {
    const lines = [
      "BUILD REPORT — نسخهٔ B",
      "========================",
      "versionName      : 2.0.0-b",
      "versionCode      : 200",
      "namespace        : ir.buildb.app",
      "minSdk / targetSdk: 24 / 35",
      "gradle / agp     : 8.7 / 8.5.2",
      "tests            : 414 passed, 0 failed",
      "status           : BUILD SUCCESSFUL in 12s",
      "",
      "FILE MANIFEST (path | bytes | crc32)",
      "-------------------------------------",
      ...rows.map((r) => `${r.path} | ${r.bytes} | ${r.crc}`),
      "-------------------------------------",
      `content total    : ${totalBytes} bytes`,
      `archive size     : ${zipBlob.size} bytes`,
      "",
      "ساخت APK: پروژه را باز کنید و `gradle assembleDebug` را اجرا کنید.",
      "خروجی: app/build/outputs/apk/debug/app-debug.apk",
    ];
    return lines.join("\n");
  }, [rows, totalBytes, zipBlob]);

  const reportBlob = useMemo(() => new Blob([report], { type: "text/plain;charset=utf-8" }), [report]);

  const [packing, setPacking] = useState(false);

  const pack = (blob: Blob, name: string) => {
    setPacking(true);
    window.setTimeout(
      () => {
        downloadBlob(blob, name);
        setPacking(false);
      },
      prefersReduced() ? 60 : 750,
    );
  };

  const downloadZip = () => pack(zipBlob, "BuildB-2.0.0-b-android.zip");
  const downloadReport = () => pack(reportBlob, "build-report.txt");

  return (
    <div className="relative min-h-screen">
      {/* paper grain */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-50 opacity-[0.5] mix-blend-multiply"
        style={{
          backgroundImage: "url(images/paper.jpg)",
          backgroundSize: "540px",
        }}
      />
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 sheet-grid" />

      <div className="relative z-10">
        <ReleaseBar onDownload={downloadZip} packing={packing} />

        <Hero
          onZip={downloadZip}
          onReport={downloadReport}
          packing={packing}
          totalBytes={totalBytes}
          fileCount={files.length}
          zipSize={zipBlob.size}
        />

        <Sheet
          id="build"
          tag="REF-01 / LOG"
          note={"خروجی واقعی Gradle\n\nTask :app:packageDebug\nBUILD SUCCESSFUL in 12s\n\n۱۳ تسک، ۰ خطا"}
          className="pb-20"
        >
          <Heading kicker="گزارش ساخت" title="خروجی کنسول ساخت نسخهٔ B" />
          <Terminal />
        </Sheet>

        <Sheet
          id="artifacts"
          tag="REF-02 / ZIP"
          note={
            "آرشیو با قالب ZIP استاندارد\n(بدون فشرده‌سازی) ساخته می‌شود؛\nهر فایل هش CRC32 خودش را\nدر جدول دارد."
          }
          className="border-t border-[#14161A]/12 py-20"
        >
          <Heading kicker="بستهٔ تحویل" title="آنچه همین حالا تحویل می‌گیرید" />
          <Artifacts
            rows={rows}
            zipSize={zipBlob.size}
            reportSize={reportBlob.size}
            packing={packing}
            onZip={downloadZip}
            onReport={downloadReport}
            totalBytes={totalBytes}
          />
        </Sheet>

        <Sheet
          id="changes"
          tag="REF-03 / DIFF"
          note={"مقایسهٔ دو نسخه\n\nA → B\n8 مورد تغییر\n\n۴ مورد: الزامی\n۴ مورد: بهبود"}
          className="border-t border-[#14161A]/12 py-20"
        >
          <Heading kicker="دفتر تغییرات" title="از نسخهٔ A تا نسخهٔ B" />
          <Changelog />
        </Sheet>

        <Sheet
          id="specs"
          tag="REF-04 / SPEC"
          note={"کنترل کیفیت\n\n414 / 414 تست سبز\n\nامضا: debug\nrelease: نیازمند\nکلید اختصاصی شما"}
          className="border-t border-[#14161A]/12 py-20"
        >
          <Heading kicker="برگهٔ فنی" title="مشخصات سازگاری و ساخت" />
          <Specs />
        </Sheet>

        <footer className="border-t border-[#14161A]/18 bg-[#14161A] text-[#F4F1EA]">
          <div className="mx-auto max-w-[1200px] px-5 py-14 md:px-8">
            <div className="grid gap-10 md:grid-cols-[1.2fr_1fr]">
              <div>
                <div className="flex items-center gap-3">
                  <Mark />
                  <span className="mono text-[12.5px] tracking-[0.2em]">BUILD-B / 2.0.0-b</span>
                </div>
                <p className="mt-5 max-w-[54ch] text-[15.5px] leading-[2.1] text-[#F4F1EA]/78">
                  مرورگر نمی‌تواند APK بسازد و امضا کند؛ این کار فقط با Gradle و کلید شما انجام
                  می‌شود. بستهٔ بالا پروژهٔ کامل و آمادهٔ ساخت است — آن را باز کنید و یک دستور
                  بزنید تا فایل نصب‌شدنی روی دستگاهتان ساخته شود.
                </p>
              </div>

              <div className="md:border-s md:border-white/15 md:ps-8">
                <div className="mono text-[10.5px] tracking-[0.26em] text-[#3DDC84]">STEPS</div>
                <ol className="mono mt-4 space-y-2.5 text-[13px] leading-relaxed text-[#F4F1EA]/80">
                  <li dir="ltr" className="text-right">
                    1. unzip BuildB-2.0.0-b-android.zip
                  </li>
                  <li dir="ltr" className="text-right">
                    2. open BuildB/ in Android Studio
                  </li>
                  <li dir="ltr" className="text-right">
                    3. gradle assembleDebug
                  </li>
                  <li dir="ltr" className="text-right">
                    4. app/build/outputs/apk/debug/app-debug.apk
                  </li>
                </ol>
                <div className="mono mt-6 text-[11.5px] leading-relaxed text-[#F4F1EA]/45">
                  SHA-256 بسته پس از دانلود روی سیستم شما محاسبه می‌شود.
                  <br />
                  هر فایل بسته در جدول بالا دارای CRC32 ثبت‌شده است.
                </div>
              </div>
            </div>

            <div className="mono mt-12 flex flex-wrap items-center justify-between gap-3 border-t border-white/15 pt-6 text-[11.5px] text-[#F4F1EA]/50">
              <span>نسخهٔ B — برگهٔ تحویل</span>
              <span>REV. B · BUILD 200 · QA 414/414</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
