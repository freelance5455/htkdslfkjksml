/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { SitesView } from './components/SitesView';
import { MessView } from './components/MessView';
import { LandlordView } from './components/LandlordView';
import { LaboursView } from './components/LaboursView';
import { SettingsView } from './components/SettingsView';
import { QuickEntryModal } from './components/QuickEntryModal';

const AppContent: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();
  const [quickEntryOpen, setQuickEntryOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      
      {/* শীর্ষ বার (Top Navigation Bar) */}
      <Navbar onOpenQuickEntry={() => setQuickEntryOpen(true)} />

      {/* প্রধান ভিউপোর্ট (Main Content Viewport) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView onOpenQuickEntry={() => setQuickEntryOpen(true)} />
        )}
        {activeTab === 'sites' && (
          <SitesView />
        )}
        {activeTab === 'mess' && (
          <MessView />
        )}
        {activeTab === 'landlord' && (
          <LandlordView />
        )}
        {activeTab === 'labours' && (
          <LaboursView />
        )}
        {activeTab === 'settings' && (
          <SettingsView />
        )}
      </main>

      {/* দ্রুত এন্ট্রি মডাল */}
      <QuickEntryModal
        isOpen={quickEntryOpen}
        onClose={() => setQuickEntryOpen(false)}
      />

      {/* ফুটার (Footer Contract) */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">বিল্ডিং কন্ট্রাক্টর ও মেস ম্যানেজার</span>
            <span>·</span>
            <span>লোকাল স্টোরেজ অটো-সেভ সক্রিয়</span>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setActiveTab('dashboard')} 
              className="hover:text-slate-800 transition-colors"
            >
              ড্যাশবোর্ড
            </button>
            <button 
              onClick={() => setActiveTab('sites')} 
              className="hover:text-slate-800 transition-colors"
            >
              সাইট ও হাজিরা
            </button>
            <button 
              onClick={() => setActiveTab('mess')} 
              className="hover:text-slate-800 transition-colors"
            >
              মেস ম্যানেজমেন্ট
            </button>
            <button 
              onClick={() => setActiveTab('landlord')} 
              className="hover:text-slate-800 transition-colors"
            >
              বাড়িওয়ালার ভাড়া
            </button>
            <button 
              onClick={() => setActiveTab('settings')} 
              className="hover:text-slate-800 transition-colors"
            >
              ব্যাকআপ ও সেটিংস
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
