/**
 * Pocket Toolkit - All-in-One Android Utility Application
 * Developer: Syed Salman Mehdi
 * Application ID: com.salmanmehdi.pockettoolkit
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { HomeDashboard } from './components/home/HomeDashboard';
import { CalculatorView } from './components/calculator/CalculatorView';
import { PhoneCareView } from './components/phonecare/PhoneCareView';
import { ToolsDirectory } from './components/tools/ToolsDirectory';
import { AboutView } from './components/about/AboutView';
import { SettingsModal } from './components/settings/SettingsModal';
import { CheckCircle2, Info, AlertTriangle } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentTab, phoneFrameMode, toasts } = useApp();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const renderActiveScreen = () => {
    switch (currentTab) {
      case 'home':
        return <HomeDashboard />;
      case 'calculator':
        return <CalculatorView />;
      case 'phonecare':
        return <PhoneCareView />;
      case 'tools':
        return <ToolsDirectory />;
      case 'about':
        return <AboutView />;
      default:
        return <HomeDashboard />;
    }
  };

  return (
    <div className={`min-h-screen bg-[#F4F6F4] dark:bg-[#090D0B] text-neutral-900 dark:text-neutral-100 flex flex-col items-center justify-start ${phoneFrameMode ? 'p-0 md:p-6' : ''}`}>
      {/* Container - adapts to Phone Frame mode or Responsive Screen */}
      <div
        className={`w-full flex-1 flex flex-col bg-[#FBFDF9] dark:bg-[#0F1512] transition-all duration-300 relative ${
          phoneFrameMode
            ? 'max-w-[430px] rounded-none md:rounded-[40px] shadow-none md:shadow-[0_20px_60px_-15px_rgba(0,0,0,0.3)] md:border-[10px] md:border-neutral-800 overflow-hidden min-h-[840px]'
            : 'max-w-2xl mx-auto shadow-sm min-h-screen'
        }`}
      >
        {/* Android Notch / Dynamic Island Bar in phoneFrameMode */}
        {phoneFrameMode && (
          <div className="hidden md:flex justify-center items-center py-1.5 bg-neutral-900 text-neutral-400 select-none">
            <div className="w-20 h-4 bg-black rounded-full flex items-center justify-end px-2">
              <div className="w-2 h-2 rounded-full bg-neutral-800"></div>
            </div>
          </div>
        )}

        {/* Top App Bar */}
        <Header onOpenSettings={() => setIsSettingsOpen(true)} />

        {/* Primary Content Screen */}
        <main className="flex-1 p-3.5 sm:p-4 overflow-y-auto">
          {renderActiveScreen()}
        </main>

        {/* Bottom Material 3 Navigation Bar */}
        <BottomNav />

        {/* Settings Dialog */}
        <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />

        {/* Floating Toasts Notification Container */}
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center space-y-2 pointer-events-none px-4 w-full max-w-sm">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className="pointer-events-auto flex items-center space-x-2 px-3.5 py-2 rounded-2xl bg-neutral-900/90 dark:bg-white/95 text-white dark:text-neutral-900 text-xs font-semibold shadow-xl backdrop-blur-md animate-fade-in"
            >
              {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" />}
              {toast.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-400 dark:text-amber-600 shrink-0" />}
              {(!toast.type || toast.type === 'info') && <Info className="w-4 h-4 text-sky-400 dark:text-sky-600 shrink-0" />}
              <span>{toast.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
