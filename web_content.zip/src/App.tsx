import { useState } from "react";
import { AppProvider, useApp } from "@/lib/store";
import SensitivityPanel from "@/components/SensitivityPanel";
import TouchPanel from "@/components/TouchPanel";
import Arena from "@/components/Arena";
import ProfilesPanel from "@/components/ProfilesPanel";
import GuidePanel from "@/components/GuidePanel";
import { cn } from "@/utils/cn";

type TabId = "sens" | "controles" | "treino" | "perfis" | "guia";

const TABS: { id: TabId; label: string; short: string; icon: string }[] = [
  { id: "sens", label: "Sensibilidade", short: "Mira", icon: "🎯" },
  { id: "controles", label: "Controles", short: "Toque", icon: "🎮" },
  { id: "treino", label: "Treino", short: "Treino", icon: "🔥" },
  { id: "perfis", label: "Perfis", short: "Perfis", icon: "🗂️" },
  { id: "guia", label: "Guia", short: "Guia", icon: "📖" },
];

function SummaryBar() {
  const { settings, profiles } = useApp();
  const match = profiles.find((p) => !p.builtin && p.settings.sensHorizontal === settings.sensHorizontal && p.settings.sensVertical === settings.sensVertical);
  const chips = [
    { label: "H", value: `${settings.sensHorizontal}%`, tone: "text-lime-300" },
    { label: "V", value: `${settings.sensVertical}%`, tone: "text-cyan-300" },
    { label: "Ganho", value: `${settings.dragGain}%`, tone: "text-amber-300" },
    { label: "Suaviz.", value: `${settings.smoothing}%`, tone: "text-slate-200" },
    { label: "Curva", value: `${settings.curve.toFixed(2)}x`, tone: "text-rose-300" },
  ];
  return (
    <div className="mb-4 flex items-center gap-2 overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <span className="shrink-0 rounded-full bg-lime-400/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-lime-300">
        {match ? match.name : "Config atual"}
      </span>
      <div className="flex items-center gap-3">
        {chips.map((c) => (
          <span key={c.label} className="shrink-0 font-mono text-[11px]">
            <span className="text-slate-500">{c.label} </span>
            <span className={cn("font-semibold", c.tone)}>{c.value}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function Shell() {
  const [tab, setTab] = useState<TabId>("sens");

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* fundo decorativo */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 left-1/2 h-80 w-[36rem] -translate-x-1/2 rounded-full bg-lime-500/10 blur-[110px]" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-cyan-500/10 blur-[100px]" />
      </div>

      <div className="relative mx-auto w-full max-w-5xl px-3 pb-28 pt-4 sm:px-6 lg:pb-10">
        <header className="mb-4 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-lime-300 to-emerald-500 text-2xl shadow-lg shadow-lime-500/20">
            🐭
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-lg font-black tracking-tight text-white">
              GG Touch <span className="text-lime-300">Free Fire</span>
            </h1>
            <p className="text-[11px] text-slate-400">
              Sensibilidade horizontal/vertical, modificador de touch e treino de mira
            </p>
          </div>
        </header>

        {/* resumo rápido dos ajustes atuais */}
        <SummaryBar />

        {/* abas desktop */}
        <nav className="mb-4 hidden gap-1.5 rounded-2xl border border-white/10 bg-white/5 p-1.5 backdrop-blur lg:flex">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs font-bold transition",
                tab === t.id ? "bg-lime-400 text-slate-950" : "text-slate-300 hover:bg-white/10",
              )}
            >
              <span>{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>

        <main key={tab} className="animate-[fade_.25s_ease-out]">
          {tab === "sens" && <SensitivityPanel />}
          {tab === "controles" && <TouchPanel />}
          {tab === "treino" && <Arena />}
          {tab === "perfis" && <ProfilesPanel />}
          {tab === "guia" && <GuidePanel />}
        </main>
      </div>

      {/* navegação inferior (mobile) */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-slate-950/90 backdrop-blur-xl lg:hidden">
        <div className="mx-auto flex max-w-lg items-stretch justify-between px-1 pb-[max(6px,env(safe-area-inset-bottom))] pt-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-1 flex-col items-center gap-0.5 rounded-xl px-1 py-1.5 text-[10px] font-semibold transition",
                tab === t.id ? "text-lime-300" : "text-slate-500",
              )}
            >
              <span className={cn("text-lg leading-none transition", tab === t.id && "scale-110")}>
                {t.icon}
              </span>
              {t.short}
            </button>
          ))}
        </div>
      </nav>

      <style>{`@keyframes fade{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}`}</style>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
