import { useCallback, useEffect, useRef, useState } from 'react';
import { GameHud } from './components/GameHud';
import { GameOverModal } from './components/GameOverModal';
import { MobileControls } from './components/MobileControls';
import { PauseModal } from './components/PauseModal';
import { TitleOverlay } from './components/TitleOverlay';
import { RailwayGameEngine } from './game/engine';
import { soundEngine } from './game/sound';
import { Direction, HudSnapshot } from './game/types';

const INITIAL_HUD: HudSnapshot = {
  status: 'TITLE',
  score: 0,
  bestScore: 0,
  clovers: 0,
  streak: 0,
  elapsedSeconds: 0,
  isNewRecord: false,
  difficultyLevel: 1,
  mapTheme: 'RAILWAY',
  mapTimeRemaining: 15,
  deathReason: null,
};

const SWIPE_THRESHOLD_PX = 22;

export default function App() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<RailwayGameEngine | null>(null);

  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [isMuted, setIsMuted] = useState<boolean>(() => soundEngine.isMuted());

  const swipeRef = useRef<{
    active: boolean;
    pointerId: number | null;
    startX: number;
    startY: number;
    swiped: boolean;
  }>({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    swiped: false,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new RailwayGameEngine(canvas, (snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;
    engine.startLoop();

    const handleResize = () => engine.resize();
    window.addEventListener('resize', handleResize);

    const resizeObserver = new ResizeObserver(() => engine.resize());
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const handleVisibility = () => {
      if (document.hidden && engine.getStatus() === 'PLAYING') {
        engine.togglePause();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('visibilitychange', handleVisibility);
      resizeObserver.disconnect();
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const handleStart = useCallback(() => {
    engineRef.current?.startGame();
  }, []);

  const handleTogglePause = useCallback(() => {
    engineRef.current?.togglePause();
  }, []);

  const handleReturnToTitle = useCallback(() => {
    engineRef.current?.returnToTitle();
  }, []);

  const handleToggleMute = useCallback(() => {
    soundEngine.unlock();
    const muted = soundEngine.toggleMute();
    setIsMuted(muted);
  }, []);

  const handleMove = useCallback((dir: Direction) => {
    engineRef.current?.move(dir);
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const engine = engineRef.current;
      if (!engine) return;

      const status = engine.getStatus();
      const key = e.key;

      if (key === 'm' || key === 'M') {
        e.preventDefault();
        handleToggleMute();
        return;
      }

      if (key === 'Escape' || key === 'p' || key === 'P') {
        if (status === 'PLAYING' || status === 'PAUSED') {
          e.preventDefault();
          engine.togglePause();
        }
        return;
      }

      if (key === 'Enter' || key === ' ') {
        if (status === 'TITLE' || status === 'GAME_OVER') {
          e.preventDefault();
          engine.startGame();
          return;
        }
        if (status === 'PAUSED') {
          e.preventDefault();
          engine.togglePause();
          return;
        }
      }

      if (status !== 'PLAYING' || e.repeat) return;

      let dir: Direction | null = null;
      if (key === 'ArrowLeft' || key === 'a' || key === 'A') dir = 'LEFT';
      else if (key === 'ArrowRight' || key === 'd' || key === 'D') dir = 'RIGHT';
      else if (key === 'ArrowUp' || key === 'w' || key === 'W') dir = 'UP';
      else if (key === 'ArrowDown' || key === 's' || key === 'S') dir = 'DOWN';

      if (dir) {
        e.preventDefault();
        engine.move(dir);
      }
    };

    const onBlur = () => {
      swipeRef.current.active = false;
      swipeRef.current.pointerId = null;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('blur', onBlur);
    };
  }, [handleToggleMute]);

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (hud.status !== 'PLAYING') return;
    soundEngine.unlock();
    swipeRef.current = {
      active: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      swiped: false,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const state = swipeRef.current;
    if (!state.active || state.pointerId !== e.pointerId) return;
    if (hud.status !== 'PLAYING') return;

    const dx = e.clientX - state.startX;
    const dy = e.clientY - state.startY;

    if (Math.abs(dx) >= SWIPE_THRESHOLD_PX || Math.abs(dy) >= SWIPE_THRESHOLD_PX) {
      let dir: Direction;
      if (Math.abs(dx) > Math.abs(dy)) {
        dir = dx < 0 ? 'LEFT' : 'RIGHT';
      } else {
        dir = dy < 0 ? 'UP' : 'DOWN';
      }
      engineRef.current?.move(dir);
      // Reset origin so continuous rapid swipes work effortlessly without lifting finger
      state.startX = e.clientX;
      state.startY = e.clientY;
      state.swiped = true;
    }
  };

  const onPointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const state = swipeRef.current;
    if (!state.active || state.pointerId !== e.pointerId) return;

    if (!state.swiped && hud.status === 'PLAYING') {
      engineRef.current?.handleTapAtClientPos(e.clientX, e.clientY);
    }

    swipeRef.current.active = false;
    swipeRef.current.pointerId = null;
  };

  const onPointerCancel = () => {
    swipeRef.current.active = false;
    swipeRef.current.pointerId = null;
  };

  return (
    <main
      ref={containerRef}
      className="relative h-dvh w-screen overflow-hidden bg-[#162a1c] select-none"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerCancel}
        className="pixelated block h-full w-full touch-none"
        aria-label="BEN TÔ NA MƯ Japanese railway game playfield"
      />

      {hud.status === 'TITLE' && (
        <TitleOverlay
          bestScore={hud.bestScore}
          isMuted={isMuted}
          onStart={handleStart}
          onToggleMute={handleToggleMute}
        />
      )}

      {(hud.status === 'PLAYING' || hud.status === 'PAUSED') && (
        <GameHud
          hud={hud}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onPause={handleTogglePause}
        />
      )}

      {hud.status === 'PLAYING' && <MobileControls onMove={handleMove} />}

      {hud.status === 'PAUSED' && (
        <PauseModal
          onResume={handleTogglePause}
          onRestart={handleStart}
          onTitle={handleReturnToTitle}
        />
      )}

      {hud.status === 'GAME_OVER' && (
        <GameOverModal
          hud={hud}
          onRestart={handleStart}
          onTitle={handleReturnToTitle}
        />
      )}
    </main>
  );
}
