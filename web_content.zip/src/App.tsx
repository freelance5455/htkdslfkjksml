import { useEffect, useState } from "react";
import OceanBackground from "./components/OceanBackground";
import GameScreen from "./components/GameScreen";
import {
  HighScoresScreen,
  HomeScreen,
  LevelSelectScreen,
  ProgressScreen,
  ResetConfirmDialog,
  SettingsModal,
} from "./components/Screens";
import { LevelResult, SkinId, TOTAL_LEVELS } from "./game";
import {
  AudioSettings,
  emptyProgress,
  loadProgress,
  Progress,
  saveProgress,
} from "./storage";
import { audio } from "./audio";

type Screen = "home" | "levels" | "game" | "progress" | "scores";

export default function App() {
  const [progress, setProgress] = useState<Progress>(loadProgress);
  const [screen, setScreen] = useState<Screen>("home");
  const [activeLevel, setActiveLevel] = useState(() => Math.min(loadProgress().unlocked, TOTAL_LEVELS));
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [scoresReturn, setScoresReturn] = useState<"home" | "progress">("home");

  useEffect(() => saveProgress(progress), [progress]);

  useEffect(() => {
    audio.sync(progress.settings);
  }, [progress.settings]);

  useEffect(() => {
    // Mobile browsers require a real gesture before creating/resuming audio.
    const unlock = () => audio.unlock(progress.settings);
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, [progress.settings]);

  const startLevel = (level: number) => {
    const safeLevel = Math.max(1, Math.min(TOTAL_LEVELS, level));
    setActiveLevel(safeLevel);
    setScreen("game");
    audio.clink();
  };

  const updateSettings = (settings: AudioSettings) => {
    setProgress((current) => ({ ...current, settings }));
  };

  const toggleSound = () => {
    setProgress((current) => ({
      ...current,
      settings: { ...current.settings, sound: !current.settings.sound },
    }));
  };

  const completeLevel = (result: LevelResult) => {
    setProgress((current) => {
      const key = String(result.level);
      const previous = current.completed[key];
      const record = {
        stars: Math.max(previous?.stars ?? 0, result.stars),
        bestMoves: Math.min(previous?.bestMoves ?? Infinity, result.moves),
        bestScore: Math.max(previous?.bestScore ?? 0, result.score),
        bestTime: Math.min(previous?.bestTime ?? Infinity, result.seconds),
      };
      const streak = result.stars === 3 ? current.currentStreak + 1 : 0;
      const scoreEntry = { ...result, date: new Date().toISOString() };
      return {
        ...current,
        unlocked: Math.max(current.unlocked, Math.min(TOTAL_LEVELS, result.level + 1)),
        completed: { ...current.completed, [key]: record },
        currentStreak: streak,
        bestStreak: Math.max(current.bestStreak, streak),
        highScores: [...current.highScores, scoreEntry]
          .sort((a, b) => b.score - a.score || a.moves - b.moves)
          .slice(0, 10),
      };
    });
  };

  const selectSkin = (selectedSkin: SkinId) => {
    setProgress((current) => ({ ...current, selectedSkin }));
  };

  const resetProgress = () => {
    const fresh = emptyProgress();
    setProgress(fresh);
    setActiveLevel(1);
    setResetOpen(false);
    setSettingsOpen(false);
    setScreen("home");
  };

  return (
    <div className="app-shell">
      <OceanBackground />
      <div className="app-content">
        {screen === "home" && (
          <HomeScreen
            progress={progress}
            onPlay={() => startLevel(Math.min(progress.unlocked, TOTAL_LEVELS))}
            onLevels={() => setScreen("levels")}
            onProgress={() => setScreen("progress")}
            onScores={() => { setScoresReturn("home"); setScreen("scores"); }}
            onSettings={() => setSettingsOpen(true)}
            onToggleSound={toggleSound}
          />
        )}
        {screen === "levels" && (
          <LevelSelectScreen progress={progress} onBack={() => setScreen("home")} onPlay={startLevel} />
        )}
        {screen === "progress" && (
          <ProgressScreen
            progress={progress}
            onBack={() => setScreen("home")}
            onScores={() => { setScoresReturn("progress"); setScreen("scores"); }}
            onSelectSkin={selectSkin}
            onReset={() => setResetOpen(true)}
            onPlay={startLevel}
          />
        )}
        {screen === "scores" && (
          <HighScoresScreen progress={progress} onBack={() => setScreen(scoresReturn)} onPlay={startLevel} />
        )}
        {screen === "game" && (
          <GameScreen
            key={activeLevel}
            levelNumber={activeLevel}
            best={progress.completed[String(activeLevel)]}
            skin={progress.selectedSkin}
            soundOn={progress.settings.sound}
            onToggleSound={toggleSound}
            onOpenSettings={() => setSettingsOpen(true)}
            onExit={() => setScreen("levels")}
            onStartLevel={startLevel}
            onComplete={completeLevel}
            onMove={() => setProgress((current) => ({ ...current, totalMoves: current.totalMoves + 1 }))}
          />
        )}
      </div>
      {settingsOpen && <SettingsModal settings={progress.settings} onChange={updateSettings} onClose={() => setSettingsOpen(false)} />}
      {resetOpen && <ResetConfirmDialog onCancel={() => setResetOpen(false)} onConfirm={resetProgress} />}
    </div>
  );
}
