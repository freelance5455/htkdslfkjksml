/**
 * Main application coordinator for Subway Mom Runner 3D (هربان من ماما 3D).
 * Unites Three.js engine, touch swipes, Gamepad polling, sound system, and UI overlays.
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameState, GameMode, CharacterItem, HoverboardItem, BackpackItem, LevelConfig, ActivePowerups, DailyMission, Achievement } from './types/game';
import { ThreeEngine } from './game/threeEngine';
import { ALL_CHARACTERS, getCharacterById } from './game/characterData';
import { HOVERBOARDS, BACKPACKS } from './game/itemsData';
import { GAME_LEVELS } from './game/levelsData';
import { INITIAL_DAILY_MISSIONS, INITIAL_ACHIEVEMENTS } from './game/storeData';
import { soundSystem } from './game/soundSystem';
import { controlsManager } from './game/controls';
import { multiplayerManager } from './game/multiplayer';

import { TitleScreen } from './components/TitleScreen';
import { HUD } from './components/HUD';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';
import { PauseModal } from './components/PauseModal';
import { CharacterSelectModal } from './components/CharacterSelectModal';
import { ShopModal } from './components/ShopModal';
import { LevelsModal } from './components/LevelsModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { MultiplayerModal } from './components/MultiplayerModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<ThreeEngine | null>(null);

  // Game UI state
  const [gameState, setGameState] = useState<GameState>('TITLE');
  const [gameMode, setGameMode] = useState<GameMode>('ENDLESS');
  const [activeModal, setActiveModal] = useState<
    'characters' | 'shop' | 'levels' | 'leaderboard' | 'multiplayer' | 'settings' | null
  >(null);

  // Player progress & currencies (with localStorage sync)
  const [coins, setCoins] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('subway_mom_coins');
      return saved ? parseInt(saved, 10) : 2500;
    } catch {
      return 2500;
    }
  });

  const [gems, setGems] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('subway_mom_gems');
      return saved ? parseInt(saved, 10) : 30;
    } catch {
      return 30;
    }
  });

  const [highScore, setHighScore] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('subway_mom_highscore') || '0', 10);
    } catch {
      return 0;
    }
  });

  // Selected Equipment
  const [selectedCharacterId, setSelectedCharacterId] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('subway_mom_char_id') || '1', 10);
    } catch {
      return 1;
    }
  });

  const [selectedBoardId, setSelectedBoardId] = useState<string>(() => {
    try {
      return localStorage.getItem('subway_mom_board_id') || 'classic';
    } catch {
      return 'classic';
    }
  });

  const [selectedBackpackId, setSelectedBackpackId] = useState<string>(() => {
    try {
      return localStorage.getItem('subway_mom_bp_id') || 'school_bag';
    } catch {
      return 'school_bag';
    }
  });

  // Initial unlocked characters across all 4 categories (Boys, Girls, Superheroes, Monsters)
  const [unlockedCharacters, setUnlockedCharacters] = useState<number[]>(() => {
    try {
      const s = localStorage.getItem('subway_mom_unlocked_chars');
      return s ? JSON.parse(s) : [1, 2, 15, 16, 29, 42];
    } catch {
      return [1, 2, 15, 16, 29, 42];
    }
  });

  const [unlockedBoards, setUnlockedBoards] = useState<string[]>(() => {
    try {
      const s = localStorage.getItem('subway_mom_unlocked_boards');
      return s ? JSON.parse(s) : ['classic', 'hover_bike'];
    } catch {
      return ['classic', 'hover_bike'];
    }
  });

  const [unlockedBackpacks, setUnlockedBackpacks] = useState<string[]>(() => {
    try {
      const s = localStorage.getItem('subway_mom_unlocked_bps');
      return s ? JSON.parse(s) : ['school_bag'];
    } catch {
      return ['school_bag'];
    }
  });

  const [completedLevels, setCompletedLevels] = useState<number[]>(() => {
    try {
      const s = localStorage.getItem('subway_mom_completed_levels');
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  const [levelStars, setLevelStars] = useState<Record<number, number>>(() => {
    try {
      const s = localStorage.getItem('subway_mom_level_stars');
      return s ? JSON.parse(s) : { 1: 2 };
    } catch {
      return { 1: 2 };
    }
  });

  const [upgrades, setUpgrades] = useState<Record<string, number>>(() => {
    try {
      const s = localStorage.getItem('subway_mom_upgrades');
      return s ? JSON.parse(s) : { magnet_boost: 1, multiplier_boost: 1, sneakers_boost: 1, jetpack_boost: 1, mom_buffer: 1 };
    } catch {
      return { magnet_boost: 1, multiplier_boost: 1, sneakers_boost: 1, jetpack_boost: 1, mom_buffer: 1 };
    }
  });

  const [currentLevelId, setCurrentLevelId] = useState<number>(1);

  // Settings
  const [musicVolume, setMusicVolume] = useState(0.4);
  const [sfxVolume, setSfxVolume] = useState(0.6);
  const [showOnScreenButtons, setShowOnScreenButtons] = useState(false);
  const [gamepadVibration, setGamepadVibration] = useState(true);

  // Live in-game stats
  const [score, setScore] = useState(0);
  const [runCoins, setRunCoins] = useState(0);
  const [distance, setDistance] = useState(0);
  const [momDistanceRatio, setMomDistanceRatio] = useState(0.85);
  const [isNewHighScore, setIsNewHighScore] = useState(false);
  const [activePowerups, setActivePowerups] = useState<ActivePowerups>({
    magnet: 0,
    multiplier: 0,
    jetpack: 0,
    sneakers: 0,
    hoverboard: false
  });

  // Daily Quests and Achievements
  const [dailyMissions, setDailyMissions] = useState<DailyMission[]>(INITIAL_DAILY_MISSIONS);
  const [achievements, setAchievements] = useState<Achievement[]>(INITIAL_ACHIEVEMENTS);

  // Helpers to resolve items
  const activeChar = getCharacterById(selectedCharacterId);
  const activeBoard = HOVERBOARDS.find((b) => b.id === selectedBoardId) || HOVERBOARDS[0];
  const activeBackpack = BACKPACKS.find((bp) => bp.id === selectedBackpackId) || BACKPACKS[0];
  const activeLevel = GAME_LEVELS.find((l) => l.id === currentLevelId) || GAME_LEVELS[0];

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('subway_mom_coins', String(coins));
      localStorage.setItem('subway_mom_gems', String(gems));
      localStorage.setItem('subway_mom_highscore', String(highScore));
      localStorage.setItem('subway_mom_char_id', String(selectedCharacterId));
      localStorage.setItem('subway_mom_board_id', selectedBoardId);
      localStorage.setItem('subway_mom_bp_id', selectedBackpackId);
      localStorage.setItem('subway_mom_unlocked_chars', JSON.stringify(unlockedCharacters));
      localStorage.setItem('subway_mom_unlocked_boards', JSON.stringify(unlockedBoards));
      localStorage.setItem('subway_mom_unlocked_bps', JSON.stringify(unlockedBackpacks));
      localStorage.setItem('subway_mom_completed_levels', JSON.stringify(completedLevels));
      localStorage.setItem('subway_mom_level_stars', JSON.stringify(levelStars));
      localStorage.setItem('subway_mom_upgrades', JSON.stringify(upgrades));
    } catch {
      // Ignore
    }
  }, [
    coins,
    gems,
    highScore,
    selectedCharacterId,
    selectedBoardId,
    selectedBackpackId,
    unlockedCharacters,
    unlockedBoards,
    unlockedBackpacks,
    completedLevels,
    levelStars,
    upgrades
  ]);

  // Handle Game Over
  const handleEngineCrash = useCallback(
    (_obstacleType: string) => {
      setGameState('GAMEOVER');

      // Update total coins
      setCoins((prev) => prev + runCoins);

      // Check high score
      if (score > highScore) {
        setHighScore(score);
        setIsNewHighScore(true);
      } else {
        setIsNewHighScore(false);
      }

      // Update quests progress
      setDailyMissions((prev) =>
        prev.map((m) => {
          if (m.type === 'coins') return { ...m, current: m.current + runCoins, completed: m.current + runCoins >= m.target };
          if (m.type === 'distance') return { ...m, current: Math.max(m.current, distance), completed: Math.max(m.current, distance) >= m.target };
          return m;
        })
      );
    },
    [runCoins, score, highScore, distance]
  );

  // Handle Victory
  const handleEngineWinLevel = useCallback(() => {
    setGameState('VICTORY');
    setCoins((prev) => prev + runCoins + 100);
    setGems((prev) => prev + 5);

    if (!completedLevels.includes(currentLevelId)) {
      setCompletedLevels((prev) => [...prev, currentLevelId]);
    }
    setLevelStars((prev) => ({ ...prev, [currentLevelId]: 3 }));
  }, [runCoins, completedLevels, currentLevelId]);

  // Initialize Three.js Engine once on mount
  useEffect(() => {
    if (!mountRef.current) return;

    const engine = new ThreeEngine(
      mountRef.current,
      {
        onScoreUpdate: (s, c, d) => {
          setScore(s);
          setRunCoins(c);
          setDistance(d);
          if (engineRef.current) {
            setActivePowerups(engineRef.current.getActivePowerups());
          }
          // Multiplayer sync
          if (gameMode === 'MULTIPLAYER') {
            multiplayerManager.broadcastLocalState(d, s, 0, 0, selectedCharacterId, true);
          }
        },
        onPowerupCollect: () => {
          if (engineRef.current) {
            setActivePowerups(engineRef.current.getActivePowerups());
          }
        },
        onCrash: handleEngineCrash,
        onWinLevel: handleEngineWinLevel,
        onMomDistanceChange: (ratio) => setMomDistanceRatio(ratio)
      },
      activeChar,
      activeBoard,
      activeBackpack,
      activeLevel
    );

    engineRef.current = engine;

    // Multiplayer companion listener
    multiplayerManager.setOnPeerUpdate((peer) => {
      if (engineRef.current && peer.isAlive) {
        const laneX = [-2.6, 0, 2.6][peer.lane] || 0;
        engineRef.current.updatePeerPosition(laneX, peer.y, peer.distance - distance, true);
      }
    });

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Update engine config when character/gear/level changes
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.applyConfig(activeChar, activeBoard, activeBackpack, activeLevel);
    }
  }, [activeChar, activeBoard, activeBackpack, activeLevel]);

  // Gamepad Polling Loop during PLAYING state
  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    let animFrame = 0;
    const poll = () => {
      const actions = controlsManager.pollGamepad();
      actions.forEach((act) => {
        if (!engineRef.current) return;
        if (act === 'JUMP') engineRef.current.jump();
        if (act === 'ROLL') engineRef.current.slide();
        if (act === 'LEFT') engineRef.current.moveLeft();
        if (act === 'RIGHT') engineRef.current.moveRight();
        if (act === 'BOARD') engineRef.current.toggleHoverboard();
      });
      animFrame = requestAnimationFrame(poll);
    };

    animFrame = requestAnimationFrame(poll);
    return () => cancelAnimationFrame(animFrame);
  }, [gameState]);

  // Keyboard Event Handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in a modal search input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      const act = controlsManager.handleKeyDown(e.code);
      if (!act) return;

      if (act === 'PAUSE') {
        if (gameState === 'PLAYING') {
          handlePause();
        } else if (gameState === 'PAUSED') {
          handleResume();
        }
        return;
      }

      if (gameState === 'PLAYING' && engineRef.current) {
        if (act === 'JUMP') engineRef.current.jump();
        if (act === 'ROLL') engineRef.current.slide();
        if (act === 'LEFT') engineRef.current.moveLeft();
        if (act === 'RIGHT') engineRef.current.moveRight();
        if (act === 'BOARD') engineRef.current.toggleHoverboard();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  // Touch Gesture Listeners on container
  const handleTouchStart = (e: React.TouchEvent) => {
    if (gameState !== 'PLAYING') return;
    const act = controlsManager.handleTouchStart(e);
    if (act === 'BOARD' && engineRef.current) {
      engineRef.current.toggleHoverboard();
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (gameState !== 'PLAYING' || !engineRef.current) return;
    const act = controlsManager.handleTouchEnd(e);
    if (act === 'JUMP') engineRef.current.jump();
    if (act === 'ROLL') engineRef.current.slide();
    if (act === 'LEFT') engineRef.current.moveLeft();
    if (act === 'RIGHT') engineRef.current.moveRight();
    if (act === 'BOARD') engineRef.current.toggleHoverboard();
  };

  // Flow handlers
  const handleStartGame = () => {
    setScore(0);
    setRunCoins(0);
    setDistance(0);
    setIsNewHighScore(false);
    setGameState('PLAYING');
    if (engineRef.current) {
      engineRef.current.start(true); // Safe runway
    }
  };

  const handlePause = () => {
    setGameState('PAUSED');
    if (engineRef.current) engineRef.current.pause();
  };

  const handleResume = () => {
    setGameState('PLAYING');
    if (engineRef.current) engineRef.current.resume();
  };

  const handleRestart = () => {
    setScore(0);
    setRunCoins(0);
    setDistance(0);
    setIsNewHighScore(false);
    setGameState('PLAYING');
    if (engineRef.current) {
      engineRef.current.start(true); // Safe runway & invulnerability grace period
    }
  };

  const handleHome = () => {
    setGameState('TITLE');
    multiplayerManager.disconnect();
    soundSystem.stopMusic();
  };

  const handleNextLevel = () => {
    const nextId = currentLevelId + 1;
    if (nextId <= GAME_LEVELS.length) {
      setCurrentLevelId(nextId);
    }
    handleRestart();
  };

  // Store & Equipment actions
  const handleSelectCharacter = (char: CharacterItem) => {
    setSelectedCharacterId(char.id);
  };

  const handleUnlockCharacter = (char: CharacterItem): boolean => {
    if (char.costType === 'gems') {
      if (gems < char.cost) return false;
      setGems((g) => g - char.cost);
    } else {
      if (coins < char.cost) return false;
      setCoins((c) => c - char.cost);
    }
    setUnlockedCharacters((prev) => [...prev, char.id]);
    setSelectedCharacterId(char.id);
    return true;
  };

  const handleUpgradePowerup = (upgradeId: string, cost: number): boolean => {
    if (coins < cost) return false;
    setCoins((c) => c - cost);
    setUpgrades((prev) => ({
      ...prev,
      [upgradeId]: (prev[upgradeId] || 1) + 1
    }));
    return true;
  };

  const handleSelectBoard = (board: HoverboardItem) => {
    setSelectedBoardId(board.id);
  };

  const handleUnlockBoard = (board: HoverboardItem): boolean => {
    if (coins < board.cost) return false;
    setCoins((c) => c - board.cost);
    setUnlockedBoards((prev) => [...prev, board.id]);
    setSelectedBoardId(board.id);
    return true;
  };

  const handleSelectBackpack = (bp: BackpackItem) => {
    setSelectedBackpackId(bp.id);
  };

  const handleUnlockBackpack = (bp: BackpackItem): boolean => {
    if (coins < bp.cost) return false;
    setCoins((c) => c - bp.cost);
    setUnlockedBackpacks((prev) => [...prev, bp.id]);
    setSelectedBackpackId(bp.id);
    return true;
  };

  const handleSpinMysteryBox = () => {
    setCoins((c) => Math.max(0, c - 200));
    const wonCoins = 300 + Math.floor(Math.random() * 600);
    const wonGems = Math.random() < 0.35 ? 3 : 1;
    setCoins((c) => c + wonCoins);
    setGems((g) => g + wonGems);
    return { coins: wonCoins, gems: wonGems };
  };

  const handleClaimMissionReward = (missionId: string) => {
    setDailyMissions((prev) =>
      prev.map((m) => {
        if (m.id === missionId && !m.claimed) {
          setCoins((c) => c + m.rewardCoins);
          if (m.rewardGems > 0) setGems((g) => g + m.rewardGems);
          return { ...m, claimed: true };
        }
        return m;
      })
    );
  };

  const handleStartMultiplayerRace = (_roomCode: string, _mode: 'local_lan' | 'bluetooth' | 'online_room') => {
    setGameMode('MULTIPLAYER');
    handleStartGame();
  };

  return (
    <div
      className="relative w-full h-full overflow-hidden bg-slate-950 select-none touch-none"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Isolated Three.js Canvas Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full z-0 pointer-events-auto" />

      {/* Screen: Title Screen */}
      {gameState === 'TITLE' && !activeModal && (
        <TitleScreen
          onStartGame={handleStartGame}
          onOpenCharacters={() => setActiveModal('characters')}
          onOpenShop={() => setActiveModal('shop')}
          onOpenLevels={() => setActiveModal('levels')}
          onOpenMissions={() => setActiveModal('levels')}
          onOpenLeaderboard={() => setActiveModal('leaderboard')}
          onOpenMultiplayer={() => setActiveModal('multiplayer')}
          onOpenSettings={() => setActiveModal('settings')}
          coins={coins}
          gems={gems}
          highScore={highScore}
          selectedCharacter={activeChar}
          selectedBoard={activeBoard}
        />
      )}

      {/* Screen: HUD during active play */}
      {gameState === 'PLAYING' && (
        <HUD
          score={score}
          coins={runCoins}
          distance={distance}
          momDistanceRatio={momDistanceRatio}
          activePowerups={activePowerups}
          onPause={handlePause}
          onJump={() => engineRef.current?.jump()}
          onSlide={() => engineRef.current?.slide()}
          onLeft={() => engineRef.current?.moveLeft()}
          onRight={() => engineRef.current?.moveRight()}
          onToggleBoard={() => engineRef.current?.toggleHoverboard()}
          showOnScreenButtons={showOnScreenButtons}
        />
      )}

      {/* Screen: Pause Modal */}
      {gameState === 'PAUSED' && (
        <PauseModal
          onResume={handleResume}
          onRestart={handleRestart}
          onHome={handleHome}
          onOpenSettings={() => setActiveModal('settings')}
        />
      )}

      {/* Screen: Game Over Modal */}
      {gameState === 'GAMEOVER' && (
        <GameOverModal
          score={score}
          coins={runCoins}
          distance={distance}
          isNewHighScore={isNewHighScore}
          onRestart={handleRestart}
          onHome={handleHome}
          onOpenShop={() => setActiveModal('shop')}
        />
      )}

      {/* Screen: Victory Modal */}
      {gameState === 'VICTORY' && (
        <VictoryModal
          level={activeLevel}
          score={score}
          coinsEarned={runCoins}
          onNextLevel={handleNextLevel}
          onReplay={handleRestart}
          onHome={handleHome}
        />
      )}

      {/* Modals from Navigation */}
      {activeModal === 'characters' && (
        <CharacterSelectModal
          selectedCharacterId={selectedCharacterId}
          unlockedCharacters={unlockedCharacters}
          coins={coins}
          gems={gems}
          onSelectCharacter={handleSelectCharacter}
          onUnlockCharacter={handleUnlockCharacter}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'shop' && (
        <ShopModal
          coins={coins}
          gems={gems}
          upgrades={upgrades}
          selectedBoardId={selectedBoardId}
          selectedBackpackId={selectedBackpackId}
          unlockedBoards={unlockedBoards}
          unlockedBackpacks={unlockedBackpacks}
          onUpgradePowerup={handleUpgradePowerup}
          onSelectBoard={handleSelectBoard}
          onUnlockBoard={handleUnlockBoard}
          onSelectBackpack={handleSelectBackpack}
          onUnlockBackpack={handleUnlockBackpack}
          onSpinMysteryBox={handleSpinMysteryBox}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'levels' && (
        <LevelsModal
          currentLevel={currentLevelId}
          completedLevels={completedLevels}
          levelStars={levelStars}
          dailyMissions={dailyMissions}
          achievements={achievements}
          onSelectLevel={(lvl) => {
            setCurrentLevelId(lvl.id);
            handleStartGame();
          }}
          onClaimMissionReward={handleClaimMissionReward}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'leaderboard' && (
        <LeaderboardModal
          playerHighScore={highScore}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'multiplayer' && (
        <MultiplayerModal
          onStartMultiplayerRace={handleStartMultiplayerRace}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'settings' && (
        <SettingsModal
          musicVolume={musicVolume}
          sfxVolume={sfxVolume}
          showOnScreenButtons={showOnScreenButtons}
          gamepadVibration={gamepadVibration}
          onUpdateMusicVolume={setMusicVolume}
          onUpdateSfxVolume={setSfxVolume}
          onToggleOnScreenButtons={setShowOnScreenButtons}
          onToggleGamepadVibration={setGamepadVibration}
          onClose={() => setActiveModal(null)}
        />
      )}
    </div>
  );
}
