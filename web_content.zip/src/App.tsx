import React, { useState } from 'react';
import { SCRIPT_SCENES, ScriptScene } from './data/scriptData';
import { Header } from './components/Header';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { SceneDirector } from './components/SceneDirector';
import { TTSStudio } from './components/TTSStudio';
import { LyriaMusicStudio } from './components/LyriaMusicStudio';
import { Teleprompter } from './components/Teleprompter';
import { SkillCompass } from './components/SkillCompass';
import { ScriptEditor } from './components/ScriptEditor';

export default function App() {
  const [activeTab, setActiveTab] = useState<'director' | 'tts' | 'music' | 'prompter' | 'compass' | 'editor'>('director');
  const [scenes, setScenes] = useState<ScriptScene[]>(SCRIPT_SCENES);
  const [selectedSceneIndex, setSelectedSceneIndex] = useState<number>(0);
  const [ttsAudioUrl, setTtsAudioUrl] = useState<string | null>(null);
  const [musicAudioUrl, setMusicAudioUrl] = useState<string | null>(null);
  const [currentAudioTitle, setCurrentAudioTitle] = useState<string>('২০২৭ স্কিল ভয়েসওভার');
  const [isGeneratingTTS, setIsGeneratingTTS] = useState<boolean>(false);
  const [isGeneratingMusic, setIsGeneratingMusic] = useState<boolean>(false);

  // Direct TTS generator for a specific scene
  const handleGenerateTTSForScene = async (scene: ScriptScene) => {
    setIsGeneratingTTS(true);
    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: scene.textBn,
          voiceName: 'Puck',
          style: 'Inspiring Bengali tech presenter, engaging delivery',
          speaker: 'Presenter',
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || data.message || 'TTS generation failed');
      }

      const audioUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
      setTtsAudioUrl(audioUrl);
      setCurrentAudioTitle(`${scene.titleBn} (Gemini 3.8 TTS)`);
    } catch (err: any) {
      console.error('Error generating scene TTS:', err);
      alert(`TTS জেনারেশনে সমস্যা হয়েছে: ${err.message || 'Error'}`);
    } finally {
      setIsGeneratingTTS(false);
    }
  };

  const handleUpdateSceneText = (sceneId: string, newText: string) => {
    setScenes((prev) =>
      prev.map((s) => (s.id === sceneId ? { ...s, textBn: newText } : s))
    );
  };

  const handleResetOriginal = () => {
    setScenes(SCRIPT_SCENES);
  };

  const handleAudioGenerated = (audioUrl: string, title: string) => {
    setTtsAudioUrl(audioUrl);
    setCurrentAudioTitle(title);
  };

  const handleMusicGenerated = (audioUrl: string, title: string) => {
    setMusicAudioUrl(audioUrl);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isGeneratingAny={isGeneratingTTS || isGeneratingMusic}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'director' && (
          <SceneDirector
            scenes={scenes}
            selectedSceneIndex={selectedSceneIndex}
            setSelectedSceneIndex={setSelectedSceneIndex}
            onGenerateTTSForScene={handleGenerateTTSForScene}
            isGeneratingTTS={isGeneratingTTS}
            onNavigateToTeleprompter={() => setActiveTab('prompter')}
          />
        )}

        {activeTab === 'tts' && (
          <TTSStudio
            scenes={scenes}
            selectedSceneIndex={selectedSceneIndex}
            onAudioGenerated={handleAudioGenerated}
          />
        )}

        {activeTab === 'music' && (
          <LyriaMusicStudio
            onMusicGenerated={handleMusicGenerated}
          />
        )}

        {activeTab === 'prompter' && (
          <Teleprompter
            scenes={scenes}
            selectedSceneIndex={selectedSceneIndex}
            setSelectedSceneIndex={setSelectedSceneIndex}
          />
        )}

        {activeTab === 'compass' && (
          <SkillCompass />
        )}

        {activeTab === 'editor' && (
          <ScriptEditor
            scenes={scenes}
            onUpdateSceneText={handleUpdateSceneText}
            onResetOriginal={handleResetOriginal}
            onNavigateToTTS={() => setActiveTab('tts')}
          />
        )}
      </main>

      {/* Sticky Dual-Track Audio Player Bar */}
      <AudioPlayerBar
        ttsAudioUrl={ttsAudioUrl}
        musicAudioUrl={musicAudioUrl}
        currentSceneTitle={currentAudioTitle}
      />
    </div>
  );
}
