import React, { useState } from 'react';
import { 
  ScreenType, 
  AppViewMode, 
  Product, 
  CartItem, 
  Vendor 
} from './types/ecommerce';
import { TopSearchBar } from './components/TopSearchBar';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './components/HomeScreen';
import { CategoryScreen } from './components/CategoryScreen';
import { ProductDetailScreen } from './components/ProductDetailScreen';
import { CartScreen } from './components/CartScreen';
import { CheckoutScreen } from './components/CheckoutScreen';
import { OrderSuccessScreen } from './components/OrderSuccessScreen';
import { AccountScreen } from './components/AccountScreen';
import { OrdersHistoryScreen } from './components/OrdersHistoryScreen';
import { VendorStoreScreen } from './components/VendorStoreScreen';
import { SellerChatDrawer } from './components/SellerChatDrawer';
import { MobileFrame } from './components/MobileFrame';
import { WhatsAppOrderModal } from './components/WhatsAppOrderModal';
import { ArchitectureSpecView } from './components/ArchitectureSpecView';
import { DesignSystemView } from './components/DesignSystemView';
import { AiPromptsView } from './components/AiPromptsView';
import { ExportApkView } from './components/ExportApkView';
import { SAMPLE_PRODUCTS, VENDORS, DEFAULT_ADDRESSES, INITIAL_ORDERS, WHATSAPP_DISPLAY_NUMBER } from './data/mockData';
import { OrderRecord } from './types/ecommerce';
import { 
  Smartphone, 
  Maximize2, 
  Compass, 
  Palette, 
  Sparkles,
  ShoppingBag,
  Download,
  PackageCheck,
  MessageCircle
} from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<AppViewMode>('mobile_preview');
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState<Product>(SAMPLE_PRODUCTS[0]);
  const [selectedVendorId, setSelectedVendorId] = useState<string>('v1');
  const [activeChatVendor, setActiveChatVendor] = useState<Vendor | null>(null);

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 'cart-1',
      product: SAMPLE_PRODUCTS[0],
      selectedColor: 'Electric Blaze',
      selectedSize: '42',
      quantity: 1,
      selected: true
    },
    {
      id: 'cart-2',
      product: SAMPLE_PRODUCTS[1],
      selectedColor: 'Space Gray',
      selectedSize: '45mm',
      quantity: 1,
      selected: true
    }
  ]);

  const [appliedCoupon, setAppliedCoupon] = useState<string | null>('SEWORA50');
  const [discountAmount, setDiscountAmount] = useState<number>(1770);
  const [lastOrder, setLastOrder] = useState<any>(null);
  const [orders, setOrders] = useState<OrderRecord[]>(INITIAL_ORDERS);

  // WhatsApp Order & Support modal state
  const [whatsAppModalOpen, setWhatsAppModalOpen] = useState(false);
  const [whatsAppProduct, setWhatsAppProduct] = useState<Product | null>(null);
  const [whatsAppVariant, setWhatsAppVariant] = useState({ color: '', size: '', quantity: 1 });

  const handleOpenWhatsAppOrder = (
    product?: Product | null, 
    color?: string, 
    size?: string, 
    quantity?: number
  ) => {
    if (product) {
      setWhatsAppProduct(product);
      setWhatsAppVariant({
        color: color || product.colors[0]?.name || '',
        size: size || product.sizes[0] || '',
        quantity: quantity || 1
      });
    } else {
      setWhatsAppProduct(null);
    }
    setWhatsAppModalOpen(true);
  };

  const handleReorder = (items: CartItem[]) => {
    setCartItems((prev) => [
      ...items.map((it) => ({ ...it, id: 'reorder-' + Date.now() + Math.random(), selected: true })),
      ...prev
    ]);
    setCurrentScreen('cart');
  };

  const handleOpenWhatsAppHelp = (orderNumber: string) => {
    setWhatsAppProduct(null);
    setWhatsAppModalOpen(true);
  };

  // Cart actions
  const handleAddToCart = (product: Product, color: string, size: string, quantity: number) => {
    setCartItems((prev) => {
      const existing = prev.find(
        (i) => i.product.id === product.id && i.selectedColor === color && i.selectedSize === size
      );
      if (existing) {
        return prev.map((i) =>
          i.id === existing.id ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [
        ...prev,
        {
          id: 'cart-' + Date.now(),
          product,
          selectedColor: color,
          selectedSize: size,
          quantity,
          selected: true
        }
      ];
    });
  };

  const handleBuyNow = (product: Product, color: string, size: string, quantity: number) => {
    handleAddToCart(product, color, size, quantity);
    setCurrentScreen('checkout');
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((i) => i.id !== id));
  };

  const handleToggleSelect = (id: string) => {
    setCartItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, selected: !i.selected } : i))
    );
  };

  const handleSelectAll = (selected: boolean) => {
    setCartItems((prev) => prev.map((i) => ({ ...i, selected })));
  };

  const handleApplyCoupon = (code: string): boolean => {
    if (code === 'SEWORA50') {
      setAppliedCoupon('SEWORA50 (15% OFF)');
      const selectedSubtotal = cartItems
        .filter((i) => i.selected)
        .reduce((sum, it) => sum + it.product.price * it.quantity, 0);
      setDiscountAmount(Math.round(selectedSubtotal * 0.15));
      return true;
    } else if (code === 'FREESHIP') {
      setAppliedCoupon('FREESHIP (Delivery Waived)');
      setDiscountAmount(350);
      return true;
    }
    return false;
  };

  const handleOrderSuccess = (orderData: any) => {
    setLastOrder(orderData);
    const newRecord: OrderRecord = {
      id: 'ord-' + Date.now(),
      orderNumber: orderData.orderNumber,
      date: 'Today, ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Processing',
      trackingNumber: orderData.trackingNumber,
      totalAmount: orderData.totalAmount,
      paymentMethod: orderData.paymentMethod,
      address: orderData.address,
      items: [...cartItems.filter((i) => i.selected)]
    };
    setOrders((prev) => [newRecord, ...prev]);
    setCartItems((prev) => prev.filter((i) => !i.selected));
    setCurrentScreen('order_success');
  };

  // Navigation helpers
  const navigateToProduct = (product: Product) => {
    setSelectedProduct(product);
    setCurrentScreen('pdp');
  };

  const navigateToCategory = (catId: string) => {
    setSelectedCategory(catId);
    setCurrentScreen('categories');
  };

  const navigateToStore = (vendorId: string) => {
    setSelectedVendorId(vendorId);
    setCurrentScreen('vendor');
  };

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Render current mobile screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <>
            <TopSearchBar
              onSearch={(q) => {
                setSearchQuery(q);
                if (q) setCurrentScreen('categories');
              }}
              searchQuery={searchQuery}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
            <HomeScreen
              products={SAMPLE_PRODUCTS}
              onSelectProduct={navigateToProduct}
              onNavigateToCategory={navigateToCategory}
              onOpenWhatsAppOrder={() => handleOpenWhatsAppOrder(null)}
            />
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
          </>
        );

      case 'categories':
        return (
          <>
            <TopSearchBar
              onSearch={setSearchQuery}
              searchQuery={searchQuery}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
            <CategoryScreen
              products={SAMPLE_PRODUCTS}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              onSelectProduct={navigateToProduct}
              searchQuery={searchQuery}
            />
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
          </>
        );

      case 'pdp':
        return (
          <ProductDetailScreen
            product={selectedProduct}
            onBack={() => setCurrentScreen('home')}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
            onOpenChat={(vendor) => setActiveChatVendor(vendor)}
            onOpenStore={navigateToStore}
            onOpenWhatsAppOrder={(p, c, s, q) => handleOpenWhatsAppOrder(p, c, s, q)}
          />
        );

      case 'cart':
        return (
          <>
            <CartScreen
              cartItems={cartItems}
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onToggleSelect={handleToggleSelect}
              onSelectAll={handleSelectAll}
              onProceedToCheckout={() => setCurrentScreen('checkout')}
              onContinueShopping={() => setCurrentScreen('home')}
              appliedCoupon={appliedCoupon}
              discountAmount={discountAmount}
              onApplyCoupon={handleApplyCoupon}
              onOpenWhatsAppOrder={() => handleOpenWhatsAppOrder(null)}
            />
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
          </>
        );

      case 'checkout': {
        const selected = cartItems.filter((i) => i.selected);
        const subtotal = selected.reduce((s, it) => s + it.product.price * it.quantity, 0);
        return (
          <CheckoutScreen
            items={selected.length > 0 ? selected : cartItems}
            subtotal={subtotal}
            shippingFee={350}
            discountAmount={discountAmount}
            onBack={() => setCurrentScreen('cart')}
            onOrderSuccess={handleOrderSuccess}
          />
        );
      }

      case 'order_success':
        return (
          <OrderSuccessScreen
            orderData={
              lastOrder || {
                orderNumber: 'SEW-849201',
                items: cartItems,
                totalAmount: 11450,
                paymentMethod: 'Cash on Delivery',
                address: DEFAULT_ADDRESSES[0],
                trackingNumber: 'LK-EXP-7749281',
                date: 'Oct 31, 2026'
              }
            }
            onContinueShopping={() => setCurrentScreen('home')}
            onViewAccountOrders={() => setCurrentScreen('orders')}
          />
        );

      case 'account':
        return (
          <>
            <AccountScreen
              orders={orders}
              onOpenOrders={() => setCurrentScreen('orders')}
              onOpenWishlist={() => {
                setSelectedCategory('all');
                setCurrentScreen('categories');
              }}
              onOpenVouchers={() => setCurrentScreen('cart')}
              onOpenExport={() => setViewMode('export_apk')}
              onOpenWhatsAppSupport={() => handleOpenWhatsAppOrder(null)}
            />
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
          </>
        );

      case 'orders':
        return (
          <>
            <OrdersHistoryScreen
              orders={orders}
              onBack={() => setCurrentScreen('account')}
              onReorder={handleReorder}
              onOpenWhatsAppHelp={handleOpenWhatsAppHelp}
              onContinueShopping={() => setCurrentScreen('home')}
            />
            <BottomNav
              currentScreen={currentScreen}
              onNavigate={setCurrentScreen}
              cartCount={totalCartCount}
            />
          </>
        );

      case 'vendor':
        return (
          <VendorStoreScreen
            vendorId={selectedVendorId}
            products={SAMPLE_PRODUCTS}
            onBack={() => setCurrentScreen('home')}
            onSelectProduct={navigateToProduct}
            onOpenChat={(vendor) => setActiveChatVendor(vendor)}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900">
      {/* Top Application Workspace Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 px-4 py-2.5 shadow-2xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand & Project Badge */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 font-black text-lg tracking-tight text-slate-900">
              <span className="bg-[#FF6600] text-white px-2 py-0.5 rounded text-xs font-black shadow-xs">SE</span>
              <span className="tracking-tight text-slate-900">SEWORA</span>
              <span className="text-[10px] bg-slate-900 text-yellow-300 font-black px-1.5 py-0.5 rounded ml-0.5 tracking-wider">MART</span>
            </div>
            <span className="hidden sm:inline-block text-xs font-medium text-slate-400">·</span>
            <span className="hidden sm:inline-block text-xs font-semibold text-slate-600">
              Modern Online Shopping & WhatsApp Order Platform
            </span>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto text-xs font-semibold">
            <button
              onClick={() => handleOpenWhatsAppOrder(null)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#25D366] hover:bg-emerald-600 text-white shadow-2xs font-bold transition-all cursor-pointer"
              title="Chat on WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white" />
              <span>WhatsApp</span>
            </button>
            <button
              onClick={() => setViewMode('mobile_preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'mobile_preview'
                  ? 'bg-white text-[#FF6600] shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile Phone</span>
            </button>

            <button
              onClick={() => setViewMode('responsive')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'responsive'
                  ? 'bg-white text-[#FF6600] shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Expanded</span>
            </button>

            <button
              onClick={() => setViewMode('specs_ia')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'specs_ia'
                  ? 'bg-white text-[#FF6600] shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>IA & Screen Flows</span>
            </button>

            <button
              onClick={() => setViewMode('design_system')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'design_system'
                  ? 'bg-white text-[#FF6600] shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Design System</span>
            </button>

            <button
              onClick={() => setViewMode('ai_prompts')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'ai_prompts'
                  ? 'bg-white text-[#FF6600] shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Prompts</span>
            </button>

            <button
              onClick={() => setViewMode('export_apk')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'export_apk'
                  ? 'bg-[#FF6600] text-white shadow-xs font-bold'
                  : 'text-slate-700 hover:text-[#FF6600] font-bold'
              }`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export APK (.ZIP)</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Viewport Content */}
      <main className="flex-1">
        {viewMode === 'mobile_preview' && (
          <MobileFrame isFramed={true}>
            {renderScreen()}
          </MobileFrame>
        )}

        {viewMode === 'responsive' && (
          <div className="py-4 px-2">
            <MobileFrame isFramed={false}>
              {renderScreen()}
            </MobileFrame>
          </div>
        )}

        {viewMode === 'specs_ia' && (
          <div className="py-6">
            <ArchitectureSpecView />
          </div>
        )}

        {viewMode === 'design_system' && (
          <div className="py-6">
            <DesignSystemView />
          </div>
        )}

        {viewMode === 'ai_prompts' && (
          <div className="py-6">
            <AiPromptsView />
          </div>
        )}

        {viewMode === 'export_apk' && (
          <div className="py-6">
            <ExportApkView />
          </div>
        )}
      </main>

      {/* Floating WhatsApp Quick Action Button */}
      <button
        onClick={() => handleOpenWhatsAppOrder(null)}
        className="fixed bottom-20 right-4 z-40 bg-[#25D366] hover:bg-emerald-600 text-white p-3 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center border-2 border-white group cursor-pointer"
        title="Chat with SEWORA MART on WhatsApp"
        aria-label="WhatsApp Order Support"
      >
        <MessageCircle className="w-6 h-6 fill-white" />
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-yellow-300 rounded-full border-2 border-white animate-pulse"></span>
        <span className="hidden md:group-hover:block absolute right-14 bg-slate-900 text-white text-xs font-bold px-2.5 py-1 rounded-lg shadow-md whitespace-nowrap">
          WhatsApp Order & Support
        </span>
      </button>

      {/* Simulated Live Seller Chat Modal */}
      {activeChatVendor && (
        <SellerChatDrawer
          vendor={activeChatVendor}
          isOpen={true}
          onClose={() => setActiveChatVendor(null)}
        />
      )}

      {/* WhatsApp Direct Order & Customer Care Modal */}
      <WhatsAppOrderModal
        isOpen={whatsAppModalOpen}
        onClose={() => setWhatsAppModalOpen(false)}
        product={whatsAppProduct}
        selectedColor={whatsAppVariant.color}
        selectedSize={whatsAppVariant.size}
        quantity={whatsAppVariant.quantity}
        cartItems={cartItems}
      />
    </div>
  );
}
