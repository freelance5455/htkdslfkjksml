import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { UserDataProvider } from './context/UserDataContext';
import { Navbar } from './components/Navbar';
import { SarfView } from './components/SarfView';
import { NahwView } from './components/NahwView';
import { ConjugatorView } from './components/ConjugatorView';
import { SentenceAnalyzerView } from './components/SentenceAnalyzerView';
import { QuizView } from './components/QuizView';
import { UserDashboardView } from './components/UserDashboardView';
import {
  Layers,
  Network,
  RotateCcw,
  BookOpen,
  Sparkles,
  BookmarkCheck,
  Heart
} from 'lucide-react';

const MainContent: React.FC = () => {
  const { language, isRtl } = useLanguage();
  const [activeTab, setActiveTab] = useState<string>('sarf');
  const [selectedRuleId, setSelectedRuleId] = useState<string | null>(null);

  const handleSelectRuleFromDashboard = (ruleId: string, category: 'sarf' | 'nahw') => {
    setSelectedRuleId(ruleId);
    setActiveTab(category);
  };

  return (
    <div className={`min-h-screen flex flex-col bg-stone-100/70 text-stone-900 ${isRtl ? 'dir-rtl' : 'dir-ltr'}`}>
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'sarf' && <SarfView initialRuleId={selectedRuleId} />}
        {activeTab === 'nahw' && <NahwView initialRuleId={selectedRuleId} />}
        {activeTab === 'conjugator' && <ConjugatorView />}
        {activeTab === 'analyzer' && <SentenceAnalyzerView />}
        {activeTab === 'quiz' && <QuizView />}
        {activeTab === 'dashboard' && (
          <UserDashboardView onSelectRule={handleSelectRuleFromDashboard} />
        )}
      </main>

      {/* Classical Scholarly Footer */}
      <footer className="bg-stone-900 text-stone-400 border-t border-stone-800 py-10 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="flex items-center justify-center gap-2 text-amber-300 font-arabic text-xl font-bold">
            <span>الصَّرْفُ أُمُّ الْعُلُومِ وَالنَّحْوُ أَبُوهَا</span>
          </div>

          <p className="text-xs sm:text-sm text-stone-300 max-w-2xl mx-auto leading-relaxed">
            {language === 'pashto'
              ? 'د قرآن مجید او سنتو د ژبې د زده کړې لپاره جامع پوهنځی، چې د صرف او نحو ټول قوانین په پښتو، اردو او انګلیسي ژبو په بشپړه توګه وړاندې کوي.'
              : language === 'urdu'
              ? 'قرآن مجید اور احادیثِ نبویہ کی تفہیم کے لیے علم الصرف اور علم النحو کی کامل اور جامع اکیڈمی، پشتو، اردو اور انگریزی تشریحات کے ساتھ۔'
              : 'A comprehensive educational academy for mastering Arabic Morphology (Ilm-e-Sarf) and Syntax (Ilm-e-Nahw) with in-depth expositions in Pashto, Urdu, and English.'}
          </p>

          <div className="flex justify-center flex-wrap gap-6 text-xs text-stone-400 pt-2 border-t border-stone-800/80">
            <button onClick={() => setActiveTab('sarf')} className="hover:text-amber-300 transition-colors">
              {language === 'pashto' ? 'علم الصرف' : language === 'urdu' ? 'علم الصرف' : 'Ilm-e-Sarf'}
            </button>
            <button onClick={() => setActiveTab('nahw')} className="hover:text-amber-300 transition-colors">
              {language === 'pashto' ? 'علم النحو' : language === 'urdu' ? 'علم النحو' : 'Ilm-e-Nahw'}
            </button>
            <button onClick={() => setActiveTab('conjugator')} className="hover:text-amber-300 transition-colors">
              {language === 'pashto' ? 'د افعالو گردان' : language === 'urdu' ? 'گردان و تصریف' : 'Conjugator'}
            </button>
            <button onClick={() => setActiveTab('analyzer')} className="hover:text-amber-300 transition-colors">
              {language === 'pashto' ? 'د جملو ترکیب' : language === 'urdu' ? 'ترکیبِ نحوی' : 'I\'rab Analyzer'}
            </button>
            <button onClick={() => setActiveTab('quiz')} className="hover:text-amber-300 transition-colors">
              {language === 'pashto' ? 'ازموینه' : language === 'urdu' ? 'آزمائش' : 'Quiz'}
            </button>
          </div>

          <div className="text-[11px] text-stone-500 pt-2">
            © {new Date().getFullYear()} مِرْآةُ الصَّرْفِ وَالنَّحْوِ • Ilm-e-Sarf & Nahw Academy • د صرف او نحو لارښود
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <UserDataProvider>
          <MainContent />
        </UserDataProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
