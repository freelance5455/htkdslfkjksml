import { useCallback, useEffect, useRef, useState } from 'react';
import { RallyEngine, type HudData } from './game/engine';
import { InputManager } from './game/input';
import type { Quality } from './game/world';

type Screen = 'menu' | 'loading' | 'game';

const CAR_COLORS = [
  { name: 'قرمز رالی', value: '#d21f2b' },
  { name: 'آبی', value: '#1f5fd2' },
  { name: 'نارنجی', value: '#e8721f' },
  { name: 'سبز', value: '#0f9a6c' },
  { name: 'بنفش', value: '#7a1fd2' },
  { name: 'زرد', value: '#d8a722' },
  { name: 'مشکی', value: '#16181d' },
  { name: 'سفید', value: '#e8ecf2' },
];

const QUALITIES: { id: Quality; name: string; desc: string }[] = [
  { id: 'low', name: 'سبک', desc: 'موبایل‌های ضعیف' },
  { id: 'medium', name: 'متوسط', desc: 'پیشنهادی' },
  { id: 'high', name: 'سینمایی', desc: 'گرافیک حداکثر' },
];

function TouchButton({
  label,
  sub,
  onChange,
  className = '',
  color = 'bg-white/10',
}: {
  label: string;
  sub?: string;
  onChange: (pressed: boolean) => void;
  className?: string;
  color?: string;
}) {
  const [active, setActive] = useState(false);
  const set = (v: boolean) => {
    setActive(v);
    onChange(v);
  };
  return (
    <button
      className={`touch-btn ${active ? 'active ' : ''}${color} flex flex-col items-center justify-center rounded-2xl border border-white/25 font-bold text-white shadow-xl ${className}`}
      style={{ boxShadow: active ? '0 0 24px rgba(56,189,248,0.5), inset 0 0 12px rgba(0,0,0,0.4)' : undefined, background: active ? 'rgba(56,189,248,0.35)' : undefined }}
      onPointerDown={(e) => {
        e.preventDefault();
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        set(true);
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        set(false);
      }}
      onPointerCancel={() => set(false)}
      onLostPointerCapture={() => set(false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      <span className="text-2xl leading-none sm:text-3xl">{label}</span>
      {sub && <span className="mt-1 text-[10px] font-medium opacity-80">{sub}</span>}
    </button>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [quality, setQuality] = useState<Quality>('medium');
  const [carColor, setCarColor] = useState('#d21f2b');
  const [progress, setProgress] = useState(0);
  const [progressLabel, setProgressLabel] = useState('');
  const [hud, setHud] = useState<HudData>({ speedKmh: 0, region: 'شهر', surface: 'asphalt', drifting: false });
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [gamepad, setGamepad] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [regionFlash, setRegionFlash] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<RallyEngine | null>(null);
  const inputRef = useRef<InputManager | null>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const staticMapRef = useRef<HTMLCanvasElement | null>(null);
  const prevRegion = useRef('');

  const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

  // gamepad polling for menu indicator
  useEffect(() => {
    const t = setInterval(() => {
      try {
        const pads = navigator.getGamepads ? navigator.getGamepads() : [];
        let found = false;
        for (const p of pads) if (p && p.connected) found = true;
        setGamepad(found);
      } catch {
        /* ignore */
      }
    }, 1500);
    return () => clearInterval(t);
  }, []);

  // region flash
  useEffect(() => {
    if (screen === 'game' && hud.region !== prevRegion.current) {
      prevRegion.current = hud.region;
      setRegionFlash(hud.region);
      const t = setTimeout(() => setRegionFlash(null), 1800);
      return () => clearTimeout(t);
    }
  }, [hud.region, screen]);

  const startGame = useCallback(async () => {
    setLoadError(null);
    setScreen('loading');
    setProgress(0);
    // let UI paint
    await new Promise((r) => setTimeout(r, 60));
    try {
      const input = new InputManager();
      input.attach();
      inputRef.current = input;
      const engine = new RallyEngine({
        quality,
        carColor,
        input,
        onHUD: (h) => setHud(h),
        onProgress: (p, label) => {
          setProgress(p);
          setProgressLabel(label);
        },
      });
      engineRef.current = engine;
      if (!containerRef.current) throw new Error('container missing');
      containerRef.current.innerHTML = '';
      await engine.init(containerRef.current);
      engine.start();
      setScreen('game');
      setPaused(false);
    } catch (e) {
      console.error(e);
      setLoadError('خطا در بارگذاری بازی. لطفاً کیفیت «سبک» را انتخاب کنید و دوباره تلاش کنید.');
      setScreen('menu');
      try {
        engineRef.current?.dispose();
      } catch {
        /* ignore */
      }
      engineRef.current = null;
      inputRef.current?.detach();
      inputRef.current = null;
    }
  }, [quality, carColor]);

  const quitToMenu = useCallback(() => {
    try {
      engineRef.current?.dispose();
    } catch {
      /* ignore */
    }
    engineRef.current = null;
    inputRef.current?.detach();
    inputRef.current = null;
    setScreen('menu');
    setPaused(false);
  }, []);

  // cleanup on unmount
  useEffect(() => {
    return () => {
      try {
        engineRef.current?.dispose();
      } catch {
        /* ignore */
      }
      inputRef.current?.detach();
    };
  }, []);

  // pause with Esc/P
  useEffect(() => {
    if (screen !== 'game') return;
    const fn = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key.toLowerCase() === 'p') {
        setPaused((p) => {
          const np = !p;
          if (np) engineRef.current?.pause();
          else engineRef.current?.resume();
          return np;
        });
      }
      if (e.key.toLowerCase() === 'c') engineRef.current?.toggleCamera();
      if (e.key.toLowerCase() === 'r') engineRef.current?.recover();
    };
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [screen]);

  // ---------- minimap ----------
  useEffect(() => {
    if (screen !== 'game') return;
    // build static map once
    const S = 220;
    const off = document.createElement('canvas');
    off.width = S;
    off.height = S;
    const ctx = off.getContext('2d')!;
    const mx = (x: number) => ((x + 1200) / 2400) * S;
    const mz = (z: number) => ((z + 1200) / 2400) * S;
    // bg grass
    ctx.fillStyle = '#4a7a38';
    ctx.fillRect(0, 0, S, S);
    // forests
    ctx.fillStyle = '#2c5a26';
    ctx.fillRect(mx(430), mz(-990), mx(1010) - mx(430), mz(-240) - mz(-990));
    ctx.fillRect(mx(-1010), mz(-990), mx(-450) - mx(-1010), mz(-80) - mz(-990));
    // city
    ctx.fillStyle = '#8d939c';
    ctx.fillRect(mx(-420), mz(-520), mx(420) - mx(-420), mz(220) - mz(-520));
    // city roads
    ctx.strokeStyle = '#3a3f47';
    ctx.lineWidth = 1;
    for (let x = -400; x <= 400; x += 100) {
      ctx.beginPath();
      ctx.moveTo(mx(x), mz(-520));
      ctx.lineTo(mx(x), mz(220));
      ctx.stroke();
    }
    for (let z = -500; z <= 200; z += 100) {
      ctx.beginPath();
      ctx.moveTo(mx(-420), mz(z));
      ctx.lineTo(mx(420), mz(z));
      ctx.stroke();
    }
    // village
    ctx.fillStyle = '#7fa050';
    ctx.fillRect(mx(450), mz(-210), mx(810) - mx(450), mz(250) - mz(-210));
    // beach + sea
    ctx.fillStyle = '#dec08a';
    ctx.fillRect(0, mz(440), S, mz(630) - mz(440));
    ctx.fillStyle = '#1e6fa8';
    ctx.fillRect(0, mz(630), S, S - mz(630));
    // coastal highway
    ctx.strokeStyle = '#22262c';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(mx(-1050), mz(380));
    ctx.lineTo(mx(1050), mz(380));
    ctx.stroke();
    // ring
    ctx.strokeStyle = '#3a3f47';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(mx(-460), mz(-560), mx(460) - mx(-460), mz(280) - mz(-560));
    // mountains border
    ctx.fillStyle = 'rgba(120,115,108,0.9)';
    ctx.fillRect(0, 0, S, 8);
    ctx.fillRect(0, 0, 8, S);
    ctx.fillRect(S - 8, 0, 8, S);
    staticMapRef.current = off;

    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const cv = minimapRef.current;
      const eng = engineRef.current;
      const st = staticMapRef.current;
      if (!cv || !eng || !st) return;
      const c = cv.getContext('2d');
      if (!c) return;
      const W = cv.width;
      const H = cv.height;
      c.clearRect(0, 0, W, H);
      c.save();
      c.beginPath();
      c.arc(W / 2, H / 2, W / 2 - 2, 0, Math.PI * 2);
      c.clip();
      // zoomed view centered on player
      const zoom = 2.6;
      const px = ((eng.pos.x + 1200) / 2400) * S;
      const pz = ((eng.pos.z + 1200) / 2400) * S;
      const dw = S / zoom;
      c.imageSmoothingEnabled = true;
      c.drawImage(st, px - dw / 2, pz - dw / 2, dw, dw, 0, 0, W, H);
      // traffic dots
      c.fillStyle = '#ffd21f';
      for (const t of eng.getTrafficPositions()) {
        const tx = ((t.x + 1200) / 2400) * S;
        const tz = ((t.z + 1200) / 2400) * S;
        const sx = ((tx - (px - dw / 2)) / dw) * W;
        const sy = ((tz - (pz - dw / 2)) / dw) * H;
        if (sx < 0 || sx > W || sy < 0 || sy > H) continue;
        c.beginPath();
        c.arc(sx, sy, 3, 0, Math.PI * 2);
        c.fill();
      }
      // player arrow
      c.translate(W / 2, H / 2);
      // heading 0 = north (-z) = up on map. Map: x right, z down. Forward = (-sin h, -cos h) in xz => map dx=-sin h, dy=-cos h. Angle from up: atan2(dx, -dy)= atan2(-sin h, cos h) = -h. So rotate by -h.
      c.rotate(-eng.heading);
      c.fillStyle = '#ff2a3a';
      c.strokeStyle = '#fff';
      c.lineWidth = 1.5;
      c.beginPath();
      c.moveTo(0, -8);
      c.lineTo(5.5, 6);
      c.lineTo(0, 3);
      c.lineTo(-5.5, 6);
      c.closePath();
      c.fill();
      c.stroke();
      c.restore();
      // ring
      c.strokeStyle = 'rgba(255,255,255,0.5)';
      c.lineWidth = 2;
      c.beginPath();
      c.arc(W / 2, H / 2, W / 2 - 2, 0, Math.PI * 2);
      c.stroke();
    };
    draw();
    return () => cancelAnimationFrame(raf);
  }, [screen]);

  const surfaceLabel: Record<string, string> = {
    asphalt: 'آسفالت',
    sidewalk: 'پیاده‌رو',
    dirt: 'خاکی',
    grass: 'چمن',
    sand: 'شن',
    water: 'آب',
  };

  const speedPct = Math.min(1, hud.speedKmh / 230);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0a0f1e] text-white" dir="rtl">
      {/* 3D container always mounted so ref exists during loading */}
      <div ref={containerRef} className="game-canvas-container absolute inset-0" style={{ visibility: screen === 'game' ? 'visible' : 'hidden' }} />

      {/* ============ MENU ============ */}
      {screen === 'menu' && (
        <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-[#0a0f1e] via-[#101a33] to-[#0a0f1e]">
          <div className="checker h-3 w-full opacity-80" />
          <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col items-center px-5 py-8">
            {/* logo */}
            <div className="slide-up flex flex-col items-center">
              <div className="flex items-center gap-2 rounded-full border border-red-500/40 bg-red-500/10 px-4 py-1 text-xs text-red-300">
                <span className="rally-pulse inline-block h-2 w-2 rounded-full bg-red-400" />
                جهان‌باز واقعی • شهر • روستا • جنگل • ساحل • کوهستان
              </div>
              <h1 className="mt-4 text-center text-6xl font-black tracking-tight sm:text-7xl" dir="ltr">
                <span className="bg-gradient-to-b from-yellow-200 via-yellow-400 to-orange-500 bg-clip-text text-transparent drop-shadow-[0_4px_20px_rgba(255,180,0,0.35)]">
                  RALLY
                </span>{' '}
                <span className="bg-gradient-to-b from-red-400 via-red-500 to-red-700 bg-clip-text text-transparent drop-shadow-[0_4px_20px_rgba(255,40,60,0.4)]">
                  X
                </span>
              </h1>
              <p className="mt-2 text-center text-sm text-slate-300">بازی ریسینگ سه‌بعدی جهان‌باز — آزادانه در نقشه عظیم رانندگی کن</p>
            </div>

            {loadError && (
              <div className="mt-4 w-full rounded-xl border border-red-500/50 bg-red-500/15 p-3 text-center text-sm text-red-200">{loadError}</div>
            )}

            {/* car color */}
            <div className="slide-up mt-6 w-full rounded-2xl border border-white/10 bg-white/5 p-4" style={{ animationDelay: '0.1s' }}>
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-bold">رنگ ماشین رالی</h2>
                <span className="text-xs text-slate-400">{CAR_COLORS.find((c) => c.value === carColor)?.name}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {CAR_COLORS.map((c) => (
                  <button
                    key={c.value}
                    onClick={() => setCarColor(c.value)}
                    className={`h-10 w-10 rounded-full border-2 transition-transform ${carColor === c.value ? 'scale-110 border-white shadow-lg' : 'border-white/20'}`}
                    style={{ background: c.value, boxShadow: carColor === c.value ? `0 0 16px ${c.value}` : undefined }}
                    aria-label={c.name}
                  />
                ))}
              </div>
              {/* car preview strip */}
              <div className="mt-3 flex items-center gap-3 rounded-xl bg-black/30 p-3" dir="ltr">
                <svg viewBox="0 0 120 40" className="h-12 w-32 drop-shadow-lg">
                  <rect x="8" y="20" width="104" height="12" rx="6" fill={carColor} />
                  <rect x="30" y="10" width="52" height="14" rx="6" fill="#0e1a26" />
                  <rect x="55" y="10" width="10" height="14" fill={carColor} opacity="0.9" />
                  <circle cx="30" cy="32" r="8" fill="#151515" />
                  <circle cx="30" cy="32" r="3.5" fill="#e8edf2" />
                  <circle cx="90" cy="32" r="8" fill="#151515" />
                  <circle cx="90" cy="32" r="3.5" fill="#e8edf2" />
                  <rect x="104" y="23" width="6" height="5" fill="#fff3c0" />
                  <rect x="6" y="23" width="5" height="5" fill="#ff2222" />
                </svg>
                <div className="text-xs text-slate-300">
                  <div className="font-bold text-white">RALLY X — 4WD</div>
                  <div>حداکثر سرعت: ۲۲۳ کیلومتر • شتاب بالا</div>
                </div>
              </div>
            </div>

            {/* quality */}
            <div className="slide-up mt-3 w-full rounded-2xl border border-white/10 bg-white/5 p-4" style={{ animationDelay: '0.15s' }}>
              <h2 className="mb-3 font-bold">کیفیت گرافیک</h2>
              <div className="grid grid-cols-3 gap-2">
                {QUALITIES.map((q) => (
                  <button
                    key={q.id}
                    onClick={() => setQuality(q.id)}
                    className={`rounded-xl border p-3 text-center transition-all ${quality === q.id ? 'border-cyan-400 bg-cyan-400/15 shadow-[0_0_18px_rgba(34,211,238,0.3)]' : 'border-white/10 bg-white/5'}`}
                  >
                    <div className="font-bold">{q.name}</div>
                    <div className="mt-1 text-[11px] text-slate-400">{q.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* controls info */}
            <div className="slide-up mt-3 grid w-full grid-cols-1 gap-2 sm:grid-cols-3" style={{ animationDelay: '0.2s' }}>
              <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
                <div className="text-xl">📱</div>
                <div className="mt-1 text-xs font-bold">موبایل</div>
                <div className="text-[11px] text-slate-400">دکمه‌های گاز، ترمز و فرمان لمسی</div>
              </div>
              <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
                <div className="text-xl">⌨️</div>
                <div className="mt-1 text-xs font-bold">کیبورد</div>
                <div className="text-[11px] text-slate-400" dir="ltr">WASD / Arrows • Space دربفت</div>
              </div>
              <div className={`rounded-xl border p-3 text-center ${gamepad ? 'border-green-400/50 bg-green-400/10' : 'border-white/10 bg-white/5'}`}>
                <div className="text-xl">🎮</div>
                <div className="mt-1 text-xs font-bold">گیم‌پد {gamepad ? 'متصل ✓' : ''}</div>
                <div className="text-[11px] text-slate-400">{gamepad ? 'کنترلر شناسایی شد' : 'دسته را وصل کن'}</div>
              </div>
            </div>

            {/* start */}
            <button
              onClick={startGame}
              className="slide-up group relative mt-6 w-full overflow-hidden rounded-2xl bg-gradient-to-l from-red-600 via-red-500 to-orange-500 p-4 text-xl font-black shadow-[0_10px_40px_rgba(220,40,50,0.45)] transition-transform active:scale-[0.98]"
              style={{ animationDelay: '0.25s' }}
            >
              <span className="relative z-10">🏁 شروع رانندگی</span>
              <div className="absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </button>
            <p className="mt-3 text-center text-[11px] text-slate-500">نقشه بزرگ است؛ بارگذاری اول ممکن است چند ثانیه طول بکشد</p>
          </div>
          <div className="checker h-3 w-full opacity-80" />
        </div>
      )}

      {/* ============ LOADING ============ */}
      {screen === 'loading' && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#0a0f1e] px-8">
          <h1 className="text-5xl font-black" dir="ltr">
            <span className="bg-gradient-to-b from-yellow-200 to-orange-500 bg-clip-text text-transparent">RALLY</span>{' '}
            <span className="bg-gradient-to-b from-red-400 to-red-700 bg-clip-text text-transparent">X</span>
          </h1>
          <div className="mt-8 w-full max-w-md">
            <div className="mb-2 flex justify-between text-sm text-slate-300">
              <span>{progressLabel || 'در حال ساخت جهان...'}</span>
              <span dir="ltr">{Math.round(progress * 100)}%</span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-gradient-to-l from-red-500 via-orange-400 to-yellow-300 transition-all duration-200" style={{ width: `${progress * 100}%` }} />
            </div>
            <div className="mt-4 flex justify-center gap-1 text-2xl" dir="ltr">
              <span className="rally-pulse">🏎️</span>
              <span className="text-slate-500">💨</span>
            </div>
            <p className="mt-2 text-center text-xs text-slate-500">ساخت شهر، جنگل، ساحل، کوهستان و ترافیک...</p>
          </div>
        </div>
      )}

      {/* ============ GAME HUD ============ */}
      {screen === 'game' && (
        <>
          {/* top bar */}
          <div className="pointer-events-none absolute left-0 right-0 top-0 flex items-start justify-between gap-2 p-3" dir="ltr">
            {/* minimap */}
            <div className="relative shrink-0">
              <canvas ref={minimapRef} width={128} height={128} className="h-28 w-28 rounded-full bg-black/40 shadow-xl sm:h-32 sm:w-32" />
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-bold backdrop-blur" dir="rtl">
                {hud.region}
              </div>
            </div>

            {/* speed */}
            <div className="flex flex-col items-center rounded-2xl bg-black/45 px-5 py-2 backdrop-blur-md">
              <div className="speed-glow text-4xl font-black tabular-nums text-cyan-300 sm:text-5xl" dir="ltr">
                {hud.speedKmh}
              </div>
              <div className="text-[10px] tracking-widest text-slate-300">KM/H</div>
              <div className="mt-1 h-1.5 w-28 overflow-hidden rounded-full bg-white/15" dir="ltr">
                <div
                  className={`h-full rounded-full transition-all ${speedPct > 0.85 ? 'bg-red-500' : speedPct > 0.6 ? 'bg-orange-400' : 'bg-cyan-400'}`}
                  style={{ width: `${speedPct * 100}%` }}
                />
              </div>
              {hud.drifting && <div className="rally-pulse mt-1 rounded bg-orange-500/80 px-2 py-0.5 text-[11px] font-black">دریفت! 🔥</div>}
            </div>

            {/* buttons */}
            <div className="pointer-events-auto flex flex-col gap-2" dir="rtl">
              <button
                onClick={() => {
                  setPaused((p) => {
                    if (!p) engineRef.current?.pause();
                    else engineRef.current?.resume();
                    return !p;
                  });
                }}
                className="rounded-xl bg-black/50 p-2.5 text-lg backdrop-blur-md active:scale-95"
                aria-label="توقف"
              >
                ⏸️
              </button>
              <button onClick={() => engineRef.current?.toggleCamera()} className="rounded-xl bg-black/50 p-2.5 text-lg backdrop-blur-md active:scale-95" aria-label="دوربین">
                📷
              </button>
              <button
                onClick={() => {
                  const m = !muted;
                  setMuted(m);
                  engineRef.current?.setMuted(m);
                }}
                className="rounded-xl bg-black/50 p-2.5 text-lg backdrop-blur-md active:scale-95"
                aria-label="صدا"
              >
                {muted ? '🔇' : '🔊'}
              </button>
              <button onClick={() => engineRef.current?.recover()} className="rounded-xl bg-black/50 p-2.5 text-lg backdrop-blur-md active:scale-95" aria-label="بازگشت به جاده">
                🛟
              </button>
            </div>
          </div>

          {/* region flash */}
          {regionFlash && (
            <div className="pointer-events-none absolute left-1/2 top-24 -translate-x-1/2 rounded-2xl border border-white/20 bg-black/60 px-6 py-2 text-xl font-black backdrop-blur-md slide-up">
              📍 {regionFlash}
            </div>
          )}

          {/* surface badge */}
          <div className="pointer-events-none absolute bottom-40 left-3 rounded-lg bg-black/45 px-2 py-1 text-[11px] text-slate-200 backdrop-blur sm:bottom-8 sm:left-auto sm:right-3" dir="rtl">
            سطح: <b>{surfaceLabel[hud.surface] ?? hud.surface}</b>
            {(hud.surface === 'grass' || hud.surface === 'sand') && <span className="text-orange-300"> • خارج از جاده!</span>}
          </div>

          {/* touch controls */}
          <div className="absolute bottom-0 left-0 right-0 flex items-end justify-between p-4 pb-6" style={{ display: isTouch ? 'flex' : 'none' }}>
            <div className="flex gap-3" dir="ltr">
              <TouchButton label="◀" sub="چپ" onChange={(v) => inputRef.current?.setTouch('left', v)} className="h-20 w-20 sm:h-24 sm:w-24" />
              <TouchButton label="▶" sub="راست" onChange={(v) => inputRef.current?.setTouch('right', v)} className="h-20 w-20 sm:h-24 sm:w-24" />
            </div>
            <div className="flex items-end gap-3" dir="ltr">
              <TouchButton label="🛑" sub="دستی" onChange={(v) => inputRef.current?.setTouch('handbrake', v)} className="h-14 w-14 text-lg" color="bg-orange-500/20" />
              <TouchButton label="▼" sub="ترمز" onChange={(v) => inputRef.current?.setTouch('brake', v)} className="h-20 w-20 sm:h-24 sm:w-24" color="bg-red-500/20" />
              <TouchButton label="▲" sub="گاز" onChange={(v) => inputRef.current?.setTouch('gas', v)} className="h-24 w-24 sm:h-28 sm:w-28" color="bg-green-500/20" />
            </div>
          </div>

          {/* desktop hint */}
          {!isTouch && (
            <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-black/50 px-4 py-1.5 text-[11px] text-slate-300 backdrop-blur" dir="ltr">
              WASD / Arrows drive • Space handbrake • C camera • R recover • P pause
            </div>
          )}

          {/* help toggle */}
          <button onClick={() => setShowHelp((s) => !s)} className="absolute bottom-24 right-3 rounded-full bg-black/50 px-3 py-1.5 text-xs backdrop-blur sm:bottom-16" style={{ display: isTouch ? 'block' : 'none' }}>
            ❓ راهنما
          </button>
          {showHelp && (
            <div className="absolute bottom-36 right-3 max-w-[240px] rounded-xl border border-white/15 bg-black/75 p-3 text-xs leading-6 backdrop-blur">
              <b>راهنما:</b>
              <br />▲ گاز • ▼ ترمز/دنده عقب
              <br />◀ ▶ فرمان چپ و راست
              <br />
              🛑 ترمزدستی برای دریفت
              <br />📷 تغییر دوربین • 🛟 بازگشت به جاده
              <br />
              روی چمن و شن سرعت کم می‌شود!
            </div>
          )}

          {/* ============ PAUSE ============ */}
          {paused && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 p-5 backdrop-blur-sm">
              <div className="w-full max-w-sm rounded-2xl border border-white/15 bg-[#121a30] p-6 slide-up">
                <h2 className="text-center text-2xl font-black">⏸️ توقف</h2>
                <div className="mt-2 text-center text-sm text-slate-400">
                  {hud.region} • {hud.speedKmh} km/h
                </div>
                <div className="mt-4 flex flex-col gap-2">
                  <button
                    onClick={() => {
                      setPaused(false);
                      engineRef.current?.resume();
                    }}
                    className="rounded-xl bg-green-600 p-3 font-bold active:scale-[0.98]"
                  >
                    ▶️ ادامه بازی
                  </button>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => engineRef.current?.recover()} className="rounded-xl bg-white/10 p-3 text-sm font-bold active:scale-[0.98]">
                      🛟 بازگشت به جاده
                    </button>
                    <button
                      onClick={() => {
                        const m = !muted;
                        setMuted(m);
                        engineRef.current?.setMuted(m);
                      }}
                      className="rounded-xl bg-white/10 p-3 text-sm font-bold active:scale-[0.98]"
                    >
                      {muted ? '🔇 بی‌صدا' : '🔊 صدادار'}
                    </button>
                  </div>
                  <div className="rounded-xl bg-white/5 p-3">
                    <div className="mb-2 text-sm font-bold">رنگ ماشین</div>
                    <div className="flex flex-wrap gap-2">
                      {CAR_COLORS.map((c) => (
                        <button
                          key={c.value}
                          onClick={() => {
                            setCarColor(c.value);
                            engineRef.current?.setCarColor(c.value);
                          }}
                          className={`h-8 w-8 rounded-full border-2 ${carColor === c.value ? 'border-white' : 'border-white/20'}`}
                          style={{ background: c.value }}
                          aria-label={c.name}
                        />
                      ))}
                    </div>
                  </div>
                  <button onClick={quitToMenu} className="rounded-xl bg-red-600/80 p-3 font-bold active:scale-[0.98]">
                    🏠 خروج به منو
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
