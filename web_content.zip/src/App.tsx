import { useEffect, useRef, useState } from 'react';
import { engine } from './game/engine';
import { audio } from './game/audio';
import HUD from './ui/HUD';
import WeaponWheel from './ui/WeaponWheel';
import Inventory from './ui/Inventory';
import Phone from './ui/Phone';
import MapScreen from './ui/MapScreen';
import ShopPanel from './ui/ShopPanel';
import PauseMenu from './ui/PauseMenu';
import JailScreen from './ui/JailScreen';
import MobileControls from './ui/MobileControls';

type Quality = 'low' | 'medium' | 'high';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [started, setStarted] = useState(false);
  const [ready, setReady] = useState(false);
  const [quality, setQuality] = useState<Quality>(
    (localStorage.getItem('solstice_quality') as Quality) || 'high'
  );
  const [isMobile, setIsMobile] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('Generating city…');

  useEffect(() => {
    const mobile =
      ('ontouchstart' in window && navigator.maxTouchPoints > 0) ||
      /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
    setIsMobile(mobile);
    if (mobile && !localStorage.getItem('solstice_quality')) {
      setQuality('medium');
    }
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;
    let cancelled = false;
    const steps = [
      'Laying roads…',
      'Raising skyscrapers…',
      'Planting 900 trees…',
      'Parking 40 vehicles…',
      'Waking the citizens…',
      'Loading CHOP…',
    ];
    let i = 0;
    const t = setInterval(() => {
      i = (i + 1) % steps.length;
      setLoadingMsg(steps[i]);
    }, 420);
    // init after a frame so the loading screen paints first
    const id = requestAnimationFrame(() => {
      setTimeout(() => {
        if (cancelled || !canvasRef.current) return;
        try {
          engine.init(canvasRef.current, quality);
          setReady(true);
        } catch (err) {
          console.error(err);
          setLoadingMsg('WebGL unavailable on this device');
        }
      }, 60);
    });
    return () => {
      cancelled = true;
      clearInterval(t);
      cancelAnimationFrame(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = () => {
    audio.resume();
    localStorage.setItem('solstice_quality', quality);
    setStarted(true);
    if (!isMobile) {
      // request pointer lock on the first click of the canvas
      canvasRef.current?.requestPointerLock?.();
    }
  };

  return (
    <div className="fixed inset-0 bg-black overflow-hidden">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full touch-none"
        onClick={() => {
          audio.resume();
          if (started && !isMobile && !engine.pointerLocked) {
            canvasRef.current?.requestPointerLock?.();
          }
        }}
      />

      {/* ---------------- HUD ---------------- */}
      {ready && started && (
        <>
          <HUD onOpenMap={() => (engine.mapOpen = true)} />
          <WeaponWheel />
          <Inventory />
          <Phone />
          <MapScreen />
          <ShopPanel />
          <PauseMenu />
          <JailScreen />
          {isMobile && <MobileControls />}
        </>
      )}

      {/* ---------------- start screen ---------------- */}
      {!started && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,#16202e_0%,#070a0e_70%)]">
          <div className="absolute inset-0 opacity-[0.16] bg-[url('/images/city.jpg')] bg-cover bg-center" />
          <div className="relative w-full max-w-2xl px-6 text-center">
            <div className="text-[10px] tracking-[0.6em] text-amber-400/80 mb-3">
              W E L C O M E T O
            </div>
            <h1 className="text-5xl sm:text-7xl font-black tracking-tight text-white drop-shadow-[0_6px_30px_rgba(0,0,0,0.8)]">
              SOLSTICE <span className="text-amber-400">CITY</span>
            </h1>
            <p className="text-white/60 text-sm mt-3 max-w-lg mx-auto leading-relaxed">
              An open world of streets, jobs, rain and neon. Drive your Vortex M8, work the
              city, keep your pet CHOP close and stay out of the police van.
            </p>

            {!ready ? (
              <div className="mt-8">
                <div className="w-56 h-1 bg-white/10 rounded-full mx-auto overflow-hidden">
                  <div className="h-full w-1/3 bg-amber-400 animate-pulse" />
                </div>
                <p className="text-white/45 text-xs mt-3 tracking-wider">{loadingMsg}</p>
              </div>
            ) : (
              <div className="mt-8 space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-[10px] tracking-widest text-white/40">GRAPHICS</span>
                  {(['low', 'medium', 'high'] as Quality[]).map((q) => (
                    <button
                      key={q}
                      onClick={() => {
                        setQuality(q);
                        engine.setQuality(q);
                      }}
                      className={`px-3 py-1.5 rounded-md text-[11px] font-bold tracking-wider border ${
                        quality === q
                          ? 'bg-amber-500 text-black border-amber-400'
                          : 'bg-white/5 text-white/60 border-white/15'
                      }`}
                    >
                      {q.toUpperCase()}
                    </button>
                  ))}
                </div>
                <button
                  onClick={start}
                  className="w-full sm:w-64 py-4 bg-gradient-to-b from-amber-400 to-amber-600 text-black font-black tracking-[0.2em] rounded-xl hover:brightness-110 active:scale-[0.98] transition shadow-[0_10px_40px_rgba(245,185,66,0.35)]"
                >
                  PLAY
                </button>
                <div className="flex items-center justify-center gap-3 text-[11px]">
                  <button
                    onClick={() => {
                      start();
                      setTimeout(() => engine.load(), 300);
                    }}
                    className="text-white/60 hover:text-white underline underline-offset-4"
                  >
                    Continue saved game
                  </button>
                </div>
                <div className="text-[10px] text-white/35 leading-relaxed max-w-md mx-auto">
                  WASD move · SHIFT run · SPACE jump · E interact · F punch · Q weapons · TAB bag
                  · P phone · M map. On mobile use the on-screen stick and buttons.
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
