import React, { useState, useEffect } from 'react';
import { 
  loadProfile, 
  saveProfile, 
  addXpToProfile, 
  getRankDetails 
} from './utils/storage';
import { HunterProfile, Language, HunterRank } from './types';
import { soundManager } from './utils/audio';
import { BottomNavBar, TabType } from './components/navigation/BottomNavBar';
import { AnimeCompanion } from './components/companion/AnimeCompanion';
import { Anatomy3DViewer } from './components/anatomy/Anatomy3DViewer';
import { MedicalDictionary } from './components/dictionary/MedicalDictionary';
import { RadiologyAcademy } from './components/radiology/RadiologyAcademy';
import { LearningDungeon } from './components/learning/LearningDungeon';
import { MedicalAiAssistant } from './components/ai/MedicalAiAssistant';
import { QuizArena } from './components/quiz/QuizArena';
import { LeaderboardPvP } from './components/multiplayer/LeaderboardPvP';
import { StudentProfileView } from './components/profile/StudentProfile';
import { 
  Flame, 
  Heart, 
  Volume2, 
  VolumeX, 
  Crown, 
  Sparkles,
  Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  const [profile, setProfile] = useState<HunterProfile>(() => loadProfile());
  const [activeTab, setActiveTab] = useState<TabType>('dungeon');
  const [companionReaction, setCompanionReaction] = useState<'correct' | 'wrong' | 'levelUp' | 'rankUp' | null>(null);
  const [levelUpModal, setLevelUpModal] = useState<{ show: boolean; newLevel: number; newRank?: HunterRank } | null>(null);

  // Auto-save profile when it changes
  useEffect(() => {
    saveProfile(profile);
  }, [profile]);

  // Handle XP addition with level up / rank elevation
  const handleAddXp = (amount: number) => {
    const { profile: updated, leveledUp, rankedUp } = addXpToProfile(profile, amount);
    setProfile(updated);

    if (rankedUp) {
      setCompanionReaction('rankUp');
      soundManager.playRankUp(updated.settings.soundEnabled);
      setLevelUpModal({ show: true, newLevel: updated.level, newRank: updated.rank });
      try {
        confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
      } catch {}
    } else if (leveledUp) {
      setCompanionReaction('levelUp');
      soundManager.playSuccess(updated.settings.soundEnabled);
      setLevelUpModal({ show: true, newLevel: updated.level });
      try {
        confetti({ particleCount: 60, spread: 60 });
      } catch {}
    }
  };

  // Handle question answers from quests
  const handleAnswerQuestion = (isCorrect: boolean, xpReward: number) => {
    if (isCorrect) {
      setCompanionReaction('correct');
      if (xpReward > 0) {
        handleAddXp(xpReward);
      }
    } else {
      setCompanionReaction('wrong');
    }
  };

  // Consume 1 heart
  const handleConsumeHeart = (): boolean => {
    if (profile.hearts > 0) {
      const updated = {
        ...profile,
        hearts: profile.hearts - 1,
        lastHeartRefill: profile.hearts === profile.maxHearts ? Date.now() : profile.lastHeartRefill
      };
      setProfile(updated);
      return updated.hearts > 0;
    }
    return false;
  };

  // Refill hearts by learning / review
  const handleRefillHearts = () => {
    setProfile((prev) => ({
      ...prev,
      hearts: prev.maxHearts,
      lastHeartRefill: Date.now()
    }));
    soundManager.playManaRestore(profile.settings.soundEnabled);
  };

  // Toggle favorite term
  const handleToggleFavorite = (termId: string) => {
    const exists = profile.favoriteTermIds.includes(termId);
    const updated = {
      ...profile,
      favoriteTermIds: exists
        ? profile.favoriteTermIds.filter((id) => id !== termId)
        : [...profile.favoriteTermIds, termId]
    };
    setProfile(updated);
  };

  // Toggle difficult term
  const handleToggleDifficult = (termId: string) => {
    const exists = profile.difficultTermIds.includes(termId);
    const updated = {
      ...profile,
      difficultTermIds: exists
        ? profile.difficultTermIds.filter((id) => id !== termId)
        : [...profile.difficultTermIds, termId]
    };
    setProfile(updated);
  };

  // Lesson completion
  const handleCompleteLesson = (lessonId: string, xpReward: number) => {
    if (!profile.completedLessonIds.includes(lessonId)) {
      setProfile((prev) => ({
        ...prev,
        completedLessonIds: [...prev.completedLessonIds, lessonId]
      }));
      handleAddXp(xpReward);
      setCompanionReaction('correct');
    }
  };

  // Mistakes tracker
  const handleRecordMistake = (questionId: string) => {
    if (!profile.mistakeQuestionIds.includes(questionId)) {
      setProfile((prev) => ({
        ...prev,
        mistakeQuestionIds: [...prev.mistakeQuestionIds, questionId]
      }));
    }
  };

  const handleClearMistake = (questionId: string) => {
    setProfile((prev) => ({
      ...prev,
      mistakeQuestionIds: prev.mistakeQuestionIds.filter((id) => id !== questionId)
    }));
  };

  const rankInfo = getRankDetails(profile.rank);

  return (
    <div className="min-h-screen bg-[#07040f] text-slate-100 flex flex-col justify-between selection:bg-purple-600 selection:text-white pb-24 font-cairo">
      {/* Top App Header */}
      <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-purple-500/30 px-4 py-2.5 shadow-lg">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          {/* Brand & Hunter Rank */}
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm font-tech border shadow-md ${rankInfo.color} ${rankInfo.bg}`}>
              {profile.rank}
            </div>
            <div>
              <h1 className="text-sm md:text-base font-black text-slate-100 tracking-tight flex items-center gap-1.5">
                <span className="text-purple-400">SHADOW</span>
                <span>RADIOLOGY</span>
                <span className="text-[10px] bg-purple-900/80 text-purple-200 px-1.5 py-0.5 rounded border border-purple-500/40 font-mono">
                  DZ
                </span>
              </h1>
              <p className="text-[10px] text-slate-400 -mt-0.5 font-sans">
                {profile.name} • {rankInfo.nameAr}
              </p>
            </div>
          </div>

          {/* Quick HUD Metrics (Hearts, Streak, Audio Toggle) */}
          <div className="flex items-center gap-3 text-xs">
            {/* Hearts / Mana */}
            <div className="flex items-center gap-1 bg-rose-950/40 px-2.5 py-1 rounded-xl border border-rose-800/40">
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
              <span className="font-mono font-bold text-rose-300">
                {profile.hearts}
              </span>
            </div>

            {/* Streak */}
            <div className="flex items-center gap-1 bg-amber-950/40 px-2.5 py-1 rounded-xl border border-amber-800/40">
              <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span className="font-mono font-bold text-amber-300">
                {profile.streak}
              </span>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={() => {
                setProfile((prev) => ({
                  ...prev,
                  settings: { ...prev.settings, soundEnabled: !prev.settings.soundEnabled }
                }));
              }}
              title="كتم أو تشغيل المؤثرات الصوتية"
              className="p-1.5 bg-slate-900 hover:bg-purple-900/50 rounded-xl border border-purple-800/40 text-purple-300 transition-colors"
            >
              {profile.settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-5xl mx-auto w-full px-3 md:px-6 py-4 flex flex-col gap-6">
        {/* Interactive Anime Companion Hero Banner */}
        <AnimeCompanion
          language={profile.settings.language}
          soundEnabled={profile.settings.soundEnabled}
          currentReaction={companionReaction}
          onClearReaction={() => setCompanionReaction(null)}
        />

        {/* Dynamic Tab Views */}
        {activeTab === 'dungeon' && (
          <LearningDungeon
            profile={profile}
            language={profile.settings.language}
            soundEnabled={profile.settings.soundEnabled}
            onAnswerQuestion={handleAnswerQuestion}
            onConsumeHeart={handleConsumeHeart}
            onRefillHearts={handleRefillHearts}
          />
        )}

        {activeTab === 'dictionary' && (
          <MedicalDictionary
            language={profile.settings.language}
            soundEnabled={profile.settings.soundEnabled}
            favorites={profile.favoriteTermIds}
            difficultWords={profile.difficultTermIds}
            onToggleFavorite={handleToggleFavorite}
            onToggleDifficult={handleToggleDifficult}
          />
        )}

        {activeTab === 'academy' && (
          <RadiologyAcademy
            language={profile.settings.language}
            soundEnabled={profile.settings.soundEnabled}
            completedLessonIds={profile.completedLessonIds}
            userRank={profile.rank}
            onCompleteLesson={handleCompleteLesson}
          />
        )}

        {activeTab === '3d' && (
          <Anatomy3DViewer
            language={profile.settings.language}
            soundEnabled={profile.settings.soundEnabled}
            onAddXp={handleAddXp}
            onExplorePart={(partId) => {
              handleAddXp(20);
            }}
          />
        )}

        {activeTab === 'quiz' && (
          <div className="flex flex-col gap-8">
            <QuizArena
              profile={profile}
              language={profile.settings.language}
              soundEnabled={profile.settings.soundEnabled}
              onAddXp={handleAddXp}
              onRecordMistake={handleRecordMistake}
              onClearMistake={handleClearMistake}
            />

            {/* Multiplayer Leaderboard & 1v1 PvP Duel */}
            <LeaderboardPvP
              profile={profile}
              language={profile.settings.language}
              soundEnabled={profile.settings.soundEnabled}
              onAddXp={handleAddXp}
            />
          </div>
        )}

        {activeTab === 'ai' && (
          <MedicalAiAssistant
            language={profile.settings.language}
            soundEnabled={profile.settings.soundEnabled}
          />
        )}

        {activeTab === 'profile' && (
          <StudentProfileView
            profile={profile}
            language={profile.settings.language}
            soundEnabled={profile.settings.soundEnabled}
            onUpdateProfile={(updated) => setProfile(updated)}
            onChangeLanguage={(lang) => {
              setProfile((prev) => ({
                ...prev,
                settings: { ...prev.settings, language: lang }
              }));
            }}
            onToggleSound={() => {
              setProfile((prev) => ({
                ...prev,
                settings: { ...prev.settings, soundEnabled: !prev.settings.soundEnabled }
              }));
            }}
          />
        )}
      </main>

      {/* Level Up & Rank Elevation Celebration Modal */}
      {levelUpModal && levelUpModal.show && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-950 p-6 rounded-3xl border-2 border-purple-500 shadow-neon-purple text-center animate-scale-up">
            <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-2 animate-bounce" />

            <h3 className="text-2xl font-black text-slate-100 mb-1">
              {levelUpModal.newRank ? 'ترقية رتبة الصياد الأسطورية!' : 'ارتقاء في المستوى!'}
            </h3>

            <p className="text-xs text-purple-300 mb-5">
              {levelUpModal.newRank
                ? `تهانينا! لقد بلغت ${rankInfo.nameAr}. طاقتك الإشعاعية وصلت لآفاق جديدة.`
                : `وصلت بنجاح إلى المستوى ${levelUpModal.newLevel}. استمر في حصد المعرفة الشعاعية!`}
            </p>

            <button
              onClick={() => setLevelUpModal(null)}
              className="px-8 py-3 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-black text-xs rounded-xl shadow-neon-purple active:scale-95 transition-all"
            >
              متابعة المغامرة
            </button>
          </div>
        </div>
      )}

      {/* App Credit Footer */}
      <footer className="text-center py-4 text-[11px] text-slate-500 border-t border-purple-900/30">
        <p className="text-slate-400 font-semibold">
          Shadow Radiology – Paramedical DZ
        </p>
        <p className="text-purple-400 font-mono mt-0.5 font-bold">
          Rachid Boulghiti
        </p>
      </footer>

      {/* Touch-Friendly Android Bottom Navigation */}
      <BottomNavBar
        activeTab={activeTab}
        onChangeTab={(tab) => setActiveTab(tab)}
        soundEnabled={profile.settings.soundEnabled}
      />
    </div>
  );
}
