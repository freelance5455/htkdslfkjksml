/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { PublicLayout } from './layouts/PublicLayout';
import { PublicHome } from './pages/public/PublicHome';
import { MerchantDashboardPage } from './pages/public/MerchantDashboardPage';
import { StorefrontPage } from './pages/public/StorefrontPage';
import { AdminApp } from './AdminApp';

/**
 * Main Application Router
 * Final Route Structure:
 *  - "/"           -> Strictly Public Home Page (Zero Admin UI)
 *  - "/admin"      -> Admin Panel (Protected for Super Admins)
 *  - "/admin/login"-> Admin Login
 *  - "/dashboard"  -> Merchant Dashboard Console
 *  - "/storefront" -> Public Storefront
 */
export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <Routes>
          {/* Public Website Routes */}
          <Route path="/" element={<PublicLayout />}>
            <Route index element={<PublicHome />} />
            <Route path="storefront" element={<StorefrontPage />} />
          </Route>

          {/* Dedicated Merchant Dashboard (Isolated Professional Admin Layout) */}
          <Route path="/dashboard" element={<MerchantDashboardPage />} />

          {/* Dedicated Isolated Admin App (/admin/*) */}
          <Route path="/admin/*" element={<AdminApp />} />

          {/* Catch-all Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppProvider>
    </BrowserRouter>
  );
}
