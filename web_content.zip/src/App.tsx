import { useEffect, useMemo, useState } from "react";
import { useStudio } from "@/hooks/useStudio";
import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { EditorView } from "@/components/EditorView";
import { FilesView } from "@/components/FilesView";
import { PreviewView } from "@/components/PreviewView";
import { SettingsView } from "@/components/SettingsView";
import { StatusBar } from "@/components/StatusBar";
import { FileDialog } from "@/components/FileDialog";
import { NewProjectDialog } from "@/components/NewProjectDialog";
import { Toaster } from "@/components/ui/sonner";

export type Tab = "editor" | "files" | "preview" | "settings";

export default function App() {
  const studio = useStudio();
  const [tab, setTab] = useState<Tab>("editor");
  const [fileDialogOpen, setFileDialogOpen] = useState(false);
  const [projectDialogOpen, setProjectDialogOpen] = useState(false);

  const activeFile = useMemo(
    () => studio.files.find((f) => f.id === studio.activeFileId) ?? null,
    [studio.files, studio.activeFileId]
  );

  useEffect(() => {
    document.documentElement.dir = studio.settings.language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = studio.settings.language;
    document.documentElement.classList.toggle("dark", studio.settings.theme === "dark");
  }, [studio.settings.language, studio.settings.theme]);

  return (
    <div className="flex h-dvh flex-col bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <TopBar
        studio={studio}
        tab={tab}
        onTab={setTab}
        onOpenFiles={() => setFileDialogOpen(true)}
        onNewProject={() => setProjectDialogOpen(true)}
      />

      <main className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
        {tab === "editor" && (
          <EditorView
            studio={studio}
            activeFile={activeFile}
            onOpenFiles={() => setFileDialogOpen(true)}
          />
        )}
        {tab === "files" && (
          <FilesView
            studio={studio}
            onOpenFiles={() => setFileDialogOpen(true)}
            onNewProject={() => setProjectDialogOpen(true)}
          />
        )}
        {tab === "preview" && <PreviewView studio={studio} />}
        {tab === "settings" && <SettingsView studio={studio} />}
      </main>

      <StatusBar studio={studio} activeFile={activeFile} />
      <BottomNav tab={tab} onTab={setTab} />

      <FileDialog
        open={fileDialogOpen}
        onOpenChange={setFileDialogOpen}
        studio={studio}
      />
      <NewProjectDialog
        open={projectDialogOpen}
        onOpenChange={setProjectDialogOpen}
        studio={studio}
      />
      <Toaster position="top-center" richColors />
    </div>
  );
}