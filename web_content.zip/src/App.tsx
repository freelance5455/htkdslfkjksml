import React, { useState, useEffect } from 'react';
import { BusinessProfile, SaleInvoice, Product, Customer } from './types/business';
import { StorageService } from './db/storage';
import { BusinessSetup } from './components/BusinessSetup';
import { Dashboard } from './components/Dashboard';
import { ProductManagement } from './components/ProductManagement';
import { StockAlertView } from './components/StockAlertView';
import { SalesScreen } from './components/SalesScreen';
import { InvoiceModal } from './components/InvoiceModal';
import { SalesHistoryScreen } from './components/SalesHistoryScreen';
import { EditSaleModal } from './components/EditSaleModal';
import { CustomerManagement } from './components/CustomerManagement';
import { DueManagement } from './components/DueManagement';
import { ReturnManagement } from './components/ReturnManagement';
import { ProductProfitView } from './components/ProductProfitView';
import { TransactionsView } from './components/TransactionsView';
import { ExpenseManagement } from './components/ExpenseManagement';
import { SettingsScreen } from './components/SettingsScreen';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { AIAssistantModal } from './components/AIAssistantModal';
import { BottomNav } from './components/BottomNav';

export default function App() {
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [activeTab, setActiveTab] = useState<'home' | 'customers' | 'settings'>('home');
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [viewData, setViewData] = useState<any>(null);

  // Active Modals
  const [activeInvoice, setActiveInvoice] = useState<SaleInvoice | null>(null);
  const [editingInvoice, setEditingInvoice] = useState<SaleInvoice | null>(null);
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string | null>(null);
  const [aiModalTab, setAiModalTab] = useState<'chat' | 'search' | 'maps' | 'live' | null>(null);

  // Load profile on start
  useEffect(() => {
    const saved = StorageService.getBusinessProfile();
    if (saved && saved.isSetupCompleted) {
      setProfile(saved);
    }
  }, []);

  // Handle bottom navigation tabs
  const handleTabChange = (tab: 'home' | 'customers' | 'settings') => {
    setActiveTab(tab);
    if (tab === 'home') {
      setCurrentView('dashboard');
    } else if (tab === 'customers') {
      setCurrentView('customers');
    } else if (tab === 'settings') {
      setCurrentView('settings');
    }
  };

  // Handle navigation from dashboard action cards
  const handleNavigate = (view: string, data?: any) => {
    setCurrentView(view);
    setViewData(data);
    if (view === 'dashboard') {
      setActiveTab('home');
    } else if (view === 'customers') {
      setActiveTab('customers');
    } else if (view === 'settings') {
      setActiveTab('settings');
    }
  };

  // If business setup is not completed yet, show First Launch setup screen
  if (!profile || !profile.isSetupCompleted) {
    return (
      <BusinessSetup
        lang={lang}
        onComplete={(newProfile) => {
          setProfile(newProfile);
          setCurrentView('dashboard');
          setActiveTab('home');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-500 selection:text-white">
      {/* View Switcher */}
      {currentView === 'dashboard' && (
        <Dashboard
          profile={profile}
          lang={lang}
          onNavigate={handleNavigate}
          onOpenSearch={(q) => setGlobalSearchQuery(q)}
          onOpenAI={(tab) => setAiModalTab(tab || 'chat')}
        />
      )}

      {currentView === 'products' && (
        <ProductManagement
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          initialStockAddId={viewData?.openStockAdd}
        />
      )}

      {currentView === 'sales' && (
        <SalesScreen
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          onInvoiceCreated={(inv) => {
            setActiveInvoice(inv);
            handleNavigate('dashboard');
          }}
        />
      )}

      {currentView === 'sales_history' && (
        <SalesHistoryScreen
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          onViewInvoice={(inv) => setActiveInvoice(inv)}
          onEditInvoice={(inv) => setEditingInvoice(inv)}
        />
      )}

      {currentView === 'customers' && (
        <CustomerManagement
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          onViewInvoice={(inv) => setActiveInvoice(inv)}
        />
      )}

      {currentView === 'due_alerts' && (
        <DueManagement
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          onViewInvoice={(inv) => setActiveInvoice(inv)}
          initialCustomerId={viewData?.customerId}
        />
      )}

      {currentView === 'returns' && (
        <ReturnManagement
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
        />
      )}

      {currentView === 'product_profit' && (
        <ProductProfitView
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
        />
      )}

      {currentView === 'stock_alerts' && (
        <StockAlertView
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          onNavigateToProductEdit={(p) => handleNavigate('products')}
        />
      )}

      {currentView === 'transactions' && (
        <TransactionsView
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
        />
      )}

      {currentView === 'expenses' && (
        <ExpenseManagement
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
        />
      )}

      {currentView === 'settings' && (
        <SettingsScreen
          profile={profile}
          lang={lang}
          onBack={() => handleNavigate('dashboard')}
          onLanguageChange={(newLang) => setLang(newLang)}
          onProfileUpdate={(updated) => setProfile(updated)}
        />
      )}

      {/* Invoice Modal (View / Print / WhatsApp Share) */}
      {activeInvoice && (
        <InvoiceModal
          invoice={activeInvoice}
          profile={profile}
          lang={lang}
          onClose={() => setActiveInvoice(null)}
        />
      )}

      {/* Edit Sale Modal */}
      {editingInvoice && (
        <EditSaleModal
          invoice={editingInvoice}
          lang={lang}
          onClose={() => setEditingInvoice(null)}
          onSaveSuccess={(updated) => {
            setEditingInvoice(null);
            setActiveInvoice(updated);
          }}
        />
      )}

      {/* Global Search Modal */}
      {globalSearchQuery !== null && (
        <GlobalSearchModal
          initialQuery={globalSearchQuery}
          lang={lang}
          onClose={() => setGlobalSearchQuery(null)}
          onSelectProduct={() => handleNavigate('products')}
          onSelectCustomer={() => handleNavigate('customers')}
          onSelectInvoice={(inv) => setActiveInvoice(inv)}
        />
      )}

      {/* AI Assistant Modal (Gemini Chat, Search Grounding, Maps Grounding, Live Voice) */}
      {aiModalTab !== null && (
        <AIAssistantModal
          defaultTab={aiModalTab}
          lang={lang}
          onClose={() => setAiModalTab(null)}
        />
      )}

      {/* Android-style Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        lang={lang}
        onTabChange={handleTabChange}
      />
    </div>
  );
}
