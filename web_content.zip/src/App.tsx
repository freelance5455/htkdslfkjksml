import React, { useState, useEffect, useMemo } from "react";
import { MenuCategory, Dish } from "./types";
import { DEFAULT_MENU_CATEGORIES } from "./data/defaultMenu";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { PhilosophySection } from "./components/PhilosophySection";
import { EditorialFoodStory } from "./components/EditorialFoodStory";
import { SpaceSection } from "./components/SpaceSection";
import { NutritionSection } from "./components/NutritionSection";
import { JournalSection } from "./components/JournalSection";
import { VisitSection } from "./components/VisitSection";
import { FooterSection } from "./components/FooterSection";
import { MenuOverlay } from "./components/MenuOverlay";
import { FoodDetailModal } from "./components/FoodDetailModal";
import { MenuImportModal } from "./components/MenuImportModal";
import { ConciergeModal } from "./components/ConciergeModal";
import { ImageStudioModal } from "./components/ImageStudioModal";
import { OrderModal } from "./components/OrderModal";
import { MobileBottomBar } from "./components/MobileBottomBar";
import { MessageSquare, Sparkles, Phone } from "lucide-react";
import { RESTAURANT_INFO } from "./data/restaurantInfo";

export default function App() {
  // Menu State with LocalStorage persistence for imported menus
  const [categories, setCategories] = useState<MenuCategory[]>(() => {
    try {
      const saved = localStorage.getItem("kaloreez_menu_v2");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 10) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn("Failed to load saved menu:", e);
    }
    return DEFAULT_MENU_CATEGORIES;
  });

  // Modal & Overlay visibility states
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [initialCategorySlug, setInitialCategorySlug] = useState<string>("all");
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState(false);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [isOrderOpen, setIsOrderOpen] = useState(false);
  const [selectedDishDetail, setSelectedDishDetail] = useState<Dish | null>(null);
  const [orderTargetDish, setOrderTargetDish] = useState<Dish | null>(null);

  // Sync menu persistence
  const handleApplyImportedMenu = (newCategories: MenuCategory[]) => {
    setCategories(newCategories);
    try {
      localStorage.setItem("kaloreez_menu_v2", JSON.stringify(newCategories));
    } catch (e) {
      console.warn("Failed to persist imported menu:", e);
    }
    // Automatically open the reconstructed menu so the user immediately experiences the updated navigation!
    setIsMenuOpen(true);
    setInitialCategorySlug("all");
  };

  const handleResetDefaultMenu = () => {
    setCategories(DEFAULT_MENU_CATEGORIES);
    try {
      localStorage.removeItem("kaloreez_menu_v2");
    } catch (e) {
      console.warn(e);
    }
  };

  const handleOpenMenuCategory = (slug?: string) => {
    setInitialCategorySlug(slug || "all");
    setIsMenuOpen(true);
  };

  const handleOpenOrderModal = (dish?: Dish) => {
    setOrderTargetDish(dish || null);
    setIsOrderOpen(true);
  };

  // Curated list of verified dishes for the Editorial Food Story section
  const featuredDishes = useMemo(() => {
    const dishes: Dish[] = [];
    categories.forEach((cat) => {
      cat.dishes.forEach((d) => {
        if (d.isEditorialFeature || dishes.length < 3) {
          dishes.push(d);
        }
      });
    });
    return dishes.slice(0, 3);
  }, [categories]);

  // Total items across all categories for badge counter
  const totalDishCount = useMemo(() => {
    return categories.reduce((sum, cat) => sum + cat.dishes.length, 0);
  }, [categories]);

  return (
    <div className="min-h-screen bg-[#F4F0E7] text-[#17201C] font-sans selection:bg-[#9BAF82]/30 selection:text-[#17201C] relative">
      {/* Primary Fixed Header & Mega-Menu Navigation */}
      <Navbar
        categories={categories}
        onOpenMenu={handleOpenMenuCategory}
        onOpenImport={() => setIsImportOpen(true)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
        onOpenStudio={() => setIsStudioOpen(true)}
        onOrderOnline={() => handleOpenOrderModal()}
      />

      {/* Main Editorial Experience (pb-20 on mobile prevents bottom bar overlap) */}
      <main className="pb-24 lg:pb-0">
        {/* Cinematic Hero */}
        <Hero
          onExploreMenu={() => handleOpenMenuCategory("all")}
          onVisit={() => {
            const elem = document.getElementById("visit");
            if (elem) elem.scrollIntoView({ behavior: "smooth" });
          }}
        />

        {/* Philosophy & Craft */}
        <PhilosophySection
          onLearnMore={() => {
            const elem = document.getElementById("journal");
            if (elem) elem.scrollIntoView({ behavior: "smooth" });
          }}
        />

        {/* Editorial Food Story (Not a menu grid, but an invitation) */}
        <EditorialFoodStory
          featuredDishes={featuredDishes}
          onSelectDish={(d) => setSelectedDishDetail(d)}
          onOpenMenu={() => handleOpenMenuCategory("all")}
        />

        {/* The Space & Atmosphere */}
        <SpaceSection />

        {/* Nutrition & Transparent Ledger */}
        <NutritionSection />

        {/* Culinary Journal */}
        <JournalSection />

        {/* Visit & Directions */}
        <VisitSection onOrderOnline={() => handleOpenOrderModal()} />
      </main>

      {/* Final Editorial Call to Action & Footer */}
      <FooterSection
        onOpenMenu={() => handleOpenMenuCategory("all")}
        onOrderOnline={() => handleOpenOrderModal()}
      />

      {/* Persistent Floating Action Buttons (Desktop Only: Direct Call & Concierge) */}
      <div className="hidden lg:flex fixed bottom-6 right-6 z-30 items-center gap-2.5">
        {/* Direct Call Button: Always accessible, immediately triggers tel: */}
        <a
          href={`tel:${RESTAURANT_INFO.phone}`}
          className="group flex items-center gap-2 px-4 py-3 rounded-full bg-[#17201C] text-[#F4F0E7] shadow-xl hover:bg-[#9BAF82] hover:text-[#17201C] active:scale-95 transition-all border border-[#D8D0C2]/50 cursor-pointer"
          title={`Direct Call: ${RESTAURANT_INFO.phoneDisplay}`}
        >
          <div className="w-5 h-5 rounded-full bg-[#9BAF82]/20 flex items-center justify-center text-[#9BAF82] group-hover:text-[#17201C]">
            <Phone className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-serif font-medium tracking-wide">
            Call Eatery ({RESTAURANT_INFO.phoneDisplay})
          </span>
        </a>

        {/* Concierge Button */}
        <button
          type="button"
          onClick={() => setIsConciergeOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#17201C] text-[#F4F0E7] shadow-xl hover:bg-[#9BAF82] hover:text-[#17201C] transition-all cursor-pointer border border-[#D8D0C2]/50"
          title="Open Nutrition Concierge"
        >
          <div className="w-5 h-5 rounded-full bg-[#9BAF82]/20 flex items-center justify-center text-[#9BAF82] group-hover:text-[#17201C]">
            <MessageSquare className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-serif italic tracking-wide">
            Table Concierge
          </span>
        </button>
      </div>

      {/* Native-Feel Mobile Bottom Navigation Bar (Hidden when modals are open) */}
      {!isMenuOpen && !isOrderOpen && !isConciergeOpen && !isImportOpen && !isStudioOpen && !selectedDishDetail && (
        <MobileBottomBar
          onOpenMenu={() => handleOpenMenuCategory("all")}
          onOpenConcierge={() => setIsConciergeOpen(true)}
          onOrderOnline={() => handleOpenOrderModal()}
          dishCount={totalDishCount}
        />
      )}

      {/* Interactive Overlays & Modals */}
      {/* 1. Full-Screen Digital Menu Overlay */}
      <MenuOverlay
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        categories={categories}
        initialCategorySlug={initialCategorySlug}
        onOpenImport={() => {
          setIsMenuOpen(false);
          setIsImportOpen(true);
        }}
        onOrderOnline={(dish) => handleOpenOrderModal(dish)}
      />

      {/* 2. Single Dish Detail Modal */}
      <FoodDetailModal
        dish={selectedDishDetail}
        onClose={() => setSelectedDishDetail(null)}
        onOrderOnline={(dish) => {
          setSelectedDishDetail(null);
          handleOpenOrderModal(dish);
        }}
      />

      {/* 3. Real Menu Photo Import & OCR Reconstruction Modal */}
      <MenuImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onApplyMenu={handleApplyImportedMenu}
        onResetToDefault={handleResetDefaultMenu}
      />

      {/* 4. Multi-Turn Gemini Concierge Chat Modal */}
      <ConciergeModal
        isOpen={isConciergeOpen}
        onClose={() => setIsConciergeOpen(false)}
        categories={categories}
      />

      {/* 5. Gemini 3 Pro Image Culinary Studio Modal */}
      <ImageStudioModal
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
      />

      {/* 6. Order / Table Reservation Modal */}
      <OrderModal
        isOpen={isOrderOpen}
        onClose={() => {
          setIsOrderOpen(false);
          setOrderTargetDish(null);
        }}
        initialDish={orderTargetDish}
      />
    </div>
  );
}
