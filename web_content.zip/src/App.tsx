import React, { useState, useRef, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { LiveSession } from './components/LiveSession';
import { LiveCameraModal } from './components/LiveCameraModal';
import { LiveScreenShareModal } from './components/LiveScreenShareModal';
import { SettingsModal } from './components/SettingsModal';
import { TextScannerModal } from './components/TextScannerModal';
import { HelpAIAssistant } from './components/HelpAIAssistant';
import { PricingModal } from './components/PricingModal';
import { AdminDashboard } from './components/AdminDashboard';
import { MyPlanModal } from './components/MyPlanModal';
import { InterstitialAd } from './components/InterstitialAd';
import { streamChatResponse, generateImage, ChatMessage as ChatMessageType } from './services/gemini';
import { parseAndExecuteVoiceCommand } from './utils/voiceCommands';
import { Menu, Image, BookOpen, PenLine, Lightbulb, Plus, FileText, Globe, Crown, Shield, LogOut, Check, X, Camera, Monitor } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { jsPDF } from 'jspdf';
import Tesseract from 'tesseract.js';

import { useGoogleLogin, googleLogout } from '@react-oauth/google';

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessageType[];
  date: string;
}

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLiveOpen, setIsLiveOpen] = useState(false);
  const [isLiveCameraOpen, setIsLiveCameraOpen] = useState(false);
  const [isLiveScreenShareOpen, setIsLiveScreenShareOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isAdOpen, setIsAdOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [isThinking, setIsThinking] = useState(false);
  const [chatId, setChatId] = useState(0); // To reset ChatInput on new chat
  const [userName, setUserName] = useState<string | null>(() => {
    return localStorage.getItem('india_ai_user_name') || 'Dost';
  });
  const [userEmail, setUserEmail] = useState<string | null>(() => {
    return localStorage.getItem('india_ai_user_email') || 'keshavraj5005@gmail.com';
  });
  const [tempName, setTempName] = useState(() => localStorage.getItem('india_ai_user_name') || 'Keshav');
  const [loginStep, setLoginStep] = useState<'google' | 'dob'>('google');
  const [tempEmail, setTempEmail] = useState(() => localStorage.getItem('india_ai_user_email') || 'keshavraj5005@gmail.com');
  const [tempDob, setTempDob] = useState('');
  const [showNameModal, setShowNameModal] = useState(false);
  const [persona, setPersona] = useState<'Male' | 'Female'>('Female');
  const [language, setLanguage] = useState('Hinglish');
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [isPricingOpen, setIsPricingOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isMyPlanOpen, setIsMyPlanOpen] = useState(false);
  const [userPlan, setUserPlan] = useState('FREE');
  const [userId, setUserId] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [paymentStatus, setPaymentStatus] = useState<'success' | 'cancelled' | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check for payment redirect status
    const params = new URLSearchParams(window.location.search);
    const payment = params.get('payment');
    if (payment === 'success') {
      setPaymentStatus('success');
      setUserPlan('PRO'); // Optimistic update
      window.history.replaceState({}, '', window.location.pathname);
    } else if (payment === 'cancelled') {
      setPaymentStatus('cancelled');
      window.history.replaceState({}, '', window.location.pathname);
    }

    // Listen for custom events from Sidebar
    const handleOpenMyPlan = () => setIsMyPlanOpen(true);
    window.addEventListener('open-my-plan', handleOpenMyPlan);

    // Generate or get User ID
    let storedId = localStorage.getItem('india_ai_user_id');
    if (!storedId) {
      storedId = uuidv4();
      localStorage.setItem('india_ai_user_id', storedId);
    }
    setUserId(storedId);

    // Fetch Plan Status
    fetch('/api/user', { headers: { 'x-user-id': storedId }})
      .then(res => res.json())
      .then(data => {
        if (data.plan) setUserPlan(data.plan);
      })
      .catch(console.error);

    // Load Chat History
    const savedChats = localStorage.getItem(`india_ai_chats_${storedId}`);
    if (savedChats) {
      try {
        setChatHistory(JSON.parse(savedChats));
      } catch (e) {
        console.error("Failed to parse chat history");
      }
    }

    const savedName = localStorage.getItem('india_ai_user_name') || 'Keshav';
    const savedEmail = localStorage.getItem('india_ai_user_email') || 'keshavraj5005@gmail.com';
    setTempEmail(savedEmail);
    setUserEmail(savedEmail);
    setTempName(savedName);
    setUserName(savedName);
    setShowNameModal(false); // Open directly to the chat! Never lock the user out.

    // Pre-load voices for the speech synthesis so they are ready by login
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      try {
        window.speechSynthesis.getVoices();
        window.speechSynthesis.onvoiceschanged = () => {
          try {
            window.speechSynthesis.getVoices();
          } catch (_) {}
        };
      } catch (_) {}
    }
  }, []);

  const playBigBossAudio = () => {
    try {
      if (!window.speechSynthesis) return;
      window.speechSynthesis.cancel();
      const text = "Welcome to India chat GPT. India ko kya bola tha tune? Main bolata Hun Tu Sun. tu kya hai be idhar dekh, I am India chat GPT. hila dala na... haaa!";
      const msg = new SpeechSynthesisUtterance(text);
      
      const voices = window.speechSynthesis.getVoices();
      let selectedVoice = voices.find(v => 
        v.name.toLowerCase().includes('hemant') || 
        v.name.toLowerCase().includes('rishi') || 
        v.name.toLowerCase().includes('male') ||
        v.name.toLowerCase().includes('david') ||
        v.name.toLowerCase().includes('mark')
      );

      if (selectedVoice) {
        msg.voice = selectedVoice;
      } else {
        msg.lang = 'hi-IN';
      }
      
      msg.pitch = 0.1;
      msg.rate = 0.85;
      window.speechSynthesis.speak(msg);
    } catch (e) {
      console.warn("Speech synthesis audio blocked or not supported:", e);
    }
  };

  const handleSaveName = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const finalName = tempName.trim() || (tempEmail ? tempEmail.split('@')[0] : 'Dost');
    localStorage.setItem('india_ai_user_name', finalName);
    if (tempEmail) {
      localStorage.setItem('india_ai_user_email', tempEmail);
      setUserEmail(tempEmail);
    }
    setUserName(finalName);
    setShowNameModal(false);
    
    // Attempt to save to backend
    if (userId) {
      fetch('/api/user/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': userId },
        body: JSON.stringify({ name: finalName, email: tempEmail, dob: tempDob || '2000-01-01' })
      }).catch(console.error);
    }

    playBigBossAudio();
  };

  const handleGuestLogin = () => {
    const guestName = 'Dost';
    localStorage.setItem('india_ai_user_name', guestName);
    setUserName(guestName);
    setShowNameModal(false);
    playBigBossAudio();
  };

  const triggerGoogleOAuth = useGoogleLogin({
    prompt: 'select_account',
    onSuccess: async (tokenResponse) => {
      try {
        const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { Authorization: `Bearer ${tokenResponse.access_token}` },
        });
        const userInfo = await res.json();
        const finalEmail = userInfo.email || 'keshavraj5005@gmail.com';
        const finalName = userInfo.name || 'Keshav';
        setTempEmail(finalEmail);
        setTempName(finalName);
        setUserEmail(finalEmail);
        setUserName(finalName);
        localStorage.setItem('india_ai_user_email', finalEmail);
        localStorage.setItem('india_ai_user_name', finalName);
        setShowNameModal(false);
      } catch (err) {
        console.error("Failed to fetch user info", err);
        const finalEmail = 'keshavraj5005@gmail.com';
        const finalName = 'Keshav';
        setTempEmail(finalEmail);
        setTempName(finalName);
        setUserEmail(finalEmail);
        setUserName(finalName);
        localStorage.setItem('india_ai_user_email', finalEmail);
        localStorage.setItem('india_ai_user_name', finalName);
        setShowNameModal(false);
      }
    },
    onError: (errorResponse) => {
      console.warn("Google Sign-In prompt closed or not available:", errorResponse);
      const finalEmail = tempEmail || 'keshavraj5005@gmail.com';
      const finalName = tempName || 'Keshav';
      localStorage.setItem('india_ai_user_email', finalEmail);
      localStorage.setItem('india_ai_user_name', finalName);
      setUserEmail(finalEmail);
      setUserName(finalName);
      setShowNameModal(false);
    }
  });

  const handleGoogleClick = () => {
    try {
      triggerGoogleOAuth();
    } catch (err) {
      console.warn("Direct trigger exception in GoogleOAuth:", err);
      const finalEmail = tempEmail || 'keshavraj5005@gmail.com';
      const finalName = tempName || 'Keshav';
      localStorage.setItem('india_ai_user_email', finalEmail);
      localStorage.setItem('india_ai_user_name', finalName);
      setUserEmail(finalEmail);
      setUserName(finalName);
      setShowNameModal(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  const generatePDF = async (content: string, fileName: string = 'india-ai-document.pdf') => {
    try {
      const pdf = new jsPDF();
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 20;
      const contentWidth = pageWidth - (margin * 2);
      
      // Add branding header exactly as in screenshot
      const addHeader = (pageNum: number) => {
        pdf.setPage(pageNum);
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(10);
        pdf.setTextColor(180, 180, 180); // Light gray
        pdf.text("Generated by India GPT", pageWidth - margin, 15, { align: "right" });
        pdf.setTextColor(0, 0, 0); // Reset color
      };

      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(12);
      
      // Split text into lines that fit the width
      const lines = pdf.splitTextToSize(content, contentWidth);
      
      let cursorY = 30;
      addHeader(1);

      lines.forEach((line: string) => {
        if (cursorY + 10 > pageHeight - margin) {
          pdf.addPage();
          cursorY = 30;
          addHeader(pdf.getNumberOfPages());
          pdf.setFontSize(12); // Ensure font size is reset for new page
        }
        pdf.text(line, margin, cursorY);
        cursorY += 7; // Line spacing
      });
      
      pdf.save(fileName);
      return true;
    } catch (err) {
      console.error("PDF Generation Error:", err);
      throw err;
    }
  };

  const generateImagePDF = async (images: string[], fileName: string = 'india-ai-images.pdf') => {
    try {
      let pdf: any = null;

      for (let i = 0; i < images.length; i++) {
        const img = images[i];
        
        // Get image dimensions
        const imgProps = await new Promise<{w: number, h: number}>((resolve) => {
          const image = new window.Image();
          image.onload = () => resolve({ w: image.width, h: image.height });
          image.src = img;
        });

        const orientation = imgProps.w > imgProps.h ? 'l' : 'p';

        if (i === 0) {
          pdf = new jsPDF({
            orientation: orientation,
            unit: 'px',
            format: [imgProps.w, imgProps.h]
          });
        } else {
          pdf.addPage([imgProps.w, imgProps.h], orientation);
        }

        // Add image at full size
        pdf.addImage(img, 'JPEG', 0, 0, imgProps.w, imgProps.h);
        
        // Add branding overlay (subtle)
        pdf.setFont("helvetica", "normal");
        const fontSize = Math.max(12, Math.floor(imgProps.w / 40));
        pdf.setFontSize(fontSize);
        pdf.setTextColor(180, 180, 180);
        pdf.text("Generated by India GPT", imgProps.w - (imgProps.w / 20), fontSize + 10, { align: "right" });
      }
      
      pdf.save(fileName);
      return true;
    } catch (err) {
      console.error("Direct PDF Error:", err);
      throw err;
    }
  };

  const handleSendMessage = (content: string, images?: string[]) => {
    if (userPlan === 'FREE') {
      setPendingAction(() => () => executeSendMessage(content, images));
      setIsAdOpen(true);
    } else {
      executeSendMessage(content, images);
    }
  };

  const executeSendMessage = async (content: string, images?: string[]) => {
    const userMessage: ChatMessageType = { role: 'user', content, images };
    setMessages(prev => [...prev, userMessage]);
    setIsThinking(true);

    // Check for voice app-launcher command (WhatsApp, YouTube, Google, etc.)
    const voiceAction = parseAndExecuteVoiceCommand(content);
    if (voiceAction) {
      setIsThinking(false);
      const actionCard = `${voiceAction.spokenReply}\n\n👉 [**${voiceAction.actionName} Open Karein**](${voiceAction.url})\n\n*(Agar popup block hua ho ya new window open na hui ho, toh upar diye gaye link par click karein)*`;
      setMessages(prev => [...prev, { role: 'model', content: actionCard }]);
      if ('speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
          const utter = new SpeechSynthesisUtterance(voiceAction.spokenReply);
          utter.lang = 'hi-IN';
          window.speechSynthesis.speak(utter);
        } catch (_) {}
      }
      return;
    }

    const lowerContent = content.toLowerCase();
    
    // Check for PDF generation (only if user explicitly asks for a PDF file/download)
    const isPDFRequest = /\b(pdf|create pdf|make pdf|generate pdf|download pdf|convert to pdf|pdf banao|photo to pdf)\b/i.test(lowerContent);

    if (isPDFRequest) {
      try {
        // Determine if user wants direct images or smart text extraction
        const isDirectPhotoPDF = (images && images.length > 0) && (
          lowerContent.includes('photo') || 
          lowerContent.includes('image') || 
          lowerContent.includes('direct') ||
          (!lowerContent.includes('text') && !lowerContent.includes('read'))
        );

        if (isDirectPhotoPDF && images && images.length > 0) {
          setMessages(prev => [...prev, { role: 'model', content: 'Creating a direct Photo PDF for you...', isThinking: true }]);
          await generateImagePDF(images);
          setMessages(prev => {
            const newMessages = [...prev];
            newMessages.pop();
            newMessages.push({ role: 'model', content: `I have created a PDF with your ${images.length} photo(s). Aapka Photo PDF download ho gaya hai! (Generated by India GPT)` });
            return newMessages;
          });
        } else {
          setMessages(prev => [...prev, { role: 'model', content: 'Analyzing and formatting your document...', isThinking: true }]);
          
          // Use Gemini to extract and format text professionally
          const prompt = images && images.length > 0 
            ? `Extract all text from these images. Clean and organize it into a professional document structure. 
               CRITICAL: Preserve the EXACT language (Hindi, English, Math, Bhojpuri, etc.) as written. Do not translate.
               Start with "Here is the formatted text from the image, cleaned and organized:" 
               followed by the content. Use the same structure as the provided text. Do not use markdown bold/italic for the main body.`
            : `Format the following text into a professional document structure. 
               CRITICAL: Preserve the EXACT language and style. Do not translate.
               Start with "Here is the formatted text, cleaned and organized:" 
               followed by the content: ${content}. Do not use markdown bold/italic for the main body.`;
          
          const stream = streamChatResponse(messages, prompt, images, 'gemini-3.1-flash-lite', persona, userName || undefined, language);
          let fullFormattedText = '';
          
          for await (const chunk of stream) {
            if (chunk.error) {
               throw new Error(chunk.error);
            }
            fullFormattedText += chunk.text || '';
            setMessages(prev => {
              const newMessages = [...prev];
              const last = newMessages[newMessages.length - 1];
              if (last && last.role === 'model') {
                last.content = fullFormattedText;
              }
              return newMessages;
            });
          }

          // Generate PDF from the AI-formatted text
          await generatePDF(fullFormattedText);
          
          setMessages(prev => {
            const newMessages = [...prev];
            const last = newMessages[newMessages.length - 1];
            if (last && last.role === 'model') {
              last.content = fullFormattedText + "\n\n---\n**Aapka Smart PDF download ho gaya hai! (Generated by India GPT)**";
            }
            return newMessages;
          });
        }
      } catch (error) {
        console.error("Error creating PDF:", error);
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages.pop();
          newMessages.push({ role: 'model', content: "I encountered an error while creating the PDF. Please try again." });
          return newMessages;
        });
      } finally {
        setIsThinking(false);
      }
      return;
    }

    // Check for image generation intent (must specifically request visual image/photo creation)
    const textTaskKeywords = ['code', 'script', 'program', 'function', 'formula', 'math', 'solve', 'calculate', 'essay', 'letter', 'application', 'story', 'poem', 'kavita', 'notes', 'summary', 'explain', 'samjhao', 'batao', 'kaise', 'kyun', 'what', 'why', 'how', 'when', 'routine', 'plan', 'recipe', 'conclusion'];
    const hasTextTaskKeyword = textTaskKeywords.some(kw => lowerContent.includes(kw));
    const asksForVisualMedia = /\b(image|photo|picture|wallpaper|tasveer|chhavi|drawing|sketch|avatar|portrait)\b/i.test(lowerContent);

    const isExplicitImageGen = /\b(generate\s+(an?\s+)?(image|photo|picture|wallpaper|drawing|art|portrait)|create\s+(an?\s+)?(image|photo|picture|wallpaper|drawing|art)|draw\s+(an?\s+)?(image|photo|picture|drawing|sketch)|paint\s+(an?\s+)?(picture|portrait|scene)|(photo|image|tasveer|picture|drawing|wallpaper)\s+(banao|dikhaye|dikhao|karo))\b/i.test(lowerContent);
    const isImageEditWithUpload = Boolean(images && images.length > 0 && /\b(look like|pahnana|dress|change background|cinematic style|anime style|sketch style|remove background)\b/i.test(lowerContent));

    const isGenerationKeyword = (!hasTextTaskKeyword || asksForVisualMedia) && (isExplicitImageGen || isImageEditWithUpload);

    // If it's a generation request (either text-only or image-to-image)
    if (isGenerationKeyword) {
      try {
        // Add a temporary loading message
        setMessages(prev => [...prev, { role: 'model', content: 'Generating high-quality image...', isThinking: true }]);
        
        // Pass the images if they exist (image-to-image)
        const imageUrl = await generateImage(content, images);
        
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages.pop(); // Remove placeholder
          
          if (imageUrl) {
            newMessages.push({ 
              role: 'model', 
              content: `Here is the image you requested based on: "${content}"`, 
              images: [imageUrl] 
            });
          } else {
            newMessages.push({ 
              role: 'model', 
              content: "I apologize, but I couldn't generate an image for that prompt. Please try a different description." 
            });
          }
          return newMessages;
        });
      } catch (error: any) {
        console.error("Error generating image:", error);
        
        let errorMessage = "An error occurred while generating the image.";
        if (error?.status === 429 || error?.message?.includes('429') || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('quota')) {
          errorMessage = "You have exceeded your image generation quota. Please check your API plan or try again later.";
        }
        
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages.pop();
          newMessages.push({ role: 'model', content: errorMessage });
          return newMessages;
        });
      } finally {
        setIsThinking(false);
      }
      return;
    }

    try {
      const stream = streamChatResponse(messages, content, images, 'gemini-3.1-flash-lite', persona, userName || undefined, language);
      let fullResponse = '';
      let responseImages: string[] = [];
      let isFirstChunk = true;
      
      // Add a placeholder message for the AI response
      setMessages(prev => [...prev, { role: 'model', content: '' }]);

      for await (const chunk of stream) {
        if (chunk.error) {
           throw new Error(chunk.error);
        }
        if (isFirstChunk) {
          setIsThinking(false);
          isFirstChunk = false;
        }
        const text = chunk.text || '';
        fullResponse += text;
        
        // Check for image in the chunk
        if (chunk.image && !responseImages.includes(chunk.image)) {
          responseImages.push(chunk.image);
        } else if (chunk.candidates?.[0]?.content?.parts) {
            for (const part of chunk.candidates[0].content.parts) {
                if (part.inlineData) {
                    const newImg = `data:image/png;base64,${part.inlineData.data}`;
                    if (!responseImages.includes(newImg)) {
                      responseImages.push(newImg);
                    }
                }
            }
        }
        
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          if (lastMessage.role === 'model') {
            lastMessage.content = fullResponse;
            if (responseImages.length > 0) {
                lastMessage.images = responseImages;
            }
          }
          return newMessages;
        });
      }
    } catch (error: any) {
      console.error("Error generating response:", error);
      let errorMessage = error?.message || "I apologize, but I encountered an error. Please try again.";
      
      if (error.status === 403 || error.message?.includes('403') || error.message?.includes('plan limit')) {
        errorMessage = error.message || "You have reached your plan limits. Please upgrade to continue.";
        setIsPricingOpen(true);
      } else if (error.status === 429 || error.message?.includes('429') || error.message?.includes('rate limit')) {
        errorMessage = "I'm receiving too many requests right now. Please wait a moment and try again.";
      }
      
      setMessages(prev => {
        const newMessages = [...prev];
        const lastMessage = newMessages[newMessages.length - 1];
        if (lastMessage && lastMessage.role === 'model' && !lastMessage.content) {
          lastMessage.content = errorMessage;
          return newMessages;
        }
        return [...newMessages, { role: 'model', content: errorMessage }];
      });
    } finally {
      setIsThinking(false);
    }
  };

  const handleNewChat = () => {
    setMessages([]);
    setCurrentSessionId('');
    setIsThinking(false);
    setChatId(prev => prev + 1); // Increment ID to reset ChatInput state
  };

  const handleLogout = () => {
    try {
      googleLogout();
    } catch (_) {}
    localStorage.removeItem('india_ai_user_name');
    localStorage.removeItem('india_ai_user_email');
    localStorage.removeItem('india_ai_user_id');
    setUserName(null);
    setUserEmail(null);
    setUserId('');
    setLoginStep('google');
    setTempName('');
    setTempEmail('');
    setTempDob('');
    setMessages([]);
    setCurrentSessionId('');
    setShowNameModal(true);
  };

  // Save chat history whenever messages change
  useEffect(() => {
    if (messages.length === 0 || !userId) return;
    
    setChatHistory(prev => {
      let activeSessionId = currentSessionId;
      if (!activeSessionId) {
        activeSessionId = uuidv4();
        setCurrentSessionId(activeSessionId);
      }
      
      const existingIdx = prev.findIndex(s => s.id === activeSessionId);
      const title = messages[0]?.content.substring(0, 30) + (messages[0]?.content.length > 30 ? '...' : '');
      const newSession: ChatSession = {
        id: activeSessionId,
        title: title || 'New Chat',
        messages: [...messages],
        date: new Date().toISOString()
      };

      const updated = existingIdx >= 0 
        ? prev.map(s => s.id === activeSessionId ? newSession : s)
        : [newSession, ...prev];
        
      localStorage.setItem(`india_ai_chats_${userId}`, JSON.stringify(updated));
      return updated;
    });
  }, [messages, userId, currentSessionId]);

  const handleSelectChat = (sessionId: string) => {
    const session = chatHistory.find(s => s.id === sessionId);
    if (session) {
      setCurrentSessionId(sessionId);
      setMessages(session.messages);
      if (window.innerWidth < 768) setIsSidebarOpen(false);
    }
  };

  const handleDeleteChat = (sessionId: string) => {
    setChatHistory(prev => {
      const updated = prev.filter(s => s.id !== sessionId);
      localStorage.setItem(`india_ai_chats_${userId}`, JSON.stringify(updated));
      return updated;
    });
    if (currentSessionId === sessionId) {
      handleNewChat();
    }
  };

  return (
    <div className="flex h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans overflow-hidden relative">
      <InterstitialAd 
        isOpen={isAdOpen} 
        onComplete={() => {
          setIsAdOpen(false);
          if (pendingAction) {
            pendingAction();
            setPendingAction(null);
          }
        }} 
      />
      {/* Background Animated Drift Effect */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute inset-[-10%] bg-cover bg-center bg-no-repeat opacity-15 dark:opacity-10 animate-drift"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1542282088-fe8426682b8f?q=80&w=3200&auto=format&fit=crop)' }}
        />
        <div className="absolute inset-0 bg-slate-50/90 dark:bg-slate-950/90" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 animate-show-text mix-blend-overlay">
          <h1 className="text-4xl md:text-6xl font-black text-white/40 drop-shadow-[0_0_15px_rgba(255,165,0,0.5)] tracking-widest text-center px-4 uppercase">
            I am India<br/>come back 2026
          </h1>
        </div>
      </div>

      <div className="z-10 flex h-full w-full">
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)} 
          onNewChat={handleNewChat}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenSubscription={() => setIsPricingOpen(true)}
          chatHistory={chatHistory}
          currentSessionId={currentSessionId}
          onSelectChat={handleSelectChat}
          onDeleteChat={handleDeleteChat}
          userName={userName}
          userEmail={userEmail}
          onOpenLoginModal={() => {
            setLoginStep('google');
            setShowNameModal(true);
          }}
          onLogout={handleLogout}
          onOpenLiveCamera={() => setIsLiveCameraOpen(true)}
          onOpenScreenShare={() => setIsLiveScreenShareOpen(true)}
        />

      <div className="flex-1 flex flex-col h-full relative w-full">
        {/* Header */}
        <header className="h-14 border-b border-slate-200 dark:border-slate-800 flex items-center px-4 justify-between bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm z-10">
          <div className="flex items-center">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="md:hidden p-2 -ml-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            >
              <Menu size={24} />
            </button>
            <button
              onClick={() => setIsAdminOpen(true)}
              className="hidden md:flex ml-2 p-1.5 items-center gap-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs font-medium"
              title="Admin Dashboard"
            >
              <Shield size={16} /> Admin
            </button>
          </div>
          
          <h1 className="font-semibold text-lg flex items-center justify-center flex-1 gap-2">
            India GPT
            <div className="flex items-center gap-1 ml-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-full">
              <button 
                onClick={() => setPersona('Female')}
                className={`px-2 py-0.5 text-[10px] rounded-full transition-all ${persona === 'Female' ? 'bg-orange-500 text-white shadow-sm' : 'text-slate-500'}`}
              >
                Female
              </button>
              <button 
                onClick={() => setPersona('Male')}
                className={`px-2 py-0.5 text-[10px] rounded-full transition-all ${persona === 'Male' ? 'bg-blue-500 text-white shadow-sm' : 'text-slate-500'}`}
              >
                Male
              </button>
            </div>
            <div className="flex items-center gap-1 ml-2 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-full text-xs">
              <Globe size={12} className="text-slate-500" />
              <select 
                value={language} 
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-transparent border-none text-slate-700 dark:text-slate-200 outline-none text-[10px] pr-2 cursor-pointer"
              >
                <option value="Hinglish">Hinglish</option>
                <option value="Hindi">Hindi</option>
                <option value="English">English</option>
                <option value="Bhojpuri">Bhojpuri</option>
                <option value="Marathi">Marathi</option>
                <option value="Tamil">Tamil</option>
                <option value="Telugu">Telugu</option>
                <option value="Bengali">Bengali</option>
              </select>
            </div>
          </h1>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-xs font-semibold rounded-full border border-green-200 dark:border-green-800/50 mr-1">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              {new Date().toLocaleString('en-US', { month: 'short' })} Update Active!
            </div>
            <button 
              onClick={() => setIsLiveCameraOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-orange-500/20 to-amber-500/20 hover:from-orange-500/30 hover:to-amber-500/30 text-orange-600 dark:text-orange-400 text-xs font-bold rounded-full border border-orange-500/30 transition-all shadow-sm"
              title="Live Camera Vision"
            >
              <Camera size={14} />
              <span className="hidden sm:inline">Live Camera</span>
            </button>
            <button 
              onClick={() => setIsLiveScreenShareOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 text-cyan-600 dark:text-cyan-400 text-xs font-bold rounded-full border border-cyan-500/30 transition-all shadow-sm"
              title="Live Screen Share"
            >
              <Monitor size={14} />
              <span className="hidden sm:inline">Screen Share</span>
            </button>
            <button
              onClick={() => {
                setLoginStep('google');
                setShowNameModal(true);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-full border border-slate-300 dark:border-slate-700 transition-colors shadow-sm"
              title={userEmail ? `Google Account: ${userEmail}` : "Google Account se Login Karein"}
            >
              <svg viewBox="0 0 24 24" width="14" height="14" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
                <g transform="matrix(1, 0, 0, 1, 27.009001, -39.238998)">
                  <path fill="#4285F4" d="M -3.264 51.509 C -3.264 50.719 -3.334 49.969 -3.454 49.239 L -14.754 49.239 L -14.754 52.749 L -8.284 52.749 C -8.574 53.879 -9.254 54.819 -10.204 55.449 L -10.204 57.779 L -6.324 57.779 C -4.054 55.699 -2.764 52.569 -3.264 51.509 Z"/>
                  <path fill="#34A853" d="M -14.754 63.239 C -11.514 63.239 -8.804 62.159 -6.824 60.279 L -10.204 57.949 C -11.274 58.669 -12.654 59.109 -14.754 59.109 C -18.774 59.109 -22.174 56.459 -23.384 52.889 L -27.384 52.889 L -27.384 55.989 C -25.104 60.519 -20.274 63.239 -14.754 63.239 Z"/>
                  <path fill="#FBBC05" d="M -23.384 52.889 C -23.704 51.949 -23.884 50.949 -23.884 49.919 C -23.884 48.889 -23.704 47.889 -23.384 46.949 L -23.384 43.849 L -27.384 43.849 C -28.204 45.479 -28.664 47.319 -28.664 49.239 C -28.664 51.159 -28.204 52.999 -27.384 54.629 L -23.384 52.889 Z"/>
                  <path fill="#EA4335" d="M -14.754 40.739 C -12.984 40.739 -11.404 41.349 -10.154 42.539 L -6.744 39.129 C -8.844 37.169 -11.544 36.009 -14.754 36.009 C -20.274 36.009 -25.104 38.729 -27.384 43.259 L -23.384 46.359 C -22.174 42.789 -18.774 40.739 -14.754 40.739 Z"/>
                </g>
              </svg>
              <span className="hidden sm:inline truncate max-w-[120px]">
                {userEmail || userName || 'Google Account'}
              </span>
            </button>
            <button 
              onClick={() => setShowHistoryModal(true)}
              className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hidden md:block"
              title="History Log"
            >
              <FileText size={20} />
            </button>
            <button 
              onClick={() => setIsPricingOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-orange-500 to-rose-500 text-white text-xs font-bold rounded-full shadow-sm hover:shadow-md transition-all"
            >
              <Crown size={14} /> 
              {userPlan === 'FREE' ? 'PRO' : userPlan}
            </button>
            <button 
              onClick={handleNewChat}
              className="p-2 -mr-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hidden md:block"
              title="New Chat"
            >
              <Plus size={24} />
            </button>
            <button 
              onClick={handleLogout}
              className="p-2 ml-1 text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition-colors flex items-center gap-1 font-bold text-sm"
              title="Logout"
            >
              <LogOut size={20} />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </header>

        {/* Chat Area */}
        <main className="flex-1 overflow-y-auto scroll-smooth">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-start pt-8 md:justify-center md:pt-0 p-4 md:p-8 text-center overflow-y-auto">
              <div className="mb-4 animate-fade-in">
                <h2 className="text-2xl md:text-4xl font-bold text-slate-800 dark:text-white mb-1">
                  Welcome, {userName || 'Friend'}!
                </h2>
                <p className="text-slate-500 dark:text-slate-400 text-base md:text-lg">
                  Aapka swagat hai India GPT mein. Main aapki kaise madad kar sakta hoon?
                </p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full max-w-3xl">
                <button 
                  onClick={() => setIsLiveCameraOpen(true)}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-gradient-to-br from-orange-500/10 via-amber-500/10 to-transparent dark:from-orange-950/40 dark:via-amber-950/20 dark:to-slate-900 hover:bg-orange-500/15 border-2 border-orange-500/40 hover:border-orange-500/70 rounded-2xl transition-all shadow-sm group text-left"
                >
                  <div className="p-2 bg-gradient-to-tr from-orange-600 to-amber-500 text-white rounded-xl shadow-md shadow-orange-500/25 group-hover:scale-105 transition-transform flex items-center justify-between w-full">
                    <Camera size={22} />
                    <span className="text-[10px] bg-green-500 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                      Live
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-1">
                      Live Camera
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                      Dikhayein aur Poochein
                    </span>
                  </div>
                </button>

                <button 
                  onClick={() => setIsLiveScreenShareOpen(true)}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-gradient-to-br from-cyan-500/10 via-blue-500/10 to-transparent dark:from-cyan-950/40 dark:via-blue-950/20 dark:to-slate-900 hover:bg-cyan-500/15 border-2 border-cyan-500/40 hover:border-cyan-500/70 rounded-2xl transition-all shadow-sm group text-left"
                >
                  <div className="p-2 bg-gradient-to-tr from-cyan-600 to-blue-500 text-white rounded-xl shadow-md shadow-cyan-500/25 group-hover:scale-105 transition-transform flex items-center justify-between w-full">
                    <Monitor size={22} />
                    <span className="text-[10px] bg-cyan-500 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                      Share
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-1">
                      Live Screen Share
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                      Screen Dekh Kar Madad
                    </span>
                  </div>
                </button>

                <button 
                  onClick={() => handleSendMessage("Generate an image of a futuristic Indian city")}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl transition-colors"
                >
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
                    <Image size={24} />
                  </div>
                  <span className="font-medium text-slate-700 dark:text-slate-200">Create images</span>
                </button>

                <button 
                  onClick={() => handleSendMessage("Teach me about Quantum Computing")}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl transition-colors"
                >
                  <div className="p-2 bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 rounded-lg">
                    <BookOpen size={24} />
                  </div>
                  <span className="font-medium text-slate-700 dark:text-slate-200">Learn</span>
                </button>

                <button 
                  onClick={() => handleSendMessage("Write a short story about a robot in Mumbai")}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl transition-colors"
                >
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg">
                    <PenLine size={24} />
                  </div>
                  <span className="font-medium text-slate-700 dark:text-slate-200">Write</span>
                </button>

                <button 
                  onClick={() => handleSendMessage("How do I make authentic Masala Chai?")}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl transition-colors"
                >
                  <div className="p-2 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400 rounded-lg">
                    <Lightbulb size={24} />
                  </div>
                  <span className="font-medium text-slate-700 dark:text-slate-200">How to</span>
                </button>

                <button 
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.multiple = true;
                    input.accept = 'image/*';
                    input.onchange = (e: any) => {
                      const files = Array.from(e.target.files || []);
                      if (files.length > 0) {
                        const images: string[] = [];
                        let processed = 0;
                        files.forEach(file => {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            images.push(reader.result as string);
                            processed++;
                            if (processed === files.length) {
                              handleSendMessage("Make a PDF of these images", images);
                            }
                          };
                          reader.readAsDataURL(file as any);
                        });
                      }
                    };
                    input.click();
                  }}
                  className="flex flex-col items-start justify-between p-3 h-28 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl transition-colors"
                >
                  <div className="p-2 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg">
                    <FileText size={24} />
                  </div>
                  <span className="font-medium text-slate-700 dark:text-slate-200">Images to PDF</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="py-6 space-y-2">
              {messages.map((msg, idx) => (
                <ChatMessage 
                  key={idx} 
                  role={msg.role} 
                  content={msg.content}
                  images={msg.images}
                  isThinking={msg.role === 'model' && !msg.content && (!msg.images || msg.images.length === 0)}
                />
              ))}
              {isThinking && (!messages.length || messages[messages.length - 1].role === 'user') && (
                <ChatMessage role="model" content="" isThinking={true} />
              )}
              <div ref={messagesEndRef} className="h-4" />
            </div>
          )}
        </main>

        {/* Input Area */}
        <div className="bg-white dark:bg-slate-950 p-2 md:p-4">
          <ChatInput 
            key={chatId}
            onSend={handleSendMessage} 
            onLiveChat={() => setIsLiveOpen(true)}
            onLiveCamera={() => setIsLiveCameraOpen(true)}
            onLiveScreenShare={() => setIsLiveScreenShareOpen(true)}
            onScanText={() => setIsScannerOpen(true)}
            disabled={isThinking} 
          />
        </div>
      </div>

      <TextScannerModal isOpen={isScannerOpen} onClose={() => setIsScannerOpen(false)} />
      <HelpAIAssistant />
      <LiveSession isOpen={isLiveOpen} onClose={() => setIsLiveOpen(false)} />
      <LiveCameraModal 
        isOpen={isLiveCameraOpen} 
        onClose={() => setIsLiveCameraOpen(false)}
        userName={userName || 'Dost'}
        persona={persona}
        language={language}
        onSaveToChat={(newMessages) => {
          setMessages(prev => [...prev, ...newMessages]);
        }}
      />
      <LiveScreenShareModal 
        isOpen={isLiveScreenShareOpen} 
        onClose={() => setIsLiveScreenShareOpen(false)}
        userName={userName || 'Dost'}
        persona={persona}
        language={language}
        onSaveToChat={(newMessages) => {
          setMessages(prev => [...prev, ...newMessages]);
        }}
      />
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        onOpenLiveChat={() => setIsLiveOpen(true)}
      />

      {/* History Log Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 border border-slate-200 dark:border-slate-800 flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FileText className="text-orange-500" />
                Search & Chat History
              </h2>
              <button 
                onClick={() => setShowHistoryModal(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
              >
                <Plus className="rotate-45 text-slate-500" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
              {chatHistory.length === 0 ? (
                <p className="text-center text-slate-500 py-10 italic">No search or chat history yet.</p>
              ) : (
                chatHistory.map((session) => (
                  <div key={session.id} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center justify-between group transition-all hover:bg-slate-100 dark:hover:bg-slate-800">
                    <div 
                      className="flex-1 cursor-pointer"
                      onClick={() => {
                        handleSelectChat(session.id);
                        setShowHistoryModal(false);
                      }}
                    >
                      <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm mb-1">{session.title}</h3>
                      <p className="text-xs text-slate-500">{new Date(session.date).toLocaleString()}</p>
                      <p className="text-xs text-slate-400 mt-2 line-clamp-1">{session.messages[0]?.content}</p>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteChat(session.id);
                      }}
                      className="p-2 text-red-500 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-lg transition-colors ml-4"
                      title="Delete this history"
                    >
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
                    </button>
                  </div>
                ))
              )}
            </div>
            
            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest">
                All Searches & Images are Saved Locally
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Login Screen Modal */}
      {showNameModal && (
        <div 
          onClick={(e) => { if (e.target === e.currentTarget) setShowNameModal(false); }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in"
        >
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-8 border border-slate-200 dark:border-slate-800 text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
            
            {/* Always visible close button */}
            <button 
              type="button"
              onClick={() => setShowNameModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full transition-colors bg-slate-100 dark:bg-slate-800"
              title="Close"
            >
              <X size={20} />
            </button>

            <div className="w-20 h-20 bg-gradient-to-br from-orange-500 via-slate-100 to-green-500 rounded-3xl flex items-center justify-center text-slate-900 text-2xl font-bold shadow-xl mx-auto mb-5 border-4 border-white dark:border-slate-800">
              GPT
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">India Chat GPT</h2>
            
            {loginStep === 'google' && (
              <div className="space-y-4">
                <p className="text-slate-600 dark:text-slate-300 text-sm">
                  Apne <b>Google / Gmail Account</b> se login karein ya direct chat shuru karein.
                </p>
                
                <button
                  type="button"
                  onClick={handleGoogleClick}
                  className="w-full py-3.5 px-6 bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-orange-500 text-slate-800 dark:text-white rounded-2xl font-bold text-base shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-3 active:scale-[0.99]"
                >
                  <svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg">
                    <g transform="matrix(1, 0, 0, 1, 27.009001, -39.238998)">
                      <path fill="#4285F4" d="M -3.264 51.509 C -3.264 50.719 -3.334 49.969 -3.454 49.239 L -14.754 49.239 L -14.754 52.749 L -8.284 52.749 C -8.574 53.879 -9.254 54.819 -10.204 55.449 L -10.204 57.779 L -6.324 57.779 C -4.054 55.699 -2.764 52.569 -3.264 51.509 Z"/>
                      <path fill="#34A853" d="M -14.754 63.239 C -11.514 63.239 -8.804 62.159 -6.824 60.279 L -10.204 57.949 C -11.274 58.669 -12.654 59.109 -14.754 59.109 C -18.774 59.109 -22.174 56.459 -23.384 52.889 L -27.384 52.889 L -27.384 55.989 C -25.104 60.519 -20.274 63.239 -14.754 63.239 Z"/>
                      <path fill="#FBBC05" d="M -23.384 52.889 C -23.704 51.949 -23.884 50.949 -23.884 49.919 C -23.884 48.889 -23.704 47.889 -23.384 46.949 L -23.384 43.849 L -27.384 43.849 C -28.204 45.479 -28.664 47.319 -28.664 49.239 C -28.664 51.159 -28.204 52.999 -27.384 54.629 L -23.384 52.889 Z"/>
                      <path fill="#EA4335" d="M -14.754 40.739 C -12.984 40.739 -11.404 41.349 -10.154 42.539 L -6.744 39.129 C -8.844 37.169 -11.544 36.009 -14.754 36.009 C -20.274 36.009 -25.104 38.729 -27.384 43.259 L -23.384 46.359 C -22.174 42.789 -18.774 40.739 -14.754 40.739 Z"/>
                    </g>
                  </svg>
                  Google Account se Sign In
                </button>

                {/* 1-Click Quick Connect as Keshav / Current User */}
                <button
                  type="button"
                  onClick={() => {
                    const email = tempEmail || 'keshavraj5005@gmail.com';
                    const name = tempName || 'Keshav';
                    localStorage.setItem('india_ai_user_email', email);
                    localStorage.setItem('india_ai_user_name', name);
                    setUserEmail(email);
                    setUserName(name);
                    setShowNameModal(false);
                  }}
                  className="w-full py-2.5 px-4 bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 rounded-xl font-medium text-xs flex items-center justify-center gap-2 transition-colors border border-orange-500/20"
                >
                  ⚡ 1-Click: {tempEmail || 'keshavraj5005@gmail.com'} ke sath shuru karein
                </button>

                <div className="flex items-center my-2">
                  <div className="flex-1 border-t border-slate-200 dark:border-slate-800"></div>
                  <span className="px-3 text-xs uppercase font-medium text-slate-400">ya Gmail / Naam likhein</span>
                  <div className="flex-1 border-t border-slate-200 dark:border-slate-800"></div>
                </div>

                <form onSubmit={handleSaveName} className="space-y-3 text-left">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 ml-1">Gmail / Email ID (Optional)</label>
                    <input
                      type="email"
                      placeholder="e.g. keshavraj5005@gmail.com"
                      value={tempEmail}
                      onChange={(e) => setTempEmail(e.target.value)}
                      className="w-full mt-1 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-orange-500 outline-none text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 ml-1">Aapka Naam</label>
                    <input
                      type="text"
                      placeholder="Apna naam likhein (e.g. Keshav)"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      className="w-full mt-1 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-orange-500 outline-none text-slate-900 dark:text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-xl font-bold text-sm shadow-md transition-all active:scale-[0.99]"
                  >
                    India GPT Kholein 🚀
                  </button>
                </form>

                <button
                  type="button"
                  onClick={() => setShowNameModal(false)}
                  className="w-full py-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 text-xs font-semibold transition-colors"
                >
                  Direct Chat Shuru Karein (Bina Login ke)
                </button>
              </div>
            )}

            {loginStep === 'dob' && (
              <form onSubmit={handleSaveName} className="space-y-4 animate-fade-in">
                <p className="text-slate-500 dark:text-slate-400 mb-4 text-sm">
                  Welcome, {tempName}! Kripya apni Janm Tithi (Date of Birth) confirm karein.
                </p>
                <div className="text-left space-y-1">
                  <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 ml-1">Date of Birth</label>
                  <input
                    type="date"
                    value={tempDob}
                    onChange={(e) => setTempDob(e.target.value)}
                    autoFocus
                    className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-base focus:ring-2 focus:ring-orange-500 transition-all dark:text-white"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => handleSaveName()}
                    className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl font-medium text-sm transition-all"
                  >
                    Skip
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white rounded-xl font-bold text-sm shadow-md transition-all active:scale-[0.99]"
                  >
                    Start Chatting
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
      
      {paymentStatus && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl border border-slate-200 dark:border-slate-800">
            {paymentStatus === 'success' ? (
              <>
                <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Check size={40} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Payment Successful!</h3>
                <p className="text-slate-600 dark:text-slate-400 mb-8">Badhai ho! Aapka PRO plan successfully unlock ho gaya hai. Ab aap premium features enjoy kar sakte hain.</p>
                <button 
                  onClick={() => setPaymentStatus(null)} 
                  className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold shadow-lg shadow-green-600/20 transition-transform active:scale-95"
                >
                  Start Using Pro
                </button>
              </>
            ) : (
              <>
                <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-6">
                  <X size={40} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Payment Failed</h3>
                <p className="text-slate-600 dark:text-slate-400 mb-8">Aapka payment fail ya cancel ho gaya hai. Kripya apne bank details check karein aur dobara try karein.</p>
                <button 
                  onClick={() => { setPaymentStatus(null); setIsPricingOpen(true); }} 
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold shadow-lg shadow-red-600/20 transition-transform active:scale-95"
                >
                  Try Again
                </button>
              </>
            )}
          </div>
        </div>
      )}

      <PricingModal 
        isOpen={isPricingOpen} 
        onClose={() => setIsPricingOpen(false)} 
        userId={userId} 
        onSuccess={() => {
          setIsPricingOpen(false);
          setPaymentStatus('success');
          setUserPlan('PRO');
        }}
      />
      <MyPlanModal isOpen={isMyPlanOpen} onClose={() => setIsMyPlanOpen(false)} userId={userId} onUpgrade={() => { setIsMyPlanOpen(false); setIsPricingOpen(true); }} />
      {isAdminOpen && <AdminDashboard onClose={() => setIsAdminOpen(false)} />}
      </div>
    </div>
  );
}

export default App;
