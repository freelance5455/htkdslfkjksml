/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { KhataProvider, useKhata } from './context/KhataContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { PinLockModal } from './components/common/PinLockModal';
import { TransactionModal } from './components/transactions/TransactionModal';
import { AddCategoryModal } from './components/common/AddCategoryModal';
import { DashboardView } from './components/dashboard/DashboardView';
import { DailyKhataView } from './components/transactions/DailyKhataView';
import { BudgetView } from './components/budget/BudgetView';
import { LoansAndBillsView } from './components/loans/LoansAndBillsView';
import { ReportsView } from './components/reports/ReportsView';
import { CalculatorModal } from './components/calculator/CalculatorModal';
import { SavingsTrackerModal } from './components/savings/SavingsTrackerModal';
import { FamilyManagementModal } from './components/family/FamilyManagementModal';
import { BackupRestoreModal } from './components/backup/BackupRestoreModal';
import { AndroidApkModal } from './components/android/AndroidApkModal';
import { WifiOff } from 'lucide-react';

function MainLayout() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans text-slate-900">
      {/* Top Bar Header */}
      <Header currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Offline Toast if disconnected */}
      {!isOnline && (
        <div className="bg-amber-600 text-white text-xs font-semibold py-1.5 px-4 text-center flex items-center justify-center gap-1.5 shadow-sm">
          <WifiOff className="w-3.5 h-3.5" />
          <span>ऑफ़लाइन मोड (Offline Mode) — आपका डेटा आपके फ़ोन में सुरक्षित है।</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-6 pt-4 pb-20 md:pb-8">
        {currentTab === 'home' && <DashboardView onNavigateTab={setCurrentTab} />}
        {currentTab === 'khata' && <DailyKhataView />}
        {currentTab === 'budget' && <BudgetView />}
        {currentTab === 'loans_bills' && <LoansAndBillsView />}
        {currentTab === 'more' && <ReportsView />}
      </main>

      {/* Mobile Fixed Bottom Navigation */}
      <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Global Modals & Drawers */}
      <PinLockModal />
      <TransactionModal />
      <AddCategoryModal />
      <CalculatorModal />
      <SavingsTrackerModal />
      <FamilyManagementModal />
      <BackupRestoreModal />
      <AndroidApkModal />
    </div>
  );
}

export default function App() {
  return (
    <KhataProvider>
      <MainLayout />
    </KhataProvider>
  );
}
