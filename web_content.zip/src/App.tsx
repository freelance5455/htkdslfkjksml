import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Header } from './components/Header';
import { BottomNav, TabId } from './components/BottomNav';
import { TapView } from './components/TapView';
import { WithdrawView } from './components/WithdrawView';
import { BoostView } from './components/BoostView';
import { EarnView } from './components/EarnView';
import { FriendsView } from './components/FriendsView';
import { ReceiptModal } from './components/ReceiptModal';
import { RulesModal } from './components/RulesModal';
import { OfflineModal } from './components/OfflineModal';
import { WatchAdModal } from './components/WatchAdModal';
import { InstallAppModal } from './components/InstallAppModal';
import {
  COINS_PER_PKR,
  INITIAL_UPGRADES,
  INITIAL_TASKS,
  INITIAL_DAILY_STREAKS,
  INITIAL_LIVE_PAYOUTS,
  INITIAL_MISSIONS,
  RECENT_NAMES_POOL,
  CITIES_POOL,
} from './data/mockData';
import { UpgradeItem, WithdrawalRecord, EarnTask, DailyStreakDay, LivePayoutItem, Mission } from './types';
import { useAudioFeedback } from './hooks/useAudioFeedback';

const STORAGE_KEY = 'taptapcash_userdata_v2';

export default function App() {
  // Primary State
  const [coins, setCoins] = useState<number>(3500); // 35 PKR starter
  const [energy, setEnergy] = useState<number>(500);
  const [maxEnergy, setMaxEnergy] = useState<number>(500);
  const [tapPower, setTapPower] = useState<number>(1);
  const [energyRegenRate, setEnergyRegenRate] = useState<number>(2);
  const [critChance, setCritChance] = useState<number>(0.03);
  const [level, setLevel] = useState<number>(1);
  const [totalTaps, setTotalTaps] = useState<number>(0);

  const [upgrades, setUpgrades] = useState<UpgradeItem[]>(INITIAL_UPGRADES);
  const [tasks, setTasks] = useState<EarnTask[]>(INITIAL_TASKS);
  const [dailyStreaks, setDailyStreaks] = useState<DailyStreakDay[]>(INITIAL_DAILY_STREAKS);
  const [missions, setMissions] = useState<Mission[]>(INITIAL_MISSIONS);
  const [withdrawalHistory, setWithdrawalHistory] = useState<WithdrawalRecord[]>([]);
  const [referralCode] = useState<string>('CASH-9821');
  const [referralBonusClaimable, setReferralBonusClaimable] = useState<number>(5000);
  const [freeSpinsAvailable, setFreeSpinsAvailable] = useState<number>(3);

  // Settings & Navigation
  const { isMuted, toggleMute } = useAudioFeedback();
  const [activeTab, setActiveTab] = useState<TabId>('tap');
  const [hapticsEnabled, setHapticsEnabled] = useState<boolean>(true);
  const [rulesOpen, setRulesOpen] = useState<boolean>(false);
  const [activeReceipt, setActiveReceipt] = useState<WithdrawalRecord | null>(null);
  const [isWatchAdOpen, setIsWatchAdOpen] = useState<boolean>(false);
  const [installModalOpen, setInstallModalOpen] = useState<boolean>(false);

  // Energy Refill timer
  const [canRefillEnergy, setCanRefillEnergy] = useState<boolean>(true);
  const [refillCooldown, setRefillCooldown] = useState<number>(0);

  // Live Payouts Ticker
  const [livePayouts, setLivePayouts] = useState<LivePayoutItem[]>(INITIAL_LIVE_PAYOUTS);

  // Offline earnings modal
  const [offlineReward, setOfflineReward] = useState<{ coins: number; seconds: number } | null>(null);

  // Calculate current passive income rate
  const passiveRate = useMemo(() => {
    return upgrades
      .filter((u) => u.category === 'idle')
      .reduce((sum, u) => sum + u.currentValue, 0);
  }, [upgrades]);

  const pkrBalance = coins / COINS_PER_PKR;

  // Load saved state on mount & calculate offline earnings
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.coins === 'number') setCoins(parsed.coins);
        if (typeof parsed.energy === 'number') setEnergy(parsed.energy);
        if (typeof parsed.maxEnergy === 'number') setMaxEnergy(parsed.maxEnergy);
        if (typeof parsed.tapPower === 'number') setTapPower(parsed.tapPower);
        if (typeof parsed.energyRegenRate === 'number') setEnergyRegenRate(parsed.energyRegenRate);
        if (typeof parsed.critChance === 'number') setCritChance(parsed.critChance);
        if (typeof parsed.level === 'number') setLevel(parsed.level);
        if (Array.isArray(parsed.upgrades)) setUpgrades(parsed.upgrades);
        if (Array.isArray(parsed.withdrawalHistory)) setWithdrawalHistory(parsed.withdrawalHistory);
        if (Array.isArray(parsed.tasks)) setTasks(parsed.tasks);
        if (Array.isArray(parsed.dailyStreaks)) setDailyStreaks(parsed.dailyStreaks);
        if (Array.isArray(parsed.missions)) setMissions(parsed.missions);

        // Check offline earnings if player was away and has passive income
        const lastActive = parsed.lastActiveTimestamp;
        if (lastActive && typeof lastActive === 'number') {
          const now = Date.now();
          const elapsedSecs = Math.floor((now - lastActive) / 1000);
          const currentIdleRate = (parsed.upgrades || [])
            .filter((u: UpgradeItem) => u.category === 'idle')
            .reduce((s: number, u: UpgradeItem) => s + (u.currentValue || 0), 0);

          if (elapsedSecs > 15 && currentIdleRate > 0) {
            const cappedSecs = Math.min(elapsedSecs, 8 * 3600); // Max 8 hours
            const earned = Math.floor(cappedSecs * currentIdleRate);
            if (earned > 20) {
              setOfflineReward({ coins: earned, seconds: cappedSecs });
            }
          }
        }
      }
    } catch {
      // Ignore parse errors
    }
  }, []);

  // Save state periodically and on unload
  useEffect(() => {
    const dataToSave = {
      coins,
      energy,
      maxEnergy,
      tapPower,
      energyRegenRate,
      critChance,
      level,
      upgrades,
      withdrawalHistory,
      tasks,
      dailyStreaks,
      missions,
      lastActiveTimestamp: Date.now(),
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    } catch {
      // quota or private mode
    }
  }, [coins, energy, maxEnergy, tapPower, energyRegenRate, critChance, level, upgrades, withdrawalHistory, tasks, dailyStreaks, missions]);

  // Main 1-second game loop (Stamina regen, idle coins, refill cooldown)
  useEffect(() => {
    const interval = setInterval(() => {
      // Regenerate energy
      setEnergy((prev) => Math.min(maxEnergy, prev + energyRegenRate));

      // Add passive coins if any
      if (passiveRate > 0) {
        setCoins((prev) => prev + passiveRate);
      }

      // Decrement refill cooldown
      setRefillCooldown((prev) => {
        if (prev <= 1) {
          setCanRefillEnergy(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [maxEnergy, energyRegenRate, passiveRate]);

  // Periodically generate simulated real-time live payout notifications
  useEffect(() => {
    const interval = setInterval(() => {
      const randomName = RECENT_NAMES_POOL[Math.floor(Math.random() * RECENT_NAMES_POOL.length)];
      const randomCity = CITIES_POOL[Math.floor(Math.random() * CITIES_POOL.length)];
      const amounts = [100, 250, 500, 1000, 2500];
      const randomAmount = amounts[Math.floor(Math.random() * amounts.length)];
      const methods: ('easypaisa' | 'jazzcash')[] = ['easypaisa', 'jazzcash'];
      const randomMethod = methods[Math.floor(Math.random() * methods.length)];

      const newItem: LivePayoutItem = {
        id: String(Date.now()),
        userName: randomName,
        city: randomCity,
        amountPKR: randomAmount,
        method: randomMethod,
        timeAgo: 'Just now',
      };

      setLivePayouts((prev) => [newItem, ...prev.slice(0, 7)]);
    }, 18000);

    return () => clearInterval(interval);
  }, []);

  // Handlers
  const handleTap = (gained: number, energyCost: number) => {
    setCoins((prev) => prev + gained);
    setEnergy((prev) => Math.max(0, prev - energyCost));
    setTotalTaps((prev) => {
      const next = prev + 1;
      // Daily task milestone for taps
      if (next >= 200) {
        setTasks((prevTasks) =>
          prevTasks.map((t) =>
            t.id === 'task_daily_taps' ? { ...t, completed: true } : t
          )
        );
      }
      return next;
    });

    // Update missions of type 'taps'
    setMissions((prev) =>
      prev.map((m) =>
        m.type === 'taps' && !m.claimed
          ? { ...m, currentCount: m.currentCount + 1 }
          : m
      )
    );
  };

  const handleFullEnergyRefill = () => {
    setEnergy(maxEnergy);
    setCanRefillEnergy(false);
    setRefillCooldown(60); // 60s cooldown
  };

  const handleUpgrade = (upgradeId: string) => {
    const upgrade = upgrades.find((u) => u.id === upgradeId);
    if (!upgrade) return;

    const cost = Math.round(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.level));
    if (coins < cost) return;

    setCoins((prev) => prev - cost);

    // Update missions of type 'upgrades'
    setMissions((prev) =>
      prev.map((m) =>
        m.type === 'upgrades' && !m.claimed
          ? { ...m, currentCount: m.currentCount + 1 }
          : m
      )
    );

    const newLevel = upgrade.level + 1;
    let nextVal = upgrade.currentValue;

    // Apply attribute change
    if (upgrade.id === 'multi_tap') {
      const nextPower = tapPower + 1;
      setTapPower(nextPower);
      nextVal = nextPower;
    } else if (upgrade.id === 'energy_capacity') {
      const nextMax = maxEnergy + 100;
      setMaxEnergy(nextMax);
      setEnergy((prev) => Math.min(nextMax, prev + 100));
      nextVal = nextMax;
    } else if (upgrade.id === 'energy_regen') {
      const nextRegen = energyRegenRate + 1;
      setEnergyRegenRate(nextRegen);
      nextVal = nextRegen;
    } else if (upgrade.id === 'auto_miner_1') {
      nextVal = newLevel * 3;
    } else if (upgrade.id === 'auto_miner_2') {
      nextVal = newLevel * 15;
    } else if (upgrade.id === 'auto_miner_3') {
      nextVal = newLevel * 60;
    } else if (upgrade.id === 'crit_chance') {
      const nextCrit = Math.min(0.25, critChance + 0.03);
      setCritChance(nextCrit);
      nextVal = Math.round(nextCrit * 100);
    }

    setUpgrades((prev) =>
      prev.map((u) =>
        u.id === upgradeId
          ? {
              ...u,
              level: newLevel,
              currentValue: nextVal,
              nextValue: nextVal + 2,
            }
          : u
      )
    );

    // Calculate player rank level based on total upgrade investments
    setLevel((prev) => {
      const totalUpgradesCount = upgrades.reduce((sum, u) => sum + u.level, 0) + 1;
      const calculatedLevel = Math.max(1, Math.floor(totalUpgradesCount / 3) + 1);
      if (calculatedLevel >= 3) {
        setTasks((prevTasks) =>
          prevTasks.map((t) =>
            t.id === 'task_level_3' ? { ...t, completed: true } : t
          )
        );
      }
      return calculatedLevel;
    });
  };

  const handleProcessWithdrawal = (record: WithdrawalRecord) => {
    setCoins((prev) => Math.max(0, prev - record.coinsDebited));
    setWithdrawalHistory((prev) => [record, ...prev]);
  };

  const handleClaimDaily = (dayIndex: number) => {
    const day = dailyStreaks[dayIndex];
    if (!day || day.claimed) return;

    setCoins((prev) => prev + day.coins);
    setDailyStreaks((prev) =>
      prev.map((d, i) => (i === dayIndex ? { ...d, claimed: true, isToday: false } : d))
    );
  };

  const handleClaimTask = (taskId: string) => {
    const task = tasks.find((t) => t.id === taskId);
    if (!task || task.claimed) return;

    setCoins((prev) => prev + task.rewardCoins);
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, claimed: true, completed: true } : t))
    );
  };

  const handleSpinReward = (coinsWon: number) => {
    setCoins((prev) => prev + coinsWon);
    setFreeSpinsAvailable((prev) => Math.max(0, prev - 1));

    // Update missions of type 'spins'
    setMissions((prev) =>
      prev.map((m) =>
        m.type === 'spins' && !m.claimed
          ? { ...m, currentCount: m.currentCount + 1 }
          : m
      )
    );
  };

  const handleClaimMission = (missionId: string) => {
    const mission = missions.find((m) => m.id === missionId);
    if (!mission || mission.claimed || mission.currentCount < mission.targetCount) return;

    setCoins((prev) => prev + mission.rewardCoins);
    setMissions((prev) =>
      prev.map((m) => (m.id === missionId ? { ...m, claimed: true } : m))
    );
  };

  const handleClaimReferralBonus = () => {
    if (referralBonusClaimable <= 0) return;
    setCoins((prev) => prev + referralBonusClaimable);
    setReferralBonusClaimable(0);
  };

  const handleClaimOfflineEarnings = (multiplier: number) => {
    if (!offlineReward) return;
    setCoins((prev) => prev + offlineReward.coins * multiplier);
    setOfflineReward(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-body selection:bg-amber-500 selection:text-slate-950">
      {/* Top Bar Contract Compliant Header */}
      <Header
        coins={coins}
        pkrBalance={pkrBalance}
        soundMuted={isMuted}
        onToggleSound={toggleMute}
        hapticsEnabled={hapticsEnabled}
        onToggleHaptics={() => setHapticsEnabled(!hapticsEnabled)}
        onOpenRules={() => setRulesOpen(true)}
        onOpenInstallModal={() => setInstallModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-4xl mx-auto">
        {activeTab === 'tap' && (
          <TapView
            coins={coins}
            energy={energy}
            maxEnergy={maxEnergy}
            tapPower={tapPower}
            passiveRate={passiveRate}
            critChance={critChance}
            level={level}
            onTap={handleTap}
            onFullEnergyRefill={handleFullEnergyRefill}
            canRefillEnergy={canRefillEnergy}
            refillCooldownRemaining={refillCooldown}
            livePayouts={livePayouts}
            onOpenWithdraw={() => setActiveTab('withdraw')}
            onWatchAd={() => setIsWatchAdOpen(true)}
            onOpenInstallModal={() => setInstallModalOpen(true)}
          />
        )}

        {activeTab === 'boost' && (
          <BoostView
            coins={coins}
            upgrades={upgrades}
            onUpgrade={handleUpgrade}
            tapPower={tapPower}
            maxEnergy={maxEnergy}
            passiveRate={passiveRate}
            critChance={critChance}
          />
        )}

        {activeTab === 'earn' && (
          <EarnView
            tasks={tasks}
            dailyStreaks={dailyStreaks}
            missions={missions}
            onClaimDaily={handleClaimDaily}
            onClaimTask={handleClaimTask}
            onClaimMission={handleClaimMission}
            onSpinReward={handleSpinReward}
            freeSpinsAvailable={freeSpinsAvailable}
          />
        )}

        {activeTab === 'withdraw' && (
          <WithdrawView
            coins={coins}
            pkrBalance={pkrBalance}
            withdrawalHistory={withdrawalHistory}
            onProcessWithdrawal={handleProcessWithdrawal}
            onViewReceipt={(rec) => setActiveReceipt(rec)}
          />
        )}

        {activeTab === 'friends' && (
          <FriendsView
            referralCode={referralCode}
            totalReferralBonusClaimable={referralBonusClaimable}
            onClaimReferralBonus={handleClaimReferralBonus}
          />
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(tab) => setActiveTab(tab)}
        canClaimDaily={
          dailyStreaks.some((d) => d.isToday && !d.claimed) ||
          missions.some((m) => m.currentCount >= m.targetCount && !m.claimed)
        }
        canWithdraw={coins >= 2500}
      />

      {/* Digital Transaction E-Receipt Modal */}
      <ReceiptModal
        receipt={activeReceipt}
        onClose={() => setActiveReceipt(null)}
      />

      {/* How It Works & Payout Guide Modal */}
      <RulesModal
        isOpen={rulesOpen}
        onClose={() => setRulesOpen(false)}
      />

      {/* Offline Earnings Welcome Back Modal */}
      {offlineReward && (
        <OfflineModal
          coinsEarned={offlineReward.coins}
          secondsAway={offlineReward.seconds}
          onClaim={handleClaimOfflineEarnings}
        />
      )}

      {/* Rewarded Video Ad Modal */}
      <WatchAdModal
        isOpen={isWatchAdOpen}
        onClose={() => setIsWatchAdOpen(false)}
        rewardCoins={250}
        onRewardEarned={(reward) => {
          setCoins((c) => c + reward);
          setEnergy(maxEnergy);
        }}
      />

      {/* Mobile App Install & Download Modal */}
      <InstallAppModal
        isOpen={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
      />
    </div>
  );
}
