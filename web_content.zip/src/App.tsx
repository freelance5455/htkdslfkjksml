import React, { useState, useEffect } from 'react';
import { ParentControlProvider, useParentControl } from './context/ParentControlContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { MobileBottomNav } from './components/MobileBottomNav';
import { ChildSimulatorModal } from './components/ChildSimulatorModal';
import { ParentPinModal } from './components/ParentPinModal';
import { ChildCompanionView } from './components/ChildCompanionView';
import { DashboardView } from './components/views/DashboardView';
import { AppManagementView } from './components/views/AppManagementView';
import { CameraMicView } from './components/views/CameraMicView';
import { DeviceSettingsView } from './components/views/DeviceSettingsView';
import { LocationView } from './components/views/LocationView';
import { AlertsView } from './components/views/AlertsView';
import { PairDeviceView } from './components/views/PairDeviceView';
import { FlutterExportView } from './components/views/FlutterExportView';
import { ApkExportView } from './components/views/ApkExportView';
import { Toast } from './components/Toast';
import { Smartphone, ShieldCheck } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [appMode, setAppMode] = useState<'parent' | 'child'>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('mode') === 'child' ? 'child' : 'parent';
    }
    return 'parent';
  });
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);

  const { 
    language, 
    setIsSimulatorOpen, 
    activeDevice,
    isParentDashboardLocked 
  } = useParentControl();
  
  const isAr = language === 'ar';

  // Handle URL change or browser history
  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      setAppMode(params.get('mode') === 'child' ? 'child' : 'parent');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleSwitchToChildMode = () => {
    setAppMode('child');
    const url = new URL(window.location.href);
    url.searchParams.set('mode', 'child');
    window.history.pushState({}, '', url.toString());
  };

  const handleSwitchToParentMode = () => {
    setAppMode('parent');
    const url = new URL(window.location.href);
    url.searchParams.delete('mode');
    window.history.pushState({}, '', url.toString());
  };

  // If in Child Companion Mode
  if (appMode === 'child') {
    return (
      <ChildCompanionView onSwitchToParent={handleSwitchToParentMode} />
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col selection:bg-indigo-600 selection:text-white transition-colors duration-200">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenPairModal={() => setActiveTab('pair')}
        onOpenFlutterCode={() => setActiveTab('flutter')}
        onOpenChildMode={handleSwitchToChildMode}
        onOpenPinModal={() => setIsPinModalOpen(true)}
      />

      {/* Primary Navigation Tabs */}
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 pb-24 sm:pb-8">
        {activeTab === 'dashboard' && <DashboardView setActiveTab={setActiveTab} />}
        {activeTab === 'apps' && <AppManagementView />}
        {activeTab === 'camera_mic' && <CameraMicView />}
        {activeTab === 'settings' && <DeviceSettingsView />}
        {activeTab === 'location' && <LocationView />}
        {activeTab === 'alerts' && <AlertsView />}
        {activeTab === 'pair' && <PairDeviceView onPairedSuccess={() => setActiveTab('dashboard')} />}
        {activeTab === 'flutter' && <FlutterExportView />}
        {activeTab === 'apk' && <ApkExportView />}
      </main>

      {/* Interactive Child Phone Simulator Modal */}
      <ChildSimulatorModal />

      {/* Global In-app Toast Banner */}
      <Toast />

      {/* Parent Security PIN Modal (Keypad prompt) */}
      <ParentPinModal
        isOpen={isParentDashboardLocked || isPinModalOpen}
        onClose={() => setIsPinModalOpen(false)}
        isLockedScreen={isParentDashboardLocked}
      />

      {/* Dedicated Native Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenChildMode={handleSwitchToChildMode}
        onOpenPinModal={() => setIsPinModalOpen(true)}
      />

      {/* Mobile Floating Quick Simulator Button (Docked right above bottom navigation) */}
      <div className="fixed bottom-[70px] end-3.5 z-30 sm:hidden flex flex-col items-end gap-2">
        <button
          id="mobile-floating-simulator-btn"
          onClick={() => setIsSimulatorOpen(true)}
          className="relative p-3 bg-indigo-600 hover:bg-indigo-700 active:scale-90 text-white rounded-full shadow-lg shadow-indigo-600/30 flex items-center justify-center border-2 border-white dark:border-slate-800 transition-transform"
          title={isAr ? 'محاكي هاتف الطفل' : 'Child Phone Simulator'}
          aria-label={isAr ? 'فتح محاكي هاتف الطفل' : 'Open Child Phone Simulator'}
        >
          <Smartphone className="w-5 h-5 animate-pulse" />
          <span className="absolute -top-1 -end-1 w-3 h-3 rounded-full bg-emerald-400 border-2 border-white dark:border-slate-900" />
        </button>
      </div>

      {/* Desktop/Tablet Floating Quick Actions */}
      <div className="fixed bottom-5 end-5 z-30 hidden sm:flex flex-row gap-2">
        <button
          id="floating-child-mode-btn"
          onClick={handleSwitchToChildMode}
          className="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-purple-300 font-bold text-xs sm:text-sm rounded-xl shadow-lg border border-purple-500/30 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
          title={isAr ? 'فتح وضع هاتف الطفل الحقيقي' : 'Open Child Device View'}
        >
          <Smartphone className="w-4 h-4 text-purple-400" />
          <span>{isAr ? 'وضع هاتف الطفل (Child Mode)' : 'Child Device Mode'}</span>
        </button>

        <button
          id="floating-simulator-toggle-btn"
          onClick={() => setIsSimulatorOpen(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-indigo-600/25 flex items-center gap-2 border border-indigo-500/20 transition-all hover:scale-105 active:scale-95"
          title={isAr ? 'فتح محاكي هاتف الطفل التفاعلي' : 'Open Child Phone Simulator'}
        >
          <Smartphone className="w-4 h-4 animate-pulse" />
          <span>{isAr ? 'محاكي هاتف الطفل' : 'Live Simulator'}</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        </button>
      </div>

      {/* Footer (Desktop & Mobile with bottom clearance) */}
      <footer className="w-full bg-white dark:bg-slate-900 border-t border-slate-200/80 dark:border-slate-800 py-4 px-4 sm:px-6 text-center text-xs text-slate-500 dark:text-slate-400 mt-auto mb-16 sm:mb-0 transition-colors">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span className="font-medium text-slate-700 dark:text-slate-300">
              {isAr ? 'ParentGuard • نظام الحماية والتحكم الأبوي المتكامل (Android & iOS)' : 'ParentGuard • Parental Control System'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            <span>{isAr ? 'قاعدة البيانات:' : 'Database:'}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold font-mono">● Firebase Firestore Cloud</span>
            <span className="mx-1.5 text-slate-300 dark:text-slate-700">|</span>
            <span>{isAr ? 'جهاز نشط:' : 'Active:'}</span>
            <span className="text-slate-900 dark:text-slate-200 font-semibold">{activeDevice?.childNameAr}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <ParentControlProvider>
      <MainAppContent />
    </ParentControlProvider>
  );
}
