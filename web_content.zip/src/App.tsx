/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Shield, Cloud, Server, Sliders, Wifi, Key, Signal, Battery,
  MessageSquare, Image as ImageIcon, Send, Sparkles, RefreshCw,
  Lock, CheckCircle2, XCircle, AlertCircle, HelpCircle, Download,
  Settings, User, ChevronDown, X, Play, Volume2, Globe
} from 'lucide-react';

// Credential pairs
const validCredentialsMap: Record<string, { pass: string; label: string; days: number }> = {
  "79284": { pass: "374424", label: "2 Days Access", days: 2 },
  "10021": { pass: "882194", label: "2 Hours Access", days: 1 },
  "10022": { pass: "301948", label: "2 Hours Access", days: 1 },
  "10061": { pass: "551029", label: "6 Hours Access", days: 1 },
  "10062": { pass: "991823", label: "6 Hours Access", days: 1 },
  "10121": { pass: "449102", label: "12 Hours Access", days: 1 },
  "10122": { pass: "661928", label: "12 Hours Access", days: 1 },
  "10241": { pass: "772019", label: "24 Hours (1 Day)", days: 1 },
  "10242": { pass: "110938", label: "24 Hours (1 Day)", days: 1 },
  "20001": { pass: "901827", label: "Night Only (12 AM - 6 AM)", days: 7 },
  "20002": { pass: "382910", label: "Night Only (12 AM - 6 AM)", days: 14 },
  "20003": { pass: "571029", label: "Night Only (12 AM - 6 AM)", days: 30 },
  "30031": { pass: "220194", label: "3 Days Access", days: 3 },
  "30032": { pass: "884019", label: "3 Days Access", days: 3 },
  "30071": { pass: "771029", label: "1 Week Access", days: 7 },
  "30072": { pass: "662910", label: "1 Week Access", days: 7 },
  "30141": { pass: "993810", label: "2 Weeks Access", days: 14 },
  "30142": { pass: "441029", label: "2 Weeks Access", days: 14 },
  "40301": { pass: "882019", label: "1 Month Access", days: 30 },
  "40302": { pass: "551920", label: "1 Month Access", days: 30 },
  "40303": { pass: "339102", label: "1 Month Access", days: 30 },
  "40304": { pass: "774910", label: "1 Month Access", days: 30 },
  "50601": { pass: "661029", label: "2 Months Access", days: 60 },
  "50602": { pass: "992019", label: "2 Months Access", days: 60 },
  "50603": { pass: "114920", label: "2 Months Access", days: 60 },
  "60901": { pass: "881029", label: "3 Months Access (Max)", days: 90 },
  "60902": { pass: "332019", label: "3 Months Access (Max)", days: 90 },
  "60903": { pass: "554910", label: "3 Months Access (Max)", days: 90 },
  "60904": { pass: "771920", label: "3 Months Access (Max)", days: 90 }
};

const serverList = [
  { id: "s1", name: "Auto Select Server", desc: "Random Fast Server", badge: "Random" },
  { id: "s2", name: "HYPER SONIC-UG", desc: "Uganda High Speed Node", badge: "Unlocked" },
  { id: "s3", name: "SUPER WORKING-UK", desc: "United Kingdom Low Latency", badge: "Unlocked" },
  { id: "s4", name: "AIRTEL 5G PHANTOM", desc: "Australia Gaming Route", badge: "Unlocked" },
  { id: "s5", name: "AIRTEL TRIPLE 🔥", desc: "Czech Republic Streaming", badge: "Unlocked" },
  { id: "s6", name: "ALPHA MODE 🔥", desc: "Germany Ultra Bandwidth", badge: "Unlocked" },
  { id: "s7", name: "AIRTEL GOST MODE", desc: "France Private Bypass", badge: "Unlocked" },
  { id: "s8", name: "SUPER COOL 😎", desc: "India Fast Server", badge: "Unlocked" },
  { id: "s9", name: "AIRTEL STAR LINK-PRO", desc: "China Dominator Route", badge: "Unlocked" }
];

const payloadList = [
  { id: "p1", title: "AIRTEL ELITE FORCE 🛡️", sub: "BUY LFH *100*2*10*2# TO GET CONNECTED" },
  { id: "p2", title: "AIRTEL SUPER COOL 😎", sub: "ACTIVATED 🔒 LIMIT EXTENDING SPEED *163#" },
  { id: "p3", title: "AIRTEL👻💀 GOST MODE", sub: "Good Working All Town and City's" },
  { id: "p4", title: "AIRTEL🔥5G PHANTOM 👻", sub: "SPEED ➡️ for gaming/tiktok" },
  { id: "p5", title: "AIRTEL 🛡️VIP ACCESS", sub: "VIP Group user enjoy Your day📶🙏✅" },
  { id: "p6", title: "AIRTEL STAR ⭐LINK-PRO", sub: "WE DON'T JUST CONNECT WE DOMINATE" },
  { id: "p7", title: "LYC MOBILE UNLIMITED FREE", sub: "CONNECT YOUR LYC MOBILE AND ENJOY" },
  { id: "p8", title: "AIRTEL NITRO BOOST", sub: "Best For :Gaming tournaments,CODM,PUBG 🎮⚡👑" },
  { id: "p9", title: "MTN UNLIMITED VIP 👑", sub: "Test On Your Mtn Without Bundle 💀" },
  { id: "p10", title: "AIRTEL💯|| TIKTOK BUNDLE", sub: "Get TikTok Bundle From Airtel App And Connect" }
];

export default function App() {
  // Navigation & active view mode
  const [activeTab, setActiveTab] = useState<'vpn' | 'chat' | 'images'>('vpn');

  // VPN State
  const [simSlot, setSimSlot] = useState<1 | 2>(1);
  const [selectedServer, setSelectedServer] = useState(serverList[0]);
  const [selectedPayload, setSelectedPayload] = useState(payloadList[0]);
  const [userCode, setUserCode] = useState('');
  const [userPass, setUserPass] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionDuration, setConnectionDuration] = useState(0);
  const [downloadSpeed, setDownloadSpeed] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState(0);
  const [expirationDays, setExpirationDays] = useState(0);

  // Modals
  const [modalOpen, setModalOpen] = useState<'server' | 'payload' | 'updater' | 'privacy' | 'hotshare' | 'welcome' | 'support' | null>('welcome');
  const [hotspotActive, setHotspotActive] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Chat State
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'model'; content: string }>>([
    { role: 'model', content: "Hello! I'm your Rose Cloud AI Assistant. How can I help you set up your VPN, find a valid code, or choose the right payload today?" }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatModel, setChatModel] = useState('gemini-3.8-flash');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Image Generation State
  const [imagePrompt, setImagePrompt] = useState('Cyberpunk neon aurora glowing shield background for Rose Cloud VPN 4k wallpaper');
  const [imageAspect, setImageAspect] = useState('16:9');
  const [imageSize, setImageSize] = useState('2K');
  const [generatedImages, setGeneratedImages] = useState<Array<{ url: string; prompt: string; size: string; aspect: string }>>([]);
  const [isImageLoading, setIsImageLoading] = useState(false);

  // Canvas ref for wave graph
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const waveDataRef = useRef<number[]>(new Array(50).fill(0));

  // Toast trigger
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Timer & Speed simulation
  useEffect(() => {
    let timer: any;
    let speedTimer: any;
    if (isConnected) {
      timer = setInterval(() => {
        setConnectionDuration(prev => prev + 1);
      }, 1000);

      speedTimer = setInterval(() => {
        const dl = Number((Math.random() * 6.2 + 1.8).toFixed(2));
        const ul = Number((Math.random() * 2.1 + 0.4).toFixed(2));
        setDownloadSpeed(dl);
        setUploadSpeed(ul);

        // Update wave data
        const arr = waveDataRef.current;
        arr.shift();
        arr.push(dl * 10);
      }, 500);
    } else {
      setConnectionDuration(0);
      setDownloadSpeed(0);
      setUploadSpeed(0);
    }
    return () => {
      clearInterval(timer);
      clearInterval(speedTimer);
    };
  }, [isConnected]);

  // Wave canvas drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const draw = () => {
      canvas.width = canvas.parentElement?.clientWidth || 300;
      canvas.height = canvas.parentElement?.clientHeight || 64;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const waveData = waveDataRef.current;
      const sliceWidth = canvas.width / (waveData.length - 1);

      ctx.beginPath();
      ctx.moveTo(0, canvas.height);

      for (let i = 0; i < waveData.length; i++) {
        const x = i * sliceWidth;
        const normalizedVal = Math.min(waveData[i] / 80, 1);
        const y = canvas.height - (normalizedVal * (canvas.height - 12));
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }

      ctx.lineTo(canvas.width, canvas.height);
      ctx.closePath();

      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, 'rgba(244, 63, 94, 0.8)');
      gradient.addColorStop(0.5, 'rgba(168, 85, 247, 0.5)');
      gradient.addColorStop(1, 'rgba(15, 23, 42, 0.1)');

      ctx.fillStyle = gradient;
      ctx.fill();

      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#38bdf8';
      ctx.stroke();

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const formatDuration = (sec: number) => {
    const hrs = String(Math.floor(sec / 3600)).padStart(2, '0');
    const mins = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
    const s = String(sec % 60).padStart(2, '0');
    return `${hrs}:${mins}:${s}`;
  };

  const handleToggleConnection = () => {
    if (isConnecting) return;
    if (isConnected) {
      setIsConnected(false);
      showToast("VPN Disconnected");
      return;
    }

    if (!userCode.trim() || !userPass.trim()) {
      setModalOpen('support');
      return;
    }

    const match = validCredentialsMap[userCode.trim()];
    if (match && match.pass === userPass.trim()) {
      setIsConnecting(true);
      setTimeout(() => {
        setIsConnecting(false);
        setIsConnected(true);
        setExpirationDays(match.days);
        showToast("Tunnel Connected Successfully!");
      }, 1500);
    } else {
      setModalOpen('support');
    }
  };

  // Send message to AI Chatbot
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const newMessages = [...messages, { role: 'user' as const, content: chatInput }];
    setMessages(newMessages);
    setChatInput('');
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMessages, model: chatModel }),
      });
      const data = await res.json();
      if (res.ok && data.text) {
        setMessages([...newMessages, { role: 'model', content: data.text }]);
      } else {
        setMessages([...newMessages, { role: 'model', content: "Sorry, I encountered an error connecting to Rose Cloud AI." }]);
      }
    } catch (err) {
      setMessages([...newMessages, { role: 'model', content: "Network error. Please check your connection." }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Generate Image
  const handleGenerateImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imagePrompt.trim() || isImageLoading) return;

    setIsImageLoading(true);
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imagePrompt,
          aspectRatio: imageAspect,
          imageSize: imageSize,
          model: 'gemini-3-pro-image-preview',
        }),
      });
      const data = await res.json();
      if (res.ok && data.imageUrl) {
        setGeneratedImages(prev => [{ url: data.imageUrl, prompt: imagePrompt, size: imageSize, aspect: imageAspect }, ...prev]);
        showToast("High-resolution wallpaper generated successfully!");
      } else {
        showToast(data.error || "Failed to generate image.");
      }
    } catch (err) {
      showToast("Network error during image generation.");
    } finally {
      setIsImageLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans flex flex-col items-center justify-start pb-20">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-2xl z-50 border border-white/20 animate-bounce">
          {toastMessage}
        </div>
      )}

      {/* Top Primary Navigation Header */}
      <header className="w-full max-w-5xl px-4 py-3 flex items-center justify-between border-b border-white/10 bg-slate-900/80 backdrop-blur sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-rose-500 flex items-center justify-center font-bold text-slate-900">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <span className="font-extrabold text-base tracking-wider bg-gradient-to-r from-white via-rose-200 to-rose-400 bg-clip-text text-transparent">
            ROSE CLOUD VPN
          </span>
        </div>

        <nav className="flex items-center gap-1 sm:gap-2 bg-white/5 p-1 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveTab('vpn')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1.5 ${activeTab === 'vpn' ? 'bg-rose-600 text-white shadow-lg' : 'text-rose-200 hover:bg-white/10'}`}
          >
            <Shield className="w-3.5 h-3.5" /> VPN App
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1.5 ${activeTab === 'chat' ? 'bg-rose-600 text-white shadow-lg' : 'text-rose-200 hover:bg-white/10'}`}
          >
            <MessageSquare className="w-3.5 h-3.5" /> AI Assistant
          </button>
          <button
            onClick={() => setActiveTab('images')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1.5 ${activeTab === 'images' ? 'bg-rose-600 text-white shadow-lg' : 'text-rose-200 hover:bg-white/10'}`}
          >
            <ImageIcon className="w-3.5 h-3.5" /> AI Wallpaper Studio
          </button>
        </nav>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-5xl px-4 py-6 flex-1 flex flex-col items-center">

        {/* TAB 1: VPN APP (Embedded Phone Shell Container) */}
        {activeTab === 'vpn' && (
          <div className="w-full max-w-[440px] bg-gradient-to-br from-purple-950 via-rose-950 to-slate-950 rounded-3xl shadow-2xl border border-white/20 flex flex-col justify-between overflow-hidden relative pb-16">
            
            {/* Status Bar */}
            <div className="px-4 pt-3 pb-2 flex flex-col items-center">
              <div className="w-full flex justify-between items-center text-[11px] text-rose-200/80 mb-2 font-mono px-1">
                <span>12:38</span>
                <div className="flex items-center gap-2">
                  {isConnected && (
                    <span className="text-amber-300 animate-pulse text-[11px]" title="VPN Tunnel Active">
                      <Key className="w-3 h-3 inline" />
                    </span>
                  )}
                  <span className="bg-white/10 px-2 py-0.5 rounded-full text-[10px] text-rose-300 font-sans font-semibold">Android 14</span>
                  <Signal className="w-3 h-3" />
                  <Wifi className="w-3 h-3" />
                  <Battery className="w-3 h-3 text-emerald-400" />
                </div>
              </div>

              <div className="w-full flex justify-between items-center text-xs mb-1 px-1">
                <span className="text-rose-300 font-semibold tracking-wider uppercase">Build By : ROSE CLOUD DEV</span>
              </div>
              
              {/* Logo Badge */}
              <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-cyan-400 via-rose-500 to-purple-600 p-1 shadow-2xl mb-2 flex items-center justify-center border-2 border-white/40">
                <div className="w-full h-full rounded-full bg-slate-900 flex flex-col items-center justify-center text-center overflow-hidden relative">
                  <Cloud className="w-5 h-5 text-cyan-300 absolute -top-1 opacity-90" />
                  <Shield className="w-6 h-6 text-rose-400 z-10" />
                </div>
              </div>

              {/* Speed Wave Graph */}
              <div className="w-full h-16 relative flex items-center justify-center my-1 overflow-hidden rounded-xl bg-black/20 backdrop-blur-sm border border-white/10">
                <canvas ref={canvasRef} className="w-full h-full block" />
                <div className="absolute top-1 left-2 text-[9px] font-mono text-cyan-300/80 pointer-events-none">
                  {(downloadSpeed * 10).toFixed(2)} MB/s
                </div>
                <div className="absolute top-1 right-2 text-[8px] font-mono text-white/50 text-right leading-tight pointer-events-none">
                  8.0<br/>6.2<br/>4.4<br/>2.7<br/>0.0
                </div>
              </div>

              <h1 className="text-xl font-black tracking-wider text-white drop-shadow-md">ROSE CLOUD VPN</h1>
              <div className="flex items-center gap-4 text-xs mt-1 text-rose-200 font-medium">
                <span>Config Version : <strong className="text-white">100.2.0</strong></span>
                <span>Duration : <strong className="text-white">{formatDuration(connectionDuration)}</strong></span>
              </div>
            </div>

            {/* Interactive Controls */}
            <div className="px-4 flex-1 flex flex-col gap-2.5 my-auto">

              {/* SIM Slot Bar */}
              <div className="bg-white/10 backdrop-blur rounded-xl p-1.5 flex items-center justify-between border border-white/15">
                <span className="text-[11px] font-bold text-rose-200 uppercase tracking-wider px-2 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-300 animate-pulse"></span> SIM Slot:
                </span>
                <div className="flex gap-1">
                  <button
                    onClick={() => { setSimSlot(1); showToast("Switched to SIM 1 (Airtel)"); }}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition ${simSlot === 1 ? 'bg-rose-600 text-white shadow' : 'bg-white/10 text-rose-200'}`}
                  >
                    SIM 1 (Airtel)
                  </button>
                  <button
                    onClick={() => { setSimSlot(2); showToast("Switched to SIM 2 (MTN)"); }}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition ${simSlot === 2 ? 'bg-amber-600 text-white shadow' : 'bg-white/10 text-rose-200'}`}
                  >
                    SIM 2 (MTN)
                  </button>
                </div>
              </div>

              {/* Server Selector Trigger */}
              <div
                onClick={() => setModalOpen('server')}
                className="bg-white/95 backdrop-blur text-slate-900 rounded-xl p-3 flex items-center justify-between shadow-lg cursor-pointer hover:bg-white transition active:scale-95 border border-white/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                    <Server className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-slate-900">{selectedServer.name}</div>
                    <div className="text-xs text-rose-600 font-medium">{selectedServer.desc}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-600 font-semibold">
                  <span className="text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">{selectedServer.badge}</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Payload Selector Trigger */}
              <div
                onClick={() => setModalOpen('payload')}
                className="bg-white/95 backdrop-blur text-slate-900 rounded-xl p-3 flex items-center justify-between shadow-lg cursor-pointer hover:bg-white transition active:scale-95 border border-white/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                    <Sliders className="w-4 h-4" />
                  </div>
                  <div className="overflow-hidden">
                    <div className="font-bold text-sm text-slate-900 truncate max-w-[220px]">{selectedPayload.title}</div>
                    <div className="text-xs text-rose-600 font-medium truncate max-w-[220px]">{selectedPayload.sub}</div>
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-600" />
              </div>

              {/* Credential Inputs */}
              <div className="bg-white/95 backdrop-blur text-slate-900 rounded-xl p-2.5 flex items-center justify-between shadow-lg font-mono text-sm border border-white/20">
                <div className="flex-1 flex items-center justify-center gap-2 border-r border-slate-200 px-2">
                  <span className="text-[10px] text-slate-400 font-sans font-bold">ID:</span>
                  <input
                    type="text"
                    value={userCode}
                    onChange={(e) => setUserCode(e.target.value)}
                    placeholder="Enter Code"
                    className="w-24 text-center font-bold tracking-wider text-slate-900 bg-slate-100 rounded py-1 focus:outline-none focus:ring-2 focus:ring-rose-500 text-xs"
                  />
                </div>
                <div className="flex-1 flex items-center justify-center gap-2 px-2">
                  <span className="text-[10px] text-slate-400 font-sans font-bold">PASS:</span>
                  <input
                    type="password"
                    value={userPass}
                    onChange={(e) => setUserPass(e.target.value)}
                    placeholder="Password"
                    className="w-24 text-center font-bold tracking-widest text-slate-800 bg-slate-100 rounded py-1 focus:outline-none focus:ring-2 focus:ring-rose-500 text-xs"
                  />
                </div>
              </div>

              {/* Traffic Stats & Status */}
              <div className="flex items-center justify-between px-2 text-xs font-semibold text-rose-100">
                <div className="flex items-center gap-1">
                  <Download className="w-3.5 h-3.5 text-cyan-300" />
                  <span>{downloadSpeed} MB/s</span>
                </div>
                <div className="text-center">
                  <div className="text-sm font-bold uppercase tracking-wider">Hysteria Http</div>
                  <div className={`font-extrabold tracking-wide text-xs ${isConnected ? 'text-emerald-400 animate-pulse' : 'text-rose-300'}`}>
                    {isConnecting ? 'Authenticating...' : isConnected ? 'Connected' : 'Disconnected'}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Download className="w-3.5 h-3.5 text-cyan-300 rotate-180" />
                  <span>{uploadSpeed} MB/s</span>
                </div>
              </div>

              {/* Giant Connect Button */}
              <div className="flex flex-col items-center justify-center my-1 relative">
                {isConnected && (
                  <div className="absolute w-44 h-44 rounded-full border-4 border-transparent bg-gradient-to-r from-cyan-400 via-rose-500 to-amber-400 animate-spin opacity-80 blur-sm"></div>
                )}
                <button
                  onClick={handleToggleConnection}
                  disabled={isConnecting}
                  className="w-36 h-36 rounded-full bg-white shadow-2xl flex flex-col items-center justify-center relative z-10 border-4 border-rose-500 active:scale-95 transition cursor-pointer group"
                >
                  <div className="w-28 h-28 rounded-full bg-gradient-to-b from-rose-50 to-white flex flex-col items-center justify-center shadow-inner border border-rose-200">
                    <span className={`font-black text-xl tracking-wider ${isConnected ? 'text-rose-600' : 'text-rose-600'}`}>
                      {isConnecting ? '...' : isConnected ? 'STOP' : 'START'}
                    </span>
                    <span className="text-xs text-slate-500 font-bold mt-0.5">
                      {isConnecting ? 'Connecting' : isConnected ? 'Connected' : 'Tap to Connect'}
                    </span>
                  </div>
                </button>
              </div>

              {/* Expiration Box */}
              <div className="text-center text-xs text-rose-200 font-medium">
                Account Expiration Details<br />
                <strong className="text-white text-sm">{expirationDays} Days Left</strong>
              </div>

            </div>

            {/* Bottom Nav Bar inside Phone Frame */}
            <nav className="absolute bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur border-t border-white/10 grid grid-cols-3 py-2 px-3 text-rose-200 shadow-2xl z-20 rounded-t-2xl">
              <button onClick={() => setModalOpen('updater')} className="flex flex-col items-center justify-center gap-1 hover:text-white transition">
                <Download className="w-4 h-4 text-rose-400" />
                <span className="text-[10px] font-bold">Update</span>
              </button>
              <button onClick={() => setModalOpen('hotshare')} className="flex flex-col items-center justify-center gap-1 hover:text-white transition">
                <Wifi className="w-4 h-4 text-cyan-400" />
                <span className="text-[10px] font-bold">Hotshare</span>
              </button>
              <button onClick={() => setModalOpen('privacy')} className="flex flex-col items-center justify-center gap-1 hover:text-white transition">
                <Shield className="w-4 h-4 text-rose-400" />
                <span className="text-[10px] font-bold">Privacy</span>
              </button>
            </nav>

          </div>
        )}

        {/* TAB 2: AI CUSTOMER ASSISTANT CHATBOT */}
        {activeTab === 'chat' && (
          <div className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl flex flex-col h-[70vh] overflow-hidden">
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-slate-800/60">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center text-white font-bold">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Rose Cloud AI Customer Support</h3>
                  <p className="text-[11px] text-rose-300">Expert Guide for VPN Configurations & Codes</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={chatModel}
                  onChange={(e) => setChatModel(e.target.value)}
                  className="bg-slate-900 border border-white/20 text-xs rounded-lg px-2 py-1 text-white font-medium focus:outline-none"
                >
                  <option value="gemini-3.8-flash">Gemini 3.8 Flash (General)</option>
                  <option value="gemini-4-argon">Gemini 4 Argon (Advanced/Complex)</option>
                  <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Fast)</option>
                </select>
              </div>
            </div>

            {/* Preset prompt suggestions */}
            <div className="px-4 py-2 bg-slate-950/60 border-b border-white/5 flex gap-2 overflow-x-auto text-xs">
              <button onClick={() => setChatInput("How do I connect without bundles on MTN?")} className="bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full whitespace-nowrap text-rose-200 transition">
                MTN Unlimited Guide
              </button>
              <button onClick={() => setChatInput("What is the Airtel Elite Force payload?")} className="bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full whitespace-nowrap text-rose-200 transition">
                Airtel Elite Force
              </button>
              <button onClick={() => setChatInput("My user code is incorrect, how do I get a valid voucher?")} className="bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full whitespace-nowrap text-rose-200 transition">
                Voucher & Support Help
              </button>
            </div>

            {/* Message Thread */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((m, idx) => (
                <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-md ${m.role === 'user' ? 'bg-rose-600 text-white rounded-br-none' : 'bg-slate-800 text-slate-100 rounded-bl-none border border-white/10'}`}>
                    <p className="whitespace-pre-wrap">{m.content}</p>
                  </div>
                </div>
              ))}
              {isChatLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-800 text-rose-300 rounded-2xl px-4 py-3 text-xs flex items-center gap-2 border border-white/10 animate-pulse">
                    <Sparkles className="w-4 h-4 animate-spin" /> Rose Cloud AI is thinking...
                  </div>
                </div>
              )}
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-white/10 bg-slate-800/60 flex items-center gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about connection tips, payloads, or codes..."
                className="flex-1 bg-slate-900 border border-white/20 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
              <button
                type="submit"
                disabled={isChatLoading || !chatInput.trim()}
                className="bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white p-2.5 rounded-xl transition flex items-center justify-center shadow-lg"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* TAB 3: AI WALLPAPER & ASSET STUDIO */}
        {activeTab === 'images' && (
          <div className="w-full max-w-3xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl p-6 flex flex-col gap-6">
            <div>
              <h2 className="text-xl font-extrabold text-rose-400 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-cyan-400" /> Rose Cloud AI Wallpaper & Asset Studio
              </h2>
              <p className="text-xs text-slate-300 mt-1">
                Generate high-resolution custom VPN wallpapers, banners, and cyberpunk shields using <code className="text-rose-300">gemini-3-pro-image-preview</code> with configurable resolutions (1K, 2K, 4K) and aspect ratios.
              </p>
            </div>

            <form onSubmit={handleGenerateImage} className="flex flex-col gap-4 bg-slate-950 p-4 rounded-xl border border-white/10">
              <div>
                <label className="block text-xs font-bold text-rose-200 mb-1">Image Prompt / Description</label>
                <textarea
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-900 border border-white/20 rounded-xl p-3 text-xs text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  placeholder="Describe your desired wallpaper or asset..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-rose-200 mb-1">Aspect Ratio</label>
                  <select
                    value={imageAspect}
                    onChange={(e) => setImageAspect(e.target.value)}
                    className="w-full bg-slate-900 border border-white/20 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                  >
                    <option value="1:1">1:1 Square</option>
                    <option value="16:9">16:9 Landscape Banner</option>
                    <option value="9:16">9:16 Vertical Mobile Wallpaper</option>
                    <option value="4:3">4:3 Standard</option>
                    <option value="3:4">3:4 Portrait</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-rose-200 mb-1">Resolution (Image Size)</label>
                  <select
                    value={imageSize}
                    onChange={(e) => setImageSize(e.target.value)}
                    className="w-full bg-slate-900 border border-white/20 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                  >
                    <option value="1K">1K Resolution</option>
                    <option value="2K">2K High Quality</option>
                    <option value="4K">4K Ultra HD</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isImageLoading || !imagePrompt.trim()}
                className="w-full bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 disabled:opacity-50 text-white font-bold py-3 rounded-xl transition text-sm shadow-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                {isImageLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {isImageLoading ? `Generating ${imageSize} Image...` : `Generate ${imageSize} AI Wallpaper`}
              </button>
            </form>

            {/* Generated Gallery */}
            {generatedImages.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-white">Generated Gallery</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {generatedImages.map((img, idx) => (
                    <div key={idx} className="bg-slate-950 rounded-xl overflow-hidden border border-white/10 shadow-lg flex flex-col">
                      <div className="relative aspect-video bg-slate-900 flex items-center justify-center overflow-hidden">
                        <img src={img.url} alt={img.prompt} className="w-full h-full object-cover" />
                        <span className="absolute top-2 right-2 bg-black/60 backdrop-blur text-[10px] font-mono px-2 py-0.5 rounded text-cyan-300 font-bold">
                          {img.size} ({img.aspect})
                        </span>
                      </div>
                      <div className="p-3 text-xs text-slate-300 flex-1 flex flex-col justify-between">
                        <p className="line-clamp-2 font-medium">{img.prompt}</p>
                        <a
                          href={img.url}
                          download="rose_cloud_wallpaper.png"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-2 text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1 text-[11px]"
                        >
                          <Download className="w-3.5 h-3.5" /> Download Full Image
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

      </main>

      {/* ================= MODALS ================= */}

      {/* 1. Server Modal */}
      {modalOpen === 'server' && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md max-h-[85vh] rounded-2xl flex flex-col overflow-hidden shadow-2xl text-slate-900">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-base text-rose-600 flex items-center gap-2">
                <Server className="w-4 h-4" /> Select VPN Server (Unlocked)
              </h3>
              <button onClick={() => setModalOpen(null)} className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-y-auto p-2 flex flex-col gap-2 divide-y divide-slate-100">
              {serverList.map(srv => (
                <div
                  key={srv.id}
                  onClick={() => { setSelectedServer(srv); setModalOpen(null); showToast(`Server switched to: ${srv.name}`); }}
                  className="p-3 flex items-center justify-between hover:bg-rose-50 cursor-pointer rounded-xl transition group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                      <Server className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-slate-800 group-hover:text-rose-600">{srv.name}</div>
                      <div className="text-xs text-rose-500 font-medium">{srv.desc}</div>
                    </div>
                  </div>
                  <span className="text-xs text-purple-600 bg-purple-50 font-semibold px-2 py-0.5 rounded-full">{srv.badge}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. Payload Modal */}
      {modalOpen === 'payload' && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md max-h-[85vh] rounded-2xl flex flex-col overflow-hidden shadow-2xl text-slate-900">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-base text-rose-600 flex items-center gap-2">
                <Sliders className="w-4 h-4" /> Select Tweaks & Payloads
              </h3>
              <button onClick={() => setModalOpen(null)} className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-y-auto p-2 flex flex-col gap-2 divide-y divide-slate-100">
              {payloadList.map(p => (
                <div
                  key={p.id}
                  onClick={() => { setSelectedPayload(p); setModalOpen(null); showToast(`Payload updated: ${p.title}`); }}
                  className="p-3 flex items-center justify-between hover:bg-rose-50 cursor-pointer rounded-xl transition group"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold flex-shrink-0">
                      <Sliders className="w-4 h-4" />
                    </div>
                    <div className="overflow-hidden">
                      <div className="font-bold text-sm text-slate-800 group-hover:text-rose-600 truncate">{p.title}</div>
                      <div className="text-xs text-rose-500 font-medium truncate">{p.sub}</div>
                    </div>
                  </div>
                  {p.id === selectedPayload.id && <CheckCircle2 className="w-4 h-4 text-rose-600 flex-shrink-0 ml-2" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. Updater Modal */}
      {modalOpen === 'updater' && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl flex flex-col overflow-hidden shadow-2xl text-slate-900 p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-lg text-rose-600">Config Updater</h3>
              <button onClick={() => setModalOpen(null)} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="text-xs text-slate-600 space-y-2 mb-5">
              <p>1.) <strong>Online Update</strong> - Requires internet connection.</p>
              <p>2.) <strong>Offline Update</strong> - Needs to import .rj or .js file.</p>
              <p>3.) <strong>Clear Data</strong> - Clear all saved configs.</p>
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs font-bold">
              <button onClick={() => { setExpirationDays(0); showToast("Configs cleared"); setModalOpen(null); }} className="bg-slate-100 text-rose-600 p-2.5 rounded-xl hover:bg-rose-50 transition border border-rose-200">CLEAR</button>
              <button onClick={() => { showToast("Please import a .rj or .js file."); setModalOpen(null); }} className="bg-slate-100 text-slate-700 p-2.5 rounded-xl hover:bg-slate-200 transition">OFFLINE</button>
              <button onClick={() => { showToast("Configs updated online!"); setModalOpen(null); }} className="bg-rose-600 text-white p-2.5 rounded-xl hover:bg-rose-700 shadow-md transition">ONLINE</button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Privacy Modal */}
      {modalOpen === 'privacy' && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md max-h-[85vh] rounded-2xl flex flex-col overflow-hidden shadow-2xl text-slate-900">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-base text-rose-600 flex items-center gap-2">
                <Shield className="w-4 h-4" /> Users Privacy and Agreement
              </h3>
              <button onClick={() => setModalOpen(null)} className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-y-auto p-4 text-xs text-slate-700 space-y-3 leading-relaxed">
              <p className="font-bold text-slate-900">These terms and conditions outline the rules and regulations for the use of Rose Cloud VPN Software on Android devices.</p>
              <p>By accessing this Software we assume that you accept these terms and conditions. Do not continue to use our service if you do not agree to take all of the terms and conditions stated on this page.</p>
              <p className="pt-2 text-center font-bold text-slate-500">© Copyright 2026 | ROSE CLOUD VPN - All Rights Reserved</p>
            </div>
          </div>
        </div>
      )}

      {/* 5. Hotshare Modal */}
      {modalOpen === 'hotshare' && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl flex flex-col overflow-hidden shadow-2xl text-slate-900 p-5">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-base text-rose-600 flex items-center gap-1.5"><Wifi className="w-4 h-4" /> Hotspot Tether & Proxy</h3>
              <button onClick={() => setModalOpen(null)} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
            </div>
            <div className={`text-xs font-bold p-2.5 rounded-lg text-center mb-3 border ${hotspotActive ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-slate-100 text-slate-700 border-slate-200'}`}>
              {hotspotActive ? 'You are Sharing Internet !! (Proxy 10.13.167.124:8080 Active)' : 'Hotspot Proxy Server Inactive'}
            </div>
            
            <div className="flex items-center justify-between bg-slate-100 p-3 rounded-xl mb-4">
              <span className="font-bold text-xs text-slate-700">ENABLE PROXY SERVER</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={hotspotActive} onChange={() => setHotspotActive(!hotspotActive)} className="sr-only peer" />
                <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
              </label>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl text-xs space-y-2 text-slate-700 border border-slate-200 mb-4">
              <div className="font-bold text-slate-900 mb-1">Guide:</div>
              <p>1. Turn on Hotspot.</p>
              <p>2. Connect other device to hotspot and set manual proxy:</p>
              <div className="bg-white p-2 rounded border border-slate-300 font-mono text-rose-600 font-bold">
                Proxy Hostname: 10.13.167.124<br />
                Proxy Port: 8080
              </div>
            </div>
            <button onClick={() => setModalOpen(null)} className="w-full bg-rose-600 text-white font-bold py-2.5 rounded-xl hover:bg-rose-700 transition text-sm">OK</button>
          </div>
        </div>
      )}

      {/* 6. Welcome Modal */}
      {modalOpen === 'welcome' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/10 w-full max-w-sm rounded-2xl flex flex-col overflow-hidden shadow-2xl text-white p-6 text-center">
            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-rose-500 to-purple-600 text-white flex items-center justify-center mx-auto mb-3 text-2xl font-bold shadow-lg border border-white/20">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <h3 className="font-extrabold text-lg text-rose-400 mb-1">👑 WELCOME TO ROSE CLOUD 👑</h3>
            <p className="text-xs text-rose-100/90 mb-5 leading-relaxed font-sans">
              Thank you for choosing Rose Cloud VPN! 🚀<br />
              Please enter your company user code and password to unlock unlimited high-speed secure browsing.
            </p>
            <button onClick={() => setModalOpen(null)} className="w-full bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-bold py-3 rounded-xl transition text-sm shadow-lg active:scale-95 cursor-pointer">
              OKAY
            </button>
          </div>
        </div>
      )}

      {/* 7. Developer Support Modal */}
      {modalOpen === 'support' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/30 w-full max-w-sm rounded-2xl flex flex-col overflow-hidden shadow-2xl text-white p-6 text-center">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-3 text-2xl font-bold shadow-inner border border-emerald-500/40">
              <MessageSquare className="w-7 h-7" />
            </div>
            <h3 className="font-extrabold text-base text-rose-400 mb-1">AUTHENTICATION ERROR</h3>
            <p className="text-xs text-rose-200/90 mb-4 leading-relaxed">
              The User Code or Password you entered is incorrect or unassigned.<br /><br />
              Please retry typing your inputs or contact developer support on WhatsApp for help and custom vouchers.
            </p>
            <a
              href="https://wa.me/256794911250?text=Hello%20Developer,%20I%20need%20assistance%20with%20my%20Rose%20Cloud%20VPN%20Code%20and%20Password."
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl transition text-sm shadow-lg flex items-center justify-center gap-2 mb-2"
            >
              Contact Developer (+256794911250)
            </a>
            <button
              onClick={() => { setUserCode(''); setUserPass(''); setModalOpen(null); }}
              className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 rounded-xl transition text-xs shadow-md mb-2"
            >
              Retry / Type Correct Inputs
            </button>
            <button onClick={() => setModalOpen(null)} className="w-full bg-white/10 hover:bg-white/20 text-slate-300 font-semibold py-2 rounded-xl transition text-xs">
              Dismiss
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
