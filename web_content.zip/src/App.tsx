import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomTabBar } from './components/BottomTabBar';
import { DesktopNavSidebar } from './components/DesktopNavSidebar';
import { DesktopRightSidebar } from './components/DesktopRightSidebar';
import { AuthOnboardingScreen } from './components/AuthOnboardingScreen';
import { LanguageSelectionScreen } from './components/LanguageSelectionScreen';
import { LanguageModal } from './components/LanguageModal';
import { SplashScreenIntro } from './components/SplashScreenIntro';

// Views
import { FeedView } from './components/FeedView';
import { ExploreView } from './components/ExploreView';
import { ChatRoomsView } from './components/ChatRoomsView';
import { GamesSection } from './components/GamesSection';
import { LeaderboardView } from './components/LeaderboardView';
import { ProfileView } from './components/ProfileView';
import { ReferralEngine } from './components/ReferralEngine';

// Modals
import { CreateConfessionModal } from './components/CreateConfessionModal';
import { CollegeVerificationModal } from './components/CollegeVerificationModal';
import { ShareQuoteCardModal } from './components/ShareQuoteCardModal';
import { ReportModal } from './components/ReportModal';
import { DirectWhispersModal } from './components/DirectWhispersModal';
import { PremiumModal } from './components/PremiumModal';
import { AuthModal } from './components/AuthModal';
import { NotificationsModal } from './components/NotificationsModal';
import { ReactNativeExportModal } from './components/ReactNativeExportModal';
import { AdminModerationModal } from './components/AdminModerationModal';
import { AppUpdateModal } from './components/AppUpdateModal';

import { 
  Lock, 
  Smartphone, 
  Code 
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { 
    activeTab, 
    isMobileFrameView, 
    setIsMobileFrameView, 
    setIsExportModalOpen, 
    setIsCollegeModalOpen,
    isAuthenticated,
    hasSelectedLanguage,
    t,
    user 
  } = useApp();

  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);

  // Content switcher
  const renderTabContent = () => {
    switch (activeTab) {
      case 'feed':
        return <FeedView />;
      case 'explore':
        return <ExploreView />;
      case 'chat':
        return <ChatRoomsView />;
      case 'games':
        return <GamesSection />;
      case 'leaderboard':
        return <LeaderboardView />;
      case 'referral':
        return <ReferralEngine />;
      case 'profile':
        return <ProfileView />;
      default:
        return <FeedView />;
    }
  };

  // 1. STEP 1: Ask for Language FIRST (if user hasn't selected yet)
  if (!hasSelectedLanguage) {
    return (
      <div className="min-h-screen bg-[#05060b] text-slate-100 flex flex-col items-center justify-center p-2">
        {isMobileFrameView ? (
          <div className="flex flex-col items-center w-full max-w-sm">
            <div className="mb-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Mobile Phone Frame</span>
              <button onClick={() => setIsMobileFrameView(false)} className="text-cyan-400 hover:underline font-bold ml-1">
                Exit Frame
              </button>
            </div>
            
            <div className="relative w-full max-w-[390px] h-[min(720px,calc(100vh-65px))] max-h-[92vh] rounded-[44px] border-[8px] border-[#181d2e] shadow-[0_0_50px_rgba(6,182,212,0.3)] overflow-hidden bg-[#05060b] flex flex-col">
              <div className="h-8 shrink-0 bg-[#070912] flex items-center justify-between px-5 select-none relative z-40 border-b border-slate-900/60">
                <span className="text-[10px] font-semibold text-slate-300 font-mono">9:41</span>
                <div className="w-20 h-3.5 bg-black rounded-full flex items-center justify-end pr-2 border border-slate-800/40">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-800" />
                </div>
                <div className="flex items-center gap-1 text-[9px] text-slate-400 font-mono">
                  <span>5G</span>
                  <span>98%</span>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                <LanguageSelectionScreen />
              </div>
            </div>
          </div>
        ) : (
          <LanguageSelectionScreen />
        )}
      </div>
    );
  }

  // 2. STEP 2: If user is NOT yet registered/logged in: Show Auth Onboarding in chosen language!
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#05060b] text-slate-100 flex flex-col items-center justify-center p-2">
        {isMobileFrameView ? (
          <div className="flex flex-col items-center w-full max-w-sm">
            <div className="mb-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Mobile Phone Frame</span>
              <button onClick={() => setIsMobileFrameView(false)} className="text-cyan-400 hover:underline font-bold ml-1">
                Exit Frame
              </button>
            </div>
            
            <div className="relative w-full max-w-[390px] h-[min(720px,calc(100vh-65px))] max-h-[92vh] rounded-[44px] border-[8px] border-[#181d2e] shadow-[0_0_50px_rgba(6,182,212,0.3)] overflow-hidden bg-[#05060b] flex flex-col">
              <div className="h-8 shrink-0 bg-[#070912] flex items-center justify-between px-5 select-none relative z-40 border-b border-slate-900/60">
                <span className="text-[10px] font-semibold text-slate-300 font-mono">9:41</span>
                <div className="w-20 h-3.5 bg-black rounded-full flex items-center justify-end pr-2 border border-slate-800/40">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-800" />
                </div>
                <div className="flex items-center gap-1 text-[9px] text-slate-400 font-mono">
                  <span>5G</span>
                  <span>98%</span>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                <AuthOnboardingScreen />
              </div>
            </div>
          </div>
        ) : (
          <AuthOnboardingScreen />
        )}

        <LanguageModal />
      </div>
    );
  }

  // 3. STEP 3: User IS Authenticated -> Render Full Application in Chosen Language
  return (
    <div className="min-h-screen bg-[#05060a] text-slate-100 flex flex-col items-center">
      
      {/* Smartphone Device Frame Mode */}
      {isMobileFrameView ? (
        <div className="py-2 px-2 flex flex-col items-center w-full max-w-md h-screen justify-center">
          
          {/* Top Switcher Bar */}
          <div className="mb-2 px-3.5 py-1 rounded-full bg-slate-900/90 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2 shadow-lg shrink-0">
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span>{t.smartphoneMode}</span>
            <button
              onClick={() => setIsMobileFrameView(false)}
              className="text-cyan-400 hover:underline font-semibold ml-2"
            >
              {t.exitFrame}
            </button>
          </div>

          {/* Smartphone Hardware Shell: Sized dynamically to ALWAYS fit on user's screen without scrolling off */}
          <div className="relative w-full max-w-[390px] h-[min(720px,calc(100vh-65px))] max-h-[92vh] rounded-[44px] border-[8px] border-[#181d2e] shadow-[0_0_50px_rgba(6,182,212,0.35)] overflow-hidden bg-[#07080d] flex flex-col">
            
            {/* 1. Top Status Bar with Camera Notch (shrink-0) */}
            <div className="h-8 shrink-0 bg-[#090b14] flex items-center justify-between px-5 select-none relative z-40 border-b border-slate-900/60">
              <span className="text-[10px] font-semibold text-slate-300 font-mono">9:41</span>
              
              <div className="w-20 h-3.5 bg-black rounded-full flex items-center justify-end pr-2 border border-slate-800/40">
                <div className="w-1.5 h-1.5 rounded-full bg-slate-800" />
              </div>

              <div className="flex items-center gap-1 text-[9px] text-slate-400 font-mono">
                <span>5G</span>
                <span>98%</span>
              </div>
            </div>

            {/* 2. Top Header (shrink-0 so it stays fixed at top of phone frame, never cut off) */}
            <div className="shrink-0 z-30">
              <Header />
            </div>

            {/* 3. College Notice Bar if unverified */}
            {!user.isVerifiedStudent && (
              <div className="bg-gradient-to-r from-cyan-950/80 via-purple-950/80 to-slate-900 border-b border-cyan-500/30 px-3 py-1 text-[10px] flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1 text-cyan-200 truncate">
                  <Lock className="w-3 h-3 text-cyan-400 shrink-0" />
                  <span className="truncate">Enter college code to unlock</span>
                </div>
                <button
                  onClick={() => setIsCollegeModalOpen(true)}
                  className="px-2 py-0.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-[9px] shrink-0 ml-1"
                >
                  {t.verify}
                </button>
              </div>
            )}

            {/* 4. Middle Scrollable Area: ONLY this part scrolls, so header and bottom taskbar are 100% permanent! */}
            <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden relative flex flex-col px-2.5 py-2">
              <main className="flex-1 pb-4">
                {renderTabContent()}
              </main>
            </div>

            {/* 5. Bottom Taskbar: Pinned firmly at bottom inside phone frame - NEVER HIDDEN! */}
            <div className="shrink-0 bg-[#090b14]/98 border-t border-slate-800/90 z-40 relative">
              <BottomTabBar isDockedInFrame={true} />
              <div className="w-24 h-1 bg-slate-600/60 rounded-full mx-auto my-1" />
            </div>

          </div>
        </div>
      ) : (
        /* Full Viewport Responsive Layout (Standard Mobile, Tablet, Laptop, Desktop) */
        <div className="w-full min-h-screen flex flex-col bg-[#07080d] text-slate-100 relative">
          
          <Header />

          {/* College Notice Bar */}
          {!user.isVerifiedStudent && (
            <div className="bg-gradient-to-r from-cyan-950/80 via-purple-950/80 to-slate-900 border-b border-cyan-500/30 px-4 py-2 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-200">
                <Lock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Join with your unique college code to unlock your campus feed</span>
              </div>
              <button
                onClick={() => setIsCollegeModalOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold text-[11px] shadow-sm hover:bg-cyan-400 transition-all shrink-0 ml-2"
              >
                {t.verify}
              </button>
            </div>
          )}

          {/* Main 3-Column / Fluid Responsive Container */}
          <div className="flex-1 w-full max-w-7xl mx-auto flex justify-center px-0 sm:px-4 lg:px-6">
            <DesktopNavSidebar />
            <main className="flex-1 max-w-2xl w-full min-w-0 px-3 sm:px-4 py-3 sm:py-5 pb-32 sm:pb-36">
              {renderTabContent()}
            </main>
            <DesktopRightSidebar />
          </div>

          {/* Instagram-Style Bottom Navigation Taskbar: Fixed at bottom of every Mobile & Tablet screen */}
          <BottomTabBar isDockedInFrame={false} />

          {/* Footer */}
          <footer className="pb-28 lg:pb-20 pt-6 border-t border-slate-900 text-center text-xs text-slate-500 space-y-2">
            <div className="flex items-center justify-center gap-3 text-slate-400">
              <span>Secret Gossip v2.0</span>
              <span>·</span>
              <button 
                onClick={() => setIsAdminModalOpen(true)} 
                className="hover:text-cyan-400 transition-colors"
              >
                {t.safetyConsole}
              </button>
              <span>·</span>
              <button 
                onClick={() => setIsExportModalOpen(true)} 
                className="text-cyan-400 hover:underline flex items-center gap-1"
              >
                <Code className="w-3 h-3" />
                <span>{t.rnGuide}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-600">
              {t.tagline} 100% anonymous · Zero tracking · End-to-end masked
            </p>
          </footer>

        </div>
      )}

      {/* Global Modals */}
      <CreateConfessionModal />
      <CollegeVerificationModal />
      <ShareQuoteCardModal />
      <ReportModal />
      <DirectWhispersModal />
      <PremiumModal />
      <AuthModal />
      <NotificationsModal />
      <ReactNativeExportModal />
      <LanguageModal />
      <AdminModerationModal 
        isOpen={isAdminModalOpen} 
        onClose={() => setIsAdminModalOpen(false)} 
      />
      <AppUpdateModal />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <SplashScreenIntro durationMs={2000} />
      <MainLayout />
    </AppProvider>
  );
}
