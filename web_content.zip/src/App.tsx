import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { CallingView } from './components/communication/CallingView';
import { MessagingView } from './components/communication/MessagingView';
import { MarketplaceView } from './components/ecommerce/MarketplaceView';
import { OrderManagerView } from './components/ecommerce/OrderManagerView';
import { CartDrawer } from './components/ecommerce/CartDrawer';
import { AttendanceView } from './components/education/AttendanceView';
import { HomeworkView } from './components/education/HomeworkView';
import { GradeBookView } from './components/education/GradeBookView';
import { TimetableView } from './components/education/TimetableView';
import { TaskManagerView } from './components/office/TaskManagerView';
import { StaffAttendanceView } from './components/office/StaffAttendanceView';
import { LeaveManagerView } from './components/office/LeaveManagerView';
import { GigsAndWalletView } from './components/wallet/GigsAndWalletView';
import { ReceiptModal } from './components/modals/ReceiptModal';
import { ReportCardModal } from './components/modals/ReportCardModal';
import {
  Video,
  MessageSquare,
  Store,
  ClipboardList,
  UserCheck,
  BookOpen,
  GraduationCap,
  Calendar,
  CheckSquare,
  Clock,
  CalendarCheck,
  Briefcase,
  Wallet,
} from 'lucide-react';

const MainContent: React.FC = () => {
  const { currentPillar, activeSubView, setActiveSubView } = useApp();

  // Sub-navigation configurations for each pillar
  const subNavConfig: Record<
    string,
    { id: string; label: string; icon: React.ComponentType<{ className?: string }> }[]
  > = {
    communication: [
      { id: 'calls', label: 'Voice & Video Calls', icon: Video },
      { id: 'messaging', label: 'Instant Messaging', icon: MessageSquare },
    ],
    ecommerce: [
      { id: 'marketplace', label: 'Storefront & Catalog', icon: Store },
      { id: 'orders', label: 'Orders & Receipts', icon: ClipboardList },
    ],
    education: [
      { id: 'attendance', label: 'Daily Attendance', icon: UserCheck },
      { id: 'homework', label: 'Homework & Assignments', icon: BookOpen },
      { id: 'gradebook', label: 'Exam Results & Report Cards', icon: GraduationCap },
      { id: 'timetable', label: 'Academic Timetables', icon: Calendar },
    ],
    office: [
      { id: 'tasks', label: 'Task Delegation', icon: CheckSquare },
      { id: 'staff_attendance', label: 'Staff Punch Clock', icon: Clock },
      { id: 'leave_management', label: 'Leave & Approvals', icon: CalendarCheck },
    ],
    wallet: [
      { id: 'gigs', label: 'Campus Gigs & Tasks', icon: Briefcase },
      { id: 'wallet', label: 'My Wallet & Transactions', icon: Wallet },
    ],
  };

  const currentSubTabs = subNavConfig[currentPillar] || [];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header />

      {/* Sub-Navigation Secondary Bar */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-1 overflow-x-auto py-2.5">
            {currentSubTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeSubView === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubView(tab.id)}
                  className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Pillar 1: Communication */}
        {currentPillar === 'communication' && (
          <>
            {activeSubView === 'calls' && <CallingView />}
            {activeSubView === 'messaging' && <MessagingView />}
          </>
        )}

        {/* Pillar 2: E-Commerce */}
        {currentPillar === 'ecommerce' && (
          <>
            {activeSubView === 'marketplace' && <MarketplaceView />}
            {activeSubView === 'orders' && <OrderManagerView />}
          </>
        )}

        {/* Pillar 3: Education */}
        {currentPillar === 'education' && (
          <>
            {activeSubView === 'attendance' && <AttendanceView />}
            {activeSubView === 'homework' && <HomeworkView />}
            {activeSubView === 'gradebook' && <GradeBookView />}
            {activeSubView === 'timetable' && <TimetableView />}
          </>
        )}

        {/* Pillar 4: Office */}
        {currentPillar === 'office' && (
          <>
            {activeSubView === 'tasks' && <TaskManagerView />}
            {activeSubView === 'staff_attendance' && <StaffAttendanceView />}
            {activeSubView === 'leave_management' && <LeaveManagerView />}
          </>
        )}

        {/* Pillar 5: Earnings & Wallet */}
        {currentPillar === 'wallet' && <GigsAndWalletView />}
      </main>

      {/* Global Modals & Drawers */}
      <CartDrawer />
      <ReceiptModal />
      <ReportCardModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
