import React, { useState, useEffect, useMemo } from 'react';
import { GRADE_9_STUDY_MODULES } from './data/grade9Data.ts';
import { StudyModule, ProgressMap } from './types/index.ts';
import { Navbar } from './components/Navbar.tsx';
import { HeroBanner } from './components/HeroBanner.tsx';
import { SubjectFilter } from './components/SubjectFilter.tsx';
import { StudyNoteCard } from './components/StudyNoteCard.tsx';
import { StudyNotesReader } from './components/StudyNotesReader.tsx';
import { QuizRunner } from './components/QuizRunner.tsx';
import { FlashcardViewer } from './components/FlashcardViewer.tsx';
import { AiGeneratorModal } from './components/AiGeneratorModal.tsx';
import { BottomNav } from './components/BottomNav.tsx';
import { CircularProgressRing } from './components/CircularProgressRing.tsx';
import {
  BookOpen,
  HelpCircle,
  Sparkles,
  Bookmark,
  Award,
  RotateCcw,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<'om' | 'en'>('om');
  const [modules, setModules] = useState<StudyModule[]>(() => {
    try {
      const saved = localStorage.getItem('barattoota_grade9_modules');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const existingIds = new Set(GRADE_9_STUDY_MODULES.map((m) => m.id));
          const customOnly = parsed.filter((m: StudyModule) => !existingIds.has(m.id));
          return [...GRADE_9_STUDY_MODULES, ...customOnly];
        }
      }
    } catch (e) {
      // fallback
    }
    return GRADE_9_STUDY_MODULES;
  });

  const [currentTab, setCurrentTab] = useState<'notes' | 'quiz' | 'flashcards' | 'ai' | 'saved'>('notes');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeReaderModule, setActiveReaderModule] = useState<StudyModule | null>(null);
  const [activeQuizModule, setActiveQuizModule] = useState<StudyModule | null>(null);
  const [activeFlashcardModule, setActiveFlashcardModule] = useState<StudyModule | undefined>(undefined);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  // Module Progress tracking per module (Version 3)
  const [progressMap, setProgressMap] = useState<ProgressMap>(() => {
    try {
      const saved = localStorage.getItem('barattoota_grade9_progress_v3');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
    return {};
  });

  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('barattoota_grade9_bookmarks');
      if (saved) {
        return new Set(JSON.parse(saved));
      }
    } catch (e) {}
    return new Set();
  });

  // Save custom modules
  useEffect(() => {
    try {
      localStorage.setItem('barattoota_grade9_modules', JSON.stringify(modules));
    } catch (e) {}
  }, [modules]);

  // Save bookmarks
  useEffect(() => {
    try {
      localStorage.setItem('barattoota_grade9_bookmarks', JSON.stringify(Array.from(bookmarkedIds)));
    } catch (e) {}
  }, [bookmarkedIds]);

  // Save progress
  useEffect(() => {
    try {
      localStorage.setItem('barattoota_grade9_progress_v3', JSON.stringify(progressMap));
    } catch (e) {}
  }, [progressMap]);

  const toggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => {
      const updated = new Set(prev);
      if (updated.has(id)) {
        updated.delete(id);
      } else {
        updated.add(id);
      }
      return updated;
    });
  };

  const handleToggleLanguage = () => {
    setLanguage((prev) => (prev === 'om' ? 'en' : 'om'));
  };

  const handleModuleGenerated = (newModule: StudyModule) => {
    setModules((prev) => [newModule, ...prev]);
    setActiveReaderModule(newModule);
    setCurrentTab('notes');
  };

  const handleReadNotes = (module: StudyModule) => {
    setActiveReaderModule(module);
    setActiveQuizModule(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTakeQuiz = (module: StudyModule) => {
    setActiveQuizModule(module);
    setActiveReaderModule(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenFlashcardsForModule = (module: StudyModule) => {
    setActiveFlashcardModule(module);
    setCurrentTab('flashcards');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Called when quiz finishes
  const handleQuizCompleted = (moduleId: string, score: number, total: number) => {
    setProgressMap((prev) => {
      const existing = prev[moduleId];
      const prevBest = existing?.bestScore || 0;
      const newBest = Math.max(prevBest, score);
      const isCompleted = newBest === total && total > 0;

      return {
        ...prev,
        [moduleId]: {
          bestScore: newBest,
          totalQuestions: total,
          completed: isCompleted,
          lastAttemptDate: new Date().toISOString(),
        },
      };
    });
  };

  // Reset progress confirmation
  const handleResetProgress = () => {
    const confirmMsg =
      language === 'om'
        ? 'Qabxii qormaataa fi adeemsa hunda haaromsuu (reset gochuu) barbaadduu?'
        : 'Are you sure you want to reset all your study progress and quiz scores?';
    if (window.confirm(confirmMsg)) {
      setProgressMap({});
      try {
        localStorage.removeItem('barattoota_grade9_progress_v3');
      } catch (e) {}
    }
  };

  // Filter categories
  const categories = ['all', 'Afaan Oromoo', 'Saayinsii', 'Aadaa'];

  const filteredModules = useMemo(() => {
    return modules.filter((m) => {
      if (currentTab === 'saved' && !bookmarkedIds.has(m.id)) {
        return false;
      }
      if (activeCategory !== 'all' && m.category !== activeCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = m.title.toLowerCase().includes(query) || m.titleEn.toLowerCase().includes(query);
        const matchesSubject = m.subject.toLowerCase().includes(query);
        const matchesSummary = m.topicSummary.toLowerCase().includes(query);
        const matchesTerms = m.keyTerms?.some(
          (t) => t.term.toLowerCase().includes(query) || t.definition.toLowerCase().includes(query)
        );
        return matchesTitle || matchesSubject || matchesSummary || matchesTerms;
      }
      return true;
    });
  }, [modules, currentTab, activeCategory, searchQuery, bookmarkedIds]);

  // Aggregate progress metrics across curriculum
  const totalQuestions = useMemo(() => {
    return modules.reduce((acc, m) => acc + (m.questions?.length || 5), 0);
  }, [modules]);

  const totalAnsweredCorrectly = useMemo(() => {
    return modules.reduce((acc, m) => {
      const p = progressMap[m.id];
      return acc + (p?.bestScore || 0);
    }, 0);
  }, [modules, progressMap]);

  const masteredModulesCount = useMemo(() => {
    return modules.filter((m) => {
      const p = progressMap[m.id];
      const qTotal = m.questions?.length || 5;
      return p?.completed || (p?.bestScore === qTotal && qTotal > 0);
    }).length;
  }, [modules, progressMap]);

  const overallPercent = totalQuestions > 0 ? Math.round((totalAnsweredCorrectly / totalQuestions) * 100) : 0;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans pb-24 md:pb-10 selection:bg-amber-100 selection:text-amber-900 antialiased overflow-x-hidden">
      {/* Top Bar Navigation (Version 3.0) */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          setActiveReaderModule(null);
          setActiveQuizModule(null);
          if (tab === 'ai') {
            setIsAiModalOpen(true);
          }
        }}
        language={language}
        onToggleLanguage={handleToggleLanguage}
        onOpenAiGenerator={() => setIsAiModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {/* Active Reader Module Screen */}
        {activeReaderModule ? (
          <StudyNotesReader
            module={activeReaderModule}
            progress={progressMap[activeReaderModule.id]}
            language={language}
            onBack={() => setActiveReaderModule(null)}
            onTakeQuiz={handleTakeQuiz}
            onOpenFlashcards={handleOpenFlashcardsForModule}
          />
        ) : activeQuizModule ? (
          /* Active Quiz Screen */
          <QuizRunner
            module={activeQuizModule}
            language={language}
            onBack={() => setActiveQuizModule(null)}
            onReadNotes={handleReadNotes}
            onQuizCompleted={handleQuizCompleted}
          />
        ) : currentTab === 'flashcards' ? (
          /* Flashcards Tab */
          <FlashcardViewer
            module={activeFlashcardModule}
            allModules={modules}
            language={language}
            onBack={() => {
              setActiveFlashcardModule(undefined);
              setCurrentTab('notes');
            }}
          />
        ) : currentTab === 'quiz' ? (
          /* Quizzes Directory View with Progress Indicators */
          <div className="max-w-7xl mx-auto px-3.5 sm:px-6 py-5 sm:py-8 space-y-6">
            <div className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-900">
                  {language === 'om'
                    ? 'Qormaata Mirkaneeffannaa Kutaa 9ffaa (5 MCQs)'
                    : 'Grade 9 Review Quizzes (5 Questions Each)'}
                </h1>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  {language === 'om'
                    ? 'Boqonnaa filadhuuti gaaffilee filannoo 5 deebii fi ibsa isaanii wajjin shaakali.'
                    : 'Select any unit to test your understanding with 5 curated review MCQs and answer keys.'}
                </p>
              </div>

              {/* Quick Overall Mastery Stat */}
              <div className="flex items-center gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs shrink-0">
                <CircularProgressRing
                  score={totalAnsweredCorrectly}
                  total={totalQuestions}
                  size={46}
                  strokeWidth={4}
                />
                <div className="text-xs">
                  <p className="font-bold text-slate-900 tabular-nums">
                    {totalAnsweredCorrectly} / {totalQuestions} Correct
                  </p>
                  <p className="text-slate-500 font-medium">
                    {masteredModulesCount} of {modules.length} Mastered
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
              {modules.map((m) => {
                const prog = progressMap[m.id];
                const bScore = prog?.bestScore || 0;
                const qCount = m.questions?.length || 5;
                const isMastered = prog?.completed || (bScore === qCount && qCount > 0);

                return (
                  <div
                    key={m.id}
                    className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-amber-400 transition-all flex flex-col justify-between shadow-xs"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 text-xs text-slate-500 flex-wrap">
                            <span className="font-semibold text-amber-700">{m.subject}</span>
                            <span aria-hidden="true">·</span>
                            <span>{m.grade}</span>
                          </div>
                          <h3 className="text-base font-bold text-slate-900 leading-snug">
                            {language === 'om' ? m.title : m.titleEn}
                          </h3>
                        </div>

                        {/* Progress ring in quiz list */}
                        <CircularProgressRing
                          score={bScore}
                          total={qCount}
                          size={42}
                          strokeWidth={3.5}
                        />
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {language === 'om' ? m.topicSummary : (m.topicSummaryEn || m.topicSummary)}
                      </p>

                      <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
                        <span className="text-slate-500 font-medium">
                          {isMastered ? (
                            <span className="text-emerald-700 font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              {language === 'om' ? 'Qophii Guutuu (5/5)' : 'Mastered (5/5)'}
                            </span>
                          ) : bScore > 0 ? (
                            <span className="text-amber-700 font-semibold">
                              {language === 'om' ? `Adeemsarra (${bScore}/${qCount})` : `Score: ${bScore}/${qCount}`}
                            </span>
                          ) : (
                            <span>{language === 'om' ? 'Hin jalqabamne' : 'Not Started'}</span>
                          )}
                        </span>
                        <span className="text-slate-400 text-[11px]">5 Questions</span>
                      </div>
                    </div>

                    <div className="pt-4 mt-2">
                      <button
                        onClick={() => handleTakeQuiz(m)}
                        className="w-full min-h-[44px] flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all cursor-pointer shadow-xs active:scale-[0.98]"
                      >
                        <HelpCircle className="w-4 h-4" />
                        <span>
                          {isMastered
                            ? language === 'om'
                              ? 'Irra Deebi\'ii Qori'
                              : 'Retake Quiz'
                            : bScore > 0
                            ? language === 'om'
                              ? 'Qormaata Itti Fufi'
                              : 'Resume Quiz'
                            : language === 'om'
                            ? 'Qormaata Jalqabi'
                            : 'Start 5-MCQ Quiz'}
                        </span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Notes / Home Directory View */
          <div>
            {/* Hero banner shown on main notes tab */}
            {currentTab === 'notes' && !searchQuery && activeCategory === 'all' && (
              <HeroBanner
                language={language}
                onStartAfaanOromoo={() => {
                  const afaanMod = modules.find((m) => m.id === 'afaan-oromoo-caasluga');
                  if (afaanMod) handleReadNotes(afaanMod);
                }}
                onStartQuiz={() => {
                  const afaanMod = modules.find((m) => m.id === 'afaan-oromoo-caasluga');
                  if (afaanMod) handleTakeQuiz(afaanMod);
                }}
                onOpenAiGenerator={() => setIsAiModalOpen(true)}
                totalModules={modules.length}
                totalQuestions={totalQuestions}
              />
            )}

            {/* Filter and Grid Content */}
            <div className="max-w-7xl mx-auto px-3.5 sm:px-6 py-5 sm:py-7 space-y-5">
              {currentTab === 'saved' && (
                <div className="border-b border-slate-200 pb-3">
                  <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
                    <Bookmark className="w-5 h-5 text-amber-500 fill-amber-500" />
                    <span>
                      {language === 'om'
                        ? 'Qabxiilee Olkaawwatan (Bookmarked Notes)'
                        : 'Saved & Bookmarked Modules'}
                    </span>
                  </h1>
                  <p className="text-xs text-slate-500 mt-1">
                    {language === 'om'
                      ? 'Boqonnaalee yeroo qormaataaf irra deebitee ilaallattu asitti argatta.'
                      : 'Quick access to modules you saved for pre-exam revision.'}
                  </p>
                </div>
              )}

              {/* Study Progress Indicator Banner (Universal for all mobile phones) */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <CircularProgressRing
                      score={totalAnsweredCorrectly}
                      total={totalQuestions}
                      size={54}
                      strokeWidth={4.5}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-sm sm:text-base font-bold text-slate-900">
                          {language === 'om'
                            ? 'Adeemsa Qorannoo Kutaa 9ffaa (Study Progress)'
                            : 'Grade 9 Study Progress Tracker'}
                        </h2>
                        <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                          v3.0
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {language === 'om' ? (
                          <>
                            Gaaffilee <span className="font-bold text-slate-800">{totalAnsweredCorrectly}</span> / {totalQuestions} sirriitti deebiste ({overallPercent}%) · <span className="font-semibold text-emerald-700">{masteredModulesCount} Boqonnaa Guutame</span>
                          </>
                        ) : (
                          <>
                            <span className="font-bold text-slate-800">{totalAnsweredCorrectly}</span> / {totalQuestions} questions mastered ({overallPercent}%) · <span className="font-semibold text-emerald-700">{masteredModulesCount} units completed</span>
                          </>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Reset / Actions */}
                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {totalAnsweredCorrectly > 0 && (
                      <button
                        onClick={handleResetProgress}
                        title="Adeemsa haaromsi / Reset Progress"
                        className="min-h-[36px] px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-medium">
                          {language === 'om' ? 'Haaromsi' : 'Reset'}
                        </span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress bar line */}
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-3">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-500 ease-out"
                    style={{ width: `${overallPercent}%` }}
                  />
                </div>
              </div>

              {/* Subject / Category Filter Bar */}
              <SubjectFilter
                categories={categories}
                activeCategory={activeCategory}
                onSelectCategory={setActiveCategory}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                language={language}
              />

              {/* Grid of study modules with visual progress rings & completion statuses */}
              {filteredModules.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {filteredModules.map((module) => (
                    <StudyNoteCard
                      key={module.id}
                      module={module}
                      progress={progressMap[module.id]}
                      language={language}
                      onReadNotes={handleReadNotes}
                      onTakeQuiz={handleTakeQuiz}
                      isBookmarked={bookmarkedIds.has(module.id)}
                      onToggleBookmark={toggleBookmark}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-white p-8 sm:p-10 rounded-2xl border border-slate-200 text-center space-y-3">
                  <BookOpen className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-sm font-semibold text-slate-700">
                    {language === 'om'
                      ? 'Boqonnaan barbaaddan hin argamne.'
                      : 'No modules found matching your search.'}
                  </p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    {language === 'om'
                      ? 'AI fayyadamuun mata-duree barbaaddan haaraa maddisiisuu dandeessu.'
                      : 'You can generate concise notes and 5 questions for any topic using the AI generator.'}
                  </p>
                  <button
                    onClick={() => setIsAiModalOpen(true)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-amber-400 text-slate-950 rounded-xl cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{language === 'om' ? 'Mata-duree Kana Maddisiisi' : 'Generate This Topic'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* AI Topic Generator Modal */}
      <AiGeneratorModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        language={language}
        onModuleGenerated={handleModuleGenerated}
      />

      {/* Mobile Bottom Navigation (Universal touch targets, <= 15% viewport height) */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          setActiveReaderModule(null);
          setActiveQuizModule(null);
          if (tab === 'ai') {
            setIsAiModalOpen(true);
          }
        }}
        language={language}
        onOpenAiGenerator={() => setIsAiModalOpen(true)}
      />

      {/* Mobile-Friendly Quiet Footer (Version 3) */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs text-slate-500 text-center sm:text-left">
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <span className="font-semibold text-slate-800">Barattoota Kutaa 9</span>
            <span>·</span>
            <span className="font-mono text-[11px] font-bold text-amber-700">Version 3.0</span>
            <span>·</span>
            <span>Bilbila Hundaaf Mijaawaa (Universal Mobile)</span>
          </div>
          <div>
            Afaan Oromoo · Ethiopian National Curriculum Standards
          </div>
        </div>
      </footer>
    </div>
  );
}
