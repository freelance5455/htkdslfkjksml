import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Library } from "@/components/Library";
import { Reader } from "@/components/Reader";
import { SettingsSheet } from "@/components/SettingsSheet";
import { IconLogo } from "@/components/Icons";
import { tidyTitle, uid } from "@/lib/format";
import { PdfEngine, acquireEngine, dropEngine, releaseEngine } from "@/lib/pdf";
import * as store from "@/lib/store";
import { DEFAULT_SETTINGS, type Book, type Settings } from "@/lib/types";

export default function App() {
  const [books, setBooks] = useState<Book[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  const [booted, setBooted] = useState(false);
  const [fatal, setFatal] = useState<string | null>(null);
  const [globalSettings, setGlobalSettings] = useState(false);

  const booksRef = useRef<Book[]>(books);
  booksRef.current = books;
  const timers = useRef<Record<string, number>>({});

  const refreshStorage = useCallback(() => {
    store
      .storageUsage()
      .then(setStorage)
      .catch(() => undefined);
  }, []);

  /* ---------------- راه‌اندازی ---------------- */
  useEffect(() => {
    (async () => {
      try {
        const [s, bs] = await Promise.all([store.loadSettings(), store.getAllBooks()]);
        setSettings(s);
        setBooks(bs);
        const last = await store.getLastBook();
        if (last && bs.some((b) => b.id === last)) {
          /* فقط برای ترتیب قفسه؛ کتاب خودکار باز نمی‌شود */
        }
      } catch (e) {
        setFatal(
          `دسترسی به حافظهٔ دستگاه ممکن نشد (${(e as Error)?.message ?? "خطا"}). مرورگر را در حالت ناشناس ببندید یا اجازهٔ ذخیره‌سازی بدهید.`,
        );
      } finally {
        setBooted(true);
        refreshStorage();
      }
    })();
  }, [refreshStorage]);

  /* ---------------- پایداری ---------------- */
  const patchBook = useCallback((id: string, patch: Partial<Book>) => {
    setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b)));
    window.clearTimeout(timers.current[id]);
    timers.current[id] = window.setTimeout(() => {
      const b = booksRef.current.find((x) => x.id === id);
      if (b) store.saveBook(b).then(refreshStorage).catch(() => undefined);
    }, 380);
  }, [refreshStorage]);

  const persistSettings = useCallback((s: Settings) => {
    setSettings(s);
    store.saveSettings(s);
  }, []);

  /* ---------------- افزودن کتاب ---------------- */
  const importBlob = useCallback(
    async (blob: Blob, name: string, size: number) => {
      const title = tidyTitle(name) || "بی‌نام";
      setBusy(`در حال گشودن «${title}»…`);
      const buf = new Uint8Array(await blob.arrayBuffer());
      const id = uid();
      const eng = await acquireEngine(id, () => PdfEngine.open(buf.slice(0)));
      let pageCount = 1;
      let cover: string | null = null;
      try {
        pageCount = Math.max(1, eng.pageCount);
        cover = await eng.thumbnail(1, 320);
      } finally {
        releaseEngine(id);
      }
      await store.putFile(id, new Blob([buf as unknown as BlobPart], { type: "application/pdf" }));
      const book: Book = {
        id,
        title,
        size,
        addedAt: Date.now(),
        pageCount,
        cover,
        progress: null,
        settings: null,
        bookmarks: [],
      };
      await store.saveBook(book);
      setBooks((prev) => [book, ...prev]);
      refreshStorage();
      return book;
    },
    [refreshStorage],
  );

  const addFiles = useCallback(
    async (files: File[]) => {
      for (const f of files) {
        const isPdf = /\.pdf$/i.test(f.name) || f.type === "application/pdf";
        if (!isPdf) continue;
        try {
          await importBlob(f, f.name, f.size);
        } catch (e) {
          setBusy(null);
          window.alert(
            `«${f.name}» باز نشد.\n${(e as Error)?.message ?? ""}\nشاید فایل رمز داشته باشد یا PDF نباشد.`,
          );
        }
      }
      setBusy(null);
    },
    [importBlob],
  );

  const removeBook = useCallback(
    async (id: string) => {
      window.clearTimeout(timers.current[id]);
      dropEngine(id);
      await store.deleteBook(id).catch(() => undefined);
      setBooks((prev) => prev.filter((b) => b.id !== id));
      if (activeId === id) setActiveId(null);
      refreshStorage();
    },
    [activeId, refreshStorage],
  );

  const openBook = useCallback((id: string) => {
    setActiveId(id);
    store.setLastBook(id);
  }, []);

  /* ---------------- قفل اسکرول بدنه هنگام مطالعه ---------------- */
  useEffect(() => {
    const prev = document.body.style.overflow;
    if (activeId) document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [activeId]);

  useEffect(() => {
    const flushAll = () => {
      Object.entries(timers.current).forEach(([id]) => {
        const b = booksRef.current.find((x) => x.id === id);
        if (b) store.saveBook(b).catch(() => undefined);
      });
    };
    window.addEventListener("pagehide", flushAll);
    return () => window.removeEventListener("pagehide", flushAll);
  }, []);

  const activeBook = useMemo(
    () => books.find((b) => b.id === activeId) ?? null,
    [books, activeId],
  );

  const readerSettings = activeBook?.settings ?? settings;

  const motes = useMemo(
    () =>
      Array.from({ length: 11 }).map((_, i) => ({
        left: `${(i * 9.3 + 6) % 96}%`,
        top: `${18 + ((i * 23) % 70)}%`,
        size: 2 + ((i * 7) % 4),
        delay: `${(i * 2.3) % 22}s`,
        dur: `${20 + ((i * 5) % 16)}s`,
      })),
    [],
  );

  if (fatal) {
    return (
      <div className="relative z-10 grid min-h-full place-items-center px-6 text-center">
        <p className="max-w-[42ch] text-[12.5px] leading-7 text-mist">{fatal}</p>
      </div>
    );
  }

  if (!booted) {
    return (
      <div className="relative z-10 grid min-h-full place-items-center">
        <div className="flex flex-col items-center gap-3">
          <span className="relative grid h-14 w-14 place-items-center text-gold2">
            <span className="absolute inset-0 animate-spin rounded-2xl border-2 border-gold/20 border-t-gold" />
            <IconLogo size={26} />
          </span>
          <p className="font-display text-[15px] text-mist">درشت‌نما</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="relative z-10 min-h-full">
        {activeBook ? (
          <Reader
            key={activeBook.id}
            book={activeBook}
            settings={readerSettings}
            onSettings={(s) => patchBook(activeBook.id, { settings: s })}
            onBookPatch={patchBook}
            onClose={() => setActiveId(null)}
            onDelete={removeBook}
          />
        ) : (
          <Library
            books={books}
            settings={settings}
            busy={busy}
            storage={storage}
            onOpen={openBook}
            onAddFiles={(f) => void addFiles(f)}
            onDelete={(id) => void removeBook(id)}
            onOpenSettings={() => setGlobalSettings(true)}
          />
        )}
      </div>

      {!activeBook && (
        <SettingsSheet
          open={globalSettings}
          onClose={() => setGlobalSettings(false)}
          settings={settings}
          update={(p) => persistSettings({ ...settings, ...p })}
          book={null}
          onResetProgress={() => undefined}
          onDeleteBook={() => undefined}
        />
      )}

      <div className="pointer-events-none fixed inset-0 z-[2] overflow-hidden">
        {motes.map((m, i) => (
          <span
            key={i}
            className="mote"
            style={{
              left: m.left,
              top: m.top,
              width: m.size,
              height: m.size,
              animationDelay: m.delay,
              animationDuration: m.dur,
            }}
          />
        ))}
      </div>
    </>
  );
}
