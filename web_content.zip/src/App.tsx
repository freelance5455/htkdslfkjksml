import React, { useState, useEffect, useRef } from 'react';
import { GameEngine, TimeOfDay } from './game/core/GameEngine';
import { IntroSequence } from './components/IntroSequence';
import { MainMenu } from './components/MainMenu';
import { HUD } from './components/HUD';
import { LoadoutMenu } from './components/LoadoutMenu';
import { SettingsModal } from './components/SettingsModal';
import { HUDEditor } from './components/HUDEditor';
import { MatchSetupModal } from './components/MatchSetupModal';
import { MapLoadingScreen } from './components/MapLoadingScreen';
import { MapCinematicIntro } from './components/MapCinematicIntro';
import { GameOverModal } from './components/GameOverModal';
import { CHARACTERS } from './game/models/CharacterModels';
import { MAP_CATALOG } from './game/map/MapRegistry';
import { HUDLayoutConfig } from './game/hud/HUDConfig';
import { MatchSettingsManager, MatchConfiguration } from './game/settings/MatchSettingsManager';
import { sound } from './audio/SoundEngine';

type GameScreen = 'intro' | 'menu' | 'map_loading' | 'map_cinematic' | 'playing' | 'gameover';
type ModalState = 'none' | 'match_setup' | 'characters' | 'loadout' | 'settings' | 'hud_editor';

export const App: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Top level screen state
  const [screen, setScreen] = useState<GameScreen>('intro');
  const [activeModal, setActiveModal] = useState<ModalState>('none');
  const [isPaused, setIsPaused] = useState(false);

  // Active configurations
  const [pendingMatchCfg, setPendingMatchCfg] = useState<MatchConfiguration>(() => MatchSettingsManager.get());
  const [currentMapId, setCurrentMapId] = useState<string>(() => MatchSettingsManager.get().mapId);
  const [activeCharacterId, setActiveCharacterId] = useState<string>(() => MatchSettingsManager.get().operatorId);
  const [activePrimaryId, setActivePrimaryId] = useState<string>(() => MatchSettingsManager.get().primaryWeaponId);
  const [activeSecondaryId, setActiveSecondaryId] = useState<string>(() => MatchSettingsManager.get().secondaryWeaponId);
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>('evening');
  const [menuBackground, setMenuBackground] = useState<string>(() => localStorage.getItem('blackout_menu_bg') || 'bg_suburban');

  // Initialize Game Engine once on mount - NEVER destroy on screen changes
  useEffect(() => {
    if (!containerRef.current || engineRef.current) return;

    const engine = new GameEngine(containerRef.current);
    engineRef.current = engine;
    engine.start();

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // Separate death check interval that runs only while playing
  useEffect(() => {
    if (screen !== 'playing') return;

    const checkDeathInterval = window.setInterval(() => {
      if (engineRef.current?.player.stats.isDead) {
        setScreen('gameover');
      }
    }, 200);

    return () => {
      clearInterval(checkDeathInterval);
    };
  }, [screen]);

  const setMenuCamera = (engine: GameEngine, bgId: string = menuBackground) => {
    let chosen = bgId;
    if (chosen === 'random') {
      const opts = ['bg_suburban', 'bg_city', 'bg_military', 'bg_forest', 'bg_hospital', 'bg_industrial', 'bg_flooded'];
      chosen = opts[Math.floor(Math.random() * opts.length)];
    }

    if (chosen === 'bg_city') {
      engine.camera.position.set(0, 4.5, 24);
      engine.camera.lookAt(0, 2, -10);
    } else if (chosen === 'bg_military') {
      engine.camera.position.set(0, 6.0, 22);
      engine.camera.lookAt(0, 3, -10);
    } else if (chosen === 'bg_forest') {
      engine.camera.position.set(0, 4.0, 18);
      engine.camera.lookAt(0, 2, -12);
    } else if (chosen === 'bg_hospital') {
      engine.camera.position.set(0, 5.0, 26);
      engine.camera.lookAt(0, 3, 0);
    } else if (chosen === 'bg_industrial') {
      engine.camera.position.set(0, 7.0, 24);
      engine.camera.lookAt(0, 4, -10);
    } else if (chosen === 'bg_flooded') {
      engine.camera.position.set(0, 4.0, 20);
      engine.camera.lookAt(0, 1, 0);
    } else {
      engine.camera.position.set(-12, 5.5, 14);
      engine.camera.lookAt(0, 1.5, 0);
    }
  };

  const handleSelectMenuBackground = (bgId: string) => {
    setMenuBackground(bgId);
    try {
      localStorage.setItem('blackout_menu_bg', bgId);
    } catch {}
    if (engineRef.current) {
      setMenuCamera(engineRef.current, bgId);
    }
  };

  const handleIntroComplete = () => {
    if (engineRef.current) {
      setMenuCamera(engineRef.current, menuBackground);
    }
    setScreen('menu');
  };

  // Requirement 24: START button opens MAP SELECTION -> DIFFICULTY -> ZOMBIE/PLAYER SETTINGS
  const handleOpenMatchSetup = () => {
    sound.playUIClick();
    setActiveModal('match_setup');
  };

  // Called when player confirms START MATCH from MatchSetupModal
  const handleStartMatchFromSetup = (mapId: string, cfg: MatchConfiguration) => {
    setPendingMatchCfg(cfg);
    setCurrentMapId(mapId);
    setActiveCharacterId(cfg.operatorId);
    setActivePrimaryId(cfg.primaryWeaponId);
    setActiveSecondaryId(cfg.secondaryWeaponId);
    setActiveModal('none');

    // Requirement 5: Show the loading screen for the selected map
    setScreen('map_loading');
  };

  // Called when MapLoadingScreen completes streaming the selected map
  const handleMapLoaded = () => {
    // Requirement 7 & 8: Transition into 15-second pre-outbreak map cinematic
    setScreen('map_cinematic');
  };

  // Called when MapCinematicIntro finishes or player taps SKIP
  const handleCinematicFinish = () => {
    if (!engineRef.current) return;
    const engine = engineRef.current;

    sound.resume();
    sound.stopCinematicMusic();

    // Apply Player match settings
    const pCfg = pendingMatchCfg.playerSettings;
    engine.player.stats.maxHealth = pCfg.health;
    engine.player.stats.health = pCfg.health;
    engine.player.stats.armor = pCfg.armor;
    engine.player.autoSprint = pCfg.autoSprint;
    engine.player.sensX = pCfg.sensitivity;
    engine.player.sensY = pCfg.sensitivity;
    engine.player.adsSensitivityMult = pCfg.adsSensitivity;
    engine.player.sniperSensitivity = pCfg.sniperSensitivity || 0.45;
    engine.player.opticSensitivity = pCfg.opticSensitivity || 0.55;
    engine.player.adsBehavior = pCfg.adsBehavior || 'hybrid';

    // Apply Zombie match settings
    const zCfg = pendingMatchCfg.zombieSettings;
    engine.zombies.difficulty = {
      level: pendingMatchCfg.difficulty,
      healthMultiplier: zCfg.healthMultiplier,
      damageMultiplier: zCfg.damageMultiplier,
      speedMultiplier: zCfg.speedMultiplier,
      intelligence: zCfg.intelligence,
      spawnRate: zCfg.spawnRate,
      attackCooldown: zCfg.intelligence === 'tactical' ? 0.95 : 1.2,
      maxZombies: zCfg.zombiesPerWave,
    };

    engine.player.reset(activeCharacterId, engine.mapBuilder.playerSpawn);
    engine.weapons.setWeapon('primary', activePrimaryId);
    engine.weapons.setWeapon('secondary', activeSecondaryId);
    engine.zombies.startNewGame();
    engine.isPaused = false;
    setIsPaused(false);

    setScreen('playing');

    try {
      engine.renderer.domElement.requestPointerLock?.();
    } catch {
      // Ignore
    }
  };

  // Quick Start / Restart
  const handleRestart = () => {
    setScreen('map_loading');
  };

  // Time of Day Toggle
  const handleToggleTimeOfDay = (tod: TimeOfDay) => {
    setTimeOfDay(tod);
    if (engineRef.current) {
      engineRef.current.setTimeOfDay(tod);
    }
  };

  // Character selection
  const handleSelectCharacter = (charId: string) => {
    setActiveCharacterId(charId);
    if (engineRef.current) {
      engineRef.current.player.stats.characterId = charId;
    }
    setActiveModal('none');
  };

  // Weapon loadout selection
  const handleSelectWeapons = (primaryId: string, secondaryId: string) => {
    setActivePrimaryId(primaryId);
    setActiveSecondaryId(secondaryId);
    if (engineRef.current) {
      engineRef.current.weapons.setWeapon('primary', primaryId);
      engineRef.current.weapons.setWeapon('secondary', secondaryId);
    }
    setActiveModal('none');
  };

  // In-Game Pause
  const handleOpenPause = () => {
    if (!engineRef.current) return;
    engineRef.current.isPaused = true;
    setIsPaused(true);
    setActiveModal('settings');
    if (document.pointerLockElement) {
      document.exitPointerLock?.();
    }
  };

  const handleResume = () => {
    if (!engineRef.current) return;
    engineRef.current.isPaused = false;
    setIsPaused(false);
    setActiveModal('none');
    try {
      engineRef.current.renderer.domElement.requestPointerLock?.();
    } catch {
      // Ignore
    }
  };

  // Return to Menu / Leave Game
  const handleReturnToMenu = () => {
    if (!engineRef.current) return;
    const engine = engineRef.current;
    engine.zombies.clearAllZombies();
    engine.isPaused = false;
    setIsPaused(false);
    setActiveModal('none');
    setMenuCamera(engine);
    sound.startCinematicMusic();
    setScreen('menu');
  };

  const handleSaveHUDEditor = (_cfg: HUDLayoutConfig) => {
    setActiveModal('settings');
  };

  const activeChar = CHARACTERS.find(c => c.id === activeCharacterId) || CHARACTERS[0];
  const currentMap = MAP_CATALOG.find(m => m.id === currentMapId) || MAP_CATALOG[0];

  return (
    <div className="relative w-full h-full overflow-hidden bg-black font-sans">
      {/* 3D WebGL Canvas Container */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full z-0" />

      {/* 1. Launch / Intro Sequence (Verified 9-step sequence) */}
      {screen === 'intro' && (
        <IntroSequence onComplete={handleIntroComplete} engine={engineRef.current} />
      )}

      {/* 2. Compact Cinematic Main Menu */}
      {screen === 'menu' && (
        <MainMenu
          onPlay={handleOpenMatchSetup}
          onOpenCharacters={() => setActiveModal('characters')}
          onOpenLoadout={() => setActiveModal('loadout')}
          onOpenSettings={() => setActiveModal('settings')}
          timeOfDay={timeOfDay}
          onToggleTimeOfDay={handleToggleTimeOfDay}
          onQuit={() => setScreen('intro')}
          characterName={activeChar.name}
          currentMapName={currentMap.name}
          menuBackground={menuBackground}
          onSelectMenuBackground={handleSelectMenuBackground}
        />
      )}

      {/* 3. Selected Map Asynchronous Loading Screen */}
      {screen === 'map_loading' && engineRef.current && (
        <MapLoadingScreen
          mapId={currentMapId}
          engine={engineRef.current}
          onLoaded={handleMapLoaded}
        />
      )}

      {/* 4. 15-Second Pre-Outbreak Map Cinematic (Requirement 7 & 8) */}
      {screen === 'map_cinematic' && engineRef.current && (
        <MapCinematicIntro
          mapId={currentMapId}
          engine={engineRef.current}
          onFinish={handleCinematicFinish}
        />
      )}

      {/* 5. In-Game HUD (During active play - Requirement 9: Completely hidden during cinematic) */}
      {screen === 'playing' && engineRef.current && (
        <HUD
          engine={engineRef.current}
          onOpenSettings={() => setActiveModal('settings')}
          onOpenPause={handleOpenPause}
        />
      )}

      {/* 5. Game Over Modal */}
      {screen === 'gameover' && engineRef.current && (
        <GameOverModal
          stats={engineRef.current.player.stats}
          wave={engineRef.current.zombies.currentWave}
          onRestart={handleRestart}
          onMainMenu={handleReturnToMenu}
        />
      )}

      {/* --- MODAL OVERLAYS --- */}
      {/* Complete Pre-Match Setup Briefing Modal (Map Selection + Difficulty + Zombie Settings + Player Settings) */}
      {activeModal === 'match_setup' && (
        <MatchSetupModal
          onStartMatch={handleStartMatchFromSetup}
          onClose={() => setActiveModal('none')}
        />
      )}

      {/* Characters & 3D Preview Modal */}
      {activeModal === 'characters' && (
        <LoadoutMenu
          activeCharacterId={activeCharacterId}
          onSelectCharacter={handleSelectCharacter}
          activePrimaryId={activePrimaryId}
          activeSecondaryId={activeSecondaryId}
          onSelectWeapons={handleSelectWeapons}
          onClose={() => setActiveModal('none')}
          initialTab="operators"
        />
      )}

      {/* Loadout & 3D Weapon Preview Modal */}
      {activeModal === 'loadout' && (
        <LoadoutMenu
          activeCharacterId={activeCharacterId}
          onSelectCharacter={handleSelectCharacter}
          activePrimaryId={activePrimaryId}
          activeSecondaryId={activeSecondaryId}
          onSelectWeapons={handleSelectWeapons}
          onClose={() => setActiveModal('none')}
          initialTab="armory"
        />
      )}

      {/* In-Game Pause & Settings Modal */}
      {activeModal === 'settings' && engineRef.current && (
        <SettingsModal
          engine={engineRef.current}
          onClose={() => {
            if (isPaused) handleResume();
            else setActiveModal('none');
          }}
          onResume={handleResume}
          onOpenHUDEditor={() => setActiveModal('hud_editor')}
          onLeaveGame={handleReturnToMenu}
          isPaused={isPaused}
        />
      )}

      {/* Zero-Jitter HUD Layout Customizer Editor */}
      {activeModal === 'hud_editor' && (
        <HUDEditor
          onClose={() => setActiveModal('settings')}
          onSave={handleSaveHUDEditor}
          onResume={handleResume}
          isPaused={isPaused}
        />
      )}
    </div>
  );
};

export default App;
