/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { TournamentPanel } from './components/TournamentPanel';
import { SensitivityLab } from './components/SensitivityLab';
import { HudBuilder } from './components/HudBuilder';
import { WeaponArmory } from './components/WeaponArmory';
import { CharacterCombos } from './components/CharacterCombos';
import { SquadRoster } from './components/SquadRoster';
import { ReflexTrainer } from './components/ReflexTrainer';
import { INITIAL_ROOM_CONFIG, INITIAL_TEAMS } from './data/freeFireData';
import { MatchRoom, TeamScore } from './types';
import { Trophy, Flame, Shield, Target, Crosshair, Users, Zap, ExternalLink } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('scrims');
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Persistent Room Config
  const [roomConfig, setRoomConfig] = useState<MatchRoom>(() => {
    try {
      const saved = localStorage.getItem('ff_room_config');
      return saved ? JSON.parse(saved) : INITIAL_ROOM_CONFIG;
    } catch {
      return INITIAL_ROOM_CONFIG;
    }
  });

  // Persistent Teams Scoreboard
  const [teams, setTeams] = useState<TeamScore[]>(() => {
    try {
      const saved = localStorage.getItem('ff_teams');
      return saved ? JSON.parse(saved) : INITIAL_TEAMS;
    } catch {
      return INITIAL_TEAMS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('ff_room_config', JSON.stringify(roomConfig));
    } catch {
      // storage full or blocked
    }
  }, [roomConfig]);

  useEffect(() => {
    try {
      localStorage.setItem('ff_teams', JSON.stringify(teams));
    } catch {
      // storage full or blocked
    }
  }, [teams]);

  // Booyah leader
  const booyahTeam = teams.find(t => t.booyah) || teams[0];
  const totalKillsLobby = teams.reduce((acc, t) => acc + t.kills, 0);

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col selection:bg-orange-600 selection:text-white">
      {/* Top Esports Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isMuted={isMuted}
        setIsMuted={setIsMuted}
        roomId={roomConfig.roomId}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-6 space-y-6">
        {/* Quick Ticker Strip */}
        <div className="bg-[#0e121e] border border-orange-500/20 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 font-bold text-orange-400 font-rajdhani text-sm">
              <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
              MATCH #{roomConfig.matchNumber} LIVE
            </span>
            <span className="text-slate-600 hidden sm:inline">|</span>
            <span className="text-slate-300 hidden sm:inline">
              Leader: <strong className="text-amber-300 font-bold">{booyahTeam ? booyahTeam.teamName : 'None'}</strong> ({booyahTeam ? booyahTeam.totalPoints : 0} pts)
            </span>
            <span className="text-slate-600 hidden md:inline">|</span>
            <span className="text-slate-400 hidden md:inline">
              Lobby Frags: <strong className="text-cyan-400 font-mono font-bold">{totalKillsLobby} Kills</strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">Map Rotation:</span>
            <span className="px-2 py-0.5 bg-orange-500/20 text-orange-300 border border-orange-500/30 rounded font-semibold text-[11px]">
              {roomConfig.map}
            </span>
            <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded font-semibold text-[11px]">
              {roomConfig.mode}
            </span>
          </div>
        </div>

        {/* Tab Content Router */}
        {activeTab === 'scrims' && (
          <TournamentPanel
            roomConfig={roomConfig}
            setRoomConfig={setRoomConfig}
            teams={teams}
            setTeams={setTeams}
          />
        )}

        {activeTab === 'sensitivity' && <SensitivityLab />}

        {activeTab === 'hud' && <HudBuilder />}

        {activeTab === 'armory' && <WeaponArmory />}

        {activeTab === 'combos' && <CharacterCombos />}

        {activeTab === 'roster' && <SquadRoster />}

        {activeTab === 'trainer' && <ReflexTrainer />}
      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-800/80 bg-[#080a12] py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-orange-600/30 border border-orange-500/50 flex items-center justify-center text-orange-400 font-bold text-xs font-heading">
              FF
            </div>
            <span className="font-heading text-sm font-bold text-slate-300">
              FREE FIRE PRO COMMAND PANEL
            </span>
            <span className="text-[11px] text-slate-500">
              • Esports Operations & Calibration Lab
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-400 text-[11px]">
            <span>Official FFWS 12pt Rules</span>
            <span>•</span>
            <span>OB44 Recoil & Armor Curves</span>
            <span>•</span>
            <span>Community Tournament Utility</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
