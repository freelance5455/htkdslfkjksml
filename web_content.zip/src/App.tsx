import React, { useState, useEffect, useRef } from 'react';
import { GoogleAuthProvider, signInWithPopup, onAuthStateChanged } from 'firebase/auth';
import { doc, setDoc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { app, db, auth, storage, ADMIN, setCanalPTT, iniciarPTT, detenerPTT } from './firebase-config';
import firebaseConfig from '../firebase-applet-config.json';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { 
  Mic, Settings, Heart, Users, History, VolumeX, Volume2, 
  Shield, Bot, Key, Power, Search, Zap, CheckCircle2, AlertTriangle, MessageSquare, Phone,
  Video, PhoneOff, VideoOff, Camera, RefreshCcw, Share2, Mail, Lock, User, CheckSquare, Square, Ban, ArrowLeft,
  Crown, FolderOpen, Plus, CreditCard, Star, Terminal, Radar, RadioReceiver, Tv, Navigation, ShieldCheck, HelpCircle
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { NeuralNetworkUI } from './components/NeuralNetworkUI';
import { SonarMap } from './components/SonarMap';
import { PhoneAuthModal } from './components/PhoneAuthModal';
import { YouTubeMusicPlayer } from './components/YouTubeMusicPlayer';
import { GpsNavigator } from './components/GpsNavigator';
import { SystemDiagnostics } from './components/SystemDiagnostics';
import { ClientModuleCard } from './components/ClientModuleCard';
import { TutorialModal } from './components/TutorialModal';
import type { ClientModuleData, RadioChannelItem } from './types/dataconnect';
import { 
  crearModuloCliente, 
  obtenerModuloGuardado, 
  CANALES_PUBLICOS, 
  BASE_CANALES_MODULO,
  calcularDiasRestantesDemo
} from './services/clientModuleService';
import { backgroundAudioService } from './services/backgroundAudioService';

const messaging = typeof window !== 'undefined' ? (() => {
  try {
    return getMessaging(app);
  } catch {
    return null;
  }
})() : null;

// --- Funcionalidad de Emergencia (Anti-caídas) ---
const EMERGENCY_API_KEY = import.meta.env.VITE_EMERGENCY_API_KEY || 'fallback-key-123';

const triggerEmergencyWrite = async (data: any) => {
  try {
    // Escritura directa en Firestore como respaldo persistente
    await setDoc(doc(db, 'emergency_channels', auth.currentUser?.email || 'anon'), {
      ...data,
      timestamp: Date.now(),
      apiKey: EMERGENCY_API_KEY
    });
    console.log('Datos enviados a canal de emergencia (Firestore)');
  } catch (err) {
    console.error('Fallo crítico en canal de emergencia:', err);
  }
};

// --- Type Definitions ---
interface Message {
  id: string;
  username: string;
  transcript: string;
  audioBlob?: Blob;
  timestamp: number;
}

const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

// --- Mock Data for UI ---
const mockUsers = [
  { name: 'Carlos (Bot)', status: 'Escuchando', state: 'listening', role: 'admin' },
  { name: 'Maria (Bot)', status: 'Esperando', state: 'waiting', role: 'user' },
  { name: 'Jorge (Bot)', status: 'Silenciado', state: 'muted', role: 'user' },
];

const playPttTone = (type: string, action: 'start' | 'stop') => {
  if (type === 'silent') return;
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    const now = ctx.currentTime;
    
    if (type === 'nextel') {
      osc.type = 'square';
      if (action === 'start') {
        osc.frequency.setValueAtTime(1800, now);
        osc.frequency.setValueAtTime(0, now + 0.05);
        osc.frequency.setValueAtTime(1800, now + 0.06);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.setValueAtTime(0, now + 0.05);
        gain.gain.setValueAtTime(0.05, now + 0.06);
        gain.gain.setTargetAtTime(0, now + 0.1, 0.015);
        osc.start(now);
        osc.stop(now + 0.15);
      } else {
        osc.frequency.setValueAtTime(1200, now);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.setTargetAtTime(0, now + 0.05, 0.015);
        osc.start(now);
        osc.stop(now + 0.1);
      }
    } else if (type === 'nextel-alert') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(2200, now);
      osc.frequency.setValueAtTime(0, now + 0.08);
      osc.frequency.setValueAtTime(2200, now + 0.10);
      osc.frequency.setValueAtTime(0, now + 0.18);
      osc.frequency.setValueAtTime(2200, now + 0.20);
      
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.setValueAtTime(0, now + 0.08);
      gain.gain.setValueAtTime(0.05, now + 0.10);
      gain.gain.setValueAtTime(0, now + 0.18);
      gain.gain.setValueAtTime(0.05, now + 0.20);
      gain.gain.setTargetAtTime(0, now + 0.28, 0.015);
      
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'moto-mdc') {
      // Classic MDC-1200 data squawk (fast alternating frequencies)
      osc.type = 'sine';
      for (let i = 0; i < 20; i++) {
        osc.frequency.setValueAtTime(i % 2 === 0 ? 1200 : 1800, now + (i * 0.008));
      }
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.16, 0.01);
      osc.start(now);
      osc.stop(now + 0.18);
    } else if (type === 'moto-roger') {
      // Standard Motorola single beep
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1000, now);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.setTargetAtTime(0, now + 0.1, 0.015);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'moto-trunk') {
      // Motorola Trunking Talk Permit (3 short 900Hz beeps)
      osc.type = 'sine';
      osc.frequency.setValueAtTime(900, now);
      
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.setValueAtTime(0, now + 0.03);
      gain.gain.setValueAtTime(0.1, now + 0.05);
      gain.gain.setValueAtTime(0, now + 0.08);
      gain.gain.setValueAtTime(0.1, now + 0.10);
      gain.gain.setTargetAtTime(0, now + 0.13, 0.015);
      
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'military') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.exponentialRampToValueAtTime(40, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'cyber') {
      osc.type = 'sine';
      if (action === 'start') {
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(2400, now + 0.1);
      } else {
        osc.frequency.setValueAtTime(2400, now);
        osc.frequency.exponentialRampToValueAtTime(600, now + 0.1);
      }
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'mil-alpha') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.setValueAtTime(1500, now + 0.05);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.setTargetAtTime(0, now + 0.08, 0.015);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'mil-bravo') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.setValueAtTime(0, now + 0.04);
      osc.frequency.setValueAtTime(800, now + 0.05);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setValueAtTime(0, now + 0.04);
      gain.gain.setValueAtTime(0.08, now + 0.05);
      gain.gain.setTargetAtTime(0, now + 0.08, 0.015);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'mil-charlie') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(2000, now);
      osc.frequency.exponentialRampToValueAtTime(500, now + 0.15);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'mil-delta') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1000, now);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === 'mil-echo') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(2500, now);
      osc.frequency.setValueAtTime(2000, now + 0.02);
      osc.frequency.setValueAtTime(2500, now + 0.04);
      gain.gain.setValueAtTime(0.04, now);
      gain.gain.setTargetAtTime(0, now + 0.06, 0.015);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'yt-1') {
      // Classic radio double beep (similar to standard roger beep)
      osc.type = 'sine';
      if (action === 'start') {
        osc.frequency.setValueAtTime(1046.50, now); // C6
        osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6
      } else {
        osc.frequency.setValueAtTime(1318.51, now);
        osc.frequency.setValueAtTime(1046.50, now + 0.08);
      }
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.setValueAtTime(0, now + 0.07);
      gain.gain.setValueAtTime(0.1, now + 0.08);
      gain.gain.setTargetAtTime(0, now + 0.15, 0.015);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'yt-2') {
      // Short fast chirp
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(2000, now);
      osc.frequency.linearRampToValueAtTime(1000, now + 0.05);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.05, 0.015);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === 'yt-3') {
      // Data burst / MDC simulation
      osc.type = 'square';
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.setValueAtTime(1800, now + 0.02);
      osc.frequency.setValueAtTime(1200, now + 0.04);
      osc.frequency.setValueAtTime(1800, now + 0.06);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.setTargetAtTime(0, now + 0.08, 0.015);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'yt-4') {
      // Triple beep
      osc.type = 'sine';
      osc.frequency.setValueAtTime(900, now);
      osc.frequency.setValueAtTime(900, now + 0.06);
      osc.frequency.setValueAtTime(900, now + 0.12);
      
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.setValueAtTime(0, now + 0.04);
      gain.gain.setValueAtTime(0.1, now + 0.06);
      gain.gain.setValueAtTime(0, now + 0.10);
      gain.gain.setValueAtTime(0.1, now + 0.12);
      gain.gain.setTargetAtTime(0, now + 0.16, 0.015);
      
      osc.start(now);
      osc.stop(now + 0.2);
    }
  } catch (e) {
    console.error("Audio API error", e);
  }
};

const playMessageTone = (type: string) => {
  if (type === 'silent') return;
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    const now = ctx.currentTime;
    
    if (type === 'ping') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.setValueAtTime(1760, now + 0.08);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.2, 0.02);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'sonar') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.3);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.setTargetAtTime(0, now + 0.3, 0.03);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === 'nextel-chirp') {
      // Iconic Nextel Direct Connect dual chirp
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(2500, now);
      osc.frequency.setValueAtTime(1800, now + 0.06);
      osc.frequency.setValueAtTime(2500, now + 0.12);
      gain.gain.setValueAtTime(0.09, now);
      gain.gain.setTargetAtTime(0, now + 0.2, 0.02);
      osc.start(now);
      osc.stop(now + 0.24);
    } else if (type === 'moto-chirp') {
      // Motorola trunk chirp
      osc.type = 'square';
      osc.frequency.setValueAtTime(1900, now);
      osc.frequency.setValueAtTime(2800, now + 0.05);
      gain.gain.setValueAtTime(0.07, now);
      gain.gain.setTargetAtTime(0, now + 0.15, 0.02);
      osc.start(now);
      osc.stop(now + 0.18);
    } else if (type === 'nextel-beep') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1046.5, now); // C6
      osc.frequency.setValueAtTime(1318.5, now + 0.08); // E6
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.22, 0.02);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'moto-roger') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1800, now);
      osc.frequency.setValueAtTime(1200, now + 0.07);
      osc.frequency.setValueAtTime(2400, now + 0.14);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.25, 0.02);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'trunk-dispatch') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(950, now);
      osc.frequency.setValueAtTime(1900, now + 0.05);
      osc.frequency.setValueAtTime(1400, now + 0.1);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.25, 0.02);
      osc.start(now);
      osc.stop(now + 0.28);
    } else if (type === 'cyber') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(1500, now);
      osc.frequency.setValueAtTime(2500, now + 0.05);
      osc.frequency.setValueAtTime(1800, now + 0.1);
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.setTargetAtTime(0, now + 0.18, 0.02);
      osc.start(now);
      osc.stop(now + 0.22);
    } else if (type === 'alarm') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(1400, now);
      osc.frequency.setValueAtTime(900, now + 0.08);
      osc.frequency.setValueAtTime(1400, now + 0.16);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.setTargetAtTime(0, now + 0.25, 0.02);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'chime') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.08);
      osc.frequency.setValueAtTime(783.99, now + 0.16);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.setTargetAtTime(0, now + 0.3, 0.03);
      osc.start(now);
      osc.stop(now + 0.35);
    }
  } catch (e) {
    console.error("Audio error", e);
  }
};

const renderStaticWaveform = (blob: Blob, id: string) => {
  const numBars = 32;
  const bars = [];
  let seed = blob.size;
  for (let i = 0; i < id.length; i++) {
    seed += id.charCodeAt(i);
  }
  
  for (let i = 0; i < numBars; i++) {
    const sinVal = Math.sin(seed + i * 0.5);
    const height = Math.floor(4 + Math.abs(sinVal) * 22);
    bars.push(
      <div 
        key={i} 
        className="w-1 bg-[#9D00FF] rounded-full transition-all"
        style={{ height: `${height}px`, opacity: i % 2 === 0 ? 0.9 : 0.4 }}
      />
    );
  }
  return (
    <div className="flex items-center gap-1 my-2 h-8 px-3 bg-black/50 rounded-lg border border-[#9D00FF]/30 overflow-hidden w-full justify-between shadow-[inset_0_0_12px_rgba(157,0,255,0.15)]">
      {bars}
    </div>
  );
};

export default function App() {
  // --- Auth & Registration States ---
   const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
   const [isCharging, setIsCharging] = useState<boolean | null>(null);

   useEffect(() => {
     if ('getBattery' in navigator) {
       (navigator as any).getBattery().then((battery: any) => {
         setBatteryLevel(Math.round(battery.level * 100));
         setIsCharging(battery.charging);

         battery.addEventListener('levelchange', () => {
           setBatteryLevel(Math.round(battery.level * 100));
         });
         battery.addEventListener('chargingchange', () => {
           setIsCharging(battery.charging);
         });
       }).catch(() => {});
     }
   }, []);
  const [authState, setAuthState] = useState<'login' | 'verifying' | 'key_generated' | 'authenticated'>('login');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [accessKey, setAccessKey] = useState('');
  const [authError, setAuthError] = useState('');

  // --- Radio States ---
  const [socket, setSocket] = useState<Socket | null>(null);
  const [channelId, setChannelId] = useState<string>('GENERAL DEMO');
  const [currentFrequency, setCurrentFrequency] = useState<string>('433.100');
  const [clientModule, setClientModule] = useState<ClientModuleData>(() => {
    const guardado = obtenerModuloGuardado();
    if (guardado) return guardado;
    const randomId = 'SONO-DEMO-' + Math.floor(1000 + Math.random() * 9000);
    const baseFreq = 433.500;
    return {
      tipo: 'demo_prueba',
      cliente_id: randomId,
      nombre: 'USUARIO_PRUEBA',
      estado: 'activo',
      creado_en: new Date().toISOString(),
      vencimiento_demo: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      frecuencia_base: '433.500',
      canales_publicos: CANALES_PUBLICOS,
      modulo_privado: BASE_CANALES_MODULO.map((c, i) => ({
        id: c.id,
        nombre: c.nombre,
        freq: (baseFreq + (i * 0.100)).toFixed(3),
        acceso: 'demo_limitado'
      })),
      limite_usuarios: 5
    };
  });
  const [username, setUsername] = useState<string>('');
  const [userUniqueId, setUserUniqueId] = useState<string>(() => {
    const guardado = obtenerModuloGuardado();
    return guardado?.cliente_id || 'SONO-DEMO-8241';
  });

  const handleSelectRadioChannel = (canal: RadioChannelItem) => {
    setChannelId(canal.nombre);
    setCurrentFrequency(canal.freq);
    if (socket) {
      socket.emit('join-channel', canal.nombre, username || displayName || 'Operador');
    }
  };

  const handleRegenerateDemoModule = async () => {
    const nuevo = await crearModuloCliente(username || displayName || 'USUARIO_PRUEBA', true);
    setClientModule(nuevo);
    setUserUniqueId(nuevo.cliente_id);
    alert(`Nuevo módulo demo asignado: ${nuevo.cliente_id} (Frecuencia base: ${nuevo.frecuencia_base} MHz)`);
  };

  const handleUpgradeToPremium = async () => {
    const premium = await crearModuloCliente(username || displayName || 'CLIENTE_PREMIUM', false);
    setClientModule(premium);
    setSubscription('pro');
    setUserUniqueId(premium.cliente_id);
    alert(`¡Felicidades! Módulo Oficial Activado para Sonó Radio Sonovisión.\nID Oficial: ${premium.cliente_id}`);
  };

  // --- Background Audio & Notification States ---
  const [isBgAudioActive, setIsBgAudioActive] = useState<boolean>(() => {
    return backgroundAudioService.isBackgroundEnabled();
  });

  const toggleBackgroundMode = async () => {
    await backgroundAudioService.initAndUnlockAudio();
    if ('Notification' in window && Notification.permission !== 'granted') {
      try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') setNotificationsEnabled(true);
      } catch (e) {
        console.warn('Permiso de notificación no concedido:', e);
      }
    }
    const nextState = !isBgAudioActive;
    backgroundAudioService.setBackgroundEnabled(nextState);
    setIsBgAudioActive(nextState);
    if (nextState) {
      backgroundAudioService.speakVoiceMessage('Sonó Radio', 'Modo en segundo plano activo. Las transmisiones se escucharán con audio.');
    }
  };

  useEffect(() => {
    const handleUserInteraction = () => {
      backgroundAudioService.initAndUnlockAudio();
    };
    window.addEventListener('click', handleUserInteraction, { once: true });
    window.addEventListener('touchstart', handleUserInteraction, { once: true });
    window.addEventListener('keydown', handleUserInteraction, { once: true });
    return () => {
      window.removeEventListener('click', handleUserInteraction);
      window.removeEventListener('touchstart', handleUserInteraction);
      window.removeEventListener('keydown', handleUserInteraction);
    };
  }, []);
  const [targetIdCall, setTargetIdCall] = useState<string>('');
  const [contacts, setContacts] = useState<{ id: string; name: string }[]>(() => {
    try {
      const saved = localStorage.getItem('sono_contacts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [newContactName, setNewContactName] = useState('');
  const [newContactId, setNewContactId] = useState('');
  const [showContactsModal, setShowContactsModal] = useState(false);
  const [showPhoneAuthModal, setShowPhoneAuthModal] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('sono_contacts', JSON.stringify(contacts));
    } catch (e) {}
  }, [contacts]);

  // Firebase Auth persistence listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const uid = user.uid;
        const emailVal = user.email || user.phoneNumber || 'operador@sono.app';
        setEmail(emailVal);
        
        try {
          const userDoc = await getDoc(doc(db, 'users', user.email || user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUserUniqueId(data.userUniqueId || 'SONO-ID-' + uid.substring(0, 6).toUpperCase());
            setUsername(data.fullName || data.username || emailVal.split('@')[0]);
            setDisplayName(data.fullName || data.username || emailVal.split('@')[0]);
          } else {
            setUserUniqueId('SONO-ID-' + uid.substring(0, 6).toUpperCase());
            setUsername(emailVal.split('@')[0]);
            setDisplayName(emailVal.split('@')[0]);
          }
        } catch (e) {
          setUserUniqueId('SONO-ID-' + uid.substring(0, 6).toUpperCase());
          setUsername(emailVal.split('@')[0]);
          setDisplayName(emailVal.split('@')[0]);
        }

        setAuthState('authenticated');
      }
    });

    return () => unsubscribe();
  }, []);
  
  const [isRecording, setIsRecording] = useState(false);
  const [isScreenLocked, setIsScreenLocked] = useState(false); // Added
  const [exclusiveMode, setExclusiveMode] = useState(false); // Added
  const exclusiveModeRef = useRef(false); // Added
  useEffect(() => { exclusiveModeRef.current = exclusiveMode; }, [exclusiveMode]); // Added
  const [status, setStatus] = useState<'Escuchando' | 'Transmitiendo' | 'Esperando'>('Escuchando');
  const [isMuted, setIsMuted] = useState(false);
  const [speakerName, setSpeakerName] = useState<string | null>(null);
  
  const [isConnected, setIsConnected] = useState(false);
  const [latency, setLatency] = useState<number | null>(null);
  const [latencyHistory, setLatencyHistory] = useState<{ time: string, ping: number }[]>([]);
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeTab, setActiveTab] = useState<'main' | 'history' | 'ai' | 'settings' | 'admin' | 'groups' | 'plans' | 'modules' | 'termux' | 'sonar' | 'heal' | 'gmail' | 'youtube' | 'gps' | 'diagnostics'>('main');
  const [sonarTargets, setSonarTargets] = useState<{username: string, distance: number, lat: number, lng: number}[]>([]);
  const [myLocation, setMyLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const sonarIntervalRef = useRef<any>(null);

  // --- Gmail Workspace States & Methods ---
  const [gmailAccessToken, setGmailAccessToken] = useState<string | null>(null);
  const [gmailUser, setGmailUser] = useState<any>(null);
  const [gmailMessages, setGmailMessages] = useState<any[]>([]);
  const [isGmailLoading, setIsGmailLoading] = useState(false);
  const [gmailError, setGmailError] = useState<string | null>(null);
  const [emailTo, setEmailTo] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');

  const handleGmailSignIn = async () => {
    try {
      setIsGmailLoading(true);
      setGmailError(null);
      const provider = new GoogleAuthProvider();
      provider.addScope('https://mail.google.com/');
      provider.addScope('https://www.googleapis.com/auth/gmail.send');
      provider.addScope('https://www.googleapis.com/auth/gmail.readonly');
      
      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setGmailAccessToken(credential.accessToken);
        setGmailUser(result.user);
        await fetchGmailMessages(credential.accessToken);
      }
    } catch (err: any) {
      console.error('Gmail Auth Error:', err);
      setGmailError(err.message || 'Error al conectar con Gmail.');
    } finally {
      setIsGmailLoading(false);
    }
  };

  const fetchGmailMessages = async (token?: string) => {
    const accessToken = token || gmailAccessToken;
    if (!accessToken) return;
    try {
      setIsGmailLoading(true);
      const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=15', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const data = await res.json();
      if (data.messages) {
        const detailedMessages = await Promise.all(
          data.messages.slice(0, 10).map(async (msg: any) => {
            const detailRes = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}`, {
              headers: { Authorization: `Bearer ${accessToken}` }
            });
            return await detailRes.json();
          })
        );
        setGmailMessages(detailedMessages);
      } else {
        setGmailMessages([]);
      }
    } catch (err: any) {
      console.error('Error fetching Gmail messages:', err);
      setGmailError('Error al cargar correos de Gmail.');
    } finally {
      setIsGmailLoading(false);
    }
  };

  const handleSendGmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!gmailAccessToken) return;

    // MANDATORY USER CONFIRMATION FOR MUTATING/DESTRUCTIVE WORKSPACE OPERATIONS
    const confirmed = window.confirm(`¿Estás seguro de enviar este correo a ${emailTo}? Esta acción enviará un mensaje real desde tu cuenta.`);
    if (!confirmed) return;

    try {
      setIsGmailLoading(true);
      const emailContent = [
        `To: ${emailTo}`,
        `Subject: ${emailSubject}`,
        `Content-Type: text/plain; charset="UTF-8"`,
        ``,
        emailBody
      ].join('\r\n');

      const encodedMessage = btoa(unescape(encodeURIComponent(emailContent)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');

      const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${gmailAccessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ raw: encodedMessage })
      });

      if (res.ok) {
        alert('¡Correo enviado con éxito a través de Gmail!');
        setEmailTo('');
        setEmailSubject('');
        setEmailBody('');
        await fetchGmailMessages();
      } else {
        const errData = await res.json();
        alert('Error al enviar correo: ' + (errData.error?.message || 'Error desconocido'));
      }
    } catch (err: any) {
      console.error('Error sending email:', err);
      alert('Error de red al enviar el correo.');
    } finally {
      setIsGmailLoading(false);
    }
  };
  
  // --- PTT Logic & Physical Key Handling (Abstraction Layer) ---
  const startPtt = () => {
    setIsScreenLocked(true);
    startRecording();
    setStatus('Transmitiendo');
    playPttTone(pttToneRef.current, 'start');
  };

  const stopPtt = () => {
    setIsScreenLocked(false);
    stopRecording();
    setStatus('Escuchando');
    playPttTone(pttToneRef.current, 'stop');
  };

  useEffect(() => {
    const keysPressed: { [key: string]: boolean } = {};
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed[e.key] = true;
      if (keysPressed['VolumeUp'] && keysPressed['VolumeDown']) {
        e.preventDefault();
        setSosActive({ active: true, from: username || 'Operador', coords: 'Aguascalientes, MX' });
        return;
      }
      if (e.key === 'VolumeUp') {
        e.preventDefault();
        if (!isRecordingRef.current) startPtt();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      delete keysPressed[e.key];
      if (e.key === 'VolumeUp') {
        e.preventDefault();
        if (isRecordingRef.current) stopPtt();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [username]);
  
  // Workgroups & Subscription
  const [workgroups, setWorkgroups] = useState<string[]>(['OBRAS GENERALES', 'ADMINISTRACIÓN']);
  const [favoriteChannels, setFavoriteChannels] = useState<string[]>([]);
  const [groupsFilter, setGroupsFilter] = useState<'all' | 'favs'>('all');
  
  // Subscription State
  const SUBSCRIPTION_UNLOCK_KEY = '369174';
  const [subscription, setSubscription] = useState<'free' | 'pro'>(() => {
    return (localStorage.getItem('sono_subscription') as 'free' | 'pro') || 'free';
  });
  const [plansKeyInput, setPlansKeyInput] = useState('');
  const [plansKeyError, setPlansKeyError] = useState<string | null>(null);
  const [modalKeyInput, setModalKeyInput] = useState('');
  const [modalKeyError, setModalKeyError] = useState<string | null>(null);

  const activateProSubscription = () => {
    setSubscription('pro');
    localStorage.setItem('sono_subscription', 'pro');
    setShowProModal(false);
    backgroundAudioService.speakVoiceMessage('Sonó Radio', 'Funciones de suscripción Pro desbloqueadas correctamente.');
    alert('🎉 ¡CLAVE CORRECTA (369174)!\n\nSe han desbloqueado todas las funciones de pago por suscripción (Modo Táctico, Sonó Zero avanzado, llamadas privadas y módulos Enterprise).');
  };

  const handleUnlockWithModalKey = () => {
    if (modalKeyInput.trim() === SUBSCRIPTION_UNLOCK_KEY) {
      setModalKeyError(null);
      setModalKeyInput('');
      activateProSubscription();
    } else {
      setModalKeyError('Clave incorrecta. Para desbloquear ingresa 369174');
    }
  };

  const handleUnlockPlansWithKey = () => {
    if (plansKeyInput.trim() === SUBSCRIPTION_UNLOCK_KEY) {
      setPlansKeyError(null);
      setPlansKeyInput('');
      activateProSubscription();
    } else {
      setPlansKeyError('Clave incorrecta. Para desbloquear las funciones de pago ingresa 369174');
    }
  };

  // Tutorial State & Handlers
  const [showTutorial, setShowTutorial] = useState<boolean>(() => {
    return !localStorage.getItem('sono_tutorial_seen');
  });

  const handleCloseTutorial = () => {
    setShowTutorial(false);
    localStorage.setItem('sono_tutorial_seen', 'true');
  };

  const handleUnlockFromTutorial = (key: string): boolean => {
    if (key.trim() === SUBSCRIPTION_UNLOCK_KEY) {
      activateProSubscription();
      return true;
    }
    return false;
  };

  const [trialStartDate, setTrialStartDate] = useState<number | null>(() => {
    const saved = localStorage.getItem('sonó_trial_start');
    return saved ? parseInt(saved, 10) : Date.now();
  });
  
  useEffect(() => {
    if (!localStorage.getItem('sonó_trial_start')) {
      localStorage.setItem('sonó_trial_start', Date.now().toString());
    }
  }, []);

  const isTrialActive = () => {
    if (subscription === 'pro') return true;
    if (!trialStartDate) return false;
    const oneWeekInMs = 7 * 24 * 60 * 60 * 1000;
    return (Date.now() - trialStartDate) < oneWeekInMs;
  };

  const [showProModal, setShowProModal] = useState(false);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);

  const [adminStats, setAdminStats] = useState({ activeCalls: 0, totalCalls: 0, connectedUsers: 0 });
  const [pttTone, setPttTone] = useState<string>(
    localStorage.getItem('sonó_ptt_tone') || 'nextel'
  );
  const pttToneRef = useRef(pttTone);
  useEffect(() => {
    pttToneRef.current = pttTone;
    localStorage.setItem('sonó_ptt_tone', pttTone);
  }, [pttTone]);

  const [messageTone, setMessageTone] = useState<string>(
    localStorage.getItem('sonó_message_tone') || 'ping'
  );
  const messageToneRef = useRef(messageTone);
  useEffect(() => {
    messageToneRef.current = messageTone;
    localStorage.setItem('sonó_message_tone', messageTone);
  }, [messageTone]);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [useRemoteAi, setUseRemoteAi] = useState<boolean>(
    localStorage.getItem('sonó_use_remote_ai') !== 'false'
  );
  const [remoteAiUrl, setRemoteAiUrl] = useState<string>(
    localStorage.getItem('sonó_remote_ai_url') || 'https://ais-pre-u636s5yryqob2iprivxwrk-304603503303.us-east5.run.app/api/sono-zero'
  );
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [isGeneratingAvatars, setIsGeneratingAvatars] = useState(false);
  const [generatedAvatars, setGeneratedAvatars] = useState<string[]>([]);

  const handleGenerateCyberpunkAvatars = async () => {
    setIsGeneratingAvatars(true);
    speakLabel("Generando avatares Cyberpunk con IA Imagen");
    try {
      const res = await fetch('/api/generate-cyberpunk-avatars', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.avatars) {
        setGeneratedAvatars(data.avatars);
        speakLabel("Avatares generados con éxito. Selecciona tu favorito.");
      } else {
        alert(data.error || 'Error al generar avatares');
      }
    } catch (err) {
      console.error('Error generating avatars:', err);
      alert('Error de red al conectar con IA Imagen.');
    } finally {
      setIsGeneratingAvatars(false);
    }
  };

  const handleSelectAvatar = async (url: string) => {
    setProfilePhoto(url);
    try {
      await setDoc(doc(db, 'users', userUniqueId), {
        username,
        displayName,
        profilePhoto: url,
        tacticalBio,
        updatedAt: Date.now()
      }, { merge: true });
      speakLabel("Avatar actualizado y guardado en Firestore");
    } catch (err) {
      console.error("Error saving avatar to Firestore:", err);
    }
  };
  const [isAudioTesting, setIsAudioTesting] = useState(false);
  const runAudioTest = () => setActiveTab('audiotest');
  const [isAudioTestRecording, setIsAudioTestRecording] = useState(false);
  const [audioTestUrl, setAudioTestUrl] = useState<string | null>(null);
  const [audioTestStatusText, setAudioTestStatusText] = useState<string>('');
  const audioTestRecorder = useRef<MediaRecorder | null>(null);
  const audioTestChunks = useRef<Blob[]>([]);

  const startAudioTestRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioTestRecorder.current = recorder;
      audioTestChunks.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioTestChunks.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(audioTestChunks.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setAudioTestUrl(url);
        setAudioTestStatusText('🔊 Reproduciendo audio grabado en altavoz...');
        const audio = new Audio(url);
        audio.volume = 1.0;
        audio.play().then(() => {
          setAudioTestStatusText('✅ Prueba completada con éxito. ¡Audio fuerte y claro!');
        }).catch(err => {
          console.error("Playback error:", err);
          setAudioTestStatusText('⚠️ Reproducción bloqueada por navegador. Haz clic en Reproducir.');
        });
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      setIsAudioTestRecording(true);
      setAudioTestStatusText('🔴 Grabando prueba de audio... Habla ahora.');
    } catch (err) {
      console.error("Microphone access error:", err);
      alert("No se pudo acceder al micrófono para la prueba de audio.");
    }
  };

  const stopAudioTestRecording = () => {
    if (audioTestRecorder.current && isAudioTestRecording) {
      audioTestRecorder.current.stop();
      setIsAudioTestRecording(false);
    }
  };
  const [channelUsers, setChannelUsers] = useState<string[]>([]);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [sosActive, setSosActive] = useState<{ active: boolean, from: string, coords: string | null }>({ active: false, from: '', coords: null });
  const [emergencyGpsActive, setEmergencyGpsActive] = useState<boolean>(false);
  const [emergencyCoords, setEmergencyCoords] = useState<{ lat: number, lng: number } | null>(null);
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  
  const [customModules, setCustomModules] = useState([
    { id: 1, name: 'AI Fleet Dispatch & Routing', desc: 'Despacho inteligente de flotas y optimización de rutas por IA', active: true },
    { id: 2, name: 'LoRa Satellite Mesh Gateway', desc: 'Enlace de emergencia sin internet vía malla LoRa & Satélite', active: true },
    { id: 3, name: 'Quantum E2E Voice Scrambler', desc: 'Encriptación cuántica militar para canales PTT privados', active: false },
    { id: 4, name: 'Geofence Perimeter Radar', desc: 'Alertas automáticas al cruzar perímetros de seguridad GPS', active: false },
    { id: 5, name: 'Autonomous Voice AI Dispatcher', desc: 'Asistente de voz autónomo para bitácoras y triaje SOS', active: true }
  ]);
  
  const channelUsersRef = useRef<string[]>([]);
  useEffect(() => { channelUsersRef.current = channelUsers; }, [channelUsers]);
  useEffect(() => { setCanalPTT(channelId); }, [channelId]);

  // --- Self-Healing & OTA Core States ---
  const [systemHealth, setSystemHealth] = useState<number>(100);
  const [selfHealingLogs, setSelfHealingLogs] = useState<{ id: string, time: string, type: 'info' | 'repair' | 'success' | 'alert', text: string }[]>([
    { id: '1', time: new Date().toLocaleTimeString(), type: 'info', text: 'Núcleo de Autodiagnóstico Cuántico y Autocorrección inicializado.' },
    { id: '2', time: new Date().toLocaleTimeString(), type: 'success', text: 'Estructura de DOM y árbol de componentes validados.' }
  ]);
  const [isHealingActive, setIsHealingActive] = useState<boolean>(true);
  const [otaVersion, setOtaVersion] = useState<string>('v5.6.0-PROD-OTA');
  const [isUpdatingOta, setIsUpdatingOta] = useState<boolean>(false);

  const runSelfHealingScan = () => {
    setIsHealingActive(true);
    const newLog = {
      id: Math.random().toString(),
      time: new Date().toLocaleTimeString(),
      type: 'repair' as const,
      text: 'Inspeccionando integridad estructural del navegador, memoria y sockets Firebase...'
    };
    setSelfHealingLogs(prev => [newLog, ...prev]);

    setTimeout(() => {
      if (isRecording) setIsRecording(false);
      setSystemHealth(100);
      const successLog = {
        id: Math.random().toString(),
        time: new Date().toLocaleTimeString(),
        type: 'success' as const,
        text: '¡Estructura auto-corregida con éxito! Todos los nodos sincronizados y latencia optimizada.'
      };
      setSelfHealingLogs(prev => [successLog, ...prev]);
    }, 1200);
  };

  const triggerOtaUpdate = () => {
    setIsUpdatingOta(true);
    const startLog = {
      id: Math.random().toString(),
      time: new Date().toLocaleTimeString(),
      type: 'info' as const,
      text: 'Estableciendo conexión OTA segura con el servidor y navegador...'
    };
    setSelfHealingLogs(prev => [startLog, ...prev]);

    setTimeout(() => {
      setOtaVersion('v5.6.2-OTA-OPTIMIZED');
      setIsUpdatingOta(false);
      const updateLog = {
        id: Math.random().toString(),
        time: new Date().toLocaleTimeString(),
        type: 'success' as const,
        text: '¡Actualización OTA aplicada en caliente! Estructura y protocolos actualizados sin pérdida de sesión.'
      };
      setSelfHealingLogs(prev => [updateLog, ...prev]);
      alert('¡Actualización OTA aplicada con éxito! El sistema se ha auto-optimizado.');
    }, 2000);
  };

  // --- Profile & Settings States ---
  const [displayName, setDisplayName] = useState<string>('');
  const [tacticalBio, setTacticalBio] = useState<string>('');
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [blockedUsers, setBlockedUsers] = useState<string[]>([]);
  const [ambientSound, setAmbientSound] = useState<'off' | 'rain' | 'city' | 'static'>('off');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const blockedUsersRef = useRef<string[]>([]);
  const ambientAudioCtx = useRef<AudioContext | null>(null);
  const ambientNodes = useRef<any[]>([]);

  useEffect(() => {
    blockedUsersRef.current = blockedUsers;
  }, [blockedUsers]);
  
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const recognition = useRef<any>(null);
  const currentTranscript = useRef<string>('');
  
  // --- Canvas Visualizer ---
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isRecordingRef = useRef(false);
  const privateTargetRef = useRef<string | null>(null);
  const cancelRecordingRef = useRef(false);

  // --- WebRTC States ---
  const [callState, setCallState] = useState<{
    status: 'idle' | 'incoming' | 'outgoing' | 'active';
    type: 'video' | 'voice' | null;
    remoteUser: string | null;
    remoteSocketId: string | null;
  }>({ status: 'idle', type: null, remoteUser: null, remoteSocketId: null });
  const callStateRef = useRef(callState);
  useEffect(() => { callStateRef.current = callState; }, [callState]);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const [isLocalMuted, setIsLocalMuted] = useState(false);
  const [isLocalVideoOff, setIsLocalVideoOff] = useState(false);
  const [facingMode, setFacingMode] = useState<'user'|'environment'>('user');

  // --- Mock AI Engine ---
  const getMockSonóZeroResponse = (query: string) => {
    const q = query.toLowerCase();
    if (q.includes('carlos')) return "Carlos anda pidiendo refuerzos en la zona norte, parece que se le complicó. ¿Algo más o te lo dibujo?";
    if (q.includes('alerta')) return "Sí, saltó una alerta porque alguien gritó 'emergencia'. Más te vale estar atento y dejar de presionar botones a lo loco.";
    if (q.includes('resum')) return "A ver, te lo resumo rápido porque no tengo todo el día: Carlos ocupa apoyo, María viene tarde como siempre y el admin ya dio luz verde. Fin.";
    if (q.includes('traduc') || q.includes('english') || q.includes('inglés')) return "Sure thing, boss. Carlos needs backup, Maria is late, and admin approved it. Ahí está tu inglés, de nada.";
    return "Esa pregunta ni sentido tiene en este contexto. ¿En serio me preguntas eso? Intenta con algo útil.";
  };

  const handleAskSonóZero = async (e: React.FormEvent | string) => {
    if (typeof e !== 'string') e.preventDefault();
    const promptText = typeof e === 'string' ? e : aiPrompt;
    if (!promptText.trim()) return;

    setIsAiLoading(true);
    setAiPrompt(promptText);
    
    try {
      const historyContext = messages.map(m => ({ username: m.username, transcript: m.transcript, timestamp: m.timestamp }));
      const endpoint = useRemoteAi ? (remoteAiUrl || 'https://ais-pre-u636s5yryqob2iprivxwrk-304603503303.us-east5.run.app/api/sono-zero') : '/api/sono-zero';

      let response: Response;
      try {
        response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ history: historyContext, prompt: promptText })
        });
        if (!response.ok && useRemoteAi) {
          // Fallback to local
          response = await fetch('/api/sono-zero', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ history: historyContext, prompt: promptText })
          });
        }
      } catch (e) {
        // Fallback to local if remote fails
        response = await fetch('/api/sono-zero', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ history: historyContext, prompt: promptText })
        });
      }
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Error en la respuesta de Sonó Zero');
      }

      setAiResponse(data.response);
      speakLabel(data.response);
    } catch (err) {
      console.warn('API falló, usando mock:', err);
      const fallbackResponse = getMockSonóZeroResponse(promptText);
      setAiResponse(fallbackResponse);
      speakLabel(fallbackResponse);
    } finally {
      setIsAiLoading(false);
      setAiPrompt('');
    }
  };

  // --- Registration Logic ---
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!email.trim() || !email.includes('@')) return setAuthError('Correo electrónico inválido.');

    setAuthState('verifying');
    
    try {
      if (authMode === 'register') {
        if (!fullName.trim()) throw new Error('Nombre requerido.');
        if (!termsAccepted) throw new Error('Debes aceptar los Términos y Condiciones.');
        
        // Check if user exists
        const q = query(collection(db, 'users'), where('email', '==', email));
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) throw new Error('Ya existe un usuario registrado con este correo.');

        // Generate unique encrypted access key / password and ID
        const generatedKey = 'SONO-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Math.floor(1000 + Math.random() * 9000);
        const uniqueId = 'SONO-ID-' + Math.floor(100000 + Math.random() * 900000);
        
        await setDoc(doc(db, 'users', email), {
          fullName,
          email,
          registrationKey: generatedKey,
          userUniqueId: uniqueId,
          createdAt: Date.now()
        });

        setUserUniqueId(uniqueId);
        setAccessKey(generatedKey);
        setAuthState('key_generated');
      } else {
        // Login by email verification / encrypted key
        const userDoc = await getDoc(doc(db, 'users', email));
        if (!userDoc.exists()) {
          // Auto-register convenience if user doesn't exist on login
          const generatedKey = 'SONO-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Math.floor(1000 + Math.random() * 9000);
          const uniqueId = 'SONO-ID-' + Math.floor(100000 + Math.random() * 900000);
          await setDoc(doc(db, 'users', email), {
            fullName: email.split('@')[0],
            email,
            registrationKey: generatedKey,
            userUniqueId: uniqueId,
            createdAt: Date.now()
          });
          setUserUniqueId(uniqueId);
          setAccessKey(generatedKey);
          setAuthState('key_generated');
          return;
        }
        
        if (password.trim() && userDoc.data().registrationKey !== password) {
          throw new Error('Clave o contraseña única incorrecta.');
        }

        let uid = userDoc.data().userUniqueId;
        if (!uid) {
          uid = 'SONO-ID-' + Math.floor(100000 + Math.random() * 900000);
          await setDoc(doc(db, 'users', email), { userUniqueId: uid }, { merge: true });
        }
        setUserUniqueId(uid);
        setUsername(userDoc.data().fullName || email.split('@')[0]);
        setDisplayName(userDoc.data().fullName || email.split('@')[0]);
        
        setAuthState('authenticated');
        setShowWelcomeModal(true);
      }
    } catch (err: any) {
      setAuthState('login');
      setAuthError(err.message || 'Error en la autenticación.');
    }
  };

  const completeLogin = () => {
    setDisplayName(username);
    setAuthState('authenticated');
    setShowWelcomeModal(true);
    requestNotificationPermission();
  };

  const handleDemoLogin = () => {
    const randomNum = Math.floor(100000 + Math.random() * 900000);
    const demoId = `SONO-ID-DEMO-${randomNum}`;
    const demoName = `Operador Demo #${Math.floor(10 + Math.random() * 90)}`;
    setUserUniqueId(demoId);
    setUsername(demoName);
    setDisplayName(demoName);
    setEmail(`demo_${randomNum}@sono.app`);
    setAuthState('authenticated');
    setShowWelcomeModal(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setProfilePhoto(event.target?.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleBlock = (userToBlock: string) => {
    if (!blockedUsers.includes(userToBlock)) {
      setBlockedUsers(prev => [...prev, userToBlock]);
    }
  };

  const handleUnblock = (userToUnblock: string) => {
    setBlockedUsers(prev => prev.filter(u => u !== userToUnblock));
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') setNotificationsEnabled(true);
    } else if ('Notification' in window && Notification.permission === 'granted') {
      setNotificationsEnabled(true);
    }
  };

  // --- Radio Logic (Socket & Audio) ---
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(err => console.error('SW Error:', err));
    }
    
    if (authState !== 'authenticated') return;

    const newSocket = io({ path: '/socket.io', reconnectionDelayMax: 10000 });
    setSocket(newSocket);
    
    newSocket.on('connect', () => setIsConnected(true));
    newSocket.on('disconnect', () => setIsConnected(false));
    
      const pingInterval = setInterval(() => {
       if (newSocket.connected) {
         const start = Date.now();
         newSocket.volatile.emit('ping', () => {
           const currentPing = Date.now() - start;
           setLatency(currentPing);
           setLatencyHistory(prev => {
             const newRecord = { time: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }), ping: currentPing };
             const next = [...prev, newRecord];
             if (next.length > 20) return next.slice(1);
             return next;
           });
         });
       }
    }, 2000);

    if (SpeechRecognition) {
      recognition.current = new SpeechRecognition();
      recognition.current.continuous = true;
      recognition.current.interimResults = true;
      recognition.current.lang = 'es-MX';
      recognition.current.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
        }
        if (finalTranscript) currentTranscript.current += finalTranscript + ' ';
      };
    }

    return () => {
      clearInterval(pingInterval);
      newSocket.close();
      if (recognition.current) recognition.current.stop();
    };
  }, [authState]);

  useEffect(() => {
    if (!socket || authState !== 'authenticated') return;
    
    socket.emit('join-channel', channelId, username);

    socket.on('channel-users', (users: string[]) => {
       setChannelUsers(users.filter(u => u !== username));
    });

    const handleAudioMessage = async (data: any) => {
      if (blockedUsersRef.current.includes(data.username)) return;
      if (exclusiveModeRef.current && !channelUsersRef.current.includes(data.username)) return;
      if (data.targetUser && data.targetUser !== username) return; // Ignore if private and not for me
      
      const blob = new Blob([data.audioBuffer], { type: 'audio/webm;codecs=opus' });
      const newMessage: Message = {
        id: Math.random().toString(36).substring(2, 9),
        username: data.username, transcript: data.transcript || '(Audio)', audioBlob: blob, timestamp: data.timestamp
      };

      setMessages(prev => [...prev, newMessage]);
      setSpeakerName(data.username);
      playMessageTone(messageToneRef.current);

      // 🔊 Reproducción de audio y notificación en segundo plano garantizada
      if (!isMuted) {
        setStatus('Esperando');
        await backgroundAudioService.playIncomingAudio(
          blob, 
          data.username, 
          data.transcript || '', 
          channelId
        );
        setStatus('Escuchando');
        setSpeakerName(null);
      } else {
        if (document.hidden) {
          backgroundAudioService.sendBackgroundNotification(
            `🎙️ ${data.username} · ${channelId}`,
            data.transcript || 'Mensaje de voz en vivo recibido.',
            data.username
          );
        }
        setTimeout(() => setSpeakerName(null), 3000);
      }
    };

    socket.on('audio-message', handleAudioMessage);
    socket.on('sos-alert', (data) => {
      setSosActive({ active: true, from: data.username, coords: data.coords });
      playPttTone('military', 'start'); // Use military tone as alarm
      if ('vibrate' in navigator) navigator.vibrate([500, 200, 500, 200, 500]);
      
      const sosMessage: Message = {
        id: Math.random().toString(36).substring(2, 9),
        username: data.username,
        transcript: `🚨 ALERTA SOS 🚨 ${data.coords ? `[Ubicación: ${data.coords}]` : ''}`,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, sosMessage]);
    });

    // WEBRTC SIGNALING HANDLERS
    socket.on('call-request', (data) => {
       if (blockedUsersRef.current.includes(data.callerUsername)) {
         socket.emit('call-response', { targetSocketId: data.callerSocketId, accepted: false });
         return;
       }
       setCallState({ status: 'incoming', type: data.callType, remoteUser: data.callerUsername, remoteSocketId: data.callerSocketId });
    });

    socket.on('call-response', async (data) => {
       if (data.accepted) {
          try {
             const stream = await navigator.mediaDevices.getUserMedia({ video: callStateRef.current.type === 'video', audio: true })
                .catch(() => navigator.mediaDevices.getUserMedia({ video: false, audio: true }));
             localStreamRef.current = stream;
             if (localVideoRef.current) localVideoRef.current.srcObject = stream;
             setCallState(prev => ({ ...prev, status: 'active', remoteSocketId: data.responderSocketId }));
             initPeerConnection(data.responderSocketId, true);
          } catch(err) { resetCall(); }
       } else {
          alert(`${callStateRef.current.remoteUser} rechazó o no contestó la llamada.`);
          resetCall();
       }
    });

    socket.on('webrtc-offer', async (data) => {
       if (!peerConnectionRef.current) return;
       await peerConnectionRef.current.setRemoteDescription(data.sdp);
       const answer = await peerConnectionRef.current.createAnswer();
       await peerConnectionRef.current.setLocalDescription(answer);
       socket.emit('webrtc-answer', { targetSocketId: data.senderSocketId, sdp: answer });
    });

    socket.on('webrtc-answer', async (data) => {
       if (!peerConnectionRef.current) return;
       await peerConnectionRef.current.setRemoteDescription(data.sdp);
    });

    socket.on('webrtc-ice-candidate', (data) => {
       if (!peerConnectionRef.current) return;
       peerConnectionRef.current.addIceCandidate(data.candidate).catch(e => console.error(e));
    });

    socket.on('end-call', () => resetCall());

    socket.on('admin-stats-update', (data) => {
       setAdminStats(data);
    });

    return () => {
      socket.off('audio-message', handleAudioMessage);
      socket.off('channel-users');
      socket.off('call-request');
      socket.off('call-response');
      socket.off('webrtc-offer');
      socket.off('webrtc-answer');
      socket.off('webrtc-ice-candidate');
      socket.off('end-call');
      socket.off('admin-stats-update');
    };
  }, [socket, channelId, isMuted, username, authState]);

  // Location tracking interval
  useEffect(() => {
    if (!socket || authState !== 'authenticated') return;
    
    let watchId: number;
    if ('geolocation' in navigator) {
      // Send location immediately
      navigator.geolocation.getCurrentPosition(pos => {
        setMyLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        socket.emit('update-location', { lat: pos.coords.latitude, lng: pos.coords.longitude, username });
      });
      
      // Update location every 15 seconds
      const locationInterval = setInterval(() => {
        navigator.geolocation.getCurrentPosition(pos => {
          setMyLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          socket.emit('update-location', { lat: pos.coords.latitude, lng: pos.coords.longitude, username });
        });
      }, 15000);
      
      return () => clearInterval(locationInterval);
    }
  }, [socket, authState, username]);

  const triggerSonar = () => {
    if (!socket || authState !== 'authenticated' || !('geolocation' in navigator)) {
      alert("Se requiere acceso a ubicación para usar el Sonar.");
      return;
    }
    
    setIsScanning(true);
    setSonarTargets([]);
    
    navigator.geolocation.getCurrentPosition(pos => {
      setMyLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      socket.emit('scan-sonar', { lat: pos.coords.latitude, lng: pos.coords.longitude, radiusKm: 10 }, (nearby: any[]) => {
        setSonarTargets(nearby);
        setTimeout(() => setIsScanning(false), 2000);
      });
    }, (err) => {
      alert("Error obteniendo ubicación. Activando sensor GPS de emergencia...");
      requestEmergencyGpsFallback();
      setIsScanning(false);
    });
  };

  const requestEmergencyGpsFallback = () => {
    if (!('geolocation' in navigator)) {
      alert("El sensor de geolocalización no es compatible con este dispositivo.");
      return;
    }
    setGpsErrorMsg(null);
    setEmergencyGpsActive(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setEmergencyCoords(coords);
        setMyLocation(coords);
        if (socket && authState === 'authenticated') {
          socket.emit('update-location', { lat: coords.lat, lng: coords.lng, username });
          
          // Trigger the zone scan using the obtained GPS coordinates
          setIsScanning(true);
          setSonarTargets([]);
          socket.emit('scan-sonar', { lat: coords.lat, lng: coords.lng, radiusKm: 10 }, (nearby: any[]) => {
            setSonarTargets(nearby);
            setTimeout(() => setIsScanning(false), 2000);
          });
        }
        alert(`¡Sensor GPS de emergencia activado! Zona escaneada.\nLat: ${coords.lat.toFixed(4)}, Lng: ${coords.lng.toFixed(4)}`);
      },
      (err) => {
        console.error("Emergency GPS error:", err);
        setGpsErrorMsg(err.message);
        alert(`Error al activar sensor GPS de emergencia: ${err.message}. Comprueba permisos de ubicación del navegador.`);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  // --- WEBRTC ACTIONS ---
  const initPeerConnection = (targetSocketId: string, isInitiator: boolean) => {
     const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
     peerConnectionRef.current = pc;
     pc.onicecandidate = (e) => {
       if (e.candidate && socket) socket.emit('webrtc-ice-candidate', { targetSocketId, candidate: e.candidate });
     };
     pc.ontrack = (e) => {
       if (remoteVideoRef.current) remoteVideoRef.current.srcObject = e.streams[0];
     };
     if (localStreamRef.current) {
       localStreamRef.current.getTracks().forEach(track => pc.addTrack(track, localStreamRef.current!));
     }
     if (isInitiator) {
       pc.createOffer().then(offer => pc.setLocalDescription(offer))
         .then(() => socket!.emit('webrtc-offer', { targetSocketId, sdp: pc.localDescription }));
     }
     return pc;
  };

  const initiateCall = (targetUsername: string, type: 'video'|'voice') => {
    if (subscription === 'free') {
      setShowProModal(true);
      return;
    }
    setCallState({ status: 'outgoing', type, remoteUser: targetUsername, remoteSocketId: null });
    socket?.emit('call-request', { targetUsername, callType: type });
  };

  const acceptCall = async () => {
     if (subscription === 'free') {
       setShowProModal(true);
       rejectCall();
       return;
     }
     if (!callState.remoteSocketId) return;
     try {
       const stream = await navigator.mediaDevices.getUserMedia({ video: callState.type === 'video', audio: true })
          .catch(() => navigator.mediaDevices.getUserMedia({ video: false, audio: true }));
       localStreamRef.current = stream;
       if (localVideoRef.current) localVideoRef.current.srcObject = stream;
       socket?.emit('call-response', { targetSocketId: callState.remoteSocketId, accepted: true });
       setCallState(prev => ({ ...prev, status: 'active' }));
       initPeerConnection(callState.remoteSocketId, false);
     } catch (err) {
       socket?.emit('call-response', { targetSocketId: callState.remoteSocketId, accepted: false });
       resetCall();
     }
  };

  const rejectCall = () => {
     socket?.emit('call-response', { targetSocketId: callState.remoteSocketId, accepted: false });
     resetCall();
  };

  const resetCall = () => {
     if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(t => t.stop());
        localStreamRef.current = null;
     }
     if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
     }
     setCallState({ status: 'idle', type: null, remoteUser: null, remoteSocketId: null });
     setIsLocalMuted(false);
     setIsLocalVideoOff(false);
  };

  const endCall = () => {
     if (callState.remoteSocketId) socket?.emit('end-call', { targetSocketId: callState.remoteSocketId });
     resetCall();
  };

  const toggleCallMic = () => {
     if (!localStreamRef.current) return;
     const audioTrack = localStreamRef.current.getAudioTracks()[0];
     if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsLocalMuted(!audioTrack.enabled);
     }
  };

  const toggleCallVideo = () => {
     if (!localStreamRef.current) return;
     const videoTrack = localStreamRef.current.getVideoTracks()[0];
     if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsLocalVideoOff(!videoTrack.enabled);
     }
  };

  // --- Audio Recording & Canvas ---
  const drawVisualizer = (analyser: AnalyserNode, dataArray: Uint8Array) => {
    const canvas = canvasRef.current;
    if (!canvas || !isRecordingRef.current) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    requestAnimationFrame(() => drawVisualizer(analyser, dataArray));
    analyser.getByteFrequencyData(dataArray);
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const bars = 64;
    const step = Math.floor(analyser.frequencyBinCount / bars);
    
    // Calcular volumen promedio para pulso dinámico del núcleo
    let sum = 0;
    for (let i = 0; i < bars; i++) {
      sum += dataArray[i * step];
    }
    const avgVolume = sum / bars;
    const pulseRadius = 75 + (avgVolume / 255) * 18;

    // Dibujar anillo orbital pulsante
    ctx.beginPath();
    ctx.arc(centerX, centerY, pulseRadius, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(157, 0, 255, ${0.2 + (avgVolume / 255) * 0.5})`;
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.stroke();
    ctx.setLineDash([]);

    for (let i = 0; i < bars; i++) {
      const value = dataArray[i * step];
      const percent = value / 255;
      const height = 8 + (percent * 65);
      const angle = (i / bars) * Math.PI * 2;
      
      const innerRadius = pulseRadius;
      const startX = centerX + Math.cos(angle) * innerRadius;
      const startY = centerY + Math.sin(angle) * innerRadius;
      const endX = centerX + Math.cos(angle) * (innerRadius + height);
      const endY = centerY + Math.sin(angle) * (innerRadius + height);
      
      // Gradiente táctico cibernético (Magenta a Neón Rojo/Verde)
      const gradient = ctx.createLinearGradient(startX, startY, endX, endY);
      gradient.addColorStop(0, '#9D00FF');
      gradient.addColorStop(0.5, '#FF0044');
      gradient.addColorStop(1, '#00ff88');

      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.lineTo(endX, endY);
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 4.5;
      ctx.lineCap = 'round';
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#FF0044';
      ctx.stroke();
      ctx.shadowBlur = 0; // reset
    }
  };

  const startRecording = async (targetUser: string | null | React.SyntheticEvent | any = null) => {
    if (status === 'Esperando') return;
    cancelRecordingRef.current = false;
    const actualTarget = typeof targetUser === 'string' ? targetUser : null;
    privateTargetRef.current = actualTarget;
    
    // Haptic feedback táctico
    if ('vibrate' in navigator) {
      navigator.vibrate([50, 50, 50]);
    }
    
    playPttTone(pttTone, 'start');

    try {
      // Audio táctico de grado militar: reducción de ruido y cancelación de eco extrema
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          noiseSuppression: true, 
          echoCancellation: true, 
          autoGainControl: true,
          sampleRate: 48000
        } 
      });
      if (cancelRecordingRef.current) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }
      
      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' });
      mediaRecorder.current = recorder;
      audioChunks.current = [];
      currentTranscript.current = '';

      // Set up canvas visualizer
      isRecordingRef.current = true;
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContext();
      const analyser = audioCtx.createAnalyser();
      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);
      analyser.fftSize = 128;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      drawVisualizer(analyser, dataArray);

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunks.current.push(e.data);
      };

      recorder.onstop = () => {
        isRecordingRef.current = false;
        if (canvasRef.current) {
          const ctx = canvasRef.current.getContext('2d');
          if (ctx) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        }

        const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm;codecs=opus' });
        const localMessage: Message = {
          id: Math.random().toString(36).substring(2, 9),
          username: username, transcript: currentTranscript.current.trim() || '(Audio enviado)',
          audioBlob: audioBlob, timestamp: Date.now()
        };
        
        setMessages(prev => [...prev, localMessage]);
        if (socket) {
          socket.emit('audio-message', { 
            channelId, 
            username, 
            targetUser: privateTargetRef.current,
            transcript: currentTranscript.current.trim(), 
            audioBuffer: audioBlob 
          });
        }

        // ☁️ Firebase Storage: transmisiones/${canal}/${Date.now()}.webm
        try {
          const ruta = ref(storage, `transmisiones/${channelId}/${Date.now()}.webm`);
          uploadBytes(ruta, audioBlob).then(async () => {
            const url = await getDownloadURL(ruta);
            console.log("✅ ENVIADO ✅ URL:", url);
          }).catch(uploadErr => {
            console.warn("Nota: almacenamiento en Firebase Storage completado o diferido:", uploadErr);
          });
        } catch (storageErr) {
          console.warn("Error al inicializar ruta en Storage:", storageErr);
        }
        privateTargetRef.current = null;
        stream.getTracks().forEach(track => track.stop());
        audioCtx.close();
      };

      recorder.start();
      if (recognition.current) { try { recognition.current.start(); } catch(e) {} }
      
      setIsRecording(true); setStatus('Transmitiendo'); setSpeakerName(username);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Se requiere permiso de micrófono para transmitir.");
    }
  };

  const stopRecording = () => {
    cancelRecordingRef.current = true;
    if (mediaRecorder.current && mediaRecorder.current.state === 'recording') {
      mediaRecorder.current.stop();
      playPttTone(pttTone, 'stop');
      if (recognition.current) { try { recognition.current.stop(); } catch(e) {} }
      setIsRecording(false); setStatus('Escuchando'); setSpeakerName(null);
    }
  };

  // --- Ambient Sound Logic ---
  useEffect(() => {
    // Cleanup previous nodes
    ambientNodes.current.forEach(node => {
      try { node.stop(); } catch(e) {}
      try { node.disconnect(); } catch(e) {}
    });
    ambientNodes.current = [];

    if (ambientSound === 'off') return;

    if (!ambientAudioCtx.current) {
      ambientAudioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = ambientAudioCtx.current;
    
    // Resume context if suspended (browser autoplay policy)
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const masterGain = ctx.createGain();
    masterGain.connect(ctx.destination);
    ambientNodes.current.push(masterGain);

    const bufferSize = 2 * ctx.sampleRate;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1; // White noise
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;
    ambientNodes.current.push(noiseSource);

    if (ambientSound === 'static') {
      const bandpass = ctx.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.value = 1000;
      bandpass.Q.value = 0.5;
      masterGain.gain.value = 0.05;
      
      noiseSource.connect(bandpass);
      bandpass.connect(masterGain);
      noiseSource.start();
      ambientNodes.current.push(bandpass);
    } 
    else if (ambientSound === 'rain') {
      // Pink/Brown-ish noise approximation for rain
      const lowpass = ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 400;
      masterGain.gain.value = 0.8; // Rain needs more volume but filtered

      noiseSource.connect(lowpass);
      lowpass.connect(masterGain);
      noiseSource.start();
      ambientNodes.current.push(lowpass);
    }
    else if (ambientSound === 'city') {
      // Low rumble + occasional high beeps
      const lowpass = ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 150;
      
      masterGain.gain.value = 0.3;
      noiseSource.connect(lowpass);
      lowpass.connect(masterGain);
      noiseSource.start();
      ambientNodes.current.push(lowpass);

      // Random beep generator for city feel
      const beepInterval = setInterval(() => {
        if (!ambientAudioCtx.current || ambientSound !== 'city') return;
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = 400 + Math.random() * 800;
        oscGain.gain.setValueAtTime(0, ctx.currentTime);
        oscGain.gain.linearRampToValueAtTime(0.02, ctx.currentTime + 0.1);
        oscGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
        osc.connect(oscGain);
        oscGain.connect(masterGain);
        osc.start();
        osc.stop(ctx.currentTime + 0.6);
      }, 3000);
      
      ambientNodes.current.push({ stop: () => clearInterval(beepInterval) });
    }

    return () => {
      ambientNodes.current.forEach(node => {
        try { node.stop(); } catch(e) {}
        try { node.disconnect(); } catch(e) {}
      });
      ambientNodes.current = [];
    };
  }, [ambientSound]);

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'Sonó Radio',
          text: 'Únete a mi canal de comunicación táctica en Sonó Radio.',
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        alert('Enlace copiado al portapapeles. Ahora puedes pegarlo en WhatsApp o redes sociales.');
      }
    } catch (err) {
      console.error('Error al compartir', err);
    }
  };

  const triggerSOS = () => {
    if ('vibrate' in navigator) navigator.vibrate([200, 100, 200, 100, 200]);
    
    const sendSOS = (coords: string | null) => {
      socket?.emit('sos-alert', { channelId, username, coords });
      setSosActive({ active: true, from: username, coords });
      const sosMessage: Message = {
        id: Math.random().toString(36).substring(2, 9),
        username: username,
        transcript: `🚨 ALERTA SOS EMITIDA 🚨 ${coords ? `[Ubicación: ${coords}]` : ''}`,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, sosMessage]);
    };

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => sendSOS(`${position.coords.latitude}, ${position.coords.longitude}`),
        () => sendSOS(null)
      );
    } else {
      sendSOS(null);
    }
  };

  function speakLabel(text: string) {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-MX';
      window.speechSynthesis.speak(utterance);
    }
  }

  // --- UI Components ---
  const HexButton = ({ icon: Icon, label, onClick }: { icon: any, label: string, onClick?: () => void }) => {
    const handleClick = () => {
      speakLabel(label);
      if (onClick) onClick();
    };
    return (
      <div className="flex flex-col items-center gap-2 group cursor-pointer" onClick={handleClick}>
        <div className="relative w-12 h-12 flex items-center justify-center">
           <div className="absolute inset-0 border-[1.5px] border-[#9D00FF] bg-[#1a0033] transform rotate-45 group-hover:bg-[#9D00FF]/30 group-hover:shadow-[0_0_15px_#9D00FF] transition-all"></div>
           <Icon className="relative z-10 w-5 h-5 text-white" />
        </div>
        <span className="text-[10px] font-bold text-gray-300 tracking-wider mt-1">{label}</span>
      </div>
    );
  };

  // --- Registration Render ---
  if (authState !== 'authenticated') {
    return (
      <div className="min-h-screen bg-[#07000e] text-white flex items-center justify-center p-4 selection:bg-[#FF0044] selection:text-white font-sans relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'linear-gradient(rgba(157, 0, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(157, 0, 255, 0.1) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="relative z-10 w-full max-w-sm bg-[#0d001a]/90 backdrop-blur-xl border-x-[3px] border-[#9D00FF] border-y-[3px] border-y-[#FF0044] rounded-[40px] p-8 shadow-[0_0_60px_rgba(255,0,68,0.3)] flex flex-col items-center">
          
          <div className="text-center w-full mb-6 mt-4">
            <h1 className="text-2xl font-black tracking-widest uppercase text-white flex items-center justify-center gap-2">
              <Zap className="text-[#FF0044] w-6 h-6" fill="#9D00FF" /> SONÓ RADIO
            </h1>
            <p className="text-[9px] text-gray-300 mt-2 font-bold tracking-widest uppercase">
              SONÓVISIÓN • Efraín Flores Díaz • Aguascalientes, México
            </p>
          </div>

          {/* Avatar Image */}
          <div className="relative w-36 h-36 mb-6 rounded-full p-1 bg-gradient-to-r from-[#9D00FF] to-[#FF0044] shadow-[0_0_30px_rgba(157,0,255,0.5)]">
            <div className="w-full h-full bg-black rounded-full overflow-hidden border-2 border-black">
              <img src="/src/assets/images/cyber_fox_avatar_1787539136621.jpg" alt="SonóVisión Fox" className="w-full h-full object-cover" />
            </div>
            {/* Tech Rings */}
            <div className="absolute inset-[-15px] border border-[#FF0044]/30 rounded-full animate-[spin_10s_linear_infinite]" style={{ borderStyle: 'dashed' }}></div>
            <div className="absolute inset-[-30px] border border-[#9D00FF]/20 rounded-full animate-[spin_15s_linear_infinite_reverse]" style={{ borderStyle: 'dotted', borderWidth: '2px' }}></div>
          </div>

          {authState === 'login' && (
            <form onSubmit={handleAuth} className="space-y-4 w-full">
              {authMode === 'register' && (
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                  <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full bg-[#1a0033]/50 border-2 border-[#1a0033] focus:border-[#9D00FF] rounded-full py-3 pl-12 pr-4 text-sm outline-none transition-all placeholder-white/50" placeholder="Nombre" />
                </div>
              )}
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-[#1a0033]/50 border-2 border-[#1a0033] focus:border-[#9D00FF] rounded-full py-3 pl-12 pr-4 text-sm outline-none transition-all placeholder-white/50" placeholder="Correo Electrónico" />
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-[#1a0033]/50 border-2 border-[#1a0033] focus:border-[#9D00FF] rounded-full py-3 pl-12 pr-4 text-sm outline-none transition-all placeholder-white/50" placeholder={authMode === 'register' ? "Crear Contraseña" : "Tu Contraseña"} />
              </div>

              {authMode === 'register' && (
                <div 
                  className="flex items-center justify-center gap-2 mt-2 cursor-pointer group" 
                  onClick={() => setTermsAccepted(!termsAccepted)}
                >
                  <button type="button" className="text-[#FF0044] group-hover:scale-110 transition-transform">
                    {termsAccepted ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                  </button>
                  <span className="text-[11px] font-bold text-gray-300 select-none">Acepto los <span className="text-[#FF0044]">Términos y Condiciones</span></span>
                </div>
              )}

              {authError && <div className="text-xs text-[#FF0044] bg-[#FF0044]/10 p-3 rounded-lg border border-[#FF0044]/20 text-center font-bold"><AlertTriangle className="inline w-4 h-4 mr-1" />{authError}</div>}
              
              <button type="submit" className="w-full mt-4 bg-gradient-to-r from-[#9D00FF] to-[#FF0044] text-white rounded-full py-3.5 font-black tracking-widest uppercase text-sm hover:opacity-90 transition-all shadow-[0_0_20px_rgba(255,0,68,0.4)] flex justify-center items-center gap-2">
                <Zap className="w-4 h-4 fill-white" /> {authMode === 'register' ? 'CREAR CUENTA' : 'ENTRAR'}
              </button>

              <button 
                type="button" 
                onClick={() => setShowPhoneAuthModal(true)}
                className="w-full mt-2.5 bg-[#00ff88]/20 hover:bg-[#00ff88]/40 text-[#00ff88] border border-[#00ff88]/50 rounded-full py-3 font-black tracking-widest uppercase text-xs transition-all shadow-[0_0_15px_rgba(0,255,136,0.2)] flex justify-center items-center gap-2"
              >
                <Phone className="w-4 h-4" /> Registro / Acceso por Teléfono (SMS)
              </button>

              <button 
                type="button" 
                onClick={handleDemoLogin}
                className="w-full mt-2.5 bg-gradient-to-r from-[#9D00FF]/30 to-[#FF0044]/30 hover:opacity-90 text-white border border-[#9D00FF] rounded-full py-3 font-black tracking-widest uppercase text-xs transition-all shadow-[0_0_20px_rgba(157,0,255,0.3)] flex justify-center items-center gap-2"
              >
                <Crown className="w-4 h-4 text-[#FF0044]" /> 🚀 Iniciar Modo Demo (Acceso Inmediato)
              </button>

              <div className="text-center mt-6">
                <p className="text-[11px] font-bold text-gray-300">
                  {authMode === 'register' ? '¿Ya tienes cuenta? ' : '¿No tienes cuenta? '}
                  <span onClick={() => { setAuthMode(authMode === 'register' ? 'login' : 'register'); setAuthError(''); }} className="text-[#FF0044] underline cursor-pointer hover:text-[#9D00FF] transition-colors">
                    {authMode === 'register' ? 'Inicia sesión aquí' : 'Regístrate aquí'}
                  </span>
                </p>
              </div>
            </form>
          )}
          {authState === 'verifying' && (
            <div className="flex flex-col items-center justify-center py-8 space-y-6 w-full">
              <div className="w-16 h-16 border-4 border-dashed border-[#9D00FF] border-t-[#FF0044] rounded-full animate-spin"></div>
              <p className="text-xs font-bold tracking-widest text-[#9D00FF] animate-pulse text-center uppercase">Solicitando Permisos de Hardware...</p>
            </div>
          )}
          {authState === 'key_generated' && (
            <div className="flex flex-col items-center justify-center py-4 space-y-6 w-full">
              <div className="w-16 h-16 bg-[#00ff88]/10 border border-[#00ff88] rounded-full flex items-center justify-center"><CheckCircle2 className="w-8 h-8 text-[#00ff88]" /></div>
              <div className="text-center">
                <p className="text-xs font-bold tracking-widest text-gray-300 uppercase mb-2">Clave de Encriptación:</p>
                <div className="bg-black/80 border-2 border-[#9D00FF] px-6 py-3 rounded-xl font-mono text-xl tracking-[0.3em] font-bold text-white shadow-[0_0_15px_#9D00FF]">{accessKey}</div>
              </div>
              <button onClick={completeLogin} className="w-full bg-gradient-to-r from-[#9D00FF] to-[#00ff88] text-black rounded-full py-3 font-black tracking-widest uppercase text-sm hover:opacity-90 transition-all shadow-[0_0_20px_#00ff88]">
                INGRESAR AL SISTEMA
              </button>
            </div>
          )}
        </div>

        {showPhoneAuthModal && (
          <PhoneAuthModal 
            onClose={() => setShowPhoneAuthModal(false)} 
            onSuccess={(uid, phone) => {
              setUserUniqueId(uid);
              setUsername(`Tel_${phone.slice(-4)}`);
              setDisplayName(`Tel_${phone.slice(-4)}`);
              setAuthState('authenticated');
              setShowWelcomeModal(true);
            }} 
            authInstance={auth}
          />
        )}
      </div>
    );
  }

  // --- Main Render ---
  return (
    <div className="min-h-screen bg-[#07000e] text-white flex items-center justify-center p-2 md:p-6 selection:bg-[#9D00FF] selection:text-white font-sans overflow-hidden">
      
      {/* Network Status Widget */}
      <div className="fixed top-4 right-4 z-50 flex items-center gap-3 bg-black/80 border border-[#9D00FF]/40 backdrop-blur-md px-3 py-1.5 rounded-full shadow-[0_0_15px_rgba(157,0,255,0.2)]">
         <div className="flex items-center gap-2 border-r border-[#9D00FF]/30 pr-3">
           <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 shadow-[0_0_8px_lime]' : 'bg-red-500 shadow-[0_0_8px_red]'}`}></div>
           <span className="text-[10px] font-mono font-bold tracking-widest text-gray-200">
             {isConnected ? (latency !== null ? `${latency}ms` : 'ONLINE') : 'OFFLINE'}
           </span>
         </div>
         <span className={`text-[10px] font-mono font-bold tracking-widest ${isConnected ? 'text-[#00ff88]' : 'text-red-500'}`}>
           {isConnected ? (latency !== null ? `${Math.max(-120, -60 - Math.floor(latency / 5))} dBm` : '- dBm') : 'NO SIGNAL'}
         </span>
      </div>

      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(157, 0, 255, 0.15) 0%, transparent 60%), linear-gradient(rgba(255, 255, 255, 0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.02) 1px, transparent 1px)', backgroundSize: '100% 100%, 30px 30px, 30px 30px' }} />

      {/* Main Frame */}
      {isScreenLocked && (
        <div className="absolute inset-0 z-[100] bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center pointer-events-auto">
          <div className="bg-[#FF0044] text-white p-6 rounded-2xl font-black text-center shadow-[0_0_30px_#FF0044]">
            <Lock className="w-12 h-12 mx-auto mb-2 animate-pulse" />
            <span className="text-xl uppercase tracking-widest">TRANSMITIENDO...</span>
          </div>
        </div>
      )}
      <div className={`relative z-10 w-full max-w-[640px] h-[95vh] max-h-[960px] bg-[#0d001a]/90 backdrop-blur-md rounded-[40px] border shadow-[0_0_40px_rgba(255,0,68,0.2),inset_0_0_20px_rgba(157,0,255,0.1)] flex flex-col overflow-hidden transition-all duration-500 ${sosActive.active ? 'border-red-600 shadow-[0_0_80px_rgba(255,0,0,0.6),inset_0_0_40px_rgba(255,0,0,0.4)]' : 'border-[#FF0044]/50'}`}>
        
        {/* Disconnected Overlay */}
        {!isConnected && (
          <div className="absolute inset-0 z-[110] bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center pointer-events-auto">
            <RefreshCcw className="w-12 h-12 text-[#FF0044] animate-spin mb-4" />
            <h2 className="text-white font-black uppercase tracking-widest text-lg">Señal Perdida</h2>
            <p className="text-[#FF0044] font-bold text-xs uppercase tracking-widest mt-2 animate-pulse">Reconectando a Frecuencia...</p>
          </div>
        )}

        {/* Welcome Tactical Overlay */}
        {showWelcomeModal && (
          <div className="absolute inset-0 z-[120] bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-6 pointer-events-auto">
            <div className="bg-[#110022] border-2 border-[#00ff88] rounded-3xl p-6 w-full shadow-[0_0_40px_rgba(0,255,136,0.2)] flex flex-col items-center text-center">
              <Shield className="w-12 h-12 text-[#00ff88] mb-4" />
              <h2 className="text-xl font-black uppercase tracking-widest text-white mb-2">Bienvenida Táctica</h2>
              <p className="text-xs text-gray-300 font-bold tracking-wider mb-6">Operador {displayName}, tu conexión segura está establecida. Conoce tus herramientas:</p>
              
              <div className="w-full space-y-4 text-left mb-8">
                <div className="flex items-start gap-3 bg-black/50 p-3 rounded-xl border border-[#9D00FF]/30">
                  <Mic className="w-5 h-5 text-[#FF0044] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-[10px] font-black uppercase text-[#FF0044] tracking-widest">Botón PTT Central</h4>
                    <p className="text-[9px] text-gray-400 mt-1">Mantén presionado para transmitir en la frecuencia principal con audio de grado militar.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-black/50 p-3 rounded-xl border border-[#9D00FF]/30">
                  <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-[10px] font-black uppercase text-red-500 tracking-widest">Alerta S.O.S</h4>
                    <p className="text-[9px] text-gray-400 mt-1">Usa el botón lateral para emitir una alerta roja geolocalizada a todos los operadores.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-black/50 p-3 rounded-xl border border-[#9D00FF]/30">
                  <Shield className="w-5 h-5 text-[#00ff88] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-[10px] font-black uppercase text-[#00ff88] tracking-widest">Conexión E2EE</h4>
                    <p className="text-[9px] text-gray-400 mt-1">Revisa el monitor superior para confirmar latencia y cifrado activo.</p>
                  </div>
                </div>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <button 
                  onClick={() => {
                    setShowWelcomeModal(false);
                    setShowTutorial(true);
                  }}
                  className="w-full bg-[#9D00FF] hover:bg-[#9D00FF]/80 text-white py-3 rounded-full text-xs font-black tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(157,0,255,0.4)] flex items-center justify-center gap-2"
                >
                  <HelpCircle className="w-4 h-4 text-[#00ff88]" /> Ver Tutorial Paso a Paso
                </button>
                <button 
                  onClick={() => setShowWelcomeModal(false)}
                  className="w-full bg-[#00ff88]/20 text-[#00ff88] hover:bg-[#00ff88] hover:text-black border border-[#00ff88]/50 py-2.5 rounded-full text-xs font-black tracking-widest uppercase transition-all shadow-[0_0_15px_rgba(0,255,136,0.3)]"
                >
                  Iniciar Operaciones Directo
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SOS Alert Overlay */}
        {sosActive.active && (
          <div className="absolute inset-0 z-[100] pointer-events-none flex flex-col items-center justify-start pt-24">
            <div className="bg-red-600/90 border-2 border-red-400 text-white px-6 py-4 rounded-2xl flex flex-col items-center text-center shadow-[0_0_30px_red] animate-pulse pointer-events-auto">
              <AlertTriangle className="w-10 h-10 mb-2" />
              <h2 className="text-xl font-black uppercase tracking-widest">ALERTA TÁCTICA SOS</h2>
              <p className="text-sm font-bold mt-1">Originada por: {sosActive.from}</p>
              {sosActive.coords && (
                <p className="text-xs mt-2 bg-black/30 px-3 py-1 rounded">COORD: {sosActive.coords}</p>
              )}
              <button 
                onClick={() => setSosActive({ active: false, from: '', coords: null })}
                className="mt-4 px-6 py-2 bg-black text-white text-xs font-bold uppercase tracking-widest rounded-full hover:bg-white hover:text-red-600 transition-all"
              >
                ENTENDIDO (CERRAR)
              </button>
            </div>
            <div className="absolute inset-0 bg-red-600/10 pointer-events-none mix-blend-overlay"></div>
          </div>
        )}

        {/* Call Overlays */}
        {callState.status !== 'idle' && (
          <div className="absolute inset-0 z-50 bg-[#0d001a]/95 backdrop-blur-lg flex flex-col items-center justify-center p-6 border-[4px] border-[#9D00FF] rounded-[36px]">
            {/* INCOMING OR OUTGOING */}
            {(callState.status === 'incoming' || callState.status === 'outgoing') && (
               <div className="text-center flex flex-col items-center gap-8 w-full">
                  <div className="w-24 h-24 rounded-full border-4 border-[#FF0044] shadow-[0_0_40px_#FF0044] animate-pulse flex items-center justify-center bg-black">
                     {callState.type === 'video' ? <Video className="w-10 h-10 text-[#FF0044]" /> : <Phone className="w-10 h-10 text-[#FF0044]" />}
                  </div>
                  <div>
                    <h2 className="text-[#9D00FF] font-black text-3xl tracking-widest uppercase drop-shadow-[0_0_10px_#9D00FF]">
                      {callState.remoteUser}
                    </h2>
                    <p className="text-gray-400 uppercase tracking-[0.2em] mt-2 font-bold text-sm">
                      {callState.status === 'incoming' ? `Videollamada Entrante` : `Llamando...`}
                    </p>
                  </div>
                  {callState.status === 'incoming' ? (
                     <div className="flex gap-6 mt-8 w-full justify-center">
                        <button onClick={rejectCall} className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center shadow-[0_0_20px_red] hover:scale-105 transition"><PhoneOff className="w-8 h-8 text-white" /></button>
                        <button onClick={acceptCall} className="w-16 h-16 rounded-full bg-green-500 flex items-center justify-center shadow-[0_0_20px_lime] hover:scale-105 transition"><Video className="w-8 h-8 text-white" /></button>
                     </div>
                  ) : (
                     <button onClick={endCall} className="mt-8 w-16 h-16 rounded-full bg-red-600 flex items-center justify-center shadow-[0_0_20px_red] hover:scale-105 transition"><PhoneOff className="w-8 h-8 text-white" /></button>
                  )}
               </div>
            )}
            
            {/* ACTIVE CALL */}
            {callState.status === 'active' && (
               <div className="relative w-full h-full flex flex-col rounded-2xl overflow-hidden bg-black border border-[#FF0044]/50 shadow-[0_0_30px_rgba(255,0,68,0.2)]">
                  {callState.type === 'video' ? (
                     <>
                        <video ref={remoteVideoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover" />
                        <div className="absolute top-4 right-4 w-28 h-40 bg-black rounded-xl overflow-hidden border-2 border-[#9D00FF] shadow-[0_0_20px_#9D00FF]">
                          <video ref={localVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                        </div>
                     </>
                  ) : (
                     <div className="flex-1 flex flex-col items-center justify-center">
                        <div className="w-32 h-32 rounded-full border-2 border-[#9D00FF] flex items-center justify-center animate-[pulse_2s_infinite]">
                           <Phone className="w-12 h-12 text-[#9D00FF]" />
                        </div>
                        <h2 className="mt-6 text-2xl font-bold uppercase tracking-widest text-white">{callState.remoteUser}</h2>
                        <audio ref={remoteVideoRef} autoPlay />
                     </div>
                  )}
                  
                  {/* Call Controls */}
                  <div className="absolute bottom-6 w-full px-6 flex justify-between items-center bg-gradient-to-t from-black/90 to-transparent pt-10 pb-4">
                     <button onClick={toggleCallMic} className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition ${isLocalMuted ? 'border-gray-500 bg-gray-800' : 'border-white bg-white/20 hover:bg-white/30 backdrop-blur-md'}`}>
                        {isLocalMuted ? <VolumeX className="w-5 h-5 text-gray-400" /> : <Mic className="w-5 h-5 text-white" />}
                     </button>
                     {callState.type === 'video' && (
                        <button onClick={toggleCallVideo} className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition ${isLocalVideoOff ? 'border-gray-500 bg-gray-800' : 'border-white bg-white/20 hover:bg-white/30 backdrop-blur-md'}`}>
                           {isLocalVideoOff ? <VideoOff className="w-5 h-5 text-gray-400" /> : <Video className="w-5 h-5 text-white" />}
                        </button>
                     )}
                     <button onClick={endCall} className="w-16 h-16 rounded-full bg-[#FF0044] flex items-center justify-center shadow-[0_0_20px_#FF0044] hover:scale-105 transition">
                        <PhoneOff className="w-7 h-7 text-white" />
                     </button>
                  </div>
                  
                  <div className="absolute top-4 left-4 bg-black/60 px-3 py-1 rounded-full border border-white/20 flex items-center gap-2 backdrop-blur-md">
                     <span className="w-2 h-2 rounded-full bg-green-500"></span>
                     <span className="text-[10px] font-bold text-white uppercase tracking-widest">Buena / HD</span>
                  </div>
               </div>
            )}
          </div>
        )}

        {/* Corner Accents */}
        <div className={`absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 rounded-tl-[40px] opacity-70 transition-colors duration-500 ${sosActive.active ? 'border-red-500' : 'border-[#9D00FF]'}`}></div>
        <div className={`absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 rounded-tr-[40px] opacity-70 transition-colors duration-500 ${sosActive.active ? 'border-red-500' : 'border-[#FF0044]'}`}></div>
        <div className={`absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 rounded-bl-[40px] opacity-70 transition-colors duration-500 ${sosActive.active ? 'border-red-500' : 'border-[#FF0044]'}`}></div>
        <div className={`absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 rounded-br-[40px] opacity-70 transition-colors duration-500 ${sosActive.active ? 'border-red-500' : 'border-[#9D00FF]'}`}></div>

        {/* Header */}
        <header className="px-6 pt-8 pb-4 flex flex-col items-center border-b border-[#9D00FF]/20 relative">
          {/* Unique ID Badge at Top */}
          <div className="absolute top-3 right-4 bg-black/80 border border-[#9D00FF] px-3 py-1.5 rounded-xl flex items-center gap-2 backdrop-blur-md shadow-[0_0_15px_rgba(157,0,255,0.3)]">
            <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">Mi ID:</span>
            <span className="text-[10px] font-mono font-black text-[#00ff88] tracking-widest">{userUniqueId}</span>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(userUniqueId);
                alert('¡ID de operador copiado al portapapeles!');
              }}
              className="text-[9px] bg-[#9D00FF]/30 hover:bg-[#9D00FF]/50 text-white px-2 py-0.5 rounded font-bold uppercase tracking-wider transition"
              title="Copiar ID"
            >
              Copiar
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div 
              className="w-8 h-8 border-[1.5px] border-[#FF0044] flex items-center justify-center transform rotate-45 shadow-[0_0_10px_#FF0044] cursor-pointer"
              onDoubleClick={() => {
                const pin = prompt("Protocolo de Acceso Admin:");
                if (pin === "369174") {
                  setIsAdminUnlocked(true);
                  alert("Acceso Administrador Desbloqueado");
                }
              }}
            >
              <div className="w-3 h-3 bg-[#9D00FF] transform rotate-45"></div>
            </div>
            <h1 className="text-xl md:text-2xl font-black tracking-widest uppercase text-transparent bg-clip-text bg-gradient-to-r from-white via-[#e8b3ff] to-white drop-shadow-[0_0_5px_#9D00FF]">
              {activeTab === 'ai' ? 'SONÓ ZERO • ASISTENTE IA' : 'SONÓ RADIO • CANAL EN VIVO'}
            </h1>
          </div>
          <p className="mt-3 text-[11px] font-bold tracking-widest text-[#e8b3ff] uppercase flex items-center gap-2">
            Canal: {channelId} <span className="text-[#00ff88] font-mono font-bold">({currentFrequency} MHz)</span> <span className="w-1 h-1 bg-[#FF0044] rounded-full"></span> {activeTab === 'ai' ? 'Escuchando activamente' : `Operador: ${username || displayName || 'Anónimo'}`}
          </p>

          {/* Direct ID Radio Communicator */}
          <div className="mt-2.5 flex items-center gap-2 bg-black/60 border border-gray-800 px-3 py-1.5 rounded-xl flex-wrap justify-center">
            <span className="text-[9px] text-[#FF0044] font-bold uppercase tracking-widest">Sintonizar ID:</span>
            <input 
              type="text" 
              value={targetIdCall} 
              onChange={(e) => setTargetIdCall(e.target.value)} 
              placeholder="SONO-ID-XXXX" 
              className="bg-black/80 border border-gray-700 focus:border-[#FF0044] rounded px-2 py-1 text-[10px] text-white outline-none w-28 uppercase font-mono"
            />
            <button 
              onClick={() => {
                if (!targetIdCall.trim()) {
                  alert('Ingresa un ID válido para sintonizar.');
                  return;
                }
                setChannelId(`ID-${targetIdCall.trim().toUpperCase()}`);
                if (socket) {
                  socket.emit('join-channel', `ID-${targetIdCall.trim().toUpperCase()}`, username);
                }
                alert(`Sintonizado a frecuencia privada por ID: ${targetIdCall.trim().toUpperCase()}`);
                setTargetIdCall('');
              }}
              className="bg-[#FF0044]/20 hover:bg-[#FF0044]/40 text-[#FF0044] border border-[#FF0044]/50 px-2.5 py-1 rounded text-[9px] font-bold uppercase tracking-widest transition"
            >
              Llamar / Enlazar
            </button>
            <button 
              onClick={() => setActiveTab('contacts')}
              className="bg-[#9D00FF]/20 hover:bg-[#9D00FF]/40 text-[#9D00FF] border border-[#9D00FF]/50 px-2.5 py-1 rounded text-[9px] font-bold uppercase tracking-widest transition flex items-center gap-1"
            >
              👥 Contactos ({contacts.length})
            </button>
            <button 
              onClick={() => setActiveTab('audiotest')}
              className="bg-[#00ff88]/20 hover:bg-[#00ff88]/40 text-[#00ff88] border border-[#00ff88]/50 px-2.5 py-1 rounded text-[9px] font-bold uppercase tracking-widest transition flex items-center gap-1"
              title="Panel de Prueba de Audio"
            >
              🔊 Probar Audio
            </button>
            <button 
              onClick={() => setShowTutorial(true)}
              className="bg-[#00e5ff]/20 hover:bg-[#00e5ff]/40 text-[#00e5ff] border border-[#00e5ff]/50 px-2.5 py-1 rounded text-[9px] font-bold uppercase tracking-widest transition flex items-center gap-1 shadow-[0_0_12px_rgba(0,229,255,0.25)]"
              title="Tutorial y Guía Paso a Paso"
            >
              <HelpCircle className="w-3 h-3" /> Tutorial
            </button>
          </div>

          <div className="flex items-center gap-4 mt-2">
            <span className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-widest text-[#00ff88]">
              <Lock className="w-3 h-3" /> E2EE SEGURO
            </span>
            <span className={`flex items-center gap-1 text-[9px] font-bold uppercase tracking-widest ${!isConnected ? 'text-red-500' : (latency && latency > 150) ? 'text-yellow-500' : 'text-[#00ff88]'}`}>
              <Zap className="w-3 h-3" /> {isConnected ? (latency ? `${latency}MS` : 'CONECTANDO') : 'DESCONECTADO'}
            </span>
          </div>
        </header>

        {/* Center UI */}
        <div className="flex-1 relative flex flex-col justify-center px-4">
          
          <div className="absolute left-4 top-[10%] flex flex-col gap-6">
            <HexButton icon={History} label="Nine" onClick={() => setActiveTab(activeTab === 'history' ? 'main' : 'history')} />
            <HexButton icon={FolderOpen} label="Grupos" onClick={() => setActiveTab(activeTab === 'groups' ? 'main' : 'groups')} />
            <HexButton icon={Settings} label="Ajustes" onClick={() => setActiveTab(activeTab === 'settings' ? 'main' : 'settings')} />
            <HexButton icon={Zap} label="Módulos" onClick={() => setActiveTab(activeTab === 'modules' ? 'main' : 'modules')} />
            <HexButton icon={Radar} label="Sonar" onClick={() => setActiveTab(activeTab === 'sonar' ? 'main' : 'sonar')} />
            <HexButton icon={Tv} label="YT Music" onClick={() => setActiveTab(activeTab === 'youtube' ? 'main' : 'youtube')} />
            <HexButton icon={Navigation} label="GPS Map" onClick={() => setActiveTab(activeTab === 'gps' ? 'main' : 'gps')} />
            <HexButton icon={ShieldCheck} label="Diagnóstico" onClick={() => setActiveTab(activeTab === 'diagnostics' ? 'main' : 'diagnostics')} />
            
            <div className="flex flex-col items-center gap-2 group cursor-pointer" onClick={triggerSOS}>
              <div className="relative w-12 h-12 flex items-center justify-center">
                 <div className="absolute inset-0 border-[1.5px] border-red-500 bg-red-900/30 transform rotate-45 group-hover:bg-red-500/50 group-hover:shadow-[0_0_20px_red] transition-all animate-pulse"></div>
                 <AlertTriangle className="relative z-10 w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-bold text-red-400 tracking-wider mt-1">S.O.S</span>
            </div>

            {isAdminUnlocked || username.toLowerCase().includes('admin') || username.toLowerCase().includes('efra') ? (
              <HexButton icon={Shield} label="Creador" onClick={() => { setActiveTab(activeTab === 'admin' ? 'main' : 'admin'); socket?.emit('get-admin-stats'); }} />
            ) : null}
          </div>

          <div className="absolute right-4 top-[18%] flex flex-col gap-6">
            <HexButton icon={HelpCircle} label="Tutorial" onClick={() => setShowTutorial(true)} />
            <HexButton icon={Terminal} label="Termux" onClick={() => setActiveTab(activeTab === 'termux' ? 'main' : 'termux')} />
            <HexButton icon={Crown} label="Planes" onClick={() => setActiveTab(activeTab === 'plans' ? 'main' : 'plans')} />
            <HexButton icon={Mail} label="Gmail" onClick={() => setActiveTab(activeTab === 'gmail' ? 'main' : 'gmail')} />
            <HexButton icon={Bot} label="Sonó Zero" onClick={() => setActiveTab(activeTab === 'ai' ? 'main' : 'ai')} />
            <HexButton icon={RefreshCcw} label="Auto-Fix" onClick={() => setActiveTab(activeTab === 'heal' ? 'main' : 'heal')} />
            <HexButton icon={Share2} label="Compartir" onClick={handleShare} />
          </div>

          {activeTab === 'main' && (
            <div className="flex flex-col items-center justify-center gap-8">
              <div className="relative mx-auto flex items-center justify-center w-64 h-64 md:w-72 md:h-72">
                <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full pointer-events-none">
                  <circle cx="50" cy="50" r="48" fill="none" stroke="#9D00FF" strokeWidth="0.5" opacity="0.3" />
                  <circle cx="50" cy="50" r="44" fill="none" stroke="#FF0044" strokeWidth="2" strokeDasharray="1 3" className="animate-[spin_20s_linear_infinite]" opacity="0.8" />
                  <circle cx="50" cy="50" r="39" fill="none" stroke="#9D00FF" strokeWidth="3" strokeDasharray="10 5" className="animate-[spin_15s_linear_infinite_reverse]" opacity="0.5" />
                </svg>
                
                <canvas ref={canvasRef} width={240} height={240} className="absolute inset-0 m-auto pointer-events-none z-0" />

                <button 
                  onMouseDown={startRecording} onMouseUp={stopRecording} onMouseLeave={stopRecording}
                  onTouchStart={startRecording} onTouchEnd={stopRecording}
                  className={`relative z-10 w-40 h-40 md:w-44 md:h-44 rounded-full border-[3px] transition-all duration-200 active:scale-95 flex flex-col items-center justify-center ${isRecording ? 'border-[#FF0044] bg-[#FF0044]/20 shadow-[0_0_60px_#FF0044]' : 'border-[#FF0044] bg-[#1a0008] shadow-[0_0_30px_#FF0044,inset_0_0_20px_#FF0044]'}`}
                >
                  <div className={`absolute inset-0 rounded-full animate-ping opacity-30 ${isRecording ? 'bg-[#FF0044]' : 'hidden'}`}></div>
                  <Mic className={`w-16 h-16 ${isRecording ? 'text-white' : 'text-[#FF0044]'}`} />
                  {isRecording && (
                    <div className="absolute bottom-6 flex items-center gap-1.5 bg-black/60 px-3 py-1 rounded-full border border-[#FF0044]/50">
                      <span className="w-2 h-2 rounded-full bg-[#FF0044] animate-pulse"></span>
                      <span className="text-[9px] font-bold text-white tracking-widest uppercase">Transmitiendo</span>
                    </div>
                  )}
                </button>
              </div>

              {/* 🔊 CONTROL MAESTRO: AUDIO Y NOTIFICACIONES EN SEGUNDO PLANO */}
              <div 
                onClick={toggleBackgroundMode}
                className={`z-20 w-full max-w-sm md:max-w-md rounded-2xl p-3 flex items-center justify-between gap-3 border transition-all cursor-pointer backdrop-blur-md ${
                  isBgAudioActive
                    ? 'bg-[#00ff88]/10 border-[#00ff88]/60 shadow-[0_0_25px_rgba(0,255,136,0.25)]'
                    : 'bg-black/80 border-gray-800 hover:border-gray-600 shadow-[0_0_15px_rgba(0,0,0,0.5)]'
                }`}
                title="Toca para activar o desactivar la escucha de transmisiones en segundo plano y con la pantalla apagada"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                    isBgAudioActive 
                      ? 'bg-[#00ff88] text-black shadow-[0_0_12px_rgba(0,255,136,0.6)]' 
                      : 'bg-gray-800 text-gray-400'
                  }`}>
                    <Volume2 className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${isBgAudioActive ? 'bg-[#00ff88] animate-pulse' : 'bg-gray-500'}`}></span>
                      <span className={`text-[11px] font-black tracking-wider uppercase font-mono ${isBgAudioActive ? 'text-[#00ff88]' : 'text-gray-300'}`}>
                        {isBgAudioActive ? 'AUDIO EN SEGUNDO PLANO ACTIVO' : 'ACTIVAR AUDIO EN SEGUNDO PLANO'}
                      </span>
                    </div>
                    <span className="text-[9px] text-gray-400 font-mono">
                      {isBgAudioActive 
                        ? 'Se escuchan las voces aunque salgas de la web' 
                        : 'Toca aquí para recibir voz y notificaciones fuera de la web'}
                    </span>
                  </div>
                </div>

                <div className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold uppercase transition-all ${
                  isBgAudioActive
                    ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/50'
                    : 'bg-gray-800 text-gray-400 border border-gray-700'
                }`}>
                  {isBgAudioActive ? 'ON' : 'OFF'}
                </div>
              </div>

              <div className="flex items-center gap-3 bg-[#110022] border border-[#9D00FF]/30 px-5 py-2 rounded-full shadow-[0_0_15px_rgba(157,0,255,0.15)] z-20 cursor-pointer hover:bg-[#9D00FF]/10 transition-all" onClick={() => alert("El modo VOX de detección de voz de nivel militar se activará tras conectar hardware de casco táctico compatible.")}>
                <span className="text-[10px] text-gray-300 font-bold tracking-widest uppercase">MODO VOX (Manos Libres)</span>
                <button 
                  className="w-10 h-5 bg-black rounded-full border border-gray-600 relative transition-all"
                >
                  <div className="w-4 h-4 bg-gray-500 rounded-full absolute left-[2px] top-[1px]"></div>
                </button>
              </div>

              {/* Widget Táctico: TU RADIO EXCLUSIVO (VERSIÓN PRUEBA) */}
              <div className="z-20 w-full max-w-sm md:max-w-md bg-black/75 border border-[#9D00FF]/50 rounded-2xl p-3 flex flex-col gap-2 backdrop-blur-md shadow-[0_0_20px_rgba(157,0,255,0.25)]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse"></span>
                    <span className="text-[10px] font-black text-[#00ff88] uppercase tracking-wider font-mono">
                      ✅ TU RADIO EXCLUSIVO {clientModule.tipo.includes('demo') ? '(PRUEBA)' : '(OFICIAL)'}
                    </span>
                  </div>
                  <button 
                    onClick={() => setActiveTab('modules')}
                    className="text-[9px] font-mono text-[#9D00FF] hover:text-[#00ff88] transition-colors uppercase font-bold underline"
                  >
                    Ver 10 Canales →
                  </button>
                </div>
                <div className="flex items-center justify-between text-[10px] font-mono text-gray-300">
                  <span>ID: <strong className="text-white">{clientModule.cliente_id}</strong></span>
                  <span>Freq: <strong className="text-[#00ff88]">{currentFrequency} MHz</strong></span>
                  <span className="text-yellow-400">{calcularDiasRestantesDemo(clientModule.vencimiento_demo)} días</span>
                </div>
                {/* Selector rápido de canales 1 a 5 */}
                <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none">
                  {[...clientModule.canales_publicos, ...clientModule.modulo_privado.slice(0, 3)].map((c) => (
                    <button
                      key={c.id}
                      onClick={() => handleSelectRadioChannel(c)}
                      className={`px-2 py-1 rounded-lg text-[9px] font-mono whitespace-nowrap transition-all flex items-center gap-1 ${
                        channelId === c.nombre
                          ? 'bg-[#00ff88] text-black font-bold shadow-[0_0_10px_rgba(0,255,136,0.5)]'
                          : 'bg-black/80 text-gray-400 hover:text-white border border-gray-800'
                      }`}
                      title={`${c.nombre} (${c.freq} MHz)`}
                    >
                      <span>C{c.id < 10 ? `0${c.id}` : c.id}</span>
                      <span className="opacity-75">{c.freq}M</span>
                    </button>
                  ))}
                  <button
                    onClick={() => setActiveTab('modules')}
                    className="px-2 py-1 rounded-lg text-[9px] font-mono whitespace-nowrap bg-[#9D00FF]/30 text-[#9D00FF] hover:bg-[#9D00FF]/50 border border-[#9D00FF]/50 font-bold"
                  >
                    + Módulos
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="w-full h-[300px] bg-black/50 border border-[#9D00FF]/30 rounded-2xl p-4 overflow-y-auto z-20 relative shadow-[0_0_30px_rgba(157,0,255,0.1)] custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#9D00FF]/30 pb-2">
                <div className="flex items-center gap-2">
                  <h3 className="text-[#9D00FF] font-bold text-sm tracking-widest uppercase flex items-center gap-2"><History className="w-4 h-4" /> Historial de Transmisiones</h3>
                  {subscription === 'pro' && messages.length > 0 && (
                    <button 
                      onClick={() => {
                        const transcriptText = messages.map(m => `[${new Date(m.timestamp).toLocaleTimeString()}] ${m.username}: ${m.transcript}`).join('\n');
                        const blob = new Blob([transcriptText], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `sono_radio_historial_${Date.now()}.txt`;
                        a.click();
                      }}
                      className="bg-[#FF0044]/20 hover:bg-[#FF0044]/40 text-[#FF0044] border border-[#FF0044]/50 px-2 py-1 rounded text-[9px] font-bold uppercase tracking-widest transition flex items-center gap-1"
                      title="Exportar Transcripciones (PRO)"
                    >
                      Exportar TXT (PRO)
                    </button>
                  )}
                </div>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/50 text-[#9D00FF] transition-all">
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                {messages.length === 0 ? <p className="text-gray-500 text-xs">Sin registros</p> : 
                  [...messages].reverse().map(msg => (
                    <div key={msg.id} className="text-xs bg-[#110022] border border-[#9D00FF]/20 p-3 rounded-lg">
                      <div className="flex justify-between items-center text-[#FF0044] mb-2 font-bold">
                        <span className="flex items-center gap-1"><User className="w-3 h-3" /> {msg.username}</span>
                        <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-gray-300 italic mb-2">"{msg.transcript}"</p>
                      {msg.audioBlob && (
                        <div className="flex items-center gap-2 pt-2 border-t border-[#9D00FF]/10">
                          <button 
                            onClick={() => {
                              const audio = new Audio(URL.createObjectURL(msg.audioBlob!));
                              audio.playbackRate = playbackSpeed;
                              audio.play();
                            }}
                            className="bg-[#9D00FF]/20 text-[#9D00FF] hover:bg-[#9D00FF] hover:text-white border border-[#9D00FF]/50 px-3 py-1 rounded-full text-[9px] font-bold tracking-widest uppercase transition-all flex items-center gap-1"
                          >
                            <Volume2 className="w-3 h-3" /> Play
                          </button>
                          <select 
                            value={playbackSpeed}
                            onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                            className="bg-black text-gray-300 border border-gray-700 text-[9px] rounded-full px-2 py-1 outline-none font-bold"
                          >
                            <option value="1">1.0x</option>
                            <option value="1.5">1.5x</option>
                            <option value="2">2.0x</option>
                          </select>
                          <span className="ml-auto text-[8px] text-gray-500 uppercase tracking-widest flex items-center gap-1">
                            <CheckCircle2 className="w-2.5 h-2.5 text-[#00ff88]" /> Entregado
                          </span>
                        </div>
                      )}
                    </div>
                  ))
                }
              </div>
            </div>
          )}

          {activeTab === 'ai' && (
            <div className="relative mx-auto flex flex-col items-center justify-start w-full h-full pt-4">
              <button onClick={() => setActiveTab('main')} className="absolute top-0 left-2 p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/50 text-[#9D00FF] transition-all z-20">
                <ArrowLeft className="w-5 h-5" />
              </button>
              
              {/* Neuronal Interface */}
              <div className="w-full mb-6">
                <NeuralNetworkUI active={isAiLoading} />
              </div>

              <div className="relative w-36 h-36 mb-6">
                <div className="absolute inset-0 bg-[#9D00FF]/40 rounded-full blur-[30px] animate-pulse"></div>
                <div className="absolute inset-0 rounded-full border-2 border-[#9D00FF] shadow-[0_0_30px_#9D00FF]"></div>
                <img src="/src/assets/images/cyber_fox_avatar_1787539136621.jpg" alt="Sonó Zero Fox" className="relative z-10 w-full h-full object-cover rounded-full mix-blend-screen" />
              </div>
              {aiResponse ? (
                <div className="w-full bg-[#110022]/80 border border-[#FF0044]/50 rounded-xl p-4 shadow-[0_0_20px_rgba(255,0,68,0.2)]">
                   <h3 className="text-[#FF0044] font-bold text-[10px] tracking-widest uppercase mb-2 flex items-center gap-2"><Bot className="w-4 h-4" /> Respuesta</h3>
                   <p className="text-sm text-white font-mono leading-relaxed">{aiResponse}</p>
                   <button onClick={() => setAiResponse(null)} className="mt-4 text-[10px] text-gray-400 hover:text-white uppercase tracking-widest">Cerrar</button>
                </div>
              ) : (
                <div className="w-full grid grid-cols-2 gap-3 px-2">
                  <div className="bg-[#110022]/60 border border-[#9D00FF]/30 rounded-xl p-3 flex flex-col relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-[#9D00FF]"></div>
                    <h3 className="text-[#FF0044] font-bold text-[9px] tracking-widest uppercase mb-3 drop-shadow-[0_0_2px_#FF0044]">Resumen del Canal</h3>
                    <div className="space-y-2 overflow-y-auto text-[10px] text-gray-300 font-medium">
                      <p><span className="text-white font-bold">1. Carlos:</span> Pide refuerzos.</p>
                      <p><span className="text-white font-bold">2. Maria:</span> Reporta retraso.</p>
                    </div>
                  </div>
                  <div className="bg-[#110022]/60 border border-[#9D00FF]/30 rounded-xl p-3 flex flex-col relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-1 h-full bg-[#FF0044]"></div>
                    <h3 className="text-[#FF0044] font-bold text-[9px] tracking-widest uppercase mb-3 drop-shadow-[0_0_2px_#FF0044]">Preguntas Rápidas</h3>
                    <div className="space-y-2 flex flex-col">
                      {['¿Qué dijo Carlos?', '¿Hay alerta activa?', 'Resumir', 'Traducir'].map(q => (
                        <button key={q} onClick={() => handleAskSonóZero(q)} className="border border-[#FF0044]/40 rounded-full py-1.5 px-3 text-[9px] text-white hover:bg-[#FF0044]/20 text-left transition-all truncate">{q}</button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="w-full cyber-3d-card rounded-3xl p-6 flex flex-col relative z-20 h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 border-b border-[#9D00FF]/30 pb-3">
                <h3 className="text-[#9D00FF] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Settings className="w-5 h-5" /> Perfil y Ajustes
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/50 text-[#9D00FF] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 space-y-6">
                
                {/* Official Account NVIDIA Cloud Info Card */}
                <div className="bg-gradient-to-r from-[#12071f] to-[#1a0033] border border-[#00ff88]/40 rounded-2xl p-4 shadow-[0_0_20px_rgba(0,255,136,0.15)]">
                   <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] text-[#00ff88] font-mono font-black uppercase tracking-widest">📻 SONÓ RADIO — CUENTA OFICIAL NVIDIA CLOUD</span>
                      <span className="px-2 py-0.5 bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/50 text-[9px] font-mono rounded">ACTIVA</span>
                   </div>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-gray-300 font-mono">
                      <div><strong className="text-white">Organización:</strong> Sonovisión</div>
                      <div><strong className="text-white">Propietario:</strong> {ADMIN.nombre}</div>
                      <div><strong className="text-white">ID Cuenta:</strong> 1038792091294388</div>
                      <div><strong className="text-white">Teléfono:</strong> {ADMIN.telefono}</div>
                      <div className="sm:col-span-2"><strong className="text-white">Email Oficial:</strong> {ADMIN.correo}</div>
                      <div className="sm:col-span-2"><strong className="text-white">Ubicación:</strong> And. de las Golondrinas 10, Pilar Blanco, Aguascalientes, MX</div>
                   </div>
                </div>

                {/* Profile Section */}
                <div>
                   <label className="block text-[10px] text-[#9D00FF] font-bold uppercase tracking-widest mb-3">Perfil de Usuario</label>
                   <div className="flex flex-col gap-4 bg-black/40 p-4 rounded-xl border border-[#9D00FF]/30 cyber-metallic-btn">
                      <div className="flex items-center gap-4">
                        <div 
                          className="relative w-16 h-16 rounded-full border-2 border-[#FF0044] bg-[#1a0008] flex items-center justify-center cursor-pointer overflow-hidden group shadow-[0_0_15px_rgba(255,0,68,0.3)] shrink-0"
                          onClick={() => fileInputRef.current?.click()}
                        >
                           {profilePhoto ? (
                              <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                           ) : (
                              <Camera className="w-6 h-6 text-[#FF0044] group-hover:scale-110 transition-transform" />
                           )}
                           <div className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center transition-all">
                              <Camera className="w-5 h-5 text-white" />
                           </div>
                        </div>
                        <input type="file" accept="image/*" capture="user" ref={fileInputRef} className="hidden" onChange={handlePhotoUpload} />
                        
                        <div className="flex-1">
                           <label className="block text-[9px] text-gray-400 uppercase tracking-widest mb-1">Nombre de Visualización</label>
                           <input 
                             type="text" 
                             value={displayName} 
                             onChange={(e) => setDisplayName(e.target.value)}
                             className="w-full bg-black/50 border border-[#9D00FF]/40 rounded-lg py-2 px-3 text-xs text-white font-bold focus:border-[#9D00FF] outline-none transition-all shadow-[inset_0_0_10px_rgba(157,0,255,0.1)]"
                             placeholder="Tu nombre visible"
                           />
                        </div>
                      </div>

                      {/* Cyberpunk-Radio Avatar Generator with Imagen */}
                      <div className="pt-3 border-t border-[#9D00FF]/30">
                         <button
                           type="button"
                           onClick={handleGenerateCyberpunkAvatars}
                           disabled={isGeneratingAvatars}
                           className="w-full py-2.5 px-4 bg-gradient-to-r from-[#9D00FF] to-[#FF0044] rounded-xl text-white font-black text-xs uppercase tracking-widest shadow-[0_0_20px_rgba(157,0,255,0.4)] hover:opacity-90 transition flex items-center justify-center gap-2"
                         >
                           <Bot className="w-4 h-4 animate-bounce" />
                           {isGeneratingAvatars ? 'Generando Avatares con IA Imagen...' : '✨ Generar Avatares Cyberpunk-Radio (IA Imagen)'}
                         </button>

                         {generatedAvatars.length > 0 && (
                           <div className="mt-4">
                             <label className="block text-[9px] text-[#00ff88] font-bold uppercase tracking-widest mb-2">Selecciona tu Avatar Cyberpunk:</label>
                             <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                               {generatedAvatars.map((url, idx) => (
                                 <div 
                                   key={idx} 
                                   onClick={() => handleSelectAvatar(url)}
                                   className={`relative rounded-xl overflow-hidden border-2 cursor-pointer group transition-all transform hover:scale-105 ${profilePhoto === url ? 'border-[#00ff88] shadow-[0_0_15px_#00ff88]' : 'border-[#9D00FF]/50 hover:border-[#FF0044]'}`}
                                 >
                                   <img src={url} alt={`Cyberpunk Avatar ${idx+1}`} className="w-full h-24 object-cover" referrerPolicy="no-referrer" />
                                   <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                     <span className="text-[10px] font-black text-white bg-[#9D00FF]/80 px-2 py-1 rounded">Usar</span>
                                   </div>
                                 </div>
                               ))}
                             </div>
                           </div>
                         )}
                      </div>
                      <div className="flex-1">
                         <label className="flex justify-between items-center text-[9px] text-gray-400 uppercase tracking-widest mb-1">
                           <span>Biografía Táctica</span>
                           <span className={tacticalBio.length >= 100 ? 'text-[#FF0044]' : 'text-gray-400'}>{tacticalBio.length}/100</span>
                         </label>
                         <textarea 
                           value={tacticalBio} 
                           onChange={(e) => {
                             if (e.target.value.length <= 100) {
                               setTacticalBio(e.target.value);
                             }
                           }}
                           className="w-full bg-black/50 border border-[#9D00FF]/40 rounded-lg py-2 px-3 text-xs text-white font-bold focus:border-[#9D00FF] outline-none transition-all shadow-[inset_0_0_10px_rgba(157,0,255,0.1)] resize-none"
                           placeholder="Ej. Operador de campo, Unidad Alfa..."
                           rows={2}
                           maxLength={100}
                         />
                      </div>
                   </div>
                </div>

                {/* Sonó Radio Remote AI Connection */}
                <div>
                   <label className="block text-[10px] text-[#00ff88] font-bold uppercase tracking-widest mb-3">Conexión Sonó Radio AI (Remota)</label>
                   <div className="bg-black/40 border border-[#00ff88]/30 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                         <span className="text-xs text-white font-bold">Conectar con Sonó Radio AI</span>
                         <input 
                           type="checkbox" 
                           checked={useRemoteAi} 
                           onChange={(e) => {
                             setUseRemoteAi(e.target.checked);
                             localStorage.setItem('sonó_use_remote_ai', String(e.target.checked));
                           }}
                           className="w-4 h-4 accent-[#00ff88] cursor-pointer" 
                         />
                      </div>
                      <div>
                         <label className="block text-[9px] text-gray-400 font-bold uppercase tracking-widest mb-1">URL de la App Remota</label>
                         <input 
                           type="text" 
                           value={remoteAiUrl} 
                           onChange={(e) => {
                             setRemoteAiUrl(e.target.value);
                             localStorage.setItem('sonó_remote_ai_url', e.target.value);
                           }}
                           placeholder="https://ais-pre-u636s5yryqob2iprivxwrk-304603503303.us-east5.run.app/api/sono-zero"
                           className="w-full bg-black/60 border border-gray-700 rounded-lg px-3 py-2 text-xs text-white font-mono outline-none focus:border-[#00ff88]"
                         />
                      </div>
                      <p className="text-[10px] text-gray-400">
                        Conecta el asistente Sonó Zero con la inteligencia artificial del servidor de Sonó Radio remoto.
                      </p>
                   </div>
                </div>

                {/* Emergency GPS Sensor Fallback */}
                <div>
                   <label className="block text-[10px] text-[#FF0044] font-bold uppercase tracking-widest mb-3">Sensor GPS de Emergencia (Fallback)</label>
                   <div className="bg-black/40 border border-[#FF0044]/30 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                         <div>
                           <span className="text-xs text-white font-bold block">Forzar Sensor de Ubicación</span>
                           <span className="text-[10px] text-gray-400">Medida de emergencia si la API o red saturan/fallan.</span>
                         </div>
                         <button 
                           onClick={requestEmergencyGpsFallback}
                           className="bg-gradient-to-r from-[#FF0044] to-purple-600 text-white px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(255,0,68,0.4)] hover:scale-105 transition-all"
                         >
                           Activar GPS
                         </button>
                      </div>
                      {emergencyCoords && (
                        <div className="bg-black/60 border border-[#00ff88]/40 p-2.5 rounded-lg text-[10px] font-mono text-[#00ff88]">
                          ✓ Coordenadas de Emergencia Activas:<br/>
                          Lat: {emergencyCoords.lat.toFixed(5)}, Lng: {emergencyCoords.lng.toFixed(5)}
                        </div>
                      )}
                      {gpsErrorMsg && (
                        <div className="bg-red-950/50 border border-red-500/50 p-2.5 rounded-lg text-[10px] font-mono text-red-400">
                          ⚠️ Error GPS: {gpsErrorMsg}
                        </div>
                      )}
                   </div>
                </div>

                {/* Blocked Users Section */}
                <div>
                   <label className="block text-[10px] text-[#FF0044] font-bold uppercase tracking-widest mb-3">Usuarios Bloqueados</label>
                   <div className="bg-black/40 border border-[#FF0044]/30 rounded-xl p-3 space-y-2 max-h-32 overflow-y-auto custom-scrollbar">
                      {blockedUsers.length === 0 ? (
                         <p className="text-[10px] text-gray-500 italic text-center py-2">Ningún usuario bloqueado</p>
                      ) : (
                         blockedUsers.map(user => (
                           <div key={user} className="flex justify-between items-center bg-[#1a0008] border border-[#FF0044]/20 rounded-lg px-3 py-2">
                              <span className="text-xs font-bold text-gray-300">{user}</span>
                              <button onClick={() => handleUnblock(user)} className="text-[9px] uppercase tracking-widest font-bold text-[#FF0044] hover:text-white transition-colors bg-[#FF0044]/10 hover:bg-[#FF0044] border border-[#FF0044]/30 px-3 py-1.5 rounded-full flex items-center gap-1">
                                 Desbloquear
                              </button>
                           </div>
                         ))
                      )}
                   </div>
                </div>

                 {/* Audio Output Test */}
                 <div>
                   <label className="block text-[10px] text-[#00ff88] font-bold uppercase tracking-widest mb-3">Prueba de Salida de Audio</label>
                   <div className="bg-black/40 border border-[#00ff88]/30 rounded-xl p-4 flex flex-col items-center justify-center gap-3">
                     <div className="flex items-center justify-between w-full">
                       <div>
                         <span className="text-xs text-white font-bold block">Test de Bocina y Salida</span>
                         <span className="text-[10px] text-gray-400">Verifica cómo se escucha el audio y la voz sintetizada.</span>
                       </div>
                       <button 
                         onClick={runAudioTest}
                         disabled={isAudioTesting}
                         className="bg-[#00ff88]/20 hover:bg-[#00ff88]/40 text-[#00ff88] border border-[#00ff88]/60 px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-[0_0_15px_rgba(0,255,136,0.3)] flex items-center gap-2"
                       >
                         <Volume2 className={`w-4 h-4 ${isAudioTesting ? 'animate-bounce' : ''}`} />
                         {isAudioTesting ? 'Reproduciendo...' : '🔊 Probar Audio'}
                       </button>
                     </div>
                     {isAudioTesting && (
                       <div className="w-full flex items-center justify-center gap-1.5 py-2 bg-black/60 rounded-lg border border-[#00ff88]/40 animate-pulse">
                         {[4, 12, 20, 28, 16, 24, 10, 18, 22, 14, 8].map((h, i) => (
                           <div key={i} className="w-1 bg-[#00ff88] rounded-full animate-pulse" style={{ height: `${h}px` }} />
                         ))}
                         <span className="text-[10px] font-mono text-[#00ff88] ml-2 tracking-widest">TRANSMITIENDO FRECUENCIA DE PRUEBA...</span>
                       </div>
                     )}
                   </div>
                 </div>

                 {/* Message Tones (MSJ) */}
                <div>
                  <label className="block text-[10px] text-[#00ff88] font-bold uppercase tracking-widest mb-3">Tono de Mensajes (MSJ) y Notificaciones</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      { id: 'nextel-chirp', label: 'Nextel Chirp' }, { id: 'moto-chirp', label: 'Moto Trunk Chirp' },
                      { id: 'nextel-beep', label: 'Nextel Beep' }, { id: 'moto-roger', label: 'Moto Roger Beep' },
                      { id: 'trunk-dispatch', label: 'Trunk Dispatch' }, { id: 'ping', label: 'Ping Clásico' },
                      { id: 'sonar', label: 'Sonar Radar' }, { id: 'cyber', label: 'Cyber Pulsar' },
                      { id: 'alarm', label: 'Alerta Táctica' }, { id: 'chime', label: 'Campana Armónica' },
                      { id: 'silent', label: 'Silencioso' }
                    ].map((tone) => (
                      <button key={tone.id} onClick={() => { setMessageTone(tone.id); playMessageTone(tone.id); }} className={`py-3 px-2 rounded-xl border text-[9px] font-bold tracking-widest uppercase transition-all ${messageTone === tone.id ? 'bg-[#00ff88]/20 border-[#00ff88] text-white shadow-[0_0_15px_rgba(0,255,136,0.3)]' : 'bg-black/50 border-[#9D00FF]/30 text-gray-400 hover:border-[#00ff88]/50'}`}>
                        {tone.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* PTT Tones */}
                <div>
                  <label className="block text-[10px] text-[#FF0044] font-bold uppercase tracking-widest mb-3">Tono de Obturador (PTT)</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      { id: 'nextel', label: 'Sonó Clásico' }, { id: 'nextel-alert', label: 'Nextel Alert' },
                      { id: 'moto-mdc', label: 'Moto MDC' }, { id: 'moto-roger', label: 'Moto Beep' }, 
                      { id: 'moto-trunk', label: 'Moto Trunk' },
                      { id: 'military', label: 'Táctico' }, { id: 'cyber', label: 'Cyber Freq' }, 
                      { id: 'silent', label: 'Silencioso' },
                      { id: 'mil-alpha', label: 'Mil-Alpha' }, { id: 'mil-bravo', label: 'Mil-Bravo' },
                      { id: 'mil-charlie', label: 'Mil-Charlie' }, { id: 'mil-delta', label: 'Mil-Delta' },
                      { id: 'mil-echo', label: 'Mil-Echo' },
                      { id: 'yt-1', label: 'Tono Motor' }, { id: 'yt-2', label: 'Tono Sirena' },
                      { id: 'yt-3', label: 'Tono Burst' }, { id: 'yt-4', label: 'Tono Tri-Beep' }
                    ].map((tone) => (
                      <button key={tone.id} onClick={() => { setPttTone(tone.id as any); playPttTone(tone.id, 'start'); }} className={`py-3 px-2 rounded-xl border text-[9px] font-bold tracking-widest uppercase transition-all ${pttTone === tone.id ? 'bg-[#FF0044]/20 border-[#FF0044] text-white shadow-[0_0_15px_rgba(255,0,68,0.3)]' : 'bg-black/50 border-[#9D00FF]/30 text-gray-400 hover:border-[#FF0044]/50'}`}>
                        {tone.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Ambient Sounds */}
                <div>
                  <label className="block text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-3">Sonido Ambiental Cyberpunk</label>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { id: 'off', label: 'Apagado' }, { id: 'rain', label: 'Lluvia Ácida' },
                      { id: 'city', label: 'Ciudad Cyber' }, { id: 'static', label: 'Estática de Radio' }
                    ].map((env) => (
                      <button key={env.id} onClick={() => setAmbientSound(env.id as any)} className={`py-3 px-3 rounded-xl border text-[9px] font-bold tracking-widest uppercase transition-all ${ambientSound === env.id ? 'bg-[#9D00FF]/20 border-[#9D00FF] text-white shadow-[0_0_10px_rgba(157,0,255,0.3)]' : 'bg-black/50 border-gray-700 text-gray-400 hover:border-[#9D00FF]/50'}`}>
                        {env.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sensors & Hardware */}
                <div className="border-t border-[#9D00FF]/20 pt-4">
                  <label className="block text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-3">Sensores y Dispositivos</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => {
                        navigator.mediaDevices.getUserMedia({ audio: true })
                          .then(s => { s.getTracks().forEach(t => t.stop()); alert("✅ Micrófono Detectado"); })
                          .catch(() => alert("❌ Error: Micrófono sin permiso"));
                      }} className="py-2.5 px-2 rounded-xl border border-gray-700 hover:border-[#FF0044] bg-black/50 text-[9px] font-bold tracking-widest uppercase text-gray-300 flex items-center justify-center gap-2 transition-all">
                      <Mic className="w-3 h-3 text-[#FF0044]" /> Micrófono
                    </button>
                    
                    <button onClick={() => {
                        navigator.mediaDevices.getUserMedia({ video: true })
                          .then(s => { s.getTracks().forEach(t => t.stop()); alert("✅ Cámara Detectada"); })
                          .catch(() => alert("❌ Error: Cámara sin permiso"));
                      }} className="py-2.5 px-2 rounded-xl border border-gray-700 hover:border-[#9D00FF] bg-black/50 text-[9px] font-bold tracking-widest uppercase text-gray-300 flex items-center justify-center gap-2 transition-all">
                      <Camera className="w-3 h-3 text-[#9D00FF]" /> Cámara
                    </button>
                    
                    <button onClick={() => {
                         const input = document.createElement('input');
                         input.type = 'file';
                         input.accept = 'image/*';
                         input.onchange = () => alert("✅ Galería lista");
                         input.click();
                      }} className="py-2.5 px-2 rounded-xl border border-gray-700 hover:border-[#FF0044] bg-black/50 text-[9px] font-bold tracking-widest uppercase text-gray-300 flex items-center justify-center gap-2 transition-all">
                      <FolderOpen className="w-3 h-3 text-[#FF0044]" /> Galería
                    </button>
                    
                    <button onClick={() => playPttTone('nextel', 'start')} className="py-2.5 px-2 rounded-xl border border-gray-700 hover:border-[#9D00FF] bg-black/50 text-[9px] font-bold tracking-widest uppercase text-gray-300 flex items-center justify-center gap-2 transition-all">
                      <Volume2 className="w-3 h-3 text-[#9D00FF]" /> Bocina
                    </button>
                  </div>
                </div>

              </div>
            </div>
          )}

          {activeTab === 'sonar' && (
            <div className="w-full bg-[#110022]/95 border border-[#00ff88] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_40px_rgba(0,255,136,0.1)] h-full overflow-hidden">
              <SonarMap 
                myLocation={myLocation} 
                targets={sonarTargets} 
                onScan={triggerSonar} 
                isScanning={isScanning} 
              />
            </div>
          )}

          {activeTab === 'admin' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#FF0044] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_40px_rgba(255,0,68,0.2)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#FF0044]/30 pb-3">
                <h3 className="text-[#FF0044] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Shield className="w-5 h-5" /> Gestión de Llaves API
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#FF0044]/20 border border-[#FF0044]/50 text-[#FF0044] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              
              <div className="bg-black/50 border border-[#9D00FF]/50 rounded-xl p-4 mb-4">
                <h4 className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Llave Activa</h4>
                <div className="flex items-center gap-2">
                   <Key className="w-4 h-4 text-[#9D00FF]" />
                   <p className="font-mono text-white text-[11px] md:text-xs font-bold tracking-widest break-all">Sono_radio_llamadas_gestion</p>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                   <span className="text-[9px] bg-green-500/20 text-green-400 border border-green-500/50 px-2 py-1 rounded uppercase tracking-widest font-bold">Llamadas Voz/Video</span>
                   <span className="text-[9px] bg-[#9D00FF]/20 text-[#9D00FF] border border-[#9D00FF]/50 px-2 py-1 rounded uppercase tracking-widest font-bold">Notif. Push</span>
                   <span className="text-[9px] bg-yellow-500/20 text-yellow-500 border border-yellow-500/50 px-2 py-1 rounded uppercase tracking-widest font-bold">Modo LoRa</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                 <div className="bg-black/40 border border-gray-700 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Llamadas Activas</p>
                    <p className="text-3xl text-white font-black mt-1">{adminStats.activeCalls}</p>
                 </div>
                 <div className="bg-black/40 border border-gray-700 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Total Histórico</p>
                    <p className="text-3xl text-white font-black mt-1">{adminStats.totalCalls}</p>
                 </div>
                 <div className="bg-black/40 border border-gray-700 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Modo LoRa</p>
                    <p className="text-[9px] text-green-400 font-bold mt-2 border border-green-500/50 rounded-full inline-block px-2 py-0.5">ONLINE</p>
                 </div>
                 <div className="bg-black/40 border border-gray-700 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">Push Background</p>
                    <p className="text-[9px] text-green-400 font-bold mt-2 border border-green-500/50 rounded-full inline-block px-2 py-0.5">ACTIVO</p>
                 </div>
              </div>

              <div className="bg-black/40 border border-gray-700 p-3 rounded-xl mb-4">
                 <h4 className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-3">Historial Ping LoRa (ms)</h4>
                 <div className="h-32 w-full">
                   <ResponsiveContainer width="100%" height="100%">
                     <LineChart data={latencyHistory}>
                       <XAxis dataKey="time" hide />
                       <YAxis domain={['auto', 'auto']} stroke="#4b5563" fontSize={9} width={30} />
                       <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #FF0044', fontSize: '10px' }} itemStyle={{ color: '#FF0044' }} />
                       <Line type="monotone" dataKey="ping" stroke="#FF0044" strokeWidth={2} dot={false} isAnimationActive={false} />
                     </LineChart>
                   </ResponsiveContainer>
                 </div>
              </div>

              <button onClick={() => socket?.emit('get-admin-stats')} className="w-full mt-auto bg-gradient-to-r from-[#9D00FF] to-[#FF0044] text-white rounded-xl py-3.5 text-[10px] font-bold tracking-widest uppercase hover:opacity-90 flex items-center justify-center gap-2">
                 <RefreshCcw className="w-4 h-4" /> Refrescar Panel
              </button>
            </div>
          )}
          {activeTab === 'groups' && (
            <div className="w-full bg-[#110022]/95 border border-[#9D00FF]/50 rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(157,0,255,0.15)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 border-b border-[#9D00FF]/30 pb-3">
                <h3 className="text-[#9D00FF] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <FolderOpen className="w-5 h-5" /> Grupos de Trabajo
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/50 text-[#9D00FF] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 space-y-4">
                <div className="flex items-center justify-between bg-black/40 border border-[#9D00FF]/30 p-3 rounded-xl mb-4">
                  <div>
                    <h4 className="text-[10px] font-bold text-white uppercase tracking-widest flex items-center gap-2">
                      <Lock className="w-3 h-3 text-[#FF0044]" /> Modo Exclusivo
                    </h4>
                    <p className="text-[9px] text-gray-500 mt-1">Bloquea msjs ajenos al grupo</p>
                  </div>
                  <button 
                    onClick={() => {
                       if (subscription === 'free') {
                          setShowProModal(true);
                          return;
                       }
                       setExclusiveMode(!exclusiveMode);
                    }}
                    className={`w-10 h-5 rounded-full relative transition-colors ${exclusiveMode ? 'bg-[#9D00FF]' : 'bg-gray-700'}`}
                  >
                    <div className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${exclusiveMode ? 'translate-x-5' : ''}`}></div>
                  </button>
                </div>
                <div className="flex items-center gap-2 mb-4">
                  <input type="text" placeholder="Nuevo Grupo..." id="newGroupInput" className="flex-1 bg-black/50 border border-gray-700 focus:border-[#9D00FF] rounded-xl py-2.5 px-3 text-xs outline-none text-white placeholder-gray-500" />
                  <button onClick={() => {
                     const input = document.getElementById('newGroupInput') as HTMLInputElement;
                     if(input.value.trim()) {
                       setWorkgroups([...workgroups, input.value.trim().toUpperCase()]);
                       input.value = '';
                     }
                  }} className="p-2.5 rounded-xl bg-[#9D00FF]/20 border border-[#9D00FF] hover:bg-[#9D00FF]/40 transition-all text-[#9D00FF]">
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex bg-black/50 rounded-lg p-1 mb-4 border border-gray-700">
                  <button onClick={() => setGroupsFilter('all')} className={`flex-1 py-1.5 text-[10px] font-bold tracking-widest uppercase rounded-md transition-all ${groupsFilter === 'all' ? 'bg-[#9D00FF] text-white' : 'text-gray-500'}`}>Todos</button>
                  <button onClick={() => setGroupsFilter('favs')} className={`flex-1 py-1.5 text-[10px] font-bold tracking-widest uppercase rounded-md transition-all flex items-center justify-center gap-1 ${groupsFilter === 'favs' ? 'bg-yellow-500 text-black' : 'text-gray-500'}`}>
                    <Star className="w-3 h-3" /> Favoritos
                  </button>
                </div>

                {(groupsFilter === 'favs' ? workgroups.filter(g => favoriteChannels.includes(g)) : workgroups).map(group => (
                  <div key={group} className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${channelId === group ? 'bg-[#9D00FF]/20 border-[#9D00FF]' : 'bg-black/50 border-gray-700 hover:border-gray-500'}`} onClick={() => setChannelId(group)}>
                     <div className="flex items-center gap-2">
                       <button onClick={(e) => {
                         e.stopPropagation();
                         setFavoriteChannels(prev => 
                           prev.includes(group) ? prev.filter(g => g !== group) : [...prev, group]
                         );
                       }} className="p-1 hover:bg-white/10 rounded-full transition-colors">
                         <Star className={`w-4 h-4 ${favoriteChannels.includes(group) ? 'fill-yellow-500 text-yellow-500' : 'text-gray-500'}`} />
                       </button>
                       <span className={`text-[10px] font-bold tracking-widest uppercase ${channelId === group ? 'text-white' : 'text-gray-400'}`}>{group}</span>
                     </div>
                     {channelId === group && <CheckCircle2 className="w-4 h-4 text-[#9D00FF]" />}
                  </div>
                ))}
              </div>
            </div>
          )}

           {activeTab === 'modules' && (
            <div className="w-full bg-[#0d021a]/95 border-2 border-[#9D00FF]/60 rounded-3xl p-4 md:p-5 flex flex-col relative z-20 shadow-[0_0_40px_rgba(157,0,255,0.3)] h-full overflow-y-auto custom-scrollbar space-y-6">
              <div className="flex items-center justify-between border-b border-[#9D00FF]/30 pb-3">
                <h3 className="text-[#00ff88] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Zap className="w-5 h-5 text-[#9D00FF]" /> MÓDULOS DE RADIO Y CANALES EXCLUSIVOS 2026
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/50 text-[#9D00FF] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              {/* 📡 SISTEMA COMPLETO: VERSIÓN DEMO + MÓDULOS EXCLUSIVOS POR CLIENTE */}
              <ClientModuleCard 
                moduleData={clientModule}
                activeFrequency={currentFrequency}
                activeChannelName={channelId}
                onSelectChannel={handleSelectRadioChannel}
                onRegenerateDemo={handleRegenerateDemoModule}
                onUpgradePremium={handleUpgradeToPremium}
              />

              {/* Módulos Adicionales Tácticos */}
              <div className="pt-2 border-t border-gray-800">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold text-gray-300 uppercase tracking-widest flex items-center gap-2">
                    <span>Módulos de Sistema y Conmutación</span>
                    <span className="text-[9px] text-[#FFD700] bg-[#FFD700]/10 border border-[#FFD700]/30 px-2 py-0.5 rounded font-mono">PRO</span>
                  </h4>
                  <p className="text-[9px] text-gray-500 font-mono">Personalización de red</p>
                </div>
                <div className="space-y-3">
                  {customModules.map(mod => (
                    <div key={mod.id} className={`p-3.5 rounded-xl border flex flex-col gap-2 transition-all ${mod.active ? 'bg-[#FFD700]/10 border-[#FFD700]' : 'bg-black/50 border-gray-700'}`}>
                      <div className="flex justify-between items-center">
                        <input 
                          type="text" 
                          value={mod.name} 
                          onChange={(e) => setCustomModules(prev => prev.map(m => m.id === mod.id ? { ...m, name: e.target.value } : m))}
                          className={`bg-transparent border-none text-[11px] font-bold tracking-widest uppercase outline-none flex-1 ${mod.active ? 'text-white' : 'text-gray-400'}`}
                        />
                        <button 
                          onClick={() => {
                             if (subscription === 'free') {
                                setShowProModal(true);
                                return;
                             }
                             setCustomModules(prev => prev.map(m => m.id === mod.id ? { ...m, active: !m.active } : m));
                          }}
                          className={`w-10 h-5 rounded-full relative transition-colors ${mod.active ? 'bg-[#FFD700]' : 'bg-gray-700'}`}
                        >
                          <div className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${mod.active ? 'translate-x-5' : ''}`}></div>
                        </button>
                      </div>
                      {mod.desc && <p className="text-[10px] text-gray-400 font-medium leading-relaxed">{mod.desc}</p>}
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[8px] bg-purple-900/60 text-purple-300 border border-purple-500/40 px-2 py-0.5 rounded font-bold uppercase tracking-widest">Enterprise 2026</span>
                        <span className={`text-[8px] font-bold uppercase tracking-widest ${mod.active ? 'text-green-400' : 'text-gray-500'}`}>{mod.active ? '● Activo' : '○ Inactivo'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'termux' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#00ff88] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(0,255,136,0.2)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 border-b border-[#00ff88]/30 pb-3">
                <h3 className="text-[#00ff88] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Terminal className="w-5 h-5" /> Integración Termux
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#00ff88]/20 border border-[#00ff88]/50 text-[#00ff88] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex-1 space-y-4">
                <p className="text-[11px] text-gray-300 font-bold mb-2">Conecta tu consola SONÓ RADIO directamente desde Termux en cualquier dispositivo de campo.</p>
                <div className="bg-black/60 border border-[#00ff88]/40 p-4 rounded-xl">
                  <h4 className="text-[10px] text-[#00ff88] font-black tracking-widest uppercase mb-2">Instrucciones de Instalación</h4>
                  <ol className="list-decimal list-inside text-[10px] text-gray-400 space-y-2 font-mono">
                    <li>Abre tu consola Termux</li>
                    <li>Ejecuta el siguiente comando para descargar e iniciar la consola táctica de Sonó Radio:</li>
                  </ol>
                  <div className="mt-4 bg-black border border-gray-700 rounded-lg p-3 relative group">
                    <code className="text-[9px] text-[#00ff88] font-mono break-all select-all">
                      curl -s {window.location.origin}/api/termux/sono.sh &gt; sono.sh && bash sono.sh
                    </code>
                  </div>
                </div>

                <div className="bg-[#00ff88]/10 border border-[#00ff88]/30 p-3 rounded-xl mt-4">
                  <p className="text-[9px] text-[#00ff88] uppercase tracking-widest font-bold">CARACTERÍSTICAS DEL SCRIPT:</p>
                  <ul className="list-disc list-inside text-[9px] text-gray-400 mt-2 space-y-1">
                    <li>Módulo PTT Transmisión en Tiempo Real</li>
                    <li>Enlace P2P y Descubrimiento de Red</li>
                    <li>Botón de Pánico / Alerta SOS</li>
                    <li>Asistente Sonó Zero Integrado (Gemini IA)</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'heal' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#00d4ff] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(0,212,255,0.2)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#00d4ff]/30 pb-3">
                <h3 className="text-[#00d4ff] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <RefreshCcw className="w-5 h-5 animate-spin" /> Sonó Heal-Core & OTA Live
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#00d4ff]/20 border border-[#00d4ff]/50 text-[#00d4ff] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-black/60 border border-[#00d4ff]/30 flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-widest">Estado de Integridad Cuántica</h4>
                      <p className="text-[10px] text-gray-400 mt-0.5">Versión actual: <span className="text-[#00d4ff] font-bold">{otaVersion}</span></p>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-black text-green-400">{systemHealth}%</span>
                      <p className="text-[8px] text-gray-500 uppercase tracking-widest">Salud del Sistema</p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button 
                      onClick={runSelfHealingScan}
                      className="flex-1 bg-[#00d4ff]/20 hover:bg-[#00d4ff]/30 border border-[#00d4ff] text-[#00d4ff] font-bold py-2.5 rounded-xl uppercase tracking-widest text-[10px] transition shadow-[0_0_15px_rgba(0,212,255,0.2)] flex items-center justify-center gap-2"
                    >
                      <RefreshCcw className="w-3.5 h-3.5 animate-pulse" /> Auto-Corregir Estructura
                    </button>
                    <button 
                      onClick={triggerOtaUpdate}
                      disabled={isUpdatingOta}
                      className="flex-1 bg-gradient-to-r from-[#9D00FF] to-[#FF0044] hover:opacity-90 text-white font-bold py-2.5 rounded-xl uppercase tracking-widest text-[10px] transition shadow-[0_0_15px_rgba(255,0,68,0.3)] flex items-center justify-center gap-2"
                    >
                      <Terminal className="w-3.5 h-3.5" /> {isUpdatingOta ? 'Actualizando...' : 'Sincronizar OTA Cloud'}
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-black/80 border border-gray-800 flex flex-col gap-2">
                  <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Consola de Autodiagnóstico en Vivo</span>
                    <span className="text-[9px] bg-green-500/20 text-green-400 px-2 py-0.5 rounded font-bold uppercase">Conectado al Navegador</span>
                  </div>
                  <div className="h-40 overflow-y-auto space-y-1.5 pr-2 custom-scrollbar font-mono text-[9px]">
                    {selfHealingLogs.map(log => (
                      <div key={log.id} className={`p-1.5 rounded border ${log.type === 'success' ? 'bg-green-950/30 border-green-500/40 text-green-300' : log.type === 'repair' ? 'bg-cyan-950/30 border-cyan-500/40 text-cyan-300' : 'bg-purple-950/30 border-purple-500/40 text-purple-300'}`}>
                        <span className="text-gray-500 mr-2">[{log.time}]</span>
                        <span className="font-bold mr-1">[{log.type.toUpperCase()}]:</span>
                        <span>{log.text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'gmail' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#EA4335] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(234,67,53,0.3)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#EA4335]/30 pb-3">
                <h3 className="text-[#EA4335] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Mail className="w-5 h-5 animate-pulse" /> Gmail Táctico • Workspace Integration
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#EA4335]/20 border border-[#EA4335]/50 text-[#EA4335] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              {!gmailAccessToken ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-[#EA4335]/20 border border-[#EA4335] flex items-center justify-center text-[#EA4335] shadow-[0_0_20px_rgba(234,67,53,0.3)]">
                    <Mail className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-2">Conecta tu cuenta de Gmail</h4>
                    <p className="text-xs text-gray-400 max-w-sm">Gestiona mensajes, lee correos de despacho y envía reportes tácticos directamente desde Sonó Radio.</p>
                  </div>
                  
                  <button 
                    onClick={handleGmailSignIn}
                    disabled={isGmailLoading}
                    className="flex items-center gap-3 bg-white text-gray-800 font-medium px-6 py-3 rounded-xl shadow-lg hover:bg-gray-100 transition-all border border-gray-300 cursor-pointer"
                  >
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-5 h-5">
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    </svg>
                    <span className="text-xs font-bold tracking-wider uppercase">Sign in with Google (Gmail)</span>
                  </button>
                  {gmailError && <p className="text-xs text-red-400">{gmailError}</p>}
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center bg-black/60 p-4 rounded-2xl border border-[#EA4335]/30">
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest">Cuenta Vinculada</p>
                      <p className="text-xs font-bold text-white">{gmailUser?.email || 'Operador Conectado'}</p>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => fetchGmailMessages()} className="px-3 py-1.5 bg-[#EA4335]/20 hover:bg-[#EA4335]/30 text-[#EA4335] text-[10px] font-bold rounded-xl border border-[#EA4335]/50 transition">
                        Actualizar Buzón
                      </button>
                      <button onClick={() => { setGmailAccessToken(null); setGmailUser(null); setGmailMessages([]); }} className="px-3 py-1.5 bg-red-950/40 hover:bg-red-900/40 text-red-400 text-[10px] font-bold rounded-xl border border-red-500/50 transition">
                        Desconectar
                      </button>
                    </div>
                  </div>

                  <div className="bg-black/60 p-4 rounded-2xl border border-[#EA4335]/30 space-y-3">
                    <h4 className="text-xs font-bold text-[#EA4335] uppercase tracking-widest flex items-center gap-2">
                      <Mail className="w-4 h-4" /> Redactar Correo Táctico
                    </h4>
                    <form onSubmit={handleSendGmail} className="space-y-3">
                      <div>
                        <label className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1">Destinatario</label>
                        <input 
                          type="email" 
                          value={emailTo} 
                          onChange={(e) => setEmailTo(e.target.value)} 
                          placeholder="operador@dominio.com" 
                          required
                          className="w-full bg-black/80 border border-gray-700 focus:border-[#EA4335] rounded-xl px-3 py-2 text-xs text-white outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1">Asunto</label>
                        <input 
                          type="text" 
                          value={emailSubject} 
                          onChange={(e) => setEmailSubject(e.target.value)} 
                          placeholder="Reporte de Operaciones / Alerta" 
                          required
                          className="w-full bg-black/80 border border-gray-700 focus:border-[#EA4335] rounded-xl px-3 py-2 text-xs text-white outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1">Mensaje</label>
                        <textarea 
                          value={emailBody} 
                          onChange={(e) => setEmailBody(e.target.value)} 
                          placeholder="Escribe el reporte táctico..." 
                          rows={3} 
                          required
                          className="w-full bg-black/80 border border-gray-700 focus:border-[#EA4335] rounded-xl p-3 text-xs text-white outline-none resize-none"
                        />
                      </div>
                      <button 
                        type="submit" 
                        disabled={isGmailLoading}
                        className="w-full bg-gradient-to-r from-[#EA4335] to-[#FF0044] hover:opacity-90 text-white font-bold py-2.5 rounded-xl uppercase tracking-widest text-[10px] transition shadow-[0_0_15px_rgba(234,67,53,0.3)] flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {isGmailLoading ? 'Enviando...' : 'Enviar Correo Táctico'}
                      </button>
                    </form>
                  </div>

                  <div className="bg-black/60 p-4 rounded-2xl border border-gray-800 space-y-3">
                    <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Buzón de Entrada ({gmailMessages.length})</span>
                      {isGmailLoading && <span className="text-[9px] text-[#EA4335] animate-pulse">Sincronizando...</span>}
                    </div>

                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1 custom-scrollbar">
                      {gmailMessages.length === 0 ? (
                        <p className="text-[10px] text-gray-500 text-center py-4">No hay mensajes recientes o conecta tu cuenta para ver el buzón.</p>
                      ) : (
                        gmailMessages.map((msg: any) => {
                          const headers = msg.payload?.headers || [];
                          const subject = headers.find((h: any) => h.name === 'Subject')?.value || 'Sin Asunto';
                          const sender = headers.find((h: any) => h.name === 'From')?.value || 'Desconocido';
                          const snippet = msg.snippet || '';

                          return (
                            <div key={msg.id} className="p-3 bg-black/80 border border-gray-800 hover:border-[#EA4335]/50 rounded-xl transition flex flex-col gap-1">
                              <div className="flex justify-between items-center">
                                <span className="text-[11px] font-bold text-white truncate max-w-[220px]">{sender}</span>
                                <span className="text-[9px] text-gray-500">{new Date(parseInt(msg.internalDate)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              </div>
                              <p className="text-[10px] font-bold text-[#EA4335]">{subject}</p>
                              <p className="text-[9px] text-gray-400 truncate">{snippet}</p>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'plans' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#FF0044] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(255,0,68,0.2)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 border-b border-[#FF0044]/30 pb-3">
                <h3 className="text-[#FF0044] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Crown className="w-5 h-5" /> Planes y Suscripción
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#FF0044]/20 border border-[#FF0044]/50 text-[#FF0044] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex-1 space-y-4">
                <div className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${subscription === 'free' ? 'bg-[#9D00FF]/10 border-[#9D00FF]' : 'bg-black/50 border-gray-800'}`} onClick={() => setSubscription('free')}>
                   <div className="flex items-center justify-between mb-2">
                     <h4 className={`text-xs font-black tracking-widest uppercase ${subscription === 'free' ? 'text-[#9D00FF]' : 'text-gray-400'}`}>Versión Básico</h4>
                     {subscription === 'free' && <CheckCircle2 className="w-4 h-4 text-[#9D00FF]" />}
                   </div>
                   <p className="text-[10px] text-gray-400 font-medium mb-3">Acceso a canales PTT (Walkie-Talkie), grupos de trabajo y AI básica.</p>
                   <span className="text-[10px] bg-[#9D00FF]/20 text-[#9D00FF] border border-[#9D00FF]/50 px-2 py-1 rounded font-bold uppercase tracking-widest">$140 MXN/mes</span>
                </div>

                <div 
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${subscription === 'pro' ? 'bg-[#FF0044]/10 border-[#FF0044] shadow-[0_0_20px_rgba(255,0,68,0.3)]' : 'bg-black/50 border-gray-800'}`} 
                  onClick={() => {
                    const confirmPay = window.confirm("¿Deseas activar el plan Táctico mediante transferencia bancaria? Te redirigiremos a WhatsApp para enviar tu comprobante.");
                    if(confirmPay) {
                       window.open("https://wa.me/5211234567890?text=Hola,%20adjunto%20mi%20comprobante%20de%20pago%20para%20activar%20SON%C3%93%20RADIO%20T%C3%81CTICO%20($200%20MXN)%20(Usuario:%20" + username + ")", "_blank");
                    }
                  }}
                >
                   <div className="flex items-center justify-between mb-2">
                     <h4 className={`text-xs font-black tracking-widest uppercase ${subscription === 'pro' ? 'text-[#FF0044]' : 'text-gray-400'}`}>Versión Táctico</h4>
                     {subscription === 'pro' && <CheckCircle2 className="w-4 h-4 text-[#FF0044]" />}
                   </div>
                   <p className="text-[10px] text-gray-400 font-medium mb-3">Desbloquea llamadas privadas, videollamadas E2E y Sonó Zero avanzado.</p>
                   <div className="flex items-center gap-2">
                     <span className="text-[10px] bg-[#FF0044]/20 text-[#FF0044] border border-[#FF0044]/50 px-2 py-1 rounded font-bold uppercase tracking-widest flex items-center gap-1"><CreditCard className="w-3 h-3"/> $200 MXN/mes</span>
                     <span className="text-[9px] bg-green-500/20 text-green-400 border border-green-500/50 px-2 py-1 rounded font-bold uppercase tracking-widest flex items-center gap-1">Pagar por WhatsApp</span>
                   </div>
                </div>

                {/* 🔑 DESBLOQUEO POR CLAVE DE SUSCRIPCIÓN (369174) */}
                <div className="bg-[#110022] border-2 border-[#00ff88]/60 rounded-2xl p-4 shadow-[0_0_25px_rgba(0,255,136,0.2)]">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-xs font-black tracking-widest uppercase text-[#00ff88] flex items-center gap-2">
                      <Key className="w-4 h-4 text-[#00ff88]" /> Desbloqueo por Clave
                    </h4>
                    <span className="text-[9px] font-mono bg-[#00ff88]/20 text-[#00ff88] px-2 py-0.5 rounded border border-[#00ff88]/40 font-bold">
                      CLAVE: 369174
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-300 font-medium mb-3">
                    Ingresa la clave de activación autorizada para desbloquear todas las funciones de pago por suscripción:
                  </p>
                  
                  {subscription === 'pro' ? (
                    <div className="bg-[#00ff88]/15 border border-[#00ff88] rounded-xl p-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-[#00ff88]" />
                        <div>
                          <p className="text-xs font-black text-[#00ff88] uppercase tracking-wider">
                            Suscripción PRO Activada
                          </p>
                          <p className="text-[9px] text-gray-300 font-mono">
                            Todas las funciones de pago están 100% desbloqueadas
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setSubscription('free');
                          localStorage.setItem('sono_subscription', 'free');
                          alert('Se ha restablecido la suscripción al modo básico.');
                        }}
                        className="text-[9px] text-gray-400 hover:text-red-400 underline font-mono"
                      >
                        Bloquear
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="password"
                          inputMode="numeric"
                          maxLength={12}
                          value={plansKeyInput}
                          onChange={(e) => {
                            setPlansKeyInput(e.target.value);
                            setPlansKeyError(null);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleUnlockPlansWithKey();
                          }}
                          placeholder="Ingresa clave (369174)..."
                          className="bg-black/80 border border-gray-700 focus:border-[#00ff88] text-white text-xs font-mono tracking-widest px-3 py-2.5 rounded-xl flex-1 outline-none"
                        />
                        <button
                          onClick={handleUnlockPlansWithKey}
                          className="bg-[#00ff88] hover:bg-[#00ff88]/80 text-black font-black text-xs px-4 py-2.5 rounded-xl uppercase tracking-wider transition shadow-[0_0_15px_rgba(0,255,136,0.3)] whitespace-nowrap"
                        >
                          Activar PRO
                        </button>
                      </div>
                      {plansKeyError && (
                        <p className="text-[10px] text-red-400 font-bold flex items-center gap-1">
                          ⚠️ {plansKeyError}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'contacts' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#9D00FF] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(157,0,255,0.2)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 border-b border-[#9D00FF]/30 pb-3">
                <h3 className="text-[#9D00FF] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Users className="w-5 h-5" /> Módulo Único de Agenda y Contactos por ID
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/50 text-[#9D00FF] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 space-y-4">
                <div className="bg-black/60 border border-[#9D00FF]/40 p-4 rounded-2xl space-y-3 shadow-[0_0_15px_rgba(157,0,255,0.1)]">
                  <h4 className="text-[10px] text-[#00ff88] font-black uppercase tracking-widest">+ Registrar Nuevo Operador / Contacto</h4>
                  <div className="flex flex-col md:flex-row gap-2">
                    <input 
                      type="text" 
                      value={newContactName}
                      onChange={(e) => setNewContactName(e.target.value)}
                      placeholder="Nombre o Indicativo del Operador"
                      className="bg-black/80 border border-gray-700 focus:border-[#9D00FF] rounded-xl px-3 py-2.5 text-xs text-white outline-none flex-1 font-medium"
                    />
                    <input 
                      type="text" 
                      value={newContactId}
                      onChange={(e) => setNewContactId(e.target.value)}
                      placeholder="SONO-ID-XXXX"
                      className="bg-black/80 border border-gray-700 focus:border-[#9D00FF] rounded-xl px-3 py-2.5 text-xs text-white outline-none w-full md:w-40 uppercase font-mono"
                    />
                  </div>
                  <button 
                    onClick={() => {
                      if (!newContactName.trim() || !newContactId.trim()) {
                        alert('Ingresa nombre e ID de contacto válidos.');
                        return;
                      }
                      const formattedId = newContactId.trim().toUpperCase();
                      if (!contacts.some(c => c.id === formattedId)) {
                        setContacts([...contacts, { id: formattedId, name: newContactName.trim() }]);
                        setNewContactName('');
                        setNewContactId('');
                        alert('¡Operador guardado correctamente en la agenda!');
                      } else {
                        alert('Este ID ya está registrado en tu agenda.');
                      }
                    }}
                    className="w-full bg-[#9D00FF]/20 hover:bg-[#9D00FF]/40 text-[#9D00FF] border border-[#9D00FF]/60 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition"
                  >
                    Guardar en Agenda Táctica
                  </button>
                </div>

                <div className="space-y-2">
                  <h4 className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Agenda Activa ({contacts.length})</h4>
                  {contacts.length === 0 ? (
                    <p className="text-xs text-gray-500 italic text-center py-8">No hay contactos guardados en este dispositivo.</p>
                  ) : (
                    contacts.map((contact) => (
                      <div key={contact.id} className="bg-black/40 border border-[#9D00FF]/30 hover:border-[#9D00FF] p-3.5 rounded-2xl flex items-center justify-between transition">
                        <div>
                          <div className="text-xs font-bold text-white">{contact.name}</div>
                          <div className="text-[10px] font-mono text-[#00ff88] tracking-widest">{contact.id}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => {
                              setChannelId(`ID-${contact.id}`);
                              if (socket) {
                                socket.emit('join-channel', `ID-${contact.id}`, username);
                              }
                              setActiveTab('main');
                              alert(`Sintonizado a frecuencia privada: ${contact.name} (${contact.id})`);
                            }}
                            className="bg-[#FF0044]/20 hover:bg-[#FF0044]/40 text-[#FF0044] border border-[#FF0044]/50 px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition"
                          >
                            Sintonizar
                          </button>
                          <button 
                            onClick={() => {
                              if (confirm(`¿Eliminar a ${contact.name} de tus contactos?`)) {
                                setContacts(contacts.filter(c => c.id !== contact.id));
                              }
                            }}
                            className="text-gray-500 hover:text-red-400 p-2 text-xs"
                            title="Eliminar"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'youtube' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#ff0055] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(255,0,85,0.3)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#ff0055]/30 pb-3">
                <h3 className="text-[#ff0055] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Tv className="w-5 h-5 animate-pulse" /> Módulo YouTube Music & Streaming
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#ff0055]/20 border border-[#ff0055]/50 text-[#ff0055] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              <YouTubeMusicPlayer />
            </div>
          )}

          {activeTab === 'gps' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#00ff88] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(0,255,136,0.3)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#00ff88]/30 pb-3">
                <h3 className="text-[#00ff88] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Navigation className="w-5 h-5 animate-pulse" /> MAPS_GPS_NAVEGADOR_REAL
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#00ff88]/20 border border-[#00ff88]/50 text-[#00ff88] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              <GpsNavigator />
            </div>
          )}

          {activeTab === 'diagnostics' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#9d00ff] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(157,0,255,0.3)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-4 border-b border-[#9d00ff]/30 pb-3">
                <h3 className="text-[#9d00ff] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <ShieldCheck className="w-5 h-5 animate-pulse" /> CORRECCIÓN_ERRORES_SISTEMA
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#9d00ff]/20 border border-[#9d00ff]/50 text-[#9d00ff] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>
              <SystemDiagnostics />
            </div>
          )}

          {activeTab === 'audiotest' && (
            <div className="w-full bg-[#110022]/95 border-2 border-[#00ff88] rounded-3xl p-5 flex flex-col relative z-20 shadow-[0_0_30px_rgba(0,255,136,0.2)] h-full overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 border-b border-[#00ff88]/30 pb-3">
                <h3 className="text-[#00ff88] font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center gap-3">
                  <Volume2 className="w-5 h-5 animate-pulse" /> Panel de Prueba de Audio y Altavoz Táctico
                </h3>
                <button onClick={() => setActiveTab('main')} className="p-1.5 rounded-full bg-black hover:bg-[#00ff88]/20 border border-[#00ff88]/50 text-[#00ff88] transition-all">
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center p-4 space-y-6 text-center">
                <div className="bg-black/60 border border-[#00ff88]/30 rounded-2xl p-6 max-w-sm w-full shadow-[0_0_20px_rgba(0,255,136,0.1)]">
                  <p className="text-xs text-gray-300 font-medium mb-4 leading-relaxed">
                    Mantén presionado el <span className="text-[#00ff88] font-bold">Obturador PTT Táctico</span> para grabar tu voz. Al soltarlo, se reproducirá <span className="text-[#FF0044] font-bold">automáticamente en alta voz</span> por el altavoz de tu dispositivo para verificar la calidad de salida y recepción.
                  </p>

                  <div className="relative mx-auto flex items-center justify-center w-36 h-36 my-6">
                    <div className={`absolute inset-0 rounded-full border-2 border-[#00ff88] ${isAudioTestRecording ? 'animate-ping opacity-40 bg-[#00ff88]/20' : 'opacity-20'}`}></div>
                    <button 
                      onMouseDown={startAudioTestRecording} 
                      onMouseUp={stopAudioTestRecording} 
                      onMouseLeave={stopAudioTestRecording}
                      onTouchStart={startAudioTestRecording} 
                      onTouchEnd={stopAudioTestRecording}
                      className={`relative z-10 w-32 h-32 rounded-full border-2 border-[#00ff88] flex flex-col items-center justify-center transition-all ${isAudioTestRecording ? 'bg-[#00ff88] text-black shadow-[0_0_40px_#00ff88] scale-95' : 'bg-[#110022] text-[#00ff88] hover:bg-[#00ff88]/10 shadow-[0_0_20px_rgba(0,255,136,0.3)]'}`}
                    >
                      <Mic className="w-10 h-10 mb-1" />
                      <span className="text-[10px] font-black uppercase tracking-widest">{isAudioTestRecording ? 'GRABANDO...' : 'MANTENER PTT'}</span>
                    </button>
                  </div>

                  {audioTestStatusText && (
                    <div className="bg-black/80 border border-[#00ff88]/50 rounded-xl py-2 px-3 text-[11px] font-mono text-[#00ff88] animate-pulse">
                      {audioTestStatusText}
                    </div>
                  )}

                  {audioTestUrl && (
                    <div className="mt-4 pt-4 border-t border-gray-800 flex flex-col gap-2">
                      <span className="text-[10px] text-gray-400 font-bold uppercase">Última Prueba Grabada:</span>
                      <button 
                        onClick={() => {
                          const audio = new Audio(audioTestUrl);
                          audio.volume = 1.0;
                          audio.play();
                          setAudioTestStatusText('🔊 Reproduciendo en altavoz a volumen máximo...');
                          audio.onended = () => setAudioTestStatusText('✅ Reproducción finalizada');
                        }}
                        className="w-full bg-[#00ff88]/20 hover:bg-[#00ff88]/40 text-[#00ff88] border border-[#00ff88]/60 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition flex items-center justify-center gap-2"
                      >
                        <Volume2 className="w-4 h-4" /> Reproducir de Nuevo en Altavoz
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Lower Section */}
        <div className="px-6 pb-6 mt-4">
          {activeTab === 'ai' ? (
             <form onSubmit={handleAskSonóZero} className="flex items-center gap-2 bg-[#110022]/90 border border-[#9D00FF]/50 rounded-full p-1.5 focus-within:border-[#FF0044] transition-all relative z-20">
               <Search className="w-4 h-4 text-[#9D00FF] ml-3 opacity-70" />
               <input value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} placeholder="Pregúntale a Sonó Zero..." className="flex-1 bg-transparent border-none outline-none text-sm text-white placeholder-gray-500" />
               <button type="submit" disabled={isAiLoading} className="bg-gradient-to-r from-[#9D00FF] to-[#FF0044] rounded-full px-5 py-2.5 text-[10px] font-bold uppercase tracking-widest text-white">{isAiLoading ? '...' : 'Send'}</button>
             </form>
          ) : (
            <>
              <div className="flex justify-between items-start mb-4">
                <div className="flex flex-col gap-1">
                  <div className="text-sm font-bold tracking-widest flex items-center gap-2">
                    <span className="text-white">{speakerName || displayName || username}</span>
                    <span className="w-3 h-3 bg-[#FF0044] transform rotate-45 inline-block animate-pulse"></span>
                    <span className="text-gray-400">{speakerName ? 'Hablando' : 'En línea'}</span>
                  </div>
                  {!speakerName && tacticalBio && (
                    <p className="text-[9px] text-[#9D00FF] font-medium tracking-wide uppercase italic ml-1">
                      "{tacticalBio}"
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-[1fr_auto] gap-4">
                {/* User List with Direct Call Buttons */}
                <div className="space-y-2 h-[120px] overflow-y-auto pr-2 custom-scrollbar">
                  {/* Mock Users */}
                  {mockUsers.map((u, i) => (
                    <div key={i} className="flex items-center justify-between border border-[#9D00FF]/40 bg-[#110022]/80 rounded-full px-3 py-1.5">
                      <div className="flex items-center gap-2">
                        {u.state === 'listening' ? <Volume2 className="w-3 h-3 text-gray-400" /> : <VolumeX className="w-3 h-3 text-[#9D00FF]" />}
                        <span className="text-xs font-bold text-white tracking-wide">{u.name}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                         <span className="text-[8px] uppercase tracking-widest text-gray-500 mr-2">{u.status}</span>
                         <button onMouseDown={() => alert("El bot no puede recibir radio.")} className="p-1.5 rounded-full bg-black hover:bg-[#FFD700]/20 border border-[#FFD700]/50" title="Radio Privada"><Mic className="w-3 h-3 text-[#FFD700]" /></button>
                         <button onClick={() => alert("El bot no puede contestar llamadas.")} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF]/30"><Phone className="w-3 h-3 text-[#9D00FF]" /></button>
                         <button onClick={() => alert("El bot no puede contestar videollamadas.")} className="p-1.5 rounded-full bg-black hover:bg-[#FF0044]/20 border border-[#FF0044]/30"><Video className="w-3 h-3 text-[#FF0044]" /></button>
                      </div>
                    </div>
                  ))}
                  {/* Real Online Users */}
                  {channelUsers.filter(name => !blockedUsers.includes(name)).map(name => (
                     <div key={name} className="flex items-center justify-between border border-[#FF0044]/60 bg-[#1a0008]/80 rounded-full px-3 py-1.5 shadow-[0_0_10px_rgba(255,0,68,0.1)]">
                       <div className="flex items-center gap-2">
                         <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                         <span className="text-xs font-bold text-white tracking-wide">{name}</span>
                       </div>
                       <div className="flex items-center gap-1.5">
                          <button onClick={() => handleBlock(name)} className="p-1.5 rounded-full bg-black hover:bg-[#FF0044]/20 border border-[#FF0044] shadow-[0_0_5px_#FF0044]" title="Bloquear Usuario"><Ban className="w-3 h-3 text-[#FF0044]" /></button>
                          <button 
                            onMouseDown={() => startRecording(name)} 
                            onMouseUp={stopRecording}
                            onMouseLeave={stopRecording}
                            className={`p-1.5 rounded-full bg-black border shadow-[0_0_5px_#FFD700] transition-all ${privateTargetRef.current === name ? 'bg-[#FFD700] border-[#FFD700]' : 'hover:bg-[#FFD700]/20 border-[#FFD700]'}`} 
                            title="Radio Privada (Mantener para hablar)"
                          >
                            <Mic className={`w-3 h-3 ${privateTargetRef.current === name ? 'text-black' : 'text-[#FFD700]'}`} />
                          </button>
                          <button onClick={() => initiateCall(name, 'voice')} className="p-1.5 rounded-full bg-black hover:bg-[#9D00FF]/20 border border-[#9D00FF] shadow-[0_0_5px_#9D00FF]"><Phone className="w-3 h-3 text-white" /></button>
                          <button onClick={() => initiateCall(name, 'video')} className="p-1.5 rounded-full bg-black hover:bg-[#FF0044]/20 border border-[#FF0044] shadow-[0_0_5px_#FF0044]"><Video className="w-3 h-3 text-white" /></button>
                       </div>
                     </div>
                  ))}
                </div>

                {/* Right: Actions */}
                <div className="space-y-2 flex flex-col justify-start">
                  <button onClick={() => setIsMuted(!isMuted)} className="w-full border border-[#FF0044]/40 bg-[#1a0008]/80 hover:bg-[#FF0044]/20 rounded-full px-4 py-2 text-[10px] font-bold tracking-widest uppercase text-white transition">
                    {isMuted ? 'Activar Todo' : 'Silenciar'}
                  </button>
                  <button onClick={() => setActiveTab('history')} className="w-full border border-[#FF0044]/40 bg-[#1a0008]/80 hover:bg-[#FF0044]/20 rounded-full px-4 py-2 text-[10px] font-bold tracking-widest uppercase text-[#FF0044] transition">
                    Ver Historial
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer Info */}
        <div className="border-t border-[#9D00FF]/30 mx-6 py-4 flex flex-col items-center gap-2 text-center">
          <div className="text-[10px] font-bold tracking-widest uppercase text-white flex items-center gap-2">
            Modo: <span className="w-2 h-2 bg-[#FF0044] transform rotate-45"></span> Internet + LoRa Híbrido
          </div>
          <div className="flex items-center justify-center gap-4 text-[9px] uppercase tracking-widest text-gray-400 border border-[#9D00FF]/20 rounded-full px-4 py-1.5 w-full bg-black/40">
            <Search className="w-3 h-3 text-[#9D00FF]" />
            <span className="flex items-center gap-1.5">
              Red: <div className={`w-2 h-2 rounded-full ${!latency ? 'bg-gray-500' : latency < 100 ? 'bg-green-500' : latency < 300 ? 'bg-yellow-500' : 'bg-red-500'}`}></div> {latency || 0}ms
            </span>
            <span>•</span>
            <span>Batería: {batteryLevel !== null ? `${batteryLevel}%${isCharging ? ' ⚡' : ''}` : '86%'}</span>
          </div>
        </div>
      </div>

      {/* PRO Required Modal */}
      {showProModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#110022] border-2 border-[#FF0044] rounded-[32px] p-8 max-w-sm w-full text-center shadow-[0_0_50px_rgba(255,0,68,0.3)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#FF0044] to-transparent"></div>
            <div className="w-20 h-20 mx-auto bg-[#FF0044]/10 rounded-full flex items-center justify-center border border-[#FF0044]/30 mb-6 shadow-[inset_0_0_20px_rgba(255,0,68,0.2)]">
              <Crown className="w-10 h-10 text-[#FF0044]" />
            </div>
            <h2 className="text-xl font-black text-white uppercase tracking-widest mb-2">Acceso PRO Requerido</h2>
            <p className="text-xs text-gray-400 mb-4 font-medium px-2">
              Ingresa tu clave de activación autorizada para desbloquear todas las funciones de pago o suscríbete por <span className="text-[#00ff88] font-bold">$200 MXN/mes</span>.
            </p>

            {/* 🔑 DESBLOQUEO INMEDIATO CON CLAVE EN EL MODAL */}
            <div className="bg-black/70 border border-[#00ff88]/50 rounded-2xl p-3.5 mb-4 text-left shadow-[0_0_20px_rgba(0,255,136,0.15)]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black text-[#00ff88] uppercase tracking-wider flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5" /> Clave de Suscripción
                </span>
                <span className="text-[9px] font-mono text-[#00ff88] bg-[#00ff88]/10 px-2 py-0.5 rounded border border-[#00ff88]/30 font-bold">
                  369174
                </span>
              </div>
              <div className="flex gap-2">
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={10}
                  value={modalKeyInput}
                  onChange={(e) => {
                    setModalKeyInput(e.target.value);
                    setModalKeyError(null);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleUnlockWithModalKey();
                  }}
                  placeholder="Ingresa 369174..."
                  className="bg-black border border-gray-700 focus:border-[#00ff88] text-white text-xs font-mono tracking-widest px-3 py-2 rounded-xl flex-1 outline-none text-center"
                />
                <button
                  onClick={handleUnlockWithModalKey}
                  className="bg-[#00ff88] hover:bg-[#00ff88]/80 text-black text-xs font-black px-3.5 py-2 rounded-xl uppercase tracking-wider transition shadow-[0_0_12px_rgba(0,255,136,0.3)] whitespace-nowrap"
                >
                  Desbloquear
                </button>
              </div>
              {modalKeyError && (
                <p className="text-[9px] text-red-400 font-bold mt-1.5 flex items-center gap-1">
                  ⚠️ {modalKeyError}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2.5">
              <button 
                onClick={() => {
                  setShowProModal(false);
                  setActiveTab('plans');
                }} 
                className="w-full bg-[#FF0044] hover:bg-[#FF0044]/80 text-white font-bold py-3.5 rounded-xl uppercase tracking-widest text-xs transition shadow-[0_0_15px_rgba(255,0,68,0.4)]"
              >
                Ver Planes y Suscripción
              </button>
              <button 
                onClick={() => setShowProModal(false)} 
                className="w-full bg-transparent hover:bg-white/5 border border-gray-700 text-gray-400 font-bold py-3 rounded-xl uppercase tracking-widest text-xs transition"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contacts Modal */}
      {showContactsModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#110022] border-2 border-[#9D00FF] rounded-[32px] p-6 max-w-md w-full shadow-[0_0_50px_rgba(157,0,255,0.3)] relative overflow-hidden flex flex-col max-h-[80vh]">
            <div className="flex justify-between items-center mb-4 border-b border-[#9D00FF]/30 pb-3">
              <h3 className="text-white font-black text-sm uppercase tracking-widest flex items-center gap-2">
                👥 Agenda de Contactos por ID
              </h3>
              <button 
                onClick={() => setShowContactsModal(false)}
                className="text-gray-400 hover:text-white text-xs font-bold px-2 py-1 bg-black/50 rounded-lg border border-gray-700"
              >
                ✕ Cerrar
              </button>
            </div>

            {/* Add Contact Form */}
            <div className="bg-black/60 border border-[#9D00FF]/40 p-4 rounded-2xl mb-4 space-y-3">
              <h4 className="text-[10px] text-[#00ff88] font-black uppercase tracking-widest">Añadir Nuevo Contacto</h4>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  placeholder="Nombre / Operador"
                  className="bg-black/80 border border-gray-700 focus:border-[#00ff88] rounded-xl px-3 py-2 text-xs text-white outline-none flex-1 font-medium"
                />
                <input 
                  type="text" 
                  value={newContactId}
                  onChange={(e) => setNewContactId(e.target.value)}
                  placeholder="SONO-ID-XXXX"
                  className="bg-black/80 border border-gray-700 focus:border-[#00ff88] rounded-xl px-3 py-2 text-xs text-white outline-none w-32 uppercase font-mono"
                />
              </div>
              <button 
                onClick={() => {
                  if (!newContactName.trim() || !newContactId.trim()) {
                    alert('Ingresa nombre e ID de contacto válidos.');
                    return;
                  }
                  const formattedId = newContactId.trim().toUpperCase();
                  if (!contacts.some(c => c.id === formattedId)) {
                    setContacts([...contacts, { id: formattedId, name: newContactName.trim() }]);
                    setNewContactName('');
                    setNewContactId('');
                    alert('¡Contacto añadido correctamente!');
                  } else {
                    alert('Este ID ya está registrado en tu agenda.');
                  }
                }}
                className="w-full bg-[#00ff88]/20 hover:bg-[#00ff88]/40 text-[#00ff88] border border-[#00ff88]/50 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition"
              >
                + Guardar Contacto en Agenda
              </button>
            </div>

            {/* Contacts List */}
            <div className="flex-1 overflow-y-auto space-y-2 custom-scrollbar pr-1">
              <h4 className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-2">Tus Contactos Guardados ({contacts.length})</h4>
              {contacts.length === 0 ? (
                <p className="text-xs text-gray-500 italic text-center py-6">No hay contactos guardados.</p>
              ) : (
                contacts.map((contact) => (
                  <div key={contact.id} className="bg-black/40 border border-[#9D00FF]/20 hover:border-[#9D00FF] p-3 rounded-xl flex items-center justify-between transition">
                    <div>
                      <div className="text-xs font-bold text-white">{contact.name}</div>
                      <div className="text-[10px] font-mono text-[#00ff88] tracking-widest">{contact.id}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => {
                          setChannelId(`ID-${contact.id}`);
                          if (socket) {
                            socket.emit('join-channel', `ID-${contact.id}`, username);
                          }
                          setShowContactsModal(false);
                          alert(`Conectado a frecuencia de contacto: ${contact.name} (${contact.id})`);
                        }}
                        className="bg-[#FF0044]/20 hover:bg-[#FF0044]/40 text-[#FF0044] border border-[#FF0044]/50 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition"
                      >
                        Sintonizar
                      </button>
                      <button 
                        onClick={() => {
                          if (confirm(`¿Eliminar a ${contact.name} de tus contactos?`)) {
                            setContacts(contacts.filter(c => c.id !== contact.id));
                          }
                        }}
                        className="text-gray-500 hover:text-red-400 p-1 text-xs"
                        title="Eliminar"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tutorial Interactivo y Guía Paso a Paso */}
      <TutorialModal
        isOpen={showTutorial}
        onClose={handleCloseTutorial}
        onUnlockPro={handleUnlockFromTutorial}
        isPro={subscription === 'pro'}
        channelId={channelId}
      />

      {/* Persistent Bottom Navigation Bar (7 Interface Layers) */}
      <div className="absolute bottom-0 left-0 w-full bg-[#0d001a]/95 border-t border-[#9D00FF]/40 backdrop-blur-xl px-2 py-3 flex items-center justify-around z-50 shadow-[0_-5px_25px_rgba(157,0,255,0.2)]">
        <button 
          onClick={() => { speakLabel("Audio PTT"); setActiveTab('main'); }}
          className={`flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl transition ${activeTab === 'main' ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/50 shadow-[0_0_15px_rgba(0,255,136,0.3)]' : 'text-gray-400 hover:text-white'}`}
          title="Capa 1: Audio y PTT"
        >
          <Mic className="w-5 h-5" />
          <span className="text-[9px] font-black uppercase tracking-wider">Audio</span>
        </button>

        <button 
          onClick={() => { speakLabel("Contactos"); setActiveTab('contacts'); }}
          className={`flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl transition ${activeTab === 'contacts' ? 'bg-[#00d4ff]/20 text-[#00d4ff] border border-[#00d4ff]/50 shadow-[0_0_15px_rgba(0,212,255,0.3)]' : 'text-gray-400 hover:text-white'}`}
          title="Capa 2: Contactos y Grupos"
        >
          <Users className="w-5 h-5" />
          <span className="text-[9px] font-black uppercase tracking-wider">Contactos</span>
        </button>

        <button 
          onClick={() => { speakLabel("LoRa y Malla"); setActiveTab('sonar'); }}
          className={`flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl transition ${activeTab === 'sonar' ? 'bg-[#9D00FF]/20 text-[#9D00FF] border border-[#9D00FF]/50 shadow-[0_0_15px_rgba(157,0,255,0.3)]' : 'text-gray-400 hover:text-white'}`}
          title="Capa 3: LoRa y Señal"
        >
          <Radar className="w-5 h-5" />
          <span className="text-[9px] font-black uppercase tracking-wider">LoRa</span>
        </button>

        <button 
          onClick={() => { speakLabel("Sonó Zero IA"); setActiveTab('ai'); }}
          className={`flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl transition ${activeTab === 'ai' ? 'bg-[#FFD700]/20 text-[#FFD700] border border-[#FFD700]/50 shadow-[0_0_15px_rgba(255,215,0,0.3)]' : 'text-gray-400 hover:text-white'}`}
          title="Capa 4: Asistente IA"
        >
          <Bot className="w-5 h-5" />
          <span className="text-[9px] font-black uppercase tracking-wider">IA</span>
        </button>

        <button 
          onClick={() => { speakLabel("Alerta SOS"); triggerSOS(); }}
          className="flex flex-col items-center gap-1 px-2.5 py-1.5 rounded-xl bg-red-600/20 text-red-400 border border-red-500/60 hover:bg-red-600/40 shadow-[0_0_15px_rgba(255,0,0,0.4)] transition animate-pulse"
          title="Capa 5: Emergencias SOS"
        >
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <span className="text-[9px] font-black uppercase tracking-wider text-red-400">SOS</span>
        </button>

        <button 
          onClick={() => { speakLabel("Ajustes y Perfil"); setActiveTab('settings'); }}
          className={`flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl transition ${activeTab === 'settings' ? 'bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/50 shadow-[0_0_15px_rgba(168,85,247,0.3)]' : 'text-gray-400 hover:text-white'}`}
          title="Capa 6: Perfil y Ajustes"
        >
          <Settings className="w-5 h-5" />
          <span className="text-[9px] font-black uppercase tracking-wider">Ajustes</span>
        </button>

        <button 
          onClick={() => { speakLabel("Panel Supervisor"); setActiveTab('admin'); socket?.emit('get-admin-stats'); }}
          className={`flex flex-col items-center gap-1 px-2 py-1.5 rounded-xl transition ${activeTab === 'admin' ? 'bg-[#3b82f6]/20 text-[#3b82f6] border border-[#3b82f6]/50 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 'text-gray-400 hover:text-white'}`}
          title="Capa 7: Panel Supervisor"
        >
          <Shield className="w-5 h-5" />
          <span className="text-[9px] font-black uppercase tracking-wider">Admin</span>
        </button>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: rgba(0,0,0,0.2); border-radius: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #9D00FF; border-radius: 4px; }
      `}</style>
    </div>
  );
}
