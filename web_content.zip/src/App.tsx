import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { ChatInput } from './components/ChatInput';
import { VoiceModal } from './components/VoiceModal';
import { ImageStudio } from './components/ImageStudio';
import { GoogleMapsView } from './components/GoogleMapsView';
import { GoogleFormsView } from './components/GoogleFormsView';
import { FileViewerModal } from './components/FileViewerModal';
import { AuthModal } from './components/AuthModal';
import { SettingsModal } from './components/SettingsModal';
import { ChatSession, Message, Attachment, GeneratedImage } from './types/chat';
import { User, UserSettings, UserMemory } from './types/auth';
import { storage } from './lib/storage';
import { authClient, defaultSettings } from './lib/authClient';
import { synthesizeSpeech } from './lib/audioRecorder';
import { globalSpeechPlayer } from './lib/speechPlayer';

export default function App() {
  // Auth & User State
  const [user, setUser] = useState<User | null>(null);
  const [userSettings, setUserSettings] = useState<UserSettings>(() => {
    return authClient.getStoredSettings() || defaultSettings;
  });
  const [memories, setMemories] = useState<UserMemory[]>([]);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAuthChecking, setIsAuthChecking] = useState(true);

  // Dynamic Theme state
  const isLight =
    userSettings.theme === 'light' ||
    (userSettings.theme === 'system' &&
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-color-scheme: light)').matches);

  useEffect(() => {
    if (isLight) {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    }
  }, [isLight]);

  // Chat State
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'images' | 'maps' | 'forms'>('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [viewingAttachment, setViewingAttachment] = useState<Attachment | null>(null);

  // Streaming State
  const [isLoading, setIsLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');

  // Keyboard shortcuts (Ctrl+B to toggle sidebar, Ctrl+N for new chat)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        setIsSidebarOpen((prev) => !prev);
      }
      if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'n' || e.key.toLowerCase() === 'k')) {
        e.preventDefault();
        handleNewChat();
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  // WebSocket reference
  const wsRef = useRef<WebSocket | null>(null);

  // Stop & cancellation refs
  const abortControllerRef = useRef<AbortController | null>(null);
  const currentStreamingSessionIdRef = useRef<string | null>(null);
  const currentStreamingMessagesWithUserRef = useRef<Message[]>([]);
  const currentStreamingAccumulatedRef = useRef<string>('');
  const cleanupWsRef = useRef<(() => void) | null>(null);

  const handleStopGeneration = () => {
    if (!isLoading) return;

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      try {
        wsRef.current.send(
          JSON.stringify({
            type: 'stop',
            chatId: currentStreamingSessionIdRef.current || activeSessionId,
          })
        );
      } catch (e) {}
    }

    if (cleanupWsRef.current) {
      cleanupWsRef.current();
      cleanupWsRef.current = null;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    const sessionId = currentStreamingSessionIdRef.current || activeSessionId;
    const accumulated = currentStreamingAccumulatedRef.current || streamingMessage;
    const messagesWithUser = currentStreamingMessagesWithUserRef.current;

    if (sessionId && messagesWithUser.length > 0) {
      finalizeAssistantMessage(
        sessionId,
        messagesWithUser,
        accumulated.trim() || 'تم إيقاف توليد الإجابة.'
      );
    } else {
      setIsLoading(false);
      setStreamingMessage('');
    }
  };

  // Check Authentication Status on Startup
  useEffect(() => {
    authClient.setOnUnauthorized(() => {
      setUser(null);
      setIsAuthModalOpen(true);
    });

    authClient
      .getCurrentUser()
      .then((authData) => {
        if (authData) {
          setUser(authData.user);
          setUserSettings(authData.settings || defaultSettings);
          setMemories(authData.memories || []);
          setIsAuthModalOpen(false);
          loadUserSessions();
        } else {
          setUser(null);
          setIsAuthModalOpen(true);
        }
      })
      .catch(() => {
        setUser(null);
        setIsAuthModalOpen(true);
      })
      .finally(() => {
        setIsAuthChecking(false);
      });
  }, []);

  const loadUserSessions = () => {
    const freshSession: ChatSession = {
      id: `chat-${Date.now()}`,
      title: 'محادثة جديدة',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    };

    setActiveSessionId(freshSession.id);

    storage.fetchServerSessions().then((remoteSessions) => {
      if (remoteSessions && remoteSessions.length > 0) {
        const validSessions = remoteSessions.filter(
          (s) => s.messages && s.messages.length > 0
        );
        setSessions([freshSession, ...validSessions]);
      } else {
        setSessions([freshSession]);
      }
    });
  };

  // Connect WebSocket for ultra-low latency streaming
  useEffect(() => {
    let ws: WebSocket;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        const pingInterval = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ping' }));
          }
        }, 25000);

        (ws as any)._pingInterval = pingInterval;
      };

      ws.onerror = (e) => {
        console.warn('WebSocket error, falling back to SSE stream if needed', e);
      };

      ws.onclose = () => {
        if ((ws as any)._pingInterval) {
          clearInterval((ws as any)._pingInterval);
        }
      };
    } catch (e) {
      console.warn('Failed to initiate WebSocket:', e);
    }

    return () => {
      if (wsRef.current) {
        if ((wsRef.current as any)._pingInterval) {
          clearInterval((wsRef.current as any)._pingInterval);
        }
        wsRef.current.close();
      }
    };
  }, []);

  // Auth Handlers
  const handleAuthSuccess = (data: { user: User; settings: UserSettings; memories: UserMemory[] }) => {
    setUser(data.user);
    setUserSettings(data.settings || defaultSettings);
    setMemories(data.memories || []);
    setIsAuthModalOpen(false);
    loadUserSessions();
  };

  const handleLogout = async () => {
    await authClient.logout();
    setUser(null);
    setSessions([]);
    storage.clearLocalSessions();
    setIsSidebarOpen(false);
    setIsSettingsModalOpen(false);
    setIsAuthModalOpen(true);
  };

  const handleUpdateProfile = async (newName: string, newAvatar?: string) => {
    const updated = await authClient.updateProfile(newName, newAvatar);
    setUser(updated);
  };

  const handleUpdateSettings = async (partial: Partial<UserSettings>) => {
    const updated = await authClient.updateSettings(partial);
    setUserSettings(updated);
  };

  const handleAddMemory = async (text: string) => {
    const memory = await authClient.addMemory(text);
    setMemories((prev) => [memory, ...prev]);
  };

  const handleDeleteMemory = async (id: string) => {
    await authClient.deleteMemory(id);
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  const handleClearAllMemories = async () => {
    await authClient.clearAllMemories();
    setMemories([]);
  };

  const handleDeleteAccount = async () => {
    await authClient.deleteAccount();
    setUser(null);
    setSessions([]);
    storage.clearLocalSessions();
    setIsSidebarOpen(false);
    setIsSettingsModalOpen(false);
    setIsAuthModalOpen(true);
  };

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0] || null;

  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
    storage.setActiveSessionId(id);
    setStreamingMessage('');
    setIsLoading(false);
  };

  const handleNewChat = () => {
    setSessions((prevSessions) => {
      const current = prevSessions.find((s) => s.id === activeSessionId);
      if (current && current.messages.length === 0) {
        return prevSessions;
      }

      const newSession: ChatSession = {
        id: `chat-${Date.now()}`,
        title: 'محادثة جديدة',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
      };

      const validExisting = prevSessions.filter((s) => s.messages && s.messages.length > 0);
      setActiveSessionId(newSession.id);
      storage.setActiveSessionId(newSession.id);
      return [newSession, ...validExisting];
    });
  };

  const handleDeleteSession = (id: string) => {
    // 1. Immediately delete from server
    storage.deleteServerSession(id);

    // 2. Safely update local state without closure races
    setSessions((prevSessions) => {
      const remaining = prevSessions.filter((s) => s.id !== id);
      storage.setLocalSessions(remaining.filter((s) => s.messages && s.messages.length > 0));

      if (activeSessionId === id) {
        if (remaining.length > 0) {
          const nextActive = remaining[0];
          setActiveSessionId(nextActive.id);
          storage.setActiveSessionId(nextActive.id);
          return remaining;
        } else {
          // If no sessions remain, create a clean initial session
          const freshSession: ChatSession = {
            id: `chat-${Date.now()}`,
            title: 'محادثة جديدة',
            createdAt: Date.now(),
            updatedAt: Date.now(),
            messages: [],
          };
          setActiveSessionId(freshSession.id);
          storage.setActiveSessionId(freshSession.id);
          return [freshSession];
        }
      }

      return remaining;
    });
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) =>
        s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s
      );
      storage.setLocalSessions(updated.filter((s) => s.messages && s.messages.length > 0));
      const session = updated.find((s) => s.id === id);
      if (session) storage.updateServerSession(session);
      return updated;
    });
  };

  const handleClearAllSessions = () => {
    const freshSession: ChatSession = {
      id: `chat-${Date.now()}`,
      title: 'محادثة جديدة',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    };
    setSessions([freshSession]);
    setActiveSessionId(freshSession.id);
    storage.clearAllServerSessions();
  };

  const handleDeleteMessage = (messageId: string) => {
    if (!activeSession) return;
    const currentSessionId = activeSession.id;

    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === currentSessionId) {
          const updatedMessages = s.messages.filter((m) => m.id !== messageId);
          const updatedSession = { ...s, messages: updatedMessages, updatedAt: Date.now() };
          storage.updateServerSession(updatedSession);
          return updatedSession;
        }
        return s;
      });
      storage.setLocalSessions(updated.filter((s) => s.messages && s.messages.length > 0));
      return updated;
    });

    storage.deleteServerMessage(currentSessionId, messageId);
  };

  const handleClearChat = () => {
    if (!activeSession) return;
    const currentSessionId = activeSession.id;

    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === currentSessionId) {
          const updatedSession = {
            ...s,
            title: 'محادثة جديدة',
            messages: [],
            updatedAt: Date.now(),
          };
          storage.updateServerSession(updatedSession);
          return updatedSession;
        }
        return s;
      });
      storage.setLocalSessions(updated);
      return updated;
    });

    storage.clearServerMessages(currentSessionId);
  };

  const handleSendMessage = async (content: string, attachments: Attachment[]) => {
    if (!activeSession || isLoading) return;

    // Check auth
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }

    const currentSessionId = activeSession.id;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content,
      timestamp: Date.now(),
      attachments: attachments.length > 0 ? attachments : undefined,
    };

    let sessionTitle = activeSession.title;
    if (activeSession.messages.length === 0) {
      sessionTitle = content.slice(0, 28) || (attachments.length > 0 ? attachments[0].name : 'محادثة جديدة');
    }

    // Capture the full message list including the user's new message
    const messagesWithUser = [...activeSession.messages, userMsg];

    // Immediately render user's message in UI and persist to storage
    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === currentSessionId) {
          const sessionWithUser = {
            ...s,
            title: sessionTitle,
            messages: messagesWithUser,
            updatedAt: Date.now(),
          };
          storage.updateServerSession(sessionWithUser);
          return sessionWithUser;
        }
        return s;
      });
      storage.setLocalSessions(updated);
      return updated;
    });

    setIsLoading(true);
    setStreamingMessage('');
    currentStreamingSessionIdRef.current = currentSessionId;
    currentStreamingMessagesWithUserRef.current = messagesWithUser;
    currentStreamingAccumulatedRef.current = '';

    const token = authClient.getStoredToken();
    const modelToUse = userSettings.preferredModel && userSettings.preferredModel !== 'gemini-2.5-flash'
      ? userSettings.preferredModel
      : 'gemini-3.8-flash';

    // High-speed SSE (Server-Sent Events) streaming with zero proxy buffering
    await streamViaSSE(currentSessionId, messagesWithUser, modelToUse, token);
  };

  const streamViaSSE = async (
    targetSessionId: string,
    messagesWithUser: Message[],
    modelToUse: string,
    token: string | null
  ) => {
    try {
      const controller = new AbortController();
      abortControllerRef.current = controller;

      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          messages: messagesWithUser,
          model: modelToUse,
          userSettings,
        }),
      });

      if (!response.ok) {
        throw new Error('فشل الاتصال بالخادم.');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';
      let groundingSources: any[] = [];
      let buffer = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          // Keep incomplete line segment in buffer
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('data: ')) {
              try {
                const data = JSON.parse(trimmed.slice(6));
                if (data.text) {
                  accumulatedText += data.text;
                  currentStreamingAccumulatedRef.current = accumulatedText;
                  setStreamingMessage(accumulatedText);
                }
                if (data.sources) {
                  groundingSources = data.sources;
                }
              } catch {}
            }
          }
        }

        // Flush any trailing line in buffer
        if (buffer.trim().startsWith('data: ')) {
          try {
            const data = JSON.parse(buffer.trim().slice(6));
            if (data.text) {
              accumulatedText += data.text;
              currentStreamingAccumulatedRef.current = accumulatedText;
              setStreamingMessage(accumulatedText);
            }
            if (data.sources) {
              groundingSources = data.sources;
            }
          } catch {}
        }
      }

      finalizeAssistantMessage(targetSessionId, messagesWithUser, accumulatedText, groundingSources);
    } catch (error: any) {
      if (error.name === 'AbortError') {
        if (currentStreamingAccumulatedRef.current) {
          finalizeAssistantMessage(
            targetSessionId,
            messagesWithUser,
            currentStreamingAccumulatedRef.current,
            []
          );
        } else {
          setIsLoading(false);
          setStreamingMessage('');
        }
        return; // user clicked stop
      }
      console.error('SSE Stream error:', error);
      finalizeAssistantMessage(
        targetSessionId,
        messagesWithUser,
        currentStreamingAccumulatedRef.current || 'عذراً، حدث خطأ أثناء الاتصال بالخادم. يرجى المحاولة مرة أخرى.'
      );
    } finally {
      abortControllerRef.current = null;
    }
  };

  const finalizeAssistantMessage = (
    targetSessionId: string,
    messagesWithUser: Message[],
    content: string,
    groundingSources?: any[]
  ) => {
    const assistantMsg: Message = {
      id: `msg-resp-${Date.now()}`,
      role: 'assistant',
      content: content || '...',
      timestamp: Date.now(),
      model: userSettings.preferredModel && userSettings.preferredModel !== 'gemini-2.5-flash'
        ? userSettings.preferredModel
        : 'gemini-3.8-flash',
      groundingSources: groundingSources && groundingSources.length > 0 ? groundingSources : undefined,
    };

    // Both user message(s) AND assistant message are preserved together!
    const finalMessages = [...messagesWithUser, assistantMsg];

    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === targetSessionId) {
          const finalSession = {
            ...s,
            messages: finalMessages,
            updatedAt: Date.now(),
          };
          storage.updateServerSession(finalSession);
          return finalSession;
        }
        return s;
      });
      storage.setLocalSessions(updated.filter((s) => s.messages && s.messages.length > 0));
      return updated;
    });

    setIsLoading(false);
    setStreamingMessage('');

    // Generate smart title asynchronously if this was the first user message in the session
    if (messagesWithUser.length === 1 && messagesWithUser[0].content) {
      const userPrompt = messagesWithUser[0].content;
      fetch(`/api/chats/${targetSessionId}/title`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(authClient.getStoredToken() ? { Authorization: `Bearer ${authClient.getStoredToken()}` } : {}),
        },
        body: JSON.stringify({ prompt: userPrompt }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data?.title) {
            setSessions((prevSessions) =>
              prevSessions.map((s) => (s.id === targetSessionId ? { ...s, title: data.title } : s))
            );
          }
        })
        .catch(() => {});
    }

    // Optional Auto-play TTS if enabled in user settings using fast-start SpeechPlayer
    if (userSettings.autoPlayAudio && userSettings.ttsEnabled && content && content.trim()) {
      globalSpeechPlayer.play(assistantMsg.id, content.trim(), {
        voice: userSettings.voiceName || 'Aoede',
        speed: userSettings.voiceSpeed || 1.0,
      });
    }
  };

  const handleRegenerateMessage = async (messageId?: string) => {
    if (!activeSession || isLoading) return;
    const currentSessionId = activeSession.id;

    let targetIndex = activeSession.messages.length - 1;
    if (messageId) {
      const found = activeSession.messages.findIndex((m) => m.id === messageId);
      if (found !== -1) targetIndex = found;
    }

    if (targetIndex < 0) return;
    const targetMsg = activeSession.messages[targetIndex];

    let messagesToRun: Message[] = [];
    if (targetMsg.role === 'assistant') {
      messagesToRun = activeSession.messages.slice(0, targetIndex);
    } else {
      messagesToRun = activeSession.messages.slice(0, targetIndex + 1);
    }

    if (messagesToRun.length === 0) return;

    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === currentSessionId) {
          const updatedSession = { ...s, messages: messagesToRun, updatedAt: Date.now() };
          storage.updateServerSession(updatedSession);
          return updatedSession;
        }
        return s;
      });
      storage.setLocalSessions(updated.filter((s) => s.messages && s.messages.length > 0));
      return updated;
    });

    setIsLoading(true);
    setStreamingMessage('');
    currentStreamingSessionIdRef.current = currentSessionId;
    currentStreamingMessagesWithUserRef.current = messagesToRun;
    const token = authClient.getStoredToken();
    const modelToUse = userSettings.preferredModel && userSettings.preferredModel !== 'gemini-2.5-flash'
      ? userSettings.preferredModel
      : 'gemini-3.8-flash';

    await streamViaSSE(currentSessionId, messagesToRun, modelToUse, token);
  };


  const handleAppendVoiceMessage = (first: string, second?: string) => {
    if (!activeSession) return;
    const currentSessionId = activeSession.id;

    let userMsg: Message | null = null;
    let assistantMsg: Message | null = null;

    if (first === 'user' && second) {
      userMsg = {
        id: `msg-${Date.now()}-u`,
        role: 'user',
        content: second,
        timestamp: Date.now(),
        isVoiceInput: true,
      };
    } else if (first === 'assistant' && second) {
      assistantMsg = {
        id: `msg-${Date.now()}-a`,
        role: 'assistant',
        content: second,
        timestamp: Date.now(),
        model: 'gemini-3.8-live',
      };
    } else if (second) {
      userMsg = {
        id: `msg-${Date.now()}-u`,
        role: 'user',
        content: first,
        timestamp: Date.now(),
        isVoiceInput: true,
      };
      assistantMsg = {
        id: `msg-${Date.now()}-a`,
        role: 'assistant',
        content: second,
        timestamp: Date.now(),
        model: 'gemini-3.8-live',
      };
    }

    const newMsgs = [userMsg, assistantMsg].filter(Boolean) as Message[];
    if (newMsgs.length === 0) return;

    setSessions((prevSessions) => {
      const updated = prevSessions.map((s) => {
        if (s.id === currentSessionId) {
          let sessionTitle = s.title;
          if (s.messages.length === 0 && userMsg?.content) {
            sessionTitle = userMsg.content.slice(0, 28) || 'محادثة صوتية';
          }
          const updatedSession = {
            ...s,
            title: sessionTitle,
            messages: [...s.messages, ...newMsgs],
            updatedAt: Date.now(),
          };
          storage.updateServerSession(updatedSession);
          return updatedSession;
        }
        return s;
      });
      storage.setLocalSessions(updated.filter((s) => s.messages && s.messages.length > 0));
      return updated;
    });
  };

  const handleSendImageToChat = (image: GeneratedImage) => {
    setActiveTab('chat');

    const imageAtt: Attachment = {
      id: `img-${Date.now()}`,
      name: `صورة: ${image.prompt.slice(0, 20)}`,
      type: 'image',
      mimeType: 'image/png',
      size: 1024 * 500,
      dataUrl: image.url,
    };

    handleSendMessage(
      `حلل هذه الصورة المولدة: "${image.prompt}"`,
      [imageAtt]
    );
  };

  return (
    <div
      className={`flex h-screen w-screen overflow-hidden ${
        isLight ? 'bg-slate-50 text-slate-800' : 'bg-[#0a0b0e] text-neutral-100'
      } font-sans select-none antialiased ${
        userSettings.fontSize === 'small'
          ? 'text-xs'
          : userSettings.fontSize === 'large'
          ? 'text-base'
          : 'text-sm'
      }`}
      dir="rtl"
    >
      {/* Sidebar Drawer */}
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onClearAllSessions={handleClearAllSessions}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        user={user}
        isLight={isLight}
        confirmBeforeDelete={userSettings.confirmBeforeDelete}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Chat Workspace */}
      <main className={`flex-1 flex flex-col h-full overflow-hidden relative ${isLight ? 'bg-white text-[#202123]' : 'bg-[#171717] text-[#ececec]'}`}>
        {activeTab === 'chat' ? (
          <>
            <ChatArea
              messages={activeSession?.messages || []}
              isLoading={isLoading}
              streamingMessage={streamingMessage}
              isLight={isLight}
              userSettings={userSettings}
              onDeleteMessage={handleDeleteMessage}
              onClearChat={handleClearChat}
              onNewChat={handleNewChat}
              onSelectPrompt={(prompt) => handleSendMessage(prompt, [])}
              onOpenSidebar={() => setIsSidebarOpen(true)}
              isSidebarOpen={isSidebarOpen}
              onViewAttachment={setViewingAttachment}
              currentTitle={activeSession?.title || ''}
              onRegenerate={handleRegenerateMessage}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            />

            <ChatInput
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
              isLight={isLight}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
              onStopGeneration={handleStopGeneration}
            />
          </>
        ) : activeTab === 'images' ? (
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            {/* Image Studio Top Bar */}
            <header className={`h-16 px-4 md:px-6 flex items-center justify-between border-b ${isLight ? 'border-slate-200 bg-white text-slate-800' : 'border-[#1c1c24] bg-[#0c0c0f] text-neutral-200'} shrink-0`}>
              <button
                onClick={() => setIsSidebarOpen(true)}
                className={`p-2 ${isLight ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100' : 'text-neutral-300 hover:text-white hover:bg-neutral-800'} rounded-lg transition-colors`}
                title="فتح القائمة الجانبية"
              >
                <span className="text-xl">☰</span>
              </button>
              <h2 className={`font-semibold ${isLight ? 'text-slate-900' : 'text-neutral-200'} text-sm md:text-base`}>
                استوديو توليد الصور
              </h2>
              <button
                onClick={() => setActiveTab('chat')}
                className={`text-xs ${isLight ? 'text-slate-500 hover:text-slate-800 hover:bg-slate-100' : 'text-neutral-400 hover:text-white hover:bg-neutral-800'} px-2 py-1 rounded`}
              >
                العودة للمحادثة
              </button>
            </header>
            <ImageStudio onSendToChat={handleSendImageToChat} />
          </div>
        ) : activeTab === 'maps' ? (
          <div className="flex-1 flex flex-col h-full overflow-hidden relative">
            {!isSidebarOpen && (
              <button
                onClick={() => setIsSidebarOpen(true)}
                className="absolute top-4 right-4 z-30 p-2.5 rounded-xl bg-slate-900/90 text-white border border-slate-700 shadow-xl hover:bg-slate-800 transition"
                title="فتح الشريط الجانبي"
              >
                <span className="text-base font-bold">☰</span>
              </button>
            )}
            <GoogleMapsView user={user} isLight={isLight} />
          </div>
        ) : (
          <div className="flex-1 flex flex-col h-full overflow-hidden relative">
            {!isSidebarOpen && (
              <button
                onClick={() => setIsSidebarOpen(true)}
                className="absolute top-4 right-4 z-30 p-2.5 rounded-xl bg-slate-900/90 text-white border border-slate-700 shadow-xl hover:bg-slate-800 transition"
                title="فتح الشريط الجانبي"
              >
                <span className="text-base font-bold">☰</span>
              </button>
            )}
            <GoogleFormsView user={user} isLight={isLight} />
          </div>
        )}
      </main>

      {/* Voice Conversation Interactive Screen Modal (Powered by Gemini 3.8 Live) */}
      <VoiceModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onAppendMessage={handleAppendVoiceMessage}
        defaultVoice={userSettings.voiceName || 'Zephyr'}
        isLight={isLight}
      />

      {/* File/Excel/Image Inspection Modal */}
      <FileViewerModal
        attachment={viewingAttachment}
        onClose={() => setViewingAttachment(null)}
      />

      {/* Complete Authentication Screen (appears when not logged in) */}
      <AuthModal
        isOpen={isAuthModalOpen && !isAuthChecking}
        onSuccess={handleAuthSuccess}
        isLight={isLight}
      />

      {/* Comprehensive Modern AI Settings Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        user={user}
        settings={userSettings}
        memories={memories}
        sessions={sessions}
        isLight={isLight}
        onUpdateSettings={handleUpdateSettings}
        onUpdateProfile={handleUpdateProfile}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
        onClearAllMemories={handleClearAllMemories}
        onClearAllSessions={handleClearAllSessions}
        onDeleteAccount={handleDeleteAccount}
        onLogout={handleLogout}
      />
    </div>
  );
}
