import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Layout } from './components/layout/Layout';

// Core pages
import { HomePage } from './pages/HomePage';
import { ExplorePage } from './pages/ExplorePage';
import { CategoriesPage } from './pages/CategoriesPage';
import { CategoryDetailPage } from './pages/CategoryDetailPage';
import { FormulaLibraryPage } from './pages/FormulaLibraryPage';
import { FormulaDetailPage } from './pages/FormulaDetailPage';
import { CalculatorPage } from './pages/CalculatorPage';
import { ScientificCalculatorPage } from './pages/ScientificCalculatorPage';
import { UnitConverterPage } from './pages/UnitConverterPage';
import { ToolsPage } from './pages/ToolsPage';
import { PracticePage } from './pages/PracticePage';
import { FavoritesPage } from './pages/FavoritesPage';
import { HistoryPage } from './pages/HistoryPage';
import { SettingsPage } from './pages/SettingsPage';
import { FeedbackPage } from './pages/FeedbackPage';
import { MorePage } from './pages/MorePage';

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="explore" element={<ExplorePage />} />
            <Route path="categories" element={<CategoriesPage />} />
            <Route path="category/:id" element={<CategoryDetailPage />} />
            <Route path="formulas" element={<FormulaLibraryPage />} />
            <Route path="formula/:id" element={<FormulaDetailPage />} />
            <Route path="calculator" element={<CalculatorPage />} />
            <Route path="calculator/:formulaId" element={<CalculatorPage />} />
            <Route path="scientific-calculator" element={<ScientificCalculatorPage />} />
            <Route path="unit-converter" element={<UnitConverterPage />} />
            <Route path="tools" element={<ToolsPage />} />
            <Route path="practice" element={<PracticePage />} />
            <Route path="favorites" element={<FavoritesPage />} />
            <Route path="history" element={<HistoryPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="feedback" element={<FeedbackPage />} />
            <Route path="more" element={<MorePage />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
}

