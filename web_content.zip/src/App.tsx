/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { AppData, RepeatConfig, TaskStatus, ToDoGroup, ToDoTask, WorkGroup, WorkTask } from './types.ts';
import { loadAppData, saveAppData } from './utils/storage.ts';
import { Header } from './components/Header.tsx';
import { Navigation, TabType } from './components/Navigation.tsx';
import { WorkTab } from './components/WorkTab.tsx';
import { ToDoTab } from './components/ToDoTab.tsx';
import { TodayTab } from './components/TodayTab.tsx';
import { ApkGuideModal } from './components/ApkGuideModal.tsx';
import { getTodayDateString } from './utils/dateUtils.ts';

export default function App() {
  const [data, setData] = useState<AppData>(() => loadAppData());

  // Navigation tab (Starts at 'today')
  const [activeTab, setActiveTab] = useState<TabType>('today');

  // Navigation within Work Tab
  const [selectedWorkGroupId, setSelectedWorkGroupId] = useState<string | null>(null);

  // Navigation within To Do Tab
  const [selectedToDoGroupId, setSelectedToDoGroupId] = useState<string | null>(null);
  const [selectedToDoTaskId, setSelectedToDoTaskId] = useState<string | null>(null);

  // Edit Mode state
  const [isEditMode, setIsEditMode] = useState<boolean>(false);

  // Reset confirmation state in Work tab
  const [showWorkResetConfirm, setShowWorkResetConfirm] = useState<boolean>(false);

  // APK Guide modal state
  const [showApkGuide, setShowApkGuide] = useState<boolean>(false);

  // Save changes to localStorage on any state modification
  const updateData = (newData: AppData) => {
    setData(newData);
    saveAppData(newData);
  };

  // Turn off edit mode whenever switching tabs or navigating up/down
  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    setIsEditMode(false);
  };

  // Back button handler
  const handleBack = () => {
    setIsEditMode(false);
    if (activeTab === 'work' && selectedWorkGroupId) {
      setSelectedWorkGroupId(null);
    } else if (activeTab === 'todo') {
      if (selectedToDoTaskId) {
        setSelectedToDoTaskId(null);
      } else if (selectedToDoGroupId) {
        setSelectedToDoGroupId(null);
      }
    }
  };

  // ================= WORK TAB HANDLERS =================
  const handleAddWorkGroup = (title: string) => {
    const newGroup: WorkGroup = {
      id: `wg-${Date.now()}`,
      title,
      order: data.workGroups.length,
      tasks: [],
    };
    updateData({
      ...data,
      workGroups: [...data.workGroups, newGroup],
    });
  };

  const handleUpdateWorkGroup = (groupId: string, title: string) => {
    const updated = data.workGroups.map((g) => (g.id === groupId ? { ...g, title } : g));
    updateData({ ...data, workGroups: updated });
  };

  const handleDeleteWorkGroup = (groupId: string) => {
    const updated = data.workGroups.filter((g) => g.id !== groupId);
    if (selectedWorkGroupId === groupId) {
      setSelectedWorkGroupId(null);
    }
    updateData({ ...data, workGroups: updated });
  };

  const handleReorderWorkGroups = (newGroups: WorkGroup[]) => {
    updateData({ ...data, workGroups: newGroups });
  };

  const handleAddWorkTask = (groupId: string, title: string, details?: string) => {
    const updated = data.workGroups.map((group) => {
      if (group.id !== groupId) return group;
      const newTask: WorkTask = {
        id: `wt-${Date.now()}`,
        groupId,
        title,
        details,
        completed: false,
        order: group.tasks.length,
      };
      return {
        ...group,
        tasks: [...group.tasks, newTask],
      };
    });
    updateData({ ...data, workGroups: updated });
  };

  const handleUpdateWorkTask = (
    groupId: string,
    taskId: string,
    title: string,
    details?: string
  ) => {
    const updated = data.workGroups.map((group) => {
      if (group.id !== groupId) return group;
      const newTasks = group.tasks.map((task) =>
        task.id === taskId ? { ...task, title, details } : task
      );
      return { ...group, tasks: newTasks };
    });
    updateData({ ...data, workGroups: updated });
  };

  const handleDeleteWorkTask = (groupId: string, taskId: string) => {
    const updated = data.workGroups.map((group) => {
      if (group.id !== groupId) return group;
      return {
        ...group,
        tasks: group.tasks.filter((t) => t.id !== taskId),
      };
    });
    updateData({ ...data, workGroups: updated });
  };

  const handleToggleWorkTask = (groupId: string, taskId: string) => {
    const updated = data.workGroups.map((group) => {
      if (group.id !== groupId) return group;
      const newTasks = group.tasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      );
      return { ...group, tasks: newTasks };
    });
    updateData({ ...data, workGroups: updated });
  };

  const handleReorderWorkTasks = (groupId: string, newTasks: WorkTask[]) => {
    const updated = data.workGroups.map((group) =>
      group.id === groupId ? { ...group, tasks: newTasks } : group
    );
    updateData({ ...data, workGroups: updated });
  };

  const handleResetGroupTasks = (groupId: string) => {
    const updated = data.workGroups.map((group) => {
      if (group.id !== groupId) return group;
      const uncompletedTasks = group.tasks.map((t) => ({ ...t, completed: false }));
      return { ...group, tasks: uncompletedTasks };
    });
    updateData({ ...data, workGroups: updated });
  };

  // ================= TO DO TAB HANDLERS =================
  const handleAddToDoGroup = (name: string, details?: string) => {
    const newGroup: ToDoGroup = {
      id: `tg-${Date.now()}`,
      name,
      details,
      order: data.todoGroups.length,
      tasks: [],
    };
    updateData({
      ...data,
      todoGroups: [...data.todoGroups, newGroup],
    });
  };

  const handleUpdateToDoGroup = (groupId: string, name: string, details?: string) => {
    const updated = data.todoGroups.map((g) => (g.id === groupId ? { ...g, name, details } : g));
    updateData({ ...data, todoGroups: updated });
  };

  const handleDeleteToDoGroup = (groupId: string) => {
    const deletedGroup = data.todoGroups.find((g) => g.id === groupId);
    const deletedTaskIds = new Set(deletedGroup?.tasks.map((t) => t.id) ?? []);
    const updated = data.todoGroups.filter((g) => g.id !== groupId);
    const updatedCustomOrder = data.todayCustomOrder.filter((id) => !deletedTaskIds.has(id));

    if (selectedToDoGroupId === groupId) {
      setSelectedToDoGroupId(null);
      setSelectedToDoTaskId(null);
    }

    updateData({
      ...data,
      todoGroups: updated,
      todayCustomOrder: updatedCustomOrder,
    });
  };

  const handleReorderToDoGroups = (newGroups: ToDoGroup[]) => {
    updateData({ ...data, todoGroups: newGroups });
  };

  const handleAddToDoTask = (
    groupId: string,
    name: string,
    details: string | undefined,
    repeat: RepeatConfig
  ) => {
    const today = getTodayDateString();
    const newTask: ToDoTask = {
      id: `tt-${Date.now()}`,
      groupId,
      name,
      details,
      repeat,
      createdAt: today,
      order: 0,
      reports: {},
      postponedDates: {},
    };

    const updated = data.todoGroups.map((group) => {
      if (group.id !== groupId) return group;
      newTask.order = group.tasks.length;
      return {
        ...group,
        tasks: [...group.tasks, newTask],
      };
    });

    const newCustomOrder = [...data.todayCustomOrder, newTask.id];

    updateData({
      ...data,
      todoGroups: updated,
      todayCustomOrder: newCustomOrder,
    });
  };

  const handleUpdateToDoTask = (
    groupId: string,
    taskId: string,
    name: string,
    details: string | undefined,
    repeat?: RepeatConfig
  ) => {
    const updated = data.todoGroups.map((group) => {
      if (group.id !== groupId) return group;
      const newTasks = group.tasks.map((task) => {
        if (task.id !== taskId) return task;
        return {
          ...task,
          name,
          details,
          repeat: repeat || task.repeat,
        };
      });
      return { ...group, tasks: newTasks };
    });
    updateData({ ...data, todoGroups: updated });
  };

  const handleDeleteToDoTask = (groupId: string, taskId: string) => {
    const updated = data.todoGroups.map((group) => {
      if (group.id !== groupId) return group;
      return {
        ...group,
        tasks: group.tasks.filter((t) => t.id !== taskId),
      };
    });
    const updatedCustomOrder = data.todayCustomOrder.filter((id) => id !== taskId);

    if (selectedToDoTaskId === taskId) {
      setSelectedToDoTaskId(null);
    }

    updateData({
      ...data,
      todoGroups: updated,
      todayCustomOrder: updatedCustomOrder,
    });
  };

  const handleReorderToDoTasks = (groupId: string, newTasks: ToDoTask[]) => {
    const updated = data.todoGroups.map((group) =>
      group.id === groupId ? { ...group, tasks: newTasks } : group
    );
    updateData({ ...data, todoGroups: updated });
  };

  const handleUpdateTaskReport = (
    groupId: string,
    taskId: string,
    dateStr: string,
    status: TaskStatus | null,
    postponedTo?: string
  ) => {
    const updated = data.todoGroups.map((group) => {
      if (group.id !== groupId) return group;
      const newTasks = group.tasks.map((task) => {
        if (task.id !== taskId) return task;

        const updatedReports = { ...(task.reports || {}) };
        const updatedPostponed = { ...(task.postponedDates || {}) };

        if (status === null) {
          // Clear report
          delete updatedReports[dateStr];
          delete updatedPostponed[dateStr];
        } else if (status === 'postponed' && postponedTo) {
          updatedReports[dateStr] = 'postponed';
          updatedPostponed[dateStr] = postponedTo;
        } else {
          updatedReports[dateStr] = status;
          delete updatedPostponed[dateStr];
        }

        return {
          ...task,
          reports: updatedReports,
          postponedDates: updatedPostponed,
        };
      });
      return { ...group, tasks: newTasks };
    });

    updateData({ ...data, todoGroups: updated });
  };

  const handleUpdateCustomOrder = (newOrder: string[]) => {
    updateData({ ...data, todayCustomOrder: newOrder });
  };

  // Determine header configuration based on active tab & subscreen
  let headerTitle = 'কাজের তালিকা ও রুটিন';
  let headerSubtitle = '';
  let showBack = false;
  let showReset = false;
  let showEdit = true;

  if (activeTab === 'today') {
    headerTitle = 'আজকের রুটিন';
    headerSubtitle = 'টুডে ট্যাব';
    showBack = false;
    showReset = false;
    showEdit = true;
  } else if (activeTab === 'work') {
    if (selectedWorkGroupId) {
      const currentGroup = data.workGroups.find((g) => g.id === selectedWorkGroupId);
      headerTitle = currentGroup?.title || 'ওয়ার্ক গ্রুপ';
      headerSubtitle = 'কাজের তালিকা';
      showBack = true;
      showReset = true;
      showEdit = true;
    } else {
      headerTitle = 'ওয়ার্ক গ্রুপসমূহ';
      headerSubtitle = 'দৈনিক চেকলিস্ট';
      showBack = false;
      showReset = false;
      showEdit = true;
    }
  } else if (activeTab === 'todo') {
    if (selectedToDoTaskId) {
      const currentGroup = data.todoGroups.find((g) => g.id === selectedToDoGroupId);
      const currentTask = currentGroup?.tasks.find((t) => t.id === selectedToDoTaskId);
      headerTitle = currentTask?.name || 'কাজের বিবরণ';
      headerSubtitle = currentGroup?.name || 'টু ডু';
      showBack = true;
      showReset = false;
      showEdit = false; // Task details page has its own tab controls
    } else if (selectedToDoGroupId) {
      const currentGroup = data.todoGroups.find((g) => g.id === selectedToDoGroupId);
      headerTitle = currentGroup?.name || 'টু ডু গ্রুপ';
      headerSubtitle = 'রুটিনের কাজসমূহ';
      showBack = true;
      showReset = false;
      showEdit = true;
    } else {
      headerTitle = 'টু ডু গ্রুপসমূহ';
      headerSubtitle = 'রুটিন ও শিডিউল';
      showBack = false;
      showReset = false;
      showEdit = true;
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans select-none">
      {/* Top Bar Header */}
      <Header
        title={headerTitle}
        subtitle={headerSubtitle}
        isEditMode={isEditMode}
        onToggleEditMode={() => setIsEditMode(!isEditMode)}
        showEditButton={showEdit}
        showResetButton={showReset}
        onReset={() => setShowWorkResetConfirm(true)}
        onBack={showBack ? handleBack : undefined}
        onOpenApkGuide={() => setShowApkGuide(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full max-w-md mx-auto">
        {activeTab === 'today' && (
          <TodayTab
            todoGroups={data.todoGroups}
            todayCustomOrder={data.todayCustomOrder}
            isEditMode={isEditMode}
            onUpdateTaskReport={handleUpdateTaskReport}
            onUpdateCustomOrder={handleUpdateCustomOrder}
          />
        )}

        {activeTab === 'work' && (
          <WorkTab
            groups={data.workGroups}
            selectedGroupId={selectedWorkGroupId}
            isEditMode={isEditMode}
            onSelectGroup={setSelectedWorkGroupId}
            onAddGroup={handleAddWorkGroup}
            onUpdateGroup={handleUpdateWorkGroup}
            onDeleteGroup={handleDeleteWorkGroup}
            onReorderGroups={handleReorderWorkGroups}
            onAddTask={handleAddWorkTask}
            onUpdateTask={handleUpdateWorkTask}
            onDeleteTask={handleDeleteWorkTask}
            onToggleTask={handleToggleWorkTask}
            onReorderTasks={handleReorderWorkTasks}
            onResetGroupTasks={handleResetGroupTasks}
            showResetConfirm={showWorkResetConfirm}
            setShowResetConfirm={setShowWorkResetConfirm}
          />
        )}

        {activeTab === 'todo' && (
          <ToDoTab
            groups={data.todoGroups}
            selectedGroupId={selectedToDoGroupId}
            selectedTaskId={selectedToDoTaskId}
            isEditMode={isEditMode}
            onSelectGroup={setSelectedToDoGroupId}
            onSelectTask={setSelectedToDoTaskId}
            onAddGroup={handleAddToDoGroup}
            onUpdateGroup={handleUpdateToDoGroup}
            onDeleteGroup={handleDeleteToDoGroup}
            onReorderGroups={handleReorderToDoGroups}
            onAddTask={handleAddToDoTask}
            onUpdateTask={handleUpdateToDoTask}
            onDeleteTask={handleDeleteToDoTask}
            onReorderTasks={handleReorderToDoTasks}
            onUpdateTaskReport={handleUpdateTaskReport}
          />
        )}
      </main>

      {/* Bottom Navigation (Always 3 tabs: Today, Work, To Do) */}
      <Navigation activeTab={activeTab} onChangeTab={handleTabChange} />

      {/* APK Guide Modal */}
      <ApkGuideModal isOpen={showApkGuide} onClose={() => setShowApkGuide(false)} />
    </div>
  );
}
