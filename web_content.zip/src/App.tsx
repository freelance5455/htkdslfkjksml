import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './i18n/index.ts';
import { SpaceType, RegulationTool, UserProfile } from './types/index.ts';
import { ALL_TOOLS } from './data/toolsData.ts';
import { storageService } from './lib/supabase.ts';

// Components
import { Header } from './components/Header.tsx';
import { EmergencyBanner } from './components/EmergencyBanner.tsx';
import { QuickCrisisBar } from './components/QuickCrisisBar.tsx';
import { SpaceAdult } from './components/SpaceAdult.tsx';
import { SpaceParents } from './components/SpaceParents.tsx';
import { ToolRunnerModal } from './components/ToolRunnerModal.tsx';
import { TherapistChatModal } from './components/TherapistChatModal.tsx';
import { JournalHistoryModal } from './components/JournalHistoryModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { EmergencyInfoModal } from './components/EmergencyInfoModal.tsx';
import { OnboardingModal } from './components/OnboardingModal.tsx';
import { Heart, Sparkles, Shield, PhoneCall } from 'lucide-react';

export default function App() {
  const { t } = useTranslation();

  // App Navigation & Space state
  const [currentSpace, setCurrentSpace] = useState<SpaceType>('adult');

  // Modal states
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(() => {
    return !storageService.isDisclaimerAccepted();
  });
  const [activeTool, setActiveTool] = useState<RegulationTool | null>(null);
  const [activeVersion, setActiveVersion] = useState<'short' | 'full'>('short');
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState<boolean>(false);

  // User and Favorites state
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    return storageService.getUserProfile();
  });
  const [favorites, setFavorites] = useState<string[]>(() => {
    return storageService.getFavorites();
  });

  // Dark Mode state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('coeur_regule_theme') === 'dark';
    }
    return false;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('coeur_regule_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('coeur_regule_theme', 'light');
    }
  }, [isDarkMode]);

  const handleAcceptDisclaimer = () => {
    storageService.setDisclaimerAccepted(true);
    setIsOnboardingOpen(false);
  };

  const handleOpenTool = (tool: RegulationTool, version: 'short' | 'full' = 'short') => {
    setActiveTool(tool);
    setActiveVersion(version);
  };

  const handleOpenToolById = (toolId: string, version: 'short' | 'full' = 'short') => {
    const found = ALL_TOOLS.find((t) => t.id === toolId);
    if (found) {
      // Automatically switch space if needed
      if (found.space !== currentSpace) {
        setCurrentSpace(found.space);
      }
      setActiveTool(found);
      setActiveVersion(version);
    }
  };

  const handleToggleFavorite = (toolId: string) => {
    storageService.toggleFavorite(toolId);
    setFavorites(storageService.getFavorites());
  };

  const handleToggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  return (
    <div className="min-h-screen bg-slate-50/60 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] transition-colors selection:bg-rose-200 selection:text-rose-900">
      {/* Top Accessible Emergency Hotline Banner */}
      <EmergencyBanner onOpenEmergencyModal={() => setIsEmergencyOpen(true)} />

      {/* Main App Navigation Header */}
      <Header
        currentSpace={currentSpace}
        onSelectSpace={setCurrentSpace}
        onOpenChat={() => setIsChatOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        userProfile={userProfile}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
      />

      {/* Main Application Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:py-8 space-y-8">
        {/* Quick Crisis Bar (6 Large High-Visibility Buttons) */}
        <QuickCrisisBar onTriggerAction={handleOpenToolById} />

        {/* Dynamic Space View */}
        {currentSpace === 'adult' ? (
          <SpaceAdult
            tools={ALL_TOOLS}
            onOpenTool={handleOpenTool}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
          />
        ) : (
          <SpaceParents
            tools={ALL_TOOLS}
            onOpenTool={handleOpenTool}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
          />
        )}
      </main>

      {/* Calming, Reassuring Footer */}
      <footer className="mt-16 bg-white dark:bg-slate-900 border-t border-rose-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-xs py-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div className="space-y-1">
            <div className="flex items-center justify-center md:justify-start gap-2 font-bold text-slate-800 dark:text-slate-200">
              <Heart className="w-4 h-4 text-rose-500 fill-current" />
              <span>Cœur Régulé</span>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">
                Approche Humaniste & Centrée sur le Cœur
              </span>
            </div>
            <p className="max-w-xl text-[11px] leading-relaxed">
              Outil thérapeutique d'accompagnement et de psycho-éducation. Ne remplace pas un suivi professionnel. En cas d'urgence ou de détresse psychologique importante, appelez le{' '}
              <a href="tel:3114" className="font-bold text-rose-600 dark:text-rose-400 underline">
                3114 (France)
              </a>{' '}
              ou le 112 (Europe).
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold">
            <button
              onClick={() => setIsEmergencyOpen(true)}
              className="text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Numéros d'urgence</span>
            </button>
            <button
              onClick={() => setIsChatOpen(true)}
              className="hover:text-slate-800 dark:hover:text-slate-200"
            >
              Thérapeute IA
            </button>
            <button
              onClick={() => setIsOnboardingOpen(true)}
              className="hover:text-slate-800 dark:hover:text-slate-200"
            >
              Avertissement déontologique
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      {/* 1. Mandatory Non-Skippable Onboarding Disclaimer */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onAccept={handleAcceptDisclaimer}
      />

      {/* 2. Interactive Tool Runner Modal (Short / Full + Before / After Rating + Pauses) */}
      <ToolRunnerModal
        tool={activeTool}
        initialVersion={activeVersion}
        onClose={() => setActiveTool(null)}
        onSessionSaved={() => {
          // Refresh favorites or history if needed
        }}
      />

      {/* 3. AI Therapist Chat with Crisis Detection & Tool Launching */}
      <TherapistChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        space={currentSpace}
        onOpenTool={(toolId) => {
          setIsChatOpen(false);
          handleOpenToolById(toolId);
        }}
      />

      {/* 4. Journal & Emotional Logs Modal */}
      <JournalHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onSelectToolById={(toolId) => {
          setIsHistoryOpen(false);
          handleOpenToolById(toolId);
        }}
      />

      {/* 5. Authentication & Profile Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={userProfile}
        onUserUpdate={setUserProfile}
      />

      {/* 6. Comprehensive Emergency Numbers Modal */}
      <EmergencyInfoModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />
    </div>
  );
}
