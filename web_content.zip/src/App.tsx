import { useCallback, useEffect, useMemo, useState } from 'react';
import { signInWithPopup, signOut, onAuthStateChanged, type User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';
import type { AttendanceRecord, ComputedDay, DayStatus, UserProfile } from './types';
import {
  DATE_KEY_REGEX,
  MAX_NOTE_LENGTH,
  addDaysUTC,
  computeDaysAndSummary,
  getTodayDateKey,
  parseDateKey,
} from './utils/attendance';
import { ErrorBoundary } from './components/ErrorBoundary';
import { TopBar } from './components/TopBar';
import { SummaryStrip } from './components/SummaryStrip';
import { ReturnSetupCard } from './components/ReturnSetupCard';
import { AttendanceCalendar } from './components/AttendanceCalendar';
import { AttendanceLogTable } from './components/AttendanceLogTable';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';

const LOCAL_DRAFT_PROFILE_KEY = 'attendance_draft_profile_v1';
const LOCAL_DRAFT_RECORDS_KEY = 'attendance_draft_records_v1';

const DEFAULT_PROFILE: UserProfile = {
  userId: 'local',
  returnStartDate: '',
  scheduleMode: 'rotation',
  weeklyRestDays: '',
  rotationWorkDays: 1,
  rotationRestDays: 0,
};

function normalizeRecordStatus(raw: unknown): DayStatus {
  if (raw === 'annual') return 'annual';
  return 'work';
}

function loadDraftProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(LOCAL_DRAFT_PROFILE_KEY);
    if (!raw) return DEFAULT_PROFILE;
    const parsed = JSON.parse(raw) as Partial<UserProfile>;
    return {
      userId: 'local',
      returnStartDate:
        typeof parsed.returnStartDate === 'string' &&
        (parsed.returnStartDate === '' || DATE_KEY_REGEX.test(parsed.returnStartDate))
          ? parsed.returnStartDate
          : '',
      scheduleMode: 'rotation',
      weeklyRestDays: '',
      rotationWorkDays: 1,
      rotationRestDays: 0,
    };
  } catch {
    return DEFAULT_PROFILE;
  }
}

function loadDraftRecords(): Map<string, AttendanceRecord> {
  const map = new Map<string, AttendanceRecord>();
  try {
    const raw = localStorage.getItem(LOCAL_DRAFT_RECORDS_KEY);
    if (!raw) return map;
    const parsed = JSON.parse(raw) as AttendanceRecord[];
    if (Array.isArray(parsed)) {
      for (const rec of parsed) {
        if (
          rec &&
          DATE_KEY_REGEX.test(rec.date) &&
          (rec.status === 'work' || rec.status === 'annual')
        ) {
          map.set(rec.date, {
            userId: 'local',
            date: rec.date,
            monthKey: rec.date.slice(0, 7),
            status: rec.status,
            note: typeof rec.note === 'string' ? rec.note.slice(0, MAX_NOTE_LENGTH) : '',
          });
        }
      }
    }
  } catch {
    // ignore malformed draft
  }
  return map;
}

function AttendanceApp() {
  const todayKey = getTodayDateKey();
  const todayParts = parseDateKey(todayKey);

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState<boolean>(false);
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);

  const [profile, setProfile] = useState<UserProfile>(() => loadDraftProfile());
  const [recordsMap, setRecordsMap] = useState<Map<string, AttendanceRecord>>(() =>
    loadDraftRecords()
  );
  const [loadingCloud, setLoadingCloud] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [fatalError, setFatalError] = useState<Error | null>(null);
  const [coverImgFailed, setCoverImgFailed] = useState<boolean>(false);

  const [viewYear, setViewYear] = useState<number>(todayParts.year);
  const [viewMonth, setViewMonth] = useState<number>(todayParts.month);

  if (fatalError) {
    throw fatalError;
  }

  // Persist local draft only when signed out
  useEffect(() => {
    if (!user && authReady) {
      try {
        localStorage.setItem(LOCAL_DRAFT_PROFILE_KEY, JSON.stringify(profile));
      } catch {
        // ignore storage quota errors
      }
    }
  }, [profile, user, authReady]);

  useEffect(() => {
    if (!user && authReady) {
      try {
        localStorage.setItem(
          LOCAL_DRAFT_RECORDS_KEY,
          JSON.stringify(Array.from(recordsMap.values()))
        );
      } catch {
        // ignore storage quota errors
      }
    }
  }, [recordsMap, user, authReady]);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
      if (!firebaseUser) {
        setProfile(loadDraftProfile());
        setRecordsMap(loadDraftRecords());
        setLoadingCloud(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Ensure root user profile exists in Firestore and attach real-time listeners when authenticated
  useEffect(() => {
    if (!authReady || !user) return;

    let cancelled = false;
    let unsubProfile: (() => void) | undefined;
    let unsubRecords: (() => void) | undefined;

    const userPath = `users/${user.uid}`;
    const recordsPath = `users/${user.uid}/records`;

    const initAndSubscribe = async () => {
      setLoadingCloud(true);
      const userRef = doc(db, 'users', user.uid);

      try {
        const snap = await getDoc(userRef);
        if (!snap.exists()) {
          const draft = loadDraftProfile();
          const initialPayload = {
            userId: user.uid,
            returnStartDate:
              draft.returnStartDate && DATE_KEY_REGEX.test(draft.returnStartDate)
                ? draft.returnStartDate
                : '',
            scheduleMode: 'rotation',
            weeklyRestDays: '',
            rotationWorkDays: 1,
            rotationRestDays: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          };
          await setDoc(userRef, initialPayload);

          const draftRecords = loadDraftRecords();
          for (const rec of draftRecords.values()) {
            if (DATE_KEY_REGEX.test(rec.date)) {
              await setDoc(doc(db, 'users', user.uid, 'records', rec.date), {
                userId: user.uid,
                date: rec.date,
                monthKey: rec.date.slice(0, 7),
                status: normalizeRecordStatus(rec.status),
                note: (rec.note || '').trim().slice(0, MAX_NOTE_LENGTH),
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }
          localStorage.removeItem(LOCAL_DRAFT_PROFILE_KEY);
          localStorage.removeItem(LOCAL_DRAFT_RECORDS_KEY);
        }
      } catch (err) {
        if (!cancelled) {
          try {
            handleFirestoreError(err, OperationType.WRITE, userPath);
          } catch (wrapped) {
            setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
          }
        }
        return;
      }

      if (cancelled) return;

      unsubProfile = onSnapshot(
        userRef,
        (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data();
            setProfile({
              userId: String(data.userId || user.uid),
              returnStartDate:
                typeof data.returnStartDate === 'string' ? data.returnStartDate : '',
              scheduleMode: 'rotation',
              weeklyRestDays: '',
              rotationWorkDays: 1,
              rotationRestDays: 0,
            });
          }
          setLoadingCloud(false);
        },
        (err) => {
          try {
            handleFirestoreError(err, OperationType.GET, userPath);
          } catch (wrapped) {
            setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
          }
        }
      );

      const recordsQuery = query(
        collection(db, 'users', user.uid, 'records'),
        where('userId', '==', user.uid)
      );

      unsubRecords = onSnapshot(
        recordsQuery,
        (snapshot) => {
          const nextMap = new Map<string, AttendanceRecord>();
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (typeof data.date === 'string' && DATE_KEY_REGEX.test(data.date)) {
              nextMap.set(data.date, {
                userId: String(data.userId || user.uid),
                date: data.date,
                monthKey: String(data.monthKey || data.date.slice(0, 7)),
                status: normalizeRecordStatus(data.status),
                note: typeof data.note === 'string' ? data.note : '',
              });
            }
          });
          setRecordsMap(nextMap);
        },
        (err) => {
          try {
            handleFirestoreError(err, OperationType.LIST, recordsPath);
          } catch (wrapped) {
            setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
          }
        }
      );
    };

    void initAndSubscribe();

    return () => {
      cancelled = true;
      unsubProfile?.();
      unsubRecords?.();
    };
  }, [authReady, user]);

  const handleSignIn = async () => {
    setAuthNotice(null);
    setIsSigningIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const code = (err as { code?: string })?.code;
      if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
        setAuthNotice('تم إلغاء نافذة تسجيل الدخول. يمكنك المحاولة مجدداً في أي وقت.');
      } else {
        setAuthNotice('تعذر إتمام تسجيل الدخول بحساب Google. يرجى المحاولة مرة أخرى.');
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    setAuthNotice(null);
    await signOut(auth);
  };

  const updateCloudProfile = useCallback(
    async (nextProfile: UserProfile) => {
      if (!user) {
        setProfile(nextProfile);
        return;
      }
      setSaving(true);
      const userPath = `users/${user.uid}`;
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          returnStartDate: nextProfile.returnStartDate,
          scheduleMode: 'rotation',
          weeklyRestDays: '',
          rotationWorkDays: 1,
          rotationRestDays: 0,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        try {
          handleFirestoreError(err, OperationType.UPDATE, userPath);
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      } finally {
        setSaving(false);
      }
    },
    [user]
  );

  const handleSaveReturnStart = async (dateKey: string) => {
    if (!DATE_KEY_REGEX.test(dateKey)) return;
    const nextProfile: UserProfile = {
      ...profile,
      returnStartDate: dateKey,
    };
    const parts = parseDateKey(dateKey);
    setViewYear(parts.year);
    setViewMonth(parts.month);
    await updateCloudProfile(nextProfile);
  };

  const handleClearReturnStart = async () => {
    await updateCloudProfile({
      ...profile,
      returnStartDate: '',
    });
  };

  const handleSetDayOverride = async (dateKey: string, status: DayStatus, note: string) => {
    if (!DATE_KEY_REGEX.test(dateKey)) return;
    const cleanNote = note.trim().slice(0, MAX_NOTE_LENGTH);

    if (!user) {
      setRecordsMap((prev) => {
        const next = new Map(prev);
        next.set(dateKey, {
          userId: 'local',
          date: dateKey,
          monthKey: dateKey.slice(0, 7),
          status,
          note: cleanNote,
        });
        return next;
      });
      return;
    }

    setSaving(true);
    const recordPath = `users/${user.uid}/records/${dateKey}`;
    const recordRef = doc(db, 'users', user.uid, 'records', dateKey);

    try {
      const existing = recordsMap.get(dateKey);
      if (existing) {
        await updateDoc(recordRef, {
          status,
          note: cleanNote,
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(recordRef, {
          userId: user.uid,
          date: dateKey,
          monthKey: dateKey.slice(0, 7),
          status,
          note: cleanNote,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.WRITE, recordPath);
      } catch (wrapped) {
        setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    } finally {
      setSaving(false);
    }
  };

  const handleRecordAnnualLeaveRange = async (
    startDateKey: string,
    daysCount: number,
    note: string
  ) => {
    if (!DATE_KEY_REGEX.test(startDateKey)) return;
    const safeCount = Math.max(1, Math.min(60, Math.floor(daysCount || 1)));
    const cleanNote = note.trim().slice(0, MAX_NOTE_LENGTH);

    const targetDates: string[] = [];
    for (let i = 0; i < safeCount; i++) {
      targetDates.push(addDaysUTC(startDateKey, i));
    }

    const parts = parseDateKey(startDateKey);
    setViewYear(parts.year);
    setViewMonth(parts.month);

    if (!user) {
      setRecordsMap((prev) => {
        const next = new Map(prev);
        for (const d of targetDates) {
          next.set(d, {
            userId: 'local',
            date: d,
            monthKey: d.slice(0, 7),
            status: 'annual',
            note: cleanNote,
          });
        }
        return next;
      });
      return;
    }

    setSaving(true);
    const batch = writeBatch(db);
    const basePath = `users/${user.uid}/records`;
    try {
      for (const d of targetDates) {
        const ref = doc(db, 'users', user.uid, 'records', d);
        if (recordsMap.has(d)) {
          batch.update(ref, {
            status: 'annual',
            note: cleanNote,
            updatedAt: serverTimestamp(),
          });
        } else {
          batch.set(ref, {
            userId: user.uid,
            date: d,
            monthKey: d.slice(0, 7),
            status: 'annual',
            note: cleanNote,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      }
      await batch.commit();
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.WRITE, basePath);
      } catch (wrapped) {
        setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteDayOverride = async (dateKey: string) => {
    if (!DATE_KEY_REGEX.test(dateKey)) return;
    if (!user) {
      setRecordsMap((prev) => {
        const next = new Map(prev);
        next.delete(dateKey);
        return next;
      });
      return;
    }

    setSaving(true);
    const recordPath = `users/${user.uid}/records/${dateKey}`;
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'records', dateKey));
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.DELETE, recordPath);
      } catch (wrapped) {
        setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    } finally {
      setSaving(false);
    }
  };

  const handleQuickSetStatus = async (day: ComputedDay, nextStatus: DayStatus) => {
    await handleSetDayOverride(
      day.date,
      nextStatus,
      day.note === 'أول يوم عودة للعمل' ? '' : day.note
    );
  };

  const { days: allComputedDays, summary: overallSummary } = useMemo(
    () => computeDaysAndSummary(todayKey, profile, recordsMap),
    [todayKey, profile, recordsMap]
  );

  return (
    <div id="top" className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <TopBar
        user={user}
        authReady={authReady}
        isSigningIn={isSigningIn}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
      />

      <main className="max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 flex-1">
        {/* Wide Modern Brand Cover */}
        <section className="w-full rounded-2xl overflow-hidden border border-slate-200 bg-white">
          <div className="w-full bg-white px-4 py-4 sm:px-8 sm:py-6 flex items-center justify-center">
            {!coverImgFailed ? (
              <img
                src="/assets/aistudio/1795724077726_ead67b60.jpg"
                alt="Eladawy Working Days"
                referrerPolicy="no-referrer"
                onError={() => setCoverImgFailed(true)}
                className="w-full max-w-3xl max-h-[240px] sm:max-h-[280px] object-contain mx-auto"
              />
            ) : (
              <div className="py-10 text-center">
                <h1
                  dir="ltr"
                  className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900"
                >
                  ELADAWY WORKING DAYS
                </h1>
              </div>
            )}
          </div>
          <div className="bg-[#142D4C] text-white px-6 py-3.5 sm:px-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <p className="text-xs sm:text-sm text-slate-100">
              تسجيل أول يوم عودة للعمل ومتابعة عدد أيام الحضور والإجازة الاعتيادي بوضوح.
            </p>
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <div className="text-xs text-amber-300 flex items-center gap-2">
                <span>تاريخ اليوم:</span>
                <span className="font-mono-num tabular-nums font-semibold text-white">
                  {todayKey}
                </span>
              </div>
              <PWAInstallButton />
            </div>
          </div>
        </section>

        {/* Clean optional cloud sync prompt when signed out */}
        {authReady && !user && (
          <div className="bg-white border border-slate-200 rounded-xl px-5 py-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <p className="text-xs sm:text-sm text-slate-600">
              يتم الحفظ حالياً على هذا المتصفح. سجّل الدخول بحساب Google لحفظ سجل حضورك وإجازاتك سحابياً.
            </p>
            <button
              type="button"
              onClick={handleSignIn}
              disabled={isSigningIn}
              className="px-4 py-2 min-h-[38px] text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto"
            >
              {isSigningIn ? 'جاري الدخول...' : 'حفظ ومزامنة السجل'}
            </button>
          </div>
        )}

        {authNotice && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-5 py-3 text-xs sm:text-sm text-amber-900">
            {authNotice}
          </div>
        )}

        {/* Always-visible attached counters for Work Days, Annual Leave & Casual Leave */}
        <SummaryStrip
          summary={overallSummary}
          returnStartDate={profile.returnStartDate}
          todayKey={todayKey}
          loading={loadingCloud}
        />

        {/* First-day-only registration + Annual Leave Entry */}
        <ReturnSetupCard
          profile={profile}
          todayKey={todayKey}
          saving={saving}
          onSaveReturnStart={handleSaveReturnStart}
          onClearReturnStart={handleClearReturnStart}
          onRecordAnnualLeaveRange={handleRecordAnnualLeaveRange}
        />

        {/* Monthly Calendar with attached monthly counts & optional manual day overrides */}
        <AttendanceCalendar
          year={viewYear}
          month={viewMonth}
          todayKey={todayKey}
          profile={profile}
          recordsMap={recordsMap}
          saving={saving}
          onChangeMonth={(y, m) => {
            setViewYear(y);
            setViewMonth(m);
          }}
          onGoToToday={() => {
            setViewYear(todayParts.year);
            setViewMonth(todayParts.month);
          }}
          onSetDayOverride={handleSetDayOverride}
          onDeleteDayOverride={handleDeleteDayOverride}
        />

        {/* Filterable Daily Log & CSV Export */}
        <AttendanceLogTable
          days={allComputedDays}
          returnStartDate={profile.returnStartDate}
          todayKey={todayKey}
          saving={saving}
          onQuickSetStatus={handleQuickSetStatus}
        />
      </main>

      <footer className="border-t border-slate-200 bg-white py-5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
          <span dir="ltr" className="font-medium text-slate-700">
            Eladawy Working Days
          </span>
          <div className="flex flex-wrap items-center gap-4">
            <span>متابعة أيام الحضور والإجازة الاعتيادي</span>
            <a
              href="/downloads/eladawy-working-days.zip"
              download="eladawy-working-days.zip"
              className="font-medium text-slate-700 hover:text-slate-900 underline underline-offset-4 whitespace-nowrap"
            >
              تصدير التطبيق (ZIP)
            </a>
          </div>
        </div>
      </footer>
      <OfflineIndicator />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AttendanceApp />
    </ErrorBoundary>
  );
}
