/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { TactilePowerButton } from './components/TactilePowerButton';
import { StatusHud } from './components/StatusHud';
import { ShakeControlCard } from './components/ShakeControlCard';
import { OledModeCard } from './components/OledModeCard';
import { ScreenLightMode } from './components/ScreenLightMode';
import { StrobeSosMode } from './components/StrobeSosMode';
import { FullscreenLantern } from './components/FullscreenLantern';
import { TimerModal } from './components/TimerModal';
import { BottomNav } from './components/BottomNav';

import { LIGHT_COLOR_PRESETS, LightColorPreset } from './types/flashlight';
import { torchService, TorchStatus } from './utils/torch';
import { wakeLockService } from './utils/wakeLock';
import { shakeService } from './utils/shakeDetector';
import { themeService, DarkModeType } from './utils/theme';
import { soundService } from './utils/sound';
import {
  Volume2,
  VolumeX,
  Vibrate,
  Smartphone,
  ShieldCheck,
  AlertCircle,
  Sun,
  Flame,
  Zap,
} from 'lucide-react';

export default function App() {
  // Flashlight state
  const [isOn, setIsOn] = useState(false);
  const [activeTab, setActiveTab] = useState('main'); // 'main' | 'screen' | 'strobe' | 'settings' | 'hazard'
  const [currentColor, setCurrentColor] = useState<LightColorPreset>(LIGHT_COLOR_PRESETS[0]);
  const [customHex, setCustomHex] = useState('#00F0FF');
  const [brightness, setBrightness] = useState(100);
  const [candleFlicker, setCandleFlicker] = useState(false);

  // Hardware torch status
  const [torchStatus, setTorchStatus] = useState<TorchStatus>(torchService.getStatus());
  const [useHardwareTorch, setUseHardwareTorch] = useState(true);

  // OLED & Theme
  const [darkMode, setDarkMode] = useState<DarkModeType>(themeService.getMode());
  const isOled = darkMode === 'oled-true-black';

  // Sound & Haptics
  const [soundEnabled, setSoundEnabled] = useState(soundService.isSoundEnabled());
  const [hapticsEnabled, setHapticsEnabled] = useState(soundService.isHapticsEnabled());

  // Strobe & SOS
  const [isStrobeActive, setIsStrobeActive] = useState(false);
  const [strobeFrequency, setStrobeFrequency] = useState(8); // 8 Hz default
  const [isSosActive, setIsSosActive] = useState(false);
  const [isHazardActive, setIsHazardActive] = useState(false);

  // Fullscreen lantern mode
  const [isFullscreenLantern, setIsFullscreenLantern] = useState(false);
  const [isBrowserFullscreen, setIsBrowserFullscreen] = useState(false);

  // Sleep Timer
  const [isTimerModalOpen, setIsTimerModalOpen] = useState(false);
  const [timerSecondsRemaining, setTimerSecondsRemaining] = useState<number | null>(null);

  // Visual shake notification banner
  const [shakeBannerVisible, setShakeBannerVisible] = useState(false);

  // Wake lock
  const [wakeLockActive, setWakeLockActive] = useState(false);

  // Ref for strobe / SOS intervals
  const strobeIntervalRef = useRef<number | null>(null);
  const sosTimeoutRef = useRef<number | null>(null);
  const hazardIntervalRef = useRef<number | null>(null);

  // Subscribe to Torch service
  useEffect(() => {
    const unsub = torchService.subscribe(setTorchStatus);
    return () => unsub();
  }, []);

  // Subscribe to Theme service
  useEffect(() => {
    const unsub = themeService.subscribe(setDarkMode);
    return () => unsub();
  }, []);

  // Primary toggle handler
  const handleTogglePower = useCallback(async () => {
    setIsOn((prev) => {
      const nextState = !prev;
      if (nextState) {
        // Turning ON
        wakeLockService.request().then(setWakeLockActive);
        if (useHardwareTorch) {
          torchService.turnOn().catch(() => {});
        }
      } else {
        // Turning OFF
        wakeLockService.release().then(() => setWakeLockActive(false));
        torchService.turnOff().catch(() => {});
        // Stop any active strobe/sos
        setIsStrobeActive(false);
        setIsSosActive(false);
        setIsHazardActive(false);
      }
      return nextState;
    });
  }, [useHardwareTorch]);

  // Shake detector trigger registration
  useEffect(() => {
    const unsubShake = shakeService.subscribeShake(() => {
      // Trigger shake visual notification
      setShakeBannerVisible(true);
      setTimeout(() => setShakeBannerVisible(false), 1400);

      // Toggle flashlight
      handleTogglePower();
    });

    return () => {
      unsubShake();
    };
  }, [handleTogglePower]);

  // Handle Hardware Torch state sync
  useEffect(() => {
    if (isOn && useHardwareTorch) {
      torchService.turnOn().catch(() => {});
    } else if (!isOn) {
      torchService.turnOff().catch(() => {});
    }
  }, [isOn, useHardwareTorch]);

  // Sleep timer interval
  useEffect(() => {
    if (timerSecondsRemaining === null) return;

    if (timerSecondsRemaining <= 0) {
      // Timer finished -> Turn off light
      setIsOn(false);
      wakeLockService.release().then(() => setWakeLockActive(false));
      torchService.turnOff().catch(() => {});
      soundService.playSwitchOff();
      setTimerSecondsRemaining(null);
      return;
    }

    const timer = setInterval(() => {
      setTimerSecondsRemaining((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);

    return () => clearInterval(timer);
  }, [timerSecondsRemaining]);

  // Strobe effect loop
  useEffect(() => {
    if (!isStrobeActive) {
      if (strobeIntervalRef.current) {
        clearInterval(strobeIntervalRef.current);
        strobeIntervalRef.current = null;
      }
      return;
    }

    let flashState = false;
    const intervalMs = Math.round(1000 / (strobeFrequency * 2));

    strobeIntervalRef.current = window.setInterval(() => {
      flashState = !flashState;
      setIsOn(flashState);
      if (useHardwareTorch) {
        torchService.setTorchState(flashState);
      }
    }, intervalMs);

    return () => {
      if (strobeIntervalRef.current) {
        clearInterval(strobeIntervalRef.current);
        strobeIntervalRef.current = null;
      }
    };
  }, [isStrobeActive, strobeFrequency, useHardwareTorch]);

  // SOS Morse Code pattern loop: · · · — — — · · ·
  useEffect(() => {
    if (!isSosActive) {
      if (sosTimeoutRef.current) {
        clearTimeout(sosTimeoutRef.current);
        sosTimeoutRef.current = null;
      }
      return;
    }

    let isRunning = true;
    const unit = 140; // ms per dot

    const scheduleMorse = async () => {
      const pattern = [
        // S: · · ·
        { on: true, dur: unit },
        { on: false, dur: unit },
        { on: true, dur: unit },
        { on: false, dur: unit },
        { on: true, dur: unit },
        { on: false, dur: unit * 3 },
        // O: — — —
        { on: true, dur: unit * 3 },
        { on: false, dur: unit },
        { on: true, dur: unit * 3 },
        { on: false, dur: unit },
        { on: true, dur: unit * 3 },
        { on: false, dur: unit * 3 },
        // S: · · ·
        { on: true, dur: unit },
        { on: false, dur: unit },
        { on: true, dur: unit },
        { on: false, dur: unit },
        { on: true, dur: unit },
        { on: false, dur: unit * 7 }, // pause before loop
      ];

      for (const step of pattern) {
        if (!isRunning) break;
        setIsOn(step.on);
        if (useHardwareTorch) {
          torchService.setTorchState(step.on);
        }
        if (step.on) {
          soundService.playBeep(step.dur);
        }
        await new Promise((r) => {
          sosTimeoutRef.current = window.setTimeout(r, step.dur);
        });
      }

      if (isRunning) {
        scheduleMorse();
      }
    };

    scheduleMorse();

    return () => {
      isRunning = false;
      if (sosTimeoutRef.current) {
        clearTimeout(sosTimeoutRef.current);
        sosTimeoutRef.current = null;
      }
    };
  }, [isSosActive, useHardwareTorch]);

  // Hazard Alternating Police Flasher Loop
  useEffect(() => {
    if (!isHazardActive) {
      if (hazardIntervalRef.current) {
        clearInterval(hazardIntervalRef.current);
        hazardIntervalRef.current = null;
      }
      return;
    }

    let step = 0;
    hazardIntervalRef.current = window.setInterval(() => {
      step = (step + 1) % 4;
      if (step === 0 || step === 1) {
        // Red flash
        setCurrentColor(LIGHT_COLOR_PRESETS.find((p) => p.id === 'oled-red') || LIGHT_COLOR_PRESETS[4]);
        setIsOn(true);
      } else {
        // Blue flash
        setCurrentColor(LIGHT_COLOR_PRESETS.find((p) => p.id === 'neon-cyan') || LIGHT_COLOR_PRESETS[0]);
        setIsOn(true);
      }
      if (useHardwareTorch) {
        torchService.setTorchState(step % 2 === 0);
      }
    }, 180);

    return () => {
      if (hazardIntervalRef.current) {
        clearInterval(hazardIntervalRef.current);
        hazardIntervalRef.current = null;
      }
    };
  }, [isHazardActive, useHardwareTorch]);

  // Fullscreen toggle
  const toggleBrowserFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsBrowserFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsBrowserFullscreen(false);
    }
  };

  // Sound toggle
  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundService.setSoundEnabled(next);
  };

  // Haptics toggle
  const handleToggleHaptics = () => {
    const next = !hapticsEnabled;
    setHapticsEnabled(next);
    soundService.setHapticsEnabled(next);
    if (next) soundService.triggerHaptic('medium');
  };

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-300 ${
        isOled ? 'bg-black text-neutral-100' : 'bg-[#070b14] text-slate-100'
      }`}
    >
      {/* Top Header */}
      <Header
        isFullscreen={isBrowserFullscreen}
        onToggleFullscreen={toggleBrowserFullscreen}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        darkMode={darkMode}
        onToggleDarkMode={() => {
          const next = darkMode === 'oled-true-black' ? 'cyber-dark' : 'oled-true-black';
          themeService.setMode(next);
        }}
      />

      {/* Floating Shake-Detected Toast */}
      {shakeBannerVisible && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-400 text-slate-950 font-bold text-xs shadow-[0_0_25px_#00F0FF] animate-bounce">
          <Smartphone className="w-4 h-4" />
          <span>Zatřesení detekováno · Svítilna přepnuta!</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 pt-3 pb-24 flex flex-col justify-between">
        {/* Top Status HUD */}
        <StatusHud
          wakeLockActive={wakeLockActive}
          timerSecondsRemaining={timerSecondsRemaining}
          onOpenTimer={() => setIsTimerModalOpen(true)}
          torchActive={isOn && useHardwareTorch && Boolean(torchStatus.isActive)}
          torchSupported={torchStatus.isSupported}
        />

        {/* Tab 1: Hlavní svítilna */}
        {activeTab === 'main' && (
          <div className="flex-1 flex flex-col justify-center items-center my-4 space-y-6">
            {/* The Central Tactile Power Button */}
            <TactilePowerButton
              isOn={isOn}
              onToggle={handleTogglePower}
              activeColor={currentColor.hex}
              glowColor={currentColor.glowColor}
              brightness={brightness}
              isOled={isOled}
              sublabel={
                isOn
                  ? torchStatus.isActive
                    ? 'LED blesk + displej aktivní'
                    : 'Displej svítí naplno'
                  : 'Klepněte nebo zatřeste telefonem pro rozsvícení'
              }
            />

            {/* Quick Shake & OLED Status bar on main view */}
            <div className="w-full max-w-md space-y-3">
              {/* Shake-to-Toggle mini banner */}
              <div
                className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-all ${
                  isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-2 text-slate-300">
                  <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Zatřesení pro zapnutí/vypnutí je aktivní</span>
                </div>
                <button
                  onClick={() => setActiveTab('settings')}
                  className="text-cyan-400 hover:underline font-semibold cursor-pointer shrink-0 ml-2"
                >
                  Nastavit
                </button>
              </div>

              {/* Hardware LED Torch capability hint if available */}
              {torchStatus.errorMessage && (
                <div className="p-3 rounded-xl bg-neutral-900/40 border border-neutral-800 text-[11px] text-slate-400 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>{torchStatus.errorMessage}</span>
                </div>
              )}

              {/* Quick Preset Buttons */}
              <div className="grid grid-cols-4 gap-2 pt-1">
                <button
                  onClick={() => {
                    soundService.playTick();
                    setCurrentColor(LIGHT_COLOR_PRESETS[0]); // Neon Cyan
                  }}
                  className={`p-2 rounded-xl border text-center text-[11px] font-semibold transition-all cursor-pointer ${
                    currentColor.id === 'neon-cyan'
                      ? 'border-cyan-400 bg-cyan-950/30 text-cyan-300 shadow-[0_0_10px_rgba(0,240,255,0.2)]'
                      : 'border-slate-800/80 bg-slate-950/60 text-slate-400 hover:text-white'
                  }`}
                >
                  Cyan
                </button>
                <button
                  onClick={() => {
                    soundService.playTick();
                    setCurrentColor(LIGHT_COLOR_PRESETS[1]); // Ultra White
                  }}
                  className={`p-2 rounded-xl border text-center text-[11px] font-semibold transition-all cursor-pointer ${
                    currentColor.id === 'cool-white'
                      ? 'border-white bg-white/10 text-white shadow-[0_0_10px_rgba(255,255,255,0.2)]'
                      : 'border-slate-800/80 bg-slate-950/60 text-slate-400 hover:text-white'
                  }`}
                >
                  Bílá
                </button>
                <button
                  onClick={() => {
                    soundService.playTick();
                    setCurrentColor(LIGHT_COLOR_PRESETS[4]); // OLED Red
                  }}
                  className={`p-2 rounded-xl border text-center text-[11px] font-semibold transition-all cursor-pointer ${
                    currentColor.id === 'oled-red'
                      ? 'border-red-500 bg-red-950/40 text-red-300 shadow-[0_0_10px_rgba(255,0,51,0.2)]'
                      : 'border-slate-800/80 bg-slate-950/60 text-slate-400 hover:text-white'
                  }`}
                >
                  Noční červená
                </button>
                <button
                  onClick={() => {
                    soundService.playTick();
                    setIsFullscreenLantern(true);
                  }}
                  className="p-2 rounded-xl border border-slate-800/80 bg-slate-950/60 text-slate-300 hover:border-cyan-400 text-center text-[11px] font-semibold transition-all cursor-pointer"
                >
                  Lucerna
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Světlo displeje & Barvy */}
        {activeTab === 'screen' && (
          <div className="py-2">
            <ScreenLightMode
              currentColor={currentColor}
              onSelectColor={setCurrentColor}
              customHex={customHex}
              onCustomHexChange={setCustomHex}
              brightness={brightness}
              onBrightnessChange={setBrightness}
              candleFlicker={candleFlicker}
              onToggleCandleFlicker={() => setCandleFlicker(!candleFlicker)}
              onLaunchFullscreen={() => {
                setIsOn(true);
                setIsFullscreenLantern(true);
              }}
              isOled={isOled}
            />
          </div>
        )}

        {/* Tab 3: Stroboskop & SOS nouzové signály */}
        {activeTab === 'strobe' && (
          <div className="py-2">
            <StrobeSosMode
              isStrobeActive={isStrobeActive}
              onToggleStrobe={() => setIsStrobeActive(!isStrobeActive)}
              strobeFrequency={strobeFrequency}
              onFrequencyChange={setStrobeFrequency}
              isSosActive={isSosActive}
              onToggleSos={() => setIsSosActive(!isSosActive)}
              isHazardActive={isHazardActive}
              onToggleHazard={() => setIsHazardActive(!isHazardActive)}
              onMomentaryPressStart={() => {
                setIsOn(true);
                if (useHardwareTorch) torchService.turnOn().catch(() => {});
              }}
              onMomentaryPressEnd={() => {
                setIsOn(false);
                if (useHardwareTorch) torchService.turnOff().catch(() => {});
              }}
              isOled={isOled}
            />
          </div>
        )}

        {/* Tab 4: OLED & Shake & Nastavení */}
        {activeTab === 'settings' && (
          <div className="py-2 space-y-4">
            {/* Shake to toggle control card */}
            <ShakeControlCard
              isOled={isOled}
              onSimulateShake={() => {
                setShakeBannerVisible(true);
                setTimeout(() => setShakeBannerVisible(false), 1400);
                handleTogglePower();
              }}
            />

            {/* OLED True Black display mode card */}
            <OledModeCard
              darkMode={darkMode}
              onSetDarkMode={setDarkMode}
              onQuickNightRed={() => {
                const redPreset = LIGHT_COLOR_PRESETS.find((p) => p.id === 'oled-red') || LIGHT_COLOR_PRESETS[4];
                setCurrentColor(redPreset);
                setIsOn(true);
              }}
            />

            {/* Sound & Haptics and Hardware Torch toggles */}
            <div
              className={`rounded-2xl p-4 sm:p-5 border space-y-3 ${
                isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Předvolby aplikace
              </h4>

              {/* Hardware LED Torch Toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-cyan-400" />
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">
                      Hardwarový LED blesk kamery
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Použít fyzickou diodu fotoaparátu telefonu
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    soundService.playTick();
                    setUseHardwareTorch(!useHardwareTorch);
                  }}
                  role="switch"
                  aria-checked={useHardwareTorch}
                  aria-label="Použít hardwarový LED blesk"
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ${
                    useHardwareTorch ? 'bg-cyan-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ${
                      useHardwareTorch ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Audio feedback toggle */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                <div className="flex items-center gap-2">
                  {soundEnabled ? (
                    <Volume2 className="w-4 h-4 text-cyan-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-slate-500" />
                  )}
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">
                      Mechanický zvuk přepínače
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Realistické cvaknutí relé a vypínače
                    </span>
                  </div>
                </div>
                <button
                  onClick={handleToggleSound}
                  role="switch"
                  aria-checked={soundEnabled}
                  aria-label="Zapnout zvuk"
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ${
                    soundEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ${
                      soundEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Haptics toggle */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                <div className="flex items-center gap-2">
                  <Vibrate className="w-4 h-4 text-cyan-400" />
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">
                      Haptická odezva (Vibrace)
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Jemné vibrace při stisku a zatřesení
                    </span>
                  </div>
                </div>
                <button
                  onClick={handleToggleHaptics}
                  role="switch"
                  aria-checked={hapticsEnabled}
                  aria-label="Zapnout vibrace"
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ${
                    hapticsEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ${
                      hapticsEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Hazard direct view if navigated from nav */}
        {activeTab === 'hazard' && (
          <div className="py-2">
            <StrobeSosMode
              isStrobeActive={isStrobeActive}
              onToggleStrobe={() => setIsStrobeActive(!isStrobeActive)}
              strobeFrequency={strobeFrequency}
              onFrequencyChange={setStrobeFrequency}
              isSosActive={isSosActive}
              onToggleSos={() => setIsSosActive(!isSosActive)}
              isHazardActive={isHazardActive}
              onToggleHazard={() => setIsHazardActive(!isHazardActive)}
              onMomentaryPressStart={() => {
                setIsOn(true);
                if (useHardwareTorch) torchService.turnOn().catch(() => {});
              }}
              onMomentaryPressEnd={() => {
                setIsOn(false);
                if (useHardwareTorch) torchService.turnOff().catch(() => {});
              }}
              isOled={isOled}
            />
          </div>
        )}
      </main>

      {/* Fullscreen Lantern Overlay */}
      {isFullscreenLantern && (
        <FullscreenLantern
          color={currentColor}
          brightness={brightness}
          onBrightnessChange={setBrightness}
          candleFlicker={candleFlicker}
          onClose={() => setIsFullscreenLantern(false)}
        />
      )}

      {/* Sleep Timer Modal */}
      <TimerModal
        isOpen={isTimerModalOpen}
        onClose={() => setIsTimerModalOpen(false)}
        secondsRemaining={timerSecondsRemaining}
        onSetTimerMinutes={(mins) => {
          setTimerSecondsRemaining(mins * 60);
          setIsTimerModalOpen(false);
          setIsOn(true);
          wakeLockService.request().then(setWakeLockActive);
          if (useHardwareTorch) torchService.turnOn().catch(() => {});
        }}
        onCancelTimer={() => {
          setTimerSecondsRemaining(null);
        }}
        isOled={isOled}
      />

      {/* Bottom Thumb Navigation Bar */}
      <BottomNav
        activeTab={activeTab === 'hazard' ? 'strobe' : activeTab}
        onSelectTab={setActiveTab}
        isOled={isOled}
      />
    </div>
  );
}
