import React, { useState, useEffect } from "react";
import { TopHeader } from "./components/TopHeader";
import { BottomNav } from "./components/BottomNav";
import { HomeScreen } from "./screens/HomeScreen";
import { CreateScreen } from "./screens/CreateScreen";
import { ProjectsScreen } from "./screens/ProjectsScreen";
import { HistoryScreen } from "./screens/HistoryScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { VoiceLibraryModal } from "./components/VoiceLibraryModal";
import { GlobalMediaPlayer } from "./components/GlobalMediaPlayer";

// Tool screens
import { VoiceTool } from "./screens/tools/VoiceTool";
import { TranslatorTool } from "./screens/tools/TranslatorTool";
import { MusicTool } from "./screens/tools/MusicTool";
import { ImageTool } from "./screens/tools/ImageTool";
import { ImageToVideoTool } from "./screens/tools/ImageToVideoTool";
import { TextToVideoTool } from "./screens/tools/TextToVideoTool";
import { AudioEnhancerTool } from "./screens/tools/AudioEnhancerTool";
import { VideoToMusicTool } from "./screens/tools/VideoToMusicTool";
import { SubtitleTool } from "./screens/tools/SubtitleTool";
import { WritingTool } from "./screens/tools/WritingTool";

import { NavTab, ToolId, BackendStatus, ProjectItem, VoiceItem } from "./types";
import { checkBackendHealth } from "./lib/api";
import { X } from "lucide-react";

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>("home");
  const [activeTool, setActiveTool] = useState<ToolId | null>(null);

  // Cross-tool communication states
  const [musicPrefillLyrics, setMusicPrefillLyrics] = useState<string | undefined>(undefined);
  const [musicPrefillStyle, setMusicPrefillStyle] = useState<string | undefined>(undefined);
  const [selectedVoiceModel, setSelectedVoiceModel] = useState<VoiceItem | undefined>(undefined);

  // Modals
  const [voiceLibraryOpen, setVoiceLibraryOpen] = useState(false);
  const [activeMediaPlayback, setActiveMediaPlayback] = useState<{
    url: string;
    type: "audio" | "video";
  } | null>(null);

  // Backend Status State (Section 24)
  const [backendStatus, setBackendStatus] = useState<BackendStatus>({
    connected: true,
    checking: false,
    statusText: "Ready",
  });

  // Android PWA Install prompt
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [canInstall, setCanInstall] = useState(false);

  useEffect(() => {
    // 1. Initial backend health check
    verifyHealth();

    // Periodic check every 45s
    const healthInterval = setInterval(verifyHealth, 45000);

    // 2. Android PWA Install Event listener
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
      setCanInstall(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    return () => {
      clearInterval(healthInterval);
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  const verifyHealth = async () => {
    setBackendStatus((prev) => ({ ...prev, checking: true }));
    try {
      const res = await checkBackendHealth();
      setBackendStatus({
        connected: res.connected,
        checking: false,
        statusText: res.statusText,
      });
    } catch {
      setBackendStatus({
        connected: false,
        checking: false,
        statusText: "Offline",
      });
    }
  };

  const handleInstallApp = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") {
      setCanInstall(false);
      setInstallPrompt(null);
    }
  };

  const handleOpenTool = (toolId: ToolId, project?: ProjectItem) => {
    setActiveTool(toolId);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleCloseTool = () => {
    setActiveTool(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSendLyricsToMusic = (lyricsText: string, style?: string) => {
    setMusicPrefillLyrics(lyricsText);
    setMusicPrefillStyle(style || "Ghazal");
    setActiveTool("music");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Persistent Mobile Top Header */}
      <TopHeader
        status={backendStatus}
        onOpenSettings={() => {
          setActiveTool(null);
          setCurrentTab("settings");
        }}
        onRefreshHealth={verifyHealth}
        canInstall={canInstall}
        onInstallApp={handleInstallApp}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full overflow-x-hidden">
        {/* If a tool is open, render that tool screen */}
        {activeTool ? (
          <div>
            {activeTool === "tts" && (
              <VoiceTool onBack={handleCloseTool} defaultVoice={selectedVoiceModel} />
            )}
            {activeTool === "translator" && <TranslatorTool onBack={handleCloseTool} />}
            {activeTool === "music" && (
              <MusicTool
                onBack={handleCloseTool}
                initialLyrics={musicPrefillLyrics}
                initialStyle={musicPrefillStyle}
              />
            )}
            {activeTool === "image" && <ImageTool onBack={handleCloseTool} />}
            {activeTool === "image-to-video" && <ImageToVideoTool onBack={handleCloseTool} />}
            {activeTool === "text-to-video" && <TextToVideoTool onBack={handleCloseTool} />}
            {activeTool === "enhance-audio" && <AudioEnhancerTool onBack={handleCloseTool} />}
            {activeTool === "video-to-music" && <VideoToMusicTool onBack={handleCloseTool} />}
            {activeTool === "subtitles" && <SubtitleTool onBack={handleCloseTool} />}
            {(activeTool === "script" || activeTool === "lyrics") && (
              <WritingTool
                onBack={handleCloseTool}
                initialTab={activeTool === "lyrics" ? "lyrics" : "script"}
                onSendToMusic={handleSendLyricsToMusic}
              />
            )}
          </div>
        ) : (
          /* Primary 5 Tabs (Section 1: Home, Create, Projects, History, Settings) */
          <div>
            {currentTab === "home" && <HomeScreen onOpenTool={handleOpenTool} />}
            {currentTab === "create" && (
              <CreateScreen
                onOpenTool={handleOpenTool}
                onOpenVoiceLibrary={() => setVoiceLibraryOpen(true)}
              />
            )}
            {currentTab === "projects" && <ProjectsScreen onOpenTool={handleOpenTool} />}
            {currentTab === "history" && (
              <HistoryScreen
                onOpenTool={handleOpenTool}
                onPlayMedia={(url, type) => setActiveMediaPlayback({ url, type })}
              />
            )}
            {currentTab === "settings" && (
              <SettingsScreen
                status={backendStatus}
                onRefreshHealth={verifyHealth}
                canInstall={canInstall}
                onInstallApp={handleInstallApp}
              />
            )}
          </div>
        )}
      </main>

      {/* Persistent Bottom Navigation Bar (ONLY 5 tabs as strictly required by Section 1) */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setActiveTool(null);
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
      />

      {/* Floating Voice Library Modal */}
      <VoiceLibraryModal
        isOpen={voiceLibraryOpen}
        selectedVoiceId={selectedVoiceModel?.id || "bn-subrata"}
        onSelectVoice={(v) => {
          setSelectedVoiceModel(v);
          setActiveTool("tts");
        }}
        onClose={() => setVoiceLibraryOpen(false)}
      />

      {/* Global Media Playback Overlay Modal (when playing from history or preview) */}
      {activeMediaPlayback && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-2xl space-y-3 relative">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 uppercase">Media Player</span>
              <button
                onClick={() => setActiveMediaPlayback(null)}
                className="p-1 rounded-full text-slate-400 hover:text-white bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <GlobalMediaPlayer
              mediaUrl={activeMediaPlayback.url}
              mediaType={activeMediaPlayback.type}
            />
          </div>
        </div>
      )}
    </div>
  );
}
