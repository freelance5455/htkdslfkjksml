import React, { useState, useEffect, useMemo } from 'react';
import { 
  Product, 
  CartItem, 
  SaleInvoice, 
  Expense, 
  PurchaseRecord, 
  StoreProfile, 
  UserRole, 
  FirebaseSyncSettings,
  CustomerDueRecord
} from './types';
import { storageService } from './services/storageService';
import { firebaseService } from './services/firebaseService';
import { Header } from './components/Header';
import { POSView } from './components/POS/POSView';
import { InvoiceListView } from './components/Invoices/InvoiceListView';
import { InventoryView } from './components/Inventory/InventoryView';
import { DashboardView } from './components/Dashboard/DashboardView';
import { DueBookView } from './components/DueBook/DueBookView';
import { ReceiptModal } from './components/Receipt/ReceiptModal';
import { BackupSyncModal } from './components/Settings/BackupSyncModal';
import { RoleSwitchModal } from './components/Role/RoleSwitchModal';
import { AddProductModal } from './components/Products/AddProductModal';
import { X, ShoppingBag, ArrowRight } from 'lucide-react';
import { toBnNum } from './utils/formatters';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'pos' | 'invoices' | 'inventory' | 'dashboard' | 'duebook'>('pos');
  
  // App Data
  const [products, setProducts] = useState<Product[]>([]);
  const [invoices, setInvoices] = useState<SaleInvoice[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [purchases, setPurchases] = useState<PurchaseRecord[]>([]);
  const [storeProfile, setStoreProfile] = useState<StoreProfile>(storageService.getStoreProfile());
  const [activeRole, setActiveRole] = useState<UserRole>('OWNER');
  const [firebaseSettings, setFirebaseSettings] = useState<FirebaseSyncSettings>(storageService.getFirebaseSyncSettings());
  
  // POS Cart
  const [cart, setCart] = useState<CartItem[]>([]);
  const [mobileCartOpen, setMobileCartOpen] = useState(false);

  // Modals
  const [activeReceiptInvoice, setActiveReceiptInvoice] = useState<SaleInvoice | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);

  // Load data from Local Database on mount
  const loadAllData = () => {
    setProducts(storageService.getProducts());
    setInvoices(storageService.getInvoices());
    setExpenses(storageService.getExpenses());
    setPurchases(storageService.getPurchases());
    setStoreProfile(storageService.getStoreProfile());
    setActiveRole(storageService.getActiveRole());
    setFirebaseSettings(storageService.getFirebaseSyncSettings());
  };

  useEffect(() => {
    loadAllData();

    // Real-time synchronization from Firebase Cloud for multi-user / multi-device
    const unsubProducts = firebaseService.subscribeToProducts((cloudProducts) => {
      if (cloudProducts && cloudProducts.length > 0) {
        setProducts(cloudProducts);
        storageService.saveProducts(cloudProducts);
      }
    });

    const unsubInvoices = firebaseService.subscribeToInvoices((cloudInvoices) => {
      if (cloudInvoices && cloudInvoices.length > 0) {
        setInvoices(cloudInvoices);
        storageService.saveInvoices(cloudInvoices);
      }
    });

    // Real-time sync for Store Profile (দোকানের পরিচিতি - নাম, ফোন, ঠিকানা)
    const unsubProfile = firebaseService.subscribeToProfile((cloudProfile) => {
      if (cloudProfile && cloudProfile.name) {
        setStoreProfile(cloudProfile);
        storageService.saveStoreProfileLocally(cloudProfile);
      }
    });

    // Initial background sync to ensure latest store profile is in cloud
    const curProfile = storageService.getStoreProfile();
    firebaseService.syncProfile(curProfile).catch(() => {});

    return () => {
      if (unsubProducts) unsubProducts();
      if (unsubInvoices) unsubInvoices();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  // Low stock counter for alert indicator
  const lowStockCount = useMemo(() => {
    return products.filter((p) => p.stock <= p.lowStockAlert).length;
  }, [products]);

  // Customer Dues
  const customerDues: CustomerDueRecord[] = useMemo(() => {
    const dueInvoices = invoices.filter((i) => i.dueAmount > 0 && i.customerName);
    const map: Record<string, CustomerDueRecord> = {};
    
    dueInvoices.forEach((inv) => {
      const key = `${inv.customerName?.trim()}_${inv.customerPhone?.trim() || ''}`;
      if (!map[key]) {
        map[key] = {
          customerName: inv.customerName || 'গ্রাহক',
          customerPhone: inv.customerPhone || '',
          totalDue: 0,
          invoices: [],
          lastPaymentDate: inv.createdAt,
        };
      }
      map[key].totalDue = +(map[key].totalDue + inv.dueAmount).toFixed(2);
      map[key].invoices.push({
        invoiceId: inv.id,
        invoiceNo: inv.invoiceNo,
        date: inv.createdAt,
        dueAmount: inv.dueAmount,
        subtotal: inv.subtotal,
        paidAmount: inv.paidAmount,
        notes: inv.notes,
        items: inv.items || [],
      });
    });

    return Object.values(map);
  }, [invoices]);

  // Handle Complete Sale from POS
  const handleCompleteSale = (invoiceData: Omit<SaleInvoice, 'id' | 'invoiceNo' | 'createdAt'>) => {
    const newInvoice = storageService.addInvoice(invoiceData);
    setInvoices(storageService.getInvoices());
    setProducts(storageService.getProducts()); // updated stock
    setCart([]);
    setMobileCartOpen(false);

    // Automatically pop open super-shop receipt modal
    setActiveReceiptInvoice(newInvoice);
    setIsReceiptModalOpen(true);
  };

  // Handle Add New Due directly from Due Book
  const handleAddNewDue = (invoiceData: Omit<SaleInvoice, 'id' | 'invoiceNo' | 'createdAt'>) => {
    const newInvoice = storageService.addInvoice(invoiceData);
    setInvoices(storageService.getInvoices());
    setProducts(storageService.getProducts()); // updated stock if store product was selected
    
    // Automatically pop open super-shop receipt modal for printing or sharing
    setActiveReceiptInvoice(newInvoice);
    setIsReceiptModalOpen(true);
  };

  // Handle Edit / Update Due Invoice (e.g. customer takes more products or changes quantity)
  const handleUpdateDue = (invoiceId: string, updatedInvoiceData: Partial<SaleInvoice>) => {
    const updated = storageService.updateInvoice(invoiceId, updatedInvoiceData);
    if (updated) {
      setInvoices(storageService.getInvoices());
      setProducts(storageService.getProducts());
    }
  };

  // View / Reprint any past invoice
  const handleViewReceipt = (invoice: SaleInvoice) => {
    setActiveReceiptInvoice(invoice);
    setIsReceiptModalOpen(true);
  };

  // Pay customer due
  const handlePayDue = (invoiceId: string, amount: number, notes?: string) => {
    const updated = storageService.updateDuePayment(invoiceId, amount, notes);
    if (updated) {
      setInvoices(storageService.getInvoices());
    }
  };

  // Delete invoice (Owner only)
  const handleDeleteInvoice = (invoiceId: string) => {
    const updated = invoices.filter((i) => i.id !== invoiceId);
    storageService.saveInvoices(updated);
    setInvoices(updated);
  };

  // Product CRUD
  const handleAddProduct = (prod: Omit<Product, 'id'>) => {
    const created = storageService.addProduct(prod);
    setProducts(storageService.getProducts());
  };

  const handleUpdateProduct = (prod: Product) => {
    storageService.updateProduct(prod);
    setProducts(storageService.getProducts());
  };

  const handleDeleteProduct = (productId: string) => {
    storageService.deleteProduct(productId);
    setProducts(storageService.getProducts());
  };

  const handleRestockProduct = (data: {
    productId: string;
    productName: string;
    quantity: number;
    unitCost: number;
    supplierName?: string;
    invoiceNo?: string;
  }) => {
    storageService.restockProduct(data);
    setProducts(storageService.getProducts());
    setPurchases(storageService.getPurchases());
  };

  // Expense CRUD
  const handleAddExpense = (exp: Omit<Expense, 'id' | 'date'>) => {
    storageService.addExpense(exp);
    setExpenses(storageService.getExpenses());
  };

  const handleDeleteExpense = (id: string) => {
    storageService.deleteExpense(id);
    setExpenses(storageService.getExpenses());
  };

  // Profile & Settings
  const handleUpdateStoreProfile = (profile: StoreProfile) => {
    storageService.saveStoreProfile(profile);
    setStoreProfile(profile);
  };

  const handleUpdateFirebaseSettings = (settings: FirebaseSyncSettings) => {
    storageService.saveFirebaseSyncSettings(settings);
    setFirebaseSettings(settings);
  };

  // Role Switching
  const handleSelectRole = (role: UserRole) => {
    storageService.setActiveRole(role);
    setActiveRole(role);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-800">
      
      {/* Universal Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          // If cashier clicks dashboard, require PIN / show role switcher
          if (tab === 'dashboard' && activeRole === 'CASHIER') {
            setIsRoleModalOpen(true);
            return;
          }
          setActiveTab(tab);
        }}
        cartCount={cart.length}
        openMobileCart={() => setMobileCartOpen(true)}
        activeRole={activeRole}
        onSwitchRole={() => setIsRoleModalOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAddProduct={() => {
          setProductToEdit(null);
          setIsAddProductModalOpen(true);
        }}
        storeProfile={storeProfile}
        lowStockCount={lowStockCount}
        isFirebaseConfigured={firebaseSettings.isConfigured}
      />

      {/* Main View Render */}
      <main className="flex-1 pb-16 md:pb-8">
        {activeTab === 'pos' && (
          <POSView
            products={products}
            cart={cart}
            setCart={setCart}
            onCompleteSale={handleCompleteSale}
            onOpenAddProduct={() => {
              setProductToEdit(null);
              setIsAddProductModalOpen(true);
            }}
            onEditProduct={(prod) => {
              setProductToEdit(prod);
              setIsAddProductModalOpen(true);
            }}
            activeRole={activeRole}
            cashierName={activeRole === 'OWNER' ? storeProfile.ownerName || 'মালিক' : 'বিক্রেতা'}
          />
        )}

        {activeTab === 'invoices' && (
          <InvoiceListView
            invoices={invoices}
            onViewReceipt={handleViewReceipt}
            onPayDue={handlePayDue}
            activeRole={activeRole}
            onDeleteInvoice={handleDeleteInvoice}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            products={products}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
            onRestockProduct={handleRestockProduct}
            activeRole={activeRole}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardView
            invoices={invoices}
            expenses={expenses}
            purchases={purchases}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
            activeRole={activeRole}
            storeProfile={storeProfile}
          />
        )}

        {activeTab === 'duebook' && (
          <DueBookView
            customerDues={customerDues}
            onPayDue={handlePayDue}
            onUpdateDue={handleUpdateDue}
            storeProfile={storeProfile}
            invoices={invoices}
            products={products}
            onAddNewDue={handleAddNewDue}
            onViewReceipt={handleViewReceipt}
            cashierName={activeRole === 'OWNER' ? storeProfile.ownerName || 'মালিক' : 'বিক্রেতা'}
          />
        )}
      </main>

      {/* Mobile Sticky Bottom Bar when in POS with items in cart */}
      {activeTab === 'pos' && cart.length > 0 && !mobileCartOpen && (
        <div className="md:hidden fixed bottom-14 left-0 right-0 p-3 bg-white border-t border-slate-200 shadow-xl flex items-center justify-between z-20">
          <div>
            <div className="text-xs text-slate-500 font-medium">
              {toBnNum(cart.length)} টি পণ্য নির্বাচিত
            </div>
            <div className="text-base font-bold text-emerald-800 font-mono">
              মোট: ৳{toBnNum(cart.reduce((s, i) => s + i.lineTotal, 0))}
            </div>
          </div>
          <button
            onClick={() => setMobileCartOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-md"
          >
            <span>ক্যাশ মেমো দেখুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Mobile Cart Fullscreen Drawer */}
      {mobileCartOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-white rounded-t-3xl max-h-[88vh] overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 bg-emerald-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-300" />
                <h3 className="font-bold text-base">চলতি কার্ট ও মেমো বিল</h3>
              </div>
              <button
                onClick={() => setMobileCartOpen(false)}
                className="p-1 rounded-lg text-emerald-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto p-4 flex-1">
              <POSView
                products={products}
                cart={cart}
                setCart={setCart}
                onCompleteSale={handleCompleteSale}
                onOpenAddProduct={() => {
                  setMobileCartOpen(false);
                  setProductToEdit(null);
                  setIsAddProductModalOpen(true);
                }}
                onEditProduct={(prod) => {
                  setMobileCartOpen(false);
                  setProductToEdit(prod);
                  setIsAddProductModalOpen(true);
                }}
                activeRole={activeRole}
                cashierName={activeRole === 'OWNER' ? storeProfile.ownerName || 'মালিক' : 'বিক্রেতা'}
              />
            </div>
          </div>
        </div>
      )}

      {/* Super-Shop Style Cash Memo / Receipt Modal */}
      <ReceiptModal
        invoice={activeReceiptInvoice}
        isOpen={isReceiptModalOpen}
        onClose={() => setIsReceiptModalOpen(false)}
        onNewSale={() => {
          setIsReceiptModalOpen(false);
          setActiveTab('pos');
        }}
        storeProfile={storeProfile}
      />

      {/* Add / Edit Product Modal with Camera, Photo Upload & Continuous Add */}
      <AddProductModal
        isOpen={isAddProductModalOpen}
        onClose={() => {
          setIsAddProductModalOpen(false);
          setProductToEdit(null);
        }}
        onAddProduct={handleAddProduct}
        editingProduct={productToEdit}
        onUpdateProduct={handleUpdateProduct}
        onDeleteProduct={handleDeleteProduct}
      />

      {/* Settings, Backup & Cloud Sync Modal */}
      <BackupSyncModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        storeProfile={storeProfile}
        onUpdateStoreProfile={handleUpdateStoreProfile}
        firebaseSettings={firebaseSettings}
        onUpdateFirebaseSettings={handleUpdateFirebaseSettings}
        onDataRestored={loadAllData}
      />

      {/* User Role & Access Modal */}
      <RoleSwitchModal
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        currentRole={activeRole}
        onSelectRole={handleSelectRole}
        storeProfile={storeProfile}
      />

      {/* Universal Developer Credit Footer */}
      <footer className="bg-white border-t border-slate-200 py-3.5 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div>
            <span className="font-bold text-slate-800">{storeProfile.name}</span> — ডিজিটাল ক্যাশ মেমো, স্টক ও হিসাব সফটওয়্যার
          </div>
          <div className="text-slate-600 font-medium">
            Designed and Developed with ❤️ by <span className="font-bold text-emerald-800">Sheikh Akash</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
