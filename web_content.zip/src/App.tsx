import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { SplashScreen } from './components/SplashScreen';
import { HomeScreen } from './components/HomeScreen';
import { MorningEveningSpecializedView } from './components/MorningEveningSpecializedView';
import { DhikrListScreen } from './components/DhikrListScreen';
import { FavoritesScreen } from './components/FavoritesScreen';
import { SearchScreen } from './components/SearchScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { QiblaFinder } from './components/QiblaFinder';
import { PrayerTimesView } from './components/PrayerTimesView';
import { DhikrDetailView } from './components/DhikrDetailView';
import { AboutModal } from './components/AboutModal';
import { BottomNav } from './components/BottomNav';
import { Toast } from './components/Toast';
import { InAppNotificationBanner } from './components/InAppNotificationBanner';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { AmbientSoundModal } from './components/AmbientSoundModal';
import { SmartTasbeehCounter } from './components/SmartTasbeehCounter';

const AppContent: React.FC = () => {
  const { 
    activeTab, 
    splashDismissed, 
    dismissSplash, 
    settings,
    showTasbeehModal,
    setShowTasbeehModal
  } = useApp();

  if (!splashDismissed) {
    return <SplashScreen onStart={dismissSplash} />;
  }

  const isAmoled = settings.darkMode && settings.amoledMode;

  return (
    <div className={`min-h-screen ${isAmoled ? 'bg-black' : 'bg-[#02140e]'} text-[#e4f2ea] flex flex-col justify-start items-center selection:bg-emerald-700 selection:text-white transition-colors duration-300`}>
      {/* Mobile-Ergonomic Android App Shell Container */}
      <main className="w-full max-w-md min-h-screen flex flex-col px-4 pt-2 relative">
        {/* Tab View Router */}
        {activeTab === 'home' && <HomeScreen />}
        {activeTab === 'morning_evening' && <MorningEveningSpecializedView />}
        {activeTab === 'list' && <DhikrListScreen />}
        {activeTab === 'prayer_times' && <PrayerTimesView />}
        {activeTab === 'qibla' && <QiblaFinder />}
        {activeTab === 'favorites' && <FavoritesScreen />}
        {activeTab === 'search' && <SearchScreen />}
        {activeTab === 'settings' && <SettingsScreen />}

        {/* Global Floating Components */}
        <InAppNotificationBanner />
        <NotificationCenterModal />
        <AmbientSoundModal />
        <SmartTasbeehCounter 
          isOpen={showTasbeehModal} 
          onClose={() => setShowTasbeehModal(false)} 
        />
        <BottomNav />
        <DhikrDetailView />
        <AboutModal />
        <Toast />
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
