import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { OnboardingFlow } from './components/common/OnboardingFlow';
import { CustomerApp } from './components/customer/CustomerApp';
import { ManufacturerApp } from './components/manufacturer/ManufacturerApp';
import { WholesalerApp } from './components/wholesaler/WholesalerApp';
import { DriverApp } from './components/driver/DriverApp';
import { AdminApp } from './components/admin/AdminApp';
import { InvoiceModal } from './components/common/InvoiceModal';
import { Phone, Shield, Truck, HelpCircle } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentRole, isOnboarding, startOnboarding } = useApp();

  if (isOnboarding) {
    return <OnboardingFlow />;
  }

  return (
    <div className="min-h-screen bg-[#0d1117] text-slate-100 flex flex-col font-sans selection:bg-[#e55938] selection:text-white">
      {/* Top Universal Stakeholder Bar */}
      <Header />

      {/* Main Stakeholder Screen Router */}
      <main className="flex-1 pb-12">
        {currentRole === 'customer' && <CustomerApp />}
        {currentRole === 'manufacturer' && <ManufacturerApp />}
        {currentRole === 'wholesaler' && <WholesalerApp />}
        {currentRole === 'driver' && <DriverApp />}
        {(currentRole === 'admin' || currentRole === 'staff') && <AdminApp />}
      </main>

      {/* Global Invoice / Consignment Note Modal */}
      <InvoiceModal />

      {/* Comprehensive Footer */}
      <footer className="bg-[#0a0d13] border-t border-[#1e2633] py-8 px-4 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#e55938] text-white font-black flex items-center justify-center text-sm shadow-md">
              BX
            </div>
            <div>
              <div className="font-bold text-white text-sm">BRICK EXCHANGE</div>
              <div className="text-[11px] text-slate-500">
                Heavy Clay & Concrete Construction Materials B2B Marketplace • West Bengal & Bihar Kiln Network
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1.5 text-slate-400">
              <Phone className="w-3.5 h-3.5 text-amber-500" />
              <span>24/7 Kiln Dispatch Support: 1800-202-BRICK</span>
            </span>
            <span className="flex items-center gap-1.5 text-emerald-400">
              <Shield className="w-3.5 h-3.5" />
              <span>Escrow Protected Handover</span>
            </span>
            <button
              onClick={startOnboarding}
              className="text-amber-400 hover:underline cursor-pointer flex items-center gap-1"
            >
              <HelpCircle className="w-3 h-3" />
              <span>Re-run Onboarding</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500">
            © {new Date().getFullYear()} Brick Exchange Technologies Pvt Ltd. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
