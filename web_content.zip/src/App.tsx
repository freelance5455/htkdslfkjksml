import { useCallback, useEffect, useRef, useState } from "react";
import { Hud } from "@/components/Hud";
import { BriefingModal, GameOverOverlay, PauseOverlay, ServerBrowser, SettingsModal, WeaponWheel, type ServerInfo } from "@/components/Overlays";
import { StartScreen } from "@/components/StartScreen";
import { TouchControls } from "@/components/TouchControls";
import { Icon } from "@/components/ui";
import { audio } from "@/game/audio";
import { GameEngine } from "@/game/engine";
import { DEFAULT_SETTINGS, type GameEvent, type GameMode, type GameResults, type HighScore, type HudState, type Settings } from "@/game/types";

const SETTINGS_KEY = "tolok.settings.v1";
const SCORES_KEY = "tolok.scores.v1";
const NAME_KEY = "tolok.name.v1";

function loadSettings(): Settings {
  const coarse = typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches;
  const fallback: Settings = { ...DEFAULT_SETTINGS, touch: coarse, quality: coarse ? "low" : "high" };
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<Settings>;
      return { ...fallback, ...parsed };
    }
  } catch {
    /* ignore */
  }
  return fallback;
}

function loadScores(): HighScore[] {
  try {
    const raw = localStorage.getItem(SCORES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HighScore[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((s) => typeof s?.score === "number" && typeof s?.name === "string")
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  } catch {
    return [];
  }
}

function loadName() {
  try {
    return localStorage.getItem(NAME_KEY) || "Толок";
  } catch {
    return "Толок";
  }
}

type Screen = "menu" | "playing" | "paused" | "gameover";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const [mode, setMode] = useState<GameMode>("dm");
  const [nickname, setNickname] = useState(loadName);
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [highScores, setHighScores] = useState<HighScore[]>(loadScores);
  const [hud, setHud] = useState<HudState | null>(null);
  const [results, setResults] = useState<GameResults | null>(null);
  const [newRecord, setNewRecord] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showBriefing, setShowBriefing] = useState(false);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [showWeapons, setShowWeapons] = useState(false);
  const [showServers, setShowServers] = useState(false);
  const [serverName, setServerName] = useState<string | null>(null);
  const [hitKey, setHitKey] = useState(0);
  const [damageKey, setDamageKey] = useState(0);
  const [toast, setToast] = useState<{ id: number; text: string; tone?: "good" | "bad" | "info" } | null>(null);
  const [streak, setStreak] = useState<{ id: number; text: string } | null>(null);
  const [killBanner, setKillBanner] = useState<{ id: number; text: string } | null>(null);

  const screenRef = useRef<Screen>(screen);
  const nicknameRef = useRef(nickname);
  const modeRef = useRef(mode);
  const settingsRef = useRef(settings);
  const highScoresRef = useRef(highScores);
  const lastVolumes = useRef({ sfx: 0.75, music: 0.35 });
  const eventId = useRef(0);
  const pauseGuard = useRef(0);

  useEffect(() => {
    screenRef.current = screen;
  }, [screen]);
  useEffect(() => {
    nicknameRef.current = nickname;
    try {
      localStorage.setItem(NAME_KEY, nickname);
    } catch {
      /* ignore */
    }
  }, [nickname]);
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);
  useEffect(() => {
    highScoresRef.current = highScores;
  }, [highScores]);

  useEffect(() => {
    settingsRef.current = settings;
    engineRef.current?.applySettings(settings);
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      /* ignore */
    }
  }, [settings]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new GameEngine(
      canvas,
      {
        onHud: (next) => setHud(next),
        onGameOver: (r) => {
          const entry: HighScore = {
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            name: nicknameRef.current.trim() || "Игрок",
            score: r.score,
            kills: r.kills,
            mode: r.mode,
            date: new Date().toISOString(),
            accuracy: r.accuracy,
          };
          const prevBest = highScoresRef.current[0]?.score ?? 0;
          const next = [...highScoresRef.current, entry].sort((a, b) => b.score - a.score).slice(0, 8);
          highScoresRef.current = next;
          setHighScores(next);
          try {
            localStorage.setItem(SCORES_KEY, JSON.stringify(next));
          } catch {
            /* ignore */
          }
          setNewRecord(r.score > prevBest && r.score > 0);
          setResults(r);
          setShowScoreboard(false);
          setScreen("gameover");
        },
        onEvent: (event: GameEvent) => {
          switch (event.type) {
            case "hit":
              setHitKey((k) => k + 1);
              break;
            case "damage":
              setDamageKey((k) => k + 1);
              break;
            case "kill":
              setKillBanner({ id: ++eventId.current, text: event.text });
              break;
            case "streak":
              setStreak({ id: ++eventId.current, text: event.text });
              break;
            case "toast":
              setToast({ id: ++eventId.current, text: event.text, tone: event.tone ?? "info" });
              break;
            case "pickup":
              setToast({ id: ++eventId.current, text: event.text, tone: "good" });
              break;
            default:
              break;
          }
        },
        onPauseRequest: () => {
          pauseGuard.current = performance.now();
          if (screenRef.current === "playing") {
            engineRef.current?.setPaused(true);
            setShowScoreboard(false);
            setScreen("paused");
          }
        },
      },
      settingsRef.current
    );
    engineRef.current = engine;
    (window as unknown as { __tolok?: GameEngine }).__tolok = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
      delete (window as unknown as { __tolok?: GameEngine }).__tolok;
      audio.stopMusic();
    };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (!streak) return;
    const timer = window.setTimeout(() => setStreak(null), 1800);
    return () => window.clearTimeout(timer);
  }, [streak]);

  useEffect(() => {
    if (!killBanner) return;
    const timer = window.setTimeout(() => setKillBanner(null), 1500);
    return () => window.clearTimeout(timer);
  }, [killBanner]);

  useEffect(() => {
    if (screen !== "playing") setShowScoreboard(false);
  }, [screen]);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const soundOn = settings.sfx > 0 || settings.music > 0;

  const toggleSound = useCallback(() => {
    setSettings((prev) => {
      if (prev.sfx > 0 || prev.music > 0) {
        lastVolumes.current = { sfx: prev.sfx, music: prev.music };
        return { ...prev, sfx: 0, music: 0 };
      }
      return { ...prev, sfx: lastVolumes.current.sfx || 0.75, music: lastVolumes.current.music || 0.35 };
    });
  }, []);

  const startMatch = useCallback((nextMode: GameMode) => {
    modeRef.current = nextMode;
    setMode(nextMode);
    audio.init();
    audio.setVolumes(settingsRef.current.sfx, settingsRef.current.music);
    if (settingsRef.current.music > 0) audio.startMusic();
    audio.play("click");
    setResults(null);
    setNewRecord(false);
    setShowScoreboard(false);
    setShowWeapons(false);
    setShowServers(false);
    setToast(null);
    setStreak(null);
    setKillBanner(null);
    engineRef.current?.start(nextMode, nicknameRef.current);
    setScreen("playing");
  }, []);

  const startGame = useCallback(() => {
    setServerName(null);
    startMatch(modeRef.current);
  }, [startMatch]);

  const connectToServer = useCallback(
    (server: ServerInfo) => {
      setServerName(server.name);
      startMatch(server.mode);
      setToast({ id: ++eventId.current, text: `Подключено: ${server.name}`, tone: "good" });
    },
    [startMatch]
  );

  const pauseGame = useCallback(() => {
    if (screenRef.current !== "playing") return;
    engineRef.current?.setPaused(true);
    setShowScoreboard(false);
    setShowWeapons(false);
    setShowServers(false);
    setScreen("paused");
    audio.play("click");
  }, []);

  const resumeGame = useCallback(() => {
    engineRef.current?.setPaused(false);
    setScreen("playing");
    audio.play("click");
  }, []);

  const restartGame = useCallback(() => {
    startMatch(modeRef.current);
  }, [startMatch]);

  const goMenu = useCallback(() => {
    engineRef.current?.toMenu();
    setShowWeapons(false);
    setShowServers(false);
    setServerName(null);
    setScreen("menu");
    setResults(null);
    setShowScoreboard(false);
    setToast(null);
    setStreak(null);
    setKillBanner(null);
    audio.stopMusic();
    audio.play("click");
  }, []);

  const resetScores = useCallback(() => {
    highScoresRef.current = [];
    setHighScores([]);
    setNewRecord(false);
    try {
      localStorage.removeItem(SCORES_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  const onSelectWeapon = useCallback((index: number) => {
    engineRef.current?.selectWeapon(index);
  }, []);

  const openWeapons = useCallback(() => {
    if (screenRef.current !== "playing") return;
    engineRef.current?.setPaused(true);
    setShowWeapons(true);
    audio.play("click");
  }, []);

  const closeWeapons = useCallback(() => {
    setShowWeapons(false);
    if (screenRef.current === "playing") engineRef.current?.setPaused(false);
  }, []);

  const selectWeaponFromWheel = useCallback((index: number) => {
    engineRef.current?.selectWeapon(index);
    setShowWeapons(false);
    if (screenRef.current === "playing") engineRef.current?.setPaused(false);
    audio.play("click");
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
      if (e.code === "Tab" && screenRef.current === "playing") {
        e.preventDefault();
        setShowScoreboard(true);
        return;
      }
      if (typing) return;
      if (e.code === "KeyX" && screenRef.current === "playing" && !showWeapons) {
        e.preventDefault();
        openWeapons();
        return;
      }
      if (e.code === "KeyM" && (screenRef.current === "playing" || screenRef.current === "paused")) {
        e.preventDefault();
        toggleSound();
        return;
      }
      if (e.code === "Escape") {
        if (showServers) {
          e.preventDefault();
          setShowServers(false);
          return;
        }
        if (showWeapons) {
          e.preventDefault();
          closeWeapons();
          return;
        }
        if (performance.now() - pauseGuard.current < 250) return;
        if (screenRef.current === "paused") {
          e.preventDefault();
          resumeGame();
        } else if (screenRef.current === "gameover") {
          e.preventDefault();
          goMenu();
        } else if (screenRef.current === "menu" && (showSettings || showBriefing)) {
          setShowSettings(false);
          setShowBriefing(false);
        }
      }
      if (e.code === "Enter" && screenRef.current === "menu" && !showSettings && !showBriefing) {
        e.preventDefault();
        startGame();
      }
      if (e.code === "KeyR" && (screenRef.current === "gameover" || screenRef.current === "paused")) {
        e.preventDefault();
        restartGame();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Tab") setShowScoreboard(false);
    };
    const onBlur = () => {
      if (screenRef.current === "playing") pauseGame();
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, [showSettings, showBriefing, showWeapons, showServers, startGame, restartGame, resumeGame, goMenu, pauseGame, closeWeapons, openWeapons, toggleSound]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink-deep">
      <canvas ref={canvasRef} className="fixed inset-0 z-0 h-full w-full" />

      {screen === "menu" && (
        <StartScreen
          mode={mode}
          onModeChange={setMode}
          nickname={nickname}
          onNicknameChange={setNickname}
          onStart={startGame}
          highScores={highScores}
          settings={settings}
          onSettingsChange={updateSettings}
          onOpenSettings={() => setShowSettings(true)}
          onOpenBriefing={() => setShowBriefing(true)}
          onOpenServers={() => setShowServers(true)}
          soundOn={soundOn}
          onToggleSound={toggleSound}
        />
      )}

      {screen !== "menu" && hud && (
        <Hud
          hud={hud}
          nickname={nickname.trim() || "Игрок"}
          serverName={serverName}
          soundOn={soundOn}
          touch={settings.touch}
          hitKey={hitKey}
          damageKey={damageKey}
          toast={toast}
          streak={streak}
          killBanner={killBanner}
          showScoreboard={showScoreboard}
          onPause={pauseGame}
          onToggleSound={toggleSound}
          onToggleScoreboard={() => setShowScoreboard((v) => !v)}
          onSelectWeapon={onSelectWeapon}
          onOpenWeapons={openWeapons}
        />
      )}

      {screen === "playing" && settings.touch && hud && (
        <TouchControls
          layout={settings.layout}
          grenades={hud.grenades}
          nearVehicle={!!hud.nearVehicle}
          inVehicle={!!hud.vehicle}
          crouched={hud.crouched}
          onMove={(x, y) => engineRef.current?.setMove(x, y)}
          onLook={(dx, dy) => engineRef.current?.addLook(dx, dy)}
          onFire={(down) => engineRef.current?.setFiring(down)}
          onJump={() => engineRef.current?.jump()}
          onCrouch={() => engineRef.current?.toggleCrouch()}
          onReload={() => engineRef.current?.reload()}
          onOpenWeapons={openWeapons}
          onGrenadeDown={() => engineRef.current?.beginGrenade()}
          onGrenadeUp={() => engineRef.current?.releaseGrenade()}
          onUse={() => engineRef.current?.useAction()}
          onAim={(down) => engineRef.current?.setAim(down)}
          onCamera={() => engineRef.current?.toggleCamera()}
          onPause={pauseGame}
        />
      )}

      {screen === "playing" && !settings.touch && <DesktopHint />}

      {screen === "paused" && (
        <PauseOverlay
          hud={hud}
          settings={settings}
          onResume={resumeGame}
          onRestart={restartGame}
          onMenu={goMenu}
          onSettingsChange={updateSettings}
          onOpenBriefing={() => setShowBriefing(true)}
        />
      )}

      {screen === "gameover" && results && (
        <GameOverOverlay results={results} highScores={highScores} newRecord={newRecord} nickname={nickname.trim() || "Игрок"} onRestart={restartGame} onMenu={goMenu} />
      )}

      {showServers && <ServerBrowser nickname={nickname.trim() || "Игрок"} onClose={() => setShowServers(false)} onConnect={connectToServer} />}

      {showWeapons && hud && <WeaponWheel hud={hud} onSelect={selectWeaponFromWheel} onClose={closeWeapons} />}

      {showSettings && <SettingsModal settings={settings} onChange={updateSettings} onClose={() => setShowSettings(false)} onResetScores={resetScores} />}
      {showBriefing && <BriefingModal onClose={() => setShowBriefing(false)} />}
    </div>
  );
}

function DesktopHint() {
  return (
    <div className="pointer-events-none fixed bottom-3 left-3 z-20 hidden items-center gap-2 rounded-xl border-2 border-cream/10 bg-ink/55 px-2.5 py-1.5 backdrop-blur-sm md:flex">
      <Icon name="keyboard" className="h-3.5 w-3.5 text-cream/40" />
      <span className="text-[9px] font-bold uppercase tracking-wider text-cream/40">
        <span className="text-cream/70">WASD</span> движение · <span className="text-cream/70">ЛКМ</span> огонь · <span className="text-cream/70">E</span> машина · <span className="text-cream/70">X</span> оружие · <span className="text-cream/70">ESC</span> пауза
      </span>
    </div>
  );
}
