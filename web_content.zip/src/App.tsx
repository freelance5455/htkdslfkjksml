import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Sparkles,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Paperclip,
  Image as ImageIcon,
  Camera,
  Monitor,
  Smartphone,
  Trash2,
  Download,
  Copy,
  Check,
  RotateCcw,
  Eye,
  Settings,
  HelpCircle,
  FileText,
  X,
  ChevronDown,
  Layers,
  ArrowUp,
  Flame,
  Zap,
  Globe,
  SlidersHorizontal,
  Radio,
  Search,
  HardDrive,
  ShieldCheck,
  Menu,
  Plus,
  Play,
  User,
  ExternalLink
} from 'lucide-react';

import {
  ChatMessage,
  Attachment,
  PersonaType,
  ToneType,
  VoiceCommandTrigger,
  VoiceActionType,
  ChatSession,
  UserProfile
} from './types';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { PhoneAssistantModal } from './components/PhoneAssistantModal';
import { ScreenReaderModal } from './components/ScreenReaderModal';
import { VoiceCommandsModal } from './components/VoiceCommandsModal';
import { ChatSearchModal } from './components/ChatSearchModal';
import { HamburgerMenu } from './components/HamburgerMenu';
import { AmbientVoiceModal } from './components/AmbientVoiceModal';
import { LoginModal } from './components/LoginModal';
import {
  compressImageFile,
  saveChatHistorySafely,
  loadChatHistorySafely,
  loadSessionsSafely,
  saveSessionsSafely,
  loadActiveSessionId,
  saveActiveSessionId,
  loadUserProfile,
  saveUserProfile,
  getStorageUsage
} from './utils/storage';
import { playWakeChime, playSuccessChime } from './utils/audio';

const PERSONAS: Array<{
  id: PersonaType;
  label: string;
  emoji: string;
  desc: string;
  gradient: string;
}> = [
  {
    id: 'mast_friend',
    label: 'Mast AI (Dildaar)',
    emoji: '🔥',
    desc: 'Fun, witty, super smart answers in Hinglish',
    gradient: 'from-orange-500/20 to-amber-500/20 border-orange-500/40 text-orange-400',
  },
  {
    id: 'screen_accessibility',
    label: 'Screen Reader & Vision',
    emoji: '🖥️',
    desc: 'Deep OCR, UI inspection & accessible audio guidance',
    gradient: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/40 text-emerald-400',
  },
  {
    id: 'phone_assistant',
    label: 'Phone Assistant',
    emoji: '📱',
    desc: 'Device stats, call/sms shortcuts, reminders & tools',
    gradient: 'from-cyan-500/20 to-blue-500/20 border-cyan-500/40 text-cyan-400',
  },
  {
    id: 'coder',
    label: 'Super Coder',
    emoji: '💻',
    desc: 'Production-grade code, architecture & bug fixes',
    gradient: 'from-violet-500/20 to-indigo-500/20 border-violet-500/40 text-violet-400',
  },
  {
    id: 'tutor',
    label: 'Study Tutor',
    emoji: '🎓',
    desc: 'Clear step-by-step explanations for homework & concepts',
    gradient: 'from-pink-500/20 to-rose-500/20 border-pink-500/40 text-pink-400',
  },
  {
    id: 'creative',
    label: 'Creative Storyteller',
    emoji: '✨',
    desc: 'Shayari, scripts, catchy reels captions & lyrics',
    gradient: 'from-purple-500/20 to-fuchsia-500/20 border-purple-500/40 text-purple-400',
  },
];

const TONES: Array<{ id: ToneType; label: string; icon: string }> = [
  { id: 'chatpata', label: 'Mast & Chatpata', icon: '🔥' },
  { id: 'concise', label: 'Short & Crisp', icon: '⚡' },
  { id: 'detailed', label: 'Deep & Detailed', icon: '📖' },
  { id: 'shuddh_hindi', label: 'Hindi', icon: '🇮🇳' },
  { id: 'english', label: 'English', icon: '🌐' },
];

const DEFAULT_VOICE_TRIGGERS: VoiceCommandTrigger[] = [
  {
    id: 'trig-0',
    phrase: 'Hey Nova',
    action: 'wake_greeting',
    enabled: true,
    isBuiltIn: true,
    description: 'Wakeword greeting: Nova answers and asks how to help you',
  },
  {
    id: 'trig-youtube',
    phrase: 'Hey Nova, open YouTube',
    action: 'open_youtube',
    enabled: true,
    isBuiltIn: true,
    description: 'Directly opens YouTube in a new tab or app',
  },
  {
    id: 'trig-google',
    phrase: 'Hey Nova, open Google',
    action: 'open_google',
    enabled: true,
    isBuiltIn: true,
    description: 'Opens Google Search in a new tab',
  },
  {
    id: 'trig-music',
    phrase: 'Hey Nova, play music',
    action: 'play_music',
    enabled: true,
    isBuiltIn: true,
    description: 'Plays music / opens YouTube Music',
  },
  {
    id: 'trig-maps',
    phrase: 'Hey Nova, open Maps',
    action: 'open_maps',
    enabled: true,
    isBuiltIn: true,
    description: 'Opens Google Maps navigation',
  },
  {
    id: 'trig-search',
    phrase: 'Hey Nova, search history',
    action: 'open_search',
    enabled: true,
    isBuiltIn: true,
    description: 'Search previous chat messages, responses, and files',
  },
  {
    id: 'trig-1',
    phrase: 'Hey Nova, clear my tasks',
    action: 'clear_tasks',
    enabled: true,
    isBuiltIn: true,
    description: 'Clears all reminders and pending phone tasks',
  },
  {
    id: 'trig-2',
    phrase: 'Hey Nova, read screen',
    action: 'read_screen',
    enabled: true,
    isBuiltIn: true,
    description: 'Captures active desktop/tab & runs accessibility OCR',
  },
  {
    id: 'trig-3',
    phrase: 'Hey Nova, open phone tools',
    action: 'open_phone_tools',
    enabled: true,
    isBuiltIn: true,
    description: 'Opens Phone Assistant & device health modal',
  },
  {
    id: 'trig-4',
    phrase: 'Hey Nova, clear chat',
    action: 'clear_chat',
    enabled: true,
    isBuiltIn: true,
    description: 'Clears active chat conversation',
  },
  {
    id: 'trig-5',
    phrase: 'Hey Nova, export chat',
    action: 'export_chat',
    enabled: true,
    isBuiltIn: true,
    description: 'Exports chat history to a downloaded text file',
  },
  {
    id: 'trig-6',
    phrase: 'Hey Nova, switch to coder',
    action: 'switch_persona',
    actionPayload: 'coder',
    enabled: true,
    isBuiltIn: true,
    description: 'Switches AI persona to Super Coder mode',
  },
  {
    id: 'trig-7',
    phrase: 'Hey Nova, mast ho jao',
    action: 'switch_persona',
    actionPayload: 'mast_friend',
    enabled: true,
    isBuiltIn: true,
    description: 'Switches AI persona to Mast AI (Dildaar)',
  },
  {
    id: 'trig-8',
    phrase: 'Hey Nova, toggle voice',
    action: 'toggle_auto_speak',
    enabled: true,
    isBuiltIn: true,
    description: 'Toggles speech audio auto-speak on or off',
  },
  {
    id: 'trig-9',
    phrase: 'Hey Nova, tell me a joke',
    action: 'send_custom_prompt',
    actionPayload: 'Ek mast chatpata joke sunao Hinglish me!',
    enabled: true,
    isBuiltIn: true,
    description: 'Asks AI to tell a funny energetic joke',
  },
];

export function App() {
  // Multi-session Chat History
  const [sessions, setSessions] = useState<ChatSession[]>(() => loadSessionsSafely());
  const [activeSessionId, setActiveSessionId] = useState<string>(() => loadActiveSessionId());

  // Messages loaded from active session or fallback
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const loadedSessions = loadSessionsSafely();
    const activeId = loadActiveSessionId();
    const currentSession = loadedSessions.find((s) => s.id === activeId) || loadedSessions[0];
    if (currentSession && currentSession.messages && currentSession.messages.length > 0) {
      return currentSession.messages;
    }
    const saved = loadChatHistorySafely();
    if (saved && saved.length > 0) {
      return saved;
    }
    return [
      {
        id: 'welcome',
        role: 'model',
        content: `### Namaste! Main hoon aapka All-in-One Super AI Assistant 🚀\n\nAap mujhse **kisi bhi topic par sawal puch sakte ho**:\n* 🎙️ **Voice Assistant Active**: Bolo **"Hey Nova, open YouTube"** ya mic dabao!\n* ☰ **Three Line Menu**: Upar ☰ menu dabao saare tools (Chat History, Phone Tools, Screen Reader, Voice Triggers) ke liye!\n* 🖼️ **Photos & Documents**: Photos, screenshots, bills ya PDFs attach karke OCR karao.\n\nBataiye, aaj kis cheez me help karoon? Ekdum mast reply milega! 🔥`,
        timestamp: Date.now(),
        persona: 'mast_friend',
      },
    ];
  });

  const [input, setInput] = useState('');
  const [persona, setPersona] = useState<PersonaType>('mast_friend');
  const [tone, setTone] = useState<ToneType>('chatpata');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // User Profile & Login System
  const [userProfile, setUserProfile] = useState<UserProfile>(() => loadUserProfile());
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Hamburger Menu (Three Line ☰ Drawer)
  const [isHamburgerOpen, setIsHamburgerOpen] = useState(false);

  // Ambient Voice Mode ("Hey Nova, open YouTube" with Screen Stay-Awake)
  const [isAmbientVoiceOpen, setIsAmbientVoiceOpen] = useState(false);

  // Storage Stats & Zero-Bloat Monitor
  const [storageStats, setStorageStats] = useState(getStorageUsage);
  const [isStorageModalOpen, setIsStorageModalOpen] = useState(false);

  // Custom Voice Commands System
  const [voiceTriggers, setVoiceTriggers] = useState<VoiceCommandTrigger[]>(() => {
    try {
      const saved = localStorage.getItem('nova_voice_triggers');
      if (saved) {
        let parsed: VoiceCommandTrigger[] = JSON.parse(saved);
        if (!parsed.some((t) => t.action === 'wake_greeting')) {
          parsed = [DEFAULT_VOICE_TRIGGERS[0], ...parsed];
        }
        if (!parsed.some((t) => t.action === 'open_youtube')) {
          parsed = [DEFAULT_VOICE_TRIGGERS[1], ...parsed];
        }
        if (!parsed.some((t) => t.action === 'open_search')) {
          parsed = [DEFAULT_VOICE_TRIGGERS.find(t => t.action === 'open_search') || DEFAULT_VOICE_TRIGGERS[5], ...parsed];
        }
        return parsed;
      }
    } catch {}
    return DEFAULT_VOICE_TRIGGERS;
  });

  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);
  const [continuousListening, setContinuousListening] = useState(() => {
    try {
      return localStorage.getItem('nova_continuous_voice') === 'true';
    } catch {
      return false;
    }
  });
  const [lastExecutedCommand, setLastExecutedCommand] = useState<{
    phrase: string;
    time: number;
    actionName: string;
  } | null>(null);

  const [voiceToast, setVoiceToast] = useState<{
    phrase: string;
    actionName: string;
  } | null>(null);

  // Modals & Panels
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const [isScreenModalOpen, setIsScreenModalOpen] = useState(false);
  const [highContrast, setHighContrast] = useState(false);

  // Voice & Audio
  const [isListening, setIsListening] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [speechRate, setSpeechRate] = useState(1.0);

  // File Inputs Ref
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Prevent any APK install prompt banner when the app is run
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      return false;
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  // Save voice triggers
  useEffect(() => {
    try {
      localStorage.setItem('nova_voice_triggers', JSON.stringify(voiceTriggers));
    } catch {}
  }, [voiceTriggers]);

  // Save continuous listening pref
  useEffect(() => {
    try {
      localStorage.setItem('nova_continuous_voice', String(continuousListening));
    } catch {}
  }, [continuousListening]);

  // Save messages and active session safely to localStorage without memory bloat & refresh storage stats
  useEffect(() => {
    setSessions((prevSessions) => {
      const updated = prevSessions.map((sess) => {
        if (sess.id === activeSessionId) {
          let title = sess.title;
          if (title === 'New Chat' || title === 'Welcome to Nova') {
            const firstUser = messages.find((m) => m.role === 'user');
            if (firstUser) {
              title = firstUser.content.slice(0, 32) + (firstUser.content.length > 32 ? '...' : '');
            }
          }
          return {
            ...sess,
            title,
            updatedAt: Date.now(),
            messages,
          };
        }
        return sess;
      });
      saveSessionsSafely(updated);
      return updated;
    });
    saveChatHistorySafely(messages);
    setStorageStats(getStorageUsage());
  }, [messages, activeSessionId]);

  // Session Handlers for Chat History Drawer
  const handleSelectSession = (sessionId: string) => {
    setActiveSessionId(sessionId);
    saveActiveSessionId(sessionId);
    const found = sessions.find((s) => s.id === sessionId);
    if (found) {
      setMessages(found.messages);
    }
  };

  const handleNewChat = () => {
    const newId = 'sess-' + Date.now();
    const initialMessages: ChatMessage[] = [
      {
        id: 'welcome-' + Date.now(),
        role: 'model',
        content: `Aadab aur namaste! Main hoon aapka **Nova AI Assistant 3.8** ✨.\n\nBatao bhai, aaj kya help chahiye? Aap mujhse Hindi, English ya Hinglish mein baat kar sakte ho. Voice command dena ho to keh sakte ho **"Hey Nova, open YouTube"** ya mic dabao!`,
        timestamp: Date.now(),
        persona,
        tone,
      },
    ];
    const newSession: ChatSession = {
      id: newId,
      title: 'New Chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: initialMessages,
    };
    const updatedSessions = [newSession, ...sessions];
    setSessions(updatedSessions);
    saveSessionsSafely(updatedSessions);
    setActiveSessionId(newId);
    saveActiveSessionId(newId);
    setMessages(initialMessages);
  };

  const handleDeleteSession = (sessionId: string) => {
    const filtered = sessions.filter((s) => s.id !== sessionId);
    if (filtered.length === 0) {
      handleNewChat();
      return;
    }
    setSessions(filtered);
    saveSessionsSafely(filtered);
    if (activeSessionId === sessionId) {
      setActiveSessionId(filtered[0].id);
      saveActiveSessionId(filtered[0].id);
      setMessages(filtered[0].messages);
    }
  };

  const handleRenameSession = (sessionId: string, newTitle: string) => {
    const updated = sessions.map((s) => (s.id === sessionId ? { ...s, title: newTitle } : s));
    setSessions(updated);
    saveSessionsSafely(updated);
  };

  const handleSaveProfile = (profile: UserProfile) => {
    setUserProfile(profile);
    saveUserProfile(profile);
  };

  // Scroll to bottom on new message
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Global Clipboard paste handler for screenshots
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            processImageFile(file, 'Clipboard_Screenshot.png');
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  // Global Keyboard shortcut for search (Ctrl+F, Cmd+F, Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey || e.metaKey) &&
        (e.key.toLowerCase() === 'f' || e.key.toLowerCase() === 'k')
      ) {
        // Prevent default browser find bar if inside chat
        e.preventDefault();
        setIsSearchModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Jump to specific message from search results
  const handleJumpToMessage = (messageId: string) => {
    setIsSearchModalOpen(false);
    setTimeout(() => {
      const element = document.getElementById(`msg-${messageId}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setHighlightedMessageId(messageId);
        setTimeout(() => {
          setHighlightedMessageId((current) => (current === messageId ? null : current));
        }, 3500);
      }
    }, 150);
  };

  // Play audio chime for voice commands
  const playCommandChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.12); // G5
      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.28);
    } catch {}
  };

  // Text-to-Speech logic
  const speakText = (text: string, messageId: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Aapke browser me Text-to-Speech support nahi hai.');
      return;
    }

    if (speakingMessageId === messageId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();

    // Strip code blocks and raw markdown symbols for clean audio speech
    const cleanSpeech = text
      .replace(/```[\s\S]*?```/g, 'Code block omitted from voice.')
      .replace(/[*_#`>]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .trim();

    if (!cleanSpeech) return;

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;

    // Pick best voice
    const voices = window.speechSynthesis.getVoices();
    const hindiOrIndianVoice = voices.find(
      (v) => v.lang.includes('hi') || v.lang.includes('IN') || v.name.includes('India')
    );
    if (hindiOrIndianVoice) {
      utterance.voice = hindiOrIndianVoice;
    }

    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);

    setSpeakingMessageId(messageId);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingMessageId(null);
  };

  // Screen Capture (Read My Screen)
  const triggerScreenCapture = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      alert('Screen Capture API is not supported in this browser or environment. Please upload a screenshot instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { displaySurface: 'monitor' } as any,
      });

      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64Data = canvas.toDataURL('image/jpeg', 0.85);

        const newAttachment: Attachment = {
          id: Date.now().toString(),
          name: `Screen_Capture_${new Date().toLocaleTimeString().replace(/:/g, '-')}.jpg`,
          type: 'screen',
          mimeType: 'image/jpeg',
          base64: base64Data,
          previewUrl: base64Data,
        };

        setAttachments((prev) => [...prev, newAttachment]);
        setPersona('screen_accessibility');
        setInput('Meri is screen ko dhyan se padho aur batao kya kya hai, text kya likha hai, aur accessibility ke hisaab se mujhe kya karna chahiye.');
      }

      // Stop stream tracks
      stream.getTracks().forEach((track) => track.stop());
    } catch (err: any) {
      console.warn('Screen capture cancelled or blocked:', err);
      if (err.name !== 'NotAllowedError') {
        alert('Screen capture access nahi mil saka. Aap screenshot upload kar sakte hain.');
      }
    }
  };

  // Execute Voice Command Action
  const executeVoiceAction = useCallback(
    (trigger: VoiceCommandTrigger, spokenTranscript?: string) => {
      playCommandChime();

      let actionName = trigger.description || 'Command executed';

      if (trigger.action === 'wake_greeting') {
        const greetingAudio = 'Haanji bhai! Nova haazir hai. Boliye, main aapki kya madad karoon?';
        actionName = 'Nova: "Haanji bhai! Nova haazir hai, boliye aaj kya help karoon?"';
        speakText(greetingAudio, 'cmd-wake-' + Date.now());
      } else if (trigger.action === 'open_youtube') {
        actionName = 'Opening YouTube 🎬';
        playSuccessChime();
        window.open('https://www.youtube.com', '_blank');
        if (autoSpeak) {
          speakText('YouTube open kar raha hoon bhai.', 'cmd-tts');
        }
      } else if (trigger.action === 'open_google') {
        actionName = 'Opening Google Search 🌐';
        playSuccessChime();
        window.open('https://www.google.com', '_blank');
      } else if (trigger.action === 'play_music') {
        actionName = 'Playing Music on YouTube 🎵';
        playSuccessChime();
        window.open('https://music.youtube.com', '_blank');
        if (autoSpeak) {
          speakText('Music start kar diya hai.', 'cmd-tts');
        }
      } else if (trigger.action === 'open_maps') {
        actionName = 'Opening Google Maps 📍';
        playSuccessChime();
        window.open('https://maps.google.com', '_blank');
      } else if (trigger.action === 'open_search') {
        actionName = 'Opened Chat History & Files Search';
        setIsSearchModalOpen(true);
        if (autoSpeak) {
          speakText('Chat aur files history search open kar diya hai.', 'cmd-tts');
        }
      } else if (trigger.action === 'clear_tasks') {
        actionName = 'Cleared all tasks & reminders';
        try {
          localStorage.setItem('nova_phone_reminders', JSON.stringify([]));
          window.dispatchEvent(new Event('nova_reminders_updated'));
        } catch {}
        if (autoSpeak) {
          speakText('Maine aapke phone ke saare tasks aur reminders clear kar diye hain.', 'cmd-tts');
        }
      } else if (trigger.action === 'read_screen') {
        actionName = 'Captured & Reading Screen';
        triggerScreenCapture();
      } else if (trigger.action === 'open_phone_tools') {
        actionName = 'Opened Phone Assistant';
        setIsPhoneModalOpen(true);
      } else if (trigger.action === 'open_screen_reader') {
        actionName = 'Opened Screen Reader Settings';
        setIsScreenModalOpen(true);
      } else if (trigger.action === 'clear_chat') {
        actionName = 'Cleared Chat History';
        clearChat();
      } else if (trigger.action === 'export_chat') {
        actionName = 'Exported Chat';
        exportChat();
      } else if (trigger.action === 'toggle_auto_speak') {
        setAutoSpeak((prev) => {
          const next = !prev;
          actionName = `Auto Speak ${next ? 'Turned ON' : 'Turned OFF'}`;
          if (!next) stopSpeaking();
          return next;
        });
      } else if (trigger.action === 'switch_persona') {
        const targetPersona = (trigger.actionPayload as PersonaType) || 'mast_friend';
        setPersona(targetPersona);
        actionName = `Switched Persona to ${PERSONAS.find((p) => p.id === targetPersona)?.label || targetPersona}`;
      } else if (trigger.action === 'switch_tone') {
        const targetTone = (trigger.actionPayload as ToneType) || 'chatpata';
        setTone(targetTone);
        actionName = `Switched Tone to ${targetTone}`;
      } else if (trigger.action === 'send_custom_prompt') {
        const promptToSend = trigger.actionPayload || 'Ek mast joke sunao!';
        actionName = `Asked AI: "${promptToSend}"`;
        handleSendMessage(promptToSend);
      }

      setLastExecutedCommand({
        phrase: spokenTranscript || trigger.phrase,
        time: Date.now(),
        actionName,
      });

      setVoiceToast({
        phrase: spokenTranscript || trigger.phrase,
        actionName,
      });

      setTimeout(() => {
        setVoiceToast((prev) => (prev?.actionName === actionName ? null : prev));
      }, 4000);
    },
    [autoSpeak]
  );

  // Speech Recognition (Voice Input with Custom Triggers Detection)
  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Chrome or Edge recommended.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'hi-IN'; // Multi-lingual recognition for Hindi, Hinglish and English
    recognition.interimResults = true;
    recognition.continuous = continuousListening;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      let currentTranscript = '';
      for (let i = 0; i < event.results.length; i++) {
        currentTranscript += event.results[i][0].transcript;
      }

      // Check if transcript matches any defined voice command trigger
      const cleanTranscript = currentTranscript
        .toLowerCase()
        .replace(/[.,!?;:'"-]/g, '')
        .trim();

      let matchedTrigger: VoiceCommandTrigger | null = null;

      // Sort by length descending so longer triggers (e.g. "Hey Nova, clear my tasks") match before shorter ("Hey Nova")
      const sortedTriggers = [...voiceTriggers.filter((t) => t.enabled)].sort(
        (a, b) => b.phrase.length - a.phrase.length
      );

      for (const trig of sortedTriggers) {
        const cleanPhrase = trig.phrase
          .toLowerCase()
          .replace(/[.,!?;:'"-]/g, '')
          .trim();

        // Special handling for wake_greeting ("Hey Nova", "Hello Nova", "Nova", "Hi Nova")
        if (trig.action === 'wake_greeting') {
          const isWakeGreeting =
            cleanTranscript === 'hey nova' ||
            cleanTranscript === 'hello nova' ||
            cleanTranscript === 'hi nova' ||
            cleanTranscript === 'nova' ||
            cleanTranscript === 'hey nova suno' ||
            cleanTranscript === 'suno nova';
          if (isWakeGreeting) {
            matchedTrigger = trig;
            break;
          }
        }

        // Variations without "hey nova" or "nova"
        const phraseWithoutWake = cleanPhrase
          .replace(/^hey\s+nova\s*,?\s*/i, '')
          .replace(/^nova\s*,?\s*/i, '')
          .trim();

        const isExactMatch = cleanTranscript === cleanPhrase;
        const isSubstring = cleanTranscript.includes(cleanPhrase);
        const isWakeMatch =
          phraseWithoutWake.length > 3 &&
          (cleanTranscript === phraseWithoutWake || cleanTranscript.includes(phraseWithoutWake));

        if (isExactMatch || isSubstring || isWakeMatch) {
          matchedTrigger = trig;
          break;
        }
      }

      if (matchedTrigger) {
        // Voice Trigger Matched!
        executeVoiceAction(matchedTrigger, currentTranscript);
        setInput('');
        if (!continuousListening) {
          try {
            recognition.stop();
          } catch {}
          setIsListening(false);
        }
        return;
      }

      setInput((prev) => (prev ? `${prev} ${currentTranscript}` : currentTranscript));
    };

    recognition.onerror = (err: any) => {
      console.warn('Speech error:', err);
      setIsListening(false);
    };

    recognition.onend = () => {
      if (continuousListening && isListening) {
        try {
          recognition.start();
          return;
        } catch {}
      }
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  // Add / Edit / Delete Triggers
  const handleAddTrigger = (trigger: Omit<VoiceCommandTrigger, 'id'>) => {
    const newTrig: VoiceCommandTrigger = {
      ...trigger,
      id: `custom-${Date.now()}`,
    };
    setVoiceTriggers((prev) => [newTrig, ...prev]);
  };

  const handleToggleTrigger = (id: string) => {
    setVoiceTriggers((prev) =>
      prev.map((t) => (t.id === id ? { ...t, enabled: !t.enabled } : t))
    );
  };

  const handleDeleteTrigger = (id: string) => {
    setVoiceTriggers((prev) => prev.filter((t) => t.id !== id));
  };

  // Process image files with instant auto-compression (zero bloat & lightning fast)
  const processImageFile = async (file: File, customName?: string) => {
    try {
      const { base64, previewUrl, size } = await compressImageFile(file, 1280, 0.82);
      const newAtt: Attachment = {
        id: Date.now().toString() + Math.random(),
        name: customName || file.name,
        type: 'image',
        mimeType: 'image/jpeg',
        size: size,
        base64: base64,
        previewUrl: previewUrl,
      };
      setAttachments((prev) => [...prev, newAtt]);
    } catch {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        const newAtt: Attachment = {
          id: Date.now().toString() + Math.random(),
          name: customName || file.name,
          type: 'image',
          mimeType: file.type || 'image/jpeg',
          size: file.size,
          base64: base64,
          previewUrl: base64,
        };
        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsDataURL(file);
    }
  };

  // Process document/code files
  const processDocFile = (file: File) => {
    if (file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        const newAtt: Attachment = {
          id: Date.now().toString() + Math.random(),
          name: file.name,
          type: 'file',
          mimeType: 'application/pdf',
          size: file.size,
          base64: base64,
        };
        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsDataURL(file);
    } else {
      const reader = new FileReader();
      reader.onload = () => {
        const textContent = reader.result as string;
        const newAtt: Attachment = {
          id: Date.now().toString() + Math.random(),
          name: file.name,
          type: 'file',
          mimeType: file.type || 'text/plain',
          size: file.size,
          text: textContent,
        };
        setAttachments((prev) => [...prev, newAtt]);
      };
      reader.readAsText(file);
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  // Send message to Gemini API via SSE Stream with Lag-Free Rendering
  const handleSendMessage = async (textToSend?: string) => {
    const prompt = (textToSend !== undefined ? textToSend : input).trim();
    if (!prompt && attachments.length === 0) return;
    if (isLoading) return;

    const userMessageId = Date.now().toString();
    const newUserMessage: ChatMessage = {
      id: userMessageId,
      role: 'user',
      content: prompt,
      timestamp: Date.now(),
      attachments: [...attachments],
      persona,
      tone,
    };

    const updatedMessages = [...messages, newUserMessage];
    setMessages(updatedMessages);
    setInput('');
    setAttachments([]);
    setIsLoading(true);

    const modelMessageId = (Date.now() + 1).toString();
    const placeholderModelMessage: ChatMessage = {
      id: modelMessageId,
      role: 'model',
      content: '',
      timestamp: Date.now(),
      persona,
      tone,
      isStreaming: true,
    };

    setMessages([...updatedMessages, placeholderModelMessage]);

    try {
      // Only send recent history and only send full attachments for the current/recent messages
      const payloadMessages = updatedMessages.slice(-14).map((m, idx, arr) => ({
        role: m.role,
        content: m.content,
        attachments: idx >= arr.length - 2 ? m.attachments : undefined,
      }));

      const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          persona,
          tone,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      if (!res.body) {
        throw new Error('No readable response body');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';

      let pendingFrame = false;
      const scheduleUpdate = () => {
        if (!pendingFrame) {
          pendingFrame = true;
          requestAnimationFrame(() => {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === modelMessageId
                  ? { ...msg, content: accumulatedText }
                  : msg
              )
            );
            pendingFrame = false;
          });
        }
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.text) {
                accumulatedText += data.text;
                scheduleUpdate();
              } else if (data.done) {
                // Done
              } else if (data.error) {
                accumulatedText += `\n\n*(Error: ${data.error})*`;
                scheduleUpdate();
              }
            } catch {}
          }
        }
      }

      // Ensure final state is flush
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === modelMessageId
            ? { ...msg, isStreaming: false, content: accumulatedText || 'Ji bhai, kuch aur puchna chahte ho?' }
            : msg
        )
      );

      if (autoSpeak && accumulatedText) {
        speakText(accumulatedText, modelMessageId);
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === modelMessageId
            ? {
                ...msg,
                isStreaming: false,
                content: `⚠️ **Maaf karna bhai, thodi dikkat aayi**: ${err.message || 'Network issue'}. Ek baar dobara try karein!`,
              }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    stopSpeaking();
    const fresh: ChatMessage[] = [
      {
        id: Date.now().toString(),
        role: 'model',
        content: 'Chat clear ho gayi hai bhai! Naya sawal pucho, photo bhejo ya voice trigger bolo (jaise "Hey Nova, read screen").',
        timestamp: Date.now(),
        persona,
      },
    ];
    setMessages(fresh);
    try {
      localStorage.removeItem('nova_chat_history');
    } catch {}
  };

  const exportChat = () => {
    const textContent = messages
      .map(
        (m) =>
          `[${new Date(m.timestamp).toLocaleString()}] ${m.role === 'user' ? 'YOU' : 'NOVA AI'}:\n${m.content}\n`
      )
      .join('\n----------------------------------------\n\n');

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Nova_AI_Chat_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className={`min-h-screen flex flex-col bg-slate-950 text-slate-100 ${
        highContrast ? 'text-lg font-medium selection:bg-yellow-400 selection:text-black' : 'text-sm'
      }`}
    >
      {/* Floating Toast Notification when a voice command is triggered */}
      {voiceToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-600 text-white shadow-2xl border border-white/20 flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="p-1.5 rounded-xl bg-white/20 text-yellow-300 animate-pulse">
            <Zap className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <div className="font-bold tracking-tight text-white flex items-center gap-1.5">
              Voice Command Executed!
            </div>
            <div className="text-cyan-100 font-mono text-[11px]">
              "{voiceToast.phrase}" &rarr;{' '}
              <span className="font-bold text-yellow-300">{voiceToast.actionName}</span>
            </div>
          </div>
          <button
            onClick={() => setVoiceToast(null)}
            className="ml-2 text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Hidden file inputs */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => {
          const files = e.target.files;
          if (files && files[0]) {
            processDocFile(files[0]);
          }
          e.target.value = '';
        }}
        accept=".txt,.pdf,.csv,.json,.py,.js,.html,.css,.md,.docx"
        className="hidden"
      />
      <input
        type="file"
        ref={imageInputRef}
        onChange={(e) => {
          const files = e.target.files;
          if (files && files[0]) {
            processImageFile(files[0]);
          }
          e.target.value = '';
        }}
        accept="image/*"
        className="hidden"
      />
      <input
        type="file"
        ref={cameraInputRef}
        onChange={(e) => {
          const files = e.target.files;
          if (files && files[0]) {
            processImageFile(files[0], 'Camera_Photo.jpg');
          }
          e.target.value = '';
        }}
        accept="image/*"
        capture="environment"
        className="hidden"
      />

      {/* Top Navbar: Clean & Sleek with Three-Line (☰) Drawer Trigger */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-slate-950/85 border-b border-slate-800/80 shadow-md">
        <div className="max-w-5xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2">
          
          {/* Left: Three Line (☰) Menu Button + New Chat Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsHamburgerOpen(true)}
              className="p-2 sm:px-2.5 sm:py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 transition cursor-pointer shadow-sm flex items-center gap-2 group hover:scale-[1.03] active:scale-95"
              title="Open Menu & Features (Three Line ☰)"
            >
              <Menu className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition" />
              <span className="hidden sm:inline text-xs font-bold text-slate-200">Menu</span>
            </button>

            <button
              onClick={handleNewChat}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 text-slate-200 text-xs font-semibold transition cursor-pointer hover:scale-[1.02] active:scale-95"
              title="Start a Fresh New Conversation"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
              <span className="hidden md:inline">New Chat</span>
            </button>
          </div>

          {/* Center: Sleek Nova Brand */}
          <div className="flex items-center gap-2">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 shadow-md shadow-cyan-500/20 text-white font-black text-sm">
              <Sparkles className="w-4 h-4 animate-pulse" />
              <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-emerald-500 rounded-full border border-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold tracking-tight text-sm sm:text-base bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
                  NOVA MAST AI
                </span>
                <span className="hidden xs:inline-flex text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                  3.8
                </span>
              </div>
            </div>
          </div>

          {/* Right: Ambient Voice Standby Mode ("Hey Nova") + User Login Profile Pill + Zero-Bloat Storage */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Ambient Voice Assistant Launcher */}
            <button
              onClick={() => setIsAmbientVoiceOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-violet-950/60 to-slate-900/90 border border-violet-500/40 hover:border-violet-400 text-violet-300 text-xs font-bold transition cursor-pointer shadow-sm hover:scale-[1.02] active:scale-95"
              title="Voice Assistant Standby: Screen stay-awake & 'Hey Nova, open YouTube' listener"
            >
              <Mic className="w-3.5 h-3.5 text-violet-400 animate-pulse" />
              <span className="hidden sm:inline">Voice Assistant</span>
            </button>

            {/* User Profile & Login Pill */}
            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="flex items-center gap-1.5 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-cyan-500/40 text-slate-200 text-xs font-semibold transition cursor-pointer hover:scale-[1.02] active:scale-95"
              title="User Account & Login Settings"
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center text-xs">
                {userProfile.avatar || '👤'}
              </div>
              <span className="hidden md:inline font-medium text-xs truncate max-w-[85px]">
                {userProfile.name}
              </span>
            </button>

            {/* Zero-Bloat Storage Chip */}
            <button
              onClick={() => setIsStorageModalOpen(true)}
              className="hidden lg:flex items-center gap-1 px-2 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/30 text-[10px] text-emerald-300 font-mono hover:scale-105 transition"
              title="Zero-Bloat Storage: Click to inspect storage metrics"
            >
              <HardDrive className="w-3 h-3 text-emerald-400" />
              <span>{storageStats.formattedUsed}</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-3 sm:p-5 flex flex-col justify-between">
        {/* Messages List */}
        <div className="space-y-4 pb-6">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isSpeaking = speakingMessageId === msg.id;
            const isHighlighted = highlightedMessageId === msg.id;

            return (
              <div
                key={msg.id}
                id={`msg-${msg.id}`}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group transition-all duration-300 animate-message-entrance gpu-accelerated ${
                  isHighlighted ? 'scale-[1.01]' : ''
                }`}
              >
                {/* Persona Header for Model */}
                {!isUser && (
                  <div className="flex items-center gap-2 mb-1 px-1 text-xs text-slate-400">
                    <span className="flex items-center gap-1 font-semibold text-cyan-400">
                      <Sparkles className="w-3.5 h-3.5" /> NOVA AI
                    </span>
                    {msg.persona && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800/80 text-slate-400 border border-slate-700/40">
                        {PERSONAS.find((p) => p.id === msg.persona)?.emoji}{' '}
                        {PERSONAS.find((p) => p.id === msg.persona)?.label}
                      </span>
                    )}
                    <span className="text-[10px] text-slate-500">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {isHighlighted && (
                      <span className="text-[10px] text-cyan-300 font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/40 animate-pulse">
                        📍 Found in Search
                      </span>
                    )}
                  </div>
                )}

                {/* User Message Header if highlighted */}
                {isUser && isHighlighted && (
                  <div className="flex items-center gap-2 mb-1 px-1 text-xs">
                    <span className="text-[10px] text-cyan-300 font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/40 animate-pulse">
                      📍 Found in Search
                    </span>
                  </div>
                )}

                {/* Message Bubble */}
                <div
                  className={`relative max-w-[95%] sm:max-w-[85%] rounded-2xl px-4 py-3 shadow-lg transition-all duration-300 ${
                    isHighlighted
                      ? 'ring-4 ring-cyan-400 ring-offset-2 ring-offset-slate-950 shadow-2xl shadow-cyan-500/50'
                      : ''
                  } ${
                    isUser
                      ? 'bg-gradient-to-br from-cyan-600 via-blue-600 to-violet-700 text-white rounded-tr-xs border border-cyan-400/20'
                      : 'bg-slate-900/90 text-slate-100 rounded-tl-xs border border-slate-800 shadow-slate-950/60 backdrop-blur-md'
                  }`}
                >
                  {/* Attachments inside user message */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="mb-3 space-y-2">
                      <div className="flex flex-wrap gap-2">
                        {msg.attachments.map((att) => {
                          if (att.previewUrl || att.base64) {
                            return (
                              <div
                                key={att.id}
                                className="relative rounded-xl overflow-hidden border border-white/20 max-w-[240px] max-h-[160px] bg-black/40 group/att"
                              >
                                <img
                                  src={att.previewUrl || att.base64}
                                  alt={att.name}
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-1.5 text-[10px] text-white truncate font-medium">
                                  {att.type === 'screen' ? '🖥️ Screen Capture' : att.name}
                                </div>
                              </div>
                            );
                          }
                          return (
                            <div
                              key={att.id}
                              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/30 border border-white/20 text-xs text-white"
                            >
                              <FileText className="w-4 h-4 text-cyan-300" />
                              <span className="font-medium truncate max-w-[140px]">{att.name}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Message Content */}
                  {isUser ? (
                    <p className="whitespace-pre-wrap leading-relaxed text-sm sm:text-base break-words font-sans">
                      {msg.content}
                    </p>
                  ) : (
                    <div>
                      <MarkdownRenderer content={msg.content} />
                      {msg.isStreaming && (
                        <div className="inline-flex items-center gap-1.5 mt-2 text-cyan-400 text-xs font-medium">
                          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                          <span>Generating reply...</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Toolbar for AI response */}
                {!isUser && !msg.isStreaming && (
                  <div className="flex items-center gap-1.5 mt-1.5 px-1 text-slate-400">
                    {/* Speak / Listen */}
                    <button
                      onClick={() => speakText(msg.content, msg.id)}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-xs transition cursor-pointer ${
                        isSpeaking
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse font-semibold'
                          : 'hover:bg-slate-800 hover:text-slate-200'
                      }`}
                      title={isSpeaking ? 'Stop Audio' : 'Listen via Voice (TTS)'}
                    >
                      {isSpeaking ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Stop</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Bolkar sunao</span>
                        </>
                      )}
                    </button>

                    {/* Copy */}
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(msg.content);
                        alert('Message copied to clipboard!');
                      }}
                      className="p-1 rounded hover:bg-slate-800 hover:text-slate-200 transition cursor-pointer"
                      title="Copy text"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>

                    {/* Ask for more detail */}
                    <button
                      onClick={() =>
                        handleSendMessage('Isme aur deeply details do aur simple example ke saath explain karo!')
                      }
                      className="px-2 py-0.5 rounded-md text-[11px] text-slate-500 hover:text-cyan-300 hover:bg-slate-800 transition cursor-pointer"
                    >
                      + Aur detail
                    </button>
                  </div>
                )}
              </div>
            );
          })}
          <div ref={chatBottomRef} />
        </div>

        {/* Middle of chat area stays clean & spacious */}

        {/* Input Card Container */}
        <div className="sticky bottom-2 z-30 pt-2">
          {/* Active Attachments Drawer */}
          {attachments.length > 0 && (
            <div className="mb-2 p-2.5 rounded-xl bg-slate-900 border border-slate-700/80 shadow-xl flex flex-wrap gap-2 items-center animate-in fade-in slide-in-from-bottom-2">
              <span className="text-[11px] font-semibold text-slate-400 mr-1">Attached ({attachments.length}):</span>
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className="relative group flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                >
                  {att.previewUrl || att.base64 ? (
                    <img
                      src={att.previewUrl || att.base64}
                      alt={att.name}
                      className="w-7 h-7 rounded object-cover border border-slate-600"
                    />
                  ) : (
                    <FileText className="w-4 h-4 text-cyan-400" />
                  )}
                  <span className="truncate max-w-[120px] font-medium">{att.name}</span>
                  <button
                    onClick={() => removeAttachment(att.id)}
                    className="p-0.5 rounded-full hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Listening Indicator with active Trigger hint */}
          {isListening && (
            <div className="mb-2 px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-500/50 flex items-center justify-between text-xs text-rose-300 animate-pulse shadow-lg backdrop-blur-md">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-0.5 h-3">
                  <span className="w-1 bg-rose-400 rounded-full animate-audio-wave-1" />
                  <span className="w-1 bg-rose-400 rounded-full animate-audio-wave-2" />
                  <span className="w-1 bg-rose-400 rounded-full animate-audio-wave-3" />
                  <span className="w-1 bg-rose-400 rounded-full animate-audio-wave-4" />
                </div>
                <span>
                  Voice Assistant listening! Try: <strong className="underline text-white font-mono">"Hey Nova, clear my tasks"</strong> ya <strong className="underline text-white font-mono">"Hey Nova, read screen"</strong>
                </span>
              </div>
              <button
                onClick={toggleListening}
                className="text-[11px] font-semibold text-rose-200 hover:text-white underline cursor-pointer"
              >
                Stop
              </button>
            </div>
          )}

          {/* Clean Floating Glassy Input Bar */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-700/80 p-2 sm:p-2.5 shadow-2xl backdrop-blur-xl transition-all focus-within:border-cyan-500/70 focus-within:ring-2 focus-within:ring-cyan-500/20">
            <div className="flex items-end gap-1.5 sm:gap-2">
              
              {/* Attachment Actions (Pic, File, Camera, Read Screen) */}
              <div className="flex items-center gap-0.5 sm:gap-1 shrink-0 pb-1">
                {/* 1. Pic */}
                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition cursor-pointer"
                  title="Upload Image / Screenshot (Auto compressed)"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>

                {/* 2. File / Doc */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 rounded-xl text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition cursor-pointer"
                  title="Upload Document / PDF / Code"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                {/* 3. Camera */}
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  className="p-2 rounded-xl text-slate-400 hover:text-violet-400 hover:bg-slate-800 transition cursor-pointer hidden sm:flex"
                  title="Take Photo with Camera"
                >
                  <Camera className="w-4 h-4" />
                </button>

                {/* 4. Read Screen */}
                <button
                  type="button"
                  onClick={triggerScreenCapture}
                  className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition cursor-pointer hidden md:flex"
                  title="Capture & Read Screen (Accessibility OCR)"
                >
                  <Monitor className="w-4 h-4" />
                </button>
              </div>

              {/* Smart Textarea */}
              <div className="flex-1 relative">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder="Pucho kuch bhi ya bolo 'Hey Nova, open YouTube'..."
                  rows={1}
                  className="w-full bg-transparent border-0 px-2 sm:px-3 py-1.5 text-sm sm:text-base text-slate-100 placeholder-slate-500 focus:outline-none resize-none font-sans max-h-32"
                />
              </div>

              {/* Right: High-Animation Voice Mic & Send Button */}
              <div className="flex items-center gap-1.5 shrink-0 pb-1">
                {/* Voice Mic Button */}
                <button
                  type="button"
                  onClick={toggleListening}
                  className={`relative p-2.5 rounded-xl transition-all duration-200 cursor-pointer flex items-center justify-center ${
                    isListening
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-500/50 scale-105 animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white hover:scale-105 active:scale-95'
                  }`}
                  title={isListening ? 'Listening... click to stop' : 'Start Voice Assistant & Voice Input'}
                >
                  {isListening ? (
                    <div className="flex items-center gap-0.5 h-4 px-0.5">
                      <span className="w-1 bg-white rounded-full animate-audio-wave-1" />
                      <span className="w-1 bg-white rounded-full animate-audio-wave-2" />
                      <span className="w-1 bg-white rounded-full animate-audio-wave-3" />
                      <span className="w-1 bg-white rounded-full animate-audio-wave-4" />
                    </div>
                  ) : (
                    <Mic className="w-4 h-4 text-cyan-300" />
                  )}
                </button>

                {/* High-Energy Send Button */}
                <button
                  type="button"
                  onClick={() => handleSendMessage()}
                  disabled={isLoading || (!input.trim() && attachments.length === 0)}
                  className={`flex items-center justify-center p-2.5 sm:px-4 rounded-xl font-bold text-sm transition-all duration-200 cursor-pointer shadow-lg ${
                    isLoading || (!input.trim() && attachments.length === 0)
                      ? 'bg-slate-800/60 text-slate-600 cursor-not-allowed'
                      : 'bg-gradient-to-r from-cyan-500 via-blue-600 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white shadow-cyan-500/30 hover:scale-[1.03] active:scale-95'
                  }`}
                  title="Send message (Enter)"
                >
                  <Send className="w-4 h-4 sm:mr-1.5" />
                  <span className="hidden sm:inline">Send</span>
                </button>
              </div>

            </div>
          </div>
        </div>
      </main>

      {/* Voice Commands Manager Modal */}
      <VoiceCommandsModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        triggers={voiceTriggers}
        onAddTrigger={handleAddTrigger}
        onToggleTrigger={handleToggleTrigger}
        onDeleteTrigger={handleDeleteTrigger}
        onTestTrigger={(trig) => executeVoiceAction(trig)}
        continuousListening={continuousListening}
        onToggleContinuousListening={setContinuousListening}
        lastExecutedCommand={lastExecutedCommand}
      />

      {/* Phone Assistant Modal */}
      <PhoneAssistantModal
        isOpen={isPhoneModalOpen}
        onClose={() => setIsPhoneModalOpen(false)}
        onSendPrompt={(p) => handleSendMessage(p)}
      />

      {/* Screen Reader & Accessibility Modal */}
      <ScreenReaderModal
        isOpen={isScreenModalOpen}
        onClose={() => setIsScreenModalOpen(false)}
        onTriggerScreenCapture={triggerScreenCapture}
        onTriggerFileUpload={() => imageInputRef.current?.click()}
        autoSpeak={autoSpeak}
        onToggleAutoSpeak={setAutoSpeak}
        highContrast={highContrast}
        onToggleHighContrast={setHighContrast}
        speechRate={speechRate}
        onChangeSpeechRate={setSpeechRate}
      />

      {/* Chat & Files History Search Modal */}
      <ChatSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        messages={messages}
        onJumpToMessage={handleJumpToMessage}
      />

      {/* Zero-Bloat Storage & Memory Saver Guarantee Modal */}
      {isStorageModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-emerald-500/40 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight">Zero-Bloat Storage</h3>
                  <p className="text-xs text-slate-400">Ultra-lightweight device memory protection</p>
                </div>
              </div>
              <button
                onClick={() => setIsStorageModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Storage Usage Metric Card */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400">Total Chat Storage Used</span>
                <div className="text-2xl font-black text-emerald-400 font-mono tracking-tight">
                  {storageStats.formattedUsed}
                </div>
                <span className="text-[11px] text-slate-500">
                  {storageStats.messageCount} messages stored ({storageStats.percentageOfQuota.toFixed(2)}% of 5 MB)
                </span>
              </div>
              <div className="px-3 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold font-mono">
                99.9% FREE
              </div>
            </div>

            {/* Storage Guarantees */}
            <div className="space-y-2.5 text-xs text-slate-300 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
              <div className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span><strong>Aapka Phone Hamesha Khali Rahega</strong>: Chat history sirf text ke roop me compressed store hoti hai, jisse 1,000 messages bhi sirf 50-80 KB jagah lete hain!</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span><strong>Auto Media Scaling</strong>: Aap chahe 10 MB ki photo bhejo ya screen capture, Nova usko instantly lean compress kar deta hai taaki phone kabhi hang na ho.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span><strong>No App Install / APK Spam</strong>: App directly browser me lightning-fast bina kisi storage clutter ke chalti hai.</span>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={() => {
                  try {
                    localStorage.removeItem('nova_chat_history');
                    setMessages([
                      {
                        id: Date.now().toString(),
                        role: 'model',
                        content: 'Media cache aur local chat clean ho gayi hai bhai! Storage ekdum 0 KB fresh hai. Boliye, aaj kya sawal hai?',
                        timestamp: Date.now(),
                        persona,
                      },
                    ]);
                    setStorageStats(getStorageUsage());
                    setIsStorageModalOpen(false);
                  } catch {}
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-red-950/40 text-slate-300 hover:text-red-400 border border-slate-700 hover:border-red-500/30 text-xs font-semibold transition cursor-pointer"
              >
                Clear Cache
              </button>
              <button
                onClick={() => {
                  exportChat();
                  setIsStorageModalOpen(false);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition cursor-pointer shadow-lg shadow-cyan-600/30"
              >
                Download Backup (.txt)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Three-Line (☰) Hamburger Features & Chat History Drawer */}
      <HamburgerMenu
        isOpen={isHamburgerOpen}
        onClose={() => setIsHamburgerOpen(false)}
        userProfile={userProfile}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onOpenSearchModal={() => setIsSearchModalOpen(true)}
        onOpenAmbientVoiceModal={() => setIsAmbientVoiceOpen(true)}
        onOpenVoiceTriggersModal={() => setIsVoiceModalOpen(true)}
        onOpenPhoneToolsModal={() => setIsPhoneModalOpen(true)}
        onOpenScreenReaderModal={() => setIsScreenModalOpen(true)}
        onOpenStorageModal={() => setIsStorageModalOpen(true)}
        autoSpeak={autoSpeak}
        onToggleAutoSpeak={() => {
          const next = !autoSpeak;
          setAutoSpeak(next);
          if (!next) stopSpeaking();
        }}
        continuousListening={continuousListening}
        onToggleContinuousListening={() => setContinuousListening(!continuousListening)}
        currentPersona={persona}
        onChangePersona={setPersona}
        currentTone={tone}
        onChangeTone={setTone}
        onClearCurrentChat={clearChat}
        onExportChat={exportChat}
        storageUsed={storageStats.formattedUsed}
      />

      {/* Ambient Voice Assistant Standby Modal ("Hey Nova, open YouTube") */}
      <AmbientVoiceModal
        isOpen={isAmbientVoiceOpen}
        onClose={() => setIsAmbientVoiceOpen(false)}
        onExecuteCommand={(action, payload) => {
          const trig: VoiceCommandTrigger = {
            id: 'ambient-cmd',
            phrase: payload || action,
            action: action as VoiceActionType,
            actionPayload: payload,
            enabled: true,
            description: action === 'open_youtube' ? 'Opening YouTube' : action,
          };
          executeVoiceAction(trig, payload);
        }}
        autoSpeak={autoSpeak}
        onToggleAutoSpeak={() => {
          const next = !autoSpeak;
          setAutoSpeak(next);
          if (!next) stopSpeaking();
        }}
      />

      {/* User Profile & Account Login Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        userProfile={userProfile}
        onSaveProfile={handleSaveProfile}
      />
    </div>
  );
}

export default App;
