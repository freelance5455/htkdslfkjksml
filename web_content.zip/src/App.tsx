import React, { useEffect } from 'react';
import { DesktopProvider, useDesktop } from './context/DesktopContext';
import { Taskbar } from './components/desktop/Taskbar';
import { StartMenu } from './components/desktop/StartMenu';
import { ActionCenter } from './components/desktop/ActionCenter';
import { WindowFrame } from './components/desktop/WindowFrame';
import { DesktopIconGrid } from './components/desktop/DesktopIconGrid';
import { LockScreen } from './components/desktop/LockScreen';

const DesktopView: React.FC = () => {
  const {
    openWindows,
    wallpaper,
    brightness,
    toggleStartMenu,
    closeStartMenu,
    closeActionCenter,
    openApp
  } = useDesktop();

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Escape key closes menus
      if (e.key === 'Escape') {
        closeStartMenu();
        closeActionCenter();
      }

      // Ctrl + E opens File Explorer
      if (e.ctrlKey && e.key.toLowerCase() === 'e') {
        e.preventDefault();
        openApp('file-explorer');
      }

      // Windows / Meta key toggles Start Menu
      if (e.key === 'Meta') {
        e.preventDefault();
        toggleStartMenu();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [closeStartMenu, closeActionCenter, openApp, toggleStartMenu]);

  return (
    <div
      className="relative w-screen h-screen overflow-hidden select-none bg-slate-950 font-sans"
      style={{
        filter: `brightness(${brightness}%)`
      }}
    >
      {/* Desktop Background Wallpaper */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-500 scale-100"
        style={{
          backgroundImage: `url(${wallpaper})`
        }}
      >
        {/* Soft bloom overlay for Windows 11 acrylic vibe */}
        <div className="absolute inset-0 bg-slate-950/20 backdrop-blur-[0.5px]" />
      </div>

      {/* Desktop Icons Grid */}
      <DesktopIconGrid />

      {/* Window Frames Stack */}
      <div className="absolute inset-0 pointer-events-none z-10">
        {openWindows.map(win => (
          <div key={win.id} className="pointer-events-auto">
            <WindowFrame window={win} />
          </div>
        ))}
      </div>

      {/* Windows 11 Start Menu Modal */}
      <StartMenu />

      {/* Windows 11 Action Center & Quick Settings */}
      <ActionCenter />

      {/* Centered Taskbar */}
      <Taskbar />

      {/* Virtual Lock Screen */}
      <LockScreen />
    </div>
  );
};

export default function App() {
  return (
    <DesktopProvider>
      <DesktopView />
    </DesktopProvider>
  );
}
