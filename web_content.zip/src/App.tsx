import React, { useState, useEffect, useRef } from 'react';
import { Alarm, AppSettings } from './types/alarm';
import { loadStoredAlarms, saveStoredAlarms, loadStoredSettings, saveStoredSettings } from './utils/storage';
import { getNextAlarmDate, requestNotificationPermission } from './utils/alarmEngine';
import { Header } from './components/Header';
import { AlarmCard } from './components/AlarmCard';
import { CreateAlarmModal } from './components/CreateAlarmModal';
import { RingingModal } from './components/RingingModal';
import { MediaLibraryTab } from './components/MediaLibraryTab';
import { SettingsTab } from './components/SettingsTab';
import { AndroidCodeExporter } from './components/AndroidCodeExporter';
import { BottomNav } from './components/BottomNav';
import { Plus, Search, Bell, Sparkles, Filter } from 'lucide-react';

export default function App() {
  const [alarms, setAlarms] = useState<Alarm[]>(loadStoredAlarms);
  const [settings, setSettings] = useState<AppSettings>(loadStoredSettings);
  const [activeTab, setActiveTab] = useState<'alarms' | 'media' | 'settings' | 'code'>('alarms');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'video' | 'audio' | 'enabled'>('all');

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingAlarm, setEditingAlarm] = useState<Alarm | null>(null);
  const [ringingAlarm, setRingingAlarm] = useState<Alarm | null>(null);

  // Permission Granted State
  const [permissionGranted, setPermissionGranted] = useState(
    'Notification' in window && Notification.permission === 'granted'
  );

  // Save changes to local storage whenever alarms or settings update
  useEffect(() => {
    saveStoredAlarms(alarms);
  }, [alarms]);

  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  // Request permissions on startup if possible
  const handleRequestPermissions = async () => {
    const res = await requestNotificationPermission();
    setPermissionGranted(res === 'granted');
  };

  // Real-time Alarm Check Engine (runs every second)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();
      const currentSecond = now.getSeconds();

      // Trigger exact matching alarms when second === 0
      if (currentSecond === 0 && !ringingAlarm) {
        const matchingAlarm = alarms.find((a) => {
          if (!a.isEnabled) return false;
          if (a.hour !== currentHour || a.minute !== currentMinute) return false;

          // Check repeat days
          if (!a.repeatDays || a.repeatDays.length === 0) {
            // One-time alarm
            return true;
          }
          const today = now.getDay();
          return a.repeatDays.includes(today);
        });

        if (matchingAlarm) {
          setRingingAlarm(matchingAlarm);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [alarms, ringingAlarm]);

  // Alarm Management Handlers
  const handleToggleAlarm = (id: string, isEnabled: boolean) => {
    setAlarms((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isEnabled } : a))
    );
  };

  const handleDeleteAlarm = (id: string) => {
    setAlarms((prev) => prev.filter((a) => a.id !== id));
  };

  const handleOpenCreateModal = () => {
    setEditingAlarm(null);
    setIsCreateModalOpen(true);
  };

  const handleOpenEditModal = (alarm: Alarm) => {
    setEditingAlarm(alarm);
    setIsCreateModalOpen(true);
  };

  const handleSaveAlarm = (alarmData: Partial<Alarm>) => {
    if (editingAlarm) {
      // Edit existing alarm
      setAlarms((prev) =>
        prev.map((a) => (a.id === editingAlarm.id ? ({ ...a, ...alarmData } as Alarm) : a))
      );
    } else {
      // Create new alarm
      const newAlarm: Alarm = {
        id: `alarm-${Date.now()}`,
        hour: alarmData.hour ?? 7,
        minute: alarmData.minute ?? 30,
        alarmLabel: alarmData.alarmLabel || 'WakeUp Alarm',
        mediaUri: alarmData.mediaUri || '',
        mediaName: alarmData.mediaName || 'Sunrise Video',
        mediaType: alarmData.mediaType || 'video',
        mediaThumbnail: alarmData.mediaThumbnail,
        repeatDays: alarmData.repeatDays || [1, 2, 3, 4, 5],
        isEnabled: true,
        volume: alarmData.volume ?? settings.defaultVolume,
        gradualVolumeEnabled: alarmData.gradualVolumeEnabled ?? settings.gradualVolume,
        vibrationEnabled: alarmData.vibrationEnabled ?? settings.vibration,
        snoozeDuration: alarmData.snoozeDuration ?? settings.defaultSnoozeDuration,
        createdAt: Date.now(),
      };
      setAlarms((prev) => [newAlarm, ...prev]);
    }
  };

  // Quick Test Trigger Alarm
  const handleTestTrigger = (alarm: Alarm) => {
    setRingingAlarm(alarm);
  };

  // Ringing Modal Handlers
  const handleStopRinging = () => {
    if (ringingAlarm) {
      // If one-time alarm, disable it after stop
      if (!ringingAlarm.repeatDays || ringingAlarm.repeatDays.length === 0) {
        setAlarms((prev) =>
          prev.map((a) => (a.id === ringingAlarm.id ? { ...a, isEnabled: false } : a))
        );
      }
    }
    setRingingAlarm(null);
  };

  const handleSnoozeRinging = (snoozeMinutes: number) => {
    if (!ringingAlarm) return;

    // Calculate snoozed time
    const now = new Date();
    const snoozedTime = new Date(now.getTime() + snoozeMinutes * 60 * 1000);

    const snoozedAlarm: Alarm = {
      ...ringingAlarm,
      id: `snoozed-${Date.now()}`,
      hour: snoozedTime.getHours(),
      minute: snoozedTime.getMinutes(),
      alarmLabel: `[Snoozed] ${ringingAlarm.alarmLabel}`,
      repeatDays: [], // One-time snooze trigger
      isEnabled: true,
    };

    setAlarms((prev) => [snoozedAlarm, ...prev]);
    setRingingAlarm(null);
  };

  // Filtered Alarms
  const filteredAlarms = alarms.filter((a) => {
    const matchesSearch =
      a.alarmLabel.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.mediaName.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterMode === 'video') return a.mediaType === 'video';
    if (filterMode === 'audio') return a.mediaType === 'audio';
    if (filterMode === 'enabled') return a.isEnabled;

    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col pb-24 transition-colors duration-200">
      {/* Top Header Bar */}
      <Header
        alarms={alarms}
        settings={settings}
        onUpdateSettings={setSettings}
        onRequestPermissions={handleRequestPermissions}
        permissionGranted={permissionGranted}
      />

      {/* Main Content Body Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-6 sm:px-6">
        {activeTab === 'alarms' && (
          <div className="space-y-6">
            {/* Action Bar: Search & Filter Controls */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* Search Bar Input */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search alarms or media tracks..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-white transition-all shadow-xs"
                />
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 p-1 bg-slate-200/80 dark:bg-slate-800 rounded-2xl shrink-0 overflow-x-auto">
                <button
                  onClick={() => setFilterMode('all')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                    filterMode === 'all'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  All ({alarms.length})
                </button>
                <button
                  onClick={() => setFilterMode('video')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                    filterMode === 'video'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Videos
                </button>
                <button
                  onClick={() => setFilterMode('audio')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                    filterMode === 'audio'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Music
                </button>
                <button
                  onClick={() => setFilterMode('enabled')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                    filterMode === 'enabled'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Active
                </button>
              </div>
            </div>

            {/* Saved Alarms List */}
            {filteredAlarms.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {filteredAlarms.map((alarm) => (
                  <AlarmCard
                    key={alarm.id}
                    alarm={alarm}
                    is24h={settings.timeFormat === '24h'}
                    onToggle={handleToggleAlarm}
                    onEdit={handleOpenEditModal}
                    onDelete={handleDeleteAlarm}
                    onTestTrigger={handleTestTrigger}
                  />
                ))}
              </div>
            ) : (
              <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                  <Bell className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  No Alarms Found
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {searchQuery
                    ? `No alarms matched "${searchQuery}".`
                    : 'Get started by tapping the floating + button to schedule your video or music alarm!'}
                </p>
                <button
                  onClick={handleOpenCreateModal}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs shadow-md hover:bg-slate-800 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Alarm</span>
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'media' && <MediaLibraryTab />}

        {activeTab === 'settings' && (
          <SettingsTab
            settings={settings}
            onUpdateSettings={setSettings}
            onTriggerTestAlarm={() => {
              if (alarms.length > 0) {
                handleTestTrigger(alarms[0]);
              }
            }}
            alarms={alarms}
            onImportAlarms={setAlarms}
          />
        )}

        {activeTab === 'code' && <AndroidCodeExporter />}
      </main>

      {/* Create / Edit Alarm Drawer Modal */}
      <CreateAlarmModal
        isOpen={isCreateModalOpen}
        editingAlarm={editingAlarm}
        onClose={() => setIsCreateModalOpen(false)}
        onSave={handleSaveAlarm}
        is24h={settings.timeFormat === '24h'}
      />

      {/* Full-Screen Ringing Screen Overlay Modal */}
      <RingingModal
        alarm={ringingAlarm}
        onStop={handleStopRinging}
        onSnooze={handleSnoozeRinging}
      />

      {/* Floating Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        onOpenCreateModal={handleOpenCreateModal}
        alarmCount={alarms.filter((a) => a.isEnabled).length}
      />
    </div>
  );
}
