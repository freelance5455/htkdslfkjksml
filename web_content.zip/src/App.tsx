import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  Sparkles,
  AlertCircle,
  Play,
  RotateCcw,
  CheckCircle2,
  Sliders,
  BookOpen,
  History,
  Info,
  Volume2,
  Layers,
  ArrowRight,
  Smartphone,
  Download,
} from 'lucide-react';

import {
  AudioSettings,
  HistoryItem,
  NarrationStyleId,
  PronunciationRule,
  SentenceItem,
  TextProcessingSettings,
  TTSEngineType,
  TTSGenerateResult,
  TTSVoice,
  UserPreset,
  VoiceSettings,
} from './types/tts';
import { TELUGU_VOICES, NARRATION_STYLES, VOICE_PRESETS, VoicePreset } from './data/voicesAndStyles';
import { DEFAULT_PRONUNCIATION_RULES } from './utils/pronunciation';
import { splitIntoTeluguSentences } from './utils/textProcessor';
import { SampleTeluguText } from './utils/sampleTexts';
import { TTSProviderRegistry } from './tts/ttsProvider';
import {
  saveAudioToDB,
  getAudioFromDB,
  deleteAudioFromDB,
  clearAudioDB,
} from './utils/audioStorage';

import { Header } from './components/Header';
import { TextEditor } from './components/TextEditor';
import { VoiceSelector } from './components/VoiceSelector';
import { VoiceControls } from './components/VoiceControls';
import { NarrationStyleSelector } from './components/NarrationStyleSelector';
import { SentenceEditor } from './components/SentenceEditor';
import { AudioPlayer } from './components/AudioPlayer';
import { AdvancedSettingsModal } from './components/AdvancedSettingsModal';
import { PronunciationModal } from './components/PronunciationModal';
import { SampleTextModal } from './components/SampleTextModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { AboutModal } from './components/AboutModal';
import { SavePresetModal } from './components/SavePresetModal';
import { DownloadApkModal } from './components/DownloadApkModal';

const DEFAULT_SAMPLE_TEXT =
  'నమస్కారం! YiuVoice తెలుగు వాయిస్ స్టూడియోకి స్వాగతం. మీ కథలు, వీడియోలు మరియు పాడ్‌కాస్ట్‌ల కొరకు సహజసిద్ధమైన తెలుగు ఏఐ గళాలను సులభంగా రూపొందించుకోండి.';

export default function App() {
  // Navigation & Modals
  const [currentTab, setCurrentTab] = useState<'studio' | 'sentences' | 'history' | 'about'>('studio');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPronunciationOpen, setIsPronunciationOpen] = useState(false);
  const [isSampleModalOpen, setIsSampleModalOpen] = useState(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [isSavePresetModalOpen, setIsSavePresetModalOpen] = useState(false);
  const [isDownloadApkOpen, setIsDownloadApkOpen] = useState(false);

  // Core TTS State
  const [text, setText] = useState<string>(DEFAULT_SAMPLE_TEXT);
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>('te-male-mohan');
  const [narrationStyle, setNarrationStyle] = useState<NarrationStyleId>('normal');
  const [activeEngine, setActiveEngine] = useState<TTSEngineType>('edge-neural');
  const [activePresetId, setActivePresetId] = useState<string | null>(null);

  // User Custom Presets saved in LocalStorage
  const [userPresets, setUserPresets] = useState<UserPreset[]>(() => {
    try {
      const saved = localStorage.getItem('yiuvoice_user_presets');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Voice, Audio & Text Settings
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    speed: 1.0,
    pitch: 0,
    volume: 100,
    sentencePause: 0.4,
    paragraphPause: 0.8,
    emphasis: 'moderate',
  });

  const [audioSettings, setAudioSettings] = useState<AudioSettings>({
    format: 'mp3',
    bitrate: 192,
    sampleRate: 24000,
    normalizeVolume: true,
  });

  const [textSettings, setTextSettings] = useState<TextProcessingSettings>({
    autoPunctuation: true,
    numberPronunciation: true,
    englishLoanwordTransliteration: true,
    abbreviationHandling: true,
    currencyPronunciation: true,
  });

  // Pronunciation & Sentences
  const [pronunciationRules, setPronunciationRules] = useState<PronunciationRule[]>(() => {
    try {
      const saved = localStorage.getItem('yiuvoice_rules');
      return saved ? JSON.parse(saved) : DEFAULT_PRONUNCIATION_RULES;
    } catch {
      return DEFAULT_PRONUNCIATION_RULES;
    }
  });

  const [sentences, setSentences] = useState<SentenceItem[]>(() =>
    splitIntoTeluguSentences(DEFAULT_SAMPLE_TEXT)
  );

  // History State with safe quota protection
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('yiuvoice_history');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed)) return [];

      let hadBloat = false;
      const cleaned = parsed.map((item) => {
        if (item.audioBase64) {
          hadBloat = true;
          // Move audio data to IndexedDB
          saveAudioToDB(item.id, item.audioBase64);
          const { audioBase64, audioUrl, ...rest } = item;
          return rest;
        }
        return item;
      });

      if (hadBloat) {
        try {
          localStorage.setItem('yiuvoice_history', JSON.stringify(cleaned));
        } catch {
          localStorage.removeItem('yiuvoice_history');
        }
      }
      return cleaned;
    } catch {
      try {
        localStorage.removeItem('yiuvoice_history');
      } catch {}
      return [];
    }
  });

  // Generation & Player State
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<TTSGenerateResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Sample playback states
  const [isPlayingVoiceSample, setIsPlayingVoiceSample] = useState<string | null>(null);
  const [previewingSentenceId, setPreviewingSentenceId] = useState<string | null>(null);
  const sampleAudioRef = useRef<HTMLAudioElement | null>(null);

  // Sync pronunciation rules to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('yiuvoice_rules', JSON.stringify(pronunciationRules));
    } catch (e) {
      console.warn('Could not save pronunciation rules:', e);
    }
  }, [pronunciationRules]);

  // Sync lightweight history metadata to localStorage (audio binary is saved in IndexedDB)
  useEffect(() => {
    try {
      // Strip audioBase64 and audioUrl to guarantee total size is tiny (< 25KB)
      const lightweightItems = history.slice(0, 30).map((item) => ({
        id: item.id,
        textSnippet: item.textSnippet,
        fullText: item.fullText,
        voiceId: item.voiceId,
        voiceName: item.voiceName,
        narrationStyle: item.narrationStyle,
        durationSec: item.durationSec,
        format: item.format,
        filename: item.filename,
        createdAt: item.createdAt,
      }));
      localStorage.setItem('yiuvoice_history', JSON.stringify(lightweightItems));
    } catch (e) {
      // In case quota was already full from old data, clear and save trimmed version
      try {
        localStorage.removeItem('yiuvoice_history');
        const trimmed = history.slice(0, 10).map((item) => ({
          id: item.id,
          textSnippet: item.textSnippet,
          fullText: item.fullText,
          voiceId: item.voiceId,
          voiceName: item.voiceName,
          narrationStyle: item.narrationStyle,
          durationSec: item.durationSec,
          format: item.format,
          filename: item.filename,
          createdAt: item.createdAt,
        }));
        localStorage.setItem('yiuvoice_history', JSON.stringify(trimmed));
      } catch {}
    }
  }, [history]);

  // Sync user presets to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('yiuvoice_user_presets', JSON.stringify(userPresets));
    } catch (e) {
      console.error(e);
    }
  }, [userPresets]);

  // Check initial engine status (quota / availability)
  useEffect(() => {
    fetch('/api/tts/status')
      .then((res) => res.json())
      .then((data) => {
        if (data.recommendedEngine) {
          setActiveEngine(data.recommendedEngine);
        }
      })
      .catch(() => {});
  }, []);

  // When voice changes, update engine if it's a realistic voice
  const handleSelectVoice = (voiceId: string) => {
    setSelectedVoiceId(voiceId);
    const voiceObj = TELUGU_VOICES.find((v) => v.id === voiceId);
    if (voiceObj?.isRealistic || voiceObj?.engine === 'edge-neural') {
      setActiveEngine('edge-neural');
    }
  };

  // When text changes, update sentences if user hasn't heavily customized them
  const handleTextChange = (newText: string) => {
    setText(newText);
    setError(null);
  };

  // Built-in System Preset Selection (Section 13)
  const handleApplyPreset = (preset: VoicePreset) => {
    setActivePresetId(preset.id);
    if (preset.recommendedVoiceId) {
      setSelectedVoiceId(preset.recommendedVoiceId);
      const voiceObj = TELUGU_VOICES.find((v) => v.id === preset.recommendedVoiceId);
      if (voiceObj?.isRealistic || voiceObj?.engine === 'edge-neural') {
        setActiveEngine('edge-neural');
      }
    }
    const style = preset.narrationStyle || preset.style;
    if (style) {
      setNarrationStyle(style);
    }
    setVoiceSettings((prev) => ({
      ...prev,
      ...preset.settings,
    }));
  };

  // Custom User Preset Selection
  const handleApplyUserPreset = (preset: UserPreset) => {
    setActivePresetId(preset.id);
    setSelectedVoiceId(preset.voiceId);
    setNarrationStyle(preset.narrationStyle);
    setVoiceSettings({
      ...preset.settings,
    });
  };

  // Save Current Combination as Custom User Preset
  const handleSaveUserPreset = (name: string) => {
    const newPreset: UserPreset = {
      id: `user-preset-${Date.now()}`,
      name,
      voiceId: selectedVoiceId,
      narrationStyle,
      settings: { ...voiceSettings },
      createdAt: new Date().toISOString(),
    };
    setUserPresets((prev) => [newPreset, ...prev]);
    setActivePresetId(newPreset.id);
  };

  // Delete Custom User Preset
  const handleDeleteUserPreset = (id: string) => {
    setUserPresets((prev) => prev.filter((p) => p.id !== id));
    if (activePresetId === id) {
      setActivePresetId(null);
    }
  };

  // Narration Style Selection
  const handleSelectStyle = (styleId: NarrationStyleId) => {
    setNarrationStyle(styleId);
    const matched = NARRATION_STYLES.find((s) => s.id === styleId);
    if (matched) {
      setVoiceSettings((prev) => ({
        ...prev,
        speed: Math.round(matched.speedMultiplier * 100) / 100,
        sentencePause: Math.round((matched.sentencePauseMs / 1000) * 100) / 100,
      }));
    }
  };

  // Generate Audio Action (Section 8)
  const handleGenerate = async () => {
    if (!text || !text.trim()) {
      setError('దయచేసి తెలుగు టెక్స్ట్ నమోదు చేయండి. (Please enter some Telugu text.)');
      return;
    }

    setIsGenerating(true);
    setError(null);

    try {
      const provider = TTSProviderRegistry.get(activeEngine);
      let res: TTSGenerateResult;

      try {
        res = await provider.generateSpeech({
          text,
          voiceId: selectedVoiceId,
          engine: activeEngine,
          narrationStyle,
          settings: voiceSettings,
          audioSettings,
          textSettings,
          pronunciationRules: pronunciationRules.filter((r) => r.active),
          sentences: sentences.length > 0 ? sentences : undefined,
        });
      } catch (primaryErr: any) {
        // Transparent multi-tier fallback:
        // Tier 1: Try Realistic Neural Studio Engine (free, reliable, high fidelity)
        // Tier 2: Try Google Native te-IN Engine
        console.warn('Primary engine failed, attempting Realistic Neural fallback:', primaryErr);
        try {
          const edgeProvider = TTSProviderRegistry.get('edge-neural');
          res = await edgeProvider.generateSpeech({
            text,
            voiceId: selectedVoiceId,
            engine: 'edge-neural',
            narrationStyle,
            settings: voiceSettings,
            audioSettings,
            textSettings,
            pronunciationRules: pronunciationRules.filter((r) => r.active),
            sentences: sentences.length > 0 ? sentences : undefined,
          });
          res.fallbackNote =
            'జెమిని ఏఐ కోటా పరిమితి కారణముగా రియలిస్టిక్ న్యూరల్ స్టూడియో ఇంజిన్ ద్వారా మీ ఆడియో అత్యున్నత నాణ్యతతో రూపొందించబడింది. (Generated via Realistic Neural Studio)';
        } catch (edgeErr) {
          console.warn('Realistic fallback failed, attempting Native Telugu fallback:', edgeErr);
          const nativeProvider = TTSProviderRegistry.get('native-telugu');
          res = await nativeProvider.generateSpeech({
            text,
            voiceId: selectedVoiceId,
            engine: 'native-telugu',
            narrationStyle,
            settings: voiceSettings,
            audioSettings,
            textSettings,
            pronunciationRules: pronunciationRules.filter((r) => r.active),
            sentences: sentences.length > 0 ? sentences : undefined,
          });
          res.fallbackNote =
            'నేటివ్ తెలుగు ఇంజిన్ ద్వారా మీ ఆడియో విజయవంతంగా రూపొందించబడింది. (Generated via Native Telugu Engine)';
        }
      }

      setResult(res);

      // Add to local history
      const voiceObj = TELUGU_VOICES.find((v) => v.id === selectedVoiceId);
      const newHistoryItem: HistoryItem = {
        id: `gen-${Date.now()}`,
        textSnippet: text.length > 90 ? text.substring(0, 90) + '...' : text,
        fullText: text,
        voiceId: selectedVoiceId,
        voiceName: voiceObj ? `${voiceObj.name} (${voiceObj.teluguName})` : selectedVoiceId,
        narrationStyle,
        durationSec: res.durationSec,
        format: res.format,
        audioUrl: res.audioUrl,
        audioBase64: res.audioBase64,
        filename: res.filename,
        createdAt: new Date().toISOString(),
      };

      // Safely persist audio binary into IndexedDB (completely bypasses localStorage quota)
      if (res.audioBase64) {
        saveAudioToDB(newHistoryItem.id, res.audioBase64);
      }

      setHistory((prev) => [newHistoryItem, ...prev.slice(0, 29)]);

      // Scroll to player smoothly
      setTimeout(() => {
        document.getElementById('yiuvoice-audio-player')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err: any) {
      let friendlyMsg = err?.message || '';
      try {
        if (friendlyMsg.includes('{')) {
          const jsonStart = friendlyMsg.indexOf('{');
          const parsed = JSON.parse(friendlyMsg.slice(jsonStart));
          if (parsed?.error?.message) {
            friendlyMsg = parsed.error.message;
          }
        }
      } catch {}

      if (friendlyMsg.includes('429') || friendlyMsg.toLowerCase().includes('quota')) {
        setError(
          'జెమిని ఏపీఐ ఉచిత కోటా ముగిసింది. దయచేసి "Google te-IN Native Engine" ఎంచుకొని ధ్వని రూపొందించండి. (API quota reached. Please select Google te-IN Native Engine.)'
        );
      } else {
        setError(
          friendlyMsg ||
            'ధ్వని ఉత్పత్తిలో లోపం సంభవించింది. దయచేసి మళ్లీ ప్రయత్నించండి. (Voice generation failed.)'
        );
      }
    } finally {
      setIsGenerating(false);
    }
  };

  // Preview Voice Sample
  const handlePreviewVoiceSample = async (voice: TTSVoice) => {
    if (isPlayingVoiceSample === voice.id) {
      sampleAudioRef.current?.pause();
      setIsPlayingVoiceSample(null);
      return;
    }

    setIsPlayingVoiceSample(voice.id);
    const previewSentence =
      voice.samplePhrase ||
      `నమస్కారం, ఇది ${voice.teluguName}. నా తెలుగు గళం మీ ప్రాజెక్ట్ కోసం సిద్ధంగా ఉంది.`;

    try {
      const res = await fetch('/api/tts/preview-sentence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: previewSentence,
          voiceId: voice.id,
          narrationStyle,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Preview failed');
      }
      const data = await res.json();

      if (!data.audioBase64) {
        throw new Error('No audio returned');
      }

      const binary = atob(data.audioBase64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'audio/mp3' });
      const url = URL.createObjectURL(blob);

      if (!sampleAudioRef.current) {
        sampleAudioRef.current = new Audio();
      }
      sampleAudioRef.current.src = url;
      sampleAudioRef.current.onended = () => setIsPlayingVoiceSample(null);
      sampleAudioRef.current.onerror = () => setIsPlayingVoiceSample(null);
      await sampleAudioRef.current.play().catch((playErr) => {
        console.warn('Audio play interrupted or requires user gesture:', playErr);
        setIsPlayingVoiceSample(null);
      });
    } catch (e: any) {
      console.warn('Voice preview issue:', e?.message || e);
      setIsPlayingVoiceSample(null);
    }
  };

  // Preview Single Sentence
  const handlePreviewSentence = async (sentence: SentenceItem) => {
    if (!sentence.text.trim()) return;
    setPreviewingSentenceId(sentence.id);

    try {
      const res = await fetch('/api/tts/preview-sentence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sentence.text,
          voiceId: selectedVoiceId,
          narrationStyle,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Sentence preview failed');
      }
      const data = await res.json();

      if (!data.audioBase64) {
        throw new Error('No audio returned');
      }

      const binary = atob(data.audioBase64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'audio/mp3' });
      const url = URL.createObjectURL(blob);

      if (!sampleAudioRef.current) {
        sampleAudioRef.current = new Audio();
      }
      sampleAudioRef.current.src = url;
      sampleAudioRef.current.onended = () => setPreviewingSentenceId(null);
      sampleAudioRef.current.onerror = () => setPreviewingSentenceId(null);
      await sampleAudioRef.current.play().catch((playErr) => {
        console.warn('Audio play interrupted or requires user gesture:', playErr);
        setPreviewingSentenceId(null);
      });
    } catch (e: any) {
      console.warn('Sentence preview issue:', e?.message || e);
      setPreviewingSentenceId(null);
    }
  };

  // Play item from history
  const handlePlayHistoryItem = async (item: HistoryItem) => {
    let base64 = item.audioBase64;
    if (!base64) {
      base64 = (await getAudioFromDB(item.id)) || undefined;
    }

    let url = item.audioUrl;
    if (!url && base64) {
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const mime = item.format === 'wav' ? 'audio/wav' : 'audio/mp3';
      const blob = new Blob([bytes], { type: mime });
      url = URL.createObjectURL(blob);
    }

    if (url) {
      setResult({
        audioUrl: url,
        audioBlob: new Blob(),
        audioBase64: base64 || '',
        format: item.format,
        durationSec: item.durationSec,
        filename: item.filename,
        voiceUsed: item.voiceId,
        engineUsed: 'gemini-neural',
        narrationStyleUsed: item.narrationStyle,
        processedText: item.fullText || item.textSnippet,
        generatedAt: item.createdAt,
      });
      setCurrentTab('studio');
      setTimeout(() => {
        document.getElementById('yiuvoice-audio-player')?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      // If audio file wasn't stored, populate text into editor so user can regenerate
      setText(item.fullText || item.textSnippet);
      setCurrentTab('studio');
    }
  };

  // Download item from history
  const handleDownloadHistoryItem = async (item: HistoryItem) => {
    let base64 = item.audioBase64;
    if (!base64) {
      base64 = (await getAudioFromDB(item.id)) || undefined;
    }

    let url = item.audioUrl;
    if (!url && base64) {
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const mime = item.format === 'wav' ? 'audio/wav' : 'audio/mp3';
      const blob = new Blob([bytes], { type: mime });
      url = URL.createObjectURL(blob);
    }

    if (url) {
      const a = document.createElement('a');
      a.href = url;
      a.download = item.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  // Select sample from modal
  const handleSelectSample = (sample: SampleTeluguText) => {
    setText(sample.text);
    const chosenStyle = (sample.recommendedStyle || sample.presetStyle) as NarrationStyleId;
    if (chosenStyle) {
      setNarrationStyle(chosenStyle);
    }
    setSentences(splitIntoTeluguSentences(sample.text));
  };

  const selectedVoice = TELUGU_VOICES.find((v) => v.id === selectedVoiceId) || TELUGU_VOICES[0];

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col selection:bg-cyan-500/30 font-sans antialiased">
      {/* App Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          if (tab === 'about') {
            setIsAboutModalOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
        activeEngine={activeEngine}
        setActiveEngine={setActiveEngine}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenPronunciation={() => setIsPronunciationOpen(true)}
        onOpenDownloadApk={() => setIsDownloadApkOpen(true)}
        historyCount={history.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Error Notification Banner */}
        {error && (
          <div className="p-4 rounded-xl bg-red-500/15 border border-red-500/40 text-red-300 text-sm flex items-start justify-between gap-3 animate-fade-in shadow-lg shadow-red-950/20">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold block">లోపం (Generation Error):</strong>
                <p className="mt-0.5 text-xs text-red-200/90">{error}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setError(null)}
              className="text-red-400 hover:text-red-200 text-xs font-bold px-2 py-1 rounded bg-red-500/20 cursor-pointer"
            >
              సరే (Dismiss)
            </button>
          </div>
        )}

        {/* Tab 1: Voice Studio (Primary Workspace) */}
        {currentTab === 'studio' && (
          <div className="space-y-6 animate-fade-in">
            {/* Android APK Download Quick Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900/90 to-cyan-950/40 border border-emerald-500/30 text-xs shadow-md shadow-emerald-950/20">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-100 flex items-center gap-2">
                    <span>Android APK ఫైల్ అందుబాటులో ఉంది</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      v1.2.0 .apk
                    </span>
                  </div>
                  <p className="text-slate-400 mt-0.5">
                    మీ ఆండ్రాయిడ్ ఫోన్‌లో YiuVoice మొబైల్ యాప్‌ను డైరెక్ట్‌గా డౌన్‌లోడ్ చేసి ఇన్‌స్టాల్ చేసుకోండి.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <a
                  id="direct-download-apk-link"
                  href="/api/download/apk"
                  download="yiuvoice-v1.2.0.apk"
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20 active:scale-95 cursor-pointer"
                  title="Direct Download APK (58.9 KB)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>డౌన్‌లోడ్ APK (.apk)</span>
                </a>

                <button
                  id="banner-open-apk-modal-btn"
                  type="button"
                  onClick={() => setIsDownloadApkOpen(true)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold transition-all cursor-pointer"
                  title="View all installation options"
                >
                  మరిన్ని వివరాలు
                </button>
              </div>
            </div>

            {/* Top Workspace Grid: Text Editor + Quick Details */}
            <TextEditor
              text={text}
              onChange={handleTextChange}
              onOpenSampleModal={() => setIsSampleModalOpen(true)}
            />

            {/* Voice Selection Section (Requirement #4) */}
            <VoiceSelector
              voices={TELUGU_VOICES}
              selectedVoiceId={selectedVoiceId}
              onSelectVoice={handleSelectVoice}
              activeEngine={activeEngine}
              onPreviewVoiceSample={handlePreviewVoiceSample}
              isPlayingSample={isPlayingVoiceSample}
            />

            {/* Voice Controls & Presets (Requirement #5 & #13 + Custom Presets) */}
            <VoiceControls
              settings={voiceSettings}
              onChange={setVoiceSettings}
              onApplyPreset={handleApplyPreset}
              activePresetId={activePresetId}
              currentVoiceId={selectedVoiceId}
              currentNarrationStyle={narrationStyle}
              userPresets={userPresets}
              onApplyUserPreset={handleApplyUserPreset}
              onDeleteUserPreset={handleDeleteUserPreset}
              onOpenSavePresetModal={() => setIsSavePresetModalOpen(true)}
            />

            {/* Narration Styles Selector (Requirement #6) */}
            <NarrationStyleSelector
              selectedStyleId={narrationStyle}
              onSelectStyle={handleSelectStyle}
            />

            {/* Big Prominent Generate Button Bar (Requirement #8) */}
            <div className="w-full bg-[#101522] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Mic className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <span>ఎంచుకున్న గళం: {selectedVoice.name}</span>
                    <span className="text-xs text-slate-400 font-telugu">({selectedVoice.teluguName})</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    రీతి: <strong className="text-cyan-300">{narrationStyle}</strong> • వేగం:{' '}
                    <strong className="text-cyan-300">{voiceSettings.speed}x</strong> • ఫార్మాట్:{' '}
                    <strong className="text-emerald-400 uppercase">{audioSettings.format}</strong>
                  </div>
                </div>
              </div>

              {/* Large Generate Button */}
              <button
                id="btn-generate-speech"
                type="button"
                onClick={handleGenerate}
                disabled={isGenerating || !text.trim()}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 text-slate-950 font-black text-base shadow-xl shadow-cyan-500/25 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:pointer-events-none cursor-pointer ring-2 ring-white/20 active:scale-[0.98]"
              >
                <Sparkles className="w-5 h-5 stroke-[2.5]" />
                <span>
                  {isGenerating
                    ? 'ధ్వని రూపొందుతోంది…'
                    : '🎙️ తెలుగు వాయిస్ రూపొందించండి (Generate Voice)'}
                </span>
              </button>
            </div>

            {/* Audio Player & MP3 Download Section (Requirements #9 & #10) */}
            <AudioPlayer
              result={result}
              isLoading={isGenerating}
              onRegenerate={handleGenerate}
            />
          </div>
        )}

        {/* Tab 2: Sentence-Level Controls (Requirement #7) */}
        {currentTab === 'sentences' && (
          <div className="space-y-6 animate-fade-in">
            <SentenceEditor
              fullText={text}
              sentences={sentences}
              onChangeSentences={setSentences}
              onPreviewSentence={handlePreviewSentence}
              onApplyBackToText={(newFull) => {
                setText(newFull);
                setCurrentTab('studio');
              }}
              previewingSentenceId={previewingSentenceId}
            />

            {/* Quick action bar */}
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setCurrentTab('studio')}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-all cursor-pointer flex items-center gap-2"
              >
                <span>స్టూడియోకు తిరిగి వెళ్లండి (Back to Studio)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: History Drawer (Requirement #14) */}
        {currentTab === 'history' && (
          <div className="space-y-6 animate-fade-in">
            <HistoryDrawer
              history={history}
              onPlayItem={handlePlayHistoryItem}
              onDownloadItem={handleDownloadHistoryItem}
              onUseText={(t) => {
                setText(t);
                setCurrentTab('studio');
              }}
              onDeleteItem={(id) => {
                deleteAudioFromDB(id);
                setHistory((prev) => prev.filter((h) => h.id !== id));
              }}
              onClearHistory={() => {
                clearAudioDB();
                setHistory([]);
              }}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-[#06080d] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-400">YiuVoice</span>
            <span>•</span>
            <span>తెలుగు AI టెక్స్ట్-టు-స్పీచ్ స్టూడియో (Telugu AI Voice Platform)</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>24kHz Studio PCM & LameJS MP3</span>
            <span>•</span>
            <button
              onClick={() => setIsAboutModalOpen(true)}
              className="text-slate-400 hover:text-cyan-400 cursor-pointer transition-colors"
            >
              About & Architecture
            </button>
            <span>•</span>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="text-slate-400 hover:text-cyan-400 cursor-pointer transition-colors"
            >
              Settings
            </button>
            <span>•</span>
            <button
              id="footer-download-apk-btn"
              onClick={() => setIsDownloadApkOpen(true)}
              className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer transition-colors flex items-center gap-1"
            >
              <Smartphone className="w-3 h-3" />
              <span>Android APK</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AdvancedSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        voiceSettings={voiceSettings}
        onChangeVoiceSettings={setVoiceSettings}
        audioSettings={audioSettings}
        onChangeAudioSettings={setAudioSettings}
        textSettings={textSettings}
        onChangeTextSettings={setTextSettings}
        activeEngine={activeEngine}
        onChangeEngine={setActiveEngine}
      />

      <PronunciationModal
        isOpen={isPronunciationOpen}
        onClose={() => setIsPronunciationOpen(false)}
        rules={pronunciationRules}
        onChangeRules={setPronunciationRules}
      />

      <SampleTextModal
        isOpen={isSampleModalOpen}
        onClose={() => setIsSampleModalOpen(false)}
        onSelectSample={handleSelectSample}
      />

      <AboutModal
        isOpen={isAboutModalOpen}
        onClose={() => setIsAboutModalOpen(false)}
      />

      <SavePresetModal
        isOpen={isSavePresetModalOpen}
        onClose={() => setIsSavePresetModalOpen(false)}
        voiceId={selectedVoiceId}
        narrationStyle={narrationStyle}
        voiceSettings={voiceSettings}
        onSavePreset={handleSaveUserPreset}
      />

      <DownloadApkModal
        isOpen={isDownloadApkOpen}
        onClose={() => setIsDownloadApkOpen(false)}
      />
    </div>
  );
}
