"use client";

import ErrorBoundary from "@/components/ErrorBoundary";
import Dashboard from "@/app/page";

/**
 * רכיב השורש המשותף (Vite / React Web Preview).
 * עוטף את לוח המחוונים ב-ErrorBoundary כדי למנוע מסך ריק בכל תרחיש כשל.
 */
export default function App() {
  return (
    <div dir="rtl" lang="he" className="min-h-screen bg-slate-950 text-slate-100 antialiased">
      <ErrorBoundary title="שגיאה כללית באפליקציה - לחץ לנסות שוב">
        <Dashboard />
      </ErrorBoundary>
    </div>
  );
}
