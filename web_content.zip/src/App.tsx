/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { Suggestions } from './components/Suggestions';
import { Sidebar } from './components/Sidebar';
import { DeployGuideModal } from './components/DeployGuideModal';
import { fetchServerStatus, sendChatMessage } from './services/api';
import { ChatMessage as ChatMessageType, Conversation } from './types/chat';
import { ArrowDown, AlertCircle, RefreshCw, Sparkles, Trash2 } from 'lucide-react';

const STORAGE_KEY = 'mostafa_ai_conversations_v1';
const ACTIVE_CONV_KEY = 'mostafa_ai_active_conv_id';

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeId, setActiveId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(ACTIVE_CONV_KEY) || null;
    } catch {
      return null;
    }
  });

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isClearAllModalOpen, setIsClearAllModalOpen] = useState(false);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [serverOk, setServerOk] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Sync conversations to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }, [conversations]);

  // Sync activeId
  useEffect(() => {
    if (activeId) {
      localStorage.setItem(ACTIVE_CONV_KEY, activeId);
    } else {
      localStorage.removeItem(ACTIVE_CONV_KEY);
    }
  }, [activeId]);

  // Verify server connection on load
  useEffect(() => {
    fetchServerStatus().then((status) => {
      setServerOk(status.status === 'ok');
    });
  }, []);

  // Find active conversation
  const currentConversation = conversations.find((c) => c.id === activeId);
  const messages: ChatMessageType[] = currentConversation ? currentConversation.messages : [];

  // Auto scroll to bottom
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages.length, messages[messages.length - 1]?.content]);

  // Handle scroll detection for "Scroll to Bottom" button
  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottom(distanceToBottom > 160);
  };

  // Start a new chat
  const handleNewChat = () => {
    setActiveId(null);
    setErrorMessage(null);
  };

  // Clear current chat messages
  const handleClearChat = () => {
    if (!activeId) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === activeId ? { ...c, messages: [], updatedAt: Date.now() } : c))
    );
    setErrorMessage(null);
  };

  // Delete specific conversation
  const handleDeleteConversation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) {
      const remaining = conversations.filter((c) => c.id !== id);
      setActiveId(remaining.length > 0 ? remaining[0].id : null);
    }
  };

  // Open clear-all confirmation modal (No window.confirm)
  const handleRequestClearAll = () => {
    setIsClearAllModalOpen(true);
  };

  // Confirmed clear all
  const handleConfirmClearAll = () => {
    setConversations([]);
    setActiveId(null);
    setIsClearAllModalOpen(false);
    setErrorMessage(null);
  };

  // Execute request to backend and stream response into conversation
  const executeGeneration = async (
    targetConvId: string,
    historyToSend: ChatMessageType[]
  ) => {
    const assistantId = `msg_ai_${Date.now()}`;
    const assistantPlaceholder: ChatMessageType = {
      id: assistantId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    // Add assistant placeholder
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === targetConvId) {
          return {
            ...c,
            updatedAt: Date.now(),
            messages: [...c.messages, assistantPlaceholder],
          };
        }
        return c;
      })
    );

    setIsLoading(true);

    try {
      let accumulatedContent = '';

      const finalReply = await sendChatMessage(historyToSend, (token) => {
        accumulatedContent += token;
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === targetConvId) {
              return {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === assistantId ? { ...m, content: accumulatedContent, isStreaming: true } : m
                ),
              };
            }
            return c;
          })
        );
      });

      // Mark streaming completed
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === targetConvId) {
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === assistantId
                  ? { ...m, content: finalReply || accumulatedContent, isStreaming: false }
                  : m
              ),
            };
          }
          return c;
        })
      );
    } catch (err: any) {
      console.error('Chat generation error:', err);
      const errText =
        err?.message || 'تعذر الاتصال بـ Mostafa AI. يرجى المحاولة بعد لحظات.';
      setErrorMessage(errText);

      // Render friendly error message inside the assistant bubble
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === targetConvId) {
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === assistantId
                  ? {
                      ...m,
                      content: `⚠️ ${errText}`,
                      isStreaming: false,
                    }
                  : m
              ),
            };
          }
          return c;
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Send new user message
  const handleSendMessage = async (
    text: string,
    image?: { data: string; mimeType: string; previewUrl?: string }
  ) => {
    if (isLoading || (!text.trim() && !image)) return;

    setErrorMessage(null);

    const userMessage: ChatMessageType = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      image,
    };

    let targetConvId = activeId;
    let targetHistory: ChatMessageType[] = [];

    // If no active conversation, create one
    if (!targetConvId || !currentConversation) {
      targetConvId = `conv_${Date.now()}`;
      const title = text.trim() ? (text.length > 32 ? `${text.slice(0, 32)}...` : text) : 'تحليل صورة';
      const newConv: Conversation = {
        id: targetConvId,
        title,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [userMessage],
      };
      setConversations((prev) => [newConv, ...prev]);
      setActiveId(targetConvId);
      targetHistory = [userMessage];
    } else {
      // Append user message to active conversation
      targetHistory = [...currentConversation.messages, userMessage];
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === targetConvId) {
            return {
              ...c,
              updatedAt: Date.now(),
              messages: targetHistory,
            };
          }
          return c;
        })
      );
    }

    await executeGeneration(targetConvId, targetHistory);
  };

  // Retry generating last response without duplicating user messages
  const handleRetry = async () => {
    if (isLoading || !activeId) return;

    const targetConv = conversations.find((c) => c.id === activeId);
    if (!targetConv || targetConv.messages.length === 0) return;

    setErrorMessage(null);

    // Remove the trailing failed assistant message if it exists
    const cleanList = [...targetConv.messages];
    if (cleanList.length > 0 && cleanList[cleanList.length - 1].role === 'assistant') {
      cleanList.pop();
    }

    // Verify there is a user message to respond to
    const hasUserMsg = cleanList.some((m) => m.role === 'user');
    if (!hasUserMsg) return;

    // Update conversation state with the cleaned list
    setConversations((prev) =>
      prev.map((c) => (c.id === activeId ? { ...c, messages: cleanList } : c))
    );

    // Execute generation with cleaned history
    await executeGeneration(activeId, cleanList);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#070C1A] text-slate-100 font-sans select-text">
      {/* Sidebar for conversations */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        conversations={conversations}
        activeId={activeId}
        onSelectConversation={(id) => setActiveId(id)}
        onNewChat={handleNewChat}
        onDeleteConversation={handleDeleteConversation}
        onClearAll={handleRequestClearAll}
        onOpenGuide={() => setIsGuideOpen(true)}
      />

      {/* Main Chat Workspace */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative">
        {/* Header */}
        <Header
          onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
          onNewChat={handleNewChat}
          onClearChat={handleClearChat}
          onOpenGuide={() => setIsGuideOpen(true)}
          hasMessages={messages.length > 0}
          isOnline={serverOk}
        />

        {/* Chat Messages Scroll Container */}
        <div
          ref={chatContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 space-y-3.5 scroll-smooth"
        >
          {messages.length === 0 ? (
            <div className="min-h-full flex flex-col items-center justify-center">
              <Suggestions onSelectSuggestion={(prompt) => handleSendMessage(prompt)} />
            </div>
          ) : (
            <div className="max-w-4xl mx-auto space-y-3 sm:space-y-4 pb-2">
              {messages.map((msg) => (
                <ChatMessage
                  key={msg.id}
                  message={msg}
                  onRetry={msg.role === 'assistant' ? handleRetry : undefined}
                />
              ))}

              {/* Loading thinking indicator */}
              {isLoading && messages[messages.length - 1]?.content === '' && (
                <div className="w-full py-3 px-4 rounded-2xl bg-[#0E172E]/90 border border-blue-900/40 flex items-center gap-3 animate-pulse">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-700 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
                    <Sparkles className="w-4 h-4 animate-spin text-cyan-200" />
                  </div>
                  <div className="flex items-center gap-1.5 text-blue-300 text-xs sm:text-sm font-medium">
                    <span>Mostafa AI يفكر الآن</span>
                    <span className="flex gap-1 mr-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Floating Scroll-to-Bottom Button */}
        {showScrollBottom && (
          <button
            onClick={() => scrollToBottom('smooth')}
            className="absolute bottom-24 left-6 z-20 p-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/40 border border-blue-400/40 active:scale-95 transition-all animate-bounce"
            title="الانتقال إلى أسفل المحادثة"
          >
            <ArrowDown className="w-4 h-4" />
          </button>
        )}

        {/* Global Error Banner if any */}
        {errorMessage && (
          <div className="max-w-4xl mx-auto w-full px-3 mb-1 animate-fade-in">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-rose-950/60 border border-rose-800/60 text-rose-200 text-xs">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleRetry}
                  className="flex items-center gap-1 px-2 py-0.5 rounded bg-rose-800/50 hover:bg-rose-700/60 text-rose-100 text-[11px] transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>إعادة المحاولة</span>
                </button>
                <button
                  onClick={() => setErrorMessage(null)}
                  className="p-1 hover:text-white text-rose-300"
                >
                  ✕
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Sticky Chat Input Bar */}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </div>

      {/* Deploy & Setup Step-by-Step Guide Modal */}
      <DeployGuideModal isOpen={isGuideOpen} onClose={() => setIsGuideOpen(false)} />

      {/* In-App Confirmation Modal for Clearing All Conversations (No window.confirm) */}
      {isClearAllModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in">
          <div className="bg-[#0A1126] border border-blue-900/60 rounded-2xl p-5 max-w-sm w-full shadow-2xl text-right">
            <div className="flex items-center gap-2.5 text-rose-400 mb-2">
              <Trash2 className="w-5 h-5 flex-shrink-0" />
              <h3 className="font-bold text-white text-sm">مسح جميع سجلات المحادثات</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              هل أنت متأكد من رغبتك في حذف كافة المحادثات السابقة؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex items-center justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setIsClearAllModalOpen(false)}
                className="px-3.5 py-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-950/60 border border-blue-900/40 transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmClearAll}
                className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold shadow-md shadow-rose-600/30 transition-colors"
              >
                تأكيد المسح
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
