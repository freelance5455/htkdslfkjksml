import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { ChakraMandala } from './components/ChakraMandala';
import { VoiceController } from './components/VoiceController';
import { PalmScannerModal } from './components/PalmScannerModal';
import { PalmAnalysisView } from './components/PalmAnalysisView';
import { SettingsModal } from './components/SettingsModal';
import { CleanMemoryModal } from './components/CleanMemoryModal';
import { LiveSession } from './services/liveSession';
import {
  AppSettings,
  CameraState,
  PalmReadingResult,
  SessionState,
} from './types';

const STORAGE_KEY = 'ai_partner_user_settings';

const DEFAULT_SETTINGS: AppSettings = {
  geminiApiKey: '',
  theme: 'dark',
  autoStartCamera: false,
  voiceLanguage: 'auto',
};

export default function App() {
  // Application Settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_SETTINGS, ...parsed };
      }
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });

  const hasSavedKey = !!settings.geminiApiKey && settings.geminiApiKey.trim().length > 0;

  // States
  const [sessionState, setSessionState] = useState<SessionState>('DISCONNECTED');
  const [cameraState, setCameraState] = useState<CameraState>('CAMERA_OFF');
  const [latestTranscript, setLatestTranscript] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [volumeLevel, setVolumeLevel] = useState<number>(0);

  // Modal / View Controls
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isCleanModalOpen, setIsCleanModalOpen] = useState<boolean>(false);

  // Palm Analysis States
  const [isAnalyzingPalm, setIsAnalyzingPalm] = useState<boolean>(false);
  const [palmProgressPercent, setPalmProgressPercent] = useState<number>(0);
  const [palmReadingResult, setPalmReadingResult] = useState<PalmReadingResult | null>(null);

  // Live Session Reference
  const liveSessionRef = useRef<LiveSession | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Sync theme with document class
  useEffect(() => {
    if (settings.theme === 'light') {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
  }, [settings.theme]);

  // Save settings in localStorage
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));
    if (newSettings.geminiApiKey && newSettings.geminiApiKey.trim()) {
      setErrorMessage(null);
    }
    if (liveSessionRef.current) {
      liveSessionRef.current.setApiKey(newSettings.geminiApiKey.trim());
    }
  };

  // Initialize LiveSession
  useEffect(() => {
    const liveSession = new LiveSession({
      onStateChange: (newState) => {
        setSessionState(newState);
        if (newState === 'LISTENING' || newState === 'SPEAKING') {
          setErrorMessage(null);
        }
      },
      onTranscript: (text) => {
        setLatestTranscript(text);
      },
      onError: (msg) => {
        setErrorMessage(msg);
      },
      onInterrupted: () => {
        // Interrupted by user
      },
    });

    if (settings.geminiApiKey) {
      liveSession.setApiKey(settings.geminiApiKey.trim());
    }
    liveSessionRef.current = liveSession;

    // Volume level animation loop
    const updateVolume = () => {
      const streamer = liveSession.getAudioStreamer();
      if (streamer) {
        const outVol = streamer.getOutputVolume();
        const inVol = streamer.getInputVolume();
        const combined = Math.max(outVol, inVol);
        setVolumeLevel(combined);
      }
      animFrameRef.current = requestAnimationFrame(updateVolume);
    };
    animFrameRef.current = requestAnimationFrame(updateVolume);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      liveSession.disconnect();
    };
  }, []);

  // Keep camera state synced with LiveSession
  const handleCameraStateChange = useCallback((newState: CameraState) => {
    setCameraState(newState);
    if (liveSessionRef.current) {
      liveSessionRef.current.setCameraState(newState);
    }
  }, []);

  // Send camera frame to LiveSession
  const handleSendFrame = useCallback((base64Jpeg: string, force?: boolean): boolean => {
    if (liveSessionRef.current) {
      return liveSessionRef.current.sendVideoFrame(base64Jpeg, force);
    }
    return false;
  }, []);

  // Toggle Live Voice Session (API KEY GATED)
  const handleToggleSession = async () => {
    if (!liveSessionRef.current) return;

    if (sessionState === 'LISTENING' || sessionState === 'SPEAKING' || sessionState === 'CONNECTING') {
      liveSessionRef.current.disconnect();
      return;
    }

    setErrorMessage(null);

    // API KEY GATE: The app must NOT start Gemini Live AI until the user has entered and saved their own key
    if (!hasSavedKey) {
      setErrorMessage('Please add and save your Gemini API key in Settings first.');
      return;
    }

    liveSessionRef.current.setApiKey(settings.geminiApiKey.trim());
    await liveSessionRef.current.connect();
  };

  // CLEAN / Start Fresh (Preserves Saved API Key)
  const handleCleanSession = () => {
    if (liveSessionRef.current) {
      liveSessionRef.current.cleanSession();
    }
    setPalmReadingResult(null);
    setLatestTranscript('');
    setErrorMessage(null);
    setIsCleanModalOpen(true);
  };

  // Perform Deep Palm Reading Analysis
  const handleStartAnalysis = async (capturedImage: string) => {
    setIsScannerOpen(false);

    if (!hasSavedKey) {
      setErrorMessage('Please add and save your Gemini API key in Settings first.');
      setIsSettingsOpen(true);
      return;
    }

    setIsAnalyzingPalm(true);
    setPalmProgressPercent(15);

    const progressInterval = setInterval(() => {
      setPalmProgressPercent((prev) => {
        if (prev >= 88) {
          clearInterval(progressInterval);
          return 88;
        }
        return prev + 6;
      });
    }, 180);

    try {
      const apiKey = settings.geminiApiKey.trim();
      const res = await fetch('/api/palm/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: capturedImage,
          key: apiKey,
        }),
      });

      clearInterval(progressInterval);
      setPalmProgressPercent(100);

      const json = await res.json();
      if (!res.ok || json.error) {
        throw new Error(json.message || 'Failed to analyze palm.');
      }

      const reading: PalmReadingResult = {
        career: json.data?.career || 'Strong creative leadership and growth in communication.',
        loveLife: json.data?.loveLife || 'Emotional loyalty with deep genuine bonds.',
        health: json.data?.health || 'Great vitality, maintain sound sleep and mental stillness.',
        future: json.data?.future || 'Bright new beginnings and fortunate travel opportunities.',
        summary: json.data?.summary || 'Your palm reveals rare creative intuition and positive fortune.',
        timestamp: Date.now(),
        capturedImageUrl: capturedImage,
      };

      if (json.data?.speechText && liveSessionRef.current && sessionState === 'LISTENING') {
        liveSessionRef.current.sendText(
          `[System Instruction: You just scanned the user's palm. Speak this reading warmly: "${json.data.speechText}"]`
        );
      }

      setTimeout(() => {
        setIsAnalyzingPalm(false);
        setPalmReadingResult(reading);
      }, 500);
    } catch (err: unknown) {
      clearInterval(progressInterval);
      setIsAnalyzingPalm(false);
      const msg = err instanceof Error ? err.message : 'Palm analysis error';
      setErrorMessage(msg);
    }
  };

  return (
    <div className="h-[100dvh] max-h-[100dvh] w-full flex flex-col justify-between relative bg-[#070913] text-white overflow-hidden select-none">
      {/* Background ambient lighting */}
      <div className="fixed -top-40 -left-40 w-96 h-96 bg-purple-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed -bottom-40 -right-40 w-96 h-96 bg-cyan-500/15 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Header: AI Partner + Sitting + Camera + Refresh/Reset */}
      <Header
        cameraState={cameraState}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onCleanSession={handleCleanSession}
        hasSavedKey={hasSavedKey}
      />

      {/* Center Design: Pure Rotating Zodiac / Sacred Chakra Mandala (Zero human photo) */}
      <main className="flex-1 flex flex-col items-center justify-center w-full px-4 max-w-md mx-auto my-auto overflow-hidden">
        <ChakraMandala
          sessionState={sessionState}
          latestTranscript={latestTranscript}
          isAudioActive={volumeLevel > 0.08}
        />
      </main>

      {/* Bottom Area: ONE START Section / Button */}
      <footer className="w-full max-w-md mx-auto shrink-0">
        <VoiceController
          sessionState={sessionState}
          onToggleSession={handleToggleSession}
          volumeLevel={volumeLevel}
          errorMessage={errorMessage}
          hasSavedKey={hasSavedKey}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      </footer>

      {/* Palm Scanner View (REAL CAMERA) */}
      <PalmScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        cameraState={cameraState}
        onCameraStateChange={handleCameraStateChange}
        onSendFrame={handleSendFrame}
        onStartAnalysis={handleStartAnalysis}
      />

      {/* Palm Analysis & Reading Results View */}
      {(isAnalyzingPalm || palmReadingResult) && (
        <PalmAnalysisView
          isLoading={isAnalyzingPalm}
          progressPercent={palmProgressPercent}
          readingResult={palmReadingResult}
          onClose={() => setPalmReadingResult(null)}
          onRescan={() => {
            setPalmReadingResult(null);
            setIsScannerOpen(true);
          }}
          onSpeakSummary={(text) => {
            if (liveSessionRef.current && sessionState === 'LISTENING') {
              liveSessionRef.current.sendText(`Read aloud this palm analysis: ${text}`);
            } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
              try {
                window.speechSynthesis.cancel();
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.rate = 1.05;
                utterance.pitch = 1.15;
                window.speechSynthesis.speak(utterance);
              } catch {
                // ignore
              }
            }
          }}
        />
      )}

      {/* Settings Modal (Sitting) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        hasEnvKey={false}
      />

      {/* Clean Memory Modal ("Start Fresh") */}
      <CleanMemoryModal
        isOpen={isCleanModalOpen}
        onStartNewConversation={() => {
          setIsCleanModalOpen(false);
          if (sessionState === 'DISCONNECTED' && hasSavedKey) {
            handleToggleSession();
          }
        }}
      />
    </div>
  );
}
