import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { MessageItem } from './components/MessageItem';
import { ChatInput } from './components/ChatInput';
import { WelcomeHero } from './components/WelcomeHero';
import { GuideModal } from './components/GuideModal';
import { ClearConfirmModal } from './components/ClearConfirmModal';
import { UtaraDictionaryDrawer } from './components/UtaraDictionaryDrawer';
import { ImageEditor } from './components/ImageEditor';
import { ImageSetupModal } from './components/ImageSetupModal';
import { ChatMessage, PersonaMode, ActiveTab } from './types';
import { AlertCircle, ArrowDown } from 'lucide-react';

const STORAGE_KEY_MESSAGES = 'hann_ai_chat_history_v2';
const STORAGE_KEY_MODE = 'hann_ai_persona_mode_v2';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MESSAGES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Clean out any blank or thinking artifacts from previous sessions
          return parsed.filter(
            (m: any) =>
              m &&
              typeof m.content === 'string' &&
              m.content.trim().length > 0 &&
              !m.isThinking
          );
        }
      }
      return [];
    } catch {
      return [];
    }
  });

  const [mode, setMode] = useState<PersonaMode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MODE);
      return (saved as PersonaMode) || 'utara';
    } catch {
      return 'utara';
    }
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isDictionaryOpen, setIsDictionaryOpen] = useState(false);
  const [isImageSetupOpen, setIsImageSetupOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Save valid messages to localStorage
  useEffect(() => {
    try {
      const validMessages = messages.filter(
        (m) => m.content && m.content.trim().length > 0 && !m.isThinking
      );
      localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(validMessages));
    } catch (e) {
      console.warn('Failed to save chat to localStorage:', e);
    }
  }, [messages]);

  // Save mode to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_MODE, mode);
    } catch (e) {
      console.warn('Failed to save mode to localStorage:', e);
    }
  }, [mode]);

  // Scroll to bottom helper
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    if (activeTab === 'chat') {
      scrollToBottom();
    }
  }, [messages, isLoading, activeTab]);

  // Scroll listener to toggle "jump to bottom" button
  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 120;
    setShowScrollBottom(!isNearBottom);
  };

  // Send message handler
  const handleSendMessage = async (text: string) => {
    const trimmedText = text.trim();
    if (!trimmedText || isLoading) return;

    setErrorMessage(null);

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: trimmedText,
      timestamp: Date.now(),
    };

    const thinkingBotMessageId = `bot-${Date.now()}`;
    const botThinkingMessage: ChatMessage = {
      id: thinkingBotMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isThinking: true,
    };

    // Filter out previous thinking or error items for the API payload
    const activeHistory = messages.filter(
      (m) => m.content && m.content.trim().length > 0 && !m.isThinking && !m.isError
    );

    const updatedMessages = [...messages, userMessage, botThinkingMessage];
    setMessages(updatedMessages);
    setIsLoading(true);

    try {
      const payloadMessages = [
        ...activeHistory.map((m) => ({ role: m.role, content: m.content })),
        { role: 'user', content: trimmedText },
      ];

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: payloadMessages,
          mode,
        }),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok || !data?.success) {
        const errorDetail =
          data?.error ||
          (response.status === 503
            ? 'Model AI sedang menerima trafik yang sangat tinggi. Sila cuba lagi sebentar lagi.'
            : `Ralat pelayan (Kod: ${response.status}). Sila semak sambungan anda.`);
        throw new Error(errorDetail);
      }

      const replyContent = data.reply || 'Maaf hang, jawapan kosong diterima.';

      // Replace the thinking placeholder with the real AI answer
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === thinkingBotMessageId
            ? {
                ...msg,
                content: replyContent,
                isThinking: false,
                isError: false,
              }
            : msg
        )
      );
    } catch (err: any) {
      console.error('Chat API error:', err);
      const displayError =
        err?.message ||
        'Maaf hang, ada masalah teknikal semasa berhubung dengan server AI.';

      setErrorMessage(displayError);

      // Replace thinking message with actionable error card
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === thinkingBotMessageId
            ? {
                ...msg,
                content: `⚠️ ${displayError}`,
                isThinking: false,
                isError: true,
              }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Retry sending when a previous attempt had an error
  const handleRetry = (errorMsgId: string) => {
    const msgIndex = messages.findIndex((m) => m.id === errorMsgId);
    let userPromptToRetry = '';

    for (let i = msgIndex - 1; i >= 0; i--) {
      if (messages[i].role === 'user') {
        userPromptToRetry = messages[i].content;
        break;
      }
    }

    if (userPromptToRetry) {
      setMessages((prev) => prev.filter((m) => m.id !== errorMsgId));
      handleSendMessage(userPromptToRetry);
    }
  };

  // Clear chat handler
  const handleClearChat = () => {
    setMessages([]);
    setErrorMessage(null);
    try {
      localStorage.removeItem(STORAGE_KEY_MESSAGES);
    } catch (e) {
      console.warn('Failed to clear storage:', e);
    }
  };

  return (
    <div className="flex flex-col h-[100vh] h-[100dvh] w-full bg-[#080312] text-slate-100 overflow-hidden relative">
      {/* Background neon ambient glows */}
      <div className="pointer-events-none fixed top-0 left-1/4 w-96 h-96 bg-purple-900/15 rounded-full blur-[120px] -z-10" />
      <div className="pointer-events-none fixed bottom-1/4 right-1/4 w-96 h-96 bg-fuchsia-900/10 rounded-full blur-[140px] -z-10" />

      {/* Top Header with Tab Switcher */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        mode={mode}
        onModeChange={setMode}
        onOpenGuide={() => setIsGuideOpen(true)}
        onOpenDictionary={() => setIsDictionaryOpen(true)}
        onOpenClearModal={() => setIsClearModalOpen(true)}
        onOpenImageSetup={() => setIsImageSetupOpen(true)}
        messageCount={messages.length}
      />

      {/* Error banner if present */}
      {errorMessage && activeTab === 'chat' && (
        <div className="bg-red-950/90 border-b border-red-500/40 px-4 py-2.5 flex items-center justify-between text-xs text-red-200 shadow-md">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="font-medium">{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-red-300 hover:text-white ml-2 text-sm font-bold p-1"
            title="Tutup amaran"
          >
            ✕
          </button>
        </div>
      )}

      {/* MAIN VIEW: Tab 1 = Chatbot, Tab 2 = AI Image Editor */}
      {activeTab === 'chat' ? (
        <>
          {/* Chat scrollable container */}
          <main
            ref={chatContainerRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 overscroll-contain"
          >
            <div className="max-w-4xl mx-auto h-full flex flex-col justify-between">
              {messages.length === 0 ? (
                <WelcomeHero
                  onSelectPrompt={handleSendMessage}
                  onOpenGuide={() => setIsGuideOpen(true)}
                />
              ) : (
                <div className="flex-1 pb-4">
                  {messages.map((msg) => (
                    <MessageItem
                      key={msg.id}
                      message={msg}
                      onRetry={handleRetry}
                    />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>
          </main>

          {/* Floating Scroll to Bottom Button */}
          {showScrollBottom && (
            <button
              onClick={() => scrollToBottom('smooth')}
              className="absolute bottom-24 right-4 sm:right-8 p-2.5 rounded-full bg-purple-700/80 hover:bg-purple-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.5)] border border-purple-400/40 backdrop-blur-sm transition-all hover:scale-110 active:scale-95 z-20"
              title="Tatal ke bawah"
              aria-label="Tatal ke bawah"
            >
              <ArrowDown className="w-4 h-4" />
            </button>
          )}

          {/* Bottom Composer Bar */}
          <ChatInput
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
          />
        </>
      ) : (
        /* Image Editor Tab */
        <ImageEditor onOpenSetupGuide={() => setIsImageSetupOpen(true)} />
      )}

      {/* Modals & Drawers */}
      <GuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
        onSelectPrompt={handleSendMessage}
      />

      <ClearConfirmModal
        isOpen={isClearModalOpen}
        onClose={() => setIsClearModalOpen(false)}
        onConfirm={handleClearChat}
      />

      <UtaraDictionaryDrawer
        isOpen={isDictionaryOpen}
        onClose={() => setIsDictionaryOpen(false)}
        onUseWord={handleSendMessage}
      />

      <ImageSetupModal
        isOpen={isImageSetupOpen}
        onClose={() => setIsImageSetupOpen(false)}
      />
    </div>
  );
}
