import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Mascot from './components/Mascot';
import Confetti from './components/Confetti';
import { buildSession, ZONE_META, TRY_AGAIN, shadowFor, type Question, type Zone } from './data/content';
import { sfx, speakUrdu, stopSpeak, startMusic, stopMusic } from './lib/sound';

type Screen = 'menu' | 'playing' | 'gameover';
interface ScoreEntry { zone: Zone; score: number; stars: number; date: string; firstTry: number; }

const GREETINGS = ['Assalam-o-Alaikum dost! 👋', 'Khelne aur seekhne ke liye tayyar ho? 🌈', 'Tum super star ho! ⭐', 'Chalo mil kar khelte hain! 🎈'];
const ROUNDS = 10;

function loadScores(): ScoreEntry[] {
  try { return JSON.parse(localStorage.getItem('nursery-highscores') || '[]'); } catch { return []; }
}
function saveScore(e: ScoreEntry) {
  const all = [...loadScores(), e].sort((a, b) => b.score - a.score).slice(0, 10);
  localStorage.setItem('nursery-highscores', JSON.stringify(all));
  return all;
}

function Background() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
      <div className="absolute inset-0 bg-gradient-to-b from-sky-300 via-sky-200 to-amber-100" />
      {/* sun */}
      <div className="absolute -top-10 -right-10 h-44 w-44 rounded-full bg-yellow-300 shadow-[0_0_60px_#fde047] anim-floaty" />
      <div className="absolute top-6 right-8 text-5xl anim-twinkle">☀️</div>
      {/* rainbow */}
      <svg className="absolute bottom-24 left-1/2 -translate-x-1/2 w-[720px] max-w-none opacity-70" viewBox="0 0 720 200" style={{ animation: 'rainbowPulse 4s ease-in-out infinite' }}>
        <path d="M60 200 A300 300 0 0 1 660 200" fill="none" stroke="#f43f5e" strokeWidth="18" />
        <path d="M82 200 A278 278 0 0 1 638 200" fill="none" stroke="#f59e0b" strokeWidth="18" />
        <path d="M104 200 A256 256 0 0 1 616 200" fill="none" stroke="#facc15" strokeWidth="18" />
        <path d="M126 200 A234 234 0 0 1 594 200" fill="none" stroke="#22c55e" strokeWidth="18" />
        <path d="M148 200 A212 212 0 0 1 572 200" fill="none" stroke="#3b82f6" strokeWidth="18" />
      </svg>
      {/* clouds */}
      {[ {top:'6%', dur:'55s', delay:'-10s', s:1}, {top:'14%', dur:'70s', delay:'-35s', s:.7}, {top:'3%', dur:'85s', delay:'-60s', s:1.2} ].map((c,i)=>(
        <div key={i} className="cloud" style={{ top:c.top, animationDuration:c.dur, animationDelay:c.delay, transform:`scale(${c.s})` }}>
          <div className="flex items-end"><div className="h-10 w-16 rounded-full bg-white" /><div className="h-14 w-20 -ml-6 rounded-full bg-white" /><div className="h-9 w-14 -ml-5 rounded-full bg-white" /></div>
        </div>
      ))}
      {/* hills */}
      <div className="absolute bottom-0 left-0 right-0 h-28">
        <div className="absolute bottom-0 left-[-10%] h-28 w-[70%] rounded-[100%] bg-green-400" />
        <div className="absolute bottom-0 right-[-10%] h-32 w-[70%] rounded-[100%] bg-emerald-400" />
        <div className="absolute bottom-0 left-[30%] h-20 w-[50%] rounded-[100%] bg-lime-300" />
      </div>
      <div className="absolute bottom-6 left-6 text-3xl anim-floaty">🌷</div>
      <div className="absolute bottom-10 right-10 text-3xl anim-floaty" style={{animationDelay:'.6s'}}>🌻</div>
      <div className="absolute bottom-4 left-1/2 text-2xl anim-floaty" style={{animationDelay:'1.1s'}}>🦋</div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [zone, setZone] = useState<Zone>('abc');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [wrongIds, setWrongIds] = useState<Set<string>>(new Set());
  const [feedback, setFeedback] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [message, setMessage] = useState(GREETINGS[0]);
  const [paused, setPaused] = useState(false);
  const [confettiKey, setConfettiKey] = useState(0);
  const [confettiContinuous, setConfettiContinuous] = useState(false);
  const [, setShakeKey] = useState(0);
  const [floatPts, setFloatPts] = useState<{ val: number; key: number } | null>(null);
  const [firstTryCount, setFirstTryCount] = useState(0);
  const [soundOn, setSoundOn] = useState(true);
  const [musicOn, setMusicOn] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [showScores, setShowScores] = useState(false);
  const [scores, setScores] = useState<ScoreEntry[]>(loadScores);
  const [focusIdx, setFocusIdx] = useState(0);
  const [greetIdx, setGreetIdx] = useState(0);
  const [isNewBest, setIsNewBest] = useState(false);
  const [showInstall, setShowInstall] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [installed, setInstalled] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const timerRef = useRef<number | null>(null);
  const soundRef = useRef(soundOn); soundRef.current = soundOn;
  const voiceRef = useRef(voiceOn); voiceRef.current = voiceOn;

  const q = questions[idx];
  const meta = ZONE_META[zone];
  const stars = firstTryCount >= 8 ? 3 : firstTryCount >= 5 ? 2 : 1;
  const best = useMemo(() => { const z = scores.filter(s => s.zone === zone); return z.length ? Math.max(...z.map(s => s.score)) : 0; }, [scores, zone]);

  useEffect(() => { const t = setInterval(() => setGreetIdx(i => (i + 1) % GREETINGS.length), 3500); return () => clearInterval(t); }, []);

  // PWA install prompt (Android Chrome)
  useEffect(() => {
    const h = (e: any) => { e.preventDefault(); setInstallPrompt(e); };
    const done = () => { setInstalled(true); setInstallPrompt(null); };
    window.addEventListener('beforeinstallprompt', h);
    window.addEventListener('appinstalled', done);
    if (window.matchMedia('(display-mode: standalone)').matches) setInstalled(true);
    return () => { window.removeEventListener('beforeinstallprompt', h); window.removeEventListener('appinstalled', done); };
  }, []);

  const installApp = async () => {
    if (installPrompt) { installPrompt.prompt(); const r = await installPrompt.userChoice; if (r?.outcome === 'accepted') setInstalled(true); setInstallPrompt(null); }
    else setShowInstall(true);
    sfx.click();
  };

  // Download the whole game as ONE .html file (NOT zip) — double-click to play offline
  const downloadGameFile = async () => {
    setDownloading(true); sfx.click();
    try {
      let html = '';
      try { const res = await fetch(window.location.href); html = await res.text(); } catch {}
      if (!html || html.length < 500) html = '<!doctype html>\n' + document.documentElement.outerHTML;
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'Fun-Learning-Zone-Bachon-Ka-Game.html';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      if (voiceRef.current) speakUrdu('Game download ho raha hai! File ko kholo aur khelo!');
    } catch { alert('Download nahi ho saka. Dobara try karo!'); }
    setDownloading(false);
  };

  useEffect(() => {
    if (musicOn) startMusic(); else stopMusic();
    return () => stopMusic();
  }, [musicOn]);

  const speakQuestion = useCallback((qq?: Question) => {
    const cur = qq || questions[idx];
    if (!cur || !voiceRef.current) return;
    speakUrdu(cur.speak);
  }, [questions, idx]);

  // speak + count pops when new question arrives
  useEffect(() => {
    if (screen !== 'playing' || !q || paused) return;
    setFocusIdx(0);
    const t = setTimeout(() => speakQuestion(q), 350);
    if (q.countItems && soundRef.current) {
      for (let i = 0; i < q.countItems.count; i++) setTimeout(() => sfx.countPop(i), 400 + i * 160);
    }
    return () => clearTimeout(t);
  }, [idx, screen, paused]); // eslint-disable-line

  const startGame = (z: Zone) => {
    if (soundRef.current) sfx.click();
    setZone(z);
    setQuestions(buildSession(z, ROUNDS));
    setIdx(0); setScore(0); setStreak(0); setBestStreak(0); setAttempts(0);
    setWrongIds(new Set()); setFeedback('idle'); setFirstTryCount(0); setPaused(false); setIsNewBest(false);
    setMessage('Chalo shuru karte hain! Sahi jawab ko chhuo! 🎯');
    setScreen('playing');
  };

  const goHome = () => { stopSpeak(); setScreen('menu'); setPaused(false); setFeedback('idle'); };

  const finishGame = useCallback((finalScore: number, ft: number) => {
    const st = ft >= 8 ? 3 : ft >= 5 ? 2 : 1;
    const prevBest = (() => { const z = loadScores().filter(s => s.zone === zone); return z.length ? Math.max(...z.map(s => s.score)) : 0; })();
    setIsNewBest(finalScore > prevBest && finalScore > 0);
    const updated = saveScore({ zone, score: finalScore, stars: st, date: new Date().toLocaleDateString(), firstTry: ft });
    setScores(updated);
    setScreen('gameover');
    setConfettiContinuous(true); setConfettiKey(k => k + 1);
    if (soundRef.current) { sfx.win(); setTimeout(() => sfx.star(), 600); }
    if (voiceRef.current) speakUrdu(finalScore > prevBest ? 'Wah! Naya best score! Kya baat hai!' : 'Bohat khub! Tum ne game poora kar liya! Shabash!');
  }, [zone]);

  const handlePick = useCallback((optId: string) => {
    if (screen !== 'playing' || paused || feedback === 'correct' || !q) return;
    const opt = q.options.find(o => o.id === optId);
    if (!opt || wrongIds.has(optId)) return;
    if (opt.isCorrect) {
      const firstTry = attempts === 0;
      const pts = 10 + (firstTry ? 5 : 0) + Math.min(streak, 5);
      const newScore = score + pts;
      const newStreak = streak + 1;
      const ft = firstTryCount + (firstTry ? 1 : 0);
      setScore(newScore); setStreak(newStreak); setBestStreak(b => Math.max(b, newStreak)); setFirstTryCount(ft);
      setFeedback('correct'); setMessage(q.praise);
      setFloatPts({ val: pts, key: Date.now() });
      setConfettiContinuous(false); setConfettiKey(k => k + 1);
      if (soundRef.current) { sfx.correct(); setTimeout(() => sfx.star(), 250); }
      if (voiceRef.current) speakUrdu(q.praise);
      timerRef.current = window.setTimeout(() => {
        if (idx + 1 >= questions.length) finishGame(newScore, ft);
        else { setIdx(idx + 1); setAttempts(0); setWrongIds(new Set()); setFeedback('idle'); setMessage('Wah! Agla sawal! 👀'); }
      }, 1500);
    } else {
      const msg = TRY_AGAIN[Math.floor(Math.random() * TRY_AGAIN.length)];
      setAttempts(a => a + 1); setStreak(0); setFeedback('wrong'); setMessage(msg);
      setWrongIds(s => new Set(s).add(optId)); setShakeKey(k => k + 1);
      if (soundRef.current) sfx.wrong();
      if (voiceRef.current) speakUrdu(msg);
      setTimeout(() => setFeedback('idle'), 700);
    }
  }, [screen, paused, feedback, q, wrongIds, attempts, streak, score, firstTryCount, idx, questions, finishGame]);

  // Keyboard controls
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key.toLowerCase() === 'p') {
        if (screen === 'playing') { setPaused(p => !p); if (soundRef.current) sfx.click(); }
        return;
      }
      if (screen === 'menu') {
        if (e.key === '1') startGame('abc'); if (e.key === '2') startGame('123'); if (e.key === '3') startGame('urdu');
        if (e.key === 'Enter' || e.key === ' ') startGame('abc');
        return;
      }
      if (screen === 'gameover') {
        if (e.key === 'Enter' || e.key === ' ') startGame(zone);
        if (e.key === 'Escape') goHome();
        return;
      }
      if (paused) { if (e.key === 'Enter') setPaused(false); return; }
      if (['1', '2', '3'].includes(e.key)) { const i = Number(e.key) - 1; if (q?.options[i]) handlePick(q.options[i].id); }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') setFocusIdx(f => Math.min(2, f + 1));
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') setFocusIdx(f => Math.max(0, f - 1));
      else if (e.key === 'Enter' && q?.options[focusIdx]) handlePick(q.options[focusIdx].id);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [screen, paused, q, focusIdx, handlePick, zone]);

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current); stopSpeak(); }, []);

  const toggleSound = () => { const v = !soundOn; setSoundOn(v); if (v) sfx.pop(); else stopSpeak(); };
  const toggleMusic = () => { setMusicOn(m => !m); if (soundRef.current) sfx.click(); };
  const toggleVoice = () => { const v = !voiceOn; setVoiceOn(v); if (!v) stopSpeak(); else if (q) setTimeout(() => speakQuestion(q), 100); };

  return (
    <div className="relative min-h-dvh overflow-hidden font-[Fredoka]">
      <Background />
      <Confetti burstKey={confettiKey} continuous={confettiContinuous} />

      {/* Top controls */}
      <header className="relative z-20 mx-auto flex max-w-3xl items-center justify-between gap-2 px-3 pt-3">
        <button onClick={goHome} className="btn-chunky bg-white px-4 py-2 text-lg text-slate-700" aria-label="Home">🏠 Home</button>
        <div className="flex items-center gap-2">
          <button onClick={toggleSound} className={`btn-chunky px-3 py-2 text-lg ${soundOn ? 'bg-amber-300' : 'bg-white/70'}`} aria-label="Sound">{soundOn ? '🔊' : '🔇'}</button>
          <button onClick={toggleMusic} className={`btn-chunky px-3 py-2 text-lg ${musicOn ? 'bg-pink-300' : 'bg-white/70'}`} aria-label="Music">🎵</button>
          <button onClick={toggleVoice} className={`btn-chunky px-3 py-2 text-lg ${voiceOn ? 'bg-emerald-300' : 'bg-white/70'}`} aria-label="Urdu Voice" title="Urdu Voice">🗣️ اردو</button>
          {screen === 'playing' && <button onClick={() => { setPaused(true); sfx.click(); }} className="btn-chunky bg-white px-4 py-2 text-lg" aria-label="Pause">⏸️ Pause</button>}
        </div>
      </header>

      <main className="relative z-10 mx-auto flex min-h-[calc(100dvh-64px)] w-full max-w-3xl flex-col items-center px-3 pb-8">
        {screen === 'menu' && (
          <div className="flex w-full flex-col items-center anim-slide-up">
            <div className="mt-1 flex items-end gap-2">
              <Mascot size={140} mood="happy" />
              <div className="relative mb-6 max-w-[220px] rounded-3xl rounded-bl-none bg-white px-4 py-3 text-center text-lg font-bold text-slate-700 shadow-lg">
                {GREETINGS[greetIdx]}<span className="block text-sm font-semibold text-slate-500">Main Hooty Ullu hoon! 🦉</span>
              </div>
            </div>
            <h1 className="text-center text-5xl font-bold leading-tight text-white drop-shadow-[0_4px_0_rgba(0,0,0,.15)] sm:text-6xl">
              <span className="text-rose-500">Fun</span> <span className="text-amber-500">Learning</span> <span className="text-sky-600">Zone</span>
            </h1>
            <p className="mt-1 text-center text-lg font-semibold text-slate-600">ABC • 123 • اردو — Play, Tap & Learn! 🎈</p>

            <div className="mt-6 grid w-full gap-4 sm:grid-cols-3">
              {(Object.keys(ZONE_META) as Zone[]).map((z, i) => {
                const m = ZONE_META[z];
                const zb = scores.filter(s => s.zone === z);
                const zbBest = zb.length ? Math.max(...zb.map(s => s.score)) : 0;
                return (
                  <button key={z} onClick={() => startGame(z)} className={`btn-chunky group bg-gradient-to-b ${m.gradient} ${m.shadow} p-5 text-white active:translate-y-1`}
                    style={{ animation: `popIn .5s ${i * 0.12}s cubic-bezier(.34,1.56,.64,1) both` }}>
                    <div className="text-6xl transition-transform group-hover:scale-110 group-hover:-rotate-6">{m.emoji}</div>
                    <div className="mt-2 text-3xl font-bold">{m.name}</div>
                    <div className={`text-xl font-bold ${z === 'urdu' ? 'font-urdu' : ''}`}>{m.urdu}</div>
                    <div className="mt-1 text-sm font-semibold opacity-90">{m.desc}</div>
                    {zbBest > 0 && <div className="mt-2 inline-block rounded-full bg-white/25 px-3 py-0.5 text-sm font-bold">🏆 Best: {zbBest}</div>}
                    <div className="mt-2 text-xs font-bold opacity-80">Press {i + 1} ⌨️</div>
                  </button>
                );
              })}
            </div>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button onClick={() => { setShowScores(s => !s); sfx.click(); }} className="btn-chunky bg-white px-5 py-3 text-lg text-slate-700">🏆 High Scores</button>
              <button onClick={() => startGame('abc')} className="btn-chunky bg-gradient-to-b from-amber-300 to-orange-400 px-6 py-3 text-xl text-white shadow-[0_7px_0_#c2410c]">▶️ Khelo! Start</button>
            </div>

            {/* 📲 App Download / Install — NOT zip, direct app + single HTML file */}
            <div className="mt-5 w-full max-w-lg rounded-[2rem] bg-white/95 p-5 text-center shadow-2xl">
              <h2 className="text-2xl font-bold text-slate-800">📲 App Download Karo <span className="text-base text-slate-400">(ZIP nahi!)</span></h2>
              <p className="mt-1 font-semibold text-slate-500">Phone mein app ki tarah install karo — offline bhi chalega! 🗣️ Urdu voice on hai</p>
              <div className="mt-4 flex flex-col gap-3 sm:flex-row">
                <button onClick={installApp} className="btn-chunky flex-1 bg-gradient-to-b from-sky-400 to-blue-500 px-4 py-3 text-lg text-white shadow-[0_7px_0_#0369a1]">
                  {installed ? '✅ App Install Ho Gaya!' : '📲 Install App (Phone)'}
                </button>
                <button onClick={downloadGameFile} disabled={downloading} className="btn-chunky flex-1 bg-gradient-to-b from-emerald-400 to-green-500 px-4 py-3 text-lg text-white shadow-[0_7px_0_#047857] disabled:opacity-60">
                  {downloading ? '⏳ Download ho raha hai...' : '💾 Game File (.html)'}
                </button>
              </div>
              {showInstall && !installed && (
                <div className="anim-pop mt-4 rounded-2xl bg-sky-50 p-4 text-left text-sm font-semibold text-slate-600">
                  <p><b>🤖 Android:</b> Chrome menu (⋮) → <b>“Add to Home screen”</b> ya <b>“Install app”</b> dabao.</p>
                  <p className="mt-1"><b>🍎 iPhone:</b> Share (⬆️) → <b>“Add to Home Screen”</b> dabao.</p>
                  <p className="mt-1">Phir home screen par <b>Learning Zone</b> app icon ban jayega! 🎉</p>
                </div>
              )}
              <p className="mt-3 text-xs font-semibold text-slate-400">💾 Game File = 1 HTML file download hogi. Us file par double-click karo, game khul jayega — internet ki zaroorat nahi!</p>
            </div>
            <p className="mt-4 text-center text-sm font-semibold text-slate-500">Jawab ko chhuo • Keys 1-2-3 • P = Pause • 🗣️ Urdu voice har sawal Urdu mein bolegi</p>

            {showScores && (
              <div className="anim-pop mt-4 w-full max-w-md rounded-3xl bg-white/95 p-5 shadow-xl">
                <h2 className="text-center text-2xl font-bold text-slate-800">🏆 High Scores</h2>
                {scores.length === 0 ? <p className="mt-2 text-center font-semibold text-slate-500">No scores yet — be the first superstar! ⭐</p> : (
                  <table className="mt-3 w-full text-left text-base font-semibold text-slate-700">
                    <thead><tr className="text-slate-400 text-sm"><th className="py-1">Zone</th><th>Score</th><th>Stars</th><th>Date</th></tr></thead>
                    <tbody>{scores.slice(0, 5).map((s, i) => (
                      <tr key={i} className="border-t border-slate-100"><td className="py-2">{ZONE_META[s.zone].emoji} {ZONE_META[s.zone].name}</td><td className="font-bold">{s.score}</td><td>{'⭐'.repeat(s.stars)}</td><td className="text-sm text-slate-400">{s.date}</td></tr>
                    ))}</tbody>
                  </table>
                )}
              </div>
            )}
          </div>
        )}

        {screen === 'playing' && q && (
          <div className="flex w-full flex-col items-center">
            {/* HUD */}
            <div className="mt-2 flex w-full flex-wrap items-center justify-between gap-2">
              <div className={`rounded-full bg-gradient-to-r ${meta.gradient} px-4 py-1.5 font-bold text-white shadow`}>{meta.emoji} {meta.name}</div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-white px-4 py-1.5 font-bold text-slate-700 shadow">⭐ Score: {score}</div>
                {streak >= 2 && <div className="rounded-full bg-orange-100 px-3 py-1.5 font-bold text-orange-600 shadow anim-pop">🔥 x{streak}</div>}
                <div className="rounded-full bg-white px-3 py-1.5 font-bold text-slate-500 shadow">Best {best}</div>
              </div>
            </div>
            {/* progress */}
            <div className="mt-3 w-full">
              <div className="flex justify-between gap-1">
                {questions.map((_, i) => (
                  <div key={i} className={`h-3.5 flex-1 rounded-full transition-all duration-500 ${i < idx ? 'bg-emerald-400' : i === idx ? 'bg-amber-400 scale-y-125' : 'bg-white/60'}`} />
                ))}
              </div>
              <p className="mt-1 text-center text-sm font-bold text-slate-500">Question {idx + 1} of {questions.length}</p>
            </div>

            {/* Question card */}
            <div key={q.id} className={`anim-pop relative mt-2 w-full rounded-[2rem] bg-white/95 p-5 text-center shadow-2xl ${feedback === 'wrong' ? 'anim-shake' : ''} ${feedback === 'correct' ? 'ring-4 ring-emerald-300' : ''}`}>
              {floatPts && feedback === 'correct' && <div key={floatPts.key} className="absolute -top-2 right-6 rounded-full bg-emerald-400 px-4 py-1 text-xl font-bold text-white shadow anim-floaty">+{floatPts.val} ⭐</div>}
              <h2 className={`text-4xl font-bold text-slate-800 sm:text-5xl ${zone === 'urdu' ? 'font-urdu' : ''}`}>{q.title}</h2>
              <p className={`mt-1 text-lg font-semibold text-slate-500 ${zone === 'urdu' ? 'font-urdu' : ''}`}>{q.subtitle}</p>

              {/* Visual prompt */}
              <div className="mt-4 flex min-h-[150px] items-center justify-center">
                {q.bigLetter && (
                  <div className={`flex h-36 w-36 items-center justify-center rounded-full bg-gradient-to-b ${meta.gradient} text-8xl font-bold text-white shadow-[0_8px_0_rgba(0,0,0,.15)] anim-bounce-soft ${zone === 'urdu' ? 'font-urdu' : ''}`}>{q.bigLetter}</div>
                )}
                {q.bigEmoji && (
                  <div className="text-center">
                    <div className="text-[110px] leading-none anim-bounce-soft">{q.bigEmoji}</div>
                    <div className="mt-1 text-3xl font-bold text-slate-700">{q.bigWord}</div>
                  </div>
                )}
                {q.countItems && (
                  <div className="max-w-sm">
                    <div className="flex flex-wrap justify-center gap-1">
                      {Array.from({ length: q.countItems.count }).map((_, i) => (
                        <span key={i} className="anim-item-pop text-5xl sm:text-6xl" style={{ animationDelay: `${i * 0.16}s` }}>{q.countItems!.emoji}</span>
                      ))}
                    </div>
                    <p className="mt-2 text-xl font-bold text-slate-500">Ginn kar batao! 👀</p>
                  </div>
                )}
                {!q.bigLetter && !q.bigEmoji && !q.countItems && <div className="text-8xl anim-bounce-soft">🔢</div>}
              </div>

              <button onClick={() => speakQuestion(q)} className="btn-chunky mt-2 bg-sky-100 px-4 py-2 font-bold text-sky-700">🔊 Phir Suno (Urdu)</button>
            </div>

            {/* Mascot + message */}
            <div className="mt-3 flex w-full items-center gap-3">
              <Mascot size={84} mood={feedback === 'correct' ? 'cheer' : feedback === 'wrong' ? 'think' : 'happy'} cheer={feedback === 'correct'} />
              <div className={`flex-1 rounded-3xl rounded-bl-none px-4 py-3 text-lg font-bold shadow ${feedback === 'correct' ? 'bg-emerald-100 text-emerald-700' : feedback === 'wrong' ? 'bg-amber-100 text-amber-700' : 'bg-white text-slate-700'}`}>
                {message}
              </div>
            </div>

            {/* Options */}
            <div className="mt-4 grid w-full gap-3 sm:grid-cols-3">
              {q.options.map((opt, i) => {
                const isWrong = wrongIds.has(opt.id);
                const isCorrectShown = feedback === 'correct' && opt.isCorrect;
                const isFocused = focusIdx === i;
                return (
                  <button key={opt.id} onClick={() => handlePick(opt.id)} disabled={isWrong || feedback === 'correct'}
                    className={`btn-chunky relative flex min-h-[110px] flex-col items-center justify-center gap-1 p-4 text-white ${isCorrectShown ? 'bg-emerald-400 shadow-[0_7px_0_#047857] scale-105' : isWrong ? 'bg-slate-300 opacity-50 shadow-[0_7px_0_#64748b]' : `${opt.color} ${shadowFor(opt.color)}`} ${isFocused ? 'ring-4 ring-white ring-offset-2 ring-offset-sky-200' : ''} ${feedback === 'wrong' && isWrong ? 'anim-wiggle' : ''}`}
                    aria-label={`Option ${i + 1}: ${opt.primary}`}>
                    <span className="absolute left-3 top-2 rounded-full bg-white/30 px-2 py-0.5 text-xs font-bold">{i + 1}</span>
                    {isCorrectShown && <span className="absolute right-3 top-2 text-2xl">✅</span>}
                    {isWrong && <span className="absolute right-3 top-2 text-2xl">💪</span>}
                    {opt.emoji && <span className="text-6xl leading-none">{opt.emoji}</span>}
                    <span className={`text-3xl font-bold leading-tight ${zone === 'urdu' ? 'font-urdu' : ''}`}>{opt.primary}</span>
                    {opt.secondary && <span className="text-sm font-semibold opacity-90">{opt.secondary}</span>}
                  </button>
                );
              })}
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-500">Tap an answer or press 1 • 2 • 3</p>
          </div>
        )}

        {screen === 'gameover' && (
          <div className="anim-pop flex w-full flex-col items-center rounded-[2rem] bg-white/95 p-6 text-center shadow-2xl sm:p-8">
            <Mascot size={150} mood="cheer" cheer />
            <h2 className="mt-2 text-5xl font-bold text-slate-800">🎉 Shabash! Bohat Khub!</h2>
            <p className="mt-1 text-xl font-semibold text-slate-500">You finished {meta.name}!</p>
            <div className="mt-3 flex gap-2 text-6xl">
              {[1, 2, 3].map(i => <span key={i} className={i <= stars ? 'anim-bounce-soft' : 'opacity-25 grayscale'} style={{ animationDelay: `${i * 0.2}s` }}>⭐</span>)}
            </div>
            <div className="mt-4 grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-amber-50 p-3"><div className="text-3xl font-bold text-amber-600">{score}</div><div className="text-sm font-bold text-slate-500">Score</div></div>
              <div className="rounded-2xl bg-sky-50 p-3"><div className="text-3xl font-bold text-sky-600">{firstTryCount}/{ROUNDS}</div><div className="text-sm font-bold text-slate-500">First Try</div></div>
              <div className="rounded-2xl bg-orange-50 p-3"><div className="text-3xl font-bold text-orange-600">🔥{bestStreak}</div><div className="text-sm font-bold text-slate-500">Best Streak</div></div>
            </div>
            {isNewBest && <div className="anim-pop mt-3 rounded-full bg-gradient-to-r from-amber-300 to-orange-400 px-5 py-2 text-lg font-bold text-white shadow">🏆 NEW BEST SCORE!</div>}
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <button onClick={() => startGame(zone)} className="btn-chunky bg-gradient-to-b from-emerald-400 to-green-500 px-6 py-3 text-xl text-white shadow-[0_7px_0_#047857]">🔁 Phir Khelo</button>
              <button onClick={goHome} className="btn-chunky bg-white px-6 py-3 text-xl text-slate-700">🏠 Home</button>
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-400">Press Enter to play again • Esc for home</p>
            {scores.length > 0 && (
              <div className="mt-4 w-full max-w-md rounded-2xl bg-slate-50 p-4 text-left">
                <h3 className="text-center font-bold text-slate-700">🏆 Top Scores</h3>
                {scores.slice(0, 3).map((s, i) => <div key={i} className="flex justify-between border-t border-slate-200 py-1.5 font-semibold text-slate-600"><span>{i + 1}. {ZONE_META[s.zone].emoji} {ZONE_META[s.zone].name}</span><span>{s.score} ⭐</span></div>)}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Pause overlay */}
      {paused && screen === 'playing' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-sm" role="dialog" aria-modal>
          <div className="anim-pop w-full max-w-sm rounded-[2rem] bg-white p-6 text-center shadow-2xl">
            <div className="text-7xl">⏸️</div>
            <h2 className="mt-2 text-4xl font-bold text-slate-800">Ruko! Paused</h2>
            <p className="font-semibold text-slate-500">Take a little break! 🌈</p>
            <div className="mt-5 flex flex-col gap-3">
              <button onClick={() => { setPaused(false); sfx.click(); }} className="btn-chunky bg-gradient-to-b from-emerald-400 to-green-500 py-3 text-xl text-white shadow-[0_7px_0_#047857]">▶️ Khelo Phir Se</button>
              <button onClick={() => startGame(zone)} className="btn-chunky bg-amber-300 py-3 text-xl text-white shadow-[0_7px_0_#b45309]">🔁 Restart</button>
              <button onClick={goHome} className="btn-chunky bg-slate-100 py-3 text-xl text-slate-700">🏠 Home</button>
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-400">Press P or Esc to resume</p>
          </div>
        </div>
      )}
    </div>
  );
}
