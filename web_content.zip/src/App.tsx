import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { loadDb, TIER_STYLE, toArabicDigits, type Db } from "./lib/data";
import { StoreProvider, useStore } from "./lib/store";
import { HadithCard } from "./components/HadithCard";
import { ResultsList } from "./components/ResultsList";
import { BackIcon, GridIcon, HeartIcon, HomeIcon, InfoIcon, MoonIcon, SearchIcon, SunIcon } from "./components/Icons";

type Tab = "home" | "search" | "topics" | "favs" | "about";
type Sub = { kind: "topic"; code: string } | { kind: "imam"; code: string } | null;

const TABS: { id: Tab; label: string; icon: ReactNode }[] = [
  { id: "home", label: "الرئيسية", icon: <HomeIcon /> },
  { id: "search", label: "البحث", icon: <SearchIcon /> },
  { id: "topics", label: "الاختيارات", icon: <GridIcon /> },
  { id: "favs", label: "المفضلة", icon: <HeartIcon /> },
  { id: "about", label: "حول", icon: <InfoIcon /> },
];

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}

function Shell() {
  const [db, setDb] = useState<Db | null>(null);
  const [error, setError] = useState(false);
  const [tab, setTab] = useState<Tab>("home");
  const [sub, setSub] = useState<Sub>(null);

  useEffect(() => {
    loadDb().then(setDb).catch(() => setError(true));
  }, []);

  // زر الرجوع (يعمل مع زر الرجوع في أندرويد)
  useEffect(() => {
    const onPop = () => setSub(null);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const openSub = useCallback((s: Sub) => {
    history.pushState({ sub: true }, "");
    setSub(s);
    window.scrollTo({ top: 0 });
  }, []);
  const closeSub = useCallback(() => {
    if (history.state?.sub) history.back();
    else setSub(null);
  }, []);
  const go = (t: Tab) => {
    if (sub) setSub(null);
    setTab(t);
    window.scrollTo({ top: 0 });
  };

  if (error)
    return (
      <div className="flex min-h-screen items-center justify-center p-8 text-center">
        تعذّر تحميل قاعدة الأحاديث. أعد تشغيل التطبيق.
      </div>
    );
  if (!db) return <Splash />;

  const openTopic = (code: string) => openSub({ kind: "topic", code });
  const openImam = (code: string) => openSub({ kind: "imam", code });

  let content: ReactNode;
  if (sub?.kind === "topic") {
    const info = db.topicInfo[sub.code];
    content = (
      <SubPage title={`${info?.icon ?? ""} ${info?.name ?? ""}`} count={db.topicCounts[sub.code]} onBack={closeSub}>
        <ResultsList
          key={"t" + sub.code}
          db={db}
          topic={sub.code}
          placeholder={`ابحث داخل «${info?.name}»…`}
          onImam={openImam}
          onTopic={openTopic}
        />
      </SubPage>
    );
  } else if (sub?.kind === "imam") {
    content = (
      <SubPage title={db.imamName[sub.code]} count={db.imamCounts[sub.code]} onBack={closeSub}>
        <ResultsList
          key={"i" + sub.code}
          db={db}
          imam={sub.code}
          browse
          placeholder="ابحث في أحاديثه…"
          onTopic={openTopic}
        />
      </SubPage>
    );
  } else if (tab === "home") {
    content = <Home db={db} onSearch={() => go("search")} onTopics={() => go("topics")} onImam={openImam} onTopic={openTopic} />;
  } else if (tab === "search") {
    content = (
      <Page title="البحث في الأحاديث">
        <ResultsList db={db} onTopic={openTopic} onImam={openImam} />
      </Page>
    );
  } else if (tab === "topics") {
    content = <Topics db={db} onOpen={openTopic} />;
  } else if (tab === "favs") {
    content = <Favs db={db} onTopic={openTopic} onImam={openImam} />;
  } else {
    content = <About db={db} />;
  }

  return (
    <div className="mx-auto min-h-screen max-w-3xl" dir="rtl">
      <main className="px-4 pb-28">{content}</main>
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-stone-200 bg-white/95 backdrop-blur dark:border-stone-800 dark:bg-stone-950/95">
        <div className="mx-auto flex max-w-3xl">
          {TABS.map((t) => {
            const active = !sub && tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => go(t.id)}
                className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold transition ${
                  active ? "text-emerald-800 dark:text-emerald-400" : "text-stone-500 dark:text-stone-400"
                }`}
              >
                <span className={`rounded-full px-4 py-1 transition ${active ? "bg-emerald-100 dark:bg-emerald-900/50" : ""}`}>
                  {t.icon}
                </span>
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function Splash() {
  return (
    <div className="islamic-pattern flex min-h-screen flex-col items-center justify-center gap-5 text-white">
      <div className="flex h-24 w-24 items-center justify-center rounded-3xl bg-white/10 text-5xl ring-2 ring-amber-300/60">📖</div>
      <h1 className="text-4xl font-extrabold tracking-wider">ABK</h1>
      <p className="text-sm text-emerald-100">أحاديث النبي وأهل البيت (ع)</p>
      <div className="h-1.5 w-40 overflow-hidden rounded-full bg-white/20">
        <div className="h-full w-1/2 animate-pulse rounded-full bg-amber-300" />
      </div>
      <p className="text-xs text-emerald-200/80">جارٍ تجهيز قاعدة الأحاديث…</p>
    </div>
  );
}

function Page({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <div>
      <div className="safe-top -mx-4 flex items-center justify-between bg-emerald-800 px-4 pb-3 pt-4 text-white dark:bg-emerald-950">
        <h1 className="text-lg font-extrabold">{title}</h1>
        {right}
      </div>
      <div className="pt-0">{children}</div>
    </div>
  );
}

function SubPage({ title, count, onBack, children }: { title: string; count?: number; onBack: () => void; children: ReactNode }) {
  return (
    <div>
      <div className="safe-top -mx-4 flex items-center gap-2 bg-emerald-800 px-3 pb-3 pt-4 text-white dark:bg-emerald-950">
        <button onClick={onBack} aria-label="رجوع" className="rounded-full p-2 active:bg-white/20">
          <BackIcon />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-extrabold">{title}</h1>
          {count !== undefined && <p className="text-xs text-emerald-100">{toArabicDigits(count.toLocaleString("en"))} حديث</p>}
        </div>
      </div>
      {children}
    </div>
  );
}

function ThemeToggle() {
  const { dark, setDark } = useStore();
  return (
    <button onClick={() => setDark(!dark)} aria-label="الوضع الليلي" className="rounded-full p-2 active:bg-white/20">
      {dark ? <SunIcon /> : <MoonIcon />}
    </button>
  );
}

/* ---------------------------- الرئيسية ---------------------------- */

function Home({
  db,
  onSearch,
  onTopics,
  onImam,
  onTopic,
}: {
  db: Db;
  onSearch: () => void;
  onTopics: () => void;
  onImam: (c: string) => void;
  onTopic: (c: string) => void;
}) {
  const daily = useMemo(() => {
    const pool = db.items.filter((h) => h.g <= 2 && h.s > 0 && h.t.length - h.s > 90 && h.t.length - h.s < 420);
    const day = Math.floor(Date.now() / 86400000);
    return pool[(day * 7919) % pool.length];
  }, [db]);

  const imams = db.meta.imams.filter(([c]) => c !== "abulhasan" && (db.imamCounts[c] || 0) > 0);
  const total = db.items.length;
  const sanad = db.tierCounts[1] + db.tierCounts[2] + db.tierCounts[3] + db.tierCounts[4];

  return (
    <div>
      <section className="islamic-pattern safe-top -mx-4 rounded-b-[2rem] px-5 pb-8 pt-8 text-white shadow-lg">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-amber-200">بسم الله الرحمن الرحيم</p>
            <h1 className="mt-1 text-4xl font-extrabold tracking-wider">ABK</h1>
            <p className="mt-1 text-sm leading-7 text-emerald-50">أحاديث النبي محمد ﷺ وأهل بيته الأطهار (ع)<br />إلى الإمام المهدي (عج)</p>
          </div>
          <ThemeToggle />
        </div>

        <div className="mt-5 grid grid-cols-3 gap-2 text-center">
          <Stat n={toArabicDigits(total.toLocaleString("en"))} l="حديث" />
          <Stat n={toArabicDigits(sanad.toLocaleString("en"))} l="مسنَد معتبر" />
          <Stat n="٠" l="إنترنت مطلوب" />
        </div>

        <button
          onClick={onSearch}
          className="mt-5 flex w-full items-center gap-3 rounded-2xl bg-white px-4 py-3.5 text-right text-stone-500 shadow-md active:scale-[.99]"
        >
          <SearchIcon size={20} />
          <span className="text-sm">ابحث في الأحاديث…</span>
        </button>
      </section>

      <section className="mt-5">
        <h2 className="mb-2 flex items-center gap-2 text-base font-extrabold text-emerald-900 dark:text-emerald-300">
          <span>🌟</span> حديث اليوم
        </h2>
        {daily && <HadithCard db={db} h={daily} onTopic={onTopic} onImam={onImam} />}
      </section>

      <section className="mt-6">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-base font-extrabold text-emerald-900 dark:text-emerald-300">تصفّح بحسب المعصوم (ع)</h2>
        </div>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
          {imams.map(([c, n]) => (
            <button
              key={c}
              onClick={() => onImam(c)}
              className="rounded-2xl border border-stone-200 bg-white p-3 text-right shadow-sm active:scale-[.98] dark:border-stone-700 dark:bg-stone-900"
            >
              <div className="text-sm font-bold leading-6 text-stone-800 dark:text-stone-100">{n}</div>
              <div className="mt-0.5 text-xs text-stone-500">{toArabicDigits(db.imamCounts[c].toLocaleString("en"))} حديث</div>
            </button>
          ))}
        </div>
      </section>

      <button
        onClick={onTopics}
        className="mt-6 flex w-full items-center justify-between rounded-2xl bg-amber-100 px-5 py-4 text-right text-amber-900 shadow-sm active:scale-[.99] dark:bg-amber-900/30 dark:text-amber-100"
      >
        <span>
          <span className="block text-base font-extrabold">📚 الاختيارات</span>
          <span className="text-xs">الطعام والشراب، الصلاة، الصيام، الحج، الزواج، الأخلاق وغيرها…</span>
        </span>
        <span className="rotate-180"><BackIcon /></span>
      </button>
    </div>
  );
}

function Stat({ n, l }: { n: string; l: string }) {
  return (
    <div className="rounded-2xl bg-white/12 px-2 py-2.5 ring-1 ring-white/20">
      <div className="text-xl font-extrabold text-amber-200">{n}</div>
      <div className="text-[11px] text-emerald-50">{l}</div>
    </div>
  );
}

/* ---------------------------- الاختيارات ---------------------------- */

function Topics({ db, onOpen }: { db: Db; onOpen: (c: string) => void }) {
  const list = db.meta.topics
    .filter(([c]) => c !== "misc" && db.topicCounts[c])
    .sort((a, b) => (db.topicCounts[b[0]] || 0) - (db.topicCounts[a[0]] || 0));
  const misc = db.meta.topics.find(([c]) => c === "misc");
  return (
    <Page title="الاختيارات">
      <p className="px-1 pb-3 pt-3 text-sm leading-7 text-stone-600 dark:text-stone-300">
        اختر فئة لعرض كل الأحاديث الواردة فيها — مثلاً «الطعام والشراب» أو «الصلاة».
      </p>
      <div className="grid grid-cols-2 gap-3">
        {[...list, ...(misc && db.topicCounts.misc ? [misc] : [])].map(([c, name, icon]) => (
          <button
            key={c}
            onClick={() => onOpen(c)}
            className="group flex flex-col items-start gap-2 rounded-2xl border border-stone-200 bg-white p-4 text-right shadow-sm transition active:scale-[.97] dark:border-stone-700 dark:bg-stone-900"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-2xl dark:bg-emerald-900/40">{icon}</span>
            <span className="text-sm font-extrabold leading-6 text-stone-800 dark:text-stone-100">{name}</span>
            <span className="text-xs text-stone-500">{toArabicDigits((db.topicCounts[c] || 0).toLocaleString("en"))} حديث</span>
          </button>
        ))}
      </div>
    </Page>
  );
}

/* ---------------------------- المفضلة ---------------------------- */

function Favs({ db, onTopic, onImam }: { db: Db; onTopic: (c: string) => void; onImam: (c: string) => void }) {
  const { favs } = useStore();
  const map = useMemo(() => {
    const m = new Map<string, number>();
    db.items.forEach((h) => m.set(`${h.b}:${h.n}`, h.id));
    return m;
  }, [db]);
  const items = favs.map((k) => map.get(k)).filter((x): x is number => x !== undefined).map((i) => db.items[i]);
  return (
    <Page title="المفضلة">
      <div className="space-y-3 pt-3">
        {items.length === 0 ? (
          <div className="px-6 py-16 text-center text-stone-500">
            <div className="mb-3 text-5xl">🤍</div>
            <p className="text-sm leading-7">لم تضف أي حديث بعد.<br />اضغط على القلب أسفل أي حديث ليُحفظ هنا للرجوع إليه بدون إنترنت.</p>
          </div>
        ) : (
          items.map((h) => <HadithCard key={h.id} db={db} h={h} onTopic={onTopic} onImam={onImam} />)
        )}
      </div>
    </Page>
  );
}

/* ---------------------------- حول ---------------------------- */

function About({ db }: { db: Db }) {
  const { fontSize, setFontSize, dark, setDark, showSanad, setShowSanad } = useStore();
  const isApp = typeof location !== "undefined" && (location.hostname === "localhost" || location.protocol === "file:");
  const perBook = useMemo(() => {
    const m = new Map<string, number>();
    db.items.forEach((h) => {
      const n = db.meta.books[h.b][0];
      m.set(n, (m.get(n) || 0) + 1);
    });
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [db]);

  return (
    <Page title="حول التطبيق والإعدادات">
      <div className="space-y-4 pt-4">
        <Card title="⚙️ الإعدادات">
          <div className="space-y-4">
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <span>حجم خط الحديث</span>
                <span className="text-stone-500">{toArabicDigits(fontSize)}</span>
              </div>
              <input
                type="range"
                min={16}
                max={34}
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="w-full accent-emerald-700"
              />
              <p className="font-hadith mt-1 text-stone-700 dark:text-stone-200" style={{ fontSize }}>
                قَالَ رَسُولُ اللَّهِ ﷺ: «إِنَّمَا بُعِثْتُ لِأُتَمِّمَ مَكَارِمَ الْأَخْلَاقِ»
              </p>
            </div>
            <Toggle label="الوضع الليلي" value={dark} onChange={setDark} />
            <Toggle label="إظهار السند دائماً" value={showSanad} onChange={setShowSanad} />
          </div>
        </Card>

        <Card title="📖 عن ABK">
          <p className="text-sm leading-8 text-stone-700 dark:text-stone-300">
            تطبيق يعمل <b>بالكامل بدون إنترنت</b>، يضم {toArabicDigits(db.items.length.toLocaleString("en"))} نصاً مأثوراً عن النبي محمد ﷺ والأئمة الأطهار (ع) حتى الإمام المهدي (عج)،
            مقسّم إلى قسم <b>البحث</b> وقسم <b>الاختيارات</b> (فئات موضوعية) مع المفضلة والوضع الليلي.
          </p>
        </Card>

        <Card title="✅ منهج اختيار الأحاديث">
          <ul className="list-disc space-y-2 pr-5 text-sm leading-7 text-stone-700 dark:text-stone-300">
            <li>
              لم يُدرَج حديث إلا إذا حكم عليه أحد العلماء بالصحة أو الحسن أو التوثيق أو الاعتبار: العلامة المجلسي (مرآة العقول)،
              الشيخ البهبودي (صحيح الكافي/الفقيه/التهذيب)، الشيخ علي أكبر الغفاري، الشيخ آصف المحسني (معجم الأحاديث المعتبرة)، والشيخ هادي النجفي.
            </li>
            <li>أُزيلت المكررات (الحديث الواحد المذكور في أكثر من كتاب يظهر مرة واحدة).</li>
            <li>
              قسم «مأثور» ({toArabicDigits(db.tierCounts[5].toLocaleString("en"))}) هو من <b>نهج البلاغة</b> وتوقيعات الإمام المهدي (عج) ولا يخضع للتصنيف السندي المعتاد؛
              ويمكنك استبعاده بمرشح «✔ المسنَدة المعتبرة».
            </li>
            <li>
              نسبة الحديث إلى المعصوم وتصنيفه الموضوعي استُخلصا آلياً من النص وعناوين الأبواب، وقد يقع فيهما خطأ؛ فيُرجع إلى المصدر الأصلي
              (مذكور في أسفل كل حديث) قبل الاحتجاج. عبارة «أبو الحسن» وحدها محتملة بين الكاظم والرضا والهادي (ع) وتُعرض كما وردت.
            </li>
          </ul>
        </Card>

        <Card title="🎖️ درجات الحديث">
          <div className="space-y-2">
            {[1, 2, 3, 4, 5].map((t) => (
              <div key={t} className="flex items-start gap-3 text-sm">
                <span className={`mt-0.5 shrink-0 rounded-full px-2.5 py-0.5 text-xs font-bold ring-1 ${TIER_STYLE[t].cls}`}>{TIER_STYLE[t].label}</span>
                <span className="leading-7 text-stone-700 dark:text-stone-300">
                  {TIER_STYLE[t].desc} <span className="text-stone-400">({toArabicDigits(db.tierCounts[t].toLocaleString("en"))})</span>
                </span>
              </div>
            ))}
          </div>
        </Card>

        <Card title="📚 المصادر">
          <div className="grid grid-cols-1 gap-1.5 text-sm">
            {perBook.map(([n, c]) => (
              <div key={n} className="flex justify-between border-b border-stone-100 py-1 dark:border-stone-800">
                <span>{n}</span>
                <span className="text-stone-500">{toArabicDigits(c.toLocaleString("en"))}</span>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs leading-6 text-stone-500">
            النصوص والدرجات مأخوذة من قاعدة بيانات مشروع «الثقلين» (thaqalayn.net) المفتوحة، وضُمّنت داخل التطبيق ليعمل دون اتصال.
          </p>
        </Card>

        {!isApp && (
          <a
            href="./ABK.apk"
            download
            className="block rounded-2xl bg-emerald-800 py-4 text-center text-base font-extrabold text-white shadow active:scale-[.99]"
          >
            ⬇️ تحميل ملف التطبيق ABK.apk (أندرويد)
          </a>
        )}
        <p className="pb-4 text-center text-xs text-stone-400">ABK · الإصدار ١٫٠</p>
      </div>
    </Page>
  );
}

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-stone-200 bg-white p-4 shadow-sm dark:border-stone-700 dark:bg-stone-900">
      <h2 className="mb-3 text-base font-extrabold text-emerald-900 dark:text-emerald-300">{title}</h2>
      {children}
    </section>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} className="flex w-full items-center justify-between text-sm">
      <span>{label}</span>
      <span className={`relative h-7 w-12 rounded-full transition ${value ? "bg-emerald-700" : "bg-stone-300 dark:bg-stone-600"}`}>
        <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${value ? "right-0.5" : "right-[22px]"}`} />
      </span>
    </button>
  );
}
