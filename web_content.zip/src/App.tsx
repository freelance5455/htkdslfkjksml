/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  Trophy, 
  Volume2, 
  VolumeX, 
  Play, 
  Sparkles, 
  ChevronLeft, 
  X, 
  Shield, 
  Gauge, 
  Flame, 
  Award,
  Layers,
  Sparkle
} from 'lucide-react';

// --- DATA STRUCTURES & DEFINITIONS ---

export interface CarReward {
  id: number;
  level: number;
  name: string;
  subtitle: string;
  type: string;
  rarity: 'كلاسيك' | 'مميز' | 'نادر' | 'خارق' | 'أسطوري';
  color: string;
  accentColor: string;
  speed: number;      // 1 to 10
  durability: number; // 1 to 10
  torque: number;     // 1 to 10
  description: string;
  features: string[];
}

export const CAR_REWARDS: CarReward[] = [
  {
    id: 1,
    level: 1,
    name: 'عربية كلاسيكية (شاهين العمدة)',
    subtitle: 'أصالة شوارع زمان',
    type: 'سيدان كلاسيك',
    rarity: 'كلاسيك',
    color: '#8c2d19',
    accentColor: '#f5b942',
    speed: 5,
    durability: 7,
    torque: 6,
    description: 'عربية الأصالة المصرية، شاسيه صلب وماتور بيتحمل كل المشاوير وسحبها أصيل في أصعب السكك.',
    features: ['شبكة أمامية كروم', 'فوانيس دائرية كلاسيكية', 'صاج مجلفن ضد الصدمات']
  },
  {
    id: 2,
    level: 2,
    name: 'عربية بيك أب (دبابة الصناديق)',
    subtitle: 'سفينة التحميل الثقيل',
    type: 'بيك أب نقل ثقيل',
    rarity: 'مميز',
    color: '#1b4d7a',
    accentColor: '#e0a14c',
    speed: 6,
    durability: 8,
    torque: 9,
    description: 'تشيل حمولة الورشة كلها بقطع غيارها ومعداتها، وتعدي فوق أي مطب أو حفرة بكل ثبات.',
    features: ['صندوق شحن خلفي عريض', 'مساعدين هيدروليك مدعمة', 'صدام حديد صلب']
  },
  {
    id: 3,
    level: 3,
    name: 'سيارة سباق (صاروخ الحارة)',
    subtitle: 'انطلاقة التيربو الناري',
    type: 'سباق وتيربو',
    rarity: 'مميز',
    color: '#d62828',
    accentColor: '#fcbf49',
    speed: 9,
    durability: 5,
    torque: 8,
    description: 'سرعة خارقة وانسيابية هوائية، مزودة بجناح خلفي رياضي وخطوط لهب تخلي الوحوش تبلع ريقها!',
    features: ['جناح سباق أيروديناميكي', 'إطارات سباق ملساء', 'نظام عادم مزدوج هادر']
  },
  {
    id: 4,
    level: 4,
    name: 'جيب صحراوي (الوحش 4×4)',
    subtitle: 'قاهر الجبال والكثبان',
    type: 'دفع رباعي جبلي',
    rarity: 'نادر',
    color: '#70654e',
    accentColor: '#4895ef',
    speed: 6,
    durability: 9,
    torque: 9,
    description: 'قاهرة الكثبان الرملية والمنحدرات الوعرة، عجل ضخم مع كشافات علوية تنور أظلم الدروب.',
    features: ['شريط كشافات سقف LED', 'إطارات جبلية مضلعة ضخمة', 'ونش إنقاذ أمامي']
  },
  {
    id: 5,
    level: 5,
    name: 'عربية شرطة (النسر السريع)',
    subtitle: 'حامية العدالة والأمن',
    type: 'دورية أمنية خاصة',
    rarity: 'نادر',
    color: '#1c2541',
    accentColor: '#ff0055',
    speed: 8,
    durability: 8,
    torque: 7,
    description: 'تحافظ على أمن المملكة وتطارد الوحوش بسارينة الطوارئ الوامضة ومصد صدمات فولاذي.',
    features: ['فليشر طوارئ أزرق وأحمر', 'شعار النسر الملكي', 'مصد أمامي لفض المطاردات']
  },
  {
    id: 6,
    level: 6,
    name: 'سيارة رالي (قاهر الرمال)',
    subtitle: 'بطل دروب داكار',
    type: 'رالي احترافي',
    rarity: 'نادر',
    color: '#f77f00',
    accentColor: '#003049',
    speed: 8,
    durability: 8,
    torque: 8,
    description: 'مصممة للسباقات الشاقة وسط العواصف الترابية ومطبات الحجارة، لا تخاف الغبار ولا الانزلاق.',
    features: ['4 كشافات ضباب دائرية', 'قفص حماية رول كيدج', 'رفارف طين مدعمة']
  },
  {
    id: 7,
    level: 7,
    name: 'سيارة إنقاذ ومطافئ (الفزعة)',
    subtitle: 'درع التدخل السريع',
    type: 'إنقاذ وتدخل خاص',
    rarity: 'خارق',
    color: '#b7094c',
    accentColor: '#ffb703',
    speed: 7,
    durability: 10,
    torque: 9,
    description: 'تطفي نيران المعارك وتتدخل لإنقاذ الورشة، مزودة بخزانات دعم ومعدات صيانة ميدانية.',
    features: ['سلم إنقاذ تلسكوبي', 'صفارات إنذار صوتية', 'صناديق عدة طوارئ جانبية']
  },
  {
    id: 8,
    level: 8,
    name: 'سيارة عضلات (المسل كار الجبار)',
    subtitle: 'زئير محرك V8 الخارق',
    type: 'عضلات أمريكية',
    rarity: 'خارق',
    color: '#3a0ca3',
    accentColor: '#4cc9f0',
    speed: 9,
    durability: 8,
    torque: 10,
    description: 'عزم جبار يهز الأرض، سوبرتشارجر بارز من الكبوت مع صوت محرك يرعب كل وحوش المملكة.',
    features: ['سوبرتشارجر هواء مكشوف', 'عجلات خلفية عريضة جداً', 'عوادم جانبية مشتعلة']
  },
  {
    id: 9,
    level: 9,
    name: 'سيارة مستقبلية (نيون سايبر)',
    subtitle: 'تكنولوجيا طاقة المستقبل',
    type: 'سايبر هايبركار',
    rarity: 'خارق',
    color: '#03045e',
    accentColor: '#00f5d4',
    speed: 10,
    durability: 8,
    torque: 9,
    description: 'تكنولوجيا المستقبل دخلت ورشة المعلم، بطاريات بوليمر نفاثة مع إضاءات نيون مشعة تسابق الريح.',
    features: ['إضاءة نيون سفلية متوهجة', 'أجنحة طاقة ديناميكية', 'زجاج عاكس متدرج']
  },
  {
    id: 10,
    level: 10,
    name: 'العربية الأسطورية (فانتوم المعلم الذهبية)',
    subtitle: 'تاج المملكة وفخر الصناعة',
    type: 'تحفة ملكية أسطورية',
    rarity: 'أسطوري',
    color: '#d4af37',
    accentColor: '#ffffff',
    speed: 10,
    durability: 10,
    torque: 10,
    description: 'درة تاج مملكة المعلم سردينه، مذهبة بالكامل بأيدي المعلم ومطعمة بكروم ماسي لا يقهر!',
    features: ['هيكل مطلي بماء الذهب', 'تاج ملكي على المقدمة', 'بريق أسطوري وعوادم متوهجة']
  }
];

// --- WORLD BACKGROUND THEMES ---
export interface WorldTheme {
  id: number;
  name: string;
  subtitle: string;
  skyTop: string;
  skyMid: string;
  skyBottom: string;
  groundBase: string;
  groundGrass: string;
  groundEdge: string;
  ambientType: 'dust' | 'sand' | 'neon' | 'embers';
  particleColor: string;
}

export const WORLD_THEMES: WorldTheme[] = [
  {
    id: 1,
    name: 'حارة الورشة القديمة',
    subtitle: 'غروب المدينة وأصالة الورش',
    skyTop: '#4a90e2',
    skyMid: '#ffd194',
    skyBottom: '#ff9a76',
    groundBase: '#6b3b32',
    groundGrass: '#54bd55',
    groundEdge: '#a5ed76',
    ambientType: 'dust',
    particleColor: '#fde047'
  },
  {
    id: 2,
    name: 'وادي الخردة والصحراء',
    subtitle: 'رمال ذهبية وتلال الخردة القديمة',
    skyTop: '#d97706',
    skyMid: '#f59e0b',
    skyBottom: '#fef3c7',
    groundBase: '#78350f',
    groundGrass: '#ca8a04',
    groundEdge: '#fde047',
    ambientType: 'sand',
    particleColor: '#fbbf24'
  },
  {
    id: 3,
    name: 'مدينة النيون والمستقبل',
    subtitle: 'ناطحات سحاب وأضواء سايبر مشعة',
    skyTop: '#090a1e',
    skyMid: '#1e1b4b',
    skyBottom: '#4338ca',
    groundBase: '#1e293b',
    groundGrass: '#06b6d4',
    groundEdge: '#67e8f9',
    ambientType: 'neon',
    particleColor: '#22d3ee'
  },
  {
    id: 4,
    name: 'قلعة الميكانيكا والبراكين',
    subtitle: 'تروس ضخمة ونيران الصهر والحديد',
    skyTop: '#450a0a',
    skyMid: '#991b1b',
    skyBottom: '#f97316',
    groundBase: '#262626',
    groundGrass: '#dc2626',
    groundEdge: '#fbbf24',
    ambientType: 'embers',
    particleColor: '#f97316'
  }
];

// --- SOUND SYNTHESIZER (Web Audio API) ---
class SoundManager {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  playHammer() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(170, now);
    osc.frequency.exponentialRampToValueAtTime(35, now + 0.17);
    gain.gain.setValueAtTime(0.7, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);

    const metalOsc = this.ctx.createOscillator();
    const metalGain = this.ctx.createGain();
    metalOsc.type = 'square';
    metalOsc.frequency.setValueAtTime(690, now);
    metalOsc.frequency.exponentialRampToValueAtTime(220, now + 0.12);
    metalGain.gain.setValueAtTime(0.35, now);
    metalGain.gain.exponentialRampToValueAtTime(0.01, now + 0.13);
    metalOsc.connect(metalGain);
    metalGain.connect(this.ctx.destination);
    metalOsc.start(now);
    metalOsc.stop(now + 0.13);
  }

  playWrench() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(860, now);
    osc.frequency.exponentialRampToValueAtTime(320, now + 0.15);
    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  playNutThrow() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(680, now + 0.13);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.14);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.14);
  }

  playExplosion() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(25, now + 0.35);
    gain.gain.setValueAtTime(0.65, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.36);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.36);
  }

  playJump() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(210, now);
    osc.frequency.exponentialRampToValueAtTime(480, now + 0.15);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  playPickup() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);
      gain.gain.setValueAtTime(0.3, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.06 + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 0.16);
    });
  }

  playWinFanfare() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.11);
      gain.gain.setValueAtTime(0.4, now + idx * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.11 + 0.35);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(now + idx * 0.11);
      osc.stop(now + idx * 0.11 + 0.36);
    });
  }

  playHurt() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.2);
    gain.gain.setValueAtTime(0.45, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  playCarHorn() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    // Egyptian shaabi double honk "بيب بيب!"
    [0, 0.12].forEach((t) => {
      [420, 520].forEach((freq) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now + t);
        gain.gain.setValueAtTime(0.22, now + t);
        gain.gain.exponentialRampToValueAtTime(0.01, now + t + 0.09);
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        osc.start(now + t);
        osc.stop(now + t + 0.1);
      });
    });
  }

  playNitroSound() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(560, now + 0.35);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.45);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.46);
  }

  playRaceCoin() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(1760, now + 0.12);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
  }
}

const sounds = new SoundManager();

// --- CAR PROCEDURAL CANVAS RENDERER ---
function drawCarIllustration(
  ctx: CanvasRenderingContext2D,
  car: CarReward,
  x: number,
  y: number,
  scale: number = 1.0,
  opts?: { lightOn?: boolean; shine?: boolean; bob?: number }
) {
  ctx.save();
  ctx.translate(x, y + (opts?.bob || 0));
  ctx.scale(scale, scale);

  const col = car.color;
  const acc = car.accentColor;

  switch (car.id) {
    case 1: // Classic Sedan (شاهين العمدة)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(-42, -6, 84, 18, [4, 6, 2, 2]);
      ctx.fill();
      ctx.fillStyle = '#6e2314';
      ctx.beginPath();
      ctx.moveTo(-24, -6);
      ctx.lineTo(-14, -20);
      ctx.lineTo(16, -20);
      ctx.lineTo(26, -6);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#bfe3f7';
      ctx.fillRect(-18, -18, 15, 11);
      ctx.fillRect(2, -18, 18, 11);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(38, -2, 6, 12);
      ctx.fillRect(-44, -2, 4, 12);
      ctx.fillStyle = acc;
      ctx.fillRect(36, 1, 3, 5);
      ctx.fillStyle = opts?.lightOn ? '#fff7a1' : '#fef08a';
      ctx.beginPath();
      ctx.arc(40, -1, 3, 0, Math.PI * 2);
      ctx.fill();
      break;

    case 2: // Pickup Truck (دبابة الصناديق)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(-8, -22, 48, 32, [4, 6, 2, 2]);
      ctx.fill();
      ctx.fillStyle = '#a5d8ff';
      ctx.fillRect(10, -19, 22, 12);
      ctx.fillStyle = '#8b5a2b';
      ctx.fillRect(-45, -8, 40, 18);
      ctx.fillStyle = acc;
      ctx.fillRect(-45, -14, 38, 4);
      ctx.fillRect(-42, -14, 4, 10);
      ctx.fillRect(-26, -14, 4, 10);
      ctx.fillStyle = '#475569';
      ctx.fillRect(38, 0, 7, 10);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(-35, -16, 12, 9);
      break;

    case 3: // Race Car (صاروخ الحارة)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(-45, 8);
      ctx.lineTo(-44, -4);
      ctx.lineTo(-20, -12);
      ctx.lineTo(18, -12);
      ctx.lineTo(44, 2);
      ctx.lineTo(46, 8);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.ellipse(-2, -11, 16, 7, 0, Math.PI, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.ellipse(-2, -11, 13, 5, 0, Math.PI, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = acc;
      ctx.fillRect(-45, -2, 90, 3);
      ctx.fillStyle = '#111827';
      ctx.fillRect(-44, -20, 16, 3);
      ctx.fillRect(-42, -17, 3, 14);
      ctx.fillRect(-32, -17, 3, 14);
      break;

    case 4: // 4x4 Desert Jeep (الوحش 4x4)
      ctx.fillStyle = col;
      ctx.fillRect(-38, -14, 76, 20);
      ctx.fillStyle = '#4a4435';
      ctx.fillRect(-22, -26, 42, 14);
      ctx.fillStyle = '#bae6fd';
      ctx.fillRect(0, -24, 18, 10);
      ctx.fillRect(-18, -24, 14, 10);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-16, -30, 32, 4);
      for (let li = 0; li < 4; li++) {
        ctx.fillStyle = opts?.lightOn ? '#fef08a' : '#cbd5e1';
        ctx.beginPath();
        ctx.arc(-10 + li * 7, -28, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(36, -6, 7, 16);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(39, 0, 4, 4);
      break;

    case 5: // Police Cruiser (النسر السريع)
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.roundRect(-42, -7, 84, 18, [4, 6, 2, 2]);
      ctx.fill();
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-12, -7, 24, 18);
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.moveTo(-24, -7);
      ctx.lineTo(-14, -21);
      ctx.lineTo(16, -21);
      ctx.lineTo(26, -7);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#7dd3fc';
      ctx.fillRect(-10, -18, 20, 10);
      const flash = Math.floor(Date.now() / 250) % 2 === 0;
      ctx.fillStyle = flash ? '#ef4444' : '#2563eb';
      ctx.fillRect(-5, -25, 5, 4);
      ctx.fillStyle = flash ? '#2563eb' : '#ef4444';
      ctx.fillRect(1, -25, 5, 4);
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(0, 2, 3, 0, Math.PI * 2);
      ctx.fill();
      break;

    case 6: // Rally Racer (قاهر الرمال)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(-42, -9, 84, 20, [5, 8, 3, 3]);
      ctx.fill();
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(-22, -9);
      ctx.lineTo(-12, -22);
      ctx.lineTo(14, -22);
      ctx.lineTo(24, -9);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(-8, -19, 18, 9);
      for (let ri = 0; ri < 4; ri++) {
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(28 + ri * 3, -10 + (ri % 2) * 3, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-44, 4, 3, 8);
      ctx.fillRect(40, 4, 3, 8);
      break;

    case 7: // Fire & Rescue (الفزعة)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(-46, -18, 92, 30, [4, 6, 2, 2]);
      ctx.fill();
      ctx.fillStyle = '#bae6fd';
      ctx.fillRect(20, -15, 20, 11);
      ctx.fillStyle = acc;
      ctx.fillRect(-46, 2, 92, 4);
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(-36, -24, 60, 4);
      for (let li = 0; li < 6; li++) {
        ctx.fillRect(-32 + li * 10, -26, 2, 8);
      }
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(30, -22, 3.5, 0, Math.PI * 2);
      ctx.fill();
      break;

    case 8: // Muscle Car (المسل كار الجبار)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.roundRect(-44, -8, 88, 19, [3, 7, 2, 2]);
      ctx.fill();
      ctx.fillStyle = '#240046';
      ctx.beginPath();
      ctx.moveTo(-28, -8);
      ctx.lineTo(-18, -20);
      ctx.lineTo(8, -20);
      ctx.lineTo(18, -8);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#64748b';
      ctx.fillRect(-14, -18, 20, 9);
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(24, -14, 10, 6);
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(29, -14, 3, 0, Math.PI, true);
      ctx.fill();
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(-10, 8, 30, 3);
      break;

    case 9: // Cyber Future Car (نيون سايبر)
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(-45, 8);
      ctx.lineTo(-40, -6);
      ctx.lineTo(-16, -18);
      ctx.lineTo(20, -18);
      ctx.lineTo(46, 0);
      ctx.lineTo(46, 8);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#a855f7';
      ctx.beginPath();
      ctx.moveTo(-12, -16);
      ctx.lineTo(16, -16);
      ctx.lineTo(28, -4);
      ctx.lineTo(-6, -4);
      ctx.closePath();
      ctx.fill();
      ctx.shadowColor = acc;
      ctx.shadowBlur = 10;
      ctx.fillStyle = acc;
      ctx.fillRect(-40, 10, 80, 2);
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#22d3ee';
      ctx.fillRect(40, -2, 6, 3);
      break;

    case 10: // Golden Legendary Phantom (فانتوم المعلم الذهبية)
    default:
      const goldGrad = ctx.createLinearGradient(-45, -20, 45, 10);
      goldGrad.addColorStop(0, '#fef08a');
      goldGrad.addColorStop(0.5, '#d4af37');
      goldGrad.addColorStop(1, '#996515');
      ctx.fillStyle = goldGrad;
      ctx.beginPath();
      ctx.roundRect(-46, -10, 92, 21, [6, 9, 3, 3]);
      ctx.fill();
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.moveTo(-26, -10);
      ctx.lineTo(-16, -24);
      ctx.lineTo(16, -24);
      ctx.lineTo(26, -10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#fde68a';
      ctx.fillRect(-12, -21, 24, 10);
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.moveTo(42, -10);
      ctx.lineTo(44, -16);
      ctx.lineTo(46, -12);
      ctx.lineTo(48, -16);
      ctx.lineTo(50, -10);
      ctx.closePath();
      ctx.fill();
      break;
  }

  // Wheels
  const isOffroad = car.id === 4 || car.id === 2;
  const wheelRadius = isOffroad ? 11 : 9;
  [-26, 26].forEach((wx) => {
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(wx, 8, wheelRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = car.id === 10 ? '#fbbf24' : car.id === 3 ? '#e2e8f0' : '#64748b';
    ctx.beginPath();
    ctx.arc(wx, 8, wheelRadius - 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(wx, 8, 2, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.restore();
}

// --- MAIN REACT COMPONENT ---
export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentWorld, setCurrentWorld] = useState<number>(1);
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [showGarage, setShowGarage] = useState<boolean>(false);
  const [showWorldMenu, setShowWorldMenu] = useState<boolean>(false);
  const [showRewardModal, setShowRewardModal] = useState<boolean>(false);
  const [swapControlSides, setSwapControlSides] = useState<boolean>(false);
  const [selectedGarageCar, setSelectedGarageCar] = useState<CarReward>(CAR_REWARDS[0]);
  const [collectedCarIds, setCollectedCarIds] = useState<number[]>([1]);
  const [latestRewardCar, setLatestRewardCar] = useState<CarReward>(CAR_REWARDS[0]);
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [isRacing, setIsRacing] = useState<boolean>(false);
  const [raceSpeedDisplay, setRaceSpeedDisplay] = useState<number>(230);
  const [raceDistanceDisplay, setRaceDistanceDisplay] = useState<number>(600);
  const [racePositionDisplay, setRacePositionDisplay] = useState<number>(3);
  const [raceNitroDisplay, setRaceNitroDisplay] = useState<number>(85);

  const cycleZoom = () => {
    const levels = [1.0, 1.25, 1.5];
    const nextIdx = (levels.indexOf(zoomLevel) + 1) % levels.length;
    const nextZoom = levels[nextIdx];
    setZoomLevel(nextZoom);
    engineRef.current.zoom = nextZoom;
    const desc = nextZoom === 1.5 ? 'مكبر (1.5x)' : nextZoom === 1.25 ? 'متوازن (1.25x)' : 'كامل (1.0x)';
    engineRef.current.say(`تم تغيير حجم الشاشة: ${desc} 🔍`);
  };

  // Load unlocked cars
  useEffect(() => {
    try {
      const saved = localStorage.getItem('sardina_collected_cars_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setCollectedCarIds(parsed);
        }
      }
    } catch (_) {}
  }, []);

  const unlockCar = useCallback((carId: number) => {
    setCollectedCarIds((prev) => {
      if (!prev.includes(carId)) {
        const next = [...prev, carId];
        try {
          localStorage.setItem('sardina_collected_cars_v2', JSON.stringify(next));
        } catch (_) {}
        return next;
      }
      return prev;
    });
  }, []);

  // Game Engine Mutable State Ref
  const engineRef = useRef({
    W: 800,
    H: 600,
    D: 1,
    WW: 3000,
    cam: 0,
    camX: 0,
    camY: 0,
    zoom: 1.0,
    playing: false,
    won: false,
    // Stage Finale Car Race Mode
    racing: false,
    raceFinished: false,
    raceCar: null as CarReward | null,
    raceDistance: 600,
    raceTotalDist: 600,
    raceSpeed: 230,
    raceTargetSpeed: 230,
    raceLane: 1,
    raceY: 340,
    raceTargetY: 340,
    raceNitro: 85,
    isNitroActive: false,
    nitroTimer: 0,
    raceScroll: 0,
    raceTime: 0,
    racePosition: 3,
    raceWinnerCelebrated: false,
    raceWinCelebrationTimer: 0,
    rivals: [] as Array<{
      id: number;
      name: string;
      car: CarReward;
      lane: number;
      x: number;
      baseSpeed: number;
      passed: boolean;
    }>,
    roadPickups: [] as Array<{
      id: number;
      x: number;
      lane: number;
      type: 'nitro' | 'coin' | 'wrench';
      collected: boolean;
    }>,
    roadObstacles: [] as Array<{
      id: number;
      x: number;
      lane: number;
      hit: boolean;
    }>,
    raceEffects: [] as Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      color: string;
      size: number;
      type: 'fire' | 'smoke' | 'spark' | 'confetti';
    }>,
    raceFireworks: [] as Array<{
      x: number;
      y: number;
      color: string;
      sparks: Array<{ x: number; y: number; vx: number; vy: number; life: number; color: string }>;
    }>,
    keys: {
      left: false,
      right: false,
      jump: false,
      hammer: false,
      wrench: false,
      nuts: false,
    } as Record<string, boolean>,
    lastTime: 0,
    world: 1,
    level: 1,
    carBuilt: false,
    shake: 0,
    shakePower: 0,
    walkCycle: 0,
    landSquash: 0,
    // Shockwave Rings Effect
    shockwaves: [] as Array<{ x: number; y: number; r: number; maxR: number; alpha: number; color: string }>,
    // Floating Text Callouts Effect
    floatingTexts: [] as Array<{ x: number; y: number; text: string; life: number; color: string }>,
    // Player
    p: {
      x: 50,
      y: 0,
      w: 30,
      h: 42,
      vx: 0,
      vy: 0,
      face: 1,
      hp: 3,
      inv: 0,
      atk: 0,
      atkMax: 24,
      weapon: 'hammer' as 'hammer' | 'wrench' | 'nuts',
      atkPhase: 'none' as 'none' | 'windup' | 'strike' | 'impact' | 'recovery',
      hasImpacted: false,
      ground: false,
      skidTimer: 0,
    },
    // Parts & Crates
    parts: [] as Array<{ x: number; y: number; type: string; got: boolean }>,
    crates: [] as Array<{ x: number; y: number; opened: boolean }>,
    openedCrates: 0,
    // Rich Monsters Roster (8 Types)
    foes: [] as Array<{
      x: number;
      y: number;
      baseY?: number;
      w: number;
      h: number;
      dir: number;
      kind: number; // 0: Beetle, 1: Hopper, 2: Shield Brute, 3: Fire Spitter, 4: Saw Bot, 5: Flying Gargoyle, 6: Tin Golem, 7: Slime
      alive: boolean;
      shield: number;
      cool: number;
      phase: number;
      hp: number;
      maxHp: number;
      hitFlash?: number;
    }>,
    // Particles (Sparks, Dust, Embers, Acid, Nuts, Fireballs, Stars, Debris)
    particles: [] as Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife?: number;
      color: string;
      size?: number;
      isSpark?: boolean;
      isDust?: boolean;
      isStar?: boolean;
      isDebris?: boolean;
      rot?: number;
      vRot?: number;
      nut?: boolean;
      fireball?: boolean;
      shockwaveWave?: boolean; // Ground shockwave travelling
    }>,
    // Level gaps & platforms
    gaps: [[470, 530], [990, 1050], [1510, 1570], [2070, 2135]] as Array<[number, number]>,
    platformXs: [310, 620, 880, 1190, 1450, 1700, 1960, 2250],
    platforms: [] as Array<{ x: number; y: number; w: number; h: number }>,
    types: ['شاسيه', 'عجلة', 'مسمار', 'باب', 'موتور', 'عجلة'],
    say: (msg: string) => {
      const el = document.getElementById('engine-msg');
      if (el) el.textContent = msg;
    },
    updateHud: () => {
      const eng = engineRef.current;
      const hpEl = document.getElementById('engine-health');
      if (hpEl) hpEl.textContent = '❤️'.repeat(eng.p.hp) + '🖤'.repeat(3 - eng.p.hp);
      const partsEl = document.getElementById('engine-parts');
      if (partsEl) {
        const count = eng.parts.filter((a) => a.got).length;
        partsEl.innerHTML = `<span class="hidden sm:inline">قطع الغيار </span><span class="sm:hidden">قطع </span>${count}/6`;
      }
      const stageEl = document.getElementById('engine-stage');
      if (stageEl) {
        const theme = WORLD_THEMES.find((w) => w.id === eng.world) || WORLD_THEMES[0];
        stageEl.innerHTML = `<span class="hidden sm:inline">${theme.name} • </span>مستوى ${eng.level}/10`;
      }
    }
  });

  useEffect(() => {
    sounds.enabled = soundEnabled;
  }, [soundEnabled]);

  // Main Game Setup & Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const eng = engineRef.current;

    function resize() {
      eng.W = window.innerWidth;
      eng.H = window.innerHeight;
      eng.D = Math.min(window.devicePixelRatio || 1, 2);
      canvas!.width = eng.W * eng.D;
      canvas!.height = eng.H * eng.D;
      canvas!.style.width = eng.W + 'px';
      canvas!.style.height = eng.H + 'px';
      ctx!.setTransform(eng.D, 0, 0, eng.D, 0, 0);
    }
    window.addEventListener('resize', resize);
    resize();

    function gy() {
      return 540;
    }

    function platTop(x: number) {
      return gy() - (x % 3 === 0 ? 110 : 70);
    }

    function solid(x: number) {
      return !eng.gaps.some((g) => x > g[0] && x < g[1]);
    }

    function addShockwave(x: number, y: number, color: string = '#fef08a', maxR: number = 70) {
      eng.shockwaves.push({ x, y, r: 8, maxR, alpha: 1.0, color });
    }

    function addFloatingText(x: number, y: number, text: string, color: string = '#ffd05b') {
      eng.floatingTexts.push({ x, y, text, life: 40, color });
    }

    function openCratesAt(cx: number, cy: number, rx: number, ry: number): boolean {
      let openedAny = false;
      eng.crates.forEach((b) => {
        if (!b.opened) {
          const crateCenterX = b.x + 15;
          const crateCenterY = b.y + 15;
          if (Math.abs(crateCenterX - cx) <= rx && Math.abs(crateCenterY - cy) <= ry) {
            b.opened = true;
            openedAny = true;
            eng.openedCrates++;
            addShockwave(crateCenterX, crateCenterY, '#fbbf24', 60);
            addFloatingText(crateCenterX, crateCenterY - 14, 'كنز الورشة! 📦✨', '#fef08a');
            sounds.playPickup();
            for (let i = 0; i < 20; i++) {
              eng.particles.push({
                x: crateCenterX,
                y: crateCenterY,
                vx: (Math.random() - 0.5) * 220,
                vy: -90 - Math.random() * 180,
                life: 38,
                color: i % 2 ? '#ffe17a' : '#f6a63a',
                size: 4 + Math.random() * 3
              });
            }
          }
        }
      });
      if (openedAny) {
        eng.say('💥 الصندوق اتفتح! عاش يا معلم');
      }
      return openedAny;
    }

    function openNearbyCrate(): boolean {
      const { p } = eng;
      return openCratesAt(p.x + p.w / 2, p.y + p.h / 2, 130, 150);
    }

    function spawnWeaponHitParticles(
      hitX: number,
      hitY: number,
      weapon: 'hammer' | 'wrench' | 'nuts',
      face: number,
      isShieldBreak: boolean,
      isFatal: boolean
    ) {
      // 1. Expanding shockwave ring at impact point
      addShockwave(hitX, hitY, weapon === 'hammer' ? '#fde047' : '#38bdf8', isFatal ? 75 : 50);

      // 2. High-speed directional sparks in blow direction
      const sparkCount = weapon === 'hammer' ? 24 : 18;
      const sparkColors = weapon === 'hammer'
        ? ['#ffffff', '#fef08a', '#f59e0b', '#f97316', '#ff4444']
        : ['#ffffff', '#38bdf8', '#0284c7', '#7dd3fc', '#06b6d4'];

      for (let i = 0; i < sparkCount; i++) {
        const spreadAngle = (Math.random() - 0.5) * 1.5;
        const baseAngle = face > 0 ? 0 : Math.PI;
        const finalAngle = baseAngle + spreadAngle;
        const speed = 140 + Math.random() * 260;

        eng.particles.push({
          x: hitX + (Math.random() - 0.5) * 6,
          y: hitY + (Math.random() - 0.5) * 6,
          vx: Math.cos(finalAngle) * speed,
          vy: Math.sin(finalAngle) * speed - 60 - Math.random() * 80,
          life: 20 + Math.floor(Math.random() * 14),
          color: sparkColors[i % sparkColors.length],
          size: 2.5 + Math.random() * 3,
          isSpark: true,
        });
      }

      // 3. Comic Impact Stars (✦) bursting outward
      const starCount = weapon === 'hammer' ? 6 : 4;
      for (let s = 0; s < starCount; s++) {
        const ang = (Math.PI * 2 * s) / starCount + (Math.random() - 0.5) * 0.4;
        const spd = 80 + Math.random() * 130;
        eng.particles.push({
          x: hitX,
          y: hitY,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd - 30,
          life: 20 + Math.floor(Math.random() * 10),
          color: weapon === 'hammer' ? '#fef08a' : '#7dd3fc',
          size: 5 + Math.random() * 4,
          isStar: true,
          rot: Math.random() * Math.PI,
          vRot: (Math.random() - 0.5) * 12,
        });
      }

      // 4. Flying scrap metal & stone debris shards with gravity
      const debrisCount = isShieldBreak ? 16 : (weapon === 'hammer' ? 9 : 6);
      for (let d = 0; d < debrisCount; d++) {
        eng.particles.push({
          x: hitX,
          y: hitY,
          vx: face * 70 + (Math.random() - 0.5) * 220,
          vy: -80 - Math.random() * 190,
          life: 30 + Math.floor(Math.random() * 15),
          color: isShieldBreak ? (d % 2 ? '#94a3b8' : '#e2e8f0') : (weapon === 'hammer' ? '#d97706' : '#64748b'),
          size: 3.5 + Math.random() * 3.5,
          isDebris: true,
          rot: Math.random() * Math.PI,
          vRot: (Math.random() - 0.5) * 14,
        });
      }
    }

    function resetGame(levelNum?: number, worldNum?: number) {
      if (typeof levelNum === 'number') eng.level = levelNum;
      if (typeof worldNum === 'number') eng.world = worldNum;

      setCurrentLevel(eng.level);
      setCurrentWorld(eng.world);

      eng.platforms = eng.platformXs.map((x) => ({
        x,
        y: platTop(x),
        w: 100,
        h: 23,
      }));

      eng.p.x = 50;
      eng.p.y = gy() - eng.p.h;
      eng.p.vx = 0;
      eng.p.vy = 0;
      eng.p.hp = 3;
      eng.p.inv = 0;
      eng.p.atk = 0;
      eng.p.atkPhase = 'none';
      eng.p.hasImpacted = false;
      eng.p.ground = true;
      eng.cam = 0;
      eng.camX = 0;
      eng.camY = gy() - (eng.H - 120) / eng.zoom;
      eng.won = false;
      eng.carBuilt = false;
      eng.racing = false;
      eng.raceFinished = false;
      setIsRacing(false);
      eng.shake = 0;
      eng.shakePower = 0;
      eng.walkCycle = 0;
      eng.landSquash = 0;
      eng.shockwaves = [];
      eng.floatingTexts = [];

      eng.parts = Array.from({ length: 6 }, (_, i) => ({
        x: 250 + i * 400,
        y: gy() - 75 - (i % 2) * 45,
        type: eng.types[i],
        got: false,
      }));

      // Real crates on ALL platforms + ground bonus crates
      eng.crates = eng.platforms.map((a) => ({ x: a.x + 35, y: a.y - 30, opened: false }));
      eng.crates.push({ x: 500, y: gy() - 31, opened: false });
      eng.crates.push({ x: 1350, y: gy() - 31, opened: false });
      eng.crates.push({ x: 2150, y: gy() - 31, opened: false });
      eng.openedCrates = 0;

      // Rich diverse monster roster according to world & level
      // 8 kinds: 0: Beetle, 1: Hopper, 2: Shield Brute, 3: Fire Spitter, 4: Saw Bot, 5: Flying Gargoyle, 6: Tin Golem, 7: Slime
      const baseFoes = [
        { x: 380, dir: 1, kind: 0, hp: 1 },
        { x: 740, dir: -1, kind: (eng.world >= 2 ? 4 : 1), hp: 1 },
        { x: 1080, dir: 1, kind: 5, hp: 1 }, // Flying Monster
        { x: 1400, dir: -1, kind: 2, hp: 2 }, // Shield Brute
        { x: 1720, dir: 1, kind: (eng.world === 3 ? 4 : 7), hp: 1 }, // Electric or Slime
        { x: 2020, dir: -1, kind: 3, hp: 1 }, // Fire Spitter
        { x: 2360, dir: 1, kind: (eng.level >= 3 ? 6 : 0), hp: (eng.level >= 3 ? 3 : 1) }, // Tin Golem Mini-Boss
        { x: 2580, dir: -1, kind: (eng.world >= 3 ? 5 : 2), hp: 1 }
      ];

      eng.foes = baseFoes.map((e, i) => ({
        ...e,
        y: gy() - 38,
        baseY: gy() - 38,
        w: e.kind === 6 ? 56 : 42,
        h: e.kind === 6 ? 54 : 38,
        alive: true,
        shield: e.kind === 2 ? 1 : 0,
        cool: 80 + i * 22,
        phase: Math.random() * 6,
        maxHp: e.hp,
      }));

      eng.particles = [];
      eng.updateHud();
      eng.say('اجمع قطع الغيار — الورشة في آخر الطريق!');
    }

    function executeAttack(w: 'hammer' | 'wrench' | 'nuts') {
      if (!eng.playing || eng.won || eng.p.atk > 0) return;

      eng.p.weapon = w;
      eng.p.hasImpacted = false;

      if (w === 'nuts') {
        eng.p.atk = 16;
        eng.p.atkMax = 16;
        eng.particles.push({
          x: eng.p.x + eng.p.w / 2 + eng.p.face * 28,
          y: eng.p.y + 25,
          vx: eng.p.face * 420,
          vy: -95,
          life: 110,
          color: '#f3b72e',
          nut: true,
        });
        sounds.playNutThrow();
        addFloatingText(eng.p.x + eng.p.w / 2, eng.p.y - 10, 'قذيفة صامولة! 💣', '#fbbf24');
        eng.say('المعلم رمى صامولة متفجرة! 💥');
        return;
      }

      eng.p.atkMax = w === 'hammer' ? 26 : 22;
      eng.p.atk = eng.p.atkMax;
    }

    function jumpPlayer() {
      if (!eng.playing || eng.won) return;
      openNearbyCrate();
      if (eng.p.ground) {
        eng.p.vy = -650;
        eng.p.ground = false;
        sounds.playJump();
        // Jump dust particles
        for (let i = 0; i < 6; i++) {
          eng.particles.push({
            x: eng.p.x + eng.p.w / 2 + (Math.random() - 0.5) * 20,
            y: gy() - 4,
            vx: (Math.random() - 0.5) * 80,
            vy: -Math.random() * 60,
            life: 16,
            color: '#cbd5e1',
            isDust: true,
            size: 3
          });
        }
      }
    }

    // Keyboard Listeners
    function onKeyDown(e: KeyboardEvent) {
      if (eng.racing) {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          e.preventDefault();
          raceShiftLane(-1);
        } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
          e.preventDefault();
          raceShiftLane(1);
        } else if (e.key === ' ' || e.key === 'Shift' || e.key === 'x' || e.key === 'X') {
          e.preventDefault();
          raceActivateNitro();
        } else if (e.key === 'h' || e.key === 'H' || e.key === 'c' || e.key === 'C') {
          e.preventDefault();
          raceHonkHorn();
        }
        return;
      }

      const map: Record<string, string> = {
        ArrowLeft: 'left',
        a: 'left',
        ArrowRight: 'right',
        d: 'right',
        ArrowUp: 'jump',
        ' ': 'jump',
        w: 'jump',
        z: 'hammer',
        Z: 'hammer',
        x: 'wrench',
        X: 'wrench',
        c: 'nuts',
        C: 'nuts',
      };
      const key = map[e.key];
      if (key) {
        e.preventDefault();
        if (!eng.keys[key]) {
          eng.keys[key] = true;
          if (key === 'jump') jumpPlayer();
          if (key === 'hammer' || key === 'wrench' || key === 'nuts') {
            executeAttack(key as 'hammer' | 'wrench' | 'nuts');
          }
        }
      }
    }

    function onKeyUp(e: KeyboardEvent) {
      const map: Record<string, string> = {
        ArrowLeft: 'left',
        a: 'left',
        ArrowRight: 'right',
        d: 'right',
        ArrowUp: 'jump',
        ' ': 'jump',
        w: 'jump',
        z: 'hammer',
        Z: 'hammer',
        x: 'wrench',
        X: 'wrench',
        c: 'nuts',
        C: 'nuts',
      };
      const key = map[e.key];
      if (key) {
        eng.keys[key] = false;
      }
    }

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // ==========================================
    // STAGE FINALE CAR RACE MINI-GAME LOGIC
    // ==========================================
    function getLaneY(lane: number) {
      const roadTop = eng.H * 0.44;
      const roadBottom = eng.H * 0.90;
      const laneH = (roadBottom - roadTop) / 3;
      return roadTop + laneH * (lane + 0.5);
    }

    function startCarRace(rewardCar: CarReward) {
      eng.racing = true;
      eng.raceFinished = false;
      eng.raceCar = rewardCar;
      eng.raceDistance = 600;
      eng.raceTotalDist = 600;
      eng.raceSpeed = 230;
      eng.raceTargetSpeed = 230;
      eng.raceLane = 1;
      eng.raceY = getLaneY(1);
      eng.raceTargetY = getLaneY(1);
      eng.raceNitro = 85;
      eng.isNitroActive = false;
      eng.nitroTimer = 0;
      eng.raceScroll = 0;
      eng.raceTime = 0;
      eng.racePosition = 3;
      eng.raceWinnerCelebrated = false;
      eng.raceWinCelebrationTimer = 0;
      eng.raceEffects = [];
      eng.raceFireworks = [];

      // Rivals pool with distinct cars
      const otherCars = CAR_REWARDS.filter((c) => c.id !== rewardCar.id);
      eng.rivals = [
        {
          id: 1,
          name: 'صاروخ الحارة',
          car: otherCars[0] || CAR_REWARDS[2],
          lane: 0,
          x: 420,
          baseSpeed: 185,
          passed: false,
        },
        {
          id: 2,
          name: 'شبندر التجار',
          car: otherCars[1] || CAR_REWARDS[1],
          lane: 2,
          x: 750,
          baseSpeed: 200,
          passed: false,
        },
        {
          id: 3,
          name: 'البلدوزر السريع',
          car: otherCars[2] || CAR_REWARDS[3],
          lane: 1,
          x: 1080,
          baseSpeed: 215,
          passed: false,
        },
      ];

      // Road Pickups
      eng.roadPickups = [
        { id: 1, x: 300, lane: 1, type: 'nitro', collected: false },
        { id: 2, x: 580, lane: 0, type: 'coin', collected: false },
        { id: 3, x: 800, lane: 2, type: 'nitro', collected: false },
        { id: 4, x: 1020, lane: 1, type: 'coin', collected: false },
        { id: 5, x: 1220, lane: 0, type: 'wrench', collected: false },
        { id: 6, x: 1450, lane: 2, type: 'nitro', collected: false },
      ];

      // Road Obstacles
      eng.roadObstacles = [
        { id: 1, x: 490, lane: 1, hit: false },
        { id: 2, x: 910, lane: 2, hit: false },
        { id: 3, x: 1320, lane: 0, hit: false },
      ];

      setIsRacing(true);
      setRaceSpeedDisplay(230);
      setRaceDistanceDisplay(600);
      setRacePositionDisplay(3);
      setRaceNitroDisplay(85);

      sounds.playCarHorn();
      eng.say(`انطلق في سباق المرحلة بسيارتك الجديدة: ${rewardCar.name}! 🏁🚗`);
    }

    function raceShiftLane(dir: number) {
      if (!eng.racing) return;
      const next = Math.max(0, Math.min(2, eng.raceLane + dir));
      if (next !== eng.raceLane) {
        eng.raceLane = next;
        eng.raceTargetY = getLaneY(next);
        sounds.playJump();
      }
    }

    function raceActivateNitro() {
      if (!eng.racing || eng.isNitroActive || eng.raceNitro < 20) return;
      eng.isNitroActive = true;
      eng.nitroTimer = 2.4;
      eng.raceNitro = Math.max(0, eng.raceNitro - 35);
      eng.shake = 10;
      eng.shakePower = 6;
      sounds.playNitroSound();
      addFloatingText(eng.W * 0.35, eng.raceY - 45, '🔥 تيربو نيترو ناري! 🔥', '#38bdf8');
      eng.say('المعلم سردينه ولّع التيربو! وسع الطريق! 🚀🔥');
    }

    function raceHonkHorn() {
      if (!eng.racing) return;
      sounds.playCarHorn();
      addFloatingText(eng.W * 0.28, eng.raceY - 40, 'بيب بيب! 🎺', '#fef08a');
      eng.say('بيب بيب! وسع يا ابني للمعلم سردينه! 🚗💨');
    }

    function finishCarRaceEarly() {
      if (!eng.racing) return;
      eng.racing = false;
      eng.won = true;
      setIsRacing(false);
      setShowRewardModal(true);
      sounds.playWinFanfare();
      eng.say(`مبروك يا معلم! تم تصنيع ${latestRewardCar.name} 🏆`);
    }

    function updateRace(dt: number) {
      eng.raceTime += dt;

      // Update Screen Dimensions & target position
      const playerCarX = eng.W * 0.22;
      const targetY = getLaneY(eng.raceLane);
      eng.raceY += (targetY - eng.raceY) * Math.min(1, dt * 11);

      // Nitro Handling & Speeds
      if (eng.isNitroActive) {
        eng.nitroTimer -= dt;
        eng.raceTargetSpeed = 440;
        // Fire particles from exhaust
        for (let i = 0; i < 2; i++) {
          eng.raceEffects.push({
            x: playerCarX - 44,
            y: eng.raceY + 6 + (Math.random() - 0.5) * 8,
            vx: -700 - Math.random() * 250,
            vy: (Math.random() - 0.5) * 60,
            life: 14,
            maxLife: 14,
            color: Math.random() > 0.4 ? '#38bdf8' : '#f97316',
            size: 5 + Math.random() * 5,
            type: 'fire',
          });
        }
        if (eng.nitroTimer <= 0) {
          eng.isNitroActive = false;
          eng.raceTargetSpeed = 230;
        }
      } else {
        // Natural gradual nitro regen
        eng.raceNitro = Math.min(100, eng.raceNitro + dt * 10);
      }

      // Smooth Speed interpolation
      eng.raceSpeed += (eng.raceTargetSpeed - eng.raceSpeed) * Math.min(1, dt * 4.5);

      // Distance & Road Scroll
      if (eng.raceDistance > 0) {
        eng.raceDistance = Math.max(0, eng.raceDistance - (eng.raceSpeed / 3.6) * dt * 0.55);
      }
      eng.raceScroll += (eng.raceSpeed / 3.6) * dt * 4.2;

      // Tire dust particles
      if (Math.random() > 0.45) {
        eng.raceEffects.push({
          x: playerCarX - 34,
          y: eng.raceY + 11,
          vx: -350,
          vy: -15 - Math.random() * 25,
          life: 12,
          maxLife: 12,
          color: '#cbd5e155',
          size: 3 + Math.random() * 3,
          type: 'smoke',
        });
      }

      // Move Rivals relative to player speed
      eng.rivals.forEach((rival) => {
        rival.x -= (eng.raceSpeed - rival.baseSpeed) * dt * 1.5;
        if (!rival.passed && playerCarX > rival.x) {
          rival.passed = true;
          eng.racePosition = Math.max(1, eng.racePosition - 1);
          sounds.playCarHorn();
          addFloatingText(eng.W * 0.35, eng.raceY - 45, `تجاوزت ${rival.name}! 🚀`, '#fef08a');
          eng.say(`المعلم تجاوز ${rival.name}! المركز ${eng.racePosition} 🏆`);
        }
      });

      // Move Pickups & Check Collision
      eng.roadPickups.forEach((item) => {
        item.x -= (eng.raceSpeed * 0.85) * dt * 1.5;
        if (!item.collected && Math.abs(item.x - playerCarX) < 42 && eng.raceLane === item.lane) {
          item.collected = true;
          if (item.type === 'nitro') {
            eng.raceNitro = Math.min(100, eng.raceNitro + 40);
            raceActivateNitro();
          } else {
            sounds.playRaceCoin();
            addFloatingText(playerCarX, eng.raceY - 35, '+100 صامولة ذهبية! 🪙', '#fde047');
          }
        }
      });

      // Move Obstacles & Check Collision
      eng.roadObstacles.forEach((obs) => {
        obs.x -= (eng.raceSpeed * 0.85) * dt * 1.5;
        if (!obs.hit && Math.abs(obs.x - playerCarX) < 38 && eng.raceLane === obs.lane) {
          obs.hit = true;
          eng.raceSpeed = Math.max(140, eng.raceSpeed - 65);
          eng.shake = 8;
          eng.shakePower = 5;
          sounds.playHurt();
          addFloatingText(playerCarX, eng.raceY - 35, 'مطب! ⚠️', '#fb7185');
        }
      });

      // Finish Line Crossing
      if (eng.raceDistance <= 0) {
        eng.raceFinished = true;
        eng.racePosition = 1;

        if (!eng.raceWinnerCelebrated) {
          eng.raceWinnerCelebrated = true;
          sounds.playWinFanfare();
          sounds.playCarHorn();
          addFloatingText(eng.W * 0.5, eng.H * 0.35, '🏆 فوز كاسح! المركز الأول! 🥇', '#fef08a');
          eng.say(`مبروك يا معلم! فوز ساحق بـ ${eng.raceCar?.name}! 🥇🏆`);

          // Spawn celebratory fireworks & confetti
          for (let f = 0; f < 7; f++) {
            const fx = 100 + Math.random() * (eng.W - 200);
            const fy = 80 + Math.random() * (eng.H * 0.35);
            const sparks: Array<{ x: number; y: number; vx: number; vy: number; life: number; color: string }> = [];
            const col = ['#fde047', '#38bdf8', '#f43f5e', '#a855f7', '#4ade80'][f % 5];
            for (let s = 0; s < 18; s++) {
              const ang = (Math.PI * 2 * s) / 18;
              const spd = 60 + Math.random() * 110;
              sparks.push({
                x: fx,
                y: fy,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd,
                life: 35 + Math.floor(Math.random() * 20),
                color: col,
              });
            }
            eng.raceFireworks.push({ x: fx, y: fy, color: col, sparks });
          }

          for (let c = 0; c < 60; c++) {
            eng.raceEffects.push({
              x: Math.random() * eng.W,
              y: -10 - Math.random() * 100,
              vx: (Math.random() - 0.5) * 80,
              vy: 70 + Math.random() * 120,
              life: 80,
              maxLife: 80,
              color: ['#f43f5e', '#fbbf24', '#38bdf8', '#4ade80', '#e879f9'][c % 5],
              size: 4 + Math.random() * 4,
              type: 'confetti',
            });
          }
        }

        eng.raceWinCelebrationTimer += dt;
        if (eng.raceWinCelebrationTimer > 3.2) {
          eng.racing = false;
          eng.won = true;
          setIsRacing(false);
          setShowRewardModal(true);
        }
      }

      // Update Effects & Fireworks
      eng.raceEffects.forEach((ef) => {
        ef.x += ef.vx * dt;
        ef.y += ef.vy * dt;
        ef.life--;
      });
      eng.raceEffects = eng.raceEffects.filter((ef) => ef.life > 0);

      eng.raceFireworks.forEach((fw) => {
        fw.sparks.forEach((sp) => {
          sp.x += sp.vx * dt;
          sp.y += sp.vy * dt;
          sp.vy += 60 * dt; // gravity
          sp.life--;
        });
        fw.sparks = fw.sparks.filter((sp) => sp.life > 0);
      });
      eng.raceFireworks = eng.raceFireworks.filter((fw) => fw.sparks.length > 0);

      // Periodically sync telemetry to state
      if (Math.floor(eng.raceTime * 20) % 3 === 0) {
        setRaceSpeedDisplay(Math.round(eng.raceSpeed));
        setRaceDistanceDisplay(Math.max(0, Math.round(eng.raceDistance)));
        setRacePositionDisplay(eng.racePosition);
        setRaceNitroDisplay(Math.round(eng.raceNitro));
      }
    }

    // Main Game Update
    function update(dt: number) {
      if (eng.racing) {
        updateRace(dt);
        return;
      }
      if (eng.won) return;
      const { p } = eng;

      // Horizontal movement
      const prevFace = p.face;
      p.vx = 0;
      if (eng.keys.left) {
        p.vx = -245;
        p.face = -1;
      }
      if (eng.keys.right) {
        p.vx = 245;
        p.face = 1;
      }
      p.x = Math.max(0, Math.min(eng.WW - p.w, p.x + p.vx * dt));

      // Skid puff on sharp turnaround
      if (prevFace !== p.face && Math.abs(p.vx) > 10 && p.ground) {
        for (let i = 0; i < 5; i++) {
          eng.particles.push({
            x: p.x + p.w / 2,
            y: gy() - 4,
            vx: -p.face * (40 + Math.random() * 60),
            vy: -20 - Math.random() * 40,
            life: 14,
            color: '#e2e8f0',
            isDust: true,
            size: 3
          });
        }
      }

      // Walking cycle & Running dust
      if (Math.abs(p.vx) > 10 && p.ground) {
        eng.walkCycle += dt * 14;
        if (Math.random() < 0.25) {
          eng.particles.push({
            x: p.x + p.w / 2 - p.face * 16,
            y: gy() - 4,
            vx: -p.face * 30,
            vy: -15,
            life: 12,
            color: '#cbd5e1',
            isDust: true,
            size: 2.5
          });
        }
      } else {
        eng.walkCycle = 0;
      }

      // Vertical physics
      const prevBottom = p.y + p.h;
      p.vy += 1450 * dt;
      p.y += p.vy * dt;

      const wasGround = p.ground;
      p.ground = false;

      // Platform & Ground Collision
      if (p.vy >= 0) {
        if (p.y + p.h >= gy() && solid(p.x + p.w / 2)) {
          p.y = gy() - p.h;
          p.vy = 0;
          p.ground = true;
        } else {
          for (const a of eng.platforms) {
            if (
              p.x + p.w - 5 > a.x &&
              p.x + 5 < a.x + a.w &&
              prevBottom <= a.y + 10 &&
              p.y + p.h >= a.y
            ) {
              p.y = a.y - p.h;
              p.vy = 0;
              p.ground = true;
              break;
            }
          }
        }
      }

      // Landing squash & dust
      if (!wasGround && p.ground) {
        eng.landSquash = 1.0;
        for (let i = 0; i < 8; i++) {
          eng.particles.push({
            x: p.x + p.w / 2 + (Math.random() - 0.5) * 24,
            y: gy() - 4,
            vx: (Math.random() - 0.5) * 110,
            vy: -30,
            life: 15,
            color: '#cbd5e1',
            isDust: true,
            size: 3
          });
        }
      }
      if (eng.landSquash > 0) {
        eng.landSquash = Math.max(0, eng.landSquash - dt * 6);
      }

      // Touch / run-into crate opening check
      openCratesAt(p.x + p.w / 2, p.y + p.h / 2, 50, 65);

      // Pit fall
      if (p.y > gy() + 150) {
        p.hp--;
        p.x = Math.max(20, p.x - 120);
        p.y = gy() - 130;
        p.vy = 0;
        p.inv = 80;
        sounds.playHurt();
        eng.updateHud();
        addFloatingText(p.x + p.w / 2, p.y - 10, 'سقطت في الحفرة! ⚠️', '#ef4444');
      }

      if (p.inv > 0) p.inv--;

      // --- ATTACK TIMING & KINEMATICS ---
      if (p.atk > 0) {
        p.atk--;
        const progress = 1 - p.atk / p.atkMax;

        if (progress < 0.28) {
          p.atkPhase = 'windup';
        } else if (progress < 0.52) {
          p.atkPhase = 'strike';
        } else if (progress < 0.68) {
          p.atkPhase = 'impact';
        } else {
          p.atkPhase = 'recovery';
        }

        if (progress >= 0.48 && !p.hasImpacted && (p.weapon === 'hammer' || p.weapon === 'wrench')) {
          p.hasImpacted = true;
          const range = p.weapon === 'hammer' ? 125 : 110;
          const hitX = p.x + p.w / 2 + p.face * (p.weapon === 'hammer' ? 36 : 28);
          const hitY = p.y + (p.weapon === 'hammer' ? 22 : 18);

          // Impact Sparks & Shockwave
          addShockwave(hitX, gy() - 4, p.weapon === 'hammer' ? '#fef08a' : '#38bdf8', p.weapon === 'hammer' ? 75 : 50);

          for (let sp = 0; sp < 14; sp++) {
            eng.particles.push({
              x: hitX + (Math.random() - 0.5) * 10,
              y: hitY + (Math.random() - 0.5) * 10,
              vx: p.face * (80 + Math.random() * 160),
              vy: -60 - Math.random() * 120,
              life: 25,
              color: sp % 3 === 0 ? '#ffffff' : sp % 2 === 0 ? '#fde047' : '#f97316',
              size: 3 + Math.random() * 3,
              isSpark: true,
            });
          }

          if (p.weapon === 'hammer') {
            eng.shake = 16;
            eng.shakePower = 8;
            sounds.playHammer();
            addFloatingText(hitX, hitY - 20, 'ضربة معلم! 🔨', '#fef08a');
            for (let i = 0; i < 16; i++) {
              eng.particles.push({
                x: p.x + p.w / 2 + (Math.random() - 0.5) * 140,
                y: gy() - 8,
                vx: (Math.random() - 0.5) * 220,
                vy: -Math.random() * 200,
                life: 26,
                color: i % 2 ? '#f6d46d' : '#d9b58a',
                size: 4,
              });
            }
          } else {
            eng.shake = 10;
            eng.shakePower = 5;
            sounds.playWrench();
            addFloatingText(hitX, hitY - 20, 'شدة بمفتاح! 🔧', '#38bdf8');
          }

          const opened = openNearbyCrate();

          eng.foes.forEach((e) => {
            if (!e.alive) return;
            const dx = e.x + 20 - (p.x + 19);
            const isInFront = dx * p.face > 0;
            if (isInFront && Math.abs(dx) < range && Math.abs(e.y - p.y) < 125) {
              const enemyCenterX = e.x + (e.w || 42) / 2;
              const enemyCenterY = e.y + (e.h || 38) / 2;

              // Heavy punch impact feedback: knockback, hit flash, camera shake
              e.x += p.face * 22;
              e.hitFlash = 10;
              eng.shake = Math.max(eng.shake, p.weapon === 'hammer' ? 15 : 10);
              eng.shakePower = p.weapon === 'hammer' ? 7.5 : 4.5;

              if (e.kind === 2 && e.shield > 0) {
                e.shield = 0;
                sounds.playHammer();
                spawnWeaponHitParticles(enemyCenterX, enemyCenterY, p.weapon, p.face, true, false);
                addFloatingText(enemyCenterX, e.y - 18, 'تحطم الدرع! 🛡️💥', '#38bdf8');
                eng.say('الوحش الحجري درعه اتكسر! اضربه كمان ضربة');
              } else {
                e.hp--;
                if (e.hp <= 0) {
                  e.alive = false;
                  sounds.playExplosion();
                  spawnWeaponHitParticles(enemyCenterX, enemyCenterY, p.weapon, p.face, false, true);
                  addFloatingText(enemyCenterX, e.y - 18, 'سقط الوحش! 💥💀', '#ff4444');
                } else {
                  if (p.weapon === 'hammer') sounds.playHammer(); else sounds.playWrench();
                  spawnWeaponHitParticles(enemyCenterX, enemyCenterY, p.weapon, p.face, false, false);
                  addFloatingText(
                    enemyCenterX,
                    e.y - 18,
                    p.weapon === 'hammer' ? 'ضربة ساحقة! 🔨⚡' : 'صعقة مفتاح! 🔧⚡',
                    p.weapon === 'hammer' ? '#fde047' : '#38bdf8'
                  );
                }
              }
            }
          });
        }
      } else {
        p.atkPhase = 'none';
        p.hasImpacted = false;
      }

      // Collect parts
      eng.parts.forEach((a) => {
        if (!a.got && Math.abs(a.x - (p.x + 19)) < 48 && Math.abs(a.y - (p.y + 25)) < 75) {
          a.got = true;
          sounds.playPickup();
          addShockwave(a.x, a.y, '#fef08a', 45);
          addFloatingText(a.x, a.y - 20, `+ قطعة ${a.type}! ✨`, '#a3ed76');
          eng.updateHud();
          eng.say(`عاش يا معلم سردينه! جمعت ${a.type} ⚙️`);
        }
      });

      // Monster Updates with Unique Behaviors
      eng.foes.forEach((e) => {
        if (!e.alive) return;
        
        // Horizontal patrol
        const speed = e.kind === 4 ? 85 : e.kind === 6 ? 26 : e.kind === 2 ? 30 : 50;
        e.x += e.dir * speed * dt;
        if (e.x < 100 || e.x > eng.WW - 300) e.dir *= -1;

        // Specific Monster Mechanics:
        if (e.kind === 1) { // 1: Hopper Imp
          e.phase += dt * 4;
          e.y = gy() - 38 - Math.max(0, Math.sin(e.phase)) * 45;
        } else if (e.kind === 5) { // 5: Flying Gargoyle
          e.phase += dt * 3.5;
          e.y = (e.baseY || gy() - 100) - 80 + Math.sin(e.phase) * 55;
        } else if (e.kind === 4) { // 4: Saw Bot (Charges and emits sparks)
          e.y = gy() - 38;
          if (Math.random() < 0.3) {
            eng.particles.push({
              x: e.x + 20,
              y: gy() - 5,
              vx: (Math.random() - 0.5) * 80,
              vy: -Math.random() * 50,
              life: 12,
              color: '#38bdf8',
              isSpark: true,
              size: 2.5
            });
          }
        } else if (e.kind === 3) { // 3: Flame Spitter
          e.y = gy() - 38;
          e.cool -= dt * 60;
          if (e.cool <= 0 && Math.abs(p.x - e.x) < 320) {
            eng.particles.push({
              x: e.x + 20,
              y: e.y + 18,
              vx: (p.x < e.x ? -1 : 1) * 140,
              vy: -25,
              life: 48,
              color: '#ff6a27',
              fireball: true,
              size: 10,
            });
            e.cool = 130;
          }
        } else if (e.kind === 6) { // 6: Giant Tin Golem
          e.y = gy() - 54;
          e.cool -= dt * 60;
          if (e.cool <= 0 && Math.abs(p.x - e.x) < 400) {
            // Stomp ground wave!
            eng.shake = 12;
            eng.shakePower = 6;
            addShockwave(e.x + 20, gy() - 4, '#ef4444', 60);
            addFloatingText(e.x + 20, e.y - 15, 'هزة الغول! ⚡', '#ef4444');
            eng.particles.push({
              x: e.x + 20,
              y: gy() - 8,
              vx: (p.x < e.x ? -1 : 1) * 180,
              vy: 0,
              life: 60,
              color: '#f97316',
              shockwaveWave: true,
              size: 14
            });
            e.cool = 160;
          }
        } else if (e.kind === 2) { // 2: Shield Brute / Rock Monster
          e.y = gy() - 38;
          if (Math.random() < 0.16) {
            eng.particles.push({
              x: e.x + 8 + Math.random() * 24,
              y: gy() - 4,
              vx: (Math.random() - 0.5) * 35,
              vy: -10 - Math.random() * 20,
              life: 14,
              color: Math.random() > 0.4 ? '#fb923c' : '#94a3b8',
              isSpark: true,
              size: 2.5
            });
          }
        } else if (e.kind === 7) { // 7: Slime
          e.y = gy() - 38;
          e.phase += dt * 3;
        } else {
          e.y = gy() - 38;
        }

        // Collision with player
        if (p.inv <= 0 && Math.abs(p.x + p.w / 2 - (e.x + 20)) < 26 && Math.abs(p.y + p.h / 2 - (e.y + 20)) < 30) {
          p.hp--;
          p.inv = 90;
          p.vy = -270;
          sounds.playHurt();
          eng.updateHud();
          addFloatingText(p.x + p.w / 2, p.y - 15, 'إصابة! ❤️-', '#ef4444');
          eng.say('خلي بالك يا معلم!');
          if (p.hp <= 0) {
            p.hp = 3;
            p.x = 40;
            p.y = gy() - p.h;
            p.inv = 100;
            eng.updateHud();
            eng.say('رجعت من أول الطريق — شد حيلك يا بطل!');
          }
        }
      });

      // Particle physics & collision
      eng.particles.forEach((a) => {
        if (a.nut) {
          const hit = eng.foes.find(
            (e) => e.alive && Math.abs(e.x + 20 - a.x) < 32 && Math.abs(e.y + 20 - a.y) < 35
          );
          if (hit || a.life < 3) {
            eng.shake = 15;
            eng.shakePower = 9;
            sounds.playExplosion();
            addShockwave(a.x, a.y, '#f59e0b', 80);
            addFloatingText(a.x, a.y - 20, 'انفجار صامولة! 💥', '#fef08a');

            for (let i = 0; i < 22; i++) {
              eng.particles.push({
                x: a.x,
                y: a.y,
                vx: (Math.random() - 0.5) * 300,
                vy: -Math.random() * 260,
                life: 32,
                color: i % 2 ? '#ffb52e' : '#ff442e',
                size: 4 + Math.random() * 3,
              });
            }
            eng.foes.forEach((e) => {
              if (e.alive && Math.abs(e.x - a.x) < 110 && Math.abs(e.y - a.y) < 95) {
                if (e.kind === 2 && e.shield > 0) e.shield = 0;
                else {
                  e.hp -= 2;
                  if (e.hp <= 0) e.alive = false;
                }
              }
            });
            openCratesAt(a.x, a.y, 140, 140);
            a.life = 0;
          }
        }

        if (a.fireball && p.inv <= 0 && Math.abs(a.x - (p.x + p.w / 2)) < 24 && Math.abs(a.y - (p.y + 30)) < 30) {
          p.hp = Math.max(0, p.hp - 1);
          p.inv = 90;
          sounds.playHurt();
          eng.updateHud();
          addFloatingText(p.x + p.w / 2, p.y - 10, 'كرة نار! 🔥', '#f97316');
          a.life = 0;
        }

        if (a.shockwaveWave && p.inv <= 0 && p.ground && Math.abs(a.x - (p.x + p.w / 2)) < 26) {
          p.hp = Math.max(0, p.hp - 1);
          p.inv = 90;
          p.vy = -280;
          sounds.playHurt();
          eng.updateHud();
          addFloatingText(p.x + p.w / 2, p.y - 10, 'هزة أرضية! ⚡', '#f97316');
          a.life = 0;
        }
      });

      eng.particles = eng.particles.filter((a) => {
        a.x += a.vx * dt;
        a.y += a.vy * dt;
        if (!a.shockwaveWave) a.vy += (a.isDebris ? 520 : 380) * dt;
        if (a.vRot) a.rot = (a.rot || 0) + a.vRot * dt;
        a.life--;
        return a.life > 0;
      });

      // Update Shockwaves
      eng.shockwaves.forEach((sw) => {
        sw.r += dt * 180;
        sw.alpha = Math.max(0, 1 - sw.r / sw.maxR);
      });
      eng.shockwaves = eng.shockwaves.filter((sw) => sw.alpha > 0.05);

      // Update Floating Texts
      eng.floatingTexts.forEach((ft) => {
        ft.y -= dt * 35;
        ft.life--;
      });
      eng.floatingTexts = eng.floatingTexts.filter((ft) => ft.life > 0);

      // Camera Tracking in both X and Y with smooth damping & zoom
      const viewW = eng.W / eng.zoom;
      const viewH = eng.H / eng.zoom;
      const targetGroundScreenY = eng.H - 120;
      const baseCamY = gy() - targetGroundScreenY / eng.zoom;

      let targetCamY = baseCamY;
      if (p.y < gy() - 120) {
        targetCamY = Math.min(baseCamY, p.y + p.h / 2 - viewH * 0.55);
      }
      eng.camY += (targetCamY - eng.camY) * 0.12;

      const targetCamX = Math.max(0, Math.min(eng.WW - viewW, p.x + p.w / 2 - viewW * 0.42));
      eng.camX += (targetCamX - eng.camX) * 0.15;
      eng.cam = eng.camX;

      // Workshop & Win Condition
      if (p.x > eng.WW - 390) {
        if (eng.parts.every((a) => a.got)) {
          eng.carBuilt = true;
          eng.updateHud();
          eng.say('كل القطع وصلت! ادخل الورشة واستلم عربيتك 🚗');
          if (p.x > eng.WW - 160 && !eng.racing && !eng.won) {
            const carIdx = (eng.level - 1) % CAR_REWARDS.length;
            const rewardCar = CAR_REWARDS[carIdx];
            setLatestRewardCar(rewardCar);
            unlockCar(rewardCar.id);
            startCarRace(rewardCar);
          }
        } else {
          eng.say(`الورشة قدامك! باقي ${eng.parts.filter((a) => !a.got).length} قطع غيار`);
        }
      }
    }

    // Dynamic Multi-Theme Sky & Diverse Backgrounds
    function renderSky() {
      const theme = WORLD_THEMES.find((w) => w.id === eng.world) || WORLD_THEMES[0];
      const g = ctx!.createLinearGradient(0, 0, 0, eng.H);
      g.addColorStop(0, theme.skyTop);
      g.addColorStop(0.55, theme.skyMid);
      g.addColorStop(1, theme.skyBottom);
      ctx!.fillStyle = g;
      ctx!.fillRect(0, 0, eng.W, eng.H);

      const screenGY = (gy() - eng.camY) * eng.zoom;

      // --- WORLD 1: OLD WORKSHOP ALLEY (حارة الورشة القديمة) ---
      if (eng.world === 1) {
        // Distant city silhouette
        ctx!.fillStyle = 'rgba(74, 52, 60, 0.35)';
        for (let i = 0; i < 9; i++) {
          const bx = i * 160 - ((eng.cam * 0.08) % 160);
          const bh = 110 + (i % 4) * 35;
          ctx!.fillRect(bx, screenGY - bh, 120, bh);
          // Chimneys puffing smoke
          if (i % 2 === 0) {
            ctx!.fillRect(bx + 20, screenGY - bh - 25, 14, 25);
            const smokeX = bx + 27 + Math.sin(Date.now() / 600 + i) * 6;
            ctx!.fillStyle = 'rgba(255, 255, 255, 0.25)';
            ctx!.beginPath();
            ctx!.arc(smokeX, screenGY - bh - 35, 12, 0, Math.PI * 2);
            ctx!.arc(smokeX + 10, screenGY - bh - 55, 18, 0, Math.PI * 2);
            ctx!.fill();
            ctx!.fillStyle = 'rgba(74, 52, 60, 0.35)';
          }
        }

        // Fluffy Sunset Clouds
        for (let i = 0; i < 5; i++) {
          const cx = (((i * 240 - eng.cam * 0.12) % (eng.W + 200)) + eng.W + 200) % (eng.W + 200);
          const cy = 70 + (i % 3) * 40;
          ctx!.fillStyle = '#ffffffd0';
          ctx!.beginPath();
          ctx!.ellipse(cx, cy, 38, 16, 0, 0, Math.PI * 2);
          ctx!.ellipse(cx + 22, cy - 8, 30, 24, 0, 0, Math.PI * 2);
          ctx!.ellipse(cx + 44, cy + 2, 32, 15, 0, 0, Math.PI * 2);
          ctx!.fill();
        }

        // Warm ambient dust particles
        for (let i = 0; i < 15; i++) {
          const dx = (Math.sin(Date.now() / 1000 + i * 2) * 50 + i * 90) % eng.W;
          const dy = 50 + (i * 35) % (eng.H - 150);
          ctx!.fillStyle = 'rgba(254, 240, 138, 0.4)';
          ctx!.beginPath();
          ctx!.arc(dx, dy, 2, 0, Math.PI * 2);
          ctx!.fill();
        }
      }

      // --- WORLD 2: DESERT SCRAPYARD (وادي الخردة والصحراء) ---
      else if (eng.world === 2) {
        // Distant Pyramids & Mesa Ridge
        for (let i = 0; i < 4; i++) {
          const px = i * 360 - ((eng.cam * 0.07) % 360);
          const py = screenGY + 10;
          ctx!.fillStyle = 'rgba(180, 83, 9, 0.45)';
          ctx!.beginPath();
          ctx!.moveTo(px - 140, py);
          ctx!.lineTo(px, py - 180 - (i % 2) * 40);
          ctx!.lineTo(px + 140, py);
          ctx!.closePath();
          ctx!.fill();
        }

        // Midground Dunes with Abandoned Gears & Wrecks
        for (let i = 0; i < 6; i++) {
          const dx = i * 260 - ((eng.cam * 0.18) % 260);
          const dy = screenGY + 10;
          ctx!.fillStyle = 'rgba(217, 119, 6, 0.7)';
          ctx!.beginPath();
          ctx!.ellipse(dx, dy, 220, 95, 0, Math.PI, Math.PI * 2);
          ctx!.fill();

          // Half-buried giant gear
          if (i % 2 === 1) {
            ctx!.strokeStyle = 'rgba(120, 53, 15, 0.8)';
            ctx!.lineWidth = 8;
            ctx!.beginPath();
            ctx!.arc(dx + 40, dy - 40, 35, 0, Math.PI * 2);
            ctx!.stroke();
          }
        }

        // Blowing golden sand specks
        for (let i = 0; i < 24; i++) {
          const sx = (Date.now() / 6 + i * 70) % eng.W;
          const sy = 100 + (i * 38) % (eng.H - 160);
          ctx!.fillStyle = 'rgba(254, 243, 199, 0.65)';
          ctx!.fillRect(sx, sy, 3, 1.5);
        }
      }

      // --- WORLD 3: CYBERPUNK NEON METROPOLIS (مدينة النيون) ---
      else if (eng.world === 3) {
        // Holographic Cyber Sky Grid
        ctx!.strokeStyle = 'rgba(99, 102, 241, 0.15)';
        ctx!.lineWidth = 1;
        for (let ly = 40; ly < eng.H - 100; ly += 30) {
          ctx!.beginPath();
          ctx!.moveTo(0, ly);
          ctx!.lineTo(eng.W, ly);
          ctx!.stroke();
        }

        // Neon Skyscrapers with glowing windows
        for (let i = 0; i < 8; i++) {
          const sx = i * 140 - ((eng.cam * 0.1) % 140);
          const sh = 160 + (i % 5) * 45;
          ctx!.fillStyle = '#0f172a';
          ctx!.fillRect(sx, screenGY - sh, 90, sh);
          ctx!.strokeStyle = i % 2 === 0 ? '#06b6d4' : '#ec4899';
          ctx!.lineWidth = 1.5;
          ctx!.strokeRect(sx, screenGY - sh, 90, sh);

          // Random cyber windows
          for (let wy = screenGY - sh + 15; wy < screenGY - 20; wy += 20) {
            for (let wx = sx + 12; wx < sx + 75; wx += 18) {
              if ((wx + wy) % 3 === 0) {
                ctx!.fillStyle = i % 2 === 0 ? '#38bdf8' : '#f472b6';
                ctx!.fillRect(wx, wy, 8, 8);
              }
            }
          }
        }

        // Distant flying hovercars with neon light streaks
        const hx = ((Date.now() / 4) % (eng.W + 200)) - 100;
        ctx!.fillStyle = '#22d3ee';
        ctx!.fillRect(hx, 110, 30, 4);
        ctx!.fillStyle = 'rgba(34, 211, 238, 0.4)';
        ctx!.fillRect(hx - 50, 111, 50, 2);
      }

      // --- WORLD 4: VOLCANIC MECHANICAL CITADEL (قلعة الميكانيكا) ---
      else if (eng.world === 4) {
        // Colossal rotating brass gears in sky
        const angle = Date.now() / 1500;
        ctx!.save();
        ctx!.translate(eng.W * 0.75, 130);
        ctx!.rotate(angle);
        ctx!.strokeStyle = 'rgba(217, 119, 6, 0.35)';
        ctx!.lineWidth = 16;
        ctx!.beginPath();
        ctx!.arc(0, 0, 90, 0, Math.PI * 2);
        ctx!.stroke();
        for (let g = 0; g < 8; g++) {
          ctx!.rotate(Math.PI / 4);
          ctx!.fillStyle = 'rgba(217, 119, 6, 0.35)';
          ctx!.fillRect(-12, -115, 24, 25);
        }
        ctx!.restore();

        // Dark fortress towers & glowing volcanic magma fissures
        for (let i = 0; i < 7; i++) {
          const fx = i * 200 - ((eng.cam * 0.12) % 200);
          const fh = 140 + (i % 3) * 50;
          ctx!.fillStyle = '#171717';
          ctx!.beginPath();
          ctx!.moveTo(fx - 40, screenGY);
          ctx!.lineTo(fx, screenGY - fh);
          ctx!.lineTo(fx + 70, screenGY);
          ctx!.closePath();
          ctx!.fill();
          // Lava cracks
          ctx!.strokeStyle = '#f97316';
          ctx!.lineWidth = 2;
          ctx!.beginPath();
          ctx!.moveTo(fx, screenGY - fh);
          ctx!.lineTo(fx + 10, screenGY - fh / 2);
          ctx!.lineTo(fx - 5, screenGY);
          ctx!.stroke();
        }

        // Rising embers
        for (let i = 0; i < 20; i++) {
          const ex = (Math.sin(Date.now() / 800 + i) * 30 + i * 75) % eng.W;
          const ey = eng.H - ((Date.now() / 15 + i * 40) % (eng.H - 50));
          ctx!.fillStyle = i % 2 === 0 ? '#ef4444' : '#f59e0b';
          ctx!.beginPath();
          ctx!.arc(ex, ey, 2.5, 0, Math.PI * 2);
          ctx!.fill();
        }
      }
    }

    // Ground & Level Platforms
    function renderGround() {
      const theme = WORLD_THEMES.find((w) => w.id === eng.world) || WORLD_THEMES[0];
      const y = gy();

      // Base soil (deep fill to prevent any lower gap)
      ctx!.fillStyle = theme.groundBase;
      ctx!.fillRect(0, y, eng.WW, 600);

      // Stylized soil bricks
      for (let x = 0; x < eng.WW; x += 42) {
        if (!solid(x + 20)) continue;
        ctx!.fillStyle = 'rgba(0,0,0,0.15)';
        ctx!.fillRect(x, y + 13, 42, 38);
        ctx!.strokeStyle = 'rgba(255,255,255,0.06)';
        ctx!.lineWidth = 1.5;
        ctx!.strokeRect(x + 1, y + 14, 40, 35);
      }

      // Top grass / surface trim
      ctx!.fillStyle = theme.groundGrass;
      ctx!.fillRect(0, y, eng.WW, 13);
      ctx!.fillStyle = theme.groundEdge;
      ctx!.fillRect(0, y, eng.WW, 4);

      // Level Gaps (Hazards)
      for (const g of eng.gaps) {
        ctx!.fillStyle = '#0f172a';
        ctx!.fillRect(g[0], y, g[1] - g[0], 600);
        // Animated hazard warning stripes
        ctx!.fillStyle = theme.groundGrass;
        ctx!.fillRect(g[0] - 5, y, g[1] - g[0] + 10, 6);
      }

      // Floating Platforms
      for (const a of eng.platforms) {
        const px = a.x;
        const py = a.y;
        ctx!.fillStyle = theme.groundBase;
        ctx!.beginPath();
        ctx!.roundRect(px, py, 100, 26, 5);
        ctx!.fill();
        ctx!.fillStyle = theme.groundGrass;
        ctx!.fillRect(px, py, 100, 8);
        ctx!.fillStyle = theme.groundEdge;
        ctx!.fillRect(px + 4, py, 92, 3);
        ctx!.strokeStyle = '#00000033';
        ctx!.lineWidth = 2;
        ctx!.strokeRect(px + 1, py + 2, 98, 22);
      }

      // Render All Real Mystery Crates
      eng.crates.forEach((cb) => {
        if (!cb.opened) {
          ctx!.fillStyle = '#8e4a26';
          ctx!.beginPath();
          ctx!.roundRect(cb.x, cb.y, 31, 31, 4);
          ctx!.fill();
          ctx!.fillStyle = '#f5b941';
          ctx!.beginPath();
          ctx!.roundRect(cb.x + 3, cb.y + 3, 25, 25, 3);
          ctx!.fill();
          ctx!.fillStyle = '#fff7c5';
          ctx!.font = 'bold 22px Arial';
          ctx!.fillText('?', cb.x + 8, cb.y + 24);
        } else {
          ctx!.fillStyle = '#85502e';
          ctx!.beginPath();
          ctx!.roundRect(cb.x, cb.y + 11, 31, 20, 3);
          ctx!.fill();
          ctx!.fillStyle = '#bd8b4d';
          ctx!.fillRect(cb.x + 4, cb.y + 14, 23, 13);
        }
      });

      // Stone blocks at the end
      for (let x = 2440; x < eng.WW - 300; x += 65) {
        const yy = y - 20;
        ctx!.fillStyle = '#91b5bd';
        ctx!.beginPath();
        ctx!.roundRect(x, yy, 61, 24, 5);
        ctx!.fill();
        ctx!.fillStyle = '#c8e2e5';
        ctx!.fillRect(x + 4, yy + 3, 52, 6);
        ctx!.strokeStyle = '#64848d';
        ctx!.lineWidth = 2;
        ctx!.strokeRect(x + 1, yy + 1, 59, 21);
      }
    }

    // Render Monsters (8 Diverse Types)
    function renderEnemies() {
      eng.foes.forEach((e) => {
        if (!e.alive) return;
        ctx!.save();
        ctx!.translate(e.x, e.y);

        // Damage flash feedback
        if (e.hitFlash && e.hitFlash > 0) {
          e.hitFlash--;
          if (e.hitFlash % 2 === 0) {
            ctx!.filter = 'brightness(2.2) contrast(1.4)';
          }
        }

        // 0: Spiked Gear Beetle (خنفساء التروس)
        if (e.kind === 0) {
          ctx!.fillStyle = '#a83d43';
          ctx!.beginPath();
          ctx!.ellipse(21, 25, 21, 14, 0, 0, Math.PI * 2);
          ctx!.fill();
          for (let i = 0; i < 7; i++) {
            ctx!.fillStyle = i % 2 ? '#d45c57' : '#7d2736';
            ctx!.beginPath();
            ctx!.moveTo(3 + i * 6, 17);
            ctx!.lineTo(7 + i * 6, 2 + (i % 3) * 3);
            ctx!.lineTo(13 + i * 5, 18);
            ctx!.fill();
          }
          ctx!.fillStyle = '#fff0d6';
          ctx!.beginPath();
          ctx!.ellipse(13, 22, 6, 7, 0, 0, Math.PI * 2);
          ctx!.ellipse(27, 22, 6, 7, 0, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#26222a';
          ctx!.fillRect(14, 21, 3, 5);
          ctx!.fillRect(27, 21, 3, 5);
        }
        // 1: Hopping Scrap Imp (العفريت الوثاب)
        else if (e.kind === 1) {
          ctx!.fillStyle = '#7a32a9';
          ctx!.beginPath();
          ctx!.ellipse(21, 24, 20, 16, 0, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#f3e9ff';
          ctx!.beginPath();
          ctx!.ellipse(13, 22, 5, 7, 0, 0, Math.PI * 2);
          ctx!.ellipse(28, 22, 5, 7, 0, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#241631';
          ctx!.fillRect(14, 21, 3, 5);
          ctx!.fillRect(28, 21, 3, 5);
        }
        // 2: Shield Brute (الوحش الصخري المدرع / المتوهج)
        else if (e.kind === 2) {
          const mFace = e.dir > 0 ? 1 : -1;
          const pulse = 0.72 + Math.sin(Date.now() / 160 + e.x * 0.08) * 0.28;

          ctx!.save();
          // Center transformation around (21, 20) and face movement direction
          ctx!.translate(21, 20);
          ctx!.scale(mFace, 1);

          // 1. Ambient Volcanic Radiant Glow Aura ("زاهي")
          const auraGrad = ctx!.createRadialGradient(0, 0, 4, 0, 0, 26);
          auraGrad.addColorStop(0, `rgba(249, 115, 22, ${0.45 * pulse})`);
          auraGrad.addColorStop(0.6, `rgba(234, 88, 12, ${0.18 * pulse})`);
          auraGrad.addColorStop(1, 'rgba(234, 88, 12, 0)');
          ctx!.fillStyle = auraGrad;
          ctx!.beginPath();
          ctx!.arc(0, 0, 26, 0, Math.PI * 2);
          ctx!.fill();

          // 2. Heavy Chiseled Obsidian / Basalt Silhouette with Strong Contrast Outlines
          ctx!.fillStyle = '#090d16';
          ctx!.beginPath();
          ctx!.moveTo(-19, 18);
          ctx!.lineTo(-18, -6);
          ctx!.lineTo(-10, -18); // Back boulder crag
          ctx!.lineTo(2, -19);   // Crest ridge
          ctx!.lineTo(14, -13);  // Heavy brow peak
          ctx!.lineTo(20, -2);   // Forehead stone slab
          ctx!.lineTo(18, 18);   // Heavy stone base
          ctx!.closePath();
          ctx!.fill();

          // Dark Basalt Primary Body Slabs
          ctx!.fillStyle = '#1e293b';
          ctx!.beginPath();
          ctx!.moveTo(-17, 16);
          ctx!.lineTo(-16, -5);
          ctx!.lineTo(-9, -16);
          ctx!.lineTo(1, -17);
          ctx!.lineTo(12, -11);
          ctx!.lineTo(18, -1);
          ctx!.lineTo(16, 16);
          ctx!.closePath();
          ctx!.fill();

          // Crystalline / Granite Rock Facets (High Contrast Shading)
          ctx!.fillStyle = '#475569';
          ctx!.beginPath();
          ctx!.moveTo(-9, -16);
          ctx!.lineTo(1, -17);
          ctx!.lineTo(5, -6);
          ctx!.lineTo(-7, -4);
          ctx!.closePath();
          ctx!.fill();

          // Sharp bright edge highlight facet
          ctx!.fillStyle = '#94a3b8';
          ctx!.beginPath();
          ctx!.moveTo(-8, -15);
          ctx!.lineTo(0, -16);
          ctx!.lineTo(11, -11);
          ctx!.lineTo(6, -8);
          ctx!.closePath();
          ctx!.fill();

          // Back shadow boulder plate
          ctx!.fillStyle = '#0f172a';
          ctx!.beginPath();
          ctx!.moveTo(-17, -5);
          ctx!.lineTo(-7, -4);
          ctx!.lineTo(-6, 14);
          ctx!.lineTo(-17, 16);
          ctx!.closePath();
          ctx!.fill();

          // 3. Vivid Magma Fissures / Luminous Veins ("واضح وزاهي")
          ctx!.strokeStyle = '#ea580c';
          ctx!.lineWidth = 3.5;
          ctx!.lineCap = 'round';
          ctx!.lineJoin = 'round';
          ctx!.beginPath();
          ctx!.moveTo(-12, 6);
          ctx!.lineTo(-4, 2);
          ctx!.lineTo(4, 7);
          ctx!.lineTo(12, 4);
          ctx!.moveTo(2, -4);
          ctx!.lineTo(5, 5);
          ctx!.lineTo(3, 14);
          ctx!.stroke();

          // Blazing molten core
          ctx!.strokeStyle = '#fef08a';
          ctx!.lineWidth = 1.6;
          ctx!.beginPath();
          ctx!.moveTo(-12, 6);
          ctx!.lineTo(-4, 2);
          ctx!.lineTo(4, 7);
          ctx!.lineTo(12, 4);
          ctx!.moveTo(2, -4);
          ctx!.lineTo(5, 5);
          ctx!.lineTo(3, 14);
          ctx!.stroke();

          // 4. Intimidating Glowing Rocky Eyes ("واضح")
          // Deep carved stone eye sockets in pitch black
          ctx!.fillStyle = '#020617';
          ctx!.beginPath();
          ctx!.moveTo(5, -7);
          ctx!.lineTo(15, -5);
          ctx!.lineTo(14, 0);
          ctx!.lineTo(4, -1);
          ctx!.closePath();
          ctx!.fill();

          // Vivid Blazing Magma Eye directed forward
          ctx!.fillStyle = '#ff4500';
          ctx!.beginPath();
          ctx!.arc(10, -3.5, 3.8, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#facc15';
          ctx!.beginPath();
          ctx!.arc(10.5, -3.5, 2.5, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#ffffff';
          ctx!.beginPath();
          ctx!.arc(11.2, -4, 1.2, 0, Math.PI * 2);
          ctx!.fill();

          // Sharp stone brow ridge
          ctx!.strokeStyle = '#cbd5e1';
          ctx!.lineWidth = 2.2;
          ctx!.beginPath();
          ctx!.moveTo(4, -7.5);
          ctx!.lineTo(15, -5.5);
          ctx!.stroke();

          // 5. Jagged Stone Teeth / Molten Jaw
          ctx!.fillStyle = '#020617';
          ctx!.fillRect(6, 7, 10, 6);
          // Molten glow inside mouth
          ctx!.fillStyle = '#f97316';
          ctx!.fillRect(7, 9, 8, 3);
          ctx!.fillStyle = '#fef08a';
          ctx!.fillRect(8, 10, 6, 1.5);
          // Stone teeth
          ctx!.fillStyle = '#f1f5f9';
          ctx!.beginPath();
          ctx!.moveTo(7, 7);
          ctx!.lineTo(8.5, 9);
          ctx!.lineTo(10, 7);
          ctx!.lineTo(11.5, 9);
          ctx!.lineTo(13, 7);
          ctx!.fill();
          ctx!.beginPath();
          ctx!.moveTo(8, 13);
          ctx!.lineTo(9.5, 11);
          ctx!.lineTo(11, 13);
          ctx!.lineTo(12.5, 11);
          ctx!.lineTo(14, 13);
          ctx!.fill();

          // 6. Glowing Crystal Shoulder Spikes
          ctx!.fillStyle = '#f59e0b';
          ctx!.beginPath();
          ctx!.moveTo(-10, -16);
          ctx!.lineTo(-7, -24);
          ctx!.lineTo(-4, -15);
          ctx!.closePath();
          ctx!.fill();
          ctx!.fillStyle = '#fef08a';
          ctx!.beginPath();
          ctx!.moveTo(-7, -24);
          ctx!.lineTo(-5, -16);
          ctx!.lineTo(-7, -16);
          ctx!.closePath();
          ctx!.fill();

          ctx!.restore();

          // 7. Luminous Energy Shield (when shielded)
          if (e.shield) {
            const shieldPulse = 0.8 + Math.sin(Date.now() / 140) * 0.2;
            ctx!.save();
            // Luminous cyan dome
            ctx!.fillStyle = `rgba(56, 189, 248, ${0.18 * shieldPulse})`;
            ctx!.beginPath();
            ctx!.arc(21, 20, 26, 0, Math.PI * 2);
            ctx!.fill();

            // Double electric shield ring with animated dashes
            ctx!.strokeStyle = '#38bdf8';
            ctx!.lineWidth = 3.0;
            ctx!.beginPath();
            ctx!.arc(21, 20, 26, 0, Math.PI * 2);
            ctx!.stroke();

            ctx!.strokeStyle = 'rgba(255, 255, 255, 0.85)';
            ctx!.lineWidth = 1.5;
            ctx!.setLineDash([8, 6]);
            ctx!.lineDashOffset = -Date.now() / 40;
            ctx!.beginPath();
            ctx!.arc(21, 20, 28, 0, Math.PI * 2);
            ctx!.stroke();
            ctx!.setLineDash([]);

            // Shield Rune Nodes
            for (let sn = 0; sn < 4; sn++) {
              const ang = (Math.PI * 2 * sn) / 4 + Date.now() / 600;
              const sx = 21 + Math.cos(ang) * 26;
              const sy = 20 + Math.sin(ang) * 26;
              ctx!.fillStyle = '#fef08a';
              ctx!.beginPath();
              ctx!.arc(sx, sy, 3, 0, Math.PI * 2);
              ctx!.fill();
              ctx!.fillStyle = '#ffffff';
              ctx!.beginPath();
              ctx!.arc(sx, sy, 1.5, 0, Math.PI * 2);
              ctx!.fill();
            }

            // Overhead Shield Badge
            ctx!.fillStyle = '#0284c7';
            ctx!.beginPath();
            ctx!.roundRect(6, -14, 30, 12, 4);
            ctx!.fill();
            ctx!.strokeStyle = '#67e8f9';
            ctx!.lineWidth = 1.2;
            ctx!.stroke();
            ctx!.fillStyle = '#ffffff';
            ctx!.font = 'bold 8px Tahoma';
            ctx!.textAlign = 'center';
            ctx!.fillText('🛡️ مدرع', 21, -5);
            ctx!.textAlign = 'start';
            ctx!.restore();
          }
        }
        // 3: Flame Spitter (تنين الورشة الناري)
        else if (e.kind === 3) {
          ctx!.fillStyle = '#f08b2f';
          ctx!.beginPath();
          ctx!.ellipse(21, 21, 17, 15, 0, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#ef4444';
          ctx!.beginPath();
          ctx!.moveTo(32, 18);
          ctx!.lineTo(44, 15);
          ctx!.lineTo(34, 25);
          ctx!.closePath();
          ctx!.fill();
          ctx!.fillStyle = '#fff';
          ctx!.beginPath();
          ctx!.arc(15, 19, 5, 0, Math.PI * 2);
          ctx!.arc(28, 19, 5, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#3a1d17';
          ctx!.fillRect(16, 18, 3, 5);
          ctx!.fillRect(28, 18, 3, 5);
        }
        // 4: Electric Saw-Bot (وحش التروس الصاعق)
        else if (e.kind === 4) {
          ctx!.save();
          ctx!.translate(21, 19);
          ctx!.rotate(Date.now() / 100);
          ctx!.fillStyle = '#0284c7';
          ctx!.beginPath();
          ctx!.arc(0, 0, 18, 0, Math.PI * 2);
          ctx!.fill();
          // Saw blades
          ctx!.fillStyle = '#38bdf8';
          for (let sb = 0; sb < 8; sb++) {
            ctx!.rotate(Math.PI / 4);
            ctx!.fillRect(-3, -24, 6, 8);
          }
          ctx!.restore();
          // Glowing center eye
          ctx!.fillStyle = '#fef08a';
          ctx!.beginPath();
          ctx!.arc(21, 19, 6, 0, Math.PI * 2);
          ctx!.fill();
        }
        // 5: Flying Gargoyle (عفريت الخردة الطائر)
        else if (e.kind === 5) {
          const wingFlap = Math.sin(Date.now() / 120) * 12;
          ctx!.fillStyle = '#475569';
          ctx!.beginPath();
          ctx!.ellipse(21, 20, 16, 12, 0, 0, Math.PI * 2);
          ctx!.fill();
          // Metallic Wings
          ctx!.fillStyle = '#94a3b8';
          ctx!.beginPath();
          ctx!.moveTo(12, 18);
          ctx!.lineTo(-8, 8 - wingFlap);
          ctx!.lineTo(8, 25);
          ctx!.closePath();
          ctx!.fill();
          ctx!.beginPath();
          ctx!.moveTo(30, 18);
          ctx!.lineTo(50, 8 - wingFlap);
          ctx!.lineTo(34, 25);
          ctx!.closePath();
          ctx!.fill();
          // Menacing red eyes
          ctx!.fillStyle = '#ef4444';
          ctx!.beginPath();
          ctx!.arc(16, 17, 3, 0, Math.PI * 2);
          ctx!.arc(26, 17, 3, 0, Math.PI * 2);
          ctx!.fill();
        }
        // 6: Giant Tin Golem (غول الصفيح العملاق - ميني بوس)
        else if (e.kind === 6) {
          // Bulky Robot Golem Body
          ctx!.fillStyle = '#334155';
          ctx!.beginPath();
          ctx!.roundRect(4, 8, 48, 44, 6);
          ctx!.fill();
          // Chest Plate with Glowing Core
          ctx!.fillStyle = '#f59e0b';
          ctx!.beginPath();
          ctx!.arc(28, 26, 9, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#ef4444';
          ctx!.beginPath();
          ctx!.arc(28, 26, 5, 0, Math.PI * 2);
          ctx!.fill();
          // Head / Horns
          ctx!.fillStyle = '#1e293b';
          ctx!.fillRect(16, -2, 24, 12);
          ctx!.fillStyle = '#e2e8f0';
          ctx!.fillRect(20, 2, 6, 4);
          ctx!.fillRect(30, 2, 6, 4);
          // HP bar above boss
          ctx!.fillStyle = '#0f172a';
          ctx!.fillRect(4, -14, 48, 6);
          ctx!.fillStyle = '#22c55e';
          ctx!.fillRect(4, -14, (e.hp / e.maxHp) * 48, 6);
        }
        // 7: Toxic Slime (وحش الزيت والسم)
        else {
          const wobble = Math.sin(Date.now() / 180) * 3;
          ctx!.fillStyle = '#15803d';
          ctx!.beginPath();
          ctx!.ellipse(21, 24 + wobble / 2, 20 + wobble, 14 - wobble / 2, 0, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#4ade80';
          ctx!.beginPath();
          ctx!.arc(14, 18, 5, 0, Math.PI * 2);
          ctx!.arc(28, 18, 5, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#052e16';
          ctx!.fillRect(15, 17, 3, 4);
          ctx!.fillRect(29, 17, 3, 4);
        }

        ctx!.filter = 'none';
        ctx!.restore();
      });
    }

    // ==========================================
    // STAGE FINALE CAR RACE CANVAS RENDERER
    // ==========================================
    function renderRace() {
      // 1. Sky & Horizon
      const theme = WORLD_THEMES.find((w) => w.id === eng.world) || WORLD_THEMES[0];
      const skyGrad = ctx!.createLinearGradient(0, 0, 0, eng.H * 0.44);
      skyGrad.addColorStop(0, theme.skyTop);
      skyGrad.addColorStop(0.7, theme.skyMid);
      skyGrad.addColorStop(1, theme.skyBottom);
      ctx!.fillStyle = skyGrad;
      ctx!.fillRect(0, 0, eng.W, eng.H * 0.44);

      // Distant mountains / skyline scrolling
      ctx!.fillStyle = 'rgba(15, 23, 42, 0.45)';
      for (let i = 0; i < 10; i++) {
        const mx = i * 140 - ((eng.raceScroll * 0.08) % 140);
        const mh = 70 + (i % 4) * 25;
        ctx!.fillRect(mx, eng.H * 0.44 - mh, 110, mh);
      }

      // Highway Light Poles on side
      for (let p = 0; p < 7; p++) {
        const px = p * 150 - ((eng.raceScroll * 0.5) % 150);
        ctx!.fillStyle = '#475569';
        ctx!.fillRect(px, eng.H * 0.44 - 45, 4, 45);
        ctx!.fillRect(px, eng.H * 0.44 - 45, 18, 4);
        ctx!.fillStyle = '#fef08a';
        ctx!.beginPath();
        ctx!.arc(px + 18, eng.H * 0.44 - 42, 3.5, 0, Math.PI * 2);
        ctx!.fill();
      }

      // 2. Road Asphalt Surface
      const roadTop = eng.H * 0.44;
      const roadBottom = eng.H * 0.90;
      const roadH = roadBottom - roadTop;

      // Road background tarmac
      const roadGrad = ctx!.createLinearGradient(0, roadTop, 0, roadBottom);
      roadGrad.addColorStop(0, '#1e293b');
      roadGrad.addColorStop(0.5, '#0f172a');
      roadGrad.addColorStop(1, '#1e293b');
      ctx!.fillStyle = roadGrad;
      ctx!.fillRect(0, roadTop, eng.W, roadH);

      // Top & Bottom Red-White Curbs
      for (let c = 0; c < 30; c++) {
        const cx = c * 32 - ((eng.raceScroll * 1.5) % 32);
        const color = c % 2 === 0 ? '#ef4444' : '#f8fafc';
        ctx!.fillStyle = color;
        ctx!.fillRect(cx, roadTop - 7, 32, 7);
        ctx!.fillRect(cx, roadBottom, 32, 7);
      }

      // Metallic crash barriers with shadow
      ctx!.fillStyle = '#64748b';
      ctx!.fillRect(0, roadTop - 11, eng.W, 4);
      ctx!.fillRect(0, roadBottom + 7, eng.W, 4);

      // Dashed White Lane Divider Lines (2 lines for 3 lanes)
      const laneH = roadH / 3;
      for (let laneIdx = 1; laneIdx <= 2; laneIdx++) {
        const lineY = roadTop + laneIdx * laneH;
        ctx!.fillStyle = '#f8fafc';
        for (let d = 0; d < 25; d++) {
          const dx = d * 45 - ((eng.raceScroll * 2.2) % 45);
          ctx!.fillRect(dx, lineY - 2, 24, 4);
        }
      }

      // Finish Line Banner Arch approaching when near finish!
      if (eng.raceDistance < 90) {
        const finishX = eng.W * 0.22 + eng.raceDistance * 8;
        // Arch columns
        ctx!.fillStyle = '#0f172a';
        ctx!.fillRect(finishX - 8, roadTop - 65, 16, roadH + 75);
        ctx!.fillRect(finishX + 32, roadTop - 65, 16, roadH + 75);
        // Arch overhead truss
        ctx!.fillStyle = '#1e293b';
        ctx!.fillRect(finishX - 12, roadTop - 65, 64, 28);
        ctx!.strokeStyle = '#fbbf24';
        ctx!.lineWidth = 3;
        ctx!.strokeRect(finishX - 12, roadTop - 65, 64, 28);

        // Checkered finish banner on top
        for (let r = 0; r < 2; r++) {
          for (let c = 0; c < 6; c++) {
            ctx!.fillStyle = (r + c) % 2 === 0 ? '#000000' : '#ffffff';
            ctx!.fillRect(finishX - 10 + c * 10, roadTop - 63 + r * 12, 10, 12);
          }
        }
        // Banner text
        ctx!.fillStyle = '#fef08a';
        ctx!.font = 'bold 11px Tahoma';
        ctx!.textAlign = 'center';
        ctx!.fillText('خط النهاية 🏁', finishX + 20, roadTop - 40);
        ctx!.textAlign = 'start';
      }

      // 3. Render Pickups
      eng.roadPickups.forEach((item) => {
        if (item.collected || item.x < -40 || item.x > eng.W + 40) return;
        const iy = getLaneY(item.lane);
        const bob = Math.sin(Date.now() / 200 + item.x) * 4;

        if (item.type === 'nitro') {
          // Glowing Nitro canister
          ctx!.fillStyle = 'rgba(56, 189, 248, 0.4)';
          ctx!.beginPath();
          ctx!.arc(item.x, iy + bob, 16, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.font = '24px sans-serif';
          ctx!.textAlign = 'center';
          ctx!.fillText('⚡', item.x, iy + 8 + bob);
        } else {
          // Gold coin
          ctx!.fillStyle = 'rgba(250, 204, 21, 0.45)';
          ctx!.beginPath();
          ctx!.arc(item.x, iy + bob, 14, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.font = '22px sans-serif';
          ctx!.textAlign = 'center';
          ctx!.fillText('🪙', item.x, iy + 7 + bob);
        }
        ctx!.textAlign = 'start';
      });

      // 4. Render Obstacles (Road Cones)
      eng.roadObstacles.forEach((obs) => {
        if (obs.x < -40 || obs.x > eng.W + 40) return;
        const oy = getLaneY(obs.lane);
        ctx!.font = '24px sans-serif';
        ctx!.textAlign = 'center';
        ctx!.fillText('🚧', obs.x, oy + 8);
        ctx!.textAlign = 'start';
      });

      // 5. Render Rivals
      eng.rivals.forEach((rival) => {
        if (rival.x < -80 || rival.x > eng.W + 100) return;
        const ry = getLaneY(rival.lane);
        drawCarIllustration(ctx!, rival.car, rival.x, ry, 1.32, { lightOn: true, shine: true });

        // Overhead rival badge
        ctx!.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx!.beginPath();
        ctx!.roundRect(rival.x - 38, ry - 32, 76, 17, 8);
        ctx!.fill();
        ctx!.strokeStyle = '#94a3b8';
        ctx!.lineWidth = 1;
        ctx!.stroke();
        ctx!.fillStyle = '#f1f5f9';
        ctx!.font = 'bold 9px Tahoma';
        ctx!.textAlign = 'center';
        ctx!.fillText(rival.name, rival.x, ry - 20);
        ctx!.textAlign = 'start';
      });

      // 6. Render Player's Car (The exact car assembled in the level!)
      const playerCarX = eng.W * 0.22;
      const playerCar = eng.raceCar || CAR_REWARDS[0];

      // Headlight Beam forward on road
      const beamGrad = ctx!.createRadialGradient(playerCarX + 45, eng.raceY, 10, playerCarX + 160, eng.raceY, 130);
      beamGrad.addColorStop(0, 'rgba(254, 240, 138, 0.4)');
      beamGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');
      ctx!.fillStyle = beamGrad;
      ctx!.beginPath();
      ctx!.moveTo(playerCarX + 40, eng.raceY - 6);
      ctx!.lineTo(playerCarX + 190, eng.raceY - 24);
      ctx!.lineTo(playerCarX + 190, eng.raceY + 24);
      ctx!.lineTo(playerCarX + 40, eng.raceY + 8);
      ctx!.closePath();
      ctx!.fill();

      // Draw the assembled car
      drawCarIllustration(ctx!, playerCar, playerCarX, eng.raceY, 1.45, {
        lightOn: true,
        shine: true,
      });

      // Overhead Moalem Sardina Badge
      ctx!.fillStyle = '#16a34a';
      ctx!.beginPath();
      ctx!.roundRect(playerCarX - 44, eng.raceY - 36, 88, 18, 9);
      ctx!.fill();
      ctx!.strokeStyle = '#fef08a';
      ctx!.lineWidth = 1.5;
      ctx!.stroke();
      ctx!.fillStyle = '#ffffff';
      ctx!.font = 'bold 10px Tahoma';
      ctx!.textAlign = 'center';
      ctx!.fillText('👨🏻‍🔧 المعلم سردينه', playerCarX, eng.raceY - 23);
      ctx!.textAlign = 'start';

      // Hyperspeed streaks when Nitro is active
      if (eng.isNitroActive) {
        ctx!.strokeStyle = 'rgba(56, 189, 248, 0.65)';
        ctx!.lineWidth = 2.5;
        for (let sl = 0; sl < 14; sl++) {
          const sy = roadTop + (sl * 17) % roadH;
          const sx = (sl * 67 + eng.raceScroll * 3) % eng.W;
          ctx!.beginPath();
          ctx!.moveTo(sx, sy);
          ctx!.lineTo(sx + 55, sy);
          ctx!.stroke();
        }
      }

      // 7. Render Race Effects (Fire, Smoke, Confetti)
      eng.raceEffects.forEach((ef) => {
        ctx!.save();
        ctx!.globalAlpha = Math.min(1, ef.life / ef.maxLife);
        ctx!.fillStyle = ef.color;
        if (ef.type === 'confetti') {
          ctx!.fillRect(ef.x, ef.y, ef.size, ef.size * 1.6);
        } else {
          ctx!.beginPath();
          ctx!.arc(ef.x, ef.y, ef.size, 0, Math.PI * 2);
          ctx!.fill();
        }
        ctx!.restore();
      });

      // 8. Render Fireworks
      eng.raceFireworks.forEach((fw) => {
        fw.sparks.forEach((sp) => {
          ctx!.save();
          ctx!.globalAlpha = Math.min(1, sp.life / 25);
          ctx!.fillStyle = sp.color;
          ctx!.beginPath();
          ctx!.arc(sp.x, sp.y, 2.5, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.restore();
        });
      });

      // 9. Floating texts in race
      eng.floatingTexts.forEach((ft) => {
        ctx!.save();
        ctx!.globalAlpha = Math.min(1, ft.life / 20);
        ctx!.font = 'bold 16px Tahoma, sans-serif';
        ctx!.fillStyle = ft.color;
        ctx!.shadowColor = '#000000cc';
        ctx!.shadowBlur = 4;
        ctx!.textAlign = 'center';
        ctx!.fillText(ft.text, ft.x, ft.y);
        ctx!.restore();
      });
      eng.floatingTexts.forEach((ft) => {
        ft.life--;
        ft.y -= 0.6;
      });
      eng.floatingTexts = eng.floatingTexts.filter((ft) => ft.life > 0);

      // 10. Finish Grand Victory Overlay
      if (eng.raceFinished) {
        ctx!.save();
        ctx!.fillStyle = 'rgba(7, 24, 43, 0.7)';
        ctx!.fillRect(0, eng.H * 0.28, eng.W, 110);
        ctx!.strokeStyle = '#fef08a';
        ctx!.lineWidth = 3;
        ctx!.strokeRect(0, eng.H * 0.28, eng.W, 110);

        ctx!.textAlign = 'center';
        ctx!.fillStyle = '#fef08a';
        ctx!.font = 'bold 24px Tahoma, sans-serif';
        ctx!.fillText('🏆 المركز الأول — فوز ساحق للمعلم سردينه! 🥇', eng.W / 2, eng.H * 0.28 + 40);

        ctx!.fillStyle = '#ffffff';
        ctx!.font = 'bold 14px Tahoma, sans-serif';
        ctx!.fillText(`أثبتت ${playerCar.name} جدارتها على الطريق وسحقت المنافسين!`, eng.W / 2, eng.H * 0.28 + 70);

        ctx!.fillStyle = '#38bdf8';
        ctx!.font = 'bold 12px Tahoma, sans-serif';
        ctx!.fillText('جاري نقلك إلى منصة التتويج والكراج... 🏁✨', eng.W / 2, eng.H * 0.28 + 94);
        ctx!.textAlign = 'start';
        ctx!.restore();
      }
    }

    // Canvas Render Pipeline
    function render() {
      if (eng.racing) {
        renderRace();
        return;
      }
      renderSky();

      ctx!.save();
      let sx = 0,
        sy = 0;
      if (eng.shake > 0) {
        sx = (Math.random() - 0.5) * eng.shakePower;
        sy = (Math.random() - 0.5) * eng.shakePower;
        eng.shake--;
        if (eng.shake === 0) eng.shakePower = 0;
      }
      ctx!.scale(eng.zoom, eng.zoom);
      ctx!.translate(sx - eng.camX, sy - eng.camY);

      renderGround();

      // Collectable Parts - Highly visible, shiny, and shadow-free
      eng.parts.forEach((a) => {
        if (a.got) return;
        const iconMap: Record<string, string> = {
          شاسيه: '⚙️',
          عجلة: '🛞',
          مسمار: '🔩',
          باب: '🚪',
          موتور: '🧰',
        };
        const icon = iconMap[a.type] || '🔩';
        const bob = Math.sin(Date.now() / 250 + a.x) * 5;

        // Radiant golden aura (NO dark shadow underneath!)
        const auraGrad = ctx!.createRadialGradient(a.x + 18, a.y - 12 + bob, 4, a.x + 18, a.y - 12 + bob, 26);
        auraGrad.addColorStop(0, 'rgba(254, 240, 138, 0.65)');
        auraGrad.addColorStop(0.55, 'rgba(245, 158, 11, 0.28)');
        auraGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
        ctx!.fillStyle = auraGrad;
        ctx!.beginPath();
        ctx!.arc(a.x + 18, a.y - 12 + bob, 26, 0, Math.PI * 2);
        ctx!.fill();

        // Sparkle stars orbiting the part
        const sparkTime = Date.now() / 400 + a.x;
        const spX = a.x + 18 + Math.cos(sparkTime) * 18;
        const spY = a.y - 12 + bob + Math.sin(sparkTime) * 12;
        ctx!.fillStyle = '#ffffff';
        ctx!.beginPath();
        ctx!.arc(spX, spY, 2.5, 0, Math.PI * 2);
        ctx!.fill();

        // Large high-contrast icon
        ctx!.font = '36px sans-serif';
        ctx!.textAlign = 'center';
        ctx!.fillText(icon, a.x + 18, a.y + bob);

        // Crisp readable label with outline (NO dark shadow box underneath!)
        ctx!.font = 'bold 12px Tahoma, sans-serif';
        ctx!.strokeStyle = 'rgba(15, 23, 42, 0.95)';
        ctx!.lineWidth = 3.5;
        ctx!.strokeText(a.type, a.x + 18, a.y + 20 + bob);
        ctx!.fillStyle = '#fef08a';
        ctx!.fillText(a.type, a.x + 18, a.y + 20 + bob);
        ctx!.textAlign = 'start';
      });

      renderEnemies();

      // Workshop & Garage Bay
      const wx = eng.WW - 360;
      const wy = gy() - 205;
      ctx!.fillStyle = '#68442e';
      ctx!.fillRect(wx, wy + 42, 315, 165);
      ctx!.fillStyle = '#e0a14c';
      ctx!.fillRect(wx - 15, wy + 25, 345, 28);
      ctx!.fillStyle = '#9e4929';
      ctx!.fillRect(wx + 20, wy + 62, 275, 145);
      ctx!.fillStyle = '#ffd36b';
      ctx!.fillRect(wx + 36, wy + 77, 243, 9);
      ctx!.fillStyle = '#f5d99a';
      ctx!.font = 'bold 24px Tahoma';
      ctx!.fillText('ورشة المعلم سردينه', wx + 43, wy + 49);

      // Garage Car Bay Interior
      ctx!.fillStyle = '#1a2736';
      ctx!.fillRect(wx + 92, wy + 93, 132, 114);
      ctx!.fillStyle = '#334155';
      ctx!.fillRect(wx + 101, wy + 101, 114, 106);

      const currentLevelCar = CAR_REWARDS[(eng.level - 1) % CAR_REWARDS.length];
      if (eng.carBuilt) {
        drawCarIllustration(ctx!, currentLevelCar, wx + 158, wy + 160, 0.95, {
          lightOn: true,
          shine: true,
          bob: Math.sin(Date.now() / 250) * 2,
        });
        ctx!.fillStyle = '#fef08a';
        ctx!.font = 'bold 12px Tahoma';
        ctx!.textAlign = 'center';
        ctx!.fillText(currentLevelCar.name, wx + 158, wy + 120);
        ctx!.textAlign = 'start';
      } else {
        ctx!.fillStyle = '#38bdf8';
        ctx!.font = 'bold 14px Tahoma';
        ctx!.textAlign = 'center';
        ctx!.fillText('منصة التجميع 🔧', wx + 158, wy + 145);
        ctx!.fillStyle = '#94a3b8';
        ctx!.font = '11px Tahoma';
        ctx!.fillText(`عربية المستوى: ${currentLevelCar.type}`, wx + 158, wy + 170);
        ctx!.textAlign = 'start';
      }

      // --- HERO (المعلم سردينه) WITH DETAILED ARM & TOOL ANIMATION ---
      const { p } = eng;
      ctx!.save();

      let bodyScaleX = 1.0;
      let bodyScaleY = 1.0;
      let bobY = 0;

      if (p.ground) {
        if (Math.abs(p.vx) > 10) {
          bobY = Math.abs(Math.sin(eng.walkCycle)) * 2.5;
        }
        if (eng.landSquash > 0) {
          bodyScaleX = 1.0 + eng.landSquash * 0.12;
          bodyScaleY = 1.0 - eng.landSquash * 0.12;
        }
      } else if (p.vy < -50) {
        bodyScaleX = 0.94;
        bodyScaleY = 1.08;
      }

      const heroScale = 0.80;
      ctx!.translate(p.x + p.w / 2, p.y + p.h - 52 * heroScale + bobY);
      ctx!.scale(p.face * bodyScaleX * heroScale, bodyScaleY * heroScale);

      if (p.inv > 0 && Math.floor(p.inv / 5) % 2) {
        ctx!.globalAlpha = 0.45;
      }

      // Legs & Boots
      const legStride = Math.sin(eng.walkCycle) * 0.35;
      ctx!.save();
      ctx!.translate(-9, 36);
      ctx!.rotate(legStride);
      ctx!.fillStyle = '#414653';
      ctx!.beginPath();
      ctx!.roundRect(-6, 0, 12, 13, 3);
      ctx!.fill();
      ctx!.fillStyle = '#302b2a';
      ctx!.beginPath();
      ctx!.roundRect(-8, 11, 16, 6, 2);
      ctx!.fill();
      ctx!.restore();

      ctx!.save();
      ctx!.translate(9, 36);
      ctx!.rotate(-legStride);
      ctx!.fillStyle = '#414653';
      ctx!.beginPath();
      ctx!.roundRect(-6, 0, 12, 13, 3);
      ctx!.fill();
      ctx!.fillStyle = '#302b2a';
      ctx!.beginPath();
      ctx!.roundRect(-8, 11, 16, 6, 2);
      ctx!.fill();
      ctx!.restore();

      // Coat & Torso
      ctx!.fillStyle = '#555c6d';
      ctx!.beginPath();
      ctx!.roundRect(-19, 17, 38, 26, 7);
      ctx!.fill();

      // Coat Lapels
      ctx!.fillStyle = '#747b8c';
      ctx!.beginPath();
      ctx!.moveTo(-17, 18);
      ctx!.lineTo(-8, 15);
      ctx!.lineTo(0, 28);
      ctx!.lineTo(-7, 37);
      ctx!.closePath();
      ctx!.fill();
      ctx!.beginPath();
      ctx!.moveTo(17, 18);
      ctx!.lineTo(8, 15);
      ctx!.lineTo(1, 28);
      ctx!.lineTo(8, 37);
      ctx!.closePath();
      ctx!.fill();

      // Scarf
      ctx!.fillStyle = '#b9b4ac';
      ctx!.beginPath();
      ctx!.moveTo(-7, 14);
      ctx!.lineTo(7, 14);
      ctx!.lineTo(11, 39);
      ctx!.lineTo(2, 43);
      ctx!.lineTo(-6, 31);
      ctx!.closePath();
      ctx!.fill();
      ctx!.strokeStyle = '#88877f';
      ctx!.lineWidth = 1;
      for (let yy = 19; yy < 39; yy += 5) {
        ctx!.beginPath();
        ctx!.moveTo(-5, yy);
        ctx!.lineTo(9, yy + 2);
        ctx!.stroke();
      }

      // Back Arm
      const backArmAngle = p.atk > 0 ? -0.2 : -Math.sin(eng.walkCycle) * 0.3;
      ctx!.save();
      ctx!.translate(-14, 20);
      ctx!.rotate(backArmAngle);
      ctx!.fillStyle = '#464c5a';
      ctx!.beginPath();
      ctx!.roundRect(-4, 0, 8, 18, 4);
      ctx!.fill();
      ctx!.fillStyle = '#c58c68';
      ctx!.beginPath();
      ctx!.arc(0, 19, 4, 0, Math.PI * 2);
      ctx!.fill();
      ctx!.restore();

      // Head & Face (Looking forward towards the road in travel direction)
      // 1. Rear side ear
      ctx!.fillStyle = '#d7a078';
      ctx!.beginPath();
      ctx!.ellipse(-11, 2, 3.8, 5.2, 0, 0, Math.PI * 2);
      ctx!.fill();
      ctx!.fillStyle = '#ad714b';
      ctx!.beginPath();
      ctx!.ellipse(-10.5, 2, 2.0, 3.0, 0, 0, Math.PI * 2);
      ctx!.fill();

      // 2. Head contour (Profile / 3/4 leaning towards the road)
      ctx!.fillStyle = '#e4b18a';
      ctx!.beginPath();
      ctx!.ellipse(2, 0, 15.5, 18.5, 0.05, 0, Math.PI * 2);
      ctx!.fill();

      // Cheek & jaw definition
      ctx!.fillStyle = '#dfa57e';
      ctx!.beginPath();
      ctx!.ellipse(5, 4, 7, 5, 0.1, 0, Math.PI * 2);
      ctx!.fill();

      // 3. Graying hair / sideburn at the nape (behind the ear)
      ctx!.fillStyle = '#bfc0bd';
      ctx!.beginPath();
      ctx!.moveTo(-13, -7);
      ctx!.lineTo(-16, 5);
      ctx!.lineTo(-12, 12);
      ctx!.lineTo(-9, 7);
      ctx!.lineTo(-9, -2);
      ctx!.closePath();
      ctx!.fill();

      // 4. Moalem Eyebrow (Angled determinedly forward towards the road)
      ctx!.strokeStyle = '#2d2420';
      ctx!.lineWidth = 3.5;
      ctx!.lineCap = 'round';
      ctx!.beginPath();
      ctx!.moveTo(1, -7.5);
      ctx!.lineTo(11.5, -6);
      ctx!.stroke();

      // Brow furrow crease
      ctx!.strokeStyle = '#b37754';
      ctx!.lineWidth = 1.2;
      ctx!.beginPath();
      ctx!.moveTo(3, -9.5);
      ctx!.lineTo(7, -8.5);
      ctx!.stroke();

      // 5. Eye Looking Forward Ahead Towards the Road (+X)
      // Sclera (almond shaped eye gazing forward)
      ctx!.fillStyle = '#fffdf5';
      ctx!.beginPath();
      ctx!.ellipse(6.5, -2.5, 4.3, 3.0, 0.08, 0, Math.PI * 2);
      ctx!.fill();
      ctx!.strokeStyle = '#5a463b';
      ctx!.lineWidth = 1;
      ctx!.stroke();

      // Pupil & Iris - firmly directed forward toward the road ahead
      ctx!.fillStyle = '#2b201a';
      ctx!.beginPath();
      ctx!.arc(8.5, -2.5, 2.2, 0, Math.PI * 2);
      ctx!.fill();

      // Pupil deep center
      ctx!.fillStyle = '#0f0a07';
      ctx!.beginPath();
      ctx!.arc(8.7, -2.5, 1.3, 0, Math.PI * 2);
      ctx!.fill();

      // Specular highlight / glint reflecting the road horizon
      ctx!.fillStyle = '#ffffff';
      ctx!.beginPath();
      ctx!.arc(9.4, -3.3, 0.9, 0, Math.PI * 2);
      ctx!.fill();

      // Eyelid crease
      ctx!.strokeStyle = '#c58c68';
      ctx!.lineWidth = 1.2;
      ctx!.beginPath();
      ctx!.moveTo(3, -5.5);
      ctx!.quadraticCurveTo(7, -6.8, 10.5, -5.0);
      ctx!.stroke();

      // 6. Craftsman Nose (pointing proudly forward along the road)
      ctx!.fillStyle = '#d79b73';
      ctx!.beginPath();
      ctx!.moveTo(8, -2);
      ctx!.lineTo(15.5, 1.5);
      ctx!.quadraticCurveTo(17, 3.2, 14.5, 5);
      ctx!.lineTo(8, 4.5);
      ctx!.closePath();
      ctx!.fill();
      // Nostril contour
      ctx!.fillStyle = '#aa6c47';
      ctx!.beginPath();
      ctx!.arc(11.5, 4.2, 1.4, 0, Math.PI * 2);
      ctx!.fill();

      // 7. Moalem Sardina's Egyptian Mustache (sweeping forward toward the road)
      ctx!.fillStyle = '#3a322e';
      ctx!.beginPath();
      ctx!.moveTo(5, 5.5);
      ctx!.quadraticCurveTo(13, 4, 18.5, 7.5);
      ctx!.quadraticCurveTo(20, 9.5, 17, 11.5);
      ctx!.quadraticCurveTo(9, 12, 0, 9.5);
      ctx!.quadraticCurveTo(-4, 7.8, 1.5, 6.5);
      ctx!.closePath();
      ctx!.fill();

      // Mustache hair texture & forward sheen
      ctx!.strokeStyle = '#5a504b';
      ctx!.lineWidth = 1.3;
      ctx!.beginPath();
      ctx!.moveTo(6, 7.5);
      ctx!.quadraticCurveTo(12, 6.8, 17.5, 9);
      ctx!.stroke();

      // 8. Egyptian Workshop Cap / Beret (tilted forward over the brow toward the road)
      ctx!.fillStyle = '#d2d1cc';
      ctx!.beginPath();
      ctx!.ellipse(-1, -12, 17, 9, 0.05, Math.PI, Math.PI * 2);
      ctx!.fill();

      // Visor / brim extending forward over the brow toward the road
      ctx!.fillStyle = '#b8b8b4';
      ctx!.beginPath();
      ctx!.moveTo(-16, -12);
      ctx!.lineTo(17.5, -12);
      ctx!.lineTo(19, -8.5);
      ctx!.lineTo(12, -7);
      ctx!.lineTo(-16, -10);
      ctx!.closePath();
      ctx!.fill();

      // Cap rim band shadow
      ctx!.fillStyle = '#9c9c98';
      ctx!.fillRect(-16, -11, 33, 2);

      // --- ARTICULATED ATTACKING ARM & WEAPON ---
      let shoulderAngle = 0.2;
      let elbowAngle = 0.3;
      let wristAngle = 0.0;

      if (p.atk > 0 && (p.weapon === 'hammer' || p.weapon === 'wrench')) {
        const progress = 1.0 - p.atk / p.atkMax;
        if (p.weapon === 'hammer') {
          if (progress < 0.28) {
            const t = progress / 0.28;
            shoulderAngle = 0.2 + t * (-1.8 - 0.2);
            elbowAngle = 0.3 + t * (-1.3 - 0.3);
            wristAngle = t * -0.4;
          } else if (progress < 0.52) {
            const t = (progress - 0.28) / 0.24;
            const ease = t * t;
            shoulderAngle = -1.8 + ease * (1.25 - -1.8);
            elbowAngle = -1.3 + ease * (0.25 - -1.3);
            wristAngle = -0.4 + ease * (0.4 - -0.4);
          } else if (progress < 0.68) {
            shoulderAngle = 1.25;
            elbowAngle = 0.25;
            wristAngle = 0.4;
          } else {
            const t = (progress - 0.68) / 0.32;
            const easeOut = 1 - Math.pow(1 - t, 2);
            shoulderAngle = 1.25 + easeOut * (0.2 - 1.25);
            elbowAngle = 0.25 + easeOut * (0.3 - 0.25);
            wristAngle = 0.4 + easeOut * (0.0 - 0.4);
          }
        } else if (p.weapon === 'wrench') {
          if (progress < 0.28) {
            const t = progress / 0.28;
            shoulderAngle = 0.2 + t * (-0.85 - 0.2);
            elbowAngle = 0.3 + t * (-1.4 - 0.3);
            wristAngle = t * -0.6;
          } else if (progress < 0.52) {
            const t = (progress - 0.28) / 0.24;
            const ease = t * t;
            shoulderAngle = -0.85 + ease * (0.45 - -0.85);
            elbowAngle = -1.4 + ease * (0.15 - -1.4);
            wristAngle = -0.6 + ease * (0.95 - -0.6);
          } else if (progress < 0.68) {
            shoulderAngle = 0.45;
            elbowAngle = 0.15;
            wristAngle = 0.95;
          } else {
            const t = (progress - 0.68) / 0.32;
            const easeOut = 1 - Math.pow(1 - t, 2);
            shoulderAngle = 0.45 + easeOut * (0.2 - 0.45);
            elbowAngle = 0.15 + easeOut * (0.3 - 0.15);
            wristAngle = 0.95 + easeOut * (0.0 - 0.95);
          }
        }
      } else {
        shoulderAngle = 0.2 + Math.sin(eng.walkCycle) * 0.35;
      }

      ctx!.save();
      ctx!.translate(12, 19);
      ctx!.rotate(shoulderAngle);

      ctx!.fillStyle = '#555c6d';
      ctx!.beginPath();
      ctx!.roundRect(-4, 0, 9, 14, 4);
      ctx!.fill();

      ctx!.translate(0, 13);
      ctx!.rotate(elbowAngle);

      ctx!.fillStyle = '#656d80';
      ctx!.beginPath();
      ctx!.roundRect(-4, 0, 8, 12, 3);
      ctx!.fill();

      ctx!.translate(0, 12);
      ctx!.rotate(wristAngle);

      ctx!.fillStyle = '#d6a078';
      ctx!.beginPath();
      ctx!.arc(0, 2, 5, 0, Math.PI * 2);
      ctx!.fill();

      const toolToRender = p.atk > 0 ? p.weapon : 'hammer';
      if (toolToRender === 'hammer') {
        ctx!.save();
        ctx!.rotate(-Math.PI / 2 + 0.1);
        ctx!.fillStyle = '#8a5a36';
        ctx!.beginPath();
        ctx!.roundRect(-3, -26, 6, 32, 2);
        ctx!.fill();
        ctx!.fillStyle = '#6d4222';
        ctx!.fillRect(-1, -24, 2, 28);
        ctx!.fillStyle = '#94a3b8';
        ctx!.beginPath();
        ctx!.roundRect(-9, -34, 18, 11, 3);
        ctx!.fill();
        ctx!.fillStyle = '#e2e8f0';
        ctx!.fillRect(5, -34, 4, 11);
        ctx!.fillStyle = '#64748b';
        ctx!.fillRect(-9, -34, 3, 11);

        // Glow trail swoosh
        if (p.atkPhase === 'strike') {
          ctx!.strokeStyle = 'rgba(255, 230, 140, 0.45)';
          ctx!.lineWidth = 5;
          ctx!.beginPath();
          ctx!.arc(0, -30, 14, -0.8, 0.8);
          ctx!.stroke();
        }
        ctx!.restore();
      } else if (toolToRender === 'wrench') {
        ctx!.save();
        ctx!.rotate(-Math.PI / 2 + 0.1);
        ctx!.fillStyle = '#94a3b8';
        ctx!.beginPath();
        ctx!.roundRect(-3, -26, 6, 30, 2);
        ctx!.fill();
        ctx!.fillStyle = '#cbd5e1';
        ctx!.fillRect(-1, -22, 2, 24);
        ctx!.fillStyle = '#64748b';
        ctx!.beginPath();
        ctx!.roundRect(-7, -35, 14, 11, 2);
        ctx!.fill();
        ctx!.fillStyle = '#1e293b';
        ctx!.fillRect(-3, -36, 6, 7);
        ctx!.fillStyle = '#d97706';
        ctx!.fillRect(-2, -31, 4, 3);
        ctx!.restore();
      }

      ctx!.restore();
      ctx!.restore();

      // Render Expanding Shockwave Rings
      eng.shockwaves.forEach((sw) => {
        ctx!.save();
        ctx!.globalAlpha = sw.alpha;
        ctx!.strokeStyle = sw.color;
        ctx!.lineWidth = 3.5;
        ctx!.beginPath();
        ctx!.arc(sw.x, sw.y, sw.r, 0, Math.PI * 2);
        ctx!.stroke();
        ctx!.restore();
      });

      // Render Floating Action Texts
      eng.floatingTexts.forEach((ft) => {
        ctx!.save();
        ctx!.globalAlpha = Math.min(1, ft.life / 20);
        ctx!.font = 'bold 15px Tahoma, sans-serif';
        ctx!.fillStyle = ft.color;
        ctx!.shadowColor = '#000000cc';
        ctx!.shadowBlur = 4;
        ctx!.textAlign = 'center';
        ctx!.fillText(ft.text, ft.x, ft.y);
        ctx!.restore();
      });

      // Particles (Sparks, Nuts, Fireballs, Ground Shockwaves)
      eng.particles.forEach((a) => {
        ctx!.globalAlpha = Math.min(1, a.life / 20);
        ctx!.fillStyle = a.color;

        if (a.fireball) {
          ctx!.beginPath();
          ctx!.arc(a.x, a.y, 9, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#ffe98a';
          ctx!.beginPath();
          ctx!.arc(a.x - 2, a.y - 2, 4, 0, Math.PI * 2);
          ctx!.fill();
        } else if (a.shockwaveWave) {
          ctx!.beginPath();
          ctx!.ellipse(a.x, a.y, 14, 8, 0, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.fillStyle = '#fef08a';
          ctx!.beginPath();
          ctx!.arc(a.x, a.y - 2, 4, 0, Math.PI * 2);
          ctx!.fill();
        } else if (a.nut) {
          ctx!.save();
          ctx!.translate(a.x, a.y);
          ctx!.rotate(a.life * 0.15);
          ctx!.fillStyle = '#aeb8c4';
          ctx!.strokeStyle = '#fff0a0';
          ctx!.lineWidth = 2;
          ctx!.beginPath();
          for (let j = 0; j < 6; j++) {
            const ang = (Math.PI / 3) * j - Math.PI / 6;
            const xx = Math.cos(ang) * 11;
            const yy = Math.sin(ang) * 11;
            j ? ctx!.lineTo(xx, yy) : ctx!.moveTo(xx, yy);
          }
          ctx!.closePath();
          ctx!.fill();
          ctx!.stroke();
          ctx!.fillStyle = '#29394a';
          ctx!.beginPath();
          ctx!.arc(0, 0, 4, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.restore();
        } else if (a.isSpark) {
          ctx!.save();
          ctx!.translate(a.x, a.y);
          const sparkAngle = Math.atan2(a.vy, a.vx);
          ctx!.rotate(sparkAngle);
          const len = Math.min(16, Math.sqrt(a.vx * a.vx + a.vy * a.vy) * 0.05);
          ctx!.strokeStyle = a.color;
          ctx!.lineWidth = a.size || 2.5;
          ctx!.lineCap = 'round';
          ctx!.beginPath();
          ctx!.moveTo(-len, 0);
          ctx!.lineTo(len, 0);
          ctx!.stroke();
          ctx!.fillStyle = '#ffffff';
          ctx!.beginPath();
          ctx!.arc(0, 0, (a.size || 2.5) * 0.6, 0, Math.PI * 2);
          ctx!.fill();
          ctx!.restore();
        } else if (a.isStar) {
          ctx!.save();
          ctx!.translate(a.x, a.y);
          ctx!.rotate(a.rot || 0);
          const sz = (a.size || 6) * Math.min(1, a.life / 10);
          ctx!.fillStyle = a.color;
          ctx!.beginPath();
          ctx!.moveTo(0, -sz * 1.8);
          ctx!.lineTo(sz * 0.4, -sz * 0.4);
          ctx!.lineTo(sz * 1.8, 0);
          ctx!.lineTo(sz * 0.4, sz * 0.4);
          ctx!.lineTo(0, sz * 1.8);
          ctx!.lineTo(-sz * 0.4, sz * 0.4);
          ctx!.lineTo(-sz * 1.8, 0);
          ctx!.lineTo(-sz * 0.4, -sz * 0.4);
          ctx!.closePath();
          ctx!.fill();
          ctx!.restore();
        } else if (a.isDebris) {
          ctx!.save();
          ctx!.translate(a.x, a.y);
          ctx!.rotate(a.rot || 0);
          ctx!.fillStyle = a.color;
          ctx!.fillRect(-(a.size || 4) / 2, -(a.size || 4) / 2, a.size || 4, (a.size || 4) * 1.3);
          ctx!.restore();
        } else if (a.isDust) {
          ctx!.fillStyle = 'rgba(226, 232, 240, 0.45)';
          ctx!.beginPath();
          ctx!.arc(a.x, a.y, a.size || 3, 0, Math.PI * 2);
          ctx!.fill();
        } else {
          ctx!.fillRect(a.x, a.y, a.size || 5, a.size || 5);
        }
      });
      ctx!.globalAlpha = 1;

      ctx!.restore();
    }

    let animId: number;
    function loop(t: number) {
      if (!eng.playing) return;
      const dt = Math.min((t - eng.lastTime) / 1000, 0.04);
      eng.lastTime = t;

      update(dt);
      render();

      animId = requestAnimationFrame(loop);
    }

    (window as unknown as { startMoalemGame: () => void }).startMoalemGame = () => {
      eng.playing = true;
      setIsPlaying(true);
      resetGame(eng.level, eng.world);
      eng.lastTime = performance.now();
      animId = requestAnimationFrame(loop);
    };

    (window as unknown as { restartMoalemGame: (nextLevel?: boolean) => void }).restartMoalemGame = (
      nextLevel?: boolean
    ) => {
      if (nextLevel) {
        let nL = eng.level + 1;
        let nW = eng.world;
        if (nL > 10) {
          nL = 1;
          nW++;
          if (nW > 4) nW = 1;
        }
        eng.level = nL;
        eng.world = nW;
      }
      setShowRewardModal(false);
      resetGame(eng.level, eng.world);
      eng.playing = true;
      eng.lastTime = performance.now();
      animId = requestAnimationFrame(loop);
    };

    (window as unknown as { triggerPlayerAction: (action: string) => void }).triggerPlayerAction = (
      action: string
    ) => {
      if (action === 'jump') jumpPlayer();
      else if (action === 'hammer' || action === 'wrench' || action === 'nuts') {
        executeAttack(action as 'hammer' | 'wrench' | 'nuts');
      }
    };

    (window as unknown as { switchWorldTheme: (worldId: number) => void }).switchWorldTheme = (worldId: number) => {
      eng.world = worldId;
      setCurrentWorld(worldId);
      eng.updateHud();
      eng.say(`انتقلت إلى ${WORLD_THEMES.find(w => w.id === worldId)?.name || ''} 🌍`);
    };

    (window as unknown as { raceShiftLane: (dir: number) => void }).raceShiftLane = (dir: number) => {
      raceShiftLane(dir);
    };

    (window as unknown as { raceActivateNitro: () => void }).raceActivateNitro = () => {
      raceActivateNitro();
    };

    (window as unknown as { raceHonkHorn: () => void }).raceHonkHorn = () => {
      raceHonkHorn();
    };

    (window as unknown as { finishCarRaceEarly: () => void }).finishCarRaceEarly = () => {
      finishCarRaceEarly();
    };

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      cancelAnimationFrame(animId);
    };
  }, [unlockCar]);

  // Touch and button actions
  const handleButtonDown = (btn: string) => {
    const eng = engineRef.current;
    if (btn === 'left') eng.keys.left = true;
    if (btn === 'right') eng.keys.right = true;
    if (btn === 'jump') {
      const fn = (window as unknown as { triggerPlayerAction: (a: string) => void }).triggerPlayerAction;
      if (fn) fn('jump');
    }
    if (btn === 'hammer' || btn === 'wrench' || btn === 'nuts') {
      const fn = (window as unknown as { triggerPlayerAction: (a: string) => void }).triggerPlayerAction;
      if (fn) fn(btn);
    }
  };

  const handleButtonUp = (btn: string) => {
    const eng = engineRef.current;
    if (btn === 'left') eng.keys.left = false;
    if (btn === 'right') eng.keys.right = false;
  };

  const startGame = () => {
    const fn = (window as unknown as { startMoalemGame: () => void }).startMoalemGame;
    if (fn) fn();
  };

  const continueNextLevel = () => {
    const fn = (window as unknown as { restartMoalemGame: (n: boolean) => void }).restartMoalemGame;
    if (fn) fn(true);
  };

  const switchTheme = (id: number) => {
    const fn = (window as unknown as { switchWorldTheme: (n: number) => void }).switchWorldTheme;
    if (fn) fn(id);
    setShowWorldMenu(false);
  };

  // Preview canvas for Garage Modal
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (showGarage && previewCanvasRef.current) {
      const canvas = previewCanvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawCarIllustration(ctx, selectedGarageCar, canvas.width / 2, canvas.height / 2, 1.45, {
          lightOn: true,
          shine: true,
        });
      }
    }
  }, [showGarage, selectedGarageCar]);

  // Preview canvas for Victory Reward Modal
  const rewardCanvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (showRewardModal && rewardCanvasRef.current) {
      const canvas = rewardCanvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawCarIllustration(ctx, latestRewardCar, canvas.width / 2, canvas.height / 2, 1.6, {
          lightOn: true,
          shine: true,
        });
      }
    }
  }, [showRewardModal, latestRewardCar]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#16283c] text-white select-none font-sans">
      {/* Game Canvas */}
      <canvas
        ref={canvasRef}
        className="block w-full h-full touch-none"
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* TOP HUD BAR */}
      {isRacing ? (
        <div className="fixed top-1.5 left-1.5 right-1.5 flex justify-between items-center gap-1.5 z-20 pointer-events-none select-none">
          <div className="flex items-center gap-1 sm:gap-1.5 pointer-events-auto shrink-0">
            {/* Car Name Badge */}
            <div className="bg-gradient-to-b from-[#1e293b] to-[#0f172a] border border-yellow-400/80 rounded-lg px-2 py-0.5 sm:px-2.5 sm:py-1 font-bold text-[10px] sm:text-xs text-yellow-300 shadow-sm flex items-center gap-1 h-7 sm:h-8">
              <span>🏎️</span>
              <span className="truncate max-w-[80px] sm:max-w-none">{latestRewardCar.name}</span>
            </div>

            {/* Speedometer */}
            <div className="bg-gradient-to-b from-[#0284c7] to-[#0369a1] border border-cyan-300/80 rounded-lg px-2 py-0.5 sm:px-2.5 sm:py-1 font-bold text-[10px] sm:text-xs text-white shadow-sm flex items-center gap-1 h-7 sm:h-8">
              <Gauge className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-cyan-200" />
              <span>{raceSpeedDisplay} كم/س</span>
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5 pointer-events-auto shrink-0">
            {/* Position Badge */}
            <div className="bg-gradient-to-b from-[#f59e0b] to-[#b45309] border border-yellow-300/80 rounded-lg px-2 py-0.5 sm:px-2.5 sm:py-1 font-bold text-[10px] sm:text-xs text-white shadow-sm flex items-center gap-1 h-7 sm:h-8">
              <span>🏆</span>
              <span>م {racePositionDisplay}</span>
            </div>

            {/* Distance to finish */}
            <div className="bg-gradient-to-b from-[#16a34a] to-[#15803d] border border-emerald-300/80 rounded-lg px-2 py-0.5 sm:px-2.5 sm:py-1 font-bold text-[10px] sm:text-xs text-white shadow-sm flex items-center gap-1 h-7 sm:h-8">
              <span>🏁</span>
              <span>{raceDistanceDisplay}م</span>
            </div>

            {/* Skip / Finish Race Early */}
            <button
              onClick={() => {
                const fn = (window as unknown as { finishCarRaceEarly: () => void }).finishCarRaceEarly;
                if (fn) fn();
              }}
              title="تخطي السباق واستلام المكافأة مباشرة"
              className="bg-slate-800/90 hover:bg-slate-700 border border-slate-500 rounded-lg px-2 py-0.5 sm:py-1 text-[10px] sm:text-xs text-slate-300 font-bold transition active:scale-95 cursor-pointer shadow-sm flex items-center gap-1 h-7 sm:h-8"
            >
              <span>تخطي ⏭️</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="fixed top-1.5 left-1.5 right-1.5 flex justify-between items-center gap-1.5 z-20 pointer-events-none select-none">
          {/* Player Stats Capsule: Hearts + Parts */}
          <div className="flex items-center gap-1.5 bg-[#0f1d2fe6] backdrop-blur-md border border-[#ffda7888] rounded-lg px-2 py-0.5 shadow-md pointer-events-auto shrink-0 h-7 sm:h-8">
            <div
              id="engine-health"
              className="font-bold text-xs sm:text-sm tracking-tight text-red-500 drop-shadow flex items-center"
              title="صحة المعلم سردينه"
            >
              ❤️❤️❤️
            </div>
            <div className="w-px h-3.5 bg-slate-600/70" />
            <div
              id="engine-parts"
              className="font-bold text-[10px] sm:text-xs text-amber-300 flex items-center gap-1"
              title="قطع الغيار المجمعة"
            >
              <span className="hidden sm:inline">قطع الغيار </span>
              <span className="sm:hidden">قطع </span>
              0/6
            </div>
          </div>

          {/* Stage & World Selector Badge */}
          <button
            onClick={() => setShowWorldMenu(true)}
            title="تغيير الخلفية والعالم"
            className="bg-gradient-to-b from-[#203c59ee] to-[#10253dee] border border-[#ffda7888] hover:border-yellow-400 rounded-lg px-2 py-0.5 font-bold text-[10px] sm:text-xs shadow-md text-white flex items-center gap-1 cursor-pointer transition active:scale-95 pointer-events-auto shrink min-w-0 max-w-[125px] sm:max-w-none h-7 sm:h-8"
          >
            <Layers className="w-3 h-3 text-yellow-300 shrink-0" />
            <span id="engine-stage" className="truncate">
              <span className="hidden sm:inline">{WORLD_THEMES.find(w => w.id === currentWorld)?.name || 'حارة الورشة'} • </span>مستوى {currentLevel}/10
            </span>
          </button>

          {/* Quick Action Tools: Garage, Zoom, Swap Controls, Sound Toggle */}
          <div className="flex items-center gap-1 pointer-events-auto shrink-0">
            {/* Garage Button */}
            <button
              onClick={() => setShowGarage(true)}
              title="كراج ومتحف المعلم سردينه"
              className="bg-gradient-to-b from-[#f59e0b] to-[#b45309] border border-[#fef08a] hover:brightness-110 active:scale-95 text-white font-bold px-1.5 py-0.5 rounded-lg shadow-md text-[10px] sm:text-xs flex items-center gap-1 cursor-pointer transition h-7 sm:h-8"
            >
              <Trophy className="w-3 h-3 text-yellow-200 shrink-0" />
              <span className="hidden sm:inline">الكراج</span>
              <span className="bg-black/30 rounded-full px-1 py-0.2 text-[9px] sm:text-[10px] font-black">
                {collectedCarIds.length}/10
              </span>
            </button>

            {/* Zoom Level Toggle Button */}
            <button
              onClick={cycleZoom}
              title="تكبير وتصغير شاشة اللعب وحجم الشخصية"
              className="bg-gradient-to-b from-[#203c59ee] to-[#10253dee] border border-[#ffda7888] hover:border-yellow-400 rounded-lg px-1.5 py-0.5 font-bold text-[10px] sm:text-xs shadow-md text-yellow-300 flex items-center justify-center gap-0.5 cursor-pointer transition active:scale-95 h-7 sm:h-8 min-w-[28px]"
            >
              <span className="text-[11px]">🔍</span>
              <span className="font-black text-[10px] sm:text-xs">
                {zoomLevel}x
              </span>
            </button>

            {/* Swap Controls Side Button */}
            <button
              onClick={() => setSwapControlSides((prev) => !prev)}
              title="تبديل أماكن الأزرار (أزرار الحركة يمين أو يسار)"
              className="bg-gradient-to-b from-[#203c59ee] to-[#10253dee] border border-[#ffda7888] hover:border-yellow-400 p-1 rounded-lg text-yellow-300 hover:brightness-110 active:scale-95 cursor-pointer shadow-md text-xs font-bold flex items-center justify-center h-7 sm:h-8 w-7 sm:w-8"
            >
              <span className="leading-none">⇄</span>
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled((prev) => !prev)}
              className="bg-gradient-to-b from-[#203c59ee] to-[#10253dee] border border-[#ffda7888] p-1 rounded-lg text-yellow-300 hover:brightness-110 active:scale-95 cursor-pointer shadow-md h-7 sm:h-8 w-7 sm:w-8 flex items-center justify-center"
              title={soundEnabled ? 'كتم الصوت' : 'تشغيل الصوت'}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 text-gray-400" />}
            </button>
          </div>
        </div>
      )}

      {/* TOP NOTIFICATION MESSAGE PILL */}
      <div
        id="engine-msg"
        className="fixed top-10 sm:top-11 left-1/2 -translate-x-1/2 bg-[#0c1a2ee8] backdrop-blur-md border border-amber-400/50 rounded-full px-3 py-0.5 text-[10px] sm:text-xs font-semibold z-10 text-amber-200 shadow-md whitespace-nowrap max-w-[85vw] overflow-hidden text-ellipsis pointer-events-none transition-all duration-200"
      >
        {isRacing
          ? '🏁 سباق نهاية المرحلة — بدّل الحارات وفعّل التيربو لتسبق المنافسين!'
          : 'اجمع قطع الغيار — الورشة في آخر الطريق!'}
      </div>

      {/* BOTTOM ON-SCREEN TOUCH CONTROLS */}
      {isRacing ? (
        <div 
          dir="ltr"
          style={{ direction: 'ltr' }}
          className="fixed bottom-2 left-2 right-2 flex justify-between items-end z-20 pointer-events-none"
        >
          {/* Steering Pad: Lane UP and Lane DOWN */}
          <div className="flex flex-col items-center gap-1.5 bg-[#07182bd8] p-1.5 rounded-2xl border-2 border-cyan-400/70 backdrop-blur-sm pointer-events-auto shadow-2xl">
            {/* Lane Up Button */}
            <button
              type="button"
              onClick={() => {
                const fn = (window as unknown as { raceShiftLane: (d: number) => void }).raceShiftLane;
                if (fn) fn(-1);
              }}
              className="w-16 h-10 sm:w-20 sm:h-11 rounded-xl bg-gradient-to-b from-[#344b63ef] to-[#172b43ef] border-2 border-cyan-400 active:translate-y-0.5 text-white font-black flex items-center justify-center gap-1 shadow-lg active:shadow-none select-none cursor-pointer"
              title="انتقل للحارة العليا"
            >
              <span className="text-lg">⬆️</span>
              <span className="text-[11px] font-bold font-sans">حارة فوق</span>
            </button>

            {/* Lane Down Button */}
            <button
              type="button"
              onClick={() => {
                const fn = (window as unknown as { raceShiftLane: (d: number) => void }).raceShiftLane;
                if (fn) fn(1);
              }}
              className="w-16 h-10 sm:w-20 sm:h-11 rounded-xl bg-gradient-to-b from-[#344b63ef] to-[#172b43ef] border-2 border-cyan-400 active:translate-y-0.5 text-white font-black flex items-center justify-center gap-1 shadow-lg active:shadow-none select-none cursor-pointer"
              title="انتقل للحارة السفلى"
            >
              <span className="text-lg">⬇️</span>
              <span className="text-[11px] font-bold font-sans">حارة تحت</span>
            </button>
          </div>

          {/* Action Pad: Nitro Boost & Shaabi Horn */}
          <div className="flex flex-col items-center gap-1.5 bg-[#07182bd8] p-1.5 rounded-2xl border-2 border-yellow-400/70 backdrop-blur-sm pointer-events-auto shadow-2xl">
            {/* Nitro Boost Button */}
            <button
              type="button"
              onClick={() => {
                const fn = (window as unknown as { raceActivateNitro: () => void }).raceActivateNitro;
                if (fn) fn();
              }}
              className={`w-28 h-10 sm:w-32 sm:h-11 rounded-xl bg-gradient-to-b from-[#ef4444] to-[#b91c1c] border-2 border-yellow-300 active:translate-y-0.5 text-white font-black flex items-center justify-center gap-1.5 shadow-lg active:shadow-none select-none cursor-pointer ring-2 ring-amber-500/50 ${
                raceNitroDisplay >= 20 ? 'animate-pulse' : 'opacity-60'
              }`}
              title="تفعيل التيربو والنيترو الناري"
            >
              <span className="text-base">🔥</span>
              <span className="text-[11px] sm:text-xs font-black font-sans">تيربو نيترو ({raceNitroDisplay}%)</span>
            </button>

            {/* Horn Button */}
            <button
              type="button"
              onClick={() => {
                const fn = (window as unknown as { raceHonkHorn: () => void }).raceHonkHorn;
                if (fn) fn();
              }}
              className="w-28 h-9 sm:w-32 sm:h-10 rounded-xl bg-gradient-to-b from-[#eab308] to-[#ca8a04] border-2 border-yellow-200 active:translate-y-0.5 text-white font-black flex items-center justify-center gap-1.5 shadow-lg active:shadow-none select-none cursor-pointer"
              title="كلاكس شعبي (بيب بيب!)"
            >
              <span className="text-base">🎺</span>
              <span className="text-[11px] font-bold font-sans">كلاكس (بيب بيب!)</span>
            </button>
          </div>
        </div>
      ) : (
        <div 
          dir="ltr"
          style={{ direction: 'ltr' }}
          className={`fixed bottom-2 left-2 right-2 flex ${swapControlSides ? 'flex-row-reverse' : 'flex-row'} justify-between items-end z-20 pointer-events-none`}
        >
          {/* Movement Pad: Jump ON TOP, Left and Right directions SIDE-BY-SIDE UNDERNEATH */}
          <div 
            dir="ltr"
            style={{ direction: 'ltr' }}
            className="flex flex-col items-center gap-1 bg-[#07182bd8] p-1.5 rounded-2xl border-2 border-[#ffda7888] backdrop-blur-sm pointer-events-auto shadow-xl"
          >
            {/* Jump Button ⤴ - DIRECTLY ON TOP (زر القفز فوقهم) */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.preventDefault();
                handleButtonDown('jump');
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                handleButtonUp('jump');
              }}
              onPointerCancel={(e) => {
                e.preventDefault();
                handleButtonUp('jump');
              }}
              className="w-full h-8 sm:h-9 rounded-xl bg-gradient-to-b from-[#16a34a] to-[#15803d] border-2 border-[#a3ed76] active:translate-y-0.5 text-white font-black flex items-center justify-center gap-1.5 shadow-md active:shadow-none select-none cursor-pointer ring-1 ring-emerald-500/40"
              title="قفز المعلم سردينه"
            >
              <span className="text-lg leading-none">⤴</span>
              <span className="text-[11px] sm:text-xs font-sans font-black">قفز</span>
            </button>

            {/* Direction Buttons: Left (شمال) & Right (يمين) SIDE-BY-SIDE (جنب بعض) */}
            <div className="flex flex-row gap-1.5">
              {/* Left Button ◀ (شمال) */}
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  handleButtonDown('left');
                }}
                onPointerUp={(e) => {
                  e.preventDefault();
                  handleButtonUp('left');
                }}
                onPointerCancel={(e) => {
                  e.preventDefault();
                  handleButtonUp('left');
                }}
                className="w-11 h-10 sm:w-12 sm:h-11 rounded-xl bg-gradient-to-b from-[#344b63ef] to-[#172b43ef] border-2 border-[#ffeab0] active:translate-y-0.5 active:border-yellow-400 text-white font-bold flex flex-col items-center justify-center shadow-md active:shadow-none select-none cursor-pointer"
                title="تحرك للشمال / يسار"
              >
                <span className="text-lg leading-none">◀</span>
                <span className="text-[9px] text-slate-300 font-sans leading-tight">شمال</span>
              </button>

              {/* Right Button ▶ (يمين) */}
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  handleButtonDown('right');
                }}
                onPointerUp={(e) => {
                  e.preventDefault();
                  handleButtonUp('right');
                }}
                onPointerCancel={(e) => {
                  e.preventDefault();
                  handleButtonUp('right');
                }}
                className="w-11 h-10 sm:w-12 sm:h-11 rounded-xl bg-gradient-to-b from-[#344b63ef] to-[#172b43ef] border-2 border-[#ffeab0] active:translate-y-0.5 active:border-yellow-400 text-white font-bold flex flex-col items-center justify-center shadow-md active:shadow-none select-none cursor-pointer"
                title="تحرك لليمين"
              >
                <span className="text-lg leading-none">▶</span>
                <span className="text-[9px] text-slate-300 font-sans leading-tight">يمين</span>
              </button>
            </div>
          </div>

          {/* Action Combat Tools: Hammer on top, Wrench and Nuts underneath */}
          <div 
            dir="ltr"
            style={{ direction: 'ltr' }}
            className="flex flex-col items-center gap-1 bg-[#07182bd8] p-1.5 rounded-2xl border-2 border-[#ffda7888] backdrop-blur-sm pointer-events-auto shadow-xl"
          >
            {/* Hammer Button - Top */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.preventDefault();
                handleButtonDown('hammer');
              }}
              onPointerUp={(e) => {
                e.preventDefault();
                handleButtonUp('hammer');
              }}
              className="w-full h-8 sm:h-9 rounded-xl bg-gradient-to-b from-[#d56c3b] to-[#91391e] border-2 border-[#ffeab0] active:translate-y-0.5 text-white font-bold flex items-center justify-center gap-1.5 shadow-md active:shadow-none select-none cursor-pointer"
              title="ضربة الشاكوش"
            >
              <span className="text-base leading-none">🔨</span>
              <span className="text-[11px] sm:text-xs font-sans font-bold">شاكوش</span>
            </button>

            {/* Secondary Tools: Wrench & Nuts side-by-side underneath */}
            <div className="flex flex-row gap-1.5">
              {/* Wrench Button */}
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  handleButtonDown('wrench');
                }}
                onPointerUp={(e) => {
                  e.preventDefault();
                  handleButtonUp('wrench');
                }}
                className="w-11 h-10 sm:w-12 sm:h-11 rounded-xl bg-gradient-to-b from-[#0284c7] to-[#0369a1] border-2 border-[#ffeab0] active:translate-y-0.5 text-white font-bold flex flex-col items-center justify-center shadow-md active:shadow-none select-none cursor-pointer"
                title="ضربة المفتاح"
              >
                <span className="text-base leading-none">🔧</span>
                <span className="text-[9px] text-slate-300 font-sans leading-tight">مفتاح</span>
              </button>

              {/* Nuts Button */}
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  handleButtonDown('nuts');
                }}
                onPointerUp={(e) => {
                  e.preventDefault();
                  handleButtonUp('nuts');
                }}
                className="w-11 h-10 sm:w-12 sm:h-11 rounded-xl bg-gradient-to-b from-[#eab308] to-[#ca8a04] border-2 border-[#ffeab0] active:translate-y-0.5 text-white font-bold flex flex-col items-center justify-center shadow-md active:shadow-none select-none cursor-pointer"
                title="صواميل متفجرة"
              >
                <span className="text-base leading-none">💣</span>
                <span className="text-[9px] text-slate-300 font-sans leading-tight">صواميل</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* WORLD / BACKGROUND SELECTOR MODAL */}
      {showWorldMenu && (
        <div className="fixed inset-0 bg-[#07182bf0] backdrop-blur-md z-40 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-gradient-to-b from-[#1e293b] to-[#0f172a] border-4 border-[#ffda78] rounded-3xl p-5 text-white shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center pb-3 border-b border-slate-700 mb-4">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-400" />
                <h3 className="text-lg font-black text-[#fef08a]">اختر خلفية وعالم اللعبة</h3>
              </div>
              <button
                onClick={() => setShowWorldMenu(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-3 text-right">
              تمتع بخلفيات وبيئات متنوعة ومؤثرات بصرية ساحرة لكل عالم:
            </p>

            <div className="space-y-2.5">
              {WORLD_THEMES.map((theme) => {
                const isActive = currentWorld === theme.id;
                return (
                  <button
                    key={theme.id}
                    onClick={() => switchTheme(theme.id)}
                    className={`w-full p-3 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
                      isActive
                        ? 'bg-amber-500/25 border-amber-400 ring-2 ring-amber-400/40'
                        : 'bg-slate-800/80 border-slate-700 hover:border-slate-500 hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-[#fef08a]">{theme.name}</span>
                        {isActive && (
                          <span className="text-[10px] bg-amber-400 text-slate-950 font-bold px-2 py-0.5 rounded-full">
                            الحالي ✓
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{theme.subtitle}</p>
                    </div>

                    <div
                      className="w-8 h-8 rounded-xl border border-white/20 shadow-inner flex items-center justify-center text-sm"
                      style={{
                        background: `linear-gradient(135deg, ${theme.skyTop}, ${theme.skyBottom})`
                      }}
                    >
                      {theme.id === 1 ? '🌇' : theme.id === 2 ? '🏜️' : theme.id === 3 ? '🏙️' : '🌋'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* START SCREEN MODAL */}
      {!isPlaying && (
        <div className="fixed inset-0 bg-[#07182bdc] backdrop-blur-sm z-30 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-gradient-to-b from-[#fff5d9] to-[#f5d5a1] border-4 border-[#ffb844] rounded-3xl p-6 text-center text-[#26384a] shadow-2xl">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#b53d20] mb-2">
              مملكة المعلم سردينه
            </h1>
            <div className="text-4xl sm:text-5xl my-3 flex items-center justify-center gap-2">
              <span>👨🏻‍🔧</span>
              <span>🔨</span>
              <span>🚗</span>
            </div>

            <div className="bg-[#fff9ea] rounded-2xl p-4 border border-[#f5b844] text-xs sm:text-sm text-right leading-relaxed mb-4 text-[#334155] space-y-2">
              <p className="font-bold text-[#b53d20]">✨ مميزات التحديث المطور:</p>
              <p>
                🎮 <b>تحكم مريح:</b> أزرار الاتجاهات (يسار/يمين) والقفز أصبحت متجاورة جنب بعض لتسهيل الحركة!
              </p>
              <p>
                👾 <b>وحوش جديدة ومتنوعة:</b> حارب خنفساء التروس، العفريت الوثاب، وحش المنشار الصاعق، الوحش الحجري المدرع، عفريت الخردة الطائر، وغول الصفيح العملاق!
              </p>
              <p>
                🌄 <b>خلفيات وبيئات متنوعة:</b> حارة الورشة، وادي الخردة الصحراوي، مدينة النيون المستقبلية، وقلعة الميكانيكا والبراكين!
              </p>
              <p>
                💥 <b>تأثيرات بصرية جذابة:</b> دوائر صدمات ارتدادية، شرارات نار وشرر متطاير، اهتزاز شاشة واقعي، وكلمات تفاعلية مشوقة.
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={startGame}
                className="flex-1 bg-gradient-to-b from-[#35a75e] to-[#16713c] hover:brightness-110 active:scale-95 text-white font-bold py-3.5 px-4 rounded-2xl text-base shadow-lg cursor-pointer flex items-center justify-center gap-2 transition"
              >
                <Play className="w-5 h-5 fill-current" />
                يلا نبدأ يا معلم! 🚀
              </button>
              <button
                onClick={() => setShowGarage(true)}
                className="bg-gradient-to-b from-[#f59e0b] to-[#b45309] hover:brightness-110 active:scale-95 text-white font-bold py-3.5 px-4 rounded-2xl text-base shadow-lg cursor-pointer flex items-center justify-center gap-1 transition"
                title="معرض العربيات"
              >
                <Trophy className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VICTORY & NEW CAR REWARD MODAL */}
      {showRewardModal && (
        <div className="fixed inset-0 bg-[#07182bf0] backdrop-blur-md z-40 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-gradient-to-b from-[#1e293b] to-[#0f172a] border-4 border-[#ffda78] rounded-3xl p-6 text-center text-white shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="inline-flex items-center gap-1.5 bg-[#f59e0b] text-[#1e293b] font-black text-xs px-3 py-1 rounded-full uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              عربية جديدة انضمت لأسطولك!
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#fef08a] mb-1">
              مبروك يا معلم سردينه!
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mb-4">
              جمعت قطع الغيار بالكامل وجمّعت عربيتك بنجاح في الورشة 🏆
            </p>

            <div className="relative bg-gradient-to-b from-[#1e293b] to-[#0f172a] rounded-2xl p-4 border-2 border-yellow-500/40 flex flex-col items-center justify-center mb-4">
              <div className="absolute top-2 right-3 text-xs font-bold text-amber-400 flex items-center gap-1">
                <Award className="w-4 h-4" />
                <span>مكافأة المستوى {latestRewardCar.level}</span>
              </div>

              <canvas ref={rewardCanvasRef} width={260} height={120} className="w-64 h-30" />

              <div className="mt-2 text-center">
                <h3 className="text-lg font-black text-[#fef08a]">{latestRewardCar.name}</h3>
                <p className="text-xs text-cyan-300 font-semibold">{latestRewardCar.subtitle}</p>
              </div>

              {/* Stats Bar */}
              <div className="w-full grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-600/60 text-xs">
                <div className="bg-slate-900/60 rounded-xl p-2 text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-400 mb-1">
                    <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                    <span>السرعة</span>
                  </div>
                  <div className="font-black text-cyan-300">{latestRewardCar.speed}/10</div>
                </div>

                <div className="bg-slate-900/60 rounded-xl p-2 text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-400 mb-1">
                    <Shield className="w-3.5 h-3.5 text-emerald-400" />
                    <span>المتانة</span>
                  </div>
                  <div className="font-black text-emerald-300">{latestRewardCar.durability}/10</div>
                </div>

                <div className="bg-slate-900/60 rounded-xl p-2 text-center">
                  <div className="flex items-center justify-center gap-1 text-slate-400 mb-1">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>العزم</span>
                  </div>
                  <div className="font-black text-amber-300">{latestRewardCar.torque}/10</div>
                </div>
              </div>
            </div>

            <p className="text-xs text-amber-100/90 italic bg-amber-950/40 p-2.5 rounded-xl border border-amber-800/40 mb-4 text-right">
              "{latestRewardCar.description}"
            </p>

            <div className="flex gap-2">
              <button
                onClick={continueNextLevel}
                className="flex-1 bg-gradient-to-b from-[#16a34a] to-[#15803d] hover:brightness-110 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-sm shadow-lg cursor-pointer flex items-center justify-center gap-2 transition"
              >
                <span>المستوى التالي</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setShowRewardModal(false);
                  setSelectedGarageCar(latestRewardCar);
                  setShowGarage(true);
                }}
                className="bg-gradient-to-b from-[#f59e0b] to-[#b45309] hover:brightness-110 active:scale-95 text-white font-bold py-3 px-4 rounded-xl text-sm shadow-lg cursor-pointer flex items-center justify-center gap-1.5 transition"
              >
                <Trophy className="w-4 h-4" />
                <span>كراج العربيات</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GARAGE / ACHIEVEMENTS MODAL */}
      {showGarage && (
        <div className="fixed inset-0 bg-[#07182bf5] backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-2xl bg-gradient-to-b from-[#1e293b] to-[#0f172a] border-4 border-[#ffda78] rounded-3xl p-4 sm:p-6 text-white shadow-2xl flex flex-col max-h-[92vh]">
            <div className="flex justify-between items-center pb-3 border-b border-slate-700">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-500 rounded-xl text-slate-900">
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-[#fef08a]">
                    كراج ومتحف المعلم سردينه
                  </h2>
                  <p className="text-xs text-slate-400">
                    العربيات المجمعة: {collectedCarIds.length} من {CAR_REWARDS.length}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowGarage(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-4">
              {/* Selected Car Showcase Box */}
              <div className="bg-gradient-to-b from-[#334155] to-[#1e293b] rounded-2xl p-4 border-2 border-yellow-500/30 flex flex-col sm:flex-row items-center gap-4">
                <div className="flex-1 flex flex-col items-center justify-center">
                  <canvas ref={previewCanvasRef} width={220} height={100} className="w-56 h-26" />
                  <span className="text-[11px] font-bold text-amber-400 mt-1">
                    {selectedGarageCar.rarity} • المستوى {selectedGarageCar.level}
                  </span>
                </div>

                <div className="flex-1 text-right w-full">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-base font-black text-[#fef08a]">{selectedGarageCar.name}</h3>
                      <p className="text-xs text-cyan-300">{selectedGarageCar.type}</p>
                    </div>
                    {collectedCarIds.includes(selectedGarageCar.id) ? (
                      <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full border border-emerald-500/30">
                        مفتوحة في كراجك ✓
                      </span>
                    ) : (
                      <span className="bg-rose-500/20 text-rose-300 text-[10px] px-2 py-0.5 rounded-full border border-rose-500/30">
                        مغلقة (مستوى {selectedGarageCar.level})
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 my-2 leading-relaxed">
                    {selectedGarageCar.description}
                  </p>

                  <div className="flex flex-wrap gap-1 mb-2">
                    {selectedGarageCar.features.map((f, i) => (
                      <span
                        key={i}
                        className="bg-slate-900/60 text-slate-300 text-[10px] px-2 py-0.5 rounded-md border border-slate-700"
                      >
                        • {f}
                      </span>
                    ))}
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                    <div className="bg-slate-900/60 p-1 rounded text-center">
                      <span className="text-slate-400 block text-[9px]">السرعة</span>
                      <span className="font-bold text-cyan-300">{selectedGarageCar.speed}/10</span>
                    </div>
                    <div className="bg-slate-900/60 p-1 rounded text-center">
                      <span className="text-slate-400 block text-[9px]">المتانة</span>
                      <span className="font-bold text-emerald-300">{selectedGarageCar.durability}/10</span>
                    </div>
                    <div className="bg-slate-900/60 p-1 rounded text-center">
                      <span className="text-slate-400 block text-[9px]">العزم</span>
                      <span className="font-bold text-amber-300">{selectedGarageCar.torque}/10</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Grid of All 10 Cars */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 mb-2">أسطول مستويات المملكة:</h4>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {CAR_REWARDS.map((car) => {
                    const isUnlocked = collectedCarIds.includes(car.id);
                    const isSelected = selectedGarageCar.id === car.id;
                    return (
                      <button
                        key={car.id}
                        onClick={() => setSelectedGarageCar(car)}
                        className={`p-2.5 rounded-xl border text-right transition cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/50'
                            : isUnlocked
                            ? 'bg-slate-800/80 border-slate-700 hover:border-slate-500'
                            : 'bg-slate-900/40 border-slate-800 opacity-60'
                        }`}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-black/40 text-amber-300">
                            م {car.level}
                          </span>
                          {isUnlocked ? (
                            <span className="text-[10px] text-emerald-400 font-bold">✓</span>
                          ) : (
                            <span className="text-[10px] text-slate-500">🔒</span>
                          )}
                        </div>

                        <div className="text-center my-1 text-2xl">
                          {isUnlocked ? (
                            car.id === 1 ? '🚗' :
                            car.id === 2 ? '🛻' :
                            car.id === 3 ? '🏎️' :
                            car.id === 4 ? '🚙' :
                            car.id === 5 ? '🚓' :
                            car.id === 6 ? '🏁' :
                            car.id === 7 ? '🚒' :
                            car.id === 8 ? '🚘' :
                            car.id === 9 ? '⚡' : '👑'
                          ) : (
                            '🔒'
                          )}
                        </div>

                        <div className="text-[11px] font-bold text-slate-200 truncate">
                          {car.name.split('(')[0]}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-700 flex justify-end">
              <button
                onClick={() => setShowGarage(false)}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold py-2 px-5 rounded-xl text-sm transition cursor-pointer"
              >
                إغلاق الكراج والعودة للعب
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
