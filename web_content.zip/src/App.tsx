import React, { useState, useEffect } from 'react';
import { Pantalla } from './types';
import { SplashView } from './components/SplashView';
import { PermisosModal } from './components/PermisosModal';
import { InicioView } from './components/InicioView';
import { CarpetaView } from './components/CarpetaView';
import { CamaraView } from './components/CamaraView';
import { PreviaView } from './components/PreviaView';
import { VisorView } from './components/VisorView';
import { AjustesView } from './components/AjustesView';
import { SalidaView } from './components/SalidaView';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [pantalla, setPantalla] = useState<Pantalla>(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      return { tipo: 'inicio' };
    }
    return { tipo: 'splash' };
  });
  const [mostrarPermisos, setMostrarPermisos] = useState(false);

  // Tema claro / oscuro persistente Requerimiento 32
  const [oscuro, setOscuro] = useState(() => {
    const guardado = localStorage.getItem('galeria_taller_tema_oscuro');
    return guardado !== null ? guardado === 'true' : true; // Por defecto oscuro para taller
  });

  // Notificación tipo Toast para guardado exitoso Requerimiento 22
  const [toastMensaje, setToastMensaje] = useState<string | null>(null);

  const mostrarToast = (mensaje: string) => {
    setToastMensaje(mensaje);
    setTimeout(() => {
      setToastMensaje(null);
    }, 3200);
  };

  useEffect(() => {
    localStorage.setItem('galeria_taller_tema_oscuro', oscuro ? 'true' : 'false');
    if (oscuro) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [oscuro]);

  // Manejo de Splash finalizado
  const handleSplashFinalizado = () => {
    const yaVisto = localStorage.getItem('galeria_taller_permisos_vistos');
    if (yaVisto === 'true') {
      setPantalla({ tipo: 'inicio' });
    } else {
      setMostrarPermisos(true);
    }
  };

  const handlePermisosAceptados = () => {
    localStorage.setItem('galeria_taller_permisos_vistos', 'true');
    setMostrarPermisos(false);
    setPantalla({ tipo: 'inicio' });
  };

  return (
    <div className={`min-h-screen ${oscuro ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'}`}>
      {/* Toast Flotante Requerimiento 22 */}
      {toastMensaje && (
        <div className="fixed top-5 inset-x-0 z-50 flex justify-center px-4 pointer-events-none animate-bounce">
          <div className="bg-slate-900/95 dark:bg-white/95 text-white dark:text-slate-900 px-5 py-3 rounded-2xl shadow-2xl border border-amber-500/30 flex items-center gap-2.5 backdrop-blur-md">
            <CheckCircle2 className="text-amber-400 dark:text-amber-600 shrink-0" size={20} />
            <span className="text-sm font-bold">{toastMensaje}</span>
          </div>
        </div>
      )}

      {/* Pantalla Splash Requerimiento 1 */}
      {pantalla.tipo === 'splash' && (
        <SplashView onFinalizar={handleSplashFinalizado} />
      )}

      {/* Modal Permisos Requerimiento 2 */}
      {mostrarPermisos && (
        <PermisosModal onAceptado={handlePermisosAceptados} />
      )}

      {/* Pantalla Principal (Carpetas) Requerimiento 3-10 */}
      {pantalla.tipo === 'inicio' && (
        <InicioView
          onAbrirCarpeta={(carpetaId) => setPantalla({ tipo: 'carpeta', carpetaId })}
          onIrAjustes={() => setPantalla({ tipo: 'ajustes' })}
        />
      )}

      {/* Pantalla Interior de Carpeta Requerimiento 11-13 */}
      {pantalla.tipo === 'carpeta' && (
        <CarpetaView
          carpetaId={pantalla.carpetaId}
          onVolver={() => setPantalla({ tipo: 'inicio' })}
          onAbrirCamara={() => setPantalla({ tipo: 'camara', carpetaId: pantalla.carpetaId })}
          onVerFoto={(fotoId) =>
            setPantalla({ tipo: 'visor', carpetaId: pantalla.carpetaId, fotoId })
          }
        />
      )}

      {/* Pantalla de Cámara Requerimiento 14-17 */}
      {pantalla.tipo === 'camara' && (
        <CamaraView
          onAtras={() => setPantalla({ tipo: 'carpeta', carpetaId: pantalla.carpetaId })}
          onFotoCapturada={(tempFoto) =>
            setPantalla({
              tipo: 'previa',
              tempFoto,
              carpetaId: pantalla.carpetaId,
            })
          }
        />
      )}

      {/* Pantalla de Previa y Guardado Requerimiento 18-22, 34 */}
      {pantalla.tipo === 'previa' && (
        <PreviaView
          tempFoto={pantalla.tempFoto}
          carpetaInicialId={pantalla.carpetaId}
          onRepetir={() => setPantalla({ tipo: 'camara', carpetaId: pantalla.carpetaId })}
          onGuardado={(destinoCarpetaId) => {
            mostrarToast('Foto guardada exitosamente en la carpeta');
            setPantalla({ tipo: 'carpeta', carpetaId: destinoCarpetaId });
          }}
          onSalirSinGuardar={() =>
            setPantalla({ tipo: 'carpeta', carpetaId: pantalla.carpetaId })
          }
        />
      )}

      {/* Pantalla Visor de Foto Requerimiento 23-28 */}
      {pantalla.tipo === 'visor' && (
        <VisorView
          carpetaId={pantalla.carpetaId}
          fotoInicialId={pantalla.fotoId}
          onVolver={() => setPantalla({ tipo: 'carpeta', carpetaId: pantalla.carpetaId })}
        />
      )}

      {/* Pantalla de Ajustes Requerimiento 31-33 */}
      {pantalla.tipo === 'ajustes' && (
        <AjustesView
          oscuro={oscuro}
          onCambiarTema={setOscuro}
          onVolver={() => setPantalla({ tipo: 'inicio' })}
          onSalirApp={() => setPantalla({ tipo: 'salida' })}
        />
      )}

      {/* Pantalla de Salida Requerimiento 35 */}
      {pantalla.tipo === 'salida' && (
        <SalidaView
          onReabrir={() => setPantalla({ tipo: 'inicio' })}
        />
      )}
    </div>
  );
}
