import React, { useState, useEffect } from 'react';
import { AppHeader } from './components/AppHeader';
import { HomeDashboard } from './components/HomeDashboard';
import { BottomNavigation, TabType } from './components/BottomNavigation';
import { NotesTab } from './components/NotesTab';
import { VideoTab } from './components/VideoTab';
import { FollowTab } from './components/FollowTab';
import { MoreTab } from './components/MoreTab';
import { ChapterReaderModal } from './components/ChapterReaderModal';
import { NavigationDrawer } from './components/NavigationDrawer';
import {
  ThemeModal,
  NotificationModal,
  ShareModal,
  PremiumModal,
  CategoryBrowserModal,
} from './components/AppModals';
import { BIOLOGY_CHAPTERS, ChapterData } from './data/biologyData';
import { Smartphone, Monitor } from 'lucide-react';

export function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [selectedClass, setSelectedClass] = useState<'11' | '12'>('11');
  const [themeMode, setThemeMode] = useState<'teal' | 'sepia' | 'dark'>(() => {
    return (localStorage.getItem('jv_theme') as 'teal' | 'sepia' | 'dark') || 'teal';
  });

  // Modals state
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isPremiumModalOpen, setIsPremiumModalOpen] = useState(false);
  const [categoryModal, setCategoryModal] = useState<'premium_notes' | 'handwritten_notes' | 'ncert_book' | 'ncert_solutions' | 'video_classes' | 'mcq_pdf' | 'important_questions' | 'mind_maps' | null>(null);

  // Active Reading chapter
  const [activeChapter, setActiveChapter] = useState<ChapterData | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'premium' | 'handwritten' | 'ncert' | 'solutions' | 'mcq' | 'important' | 'mindmap'>('premium');

  // Premium status & Bookmarks from local storage
  const [isPremium, setIsPremium] = useState<boolean>(() => {
    return localStorage.getItem('jv_premium') === 'true';
  });
  const [bookmarkedIds, setBookmarkedIds] = useState<number[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('jv_bookmarks') || '[1, 8]');
    } catch {
      return [1, 8];
    }
  });

  // Frame view switcher on wide screens
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);

  // Persist settings
  useEffect(() => {
    localStorage.setItem('jv_theme', themeMode);
  }, [themeMode]);

  useEffect(() => {
    localStorage.setItem('jv_premium', isPremium ? 'true' : 'false');
  }, [isPremium]);

  useEffect(() => {
    localStorage.setItem('jv_bookmarks', JSON.stringify(bookmarkedIds));
  }, [bookmarkedIds]);

  const toggleBookmark = (id: number) => {
    setBookmarkedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectCategory = (cat: 'premium_notes' | 'handwritten_notes' | 'ncert_book' | 'ncert_solutions' | 'video_classes' | 'mcq_pdf' | 'important_questions' | 'mind_maps') => {
    if (cat === 'premium_notes') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('premium');
    } else if (cat === 'handwritten_notes') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('handwritten');
    } else if (cat === 'ncert_book') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('premium');
    } else if (cat === 'ncert_solutions') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('solutions');
    } else if (cat === 'video_classes') {
      setCurrentTab('video');
    } else if (cat === 'mcq_pdf') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('mcq');
    } else if (cat === 'important_questions') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('important');
    } else if (cat === 'mind_maps') {
      setActiveChapter(BIOLOGY_CHAPTERS[0]);
      setActiveSubTab('mindmap');
    }
  };

  const openChapterWithTab = (ch: ChapterData, subTab: any = 'premium') => {
    setActiveChapter(ch);
    setActiveSubTab(subTab);
  };

  const appThemeClasses = {
    teal: 'bg-slate-100 text-slate-800',
    sepia: 'bg-[#fbf7ee] text-[#433422]',
    dark: 'bg-slate-950 text-slate-100',
  }[themeMode];

  return (
    <div className={`min-h-screen flex flex-col items-center justify-start ${appThemeClasses} transition-colors duration-200 antialiased`}>
      {/* Top Device Preview Bar on desktop */}
      <div className="hidden md:flex w-full bg-slate-900 text-slate-300 py-1.5 px-6 items-center justify-between text-xs z-50 border-b border-slate-800">
        <div className="flex items-center gap-2 font-medium font-devanagari">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
          <span>जीव विज्ञान साथी — कक्षा 11 एवं 12 हिंदी अध्ययन ऐप</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-slate-400">व्यू मोड:</span>
          <button
            onClick={() => setIsPhoneFrame(true)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors ${
              isPhoneFrame ? 'bg-[#00838f] text-white font-bold' : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            मोबाइल फोन दृश्य (स्क्रीनशॉट अनुसार)
          </button>
          <button
            onClick={() => setIsPhoneFrame(false)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors ${
              !isPhoneFrame ? 'bg-[#00838f] text-white font-bold' : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            विस्तृत डेस्कटॉप दृश्य
          </button>
        </div>
      </div>

      {/* Main App Container */}
      <div
        className={`w-full min-h-screen flex flex-col relative transition-all duration-300 ${
          isPhoneFrame
            ? 'max-w-md shadow-2xl md:my-4 md:rounded-3xl overflow-hidden border border-slate-300 md:min-h-[844px] bg-white'
            : 'max-w-4xl shadow-xl md:my-4 md:rounded-2xl overflow-hidden bg-white'
        }`}
      >
        {/* App Header */}
        <AppHeader
          onOpenDrawer={() => setIsDrawerOpen(true)}
          onOpenTheme={() => setIsThemeModalOpen(true)}
          onOpenNotification={() => setIsNotificationModalOpen(true)}
          onOpenShare={() => setIsShareModalOpen(true)}
          selectedClass={selectedClass}
          onChangeClass={setSelectedClass}
          notificationCount={1}
          themeMode={themeMode}
        />

        {/* Content Tabs */}
        <div className="flex-1 overflow-x-hidden">
          {currentTab === 'home' && (
            <HomeDashboard
              selectedClass={selectedClass}
              onSelectCategory={handleSelectCategory}
              onOpenPremium={() => setIsPremiumModalOpen(true)}
              isPremiumUser={isPremium}
              onViewAll={() => setCategoryModal('premium_notes')}
              onSelectChapter={(ch) => openChapterWithTab(ch, 'premium')}
              recentChapter={BIOLOGY_CHAPTERS[0]}
            />
          )}

          {currentTab === 'notes' && (
            <NotesTab
              selectedClass={selectedClass}
              onSelectChapter={openChapterWithTab}
              bookmarkedChapterIds={bookmarkedIds}
              onToggleBookmark={toggleBookmark}
            />
          )}

          {currentTab === 'video' && (
            <VideoTab
              onSelectChapterVideo={(ch) => openChapterWithTab(ch, 'premium')}
            />
          )}

          {currentTab === 'follow' && <FollowTab />}

          {currentTab === 'more' && <MoreTab />}
        </div>

        {/* Bottom Navigation Bar */}
        <BottomNavigation
          currentTab={currentTab}
          onChangeTab={(tab) => {
            setCurrentTab(tab);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />

        {/* Slide-out Navigation Drawer */}
        <NavigationDrawer
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          selectedClass={selectedClass}
          onChangeClass={setSelectedClass}
          onOpenPremium={() => setIsPremiumModalOpen(true)}
          onOpenTheme={() => setIsThemeModalOpen(true)}
          onOpenShare={() => setIsShareModalOpen(true)}
          onOpenBookmarks={() => {
            setCurrentTab('notes');
          }}
          onOpenDownloads={() => {
            setCurrentTab('more');
          }}
          bookmarkCount={bookmarkedIds.length}
        />

        {/* Theme Changer Modal */}
        <ThemeModal
          isOpen={isThemeModalOpen}
          onClose={() => setIsThemeModalOpen(false)}
          currentTheme={themeMode}
          onSelectTheme={setThemeMode}
        />

        {/* Notification Alert Modal */}
        <NotificationModal
          isOpen={isNotificationModalOpen}
          onClose={() => setIsNotificationModalOpen(false)}
        />

        {/* Share App Modal */}
        <ShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
        />

        {/* Remove Ads & Premium Modal */}
        <PremiumModal
          isOpen={isPremiumModalOpen}
          onClose={() => setIsPremiumModalOpen(false)}
          isPremium={isPremium}
          onTogglePremium={() => setIsPremium(!isPremium)}
        />

        {/* Category Browser Modal ("सभी देखें") */}
        <CategoryBrowserModal
          isOpen={categoryModal !== null}
          onClose={() => setCategoryModal(null)}
          category={categoryModal}
          onSelectChapterWithTab={openChapterWithTab}
          selectedClass={selectedClass}
        />

        {/* Full Chapter Study & Handwritten Notes Reader */}
        {activeChapter && (
          <ChapterReaderModal
            chapter={activeChapter}
            initialSubTab={activeSubTab}
            onClose={() => setActiveChapter(null)}
            onSelectChapter={(ch) => setActiveChapter(ch)}
            isBookmarked={bookmarkedIds.includes(activeChapter.chapterNumber)}
            onToggleBookmark={toggleBookmark}
            themeMode={themeMode}
          />
        )}
      </div>
    </div>
  );
}

export default App;
