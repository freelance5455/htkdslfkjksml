import React, { useState, useEffect } from 'react';
import {
  MessageSquare, Users, Shield, Clock, User as UserIcon,
  Search, MoreVertical, LogOut, Phone, ShieldAlert,
  Plus, AlertCircle, Wifi, WifiOff, Bell, BellRing, Bot
} from 'lucide-react';
import type { User, Chat } from './types/index.ts';
import { api, wsClient } from './services/api.ts';
import { notificationService, type InAppToast } from './services/notificationService.ts';
import { soundService } from './services/soundService.ts';
import { APP_LOGO, WHATSAPP_SERVICE_NUMBER, WHATSAPP_SERVICE_URL } from './constants.ts';
import { LoginScreen } from './components/LoginScreen.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { AdminLoginModal } from './components/AdminLoginModal.tsx';
import { WhatsAppModal } from './components/WhatsAppModal.tsx';
import { FirstLoginModal } from './components/FirstLoginModal.tsx';
import { ReportModal } from './components/ReportModal.tsx';
import { ChatList } from './components/ChatList.tsx';
import { ChatThread } from './components/ChatThread.tsx';
import { UserDirectory } from './components/UserDirectory.tsx';
import { GroupsTab } from './components/GroupsTab.tsx';
import { StatusTab } from './components/StatusTab.tsx';
import { ProfileTab } from './components/ProfileTab.tsx';
import { CallModal, type ActiveCallState } from './components/CallModal.tsx';
import { IncomingCallModal } from './components/IncomingCallModal.tsx';
import { NotificationToast } from './components/NotificationToast.tsx';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [showFirstLoginPasswordModal, setShowFirstLoginPasswordModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'chats' | 'users' | 'groups' | 'status' | 'profile'>('chats');
  const [activeChat, setActiveChat] = useState<Chat | null>(null);

  // Overlays & Modals
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [showAdminLoginModal, setShowAdminLoginModal] = useState(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState(false);
  const [isTopMenuOpen, setIsTopMenuOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');

  // In-App Toast
  const [currentToast, setCurrentToast] = useState<InAppToast | null>(null);

  // Calling States
  const [activeCall, setActiveCall] = useState<ActiveCallState | null>(null);
  const [incomingCall, setIncomingCall] = useState<{
    callId: string;
    callerId: string;
    callerName: string;
    callerAvatar: string;
    isVideo: boolean;
    chatId?: string;
  } | null>(null);

  // Report Modal state
  const [reportData, setReportData] = useState<{
    isOpen: boolean;
    reportedUserId: string;
    reportedUsername: string;
    messageId?: string;
    evidence?: string;
  }>({
    isOpen: false,
    reportedUserId: '',
    reportedUsername: '',
  });

  // Restore stored session on load
  useEffect(() => {
    const savedUser = localStorage.getItem('ug_current_user');
    const savedToken = localStorage.getItem('ug_token');
    if (savedUser && savedToken) {
      try {
        const parsed = JSON.parse(savedUser);
        setCurrentUser(parsed);
        setToken(savedToken);
        wsClient.connect(parsed.id);
      } catch (e) {
        localStorage.removeItem('ug_current_user');
      }
    }

    if (notificationService.isSupported()) {
      setNotificationPermission(notificationService.getPermission());
    }

    // Subscribe to in-app toasts
    const unsubToasts = notificationService.subscribeToToasts((toast) => {
      setCurrentToast(toast);
      setTimeout(() => {
        setCurrentToast(prev => (prev?.id === toast.id ? null : prev));
      }, 5000);
    });

    return () => {
      unsubToasts();
    };
  }, []);

  // Real-Time Events (Messages, Calls, Presence, Bans)
  useEffect(() => {
    const unsubConn = wsClient.on('connection:change', (data) => {
      setIsOnline(Boolean(data.online));
    });

    const unsubBanned = wsClient.on('user:banned', (data) => {
      if (currentUser) {
        setCurrentUser(prev => prev ? { ...prev, status: 'banned', banInfo: data.banRecord } : null);
      }
    });

    // Real-Time Message Notification
    const unsubMsg = wsClient.on('message:new', (data) => {
      if (currentUser && data.message.senderId !== currentUser.id) {
        // If user is currently looking at another chat or tab
        const isCurrentActiveChat = activeChat && activeChat.id === data.chatId;
        if (!isCurrentActiveChat) {
          notificationService.notifyMessage({
            senderName: data.message.senderName,
            text: data.message.text || 'Sent an attachment',
            avatar: data.message.senderAvatar,
            chatId: data.chatId,
          });
        }
      }
    });

    // Calling Listeners
    const unsubIncoming = wsClient.on('call:incoming', (data) => {
      if (currentUser && data.callerId !== currentUser.id) {
        setIncomingCall({
          callId: data.callId,
          callerId: data.callerId,
          callerName: data.callerName,
          callerAvatar: data.callerAvatar,
          isVideo: Boolean(data.isVideo),
          chatId: data.chatId,
        });
        notificationService.notifyCall({
          callerName: data.callerName,
          callerAvatar: data.callerAvatar,
          isVideo: data.isVideo,
          chatId: data.chatId,
        });
      }
    });

    const unsubAccepted = wsClient.on('call:accepted', (data) => {
      setActiveCall(prev => {
        if (prev && prev.callId === data.callId) {
          return { ...prev, status: 'connected' };
        }
        return prev;
      });
    });

    const unsubRejected = wsClient.on('call:rejected', (data) => {
      soundService.stopRingtone();
      soundService.playCallEndedSound();
      alert(`Call Declined: ${data.reason || 'User busy'}`);
      setActiveCall(null);
    });

    const unsubEnded = wsClient.on('call:ended', () => {
      soundService.stopRingtone();
      soundService.playCallEndedSound();
      setActiveCall(null);
      setIncomingCall(null);
    });

    return () => {
      unsubConn();
      unsubBanned();
      unsubMsg();
      unsubIncoming();
      unsubAccepted();
      unsubRejected();
      unsubEnded();
    };
  }, [currentUser, activeChat]);

  const handleRequestNotificationPermission = async () => {
    const perm = await notificationService.requestPermission();
    setNotificationPermission(perm);
    if (perm === 'granted') {
      soundService.playMessageSound();
    }
  };

  const handleLoginSuccess = (user: User, userToken: string, isTempPassword?: boolean) => {
    setCurrentUser(user);
    setToken(userToken);
    localStorage.setItem('ug_current_user', JSON.stringify(user));
    localStorage.setItem('ug_token', userToken);
    wsClient.connect(user.id);

    if (isTempPassword) {
      setShowFirstLoginPasswordModal(true);
    }
  };

  const handleLogout = () => {
    wsClient.disconnect();
    setCurrentUser(null);
    setToken(null);
    setActiveChat(null);
    setActiveCall(null);
    setIncomingCall(null);
    soundService.stopRingtone();
    localStorage.removeItem('ug_current_user');
    localStorage.removeItem('ug_token');
  };

  const handleStartDirectChat = async (targetUserId: string) => {
    if (!currentUser) return;
    try {
      const chat = await api.createDirectChat(currentUser.id, targetUserId);
      setActiveChat(chat);
      setActiveTab('chats');
    } catch (e) {
      alert('Failed to start chat');
    }
  };

  const handleOpenAIChat = async () => {
    if (!currentUser) return;
    try {
      const chat = await api.createDirectChat(currentUser.id, 'usr_ug_ai_agent');
      setActiveChat(chat);
      setActiveTab('chats');
    } catch (e) {
      console.error(e);
      alert('Could not start chat with Unknown Gamer AI Agent');
    }
  };

  const handleStartCall = (targetUser: User, isVideo: boolean) => {
    if (!currentUser) return;
    const callId = 'call_' + Date.now();

    setActiveCall({
      callId,
      isCaller: true,
      isVideo,
      remoteUser: {
        id: targetUser.id,
        username: targetUser.username,
        fullName: targetUser.fullName,
        avatarUrl: targetUser.avatarUrl,
        verifiedBlueTick: targetUser.verifiedBlueTick,
      },
      status: 'calling',
    });

    soundService.startIncomingRingtone();

    wsClient.send({
      type: 'call:invite',
      callId,
      callerId: currentUser.id,
      callerName: currentUser.fullName,
      callerAvatar: currentUser.avatarUrl,
      targetUserId: targetUser.id,
      isVideo,
      chatId: activeChat?.id,
    });
  };

  const handleAcceptIncomingCall = () => {
    if (!incomingCall || !currentUser) return;
    soundService.stopRingtone();

    wsClient.send({
      type: 'call:accept',
      callId: incomingCall.callId,
      callerId: incomingCall.callerId,
      acceptorId: currentUser.id,
    });

    setActiveCall({
      callId: incomingCall.callId,
      isCaller: false,
      isVideo: incomingCall.isVideo,
      remoteUser: {
        id: incomingCall.callerId,
        username: incomingCall.callerName,
        fullName: incomingCall.callerName,
        avatarUrl: incomingCall.callerAvatar,
      },
      status: 'connected',
    });

    setIncomingCall(null);
  };

  const handleDeclineIncomingCall = () => {
    if (!incomingCall || !currentUser) return;
    soundService.stopRingtone();

    wsClient.send({
      type: 'call:reject',
      callId: incomingCall.callId,
      callerId: incomingCall.callerId,
      targetUserId: currentUser.id,
      reason: 'Declined by gamer',
    });

    setIncomingCall(null);
  };

  const handleEndActiveCall = () => {
    if (!activeCall || !currentUser) return;
    soundService.stopRingtone();
    soundService.playCallEndedSound();

    wsClient.send({
      type: 'call:end',
      callId: activeCall.callId,
      targetUserId: activeCall.remoteUser.id,
      senderId: currentUser.id,
    });

    setActiveCall(null);
  };

  const openReportModal = (reportedUserId: string, reportedUsername: string, messageId?: string, evidence?: string) => {
    setReportData({
      isOpen: true,
      reportedUserId,
      reportedUsername,
      messageId,
      evidence,
    });
  };

  // If user is not logged in: show Login Screen
  if (!currentUser) {
    return (
      <>
        <LoginScreen
          onLoginSuccess={handleLoginSuccess}
          onOpenWhatsApp={() => setShowWhatsAppModal(true)}
          onOpenAdminLogin={() => setShowAdminLoginModal(true)}
        />

        <AdminLoginModal
          isOpen={showAdminLoginModal}
          onClose={() => setShowAdminLoginModal(false)}
          onSuccess={() => {
            setShowAdminLoginModal(false);
            setIsAdminOpen(true);
          }}
        />

        <WhatsAppModal
          isOpen={showWhatsAppModal}
          onClose={() => setShowWhatsAppModal(false)}
        />

        {isAdminOpen && (
          <AdminDashboard
            onClose={() => setIsAdminOpen(false)}
            onLogout={() => {
              setIsAdminOpen(false);
              localStorage.removeItem('ug_admin_token');
            }}
          />
        )}
      </>
    );
  }

  // If account is banned: show Ban Screen with appeal
  if (currentUser.status === 'banned') {
    return (
      <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[#080a0f] text-slate-100">
        <div className="w-full max-w-md rounded-2xl bg-[#0e121d] border border-red-500/50 p-6 text-center space-y-4 shadow-[0_0_30px_rgba(239,68,68,0.2)]">
          <div className="w-16 h-16 rounded-2xl bg-red-950/80 border border-red-500 flex items-center justify-center text-red-400 mx-auto">
            <AlertCircle size={32} />
          </div>
          <h2 className="text-xl font-black text-white uppercase tracking-wider font-display">
            Account Suspended / Banned
          </h2>
          <p className="text-xs text-slate-300">
            Your account <span className="text-red-400 font-mono font-bold">@{currentUser.username}</span> has been suspended by the Unknown Gamer Administration.
          </p>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-red-900/60 text-left text-xs font-mono space-y-1">
            <div className="text-slate-400">Reason: {currentUser.banInfo?.reason || 'Violation of esports policies'}</div>
            {currentUser.banInfo?.expiresAt && (
              <div className="text-slate-400">
                Expires: {new Date(currentUser.banInfo.expiresAt).toLocaleDateString()}
              </div>
            )}
          </div>

          <div className="pt-2 space-y-2">
            <button
              onClick={() => setShowWhatsAppModal(true)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20"
            >
              <Phone size={16} />
              <span>Contact Admin for Appeal on WhatsApp</span>
            </button>
            <button
              onClick={handleLogout}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Logout
            </button>
          </div>
        </div>

        <WhatsAppModal
          isOpen={showWhatsAppModal}
          onClose={() => setShowWhatsAppModal(false)}
        />
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-[#06080d] text-slate-100 flex flex-col overflow-hidden font-sans select-none">
      {/* Offline Status Warning Bar */}
      {!isOnline && (
        <div className="bg-amber-950/90 border-b border-amber-500/40 px-4 py-1.5 text-center text-[11px] font-semibold text-amber-300 flex items-center justify-center gap-1.5 shrink-0 z-50">
          <WifiOff size={14} />
          <span>Reconnecting to Unknown Gamer Server...</span>
        </div>
      )}

      {/* Push Notification Enable Banner */}
      {notificationPermission === 'default' && (
        <div className="bg-gradient-to-r from-cyan-950 to-blue-950 border-b border-cyan-500/40 px-4 py-2 flex items-center justify-between gap-3 text-xs shrink-0 z-40">
          <div className="flex items-center gap-2 text-cyan-200">
            <BellRing size={16} className="text-cyan-400 animate-pulse" />
            <span>Enable Mobile & Browser Notifications for incoming calls and messages</span>
          </div>
          <button
            onClick={handleRequestNotificationPermission}
            className="px-3 py-1 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs shrink-0"
          >
            Enable Alerts
          </button>
        </div>
      )}

      {/* Floating In-App Message Toast */}
      <NotificationToast
        toast={currentToast}
        onOpen={async (chatId) => {
          if (chatId) {
            const chats = await api.getChats(currentUser.id);
            const found = chats.find(c => c.id === chatId);
            if (found) {
              setActiveChat(found);
              setActiveTab('chats');
            }
          }
          setCurrentToast(null);
        }}
        onDismiss={() => setCurrentToast(null)}
      />

      {/* Main Responsive Layout: Desktop 2-pane / Mobile single pane */}
      <div className="flex-1 flex overflow-hidden max-w-7xl w-full mx-auto shadow-2xl border-x border-slate-800/60">
        {/* Left Column / Main Screen */}
        <div className={`flex-1 flex flex-col h-full bg-[#080a0f] ${activeChat ? 'hidden lg:flex lg:w-96 lg:max-w-md lg:border-r lg:border-slate-800/80' : 'flex'}`}>
          {/* Top Android App Action Bar */}
          <header className="h-16 px-4 bg-[#0a0f18] border-b border-cyan-500/20 flex items-center justify-between shrink-0 z-20">
            <div className="flex items-center gap-2.5">
              <img
                src={APP_LOGO}
                alt="UG Logo"
                className="w-9 h-9 rounded-xl object-cover border border-cyan-400/40 shadow-[0_0_10px_rgba(0,210,255,0.3)] bg-slate-900"
              />
              <div>
                <h1 className="text-base font-black tracking-wider uppercase text-white font-display flex items-center gap-1.5 leading-none">
                  <span>Unknown</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                    Gamer
                  </span>
                </h1>
                <div className="text-[10px] text-cyan-400 font-mono tracking-widest uppercase mt-0.5">
                  Esports Messaging
                </div>
              </div>
            </div>

            {/* Top Right Actions */}
            <div className="flex items-center gap-1 relative">
              <button
                onClick={() => setActiveTab('users')}
                className="p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-900 transition-colors"
                title="Search Gamers"
              >
                <Search size={18} />
              </button>

              {/* 3 Dots Menu Button */}
              <button
                onClick={() => setIsTopMenuOpen(!isTopMenuOpen)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors"
                aria-label="App Menu"
              >
                <MoreVertical size={18} />
              </button>

              {/* 3 Dots Dropdown Menu */}
              {isTopMenuOpen && (
                <div className="absolute right-0 top-12 w-52 rounded-2xl bg-[#0c121e] border border-cyan-500/30 p-1.5 shadow-2xl z-40 text-xs animate-in fade-in duration-100">
                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      setActiveTab('users');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors text-left"
                  >
                    <Plus size={15} className="text-cyan-400" />
                    <span>New Chat</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      setActiveTab('groups');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors text-left"
                  >
                    <Users size={15} className="text-cyan-400" />
                    <span>New Group / Clan</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      setActiveTab('profile');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors text-left"
                  >
                    <UserIcon size={15} className="text-cyan-400" />
                    <span>Profile & Settings</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      handleOpenAIChat();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-cyan-300 hover:text-cyan-200 hover:bg-cyan-950/40 transition-colors text-left font-medium"
                  >
                    <Bot size={15} className="text-cyan-400" />
                    <span>AI Support Agent</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      setShowWhatsAppModal(true);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 transition-colors text-left font-medium"
                  >
                    <Phone size={15} />
                    <span>WhatsApp Service</span>
                  </button>

                  <div className="my-1 border-t border-slate-800" />

                  {/* Secret Admin Button */}
                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      setShowAdminLoginModal(true);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-cyan-300 hover:text-cyan-200 hover:bg-cyan-950/60 transition-colors text-left font-semibold"
                  >
                    <ShieldAlert size={15} className="text-cyan-400" />
                    <span>Admin Login (Secret)</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsTopMenuOpen(false);
                      handleLogout();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-red-400 hover:text-red-300 hover:bg-red-950/40 transition-colors text-left"
                  >
                    <LogOut size={15} />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          </header>

          {/* Active Navigation Tab Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {activeTab === 'chats' && (
              <ChatList
                currentUser={currentUser}
                activeChatId={activeChat?.id}
                onSelectChat={(chat) => setActiveChat(chat)}
                onStartNewChat={() => setActiveTab('users')}
                onOpenAIChat={handleOpenAIChat}
              />
            )}

            {activeTab === 'users' && (
              <UserDirectory
                currentUser={currentUser}
                onStartChat={handleStartDirectChat}
                onOpenReport={openReportModal}
              />
            )}

            {activeTab === 'groups' && (
              <GroupsTab
                currentUser={currentUser}
                onOpenChat={(chat) => {
                  setActiveChat(chat);
                  setActiveTab('chats');
                }}
              />
            )}

            {activeTab === 'status' && (
              <StatusTab currentUser={currentUser} />
            )}

            {activeTab === 'profile' && (
              <ProfileTab
                currentUser={currentUser}
                onLogout={handleLogout}
                onOpenWhatsApp={() => setShowWhatsAppModal(true)}
                onUserUpdated={(updated) => setCurrentUser(updated)}
              />
            )}
          </div>

          {/* Android Fixed Bottom Navigation Bar */}
          <nav className="h-16 bg-[#0a0f18] border-t border-slate-800/80 grid grid-cols-5 items-center shrink-0 z-20">
            <button
              onClick={() => setActiveTab('chats')}
              className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                activeTab === 'chats' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageSquare size={20} className={activeTab === 'chats' ? 'stroke-[2.5]' : ''} />
              <span className="text-[10px] font-semibold mt-1">Chats</span>
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                activeTab === 'users' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users size={20} className={activeTab === 'users' ? 'stroke-[2.5]' : ''} />
              <span className="text-[10px] font-semibold mt-1">Users</span>
            </button>

            <button
              onClick={() => setActiveTab('groups')}
              className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                activeTab === 'groups' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield size={20} className={activeTab === 'groups' ? 'stroke-[2.5]' : ''} />
              <span className="text-[10px] font-semibold mt-1">Squads</span>
            </button>

            <button
              onClick={() => setActiveTab('status')}
              className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                activeTab === 'status' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Clock size={20} className={activeTab === 'status' ? 'stroke-[2.5]' : ''} />
              <span className="text-[10px] font-semibold mt-1">Status</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                activeTab === 'profile' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserIcon size={20} className={activeTab === 'profile' ? 'stroke-[2.5]' : ''} />
              <span className="text-[10px] font-semibold mt-1">Profile</span>
            </button>
          </nav>
        </div>

        {/* Right Column: Chat Thread on Desktop or Mobile overlay */}
        {activeChat ? (
          <div className="flex-1 flex flex-col h-full bg-[#080b12]">
            <ChatThread
              chat={activeChat}
              currentUser={currentUser}
              onBack={() => setActiveChat(null)}
              onOpenReport={openReportModal}
              onOpenWhatsApp={() => setShowWhatsAppModal(true)}
              onStartCall={handleStartCall}
            />
          </div>
        ) : (
          <div className="hidden lg:flex flex-1 flex-col items-center justify-center text-center p-8 bg-[#07090e] border-l border-slate-800/80">
            <div className="w-24 h-24 rounded-3xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-4 shadow-[0_0_30px_rgba(0,210,255,0.2)]">
              <img
                src={APP_LOGO}
                alt="Unknown Gamer"
                className="w-20 h-20 rounded-2xl object-cover"
              />
            </div>
            <h2 className="text-xl font-black text-white uppercase tracking-wider font-display">
              Unknown Gamer Arena
            </h2>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              Select a conversation or clan squad from the directory to start real-time messaging, voice, or video calling.
            </p>
            <div className="mt-4 flex items-center gap-2">
              <button
                onClick={() => setActiveTab('users')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 font-bold text-xs"
              >
                Browse Permitted Gamers
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ACTIVE CALL MODAL (Voice & Video) */}
      {activeCall && (
        <CallModal
          callState={activeCall}
          currentUser={currentUser}
          onEndCall={handleEndActiveCall}
        />
      )}

      {/* INCOMING CALL DIALOG */}
      {incomingCall && (
        <IncomingCallModal
          caller={{
            id: incomingCall.callerId,
            username: incomingCall.callerName,
            fullName: incomingCall.callerName,
            avatarUrl: incomingCall.callerAvatar,
          }}
          isVideo={incomingCall.isVideo}
          onAccept={handleAcceptIncomingCall}
          onDecline={handleDeclineIncomingCall}
        />
      )}

      {/* Secret Admin Key Login Modal */}
      <AdminLoginModal
        isOpen={showAdminLoginModal}
        onClose={() => setShowAdminLoginModal(false)}
        onSuccess={() => {
          setShowAdminLoginModal(false);
          setIsAdminOpen(true);
        }}
      />

      {/* Admin Dashboard */}
      {isAdminOpen && (
        <AdminDashboard
          onClose={() => setIsAdminOpen(false)}
          onLogout={() => {
            setIsAdminOpen(false);
            localStorage.removeItem('ug_admin_token');
          }}
        />
      )}

      {/* WhatsApp Service Modal */}
      <WhatsAppModal
        isOpen={showWhatsAppModal}
        onClose={() => setShowWhatsAppModal(false)}
      />

      {/* First Login Password Change Modal */}
      {showFirstLoginPasswordModal && (
        <FirstLoginModal
          isOpen={showFirstLoginPasswordModal}
          userId={currentUser.id}
          username={currentUser.username}
          onSuccess={() => {
            setShowFirstLoginPasswordModal(false);
            alert('Password changed successfully! You are now fully active.');
          }}
          onSkip={() => setShowFirstLoginPasswordModal(false)}
        />
      )}

      {/* User / Message Report Modal */}
      {reportData.isOpen && (
        <ReportModal
          isOpen={reportData.isOpen}
          onClose={() => setReportData(prev => ({ ...prev, isOpen: false }))}
          reporterId={currentUser.id}
          reportedUserId={reportData.reportedUserId}
          reportedUsername={reportData.reportedUsername}
          messageId={reportData.messageId}
          evidenceSnippet={reportData.evidence}
        />
      )}
    </div>
  );
}
