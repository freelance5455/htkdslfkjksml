import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { LoginPage } from './components/LoginPage';
import { HomePage } from './components/HomePage';
import { EventListingsPage } from './components/EventListingsPage';
import { MyTicketsPage } from './components/MyTicketsPage';
import { UserProfilePage } from './components/UserProfilePage';
import { DashboardPage } from './components/DashboardPage';
import { ScannerPage } from './components/ScannerPage';
import { CreatePage } from './components/CreatePage';
import { TicketPurchaseModal } from './components/TicketPurchaseModal';
import { CreateEventModal } from './components/CreateEventModal';
import { NotificationsPage } from './components/NotificationsPage';
import { PullToRefresh } from './components/PullToRefresh';
import { Toast } from './components/Toast';
import { EventraLogo } from './components/ui/EventraLogo';

const AppContent: React.FC = () => {
  const {
    user,
    isAuthLoading,
    currentPage,
    setCurrentPage,
    isCreateEventOpen,
    closeCreateEventModal,
    setStewardScannerEventId,
  } = useApp();

  // Force dark mode permanently on root
  useEffect(() => {
    document.documentElement.classList.add('dark');
    document.documentElement.classList.remove('light');
  }, []);

  // Handle URL hash changes (e.g. #scanner?eventId=evt_123 or #scanner)
  useEffect(() => {
    const handleHashCheck = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#scanner')) {
        const match = hash.match(/eventId=([^&]+)/);
        if (match && match[1]) {
          setStewardScannerEventId(match[1]);
        }
        setCurrentPage('scanner');
      }
    };

    handleHashCheck();
    window.addEventListener('hashchange', handleHashCheck);
    return () => window.removeEventListener('hashchange', handleHashCheck);
  }, [setCurrentPage, setStewardScannerEventId]);

  // Apple-grade initial boot & auth resolution splash
  if (isAuthLoading && !user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#090a0d] text-[#f4f4f6]">
        <div className="flex flex-col items-center gap-4 animate-in fade-in duration-300">
          <div className="relative w-12 h-12 flex items-center justify-center">
            <span className="w-10 h-10 rounded-2xl bg-emerald-500/20 animate-ping absolute" />
            <EventraLogo size="md" showText={false} />
          </div>
          <span className="text-[11px] font-semibold tracking-widest uppercase text-[#646875]">
            Authenticating Session...
          </span>
        </div>
      </div>
    );
  }

  // Show Login page first if not authenticated or page is login
  if (!user || currentPage === 'login') {
    return (
      <div className="bg-[#090a0d] text-[#f4f4f6] min-h-screen">
        <Toast />
        <LoginPage />
      </div>
    );
  }

  return (
    <PullToRefresh>
      <div className="min-h-screen flex flex-col bg-[#090a0d] text-[#f4f4f6] selection:bg-emerald-500 selection:text-white transition-colors">
        {/* Toast Feedback */}
        <Toast />

        {/* Floating Pill Top Bar */}
        <Navbar />

        {/* Main Pages Switcher */}
        <main className="flex-1">
          {currentPage === 'home' && <HomePage />}
          {currentPage === 'events' && <EventListingsPage />}
          {currentPage === 'create' && <CreatePage />}
          {currentPage === 'tickets' && <MyTicketsPage />}
          {currentPage === 'dashboard' && <DashboardPage />}
          {currentPage === 'scanner' && <ScannerPage />}
          {currentPage === 'profile' && <UserProfilePage />}
          {currentPage === 'notifications' && <NotificationsPage />}
        </main>

        {/* Direct Ticket Purchase Modal */}
        <TicketPurchaseModal />

        {/* Create Event Modal */}
        <CreateEventModal isOpen={isCreateEventOpen} onClose={closeCreateEventModal} />

        {/* Professional Minimalist Footer (Strictly Dark) */}
        <footer className="border-t border-[#1f2229] bg-[#0c0d12] py-10 px-6 text-xs text-[#9496a1]">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="font-bold text-[#f4f4f6] flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                Eventra
              </span>
              <span aria-hidden="true">·</span>
              <span>All Prices in KSh (KES)</span>
              <span aria-hidden="true">·</span>
              <span className="hidden sm:inline">Turnstile Verified Passbook</span>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6">
              <button
                onClick={() => {
                  setCurrentPage('home');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Home
              </button>
              <button
                onClick={() => {
                  setCurrentPage('events');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Event Listings
              </button>
              <button
                onClick={() => {
                  setCurrentPage('create');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Create Experience
              </button>
              <button
                onClick={() => {
                  setCurrentPage('tickets');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                My Passes
              </button>
              <button
                onClick={() => {
                  setCurrentPage('dashboard');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Host Studio & Roster
              </button>
              <button
                onClick={() => {
                  setCurrentPage('scanner');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Gate Scanner
              </button>
              <button
                onClick={() => {
                  setCurrentPage('profile');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Profile Settings
              </button>
            </div>
          </div>
        </footer>
      </div>
    </PullToRefresh>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
