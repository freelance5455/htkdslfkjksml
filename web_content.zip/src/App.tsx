import { useEffect, useRef, useState } from 'react';
import type Phaser from 'phaser';
import { bootGame } from './game/createGame';

const CUBE_COLORS = ['#f0505c', '#f98a3c', '#f7c948', '#5fcf63', '#3fcbc6', '#4c8ff5', '#9c6cf3', '#ef6bc6', '#f7c948'];

export default function App() {
  const hostRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let game: Phaser.Game | null = null;
    let cancelled = false;

    bootGame(host, () => setReady(true))
      .then((g) => {
        if (cancelled) g.destroy(true);
        else game = g;
      })
      .catch((err) => console.error('Failed to start game', err));

    return () => {
      cancelled = true;
      game?.destroy(true);
    };
  }, []);

  return (
    <>
      <div ref={hostRef} className="game-root" />
      {!ready && (
        <div className="loader" aria-label="Loading">
          <div className="cubes">
            {CUBE_COLORS.map((c, i) => (
              <span key={i} className="cube" style={{ background: c, animationDelay: `${i * 0.08}s` }} />
            ))}
          </div>
          <div className="loader-text">BLOCK BLAST</div>
        </div>
      )}
    </>
  );
}
