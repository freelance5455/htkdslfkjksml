import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ColorOption,
  GameState,
  ActiveScreen,
  GameStats,
  GameTheme,
  Achievement,
  DailyChallenge,
  PlayerProfile,
  FloatingText,
  TapRipple,
  DailyStreakData,
  BASE_COLORS,
  GOLDEN_COLOR,
  BOMB_COLOR,
  GAME_THEMES,
} from './types';
import { soundManager } from './audio';
import { hapticsManager } from './haptics';
import {
  loadGameStats,
  saveGameStats,
  loadUnlockedThemes,
  saveUnlockedThemes,
  loadSelectedTheme,
  saveSelectedTheme,
  loadAchievements,
  saveAchievements,
  loadDailyChallenge,
  saveDailyChallenge,
  loadPlayerProfile,
  savePlayerProfile,
  hasSeenTutorial,
  markTutorialSeen,
  addCoins,
  loadDailyStreak,
  checkDailyStreakStatus,
  claimStreakReward,
} from './storage';
import { signInWithGoogle, signOutUser, submitLeaderboardScore } from './firebase';
import { ParticleCanvas, ParticleCanvasHandle } from './components/ParticleCanvas';
import { TapFeedback } from './components/TapFeedback';
import { HeaderHUD } from './components/HeaderHUD';
import { TargetDisplay } from './components/TargetDisplay';
import { ColorButtons } from './components/ColorButtons';
import { HomeScreen } from './components/HomeScreen';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { ThemesModal } from './components/ThemesModal';
import { DailyChallengeModal } from './components/DailyChallengeModal';
import { AchievementsModal } from './components/AchievementsModal';
import { ProfileModal } from './components/ProfileModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { SettingsModal } from './components/SettingsModal';
import { TutorialModal } from './components/TutorialModal';
import { RewardedAdModal } from './components/RewardedAdModal';
import { DailyStreakModal } from './components/DailyStreakModal';
import { AndroidDownloadModal } from './components/AndroidDownloadModal';
import { Capacitor } from '@capacitor/core';
import { initAdMob, showNativeRewardedAd, REWARDED_COINS_AMOUNT } from './admob';

export default function App() {
  // Game lifecycle
  const [gameState, setGameState] = useState<GameState>('START');
  const [activeModal, setActiveModal] = useState<ActiveScreen | 'REWARDED_AD' | 'TUTORIAL' | 'DOWNLOAD_ZIP' | null>(null);

  // Persistent user state
  const [stats, setStats] = useState<GameStats>(loadGameStats);
  const [unlockedThemes, setUnlockedThemes] = useState<string[]>(loadUnlockedThemes);
  const [selectedThemeId, setSelectedThemeId] = useState<string>(loadSelectedTheme);
  const [achievements, setAchievements] = useState<Achievement[]>(loadAchievements);
  const [dailyChallenge, setDailyChallenge] = useState<DailyChallenge>(loadDailyChallenge);
  const [profile, setProfile] = useState<PlayerProfile>(loadPlayerProfile);

  // Round state
  const [score, setScore] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0);
  const [roundMaxCombo, setRoundMaxCombo] = useState<number>(0);
  const [roundCoins, setRoundCoins] = useState<number>(0);
  const [roundFeverBonus, setRoundFeverBonus] = useState<number>(0);
  const [roundGoldenTaps, setRoundGoldenTaps] = useState<number>(0);
  const [roundBombsAvoided, setRoundBombsAvoided] = useState<number>(0);

  const [targetColor, setTargetColor] = useState<ColorOption>(BASE_COLORS[0]);
  const [buttonOptions, setButtonOptions] = useState<ColorOption[]>([]);
  const [isGoldenRound, setIsGoldenRound] = useState<boolean>(false);
  const [hasBombInRound, setHasBombInRound] = useState<boolean>(false);

  // Fever Mode Mechanics (activates on 10 streak, 2x score, 6s timer)
  const [isFever, setIsFever] = useState<boolean>(false);
  const [feverTimeRemainingRatio, setFeverTimeRemainingRatio] = useState<number>(1.0);
  const feverTimerRef = useRef<number | null>(null);
  const feverEndTimestampRef = useRef<number>(0);

  // Round countdown timer
  const [timeRemainingRatio, setTimeRemainingRatio] = useState<number>(1.0);
  const roundDurationRef = useRef<number>(2400); // ms
  const roundStartTimeRef = useRef<number>(0);
  const timerFrameRef = useRef<number | null>(null);
  const isTickWarningActiveRef = useRef<boolean>(false);

  // Game over state
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);
  const [gameOverReason, setGameOverReason] = useState<'wrong_color' | 'timeout' | 'bomb'>('wrong_color');

  // FX & Feedback
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [ripples, setRipples] = useState<TapRipple[]>([]);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const particleCanvasRef = useRef<ParticleCanvasHandle | null>(null);

  // Audio toggles
  const [isSoundMuted, setIsSoundMuted] = useState<boolean>(() => soundManager.getSoundMuted());
  const [isMusicMuted, setIsMusicMuted] = useState<boolean>(() => soundManager.getMusicMuted());
  const [isHapticsEnabled, setIsHapticsEnabled] = useState<boolean>(() => hapticsManager.getEnabled());

  // Current active theme
  const currentTheme = GAME_THEMES.find((t) => t.id === selectedThemeId) || GAME_THEMES[0];

  // Daily Streak State
  const [streakData, setStreakData] = useState<DailyStreakData>(loadDailyStreak);
  const [canClaimStreak, setCanClaimStreak] = useState<boolean>(false);
  const [streakDayIndex, setStreakDayIndex] = useState<number>(0);

  // Check tutorial and login streak on launch
  useEffect(() => {
    const streakStatus = checkDailyStreakStatus();
    setStreakData(streakStatus.data);
    setCanClaimStreak(streakStatus.canClaim);
    setStreakDayIndex(streakStatus.dayIndexToClaim);

    // Update streak achievements progress
    setAchievementProgress('streak_3', streakStatus.data.currentStreak);
    setAchievementProgress('streak_7', streakStatus.data.currentStreak);

    // Initialize native AdMob on startup
    initAdMob();

    if (!hasSeenTutorial()) {
      setActiveModal('TUTORIAL');
    } else if (streakStatus.canClaim) {
      // Daily reward popup prompt on login
      setActiveModal('STREAK');
    }
  }, []);

  // Sync music state with game screen
  useEffect(() => {
    if (gameState === 'PLAYING' && !isMusicMuted) {
      soundManager.startMusic();
    } else {
      soundManager.stopMusic();
    }
  }, [gameState, isMusicMuted]);

  // Calculate Combo Multiplier: 1x (0-4), 2x (5-9), 3x (10-14), 4x (15-19), 5x (20+)
  const getComboMultiplier = useCallback((currentCombo: number) => {
    if (currentCombo >= 20) return 5;
    if (currentCombo >= 15) return 4;
    if (currentCombo >= 10) return 3;
    if (currentCombo >= 5) return 2;
    return 1;
  }, []);

  const comboMultiplier = getComboMultiplier(combo);

  // Audio & Haptic handlers
  const handleToggleSound = () => {
    const next = soundManager.toggleSound();
    setIsSoundMuted(next);
  };

  const handleToggleMusic = () => {
    const next = soundManager.toggleMusic();
    setIsMusicMuted(next);
  };

  const handleToggleHaptics = () => {
    const next = hapticsManager.toggle();
    setIsHapticsEnabled(next);
  };

  // Helper to trigger floating text
  const addFloatingText = (
    text: string,
    x: number,
    y: number,
    color: string,
    isGolden = false,
    isFeverText = false
  ) => {
    const id = Date.now() + Math.random();
    setFloatingTexts((prev) => [...prev.slice(-4), { id, text, x, y, color, isGolden, isFever: isFeverText }]);
    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((item) => item.id !== id));
    }, 850);
  };

  // Helper to trigger tap ripple
  const addRipple = (x: number, y: number, color: string) => {
    const id = Date.now() + Math.random();
    setRipples((prev) => [...prev.slice(-3), { id, x, y, color }]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((item) => item.id !== id));
    }, 500);
  };

  // Check achievements progress
  const updateAchievementProgress = useCallback((id: string, amount: number) => {
    setAchievements((prev) => {
      const updated = prev.map((ach) => {
        if (ach.id === id) {
          const nextProg = Math.min(ach.maxProgress, ach.progress + amount);
          return { ...ach, progress: nextProg };
        }
        return ach;
      });
      saveAchievements(updated);
      return updated;
    });
  }, []);

  const setAchievementProgress = useCallback((id: string, value: number) => {
    setAchievements((prev) => {
      const updated = prev.map((ach) => {
        if (ach.id === id) {
          const nextProg = Math.max(ach.progress, Math.min(ach.maxProgress, value));
          return { ...ach, progress: nextProg };
        }
        return ach;
      });
      saveAchievements(updated);
      return updated;
    });
  }, []);

  // Update Daily Challenge progress
  const updateDailyProgress = useCallback((type: 'score' | 'combo' | 'golden_taps', value: number) => {
    setDailyChallenge((prev) => {
      if (prev.type !== type || prev.completed) return prev;
      const nextCurrent = type === 'combo' ? Math.max(prev.current, value) : prev.current + value;
      const isNowCompleted = nextCurrent >= prev.target;
      const updated: DailyChallenge = {
        ...prev,
        current: nextCurrent,
        completed: isNowCompleted,
      };
      saveDailyChallenge(updated);
      return updated;
    });
  }, []);

  // Fever Mode countdown loop
  useEffect(() => {
    if (!isFever) {
      if (feverTimerRef.current !== null) {
        cancelAnimationFrame(feverTimerRef.current);
        feverTimerRef.current = null;
      }
      return;
    }

    const checkFever = () => {
      const now = performance.now();
      const remaining = feverEndTimestampRef.current - now;
      const ratio = Math.max(0, remaining / 6000);
      setFeverTimeRemainingRatio(ratio);

      if (remaining <= 0) {
        setIsFever(false);
      } else {
        feverTimerRef.current = requestAnimationFrame(checkFever);
      }
    };

    feverTimerRef.current = requestAnimationFrame(checkFever);
    return () => {
      if (feverTimerRef.current !== null) {
        cancelAnimationFrame(feverTimerRef.current);
      }
    };
  }, [isFever]);

  // Activate Fever Mode
  const triggerFeverMode = useCallback(() => {
    setIsFever(true);
    feverEndTimestampRef.current = performance.now() + 6000;
    setFeverTimeRemainingRatio(1.0);

    soundManager.playFeverActivate();
    hapticsManager.fever();
    particleCanvasRef.current?.feverSparks(35);

    setStats((prev) => {
      const updated = { ...prev, feverCount: prev.feverCount + 1 };
      saveGameStats(updated);
      return updated;
    });

    updateAchievementProgress('fever_master', 1);
  }, [updateAchievementProgress]);

  // Spawn a new round of 4 buttons
  const spawnRound = useCallback(
    (currentScore: number) => {
      // 15% chance of Golden Bonus after score 4
      const canBeGolden = currentScore >= 4 && Math.random() < 0.16;
      // 12% chance of Bomb button after score 6 (mutually exclusive with golden target)
      const canHaveBomb = !canBeGolden && currentScore >= 6 && Math.random() < 0.14;

      setHasBombInRound(canHaveBomb);

      if (canBeGolden) {
        setIsGoldenRound(true);
        setTargetColor(GOLDEN_COLOR);

        const shuffled = [...BASE_COLORS].sort(() => 0.5 - Math.random());
        const otherThree = shuffled.slice(0, 3);
        const fourButtons = [GOLDEN_COLOR, ...otherThree].sort(() => 0.5 - Math.random());
        setButtonOptions(fourButtons);
      } else {
        setIsGoldenRound(false);
        const shuffled = [...BASE_COLORS].sort(() => 0.5 - Math.random());
        const selectedColors = shuffled.slice(0, 4);
        const target = selectedColors[Math.floor(Math.random() * selectedColors.length)];
        setTargetColor(target);

        if (canHaveBomb) {
          // Replace one non-target button with the bomb!
          const nonTargetIndex = selectedColors.findIndex((c) => c.id !== target.id);
          if (nonTargetIndex !== -1) {
            selectedColors[nonTargetIndex] = BOMB_COLOR;
          }
        }

        const randomizedButtons = [...selectedColors].sort(() => 0.5 - Math.random());
        setButtonOptions(randomizedButtons);
      }

      // Round timer duration (speeds up as score climbs: 2.4s down to 0.75s)
      const duration = Math.max(750, 2400 - Math.min(currentScore, 35) * 45);
      roundDurationRef.current = duration;
      roundStartTimeRef.current = performance.now();
      setTimeRemainingRatio(1.0);
      isTickWarningActiveRef.current = false;
    },
    []
  );

  // Game Over handler
  const handleGameOver = useCallback(
    (reason: 'wrong_color' | 'timeout' | 'bomb') => {
      if (timerFrameRef.current !== null) {
        cancelAnimationFrame(timerFrameRef.current);
        timerFrameRef.current = null;
      }
      setIsFever(false);
      setGameState('GAMEOVER');
      setGameOverReason(reason);

      if (reason === 'bomb') {
        soundManager.playBombExplode();
        hapticsManager.bomb();
      } else {
        soundManager.playError();
        hapticsManager.error();
      }

      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 450);

      // Record stats and achievements
      const isNewBest = score > stats.highScore;
      setIsNewHighScore(isNewBest);

      const updatedStats: GameStats = {
        ...stats,
        highScore: Math.max(stats.highScore, score),
        gamesPlayed: stats.gamesPlayed + 1,
        maxCombo: Math.max(stats.maxCombo, roundMaxCombo),
        totalTaps: stats.totalTaps + score,
        goldenTaps: stats.goldenTaps + roundGoldenTaps,
        coins: stats.coins + roundCoins,
        bombsAvoided: stats.bombsAvoided + roundBombsAvoided,
      };
      setStats(updatedStats);
      saveGameStats(updatedStats);

      // Update achievements
      updateAchievementProgress('first_game', 1);
      setAchievementProgress('score_50', score);
      setAchievementProgress('score_100', score);
      setAchievementProgress('combo_10', roundMaxCombo);
      setAchievementProgress('combo_25', roundMaxCombo);
      updateAchievementProgress('golden_touch', roundGoldenTaps);

      // Update daily challenge
      updateDailyProgress('score', score);
      updateDailyProgress('combo', roundMaxCombo);
      updateDailyProgress('golden_taps', roundGoldenTaps);

      // Submit high score to global leaderboard if signed in
      if (profile.isGoogleUser) {
        const bestScore = Math.max(stats.highScore, score);
        const bestCombo = Math.max(stats.maxCombo, roundMaxCombo);
        if (bestScore > 0) {
          submitLeaderboardScore(profile, bestScore, bestCombo);
        }
      }

      if (isNewBest && score > 0) {
        setTimeout(() => {
          particleCanvasRef.current?.celebrate();
        }, 200);
      }
    },
    [
      score,
      roundMaxCombo,
      roundCoins,
      roundGoldenTaps,
      roundBombsAvoided,
      stats,
      profile,
      updateAchievementProgress,
      setAchievementProgress,
      updateDailyProgress,
    ]
  );

  // Start / Restart game
  const startGame = useCallback(() => {
    soundManager.playStart();
    hapticsManager.tap();

    setScore(0);
    setCombo(0);
    setRoundMaxCombo(0);
    setRoundCoins(0);
    setRoundFeverBonus(0);
    setRoundGoldenTaps(0);
    setRoundBombsAvoided(0);
    setIsFever(false);
    setIsNewHighScore(false);
    setActiveModal(null);
    setGameState('PLAYING');

    spawnRound(0);
  }, [spawnRound]);

  // Round countdown timer loop
  useEffect(() => {
    if (gameState !== 'PLAYING') {
      if (timerFrameRef.current !== null) {
        cancelAnimationFrame(timerFrameRef.current);
        timerFrameRef.current = null;
      }
      return;
    }

    const checkTimer = (now: number) => {
      const elapsed = now - roundStartTimeRef.current;
      const remainingRatio = Math.max(0, 1 - elapsed / roundDurationRef.current);
      setTimeRemainingRatio(remainingRatio);

      if (remainingRatio < 0.25 && !isTickWarningActiveRef.current) {
        soundManager.playTick();
        isTickWarningActiveRef.current = true;
      }

      if (remainingRatio <= 0) {
        handleGameOver('timeout');
      } else {
        timerFrameRef.current = requestAnimationFrame(checkTimer);
      }
    };

    timerFrameRef.current = requestAnimationFrame(checkTimer);

    return () => {
      if (timerFrameRef.current !== null) {
        cancelAnimationFrame(timerFrameRef.current);
      }
    };
  }, [gameState, handleGameOver]);

  // Handle player tapping a button
  const handleButtonTap = (option: ColorOption, event?: React.PointerEvent<HTMLButtonElement>) => {
    if (gameState !== 'PLAYING') return;

    let tapX = window.innerWidth / 2;
    let tapY = window.innerHeight * 0.7;

    if (event) {
      tapX = event.clientX;
      tapY = event.clientY;
    }

    addRipple(tapX, tapY, option.hex);

    // BOMB TAP: Instant Game Over
    if (option.isBomb) {
      particleCanvasRef.current?.bombExplosion(tapX, tapY);
      handleGameOver('bomb');
      return;
    }

    // Check correctness
    const isCorrect = option.id === targetColor.id;

    if (!isCorrect) {
      particleCanvasRef.current?.shockwave(tapX, tapY, '#EF4444');
      handleGameOver('wrong_color');
      return;
    }

    // Survived round with bomb present?
    if (hasBombInRound) {
      setRoundBombsAvoided((prev) => prev + 1);
    }

    // Correct tap!
    const nextCombo = combo + 1;
    setCombo(nextCombo);
    setRoundMaxCombo((prev) => Math.max(prev, nextCombo));

    // Activate Fever Mode on 10 consecutive taps!
    if (nextCombo === 10 && !isFever) {
      triggerFeverMode();
    }

    const mult = getComboMultiplier(nextCombo);
    const feverMultiplier = isFever ? 2 : 1;
    const isGolden = !!option.isGolden;

    // Points earned
    const basePoints = isGolden ? 5 : 1;
    const pointsEarned = basePoints * mult * feverMultiplier;
    const nextScore = score + pointsEarned;
    setScore(nextScore);

    // Track fever bonus points
    if (isFever) {
      setRoundFeverBonus((prev) => prev + (pointsEarned / 2));
    }

    // Award Coins
    let coinsEarnedThisTap = 0;
    if (isGolden) coinsEarnedThisTap += 3;
    if (nextScore % 5 === 0) coinsEarnedThisTap += 1;
    if (nextCombo === 10 || nextCombo === 20) coinsEarnedThisTap += 2;

    if (coinsEarnedThisTap > 0) {
      setRoundCoins((prev) => prev + coinsEarnedThisTap);
      soundManager.playCoin();
    }

    if (isGolden) {
      setRoundGoldenTaps((prev) => prev + 1);
      soundManager.playGolden();
      hapticsManager.golden();
      particleCanvasRef.current?.burst(tapX, tapY, '#FBBF24', 28, true);
      addFloatingText(`+${pointsEarned} GOLD! (+3 🪙)`, tapX, tapY, '#FBBF24', true);
    } else if (isFever) {
      soundManager.playFeverTap();
      hapticsManager.tap();
      particleCanvasRef.current?.burst(tapX, tapY, '#F97316', 20, false);
      addFloatingText(`+${pointsEarned} FEVER 2x!`, tapX, tapY, '#F97316', false, true);
    } else {
      if (nextCombo === 5 || nextCombo === 10 || nextCombo === 15 || nextCombo === 20) {
        soundManager.playComboUp(mult);
        hapticsManager.combo();
        addFloatingText(`${mult}x COMBO!`, tapX, tapY, '#10B981', false);
      } else {
        soundManager.playTap(mult);
        hapticsManager.tap();
        addFloatingText(mult > 1 ? `+${pointsEarned}` : '+1', tapX, tapY, option.hex, false);
      }
      particleCanvasRef.current?.burst(tapX, tapY, option.hex, 16, false);
    }

    spawnRound(nextScore);
  };

  // Claim achievement reward
  const handleClaimAchievement = (achId: string) => {
    const ach = achievements.find((a) => a.id === achId);
    if (!ach || ach.unlocked) return;

    soundManager.playGolden();
    hapticsManager.golden();
    const newCoins = addCoins(ach.rewardCoins);
    setStats((prev) => ({ ...prev, coins: newCoins }));

    setAchievements((prev) => {
      const updated = prev.map((a) => (a.id === achId ? { ...a, unlocked: true } : a));
      saveAchievements(updated);
      return updated;
    });
  };

  // Claim daily challenge reward
  const handleClaimDailyChallenge = () => {
    if (!dailyChallenge.completed || dailyChallenge.claimed) return;

    soundManager.playGolden();
    hapticsManager.golden();
    const newCoins = addCoins(dailyChallenge.rewardCoins);
    setStats((prev) => ({ ...prev, coins: newCoins }));

    setDailyChallenge((prev) => {
      const updated = { ...prev, claimed: true };
      saveDailyChallenge(updated);
      return updated;
    });

    updateAchievementProgress('daily_complete', 1);
  };

  // Unlock Theme
  const handleUnlockTheme = (theme: GameTheme) => {
    if (stats.coins < theme.cost) return;

    soundManager.playGolden();
    hapticsManager.golden();

    const newCoins = addCoins(-theme.cost);
    setStats((prev) => ({ ...prev, coins: newCoins }));

    const updatedUnlocked = [...unlockedThemes, theme.id];
    setUnlockedThemes(updatedUnlocked);
    saveUnlockedThemes(updatedUnlocked);

    setSelectedThemeId(theme.id);
    saveSelectedTheme(theme.id);

    // Update stylist achievement (if unlocked >= 2)
    setAchievementProgress('theme_stylist', updatedUnlocked.length - 1);
  };

  // Select Theme
  const handleSelectTheme = (themeId: string) => {
    soundManager.playTap();
    setSelectedThemeId(themeId);
    saveSelectedTheme(themeId);
  };

  // Google Sign-In
  const handleGoogleSignIn = async () => {
    const res = await signInWithGoogle();
    if (res.profile) {
      setProfile(res.profile);
      savePlayerProfile(res.profile);
      soundManager.playStart();
      if (stats.highScore > 0) {
        submitLeaderboardScore(res.profile, stats.highScore, stats.maxCombo);
      }
    }
  };

  // Google Sign-Out
  const handleGoogleSignOut = async () => {
    await signOutUser();
    const guest: PlayerProfile = {
      name: 'Runner',
      avatar: '🦊',
      isGoogleUser: false,
    };
    setProfile(guest);
    savePlayerProfile(guest);
  };

  // Claim Daily Login Streak reward
  const handleClaimDailyStreak = () => {
    const result = claimStreakReward();
    if (!result.success) return;

    soundManager.playGolden();
    hapticsManager.golden();
    particleCanvasRef.current?.celebrate();

    setStreakData(result.updatedData);
    setCanClaimStreak(false);
    setStats(loadGameStats());

    addFloatingText(
      `+${result.coinsEarned} COINS! 🔥`,
      window.innerWidth / 2,
      window.innerHeight * 0.45,
      '#F59E0B',
      true
    );

    // Update streak achievements
    setAchievementProgress('streak_3', result.updatedData.currentStreak);
    setAchievementProgress('streak_7', result.updatedData.currentStreak);
  };

  // Rewarded Ad completion: grant 10 bonus coins after ad is fully watched
  const handleAdReward = (earnedCoins: number) => {
    soundManager.playGolden();
    hapticsManager.golden();
    const newCoins = addCoins(earnedCoins);
    setStats((prev) => ({ ...prev, coins: newCoins }));
    addFloatingText(`+${earnedCoins} COINS!`, window.innerWidth / 2, window.innerHeight * 0.5, '#FBBF24', true);
  };

  // Google AdMob Rewarded Ad: show native ad or web preview player
  const handleRequestWatchAd = async () => {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await showNativeRewardedAd();
        if (res.rewardEarned) {
          handleAdReward(REWARDED_COINS_AMOUNT);
        }
        return;
      } catch (err) {
        console.warn('Native AdMob error, opening fallback player:', err);
      }
    }
    setActiveModal('REWARDED_AD');
  };

  return (
    <main
      className={`relative flex h-full w-full flex-col items-center justify-between overflow-hidden select-none touch-none ${
        currentTheme.bgGradient
      } ${isShaking ? 'animate-shake' : ''}`}
    >
      {/* Dynamic Ambient Background Glow */}
      <div
        className="pointer-events-none fixed inset-0 opacity-25 blur-3xl transition-colors duration-500"
        style={{
          background: `radial-gradient(circle at 50% 35%, ${
            isFever ? '#F97316' : isGoldenRound ? '#FBBF24' : targetColor.hex
          } 0%, transparent 65%)`,
        }}
      />

      {/* Hardware-accelerated Particle Canvas */}
      <ParticleCanvas ref={particleCanvasRef} />

      {/* Tap Ripple & Floating Text overlay */}
      <TapFeedback floatingTexts={floatingTexts} ripples={ripples} />

      {/* Screen 1: Home Screen */}
      {gameState === 'START' && (
        <HomeScreen
          stats={stats}
          currentTheme={currentTheme}
          profile={profile}
          dailyChallenge={dailyChallenge}
          streakData={streakData}
          canClaimStreak={canClaimStreak}
          onPlay={startGame}
          onOpenThemes={() => setActiveModal('THEMES')}
          onOpenDaily={() => setActiveModal('DAILY')}
          onOpenStreak={() => setActiveModal('STREAK')}
          onOpenLeaderboard={() => setActiveModal('LEADERBOARD')}
          onOpenAchievements={() => setActiveModal('ACHIEVEMENTS')}
          onOpenProfile={() => setActiveModal('PROFILE')}
          onOpenSettings={() => setActiveModal('SETTINGS')}
          onWatchAd={handleRequestWatchAd}
          onOpenDownloadZip={() => setActiveModal('DOWNLOAD_ZIP')}
        />
      )}

      {/* Screen 2: Active Gameplay Screen */}
      {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
        <div className="flex h-full w-full max-w-md flex-col items-center justify-between pb-safe z-10">
          {/* Top HUD: Score, Coins, Streak, Audio, Pause */}
          <HeaderHUD
            score={score}
            highScore={stats.highScore}
            coins={stats.coins + roundCoins}
            combo={combo}
            comboMultiplier={comboMultiplier}
            isFever={isFever}
            isSoundMuted={isSoundMuted}
            isMusicMuted={isMusicMuted}
            isHapticsEnabled={isHapticsEnabled}
            onToggleSound={handleToggleSound}
            onToggleMusic={handleToggleMusic}
            onToggleHaptics={handleToggleHaptics}
            onPause={() => setGameState('PAUSED')}
          />

          {/* Upper Area: Large Target Color with Radial Timer Ring & Fever Overdrive */}
          <TargetDisplay
            targetColor={targetColor}
            timeRemainingRatio={timeRemainingRatio}
            isGolden={isGoldenRound}
            isFever={isFever}
            feverTimeRemainingRatio={feverTimeRemainingRatio}
            score={score}
          />

          {/* Lower Area (Thumb Zone): 4 Large Ergonomic Color Buttons + Bomb */}
          <ColorButtons
            options={buttonOptions}
            onSelect={handleButtonTap}
            disabled={gameState !== 'PLAYING'}
          />
        </div>
      )}

      {/* Screen 3: Game Over Modal */}
      {gameState === 'GAMEOVER' && (
        <GameOverModal
          score={score}
          highScore={stats.highScore}
          isNewHighScore={isNewHighScore}
          maxCombo={roundMaxCombo}
          coinsEarned={roundCoins}
          feverScore={roundFeverBonus}
          reason={gameOverReason}
          stats={stats}
          onRestart={startGame}
          onHome={() => setGameState('START')}
          onWatchAd={handleRequestWatchAd}
        />
      )}

      {/* Screen 4: Pause Modal */}
      {gameState === 'PAUSED' && (
        <PauseModal
          score={score}
          onResume={() => {
            setGameState('PLAYING');
            roundStartTimeRef.current = performance.now();
          }}
          onRestart={startGame}
          onQuit={() => setGameState('START')}
        />
      )}

      {/* Modal Overlays */}
      {activeModal === 'THEMES' && (
        <ThemesModal
          currentTheme={currentTheme}
          coins={stats.coins}
          unlockedThemes={unlockedThemes}
          onSelectTheme={handleSelectTheme}
          onUnlockTheme={handleUnlockTheme}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'STREAK' && (
        <DailyStreakModal
          streakData={streakData}
          canClaim={canClaimStreak}
          dayIndexToClaim={streakDayIndex}
          onClaim={handleClaimDailyStreak}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'DAILY' && (
        <DailyChallengeModal
          challenge={dailyChallenge}
          onClaim={handleClaimDailyChallenge}
          onClose={() => setActiveModal(null)}
          onPlayNow={() => {
            setActiveModal(null);
            startGame();
          }}
        />
      )}

      {activeModal === 'ACHIEVEMENTS' && (
        <AchievementsModal
          achievements={achievements}
          onClaimAchievement={handleClaimAchievement}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'PROFILE' && (
        <ProfileModal
          profile={profile}
          stats={stats}
          achievements={achievements}
          onUpdateProfile={(updated) => {
            const next = { ...profile, ...updated };
            setProfile(next);
            savePlayerProfile(next);
          }}
          onGoogleSignIn={handleGoogleSignIn}
          onGoogleSignOut={handleGoogleSignOut}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'LEADERBOARD' && (
        <LeaderboardModal
          profile={profile}
          highScore={stats.highScore}
          onClose={() => setActiveModal(null)}
          onProfileUpdated={(updated) => {
            setProfile(updated);
            savePlayerProfile(updated);
          }}
        />
      )}

      {activeModal === 'SETTINGS' && (
        <SettingsModal
          isMusicMuted={isMusicMuted}
          isSoundMuted={isSoundMuted}
          isHapticsEnabled={isHapticsEnabled}
          onToggleMusic={handleToggleMusic}
          onToggleSound={handleToggleSound}
          onToggleHaptics={handleToggleHaptics}
          onShowTutorial={() => setActiveModal('TUTORIAL')}
          onOpenDownloadZip={() => setActiveModal('DOWNLOAD_ZIP')}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'TUTORIAL' && (
        <TutorialModal
          onStart={() => {
            markTutorialSeen();
            setActiveModal(null);
          }}
        />
      )}

      {activeModal === 'REWARDED_AD' && (
        <RewardedAdModal
          onReward={handleAdReward}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'DOWNLOAD_ZIP' && (
        <AndroidDownloadModal onClose={() => setActiveModal(null)} />
      )}
    </main>
  );
}
