import React, { useState } from 'react';
import {
  Smartphone,
  Store,
  ShieldAlert,
  Code,
  Sparkles,
  ShoppingBag,
  Heart,
  ShoppingCart,
  Maximize2,
  CheckCircle,
  Lock,
  Unlock,
  KeyRound,
  ShieldCheck,
  Eye,
  EyeOff,
  AlertTriangle,
  UserCheck,
  Download,
} from 'lucide-react';
import { Logo } from './components/common/Logo';
import { CustomerApp } from './components/customer/CustomerApp';
import { SellerPortal } from './components/seller/SellerPortal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { FlutterCodeCenter } from './components/flutter/FlutterCodeCenter';
import { AIStudioHub } from './components/ai/AIStudioHub';
import { SellerRegistrationModal } from './components/seller/SellerRegistrationModal';
import { ApkDownloadModal } from './components/common/ApkDownloadModal';
import {
  INITIAL_PRODUCTS,
  INITIAL_SELLERS,
  INITIAL_ORDERS,
  INITIAL_REELS,
  INITIAL_SETTLEMENT_LEDGER,
  INITIAL_DISPUTES,
  INITIAL_AUDIT_LOGS,
  INITIAL_COUPONS,
  INITIAL_BANNERS,
  SAMPLE_PRODUCTS,
  SAMPLE_ORDERS,
} from './data/mockData';
import { Product, Seller, Order, VideoReel, CartItem, SettlementLedgerEntry, Dispute, AuditLog, Coupon, Banner, Review } from './types';
import { calculateSettlement, verifyAdminCredentials, DEFAULT_ADMIN_PIN, DEFAULT_ADMIN_PASSCODE, UserRole } from './utils/marketplace';

export default function App() {
  // Navigation between the required marketplace applications
  const [activeApp, setActiveApp] = useState<'customer' | 'seller' | 'admin' | 'flutter' | 'aiHub'>('customer');
  const [customerViewMode, setCustomerViewMode] = useState<'phone' | 'fullscreen'>('phone');

  // Customer Mode Shield: when true, completely hides all admin and seller navigation controls
  const [isCustomerShieldActive, setIsCustomerShieldActive] = useState<boolean>(false);

  // Role authentication state
  const [currentRole, setCurrentRole] = useState<UserRole>('CUSTOMER');
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(false);
  const [isSellerUnlocked, setIsSellerUnlocked] = useState<boolean>(false);

  // Security Gate Modals
  const [showAdminGateModal, setShowAdminGateModal] = useState<boolean>(false);
  const [adminPasscodeInput, setAdminPasscodeInput] = useState<string>('');
  const [adminGateError, setAdminGateError] = useState<string | null>(null);

  const [showSellerGateModal, setShowSellerGateModal] = useState<boolean>(false);
  const [sellerPasscodeInput, setSellerPasscodeInput] = useState<string>('');
  const [sellerGateError, setSellerGateError] = useState<string | null>(null);

  const [showSellerRegistrationModal, setShowSellerRegistrationModal] = useState<boolean>(false);
  const [showApkModal, setShowApkModal] = useState<boolean>(false);

  // Core Marketplace State
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [sellers, setSellers] = useState<Seller[]>(INITIAL_SELLERS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [reels, setReels] = useState<VideoReel[]>(INITIAL_REELS);
  const [settlements, setSettlements] = useState<SettlementLedgerEntry[]>(INITIAL_SETTLEMENT_LEDGER);
  const [disputes, setDisputes] = useState<Dispute[]>(INITIAL_DISPUTES);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL_COUPONS);
  const [banners, setBanners] = useState<Banner[]>(INITIAL_BANNERS);

  // Cart & Wishlist (Starts empty as mock products are removed)
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);

  // Active Seller in Seller Portal
  const [selectedSellerId, setSelectedSellerId] = useState<string>(INITIAL_SELLERS[0]?.id || '');
  const currentSeller = sellers.find((s) => s.id === selectedSellerId) || sellers[0] || null;

  // Helper: Log audit action
  const logAction = (actor: string, role: 'ADMIN' | 'SELLER' | 'CUSTOMER' | 'SYSTEM', action: string, details: string) => {
    const newLog: AuditLog = {
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor,
      role,
      action,
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Switch to Admin with RBAC Security Check
  const handleRequestAdminDashboard = () => {
    if (isAdminUnlocked) {
      setActiveApp('admin');
      setCurrentRole('ADMIN');
    } else {
      setShowAdminGateModal(true);
      setAdminGateError(null);
      setAdminPasscodeInput('');
    }
  };

  // Switch to Seller Portal with Merchant Gate
  const handleRequestSellerPortal = () => {
    if (sellers.length === 0 || isSellerUnlocked || isAdminUnlocked) {
      setActiveApp('seller');
      setCurrentRole('SELLER');
    } else {
      setShowSellerGateModal(true);
      setSellerGateError(null);
      setSellerPasscodeInput('');
    }
  };

  // Admin PIN verification
  const handleVerifyAdminPasscode = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyAdminCredentials(adminPasscodeInput)) {
      setIsAdminUnlocked(true);
      setCurrentRole('ADMIN');
      setActiveApp('admin');
      setShowAdminGateModal(false);
      logAction('Super Administrator', 'ADMIN', 'ADMIN_SESSION_UNLOCKED', 'Super Admin logged in with security PIN');
    } else {
      setAdminGateError('Incorrect Admin Passcode or PIN. Access denied to protect customer & financial data.');
    }
  };

  // Seller Merchant verification
  const handleVerifySellerPasscode = (e: React.FormEvent) => {
    e.preventDefault();
    if (sellerPasscodeInput.trim() === '1234' || sellerPasscodeInput.trim().toLowerCase() === 'seller') {
      setIsSellerUnlocked(true);
      setCurrentRole('SELLER');
      setActiveApp('seller');
      setShowSellerGateModal(false);
      logAction(currentSeller?.storeName || 'Merchant', 'SELLER', 'SELLER_PORTAL_UNLOCKED', `Merchant ${currentSeller?.storeName || 'Store'} authenticated`);
    } else {
      setSellerGateError('Invalid Merchant PIN. Try demo PIN: 1234');
    }
  };

  // Register a new Seller Store
  const handleRegisterSeller = (newSeller: Seller) => {
    setSellers((prev) => [newSeller, ...prev]);
    setSelectedSellerId(newSeller.id);
    setIsSellerUnlocked(true);
    setCurrentRole('SELLER');
    setActiveApp('seller');
    setShowSellerRegistrationModal(false);
    logAction(
      newSeller.ownerName,
      'SELLER',
      'NEW_STORE_REGISTERED',
      `Registered new store "${newSeller.storeName}" with GSTIN ${newSeller.gstin} and payout bank ${newSeller.bankAccount.bankName}`
    );
  };

  // Delete / Remove an existing Seller Store
  const handleDeleteSeller = (sellerId: string) => {
    const target = sellers.find((s) => s.id === sellerId);
    setSellers((prev) => prev.filter((s) => s.id !== sellerId));
    if (selectedSellerId === sellerId) {
      const remaining = sellers.filter((s) => s.id !== sellerId);
      setSelectedSellerId(remaining[0]?.id || '');
    }
    logAction('Admin', 'ADMIN', 'SELLER_REMOVED', `Removed seller account: ${target?.storeName || sellerId}`);
  };

  // Remove All Seller accounts
  const handleClearAllSellers = () => {
    setSellers([]);
    setSelectedSellerId('');
    logAction('Admin', 'ADMIN', 'ALL_SELLERS_REMOVED', 'Removed all seller accounts from the application');
  };

  // Product Catalog Handlers
  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    setCart((prev) => prev.filter((it) => it.productId !== productId));
    setWishlist((prev) => prev.filter((id) => id !== productId));
    logAction('Admin', 'ADMIN', 'PRODUCT_DELETED', `Deleted product ${productId} from marketplace catalog`);
  };

  const handleClearAllProducts = () => {
    setProducts([]);
    setCart([]);
    setWishlist([]);
    logAction('Admin', 'ADMIN', 'ALL_PRODUCTS_REMOVED', 'Purged all products from marketplace catalog');
  };

  const handleLoadSampleProducts = () => {
    setProducts(SAMPLE_PRODUCTS);
    logAction('Admin', 'ADMIN', 'CATALOG_SEEDED', 'Loaded 8 sample demo products for evaluation');
  };

  // Lock Admin / Return to Customer Mode
  const handleLockAdminSession = () => {
    setIsAdminUnlocked(false);
    setIsSellerUnlocked(false);
    setCurrentRole('CUSTOMER');
    setActiveApp('customer');
    logAction('Administrator', 'ADMIN', 'ADMIN_SESSION_LOCKED', 'Session locked; returned to Customer App');
  };

  // Cart Handlers
  const handleAddToCart = (product: Product, variantId?: string, qty: number = 1) => {
    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (it) => it.productId === product.id && (variantId ? it.variantId === variantId : true)
      );
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx].quantity += qty;
        return copy;
      }
      const variant = product.variants.find((v) => v.id === variantId);
      return [
        ...prev,
        {
          productId: product.id,
          variantId,
          variantName: variant?.name,
          product,
          quantity: qty,
          priceAtAddition: variant?.price || product.price,
        },
      ];
    });
  };

  const handleUpdateCartQty = (productId: string, variantId: string | undefined, qty: number) => {
    if (qty <= 0) {
      handleRemoveFromCart(productId, variantId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.productId === productId && item.variantId === variantId) {
          return { ...item, quantity: qty };
        }
        return item;
      })
    );
  };

  const handleRemoveFromCart = (productId: string, variantId?: string) => {
    setCart((prev) => prev.filter((it) => !(it.productId === productId && it.variantId === variantId)));
  };

  const handleToggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  // Order Placement
  const handlePlaceOrder = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    setCart([]);
    logAction(order.customerName, 'CUSTOMER', 'ORDER_PLACED', `Placed order ${order.orderNumber} for ₹${order.totalAmount}`);

    setProducts((prevProds) =>
      prevProds.map((prod) => {
        const matchingItem = order.items.find((it) => it.productId === prod.id);
        if (matchingItem) {
          const newStock = Math.max(0, prod.stock - matchingItem.quantity);
          return { ...prod, stock: newStock, inStock: newStock > 0 };
        }
        return prod;
      })
    );
  };

  const handleCancelOrder = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: 'CANCELLED' } : ord))
    );
    logAction('Customer', 'CUSTOMER', 'ORDER_CANCELLED', `Cancelled order ${orderId}`);
  };

  const handleRequestReturn = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: 'RETURN_REQUESTED' } : ord))
    );
    const targetOrder = orders.find((o) => o.id === orderId);
    if (targetOrder) {
      const newDispute: Dispute = {
        id: `disp_${Date.now().toString().slice(-4)}`,
        orderId,
        customerId: targetOrder.customerId,
        customerName: targetOrder.customerName,
        sellerId: targetOrder.items[0]?.sellerId || 'seller_apex',
        sellerName: targetOrder.items[0]?.sellerName || 'Apex Tech',
        productTitle: targetOrder.items[0]?.title || 'Product',
        reason,
        amount: targetOrder.totalAmount,
        status: 'OPEN',
        createdAt: new Date().toISOString(),
      };
      setDisputes((prev) => [newDispute, ...prev]);
    }
    logAction('Customer', 'CUSTOMER', 'RETURN_REQUESTED', `Return requested for order ${orderId}: ${reason}`);
  };

  // Review & Rating Handlers
  const handleAddReview = (productId: string, orderId: string, review: Review) => {
    setProducts((prev) =>
      prev.map((prod) => {
        if (prod.id === productId) {
          const existingReviews = prod.reviews || [];
          const updatedReviews = [review, ...existingReviews.filter((r) => r.id !== review.id)];
          const totalRating = updatedReviews.reduce((acc, r) => acc + r.rating, 0);
          const newRating = Number((totalRating / updatedReviews.length).toFixed(1));
          return {
            ...prod,
            reviews: updatedReviews,
            rating: newRating,
            ratingCount: (prod.ratingCount || 0) + (existingReviews.some((r) => r.id === review.id) ? 0 : 1),
          };
        }
        return prod;
      })
    );

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          return {
            ...ord,
            items: ord.items.map((it) =>
              it.productId === productId ? { ...it, isReviewed: true, reviewRating: review.rating } : it
            ),
          };
        }
        return ord;
      })
    );

    logAction(review.userName, 'CUSTOMER', 'PRODUCT_REVIEWED', `Rated ${review.rating}★: "${review.title}" for product ${productId}`);
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: newStatus } : ord))
    );
    logAction('Administrator', 'ADMIN', 'ORDER_STATUS_UPDATED', `Order ${orderId} status set to ${newStatus}`);
  };

  const handleLoadSampleOrders = () => {
    if (products.length === 0) {
      setProducts(SAMPLE_PRODUCTS);
    }
    setOrders(SAMPLE_ORDERS);
    logAction('Demo Customer', 'CUSTOMER', 'SAMPLE_ORDERS_LOADED', 'Loaded sample delivered orders with verified products');
  };

  // Seller Actions
  const handleAddProduct = (product: Product) => {
    setProducts((prev) => [product, ...prev]);
    logAction(product.sellerName, 'SELLER', 'PRODUCT_CREATED', `Listed product "${product.title}" for approval`);
  };

  const handleUpdateStock = (productId: string, variantId: string | undefined, newStock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: newStock, inStock: newStock > 0 } : p))
    );
  };

  const handleShipOrderItem = (orderId: string, productId: string, awbNumber: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          return {
            ...ord,
            status: 'SHIPPED',
            carrier: 'BlueDart Express',
            trackingNumber: awbNumber,
          };
        }
        return ord;
      })
    );
    logAction(currentSeller?.storeName || 'Merchant', 'SELLER', 'ORDER_SHIPPED', `Dispatched order ${orderId} with AWB ${awbNumber}`);
  };

  // Admin Actions
  const handleApproveProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, approvalStatus: 'APPROVED' } : p))
    );
    logAction('Admin', 'ADMIN', 'PRODUCT_APPROVED', `Approved listing ${productId}`);
  };

  const handleRejectProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, approvalStatus: 'REJECTED' } : p))
    );
  };

  const handleResolveDispute = (disputeId: string, decision: 'REFUND' | 'REJECT') => {
    setDisputes((prev) =>
      prev.map((d) =>
        d.id === disputeId
          ? { ...d, status: decision === 'REFUND' ? 'RESOLVED_REFUND' : 'RESOLVED_REJECTED' }
          : d
      )
    );
    const targetDisp = disputes.find((d) => d.id === disputeId);
    if (targetDisp && decision === 'REFUND') {
      setOrders((prev) =>
        prev.map((ord) => (ord.id === targetDisp.orderId ? { ...ord, status: 'REFUNDED' } : ord))
      );
      logAction('Admin', 'ADMIN', 'DISPUTE_REFUNDED', `Issued refund of ₹${targetDisp.amount} for ${targetDisp.orderId}`);
    }
  };

  const handleAddCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [coupon, ...prev]);
    logAction('Admin', 'ADMIN', 'COUPON_CREATED', `Created voucher code ${coupon.code}`);
  };

  const handleGenerateSettlementBatch = () => {
    const pendingOrders = orders.filter((o) => o.status === 'DELIVERED');
    if (pendingOrders.length === 0) return;

    const newEntries: SettlementLedgerEntry[] = pendingOrders.map((o, idx) => {
      const breakdown = calculateSettlement(o.totalAmount, 0.12, 0.02, 0.18, 0);
      return {
        id: `set_batch_${Date.now().toString().slice(-4)}_${idx}`,
        sellerId: o.items[0]?.sellerId || 'seller_apex',
        sellerName: o.items[0]?.sellerName || 'Apex Tech Innovations',
        orderId: o.id,
        orderDate: o.createdAt.split('T')[0],
        grossAmount: breakdown.grossAmount,
        commissionDeduction: breakdown.marketplaceCommission,
        pgFeeDeduction: breakdown.paymentGatewayFee,
        gstDeduction: breakdown.gstOnFees,
        netPayout: breakdown.netSellerPayout,
        status: 'SETTLED',
        payoutDate: new Date().toISOString().split('T')[0],
        utrNumber: `HDFC${Date.now().toString().slice(-9)}`,
      };
    });

    setSettlements((prev) => [...newEntries, ...prev]);
    logAction('SYSTEM', 'SYSTEM', 'SETTLEMENT_RECONCILED', `Executed automated settlement batch for ${newEntries.length} vendor orders`);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Application Switcher Bar */}
      {!isCustomerShieldActive ? (
        <header className="h-14 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between z-40 shrink-0">
          <div className="flex items-center gap-3">
            <Logo size="sm" showTagline={false} variant="horizontal" />
          </div>

          {/* Central Role & App Switcher */}
          <nav className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800 text-xs font-bold overflow-x-auto">
            {/* Customer App button */}
            <button
              onClick={() => {
                setActiveApp('customer');
                setCurrentRole('CUSTOMER');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                activeApp === 'customer'
                  ? 'bg-[#1746A2] text-white shadow font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-[#FFD447]" />
              <span>Customer Android App</span>
            </button>

            {/* Seller Portal button (Protected) */}
            <button
              onClick={handleRequestSellerPortal}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                activeApp === 'seller'
                  ? 'bg-[#1746A2] text-white shadow font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Store className="w-3.5 h-3.5 text-[#FFD447]" />
              <span>Seller Portal</span>
              {!isSellerUnlocked && !isAdminUnlocked && <Lock className="w-3 h-3 text-slate-500 ml-0.5" />}
            </button>

            {/* Admin Dashboard button (Security Locked) */}
            <button
              onClick={handleRequestAdminDashboard}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                activeApp === 'admin'
                  ? 'bg-[#1746A2] text-white shadow font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-[#FFD447]" />
              <span>Admin Dashboard</span>
              {!isAdminUnlocked ? (
                <Lock className="w-3 h-3 text-amber-400 ml-0.5" />
              ) : (
                <Unlock className="w-3 h-3 text-emerald-400 ml-0.5" />
              )}
            </button>

            {/* Flutter Code Explorer */}
            <button
              onClick={() => setActiveApp('flutter')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                activeApp === 'flutter'
                  ? 'bg-[#1746A2] text-white shadow font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3.5 h-3.5 text-[#FFD447]" />
              <span className="hidden sm:inline">Flutter & Backend Code</span>
            </button>

            {/* AI Studio */}
            <button
              onClick={() => setActiveApp('aiHub')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                activeApp === 'aiHub'
                  ? 'bg-[#1746A2] text-white shadow font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-[#FFD447]" />
              <span className="hidden sm:inline">AI Studio</span>
            </button>

            {/* Android APK Download & Build Center */}
            <button
              onClick={() => setShowApkModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all text-emerald-400 hover:text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/40 border border-emerald-500/40 text-xs font-bold"
              title="Download Android APK or Install App on Phone"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="font-extrabold">APK Build</span>
            </button>
          </nav>

          {/* Right Role Status & Customer Shield Toggle */}
          <div className="flex items-center gap-2">
            {/* Active Session Lock status */}
            {isAdminUnlocked && (
              <button
                onClick={handleLockAdminSession}
                className="hidden md:flex items-center gap-1.5 bg-red-950/80 border border-red-500/40 text-red-300 hover:bg-red-900/60 px-2.5 py-1 rounded-xl text-xs font-bold transition-colors"
                title="Lock Admin Session and prevent unauthorized access"
              >
                <Lock className="w-3 h-3 text-red-400" />
                <span>Lock Admin Tower</span>
              </button>
            )}

            {/* Customer Shield Lock: Hides entire Admin/Developer bar for pure customer presentation */}
            <button
              onClick={() => {
                setIsCustomerShieldActive(true);
                setActiveApp('customer');
                setCurrentRole('CUSTOMER');
              }}
              className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30 text-[#FFD447] hover:bg-amber-500/20 px-2.5 py-1 rounded-xl text-xs font-bold transition-all"
              title="Lock in Customer-Only App Mode (Hides all admin tabs so customers cannot see them)"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Customer-Only Mode</span>
            </button>
          </div>
        </header>
      ) : (
        /* Minimal Customer Mode Banner with secret Admin unlock badge */
        <div className="h-8 bg-slate-950 border-b border-slate-900 px-4 flex items-center justify-between text-[11px] text-slate-400 z-40 shrink-0">
          <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Customer Production App Mode (Admin & Seller Portals Hidden)</span>
          </div>
          <button
            onClick={() => setIsCustomerShieldActive(false)}
            className="flex items-center gap-1 text-slate-400 hover:text-[#FFD447] font-semibold text-[11px] transition-colors"
            title="Switch back to Marketplace Console"
          >
            <KeyRound className="w-3 h-3" />
            <span>Admin Console</span>
          </button>
        </div>
      )}

      {/* Main View Router */}
      <main className="flex-1 flex overflow-hidden">
        {activeApp === 'customer' && (
          <CustomerApp
            products={products}
            reels={reels}
            cart={cart}
            wishlist={wishlist}
            orders={orders}
            onAddToCart={handleAddToCart}
            onUpdateCartQty={handleUpdateCartQty}
            onRemoveFromCart={handleRemoveFromCart}
            onToggleWishlist={handleToggleWishlist}
            onPlaceOrder={handlePlaceOrder}
            onCancelOrder={handleCancelOrder}
            onRequestReturn={handleRequestReturn}
            onAddReview={handleAddReview}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onLoadSampleOrders={handleLoadSampleOrders}
            activeViewMode={customerViewMode}
            onToggleViewMode={() =>
              setCustomerViewMode((prev) => (prev === 'phone' ? 'fullscreen' : 'phone'))
            }
            onOpenSellerRegistration={() => setShowSellerRegistrationModal(true)}
          />
        )}

        {activeApp === 'seller' && (
          <SellerPortal
            currentSeller={currentSeller}
            sellers={sellers}
            products={products}
            orders={orders}
            settlements={settlements}
            onAddProduct={handleAddProduct}
            onUpdateStock={handleUpdateStock}
            onShipOrderItem={handleShipOrderItem}
            onSelectSeller={(id) => setSelectedSellerId(id)}
            onOpenRegistration={() => setShowSellerRegistrationModal(true)}
            onDeleteSeller={handleDeleteSeller}
          />
        )}

        {activeApp === 'admin' && (
          <AdminDashboard
            sellers={sellers}
            products={products}
            orders={orders}
            disputes={disputes}
            auditLogs={auditLogs}
            coupons={coupons}
            banners={banners}
            settlements={settlements}
            onApproveSeller={() => {}}
            onRejectSeller={() => {}}
            onDeleteSeller={handleDeleteSeller}
            onClearAllSellers={handleClearAllSellers}
            onOpenRegistration={() => setShowSellerRegistrationModal(true)}
            onApproveProduct={handleApproveProduct}
            onRejectProduct={handleRejectProduct}
            onDeleteProduct={handleDeleteProduct}
            onClearAllProducts={handleClearAllProducts}
            onLoadSampleProducts={handleLoadSampleProducts}
            onResolveDispute={handleResolveDispute}
            onAddCoupon={handleAddCoupon}
            onGenerateSettlementBatch={handleGenerateSettlementBatch}
          />
        )}

        {activeApp === 'flutter' && <FlutterCodeCenter />}

        {activeApp === 'aiHub' && <AIStudioHub />}
      </main>

      {/* ADMIN AUTHENTICATION SECURITY GATE MODAL */}
      {showAdminGateModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 rounded-2xl bg-red-950/80 border border-red-500/40 text-red-400 flex items-center justify-center font-bold">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  PCMART Central Admin Tower
                </h3>
                <span className="text-[11px] text-red-400 font-semibold block">
                  Restricted Access • Super Administrator Only
                </span>
              </div>
            </div>

            <div className="p-3 bg-red-950/20 border border-red-900/50 rounded-2xl text-xs text-slate-300 space-y-1">
              <p className="font-semibold text-red-300 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                Customer Protection Protocol Active
              </p>
              <p className="text-[11px] text-slate-400 leading-snug">
                Customers and regular visitors cannot access administrative governance, financial ledgers, or refund tools without the verified Super Admin PIN.
              </p>
            </div>

            <form onSubmit={handleVerifyAdminPasscode} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Enter 6-Digit Admin PIN or Passcode:
                </label>
                <input
                  type="password"
                  autoFocus
                  required
                  value={adminPasscodeInput}
                  onChange={(e) => setAdminPasscodeInput(e.target.value)}
                  placeholder="Enter PIN (Demo: 992418)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white text-center font-mono text-base tracking-widest focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              {adminGateError && (
                <div className="p-2 bg-red-950/60 border border-red-500/40 rounded-xl text-[11px] text-red-300">
                  {adminGateError}
                </div>
              )}

              {/* Quick Demo Credentials hint for the owner/developer */}
              <div className="p-2 bg-slate-950 rounded-xl border border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Demo Admin PIN: <strong className="text-[#FFD447] font-mono">992418</strong></span>
                <button
                  type="button"
                  onClick={() => setAdminPasscodeInput('992418')}
                  className="text-xs text-[#FFD447] hover:underline font-bold"
                >
                  Auto-fill
                </button>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAdminGateModal(false)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel (Stay on Customer App)
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black rounded-xl shadow"
                >
                  Unlock Admin Tower
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SELLER MERCHANT SECURITY GATE MODAL */}
      {showSellerGateModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-950/80 border border-blue-500/40 text-blue-400 flex items-center justify-center font-bold">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  PCMART Seller Portal Login
                </h3>
                <span className="text-[11px] text-[#FFD447] font-semibold block">
                  Store: {currentSeller?.storeName || 'Merchant Portal'}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400">
              Enter your Merchant Verification PIN to access vendor orders, dispatch management, and bank settlement ledgers.
            </p>

            <form onSubmit={handleVerifySellerPasscode} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Merchant PIN (Demo: 1234):
                </label>
                <input
                  type="password"
                  autoFocus
                  required
                  value={sellerPasscodeInput}
                  onChange={(e) => setSellerPasscodeInput(e.target.value)}
                  placeholder="Enter 4-digit PIN"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white text-center font-mono text-base tracking-widest focus:outline-none focus:border-[#FFD447]"
                />
              </div>

              {sellerGateError && (
                <div className="p-2 bg-red-950/60 border border-red-500/40 rounded-xl text-[11px] text-red-300">
                  {sellerGateError}
                </div>
              )}

              <div className="p-2 bg-slate-950 rounded-xl border border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Demo Merchant PIN: <strong className="text-[#FFD447] font-mono">1234</strong></span>
                <button
                  type="button"
                  onClick={() => setSellerPasscodeInput('1234')}
                  className="text-xs text-[#FFD447] hover:underline font-bold"
                >
                  Auto-fill
                </button>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowSellerGateModal(false)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black rounded-xl shadow"
                >
                  Authenticate Merchant
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SELLER REGISTRATION & ONBOARDING MODAL */}
      <SellerRegistrationModal
        isOpen={showSellerRegistrationModal}
        onClose={() => setShowSellerRegistrationModal(false)}
        onRegisterSeller={handleRegisterSeller}
      />

      {/* ANDROID APK DOWNLOAD & BUILD MODAL */}
      <ApkDownloadModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
        onOpenFlutterCenter={() => setActiveApp('flutter')}
      />
    </div>
  );
}
