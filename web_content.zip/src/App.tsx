import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { BestSetupsView } from './components/BestSetupsView';
import { DirectionSelectView } from './components/DirectionSelectView';
import { AssetSelectView } from './components/AssetSelectView';
import { AnalyzingView } from './components/AnalyzingView';
import { SignalCard } from './components/SignalCard';
import { CandlestickChart } from './components/CandlestickChart';
import { PhotoAnalysisView } from './components/PhotoAnalysisView';
import { BotStudioModal } from './components/BotStudioModal';
import { ReviewsView } from './components/ReviewsView';
import { ProfileView } from './components/ProfileView';
import { ActiveTradeModal } from './components/ActiveTradeModal';
import { QuotexFloatingScanner } from './components/QuotexFloatingScanner';
import {
  Asset,
  AssetType,
  Timeframe,
  IndicatorConfig,
  BotSettings,
  QuantumSignal,
  TradeOrder,
  Candle,
} from './types/trading';
import { ALL_ASSETS, OTC_ASSETS } from './data/assets';
import {
  generateCandleHistory,
  generateQuotexAlignedCandles,
  evaluateQuantumSignal,
} from './utils/technicalAnalysis';
import { soundManager } from './utils/soundEffects';
import { voiceNarrator } from './utils/voiceNarrator';
import { ArrowLeft, Sliders, Zap, Globe, Sparkles, CheckCircle, Radio } from 'lucide-react';

export type TradeSubView =
  | 'home'
  | 'direction_select'
  | 'asset_select'
  | 'analyzing'
  | 'signal'
  | 'photo_analysis';

const DEFAULT_INDICATORS: IndicatorConfig = {
  rsi: { enabled: true, period: 14, overbought: 70, oversold: 30, weight: 20 },
  bollingerBands: { enabled: true, period: 20, stdDev: 2.0, weight: 25 },
  macd: { enabled: true, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, weight: 15 },
  emaCross: { enabled: true, fastPeriod: 7, slowPeriod: 14, trendPeriod: 50, weight: 20 },
  stochastic: { enabled: true, kPeriod: 14, dPeriod: 3, overbought: 80, oversold: 20, weight: 10 },
  supportResistance: { enabled: true, lookbackCandles: 20, weight: 15 },
  candlestickPatterns: { enabled: true, checkHammer: true, checkEngulfing: true, checkPinBar: true, weight: 20 },
};

const DEFAULT_BOT_SETTINGS: BotSettings = {
  strongSniperMode99: true, // "Giving a strong single bot 99%"
  autoExecute: false,
  stakeAmount: 25,
  martingaleMode: '1_step',
  martingaleMultiplier: 2.2,
  stopLossAmount: 200,
  takeProfitAmount: 500,
  quotexWebhookUrl: '',
  quotexAccountId: 'QX-99SNIPER-42',
  soundEnabled: true,
  minConfidenceThreshold: 90,
  fastAnalysis: true,
};

export default function App() {
  // Navigation State
  const [currentTab, setCurrentTab] = useState<TabType>('trade');
  const [tradeSubView, setTradeSubView] = useState<TradeSubView>('home');
  const [selectedDirection, setSelectedDirection] = useState<AssetType>('OTC');

  // Selected Asset & Market Candles
  const [selectedAsset, setSelectedAsset] = useState<Asset>(OTC_ASSETS[0]); // EUR/USD OTC default
  const [candles, setCandles] = useState<Candle[]>(() =>
    generateCandleHistory(OTC_ASSETS[0].currentPrice, 35, OTC_ASSETS[0].volatility)
  );
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>('1 Minute');

  // Configurations
  const [indicators, setIndicators] = useState<IndicatorConfig>(() => {
    const saved = localStorage.getItem('qx_indicators');
    return saved ? JSON.parse(saved) : DEFAULT_INDICATORS;
  });

  const [botSettings, setBotSettings] = useState<BotSettings>(() => {
    const saved = localStorage.getItem('qx_bot_settings');
    return saved ? JSON.parse(saved) : DEFAULT_BOT_SETTINGS;
  });

  // Modal State
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [isFloatingScannerOpen, setIsFloatingScannerOpen] = useState(false);

  // Active Signal & Trade Engine
  const [currentSignal, setCurrentSignal] = useState<QuantumSignal | null>(null);
  const [activeTrade, setActiveTrade] = useState<TradeOrder | null>(null);
  const [tradeHistory, setTradeHistory] = useState<TradeOrder[]>(() => {
    const saved = localStorage.getItem('qx_trade_history');
    return saved ? JSON.parse(saved) : [];
  });

  // Balance & Counters
  const [balance, setBalance] = useState<number>(() => {
    const saved = localStorage.getItem('qx_balance');
    return saved ? Number(saved) : 10000;
  });
  const [activeTradersCount, setActiveTradersCount] = useState(543);
  const [signalsCountToday, setSignalsCountToday] = useState(5452);
  const [isSyncingRates, setIsSyncingRates] = useState(false);

  // Real-time ticking second
  const [candleSecondsLeft, setCandleSecondsLeft] = useState(60 - new Date().getSeconds());
  const [entrySecondsLeft, setEntrySecondsLeft] = useState(60 - new Date().getSeconds());
  const [tradeEndsSecondsLeft, setTradeEndsSecondsLeft] = useState(120 - new Date().getSeconds());

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('qx_indicators', JSON.stringify(indicators));
  }, [indicators]);

  useEffect(() => {
    localStorage.setItem('qx_bot_settings', JSON.stringify(botSettings));
  }, [botSettings]);

  useEffect(() => {
    localStorage.setItem('qx_balance', balance.toString());
  }, [balance]);

  useEffect(() => {
    localStorage.setItem('qx_trade_history', JSON.stringify(tradeHistory));
  }, [tradeHistory]);

  // Synchronize soundManager state
  useEffect(() => {
    soundManager.setEnabled(botSettings.soundEnabled);
  }, [botSettings.soundEnabled]);

  // Generate Signal for an asset
  const generateSignalForAsset = useCallback(
    (asset: Asset, force99: boolean = botSettings.strongSniperMode99) => {
      const sig = evaluateQuantumSignal(
        asset,
        candles,
        indicators,
        selectedTimeframe,
        force99
      );
      setCurrentSignal(sig);
      currentSignalRef.current = sig;
      setSignalsCountToday((prev) => prev + 1);
      soundManager.playSignalAlert();
      if (voiceNarrator.isAutoSpeak() && botSettings.soundEnabled) {
        voiceNarrator.speakMarketNarrative(sig);
      }
    },
    [candles, indicators, selectedTimeframe, botSettings.strongSniperMode99, botSettings.soundEnabled]
  );

  const currentSignalRef = useRef<QuantumSignal | null>(null);
  currentSignalRef.current = currentSignal;

  const selectedAssetRef = useRef(selectedAsset);
  selectedAssetRef.current = selectedAsset;

  // Live Market Rates Sync (Stable callback with safe fallback)
  const fetchLiveRates = useCallback(async () => {
    setIsSyncingRates(true);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);

    try {
      const res = await fetch('/api/live-rates', { signal: controller.signal });
      clearTimeout(timeout);

      if (res.ok) {
        const data = await res.json();
        if (data && data.success && data.rates) {
          const currentSym = selectedAssetRef.current.symbol;
          const livePrice = data.rates[currentSym] || data.rates[currentSym.replace(' OTC', '')];
          if (livePrice && Math.abs(livePrice - selectedAssetRef.current.currentPrice) > 0.00001) {
            setSelectedAsset((prev) => ({ ...prev, currentPrice: livePrice }));
            setCandles((prev) => {
              if (prev.length === 0) return generateCandleHistory(livePrice, 35, selectedAssetRef.current.volatility);
              const currentClose = prev[prev.length - 1].close;
              const diff = livePrice - currentClose;
              return prev.map((c) => ({
                ...c,
                open: Number((c.open + diff).toFixed(selectedAssetRef.current.decimals)),
                high: Number((c.high + diff).toFixed(selectedAssetRef.current.decimals)),
                low: Number((c.low + diff).toFixed(selectedAssetRef.current.decimals)),
                close: Number((c.close + diff).toFixed(selectedAssetRef.current.decimals)),
              }));
            });
          }
        }
      }
    } catch {
      clearTimeout(timeout);
      // Graceful fallback: maintain existing reliable chart candles
    } finally {
      setIsSyncingRates(false);
    }
  }, []);

  // Initial live rate fetch & background polling
  useEffect(() => {
    fetchLiveRates();
    const timer = setInterval(() => {
      fetchLiveRates();
    }, 30000);
    return () => clearInterval(timer);
  }, [fetchLiveRates]);

  // Calibrate exact Quotex price
  const handleCalibratePrice = useCallback((newPrice: number) => {
    setSelectedAsset((prev) => ({ ...prev, currentPrice: newPrice }));
    setCandles((prev) => {
      if (prev.length === 0) return generateQuotexAlignedCandles(newPrice, 'BULLISH', 28, selectedAsset.volatility, selectedAsset.decimals);
      const currentClose = prev[prev.length - 1].close;
      const diff = newPrice - currentClose;
      const updated = prev.map((c) => ({
        ...c,
        open: Number((c.open + diff).toFixed(selectedAsset.decimals)),
        high: Number((c.high + diff).toFixed(selectedAsset.decimals)),
        low: Number((c.low + diff).toFixed(selectedAsset.decimals)),
        close: Number((c.close + diff).toFixed(selectedAsset.decimals)),
      }));
      updated[updated.length - 1].close = newPrice;

      setTimeout(() => {
        const sig = evaluateQuantumSignal(
          { ...selectedAsset, currentPrice: newPrice },
          updated,
          indicators,
          selectedTimeframe,
          botSettings.strongSniperMode99
        );
        setCurrentSignal(sig);
      }, 20);

      return updated;
    });
  }, [selectedAsset, indicators, selectedTimeframe, botSettings.strongSniperMode99]);

  // Fast Quotex Market Trend alignment (Bullish Rally or Bearish Drop)
  const handleSetMarketTrend = useCallback((trend: 'BULLISH' | 'BEARISH' | 'RANGE') => {
    soundManager.playPip();
    const alignedCandles = generateQuotexAlignedCandles(
      selectedAsset.currentPrice,
      trend,
      28,
      selectedAsset.volatility,
      selectedAsset.decimals
    );
    setCandles(alignedCandles);
    const newSignal = evaluateQuantumSignal(
      selectedAsset,
      alignedCandles,
      indicators,
      selectedTimeframe,
      botSettings.strongSniperMode99
    );
    setCurrentSignal(newSignal);
  }, [selectedAsset, indicators, selectedTimeframe, botSettings.strongSniperMode99]);

  // Live market tick loop (1 second interval)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentSeconds = now.getSeconds();
      const secondsLeft = 60 - currentSeconds;
      setCandleSecondsLeft(secondsLeft);
      setEntrySecondsLeft(secondsLeft);
      setTradeEndsSecondsLeft(secondsLeft + 60);

      // Audio metronome alert & spoken countdown so trader never misses out
      if (secondsLeft <= 5 && secondsLeft >= 1 && botSettings.soundEnabled) {
        soundManager.playPip();
        if (secondsLeft <= 3 && voiceNarrator.isAutoSpeak()) {
          voiceNarrator.speakCountdown(secondsLeft, currentSignalRef.current?.action || 'BUY');
        }
      } else if (currentSeconds === 0 && botSettings.soundEnabled) {
        soundManager.playSignalAlert();
        if (voiceNarrator.isAutoSpeak()) {
          voiceNarrator.speakCountdown(0, currentSignalRef.current?.action || 'BUY');
        }
      }

      // Fluctuate active traders randomly
      if (Math.random() < 0.1) {
        setActiveTradersCount((prev) => prev + (Math.random() > 0.5 ? 1 : -1));
      }

      // Add small price tick to the current running candle
      setCandles((prev) => {
        if (prev.length === 0) return prev;
        const last = { ...prev[prev.length - 1] };
        const tickDelta = (Math.random() - 0.49) * selectedAsset.volatility * 1.5;
        const newClose = last.close + tickDelta;
        last.close = newClose;
        if (newClose > last.high) last.high = newClose;
        if (newClose < last.low) last.low = newClose;

        // If candle completed at 00 seconds, create new candle
        if (currentSeconds === 0) {
          const newCandle: Candle = {
            time: Date.now(),
            open: newClose,
            high: newClose,
            low: newClose,
            close: newClose,
            volume: Math.floor(Math.random() * 300) + 50,
          };
          const nextCandles = [...prev.slice(-34), newCandle];
          
          // Re-calibrate signal immediately with confirmed closed candle
          setTimeout(() => {
            const sig = evaluateQuantumSignal(
              selectedAsset,
              nextCandles,
              indicators,
              selectedTimeframe,
              botSettings.strongSniperMode99
            );
            setCurrentSignal(sig);
            setSignalsCountToday((c) => c + 1);

            // If auto-trade is enabled and trade is safe, execute on new candle open
            if (botSettings.autoExecute && sig.isTradeSafe !== false && !activeTrade) {
              handleExecuteTrade();
            }
          }, 40);

          return nextCandles;
        }

        return [...prev.slice(0, -1), last];
      });

      // Update Active Trade countdown and resolution
      setActiveTrade((currentTrade) => {
        if (!currentTrade || currentTrade.status !== 'OPEN') return currentTrade;

        const newRemaining = currentTrade.secondsRemaining - 1;
        const livePrice = candles[candles.length - 1]?.close || currentTrade.currentPrice;

        if (newRemaining <= 0) {
          // Trade Expired - Resolve Win or Loss
          const isUp = currentTrade.direction === 'UP';
          const won = isUp ? livePrice > currentTrade.entryPrice : livePrice < currentTrade.entryPrice;
          const status = won ? 'WON' : 'LOST';
          const actualProfit = won ? currentTrade.potentialProfit : -currentTrade.stake;

          if (won) {
            soundManager.playTradeWon();
            setBalance((b) => b + currentTrade.stake + currentTrade.potentialProfit);
          } else {
            soundManager.playTradeLost();
            // Stake was already deducted at entry
          }

          const resolvedTrade: TradeOrder = {
            ...currentTrade,
            status,
            exitPrice: livePrice,
            currentPrice: livePrice,
            actualProfit,
            secondsRemaining: 0,
          };

          setTradeHistory((th) => [resolvedTrade, ...th]);
          return null; // Close active trade
        }

        return {
          ...currentTrade,
          secondsRemaining: newRemaining,
          currentPrice: livePrice,
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [selectedAsset, botSettings.autoExecute, currentSignal, activeTrade, candles]);

  // Execute trade order
  const handleExecuteTrade = useCallback(() => {
    if (!currentSignal) return;
    if (activeTrade && activeTrade.status === 'OPEN') return;

    const currentPrice = candles[candles.length - 1]?.close || selectedAsset.currentPrice;
    const stake = botSettings.stakeAmount;
    const payoutPercent = selectedAsset.payout;
    const potentialProfit = (stake * payoutPercent) / 100;

    // Deduct stake from balance
    setBalance((b) => Math.max(0, b - stake));

    const newTrade: TradeOrder = {
      id: `QX-${Date.now().toString(36).toUpperCase()}`,
      signalId: currentSignal.id,
      pair: currentSignal.pair,
      direction: currentSignal.direction,
      action: currentSignal.action,
      timeframe: selectedTimeframe,
      entryPrice: currentPrice,
      currentPrice: currentPrice,
      stake,
      payoutPercent,
      potentialProfit,
      status: 'OPEN',
      openedAt: Date.now(),
      expiresAt: Date.now() + 60 * 1000,
      secondsRemaining: 60,
      isSniper99: currentSignal.isStrongSniper99,
      mode: 'DEMO',
    };

    setActiveTrade(newTrade);
    soundManager.playTradeEntry();

    // If Quotex Webhook is configured, dispatch webhook payload asynchronously
    if (botSettings.quotexWebhookUrl) {
      fetch('/api/quotex-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pair: currentSignal.pair,
          direction: currentSignal.direction,
          amount: stake,
          expirySeconds: 60,
          signalId: currentSignal.id,
          timestamp: new Date().toISOString(),
        }),
      }).catch(console.error);
    }
  }, [currentSignal, activeTrade, candles, selectedAsset, botSettings, selectedTimeframe]);

  // Handle selecting an asset from grid
  const handleSelectAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    const newCandles = generateCandleHistory(asset.currentPrice, 35, asset.volatility);
    setCandles(newCandles);
    setTradeSubView('analyzing');
  };

  // Handle selecting a setup from Best Setups
  const handleSelectSetup = (pairSymbol: string) => {
    const found = ALL_ASSETS.find((a) => a.symbol === pairSymbol) || OTC_ASSETS[0];
    handleSelectAsset(found);
  };

  // Handle refreshing to the next signal
  const handleRefreshSignal = useCallback(() => {
    soundManager.playPip();
    fetchLiveRates();
    const now = new Date();
    const nextOpenSeconds = 60 - now.getSeconds();
    setEntrySecondsLeft(nextOpenSeconds);
    setTradeEndsSecondsLeft(nextOpenSeconds + 60);

    const updatedCandles = generateCandleHistory(
      selectedAsset.currentPrice,
      35,
      selectedAsset.volatility
    );
    setCandles(updatedCandles);
    generateSignalForAsset(selectedAsset);
  }, [selectedAsset, fetchLiveRates, generateSignalForAsset]);

  return (
    <div className="min-h-screen bg-[#0a0306] text-slate-100 flex flex-col font-sans selection:bg-red-500 selection:text-white pb-20">
      {/* Universal Top Header */}
      <Header
        soundEnabled={botSettings.soundEnabled}
        onToggleSound={() =>
          setBotSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))
        }
        voiceEnabled={botSettings.soundEnabled}
        onToggleVoice={() => {
          const next = !botSettings.soundEnabled;
          setBotSettings((s) => ({ ...s, soundEnabled: next }));
          voiceNarrator.setVoiceEnabled(next);
        }}
        onOpenSettings={() => setIsStudioOpen(true)}
        strongSniperMode={botSettings.strongSniperMode99}
        onToggleSniperMode={() =>
          setBotSettings((s) => ({
            ...s,
            strongSniperMode99: !s.strongSniperMode99,
          }))
        }
        balance={balance}
        activeTradersCount={activeTradersCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-2 sm:px-4 py-2">
        {/* TAB 1: TRADE */}
        {currentTab === 'trade' && (
          <div className="w-full flex flex-col items-center">
            {/* SUB-VIEW 1: HOME (Welcome, Today's Best Setups, Mode Pickers) */}
            {tradeSubView === 'home' && (
              <BestSetupsView
                onSelectPhotoMode={() => setTradeSubView('photo_analysis')}
                onSelectManualMode={() => setTradeSubView('direction_select')}
                onSelectSetup={handleSelectSetup}
                signalsCountToday={signalsCountToday}
              />
            )}

            {/* SUB-VIEW 2: DIRECTION SELECT (OTC PAIRS HOT vs MARKET PAIRS PRO) */}
            {tradeSubView === 'direction_select' && (
              <DirectionSelectView
                onBack={() => setTradeSubView('home')}
                onSelectDirection={(type) => {
                  setSelectedDirection(type);
                  setTradeSubView('asset_select');
                }}
              />
            )}

            {/* SUB-VIEW 3: ASSET SELECT (Searchable 2-Column Asset Grid) */}
            {tradeSubView === 'asset_select' && (
              <AssetSelectView
                type={selectedDirection}
                onBack={() => setTradeSubView('direction_select')}
                onSelectAsset={handleSelectAsset}
              />
            )}

            {/* SUB-VIEW 4: ANALYZING STATE (Circular neural progress ring) */}
            {tradeSubView === 'analyzing' && (
              <AnalyzingView
                asset={selectedAsset}
                timeframe={selectedTimeframe}
                isSniper99={botSettings.strongSniperMode99}
                isFastMode={botSettings.fastAnalysis}
                onCancel={() => setTradeSubView('asset_select')}
                onComplete={() => {
                  generateSignalForAsset(selectedAsset);
                  setTradeSubView('signal');
                }}
              />
            )}

            {/* SUB-VIEW 5: PHOTO ANALYSIS (AI Vision Screenshot Scanner) */}
            {tradeSubView === 'photo_analysis' && (
              <PhotoAnalysisView
                onBack={() => setTradeSubView('home')}
                onSignalGenerated={(sig) => {
                  const cleanPair = sig.pair.trim();
                  const match =
                    ALL_ASSETS.find(
                      (a) =>
                        a.symbol.toLowerCase() === cleanPair.toLowerCase() ||
                        a.symbol.toLowerCase() === cleanPair.replace(' otc', '').toLowerCase()
                    ) || selectedAsset;
                  const targetPrice = sig.targetPrice || match.currentPrice;
                  const updatedAsset: Asset = { ...match, currentPrice: targetPrice, payout: 91 };
                  setSelectedAsset(updatedAsset);
                  const alignedTrend = sig.direction === 'UP' ? 'BULLISH' : 'BEARISH';
                  const newCandles = generateQuotexAlignedCandles(
                    targetPrice,
                    alignedTrend,
                    28,
                    match.volatility,
                    match.decimals
                  );
                  setCandles(newCandles);
                  setCurrentSignal(sig);
                  setTradeSubView('signal');
                }}
              />
            )}

            {/* SUB-VIEW 6: SIGNAL DISPLAY & REAL-TIME CHART VIEW */}
            {tradeSubView === 'signal' && currentSignal && (
              <div className="w-full flex flex-col items-center gap-3">
                {/* Top Action Bar */}
                <div className="w-full max-w-lg flex items-center justify-between px-1">
                  <button
                    onClick={() => setTradeSubView('asset_select')}
                    className="flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Change Asset</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setTradeSubView('analyzing');
                      }}
                      className="text-xs font-bold text-red-400 hover:text-red-300 font-mono"
                    >
                      Rescan Market
                    </button>
                  </div>
                </div>

                {/* Active Trade Banner if position is open */}
                {activeTrade && activeTrade.status === 'OPEN' && (
                  <div className="w-full max-w-lg">
                    <ActiveTradeModal trade={activeTrade} asset={selectedAsset} />
                  </div>
                )}

                {/* Real-time Candlestick Chart */}
                <div className="w-full max-w-lg">
                  <CandlestickChart
                    candles={candles}
                    asset={selectedAsset}
                    activeTrade={activeTrade}
                    candleSecondsLeft={candleSecondsLeft}
                    onSyncLiveRate={fetchLiveRates}
                    onCalibratePrice={handleCalibratePrice}
                    onSetMarketTrend={handleSetMarketTrend}
                    onOpenPhotoAnalysis={() => setTradeSubView('photo_analysis')}
                    onOpenScanner={() => setIsFloatingScannerOpen(true)}
                    isSyncingRates={isSyncingRates}
                  />
                </div>

                {/* Signal Card (Screenshot 1) */}
                <SignalCard
                  signal={currentSignal}
                  entrySecondsLeft={entrySecondsLeft}
                  tradeEndsSecondsLeft={tradeEndsSecondsLeft}
                  onExecuteTrade={handleExecuteTrade}
                  isExecuting={false}
                  activeTrade={activeTrade}
                  autoExecute={botSettings.autoExecute}
                  onToggleAutoExecute={() =>
                    setBotSettings((s) => ({ ...s, autoExecute: !s.autoExecute }))
                  }
                  onOpenPhotoAnalysis={() => setTradeSubView('photo_analysis')}
                  onRefreshSignal={handleRefreshSignal}
                />
              </div>
            )}
          </div>
        )}

        {/* TAB 2: REVIEWS */}
        {currentTab === 'reviews' && <ReviewsView />}

        {/* TAB 3: PROFILE */}
        {currentTab === 'profile' && (
          <ProfileView
            balance={balance}
            onResetBalance={() => setBalance(10000)}
            tradeHistory={tradeHistory}
            botSettings={botSettings}
          />
        )}
      </main>

      {/* Bottom 3-Tab Navigation (Screenshots 2 & 6) */}
      <BottomNav currentTab={currentTab} onChangeTab={setCurrentTab} />

      {/* Quotex Market Scanner Floating Quick-Launcher Button */}
      <div className="fixed bottom-20 right-3 z-40">
        <button
          onClick={() => {
            soundManager.playPip();
            setIsFloatingScannerOpen(true);
          }}
          className="group relative flex items-center gap-1.5 bg-[#061226]/95 hover:bg-[#0c1f46] text-[#00ff88] border-2 border-[#00ff88]/60 hover:border-[#00ff88] px-3.5 py-1.5 rounded-full font-mono font-bold text-xs shadow-[0_0_22px_rgba(0,255,136,0.45)] transition-all hover:scale-105 active:scale-95 cursor-pointer backdrop-blur-md"
          title="Open Quotex Market Scanner Floating Panel"
        >
          <div className="w-2 h-2 rounded-full bg-[#00ff88] animate-ping" />
          <Radio className="w-3.5 h-3.5 text-[#00ff88] animate-pulse" />
          <span className="tracking-wider text-[11px]">SCANNER</span>
        </button>
      </div>

      {/* Custom Technical Indicators & 99% Bot Studio Modal */}
      <BotStudioModal
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
        indicators={indicators}
        onUpdateIndicators={setIndicators}
        botSettings={botSettings}
        onUpdateBotSettings={setBotSettings}
      />

      {/* Quotex Market Scanner Floating Panel Modal */}
      <QuotexFloatingScanner
        isOpen={isFloatingScannerOpen}
        onClose={() => setIsFloatingScannerOpen(false)}
        defaultPair={selectedAsset.symbol}
      />
    </div>
  );
}
