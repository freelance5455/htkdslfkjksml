import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  CellState,
  ColorId,
  Coordinate,
  GameMode,
  LevelConfig,
  SaveData,
  ScreenState,
  SpecialTile
} from './types/game';
import { COLOR_THEMES, NODE_SKINS } from './utils/colorThemes';
import { loadSaveData, writeSaveData, resetSaveData } from './utils/storage';
import { soundEngine } from './utils/audio';
import { getClassicLevel } from './data/levels';
import {
  getDailyChallengeLevel,
  getEndlessLevel,
  getTimeChallengeLevel
} from './utils/levelGenerator';
import { ACHIEVEMENTS } from './data/achievements';

import { GameCanvas } from './components/GameCanvas';
import { HUD } from './components/HUD';
import { TitleScreen } from './components/TitleScreen';
import { VictoryModal } from './components/VictoryModal';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { LevelSelectModal } from './components/LevelSelectModal';
import { ShopModal } from './components/ShopModal';
import { AchievementsModal } from './components/AchievementsModal';
import { DailyCalendarModal } from './components/DailyCalendarModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { SettingsModal } from './components/SettingsModal';
import { DownloadApkModal } from './components/DownloadApkModal';

export default function App() {
  const [saveData, setSaveData] = useState<SaveData>(loadSaveData);
  const [screen, setScreen] = useState<ScreenState>('TITLE');
  const [isDownloadApkOpen, setIsDownloadApkOpen] = useState<boolean>(false);
  const [mode, setMode] = useState<GameMode>('classic');
  const [currentLevelIndex, setCurrentLevelIndex] = useState<number>(1);
  const [level, setLevel] = useState<LevelConfig>(() => getClassicLevel(1));

  // Board & Path Drawing State
  const [grid, setGrid] = useState<CellState[][]>([]);
  const [paths, setPaths] = useState<Map<ColorId, Coordinate[]>>(new Map());
  const [pathHistory, setPathHistory] = useState<Map<ColorId, Coordinate[]>[]>([]);
  const [activeColor, setActiveColor] = useState<ColorId | null>(null);
  const [activePath, setActivePath] = useState<Coordinate[]>([]);
  const [hintPath, setHintPath] = useState<Coordinate[] | null>(null);

  // Gameplay Run Counters
  const [movesRemaining, setMovesRemaining] = useState<number>(10);
  const [movesTaken, setMovesTaken] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [comboCount, setComboCount] = useState<number>(0);
  const [highestCombo, setHighestCombo] = useState<number>(0);
  const [multiplier, setMultiplier] = useState<number>(1);
  const [lastConnectionTime, setLastConnectionTime] = useState<number>(0);

  // Time Challenge timer
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const timerRef = useRef<any>(null);

  // End State Modal Data
  const [starsEarned, setStarsEarned] = useState<number>(0);
  const [coinsEarned, setCoinsEarned] = useState<number>(0);

  // Active theme & skin configs
  const activeTheme = COLOR_THEMES[saveData.activeThemeId] || COLOR_THEMES.cyber_neon;
  const activeSkinId = saveData.activeSkinId || 'neon_orb';

  // Persist SaveData on change
  const updateSaveData = useCallback((updater: (prev: SaveData) => SaveData) => {
    setSaveData((prev) => {
      const next = updater(prev);
      writeSaveData(next);
      return next;
    });
  }, []);

  // Check achievements against current stats
  const checkAchievements = useCallback((stats: SaveData['stats'], achievements: Record<string, boolean>) => {
    const updated = { ...achievements };
    let coinsBonus = 0;

    ACHIEVEMENTS.forEach((ach) => {
      if (updated[ach.id]) return;
      let earned = false;
      if (ach.id === 'first_connect' && stats.totalPathsCompleted >= 1) earned = true;
      if (ach.id === 'level_5_clear' && stats.levelsCompleted >= 5) earned = true;
      if (ach.id === 'combo_x3' && stats.highestCombo >= 3) earned = true;
      if (ach.id === 'daily_pioneer' && stats.dailyStreak >= 1) earned = true;
      if (ach.id === 'daily_streak_3' && stats.dailyStreak >= 3) earned = true;
      if (ach.id === 'endless_stage_10' && stats.endlessHighScore >= 10) earned = true;
      if (ach.id === 'world_1_master' && stats.levelsCompleted >= 10) earned = true;

      if (earned) {
        updated[ach.id] = true;
        coinsBonus += ach.coinReward;
      }
    });

    if (coinsBonus > 0) {
      updateSaveData((prev) => ({
        ...prev,
        stats: { ...prev.stats, totalCoins: prev.stats.totalCoins + coinsBonus },
        achievements: updated
      }));
    }
  }, [updateSaveData]);

  // Initialize a new level setup
  const initLevel = useCallback((newLevel: LevelConfig, newMode: GameMode) => {
    setLevel(newLevel);
    setMode(newMode);
    setPaths(new Map());
    setPathHistory([]);
    setActiveColor(null);
    setActivePath([]);
    setHintPath(null);

    setMovesRemaining(newLevel.maxMoves);
    setMovesTaken(0);
    setScore(0);
    setComboCount(0);
    setHighestCombo(0);
    setMultiplier(1);
    setTimeLeft(newLevel.timeLimit || 30);

    // Build initial grid
    const initialGrid: CellState[][] = Array.from({ length: newLevel.rows }, (_, r) =>
      Array.from({ length: newLevel.cols }, (_, c) => ({
        r,
        c,
        color: null,
        isEndpoint: false,
        pathColor: null
      }))
    );

    // Place endpoints
    newLevel.pairs.forEach((pair) => {
      if (initialGrid[pair.start.r]?.[pair.start.c]) {
        initialGrid[pair.start.r][pair.start.c] = {
          ...initialGrid[pair.start.r][pair.start.c],
          color: pair.color,
          isEndpoint: true,
          endpointIndex: 0
        };
      }
      if (initialGrid[pair.end.r]?.[pair.end.c]) {
        initialGrid[pair.end.r][pair.end.c] = {
          ...initialGrid[pair.end.r][pair.end.c],
          color: pair.color,
          isEndpoint: true,
          endpointIndex: 1
        };
      }
    });

    // Place special tiles if any
    newLevel.specialTiles?.forEach((st) => {
      if (initialGrid[st.r]?.[st.c]) {
        initialGrid[st.r][st.c] = {
          ...initialGrid[st.r][st.c],
          specialTile: st
        };
      }
    });

    setGrid(initialGrid);
    setScreen('PLAYING');

    // Ambient audio
    if (saveData.settings.music) {
      soundEngine.startAmbientLoop();
    }
  }, [saveData.settings.music]);

  // Start game with specified mode & level
  const startGame = useCallback((targetMode: GameMode, levelId?: number | string) => {
    let lvl: LevelConfig;
    if (targetMode === 'classic') {
      const num = typeof levelId === 'number' ? levelId : 1;
      setCurrentLevelIndex(num);
      lvl = getClassicLevel(num);
    } else if (targetMode === 'time_challenge') {
      setCurrentLevelIndex(1);
      lvl = getTimeChallengeLevel(1);
    } else if (targetMode === 'endless') {
      setCurrentLevelIndex(1);
      lvl = getEndlessLevel(1);
    } else {
      // Daily
      const today = new Date().toISOString().split('T')[0];
      lvl = getDailyChallengeLevel(today);
    }
    initLevel(lvl, targetMode);
  }, [initLevel]);

  // Time Challenge Countdown Timer
  useEffect(() => {
    if (screen !== 'PLAYING' || mode !== 'time_challenge') {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          soundEngine.playGameOver();
          setScreen('GAME_OVER');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [screen, mode]);

  // Check if a color pair is completed by a path
  const isPairConnected = useCallback((pair: LevelConfig['pairs'][0], pathCoords: Coordinate[]) => {
    if (!pathCoords || pathCoords.length < 2) return false;
    const first = pathCoords[0];
    const last = pathCoords[pathCoords.length - 1];
    return (
      (first.r === pair.start.r && first.c === pair.start.c && last.r === pair.end.r && last.c === pair.end.c) ||
      (first.r === pair.end.r && first.c === pair.end.c && last.r === pair.start.r && last.c === pair.start.c)
    );
  }, []);

  // Check victory condition
  const checkVictory = useCallback((updatedPaths: Map<ColorId, Coordinate[]>, moves: number) => {
    const allConnected = level.pairs.every((pair) => {
      const p = updatedPaths.get(pair.color);
      return p && isPairConnected(pair, p);
    });

    if (allConnected) {
      soundEngine.playVictory();

      // Calculate Stars
      let stars = 1;
      if (mode === 'classic') {
        const remaining = level.maxMoves - moves;
        if (remaining >= 3 || moves <= level.parMoves) stars = 3;
        else if (remaining >= 1) stars = 2;
      } else {
        stars = 3;
      }

      // Calculate Scoring
      const remainingMoves = Math.max(0, level.maxMoves - moves);
      const moveBonus = remainingMoves * 25;
      const perfectBonus = remainingMoves >= 3 ? 500 : 0;
      const finalScore = score + moveBonus + perfectBonus + 200;

      // Calculate Coins Earned
      const coins = 20 + stars * 10 + remainingMoves * 3 + (mode === 'daily' ? 100 : 0);

      setStarsEarned(stars);
      setCoinsEarned(coins);

      // Update Player Progress & Persistence
      updateSaveData((prev) => {
        const todayStr = new Date().toISOString().split('T')[0];
        const newTotalCoins = prev.stats.totalCoins + coins;
        const newLevelsCompleted = mode === 'classic' ? Math.max(prev.stats.levelsCompleted, currentLevelIndex) : prev.stats.levelsCompleted;
        const newPerfect = stars === 3 ? prev.stats.perfectLevels + 1 : prev.stats.perfectLevels;

        // Daily Streak calculation
        let newDailyStreak = prev.stats.dailyStreak;
        let lastDate = prev.stats.lastDailyDate;
        if (mode === 'daily' && !prev.dailyCompletions[todayStr]?.completed) {
          const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
          if (lastDate === yesterday) {
            newDailyStreak += 1;
          } else {
            newDailyStreak = 1;
          }
          lastDate = todayStr;
        }

        const newStats = {
          ...prev.stats,
          totalCoins: newTotalCoins,
          levelsCompleted: newLevelsCompleted,
          perfectLevels: newPerfect,
          starsCollected: prev.stats.starsCollected + stars,
          highestCombo: Math.max(prev.stats.highestCombo, highestCombo),
          dailyStreak: newDailyStreak,
          lastDailyDate: lastDate,
          timeChallengeHighScore:
            mode === 'time_challenge' ? Math.max(prev.stats.timeChallengeHighScore, currentLevelIndex) : prev.stats.timeChallengeHighScore,
          endlessHighScore:
            mode === 'endless' ? Math.max(prev.stats.endlessHighScore, finalScore) : prev.stats.endlessHighScore
        };

        const updatedLevelProg = { ...prev.levelProgress };
        if (mode === 'classic') {
          const prevEntry = updatedLevelProg[currentLevelIndex];
          updatedLevelProg[currentLevelIndex] = {
            completed: true,
            stars: Math.max(prevEntry?.stars || 0, stars),
            highScore: Math.max(prevEntry?.highScore || 0, finalScore),
            fewestMoves: Math.min(prevEntry?.fewestMoves || 999, moves)
          };
        }

        const updatedDaily = { ...prev.dailyCompletions };
        if (mode === 'daily') {
          updatedDaily[todayStr] = {
            completed: true,
            stars,
            score: finalScore
          };
        }

        checkAchievements(newStats, prev.achievements);

        return {
          ...prev,
          stats: newStats,
          levelProgress: updatedLevelProg,
          dailyCompletions: updatedDaily
        };
      });

      setScreen('VICTORY');
    }
  }, [
    level,
    mode,
    score,
    currentLevelIndex,
    highestCombo,
    isPairConnected,
    updateSaveData,
    checkAchievements
  ]);

  // Input Handlers: Pointer Down on a Cell
  const handleCellPointerDown = useCallback((cell: Coordinate) => {
    const cellState = grid[cell.r]?.[cell.c];
    if (!cellState) return;

    // Check if cell is an endpoint
    if (cellState.isEndpoint && cellState.color) {
      const color = cellState.color;
      soundEngine.playNodeSelect(level.pairs.findIndex((p) => p.color === color));

      // Save history for Undo
      setPathHistory((prev) => [...prev.slice(-10), new Map(paths)]);

      // If a path already existed for this color, clear it to start drawing fresh
      const nextPaths = new Map(paths);
      nextPaths.delete(color);
      setPaths(nextPaths);

      setActiveColor(color);
      setActivePath([cell]);
      setHintPath(null);
    } else {
      // Check if user tapped an existing path to pick it up or backtrack
      paths.forEach((p, color) => {
        const idx = p.findIndex((pt) => pt.r === cell.r && pt.c === cell.c);
        if (idx !== -1) {
          soundEngine.playNodeSelect(level.pairs.findIndex((pair) => pair.color === color));
          // Save history for Undo
          setPathHistory((prev) => [...prev.slice(-10), new Map(paths)]);

          // Truncate path to this point
          const trimmed = p.slice(0, idx + 1);
          const nextPaths = new Map(paths);
          nextPaths.delete(color);
          setPaths(nextPaths);

          setActiveColor(color);
          setActivePath(trimmed);
          setHintPath(null);
        }
      });
    }
  }, [grid, paths, level.pairs]);

  // Pointer enters an adjacent cell while dragging
  const handleCellPointerEnter = useCallback((cell: Coordinate) => {
    if (!activeColor || activePath.length === 0) return;

    const last = activePath[activePath.length - 1];

    // Check if stepping back (backtracking)
    if (activePath.length >= 2) {
      const secondLast = activePath[activePath.length - 2];
      if (secondLast.r === cell.r && secondLast.c === cell.c) {
        soundEngine.playPathStep(activePath.length - 1);
        setActivePath((prev) => prev.slice(0, -1));
        return;
      }
    }

    // Must be orthogonally adjacent (Manhattan distance == 1)
    const dist = Math.abs(cell.r - last.r) + Math.abs(cell.c - last.c);
    if (dist !== 1) return;

    // Prevent looping on self
    if (activePath.some((pt) => pt.r === cell.r && pt.c === cell.c)) return;

    const cellState = grid[cell.r]?.[cell.c];
    if (!cellState) return;

    // Cannot step into an endpoint of another color
    if (cellState.isEndpoint && cellState.color !== activeColor) {
      soundEngine.playPathCancel();
      return;
    }

    // Cannot step into a cell already claimed by another color's path
    let isBlockedByOtherColor = false;
    paths.forEach((p, color) => {
      if (color !== activeColor) {
        if (p.some((pt) => pt.r === cell.r && pt.c === cell.c)) {
          isBlockedByOtherColor = true;
        }
      }
    });
    if (isBlockedByOtherColor) {
      soundEngine.playPathCancel();
      return;
    }

    // Step audio feedback
    soundEngine.playPathStep(activePath.length);

    // Special Tile Triggers: Portal
    if (cellState.specialTile?.type === 'portal' && cellState.specialTile.targetPortal) {
      soundEngine.playSpecial('portal');
      const target = cellState.specialTile.targetPortal;
      setActivePath((prev) => [...prev, cell, target]);
      return;
    }

    // Special Tile Triggers: Multiplier
    if (cellState.specialTile?.type === 'multiplier') {
      soundEngine.playSpecial('multiplier');
      setMultiplier((prev) => Math.min(prev * (cellState.specialTile?.value || 2), 6));
    }

    // Append to active path
    const nextActivePath = [...activePath, cell];
    setActivePath(nextActivePath);

    // Check if reached the matching target endpoint
    const pair = level.pairs.find((p) => p.color === activeColor);
    if (pair && isPairConnected(pair, nextActivePath)) {
      // Completed this connection!
      soundEngine.playPathComplete();

      // Combo System
      const now = Date.now();
      let nextCombo = 1;
      if (now - lastConnectionTime < 4500) {
        nextCombo = comboCount + 1;
        soundEngine.playCombo(nextCombo);
      }
      setComboCount(nextCombo);
      setHighestCombo((prev) => Math.max(prev, nextCombo));
      setLastConnectionTime(now);

      // Score Calculation
      const basePoints = 100 * multiplier;
      const comboBonus = (nextCombo - 1) * 50;
      setScore((prev) => prev + basePoints + comboBonus);

      // Track Move
      const nextMovesTaken = movesTaken + 1;
      const nextMovesRemaining = movesRemaining - 1;
      setMovesTaken(nextMovesTaken);
      setMovesRemaining(nextMovesRemaining);

      // Store in completed paths
      const updatedPaths = new Map(paths);
      updatedPaths.set(activeColor, nextActivePath);
      setPaths(updatedPaths);
      setActiveColor(null);
      setActivePath([]);

      // Update total paths stat
      updateSaveData((prev) => ({
        ...prev,
        stats: {
          ...prev.stats,
          totalPathsCompleted: prev.stats.totalPathsCompleted + 1,
          totalMovesMade: prev.stats.totalMovesMade + 1
        }
      }));

      // Check Victory
      checkVictory(updatedPaths, nextMovesTaken);

      // Check Out of Moves in Classic Mode
      if (mode === 'classic' && nextMovesRemaining <= 0) {
        // Only trigger Game Over if not already won
        const allDone = level.pairs.every((pr) => {
          const cp = updatedPaths.get(pr.color);
          return cp && isPairConnected(pr, cp);
        });
        if (!allDone) {
          soundEngine.playGameOver();
          setScreen('GAME_OVER');
        }
      }
    }
  }, [
    activeColor,
    activePath,
    grid,
    paths,
    level.pairs,
    isPairConnected,
    multiplier,
    lastConnectionTime,
    comboCount,
    movesTaken,
    movesRemaining,
    mode,
    updateSaveData,
    checkVictory
  ]);

  // Pointer released globally
  const handlePointerUpGlobal = useCallback(() => {
    if (activeColor && activePath.length > 0) {
      const pair = level.pairs.find((p) => p.color === activeColor);
      if (pair && isPairConnected(pair, activePath)) {
        // Already handled on endpoint touch
      } else {
        // Path left unfinished
        soundEngine.playPathCancel();
        setActiveColor(null);
        setActivePath([]);
      }
    }
  }, [activeColor, activePath, level.pairs, isPairConnected]);

  // Boosters Logic
  const handleUseBooster = useCallback((type: 'hint' | 'extraMoves' | 'colorClear' | 'undo' | 'reset') => {
    if (type === 'hint') {
      if (saveData.boosters.hint <= 0) return;
      soundEngine.playBooster();

      // Find first unconnected color pair
      const unsolvedPair = level.pairs.find((p) => {
        const pth = paths.get(p.color);
        return !pth || !isPairConnected(p, pth);
      });

      if (unsolvedPair) {
        // Generate shortest path between start and end using BFS
        const queue: { coord: Coordinate; path: Coordinate[] }[] = [
          { coord: unsolvedPair.start, path: [unsolvedPair.start] }
        ];
        const visited = new Set<string>();
        visited.add(`${unsolvedPair.start.r},${unsolvedPair.start.c}`);

        let foundPath: Coordinate[] | null = null;
        while (queue.length > 0) {
          const curr = queue.shift()!;
          if (curr.coord.r === unsolvedPair.end.r && curr.coord.c === unsolvedPair.end.c) {
            foundPath = curr.path;
            break;
          }

          const dirs = [
            { dr: -1, dc: 0 },
            { dr: 1, dc: 0 },
            { dr: 0, dc: -1 },
            { dr: 0, dc: 1 }
          ];
          for (const d of dirs) {
            const nr = curr.coord.r + d.dr;
            const nc = curr.coord.c + d.dc;
            const key = `${nr},${nc}`;
            if (
              nr >= 0 &&
              nr < level.rows &&
              nc >= 0 &&
              nc < level.cols &&
              !visited.has(key)
            ) {
              // Avoid other color endpoints
              const cell = grid[nr]?.[nc];
              if (!cell?.isEndpoint || cell?.color === unsolvedPair.color) {
                visited.add(key);
                queue.push({ coord: { r: nr, c: nc }, path: [...curr.path, { r: nr, c: nc }] });
              }
            }
          }
        }

        if (foundPath) {
          setHintPath(foundPath);
          setTimeout(() => setHintPath(null), 4000);
        }
      }

      updateSaveData((prev) => ({
        ...prev,
        boosters: { ...prev.boosters, hint: prev.boosters.hint - 1 }
      }));
    } else if (type === 'extraMoves') {
      if (saveData.boosters.extraMoves <= 0) return;
      soundEngine.playBooster();
      setMovesRemaining((prev) => prev + 5);
      updateSaveData((prev) => ({
        ...prev,
        boosters: { ...prev.boosters, extraMoves: prev.boosters.extraMoves - 1 }
      }));
    } else if (type === 'colorClear') {
      if (saveData.boosters.colorClear <= 0) return;
      // Auto solve one unsolved pair
      const unsolvedPair = level.pairs.find((p) => {
        const pth = paths.get(p.color);
        return !pth || !isPairConnected(p, pth);
      });

      if (unsolvedPair) {
        soundEngine.playBooster();
        // Simple direct river bridge
        const p1 = unsolvedPair.start;
        const p2 = unsolvedPair.end;
        const simplePath: Coordinate[] = [p1];

        let cr = p1.r;
        let cc = p1.c;
        while (cr !== p2.r) {
          cr += cr < p2.r ? 1 : -1;
          simplePath.push({ r: cr, c: cc });
        }
        while (cc !== p2.c) {
          cc += cc < p2.c ? 1 : -1;
          simplePath.push({ r: cr, c: cc });
        }

        const nextPaths = new Map(paths);
        nextPaths.set(unsolvedPair.color, simplePath);
        setPaths(nextPaths);

        updateSaveData((prev) => ({
          ...prev,
          boosters: { ...prev.boosters, colorClear: prev.boosters.colorClear - 1 }
        }));

        checkVictory(nextPaths, movesTaken);
      }
    } else if (type === 'undo') {
      if (pathHistory.length > 0 && saveData.boosters.undo > 0) {
        soundEngine.playPathCancel();
        const prevBoard = pathHistory[pathHistory.length - 1];
        setPathHistory((prev) => prev.slice(0, -1));
        setPaths(prevBoard);
        updateSaveData((prev) => ({
          ...prev,
          boosters: { ...prev.boosters, undo: Math.max(0, prev.boosters.undo - 1) }
        }));
      }
    } else if (type === 'reset') {
      soundEngine.playPathCancel();
      setPaths(new Map());
      setActiveColor(null);
      setActivePath([]);
      setHintPath(null);
    }
  }, [
    saveData.boosters,
    level,
    grid,
    paths,
    isPairConnected,
    pathHistory,
    movesTaken,
    updateSaveData,
    checkVictory
  ]);

  // Keyboard Shortcuts: Escape to Pause
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (screen === 'PLAYING') {
          soundEngine.playNodeSelect(0);
          setScreen('PAUSED');
        } else if (screen === 'PAUSED') {
          soundEngine.playNodeSelect(1);
          setScreen('PLAYING');
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [screen]);

  // Connected colors list for HUD
  const connectedColors: ColorId[] = [];
  level.pairs.forEach((pair) => {
    const p = paths.get(pair.color);
    if (p && isPairConnected(pair, p)) {
      connectedColors.push(pair.color);
    }
  });

  return (
    <main
      className="relative w-screen h-screen overflow-hidden flex flex-col items-center justify-center select-none"
      style={{
        background: activeTheme.bgGradient || '#060814'
      }}
    >
      {/* Active Playing View */}
      {screen === 'PLAYING' || screen === 'PAUSED' || screen === 'VICTORY' || screen === 'GAME_OVER' ? (
        <div className="relative w-full h-full flex flex-col items-center justify-center">
          {/* Main 60fps Game Canvas */}
          <GameCanvas
            level={level}
            grid={grid}
            paths={paths}
            activeColor={activeColor}
            activePath={activePath}
            theme={activeTheme}
            skinId={activeSkinId}
            colorblindMode={saveData.settings.colorblindMode}
            reducedMotion={saveData.settings.reducedMotion}
            hintPath={hintPath}
            onCellPointerDown={handleCellPointerDown}
            onCellPointerEnter={handleCellPointerEnter}
            onPointerUpGlobal={handlePointerUpGlobal}
          />

          {/* Low-Occlusion HUD Overlay */}
          <HUD
            level={level}
            mode={mode}
            movesRemaining={movesRemaining}
            score={score}
            multiplier={multiplier}
            comboCount={comboCount}
            timeLeft={timeLeft}
            connectedColors={connectedColors}
            theme={activeTheme}
            saveData={saveData}
            onPause={() => setScreen('PAUSED')}
            onToggleSound={() => {
              const next = !saveData.settings.sound;
              updateSaveData((p) => ({ ...p, settings: { ...p.settings, sound: next } }));
              soundEngine.setMuted(!next);
            }}
            onUseBooster={handleUseBooster}
            canUndo={pathHistory.length > 0 && saveData.boosters.undo > 0}
          />
        </div>
      ) : null}

      {/* Screen: Title Screen */}
      {screen === 'TITLE' && (
        <TitleScreen
          saveData={saveData}
          onStartGame={startGame}
          onOpenLevelSelect={() => setScreen('LEVEL_SELECT')}
          onOpenShop={() => setScreen('SHOP')}
          onOpenAchievements={() => setScreen('ACHIEVEMENTS')}
          onOpenDailyCalendar={() => setScreen('DAILY_CALENDAR')}
          onOpenHowToPlay={() => setScreen('HOW_TO_PLAY')}
          onOpenSettings={() => setScreen('SETTINGS')}
          onOpenDownloadApk={() => setIsDownloadApkOpen(true)}
        />
      )}

      {/* Screen Modals */}
      {screen === 'PAUSED' && (
        <PauseModal
          soundEnabled={saveData.settings.sound}
          musicEnabled={saveData.settings.music}
          colorblindMode={saveData.settings.colorblindMode}
          onResume={() => setScreen('PLAYING')}
          onRestart={() => initLevel(level, mode)}
          onToggleSound={() => {
            const next = !saveData.settings.sound;
            updateSaveData((p) => ({ ...p, settings: { ...p.settings, sound: next } }));
            soundEngine.setMuted(!next);
          }}
          onToggleMusic={() => {
            const next = !saveData.settings.music;
            updateSaveData((p) => ({ ...p, settings: { ...p.settings, music: next } }));
            soundEngine.setMusicMuted(!next);
          }}
          onToggleColorblind={() => {
            updateSaveData((p) => ({
              ...p,
              settings: { ...p.settings, colorblindMode: !p.settings.colorblindMode }
            }));
          }}
          onHome={() => {
            soundEngine.stopAmbientLoop();
            setScreen('TITLE');
          }}
        />
      )}

      {screen === 'VICTORY' && (
        <VictoryModal
          level={level}
          mode={mode}
          starsEarned={starsEarned}
          score={score}
          movesTaken={movesTaken}
          movesRemaining={movesRemaining}
          coinsEarned={coinsEarned}
          highestCombo={highestCombo}
          onNextLevel={() => {
            if (mode === 'classic') {
              const nextNum = currentLevelIndex + 1;
              if (nextNum <= 100) {
                startGame('classic', nextNum);
              } else {
                setScreen('LEVEL_SELECT');
              }
            } else if (mode === 'time_challenge') {
              const nextStage = currentLevelIndex + 1;
              setCurrentLevelIndex(nextStage);
              initLevel(getTimeChallengeLevel(nextStage), 'time_challenge');
            } else if (mode === 'endless') {
              const nextStage = currentLevelIndex + 1;
              setCurrentLevelIndex(nextStage);
              initLevel(getEndlessLevel(nextStage), 'endless');
            } else {
              setScreen('DAILY_CALENDAR');
            }
          }}
          onRetry={() => initLevel(level, mode)}
          onHome={() => {
            soundEngine.stopAmbientLoop();
            setScreen('TITLE');
          }}
        />
      )}

      {screen === 'GAME_OVER' && (
        <GameOverModal
          level={level}
          mode={mode}
          extraMovesCount={saveData.boosters.extraMoves}
          onUseExtraMoves={() => {
            setMovesRemaining((prev) => prev + 5);
            updateSaveData((prev) => ({
              ...prev,
              boosters: { ...prev.boosters, extraMoves: prev.boosters.extraMoves - 1 }
            }));
            setScreen('PLAYING');
          }}
          onRetry={() => initLevel(level, mode)}
          onHome={() => {
            soundEngine.stopAmbientLoop();
            setScreen('TITLE');
          }}
        />
      )}

      {screen === 'LEVEL_SELECT' && (
        <LevelSelectModal
          saveData={saveData}
          onSelectLevel={(num) => startGame('classic', num)}
          onClose={() => setScreen('TITLE')}
        />
      )}

      {screen === 'SHOP' && (
        <ShopModal
          saveData={saveData}
          onBuyTheme={(themeId, price) => {
            updateSaveData((prev) => ({
              ...prev,
              stats: { ...prev.stats, totalCoins: prev.stats.totalCoins - price },
              unlockedThemes: [...prev.unlockedThemes, themeId],
              activeThemeId: themeId
            }));
          }}
          onEquipTheme={(themeId) => {
            updateSaveData((prev) => ({ ...prev, activeThemeId: themeId }));
          }}
          onBuySkin={(skinId, price) => {
            updateSaveData((prev) => ({
              ...prev,
              stats: { ...prev.stats, totalCoins: prev.stats.totalCoins - price },
              unlockedSkins: [...prev.unlockedSkins, skinId],
              activeSkinId: skinId
            }));
          }}
          onEquipSkin={(skinId) => {
            updateSaveData((prev) => ({ ...prev, activeSkinId: skinId }));
          }}
          onBuyBooster={(bType, count, price) => {
            updateSaveData((prev) => ({
              ...prev,
              stats: { ...prev.stats, totalCoins: prev.stats.totalCoins - price },
              boosters: { ...prev.boosters, [bType]: prev.boosters[bType] + count }
            }));
          }}
          onClose={() => setScreen('TITLE')}
        />
      )}

      {screen === 'ACHIEVEMENTS' && (
        <AchievementsModal
          saveData={saveData}
          onClaimAchievement={(id, coins) => {
            updateSaveData((prev) => ({
              ...prev,
              stats: { ...prev.stats, totalCoins: prev.stats.totalCoins + coins },
              achievements: { ...prev.achievements, [id]: true }
            }));
          }}
          onClose={() => setScreen('TITLE')}
        />
      )}

      {screen === 'DAILY_CALENDAR' && (
        <DailyCalendarModal
          saveData={saveData}
          onPlayToday={() => startGame('daily')}
          onClose={() => setScreen('TITLE')}
        />
      )}

      {screen === 'HOW_TO_PLAY' && (
        <HowToPlayModal onClose={() => setScreen('TITLE')} />
      )}

      {screen === 'SETTINGS' && (
        <SettingsModal
          saveData={saveData}
          onUpdateSettings={(newSettings) => {
            updateSaveData((prev) => ({
              ...prev,
              settings: { ...prev.settings, ...newSettings }
            }));
          }}
          onResetProgress={() => {
            const fresh = resetSaveData();
            setSaveData(fresh);
          }}
          onClose={() => setScreen('TITLE')}
        />
      )}

      {isDownloadApkOpen && (
        <DownloadApkModal onClose={() => setIsDownloadApkOpen(false)} />
      )}
    </main>
  );
}
