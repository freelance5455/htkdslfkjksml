import { useCallback, useEffect, useRef, useState } from 'react';
import { GameTable } from './components/GameTable';
import { LobbyRoom } from './components/LobbyRoom';
import { RulesModal } from './components/RulesModal';
import { TitleScreen } from './components/TitleScreen';
import type {
  ActiveColor,
  AvatarId,
  ClientMessage,
  PublicRoomState,
  RoomSettings,
  ServerMessage,
} from './shared/unoTypes';
import { LocalOfflineGame } from './utils/localOfflineGame';
import { soundFx } from './utils/soundFx';

declare global {
  interface Window {
    __ARI_UNO_STANDALONE__?: boolean;
    __ARI_UNO_SERVER_URL__?: string;
  }
}

const SESSION_KEY = 'ari_uno_session';
const PROFILE_KEY = 'ari_uno_profile';

function getWsEndpoint(): string | null {
  if (window.location.protocol === 'file:') {
    const baked = window.__ARI_UNO_SERVER_URL__;
    if (baked && /^https?:\/\//i.test(baked)) {
      const wsOrigin = baked.replace(/^http/i, 'ws').replace(/\/$/, '');
      return `${wsOrigin}/ws`;
    }
    return null;
  }
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}/ws`;
}

export default function App() {
  const [roomState, setRoomState] = useState<PublicRoomState | null>(null);
  const [connected, setConnected] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [muted, setMuted] = useState(() => soundFx.isMuted());

  const wsRef = useRef<WebSocket | null>(null);
  const localGameRef = useRef<LocalOfflineGame | null>(null);
  const lastCueIdRef = useRef<string | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isStandaloneFile =
    Boolean(window.__ARI_UNO_STANDALONE__) || window.location.protocol === 'file:';

  const initialParams = (() => {
    const params = new URLSearchParams(window.location.search);
    const room = (params.get('room') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    let savedName = '';
    let savedAvatar: AvatarId = 'spade';
    try {
      const raw = localStorage.getItem(PROFILE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { name?: string; avatar?: AvatarId };
        if (parsed.name) savedName = parsed.name;
        if (parsed.avatar) savedAvatar = parsed.avatar;
      }
    } catch {
      // ignore storage errors
    }
    return { room, savedName, savedAvatar };
  })();

  const handleStateUpdate = useCallback((state: PublicRoomState, syncUrl: boolean) => {
    setRoomState(state);
    if (syncUrl && window.location.protocol !== 'file:') {
      try {
        const url = new URL(window.location.href);
        if (url.searchParams.get('room') !== state.code) {
          url.searchParams.set('room', state.code);
          window.history.replaceState({}, '', url.toString());
        }
      } catch {
        // ignore history error
      }
    }
    if (state.lastCue && state.lastCue.id !== lastCueIdRef.current) {
      lastCueIdRef.current = state.lastCue.id;
      soundFx.playCue(state.lastCue.cue);
    }
  }, []);

  const sendMessage = useCallback((msg: ClientMessage) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(msg));
    }
  }, []);

  useEffect(() => {
    let unmounted = false;
    const wsUrl = getWsEndpoint();
    if (!wsUrl) {
      return;
    }

    const connect = () => {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        if (unmounted) return;
        setConnected(true);
        setErrorMsg(null);

        try {
          const rawSession = sessionStorage.getItem(SESSION_KEY);
          if (rawSession) {
            const parsed = JSON.parse(rawSession) as { code?: string; playerId?: string };
            if (parsed.code && parsed.playerId) {
              ws.send(
                JSON.stringify({
                  type: 'reconnect_room',
                  code: parsed.code,
                  playerId: parsed.playerId,
                } satisfies ClientMessage)
              );
            }
          }
        } catch {
          // ignore
        }
      };

      ws.onmessage = (event) => {
        if (unmounted) return;
        let data: ServerMessage;
        try {
          data = JSON.parse(String(event.data)) as ServerMessage;
        } catch {
          return;
        }

        if (data.type === 'room_joined') {
          try {
            sessionStorage.setItem(
              SESSION_KEY,
              JSON.stringify({ code: data.code, playerId: data.playerId })
            );
          } catch {
            // ignore
          }
          setErrorMsg(null);
        } else if (data.type === 'state_sync') {
          handleStateUpdate(data.state, true);
        } else if (data.type === 'left_room') {
          setRoomState(null);
          try {
            sessionStorage.removeItem(SESSION_KEY);
          } catch {
            // ignore
          }
          if (window.location.protocol !== 'file:') {
            try {
              const url = new URL(window.location.href);
              url.searchParams.delete('room');
              window.history.replaceState({}, '', url.toString());
            } catch {
              // ignore
            }
          }
        } else if (data.type === 'error') {
          setErrorMsg(data.message);
        }
      };

      ws.onclose = () => {
        if (unmounted) return;
        setConnected(false);
        reconnectTimerRef.current = setTimeout(connect, 1800);
      };
    };

    connect();

    return () => {
      unmounted = true;
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      if (wsRef.current) wsRef.current.close();
      if (localGameRef.current) localGameRef.current.destroy();
    };
  }, [handleStateUpdate]);

  const saveProfile = (name: string, avatar: AvatarId) => {
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify({ name, avatar }));
    } catch {
      // ignore
    }
  };

  const handleCreateRoom = (name: string, avatar: AvatarId) => {
    saveProfile(name, avatar);
    setErrorMsg(null);
    sendMessage({ type: 'create_room', name, avatar });
  };

  const handleJoinRoom = (code: string, name: string, avatar: AvatarId) => {
    saveProfile(name, avatar);
    setErrorMsg(null);
    sendMessage({ type: 'join_room', code, name, avatar });
  };

  const handleStartOfflineMabar = (name: string, avatar: AvatarId) => {
    saveProfile(name, avatar);
    setErrorMsg(null);
    if (localGameRef.current) localGameRef.current.destroy();
    localGameRef.current = new LocalOfflineGame(name, avatar, 'mabar_lobby', (state) => {
      handleStateUpdate(state, false);
    });
  };

  const handlePlaySolo = (name: string, avatar: AvatarId) => {
    saveProfile(name, avatar);
    setErrorMsg(null);
    if (connected) {
      sendMessage({ type: 'create_room', name, avatar, soloWithBots: true });
    } else {
      if (localGameRef.current) localGameRef.current.destroy();
      localGameRef.current = new LocalOfflineGame(name, avatar, 'solo', (state) => {
        handleStateUpdate(state, false);
      });
    }
  };

  const handleLeave = () => {
    if (localGameRef.current) {
      localGameRef.current.destroy();
      localGameRef.current = null;
      setRoomState(null);
      return;
    }
    sendMessage({ type: 'leave_room' });
  };

  const handleToggleMute = () => {
    const next = soundFx.toggleMute();
    setMuted(next);
  };

  const isLocal = Boolean(localGameRef.current);

  return (
    <>
      {!roomState ? (
        <TitleScreen
          initialRoomCode={initialParams.room}
          initialName={initialParams.savedName}
          initialAvatar={initialParams.savedAvatar}
          muted={muted}
          connected={connected}
          isStandaloneFile={isStandaloneFile}
          errorMessage={errorMsg}
          onToggleMute={handleToggleMute}
          onOpenRules={() => setRulesOpen(true)}
          onCreateRoom={handleCreateRoom}
          onJoinRoom={handleJoinRoom}
          onStartOfflineMabar={handleStartOfflineMabar}
          onPlaySolo={handlePlaySolo}
        />
      ) : roomState.phase === 'LOBBY' ? (
        <LobbyRoom
          room={roomState}
          onAddBot={() =>
            isLocal ? localGameRef.current?.addBot() : sendMessage({ type: 'add_bot' })
          }
          onAddHuman={
            isLocal ? (name?: string) => localGameRef.current?.addHumanPlayer(name) : undefined
          }
          onRenamePlayer={
            isLocal
              ? (targetId: string, newName: string) =>
                  localGameRef.current?.renamePlayer(targetId, newName)
              : undefined
          }
          onRemovePlayer={(targetId) =>
            isLocal
              ? localGameRef.current?.removePlayer(targetId)
              : sendMessage({ type: 'remove_player', targetId })
          }
          onUpdateSettings={(settings: Partial<RoomSettings>) =>
            isLocal
              ? localGameRef.current?.updateSettings(settings)
              : sendMessage({ type: 'update_settings', settings })
          }
          onStartGame={() =>
            isLocal ? localGameRef.current?.startRound(true) : sendMessage({ type: 'start_game' })
          }
          onLeaveRoom={handleLeave}
        />
      ) : (
        <GameTable
          room={roomState}
          muted={muted}
          onToggleMute={handleToggleMute}
          onOpenRules={() => setRulesOpen(true)}
          onPlayCard={(cardId: string, chosenColor?: ActiveColor) =>
            isLocal
              ? localGameRef.current?.playCard(roomState.myId, cardId, chosenColor)
              : sendMessage({ type: 'play_card', cardId, chosenColor })
          }
          onChooseFlipColor={(chosenColor: ActiveColor) =>
            isLocal
              ? localGameRef.current?.chooseFlipColor(roomState.myId, chosenColor)
              : sendMessage({ type: 'choose_flip_color', chosenColor })
          }
          onDrawCard={() =>
            isLocal ? localGameRef.current?.drawForCurrent() : sendMessage({ type: 'draw_card' })
          }
          onPlayDrawnCard={(chosenColor?: ActiveColor) =>
            isLocal
              ? localGameRef.current?.playDrawnCard(chosenColor)
              : sendMessage({ type: 'play_drawn_card', chosenColor })
          }
          onPassAfterDraw={() =>
            isLocal
              ? localGameRef.current?.passAfterDraw()
              : sendMessage({ type: 'pass_after_draw' })
          }
          onCallUno={() =>
            isLocal ? localGameRef.current?.callUno() : sendMessage({ type: 'call_uno' })
          }
          onCatchUno={(targetId: string) =>
            isLocal
              ? localGameRef.current?.catchUno(targetId)
              : sendMessage({ type: 'catch_uno', targetId })
          }
          onSendEmote={(text: string) =>
            isLocal
              ? localGameRef.current?.sendEmote(text)
              : sendMessage({ type: 'send_emote', text })
          }
          onNextRound={() =>
            isLocal
              ? localGameRef.current?.startRound(false)
              : sendMessage({ type: 'next_round' })
          }
          onPlayAgain={() =>
            isLocal
              ? localGameRef.current?.startRound(true)
              : sendMessage({ type: 'play_again' })
          }
          onLeaveRoom={handleLeave}
        />
      )}

      <RulesModal open={rulesOpen} onClose={() => setRulesOpen(false)} />
    </>
  );
}
