import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  WeaponConfig,
  WeaponType,
  GraphicsSettings,
  CustomControlsSettings,
  GameResources,
  BaseState,
  PlayerState,
  GameState,
} from './types';
import {
  INITIAL_WEAPONS,
  DEFAULT_GRAPHICS_SETTINGS,
  DEFAULT_CONTROLS_SETTINGS,
} from './game/constants';
import { ZombieGameEngine } from './game/engine';
import { soundEngine } from './audio/soundEngine';
import { TopBar } from './components/TopBar';
import { VirtualControls } from './components/VirtualControls';
import { GraphicsPanel } from './components/GraphicsPanel';
import { ControlsCustomizer } from './components/ControlsCustomizer';
import { UpgradeShop } from './components/UpgradeShop';
import { GameOverModal } from './components/GameOverModal';
import { MainMenu } from './components/MainMenu';
import { LandscapeHelper } from './components/LandscapeHelper';

const STORAGE_KEY_GRAPHICS = 'zombie_game_graphics_v1';
const STORAGE_KEY_CONTROLS = 'zombie_game_controls_v1';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<ZombieGameEngine | null>(null);

  // Settings with LocalStorage persistence
  const [graphicsSettings, setGraphicsSettings] = useState<GraphicsSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_GRAPHICS);
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_GRAPHICS_SETTINGS;
  });

  const [controlsSettings, setControlsSettings] = useState<CustomControlsSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CONTROLS);
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_CONTROLS_SETTINGS;
  });

  const [isMuted, setIsMuted] = useState(false);

  // Modals & Screen States
  const [gameState, setGameState] = useState<GameState>('menu');
  const [isGraphicsOpen, setIsGraphicsOpen] = useState(false);
  const [isControlsOpen, setIsControlsOpen] = useState(false);
  const [isUpgradeShopOpen, setIsUpgradeShopOpen] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  // Game stats synced from engine
  const [wave, setWave] = useState(1);
  const [score, setScore] = useState(0);
  const [kills, setKills] = useState(0);
  const [zombiesRemaining, setZombiesRemaining] = useState(0);
  const [zombiesTotal, setZombiesTotal] = useState(0);
  const [playerHp, setPlayerHp] = useState(120);
  const [playerMaxHp, setPlayerMaxHp] = useState(120);
  const [baseHp, setBaseHp] = useState(800);
  const [baseMaxHp, setBaseMaxHp] = useState(800);
  const [currentWeapon, setCurrentWeapon] = useState<WeaponConfig>(INITIAL_WEAPONS.pistol);
  const [currentAmmo, setCurrentAmmo] = useState(12);
  const [maxAmmo, setMaxAmmo] = useState(12);
  const [isReloading, setIsReloading] = useState(false);
  const [grenades, setGrenades] = useState(2);
  const [dashCooldown, setDashCooldown] = useState(0);
  const [resources, setResources] = useState<GameResources>({
    wood: 60,
    metal: 30,
    coins: 150,
    ammo: 120,
  });

  // Save graphics settings
  const handleSaveGraphics = (newSettings: GraphicsSettings) => {
    setGraphicsSettings(newSettings);
    try {
      localStorage.setItem(STORAGE_KEY_GRAPHICS, JSON.stringify(newSettings));
    } catch {}
    if (engineRef.current) {
      engineRef.current.updateGraphicsSettings(newSettings);
    }
  };

  // Save custom controls
  const handleSaveControls = (newControls: CustomControlsSettings) => {
    setControlsSettings(newControls);
    try {
      localStorage.setItem(STORAGE_KEY_CONTROLS, JSON.stringify(newControls));
    } catch {}
  };

  const handleToggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    soundEngine.setMuted(nextMute);
  };

  // Resize canvas when container size changes
  const handleResize = useCallback(() => {
    if (!canvasRef.current || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    canvasRef.current.width = Math.floor(rect.width);
    canvasRef.current.height = Math.floor(rect.height);
  }, []);

  useEffect(() => {
    handleResize();
    const ro = new ResizeObserver(() => {
      handleResize();
    });
    if (containerRef.current) {
      ro.observe(containerRef.current);
    }
    return () => ro.disconnect();
  }, [handleResize]);

  // Start new game
  const startGame = () => {
    setGameState('playing');
    setIsPaused(false);

    if (canvasRef.current) {
      handleResize();

      const engine = new ZombieGameEngine(
        canvasRef.current,
        INITIAL_WEAPONS,
        graphicsSettings,
        {
          onGameOver: (stats) => {
            setKills(stats.kills);
            setScore(stats.score);
            setGameState('gameover');
          },
          onWaveComplete: (w) => {
            setWave(w);
            setIsUpgradeShopOpen(true);
          },
          onResourcesChange: (res) => {
            setResources(res);
          },
          onPlayerHpChange: (hp, max) => {
            setPlayerHp(hp);
            setPlayerMaxHp(max);
          },
          onBaseHpChange: (hp, max) => {
            setBaseHp(hp);
            setBaseMaxHp(max);
          },
          onWeaponChange: (w, ammo, maxA, reloading) => {
            setCurrentWeapon(w);
            setCurrentAmmo(ammo);
            setMaxAmmo(maxA);
            setIsReloading(reloading);
          },
        }
      );

      engineRef.current = engine;
      engine.start();
      engine.startWave(1);

      // Sync initial stats
      setPlayerHp(engine.player.health);
      setPlayerMaxHp(engine.player.maxHealth);
      setBaseHp(engine.base.health);
      setBaseMaxHp(engine.base.maxHealth);
      setResources({ ...engine.resources });
      setCurrentWeapon(engine.weapons.pistol);
      setCurrentAmmo(engine.weapons.pistol.magazineSize);
      setMaxAmmo(engine.weapons.pistol.magazineSize);
    }
  };

  // Sync state loop for HUD
  useEffect(() => {
    if (gameState !== 'playing') return;

    const interval = setInterval(() => {
      const eng = engineRef.current;
      if (eng) {
        setWave(eng.wave);
        setScore(eng.score);
        setKills(eng.kills);
        setZombiesRemaining(eng.zombies.length + eng.waveZombiesRemaining);
        setZombiesTotal(eng.waveZombiesTotal);
        setPlayerHp(eng.player.health);
        setBaseHp(eng.base.health);
        setGrenades(eng.player.grenades);
        setDashCooldown(eng.player.dashCooldown);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [gameState]);

  // Pause / Resume
  const togglePause = () => {
    if (!engineRef.current) return;
    if (isPaused) {
      engineRef.current.resume();
      setIsPaused(false);
    } else {
      engineRef.current.pause();
      setIsPaused(true);
    }
  };

  // Upgrades
  const handleUpgradeWeapon = (
    weaponId: WeaponType,
    stat: 'damage' | 'fireRate' | 'mag' | 'reload'
  ) => {
    if (!engineRef.current) return;
    const w = engineRef.current.weapons[weaponId];
    if (!w) return;

    let cost = { coins: 0, metal: 0, wood: 0 };
    if (stat === 'damage') {
      cost = { coins: 40 + w.damageLevel * 35, metal: 10 + w.damageLevel * 8, wood: 8 + w.damageLevel * 5 };
      if (
        engineRef.current.resources.coins >= cost.coins &&
        engineRef.current.resources.metal >= cost.metal &&
        engineRef.current.resources.wood >= cost.wood
      ) {
        engineRef.current.resources.coins -= cost.coins;
        engineRef.current.resources.metal -= cost.metal;
        engineRef.current.resources.wood -= cost.wood;
        w.damageLevel++;
        w.damage = Math.round(w.damage * 1.25);
        soundEngine.playRepair();
      }
    } else if (stat === 'fireRate') {
      cost = { coins: 40 + w.fireRateLevel * 35, metal: 10 + w.fireRateLevel * 8, wood: 8 + w.fireRateLevel * 5 };
      if (
        engineRef.current.resources.coins >= cost.coins &&
        engineRef.current.resources.metal >= cost.metal &&
        engineRef.current.resources.wood >= cost.wood
      ) {
        engineRef.current.resources.coins -= cost.coins;
        engineRef.current.resources.metal -= cost.metal;
        engineRef.current.resources.wood -= cost.wood;
        w.fireRateLevel++;
        w.fireRate = Number((w.fireRate * 1.2).toFixed(1));
        soundEngine.playRepair();
      }
    } else if (stat === 'mag') {
      cost = { coins: 40 + w.magLevel * 35, metal: 10 + w.magLevel * 8, wood: 8 + w.magLevel * 5 };
      if (
        engineRef.current.resources.coins >= cost.coins &&
        engineRef.current.resources.metal >= cost.metal &&
        engineRef.current.resources.wood >= cost.wood
      ) {
        engineRef.current.resources.coins -= cost.coins;
        engineRef.current.resources.metal -= cost.metal;
        engineRef.current.resources.wood -= cost.wood;
        w.magLevel++;
        w.magazineSize = Math.round(w.magazineSize + Math.max(3, w.magazineSize * 0.25));
        soundEngine.playRepair();
      }
    } else if (stat === 'reload') {
      cost = { coins: 40 + w.reloadLevel * 35, metal: 10 + w.reloadLevel * 8, wood: 8 + w.reloadLevel * 5 };
      if (
        engineRef.current.resources.coins >= cost.coins &&
        engineRef.current.resources.metal >= cost.metal &&
        engineRef.current.resources.wood >= cost.wood
      ) {
        engineRef.current.resources.coins -= cost.coins;
        engineRef.current.resources.metal -= cost.metal;
        engineRef.current.resources.wood -= cost.wood;
        w.reloadLevel++;
        w.reloadTime = Number(Math.max(0.6, w.reloadTime * 0.85).toFixed(1));
        soundEngine.playRepair();
      }
    }

    setResources({ ...engineRef.current.resources });
    if (engineRef.current.player.currentWeapon === weaponId) {
      setCurrentWeapon({ ...w });
    }
  };

  const handleUnlockWeapon = (weaponId: WeaponType) => {
    if (!engineRef.current) return;
    const w = engineRef.current.weapons[weaponId];
    if (!w || w.unlocked) return;

    if (engineRef.current.resources.coins >= w.unlockCostCoins) {
      engineRef.current.resources.coins -= w.unlockCostCoins;
      w.unlocked = true;
      soundEngine.playPickup();
      setResources({ ...engineRef.current.resources });
      engineRef.current.switchWeapon(weaponId);
    }
  };

  const handleUpgradeBase = (type: 'walls' | 'baseCore' | 'repairEfficiency') => {
    if (!engineRef.current) return;
    const res = engineRef.current.resources;

    if (type === 'walls' && res.coins >= 80 && res.metal >= 25 && res.wood >= 35) {
      res.coins -= 80;
      res.metal -= 25;
      res.wood -= 35;
      engineRef.current.walls.forEach((w) => {
        w.maxHealth += 200;
        w.health += 200;
      });
      soundEngine.playRepair();
    } else if (type === 'baseCore' && res.coins >= 120 && res.metal >= 40 && res.wood >= 20) {
      res.coins -= 120;
      res.metal -= 40;
      res.wood -= 20;
      engineRef.current.base.maxHealth += 300;
      engineRef.current.base.health += 300;
      engineRef.current.base.defenseLevel++;
      setBaseHp(engineRef.current.base.health);
      setBaseMaxHp(engineRef.current.base.maxHealth);
      soundEngine.playRepair();
    } else if (type === 'repairEfficiency' && res.coins >= 70 && res.metal >= 20 && res.wood >= 30) {
      res.coins -= 70;
      res.metal -= 20;
      res.wood -= 30;
      engineRef.current.base.repairEfficiencyLevel++;
      soundEngine.playRepair();
    }
    setResources({ ...res });
  };

  const handleBuySupply = (type: 'ammo' | 'grenade' | 'heal') => {
    if (!engineRef.current) return;
    const res = engineRef.current.resources;

    if (type === 'ammo' && res.coins >= 35) {
      res.coins -= 35;
      res.ammo += 60;
      soundEngine.playPickup();
    } else if (type === 'grenade' && res.coins >= 45) {
      res.coins -= 45;
      engineRef.current.player.grenades += 2;
      setGrenades(engineRef.current.player.grenades);
      soundEngine.playPickup();
    } else if (type === 'heal' && res.coins >= 50) {
      res.coins -= 50;
      engineRef.current.player.health = engineRef.current.player.maxHealth;
      setPlayerHp(engineRef.current.player.health);
      soundEngine.playPickup();
    }
    setResources({ ...res });
  };

  const handleStartNextWave = () => {
    setIsUpgradeShopOpen(false);
    if (engineRef.current) {
      engineRef.current.startWave(wave + 1);
    }
  };

  // Mouse aim and shoot for desktop testing
  const handlePointerMoveCanvas = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (gameState !== 'playing' || !engineRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const worldX = screenX + engineRef.current.camera.x;
    const worldY = screenY + engineRef.current.camera.y;

    if (!graphicsSettings.autoAim) {
      const angle = Math.atan2(
        worldY - engineRef.current.player.y,
        worldX - engineRef.current.player.x
      );
      engineRef.current.aimAngle = angle;
    }
  };

  return (
    <div
      ref={containerRef}
      id="game-viewport"
      className="relative w-full h-full overflow-hidden bg-zinc-950 select-none touch-none"
    >
      {/* 1. Main Menu Screen */}
      {gameState === 'menu' && (
        <MainMenu
          onStartGame={startGame}
          onOpenGraphics={() => setIsGraphicsOpen(true)}
          onOpenControls={() => setIsControlsOpen(true)}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* 2. Gameplay Canvas */}
      <canvas
        ref={canvasRef}
        id="game-canvas"
        onPointerMove={handlePointerMoveCanvas}
        onPointerDown={(e) => {
          // Allow desktop click to shoot if not clicking on HUD buttons
          if (e.pointerType === 'mouse' && engineRef.current) {
            engineRef.current.isFiring = true;
          }
        }}
        onPointerUp={(e) => {
          if (e.pointerType === 'mouse' && engineRef.current) {
            engineRef.current.isFiring = false;
          }
        }}
        className={`w-full h-full block cursor-crosshair ${
          gameState === 'menu' ? 'hidden' : 'block'
        }`}
      />

      {/* 3. Top HUD Bar */}
      {gameState === 'playing' && (
        <TopBar
          wave={wave}
          score={score}
          zombiesRemaining={zombiesRemaining}
          zombiesTotal={zombiesTotal}
          playerHp={playerHp}
          playerMaxHp={playerMaxHp}
          baseHp={baseHp}
          baseMaxHp={baseMaxHp}
          resources={resources}
          currentWeapon={currentWeapon}
          currentAmmo={currentAmmo}
          isPaused={isPaused}
          onTogglePause={togglePause}
          onOpenGraphics={() => setIsGraphicsOpen(true)}
          onOpenControlsCustomizer={() => setIsControlsOpen(true)}
          onOpenUpgradeShop={() => setIsUpgradeShopOpen(true)}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* 4. On-Screen Virtual Controls for Mobile & Touch */}
      {gameState === 'playing' && !isPaused && (
        <VirtualControls
          settings={controlsSettings}
          currentWeapon={currentWeapon}
          currentAmmo={currentAmmo}
          maxAmmo={maxAmmo}
          isReloading={isReloading}
          grenades={grenades}
          dashCooldown={dashCooldown}
          wood={resources.wood}
          metal={resources.metal}
          onMove={(x, y) => {
            if (engineRef.current) {
              engineRef.current.moveDir = { x, y };
            }
          }}
          onAim={(angle) => {
            if (engineRef.current) {
              engineRef.current.aimAngle = angle;
            }
          }}
          onFireStart={() => {
            if (engineRef.current) {
              engineRef.current.isFiring = true;
            }
          }}
          onFireEnd={() => {
            if (engineRef.current) {
              engineRef.current.isFiring = false;
            }
          }}
          onReload={() => {
            if (engineRef.current) {
              engineRef.current.reload();
            }
          }}
          onRepair={() => {
            if (engineRef.current) {
              engineRef.current.repairBaseOrWall();
            }
          }}
          onSwitchWeapon={() => {
            if (engineRef.current) {
              engineRef.current.switchWeapon();
            }
          }}
          onGrenade={() => {
            if (engineRef.current) {
              engineRef.current.throwGrenade();
            }
          }}
          onDash={() => {
            if (engineRef.current) {
              engineRef.current.dash();
            }
          }}
          onPlaceTurret={() => {
            if (engineRef.current) {
              engineRef.current.placeTurret();
            }
          }}
        />
      )}

      {/* 5. Graphics Panel Modal */}
      <GraphicsPanel
        isOpen={isGraphicsOpen}
        onClose={() => setIsGraphicsOpen(false)}
        settings={graphicsSettings}
        onSaveSettings={handleSaveGraphics}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* 6. Custom Controls (HUD Editor) Modal */}
      <ControlsCustomizer
        isOpen={isControlsOpen}
        onClose={() => setIsControlsOpen(false)}
        settings={controlsSettings}
        onSaveSettings={handleSaveControls}
      />

      {/* 7. Upgrade Shop Modal (Qurollar & Baza) */}
      <UpgradeShop
        isOpen={isUpgradeShopOpen}
        wave={wave}
        resources={resources}
        weapons={engineRef.current?.weapons || INITIAL_WEAPONS}
        base={engineRef.current?.base || { x: 0, y: 0, radius: 75, health: 800, maxHealth: 800, defenseLevel: 1, repairEfficiencyLevel: 1 }}
        player={engineRef.current?.player || { x: 0, y: 0, vx: 0, vy: 0, angle: 0, health: 120, maxHealth: 120, speed: 210, speedLevel: 1, currentWeapon: 'pistol', currentAmmo: 12, isReloading: false, reloadProgress: 0, grenades: 2, dashCooldown: 0, lastDashTime: 0 }}
        onUpgradeWeapon={handleUpgradeWeapon}
        onUnlockWeapon={handleUnlockWeapon}
        onUpgradeBase={handleUpgradeBase}
        onBuySupply={handleBuySupply}
        onStartNextWave={handleStartNextWave}
      />

      {/* 8. Game Over Modal */}
      <GameOverModal
        isOpen={gameState === 'gameover'}
        wave={wave}
        kills={kills}
        score={score}
        onRestart={startGame}
        onMainMenu={() => setGameState('menu')}
      />

      {/* 9. Landscape Phone Orientation Helper */}
      <LandscapeHelper onDismiss={() => {}} />
    </div>
  );
}
