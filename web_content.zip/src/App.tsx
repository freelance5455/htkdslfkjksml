import { useState } from "react";
import { Confetti, FloatingHearts } from "./components/Effects";
import {
  DontTouchScreen,
  FinalScreen,
  IntroScreen,
  QuizScreen,
  ReactionScreen,
  ScareScreen,
  SecretScreen,
  StartScreen,
} from "./components/Screens";

type Page =
  | "start"
  | "warning"
  | "scare"
  | "intro"
  | "quiz"
  | "reaction"
  | "secret"
  | "final";

export default function App() {
  const [page, setPage] = useState<Page>("start");
  const [selected, setSelected] = useState<string[]>([]);

  const handleTouch = () => {
    // Little haptic jump-scare on phones that support it.
    try {
      navigator.vibrate?.([120, 60, 260]);
    } catch {
      /* vibration not supported — ignore */
    }
    setPage("scare");
  };

  const handleQuizDone = (answers: string[]) => {
    setSelected(answers);
    setPage("reaction");
  };

  const handleReplay = () => {
    setSelected([]);
    setPage("start");
  };

  return (
    <div className="relative min-h-dvh overflow-x-hidden bg-[linear-gradient(to_bottom,#09030D,#210B29,#09030D)] bg-fixed font-sans text-white">
      <FloatingHearts />
      {page === "final" && <Confetti />}

      <main className="relative z-10 mx-auto w-full max-w-md">
        {page === "start" && <StartScreen onStart={() => setPage("warning")} />}
        {page === "warning" && <DontTouchScreen onTouch={handleTouch} />}
        {page === "scare" && <ScareScreen onDone={() => setPage("intro")} />}
        {page === "intro" && <IntroScreen onNext={() => setPage("quiz")} />}
        {page === "quiz" && <QuizScreen onDone={handleQuizDone} />}
        {page === "reaction" && (
          <ReactionScreen answers={selected} onNext={() => setPage("secret")} />
        )}
        {page === "secret" && <SecretScreen onNext={() => setPage("final")} />}
        {page === "final" && <FinalScreen onReplay={handleReplay} />}
      </main>
    </div>
  );
}
