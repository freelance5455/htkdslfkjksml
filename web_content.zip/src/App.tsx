import { useState } from 'react';
import GameView from './components/GameView';
import { MainMenu, PlayMenu, Armory, CodesScreen, SettingsScreen, Results } from './components/Menus';
import { Ico } from './components/Icons';
import type { GameConfig, MatchResult } from './game/Engine';
import { setSave } from './game/store';
import { audio } from './game/audio';

type Screen = 'main' | 'play' | 'armory' | 'codes' | 'settings' | 'game' | 'results';

async function goFullscreenLandscape() {
  try {
    const el = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => Promise<void> };
    if (!document.fullscreenElement) {
      if (el.requestFullscreen) await el.requestFullscreen({ navigationUI: 'hide' } as FullscreenOptions);
      else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
    }
    const so = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
    if (so && so.lock) await so.lock('landscape').catch(() => {});
  } catch { /* not supported */ }
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('main');
  const [cfg, setCfg] = useState<GameConfig | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [gameKey, setGameKey] = useState(0);

  const start = (c: GameConfig) => {
    audio.init();
    if ('ontouchstart' in window) goFullscreenLandscape();
    setCfg(c); setGameKey(k => k + 1); setScreen('game');
  };

  const onEnd = (r: MatchResult | null) => {
    if (!r) { setScreen('main'); return; }
    setSave(s => ({
      ...s,
      coins: s.mods.code1 ? Math.max(s.coins, 999999) : s.coins + r.coins,
      xp: s.xp + r.xp, kills: s.kills + r.kills, deaths: s.deaths + r.deaths, headshots: s.headshots + r.hs,
      matches: s.matches + 1, wins: s.wins + (r.win ? 1 : 0),
    }));
    setResult(r); setScreen('results');
  };

  return (
    <div className="fixed inset-0 bg-black text-white font-fa" dir="rtl">
      {screen === 'main' && <MainMenu go={(s) => setScreen(s as Screen)} />}
      {screen === 'play' && <PlayMenu onBack={() => setScreen('main')} onStart={start} />}
      {screen === 'armory' && <Armory onBack={() => setScreen('main')} />}
      {screen === 'codes' && <CodesScreen onBack={() => setScreen('main')} />}
      {screen === 'settings' && <SettingsScreen onBack={() => setScreen('main')} />}
      {screen === 'game' && cfg && <GameView key={gameKey} cfg={cfg} onEnd={onEnd} />}
      {screen === 'results' && result && <Results r={result} onAgain={() => cfg && start(cfg)} onMenu={() => setScreen('main')} />}

      {/* portrait warning */}
      <div className="portrait-only fixed inset-0 z-[100] bg-black/95 flex-col items-center justify-center text-center p-6">
        <div className="w-24 h-24 text-amber-400 rotate-hint">{Ico.rotate()}</div>
        <div className="text-2xl font-black text-amber-400 mt-6">گوشی را افقی کنید</div>
        <div className="text-sm text-white/70 mt-2 leading-7">این بازی برای حالت افقی (Landscape) طراحی شده است.<br />برای بهترین تجربه، قفل چرخش صفحه را خاموش کنید.</div>
        <button onClick={goFullscreenLandscape} className="btn-mil btn-gold mt-6 px-6 py-3 rounded-lg">تمام صفحه و چرخش خودکار</button>
      </div>
    </div>
  );
}
