import { useCallback, useEffect, useRef, useState } from "react";
import { GameEngine } from "./game/engine";
import { AETHER, INFERNO, type ArenaId, type HudState, type Quality } from "./game/types";
import { Hud } from "./components/Hud";
import { MainMenu } from "./components/MainMenu";
import { GuideModal, NotesModal, PauseOverlay, ResultOverlay, SettingsModal } from "./components/Overlays";

type Screen = "menu" | "game";
type Overlay = null | "guide" | "settings" | "notes" | "pause" | "result";

const initialHud: HudState = {
  phase: "menu",
  round: 1,
  timer: 60,
  message: "",
  sub: "",
  messageKey: 0,
  winner: null,
  score: [0, 0],
  fps: 60,
  fighters: [
    {
      name: AETHER.name,
      epithet: AETHER.epithet,
      health: 100,
      maxHealth: 100,
      energy: 0,
      rounds: 0,
      accent: AETHER.palette.glowCss,
      cooldowns: { light: 0, heavy: 0, dodge: 0, special: 0 },
      blocking: false,
      state: "idle",
    },
    {
      name: INFERNO.name,
      epithet: INFERNO.epithet,
      health: 100,
      maxHealth: 100,
      energy: 0,
      rounds: 0,
      accent: INFERNO.palette.glowCss,
      cooldowns: { light: 0, heavy: 0, dodge: 0, special: 0 },
      blocking: false,
      state: "idle",
    },
  ],
};

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const screenRef = useRef<Screen>("menu");

  const [screen, setScreen] = useState<Screen>("menu");
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [hud, setHud] = useState<HudState>(initialHud);
  const [quality, setQuality] = useState<Quality>("medium");
  const [arena, setArena] = useState<ArenaId>("olympus");
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [error, setError] = useState<string | null>(null);
  const pausedRef = useRef(false);

  const updateScreen = useCallback((s: Screen) => {
    screenRef.current = s;
    setScreen(s);
  }, []);

  // create the engine once; the canvas is created imperatively so a remount
  // (React StrictMode) always gets a fresh WebGL context.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const canvas = document.createElement("canvas");
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.display = "block";
    canvas.style.touchAction = "none";
    canvas.setAttribute("aria-label", "Gods of War 3D arena");
    container.appendChild(canvas);

    let engine: GameEngine | null = null;
    try {
      engine = new GameEngine({
        canvas,
        quality,
        arena,
        muted,
        volume,
        onHud: (h) => {
          if (screenRef.current === "game") setHud(h);
        },
        onError: (m) => setError(m),
        onAutoPause: () => {
          pausedRef.current = true;
          setOverlay("pause");
        },
      });
      engineRef.current = engine;
    } catch (e) {
      setError(e instanceof Error ? e.message : "The 3D renderer could not start on this device.");
    }

    const onContextLost = (ev: Event) => {
      ev.preventDefault();
      setError("The graphics context was lost. Reload the page to restart the arena.");
    };
    canvas.addEventListener("webglcontextlost", onContextLost);

    return () => {
      canvas.removeEventListener("webglcontextlost", onContextLost);
      engine?.dispose();
      engineRef.current = null;
      canvas.remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    engineRef.current?.setQuality(quality);
  }, [quality]);

  useEffect(() => {
    engineRef.current?.setArena(arena);
  }, [arena]);

  useEffect(() => {
    engineRef.current?.setMuted(muted);
  }, [muted]);

  useEffect(() => {
    engineRef.current?.setVolume(volume);
  }, [volume]);

  // auto-open the result screen when the match ends
  useEffect(() => {
    if (hud.phase === "matchOver" && screen === "game") setOverlay("result");
  }, [hud.phase, screen]);

  // escape pauses / resumes / closes the top panel
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Escape") return;
      if (screenRef.current !== "game") return;
      setOverlay((cur) => {
        if (cur === "pause") {
          pausedRef.current = false;
          engineRef.current?.setPaused(false);
          return null;
        }
        if (cur === "settings") return pausedRef.current ? "pause" : null;
        if (cur === "guide" || cur === "notes") return null;
        if (cur === "result") return cur;
        pausedRef.current = true;
        engineRef.current?.setPaused(true);
        return "pause";
      });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const start = () => {
    pausedRef.current = false;
    screenRef.current = "game";
    setScreen("game");
    setOverlay(null);
    engineRef.current?.startMatch();
  };

  const pause = () => {
    pausedRef.current = true;
    engineRef.current?.setPaused(true);
    setOverlay("pause");
  };

  const resume = () => {
    pausedRef.current = false;
    engineRef.current?.setPaused(false);
    setOverlay(null);
  };

  const restart = () => {
    pausedRef.current = false;
    engineRef.current?.setPaused(false);
    engineRef.current?.startMatch();
    setOverlay(null);
  };

  const quit = () => {
    pausedRef.current = false;
    engineRef.current?.setPaused(false);
    engineRef.current?.toMenu();
    updateScreen("menu");
    setOverlay(null);
  };

  const openSettings = () => {
    setOverlay("settings");
  };

  const closeSettings = () => {
    setOverlay(pausedRef.current ? "pause" : null);
  };

  const rematch = () => {
    engineRef.current?.rematch();
    setOverlay(null);
  };

  const toggleMute = () => setMuted((m) => !m);

  const controlsEnabled = hud.phase === "fight" && overlay === null;

  return (
    <div
      className="relative h-[100dvh] w-full select-none overflow-hidden bg-obsidian text-white"
      onContextMenu={(e) => e.preventDefault()}
    >
      <div ref={containerRef} className="absolute inset-0 z-0" />

      {/* cinematic overlays */}
      <div className="pointer-events-none absolute inset-0 z-10 vignette" />
      <div className="pointer-events-none absolute inset-0 z-10 opacity-[0.07] scanlines" />

      {screen === "game" && (
        <Hud
          hud={hud}
          muted={muted}
          controlsEnabled={controlsEnabled}
          onPause={pause}
          onToggleMute={toggleMute}
          onMove={(p, x, y) => engineRef.current?.setMove(p, x, y)}
          onPress={(p, a) => engineRef.current?.press(p, a)}
          onBlock={(p, b) => engineRef.current?.setBlock(p, b)}
        />
      )}

      {screen === "menu" && (
        <MainMenu
          arena={arena}
          quality={quality}
          muted={muted}
          volume={volume}
          onArena={setArena}
          onQuality={setQuality}
          onToggleMute={toggleMute}
          onVolume={setVolume}
          onStart={start}
          onGuide={() => setOverlay("guide")}
          onSettings={openSettings}
          onNotes={() => setOverlay("notes")}
        />
      )}

      {overlay === "guide" && <GuideModal onClose={() => setOverlay(null)} />}
      {overlay === "settings" && (
        <SettingsModal
          quality={quality}
          arena={arena}
          muted={muted}
          volume={volume}
          onQuality={setQuality}
          onArena={setArena}
          onToggleMute={toggleMute}
          onVolume={setVolume}
          onClose={closeSettings}
        />
      )}
      {overlay === "notes" && <NotesModal onClose={() => setOverlay(null)} />}
      {overlay === "pause" && (
        <PauseOverlay
          hud={hud}
          muted={muted}
          onResume={resume}
          onRestart={restart}
          onSettings={openSettings}
          onToggleMute={toggleMute}
          onQuit={quit}
        />
      )}
      {overlay === "result" && <ResultOverlay hud={hud} onRematch={rematch} onMenu={quit} />}

      {error && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-obsidian p-4">
          <div className="panel panel-notch max-w-md p-5 text-center">
            <div className="font-display gold-text text-xl font-black tracking-[0.14em]">ARENA UNAVAILABLE</div>
            <p className="mt-2 text-[11px] leading-relaxed text-white/60">{error}</p>
            <p className="mt-2 text-[10px] leading-relaxed text-white/40">
              This game needs WebGL. Try Chrome or Firefox with hardware acceleration enabled, close other 3D apps,
              and reload. On low-end devices use the LOW graphics preset.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="btn-gold mt-3 rounded-sm px-4 py-2 text-[10px] font-black tracking-[0.16em]"
            >
              RELOAD ARENA
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
