/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { BottomDock } from './components/BottomDock.tsx';
import { ChatTab } from './components/ChatTab.tsx';
import { MusicTab } from './components/MusicTab.tsx';
import { VideoTab } from './components/VideoTab.tsx';
import { PhotoTab } from './components/PhotoTab.tsx';
import { SavedLibraryModal } from './components/SavedLibraryModal.tsx';
import { AndroidInstallModal } from './components/AndroidInstallModal.tsx';
import { ActiveTab, ChatMessage, SavedItem } from './types.ts';
import { Sparkles, Wifi, WifiOff } from 'lucide-react';
import { usePWAInstall } from './utils/usePWAInstall.ts';
import { downloadAppZipPackage } from './utils/exportAppZip.ts';

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'welcome-msg',
    role: 'model',
    text: 'Muli bwanji! I am Handsome AI, your charismatic personal creative intelligence. How can I assist you today with answers, Chichewa gospel praise, Amapiano tracks, cinematic video storyboards, or face-safe photo retouching?',
    timestamp: Date.now(),
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('handsome_chat_history');
      return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
    } catch {
      return INITIAL_MESSAGES;
    }
  });
  const [isThinking, setIsThinking] = useState(false);

  const [savedItems, setSavedItems] = useState<SavedItem[]>(() => {
    try {
      const saved = localStorage.getItem('handsome_saved_vault');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isFramed, setIsFramed] = useState(false);
  const [backendOnline, setBackendOnline] = useState(true);

  const { isInstallable, isInstalled, install } = usePWAInstall();

  // Check backend health
  useEffect(() => {
    const checkHealth = async () => {
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          setBackendOnline(true);
        } else {
          setBackendOnline(false);
        }
      } catch {
        setBackendOnline(false);
      }
    };
    checkHealth();
  }, []);

  // Save chat to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('handsome_chat_history', JSON.stringify(messages));
    } catch {
      // ignore
    }
  }, [messages]);

  // Save items to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('handsome_saved_vault', JSON.stringify(savedItems));
    } catch {
      // ignore
    }
  }, [savedItems]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsThinking(true);

    try {
      // Prepare history
      const historyPayload = messages.slice(-10).map((m) => ({
        role: m.role === 'user' ? 'user' : 'model',
        text: m.text,
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: historyPayload }),
      });

      const data = await res.json();

      if (data.reply) {
        const botMsg: ChatMessage = {
          id: `bot-${Date.now()}`,
          role: 'model',
          text: data.reply,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        const errorMsg: ChatMessage = {
          id: `bot-err-${Date.now()}`,
          role: 'model',
          text: `⚠️ ${data.error || 'Handsome AI could not process this request right now.'}`,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, errorMsg]);
      }
    } catch {
      const netErrorMsg: ChatMessage = {
        id: `bot-err-${Date.now()}`,
        role: 'model',
        text: '⚠️ Network error: Could not reach the server. Please verify your connection.',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, netErrorMsg]);
    } finally {
      setIsThinking(false);
    }
  };

  const handleClearChat = () => {
    setMessages(INITIAL_MESSAGES);
    showToast('Chat history cleared');
  };

  const handleSaveItem = (
    type: 'music' | 'video' | 'photo',
    title: string,
    subtitle: string,
    content: string
  ) => {
    const newItem: SavedItem = {
      id: `item-${Date.now()}`,
      type,
      title,
      subtitle,
      content,
      timestamp: Date.now(),
    };
    setSavedItems((prev) => [newItem, ...prev]);
  };

  const handleDeleteSavedItem = (id: string) => {
    setSavedItems((prev) => prev.filter((item) => item.id !== id));
    showToast('Item deleted from vault');
  };

  return (
    <div className="min-h-screen bg-[#0a0316] flex flex-col items-center justify-center relative font-sans text-white">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-gradient-to-r from-[#fae48c] to-[#d4af37] text-[#120422] font-bold text-xs shadow-[0_4px_20px_rgba(212,175,55,0.4)] flex items-center gap-2 animate-in fade-in slide-in-from-top-4 duration-200">
          <Sparkles className="w-3.5 h-3.5 fill-current" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container: Full screen on mobile, optional phone frame on desktop */}
      <div
        className={`w-full flex flex-col transition-all duration-300 relative bg-[#0e051d] ${
          isFramed
            ? 'max-w-[420px] h-[92vh] max-h-[880px] rounded-[36px] border-[5px] border-[#2c134f] shadow-[0_10px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(212,175,55,0.2)] overflow-hidden my-auto'
            : 'h-dvh max-w-4xl mx-auto'
        }`}
      >
        {/* Simulated Android Status Bar in framed mode */}
        {isFramed && (
          <div className="shrink-0 h-6 bg-[#140628] flex items-center justify-between px-5 text-[10px] text-[#bca5d4] border-b border-[#d4af37]/10 select-none">
            <span className="font-semibold tracking-wider">09:41</span>
            <div className="flex items-center gap-2">
              <span>5G</span>
              {backendOnline ? (
                <Wifi className="w-3 h-3 text-emerald-400" />
              ) : (
                <WifiOff className="w-3 h-3 text-rose-400" />
              )}
              <div className="w-4 h-2 border border-[#bca5d4] rounded-xs p-0.5 flex items-center">
                <div className="h-full w-full bg-[#fae48c] rounded-xxs" />
              </div>
            </div>
          </div>
        )}

        {/* Top App Bar */}
        <Navbar
          savedCount={savedItems.length}
          onOpenSaved={() => setIsSavedModalOpen(true)}
          onOpenInstall={() => setIsInstallModalOpen(true)}
          isFramed={isFramed}
          onToggleFrame={() => setIsFramed(!isFramed)}
          backendOnline={backendOnline}
          isInstallable={isInstallable}
        />

        {/* Content Viewports */}
        <main className="flex-1 overflow-y-auto relative flex flex-col">
          {activeTab === 'chat' && (
            <ChatTab
              messages={messages}
              onSendMessage={handleSendMessage}
              isThinking={isThinking}
              onClearChat={handleClearChat}
              showToast={showToast}
            />
          )}

          {activeTab === 'music' && (
            <div className="flex-1 overflow-y-auto pb-4">
              <MusicTab onSave={handleSaveItem} showToast={showToast} />
            </div>
          )}

          {activeTab === 'video' && (
            <div className="flex-1 overflow-y-auto pb-4">
              <VideoTab onSave={handleSaveItem} showToast={showToast} />
            </div>
          )}

          {activeTab === 'photo' && (
            <div className="flex-1 overflow-y-auto pb-4">
              <PhotoTab onSave={handleSaveItem} showToast={showToast} />
            </div>
          )}
        </main>

        {/* Bottom Navigation Dock */}
        <BottomDock activeTab={activeTab} onSelectTab={setActiveTab} />
      </div>

      {/* Saved Library Modal */}
      <SavedLibraryModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        items={savedItems}
        onDeleteItem={handleDeleteSavedItem}
        showToast={showToast}
      />

      {/* Android Install Guide Modal */}
      <AndroidInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        onInstallPWA={async () => {
          const success = await install();
          if (success) {
            showToast('Handsome AI added to your home screen!');
            setIsInstallModalOpen(false);
          }
        }}
        onDownloadZip={() => downloadAppZipPackage(showToast)}
      />
    </div>
  );
}
