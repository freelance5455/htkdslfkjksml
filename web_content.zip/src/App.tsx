import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { Chess, Square, Move, PieceSymbol, Color } from 'chess.js';
import {
  RotateCcw,
  FlipVertical2,
  Volume2,
  VolumeX,
  Trophy,
  Scale,
  AlertTriangle,
  History,
  Crown,
  Eye,
  RefreshCw,
  Timer,
  Pause,
  Play,
  Flame,
  Zap,
  Clock,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Maximize2,
  Minimize2,
  Flag,
} from 'lucide-react';
import { soundEngine } from './utils/sound';
import {
  InteractiveChessboard,
  PieceFlipMode,
  AnimatedMoveInfo,
  PendingPromotion,
} from './components/InteractiveChessboard';
import { ChessPieceSvg } from './components/ChessPieces';
import { PWAInstallButton } from './components/PWAInstallButton';

interface TimeControlOption {
  id: string;
  label: string;
  category: 'Bullet' | 'Blitz' | 'Rapid' | 'Casual';
  initialSeconds: number; // 0 = unlimited
  incrementSeconds: number;
}

const TIME_CONTROLS: TimeControlOption[] = [
  { id: 'bullet_1_0', label: '1 min', category: 'Bullet', initialSeconds: 60, incrementSeconds: 0 },
  { id: 'bullet_2_1', label: '2 | 1', category: 'Bullet', initialSeconds: 120, incrementSeconds: 1 },
  { id: 'blitz_3_0', label: '3 min', category: 'Blitz', initialSeconds: 180, incrementSeconds: 0 },
  { id: 'blitz_3_2', label: '3 | 2', category: 'Blitz', initialSeconds: 180, incrementSeconds: 2 },
  { id: 'blitz_5_0', label: '5 min', category: 'Blitz', initialSeconds: 300, incrementSeconds: 0 },
  { id: 'rapid_10_0', label: '10 min', category: 'Rapid', initialSeconds: 600, incrementSeconds: 0 },
  { id: 'rapid_15_10', label: '15 | 10', category: 'Rapid', initialSeconds: 900, incrementSeconds: 10 },
  { id: 'unlimited', label: '∞ No Timer', category: 'Casual', initialSeconds: 0, incrementSeconds: 0 },
];

const PIECE_VALUES: Record<PieceSymbol, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
  k: 0,
};

function formatClock(ms: number): string {
  const clamped = Math.max(0, ms);
  const totalSeconds = Math.floor(clamped / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (clamped < 20000 && clamped > 0) {
    const tenths = Math.floor((clamped % 1000) / 100);
    return `${seconds.toString().padStart(2, '0')}.${tenths}`;
  }

  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

export default function App() {
  const [fenHistory, setFenHistory] = useState<string[]>([new Chess().fen()]);
  const [moveHistory, setMoveHistory] = useState<Move[]>([]);
  // viewIndex points into fenHistory (0 = start position, moveHistory.length = latest position)
  const [viewIndex, setViewIndex] = useState<number>(0);
  const [lastAnimatedMove, setLastAnimatedMove] = useState<AnimatedMoveInfo | null>(null);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [boardOrientation, setBoardOrientation] = useState<'white' | 'black'>('white');
  const [pieceFlipMode, setPieceFlipMode] = useState<PieceFlipMode>('turn');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [pendingPromotion, setPendingPromotion] = useState<PendingPromotion | null>(null);
  const [dismissedGameOverModal, setDismissedGameOverModal] = useState<boolean>(false);
  const [showMobileHistory, setShowMobileHistory] = useState<boolean>(false);
  const [isFullScreenMode, setIsFullScreenMode] = useState<boolean>(false);

  // Timer states (default 10 min Rapid)
  const [selectedTimeControlId, setSelectedTimeControlId] = useState<string>('rapid_10_0');
  const activeTimeControl = useMemo(
    () => TIME_CONTROLS.find((t) => t.id === selectedTimeControlId) ?? TIME_CONTROLS[5],
    [selectedTimeControlId]
  );
  const [whiteTimeMs, setWhiteTimeMs] = useState<number>(600 * 1000);
  const [blackTimeMs, setBlackTimeMs] = useState<number>(600 * 1000);
  const [isClockPaused, setIsClockPaused] = useState<boolean>(false);
  const [timeoutWinner, setTimeoutWinner] = useState<Color | null>(null);
  const [resignedColor, setResignedColor] = useState<Color | null>(null);
  const lastLowTimeSecondRef = useRef<number | null>(null);

  const isViewingHistory = viewIndex < moveHistory.length;

  // Displayed Chess instance at `viewIndex` (allows stepping back/forward AND playing from any past move)
  const displayedGame = useMemo(() => {
    const chess = new Chess();
    for (let i = 0; i < viewIndex; i++) {
      const move = moveHistory[i];
      if (move) {
        chess.move({
          from: move.from,
          to: move.to,
          promotion: move.promotion,
        });
      }
    }
    return chess;
  }, [moveHistory, viewIndex]);

  // Latest Chess instance at the tip of moveHistory (for end-of-game detection)
  const latestGame = useMemo(() => {
    const chess = new Chess();
    for (const move of moveHistory) {
      chess.move({
        from: move.from,
        to: move.to,
        promotion: move.promotion,
      });
    }
    return chess;
  }, [moveHistory]);

  const displayedFen = fenHistory[viewIndex] ?? fenHistory[fenHistory.length - 1];
  const board = useMemo(() => displayedGame.board(), [displayedGame]);
  const turn = displayedGame.turn(); // 'w' | 'b' at current viewed position
  const latestTurn = latestGame.turn();
  const inCheck = displayedGame.inCheck();
  const isChessGameOver = latestGame.isGameOver();
  const isGameOver = isChessGameOver || timeoutWinner !== null || resignedColor !== null;

  // Pause clock automatically while stepping through historical moves
  const isClockRunning =
    activeTimeControl.initialSeconds > 0 &&
    moveHistory.length > 0 &&
    !isGameOver &&
    !isClockPaused &&
    !isViewingHistory;

  useEffect(() => {
    if (!isClockRunning) return;

    let lastTick = performance.now();
    const interval = window.setInterval(() => {
      const now = performance.now();
      const delta = now - lastTick;
      lastTick = now;

      if (latestTurn === 'w') {
        setWhiteTimeMs((prev) => {
          const next = Math.max(0, prev - delta);
          const secLeft = Math.ceil(next / 1000);
          if (next > 0 && secLeft <= 10 && lastLowTimeSecondRef.current !== secLeft) {
            lastLowTimeSecondRef.current = secLeft;
            soundEngine.playLowTimeTick();
          }
          if (next === 0) {
            setTimeoutWinner('b');
            soundEngine.playGameOver();
          }
          return next;
        });
      } else {
        setBlackTimeMs((prev) => {
          const next = Math.max(0, prev - delta);
          const secLeft = Math.ceil(next / 1000);
          if (next > 0 && secLeft <= 10 && lastLowTimeSecondRef.current !== secLeft) {
            lastLowTimeSecondRef.current = secLeft;
            soundEngine.playLowTimeTick();
          }
          if (next === 0) {
            setTimeoutWinner('w');
            soundEngine.playGameOver();
          }
          return next;
        });
      }
    }, 100);

    return () => window.clearInterval(interval);
  }, [isClockRunning, latestTurn]);

  // Compute detailed game status including explicit Winner + How They Won
  const gameStatus = useMemo(() => {
    if (timeoutWinner) {
      const winnerName = timeoutWinner === 'w' ? 'White' : 'Black';
      const loserName = timeoutWinner === 'w' ? 'Black' : 'White';
      return {
        isEnded: true,
        winnerColor: timeoutWinner,
        winnerName,
        scoreText: timeoutWinner === 'w' ? '1 – 0' : '0 – 1',
        headline: `${winnerName} Won!`,
        methodTag: 'Won on Time',
        subline: `${winnerName} won on time (${loserName}'s clock ran out)`,
        type: 'timeout' as const,
      };
    }
    if (resignedColor) {
      const winnerColor: Color = resignedColor === 'w' ? 'b' : 'w';
      const winnerName = winnerColor === 'w' ? 'White' : 'Black';
      const loserName = resignedColor === 'w' ? 'White' : 'Black';
      return {
        isEnded: true,
        winnerColor,
        winnerName,
        scoreText: winnerColor === 'w' ? '1 – 0' : '0 – 1',
        headline: `${winnerName} Won!`,
        methodTag: 'Won by Resignation',
        subline: `${winnerName} won by resignation (${loserName} resigned)`,
        type: 'resignation' as const,
      };
    }
    if (latestGame.isCheckmate()) {
      const winnerColor: Color = latestTurn === 'w' ? 'b' : 'w';
      const winnerName = winnerColor === 'w' ? 'White' : 'Black';
      const loserName = latestTurn === 'w' ? 'White' : 'Black';
      return {
        isEnded: true,
        winnerColor,
        winnerName,
        scoreText: winnerColor === 'w' ? '1 – 0' : '0 – 1',
        headline: `${winnerName} Won!`,
        methodTag: 'Won by Checkmate',
        subline: `${winnerName} defeated ${loserName} by checkmate`,
        type: 'checkmate' as const,
      };
    }
    if (latestGame.isStalemate()) {
      return {
        isEnded: true,
        winnerColor: null,
        winnerName: 'Draw',
        scoreText: '½ – ½',
        headline: 'Game Drawn',
        methodTag: 'Draw by Stalemate',
        subline: `No legal moves available for ${latestTurn === 'w' ? 'White' : 'Black'}`,
        type: 'stalemate' as const,
      };
    }
    if (latestGame.isThreefoldRepetition()) {
      return {
        isEnded: true,
        winnerColor: null,
        winnerName: 'Draw',
        scoreText: '½ – ½',
        headline: 'Game Drawn',
        methodTag: 'Draw by Repetition',
        subline: 'The exact same board position was repeated three times',
        type: 'draw' as const,
      };
    }
    if (latestGame.isInsufficientMaterial()) {
      return {
        isEnded: true,
        winnerColor: null,
        winnerName: 'Draw',
        scoreText: '½ – ½',
        headline: 'Game Drawn',
        methodTag: 'Insufficient Material',
        subline: 'Neither player has sufficient pieces to force checkmate',
        type: 'draw' as const,
      };
    }
    if (latestGame.isDraw()) {
      return {
        isEnded: true,
        winnerColor: null,
        winnerName: 'Draw',
        scoreText: '½ – ½',
        headline: 'Game Drawn',
        methodTag: '50-Move Rule',
        subline: '50 consecutive moves played without a pawn advance or capture',
        type: 'draw' as const,
      };
    }

    return {
      isEnded: false,
      winnerColor: null,
      winnerName: null,
      scoreText: null,
      headline: turn === 'w' ? 'White to move' : 'Black to move',
      methodTag: inCheck ? 'Check' : null,
      subline: isViewingHistory
        ? `Viewing Move ${viewIndex} of ${moveHistory.length} · Make a move here to undo & branch`
        : inCheck
        ? `${turn === 'w' ? 'White' : 'Black'} King is under attack`
        : pieceFlipMode === 'turn'
        ? `Pieces oriented for ${turn === 'w' ? 'White' : 'Black'} · Board stays fixed`
        : 'Pass & Play · Click or drag any piece to move',
      type: 'active' as const,
    };
  }, [
    latestGame,
    latestTurn,
    turn,
    inCheck,
    timeoutWinner,
    resignedColor,
    pieceFlipMode,
    isViewingHistory,
    viewIndex,
    moveHistory.length,
  ]);

  // Calculate captured pieces and material advantage at current viewed position
  const materialStats = useMemo(() => {
    const startCounts: Record<Color, Record<PieceSymbol, number>> = {
      w: { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 },
      b: { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 },
    };
    const currentCounts: Record<Color, Record<PieceSymbol, number>> = {
      w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
      b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
    };

    for (const row of board) {
      for (const cell of row) {
        if (cell) {
          currentCounts[cell.color][cell.type]++;
        }
      }
    }

    const capturedByWhite: PieceSymbol[] = [];
    const capturedByBlack: PieceSymbol[] = [];
    const order: PieceSymbol[] = ['q', 'r', 'b', 'n', 'p'];

    for (const piece of order) {
      const missingBlack = Math.max(0, startCounts.b[piece] - currentCounts.b[piece]);
      for (let i = 0; i < missingBlack; i++) capturedByWhite.push(piece);

      const missingWhite = Math.max(0, startCounts.w[piece] - currentCounts.w[piece]);
      for (let i = 0; i < missingWhite; i++) capturedByBlack.push(piece);
    }

    let whiteScore = 0;
    let blackScore = 0;
    for (const piece of order) {
      whiteScore += currentCounts.w[piece] * PIECE_VALUES[piece];
      blackScore += currentCounts.b[piece] * PIECE_VALUES[piece];
    }

    return {
      capturedByWhite,
      capturedByBlack,
      whiteAdvantage: Math.max(0, whiteScore - blackScore),
      blackAdvantage: Math.max(0, blackScore - whiteScore),
    };
  }, [board]);

  // Valid moves for currently selected square (allowed even when viewing history so user can branch/undo!)
  const canInteractWithBoard = !timeoutWinner && !resignedColor && !displayedGame.isGameOver();

  const validMovesForSelected = useMemo(() => {
    if (!selectedSquare || !canInteractWithBoard) return [];
    return displayedGame.moves({ square: selectedSquare, verbose: true });
  }, [displayedGame, selectedSquare, canInteractWithBoard]);

  // Locate king square if in check
  const checkedKingSquare = useMemo((): Square | null => {
    if (!inCheck) return null;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece && piece.type === 'k' && piece.color === turn) {
          return piece.square;
        }
      }
    }
    return null;
  }, [board, inCheck, turn]);

  // Check if a move requires pawn promotion
  const isPromotionMove = useCallback(
    (from: Square, to: Square): boolean => {
      const piece = displayedGame.get(from);
      if (!piece || piece.type !== 'p') return false;
      const targetRank = to[1];
      if (piece.color === 'w' && targetRank !== '8') return false;
      if (piece.color === 'b' && targetRank !== '1') return false;

      const legalMoves = displayedGame.moves({ square: from, verbose: true });
      return legalMoves.some((m) => m.to === to && m.promotion);
    },
    [displayedGame]
  );

  // Execute a validated move (if viewing an earlier move, truncates future history = Undo & Play!)
  const executeMove = useCallback(
    (
      from: Square,
      to: Square,
      promotion: 'q' | 'r' | 'b' | 'n' = 'q',
      wasDragged: boolean = false
    ): boolean => {
      try {
        const nextChess = new Chess(displayedFen);
        const movingColor = nextChess.turn();
        const moveResult = nextChess.move({
          from,
          to,
          promotion,
        });

        if (!moveResult) return false;

        // Add time increment to the player who just completed their move
        if (activeTimeControl.initialSeconds > 0 && activeTimeControl.incrementSeconds > 0) {
          const incMs = activeTimeControl.incrementSeconds * 1000;
          if (movingColor === 'w') {
            setWhiteTimeMs((prev) => prev + incMs);
          } else {
            setBlackTimeMs((prev) => prev + incMs);
          }
        }
        lastLowTimeSecondRef.current = null;

        const nextFen = nextChess.fen();
        // Truncate any future moves beyond viewIndex so stepping back + moving acts as an undo
        setFenHistory((prev) => [...prev.slice(0, viewIndex + 1), nextFen]);
        setMoveHistory((prev) => [...prev.slice(0, viewIndex), moveResult]);
        setViewIndex((prev) => prev + 1);
        setTimeoutWinner(null);
        setResignedColor(null);

        setLastAnimatedMove({
          id: Date.now() + Math.random(),
          from: moveResult.from,
          to: moveResult.to,
          captured: moveResult.captured,
          flags: moveResult.flags,
          wasDragged,
        });
        setSelectedSquare(null);
        setPendingPromotion(null);
        setDismissedGameOverModal(false);

        if (nextChess.isGameOver()) {
          soundEngine.playGameOver();
        } else if (nextChess.inCheck()) {
          soundEngine.playCheck();
        } else if (moveResult.promotion) {
          soundEngine.playPromote();
        } else if (moveResult.flags.includes('k') || moveResult.flags.includes('q')) {
          soundEngine.playCastle();
        } else if (moveResult.captured || moveResult.flags.includes('e')) {
          soundEngine.playCapture();
        } else {
          soundEngine.playMove();
        }

        return true;
      } catch {
        return false;
      }
    },
    [displayedFen, activeTimeControl, viewIndex]
  );

  // Handle drag-and-drop piece movement
  const handlePieceDrop = useCallback(
    (sourceSquare: Square, targetSquare: Square, wasDragged: boolean) => {
      if (!canInteractWithBoard) return;

      const movingPiece = displayedGame.get(sourceSquare);
      if (!movingPiece || movingPiece.color !== turn) return;

      const legalMoves = displayedGame.moves({ square: sourceSquare, verbose: true });
      const isLegal = legalMoves.some((m) => m.to === targetSquare);
      if (!isLegal) return;

      if (isPromotionMove(sourceSquare, targetSquare)) {
        setPendingPromotion({ from: sourceSquare, to: targetSquare, color: turn });
        return;
      }

      executeMove(sourceSquare, targetSquare, 'q', wasDragged);
    },
    [canInteractWithBoard, displayedGame, turn, isPromotionMove, executeMove]
  );

  // Handle click-to-move interaction
  const handleSquareClick = useCallback(
    (square: Square) => {
      if (!canInteractWithBoard) return;

      if (pendingPromotion) {
        setPendingPromotion(null);
      }

      if (selectedSquare) {
        if (selectedSquare === square) {
          setSelectedSquare(null);
          return;
        }

        const isLegalDestination = validMovesForSelected.some((m) => m.to === square);
        if (isLegalDestination) {
          if (isPromotionMove(selectedSquare, square)) {
            setPendingPromotion({ from: selectedSquare, to: square, color: turn });
            return;
          }
          executeMove(selectedSquare, square, 'q', false);
          return;
        }
      }

      const clickedPiece = displayedGame.get(square);
      if (clickedPiece && clickedPiece.color === turn) {
        setSelectedSquare(square);
      } else {
        setSelectedSquare(null);
      }
    },
    [
      canInteractWithBoard,
      pendingPromotion,
      selectedSquare,
      validMovesForSelected,
      isPromotionMove,
      turn,
      executeMove,
      displayedGame,
    ]
  );

  // Step backward one move (review history OR undo)
  const handleStepBack = useCallback(() => {
    if (viewIndex <= 0) return;
    const nextIdx = viewIndex - 1;
    setViewIndex(nextIdx);
    setSelectedSquare(null);
    setPendingPromotion(null);
    const prevMove = nextIdx > 0 ? moveHistory[nextIdx - 1] : null;
    setLastAnimatedMove(
      prevMove
        ? {
            id: Date.now() + Math.random(),
            from: prevMove.from,
            to: prevMove.to,
            captured: prevMove.captured,
            flags: prevMove.flags,
            wasDragged: true,
          }
        : null
    );
    soundEngine.playMove();
  }, [viewIndex, moveHistory]);

  // Step forward one move (redo / replay move)
  const handleStepForward = useCallback(() => {
    if (viewIndex >= moveHistory.length) return;
    const move = moveHistory[viewIndex];
    const nextIdx = viewIndex + 1;
    setViewIndex(nextIdx);
    setSelectedSquare(null);
    setPendingPromotion(null);
    if (move) {
      setLastAnimatedMove({
        id: Date.now() + Math.random(),
        from: move.from,
        to: move.to,
        captured: move.captured,
        flags: move.flags,
        wasDragged: false,
      });
      if (move.captured || move.flags.includes('e')) {
        soundEngine.playCapture();
      } else {
        soundEngine.playMove();
      }
    }
  }, [viewIndex, moveHistory]);

  // Jump to first position
  const handleJumpToStart = useCallback(() => {
    if (viewIndex === 0) return;
    setViewIndex(0);
    setSelectedSquare(null);
    setPendingPromotion(null);
    setLastAnimatedMove(null);
    soundEngine.playMove();
  }, [viewIndex]);

  // Jump to latest position
  const handleJumpToLatest = useCallback(() => {
    if (viewIndex === moveHistory.length) return;
    const lastMove = moveHistory[moveHistory.length - 1];
    setViewIndex(moveHistory.length);
    setSelectedSquare(null);
    setPendingPromotion(null);
    if (lastMove) {
      setLastAnimatedMove({
        id: Date.now() + Math.random(),
        from: lastMove.from,
        to: lastMove.to,
        captured: lastMove.captured,
        flags: lastMove.flags,
        wasDragged: false,
      });
    }
    soundEngine.playMove();
  }, [viewIndex, moveHistory]);

  // Restart game with current time control
  const handleRestartGame = useCallback(
    (customTimeControl?: TimeControlOption) => {
      const tc = customTimeControl ?? activeTimeControl;
      const fresh = new Chess();
      setFenHistory([fresh.fen()]);
      setMoveHistory([]);
      setViewIndex(0);
      setLastAnimatedMove(null);
      setSelectedSquare(null);
      setPendingPromotion(null);
      setDismissedGameOverModal(false);
      setTimeoutWinner(null);
      setResignedColor(null);
      setIsClockPaused(false);
      setWhiteTimeMs(tc.initialSeconds * 1000);
      setBlackTimeMs(tc.initialSeconds * 1000);
      lastLowTimeSecondRef.current = null;
      soundEngine.playMove();
    },
    [activeTimeControl]
  );

  // Resign current active player
  const handleResign = useCallback(() => {
    if (isGameOver || moveHistory.length === 0) return;
    setResignedColor(latestTurn);
    setDismissedGameOverModal(false);
    soundEngine.playGameOver();
  }, [isGameOver, moveHistory.length, latestTurn]);

  // Toggle Full Screen Mode (shows ONLY the board and timers)
  const handleToggleFullScreen = useCallback(() => {
    setIsFullScreenMode((prev) => {
      const next = !prev;
      if (next && document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else if (!next && document.fullscreenElement && document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      return next;
    });
  }, []);

  // Select a new time control preset
  const handleSelectTimeControl = (tc: TimeControlOption) => {
    setSelectedTimeControlId(tc.id);
    handleRestartGame(tc);
  };

  // Cycle piece flip mode
  const handleCyclePieceFlipMode = () => {
    setPieceFlipMode((prev) => {
      if (prev === 'turn') return 'tabletop';
      if (prev === 'tabletop') return 'none';
      return 'turn';
    });
  };

  // Toggle sound
  const handleToggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      soundEngine.enabled = next;
      return next;
    });
  }, []);

  // Keyboard shortcuts (Left/Right arrows to step back/forward, Esc to exit fullscreen, F to flip)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleStepBack();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleStepForward();
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        handleStepBack();
      } else if (e.key.toLowerCase() === 'f') {
        setBoardOrientation((prev) => (prev === 'white' ? 'black' : 'white'));
      } else if (e.key === 'Escape' && isFullScreenMode) {
        setIsFullScreenMode(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleStepBack, handleStepForward, isFullScreenMode]);

  // Group moves into pairs (1. e4 e5) for the notation sheet with ply indices
  const pairedMoves = useMemo(() => {
    const pairs: {
      moveNumber: number;
      white?: Move;
      whitePly: number;
      black?: Move;
      blackPly: number;
    }[] = [];
    for (let i = 0; i < moveHistory.length; i += 2) {
      pairs.push({
        moveNumber: Math.floor(i / 2) + 1,
        white: moveHistory[i],
        whitePly: i + 1,
        black: moveHistory[i + 1],
        blackPly: i + 2,
      });
    }
    return pairs;
  }, [moveHistory]);

  const topPlayerColor: Color = boardOrientation === 'white' ? 'b' : 'w';
  const bottomPlayerColor: Color = boardOrientation === 'white' ? 'w' : 'b';

  // Render Game Over Modal (used in both regular and full-screen views)
  const renderGameOverOverlay = () => {
    if (!gameStatus.isEnded || dismissedGameOverModal) return null;

    const isDecisive = gameStatus.winnerColor !== null;
    return (
      <div className="absolute inset-0 z-30 bg-black/75 backdrop-blur-[4px] flex items-center justify-center p-4 animate-in fade-in duration-200">
        <div className="bg-[#262522] border border-white/15 rounded-2xl p-6 shadow-2xl max-w-sm w-full text-center">
          {/* Winner Emblem or Draw Scale */}
          <div className="relative w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#81B64C]/20 border border-[#81B64C]/50 flex items-center justify-center">
            {isDecisive && gameStatus.winnerColor ? (
              <div className="w-12 h-12">
                <ChessPieceSvg color={gameStatus.winnerColor} type="k" />
              </div>
            ) : (
              <Scale className="w-8 h-8 text-amber-300" />
            )}
            {isDecisive && (
              <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-amber-400 text-[#1F1E1B] flex items-center justify-center shadow-md">
                <Trophy className="w-4 h-4" />
              </div>
            )}
          </div>

          {/* Explicit Winner Headline */}
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {gameStatus.headline}
          </h2>

          {/* Explicit How They Won Tag */}
          <div className="mt-1.5 mb-2">
            <span className="inline-block px-3 py-0.5 rounded-md bg-[#81B64C]/20 text-[#A3D160] text-xs font-bold tracking-wide uppercase">
              {gameStatus.methodTag}
            </span>
          </div>

          <p className="text-xs sm:text-sm text-stone-300 mb-5">
            {gameStatus.subline}
          </p>

          {/* Match Summary Strip */}
          <div className="grid grid-cols-3 items-center py-3 px-3 rounded-xl bg-[#1F1E1B] border border-white/8 mb-5 text-xs">
            <div className="flex flex-col items-center">
              <div className="w-6 h-6 mb-1">
                <ChessPieceSvg color="w" type="k" />
              </div>
              <span className="font-semibold text-white">White</span>
              {activeTimeControl.initialSeconds > 0 && (
                <span className="font-mono text-[11px] text-stone-400 tabular-nums">
                  {formatClock(whiteTimeMs)}
                </span>
              )}
            </div>

            <div className="flex flex-col items-center">
              <span className="font-mono text-base font-bold text-[#A3D160] tabular-nums">
                {gameStatus.scoreText}
              </span>
              <span className="text-[11px] text-stone-500 mt-0.5">
                {Math.ceil(moveHistory.length / 2)} moves
              </span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-6 h-6 mb-1">
                <ChessPieceSvg color="b" type="k" />
              </div>
              <span className="font-semibold text-white">Black</span>
              {activeTimeControl.initialSeconds > 0 && (
                <span className="font-mono text-[11px] text-stone-400 tabular-nums">
                  {formatClock(blackTimeMs)}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5">
            <button
              type="button"
              onClick={() => handleRestartGame()}
              className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#81B64C] hover:bg-[#8ec455] text-[#1F1E1B] font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" />
              Play Again
            </button>
            <button
              type="button"
              onClick={() => setDismissedGameOverModal(true)}
              className="inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-[#302E2B] hover:bg-[#3B3834] text-stone-200 font-semibold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <Eye className="w-4 h-4" />
              Review Moves
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Render Full Screen Mode (ONLY Board + Timers + Minimal Exit/Step Floating Pill)
  if (isFullScreenMode) {
    const renderMinimalClockBar = (color: Color, position: 'top' | 'bottom') => {
      const isWhite = color === 'w';
      const isActiveTurn = !isGameOver && turn === color;
      const clockMs = isWhite ? whiteTimeMs : blackTimeMs;
      const isLowTime = activeTimeControl.initialSeconds > 0 && clockMs > 0 && clockMs < 20000;

      return (
        <div
          className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg border transition-colors ${
            isActiveTurn
              ? 'bg-[#302E2B] border-[#81B64C]/65'
              : 'bg-[#21201D] border-white/8 opacity-85'
          } ${position === 'top' ? 'mb-1.5' : 'mt-1.5'}`}
        >
          <div className="flex items-center gap-2">
            <div className="w-6 h-6">
              <ChessPieceSvg color={color} type="k" />
            </div>
            <span className="text-sm font-bold text-white">
              {isWhite ? 'White' : 'Black'}
            </span>
            {inCheck && turn === color && !isGameOver && (
              <span className="text-xs font-bold text-red-400">· CHECK</span>
            )}
          </div>

          <div
            className={`px-3 py-1 rounded font-mono text-base sm:text-lg font-bold tabular-nums ${
              activeTimeControl.initialSeconds === 0
                ? 'text-[#A3D160] text-xs'
                : clockMs === 0
                ? 'bg-red-900 text-red-200'
                : isActiveTurn
                ? isLowTime
                  ? 'bg-red-600 text-white'
                  : isWhite
                  ? 'bg-[#F8FAFC] text-[#1F1E1B]'
                  : 'bg-[#81B64C] text-[#1F1E1B]'
                : 'bg-[#1A1917] text-stone-400'
            }`}
          >
            {activeTimeControl.initialSeconds > 0
              ? formatClock(clockMs)
              : isActiveTurn
              ? 'To Move'
              : 'Waiting'}
          </div>
        </div>
      );
    };

    return (
      <div className="fixed inset-0 z-50 bg-[#1B1A17] flex flex-col items-center justify-center p-2 sm:p-4 select-none">
        {/* Floating Minimal Back/Forward & Exit Fullscreen Controls */}
        <div className="fixed top-3 right-3 z-40 flex items-center gap-1.5 bg-[#262522]/90 backdrop-blur-md border border-white/10 rounded-xl p-1 shadow-xl">
          <button
            type="button"
            onClick={handleStepBack}
            disabled={viewIndex === 0}
            title="Step Back / Undo (Left Arrow)"
            className="p-2 rounded-lg text-stone-200 hover:bg-white/10 disabled:opacity-35 disabled:pointer-events-none cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleStepForward}
            disabled={viewIndex >= moveHistory.length}
            title="Step Forward (Right Arrow)"
            className="p-2 rounded-lg text-stone-200 hover:bg-white/10 disabled:opacity-35 disabled:pointer-events-none cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleToggleFullScreen}
            title="Exit Full Screen (Esc)"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#302E2B] hover:bg-[#3D3B37] text-xs font-semibold text-white cursor-pointer"
          >
            <Minimize2 className="w-3.5 h-3.5 text-[#A3D160]" />
            Exit
          </button>
        </div>

        <div className="w-[min(95vw,calc(100vh-124px))] flex flex-col items-center">
          {renderMinimalClockBar(topPlayerColor, 'top')}

          <div className="relative w-full aspect-square rounded-lg overflow-hidden shadow-2xl border-2 border-[#1F1E1B] bg-[#EBECD0]">
            <InteractiveChessboard
              board={board}
              turn={turn}
              boardOrientation={boardOrientation}
              pieceFlipMode={pieceFlipMode}
              selectedSquare={selectedSquare}
              validMovesForSelected={validMovesForSelected}
              lastMove={lastAnimatedMove}
              checkedKingSquare={checkedKingSquare}
              pendingPromotion={pendingPromotion}
              disabled={!canInteractWithBoard}
              onSquareClick={handleSquareClick}
              onPieceDrop={handlePieceDrop}
              onSelectPromotion={(piece) => {
                if (pendingPromotion) {
                  executeMove(pendingPromotion.from, pendingPromotion.to, piece, false);
                }
              }}
              onCancelPromotion={() => setPendingPromotion(null)}
            />
            {renderGameOverOverlay()}
          </div>

          {renderMinimalClockBar(bottomPlayerColor, 'bottom')}
        </div>
      </div>
    );
  }

  const renderPlayerStrip = (color: Color, position: 'top' | 'bottom') => {
    const isWhite = color === 'w';
    const isActiveTurn = !isGameOver && turn === color;
    const isKingChecked = inCheck && turn === color;
    const capturedList = isWhite
      ? materialStats.capturedByWhite
      : materialStats.capturedByBlack;
    const advantage = isWhite
      ? materialStats.whiteAdvantage
      : materialStats.blackAdvantage;
    const clockMs = isWhite ? whiteTimeMs : blackTimeMs;
    const isLowTime = activeTimeControl.initialSeconds > 0 && clockMs > 0 && clockMs < 20000;

    return (
      <div
        className={`flex items-center justify-between px-3.5 py-2.5 rounded-lg border transition-colors ${
          isActiveTurn
            ? 'bg-[#302E2B] border-[#81B64C]/60 shadow-sm'
            : 'bg-[#21201D] border-white/8 opacity-90'
        } ${position === 'top' ? 'mb-2' : 'mt-2'}`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-9 h-9 p-1 rounded-md flex items-center justify-center shrink-0 border ${
              isWhite
                ? 'bg-[#EBECD0] border-white/20'
                : 'bg-[#3B3834] border-white/15'
            }`}
          >
            <ChessPieceSvg color={color} type="k" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-[#F8FAFC] whitespace-nowrap">
                {isWhite ? 'White' : 'Black'}
              </span>
              {gameStatus.isEnded && gameStatus.winnerColor === color && (
                <span className="text-xs font-bold text-amber-400 whitespace-nowrap">
                  · Winner ({gameStatus.methodTag})
                </span>
              )}
              {!gameStatus.isEnded && isActiveTurn && (
                <span className="text-xs font-medium text-[#81B64C] whitespace-nowrap">
                  · To Move
                </span>
              )}
              {isKingChecked && (
                <span className="text-xs font-semibold text-red-400 whitespace-nowrap">
                  · Check
                </span>
              )}
            </div>

            <div className="flex items-center gap-1 min-h-[20px] text-xs text-stone-400">
              {capturedList.length > 0 ? (
                <div className="flex items-center flex-wrap gap-0.5">
                  {capturedList.map((piece, idx) => (
                    <span key={idx} className="w-4 h-4 inline-block">
                      <ChessPieceSvg color={isWhite ? 'b' : 'w'} type={piece} />
                    </span>
                  ))}
                </div>
              ) : (
                <span className="text-[11px] text-stone-500">No captures yet</span>
              )}
              {advantage > 0 && (
                <span className="font-mono text-xs font-semibold text-[#81B64C] ml-1">
                  +{advantage}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="shrink-0 flex items-center gap-2">
          {activeTimeControl.initialSeconds > 0 ? (
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md font-mono text-base sm:text-lg font-bold tabular-nums tracking-tight transition-colors ${
                clockMs === 0
                  ? 'bg-red-900/80 text-red-200 border border-red-500/60'
                  : isActiveTurn
                  ? isLowTime
                    ? 'bg-red-600 text-white shadow-sm'
                    : isWhite
                    ? 'bg-[#F8FAFC] text-[#1F1E1B] shadow-sm'
                    : 'bg-[#81B64C] text-[#1F1E1B] shadow-sm'
                  : 'bg-[#1A1917] text-stone-400 border border-white/8'
              }`}
            >
              <Clock className="w-3.5 h-3.5 opacity-75 shrink-0" />
              <span>{formatClock(clockMs)}</span>
            </div>
          ) : isActiveTurn ? (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#81B64C]/15 text-[#A3D160] text-xs font-semibold whitespace-nowrap">
              <Crown className="w-3.5 h-3.5" />
              To Move
            </span>
          ) : (
            <span className="text-xs text-stone-500 font-mono whitespace-nowrap">
              Waiting
            </span>
          )}
        </div>
      </div>
    );
  };

  const pieceFlipLabel =
    pieceFlipMode === 'turn'
      ? 'Flip Pieces: On Turn'
      : pieceFlipMode === 'tabletop'
      ? 'Flip Pieces: Tabletop'
      : 'Flip Pieces: Off';

  return (
    <div className="min-h-screen bg-[#262522] text-[#F8FAFC] flex flex-col">
      {/* Top Bar — 3-Zone Contract */}
      <header className="flex items-center justify-between gap-8 px-4 sm:px-6 py-3 bg-[#1F1E1B] border-b border-white/8">
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <div className="w-7 h-7 p-0.5 rounded bg-[#81B64C] flex items-center justify-center">
            <ChessPieceSvg color="w" type="n" />
          </div>
          <span className="text-base sm:text-lg font-bold tracking-tight text-white">
            Pass & Play Chess
          </span>
        </div>

        <div className="hidden md:flex items-center gap-2 text-xs text-stone-400">
          <span>{activeTimeControl.category} ({activeTimeControl.label})</span>
          <span aria-hidden="true">·</span>
          <span>{pieceFlipLabel}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">
            Move {Math.floor(viewIndex / 2) + 1}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton />
          <button
            type="button"
            onClick={handleToggleFullScreen}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#302E2B] hover:bg-[#3B3834] text-stone-200 border border-white/10 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Full Screen Board & Clocks Mode"
          >
            <Maximize2 className="w-3.5 h-3.5 text-[#A3D160]" />
            Full Screen
          </button>

          <button
            type="button"
            onClick={handleToggleSound}
            aria-label={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            className="p-2 rounded-lg text-stone-300 hover:text-white hover:bg-white/8 transition-colors cursor-pointer"
            title={soundEnabled ? 'Wood Sound Effects: On' : 'Wood Sound Effects: Off'}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-[#A3D160]" />
            ) : (
              <VolumeX className="w-4 h-4 text-stone-500" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setShowMobileHistory((prev) => !prev)}
            className="lg:hidden inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#302E2B] hover:bg-[#3B3834] text-stone-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <History className="w-3.5 h-3.5" />
            Moves ({moveHistory.length})
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-[1060px] mx-auto px-2 sm:px-6 py-3 sm:py-5 flex flex-col lg:flex-row items-center lg:items-start justify-center gap-6">
        <div className="w-full max-w-[600px] flex flex-col">
          {/* Time Control Selector Bar */}
          <div className="mb-2.5 p-1.5 rounded-xl bg-[#1F1E1B] border border-white/8 flex items-center justify-between gap-2 overflow-x-auto">
            <div className="flex items-center gap-1">
              {TIME_CONTROLS.map((tc) => {
                const isSelected = tc.id === selectedTimeControlId;
                return (
                  <button
                    key={tc.id}
                    type="button"
                    onClick={() => handleSelectTimeControl(tc)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1 ${
                      isSelected
                        ? 'bg-[#81B64C] text-[#1F1E1B] shadow-sm'
                        : 'text-stone-300 hover:text-white hover:bg-white/6'
                    }`}
                  >
                    {tc.category === 'Bullet' && <Flame className="w-3 h-3" />}
                    {tc.category === 'Blitz' && <Zap className="w-3 h-3" />}
                    {tc.category === 'Rapid' && <Timer className="w-3 h-3" />}
                    {tc.label}
                  </button>
                );
              })}
            </div>

            {activeTimeControl.initialSeconds > 0 && moveHistory.length > 0 && !isGameOver && (
              <button
                type="button"
                onClick={() => setIsClockPaused((prev) => !prev)}
                className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-[#302E2B] hover:bg-[#3B3834] text-stone-200 flex items-center gap-1 shrink-0 cursor-pointer"
                title={isClockPaused ? 'Resume Clock' : 'Pause Clock'}
              >
                {isClockPaused ? (
                  <>
                    <Play className="w-3 h-3 text-[#A3D160]" />
                    Resume
                  </>
                ) : (
                  <>
                    <Pause className="w-3 h-3 text-amber-400" />
                    Pause
                  </>
                )}
              </button>
            )}
          </div>

          {/* Prominent Game Status Header */}
          <div
            className={`mb-2 px-4 py-2.5 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
              gameStatus.isEnded
                ? 'bg-[#302E2B] border-amber-400/60'
                : isViewingHistory
                ? 'bg-amber-950/30 border-amber-500/40'
                : inCheck
                ? 'bg-red-950/40 border-red-500/50'
                : 'bg-[#302E2B] border-white/10'
            }`}
          >
            <div className="flex items-center gap-3 min-w-0">
              {gameStatus.isEnded ? (
                <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
                  {gameStatus.winnerColor !== null ? (
                    <Trophy className="w-5 h-5" />
                  ) : (
                    <Scale className="w-5 h-5" />
                  )}
                </div>
              ) : (
                <div
                  className={`w-9 h-9 p-1 rounded-lg border shrink-0 flex items-center justify-center ${
                    turn === 'w'
                      ? 'bg-[#EBECD0] border-white'
                      : 'bg-[#3B3834] border-stone-500'
                  }`}
                >
                  <ChessPieceSvg color={turn} type="k" />
                </div>
              )}

              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold tracking-tight text-white truncate">
                    {gameStatus.headline}
                  </h1>
                  {gameStatus.isEnded && gameStatus.methodTag && (
                    <span className="text-xs font-semibold text-amber-300 whitespace-nowrap">
                      · {gameStatus.methodTag}
                    </span>
                  )}
                  {inCheck && !gameStatus.isEnded && (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-red-400 whitespace-nowrap">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      CHECK
                    </span>
                  )}
                </div>
                <p className="text-xs text-stone-400 truncate">{gameStatus.subline}</p>
              </div>
            </div>

            <div className="shrink-0 flex items-center gap-2">
              {gameStatus.isEnded && dismissedGameOverModal && (
                <button
                  type="button"
                  onClick={() => setDismissedGameOverModal(false)}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  Winner Summary
                </button>
              )}
              {!gameStatus.isEnded && moveHistory.length > 0 && !isViewingHistory && (
                <button
                  type="button"
                  onClick={handleResign}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-stone-300 hover:text-red-300 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer inline-flex items-center gap-1"
                  title="Resign current turn"
                >
                  <Flag className="w-3 h-3" />
                  Resign
                </button>
              )}
            </div>
          </div>

          {/* Top Player Bar */}
          {renderPlayerStrip(topPlayerColor, 'top')}

          {/* Chessboard Container */}
          <div className="relative w-full aspect-square rounded-lg overflow-hidden shadow-2xl border-2 border-[#1F1E1B] bg-[#EBECD0] select-none">
            <InteractiveChessboard
              board={board}
              turn={turn}
              boardOrientation={boardOrientation}
              pieceFlipMode={pieceFlipMode}
              selectedSquare={selectedSquare}
              validMovesForSelected={validMovesForSelected}
              lastMove={lastAnimatedMove}
              checkedKingSquare={checkedKingSquare}
              pendingPromotion={pendingPromotion}
              disabled={!canInteractWithBoard}
              onSquareClick={handleSquareClick}
              onPieceDrop={handlePieceDrop}
              onSelectPromotion={(piece) => {
                if (pendingPromotion) {
                  executeMove(pendingPromotion.from, pendingPromotion.to, piece, false);
                }
              }}
              onCancelPromotion={() => setPendingPromotion(null)}
            />
            {renderGameOverOverlay()}
          </div>

          {/* Bottom Player Bar */}
          {renderPlayerStrip(bottomPlayerColor, 'bottom')}

          {/* Move History Navigation & Undo Bar (Back / Forward / Start / Latest) */}
          <div className="mt-2.5 p-1.5 rounded-xl bg-[#1F1E1B] border border-white/8 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleJumpToStart}
                disabled={viewIndex === 0}
                title="Jump to start position"
                className="p-2 rounded-lg bg-[#302E2B] hover:bg-[#3D3B37] disabled:opacity-35 disabled:pointer-events-none text-stone-200 transition-colors cursor-pointer"
              >
                <ChevronsLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleStepBack}
                disabled={viewIndex === 0}
                title="Step Back / Undo Move (Left Arrow)"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#302E2B] hover:bg-[#3D3B37] disabled:opacity-35 disabled:pointer-events-none text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                <ChevronLeft className="w-4 h-4 text-[#A3D160]" />
                Back / Undo
              </button>
            </div>

            <div className="text-center font-mono text-xs text-stone-400 tabular-nums px-2">
              {moveHistory.length === 0 ? (
                <span>Start Position</span>
              ) : (
                <span>
                  Move <strong className="text-white">{viewIndex}</strong> / {moveHistory.length}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleStepForward}
                disabled={viewIndex >= moveHistory.length}
                title="Step Forward / Redo Move (Right Arrow)"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#302E2B] hover:bg-[#3D3B37] disabled:opacity-35 disabled:pointer-events-none text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                Forward
                <ChevronRight className="w-4 h-4 text-[#A3D160]" />
              </button>
              <button
                type="button"
                onClick={handleJumpToLatest}
                disabled={viewIndex >= moveHistory.length}
                title="Jump to latest move"
                className="p-2 rounded-lg bg-[#302E2B] hover:bg-[#3D3B37] disabled:opacity-35 disabled:pointer-events-none text-stone-200 transition-colors cursor-pointer"
              >
                <ChevronsRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Primary Controls Below the Board */}
          <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => handleRestartGame()}
              className="inline-flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-semibold text-xs sm:text-sm bg-[#81B64C] hover:bg-[#8ec455] text-[#1F1E1B] transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4 shrink-0" />
              Restart Game
            </button>

            <button
              type="button"
              onClick={handleCyclePieceFlipMode}
              className={`inline-flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl font-semibold text-xs sm:text-sm border transition-colors cursor-pointer whitespace-nowrap ${
                pieceFlipMode !== 'none'
                  ? 'bg-[#81B64C]/20 border-[#81B64C]/60 text-[#A3D160]'
                  : 'bg-[#302E2B] hover:bg-[#3D3B37] border-white/8 text-stone-300'
              }`}
              title="Rotate only the pieces (not the board) when turns change"
            >
              <RefreshCw className="w-4 h-4 shrink-0" />
              {pieceFlipLabel}
            </button>

            <button
              type="button"
              onClick={() =>
                setBoardOrientation((prev) => (prev === 'white' ? 'black' : 'white'))
              }
              className="inline-flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-semibold text-xs sm:text-sm bg-[#302E2B] hover:bg-[#3D3B37] text-stone-200 border border-white/8 transition-colors cursor-pointer whitespace-nowrap"
              title="Invert entire board perspective (Shortcut: F)"
            >
              <FlipVertical2 className="w-4 h-4 text-stone-300 shrink-0" />
              Flip Board
            </button>

            <button
              type="button"
              onClick={handleToggleFullScreen}
              className="inline-flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-semibold text-xs sm:text-sm bg-[#302E2B] hover:bg-[#3D3B37] text-stone-200 border border-white/8 transition-colors cursor-pointer whitespace-nowrap"
              title="Board & Clocks Only Full Screen Mode"
            >
              <Maximize2 className="w-4 h-4 text-[#A3D160] shrink-0" />
              Full Screen
            </button>
          </div>
        </div>

        {/* Right Sidebar: Interactive Algebraic Move History */}
        <aside
          className={`w-full max-w-[600px] lg:max-w-[340px] bg-[#1F1E1B] border border-white/10 rounded-xl flex flex-col overflow-hidden ${
            showMobileHistory ? 'flex' : 'hidden lg:flex'
          } lg:h-[760px]`}
        >
          <div className="px-4 py-3.5 border-b border-white/8 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-[#81B64C]" />
              <h2 className="text-sm font-bold text-white">Move Notation</h2>
            </div>
            <span className="text-xs font-mono text-stone-400 tabular-nums">
              {pairedMoves.length} {pairedMoves.length === 1 ? 'turn' : 'turns'}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-white/5 max-h-[320px] lg:max-h-none">
            {pairedMoves.length === 0 ? (
              <div className="h-48 lg:h-full flex flex-col items-center justify-center px-6 text-center text-stone-500">
                <p className="text-sm font-medium text-stone-400 mb-1">
                  Ready to play ({activeTimeControl.label})
                </p>
                <p className="text-xs text-stone-500">
                  Use Back / Forward to step through previous moves or play directly from any past position to undo.
                </p>
              </div>
            ) : (
              pairedMoves.map((pair, idx) => (
                <div
                  key={pair.moveNumber}
                  className={`grid grid-cols-7 items-center px-4 py-1.5 text-xs font-mono tabular-nums ${
                    idx % 2 === 0 ? 'bg-[#262522]/50' : 'bg-transparent'
                  }`}
                >
                  <span className="col-span-1 text-stone-500">
                    {pair.moveNumber}.
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setViewIndex(pair.whitePly);
                      setSelectedSquare(null);
                      soundEngine.playMove();
                    }}
                    className={`col-span-3 text-left px-2 py-1 rounded transition-colors cursor-pointer ${
                      viewIndex === pair.whitePly
                        ? 'bg-[#81B64C]/25 text-[#A3D160] font-bold'
                        : 'text-stone-200 hover:bg-white/5'
                    }`}
                  >
                    {pair.white?.san ?? ''}
                  </button>
                  {pair.black ? (
                    <button
                      type="button"
                      onClick={() => {
                        setViewIndex(pair.blackPly);
                        setSelectedSquare(null);
                        soundEngine.playMove();
                      }}
                      className={`col-span-3 text-left px-2 py-1 rounded transition-colors cursor-pointer ${
                        viewIndex === pair.blackPly
                          ? 'bg-[#81B64C]/25 text-[#A3D160] font-bold'
                          : 'text-stone-300 hover:bg-white/5'
                      }`}
                    >
                      {pair.black.san}
                    </button>
                  ) : (
                    <span className="col-span-3" />
                  )}
                </div>
              ))
            )}
          </div>

          <div className="p-4 bg-[#181715] border-t border-white/8 text-xs text-stone-400 space-y-2">
            <div className="flex items-center justify-between text-stone-300 font-medium">
              <span>History & Undo</span>
              <span className="font-mono text-xs text-[#A3D160]">
                {isViewingHistory ? `Viewing Move ${viewIndex}` : 'Live Position'}
              </span>
            </div>
            <p className="text-[11px] leading-relaxed text-stone-500">
              Click <strong>Back / Undo</strong> or any move in the list to inspect earlier positions. Making a move while viewing an earlier turn automatically undoes later moves.
            </p>
          </div>
        </aside>
      </main>
    </div>
  );
}
