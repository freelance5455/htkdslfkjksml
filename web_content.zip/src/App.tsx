/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { SlideshowPlayer } from './components/SlideshowPlayer';
import { ControlPanel } from './components/ControlPanel';
import { SlideTimeline } from './components/SlideTimeline';
import { VideoExporterModal } from './components/VideoExporterModal';
import { INITIAL_SLIDES } from './sampleData';
import { SlideItem, SlideshowSettings } from './types';
import { Sparkles, HelpCircle, CheckCircle, AlertTriangle } from 'lucide-react';

export default function App() {
  const [slides, setSlides] = useState<SlideItem[]>(INITIAL_SLIDES);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0);
  const [isRecorderOpen, setIsRecorderOpen] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [settings, setSettings] = useState<SlideshowSettings>({
    maskStyle: 'box',
    blur: 18,
    brightness: 1.1,
    saturate: 1.2,
    interval: 5.0, // Minimum 5 seconds as requested
    transitionDuration: 5.0,
    easing: 'linear',
    aspectRatio: '16:9',
    motionPattern: '4-linear',
    borderWidth: 4,
    borderColor: '#ffffff',
    showBorder: true,
    showShadow: true,
    foregroundScale: 75,
    crossfadeDuration: 0.6,
  });

  const timerRef = useRef<number | null>(null);

  // High-performance Slideshow auto-advance (zero lag, no 60fps React state re-render thrashing)
  useEffect(() => {
    if (!isPlaying || slides.length === 0) {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    const durationMs = Math.max(1000, (settings.interval || 5) * 1000);
    const timeoutId = window.setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, durationMs);
    timerRef.current = timeoutId;

    return () => {
      clearTimeout(timeoutId);
      timerRef.current = null;
    };
  }, [isPlaying, currentIndex, slides.length, settings.interval]);

  const handleTogglePlay = () => {
    if (slides.length === 0) {
      setToastMessage('অনুগ্রহ করে প্রথমে ছবি আপলোড করুন অথবা ডেমো লোড করুন!');
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }
    setIsPlaying((prev) => !prev);
    setProgress(0);
  };

  const handleStartShow = () => {
    if (slides.length === 0) {
      setToastMessage('অনুগ্রহ করে প্রথমে ছবি আপলোড করুন অথবা ডেমো লোড করুন!');
      setTimeout(() => setToastMessage(null), 3500);
      const input = document.getElementById('imageInput') as HTMLInputElement | null;
      if (input) input.click();
      return;
    }
    setIsPlaying(true);
    setProgress(0);
  };

  const handleStopShow = () => {
    setIsPlaying(false);
  };

  const handleClearProject = () => {
    setIsPlaying(false);
    setSlides([]);
    setCurrentIndex(0);
    setProgress(0);
    const input = document.getElementById('imageInput') as HTMLInputElement | null;
    if (input) input.value = '';
    setToastMessage('প্রজেক্টের সমস্ত ছবি মুছে ফেলা হয়েছে! নতুন ছবি সিলেক্ট করুন।');
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleExportVideo = () => {
    if (slides.length === 0) {
      setToastMessage('এক্সপোর্ট করার জন্য কোনো ছবি নেই! অনুগ্রহ করে ছবি আপলোড করুন।');
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }
    setIsRecorderOpen(true);
  };

  const handleNext = useCallback(() => {
    if (slides.length <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % slides.length);
    setProgress(0);
  }, [slides.length]);

  const handlePrev = useCallback(() => {
    if (slides.length <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
    setProgress(0);
  }, [slides.length]);

  const handleFilesSelected = (files: FileList) => {
    const newItems: SlideItem[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        const url = URL.createObjectURL(file);
        newItems.push({
          id: `upload-${Date.now()}-${i}`,
          url,
          name: file.name.replace(/\.[^/.]+$/, ''),
          size: file.size,
        });
      }
    }

    if (newItems.length > 0) {
      setSlides((prev) => [...prev, ...newItems]);
      setCurrentIndex(slides.length); // Jump to first uploaded item
      setProgress(0);
      setIsPlaying(true);
      setToastMessage(`${newItems.length} টি নতুন ছবি সফলভাবে যুক্ত হয়েছে!`);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleLoadSamplePhotos = () => {
    setSlides(INITIAL_SLIDES);
    setCurrentIndex(0);
    setProgress(0);
    setIsPlaying(true);
    setToastMessage('নমুনা ছবি লোড হয়েছে!');
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleResetSettings = () => {
    setSettings({
      maskStyle: 'box',
      blur: 18,
      brightness: 1.1,
      saturate: 1.2,
      interval: 5.0,
      transitionDuration: 5.0,
      easing: 'linear',
      aspectRatio: '16:9',
      motionPattern: '4-linear',
      borderWidth: 4,
      borderColor: '#ffffff',
      showBorder: true,
      showShadow: true,
      foregroundScale: 75,
      crossfadeDuration: 0.6,
    });
  };

  const handleSelectSlide = (index: number) => {
    setCurrentIndex(index);
    setProgress(0);
  };

  const handleRemoveSlide = (index: number) => {
    if (slides.length <= 1) {
      handleClearProject();
      return;
    }
    setSlides((prev) => prev.filter((_, i) => i !== index));
    if (currentIndex >= index && currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
    setProgress(0);
  };

  const handleMoveSlide = (index: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= slides.length) return;

    setSlides((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[targetIndex];
      updated[targetIndex] = temp;
      return updated;
    });

    if (currentIndex === index) {
      setCurrentIndex(targetIndex);
    } else if (currentIndex === targetIndex) {
      setCurrentIndex(index);
    }
  };

  // High-Resolution Snapshot Capture
  const handleExportSnapshot = () => {
    const currentSlide = slides[currentIndex];
    if (!currentSlide) return;

    const canvas = document.createElement('canvas');
    const isVertical = settings.aspectRatio === '9:16';
    const isSquare = settings.aspectRatio === '1:1';
    const isPortrait = settings.aspectRatio === '4:5';

    const width = isVertical ? 1080 : isSquare ? 1080 : isPortrait ? 1080 : 1920;
    const height = isVertical ? 1920 : isSquare ? 1080 : isPortrait ? 1350 : 1080;

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = currentSlide.url;

    img.onload = () => {
      // 1. Draw Blurred Background with White Vibe
      ctx.save();
      ctx.filter = `blur(${settings.blur * 2}px) brightness(${settings.brightness}) saturate(${settings.saturate})`;
      const imgAspect = img.naturalWidth / img.naturalHeight;
      const canvasAspect = width / height;
      let bgW = width;
      let bgH = height;
      if (imgAspect > canvasAspect) {
        bgH = height;
        bgW = height * imgAspect;
      } else {
        bgW = width;
        bgH = width / imgAspect;
      }
      ctx.drawImage(img, (width - bgW) / 2, (height - bgH) / 2, bgW, bgH);
      ctx.restore();

      // 2. Draw Vignette
      ctx.save();
      const grad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        Math.min(width, height) * 0.25,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.65,
      );
      grad.addColorStop(0, 'transparent');
      grad.addColorStop(1, 'rgba(0,0,0,0.5)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();

      // 3. Draw Foreground Main Image
      ctx.save();
      const targetW = (width * settings.foregroundScale) / 100;
      const targetH = (height * settings.foregroundScale) / 100;
      const fgX = (width - targetW) / 2;
      const fgY = (height - targetH) / 2;

      ctx.beginPath();
      if (settings.maskStyle === 'circle') {
        const radius = Math.min(targetW, targetH) * 0.45;
        ctx.arc(width / 2, height / 2, radius, 0, Math.PI * 2);
      } else if (settings.maskStyle === 'rounded') {
        ctx.roundRect(fgX, fgY, targetW, targetH, 30);
      } else if (settings.maskStyle === 'full') {
        ctx.rect(0, 0, width, height);
      } else {
        // Sharp Square Box (0px radius)
        ctx.rect(fgX, fgY, targetW, targetH);
      }
      ctx.closePath();

      if (settings.showShadow) {
        ctx.shadowColor = 'rgba(0,0,0,0.6)';
        ctx.shadowBlur = 35;
        ctx.shadowOffsetY = 15;
      }

      ctx.save();
      ctx.clip();

      let drawW = targetW;
      let drawH = targetH;
      if (settings.maskStyle === 'full') {
        drawW = width;
        drawH = height;
      }

      const zoom = currentSlide.zoom ?? 1.0;
      const offX = ((currentSlide.offsetX ?? 0) / 100) * drawW;
      const offY = ((currentSlide.offsetY ?? 0) / 100) * drawH;
      const fitMode = currentSlide.fitMode ?? 'cover';

      if (fitMode === 'contain') {
        if (imgAspect > drawW / drawH) {
          drawH = drawW / imgAspect;
        } else {
          drawW = drawH * imgAspect;
        }
      } else {
        // cover
        if (imgAspect > drawW / drawH) {
          drawW = drawH * imgAspect;
        } else {
          drawH = drawW / imgAspect;
        }
      }

      drawW *= zoom;
      drawH *= zoom;

      ctx.drawImage(
        img,
        (width - drawW) / 2 + offX,
        (height - drawH) / 2 + offY,
        drawW,
        drawH,
      );
      ctx.restore();

      if (settings.showBorder && settings.maskStyle !== 'full') {
        ctx.lineWidth = settings.borderWidth * 2;
        ctx.strokeStyle = settings.borderColor;
        ctx.stroke();
      }
      ctx.restore();

      // Download
      const link = document.createElement('a');
      link.download = `inshot-slide-${Date.now()}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    };
  };

  return (
    <div className="min-h-screen bg-[#121212] text-neutral-100 flex flex-col items-center px-2 sm:px-4 py-4 sm:py-6 font-sans">
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed top-4 z-50 bg-[#1e1e1e] border border-[#00e676]/40 text-neutral-100 px-4 py-2.5 rounded-lg shadow-2xl flex items-center gap-2.5 text-xs font-medium animate-bounce">
          <CheckCircle className="w-4 h-4 text-[#00e676]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <header className="w-full max-w-4xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-4 pb-3 border-b border-neutral-800">
        <div className="text-center sm:text-left">
          <h2 className="text-base sm:text-lg font-bold text-[#00e676] flex items-center justify-center sm:justify-start gap-2">
            <span>প্রফেশনাল ইনশট স্টাইল স্লাইডশো</span>
            <span className="text-[10px] font-normal text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
              White Vibe
            </span>
          </h2>
          <p className="text-[11px] text-[#888] mt-0.5">
            হোয়াইট ভাইব ব্লার ব্যাকগ্রাউন্ড এবং ৪টি সুনির্দিষ্ট লিনিয়ার মোশন (Zoom In, Zoom Out, Right-Left, Left-Right)
          </p>
        </div>

        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setShowHelp((prev) => !prev)}
            className="px-2.5 py-1 rounded bg-[#1e1e1e] hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 text-xs flex items-center gap-1.5 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5 text-[#00e676]" />
            <span>মোশন গাইড</span>
          </button>
        </div>
      </header>

      {/* Help Modal/Banner */}
      {showHelp && (
        <div className="w-full max-w-4xl mb-4 p-3.5 rounded-xl bg-[#1e1e1e] border border-[#00e676]/40 text-xs text-neutral-300 flex flex-col sm:flex-row gap-3 items-start justify-between shadow-lg">
          <div className="space-y-1">
            <h4 className="font-bold text-[#00e676] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> ৪টি সুনির্দিষ্ট লিনিয়ার মোশনের বর্ণনা:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px] text-neutral-300 pt-1">
              <div>• <strong>১. Zoom In:</strong> ব্যাকগ্রাউন্ড ১.০ স্কেলে স্থির থাকে এবং মূল ছবি ১.১৫ স্কেলে ধীরে জুম ইন করে।</div>
              <div>• <strong>২. Zoom Out:</strong> ব্যাকগ্রাউন্ড ১.১৫ স্কেলে থাকে এবং মূল ছবি ১.০ স্কেলে জুম আউট হয়।</div>
              <div>• <strong>৩. Right to Left:</strong> ব্যাকগ্রাউন্ড ডান থেকে সরে এবং মূল ছবি সোজা বামে ৫% লিনিয়ার স্লাইড হয়।</div>
              <div>• <strong>৪. Left to Right:</strong> ব্যাকগ্রাউন্ড বাম থেকে সরে এবং মূল ছবি সোজা ডানে ৫% লিনিয়ার স্লাইড হয়।</div>
            </div>
          </div>
          <button
            onClick={() => setShowHelp(false)}
            className="text-xs px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-400 rounded flex-shrink-0"
          >
            বন্ধ করুন
          </button>
        </div>
      )}

      {/* Main Studio Container */}
      <main className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Player & Sequence */}
        <section className="lg:col-span-7 flex flex-col gap-3.5">
          <SlideshowPlayer
            slides={slides}
            currentIndex={currentIndex}
            isPlaying={isPlaying}
            settings={settings}
            progress={progress}
            onTogglePlay={handleTogglePlay}
            onNext={handleNext}
            onPrev={handlePrev}
            onExportSnapshot={handleExportSnapshot}
            onOpenRecorder={handleExportVideo}
          />

          <SlideTimeline
            slides={slides}
            currentIndex={currentIndex}
            onSelectSlide={handleSelectSlide}
            onRemoveSlide={handleRemoveSlide}
            onMoveSlide={handleMoveSlide}
            onAddFiles={handleFilesSelected}
          />
        </section>

        {/* Right Column: InShot Controls & Configuration */}
        <section className="lg:col-span-5 flex flex-col gap-3.5">
          <ControlPanel
            settings={settings}
            slides={slides}
            currentIndex={currentIndex}
            isPlaying={isPlaying}
            onUpdateSettings={(patch) => setSettings((prev) => ({ ...prev, ...patch }))}
            onUpdateSlide={(idx, patch) => {
              setSlides((prev) =>
                prev.map((s, i) => (i === idx ? { ...s, ...patch } : s)),
              );
            }}
            onFilesSelected={handleFilesSelected}
            onLoadSamplePhotos={handleLoadSamplePhotos}
            onResetSettings={handleResetSettings}
            onClearProject={handleClearProject}
            onStartShow={handleStartShow}
            onStopShow={handleStopShow}
            onExportVideo={handleExportVideo}
            onSelectSlide={handleSelectSlide}
          />
        </section>
      </main>

      {/* Video Exporter Modal */}
      <VideoExporterModal
        isOpen={isRecorderOpen}
        onClose={() => setIsRecorderOpen(false)}
        slides={slides}
        settings={settings}
      />

      {/* Footer */}
      <footer className="w-full max-w-4xl mt-8 pt-3 border-t border-neutral-800/80 text-center text-[11px] text-neutral-500">
        প্রফেশনাল ইনশট স্টাইল ডুয়েল-লেয়ার স্লাইডশো • White Vibe Blur & 4-Motion Engine
      </footer>
    </div>
  );
}
