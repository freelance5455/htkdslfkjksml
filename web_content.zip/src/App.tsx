/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { UserProfile, TaskItem, MarketItem, ItemCategory } from './types';
import { INITIAL_MARKET_ITEMS, THEME_STYLES } from './data/initialCatalog';
import { AuthGate } from './components/AuthGate';
import { Header } from './components/Header';
import { Navigation, ActiveTab } from './components/Navigation';
import { PomodoroTimer } from './components/PomodoroTimer';
import { TaskManager } from './components/TaskManager';
import { MarketView } from './components/MarketView';
import { FoundersCorner } from './components/FoundersCorner';
import { EquipmentCenter } from './components/EquipmentCenter';
import { AICoachModal } from './components/AICoachModal';
import { CouponModal } from './components/CouponModal';
import { playLevelUpSound, playCoinSound } from './utils/soundEffects';
import { triggerConfetti } from './utils/confetti';
import { Megaphone, X, LogOut } from 'lucide-react';
import { initNotifications } from './utils/notifications';

const STORAGE_USER_KEY = 'waqti_auth_user_v2';
const STORAGE_TASKS_KEY = 'waqti_tasks_v2';
const STORAGE_MARKET_KEY = 'waqti_market_cache_v2';

export default function App() {
  // 1. User Authentication State
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_USER_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // 2. Tasks State
  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_TASKS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      //
    }
    return [
      {
        id: 't-1',
        title: 'استكمال جلسة تركيز أولى عبر مؤقت البومودورو ⏱️',
        category: 'شخصي',
        priority: 'high',
        estimatedPomodoros: 1,
        completedPomodoros: 0,
        isCompleted: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 't-2',
        title: 'استكشاف ماركت المقتنيات وشراء أول لقب أو إطار متوهج 🛒',
        category: 'شخصي',
        priority: 'medium',
        estimatedPomodoros: 1,
        completedPomodoros: 0,
        isCompleted: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 't-3',
        title: 'استشارة «كابتن وقتي» الذكي لتنظيم أهداف الأسبوع 🤖',
        category: 'دراسة',
        priority: 'low',
        estimatedPomodoros: 1,
        completedPomodoros: 0,
        isCompleted: false,
        createdAt: new Date().toISOString(),
      },
    ];
  });

  // 3. Market Items State (Merged 45+ catalog)
  const [marketItems, setMarketItems] = useState<MarketItem[]>(INITIAL_MARKET_ITEMS);

  // 4. UI Navigation & Modals State
  const [activeTab, setActiveTab] = useState<ActiveTab>('focus');
  const [linkedPomodoroTaskId, setLinkedPomodoroTaskId] = useState<string | undefined>(undefined);
  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [aiCoachTaskTarget, setAiCoachTaskTarget] = useState<string | undefined>(undefined);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [announcement, setAnnouncement] = useState<string | null>(null);

  // Initialize background notifications Service Worker
  useEffect(() => {
    initNotifications();
  }, []);

  // Network status listeners
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save user and tasks to localStorage
  useEffect(() => {
    if (user) {
      try {
        localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
      } catch {
        //
      }
    } else {
      localStorage.removeItem(STORAGE_USER_KEY);
    }
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_TASKS_KEY, JSON.stringify(tasks));
    } catch {
      //
    }
  }, [tasks]);

  // Fetch live market & sync with server
  const fetchMarketData = async () => {
    try {
      const res = await fetch('/api/market');
      if (res.ok) {
        const data = await res.json();
        if (data.items) {
          setMarketItems(data.items);
          localStorage.setItem(STORAGE_MARKET_KEY, JSON.stringify(data.items));
        }
        if (data.announcement) {
          setAnnouncement(data.announcement);
        }
      }
    } catch {
      // Offline fallback: load cached market items
      try {
        const cached = localStorage.getItem(STORAGE_MARKET_KEY);
        if (cached) setMarketItems(JSON.parse(cached));
      } catch {
        //
      }
    }
  };

  useEffect(() => {
    fetchMarketData();
  }, []);

  // Hybrid Sync user state with cloud server
  useEffect(() => {
    if (!user) return;
    const syncWithServer = async () => {
      try {
        const res = await fetch('/api/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user, tasks }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.announcement) setAnnouncement(data.announcement);
        }
      } catch {
        // Offline mode works seamlessly
      }
    };
    syncWithServer();
  }, [user?.coins, user?.xp, user?.inventory]);

  // Pomodoro Completion Handlers
  const handlePomodoroComplete = (earnedCoins: number, earnedXp: number, taskId?: string) => {
    if (!user) return;

    const newXp = user.xp + earnedXp;
    const newCoins = user.coins + earnedCoins;
    const calculatedLevel = Math.floor(newXp / 250) + 1;
    const didLevelUp = calculatedLevel > user.level;

    if (didLevelUp && soundEnabled) {
      setTimeout(() => {
        playLevelUpSound();
        triggerConfetti();
      }, 500);
    }

    setUser({
      ...user,
      coins: newCoins,
      xp: newXp,
      level: Math.max(user.level, calculatedLevel),
    });

    if (taskId) {
      setTasks((prev) =>
        prev.map((t) => {
          if (t.id === taskId) {
            const updated = t.completedPomodoros + 1;
            return {
              ...t,
              completedPomodoros: updated,
              isCompleted: updated >= t.estimatedPomodoros ? true : t.isCompleted,
            };
          }
          return t;
        })
      );
    }
  };

  // Task Actions
  const handleAddTask = (taskData: Omit<TaskItem, 'id' | 'createdAt' | 'completedPomodoros' | 'isCompleted'>) => {
    const newTask: TaskItem = {
      ...taskData,
      id: 'task-' + Date.now().toString(36),
      completedPomodoros: 0,
      isCompleted: false,
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const handleToggleTask = (taskId: string) => {
    if (!user) return;

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const isDone = !t.isCompleted;
          if (isDone) {
            // Reward on completion
            const newXp = user.xp + 35;
            const newCoins = user.coins + 20;
            const newLevel = Math.floor(newXp / 250) + 1;
            setUser((u) => (u ? { ...u, xp: newXp, coins: newCoins, level: Math.max(u.level, newLevel) } : null));
          }
          return { ...t, isCompleted: isDone, completedAt: isDone ? new Date().toISOString() : undefined };
        }
        return t;
      })
    );
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  const handleAddSubtask = (taskId: string, subtaskTitle: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const sub = { id: 'sub-' + Date.now().toString(36), title: subtaskTitle, completed: false };
          return { ...t, subtasks: [...(t.subtasks || []), sub] };
        }
        return t;
      })
    );
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updatedSubs = (t.subtasks || []).map((s) => (s.id === subtaskId ? { ...s, completed: !s.completed } : s));
          return { ...t, subtasks: updatedSubs };
        }
        return t;
      })
    );
  };

  // Market & Equipment Actions
  const handleBuyItem = (item: MarketItem) => {
    if (!user || user.coins < item.price || user.inventory.includes(item.id)) return;

    setUser({
      ...user,
      coins: user.coins - item.price,
      inventory: [...user.inventory, item.id],
    });
  };

  const handleEquipItem = (category: ItemCategory, val: string) => {
    if (!user) return;
    if (category === 'theme') {
      setUser({ ...user, theme: val });
    } else if (category === 'frame') {
      setUser({ ...user, frame: val });
    } else if (category === 'title') {
      setUser({ ...user, title: val });
    } else if (category === 'avatar') {
      setUser({ ...user, avatar: val, customAvatarUrl: undefined }); // Reverting custom avatar when selecting preset avatar
    }
  };

  const handleUpdateProfile = (updates: Partial<UserProfile>) => {
    if (!user) return;
    setUser({ ...user, ...updates });
  };

  const handleAddCoins = (amount: number) => {
    if (!user) return;
    setUser({ ...user, coins: user.coins + amount });
  };

  const handleLogout = () => {
    setIsLogoutModalOpen(true);
  };

  const confirmLogout = () => {
    setUser(null);
    localStorage.removeItem(STORAGE_USER_KEY);
    setIsLogoutModalOpen(false);
  };

  // 1. Mandatory Auth Gate: App is fully locked until login/registration!
  if (!user) {
    return <AuthGate onAuthenticated={(authedUser) => setUser(authedUser)} />;
  }

  // Active theme style classes (built-in or founder custom palette)
  const customTheme = marketItems.find((i) => i.id === user.theme && i.customThemePalette);
  const themeConfig = customTheme?.customThemePalette || THEME_STYLES[user.theme] || THEME_STYLES['theme-midnight'];

  return (
    <div
      style={customTheme?.customThemePalette ? { backgroundColor: customTheme.customThemePalette.bg } : undefined}
      className={`min-h-screen text-slate-100 flex flex-col justify-between ${themeConfig.bg} transition-colors duration-500`}
    >
      
      {/* Background radial gradient accent */}
      <div className={`fixed inset-0 bg-gradient-to-br ${themeConfig.gradient} opacity-80 pointer-events-none -z-10`} />

      <div>
        {/* Top Header */}
        <Header
          user={user}
          marketItems={marketItems}
          isOnline={isOnline}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled(!soundEnabled)}
          onOpenCouponModal={() => setIsCouponModalOpen(true)}
          onOpenEquipment={() => setActiveTab('equipment')}
          onLogout={handleLogout}
        />

        {/* Global Announcement Banner */}
        {announcement && (
          <div className="bg-gradient-to-r from-amber-600/20 via-yellow-500/20 to-amber-600/20 border-b border-amber-500/30 px-3 py-1.5 flex items-center justify-between text-xs text-amber-200">
            <div className="max-w-4xl mx-auto flex items-center gap-2 truncate">
              <Megaphone className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
              <span className="font-bold truncate">{announcement}</span>
            </div>
            <button
              onClick={() => setAnnouncement(null)}
              className="text-amber-400 hover:text-white p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Main Content Area */}
        <main className="max-w-4xl mx-auto px-3 py-4 pb-24">
          
          {/* View 1: Pomodoro Focus */}
          {activeTab === 'focus' && (
            <PomodoroTimer
              onSessionComplete={handlePomodoroComplete}
              tasks={tasks}
              soundEnabled={soundEnabled}
              initialLinkedTaskId={linkedPomodoroTaskId}
            />
          )}

          {/* View 2: Tasks & Quests */}
          {activeTab === 'tasks' && (
            <TaskManager
              tasks={tasks}
              onAddTask={handleAddTask}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
              onAIAnalyzeTask={(title) => {
                setAiCoachTaskTarget(title);
                setActiveTab('ai_coach');
              }}
              onAddSubtask={handleAddSubtask}
              onToggleSubtask={handleToggleSubtask}
              onStartPomodoroForTask={(taskId) => {
                setLinkedPomodoroTaskId(taskId);
                setActiveTab('focus');
              }}
              soundEnabled={soundEnabled}
            />
          )}

          {/* View 3: Market (45+ items) */}
          {activeTab === 'market' && (
            <MarketView
              items={marketItems}
              user={user}
              onBuyItem={handleBuyItem}
              onEquipItem={handleEquipItem}
              onOpenCouponModal={() => setIsCouponModalOpen(true)}
              soundEnabled={soundEnabled}
            />
          )}

          {/* View 4: Founder's Corner (Next to Market, Founder only) */}
          {activeTab === 'founder' && (
            <FoundersCorner
              user={user}
              marketItems={marketItems}
              onRefreshMarket={fetchMarketData}
              onAddCoins={handleAddCoins}
              soundEnabled={soundEnabled}
            />
          )}

          {/* View 5: Equipment & Inventory Center */}
          {activeTab === 'equipment' && (
            <EquipmentCenter
              user={user}
              marketItems={marketItems}
              onUpdateProfile={handleUpdateProfile}
              onEquipItem={handleEquipItem}
              onLogout={handleLogout}
              soundEnabled={soundEnabled}
            />
          )}

          {/* View 6: AI Productivity Coach */}
          {activeTab === 'ai_coach' && (
            <AICoachModal
              user={user}
              tasks={tasks}
              initialTaskTitle={aiCoachTaskTarget}
              onAddTask={handleAddTask}
              soundEnabled={soundEnabled}
            />
          )}

        </main>
      </div>

      {/* Redeem Coupon Modal */}
      {isCouponModalOpen && (
        <CouponModal
          userId={user.id}
          onRedeemSuccess={(reward) => handleAddCoins(reward)}
          onClose={() => setIsCouponModalOpen(false)}
          soundEnabled={soundEnabled}
        />
      )}

      {/* Custom Logout Confirmation Modal */}
      {isLogoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 to-red-950/40 border border-red-500/40 rounded-3xl p-6 shadow-2xl text-right">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-red-500/20 border border-red-400/40 flex items-center justify-center text-red-400 mb-3 shadow-md">
              <LogOut className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-white text-center">
              هل ترغب في تسجيل الخروج؟
            </h3>

            <p className="text-xs text-slate-300 mt-2 leading-relaxed text-center">
              سيتم حفظ كافة نقاطك، إنجازاتك، ومهامك بشكل آمن في السحابة. يمكنك العودة وتسجيل الدخول في أي وقت.
            </p>

            <div className="mt-5 space-y-2">
              <button
                type="button"
                onClick={confirmLogout}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-sm shadow-lg shadow-red-600/30 cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>نعم، تسجيل الخروج الآن 🚪</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLogoutModalOpen(false)}
                className="w-full py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold cursor-pointer"
              >
                إلغاء والبقاء في التطبيق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Mobile Dock Navigation */}
      <Navigation
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab !== 'ai_coach') setAiCoachTaskTarget(undefined);
        }}
        user={user}
      />

    </div>
  );
}
