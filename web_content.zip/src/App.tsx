/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { TeacherAvatar } from './components/TeacherAvatar';
import { UrduClass } from './components/UrduClass';
import { EnglishClass } from './components/EnglishClass';
import { MathCounterClass } from './components/MathCounterClass';
import { AIChatModal } from './components/AIChatModal';
import { MagicVideoStudio } from './components/MagicVideoStudio';
import { QuizModal } from './components/QuizModal';
import { CertificateModal } from './components/CertificateModal';
import { TracingCanvasModal } from './components/TracingCanvasModal';
import { LearningCategory } from './types/curriculum';
import { sound } from './utils/sound';
import confetti from 'canvas-confetti';
import { Sparkles, Heart, HelpCircle, Award, Download, Copy, CheckCircle, ExternalLink } from 'lucide-react';

export default function App() {
  const [childName, setChildName] = useState<string>('ارہان');
  const [activeTab, setActiveTab] = useState<LearningCategory>('urdu');
  const [starsCount, setStarsCount] = useState<number>(3); // Initial encouragement stars
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  // Modals state
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isVideoOpen, setIsVideoOpen] = useState(false);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [isCertificateOpen, setIsCertificateOpen] = useState(false);
  const [tracingTarget, setTracingTarget] = useState<{
    letter: string;
    name: string;
    example: string;
  } | null>(null);

  const handleEarnStar = () => {
    sound.playStarSound();
    setStarsCount((prev) => prev + 1);
  };

  const handleCompleteTracing = () => {
    handleEarnStar();
  };

  const handleDownloadZipBlob = async () => {
    setIsDownloading(true);
    sound.playPopSound();
    try {
      const res = await fetch('/download.zip');
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'arhan-ai-learning-app.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      sound.playSuccessSound();
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {
      window.location.href = '/download.zip';
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyLink = () => {
    const fullUrl = window.location.origin + '/download.zip';
    navigator.clipboard.writeText(fullUrl);
    setCopiedLink(true);
    sound.playSuccessSound();
    setTimeout(() => setCopiedLink(false), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50/70 via-orange-50/30 to-amber-100/40 text-slate-800 flex flex-col font-sans">
      {/* Navigation Bar */}
      <Navbar
        childName={childName}
        onUpdateChildName={setChildName}
        starsCount={starsCount}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenChat={() => setIsChatOpen(true)}
        onOpenVideo={() => setIsVideoOpen(true)}
        onOpenCertificate={() => setIsCertificateOpen(true)}
      />

      {/* Prominent High-Visibility ZIP Download Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 text-white shadow-lg border-b-4 border-amber-400 py-3.5 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-center sm:text-right">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-900 flex items-center justify-center text-xl shrink-0 shadow">
              📦
            </div>
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="font-urdu text-base sm:text-lg font-black text-amber-300">
                  مکمل سورس کوڈ زپ فائل (Download Source Code ZIP)
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] px-2 py-0.5 rounded-full font-bold">
                  2.45 MB
                </span>
              </div>
              <p className="text-xs text-purple-200 mt-0.5">
                تمام فائلیں (src, components, server.ts, images, package.json) ایک کلک میں ڈاؤنلوڈ کریں
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleDownloadZipBlob}
              disabled={isDownloading}
              className="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black rounded-xl text-xs sm:text-sm transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${isDownloading ? 'animate-bounce' : ''}`} />
              <span>{isDownloading ? 'ڈاؤنلوڈ ہو رہی ہے...' : 'ابھی ZIP ڈاؤنلوڈ کریں'}</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all border border-white/20 flex items-center gap-1.5 cursor-pointer"
              title="ڈاؤنلوڈ لنک کاپی کریں"
            >
              {copiedLink ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? 'لنک کاپی ہو گیا!' : 'لنک کاپی کریں'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 space-y-6 sm:space-y-8">
        {/* Interactive AI Teacher Hero Banner */}
        <TeacherAvatar
          childName={childName}
          onOpenChat={() => setIsChatOpen(true)}
          onOpenQuiz={() => setIsQuizOpen(true)}
          onOpenVideo={() => setIsVideoOpen(true)}
          onOpenCertificate={() => setIsCertificateOpen(true)}
          starsCount={starsCount}
        />

        {/* Current Active Classroom View */}
        <section className="transition-all duration-300">
          {activeTab === 'urdu' && (
            <UrduClass
              childName={childName}
              onTraceLetter={(target) => setTracingTarget(target)}
              onEarnStar={handleEarnStar}
            />
          )}

          {activeTab === 'english' && (
            <EnglishClass
              childName={childName}
              onTraceLetter={(target) => setTracingTarget(target)}
              onEarnStar={handleEarnStar}
            />
          )}

          {activeTab === 'math' && (
            <MathCounterClass
              childName={childName}
              onTraceNumber={(target) => setTracingTarget(target)}
              onEarnStar={handleEarnStar}
            />
          )}
        </section>

        {/* Parent Guidance & Motivational Card */}
        <div className="bg-gradient-to-r from-amber-100 via-yellow-100 to-amber-100 rounded-3xl p-5 border-2 border-amber-300 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-2xl shadow-sm shrink-0">
              💡
            </div>
            <div>
              <h4 className="font-urdu text-base font-bold text-amber-950 flex items-center gap-1.5">
                <span>ارہان کے والدین کے لیے رہنمائی:</span>
                <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
              </h4>
              <p className="font-urdu text-xs sm:text-sm text-amber-900 leading-relaxed font-medium">
                روزانہ ارہان کو 10 سے 15 منٹ محبت سے پڑھائیں، ہر درست جواب پر تالیاں بجائیں اور اس کا نام لے کر حوصلہ افزائی کریں۔
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsQuizOpen(true)}
              className="font-urdu px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-sm cursor-pointer"
            >
              ارہان کا ٹیسٹ لیں 🎯
            </button>
            <button
              onClick={() => setIsCertificateOpen(true)}
              className="font-urdu px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm rounded-xl transition-all shadow-sm cursor-pointer flex items-center gap-1.5"
            >
              <Award className="w-4 h-4" />
              <span>سند دیکھیں</span>
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto bg-white border-t border-amber-200 py-4 text-center text-xs text-amber-900 font-urdu">
        <p>
          ارہان کی جادوئی کلاس • پیارے ارہان کے روشن اور سنہرے مستقبل کے لیے محبت کے ساتھ 🌟
        </p>
      </footer>

      {/* Modals */}
      <AIChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        childName={childName}
      />

      <MagicVideoStudio
        isOpen={isVideoOpen}
        onClose={() => setIsVideoOpen(false)}
        childName={childName}
      />

      <QuizModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        childName={childName}
        onEarnStar={handleEarnStar}
      />

      <CertificateModal
        isOpen={isCertificateOpen}
        onClose={() => setIsCertificateOpen(false)}
        childName={childName}
        starsCount={starsCount}
      />

      <TracingCanvasModal
        isOpen={!!tracingTarget}
        onClose={() => setTracingTarget(null)}
        target={tracingTarget}
        childName={childName}
        onComplete={handleCompleteTracing}
      />
    </div>
  );
}
