import React, { useState, useEffect, useMemo } from 'react';
import { PRODUCTS, getProductById } from './data/products';
import { Product, CartItem } from './types';
import { Header } from './components/layout/Header';
import { Hero } from './components/home/Hero';
import { TopPicksSection } from './components/home/TopPicksSection';
import { TopOffers } from './components/home/TopOffers';
import { FeaturedCollections } from './components/home/FeaturedCollections';
import { BrandsInSpotlight } from './components/home/BrandsInSpotlight';
import { BestGadgetsBanner } from './components/home/BestGadgetsBanner';
import { TrendingSection } from './components/home/TrendingSection';
import { ProductSection } from './components/home/ProductSection';
import { ProductCarousel } from './components/home/ProductCarousel';
import { PromoBanner } from './components/home/PromoBanner';
import { BottomNav, BottomNavTab } from './components/layout/BottomNav';
import { ProductDetailsModal } from './components/shop/ProductDetailsModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { WishlistDrawer } from './components/wishlist/WishlistDrawer';
import { CheckoutModal } from './components/checkout/CheckoutModal';
import { ShopPage } from './components/shop/ShopPage';
import { CategoriesScreen } from './components/shop/CategoriesScreen';
import { BetterDealsScreen } from './components/shop/BetterDealsScreen';
import { CartScreen } from './components/cart/CartScreen';
import { OrdersScreen } from './components/orders/OrdersScreen';
import { AccountScreen } from './components/account/AccountScreen';
import { WishlistScreen } from './components/wishlist/WishlistScreen';
import { SupportScreen } from './components/support/SupportScreen';
import { PolicyScreen } from './components/pages/PolicyScreen';
import { InfoModal } from './components/pages/InfoModal';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { LanguageSelectorModal } from './components/common/LanguageSelectorModal';
import { AuthModal } from './components/auth/AuthModal';
import { UserAccountModal } from './components/account/UserAccountModal';
import { NotificationsDrawer } from './components/orders/NotificationsDrawer';
import { TrackOrderModal } from './components/orders/TrackOrderModal';
import { SplashScreen } from './components/common/SplashScreen';
import { DeliveryLocationSheet } from './components/common/DeliveryLocationSheet';
import { SavedAddressesScreen } from './components/account/SavedAddressesScreen';
import { api } from './services/api';
import { loadAndMigrateCart, persistCart, validateCartItem } from './utils/cartStorage';

export type NavTab =
  | 'home'
  | 'categories'
  | 'cart'
  | 'orders'
  | 'account'
  | 'addresses'
  | 'shop'
  | 'deals'
  | 'wishlist'
  | 'support'
  | 'policies';

function getInitialCart(): CartItem[] {
  const { items } = loadAndMigrateCart();
  return items;
}

function AppContent() {
  const { user, isAuthenticated, isLoading, wishlistIds, toggleWishlist } = useAuth();

  // App navigation state & history stack
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [navHistory, setNavHistory] = useState<NavTab[]>(['home']);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string | undefined>(undefined);
  const [selectedPolicy, setSelectedPolicy] = useState<string>('terms');

  // Delivery Location state
  const [deliveryCity, setDeliveryCity] = useState<string>(() => {
    return localStorage.getItem('omazify_delivery_location') || localStorage.getItem('ntix_delivery_city') || '';
  });
  const [deliveryPincode, setDeliveryPincode] = useState<string>(() => {
    return localStorage.getItem('ntix_delivery_pin') || '';
  });
  const [isDeliverySheetOpen, setIsDeliverySheetOpen] = useState(false);

  // Startup Splash Screen
  const [showSplash, setShowSplash] = useState(true);

  // Selected product for modal view
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Cart items with persistent local and cloud sync
  const [cartItems, setCartItems] = useState<CartItem[]>(getInitialCart);

  // Modals & Drawers state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'otp'>('login');
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [accountInitialTab, setAccountInitialTab] = useState<'profile' | 'orders' | 'addresses' | 'security'>('orders');
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [directTrackingOrder, setDirectTrackingOrder] = useState<any>(null);
  const [infoModalTitle, setInfoModalTitle] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [pendingCheckoutAfterAuth, setPendingCheckoutAfterAuth] = useState(false);

  // Automatically proceed to checkout if user just logged in to purchase
  useEffect(() => {
    if (isAuthenticated && pendingCheckoutAfterAuth) {
      setPendingCheckoutAfterAuth(false);
      setIsCheckoutOpen(true);
    }
  }, [isAuthenticated, pendingCheckoutAfterAuth]);

  // Persist cart to localStorage whenever it changes
  useEffect(() => {
    persistCart(cartItems);
    if (user) {
      api.saveCart(cartItems).catch(() => {});
    }
  }, [cartItems, user]);

  // Sync cart from server when user logs in
  useEffect(() => {
    if (user) {
      api.getCart().then((res) => {
        if (res && Array.isArray(res.items) && res.items.length > 0) {
          const validated = res.items
            .map((item: any) => validateCartItem(item))
            .filter((item: any): item is CartItem => item !== null);
          if (validated.length > 0) {
            setCartItems(validated);
          }
        }
      }).catch(() => {});
    }
  }, [user]);

  // App-like Navigation helper
  const navigateTo = (tab: NavTab) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentTab(tab);
    setNavHistory((prev) => (prev[prev.length - 1] === tab ? prev : [...prev, tab]));
  };

  const handleBack = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (navHistory.length > 1) {
      const updated = [...navHistory];
      updated.pop();
      const prevTab = updated[updated.length - 1] || 'home';
      setNavHistory(updated);
      setCurrentTab(prevTab);
    } else {
      setCurrentTab('home');
      setNavHistory(['home']);
    }
  };

  // Header / general navigation handler
  const handleNavigate = (tab: string, categoryFilter?: string, searchVal?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (tab === 'home') {
      navigateTo('home');
    } else if (tab === 'categories') {
      setActiveCategoryFilter(categoryFilter || 'All');
      navigateTo('categories');
    } else if (tab === 'shop') {
      setActiveCategoryFilter(categoryFilter || 'All');
      if (searchVal !== undefined) {
        setSearchQuery(searchVal);
      }
      navigateTo('shop');
    } else if (tab === 'cart') {
      navigateTo('cart');
    } else if (tab === 'orders') {
      if (!isAuthenticated && !isLoading) {
        setAuthModalMode('login');
        setIsAuthModalOpen(true);
      }
      navigateTo('orders');
    } else if (tab === 'account') {
      navigateTo('account');
    } else if (tab === 'addresses') {
      if (!isAuthenticated && !isLoading) {
        setAuthModalMode('login');
        setIsAuthModalOpen(true);
      }
      navigateTo('addresses');
    } else if (tab === 'wishlist') {
      navigateTo('wishlist');
    } else if (tab === 'support') {
      navigateTo('support');
    } else if (tab === 'about' || tab === 'terms' || tab === 'privacy' || tab === 'shipping' || tab === 'return_refund') {
      setSelectedPolicy(tab);
      navigateTo('policies');
    } else {
      setInfoModalTitle(tab);
    }
  };

  const handleSelectDeliveryLocation = (pin: string, city: string, fullAddress?: string) => {
    setDeliveryPincode(pin);
    setDeliveryCity(city);
    localStorage.setItem('ntix_delivery_pin', pin);
    localStorage.setItem('ntix_delivery_city', city);
    localStorage.setItem('omazify_delivery_location', city);
    if (fullAddress) {
      localStorage.setItem('omazify_delivery_address', fullAddress);
    }
  };

  // Cart operations
  const handleAddToCart = (
    product: Product,
    eOrQty?: React.MouseEvent | number,
    size?: string,
    color?: string
  ) => {
    const qty = typeof eOrQty === 'number' ? eOrQty : 1;
    const authoritative = getProductById(product.id) || product;
    const selectedSize = size || (authoritative.sizes ? authoritative.sizes[0] : undefined);
    const selectedColor = color || (authoritative.colors ? authoritative.colors[0].name : undefined);

    setCartItems((prev) => {
      const existingIdx = prev.findIndex(
        (it) =>
          it.product.id === authoritative.id &&
          it.selectedSize === selectedSize &&
          it.selectedColor === selectedColor
      );
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx].quantity += qty;
        return updated;
      }
      return [...prev, { product: authoritative, quantity: qty, selectedSize, selectedColor }];
    });
  };

  const handleBuyNow = (product: Product, quantity: number, size?: string, color?: string) => {
    handleAddToCart(product, quantity, size, color);
    setSelectedProduct(null);
    if (!isAuthenticated) {
      setPendingCheckoutAfterAuth(true);
      setAuthModalMode('login');
      setIsAuthModalOpen(true);
      return;
    }
    setIsCheckoutOpen(true);
  };

  const handleUpdateCartQuantity = (index: number, newQty: number) => {
    setCartItems((prev) => {
      if (newQty <= 0) {
        return prev.filter((_, i) => i !== index);
      }
      const updated = [...prev];
      updated[index].quantity = newQty;
      return updated;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleMoveToWishlist = (product: Product, cartIndex: number) => {
    if (!wishlistIds.has(product.id)) {
      toggleWishlist(product.id);
    }
    handleRemoveCartItem(cartIndex);
  };

  // Wishlist operations
  const handleToggleWishlist = (product: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleRemoveFromWishlist = (product: Product) => {
    toggleWishlist(product.id);
  };

  const cartTotalCount = cartItems.reduce((acc, it) => acc + it.quantity, 0);
  const wishlistProducts = PRODUCTS.filter((p) => wishlistIds.has(p.id));
  const relatedProducts = selectedProduct
    ? PRODUCTS.filter((p) => p.id !== selectedProduct.id && p.category === selectedProduct.category)
    : [];

  const newArrivals = useMemo(() => {
    return PRODUCTS.filter((p) => p.isFeatured).slice(0, 4);
  }, []);

  const bestDeals = useMemo(() => {
    return PRODUCTS.filter((p) => p.discount >= 35).slice(0, 4);
  }, []);

  const recommendedForYou = useMemo(() => {
    return PRODUCTS.filter((p) => p.rating >= 4.5 && p.isBestseller).slice(0, 4);
  }, []);

  const popularProducts = useMemo(() => {
    return PRODUCTS.slice(2, 6);
  }, []);

  const recentlyViewed = useMemo(() => {
    return [PRODUCTS[1], PRODUCTS[3], PRODUCTS[0], PRODUCTS[7]].filter(Boolean);
  }, []);

  return (
    <div className="min-h-screen w-full bg-[#FAFAFA] flex flex-col overflow-x-clip selection:bg-[#FFF9DB] selection:text-[#000000] pb-16 md:pb-0">
      {/* 0. Startup Splash Screen */}
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} minDurationMs={750} />}

      {/* 1. Header (Present on Home, Shop, and general browsing) */}
      {currentTab === 'home' || currentTab === 'shop' ? (
        <>
          <Header
            currentTab={currentTab}
            onNavigate={handleNavigate}
            cartCount={cartTotalCount}
            wishlistCount={wishlistIds.size}
            onOpenCart={() => navigateTo('cart')}
            onOpenWishlist={() => navigateTo('wishlist')}
            products={PRODUCTS}
            onSelectProduct={(p) => setSelectedProduct(p)}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onOpenAuth={(mode) => {
              setAuthModalMode(mode || 'login');
              setIsAuthModalOpen(true);
            }}
            onOpenAccount={(tab) => {
              if (!isAuthenticated && !isLoading) {
                setAuthModalMode('login');
                setIsAuthModalOpen(true);
                return;
              }
              setAccountInitialTab(tab || 'orders');
              setIsAccountModalOpen(true);
            }}
            onOpenNotifications={() => {
              setIsNotificationsOpen(true);
            }}
            deliveryCity={deliveryCity}
            deliveryPincode={deliveryPincode}
            onOpenDeliveryLocation={() => setIsDeliverySheetOpen(true)}
          />
        </>
      ) : null}

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-full">
        {/* TAB 1: HOME */}
        {currentTab === 'home' && (
          <div className="space-y-4 sm:space-y-6 py-2">
            {/* SECTION 1: Hero Banner */}
            <Hero
              onCtaClick={(cat) => {
                setActiveCategoryFilter(cat);
                navigateTo('shop');
              }}
            />

            {/* SECTION 2: Top Picks Product Carousel (Replaced Categories) */}
            <TopPicksSection
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
            />

            {/* SECTION 3: Top Offers */}
            <TopOffers
              onSelectOffer={(catTarget) => {
                setActiveCategoryFilter(catTarget);
                navigateTo('shop');
              }}
            />

            {/* SECTION 4: Featured Collections */}
            <FeaturedCollections
              onSelectCollection={(catTarget) => {
                setActiveCategoryFilter(catTarget);
                navigateTo('shop');
              }}
            />

            {/* Brands in Spotlight */}
            <BrandsInSpotlight
              onSelectCategory={(catTarget) => {
                setActiveCategoryFilter(catTarget);
                navigateTo('shop');
              }}
              onViewAll={() => {
                setActiveCategoryFilter('All');
                navigateTo('shop');
              }}
            />

            {/* SECTION 5: TRENDING NOW */}
            <TrendingSection
              products={PRODUCTS}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onViewAll={() => {
                setActiveCategoryFilter('All');
                navigateTo('shop');
              }}
            />

            {/* SECTION 6: Recommended For You */}
            <ProductSection
              title="Recommended For You"
              tag="CURATED PICKS"
              subtitle="Hand-selected based on top customer reviews"
              products={recommendedForYou}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onViewAll={() => {
                setActiveCategoryFilter('All');
                navigateTo('shop');
              }}
              variant="tinted"
            />

            {/* SECTION 7: New Arrivals */}
            <ProductSection
              title="New Arrivals"
              tag="JUST LAUNCHED 2026"
              subtitle="Fresh drops across footwear, gear and watches"
              products={newArrivals}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onViewAll={() => {
                setActiveCategoryFilter('All');
                navigateTo('shop');
              }}
              variant="white"
            />

            {/* SECTION 8: Best Deals */}
            <ProductSection
              title="Best Deals"
              tag="EXTRA DISCOUNTS"
              subtitle="Deepest price cuts with Cash on Delivery"
              products={bestDeals}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onViewAll={() => {
                setActiveCategoryFilter('All');
                navigateTo('shop');
              }}
              variant="mauve"
            />

            {/* Best Gadgets & Appliances Hero Banner */}
            <BestGadgetsBanner
              onExplore={() => {
                setActiveCategoryFilter('Accessories');
                navigateTo('shop');
              }}
            />

            {/* SECTION 9: Popular Products Carousel */}
            <ProductCarousel
              title="Popular Products"
              tag="FASTEST SELLING • CASH ON DELIVERY"
              products={popularProducts}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
            />

            {/* SECTION 10: Recently Viewed */}
            <ProductSection
              title="Recently Viewed & Top Rated"
              tag="BROWSED ITEMS"
              subtitle="Pick up where you left off"
              products={recentlyViewed}
              onSelectProduct={(p) => setSelectedProduct(p)}
              onAddToCart={handleAddToCart}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onViewAll={() => {
                setActiveCategoryFilter('All');
                navigateTo('shop');
              }}
              variant="white"
            />

            {/* SECTION 11: Promotional Banner */}
            <PromoBanner
              onExplore={() => {
                setActiveCategoryFilter('Men');
                navigateTo('shop');
              }}
            />
          </div>
        )}

        {/* TAB 2: CATEGORIES SCREEN */}
        {currentTab === 'categories' && (
          <CategoriesScreen
            products={PRODUCTS}
            initialCategory={activeCategoryFilter || 'All'}
            cartCount={cartTotalCount}
            onOpenCart={() => navigateTo('cart')}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
            wishlistIds={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
            onBack={handleBack}
          />
        )}

        {/* TAB 3: BETTER DEALS SCREEN */}
        {currentTab === 'deals' && (
          <BetterDealsScreen
            products={PRODUCTS}
            cartCount={cartTotalCount}
            onOpenCart={() => navigateTo('cart')}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
            wishlistIds={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
            onBack={handleBack}
          />
        )}

        {/* TAB 3.5: FULL SHOP COLLECTION (for search / explore) */}
        {currentTab === 'shop' && (
          <ShopPage
            products={PRODUCTS}
            initialCategory="All"
            isOffersView={false}
            initialSearchQuery={searchQuery}
            onSearchQueryChange={setSearchQuery}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
            wishlistIds={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
          />
        )}

        {/* TAB 4: CART SCREEN */}
        {currentTab === 'cart' && (
          <CartScreen
            items={cartItems}
            onUpdateQuantity={handleUpdateCartQuantity}
            onRemoveItem={handleRemoveCartItem}
            onProceedToCheckout={() => {
              if (!isAuthenticated) {
                setPendingCheckoutAfterAuth(true);
                setAuthModalMode('login');
                setIsAuthModalOpen(true);
                return;
              }
              setIsCheckoutOpen(true);
            }}
            onContinueShopping={() => navigateTo('shop')}
            onMoveToWishlist={handleMoveToWishlist}
            onSelectProduct={(p) => setSelectedProduct(p)}
            deliveryCity={deliveryCity}
            deliveryPincode={deliveryPincode}
            onChangeLocation={() => setIsDeliverySheetOpen(true)}
          />
        )}

        {/* TAB 5: ORDERS SCREEN */}
        {currentTab === 'orders' && (
          <OrdersScreen
            onBack={handleBack}
            onStartShopping={() => navigateTo('home')}
            onOpenAuth={() => {
              setAuthModalMode('login');
              setIsAuthModalOpen(true);
            }}
          />
        )}

        {/* TAB 6: ACCOUNT SCREEN */}
        {currentTab === 'account' && (
          <AccountScreen
            onBack={handleBack}
            onOpenOrders={() => navigateTo('orders')}
            onOpenWishlist={() => navigateTo('wishlist')}
            onOpenNotifications={() => {
              setIsNotificationsOpen(true);
            }}
            onOpenSupport={() => navigateTo('support')}
            onOpenPolicies={(title) => {
              setSelectedPolicy(title);
              navigateTo('policies');
            }}
            onOpenAddresses={() => {
              if (!isAuthenticated && !isLoading) {
                setAuthModalMode('login');
                setIsAuthModalOpen(true);
              }
              navigateTo('addresses');
            }}
            onOpenAuth={(mode) => {
              setAuthModalMode(mode || 'login');
              setIsAuthModalOpen(true);
            }}
            wishlistCount={wishlistIds.size}
          />
        )}

        {/* TAB 6.5: SAVED ADDRESSES SCREEN */}
        {currentTab === 'addresses' && (
          <SavedAddressesScreen
            onBack={handleBack}
            onSelectAddressForCheckout={(addr) => {
              localStorage.setItem('ntix_delivery_pin', addr.pincode);
              localStorage.setItem('ntix_delivery_city', addr.city);
              setDeliveryPincode(addr.pincode);
              setDeliveryCity(addr.city);
            }}
          />
        )}

        {/* TAB 7: WISHLIST SCREEN */}
        {currentTab === 'wishlist' && (
          <WishlistScreen
            wishlistProducts={wishlistProducts}
            onBack={handleBack}
            onRemoveFromWishlist={handleRemoveFromWishlist}
            onAddToCart={(p, e) => handleAddToCart(p, e)}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onStartShopping={() => navigateTo('shop')}
          />
        )}

        {/* TAB 8: CUSTOMER SUPPORT SCREEN */}
        {currentTab === 'support' && (
          <SupportScreen onBack={handleBack} />
        )}

        {/* TAB 9: POLICIES SCREEN */}
        {currentTab === 'policies' && (
          <PolicyScreen
            initialPolicy={selectedPolicy}
            onBack={handleBack}
          />
        )}
      </main>

      {/* BOTTOM NAVIGATION BAR */}
      <BottomNav
        currentTab={currentTab}
        onNavigateTab={(tab: BottomNavTab) => {
          setSelectedProduct(null);
          setIsCartOpen(false);
          setIsWishlistOpen(false);
          setIsAccountModalOpen(false);
          setIsCheckoutOpen(false);
          setIsNotificationsOpen(false);
          setIsDeliverySheetOpen(false);
          if (tab === 'deals') {
            setActiveCategoryFilter('All');
            navigateTo('deals');
          } else {
            navigateTo(tab);
          }
        }}
        cartCount={cartTotalCount}
        activeCategoryFilter={activeCategoryFilter}
      />

      {/* Delivery Location Bottom Sheet */}
      <DeliveryLocationSheet
        isOpen={isDeliverySheetOpen}
        onClose={() => setIsDeliverySheetOpen(false)}
        currentCity={deliveryCity}
        currentPincode={deliveryPincode}
        onSelectLocation={handleSelectDeliveryLocation}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authModalMode}
      />

      {/* User Account Modal */}
      <UserAccountModal
        isOpen={isAccountModalOpen}
        onClose={() => setIsAccountModalOpen(false)}
        initialTab={accountInitialTab}
      />

      {/* Product Details Modal */}
      {selectedProduct && (
        <ProductDetailsModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={(p, qty, size, color) => handleAddToCart(p, qty, size, color)}
          onBuyNow={handleBuyNow}
          isWishlisted={wishlistIds.has(selectedProduct.id)}
          onToggleWishlist={handleToggleWishlist}
          relatedProducts={relatedProducts}
          onSelectProduct={(p) => setSelectedProduct(p)}
          cartCount={cartItems.reduce((acc, it) => acc + it.quantity, 0)}
          onOpenCart={() => {
            setSelectedProduct(null);
            setIsCartOpen(true);
          }}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          if (!isAuthenticated) {
            setPendingCheckoutAfterAuth(true);
            setAuthModalMode('login');
            setIsAuthModalOpen(true);
            return;
          }
          setIsCheckoutOpen(true);
        }}
        onContinueShopping={() => {
          setIsCartOpen(false);
          navigateTo('shop');
        }}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlistProducts}
        onRemoveFromWishlist={handleRemoveFromWishlist}
        onAddToCart={(p, e) => handleAddToCart(p, e)}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onContinueShopping={() => {
          setIsWishlistOpen(false);
          navigateTo('shop');
        }}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        onOrderSuccess={() => {
          setCartItems([]);
        }}
        onViewOrders={() => {
          setIsCheckoutOpen(false);
          navigateTo('orders');
        }}
        onTrackOrder={(ord) => {
          setIsCheckoutOpen(false);
          setDirectTrackingOrder(ord);
        }}
        onRequireLogin={() => {
          setPendingCheckoutAfterAuth(true);
          setAuthModalMode('login');
          setIsAuthModalOpen(true);
        }}
      />

      {/* Notifications Drawer */}
      <NotificationsDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onSelectOrder={(ordId) => {
          setIsNotificationsOpen(false);
          api.getOrderById(ordId).then((res) => {
            if (res && res.order) setDirectTrackingOrder(res.order);
          }).catch(() => {
            navigateTo('orders');
          });
        }}
      />

      {/* Direct Tracking Modal */}
      <TrackOrderModal
        order={directTrackingOrder}
        onClose={() => setDirectTrackingOrder(null)}
      />

      {/* Info Modal */}
      <InfoModal
        title={infoModalTitle}
        onClose={() => setInfoModalTitle(null)}
      />

      {/* Complete Multi-Language Selector Modal */}
      <LanguageSelectorModal />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
