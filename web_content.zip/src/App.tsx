import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  CustomFont,
  ExtractedLineInfo,
  ExtractedTextBlock,
  OverlayElement,
  PageSizePreset,
  PdfDocumentTab,
  PdfPageModel,
  StudioSettings,
  TextOverlayElement,
  ToolMode,
  UILanguage,
} from './types/pdf';
import {
  exportDocumentToDocxBytes,
  exportEditedPdf,
  exportPageToImageBlob,
  parsePdfIntoStudio,
  renderOriginalPagePreviews,
  resolveTextRenderPlans,
} from './utils/pdfEngine';
import {
  AUTOSAVE_INTERVAL_MS,
  clearAutosaveStorage,
  loadAutosavePayload,
  loadPdfBytesFromDb,
  saveAutosaveSnapshot,
} from './utils/autosave';
import {
  detectInstalledSystemFonts,
  loadGoogleFontByName,
  loadLocalDeviceFontsViaApi,
  loadPersistedCustomFonts,
  loadPersistedGoogleFonts,
  registerCustomFontFace,
} from './utils/fonts';
import { TopBar } from './components/TopBar';
import { LeftSidebar } from './components/LeftSidebar';
import { PdfWorkspace } from './components/PdfWorkspace';
import { RightInspector } from './components/RightInspector';
import { FontManagerModal } from './components/FontManagerModal';
import { SignatureModal } from './components/SignatureModal';
import { SettingsModal } from './components/SettingsModal';
import { HoverTooltipLayer } from './components/HoverTooltipLayer';
import { OfflineIndicator } from './components/OfflineIndicator';

const SETTINGS_STORAGE_KEY = 'lipipdf_settings_v1';

const DEFAULT_SETTINGS: StudioSettings = {
  defaultScript: 'bn',
  autosaveEnabled: true,
  paragraphGrouping: true,
  autoNormalizeText: true,
  exportImageQuality: 'fullhd',
  defaultPageSize: 'a4',
  defaultMaskPadding: 1.5,
};

function loadInitialSettings(): StudioSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function getPageDimensionsForPreset(
  preset: PageSizePreset
): { widthPt: number; heightPt: number } {
  if (preset === 'letter') return { widthPt: 612, heightPt: 792 };
  if (preset === 'legal') return { widthPt: 612, heightPt: 1008 };
  return { widthPt: 595, heightPt: 842 };
}

function triggerDownload(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export default function App() {
  const [lang, setLang] = useState<UILanguage>('bn');
  const [documents, setDocuments] = useState<PdfDocumentTab[]>([]);
  const [activeDocId, setActiveDocId] = useState<string | null>(null);
  const [selectedOverlayId, setSelectedOverlayId] = useState<string | null>(null);
  const [customFonts, setCustomFonts] = useState<CustomFont[]>([]);
  const [scrollRequest, setScrollRequest] = useState<{
    pageId: string;
    nonce: number;
  } | null>(null);

  const [settings, setSettings] = useState<StudioSettings>(loadInitialSettings);
  const [toolMode, setToolMode] = useState<ToolMode>('edit-text');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [isFontsModalOpen, setIsFontsModalOpen] = useState<boolean>(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState<boolean>(false);
  const [isPickingBgColor, setIsPickingBgColor] = useState<boolean>(false);
  const [showPagesDrawer, setShowPagesDrawer] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [lastAutosavedAt, setLastAutosavedAt] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const settingsRef = useRef<StudioSettings>(settings);
  settingsRef.current = settings;

  const updateSettings = useCallback((patch: Partial<StudioSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage error
      }
      return next;
    });
  }, []);

  const lastTextCommitRef = useRef<number>(0);
  const docsRef = useRef<PdfDocumentTab[]>(documents);
  const activeDocIdRef = useRef<string | null>(activeDocId);
  const restoredAutosaveRef = useRef<boolean>(false);

  docsRef.current = documents;
  activeDocIdRef.current = activeDocId;

  const activeDoc = documents.find((d) => d.id === activeDocId) || null;
  const pages = activeDoc?.pages || [];
  const overlays = activeDoc?.overlays || [];
  const activePageId = activeDoc?.activePageId || '';
  const detectedFonts = activeDoc?.detectedFonts || [];
  const zoom = activeDoc?.zoom ?? 1.0;

  const updateActiveDoc = useCallback(
    (updater: (doc: PdfDocumentTab) => PdfDocumentTab) => {
      const targetId = activeDocIdRef.current;
      if (!targetId) return;
      setDocuments((prev) =>
        prev.map((doc) => (doc.id === targetId ? updater(doc) : doc))
      );
    },
    []
  );

  const updateDocWithUndo = useCallback(
    (
      updater: (doc: PdfDocumentTab) => {
        pages?: PdfPageModel[];
        overlays?: OverlayElement[];
        activePageId?: string;
        detectedFonts?: PdfDocumentTab['detectedFonts'];
      }
    ) => {
      updateActiveDoc((doc) => {
        const changes = updater(doc);
        return {
          ...doc,
          ...changes,
          undoStack: [
            ...doc.undoStack.slice(-29),
            { pages: doc.pages, overlays: doc.overlays },
          ],
          redoStack: [],
        };
      });
    },
    [updateActiveDoc]
  );

  // Automatically bring installed system fonts, saved Google fonts & previously imported TTFs into the app
  useEffect(() => {
    let active = true;
    (async () => {
      const [persisted, googleSaved, sysFonts] = await Promise.all([
        loadPersistedCustomFonts(),
        loadPersistedGoogleFonts(),
        Promise.resolve(detectInstalledSystemFonts()),
      ]);
      if (!active) return;
      setCustomFonts((prev) => {
        const merged = new Map<string, CustomFont>();
        for (const f of [...sysFonts, ...googleSaved, ...persisted, ...prev]) {
          merged.set(f.id, f);
        }
        return Array.from(merged.values());
      });
    })();
    return () => {
      active = false;
    };
  }, []);

  // Restore autosaved session from localStorage + IndexedDB on mount
  useEffect(() => {
    if (restoredAutosaveRef.current) return;
    restoredAutosaveRef.current = true;

    const saved = loadAutosavePayload();
    if (!saved || saved.documents.length === 0) return;

    let cancelled = false;
    (async () => {
      setIsLoading(true);
      try {
        const needsSchemaUpgrade = !saved.schemaVersion || saved.schemaVersion < 2;
        const rehydratedDocs: PdfDocumentTab[] = [];
        for (const docMeta of saved.documents) {
          const pdfBytes = await loadPdfBytesFromDb(docMeta.id);
          if (needsSchemaUpgrade && pdfBytes) {
            // Re-extract clean paragraph blocks & repaired Bangla/Arabic/Urdu/Persian text while preserving saved overlays
            const parsed = await parsePdfIntoStudio(pdfBytes, customFonts, {
              paragraphGrouping: settingsRef.current.paragraphGrouping,
              autoNormalizeText: settingsRef.current.autoNormalizeText,
            });
            const mergedPages: PdfPageModel[] = docMeta.pages.map((savedPage, idx) => {
              const fresh =
                savedPage.originalPageIndex !== null
                  ? parsed.pages[savedPage.originalPageIndex] || parsed.pages[idx]
                  : undefined;
              return {
                ...savedPage,
                previewDataUrl: fresh?.previewDataUrl || '',
                thumbnailDataUrl: fresh?.thumbnailDataUrl || '',
                extractedBlocks:
                  fresh?.extractedBlocks.map((b) => ({ ...b, pageId: savedPage.id })) ||
                  savedPage.extractedBlocks,
              };
            });
            if (mergedPages.length > 0) {
              rehydratedDocs.push({
                id: docMeta.id,
                docName: docMeta.docName,
                originalBytes: pdfBytes,
                pages: mergedPages,
                overlays: docMeta.overlays || [],
                activePageId: mergedPages.some((p) => p.id === docMeta.activePageId)
                  ? docMeta.activePageId
                  : mergedPages[0].id,
                detectedFonts:
                  parsed.detectedFonts.length > 0
                    ? parsed.detectedFonts
                    : docMeta.detectedFonts || [],
                undoStack: [],
                redoStack: [],
                zoom: docMeta.zoom || 1.0,
              });
              continue;
            }
          }

          const previewMap = pdfBytes
            ? await renderOriginalPagePreviews(
                pdfBytes,
                docMeta.pages.map((p) => p.originalPageIndex)
              )
            : new Map();

          const fullPages: PdfPageModel[] = docMeta.pages.map((p) => {
            const rendered =
              p.originalPageIndex !== null
                ? previewMap.get(p.originalPageIndex)
                : undefined;
            return {
              ...p,
              previewDataUrl: rendered?.previewDataUrl || '',
              thumbnailDataUrl: rendered?.thumbnailDataUrl || '',
            };
          });

          if (fullPages.length > 0) {
            rehydratedDocs.push({
              id: docMeta.id,
              docName: docMeta.docName,
              originalBytes: pdfBytes,
              pages: fullPages,
              overlays: docMeta.overlays || [],
              activePageId: fullPages.some((p) => p.id === docMeta.activePageId)
                ? docMeta.activePageId
                : fullPages[0].id,
              detectedFonts: docMeta.detectedFonts || [],
              undoStack: [],
              redoStack: [],
              zoom: docMeta.zoom || 1.0,
            });
          }
        }

        if (!cancelled && rehydratedDocs.length > 0) {
          setDocuments(rehydratedDocs);
          const restoredActive =
            rehydratedDocs.find((d) => d.id === saved.activeDocId)?.id ||
            rehydratedDocs[0].id;
          setActiveDocId(restoredActive);
        }
      } catch {
        await clearAutosaveStorage();
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  // 30-second localStorage autosave interval + immediate save on hide/unload
  useEffect(() => {
    const runAutosave = async () => {
      if (!settingsRef.current.autosaveEnabled || docsRef.current.length === 0) return;
      const savedTs = await saveAutosaveSnapshot(docsRef.current, activeDocIdRef.current);
      if (savedTs) setLastAutosavedAt(savedTs);
    };

    const intervalId = window.setInterval(() => void runAutosave(), AUTOSAVE_INTERVAL_MS);

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        void runAutosave();
      }
    };
    const onPageHide = () => void runAutosave();

    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pagehide', onPageHide);

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pagehide', onPageHide);
    };
  }, []);

  const openPdfDocuments = useCallback(
    async (entries: Array<{ bytes: Uint8Array; fileName: string }>) => {
      if (entries.length === 0) return;
      setIsLoading(true);
      setErrorMsg(null);
      try {
        const openedTabs: PdfDocumentTab[] = [];
        for (let i = 0; i < entries.length; i++) {
          const { bytes, fileName } = entries[i];
          const { pages: parsedPages, detectedFonts: fonts } =
            await parsePdfIntoStudio(bytes, customFonts, {
              paragraphGrouping: settingsRef.current.paragraphGrouping,
              autoNormalizeText: settingsRef.current.autoNormalizeText,
            });
          if (parsedPages.length > 0) {
            const docId = `doc-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`;
            openedTabs.push({
              id: docId,
              docName: fileName,
              originalBytes: bytes,
              pages: parsedPages,
              overlays: [],
              activePageId: parsedPages[0].id,
              detectedFonts: fonts,
              undoStack: [],
              redoStack: [],
              zoom: 1.0,
            });
          }
        }

        if (openedTabs.length > 0) {
          setDocuments((prev) => [...prev, ...openedTabs]);
          setActiveDocId(openedTabs[openedTabs.length - 1].id);
          setSelectedOverlayId(null);
          setShowPagesDrawer(false);
        }
      } catch (err) {
        setErrorMsg(
          err instanceof Error ? err.message : 'Failed to parse PDF document.'
        );
      } finally {
        setIsLoading(false);
      }
    },
    [customFonts]
  );

  const handleUploadPdfFiles = useCallback(
    async (files: File[]) => {
      const entries: Array<{ bytes: Uint8Array; fileName: string }> = [];
      for (const file of files) {
        const buffer = await file.arrayBuffer();
        entries.push({ bytes: new Uint8Array(buffer), fileName: file.name });
      }
      await openPdfDocuments(entries);
    },
    [openPdfDocuments]
  );

  const handleCloseDocument = useCallback((docId: string) => {
    setDocuments((prev) => {
      const idx = prev.findIndex((d) => d.id === docId);
      const next = prev.filter((d) => d.id !== docId);
      if (activeDocIdRef.current === docId) {
        const fallback = next[Math.min(idx, next.length - 1)] || null;
        setActiveDocId(fallback ? fallback.id : null);
        setSelectedOverlayId(null);
      }
      if (next.length === 0) {
        void clearAutosaveStorage();
      }
      return next;
    });
  }, []);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const handleToggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        if (document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
          setIsFullscreen(true);
          return;
        }
      } else if (document.exitFullscreen) {
        await document.exitFullscreen();
        setIsFullscreen(false);
        return;
      }
    } catch {
      // Fallback inside sandboxed iframes
    }
    setIsFullscreen((v) => !v);
    setShowPagesDrawer(false);
    setSelectedOverlayId(null);
  };

  const handleUndo = useCallback(() => {
    if (!activeDoc || activeDoc.undoStack.length === 0) return;
    updateActiveDoc((doc) => {
      if (doc.undoStack.length === 0) return doc;
      const prevSnap = doc.undoStack[doc.undoStack.length - 1];
      const nextActivePage = prevSnap.pages.some((p) => p.id === doc.activePageId)
        ? doc.activePageId
        : prevSnap.pages[0]?.id || '';
      return {
        ...doc,
        pages: prevSnap.pages,
        overlays: prevSnap.overlays,
        activePageId: nextActivePage,
        undoStack: doc.undoStack.slice(0, -1),
        redoStack: [...doc.redoStack, { pages: doc.pages, overlays: doc.overlays }],
      };
    });
  }, [activeDoc, updateActiveDoc]);

  const handleRedo = useCallback(() => {
    if (!activeDoc || activeDoc.redoStack.length === 0) return;
    updateActiveDoc((doc) => {
      if (doc.redoStack.length === 0) return doc;
      const nextSnap = doc.redoStack[doc.redoStack.length - 1];
      const nextActivePage = nextSnap.pages.some((p) => p.id === doc.activePageId)
        ? doc.activePageId
        : nextSnap.pages[0]?.id || '';
      return {
        ...doc,
        pages: nextSnap.pages,
        overlays: nextSnap.overlays,
        activePageId: nextActivePage,
        undoStack: [...doc.undoStack, { pages: doc.pages, overlays: doc.overlays }],
        redoStack: doc.redoStack.slice(0, -1),
      };
    });
  }, [activeDoc, updateActiveDoc]);

  const handleDeleteOverlay = useCallback(
    (id: string) => {
      updateDocWithUndo((doc) => ({
        overlays: doc.overlays.filter((o) => o.id !== id),
      }));
      if (selectedOverlayId === id) setSelectedOverlayId(null);
    },
    [selectedOverlayId, updateDocWithUndo]
  );

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isEditingInput =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable);

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (isEditingInput) return;
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
        return;
      }

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        if (isEditingInput) return;
        e.preventDefault();
        handleRedo();
        return;
      }

      if (
        (e.key === 'Delete' || e.key === 'Backspace') &&
        !isEditingInput &&
        selectedOverlayId
      ) {
        e.preventDefault();
        handleDeleteOverlay(selectedOverlayId);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleDeleteOverlay, handleRedo, handleUndo, selectedOverlayId]);

  const handleSelectPage = useCallback(
    (pageId: string) => {
      updateActiveDoc((doc) =>
        doc.activePageId === pageId ? doc : { ...doc, activePageId: pageId }
      );
    },
    [updateActiveDoc]
  );

  const handleJumpToPage = useCallback(
    (pageId: string) => {
      updateActiveDoc((doc) => ({ ...doc, activePageId: pageId }));
      setScrollRequest({ pageId, nonce: Date.now() });
    },
    [updateActiveDoc]
  );

  const handleActivateExtractedBlock = (block: ExtractedTextBlock) => {
    if (!activeDoc) return;
    const existing = activeDoc.overlays.find(
      (o): o is TextOverlayElement =>
        o.kind === 'text' &&
        (o.sourceBlockId === block.id || Boolean(o.mergedBlockIds?.includes(block.id)))
    );
    if (existing) {
      setSelectedOverlayId(existing.id);
      return;
    }

    const pageObj = activeDoc.pages.find((p) => p.id === block.pageId);
    const pageWidthPt = pageObj?.widthPt ?? 595;
    const isPara = (block.lines?.length ?? 1) > 1;
    const align = block.textAlign || (block.isRtl ? 'right' : 'left');
    const newOv: TextOverlayElement = {
      id: `ov-${block.id}`,
      kind: 'text',
      pageId: block.pageId,
      sourceBlockId: block.id,
      mergedBlockIds: [block.id],
      originalText: block.originalText,
      originalColor: block.color,
      originalFontId: block.matchedFontId,
      originalFontSize: block.fontSize,
      originalX: block.x,
      originalY: block.y,
      sourceSegments: block.segments,
      sourceLines: block.lines,
      isParagraph: isPara,
      hasCustomWidth: align === 'center' || align === 'right',
      maxPageWidth: Math.max(60, pageWidthPt - block.x - 16),
      text: block.originalText,
      x: block.x,
      y: block.y,
      width: Math.max(block.width, 40),
      height: block.height,
      opacity: 1,
      fontId: block.matchedFontId,
      rawFontName: block.rawFontName,
      fontSize: block.fontSize,
      fontWeight: block.fontWeight,
      fontStyle: block.fontStyle,
      textAlign: align,
      lineHeight: block.lineHeight,
      letterSpacing: 0,
      color: block.color,
      maskRect: {
        x: block.x,
        y: block.y,
        width: block.width,
        height: block.height,
        padding: settings.defaultMaskPadding,
        color: block.bgColor,
        enabled: true,
      },
    };
    updateDocWithUndo((doc) => ({
      overlays: [...doc.overlays, newOv],
      activePageId: block.pageId,
    }));
    setSelectedOverlayId(newOv.id);
  };

  const handleActivateMultiBlocks = (
    pageId: string,
    blocks: ExtractedTextBlock[],
    overlappingOverlays: TextOverlayElement[]
  ): string | null => {
    if (!activeDoc) return null;
    if (blocks.length === 0 && overlappingOverlays.length === 0) return null;

    if (blocks.length === 1 && overlappingOverlays.length === 0) {
      handleActivateExtractedBlock(blocks[0]);
      setToolMode('edit-text');
      return `ov-${blocks[0].id}`;
    }
    if (blocks.length === 0 && overlappingOverlays.length === 1) {
      setSelectedOverlayId(overlappingOverlays[0].id);
      setToolMode('edit-text');
      return overlappingOverlays[0].id;
    }

    const pageObj = activeDoc.pages.find((p) => p.id === pageId);
    const pageWidthPt = pageObj?.widthPt ?? 595;

    interface LineEntry {
      currentText: string;
      originalText: string;
      x: number;
      y: number;
      width: number;
      height: number;
      lineInfo?: ExtractedLineInfo;
      hasEditedStyleOrPos: boolean;
    }

    const lineEntries: LineEntry[] = [];
    const mergedIdsSet = new Set<string>();
    const absorbedOverlayIds = new Set<string>(overlappingOverlays.map((o) => o.id));

    for (const blk of blocks) {
      mergedIdsSet.add(blk.id);
      if (blk.lines && blk.lines.length > 0) {
        for (const ln of blk.lines) {
          lineEntries.push({
            currentText: ln.text,
            originalText: ln.text,
            x: ln.x,
            y: ln.y,
            width: ln.width,
            height: ln.height,
            lineInfo: ln,
            hasEditedStyleOrPos: false,
          });
        }
      } else {
        lineEntries.push({
          currentText: blk.originalText,
          originalText: blk.originalText,
          x: blk.x,
          y: blk.y,
          width: blk.width,
          height: blk.height,
          lineInfo: {
            text: blk.originalText,
            x: blk.x,
            y: blk.y,
            width: blk.width,
            height: blk.height,
            segments: blk.segments || [],
          },
          hasEditedStyleOrPos: false,
        });
      }
    }

    for (const ov of overlappingOverlays) {
      if (ov.sourceBlockId) mergedIdsSet.add(ov.sourceBlockId);
      for (const mid of ov.mergedBlockIds || []) mergedIdsSet.add(mid);

      const splitLines = ov.text.split('\n');
      if (ov.sourceLines && ov.sourceLines.length === splitLines.length) {
        ov.sourceLines.forEach((sl, idx) => {
          lineEntries.push({
            currentText: splitLines[idx],
            originalText: sl.text,
            x: sl.x,
            y: sl.y,
            width: sl.width,
            height: sl.height,
            lineInfo: sl,
            hasEditedStyleOrPos:
              (ov.originalColor && ov.color !== ov.originalColor) ||
              (ov.originalFontId && ov.fontId !== ov.originalFontId) ||
              (ov.originalFontSize && ov.fontSize !== ov.originalFontSize) ||
              false,
          });
        });
      } else {
        const lineStep = ov.fontSize * ov.lineHeight;
        splitLines.forEach((txt, idx) => {
          lineEntries.push({
            currentText: txt,
            originalText: ov.originalText && idx === 0 ? ov.originalText : txt,
            x: ov.x,
            y: ov.y + idx * lineStep,
            width: ov.width,
            height: lineStep,
            lineInfo: undefined,
            hasEditedStyleOrPos: true,
          });
        });
      }
    }

    if (lineEntries.length === 0) return null;

    lineEntries.sort((a, b) => {
      if (Math.abs(a.y - b.y) > 4) return a.y - b.y;
      return a.x - b.x;
    });

    const minX = Math.min(...lineEntries.map((l) => l.x));
    const minY = Math.min(...lineEntries.map((l) => l.y));
    const maxX = Math.max(...lineEntries.map((l) => l.x + l.width));
    const maxY = Math.max(...lineEntries.map((l) => l.y + l.height));

    const firstBlock = blocks
      .slice()
      .sort((a, b) => (Math.abs(a.y - b.y) > 4 ? a.y - b.y : a.x - b.x))[0];
    const firstOv = overlappingOverlays
      .slice()
      .sort((a, b) => (Math.abs(a.y - b.y) > 4 ? a.y - b.y : a.x - b.x))[0];

    const useBlockAsStyleSource =
      firstBlock && (!firstOv || firstBlock.y <= firstOv.y);

    const fontId = useBlockAsStyleSource
      ? firstBlock.matchedFontId
      : firstOv.fontId;
    const rawFontName = useBlockAsStyleSource
      ? firstBlock.rawFontName
      : firstOv.rawFontName;
    const fontSize = useBlockAsStyleSource
      ? firstBlock.fontSize
      : firstOv.fontSize;
    const fontWeight = useBlockAsStyleSource
      ? firstBlock.fontWeight
      : firstOv.fontWeight;
    const fontStyle = useBlockAsStyleSource
      ? firstBlock.fontStyle
      : firstOv.fontStyle;
    const color = useBlockAsStyleSource ? firstBlock.color : firstOv.color;
    const bgColor = useBlockAsStyleSource
      ? firstBlock.bgColor
      : firstOv.maskRect?.color || '#ffffff';
    const lineHeight = useBlockAsStyleSource
      ? firstBlock.lineHeight
      : firstOv.lineHeight;
    const textAlign = useBlockAsStyleSource
      ? firstBlock.textAlign || (firstBlock.isRtl ? 'right' : 'left')
      : firstOv.textAlign;

    const allMergedIds = Array.from(mergedIdsSet);
    const canTrackSourceLines =
      allMergedIds.length > 0 &&
      lineEntries.every((l) => Boolean(l.lineInfo) && !l.hasEditedStyleOrPos);

    const id = `ov-multi-${Date.now()}`;
    const newOv: TextOverlayElement = {
      id,
      kind: 'text',
      pageId,
      sourceBlockId: allMergedIds[0],
      mergedBlockIds: allMergedIds,
      originalText: canTrackSourceLines
        ? lineEntries.map((l) => l.originalText).join('\n')
        : undefined,
      originalColor: canTrackSourceLines ? color : undefined,
      originalFontId: canTrackSourceLines ? fontId : undefined,
      originalFontSize: canTrackSourceLines ? fontSize : undefined,
      originalX: canTrackSourceLines ? minX : undefined,
      originalY: canTrackSourceLines ? minY : undefined,
      sourceLines: canTrackSourceLines
        ? lineEntries.map((l) => l.lineInfo!)
        : undefined,
      isParagraph: true,
      hasCustomWidth: false,
      maxPageWidth: Math.max(60, pageWidthPt - minX - 16),
      text: lineEntries.map((l) => l.currentText).join('\n'),
      x: minX,
      y: minY,
      width: Math.max(40, maxX - minX),
      height: Math.max(16, maxY - minY),
      opacity: 1,
      fontId,
      rawFontName,
      fontSize,
      fontWeight,
      fontStyle,
      textAlign,
      lineHeight,
      letterSpacing: 0,
      color,
      maskRect:
        allMergedIds.length > 0 || overlappingOverlays.some((o) => o.maskRect?.enabled)
          ? {
              x: minX,
              y: minY,
              width: Math.max(20, maxX - minX),
              height: Math.max(12, maxY - minY),
              padding: settings.defaultMaskPadding,
              color: bgColor,
              enabled: true,
            }
          : undefined,
    };

    updateDocWithUndo((doc) => ({
      overlays: [
        ...doc.overlays.filter((o) => !absorbedOverlayIds.has(o.id)),
        newOv,
      ],
      activePageId: pageId,
    }));
    setSelectedOverlayId(id);
    setToolMode('edit-text');
    return id;
  };

  const handleAbsorbBelowBlock = useCallback(
    (overlayId: string, belowBlock: ExtractedTextBlock) => {
      updateActiveDoc((doc) => {
        const pageObj = doc.pages.find((p) => p.id === belowBlock.pageId);
        const pageWidthPt = pageObj?.widthPt ?? 595;

        return {
          ...doc,
          overlays: doc.overlays.map((o) => {
            if (o.id !== overlayId || o.kind !== 'text') return o;
            const existingMerged = new Set<string>([
              ...(o.sourceBlockId ? [o.sourceBlockId] : []),
              ...(o.mergedBlockIds || []),
            ]);
            if (existingMerged.has(belowBlock.id)) return o;
            existingMerged.add(belowBlock.id);

            const appendedLines: ExtractedLineInfo[] =
              belowBlock.lines && belowBlock.lines.length > 0
                ? belowBlock.lines
                : [
                    {
                      text: belowBlock.originalText,
                      x: belowBlock.x,
                      y: belowBlock.y,
                      width: belowBlock.width,
                      height: belowBlock.height,
                      segments: belowBlock.segments || [],
                    },
                  ];

            const baseLines: ExtractedLineInfo[] =
              o.sourceLines && o.sourceLines.length > 0
                ? o.sourceLines
                : o.sourceBlockId
                ? [
                    {
                      text: o.originalText ?? o.text,
                      x: o.x,
                      y: o.y,
                      width: o.width,
                      height: o.height,
                      segments: o.sourceSegments || [],
                    },
                  ]
                : [];

            const nextX = Math.min(o.x, belowBlock.x);
            const nextY = Math.min(o.y, belowBlock.y);
            const nextMaxX = Math.max(o.x + o.width, belowBlock.x + belowBlock.width);
            const nextMaxY = Math.max(o.y + o.height, belowBlock.y + belowBlock.height);

            const maskMinX = Math.min(o.maskRect?.x ?? o.x, belowBlock.x);
            const maskMinY = Math.min(o.maskRect?.y ?? o.y, belowBlock.y);
            const maskMaxX = Math.max(
              (o.maskRect?.x ?? o.x) + (o.maskRect?.width ?? o.width),
              belowBlock.x + belowBlock.width
            );
            const maskMaxY = Math.max(
              (o.maskRect?.y ?? o.y) + (o.maskRect?.height ?? o.height),
              belowBlock.y + belowBlock.height
            );

            return {
              ...o,
              sourceBlockId: o.sourceBlockId || belowBlock.id,
              mergedBlockIds: Array.from(existingMerged),
              sourceLines:
                baseLines.length > 0 ? [...baseLines, ...appendedLines] : o.sourceLines,
              originalText:
                o.originalText !== undefined
                  ? `${o.originalText}\n${belowBlock.originalText}`
                  : undefined,
              text: `${o.text}\n${belowBlock.originalText}`,
              x: nextX,
              y: nextY,
              originalX: o.originalX !== undefined ? Math.min(o.originalX, belowBlock.x) : undefined,
              width: Math.max(40, nextMaxX - nextX),
              height: Math.max(16, nextMaxY - nextY),
              maxPageWidth: Math.max(60, pageWidthPt - nextX - 16),
              isParagraph: true,
              maskRect: {
                x: maskMinX,
                y: maskMinY,
                width: Math.max(20, maskMaxX - maskMinX),
                height: Math.max(12, maskMaxY - maskMinY),
                padding: o.maskRect?.padding ?? settings.defaultMaskPadding,
                color: o.maskRect?.color || belowBlock.bgColor,
                enabled: o.maskRect?.enabled ?? true,
              },
            };
          }),
        };
      });
    },
    [settings.defaultMaskPadding, updateActiveDoc]
  );

  const handleFinishInlineEdit = useCallback(
    (overlayId: string) => {
      if (!activeDoc) return;
      const target = activeDoc.overlays.find((o) => o.id === overlayId);
      if (!target || target.kind !== 'text') return;
      const plan = resolveTextRenderPlans(target, customFonts);
      if (!plan.shouldRender) {
        updateActiveDoc((doc) => ({
          ...doc,
          overlays: doc.overlays.filter((o) => o.id !== overlayId),
        }));
        if (selectedOverlayId === overlayId) {
          setSelectedOverlayId(null);
        }
      }
    },
    [activeDoc, customFonts, selectedOverlayId, updateActiveDoc]
  );

  const handleCreateTextAt = (pageId: string, xPt: number, yPt: number) => {
    if (!pageId) return;
    const pageObj = activeDoc?.pages.find((p) => p.id === pageId);
    const pageWidthPt = pageObj?.widthPt ?? 595;
    const id = `ov-txt-${Date.now()}`;

    const newOv: TextOverlayElement = {
      id,
      kind: 'text',
      pageId,
      text: lang === 'bn' ? 'নতুন লেখা' : 'New text',
      x: xPt,
      y: Math.max(0, yPt - 8),
      width: Math.min(220, Math.max(80, pageWidthPt - xPt - 16)),
      height: 24,
      maxPageWidth: Math.max(60, pageWidthPt - xPt - 16),
      opacity: 1,
      fontId: lang === 'bn' ? 'noto-sans-bengali' : 'plus-jakarta-sans',
      fontSize: 13,
      fontWeight: 'normal',
      fontStyle: 'normal',
      textAlign: 'left',
      lineHeight: 1.3,
      letterSpacing: 0,
      color: '#0f172a',
    };
    updateDocWithUndo((doc) => ({
      overlays: [...doc.overlays, newOv],
      activePageId: pageId,
    }));
    setSelectedOverlayId(id);
    setToolMode('edit-text');
  };

  const handleCreateDrawOverlay = (
    pageId: string,
    kind: 'patch' | 'shape' | 'highlight',
    xPt: number,
    yPt: number,
    widthPt: number,
    heightPt: number
  ) => {
    if (!pageId) return;
    const id = `ov-${kind}-${Date.now()}`;

    const created: OverlayElement =
      kind === 'patch'
        ? {
            id,
            kind: 'patch',
            pageId,
            x: xPt,
            y: yPt,
            width: widthPt,
            height: heightPt,
            opacity: 1,
            fillColor: '#ffffff',
            borderColor: '#e2e8f0',
            borderWidth: 0,
          }
        : kind === 'highlight'
        ? {
            id,
            kind: 'shape',
            pageId,
            x: xPt,
            y: yPt,
            width: widthPt,
            height: heightPt,
            opacity: 0.38,
            shapeType: 'highlight',
            fillColor: '#fde047',
            strokeColor: '#eab308',
            strokeWidth: 0,
          }
        : {
            id,
            kind: 'shape',
            pageId,
            x: xPt,
            y: yPt,
            width: widthPt,
            height: heightPt,
            opacity: 1,
            shapeType: 'rectangle',
            fillColor: 'transparent',
            strokeColor: '#1d4ed8',
            strokeWidth: 1.5,
          };

    updateDocWithUndo((doc) => ({
      overlays: [...doc.overlays, created],
      activePageId: pageId,
    }));
    setSelectedOverlayId(id);
    setToolMode('edit-text');
  };

  const handleCreatePenStroke = (
    pageId: string,
    rawPoints: Array<{ x: number; y: number }>
  ) => {
    if (!pageId || rawPoints.length < 2) return;
    const minX = Math.min(...rawPoints.map((p) => p.x));
    const minY = Math.min(...rawPoints.map((p) => p.y));
    const maxX = Math.max(...rawPoints.map((p) => p.x));
    const maxY = Math.max(...rawPoints.map((p) => p.y));

    const id = `ov-pen-${Date.now()}`;
    updateDocWithUndo((doc) => ({
      activePageId: pageId,
      overlays: [
        ...doc.overlays,
        {
          id,
          kind: 'pen',
          pageId,
          x: minX,
          y: minY,
          width: Math.max(8, maxX - minX),
          height: Math.max(8, maxY - minY),
          opacity: 1,
          points: rawPoints.map((p) => ({ x: p.x - minX, y: p.y - minY })),
          strokeColor: '#1d4ed8',
          strokeWidth: 2.5,
        },
      ],
    }));
  };

  const handleUpdateOverlay = (
    id: string,
    updater: (prev: OverlayElement) => OverlayElement
  ) => {
    const now = Date.now();
    const shouldPushUndo = now - lastTextCommitRef.current > 800;
    if (shouldPushUndo) {
      lastTextCommitRef.current = now;
    }
    updateActiveDoc((doc) => ({
      ...doc,
      undoStack: shouldPushUndo
        ? [...doc.undoStack.slice(-29), { pages: doc.pages, overlays: doc.overlays }]
        : doc.undoStack,
      redoStack: shouldPushUndo ? [] : doc.redoStack,
      overlays: doc.overlays.map((o) => (o.id === id ? updater(o) : o)),
    }));
  };

  const handleResetTextOverlay = (id: string) => {
    const target = overlays.find((o) => o.id === id);
    if (!target || target.kind !== 'text' || target.originalText === undefined) return;
    updateDocWithUndo((doc) => ({
      overlays: doc.overlays.filter((o) => o.id !== id),
    }));
    setSelectedOverlayId(null);
  };

  const handleDuplicateOverlay = (id: string) => {
    const target = overlays.find((o) => o.id === id);
    if (!target) return;
    const clone: OverlayElement = {
      ...target,
      id: `ov-dup-${Date.now()}`,
      x: target.x + 16,
      y: target.y + 16,
      ...(target.kind === 'text'
        ? { sourceBlockId: undefined, originalText: undefined, maskRect: undefined }
        : {}),
    } as OverlayElement;
    updateDocWithUndo((doc) => ({
      overlays: [...doc.overlays, clone],
    }));
    setSelectedOverlayId(clone.id);
  };

  const handleInsertImageData = (
    dataUrl: string,
    aspectRatio: number,
    isSignature = false
  ) => {
    if (!activePageId) return;
    const width = isSignature ? 150 : 140;
    const height = Math.max(24, width / (aspectRatio || 1));
    const id = `ov-img-${Date.now()}`;
    updateDocWithUndo((doc) => ({
      overlays: [
        ...doc.overlays,
        {
          id,
          kind: 'image',
          pageId: doc.activePageId,
          x: 60,
          y: 100,
          width,
          height,
          opacity: 1,
          dataUrl,
          aspectRatio,
          isSignature,
        },
      ],
    }));
    setSelectedOverlayId(id);
    setToolMode('edit-text');
  };

  const handleUploadImageFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();
      img.onload = () => {
        handleInsertImageData(dataUrl, img.width / img.height, false);
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const handleRotatePage = (pageId: string) => {
    updateDocWithUndo((doc) => ({
      pages: doc.pages.map((p) =>
        p.id === pageId
          ? { ...p, rotation: (((p.rotation + 90) % 360) as 0 | 90 | 180 | 270) }
          : p
      ),
    }));
  };

  const handleDuplicatePage = (pageId: string) => {
    const idx = pages.findIndex((p) => p.id === pageId);
    if (idx === -1) return;
    const newId = `page-dup-${Date.now()}`;
    updateDocWithUndo((doc) => {
      const source = doc.pages[idx];
      if (!source) return {};
      const clonedPage: PdfPageModel = {
        ...source,
        id: newId,
        extractedBlocks: source.extractedBlocks.map((b) => ({ ...b, pageId: newId })),
      };
      const clonedOverlays = doc.overlays
        .filter((o) => o.pageId === pageId)
        .map((o, i) => ({
          ...o,
          id: `${o.id}-cp-${i}-${Date.now()}`,
          pageId: newId,
        }));

      const nextPages = [...doc.pages];
      nextPages.splice(idx + 1, 0, clonedPage);
      return {
        pages: nextPages,
        overlays: [...doc.overlays, ...clonedOverlays],
        activePageId: newId,
      };
    });
    setScrollRequest({ pageId: newId, nonce: Date.now() });
  };

  const handleMovePage = (pageId: string, dir: -1 | 1) => {
    updateDocWithUndo((doc) => {
      const idx = doc.pages.findIndex((p) => p.id === pageId);
      const targetIdx = idx + dir;
      if (idx === -1 || targetIdx < 0 || targetIdx >= doc.pages.length) return {};
      const next = [...doc.pages];
      const [removed] = next.splice(idx, 1);
      next.splice(targetIdx, 0, removed);
      return { pages: next };
    });
  };

  const handleDeletePage = (pageId: string) => {
    if (pages.length <= 1) return;
    updateDocWithUndo((doc) => {
      const idx = doc.pages.findIndex((p) => p.id === pageId);
      const nextPages = doc.pages.filter((p) => p.id !== pageId);
      const nextActive =
        doc.activePageId === pageId
          ? nextPages[Math.max(0, idx - 1)].id
          : doc.activePageId;
      return {
        pages: nextPages,
        overlays: doc.overlays.filter((o) => o.pageId !== pageId),
        activePageId: nextActive,
      };
    });
    setSelectedOverlayId(null);
  };

  const handleAddBlankPage = (afterPageId?: string) => {
    const newId = `page-blank-${Date.now()}`;
    const presetDims = getPageDimensionsForPreset(settings.defaultPageSize);
    updateDocWithUndo((doc) => {
      const targetIdx = afterPageId
        ? doc.pages.findIndex((p) => p.id === afterPageId)
        : doc.pages.length - 1;
      const refPage =
        (targetIdx >= 0 ? doc.pages[targetIdx] : doc.pages[0]) || null;
      const blankPage: PdfPageModel = {
        id: newId,
        originalPageIndex: null,
        widthPt: refPage?.widthPt || presetDims.widthPt,
        heightPt: refPage?.heightPt || presetDims.heightPt,
        rotation: 0,
        previewDataUrl: '',
        thumbnailDataUrl: '',
        extractedBlocks: [],
      };
      const nextPages = [...doc.pages];
      if (targetIdx >= 0) {
        nextPages.splice(targetIdx + 1, 0, blankPage);
      } else {
        nextPages.push(blankPage);
      }
      return {
        pages: nextPages,
        activePageId: newId,
      };
    });
    setSelectedOverlayId(null);
    setTimeout(() => setScrollRequest({ pageId: newId, nonce: Date.now() }), 50);
  };

  const handleUploadCustomFonts = async (files: File[]) => {
    try {
      const added: CustomFont[] = [];
      for (const file of files) {
        const cf = await registerCustomFontFace(file);
        added.push(cf);
      }
      if (added.length > 0) {
        setCustomFonts((prev) => {
          const merged = new Map(prev.map((f) => [f.id, f]));
          for (const f of added) merged.set(f.id, f);
          return Array.from(merged.values());
        });
      }
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Failed to load custom font file.'
      );
    }
  };

  const handleLoadDeviceFonts = async (): Promise<{
    supported: boolean;
    count: number;
  }> => {
    const apiResult = await loadLocalDeviceFontsViaApi();
    const probed = detectInstalledSystemFonts();
    const combined = [...apiResult.fonts, ...probed];

    if (combined.length > 0) {
      setCustomFonts((prev) => {
        const merged = new Map(prev.map((f) => [f.id, f]));
        for (const f of combined) merged.set(f.id, f);
        return Array.from(merged.values());
      });
    }

    return {
      supported: apiResult.supported || probed.length > 0,
      count: combined.length,
    };
  };

  const handleAddGoogleFont = async (fontName: string): Promise<CustomFont> => {
    const gf = await loadGoogleFontByName(fontName, true);
    setCustomFonts((prev) => {
      const merged = new Map(prev.map((f) => [f.id, f]));
      merged.set(gf.id, gf);
      return Array.from(merged.values());
    });
    return gf;
  };

  const handleApplyFontToDetected = (rawName: string, fontId: string) => {
    updateDocWithUndo((doc) => ({
      detectedFonts: doc.detectedFonts.map((df) =>
        df.rawName === rawName ? { ...df, matchedFontId: fontId } : df
      ),
      pages: doc.pages.map((p) => ({
        ...p,
        extractedBlocks: p.extractedBlocks.map((b) =>
          b.rawFontName === rawName ? { ...b, matchedFontId: fontId } : b
        ),
      })),
      overlays: doc.overlays.map((ov) =>
        ov.kind === 'text' && ov.rawFontName === rawName
          ? { ...ov, fontId }
          : ov
      ),
    }));
  };

  const handlePickBgColorValue = (hex: string) => {
    setIsPickingBgColor(false);
    if (!selectedOverlayId) return;
    handleUpdateOverlay(selectedOverlayId, (prev) => {
      if (prev.kind === 'text' && prev.maskRect) {
        return { ...prev, maskRect: { ...prev.maskRect, color: hex } };
      }
      if (prev.kind === 'patch') {
        return { ...prev, fillColor: hex };
      }
      return prev;
    });
  };

  const handleExportPdf = async () => {
    if (!activeDoc || activeDoc.pages.length === 0) return;
    setIsExporting(true);
    setErrorMsg(null);
    try {
      const pdfBytes = await exportEditedPdf(
        activeDoc.originalBytes,
        activeDoc.pages,
        activeDoc.overlays,
        customFonts
      );
      const blob = new Blob([pdfBytes.buffer as ArrayBuffer], {
        type: 'application/pdf',
      });
      const base = activeDoc.docName.replace(/\.pdf$/i, '');
      triggerDownload(blob, `${base}-edited.pdf`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'PDF export failed.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportImage = async (
    format: 'png' | 'jpeg',
    scope: 'current' | 'all'
  ) => {
    if (!activeDoc || activeDoc.pages.length === 0) return;
    setIsExporting(true);
    setErrorMsg(null);
    const base = activeDoc.docName.replace(/\.pdf$/i, '');
    const ext = format === 'png' ? 'png' : 'jpg';
    try {
      if (scope === 'current') {
        const idx = Math.max(
          0,
          activeDoc.pages.findIndex((p) => p.id === activeDoc.activePageId)
        );
        const page = activeDoc.pages[idx];
        const blob = await exportPageToImageBlob(
          activeDoc.originalBytes,
          page,
          activeDoc.overlays,
          customFonts,
          format,
          settings.exportImageQuality
        );
        triggerDownload(blob, `${base}-page-${idx + 1}-${settings.exportImageQuality}.${ext}`);
      } else {
        for (let i = 0; i < activeDoc.pages.length; i++) {
          const blob = await exportPageToImageBlob(
            activeDoc.originalBytes,
            activeDoc.pages[i],
            activeDoc.overlays,
            customFonts,
            format,
            settings.exportImageQuality
          );
          triggerDownload(blob, `${base}-page-${i + 1}-${settings.exportImageQuality}.${ext}`);
          if (i < activeDoc.pages.length - 1) {
            await new Promise((r) => setTimeout(r, 180));
          }
        }
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Image export failed.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleSaveSnapshotNow = async () => {
    const ts = await saveAutosaveSnapshot(docsRef.current, activeDocIdRef.current);
    if (ts) setLastAutosavedAt(ts);
  };

  const handleReparseCurrentPdf = async () => {
    if (!activeDoc || !activeDoc.originalBytes) return;
    setIsLoading(true);
    try {
      const parsed = await parsePdfIntoStudio(activeDoc.originalBytes, customFonts, {
        paragraphGrouping: settings.paragraphGrouping,
        autoNormalizeText: settings.autoNormalizeText,
      });
      updateActiveDoc((doc) => ({
        ...doc,
        detectedFonts: parsed.detectedFonts,
        pages: doc.pages.map((p, idx) => {
          const fresh =
            p.originalPageIndex !== null
              ? parsed.pages[p.originalPageIndex] || parsed.pages[idx]
              : undefined;
          if (!fresh) return p;
          return {
            ...p,
            extractedBlocks: fresh.extractedBlocks.map((b) => ({
              ...b,
              pageId: p.id,
            })),
          };
        }),
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const handleReloadAllFonts = async (): Promise<number> => {
    const res = await handleLoadDeviceFonts();
    return res.count;
  };

  const handleUnlockSelection = () => {
    setSelectedOverlayId(null);
    setIsPickingBgColor(false);
    setToolMode('edit-text');
    setShowPagesDrawer(false);
  };

  const handleClearCache = async () => {
    await clearAutosaveStorage();
    setLastAutosavedAt(null);
  };

  const handleExportDocx = async () => {
    if (!activeDoc || activeDoc.pages.length === 0) return;
    setIsExporting(true);
    setErrorMsg(null);
    try {
      const docxBytes = await exportDocumentToDocxBytes(
        activeDoc.pages,
        activeDoc.overlays,
        customFonts
      );
      const blob = new Blob([docxBytes.buffer as ArrayBuffer], {
        type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      });
      const base = activeDoc.docName.replace(/\.pdf$/i, '');
      triggerDownload(blob, `${base}.docx`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'DOCX export failed.');
    } finally {
      setIsExporting(false);
    }
  };

  const activePageIdx = pages.findIndex((p) => p.id === activePageId);
  const selectedOverlay =
    overlays.find((o) => o.id === selectedOverlayId) || null;

  return (
    <div className="h-screen w-screen max-w-full flex flex-col overflow-hidden bg-[#F4F5F7] text-slate-900">
      <TopBar
        lang={lang}
        onToggleLang={() => setLang((l) => (l === 'bn' ? 'en' : 'bn'))}
        onUploadPdfs={handleUploadPdfFiles}
        onOpenFonts={() => setIsFontsModalOpen(true)}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onExportPdf={handleExportPdf}
        onExportImage={handleExportImage}
        onExportDocx={handleExportDocx}
        isExporting={isExporting}
        hasPages={pages.length > 0}
        pageCount={pages.length}
        activePageNumber={activePageIdx >= 0 ? activePageIdx + 1 : 1}
      />

      {errorMsg && (
        <div className="bg-red-50 border-b border-red-200 px-4 py-2 text-xs text-red-700 flex items-center justify-between shrink-0">
          <span>{errorMsg}</span>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="font-semibold underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="flex-1 flex min-h-0 min-w-0 overflow-hidden relative">
        {pages.length > 0 && (
          <LeftSidebar
            lang={lang}
            isOpen={showPagesDrawer}
            pages={pages}
            activePageId={activePageId}
            detectedFonts={detectedFonts}
            onClose={() => setShowPagesDrawer(false)}
            onSelectPage={(id) => {
              handleJumpToPage(id);
              setSelectedOverlayId(null);
            }}
            onRotatePage={handleRotatePage}
            onDuplicatePage={handleDuplicatePage}
            onMovePage={handleMovePage}
            onDeletePage={handleDeletePage}
            onAddBlankPage={() => handleAddBlankPage(activePageId)}
            onOpenFonts={() => setIsFontsModalOpen(true)}
          />
        )}

        <PdfWorkspace
          lang={lang}
          documents={documents}
          activeDocId={activeDocId}
          pages={pages}
          activePageId={activePageId}
          scrollRequest={scrollRequest}
          overlays={overlays}
          selectedOverlayId={selectedOverlayId}
          toolMode={toolMode}
          zoom={zoom}
          customFonts={customFonts}
          canUndo={(activeDoc?.undoStack.length ?? 0) > 0}
          canRedo={(activeDoc?.redoStack.length ?? 0) > 0}
          isLoading={isLoading}
          isPickingBgColor={isPickingBgColor}
          isFullscreen={isFullscreen}
          onSelectDocument={(id) => {
            setActiveDocId(id);
            setSelectedOverlayId(null);
            setShowPagesDrawer(false);
          }}
          onCloseDocument={handleCloseDocument}
          onSelectPage={handleSelectPage}
          onOpenPagesDrawer={() => setShowPagesDrawer(true)}
          onAddBlankPage={handleAddBlankPage}
          onDeletePage={handleDeletePage}
          onPrevPage={() => {
            if (activePageIdx > 0) {
              handleJumpToPage(pages[activePageIdx - 1].id);
              setSelectedOverlayId(null);
            }
          }}
          onNextPage={() => {
            if (activePageIdx >= 0 && activePageIdx < pages.length - 1) {
              handleJumpToPage(pages[activePageIdx + 1].id);
              setSelectedOverlayId(null);
            }
          }}
          onRotateActivePage={() => {
            if (activePageId) handleRotatePage(activePageId);
          }}
          onToggleFullscreen={handleToggleFullscreen}
          onSetToolMode={setToolMode}
          onSetZoom={(nextZoom) =>
            updateActiveDoc((doc) => ({ ...doc, zoom: nextZoom }))
          }
          onUndo={handleUndo}
          onRedo={handleRedo}
          onSelectOverlay={setSelectedOverlayId}
          onActivateExtractedBlock={handleActivateExtractedBlock}
          onActivateMultiBlocks={handleActivateMultiBlocks}
          onAbsorbBelowBlock={handleAbsorbBelowBlock}
          onCreateTextAt={handleCreateTextAt}
          onCreateDrawOverlay={handleCreateDrawOverlay}
          onCreatePenStroke={handleCreatePenStroke}
          onUpdateOverlay={handleUpdateOverlay}
          onFinishInlineEdit={handleFinishInlineEdit}
          onPickBgColorValue={handlePickBgColorValue}
          onOpenSignature={() => setIsSignatureModalOpen(true)}
          onUploadImage={handleUploadImageFile}
          onDropPdfFiles={handleUploadPdfFiles}
        />

        {pages.length > 0 && selectedOverlay && (
          <RightInspector
            lang={lang}
            selectedOverlay={selectedOverlay}
            customFonts={customFonts}
            isPickingBgColor={isPickingBgColor}
            onClose={() => setSelectedOverlayId(null)}
            onTogglePickBgColor={() => setIsPickingBgColor((v) => !v)}
            onUpdateOverlay={handleUpdateOverlay}
            onResetTextOverlay={handleResetTextOverlay}
            onDuplicateOverlay={handleDuplicateOverlay}
            onDeleteOverlay={handleDeleteOverlay}
            onOpenFonts={() => setIsFontsModalOpen(true)}
          />
        )}
      </div>

      <FontManagerModal
        isOpen={isFontsModalOpen}
        lang={lang}
        customFonts={customFonts}
        detectedFonts={detectedFonts}
        onClose={() => setIsFontsModalOpen(false)}
        onUploadFonts={handleUploadCustomFonts}
        onLoadDeviceFonts={handleLoadDeviceFonts}
        onAddGoogleFont={handleAddGoogleFont}
        onApplyFontToDetected={handleApplyFontToDetected}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        lang={lang}
        settings={settings}
        hasActiveDoc={Boolean(activeDoc)}
        lastSavedAt={lastAutosavedAt}
        onClose={() => setIsSettingsModalOpen(false)}
        onToggleLang={(nextLang) => setLang(nextLang)}
        onUpdateSettings={updateSettings}
        onSaveSnapshotNow={handleSaveSnapshotNow}
        onReparseCurrentPdf={handleReparseCurrentPdf}
        onReloadAllFonts={handleReloadAllFonts}
        onUnlockSelection={handleUnlockSelection}
        onClearCache={handleClearCache}
      />

      <SignatureModal
        isOpen={isSignatureModalOpen}
        lang={lang}
        onClose={() => setIsSignatureModalOpen(false)}
        onInsertSignature={(dataUrl, ratio) =>
          handleInsertImageData(dataUrl, ratio, true)
        }
      />

      <HoverTooltipLayer />
      <OfflineIndicator lang={lang} />
    </div>
  );
}
