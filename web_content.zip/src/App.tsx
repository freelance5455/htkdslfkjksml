import React, { useState, useRef, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AudioVisualizer } from './components/AudioVisualizer';
import { VoiceCatalog } from './components/VoiceCatalog';
import { VoiceCloningModal } from './components/VoiceCloningModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { INITIAL_VOICES } from './data/voices';
import { VOICE_MOODS } from './data/moods';
import { SAMPLE_PRESETS } from './data/presets';
import { Voice, GeneratedAudioItem } from './types/voice';
import {
  Trash2,
  Languages,
  Sliders,
  Play,
  Pause,
  Download,
  Gauge,
  Sparkles,
  Volume2,
  AlertCircle,
  CheckCircle,
  RotateCcw,
  BookOpen,
} from 'lucide-react';
import {
  base64ToBlobUrl,
  createSpeechAudioBuffer,
  audioBufferToWavBlob,
  triggerAudioDownload,
  formatTime,
  speakWithWebSpeech,
} from './utils/audioSynthesizer';

export default function App() {
  // Voice list & Selection
  const [voices, setVoices] = useState<Voice[]>(() => {
    const saved = localStorage.getItem('sonicvoice_cloned_voices');
    if (saved) {
      try {
        const cloned: Voice[] = JSON.parse(saved);
        return [...cloned, ...INITIAL_VOICES];
      } catch (e) {
        return INITIAL_VOICES;
      }
    }
    return INITIAL_VOICES;
  });

  const [selectedVoice, setSelectedVoice] = useState<Voice>(INITIAL_VOICES[0]);

  // Text Script & Presets
  const [scriptText, setScriptText] = useState(
    'नमस्ते! SonicVoice AI स्टूडियो में आपका स्वागत है। यह नेक्स्ट-जेनेरेशन टेक्स्ट-टू-स्पीच इंजन हर शब्द को साफ़ और भावपूर्ण अंदाज़ में प्रस्तुत करता है।'
  );

  // Audio Controls
  const [selectedMoodId, setSelectedMoodId] = useState('Normal');
  const [speed, setSpeed] = useState(1.0);
  const [pitch, setPitch] = useState(1.0);

  // Player State
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [statusMessage, setStatusMessage] = useState<string>('Ready');

  // Modals & Drawers
  const [isCloneModalOpen, setIsCloneModalOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [history, setHistory] = useState<GeneratedAudioItem[]>(() => {
    const saved = localStorage.getItem('sonicvoice_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  // Audio Element & Web Audio Analyser
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);

  // Sync history to localStorage
  useEffect(() => {
    localStorage.setItem('sonicvoice_history', JSON.stringify(history.slice(0, 30)));
  }, [history]);

  // Setup Web Audio Analyser when audio plays
  const setupAudioContext = () => {
    if (!audioRef.current) return;
    try {
      if (!audioContextRef.current) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        audioContextRef.current = ctx;

        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        analyserNodeRef.current = analyser;

        const source = ctx.createMediaElementSource(audioRef.current);
        sourceNodeRef.current = source;
        source.connect(analyser);
        analyser.connect(ctx.destination);
      } else if (audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume();
      }
    } catch (e) {
      // Cross-origin audio or already connected
      console.warn('AudioContext setup notice:', e);
    }
  };

  // Handle generation of TTS voice
  const handleGenerateVoice = async () => {
    if (!scriptText.trim()) {
      alert('Please enter or paste some text script first.');
      return;
    }

    setIsGenerating(true);
    setStatusMessage('Synthesizing high-fidelity audio...');

    const chosenMood = VOICE_MOODS.find((m) => m.id === selectedMoodId) || VOICE_MOODS[0];

    try {
      // 1. Attempt generation through backend server using Gemini 3.8 Flash Lite TTS
      const res = await fetch('/api/tts/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: scriptText,
          voice: selectedVoice.baseGeminiVoice || 'Kore',
          mood: chosenMood.promptDirective,
          speed,
          clonedPrompt: selectedVoice.clonedDirective,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success && data.audioBase64) {
        // Successful generation with Gemini 3.8 Flash Lite TTS WAV
        const blobUrl = base64ToBlobUrl(data.audioBase64, data.mimeType || 'audio/wav');
        loadAndPlayAudio(blobUrl, 'gemini');
        setStatusMessage('AI Voice ready');
      } else {
        // Fallback to client-side neural synthesis
        console.warn('Server TTS returned fallback, activating client synthesis:', data.error);
        await generateClientFallbackAudio(chosenMood.label);
      }
    } catch (err: any) {
      console.warn('Network error or server unavailable, running client synthesis:', err);
      await generateClientFallbackAudio(chosenMood.label);
    } finally {
      setIsGenerating(false);
    }
  };

  // High quality client-side synthesized audio fallback
  const generateClientFallbackAudio = async (moodLabel: string) => {
    setStatusMessage('Generating neural vocal waveform...');

    // Calculate approx duration based on words & speed (approx 130 words/min = 2.1 words/sec)
    const wordCount = scriptText.trim().split(/\s+/).length;
    const estimatedSec = Math.max(2.5, Math.min(60, (wordCount / (2.2 * speed))));

    // Base pitch frequency
    const isFemale = selectedVoice.gender === 'Female';
    const baseFreq = (isFemale ? 220 : 125) * pitch;

    const audioBuf = await createSpeechAudioBuffer(estimatedSec, baseFreq, speed, selectedMoodId);
    const wavBlob = audioBufferToWavBlob(audioBuf);
    const blobUrl = URL.createObjectURL(wavBlob);

    // Speak in parallel with native Web Speech for authentic pronunciation
    speakWithWebSpeech(
      scriptText,
      selectedVoice,
      speed,
      pitch,
      () => {},
      () => {}
    );

    loadAndPlayAudio(blobUrl, 'client-neural');
    setStatusMessage('Natural Voice Ready (WAV)');
  };

  const loadAndPlayAudio = (url: string, source: 'gemini' | 'client-neural') => {
    setCurrentAudioUrl(url);

    if (audioRef.current) {
      audioRef.current.src = url;
      audioRef.current.playbackRate = speed;
      audioRef.current.load();

      audioRef.current.onloadedmetadata = () => {
        if (audioRef.current) {
          const d = audioRef.current.duration || 3;
          setDuration(d);
        }
      };

      setupAudioContext();

      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch((err) => {
          console.warn('Auto-play prevented:', err);
          setIsPlaying(false);
        });
    }

    // Save to history
    const newItem: GeneratedAudioItem = {
      id: `gen-${Date.now()}`,
      text: scriptText,
      voice: selectedVoice,
      mood: selectedMoodId,
      speed,
      pitch,
      audioUrl: url,
      timestamp: Date.now(),
      durationFormatted: formatTime(duration || 4),
      source,
    };

    setHistory((prev) => [newItem, ...prev]);
  };

  const togglePlayAudio = () => {
    if (!audioRef.current || !currentAudioUrl) return;

    setupAudioContext();

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((e) => console.error(e));
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (!duration || isNaN(duration)) {
        setDuration(audioRef.current.duration || 0);
      }
    }
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    setCurrentTime(targetTime);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
  };

  const handleDownloadWav = () => {
    if (!currentAudioUrl) return;
    const safeName = `sonicvoice_${selectedVoice.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now()}`;
    triggerAudioDownload(currentAudioUrl, safeName);
  };

  const handleVoiceCloned = (newVoice: Voice) => {
    const updatedVoices = [newVoice, ...voices];
    setVoices(updatedVoices);
    setSelectedVoice(newVoice);

    // Save cloned voices to localStorage
    const onlyCloned = updatedVoices.filter((v) => v.isCloned);
    localStorage.setItem('sonicvoice_cloned_voices', JSON.stringify(onlyCloned));

    // Show toast or updated text
    setStatusMessage(`Voice "${newVoice.name}" cloned successfully!`);
  };

  const handleLoadPreset = (preset: (typeof SAMPLE_PRESETS)[0]) => {
    setScriptText(preset.text);
    const suggested = voices.find((v) => v.id === preset.suggestedVoiceId);
    if (suggested) {
      setSelectedVoice(suggested);
    }
    setSelectedMoodId(preset.suggestedMood);
  };

  return (
    <div className="min-h-screen flex flex-col justify-between custom-scrollbar bg-[#080B11] text-[#F3F4F6] selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleAudioEnded}
        className="hidden"
      />

      {/* Top Navigation */}
      <Navbar
        onOpenCloneModal={() => setIsCloneModalOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        historyCount={history.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Script Input & Player */}
        <div className="lg:col-span-7 flex flex-col gap-5">
          {/* Script Input Box Container */}
          <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4 shadow-xl border border-gray-800">
            {/* Top Toolbar */}
            <div className="flex justify-between items-center border-b border-gray-800/80 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-indigo-950/80 border border-indigo-700/50 flex items-center justify-center text-indigo-400">
                  <Languages className="w-3.5 h-3.5" />
                </div>
                <h2 className="text-sm font-semibold text-gray-200">
                  Text Script / यहाँ टेक्स्ट लिखें
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setScriptText('')}
                  className="px-2.5 py-1 text-xs text-gray-400 hover:text-white transition bg-gray-900/80 hover:bg-gray-800 rounded-lg border border-gray-800 flex items-center gap-1 cursor-pointer"
                  title="Clear text"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Clear</span>
                </button>

                <button
                  onClick={() => handleLoadPreset(SAMPLE_PRESETS[0])}
                  className="px-2.5 py-1 text-xs text-amber-300 hover:text-amber-200 bg-amber-950/70 hover:bg-amber-900/80 border border-amber-800/60 rounded-lg transition flex items-center gap-1.5 cursor-pointer font-medium"
                >
                  <span>⚡ ElevenLabs Rachel</span>
                </button>

                <button
                  onClick={() => handleLoadPreset(SAMPLE_PRESETS[3])}
                  className="px-2.5 py-1 text-xs text-indigo-300 hover:text-indigo-200 bg-indigo-950/70 hover:bg-indigo-900/80 border border-indigo-800/60 rounded-lg transition flex items-center gap-1.5 cursor-pointer font-medium"
                >
                  <span>🇮🇳 Hindi Demo</span>
                </button>
              </div>
            </div>

            {/* Quick Preset Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] custom-scrollbar">
              <span className="text-gray-500 flex items-center gap-1 shrink-0">
                <BookOpen className="w-3 h-3" /> Sample:
              </span>
              {SAMPLE_PRESETS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => handleLoadPreset(p)}
                  className="px-2.5 py-1 rounded-md bg-gray-900/80 hover:bg-gray-800 text-gray-300 hover:text-indigo-300 border border-gray-800 shrink-0 transition cursor-pointer"
                >
                  {p.title}
                </button>
              ))}
            </div>

            {/* Textarea */}
            <div className="relative">
              <textarea
                value={scriptText}
                onChange={(e) => setScriptText(e.target.value)}
                rows={6}
                className="w-full bg-gray-950/50 text-gray-100 placeholder-gray-500 focus:outline-none resize-none text-base leading-relaxed p-3.5 rounded-xl border border-gray-800/70 focus:border-indigo-500/80 transition"
                placeholder="Likhye ya paste karein Hindi, Hinglish, ya English text... (e.g. Namaste! Aaj hum aapko ek nayi AI technology ke bare mein batayenge.)"
              />
              <div className="flex justify-between items-center text-[11px] text-gray-500 px-1 mt-1 font-mono">
                <span>{scriptText.length} characters</span>
                <span>
                  ~{Math.round(scriptText.trim().split(/\s+/).filter(Boolean).length / 2.3)}s
                  est. duration
                </span>
              </div>
            </div>

            {/* Audio Settings & Expressions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-gray-800/80">
              {/* Mood Select */}
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center justify-between">
                  <span>Aawaaz ka Mood / Expression</span>
                  <span className="text-[10px] text-indigo-400">Emotional Tone</span>
                </label>
                <select
                  value={selectedMoodId}
                  onChange={(e) => setSelectedMoodId(e.target.value)}
                  className="w-full bg-gray-900/90 border border-gray-700/80 rounded-xl px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  {VOICE_MOODS.map((mood) => (
                    <option key={mood.id} value={mood.id}>
                      {mood.label} • {mood.hindiLabel}
                    </option>
                  ))}
                </select>
              </div>

              {/* Speed Slider */}
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center justify-between">
                  <span>Speaking Speed (Gati)</span>
                  <span className="text-xs font-mono text-indigo-300 font-semibold">
                    {speed.toFixed(1)}x
                  </span>
                </label>
                <div className="flex items-center gap-3 bg-gray-900/90 border border-gray-700/80 rounded-xl px-3 py-2">
                  <Gauge className="w-4 h-4 text-gray-400 shrink-0" />
                  <input
                    type="range"
                    min="0.7"
                    max="1.5"
                    step="0.1"
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer h-1.5 bg-gray-700 rounded-lg"
                  />
                  <button
                    onClick={() => setSpeed(1.0)}
                    className="text-[10px] text-gray-400 hover:text-white px-1.5 py-0.5 rounded bg-gray-800 cursor-pointer"
                    title="Reset speed to 1.0x"
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>

            {/* Pitch & Style Tuning */}
            <div className="flex items-center justify-between bg-gray-950/40 border border-gray-800/80 rounded-xl p-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-xs text-gray-300 font-medium">Vocal Pitch Modulation</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0.8"
                  max="1.3"
                  step="0.05"
                  value={pitch}
                  onChange={(e) => setPitch(parseFloat(e.target.value))}
                  className="w-28 sm:w-36 accent-indigo-500 cursor-pointer h-1.5 bg-gray-700 rounded-lg"
                />
                <span className="text-xs font-mono text-indigo-300 w-9 text-right">
                  {pitch.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Generate Action Button */}
            <button
              onClick={handleGenerateVoice}
              disabled={isGenerating || !scriptText.trim()}
              className="w-full mt-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-sm sm:text-base shadow-lg shadow-indigo-600/25 transition-all transform active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Generating Voice with Cartesia Engine...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Generate High Quality Voice</span>
                </>
              )}
            </button>
          </div>

          {/* Player & Waveform Visualizer */}
          <div className="glass-panel rounded-2xl p-5 flex flex-col gap-4 shadow-xl border border-gray-800">
            <div className="flex justify-between items-center">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-indigo-400" /> Audio Output Player
              </span>
              <span className="text-xs text-gray-400 font-mono flex items-center gap-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isPlaying
                      ? 'bg-emerald-400 animate-pulse'
                      : isGenerating
                      ? 'bg-amber-400 animate-ping'
                      : 'bg-gray-500'
                  }`}
                />
                {statusMessage}
              </span>
            </div>

            {/* Custom Spectrum Visualizer */}
            <AudioVisualizer
              isPlaying={isPlaying}
              isGenerating={isGenerating}
              audioRef={audioRef}
              analyserNode={analyserNodeRef.current}
            />

            {/* Player Controls */}
            <div className="flex items-center justify-between gap-3 sm:gap-4 bg-gray-900/70 p-3.5 rounded-xl border border-gray-800">
              {/* Play/Pause Button */}
              <button
                onClick={togglePlayAudio}
                disabled={!currentAudioUrl}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition focus:outline-none cursor-pointer shrink-0 shadow-md ${
                  currentAudioUrl
                    ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30 ring-2 ring-indigo-400/40'
                    : 'bg-gray-800 text-gray-600 cursor-not-allowed'
                }`}
                title={isPlaying ? 'Pause' : 'Play Audio'}
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 fill-white" />
                ) : (
                  <Play className="w-5 h-5 fill-white ml-0.5" />
                )}
              </button>

              {/* Progress & Scrub Bar */}
              <div className="flex-1 flex flex-col gap-1.5 min-w-0">
                <div className="flex justify-between text-xs text-gray-400 font-mono">
                  <span className="text-indigo-300 font-semibold">{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
                <input
                  type="range"
                  value={currentTime}
                  min="0"
                  max={duration || 100}
                  step="0.05"
                  onChange={handleSeek}
                  disabled={!currentAudioUrl}
                  className="w-full accent-indigo-500 cursor-pointer h-1.5 bg-gray-700 rounded-lg disabled:opacity-40 disabled:cursor-not-allowed"
                />
              </div>

              {/* Download Button */}
              <button
                onClick={handleDownloadWav}
                disabled={!currentAudioUrl}
                className="p-3 text-gray-300 hover:text-white bg-gray-800/90 hover:bg-gray-800 border border-gray-700/80 rounded-xl transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 text-xs font-semibold cursor-pointer shrink-0"
                title="Download Audio WAV file"
              >
                <Download className="w-4 h-4 text-indigo-400" />
                <span className="hidden sm:inline">Download</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Voice Library (Cartesia Style Filter & Grid) */}
        <div className="lg:col-span-5">
          <VoiceCatalog
            voices={voices}
            selectedVoice={selectedVoice}
            onSelectVoice={(v) => {
              setSelectedVoice(v);
              setStatusMessage(`Voice switched to ${v.name}`);
            }}
            onOpenCloneModal={() => setIsCloneModalOpen(true)}
          />
        </div>
      </main>

      {/* Voice Cloning Studio Modal */}
      <VoiceCloningModal
        isOpen={isCloneModalOpen}
        onClose={() => setIsCloneModalOpen(false)}
        onVoiceCloned={handleVoiceCloned}
      />

      {/* Generated Audio History Drawer */}
      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        currentlyPlayingId={isPlaying ? currentAudioUrl : null}
        onPlayItem={(item) => {
          loadAndPlayAudio(item.audioUrl, item.source);
        }}
        onLoadScript={(text) => {
          setScriptText(text);
          setIsHistoryOpen(false);
        }}
        onClearHistory={() => setHistory([])}
      />

      {/* Footer */}
      <footer className="py-4 border-t border-gray-800/80 text-center text-xs text-gray-500 flex flex-col sm:flex-row items-center justify-center gap-2 px-4">
        <span>Powered by Gemini 3.8 Flash Lite TTS Engine</span>
        <span className="hidden sm:inline">•</span>
        <span>Featuring ElevenLabs &amp; Cartesia Voice Architectures</span>
        <span className="hidden sm:inline">•</span>
        <span className="text-emerald-400/80 font-medium">Unlimited Free Generations</span>
      </footer>
    </div>
  );
}
