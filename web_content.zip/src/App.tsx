import React, { useState, useMemo } from 'react';
import { MohallaProvider, useMohalla } from './context/MohallaContext';
import { Header } from './components/common/Header';
import { CategoryList } from './components/customer/CategoryList';
import { EmergencyBanner } from './components/customer/EmergencyBanner';
import { ProviderCard } from './components/customer/ProviderCard';
import { ProviderDetailModal } from './components/customer/ProviderDetailModal';
import { BookingModal } from './components/customer/BookingModal';
import { BookingTracker } from './components/customer/BookingTracker';
import { ChatModal } from './components/chat/ChatModal';
import { ReviewModal } from './components/reviews/ReviewModal';
import { ReportModal } from './components/common/ReportModal';
import { TrustScoreModal } from './components/common/TrustScoreModal';
import { AuthModal } from './components/auth/AuthModal';
import { ProviderDashboard } from './components/provider/ProviderDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { calculateDistanceKm, formatCurrencyPKR } from './utils/geo';
import { ProviderProfile } from './types';
import {
  Search,
  SlidersHorizontal,
  Home,
  CalendarCheck2,
  MessageSquare,
  Heart,
  User as UserIcon,
  ShieldCheck,
  Star,
  Zap,
  Clock,
  Sparkles,
  MapPin,
  X,
  Phone,
  Check,
  Wrench,
  Lock,
  LogIn,
  LogOut,
  UserCheck,
  KeyRound,
} from 'lucide-react';

function MohallaMain() {
  const {
    currentUser,
    providers,
    selectedArea,
    favorites,
    chatMessages,
    bookings,
    language,
    t,
    isAuthenticated,
    openAuthModal,
    logoutUser,
  } = useMohalla();

  // Navigation state
  const [activeView, setActiveView] = useState<string>('home'); // 'home' | 'bookings' | 'messages' | 'favorites' | 'profile' | 'provider' | 'admin'

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [onlyAvailableNow, setOnlyAvailableNow] = useState(false);
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [sortBy, setSortBy] = useState<'distance' | 'rating' | 'price' | 'jobs'>('distance');
  const [showFiltersModal, setShowFiltersModal] = useState(false);

  // Modals state
  const [selectedProviderForDetail, setSelectedProviderForDetail] = useState<ProviderProfile | null>(null);
  const [bookingProvider, setBookingProvider] = useState<{ provider: ProviderProfile; isEmergency: boolean } | null>(null);
  const [activeChatBookingId, setActiveChatBookingId] = useState<string | null>(null);
  const [reviewBookingData, setReviewBookingData] = useState<{ bookingId: string; providerId: string } | null>(null);
  const [reportingProvider, setReportingProvider] = useState<ProviderProfile | null>(null);
  const [inspectingTrustScoreProvider, setInspectingTrustScoreProvider] = useState<ProviderProfile | null>(null);

  // Filtered & Sorted Providers List
  const filteredProviders = useMemo(() => {
    return providers
      .map((p) => {
        const dist = calculateDistanceKm(
          selectedArea.lat,
          selectedArea.lng,
          p.location.lat,
          p.location.lng
        );
        return { ...p, calculatedDistance: dist };
      })
      .filter((p) => {
        // Category filter
        if (selectedCategoryId && p.category !== selectedCategoryId) {
          return false;
        }

        // Available Now filter
        if (onlyAvailableNow && !p.isAvailableNow) {
          return false;
        }

        // Verified filter
        if (onlyVerified && p.verificationStatus !== 'verified') {
          return false;
        }

        // Search Query filter (matches business name, sub-services, or bio)
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = p.businessName.toLowerCase().includes(q);
          const matchBio = p.bio.toLowerCase().includes(q);
          const matchCategory = p.category.toLowerCase().includes(q);
          const matchServices = p.subServices.some((s) => s.toLowerCase().includes(q));
          const matchArea = p.serviceAreas.some((a) => a.toLowerCase().includes(q));
          if (!matchName && !matchBio && !matchCategory && !matchServices && !matchArea) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'distance') {
          return a.calculatedDistance - b.calculatedDistance;
        }
        if (sortBy === 'rating') {
          return b.rating - a.rating;
        }
        if (sortBy === 'price') {
          return a.visitCharge - b.visitCharge;
        }
        if (sortBy === 'jobs') {
          return b.completedJobs - a.completedJobs;
        }
        return 0;
      });
  }, [providers, selectedArea, selectedCategoryId, onlyAvailableNow, onlyVerified, searchQuery, sortBy]);

  // Handle open booking from Emergency Banner
  const handleOpenEmergencyBooking = (providerId: string) => {
    const p = providers.find((prov) => prov.id === providerId);
    if (p) {
      setBookingProvider({ provider: p, isEmergency: true });
    }
  };

  // Sync active view when user role changes
  React.useEffect(() => {
    if (currentUser.role === 'provider' && activeView !== 'provider' && isAuthenticated) {
      setActiveView('provider');
    } else if (currentUser.role === 'admin' && activeView !== 'admin' && isAuthenticated) {
      setActiveView('admin');
    }
  }, [currentUser.role, isAuthenticated]);

  return (
    <div className={`min-h-screen bg-slate-50 flex flex-col ${language === 'ur' ? 'font-urdu' : ''}`}>
      {/* Top Global Header */}
      <Header activeView={activeView} setActiveView={setActiveView} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 pb-24 md:pb-8">
        {/* VIEW 1: PROVIDER PORTAL (GUARDED) */}
        {activeView === 'provider' && (
          <>
            {currentUser.role === 'provider' && isAuthenticated ? (
              <ProviderDashboard onOpenChat={(bId) => setActiveChatBookingId(bId)} />
            ) : (
              <div className="max-w-lg mx-auto bg-white rounded-3xl border border-amber-200 p-8 shadow-xl text-center space-y-4 my-8">
                <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto">
                  <Wrench className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Service Provider Portal</h2>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Log in as an authenticated Service Provider to accept incoming bookings, toggle your Available Now status, and manage earnings.
                </p>
                <div className="flex gap-2 justify-center pt-2">
                  <button
                    onClick={() => openAuthModal('provider', 'login')}
                    className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md cursor-pointer transition-all"
                  >
                    Technician Log In
                  </button>
                  <button
                    onClick={() => openAuthModal('provider', 'signup')}
                    className="px-5 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs cursor-pointer"
                  >
                    Register Workshop
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {/* VIEW 2: ADMIN PANEL (STRICTLY GUARDED) */}
        {activeView === 'admin' && (
          <>
            {currentUser.role === 'admin' && isAuthenticated ? (
              <AdminDashboard />
            ) : (
              <div className="max-w-lg mx-auto bg-white rounded-3xl border border-purple-200 p-8 shadow-xl text-center space-y-4 my-8">
                <div className="w-16 h-16 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center mx-auto">
                  <Lock className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Admin Authorization Required</h2>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Mohalla Operations and Moderation controls are strictly restricted. You must authenticate with authorized server-side administrative credentials.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => openAuthModal('admin', 'login')}
                    className="px-6 py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md cursor-pointer transition-all flex items-center gap-2 mx-auto"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Authenticate as Admin</span>
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {/* VIEW 3: CUSTOMER BOOKINGS TRACKER */}
        {activeView === 'bookings' && (
          <BookingTracker
            onOpenChat={(bId) => setActiveChatBookingId(bId)}
            onOpenReview={(bId, pId) => setReviewBookingData({ bookingId: bId, providerId: pId })}
            onViewProvider={(pId) => {
              const prov = providers.find((p) => p.id === pId);
              if (prov) setSelectedProviderForDetail(prov);
            }}
          />
        )}

        {/* VIEW 4: CUSTOMER FAVORITES */}
        {activeView === 'favorites' && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">
              {language === 'ur' ? 'پسندیدہ کاریگر' : 'Saved Providers'}
            </h2>
            {favorites.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
                <Heart className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="font-bold text-slate-700">No favorite providers yet</p>
                <p className="mt-1">Tap the heart icon on any provider profile to bookmark them.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {providers
                  .filter((p) => favorites.includes(p.id))
                  .map((p) => (
                    <ProviderCard
                      key={p.id}
                      provider={p}
                      onViewProfile={(prov) => setSelectedProviderForDetail(prov)}
                      onBookNow={(prov) => setBookingProvider({ provider: prov, isEmergency: false })}
                      onInspectTrustScore={(prov) => setInspectingTrustScoreProvider(prov)}
                    />
                  ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 5: CUSTOMER PROFILE & SETTINGS */}
        {activeView === 'profile' && (
          <div className="max-w-xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-4">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-16 h-16 rounded-2xl object-cover border border-slate-200 shadow-sm"
                />
                <div>
                  <h2 className="text-lg font-bold text-slate-900">{currentUser.name}</h2>
                  <p className="text-xs text-slate-500">{currentUser.phone} • {currentUser.email}</p>
                  <span
                    className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      currentUser.role === 'admin'
                        ? 'bg-purple-100 text-purple-800'
                        : currentUser.role === 'provider'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {currentUser.role} Account {isAuthenticated ? '• Authenticated' : '• Demo Guest'}
                  </span>
                </div>
              </div>

              <button
                onClick={() => openAuthModal('customer', 'login')}
                className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                Switch
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-600">Saved City & Neighborhood</span>
                <span className="font-bold text-slate-900">{selectedArea.name}, Karachi</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-600">Default Currency</span>
                <span className="font-bold text-slate-900">PKR (Pakistani Rupee)</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-600">Safety & Trust Guarantee</span>
                <span className="font-bold text-emerald-700 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Cash on Completion Only
                </span>
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => logoutUser()}
                className="flex-1 py-2.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 font-bold text-xs cursor-pointer flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
              <button
                onClick={() => setActiveView('home')}
                className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer"
              >
                Back to Marketplace
              </button>
            </div>
          </div>
        )}

        {/* VIEW 6: MESSAGES OVERVIEW */}
        {activeView === 'messages' && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">Active Conversations</h2>
            {bookings.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
                No active booking chats.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {bookings.map((b) => (
                  <div
                    key={b.id}
                    onClick={() => setActiveChatBookingId(b.id)}
                    className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-emerald-500 transition-all cursor-pointer shadow-2xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white font-bold flex items-center justify-center">
                        {b.providerName.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900">{b.providerName}</h4>
                        <p className="text-xs text-slate-500 line-clamp-1">{b.problemDescription}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-lg">
                      Open Chat
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 7: DEFAULT HOME MARKETPLACE SCREEN */}
        {activeView === 'home' && (
          <div className="space-y-6">
            {/* Hero Search & Title */}
            <div className="relative rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-950 p-6 sm:p-8 text-white shadow-xl overflow-hidden">
              <div className="max-w-2xl">
                <div className="flex items-center gap-2 flex-wrap mb-3">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white/10 text-emerald-200 border border-white/15 backdrop-blur-xs">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Pakistan's Verified Local Services
                  </span>

                  {/* Top Welcome Action */}
                  {!isAuthenticated && (
                    <button
                      onClick={() => openAuthModal('customer', 'login')}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors cursor-pointer"
                    >
                      <LogIn className="w-3 h-3" />
                      <span>Log In / Sign Up</span>
                    </button>
                  )}
                </div>

                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight">
                  {t('appName')}
                </h1>
                <p className="text-xs sm:text-sm text-emerald-100/90 mt-1.5 font-medium">
                  {t('tagline')} Find verified electricians, plumbers, and technicians in{' '}
                  <span className="font-bold text-white underline decoration-emerald-400">
                    {selectedArea.name}, Karachi
                  </span>
                  .
                </p>

                {/* Search Bar with Filter Trigger */}
                <div className="mt-5 flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder={t('searchPlaceholder')}
                      className="w-full pl-10 pr-10 py-3 rounded-2xl bg-white text-slate-900 text-xs sm:text-sm font-medium shadow-md outline-hidden focus:ring-2 focus:ring-emerald-400 placeholder:text-slate-400"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <button
                    onClick={() => setShowFiltersModal(true)}
                    className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/20 cursor-pointer transition-colors shrink-0"
                    title="Filters"
                  >
                    <SlidersHorizontal className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* WELCOME PORTAL SELECTOR (Customer, Service Provider, Admin) */}
            {!isAuthenticated && (
              <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
                      <span>Welcome to Mohalla</span>
                      <span className="text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full uppercase">
                        Select Portal
                      </span>
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Choose how you want to use Pakistan's trusted local services platform:
                    </p>
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium">
                    Karachi • Sindh, PK
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                  {/* 1. Customer Option */}
                  <div className="p-4 rounded-2xl border border-emerald-200 bg-gradient-to-b from-emerald-50/40 to-white flex flex-col justify-between hover:shadow-md transition-all">
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3">
                        <UserIcon className="w-5 h-5" />
                      </div>
                      <h3 className="font-bold text-slate-900 text-sm">Customer Portal</h3>
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                        Find verified electricians, plumbers, and technicians near you. Track live arrivals and pay cash on completion.
                      </p>
                    </div>
                    <div className="pt-4 mt-2 flex gap-2">
                      <button
                        onClick={() => openAuthModal('customer', 'login')}
                        className="flex-1 py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs cursor-pointer transition-all text-center"
                      >
                        Customer Login
                      </button>
                      <button
                        onClick={() => openAuthModal('customer', 'signup')}
                        className="py-2 px-3 rounded-xl border border-emerald-300 hover:bg-emerald-50 text-emerald-800 font-bold text-xs cursor-pointer text-center"
                      >
                        Sign Up
                      </button>
                    </div>
                  </div>

                  {/* 2. Service Provider Option */}
                  <div className="p-4 rounded-2xl border border-amber-200 bg-gradient-to-b from-amber-50/40 to-white flex flex-col justify-between hover:shadow-md transition-all">
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-3">
                        <Wrench className="w-5 h-5" />
                      </div>
                      <h3 className="font-bold text-slate-900 text-sm">Technician / Workshop</h3>
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                        Register your electrical, plumbing, or repair skills. Toggle Available Now, accept nearby jobs, and manage earnings.
                      </p>
                    </div>
                    <div className="pt-4 mt-2 flex gap-2">
                      <button
                        onClick={() => openAuthModal('provider', 'login')}
                        className="flex-1 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer transition-all text-center"
                      >
                        Provider Login
                      </button>
                      <button
                        onClick={() => openAuthModal('provider', 'signup')}
                        className="py-2 px-3 rounded-xl border border-amber-300 hover:bg-amber-50 text-amber-800 font-bold text-xs cursor-pointer text-center"
                      >
                        Register
                      </button>
                    </div>
                  </div>

                  {/* 3. Admin Option (Clearly Visible) */}
                  <div className="p-4 rounded-2xl border border-purple-200 bg-gradient-to-b from-purple-50/40 to-white flex flex-col justify-between hover:shadow-md transition-all ring-1 ring-purple-500/20">
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center mb-3">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-bold text-slate-900 text-sm">Admin Control HQ</h3>
                        <span className="text-[10px] font-bold bg-purple-100 text-purple-800 px-1.5 py-0.2 rounded">
                          Secure
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                        Operations headquarters for verifying technician CNICs, moderating disputes, managing service categories, and setting platform fees.
                      </p>
                    </div>
                    <div className="pt-4 mt-2">
                      <button
                        onClick={() => openAuthModal('admin', 'login')}
                        className="w-full py-2 px-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-xs cursor-pointer transition-all text-center flex items-center justify-center gap-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Admin Login</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Emergency SOS Banner */}
            <EmergencyBanner
              onOpenBookingForProvider={(provId) => handleOpenEmergencyBooking(provId)}
            />

            {/* Service Categories Grid */}
            <CategoryList
              selectedCategoryId={selectedCategoryId}
              onSelectCategory={(catId) => setSelectedCategoryId(catId)}
            />

            {/* Quick Filter Pill Buttons */}
            <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 pt-1 text-xs">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setOnlyAvailableNow(!onlyAvailableNow)}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    onlyAvailableNow
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      onlyAvailableNow ? 'bg-white animate-ping' : 'bg-emerald-500'
                    }`}
                  />
                  <span>🟢 Available Now Only</span>
                </button>

                <button
                  onClick={() => setOnlyVerified(!onlyVerified)}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    onlyVerified
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Verified Only</span>
                </button>
              </div>

              {/* Sort selector */}
              <div className="flex items-center gap-1.5 text-slate-500 shrink-0">
                <span className="text-[11px] font-semibold hidden sm:inline">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-white border border-slate-200 rounded-xl px-2.5 py-1 text-xs font-semibold text-slate-800"
                >
                  <option value="distance">Nearest Distance</option>
                  <option value="rating">Highest Rating</option>
                  <option value="price">Lowest Visit Fee</option>
                  <option value="jobs">Most Jobs Completed</option>
                </select>
              </div>
            </div>

            {/* Main Provider Cards Section */}
            <div>
              <div className="flex items-center justify-between mb-3 px-1">
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900">
                    {selectedCategoryId
                      ? `Available ${selectedCategoryId.replace('_', ' ').toUpperCase()}s`
                      : 'Nearby Verified Providers'}
                  </h2>
                  <p className="text-xs text-slate-500">
                    Showing technicians covering {selectedArea.name} ({filteredProviders.length} found)
                  </p>
                </div>
              </div>

              {/* Providers Grid */}
              {filteredProviders.length === 0 ? (
                <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
                  <Wrench className="w-12 h-12 text-slate-300 mx-auto" />
                  <h3 className="font-bold text-slate-700 text-sm">No providers match your criteria</h3>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Try disabling "Available Now Only" or clearing your search keywords.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCategoryId(null);
                      setSearchQuery('');
                      setOnlyAvailableNow(false);
                      setOnlyVerified(false);
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold cursor-pointer"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredProviders.map((provider) => (
                    <ProviderCard
                      key={provider.id}
                      provider={provider}
                      onViewProfile={(p) => setSelectedProviderForDetail(p)}
                      onBookNow={(p) => setBookingProvider({ provider: p, isEmergency: false })}
                      onInspectTrustScore={(p) => setInspectingTrustScoreProvider(p)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 py-2 px-4 md:hidden shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button
            onClick={() => setActiveView('home')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeView === 'home' ? 'text-emerald-700 font-bold' : 'text-slate-400'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px]">{t('home')}</span>
          </button>

          <button
            onClick={() => setActiveView('bookings')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeView === 'bookings' ? 'text-emerald-700 font-bold' : 'text-slate-400'
            }`}
          >
            <CalendarCheck2 className="w-5 h-5" />
            <span className="text-[10px]">{t('bookings')}</span>
          </button>

          <button
            onClick={() => setActiveView('messages')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeView === 'messages' ? 'text-emerald-700 font-bold' : 'text-slate-400'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px]">{t('messages')}</span>
          </button>

          <button
            onClick={() => setActiveView('favorites')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeView === 'favorites' ? 'text-emerald-700 font-bold' : 'text-slate-400'
            }`}
          >
            <Heart className="w-5 h-5" />
            <span className="text-[10px]">{t('favorites')}</span>
          </button>

          <button
            onClick={() => setActiveView('profile')}
            className={`flex flex-col items-center gap-0.5 cursor-pointer ${
              activeView === 'profile' ? 'text-emerald-700 font-bold' : 'text-slate-400'
            }`}
          >
            <UserIcon className="w-5 h-5" />
            <span className="text-[10px]">{t('profile')}</span>
          </button>
        </div>
      </nav>

      {/* AUTHENTICATION & LOGIN/SIGNUP MODAL */}
      <AuthModal />

      {/* MODAL 1: Provider Detail Modal */}
      {selectedProviderForDetail && (
        <ProviderDetailModal
          provider={selectedProviderForDetail}
          onClose={() => setSelectedProviderForDetail(null)}
          onBookNow={(p) => {
            setSelectedProviderForDetail(null);
            setBookingProvider({ provider: p, isEmergency: false });
          }}
          onOpenReport={(p) => {
            setSelectedProviderForDetail(null);
            setReportingProvider(p);
          }}
        />
      )}

      {/* MODAL 2: Booking Form Modal */}
      {bookingProvider && (
        <BookingModal
          provider={bookingProvider.provider}
          isEmergency={bookingProvider.isEmergency}
          onClose={() => setBookingProvider(null)}
          onSuccess={(bId) => {
            setBookingProvider(null);
            setActiveView('bookings');
          }}
        />
      )}

      {/* MODAL 3: In-App Chat Modal */}
      {activeChatBookingId && (
        <ChatModal
          bookingId={activeChatBookingId}
          onClose={() => setActiveChatBookingId(null)}
        />
      )}

      {/* MODAL 4: Star Review Modal */}
      {reviewBookingData && (
        <ReviewModal
          bookingId={reviewBookingData.bookingId}
          providerId={reviewBookingData.providerId}
          onClose={() => setReviewBookingData(null)}
        />
      )}

      {/* MODAL 5: User Incident Report Modal */}
      {reportingProvider && (
        <ReportModal
          provider={reportingProvider}
          onClose={() => setReportingProvider(null)}
        />
      )}

      {/* MODAL 6: Trust Score Algorithmic Breakdown Modal */}
      {inspectingTrustScoreProvider && (
        <TrustScoreModal
          provider={inspectingTrustScoreProvider}
          onClose={() => setInspectingTrustScoreProvider(null)}
        />
      )}

      {/* MODAL 7: Search Filters Modal */}
      {showFiltersModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">Filter Providers</h3>
              <button
                onClick={() => setShowFiltersModal(false)}
                className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-800">Available Now Only</span>
                <input
                  type="checkbox"
                  checked={onlyAvailableNow}
                  onChange={(e) => setOnlyAvailableNow(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-800">Identity & Police Verified Only</span>
                <input
                  type="checkbox"
                  checked={onlyVerified}
                  onChange={(e) => setOnlyVerified(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 rounded"
                />
              </label>

              <div>
                <span className="font-bold text-slate-700 block mb-1">Sort Providers By:</span>
                <div className="space-y-1">
                  {[
                    { id: 'distance', label: 'Nearest Distance (Karachi Neighborhood)' },
                    { id: 'rating', label: 'Highest Customer Rating' },
                    { id: 'price', label: 'Lowest Visit Fee' },
                    { id: 'jobs', label: 'Most Completed Jobs' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSortBy(s.id as any)}
                      className={`w-full p-2 rounded-xl text-left font-medium transition-colors cursor-pointer ${
                        sortBy === s.id
                          ? 'bg-emerald-50 text-emerald-950 font-bold border border-emerald-500'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowFiltersModal(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs cursor-pointer"
            >
              Apply Filters
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <MohallaProvider>
      <MohallaMain />
    </MohallaProvider>
  );
}
