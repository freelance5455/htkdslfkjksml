import { useState, useEffect } from "react";
import Hero from "./sections/Hero";
import Tablon from "./sections/Tablon";
import { Callejon, Cifras, Fiestas, Guia, Manifiesto, Pie, Vecinos } from "./sections/Cuerpo";
import QuienesSomos from "./sections/QuienesSomos";
import Estatutos from "./sections/Estatutos";
import Contacto from "./sections/Contacto";
import { Marca } from "./lib/ui";

type Pagina = "inicio" | "quienes-somos" | "estatutos" | "contacto";

const cinta = [
  "Padrón 2025 · 9.769 habitantes",
  "66,8 % nacidos fuera de España",
  "Mercadillo: todos los martes",
  "Fiestas patronales: 16 y 17 de enero",
  "Romería de San Isidro: mayo",
  "Virgen del Remedio: octubre",
  "Ayuntamiento · 966 79 42 01",
  "Vega Baja del Segura · Alicante",
];

const navInicio = [
  { id: "cifras", t: "Cifras" },
  { id: "pueblo", t: "El pueblo" },
  { id: "fiestas", t: "Fiestas" },
  { id: "tablon", t: "Tablón" },
  { id: "guia", t: "Guía" },
  { id: "vecinos", t: "Vecinos" },
];

const navPaginas: { pagina: Pagina; t: string }[] = [
  { pagina: "quienes-somos", t: "Quiénes somos" },
  { pagina: "estatutos", t: "Estatutos" },
  { pagina: "contacto", t: "Contacto" },
];

function Cabecera({
  pagina,
  setPagina,
  menuAbierto,
  setMenuAbierto,
}: {
  pagina: Pagina;
  setPagina: (p: Pagina) => void;
  menuAbierto: boolean;
  setMenuAbierto: (v: boolean) => void;
}) {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-tinta/15 bg-cal/95 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-[1440px] items-center justify-between gap-3 px-5 py-2 sm:gap-6 sm:px-8 lg:px-14">
        {/* Logo */}
        <button
          onClick={() => { setPagina("inicio"); setMenuAbierto(false); window.scrollTo(0, 0); }}
          className="flex cursor-pointer items-center gap-2 text-tinta"
          aria-label="Inicio"
        >
          <Marca className="h-12 w-auto" />
        </button>

        {/* Nav escritorio */}
        <nav aria-label="Navegación principal" className="hidden lg:flex lg:items-center lg:gap-1">
          {/* Secciones del inicio */}
          {pagina === "inicio" &&
            navInicio.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                className="label px-3 py-2 text-tinta/60 transition hover:text-naranja"
              >
                {n.t}
              </a>
            ))}

          {/* Separador */}
          {pagina === "inicio" && (
            <span className="mx-2 h-4 w-px bg-tinta/20" aria-hidden="true" />
          )}

          {/* Páginas fijas */}
          {navPaginas.map((n) => (
            <button
              key={n.pagina}
              onClick={() => { setPagina(n.pagina); setMenuAbierto(false); window.scrollTo(0, 0); }}
              className={`label cursor-pointer px-3 py-2 transition ${
                pagina === n.pagina
                  ? "text-naranja border-b-2 border-naranja"
                  : "text-tinta/60 hover:text-naranja"
              }`}
            >
              {n.t}
            </button>
          ))}
        </nav>

        {/* CTA + hamburguesa */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => { setPagina("contacto"); setMenuAbierto(false); window.scrollTo(0, 0); }}
            className="label hidden shrink-0 cursor-pointer bg-naranja px-4 py-3 text-cal transition hover:bg-tinta sm:block"
          >
            Contactar
          </button>

          {/* Hamburguesa móvil */}
          <button
            onClick={() => setMenuAbierto(!menuAbierto)}
            className="label flex cursor-pointer flex-col gap-[5px] p-2 lg:hidden"
            aria-expanded={menuAbierto}
            aria-label={menuAbierto ? "Cerrar menú" : "Abrir menú"}
          >
            <span className={`block h-[2px] w-5 bg-tinta transition-all ${menuAbierto ? "translate-y-[7px] rotate-45" : ""}`} />
            <span className={`block h-[2px] w-5 bg-tinta transition-all ${menuAbierto ? "opacity-0" : ""}`} />
            <span className={`block h-[2px] w-5 bg-tinta transition-all ${menuAbierto ? "-translate-y-[7px] -rotate-45" : ""}`} />
          </button>
        </div>
      </div>

      {/* Menú móvil desplegable */}
      {menuAbierto && (
        <div className="border-t border-tinta/15 bg-cal/98 pb-6 lg:hidden">
          <div className="mx-auto max-w-[1440px] px-5 pt-4 sm:px-8">
            {pagina === "inicio" && (
              <>
                <p className="label mb-2 text-taupe">Secciones</p>
                <div className="mb-4 grid grid-cols-3 gap-1">
                  {navInicio.map((n) => (
                    <a
                      key={n.id}
                      href={`#${n.id}`}
                      onClick={() => setMenuAbierto(false)}
                      className="label block px-3 py-3 text-center border border-tinta/15 text-tinta/70 hover:border-naranja hover:text-naranja transition"
                    >
                      {n.t}
                    </a>
                  ))}
                </div>
              </>
            )}
            <p className="label mb-2 text-taupe">Partido</p>
            <div className="grid grid-cols-1 gap-1">
              {navPaginas.map((n) => (
                <button
                  key={n.pagina}
                  onClick={() => { setPagina(n.pagina); setMenuAbierto(false); window.scrollTo(0, 0); }}
                  className={`label cursor-pointer w-full px-4 py-4 text-left border transition ${
                    pagina === n.pagina
                      ? "border-naranja bg-naranja/10 text-naranja"
                      : "border-tinta/15 text-tinta/70 hover:border-naranja hover:text-naranja"
                  }`}
                >
                  {n.t}
                </button>
              ))}
              <button
                onClick={() => { setPagina("contacto"); setMenuAbierto(false); window.scrollTo(0, 0); }}
                className="label cursor-pointer w-full bg-naranja px-4 py-4 text-left text-cal hover:bg-tinta transition"
              >
                Contactar →
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

function Rail() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed top-1/2 left-3 z-40 hidden -translate-y-1/2 xl:block"
    >
      <p
        className="label text-tinta/65"
        style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
      >
        38,11° N · 0,85° O — Vega Baja del Segura
      </p>
    </div>
  );
}

function Cinta() {
  const linea = [...cinta, ...cinta];
  return (
    <div className="marquee relative overflow-hidden border-y border-tinta/20 bg-naranja text-tinta">
      <div className="marquee-track flex w-max items-center gap-10 py-3 pr-10">
        {linea.map((c, i) => (
          <span key={i} className="label flex items-center gap-10 whitespace-nowrap">
            {c}
            <span aria-hidden="true" className="text-tinta/60">✳</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function PaginaInicio() {
  return (
    <>
      <Hero />
      <Cinta />
      <Cifras />
      <Manifiesto />
      <Callejon />
      <Fiestas />
      <Tablon />
      <Guia />
      <Vecinos />
    </>
  );
}

export default function App() {
  const [pagina, setPagina] = useState<Pagina>("inicio");
  const [menuAbierto, setMenuAbierto] = useState(false);

  // Cerrar menú al hacer scroll
  useEffect(() => {
    const onScroll = () => { if (menuAbierto) setMenuAbierto(false); };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [menuAbierto]);

  // Título de la pestaña por página
  useEffect(() => {
    const titulos: Record<Pagina, string> = {
      inicio: "Unidos por San Fulgencio | Tu pueblo, tu voz",
      "quienes-somos": "Quiénes somos · UpSF",
      estatutos: "Estatutos · UpSF",
      contacto: "Contacto · UpSF",
    };
    document.title = titulos[pagina];
  }, [pagina]);

  return (
    <div id="top" className="relative min-h-screen bg-cal text-tinta">
      <div className="grain" aria-hidden="true" />
      <Cabecera
        pagina={pagina}
        setPagina={setPagina}
        menuAbierto={menuAbierto}
        setMenuAbierto={setMenuAbierto}
      />
      <Rail />
      <main>
        {pagina === "inicio" && <PaginaInicio />}
        {pagina === "quienes-somos" && <QuienesSomos />}
        {pagina === "estatutos" && <Estatutos />}
        {pagina === "contacto" && <Contacto />}
      </main>
      <Pie pagina={pagina} setPagina={setPagina} />
    </div>
  );
}
