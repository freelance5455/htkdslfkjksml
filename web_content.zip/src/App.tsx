import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocialProvider } from './context/SocialContext';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { FeedView } from './components/FeedView';
import { ReelsView } from './components/ReelsView';
import { ProfileView } from './components/ProfileView';
import { AdminDashboard } from './components/AdminDashboard';
import { CreatePostModal } from './components/CreatePostModal';
import { CreateReelModal } from './components/CreateReelModal';
import { SearchModal } from './components/SearchModal';
import { NotificationsModal } from './components/NotificationsModal';
import { AndroidPackagingModal } from './components/AndroidPackagingModal';
import { FirebaseSettingsModal } from './components/FirebaseSettingsModal';
import { AuthModal } from './components/AuthModal';

function MainAppContent() {
  const { user } = useAuth();

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<'feed' | 'reels' | 'profile' | 'admin'>('feed');
  const [selectedProfileUserId, setSelectedProfileUserId] = useState<string | undefined>(undefined);

  // Modals state
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [isCreateReelOpen, setIsCreateReelOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isApkGuideOpen, setIsApkGuideOpen] = useState(false);
  const [isFirebaseSettingsOpen, setIsFirebaseSettingsOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const handleOpenUserProfile = (userId: string) => {
    setSelectedProfileUserId(userId);
    setActiveTab('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToMyProfile = () => {
    setSelectedProfileUserId(user?.id);
    setActiveTab('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] text-slate-900 flex flex-col font-sans">
      
      {/* Top Facebook-Style Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'profile') setSelectedProfileUserId(user?.id);
          setActiveTab(tab);
        }}
        onOpenCreatePost={() => setIsCreatePostOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
        onOpenFirebaseSettings={() => setIsFirebaseSettingsOpen(true)}
        onSelectUserForProfile={handleOpenUserProfile}
      />

      {/* Main Body Content */}
      <div className="flex-1 max-w-7xl w-full mx-auto pt-3 sm:pt-4 px-2 sm:px-4">
        {activeTab === 'feed' && (
          <FeedView
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
            onOpenCreateReel={() => setIsCreateReelOpen(true)}
            onOpenApkGuide={() => setIsApkGuideOpen(true)}
            onOpenFirebaseSettings={() => setIsFirebaseSettingsOpen(true)}
            onOpenProfile={handleOpenUserProfile}
            onNavigateToTab={setActiveTab}
          />
        )}

        {activeTab === 'reels' && (
          <div className="py-2">
            <ReelsView
              onOpenCreateReel={() => setIsCreateReelOpen(true)}
              onOpenProfile={handleOpenUserProfile}
            />
          </div>
        )}

        {activeTab === 'profile' && (
          <ProfileView
            targetUserId={selectedProfileUserId}
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboard
            onOpenProfile={handleOpenUserProfile}
          />
        )}
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'profile') setSelectedProfileUserId(user?.id);
          setActiveTab(tab);
        }}
        onOpenCreatePost={() => setIsCreatePostOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onGoToMyProfile={handleGoToMyProfile}
      />

      {/* Modals & Dialogs */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
      />

      <CreateReelModal
        isOpen={isCreateReelOpen}
        onClose={() => setIsCreateReelOpen(false)}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectUser={handleOpenUserProfile}
      />

      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
      />

      <AndroidPackagingModal
        isOpen={isApkGuideOpen}
        onClose={() => setIsApkGuideOpen(false)}
      />

      <FirebaseSettingsModal
        isOpen={isFirebaseSettingsOpen}
        onClose={() => setIsFirebaseSettingsOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SocialProvider>
        <MainAppContent />
      </SocialProvider>
    </AuthProvider>
  );
}
