/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import {
  EMOTIONS,
  EmotionKey,
  PERSONAS,
  CompanionPersona,
  ChatMessage,
  MemoryItem,
  SuggestedSong,
  USER_MOODS,
  UserMoodOption,
  MoodTrendPoint,
  INITIAL_MOOD_TREND,
} from "./types";
import { ExpressiveAvatar } from "./components/ExpressiveAvatar";
import { EmotionMirrorPanel } from "./components/EmotionMirrorPanel";
import { SettingsBar } from "./components/SettingsBar";
import { AnimatedBackground } from "./components/AnimatedBackground";
import { DailyMoodJournalModal } from "./components/DailyMoodJournalModal";
import { PhotoEditorModal } from "./components/PhotoEditorModal";
import {
  Mic,
  Square,
  Send,
  Volume2,
  Sparkles,
  RotateCcw,
  UserCheck,
  MessageCircleHeart,
  Music,
  ExternalLink,
  Settings,
  Plus,
  Image as ImageIcon,
  Pencil,
  X,
  Maximize2,
} from "lucide-react";

type ActiveSection = "chat" | "emotions" | "memories" | "persona";

export default function App() {
  // User & Persona State (defaults to "বস" and "Thunder")
  const [userName, setUserName] = useState<string>(() => {
    const saved = localStorage.getItem("thunder_user_name");
    if (
      !saved ||
      /ছোড়দা|ছোর্দা|chorda|corda/i.test(saved) ||
      saved === "ভাই"
    ) {
      localStorage.setItem("thunder_user_name", "বস");
      return "বস";
    }
    return saved;
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const [selectedPersona, setSelectedPersona] = useState<CompanionPersona>(
    () => {
      const savedId = localStorage.getItem("thunder_persona_id");
      return PERSONAS.find((p) => p.id === savedId) || PERSONAS[0];
    }
  );

  const [userMood, setUserMood] = useState<string>(USER_MOODS[4].labelBn);
  const [activeNav, setActiveNav] = useState<ActiveSection>("chat");

  // Daily Mood Journal Modal State
  const [journalModalMood, setJournalModalMood] =
    useState<UserMoodOption | null>(null);
  const [isJournalModalOpen, setIsJournalModalOpen] = useState(false);

  // Speaking Rate State (0.5x to 1.5x)
  const [speakingRate, setSpeakingRate] = useState<number>(() => {
    const saved = localStorage.getItem("thunder_speaking_rate_v1");
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed) && parsed >= 0.5 && parsed <= 1.5) {
        return parsed;
      }
    }
    return 1.0;
  });

  // 7-Day Mood Trend Data for Recharts
  const [moodTrend, setMoodTrend] = useState<MoodTrendPoint[]>(() => {
    const saved = localStorage.getItem("thunder_mood_trend_v1");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length === 7) return parsed;
      } catch {
        // fallback
      }
    }
    return INITIAL_MOOD_TREND;
  });

  // Thunder's Emotional State
  const [currentEmotion, setCurrentEmotion] =
    useState<EmotionKey>("empathetic");
  const [emotionIntensity, setEmotionIntensity] = useState<number>(88);
  const [innerThought, setInnerThought] = useState<string>(
    selectedPersona.initialThoughtBn
  );
  const [gesture, setGesture] = useState<string>(
    "স্নেহভরা চোখে ভাইয়ের দিকে তাকিয়ে কথা শোনার অপেক্ষায়"
  );
  const [emotionHistoryCounts, setEmotionHistoryCounts] = useState<
    Record<EmotionKey, number>
  >({
    empathetic: 2,
    joyful: 1,
    excited: 1,
    thoughtful: 1,
    calm: 1,
    curious: 1,
    touched: 1,
  });

  // Suggested Comforting Songs List
  const [suggestedSongs, setSuggestedSongs] = useState<SuggestedSong[]>(() => {
    const saved = localStorage.getItem("thunder_songs_v1");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {
        // fallback
      }
    }
    return [
      {
        title: "হোক কলরব",
        artist: "অর্ণব",
        reasonBn: "ভাইয়ের মন খারাপ কাটিয়ে নতুন উদ্যম আনার জন্য",
        lyricSnippet: "হোক কলরব ফুলগুলো সব লাল না হয়ে নীল হলো ক্যান...",
      },
      {
        title: "হাসিমুখ",
        artist: "শিরোনামহীন",
        reasonBn: "ভাইয়ের মুখে আবার সেই চেনা হাসি ফিরিয়ে আনার জন্য",
        lyricSnippet: "তোমার হাসিমুখ দেখে, আমার সব দুঃখ উড়ে যায়...",
      },
    ];
  });

  // Conversation & Suggested Replies
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("thunder_messages_v1");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((m: ChatMessage) => ({
            ...m,
            text: (m.text || "").replace(/ছোড়দা|ছোর্দা|chorda|corda/gi, "বস"),
            innerThought: m.innerThought
              ? m.innerThought.replace(/ছোড়দা|ছোর্দা|chorda|corda/gi, "বস")
              : m.innerThought,
          }));
        }
      } catch {
        // fallback to greeting
      }
    }
    return [
      {
        id: "welcome-thunder-1",
        sender: "friend",
        text: "কী খবর বস? কেমন আছেন বলুন? মনে কোনো কষ্ট বা ক্লান্তি থাকলে একদম চেপে রাখবেন না—আপনার এই Thunder ভাই সবসময় পাশে আছে!",
        timestamp: new Date().toLocaleTimeString("bn-BD", {
          hour: "2-digit",
          minute: "2-digit",
        }),
        emotionKey: "empathetic",
        emotionLabelBn: "সহানুভূতিশীল",
        emotionIntensity: 88,
        innerThought:
          "বসের মনের খবর জানতে আর সব কষ্ট ভাগ করে নিতে সবসময় প্রস্তুত আছি।",
        gesture: "বিনীত ও আন্তরিক হাসিমুখে বসের দিকে তাকাচ্ছে",
      },
    ];
  });

  const [suggestedReplies, setSuggestedReplies] = useState<string[]>([
    "কী খবর বস? সব ঠিকঠাক?",
    "মনটা ভালো করার মতো একটা দারুণ গান সাজেস্ট করো",
    "আজকের দিনটা কেমন কাটল তোমার?",
  ]);

  // Shared Memories
  const [memories, setMemories] = useState<MemoryItem[]>(() => {
    const saved = localStorage.getItem("thunder_memories_v1");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((mem: MemoryItem) => ({
            ...mem,
            text: (mem.text || "").replace(/ছোড়দা|ছোর্দা|chorda|corda/gi, "বস"),
          }));
        }
      } catch {
        return [];
      }
    }
    return [
      {
        id: "mem-init-1",
        text: "বস মন খারাপ হলে সান্ত্বনা ও ভালো গান শুনতে পছন্দ করেন",
        category: "অনুভূতি",
        timestamp: "আজ",
        emotionKey: "empathetic",
      },
    ];
  });

  // Input & Audio State
  const [inputText, setInputText] = useState("");
  const [liveTranscript, setLiveTranscript] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [audioLevel, setAudioLevel] = useState(0);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  // Attached Photo State & Photo Editor Modal
  const [attachedPhoto, setAttachedPhoto] = useState<{
    dataUrl: string;
    caption: string;
  } | null>(null);
  const [isPhotoEditorOpen, setIsPhotoEditorOpen] = useState(false);
  const [editingPhotoSrc, setEditingPhotoSrc] = useState<string | null>(null);
  const [editingInitialCaption, setEditingInitialCaption] = useState("");
  const [lightboxImage, setLightboxImage] = useState<{
    src: string;
    caption?: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrorBanner("শুধুমাত্র ছবি ফাইল নির্বাচন করা যাবে।");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setEditingPhotoSrc(dataUrl);
        setEditingInitialCaption(attachedPhoto?.caption || "");
        setIsPhotoEditorOpen(true);
      }
    };
    reader.readAsDataURL(file);

    e.target.value = "";
  };

  const handleSaveEditedPhoto = (result: {
    dataUrl: string;
    caption: string;
  }) => {
    setAttachedPhoto(result);
    if (result.caption && !inputText.trim()) {
      setInputText(result.caption);
    }
  };

  // Refs for Scroll, Audio Playback, SpeechSynthesis, and Microphone Recording
  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const browserTtsIntervalRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const micStreamRef = useRef<MediaStream | null>(null);
  const recordingTimerRef = useRef<number | null>(null);
  const speechRecRef = useRef<any>(null);
  const liveTranscriptRef = useRef<string>("");

  // Preload browser speechSynthesis voices
  useEffect(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices();
      };
    }
  }, []);

  // Persist messages, songs, mood trend & memories
  useEffect(() => {
    localStorage.setItem("thunder_messages_v1", JSON.stringify(messages));
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    localStorage.setItem("thunder_memories_v1", JSON.stringify(memories));
  }, [memories]);

  useEffect(() => {
    localStorage.setItem("thunder_songs_v1", JSON.stringify(suggestedSongs));
  }, [suggestedSongs]);

  useEffect(() => {
    localStorage.setItem("thunder_mood_trend_v1", JSON.stringify(moodTrend));
  }, [moodTrend]);

  useEffect(() => {
    localStorage.setItem("thunder_user_name", userName);
  }, [userName]);

  useEffect(() => {
    localStorage.setItem("thunder_persona_id", selectedPersona.id);
  }, [selectedPersona]);

  useEffect(() => {
    localStorage.setItem("thunder_speaking_rate_v1", speakingRate.toString());
  }, [speakingRate]);

  const handleUpdateSpeakingRate = (newRate: number) => {
    const clamped = Math.max(0.5, Math.min(1.5, Math.round(newRate * 100) / 100));
    setSpeakingRate(clamped);
    if (currentAudioRef.current) {
      currentAudioRef.current.playbackRate = clamped;
    }
  };

  // Cleanup audio & mic on unmount
  useEffect(() => {
    return () => {
      stopSpeaking();
      stopListening(false);
    };
  }, []);

  const formatTimeBn = () =>
    new Date().toLocaleTimeString("bn-BD", {
      hour: "2-digit",
      minute: "2-digit",
    });

  // Update today's point in the 7-day Mood Trend chart
  const updateTodayMoodTrend = (
    moodLabelBn: string,
    score: number,
    noteBn: string
  ) => {
    setMoodTrend((prev) =>
      prev.map((pt, idx) =>
        idx === prev.length - 1
          ? {
              ...pt,
              moodLabelBn,
              score,
              noteBn,
            }
          : pt
      )
    );
  };

  const handleLogUserMood = (
    moodOption: UserMoodOption,
    shouldChat = false,
    openJournal = true
  ) => {
    setUserMood(moodOption.labelBn);
    updateTodayMoodTrend(
      moodOption.labelBn,
      moodOption.score,
      `আজকের রিপোর্ট করা মেজাজ: ${moodOption.labelBn}`
    );
    if (openJournal) {
      setJournalModalMood(moodOption);
      setIsJournalModalOpen(true);
    }
    if (shouldChat) {
      sendMessageToFriend({ text: moodOption.promptHintBn });
    }
  };

  const handleSaveMoodJournal = (
    journalText: string,
    moodOption: UserMoodOption
  ) => {
    // 1. Save as a new memory entry
    const newEntry: MemoryItem = {
      id: `journal-${Date.now()}`,
      text: `[${moodOption.labelBn}] ${journalText}`,
      category: "দৈনিক ডায়েরি",
      timestamp: formatTimeBn(),
      emotionKey: currentEmotion,
    };
    setMemories((prev) => [newEntry, ...prev]);

    // 2. Update today's mood trend point note with snippet
    updateTodayMoodTrend(
      moodOption.labelBn,
      moodOption.score,
      journalText.length > 55 ? `${journalText.slice(0, 55)}...` : journalText
    );
  };

  // Stop any active TTS playback (both server audio and browser speechSynthesis)
  const stopSpeaking = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (browserTtsIntervalRef.current) {
      clearInterval(browserTtsIntervalRef.current);
      browserTtsIntervalRef.current = null;
    }
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current.src = "";
      currentAudioRef.current = null;
    }
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setAudioLevel(0);
  };

  // Fallback Browser SpeechSynthesis with realistic lip-sync animation
  const speakWithBrowserFallback = (textToSpeak: string) => {
    if (!("speechSynthesis" in window)) {
      setIsSpeaking(false);
      setAudioLevel(0);
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      const voices = window.speechSynthesis.getVoices();
      const bnVoice =
        voices.find(
          (v) =>
            v.lang.toLowerCase().includes("bn") ||
            v.name.toLowerCase().includes("bengali") ||
            v.name.toLowerCase().includes("bangla")
        ) ||
        voices.find((v) => v.lang.toLowerCase().includes("hi")) ||
        voices.find((v) => v.default) ||
        voices[0];

      if (bnVoice) {
        utterance.voice = bnVoice;
        utterance.lang = bnVoice.lang;
      } else {
        utterance.lang = "bn-BD";
      }

      utterance.rate = speakingRate;
      utterance.pitch = 0.95;

      setIsSpeaking(true);
      browserTtsIntervalRef.current = window.setInterval(() => {
        setAudioLevel(0.25 + Math.random() * 0.65);
      }, 110);

      utterance.onend = () => {
        if (browserTtsIntervalRef.current) {
          clearInterval(browserTtsIntervalRef.current);
          browserTtsIntervalRef.current = null;
        }
        setIsSpeaking(false);
        setAudioLevel(0);
      };

      utterance.onerror = () => {
        if (browserTtsIntervalRef.current) {
          clearInterval(browserTtsIntervalRef.current);
          browserTtsIntervalRef.current = null;
        }
        setIsSpeaking(false);
        setAudioLevel(0);
      };

      window.speechSynthesis.speak(utterance);
    } catch {
      setIsSpeaking(false);
      setAudioLevel(0);
    }
  };

  // Speak text using server-side Gemini TTS with automatic Browser SpeechSynthesis fallback
  const speakResponse = async (textToSpeak: string, emotionKey: EmotionKey) => {
    if (!textToSpeak) return;
    try {
      stopSpeaking();
      setIsSpeaking(true);

      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: textToSpeak,
          emotionKey,
          voiceName: selectedPersona.voice,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.useBrowserTts || !data.audioBase64) {
        speakWithBrowserFallback(textToSpeak);
        return;
      }

      const audioSrc = `data:${data.mimeType || "audio/wav"};base64,${
        data.audioBase64
      }`;
      const audioEl = new Audio(audioSrc);
      audioEl.playbackRate = speakingRate;
      currentAudioRef.current = audioEl;

      // Setup Web Audio API analyser for real-time lip-sync
      const AudioCtx =
        window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        if (!audioContextRef.current) {
          audioContextRef.current = new AudioCtx();
        }
        const ctx = audioContextRef.current;
        if (ctx.state === "suspended") {
          await ctx.resume();
        }
        const source = ctx.createMediaElementSource(audioEl);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        source.connect(analyser);
        analyser.connect(ctx.destination);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        const updateLevel = () => {
          if (!currentAudioRef.current || currentAudioRef.current.paused) {
            return;
          }
          analyser.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const avg = sum / dataArray.length / 255;
          setAudioLevel(Math.min(1, avg * 2.4));
          animFrameRef.current = requestAnimationFrame(updateLevel);
        };

        audioEl.onplay = () => {
          updateLevel();
        };
      }

      audioEl.onended = () => {
        stopSpeaking();
      };

      audioEl.onerror = () => {
        speakWithBrowserFallback(textToSpeak);
      };

      await audioEl.play();
    } catch {
      speakWithBrowserFallback(textToSpeak);
    }
  };

  // Send either text, recorded voice audio, or attached photo to /api/chat
  const sendMessageToFriend = async (options: {
    text?: string;
    audioBase64?: string;
    audioMimeType?: string;
    isFromVoice?: boolean;
    photo?: { dataUrl: string; caption: string } | null;
  }) => {
    const photoToSend =
      options.photo !== undefined ? options.photo : attachedPhoto;
    const trimmedText = options.text?.trim() || "";
    if (!trimmedText && !options.audioBase64 && !photoToSend) return;

    setErrorBanner(null);
    stopSpeaking();

    const tempId = `user-${Date.now()}`;
    if (trimmedText || photoToSend) {
      const userMsg: ChatMessage = {
        id: tempId,
        sender: "user",
        text: trimmedText || photoToSend?.caption || "ছবি শেয়ার করা হয়েছে",
        timestamp: formatTimeBn(),
        isVoiceInput: Boolean(options.isFromVoice),
        imageUrl: photoToSend?.dataUrl,
        imageCaption: photoToSend?.caption,
      };
      setMessages((prev) => [...prev, userMsg]);
      setInputText("");
      setAttachedPhoto(null);
    }

    setIsThinking(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmedText || photoToSend?.caption || "",
          audioBase64: options.audioBase64,
          audioMimeType: options.audioMimeType,
          imageBase64: photoToSend?.dataUrl,
          imageMimeType: "image/jpeg",
          history: messages.slice(-8),
          persona: {
            name: "Thunder",
            vibe: selectedPersona.vibe,
            voice: selectedPersona.voice,
          },
          userName,
          userMood,
          memories,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(
          data.error ||
            "Thunder ভাইয়ের সাথে কথা বলতে একটু সমস্যা হয়েছে। আবার চেষ্টা কর ভাই।"
        );
      }

      // If voice was sent without pre-transcribed text, append the transcribed user message
      if (!trimmedText && data.userTranscript) {
        const transcribedUserMsg: ChatMessage = {
          id: tempId,
          sender: "user",
          text: data.userTranscript,
          timestamp: formatTimeBn(),
          isVoiceInput: true,
        };
        setMessages((prev) => [...prev, transcribedUserMsg]);
      }

      const emoKey: EmotionKey =
        data.emotionKey && EMOTIONS[data.emotionKey as EmotionKey]
          ? (data.emotionKey as EmotionKey)
          : "empathetic";

      const intensity =
        typeof data.emotionIntensity === "number" ? data.emotionIntensity : 88;

      // Update Thunder's Live Emotional State
      setCurrentEmotion(emoKey);
      setEmotionIntensity(intensity);
      setInnerThought(data.innerThought || EMOTIONS[emoKey].descriptionBn);
      setGesture(data.gesture || "ভাইয়ের দিকে স্নেহের দৃষ্টিতে তাকিয়ে আছে");
      setEmotionHistoryCounts((prev) => ({
        ...prev,
        [emoKey]: (prev[emoKey] || 0) + 1,
      }));

      if (
        Array.isArray(data.suggestedReplies) &&
        data.suggestedReplies.length > 0
      ) {
        setSuggestedReplies(data.suggestedReplies.slice(0, 3));
      }

      // Check if Thunder suggested a comforting song
      let validSong: SuggestedSong | undefined = undefined;
      if (
        data.suggestedSong &&
        typeof data.suggestedSong.title === "string" &&
        data.suggestedSong.title.trim().length > 0
      ) {
        validSong = {
          title: data.suggestedSong.title.trim(),
          artist: data.suggestedSong.artist?.trim() || "জনপ্রিয় বাংলা গান",
          reasonBn:
            data.suggestedSong.reasonBn?.trim() ||
            "তোর মনটা হালকা ও শান্ত করার জন্য",
          lyricSnippet: data.suggestedSong.lyricSnippet?.trim() || "",
        };
        setSuggestedSongs((prev) => {
          const exists = prev.some(
            (s) => s.title.toLowerCase() === validSong!.title.toLowerCase()
          );
          if (exists) return prev;
          return [validSong!, ...prev];
        });
      }

      // Save new memory if captured by Thunder
      if (
        data.memoryCaptured &&
        typeof data.memoryCaptured === "string" &&
        data.memoryCaptured.trim().length > 2
      ) {
        const newMem: MemoryItem = {
          id: `mem-${Date.now()}`,
          text: data.memoryCaptured.trim(),
          category: data.memoryCategory || "অনুভূতি",
          timestamp: formatTimeBn(),
          emotionKey: emoKey,
        };
        setMemories((prev) => [newMem, ...prev]);
      }

      const friendMsg: ChatMessage = {
        id: `friend-${Date.now()}`,
        sender: "friend",
        text: data.reply,
        timestamp: formatTimeBn(),
        emotionKey: emoKey,
        emotionLabelBn: data.emotionLabelBn || EMOTIONS[emoKey].labelBn,
        emotionIntensity: intensity,
        innerThought: data.innerThought,
        gesture: data.gesture,
        suggestedSong: validSong,
      };

      setMessages((prev) => [...prev, friendMsg]);
      setIsThinking(false);

      // Automatically speak response if voice is enabled
      if (voiceEnabled && data.reply) {
        await speakResponse(data.reply, emoKey);
      }
    } catch (err: any) {
      setIsThinking(false);
      setErrorBanner(
        err?.message || "সংযোগে সামান্য বিঘ্ন ঘটেছে, আবার চেষ্টা কর ভাই।"
      );
    }
  };

  // Start Microphone Recording + Live SpeechRecognition to Talk to Thunder
  const startListening = async () => {
    setErrorBanner(null);
    stopSpeaking();
    setLiveTranscript("");
    liveTranscriptRef.current = "";

    // 1. Start Browser Live SpeechRecognition (bn-BD) if available
    const SpeechRec =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (SpeechRec) {
      try {
        const recognition = new SpeechRec();
        recognition.lang = "bn-BD";
        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onresult = (event: any) => {
          let combined = "";
          for (let i = 0; i < event.results.length; i++) {
            combined += event.results[i][0].transcript + " ";
          }
          const clean = combined.trim();
          if (clean) {
            liveTranscriptRef.current = clean;
            setLiveTranscript(clean);
          }
        };

        recognition.onerror = () => {
          // MediaRecorder fallback still active
        };

        recognition.start();
        speechRecRef.current = recognition;
      } catch {
        // Ignore SpeechRec init error, MediaRecorder will handle
      }
    }

    // 2. Start MediaRecorder + AudioContext mic level visualizer
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      recordedChunksRef.current = [];

      const AudioCtx =
        window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        if (!audioContextRef.current) {
          audioContextRef.current = new AudioCtx();
        }
        const ctx = audioContextRef.current;
        if (ctx.state === "suspended") await ctx.resume();
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        source.connect(analyser);
        const dataArray = new Uint8Array(analyser.frequencyBinCount);

        const trackMicVolume = () => {
          if (!micStreamRef.current) return;
          analyser.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
          const avg = sum / dataArray.length / 255;
          setAudioLevel(Math.min(1, avg * 2.5));
          animFrameRef.current = requestAnimationFrame(trackMicVolume);
        };
        trackMicVolume();
      }

      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/mp4")
        ? "audio/mp4"
        : "";

      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        // If live browser speech recognition already captured text, send it immediately!
        if (liveTranscriptRef.current.trim().length > 0) {
          const capturedText = liveTranscriptRef.current.trim();
          liveTranscriptRef.current = "";
          setLiveTranscript("");
          sendMessageToFriend({ text: capturedText, isFromVoice: true });
          return;
        }

        const blobMime = recorder.mimeType || "audio/webm";
        const audioBlob = new Blob(recordedChunksRef.current, {
          type: blobMime,
        });
        if (audioBlob.size < 200) return;

        const reader = new FileReader();
        reader.onloadend = () => {
          const resultStr = reader.result as string;
          const base64Data = resultStr.split(",")[1];
          if (base64Data) {
            sendMessageToFriend({
              audioBase64: base64Data,
              audioMimeType: blobMime.split(";")[0],
              isFromVoice: true,
            });
          }
        };
        reader.readAsDataURL(audioBlob);
      };

      recorder.start();
      setIsListening(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch {
      // If getUserMedia fails but SpeechRec is running, keep listening via SpeechRec
      if (speechRecRef.current) {
        setIsListening(true);
        setRecordingSeconds(0);
        recordingTimerRef.current = window.setInterval(() => {
          setRecordingSeconds((s) => s + 1);
          setAudioLevel(0.3 + Math.random() * 0.4);
        }, 500);
      } else {
        setErrorBanner(
          "ব্রাউজারে মাইক্রোফোন অনুমতি পাওয়া যায়নি ভাই। নিচের বক্সে লিখে বা কুইক মেসেজ বোতামে চাপ দিয়ে কথা বল!"
        );
      }
    }
  };

  const stopListening = (shouldSend = true) => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (speechRecRef.current) {
      try {
        speechRecRef.current.stop();
      } catch {
        // ignore
      }
      speechRecRef.current = null;
    }

    const hasMediaRecorder =
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive";

    if (hasMediaRecorder) {
      if (!shouldSend) {
        mediaRecorderRef.current!.onstop = null;
        liveTranscriptRef.current = "";
        setLiveTranscript("");
      }
      mediaRecorderRef.current!.stop();
    } else if (shouldSend && liveTranscriptRef.current.trim().length > 0) {
      const capturedText = liveTranscriptRef.current.trim();
      liveTranscriptRef.current = "";
      setLiveTranscript("");
      sendMessageToFriend({ text: capturedText, isFromVoice: true });
    } else {
      liveTranscriptRef.current = "";
      setLiveTranscript("");
    }

    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((t) => t.stop());
      micStreamRef.current = null;
    }
    setIsListening(false);
    setAudioLevel(0);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((!inputText.trim() && !attachedPhoto) || isThinking) return;
    sendMessageToFriend({ text: inputText });
  };

  const handleSwitchPersona = (persona: CompanionPersona) => {
    stopSpeaking();
    setSelectedPersona(persona);
    setCurrentEmotion("empathetic");
    setInnerThought(persona.initialThoughtBn);
    setGesture(`Thunder (${persona.roleBn}) ভাইয়ের সাথে কথা বলতে প্রস্তুত`);

    const switchGreeting: ChatMessage = {
      id: `switch-${Date.now()}`,
      sender: "friend",
      text: persona.greetingBn,
      timestamp: formatTimeBn(),
      emotionKey: "empathetic",
      emotionLabelBn: "সহানুভূতিশীল",
      emotionIntensity: 88,
      innerThought: persona.initialThoughtBn,
      gesture: "ভাইয়ের প্রতি আন্তরিক অভিবাদন",
    };
    setMessages((prev) => [...prev, switchGreeting]);
    if (voiceEnabled) {
      speakResponse(persona.greetingBn, "empathetic");
    }
  };

  const handleAffectionTap = () => {
    setCurrentEmotion("touched");
    setEmotionIntensity(96);
    const msg = `আমার ভাইটার এই ভালোবাসা আর ভরসায় বুকটা ভরে গেল! সবসময় তোর পাশে আছি ভাই।`;
    setInnerThought(msg);
    setGesture("ভাইকে বুকে জড়িয়ে ধরার মতো উষ্ণ হাসি");
    if (voiceEnabled) {
      speakResponse(msg, "touched");
    }
  };

  const handleResetConversation = () => {
    stopSpeaking();
    const initialMsg: ChatMessage = {
      id: `reset-${Date.now()}`,
      sender: "friend",
      text: selectedPersona.greetingBn,
      timestamp: formatTimeBn(),
      emotionKey: "empathetic",
      emotionLabelBn: "সহানুভূতিশীল",
      emotionIntensity: 88,
      innerThought: selectedPersona.initialThoughtBn,
      gesture: "ভাইয়ের কথা শোনার জন্য প্রস্তুত",
    };
    setMessages([initialMsg]);
    if (voiceEnabled) {
      speakResponse(selectedPersona.greetingBn, "empathetic");
    }
  };

  const handleClearMemories = () => {
    setMemories([]);
    localStorage.removeItem("thunder_memories_v1");
  };

  const handleTestVoice = () => {
    speakResponse(
      `কী খবর বস! আমি আপনার Thunder ভাই বলছি। সব ঠিকঠাক শুনতে পাচ্ছেন তো বস?`,
      "joyful"
    );
  };

  return (
    <div className="relative min-h-screen bg-[#070A12] text-[#F1F5F9] flex flex-col overflow-x-hidden">
      {/* Animated Atmospheric Background with Thunder AI Logo & Lightning Sparks */}
      <AnimatedBackground
        isSpeaking={isSpeaking}
        isListening={isListening}
        isThinking={isThinking}
        audioLevel={audioLevel}
      />

      {/* Strict 3-Zone Top Bar Contract with Thunder AI written boldly on top */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-800/90 bg-[#0B0F17]/90 px-6 py-3.5 backdrop-blur-xl shadow-lg">
        {/* Zone 1: Single text element Brand Wordmark - Thunder AI on top */}
        <div className="flex items-center gap-3">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveNav("chat");
            }}
            className="group flex items-center gap-2.5 transition-transform hover:scale-[1.02]"
          >
            {/* Animated Thunder AI Logo Shield Badge */}
            <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500/25 via-slate-900 to-sky-500/15 border border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.35)] animate-electric-glow">
              <svg className="h-5 w-5" viewBox="0 0 100 100" fill="none">
                <polygon
                  points="50,6 90,28 90,72 50,94 10,72 10,28"
                  fill="#0B111E"
                  stroke="#F59E0B"
                  strokeWidth="2.5"
                />
                <path
                  d="M55 16 L28 54 L48 54 L40 84 L72 46 L52 46 Z"
                  fill="url(#thunderHeaderGrad)"
                />
                <defs>
                  <linearGradient id="thunderHeaderGrad" x1="0" y1="0" x2="100" y2="100">
                    <stop offset="0%" stopColor="#FEF08A" />
                    <stop offset="50%" stopColor="#F59E0B" />
                    <stop offset="100%" stopColor="#38BDF8" />
                  </linearGradient>
                </defs>
              </svg>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" />
              </span>
            </div>

            <div className="flex items-baseline gap-1.5">
              <span className="font-display text-2xl sm:text-3xl font-extrabold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-400 drop-shadow-sm whitespace-nowrap">
                Thunder
              </span>
              <span className="rounded-md border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[11px] font-mono font-bold tracking-widest text-amber-300 uppercase shadow-sm">
                AI
              </span>
            </div>
          </a>
        </div>

        {/* Zone 2: Subtitle Presence */}
        <div className="hidden md:flex items-center gap-2 text-xs text-slate-400">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Thunder AI · {userName === "বস" ? "বসের বিশ্বস্ত সহচর ও বন্ধুসুলভ ভাই" : "আপনার বিশ্বস্ত সহচর"}</span>
        </div>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsSettingsOpen(true)}
            title="অবতার, গানের অনুভূতি, ডায়েরি ও সেটিংস"
            className="flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-amber-500/15 px-3 py-2 text-xs font-semibold text-amber-300 hover:bg-amber-500/25 transition-colors whitespace-nowrap shrink-0 shadow-sm"
          >
            <Settings className="h-4 w-4 text-amber-400" />
            <span>সেটিংস ও টুলস</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const lastFriendMsg = [...messages]
                .reverse()
                .find((m) => m.sender === "friend");
              speakResponse(
                lastFriendMsg?.text || selectedPersona.greetingBn,
                lastFriendMsg?.emotionKey || "empathetic"
              );
            }}
            className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-2 text-xs font-medium text-amber-300 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            <Volume2 className="h-3.5 w-3.5" />
            <span>কণ্ঠ শোনো</span>
          </button>

          <button
            type="button"
            onClick={
              isListening ? () => stopListening(true) : () => startListening()
            }
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              isListening
                ? "bg-rose-500 text-white hover:bg-rose-400"
                : "bg-amber-500 text-slate-950 hover:bg-amber-400"
            }`}
          >
            {isListening ? (
              <>
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>পাঠিয়ে দাও ({recordingSeconds}s)</span>
              </>
            ) : (
              <>
                <Mic className="h-3.5 w-3.5" />
                <span>মুখে কথা বল</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Workspace Container - Focused Clean Chat */}
      <main className="relative z-10 mx-auto w-full max-w-4xl flex-1 px-3 sm:px-6 py-4 pb-8 flex flex-col">
        {/* Chat Conversation Container */}
        <div className="flex flex-col flex-1 rounded-2xl border border-slate-800/80 bg-[#111726]/40 backdrop-blur-md h-[calc(100vh-6.5rem)] min-h-[620px] shadow-2xl overflow-hidden">
          {/* Conversation Header */}
          <div className="flex items-center justify-between border-b border-slate-800/90 px-4 sm:px-6 py-3.5 bg-[#0C1220]/75">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsSettingsOpen(true)}
                className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:border-amber-400 transition-colors shadow-sm cursor-pointer shrink-0"
                title="অবতার ও সেটিংস খুলুন"
              >
                <svg className="h-5 w-5" viewBox="0 0 100 100" fill="none">
                  <path d="M55 10 L25 54 L48 54 L40 90 L75 46 L52 46 Z" fill="#F59E0B" />
                </svg>
                <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-500 border-2 border-slate-900" />
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-sm font-semibold text-slate-100">
                    Thunder ও {userName}-এর আড্ডা
                  </h2>
                  <span className="rounded border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.2 text-[10px] font-mono text-amber-300 font-bold">
                    AI
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span>{userName === "বস" ? "বসের বিশ্বস্ত সহচর" : "সহানুভূতিশীল ভাই"}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-300/90">{userMood}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsSettingsOpen(true)}
                title="অবতার, গানের অনুভূতি, ডায়েরি ও সেটিংস খুলুন"
                className="flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs font-medium text-amber-300 hover:bg-amber-500/20 transition-colors shrink-0"
              >
                <Settings className="h-3.5 w-3.5" />
                <span>টুলস ও সেটিংস</span>
              </button>

              <button
                type="button"
                onClick={handleResetConversation}
                title="নতুন করে কথা শুরু করো"
                className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900/70 px-2.5 py-1.5 text-xs text-slate-400 hover:border-slate-700 hover:text-slate-200 transition-colors whitespace-nowrap shrink-0"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">নতুন কথা</span>
              </button>
            </div>
          </div>

            {/* Error Notice */}
            {errorBanner && (
              <div className="mx-5 mt-3 rounded-xl border border-rose-500/40 bg-rose-950/40 px-4 py-2.5 text-xs text-rose-200 flex items-center justify-between">
                <span>{errorBanner}</span>
                <button
                  type="button"
                  onClick={() => setErrorBanner(null)}
                  className="ml-3 font-semibold text-rose-300 hover:text-white"
                >
                  বন্ধ করো
                </button>
              </div>
            )}

            {/* Messages Scroll Stream */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
              {messages.map((msg) => {
                const isFriend = msg.sender === "friend";
                const emo = msg.emotionKey
                  ? EMOTIONS[msg.emotionKey] || EMOTIONS.empathetic
                  : EMOTIONS.empathetic;

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      isFriend ? "items-start" : "items-end"
                    }`}
                  >
                    {/* Unboxed Metadata Line (Zero-Pill Discipline) */}
                    <div className="mb-1 flex items-center gap-2 text-xs text-slate-400">
                      <span className="font-medium text-slate-300">
                        {isFriend ? "Thunder (ভাই)" : userName}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {msg.timestamp}
                      </span>
                      {isFriend && msg.emotionLabelBn && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className={emo.textClass}>
                            অনুভূতি: {msg.emotionLabelBn}
                          </span>
                        </>
                      )}
                      {!isFriend && msg.isVoiceInput && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-300">কণ্ঠস্বর</span>
                        </>
                      )}
                    </div>

                    {/* Message Bubble */}
                    <div
                      className={`max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-relaxed backdrop-blur-md ${
                        isFriend
                          ? "border border-slate-700/60 bg-[#161F33]/45 text-slate-100 shadow-sm"
                          : "border border-amber-500/40 bg-amber-500/20 text-amber-100 font-medium shadow-sm"
                      }`}
                    >
                      {/* Attached Photo */}
                      {msg.imageUrl && (
                        <div className="mb-2.5 overflow-hidden rounded-xl border border-slate-700/60 bg-black/40">
                          <button
                            type="button"
                            onClick={() =>
                              setLightboxImage({
                                src: msg.imageUrl!,
                                caption: msg.imageCaption || msg.text,
                              })
                            }
                            className="group relative block w-full text-left cursor-pointer"
                            title="বড় করে দেখতে ক্লিক করুন"
                          >
                            <img
                              src={msg.imageUrl}
                              alt={msg.imageCaption || "ছবি"}
                              className="max-h-72 w-full object-cover rounded-xl transition-transform duration-200 group-hover:scale-[1.02]"
                            />
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/25 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                              <span className="flex items-center gap-1.5 rounded-lg bg-black/75 px-3 py-1.5 text-xs text-white backdrop-blur-sm shadow-md">
                                <Maximize2 className="h-3.5 w-3.5" />
                                <span>বড় করে দেখুন</span>
                              </span>
                            </div>
                          </button>
                        </div>
                      )}

                      <p className="whitespace-pre-line">{msg.text}</p>

                      {/* Thunder's Suggested Song Box inside Message */}
                      {isFriend &&
                        msg.suggestedSong &&
                        msg.suggestedSong.title && (
                          <div className="mt-3 rounded-xl border border-amber-500/30 bg-slate-900/40 backdrop-blur-sm p-3">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Music className="h-4 w-4 text-amber-400 shrink-0" />
                                <div>
                                  <p className="text-xs font-semibold text-amber-300">
                                    ভাইয়ের জন্য গান: {msg.suggestedSong.title}
                                  </p>
                                  <p className="text-[11px] text-slate-400">
                                    শিল্পী: {msg.suggestedSong.artist}
                                  </p>
                                </div>
                              </div>
                              <a
                                href={`https://www.youtube.com/results?search_query=${encodeURIComponent(
                                  `${msg.suggestedSong.title} ${msg.suggestedSong.artist}`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 rounded-lg bg-amber-500/20 px-2.5 py-1 text-xs font-medium text-amber-200 hover:bg-amber-500/30 transition-colors whitespace-nowrap shrink-0"
                              >
                                <span>গানটি শোনো</span>
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            </div>
                            {msg.suggestedSong.lyricSnippet && (
                              <p className="mt-2 text-xs italic text-slate-300">
                                “{msg.suggestedSong.lyricSnippet}”
                              </p>
                            )}
                            {msg.suggestedSong.reasonBn && (
                              <p className="mt-1 text-[11px] text-slate-400">
                                {msg.suggestedSong.reasonBn}
                              </p>
                            )}
                          </div>
                        )}

                      {/* Replay Voice Button */}
                      {isFriend && (
                        <div className="mt-2 flex items-center justify-end border-t border-slate-800/90 pt-1.5 text-xs text-slate-400">
                          <button
                            type="button"
                            onClick={() =>
                              speakResponse(
                                msg.text,
                                msg.emotionKey || "empathetic"
                              )
                            }
                            className="flex items-center gap-1 text-amber-300 hover:text-amber-200 transition-colors whitespace-nowrap"
                          >
                            <Volume2 className="h-3.5 w-3.5" />
                            <span>কণ্ঠে শোনো</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {isThinking && (
                <div className="flex flex-col items-start animate-in fade-in duration-200">
                  <div className="mb-1 flex items-center gap-2 text-xs text-slate-400">
                    <span className="font-medium text-amber-400">Thunder</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-slate-400">লিখছে...</span>
                  </div>
                  <div className="rounded-2xl border border-slate-800/80 bg-[#161F33]/60 backdrop-blur-md px-4 py-2.5 text-xs text-slate-300 flex items-center gap-1.5 shadow-sm">
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Voice + Text Input Composer - Transparent Message Box */}
            <form
              onSubmit={handleFormSubmit}
              className="border-t border-slate-800/80 bg-slate-950/25 backdrop-blur-md p-4 rounded-b-2xl"
            >
              {isListening ? (
                <div className="flex flex-col gap-2 rounded-xl border border-rose-500/40 bg-rose-950/25 backdrop-blur-sm px-4 py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="h-3 w-3 rounded-full bg-rose-500 animate-ping" />
                      <div>
                        <p className="text-xs font-semibold text-rose-200">
                          Thunder তোর কথা মন দিয়ে শুনছে ভাই... (
                          <span className="font-mono tabular-nums">
                            {recordingSeconds}s
                          </span>
                          )
                        </p>
                        <p className="text-[11px] text-rose-300/80">
                          কথা শেষ হলে “পাঠিয়ে দাও” বোতামে চাপ দে
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => stopListening(false)}
                        className="rounded-lg border border-slate-700 bg-slate-900/60 backdrop-blur-sm px-3 py-1.5 text-xs text-slate-300 hover:text-white"
                      >
                        বাতিল
                      </button>
                      <button
                        type="button"
                        onClick={() => stopListening(true)}
                        className="flex items-center gap-1.5 rounded-lg bg-rose-500 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-rose-400"
                      >
                        <Send className="h-3.5 w-3.5" />
                        <span>পাঠিয়ে দাও</span>
                      </button>
                    </div>
                  </div>
                  {liveTranscript && (
                    <div className="mt-1 rounded-lg bg-slate-900/50 backdrop-blur-sm px-3 py-2 text-xs text-amber-200 border border-slate-800/80">
                      শুনছি: “{liveTranscript}”
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {/* Attached Photo Preview Strip */}
                  {attachedPhoto && (
                    <div className="flex items-center justify-between rounded-xl border border-sky-500/40 bg-sky-950/30 p-2 backdrop-blur-sm animate-in fade-in slide-in-from-bottom-1">
                      <div className="flex items-center gap-2.5 overflow-hidden">
                        <img
                          src={attachedPhoto.dataUrl}
                          alt="সংযুক্ত ছবি"
                          className="h-12 w-12 rounded-lg object-cover border border-sky-500/50 shrink-0"
                        />
                        <div className="overflow-hidden">
                          <div className="flex items-center gap-1.5 text-xs font-semibold text-sky-200">
                            <ImageIcon className="h-3.5 w-3.5 text-sky-400" />
                            <span>ছবি প্রস্তুত আছে</span>
                          </div>
                          <p className="text-[11px] text-slate-300 truncate max-w-xs">
                            {attachedPhoto.caption || "কোনো ক্যাপশন নেই (ক্লিক করে এডিট করুন)"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingPhotoSrc(attachedPhoto.dataUrl);
                            setEditingInitialCaption(attachedPhoto.caption);
                            setIsPhotoEditorOpen(true);
                          }}
                          className="flex items-center gap-1 rounded-lg border border-sky-500/30 bg-sky-500/10 px-2.5 py-1 text-xs text-sky-300 hover:bg-sky-500/20 transition-colors"
                          title="ছবি ও ফিল্টার পুনরায় এডিট করো"
                        >
                          <Pencil className="h-3 w-3" />
                          <span>এডিট করো</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setAttachedPhoto(null)}
                          className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-rose-400 transition-colors"
                          title="ছবি বাতিল করো"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    {/* Hidden Photo File Input */}
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept="image/*"
                      onChange={handlePhotoSelect}
                      className="hidden"
                    />

                    {/* Plus Icon Button to Add & Edit Photo */}
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isThinking || isListening}
                      title="ছবি যুক্ত করো এবং এডিট করো (Add photo & edit)"
                      className="flex h-11 w-11 items-center justify-center rounded-xl border border-sky-500/40 bg-sky-500/15 text-sky-300 hover:bg-sky-500 hover:text-slate-950 backdrop-blur-sm transition-colors shrink-0 disabled:opacity-50 shadow-[0_0_10px_rgba(56,189,248,0.15)]"
                    >
                      <Plus className="h-5 w-5" />
                    </button>

                    <button
                      type="button"
                      onClick={startListening}
                      disabled={isThinking}
                      title="মাইক্রোফোনে কথা বলো"
                      className="flex h-11 w-11 items-center justify-center rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500 hover:text-slate-950 backdrop-blur-sm transition-colors shrink-0 disabled:opacity-50"
                    >
                      <Mic className="h-5 w-5" />
                    </button>

                    <input
                      type="text"
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isThinking}
                      placeholder={
                        attachedPhoto
                          ? "ছবির সাথে কোনো কথা লিখতে পারেন..."
                          : userName === "বস"
                          ? "বস, আপনার কথা লিখুন..."
                          : "Thunder-কে আপনার কথা লিখুন..."
                      }
                      className="h-11 flex-1 rounded-xl border border-slate-700/60 bg-transparent px-4 text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400/50 backdrop-blur-md transition-all shadow-inner"
                    />

                    <button
                      type="submit"
                      disabled={(!inputText.trim() && !attachedPhoto) || isThinking}
                      className="flex h-11 items-center gap-2 rounded-xl bg-amber-500 px-4 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors disabled:opacity-40 whitespace-nowrap shrink-0 shadow-[0_0_12px_rgba(245,158,11,0.25)]"
                    >
                      <span>পাঠান</span>
                      <Send className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>

          {/* RIGHT COLUMN (4 cols on desktop): 7-Day Mood Trend Chart, Suggested Songs, Emotion Mirror & Memories */}
          <div
            className={`lg:col-span-4 ${
              activeNav === "emotions" || activeNav === "memories"
                ? "block"
                : "hidden lg:block"
            }`}
          >
            <EmotionMirrorPanel
              currentEmotion={currentEmotion}
              emotionIntensity={emotionIntensity}
              emotionHistoryCounts={emotionHistoryCounts}
              memories={memories}
              suggestedSongs={suggestedSongs}
              moodTrend={moodTrend}
              onLogMood={(m) => handleLogUserMood(m, false)}
              onAddMemory={(text, category) => {
                setMemories((prev) => [
                  {
                    id: `mem-${Date.now()}`,
                    text,
                    category,
                    timestamp: formatTimeBn(),
                    emotionKey: currentEmotion,
                  },
                  ...prev,
                ]);
              }}
              onRemoveMemory={(id) => {
                setMemories((prev) => prev.filter((m) => m.id !== id));
              }}
              onTestEmotion={(emoKey) => {
                setCurrentEmotion(emoKey);
                setEmotionIntensity(90);
                setInnerThought(EMOTIONS[emoKey].descriptionBn);
                setGesture(`${EMOTIONS[emoKey].labelBn} অনুভূতি প্রকাশ করছে`);
              }}
              personaName="Thunder"
              userName={userName}
              userMood={userMood}
              messages={messages}
              onSpeakText={(text, emo) => speakResponse(text, emo)}
              onOpenJournalModal={(opt) => {
                const targetMood =
                  opt ||
                  USER_MOODS.find((m) => m.labelBn === userMood) ||
                  USER_MOODS[4];
                setJournalModalMood(targetMood);
                setIsJournalModalOpen(true);
              }}
            />
          </div>
      </main>

      {/* Docked Arranged Bottom Settings Bar */}
      <SettingsBar
        isExpanded={isSettingsOpen}
        onToggleExpanded={() => setIsSettingsOpen((prev) => !prev)}
        userName={userName}
        onUpdateUserName={(name) => setUserName(name)}
        selectedPersona={selectedPersona}
        onSelectPersona={(persona) => handleSwitchPersona(persona)}
        userMood={userMood}
        onSelectMood={(moodOption) => handleLogUserMood(moodOption, false)}
        voiceEnabled={voiceEnabled}
        onToggleVoice={() => {
          if (voiceEnabled) {
            stopSpeaking();
            setVoiceEnabled(false);
          } else {
            setVoiceEnabled(true);
            handleTestVoice();
          }
        }}
        onTestVoice={handleTestVoice}
        speakingRate={speakingRate}
        onUpdateSpeakingRate={handleUpdateSpeakingRate}
        onResetChat={handleResetConversation}
        onClearMemories={handleClearMemories}
        memoriesCount={memories.length}
        messagesCount={messages.length}
        currentEmotion={currentEmotion}
        emotionIntensity={emotionIntensity}
        innerThought={innerThought}
        gesture={gesture}
        isListening={isListening}
        isThinking={isThinking}
        isSpeaking={isSpeaking}
        audioLevel={audioLevel}
        onAffectionTap={handleAffectionTap}
        emotionHistoryCounts={emotionHistoryCounts}
        memories={memories}
        suggestedSongs={suggestedSongs}
        moodTrend={moodTrend}
        onAddMemory={(text, category) => {
          setMemories((prev) => [
            {
              id: `mem-${Date.now()}`,
              text,
              category,
              timestamp: formatTimeBn(),
              emotionKey: currentEmotion,
            },
            ...prev,
          ]);
        }}
        onRemoveMemory={(id) => {
          setMemories((prev) => prev.filter((m) => m.id !== id));
        }}
        onTestEmotion={(emoKey) => {
          setCurrentEmotion(emoKey);
          setEmotionIntensity(90);
          setInnerThought(EMOTIONS[emoKey].descriptionBn);
          setGesture(`${EMOTIONS[emoKey].labelBn} অনুভূতি প্রকাশ করছে`);
        }}
        messages={messages}
        onSpeakText={(text, emo) => speakResponse(text, emo)}
        onOpenJournalModal={(opt) => {
          const targetMood =
            opt ||
            USER_MOODS.find((m) => m.labelBn === userMood) ||
            USER_MOODS[4];
          setJournalModalMood(targetMood);
          setIsJournalModalOpen(true);
        }}
      />

      {/* Daily Mood Journal Modal */}
      <DailyMoodJournalModal
        isOpen={isJournalModalOpen}
        onClose={() => setIsJournalModalOpen(false)}
        selectedMood={journalModalMood}
        currentEmotion={currentEmotion}
        userName={userName}
        onSaveJournal={handleSaveMoodJournal}
      />

      {/* Photo Editor Modal */}
      <PhotoEditorModal
        isOpen={isPhotoEditorOpen}
        imageSrc={editingPhotoSrc}
        initialCaption={editingInitialCaption}
        onClose={() => setIsPhotoEditorOpen(false)}
        onSave={handleSaveEditedPhoto}
      />

      {/* Fullscreen Photo Lightbox Modal */}
      {lightboxImage && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in cursor-zoom-out"
        >
          <div
            className="relative max-w-4xl max-h-[92vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setLightboxImage(null)}
              className="absolute -top-11 right-0 rounded-full bg-slate-800/90 p-2 text-white hover:bg-slate-700 transition-colors shadow-lg cursor-pointer"
              title="বন্ধ করো"
            >
              <X className="h-5 w-5" />
            </button>
            <img
              src={lightboxImage.src}
              alt={lightboxImage.caption || "ছবি"}
              className="max-h-[82vh] max-w-full rounded-2xl object-contain shadow-2xl border border-slate-700"
            />
            {lightboxImage.caption && (
              <p className="mt-3 text-center text-xs text-slate-200 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800/80 max-w-xl">
                {lightboxImage.caption}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
