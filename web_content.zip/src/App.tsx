import { MotionConfig } from 'framer-motion';
import VRGame from './components/VRGame';

export default function App() {
  return <MotionConfig reducedMotion="user"><VRGame /></MotionConfig>;
}
