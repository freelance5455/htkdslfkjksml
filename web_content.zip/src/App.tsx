import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Bike,
  Camera,
  Check,
  CloudFog,
  CloudRain,
  Compass,
  Copy,
  DoorOpen,
  Footprints,
  Home,
  LogOut,
  MessageSquare,
  Moon,
  Play,
  Power,
  RotateCw,
  SlidersHorizontal,
  Smartphone,
  Sun,
  Trophy,
  UserPlus,
  Users,
  Volume2,
  VolumeX,
  Wrench,
} from 'lucide-react';
import { FriendsModal } from './components/FriendsModal';
import { GameCanvas, type GameBridge } from './components/GameCanvas';
import { GeminiGarageModal } from './components/GeminiGarageModal';
import { Minimap } from './components/Minimap';
import { MissionsModal } from './components/MissionsModal';
import { RoomsModal } from './components/RoomsModal';
import { SettingsModal } from './components/SettingsModal';
import { WorkshopModal } from './components/WorkshopModal';
import {
  MultiplayerClient,
  addFriendById,
  registerPlayerProfile,
  removeFriendById,
  updateServerProfile,
} from './game/multiplayer';
import type {
  BikeCustomization,
  BikeModelType,
  DayTimePhase,
  FriendInfo,
  GameSettings,
  GameTelemetry,
  MissionDefinition,
  PlayerProgress,
  RoomInfo,
  SensitivityPreset,
  WeatherCondition,
} from './game/types';

const STORAGE_KEY = 'moto_win_progress_v1';
const SETTINGS_STORAGE_KEY = 'moto_win_settings_v1';
const PLAYER_ID_KEY = 'moto_win_player_id_v1';
const PLAYER_NAME_KEY = 'moto_win_player_name_v1';

const DEFAULT_SETTINGS: GameSettings = {
  sensitivityPreset: 'normal',
  steeringSensitivity: 1.0,
  wheelieSensitivity: 1.0,
};

function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<GameSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

const DEFAULT_CUSTOMIZATION: BikeCustomization = {
  bikeModel: 'cg_titan_160',
  colorId: 'vermelho_rally',
  tire: 'urbano',
  exhaust: 'original',
  handlebar: 'original',
  tailBar: 'original',
  motorLevel: 1,
  gearRatioLevel: 1,
  brakeLevel: 1,
  suspensionLevel: 1,
};

const DEFAULT_PROGRESS: PlayerProgress = {
  money: 800,
  xp: 0,
  level: 1,
  completedMissions: [],
  ownedModels: ['cg_titan_160', 'cg_fan_160'],
  ownedColors: ['vermelho_rally'],
  ownedTires: ['urbano'],
  ownedExhausts: ['original'],
  ownedHandlebars: ['original'],
  ownedTailBars: ['original'],
  customization: DEFAULT_CUSTOMIZATION,
};

function loadProgress(): PlayerProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<PlayerProgress>;
    return {
      ...DEFAULT_PROGRESS,
      ...parsed,
      ownedModels: parsed.ownedModels ?? DEFAULT_PROGRESS.ownedModels,
      customization: {
        ...DEFAULT_CUSTOMIZATION,
        ...(parsed.customization ?? {}),
      },
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

const INITIAL_TELEMETRY: GameTelemetry = {
  x: 7,
  y: 0,
  z: -10,
  heading: Math.PI * 0.82,
  speedKmh: 0,
  rpm: 0,
  gear: 0,
  engineOn: false,
  cranking: false,
  wheelieDeg: 0,
  leanDeg: 0,
  isWheelieing: false,
  isScraping: false,
  crashed: false,
  currentGrauScore: 0,
  bestGrauScore: 0,
  totalGrauDistM: 0,
  zone: 'Casa Principal',
  weather: 'sol',
  timeOfDay: 0.44,
  timePhase: 'dia',
  clockLabel: '10:33',
  gripFactor: 1,
  cameraMode: 'chase',
  isOnFoot: false,
  nearMoto: true,
  nearHouseDoor: false,
  houseDoorOpen: false,
  insideHouse: false,
  activeMission: null,
  missionTargetPos: null,
  enemyPositions: [],
  remotePlayers: [],
};

function loadSavedPlayerId(): string {
  try {
    return localStorage.getItem(PLAYER_ID_KEY) ?? '';
  } catch {
    return '';
  }
}

function loadSavedPlayerName(): string {
  try {
    return localStorage.getItem(PLAYER_NAME_KEY) || 'Piloto 160';
  } catch {
    return 'Piloto 160';
  }
}

export default function App() {
  const bridgeRef = useRef<GameBridge | null>(null);
  const mpClientRef = useRef<MultiplayerClient | null>(null);
  const autoEnterOnJoinRef = useRef(false);

  const [enteredGame, setEnteredGame] = useState(false);
  const [isPortraitMobile, setIsPortraitMobile] = useState(false);
  const [muted, setMuted] = useState(false);

  const [progress, setProgress] = useState<PlayerProgress>(loadProgress);
  const [settings, setSettings] = useState<GameSettings>(loadSettings);
  const [telemetry, setTelemetry] = useState<GameTelemetry>(INITIAL_TELEMETRY);

  const [playerId, setPlayerId] = useState<string>(loadSavedPlayerId);
  const [playerName, setPlayerName] = useState<string>(loadSavedPlayerName);
  const [friends, setFriends] = useState<FriendInfo[]>([]);
  const [wsConnected, setWsConnected] = useState(false);
  const [activeRoom, setActiveRoom] = useState<RoomInfo | null>(null);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [copiedRoomHud, setCopiedRoomHud] = useState(false);

  const [workshopOpen, setWorkshopOpen] = useState(false);
  const [missionsOpen, setMissionsOpen] = useState(false);
  const [garageOpen, setGarageOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [friendsOpen, setFriendsOpen] = useState(false);
  const [roomsOpen, setRoomsOpen] = useState(false);

  const [bannerNotice, setBannerNotice] = useState<{
    title: string;
    detail: string;
    tone: 'success' | 'warn';
  } | null>(null);

  // Active button visual press feedback
  const [pressedBtns, setPressedBtns] = useState({
    throttle: false,
    brake: false,
    wheelie: false,
    left: false,
    right: false,
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {
      // Ignore storage quota errors
    }
    bridgeRef.current?.applyCustomization(progress.customization);
  }, [progress]);

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage quota errors
    }
    bridgeRef.current?.applySettings(settings);
  }, [settings]);

  useEffect(() => {
    const checkOrientation = () => {
      const portrait = window.innerHeight > window.innerWidth && window.innerWidth < 1024;
      setIsPortraitMobile(portrait);
    };
    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  const showNotice = useCallback((title: string, detail: string, tone: 'success' | 'warn') => {
    setBannerNotice({ title, detail, tone });
    window.setTimeout(() => {
      setBannerNotice((prev) => (prev?.title === title ? null : prev));
    }, 4200);
  }, []);

  const handleEnterHorizontal = useCallback(() => {
    try {
      const docEl = document.documentElement;
      const orientation = screen.orientation as unknown as {
        lock?: (mode: string) => Promise<void>;
      };
      if (docEl.requestFullscreen && !document.fullscreenElement) {
        void docEl
          .requestFullscreen()
          .then(() => {
            if (orientation && typeof orientation.lock === 'function') {
              return orientation.lock('landscape').catch(() => {});
            }
            return undefined;
          })
          .catch(() => {});
      } else if (orientation && typeof orientation.lock === 'function') {
        void orientation.lock('landscape').catch(() => {});
      }
    } catch {
      // Fallback CSS landscape rotation handles locked/iOS/iframe viewports automatically
    }
    bridgeRef.current?.unlockAudio();
    setEnteredGame(true);
    window.setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 80);
  }, []);

  const handleLockLandscapeOnly = async () => {
    try {
      const docEl = document.documentElement;
      if (docEl.requestFullscreen && !document.fullscreenElement) {
        await docEl.requestFullscreen().catch(() => {});
      }
      const orientation = screen.orientation as unknown as {
        lock?: (mode: string) => Promise<void>;
      };
      if (orientation && typeof orientation.lock === 'function') {
        await orientation.lock('landscape').catch(() => {});
      }
    } catch {
      // Ignore browser restriction errors
    }
  };

  // Register real Player ID on backend and connect WebSocket
  useEffect(() => {
    let cancelled = false;
    const client = new MultiplayerClient({
      onConnectionChange: (connected) => {
        if (!cancelled) setWsConnected(connected);
      },
      onFriendsUpdated: (nextFriends, notice) => {
        if (cancelled) return;
        setFriends(nextFriends);
        if (notice) showNotice('Amigos', notice, 'success');
      },
      onRoomJoined: (room, remoteStates, doorOpen) => {
        if (cancelled) return;
        setRoomError(null);
        setActiveRoom(room);
        bridgeRef.current?.clearRemotePlayers();
        remoteStates.forEach((s) => bridgeRef.current?.upsertRemotePlayerState(s));
        bridgeRef.current?.syncDoorState(doorOpen);
        if (autoEnterOnJoinRef.current) {
          autoEnterOnJoinRef.current = false;
          setRoomsOpen(false);
          setFriendsOpen(false);
          void handleEnterHorizontal();
          showNotice(`Sala ${room.roomId}`, 'Você entrou no mesmo mapa com seu amigo!', 'success');
        }
      },
      onRoomUpdated: (room, notice) => {
        if (cancelled) return;
        setActiveRoom(room);
        if (notice) showNotice(`Sala ${room.roomId}`, notice, 'success');
      },
      onRoomLeft: () => {
        if (cancelled) return;
        setActiveRoom(null);
        bridgeRef.current?.clearRemotePlayers();
      },
      onRoomError: (message) => {
        if (cancelled) return;
        autoEnterOnJoinRef.current = false;
        setRoomError(message);
      },
      onRemoteState: (state) => {
        bridgeRef.current?.upsertRemotePlayerState(state);
      },
      onRemoteLeft: (pid) => {
        bridgeRef.current?.removeRemotePlayer(pid);
      },
      onDoorSync: (open) => {
        bridgeRef.current?.syncDoorState(open);
      },
    });
    mpClientRef.current = client;

    const savedId = loadSavedPlayerId();
    const savedName = loadSavedPlayerName();
    const model = progress.customization.bikeModel ?? 'cg_titan_160';

    registerPlayerProfile({ playerId: savedId || undefined, name: savedName, bikeModel: model })
      .then((data) => {
        if (cancelled) return;
        setPlayerId(data.player.id);
        setPlayerName(data.player.name);
        setFriends(data.friends);
        try {
          localStorage.setItem(PLAYER_ID_KEY, data.player.id);
          localStorage.setItem(PLAYER_NAME_KEY, data.player.name);
        } catch {
          // Ignore storage error
        }
        client.connect({
          playerId: data.player.id,
          name: data.player.name,
          bikeModel: data.player.bikeModel,
        });
      })
      .catch(() => {
        // Retry handled on reconnect / user action
      });

    return () => {
      cancelled = true;
      client.disconnect();
    };
  }, [handleEnterHorizontal, showNotice]);

  useEffect(() => {
    if (!playerId) return;
    mpClientRef.current?.updateIdentity({
      playerId,
      name: playerName,
      bikeModel: progress.customization.bikeModel ?? 'cg_titan_160',
    });
  }, [playerId, playerName, progress.customization.bikeModel]);

  const handleSavePlayerName = async (nextName: string) => {
    const clean = nextName.trim().slice(0, 20);
    if (!clean || !playerId) return;
    await updateServerProfile({
      playerId,
      name: clean,
      bikeModel: progress.customization.bikeModel ?? 'cg_titan_160',
    });
    setPlayerName(clean);
    try {
      localStorage.setItem(PLAYER_NAME_KEY, clean);
    } catch {
      // Ignore storage error
    }
  };

  const handleAddFriend = async (friendId: string) => {
    if (!playerId) throw new Error('Aguardando geração do seu ID...');
    const res = await addFriendById(playerId, friendId);
    setFriends(res.friends);
  };

  const handleRemoveFriend = async (friendId: string) => {
    if (!playerId) return;
    const updated = await removeFriendById(playerId, friendId);
    setFriends(updated);
  };

  const handleCreateRoom = () => {
    setRoomError(null);
    autoEnterOnJoinRef.current = false;
    mpClientRef.current?.createRoom();
  };

  const handleJoinRoom = (roomId: string) => {
    setRoomError(null);
    autoEnterOnJoinRef.current = true;
    mpClientRef.current?.joinRoom(roomId);
  };

  const handleLeaveRoom = () => {
    mpClientRef.current?.leaveRoom();
    setActiveRoom(null);
    bridgeRef.current?.clearRemotePlayers();
  };

  const handleCopyRoomHud = async () => {
    if (!activeRoom) return;
    try {
      await navigator.clipboard.writeText(activeRoom.roomId);
      setCopiedRoomHud(true);
      window.setTimeout(() => setCopiedRoomHud(false), 1600);
    } catch {
      // Ignore
    }
  };

  const handleMissionComplete = useCallback(
    (def: MissionDefinition) => {
      setProgress((prev) => {
        const nextXp = prev.xp + def.rewardXp;
        const nextLevel = 1 + Math.floor(nextXp / 300);
        const completed = prev.completedMissions.includes(def.id)
          ? prev.completedMissions
          : [...prev.completedMissions, def.id];
        return {
          ...prev,
          money: prev.money + def.rewardMoney,
          xp: nextXp,
          level: nextLevel,
          completedMissions: completed,
        };
      });
      showNotice(
        `Missão Concluída: ${def.title}`,
        `+ R$ ${def.rewardMoney} · + ${def.rewardXp} XP`,
        'success'
      );
    },
    [showNotice]
  );

  const handleMissionFail = useCallback(
    (def: MissionDefinition, reason: string) => {
      showNotice(`Missão Falhou: ${def.title}`, reason, 'warn');
    },
    [showNotice]
  );

  const bindHoldControl = (key: keyof typeof pressedBtns) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
      setPressedBtns((p) => ({ ...p, [key]: true }));
      bridgeRef.current?.setControl(key, true);
    },
    onPointerUp: (e: React.PointerEvent) => {
      e.preventDefault();
      setPressedBtns((p) => ({ ...p, [key]: false }));
      bridgeRef.current?.setControl(key, false);
    },
    onPointerCancel: () => {
      setPressedBtns((p) => ({ ...p, [key]: false }));
      bridgeRef.current?.setControl(key, false);
    },
    onLostPointerCapture: () => {
      setPressedBtns((p) => ({ ...p, [key]: false }));
      bridgeRef.current?.setControl(key, false);
    },
  });

  const handleBuyModel = (bikeModel: BikeModelType, price: number) => {
    setProgress((prev) => {
      const ownedList = prev.ownedModels ?? ['cg_titan_160', 'cg_fan_160'];
      const owned = ownedList.includes(bikeModel);
      if (!owned && prev.money < price) return prev;
      return {
        ...prev,
        money: owned ? prev.money : prev.money - price,
        ownedModels: owned ? ownedList : [...ownedList, bikeModel],
        customization: { ...prev.customization, bikeModel },
      };
    });
  };

  const handleSelectSensitivityPreset = (preset: SensitivityPreset) => {
    setSettings({
      sensitivityPreset: preset,
      steeringSensitivity: preset === 'alta' ? 1.65 : 1.0,
      wheelieSensitivity: preset === 'alta' ? 1.3 : 1.0,
    });
  };

  const handleChangeSteeringSensitivity = (val: number) => {
    setSettings((prev) => ({
      ...prev,
      sensitivityPreset: val >= 1.4 ? 'alta' : 'normal',
      steeringSensitivity: val,
    }));
  };

  const handleChangeWheelieSensitivity = (val: number) => {
    setSettings((prev) => ({
      ...prev,
      wheelieSensitivity: val,
    }));
  };

  const handleBuyColor = (colorId: string, price: number) => {
    setProgress((prev) => {
      const owned = prev.ownedColors.includes(colorId);
      if (!owned && prev.money < price) return prev;
      return {
        ...prev,
        money: owned ? prev.money : prev.money - price,
        ownedColors: owned ? prev.ownedColors : [...prev.ownedColors, colorId],
        customization: { ...prev.customization, colorId },
      };
    });
  };

  const handleBuyPart = (
    category: 'tire' | 'exhaust' | 'handlebar' | 'tailBar',
    id: string,
    price: number
  ) => {
    setProgress((prev) => {
      const ownedKey =
        category === 'tire'
          ? 'ownedTires'
          : category === 'exhaust'
            ? 'ownedExhausts'
            : category === 'handlebar'
              ? 'ownedHandlebars'
              : 'ownedTailBars';
      const list = prev[ownedKey] as string[];
      const owned = list.includes(id);
      if (!owned && prev.money < price) return prev;
      return {
        ...prev,
        money: owned ? prev.money : prev.money - price,
        [ownedKey]: owned ? list : [...list, id],
        customization: {
          ...prev.customization,
          [category]: id,
        },
      };
    });
  };

  const handleUpgradeStat = (
    stat: keyof Pick<
      BikeCustomization,
      'motorLevel' | 'gearRatioLevel' | 'brakeLevel' | 'suspensionLevel'
    >,
    price: number
  ) => {
    setProgress((prev) => {
      const cur = prev.customization[stat];
      if (cur >= 3 || prev.money < price) return prev;
      return {
        ...prev,
        money: prev.money - price,
        customization: {
          ...prev.customization,
          [stat]: cur + 1,
        },
      };
    });
  };

  const weatherLabel: Record<WeatherCondition, string> = {
    sol: 'Sol',
    chuva: 'Chuva',
    neblina: 'Neblina',
  };

  const phaseLabel: Record<DayTimePhase, string> = {
    amanhecer: 'Amanhecer',
    dia: 'Dia',
    entardecer: 'Pôr do Sol',
    noite: 'Noite',
  };

  const activeMission = telemetry.activeMission;
  const distToTarget =
    telemetry.missionTargetPos
      ? Math.round(
          Math.hypot(telemetry.x - telemetry.missionTargetPos.x, telemetry.z - telemetry.missionTargetPos.z)
        )
      : null;

  const forceCssLandscape = enteredGame && isPortraitMobile;

  return (
    <div
      className={
        forceCssLandscape
          ? 'fixed top-0 left-full w-[100dvh] h-[100dvw] origin-top-left rotate-90 overflow-hidden bg-neutral-950 select-none'
          : 'relative w-screen h-screen overflow-hidden bg-neutral-950 select-none'
      }
    >
      {/* 3D Open-World Canvas */}
      <GameCanvas
        ref={bridgeRef}
        initialCustomization={progress.customization}
        initialSettings={settings}
        showcaseMode={!enteredGame}
        inRoom={Boolean(activeRoom)}
        onTelemetry={setTelemetry}
        onMissionComplete={handleMissionComplete}
        onMissionFail={handleMissionFail}
        onSendPlayerState={(state) => mpClientRef.current?.sendPlayerState(state)}
        onDoorStateChanged={(open) => mpClientRef.current?.sendDoorState(open)}
      />

      {/* Landscape Entry Menu */}
      {!enteredGame && (
        <div className="absolute inset-0 z-40 flex flex-col justify-between bg-gradient-to-r from-neutral-950/92 via-neutral-950/60 to-neutral-950/25 p-3 sm:p-6">
          {/* Top Bar: ID Left | MOTO WIN Top-Center | Horizontal / Tools Right */}
          <div className="relative flex items-start justify-between gap-3">
            <div className="bg-neutral-950/85 border border-white/15 rounded-xl px-3 py-2 shadow-lg">
              <div className="text-[11px] text-neutral-400">Seu ID de Piloto</div>
              <div className="flex items-center gap-2">
                <span className="font-mono-tabular text-sm font-bold text-amber-400">
                  {playerId || '...'}
                </span>
                <span aria-hidden="true" className="text-neutral-600">·</span>
                <span className="text-xs font-semibold text-white truncate max-w-[110px]">
                  {playerName}
                </span>
              </div>
            </div>

            {/* Title strictly Top-Center */}
            <div className="absolute left-1/2 -translate-x-1/2 top-0 text-center pointer-events-none">
              <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight text-white drop-shadow-lg whitespace-nowrap">
                Moto Win
              </h1>
              <div className="mx-auto mt-1 h-1 w-20 rounded-full bg-amber-400" />
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleLockLandscapeOnly}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-950/85 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-amber-300 shadow-lg transition-colors cursor-pointer whitespace-nowrap"
                title="Deixar celular na horizontal"
              >
                <Smartphone className="w-4 h-4 rotate-90" />
                <RotateCw className="w-3 h-3 -ml-1" />
                <span className="hidden sm:inline">Deixar na Horizontal</span>
              </button>
              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                className="p-2.5 rounded-xl bg-neutral-950/85 hover:bg-neutral-800 border border-white/15 text-neutral-200 shadow-lg transition-colors cursor-pointer"
                title="Configurações"
                aria-label="Configurações"
              >
                <SlidersHorizontal className="w-4 h-4 text-amber-300" />
              </button>
            </div>
          </div>

          {/* Portrait Warning Banner when mobile is vertical */}
          {isPortraitMobile && (
            <div className="mx-auto mt-10 flex items-center justify-between gap-3 rounded-xl bg-amber-500 text-neutral-950 px-4 py-2.5 shadow-xl max-w-md w-full">
              <div className="flex items-center gap-2 text-xs font-bold">
                <Smartphone className="w-4 h-4 rotate-90 shrink-0" />
                <span>Deite o celular na horizontal para jogar!</span>
              </div>
              <button
                type="button"
                onClick={handleLockLandscapeOnly}
                className="px-3 py-1.5 rounded-lg bg-neutral-950 text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
              >
                Deixar na Horizontal
              </button>
            </div>
          )}

          {/* Left Main Menu Panel (keeps 3D 160cc showcase clear on the right) */}
          <div className="my-auto w-full max-w-xs sm:max-w-sm space-y-3 pt-10 sm:pt-4">
            <div className="bg-neutral-950/85 border border-white/15 rounded-2xl p-4 sm:p-5 shadow-2xl space-y-2.5">
              <button
                type="button"
                onClick={handleEnterHorizontal}
                className="w-full flex items-center justify-between px-5 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-neutral-950 font-display font-bold text-lg tracking-wide transition-all cursor-pointer shadow-lg"
              >
                <span>Jogar</span>
                <Play className="w-5 h-5 fill-current" />
              </button>

              <button
                type="button"
                onClick={() => setFriendsOpen(true)}
                className="w-full flex items-center justify-between px-5 py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/15 text-white font-display font-bold text-base transition-colors cursor-pointer"
              >
                <span>Adicionar Amigos</span>
                <UserPlus className="w-5 h-5 text-sky-400" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setRoomError(null);
                  setRoomsOpen(true);
                }}
                className="w-full flex items-center justify-between px-5 py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/15 text-white font-display font-bold text-base transition-colors cursor-pointer"
              >
                <span>Criar Sala</span>
                <DoorOpen className="w-5 h-5 text-emerald-400" />
              </button>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setWorkshopOpen(true)}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-neutral-200 transition-colors cursor-pointer"
                >
                  <Wrench className="w-3.5 h-3.5 text-sky-400" />
                  <span>Oficina 160</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSettingsOpen(true)}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-neutral-200 transition-colors cursor-pointer"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
                  <span>Sensibilidade</span>
                </button>
              </div>
            </div>
          </div>

          {/* Subtle Bottom Helper Strip */}
          <div className="flex items-center justify-between text-[11px] text-neutral-300">
            <div className="bg-neutral-950/80 border border-white/10 rounded-xl px-3 py-1.5 flex items-center gap-2">
              <Bike className="w-3.5 h-3.5 text-amber-400" />
              <span>160cc Mundo Aberto · Limite 140 km/h · Grau Realista</span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 bg-neutral-950/80 border border-white/10 rounded-xl px-3 py-1.5">
              <span className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-400' : 'bg-amber-400'}`} />
              <span>{wsConnected ? 'Multiplayer Online' : 'Conectando servidor...'}</span>
            </div>
          </div>
        </div>
      )}

      {/* In-Game HUD (strictly horizontal landscape) */}
      {enteredGame && (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-2.5 sm:p-4">
          {/* TOP ROW */}
          <div className="flex items-start justify-between gap-3">
            {/* Top-Left: Mini Speedometer + Brand + Zone + Weather / Day-Night Controls */}
            <div className="pointer-events-auto flex flex-col items-start gap-1.5">
              <div className="flex items-center gap-1.5">
                {/* Tiny Top-Left Speedometer */}
                {!telemetry.isOnFoot && (
                  <div className="bg-neutral-950/90 border border-white/15 rounded-lg px-2 py-1 shadow-lg min-w-[76px]">
                    <div className="flex items-baseline justify-between gap-1.5 font-mono-tabular leading-none">
                      <span className="text-sm font-bold text-white">
                        {Math.round(telemetry.speedKmh)}
                        <span className="text-[9px] font-normal text-neutral-400 ml-0.5">km/h</span>
                      </span>
                      <span className="text-[10px] font-bold text-amber-400">
                        {telemetry.engineOn ? (telemetry.gear === 0 ? 'N' : `${telemetry.gear}ª`) : 'OFF'}
                      </span>
                    </div>
                    <div className="mt-1 h-[2px] w-full rounded-full bg-neutral-800 overflow-hidden">
                      <div
                        className={telemetry.rpm > 8500 ? 'h-full bg-rose-500' : 'h-full bg-amber-400'}
                        style={{ width: `${Math.min(100, (telemetry.rpm / 10000) * 100)}%` }}
                      />
                    </div>
                  </div>
                )}

                <div className="bg-neutral-950/90 border border-white/15 rounded-xl px-3 py-1.5 shadow-lg">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm font-bold text-white whitespace-nowrap">
                      Moto Win
                    </span>
                    <span aria-hidden="true" className="text-neutral-600">·</span>
                    <span className="text-[11px] font-medium text-amber-400 truncate max-w-[150px]">
                      {telemetry.zone}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-neutral-300 mt-0.5 font-mono-tabular">
                    <span>{telemetry.clockLabel} ({phaseLabel[telemetry.timePhase]})</span>
                    <span aria-hidden="true">·</span>
                    <span>{weatherLabel[telemetry.weather]}</span>
                    <span aria-hidden="true">·</span>
                    <span>Aderência {Math.round(telemetry.gripFactor * 100)}%</span>
                  </div>
                </div>
              </div>

              {/* Compact Quick Action Strip: Weather, Time, Casa Principal, Camera, Sound */}
              <div className="flex flex-wrap items-center gap-1 bg-neutral-950/90 border border-white/15 rounded-xl p-1 shadow-lg">
                <button
                  type="button"
                  onClick={() => bridgeRef.current?.setWeather('sol')}
                  title="Clima: Sol"
                  className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                    telemetry.weather === 'sol' ? 'bg-amber-500 text-neutral-950' : 'text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => bridgeRef.current?.setWeather('chuva')}
                  title="Clima: Chuva"
                  className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                    telemetry.weather === 'chuva' ? 'bg-sky-500 text-neutral-950' : 'text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <CloudRain className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => bridgeRef.current?.setWeather('neblina')}
                  title="Clima: Neblina"
                  className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                    telemetry.weather === 'neblina' ? 'bg-slate-400 text-neutral-950' : 'text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <CloudFog className="w-3.5 h-3.5" />
                </button>
                <span className="w-px h-4 bg-white/15 mx-0.5" />
                <button
                  type="button"
                  onClick={() =>
                    bridgeRef.current?.setTimePhase(telemetry.timePhase === 'noite' ? 'dia' : 'noite')
                  }
                  title="Alternar Dia / Noite"
                  className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                    telemetry.timePhase === 'noite' ? 'bg-indigo-500 text-white' : 'text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => bridgeRef.current?.resetToHouse()}
                  title="Voltar para Casa Principal"
                  className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-medium text-neutral-200 hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  <Home className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden sm:inline">Casa</span>
                </button>
                <span className="w-px h-4 bg-white/15 mx-0.5" />
                <button
                  type="button"
                  onClick={() =>
                    bridgeRef.current?.setCameraMode(
                      telemetry.cameraMode === 'chase' ? 'far' : 'chase'
                    )
                  }
                  title="Câmera em Terceira Pessoa (C)"
                  className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    telemetry.cameraMode !== 'hood'
                      ? 'bg-amber-500 text-neutral-950'
                      : 'text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{telemetry.cameraMode === 'far' ? '3ª Longe' : '3ª Pessoa'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => bridgeRef.current?.setCameraMode('hood')}
                  title="Câmera em Primeira Pessoa (C)"
                  className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    telemetry.cameraMode === 'hood'
                      ? 'bg-amber-500 text-neutral-950'
                      : 'text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <span>1ª Pessoa</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const next = !muted;
                    setMuted(next);
                    bridgeRef.current?.setMuted(next);
                  }}
                  title={muted ? 'Ativar Som' : 'Silenciar Som'}
                  className="p-1.5 rounded-lg text-neutral-200 hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  {muted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Top-Center: Active Room Pill + Active Mission Tracker OR Mission Notification */}
            <div className="flex flex-col items-center gap-2 max-w-md">
              {activeRoom && (
                <div className="pointer-events-auto flex items-center gap-2 bg-neutral-950/92 border border-sky-400/40 rounded-xl px-3 py-1.5 shadow-lg">
                  <Users className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span className="text-[11px] font-semibold text-white whitespace-nowrap">
                    Sala <span className="font-mono-tabular text-amber-400">{activeRoom.roomId}</span>
                  </span>
                  <span aria-hidden="true" className="text-neutral-600">·</span>
                  <span className="text-[11px] font-mono-tabular text-neutral-300 whitespace-nowrap">
                    {activeRoom.players.length} piloto{activeRoom.players.length === 1 ? '' : 's'}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyRoomHud}
                    title="Copiar ID da Sala"
                    className="p-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-amber-300 cursor-pointer"
                  >
                    {copiedRoomHud ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                  <button
                    type="button"
                    onClick={handleLeaveRoom}
                    title="Sair da Sala"
                    className="p-1 rounded-md bg-neutral-800 hover:bg-rose-900/70 text-neutral-300 hover:text-rose-200 cursor-pointer"
                  >
                    <LogOut className="w-3 h-3" />
                  </button>
                </div>
              )}

              {activeMission && activeMission.status === 'active' && (
                <div className="pointer-events-auto bg-neutral-950/92 border border-amber-400/40 rounded-xl px-4 py-2 text-center shadow-lg">
                  <div className="flex items-center justify-center gap-2 text-xs font-semibold text-amber-400">
                    <Compass className="w-3.5 h-3.5" />
                    <span>{activeMission.def.title}</span>
                  </div>
                  <div className="text-[11px] text-neutral-200 mt-0.5 font-mono-tabular">
                    {activeMission.def.type === 'grau' && activeMission.def.targetWheelieDistM && (
                      <span>
                        Grau: {Math.round(activeMission.wheelieDistanceM)}m / {activeMission.def.targetWheelieDistM}m
                      </span>
                    )}
                    {activeMission.def.type === 'policia' && activeMission.def.policeDurationSec && (
                      <span>
                        Sobreviva: {Math.max(0, Math.ceil(activeMission.def.policeDurationSec - activeMission.elapsedSec))}s
                      </span>
                    )}
                    {distToTarget !== null && (
                      <span>
                        Destino: {distToTarget}m
                        {activeMission.def.checkpoints?.[activeMission.currentCheckpointIndex]?.label
                          ? ` (${activeMission.def.checkpoints[activeMission.currentCheckpointIndex].label})`
                          : ''}
                      </span>
                    )}
                    {activeMission.def.timeLimitSec && (
                      <span>
                        {' '}· Tempo: {Math.max(0, Math.ceil(activeMission.def.timeLimitSec - activeMission.elapsedSec))}s
                      </span>
                    )}
                  </div>
                </div>
              )}

              {bannerNotice && (
                <div
                  className={`rounded-xl px-4 py-2 border shadow-lg text-center ${
                    bannerNotice.tone === 'success'
                      ? 'bg-emerald-950/95 border-emerald-400/40 text-emerald-100'
                      : 'bg-rose-950/95 border-rose-400/40 text-rose-100'
                  }`}
                >
                  <div className="text-xs font-bold">{bannerNotice.title}</div>
                  <div className="text-[11px] font-mono-tabular">{bannerNotice.detail}</div>
                </div>
              )}
            </div>

            {/* Top-Right: Money/XP + Modal Buttons + Minimap */}
            <div className="flex items-start gap-2.5">
              <div className="pointer-events-auto flex flex-col items-end gap-1.5">
                <div className="bg-neutral-950/90 border border-white/15 rounded-xl px-3 py-1.5 text-right shadow-lg">
                  <div className="font-mono-tabular text-xs font-bold text-emerald-400">
                    R$ {progress.money.toLocaleString('pt-BR')}
                  </div>
                  <div className="font-mono-tabular text-[10px] text-neutral-300">
                    Nível {progress.level} · {progress.xp} XP
                  </div>
                </div>

                <div className="flex flex-wrap justify-end gap-1.5">
                  <button
                    type="button"
                    onClick={() => setFriendsOpen(true)}
                    className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-white shadow-lg transition-colors cursor-pointer"
                    title="Adicionar Amigos"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-sky-400" />
                    <span className="hidden lg:inline">Amigos</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRoomError(null);
                      setRoomsOpen(true);
                    }}
                    className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-white shadow-lg transition-colors cursor-pointer"
                    title="Criar ou Colocar Sala"
                  >
                    <DoorOpen className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="hidden lg:inline">Salas</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMissionsOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-white shadow-lg transition-colors cursor-pointer"
                  >
                    <Trophy className="w-3.5 h-3.5 text-amber-400" />
                    <span>Missões</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setWorkshopOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-white shadow-lg transition-colors cursor-pointer"
                  >
                    <Wrench className="w-3.5 h-3.5 text-sky-400" />
                    <span>Oficina</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setGarageOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-white shadow-lg transition-colors cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="hidden sm:inline">IA Chat</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSettingsOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-800 border border-white/15 text-xs font-semibold text-white shadow-lg transition-colors cursor-pointer"
                    title="Configurações e Sensibilidade"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5 text-amber-300" />
                    <span className="hidden sm:inline">Config.</span>
                  </button>
                </div>
              </div>

              <div className="hidden md:block">
                <Minimap telemetry={telemetry} />
              </div>
            </div>
          </div>

          {/* CENTER FEEDBACK: HOUSE DOOR PROMPT + WHEELIE GAUGE */}
          <div className="flex flex-col items-center justify-center gap-2">
            {telemetry.isOnFoot && telemetry.nearHouseDoor && (
              <button
                type="button"
                onClick={() => bridgeRef.current?.interactHouseDoor()}
                className="pointer-events-auto flex items-center gap-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 active:scale-95 border-2 border-amber-200 px-5 py-3 text-neutral-950 shadow-2xl transition-all cursor-pointer"
              >
                <DoorOpen className="w-5 h-5 shrink-0" />
                <div className="text-left">
                  <div className="font-display text-sm font-bold leading-tight">
                    {!telemetry.insideHouse
                      ? telemetry.houseDoorOpen
                        ? 'Clique para Entrar em Casa'
                        : 'Clique para Abrir a Porta e Entrar em Casa'
                      : telemetry.houseDoorOpen
                        ? 'Clique para Fechar a Porta'
                        : 'Clique para Abrir a Porta'}
                  </div>
                  <div className="text-[11px] font-medium opacity-85">
                    Porta da Casa Principal (ou tecla G)
                  </div>
                </div>
              </button>
            )}

            {telemetry.crashed && (
              <div className="bg-rose-950/90 border border-rose-500/40 rounded-xl px-4 py-2 text-center shadow-xl">
                <div className="font-display text-sm font-bold text-rose-300">QUEDA! Levantando a moto...</div>
              </div>
            )}
            {!telemetry.crashed && telemetry.isWheelieing && (
              <div className="bg-neutral-950/90 border border-amber-400/35 rounded-xl px-4 py-2 text-center shadow-lg min-w-[220px]">
                <div className="font-display text-sm font-bold text-amber-400 font-mono-tabular">
                  {telemetry.isScraping
                    ? `RASPANDO A RABETA · ${Math.round(telemetry.wheelieDeg)}°`
                    : telemetry.wheelieDeg >= 42 && telemetry.wheelieDeg <= 68
                      ? `GRAU PERFEITO · ${Math.round(telemetry.wheelieDeg)}°`
                      : `EMPINANDO · ${Math.round(telemetry.wheelieDeg)}°`}
                </div>
                {/* Projeto Grau 2 Balance Gauge (0° to 88°) */}
                <div className="relative mt-1.5 h-2 w-full rounded-full bg-neutral-800 overflow-hidden">
                  <div
                    className="absolute inset-y-0 bg-emerald-500/45"
                    style={{ left: '47.7%', width: '29.5%' }}
                  />
                  <div
                    className="absolute inset-y-0 bg-rose-500/45"
                    style={{ left: '83%', width: '17%' }}
                  />
                  <div
                    className="absolute top-0 bottom-0 w-1.5 rounded-full bg-amber-300 shadow"
                    style={{ left: `${Math.min(97, Math.max(0, (telemetry.wheelieDeg / 88) * 100))}%` }}
                  />
                </div>
                <div className="text-[11px] font-mono-tabular text-white mt-1">
                  Pontos do Grau: {telemetry.currentGrauScore} · Recorde: {telemetry.bestGrauScore}
                </div>
              </div>
            )}
          </div>

          {/* BOTTOM ROW: STEERING LEFT · SPEEDOMETER CENTER · MOTO CONTROLS RIGHT */}
          <div className="flex items-end justify-between gap-3">
            {/* Bottom-Left: Steering Controls + Horn */}
            <div className="pointer-events-auto flex items-end gap-2">
              <button
                type="button"
                {...bindHoldControl('left')}
                className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl border flex flex-col items-center justify-center font-display font-bold text-lg shadow-xl transition-transform cursor-pointer ${
                  pressedBtns.left
                    ? 'bg-amber-500 text-neutral-950 border-amber-300 scale-95'
                    : 'bg-neutral-950/90 text-white border-white/20 hover:bg-neutral-800'
                }`}
                aria-label="Virar à Esquerda"
              >
                <span>◀</span>
                <span className="text-[10px] font-sans font-semibold">ESQ</span>
              </button>
              <button
                type="button"
                {...bindHoldControl('right')}
                className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl border flex flex-col items-center justify-center font-display font-bold text-lg shadow-xl transition-transform cursor-pointer ${
                  pressedBtns.right
                    ? 'bg-amber-500 text-neutral-950 border-amber-300 scale-95'
                    : 'bg-neutral-950/90 text-white border-white/20 hover:bg-neutral-800'
                }`}
                aria-label="Virar à Direita"
              >
                <span>▶</span>
                <span className="text-[10px] font-sans font-semibold">DIR</span>
              </button>
              <button
                type="button"
                onClick={() => bridgeRef.current?.playHorn()}
                className="h-14 sm:h-16 px-3.5 rounded-2xl border border-white/20 bg-neutral-950/90 hover:bg-neutral-800 text-xs font-semibold text-neutral-200 shadow-xl cursor-pointer"
              >
                Buzina
              </button>
            </div>

            {/* Bottom-Right: Riding Controls OR On-Foot Controls */}
            <div className="pointer-events-auto flex items-end gap-2">
              {telemetry.isOnFoot ? (
                <>
                  {/* Subir na Moto */}
                  <button
                    type="button"
                    disabled={!telemetry.nearMoto}
                    onClick={() => bridgeRef.current?.toggleMount()}
                    className={`h-16 sm:h-[72px] px-3.5 rounded-2xl border flex flex-col items-center justify-center gap-0.5 shadow-xl transition-all ${
                      telemetry.nearMoto
                        ? 'bg-sky-500 hover:bg-sky-400 border-sky-200 text-neutral-950 cursor-pointer'
                        : 'bg-neutral-950/60 border-white/10 text-neutral-500 cursor-not-allowed'
                    }`}
                  >
                    <Bike className="w-4 h-4" />
                    <span className="text-[10px] font-bold whitespace-nowrap">
                      {telemetry.nearMoto ? 'SUBIR NA MOTO' : 'MOTO LONGE'}
                    </span>
                  </button>

                  {/* Abrir/Fechar Porta (quick trigger when near door) */}
                  {telemetry.nearHouseDoor && (
                    <button
                      type="button"
                      onClick={() => bridgeRef.current?.interactHouseDoor()}
                      className="h-16 sm:h-[72px] px-3.5 rounded-2xl border border-amber-300 bg-amber-500 hover:bg-amber-400 text-neutral-950 flex flex-col items-center justify-center gap-0.5 shadow-xl cursor-pointer"
                    >
                      <DoorOpen className="w-4 h-4" />
                      <span className="text-[10px] font-bold whitespace-nowrap">
                        {telemetry.insideHouse
                          ? telemetry.houseDoorOpen
                            ? 'FECHAR PORTA'
                            : 'ABRIR PORTA'
                          : 'ENTRAR CASA'}
                      </span>
                    </button>
                  )}

                  {/* Recuar */}
                  <button
                    type="button"
                    {...bindHoldControl('brake')}
                    className={`h-16 sm:h-[72px] px-4 rounded-2xl border flex flex-col items-center justify-center shadow-xl transition-transform cursor-pointer ${
                      pressedBtns.brake
                        ? 'bg-rose-600 text-white border-rose-300 scale-95'
                        : 'bg-neutral-950/90 text-rose-400 border-rose-500/40 hover:bg-neutral-800'
                    }`}
                  >
                    <span className="font-display text-xs sm:text-sm font-bold">VOLTAR</span>
                    <span className="text-[10px] opacity-80">Trás</span>
                  </button>

                  {/* Andar */}
                  <button
                    type="button"
                    {...bindHoldControl('throttle')}
                    className={`h-18 sm:h-20 px-5 rounded-2xl border flex flex-col items-center justify-center shadow-xl transition-transform cursor-pointer ${
                      pressedBtns.throttle
                        ? 'bg-emerald-500 text-neutral-950 border-emerald-200 scale-95'
                        : 'bg-emerald-950/90 text-emerald-300 border-emerald-400/50 hover:bg-emerald-900/90'
                    }`}
                  >
                    <span className="font-display text-sm sm:text-base font-bold">ANDAR</span>
                    <span className="text-[10px] opacity-85">Frente</span>
                  </button>
                </>
              ) : (
                <>
                  {/* Descer da Moto */}
                  <button
                    type="button"
                    onClick={() => bridgeRef.current?.toggleMount()}
                    title="Descer da Moto (F)"
                    className="h-14 sm:h-16 px-3 rounded-2xl border border-sky-400/50 bg-neutral-950/90 hover:bg-neutral-800 text-sky-300 flex flex-col items-center justify-center gap-0.5 shadow-xl transition-all cursor-pointer"
                  >
                    <Footprints className="w-4 h-4" />
                    <span className="text-[10px] font-bold whitespace-nowrap">DESCER</span>
                  </button>

                  {/* Ligar Moto */}
                  <button
                    type="button"
                    onClick={() => bridgeRef.current?.toggleIgnition()}
                    className={`h-14 sm:h-16 px-3.5 rounded-2xl border flex flex-col items-center justify-center gap-0.5 shadow-xl transition-all cursor-pointer ${
                      telemetry.engineOn
                        ? 'bg-emerald-600/90 border-emerald-400 text-white'
                        : telemetry.cranking
                          ? 'bg-amber-500 border-amber-300 text-neutral-950'
                          : 'bg-neutral-950/90 border-amber-400/50 text-amber-300 hover:bg-neutral-800'
                    }`}
                  >
                    <Power className="w-4 h-4" />
                    <span className="text-[10px] font-bold whitespace-nowrap">
                      {telemetry.engineOn ? 'LIGADA' : telemetry.cranking ? 'PARTIDA...' : 'LIGAR MOTO'}
                    </span>
                  </button>

                  {/* Empinar (Grau) */}
                  <button
                    type="button"
                    {...bindHoldControl('wheelie')}
                    className={`h-16 sm:h-[72px] px-3.5 sm:px-4 rounded-2xl border flex flex-col items-center justify-center shadow-xl transition-transform cursor-pointer ${
                      pressedBtns.wheelie
                        ? 'bg-orange-500 text-neutral-950 border-orange-300 scale-95'
                        : 'bg-neutral-950/90 text-orange-400 border-orange-400/40 hover:bg-neutral-800'
                    }`}
                  >
                    <span className="font-display text-xs sm:text-sm font-bold">EMPINAR</span>
                    <span className="text-[10px] opacity-80">Grau</span>
                  </button>

                  {/* Frear */}
                  <button
                    type="button"
                    {...bindHoldControl('brake')}
                    className={`h-16 sm:h-[72px] px-3.5 sm:px-4 rounded-2xl border flex flex-col items-center justify-center shadow-xl transition-transform cursor-pointer ${
                      pressedBtns.brake
                        ? 'bg-rose-600 text-white border-rose-300 scale-95'
                        : 'bg-neutral-950/90 text-rose-400 border-rose-500/40 hover:bg-neutral-800'
                    }`}
                  >
                    <span className="font-display text-xs sm:text-sm font-bold">FREAR</span>
                    <span className="text-[10px] opacity-80">Freio</span>
                  </button>

                  {/* Acelerar */}
                  <button
                    type="button"
                    {...bindHoldControl('throttle')}
                    className={`h-18 sm:h-20 px-4 sm:px-5 rounded-2xl border flex flex-col items-center justify-center shadow-xl transition-transform cursor-pointer ${
                      pressedBtns.throttle
                        ? 'bg-emerald-500 text-neutral-950 border-emerald-200 scale-95'
                        : 'bg-emerald-950/90 text-emerald-300 border-emerald-400/50 hover:bg-emerald-900/90'
                    }`}
                  >
                    <span className="font-display text-sm sm:text-base font-bold">ACELERAR</span>
                    <span className="text-[10px] opacity-85">Gás</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <WorkshopModal
        open={workshopOpen}
        progress={progress}
        onClose={() => setWorkshopOpen(false)}
        onBuyModel={handleBuyModel}
        onBuyColor={handleBuyColor}
        onBuyPart={handleBuyPart}
        onUpgradeStat={handleUpgradeStat}
      />

      <MissionsModal
        open={missionsOpen}
        progress={progress}
        activeMission={telemetry.activeMission}
        onClose={() => setMissionsOpen(false)}
        onStartMission={(def) => bridgeRef.current?.startMission(def)}
        onCancelMission={() => bridgeRef.current?.cancelMission()}
      />

      <GeminiGarageModal
        open={garageOpen}
        telemetry={telemetry}
        progress={progress}
        onClose={() => setGarageOpen(false)}
      />

      <SettingsModal
        open={settingsOpen}
        settings={settings}
        currentModel={progress.customization.bikeModel ?? 'cg_titan_160'}
        muted={muted}
        onClose={() => setSettingsOpen(false)}
        onSelectPreset={handleSelectSensitivityPreset}
        onChangeSteeringSensitivity={handleChangeSteeringSensitivity}
        onChangeWheelieSensitivity={handleChangeWheelieSensitivity}
        onToggleMute={() => {
          const next = !muted;
          setMuted(next);
          bridgeRef.current?.setMuted(next);
        }}
        onOpenWorkshop={() => setWorkshopOpen(true)}
      />

      <FriendsModal
        open={friendsOpen}
        playerId={playerId}
        playerName={playerName}
        friends={friends}
        wsConnected={wsConnected}
        onClose={() => setFriendsOpen(false)}
        onSaveName={handleSavePlayerName}
        onAddFriend={handleAddFriend}
        onRemoveFriend={handleRemoveFriend}
        onJoinFriendRoom={handleJoinRoom}
      />

      <RoomsModal
        open={roomsOpen}
        wsConnected={wsConnected}
        activeRoom={activeRoom}
        roomError={roomError}
        friends={friends}
        onClose={() => setRoomsOpen(false)}
        onCreateRoom={handleCreateRoom}
        onJoinRoom={handleJoinRoom}
        onLeaveRoom={handleLeaveRoom}
        onEnterMapWithRoom={() => {
          setRoomsOpen(false);
          void handleEnterHorizontal();
        }}
      />
    </div>
  );
}
