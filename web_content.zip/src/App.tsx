import React, { useState, useEffect } from 'react';
import {
  Mail,
  Phone,
  Settings as SettingsIcon,
  Plus,
  Coins,
  QrCode as QrIcon,
  Copy,
  Check,
  RefreshCw,
  Trash2,
  Send,
  Shield,
  BookOpen,
  Sparkles,
  Inbox,
  Clock,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  MessageSquare,
  AlertTriangle,
  User,
  ArrowRight,
  Globe,
  Bell,
  Volume2,
  Lock,
  Smartphone,
  X,
  Wifi,
  Zap,
} from 'lucide-react';

import { TempBoxStore, AVAILABLE_PHONE_CATALOG } from './services/store.ts';
import { Mailbox, EmailMessage, PhoneNumber, SmsMessage, CreditTransaction, AbuseReport, UserAccount } from './types/index.ts';
import { RealTempMailService, RealMailSession, LIVE_DOMAINS, playNotificationSound } from './services/realTempMail.ts';
import { CountdownBadge } from './components/CountdownBadge.tsx';
import { OtpChip } from './components/OtpChip.tsx';
import { QrCodeModal } from './components/QrCodeModal.tsx';
import { EmailDetailModal } from './components/EmailDetailModal.tsx';
import { GenerateEmailModal } from './components/GenerateEmailModal.tsx';
import { RentNumberModal } from './components/RentNumberModal.tsx';
import { SmsThreadModal } from './components/SmsThreadModal.tsx';
import { CreditsModal } from './components/CreditsModal.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { WebhookSimulatorModal } from './components/WebhookSimulatorModal.tsx';
import { AdminPanelModal } from './components/AdminPanelModal.tsx';
import { AdminAuthModal } from './components/AdminAuthModal.tsx';
import { AndroidApkModal } from './components/AndroidApkModal.tsx';
import { CodeDocsModal } from './components/CodeDocsModal.tsx';
import { OnboardingModal } from './components/OnboardingModal.tsx';
import { RealTempNumberService, VERIFICATION_PRESETS } from './services/realTempNumber.ts';

export default function App() {
  const [state, setState] = useState(() => TempBoxStore.getState());
  const [activeTab, setActiveTab] = useState<'email' | 'numbers' | 'settings'>('email');

  // Modal controls
  const [selectedEmailMessage, setSelectedEmailMessage] = useState<EmailMessage | null>(null);
  const [selectedPhoneNumber, setSelectedPhoneNumber] = useState<PhoneNumber | null>(null);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [showRentModal, setShowRentModal] = useState(false);
  const [showCreditsModal, setShowCreditsModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showWebhookModal, setShowWebhookModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showAdminAuthModal, setShowAdminAuthModal] = useState(false);
  const [showAndroidModal, setShowAndroidModal] = useState(false);
  const [showDocsModal, setShowDocsModal] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [qrModalData, setQrModalData] = useState<{ title: string; value: string; subtitle?: string } | null>(null);

  // Phone Workstation State (Temp Number)
  const [activePhoneCountry, setActivePhoneCountry] = useState<string>('US');
  const [activePhoneNumberId, setActivePhoneNumberId] = useState<string | null>(null);
  const [phoneWorkMode, setPhoneWorkMode] = useState<'dashboard' | 'phone'>('dashboard');
  const [phoneNotification, setPhoneNotification] = useState<{
    sender: string;
    from: string;
    text: string;
    otp?: string;
  } | null>(null);
  const [showCustomSmsModal, setShowCustomSmsModal] = useState(false);
  const [autoSmsTraffic, setAutoSmsTraffic] = useState(true);
  const [isWaitingForSms, setIsWaitingForSms] = useState(false);
  const [smsCountdown, setSmsCountdown] = useState<number | null>(null);
  const [selectedOtpService, setSelectedOtpService] = useState<string>('WhatsApp');
  const [customSmsForm, setCustomSmsForm] = useState({
    sender: 'WhatsApp',
    from: '+1 (800) 555-0199',
    text: 'Your WhatsApp security code is 849-201',
  });

  // Real Live Mailbox State (Mail.tm Primary + Guerrilla Mail Engine)
  const [liveSession, setLiveSession] = useState<RealMailSession | null>(() => RealTempMailService.getStoredSession());
  const [isCheckingMail, setIsCheckingMail] = useState(false);
  const [lastSyncText, setLastSyncText] = useState('Just now');
  const [activeDomain, setActiveDomain] = useState<string>('maxxspace.com');

  // Toast / copy feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const syncState = () => {
    setState(TempBoxStore.getState());
  };

  // 1. Initialize Real Live Mailbox Session on Mount if needed
  useEffect(() => {
    let active = true;
    async function setupLiveInbox() {
      let sess = RealTempMailService.getStoredSession();
      if (!sess) {
        try {
          setIsCheckingMail(true);
          sess = await RealTempMailService.initOrCreateSession(undefined, 'maxxspace.com');
        } catch (e) {
          console.warn('[LiveMail] Setup error:', e);
        } finally {
          if (active) setIsCheckingMail(false);
        }
      }

      if (sess && active) {
        setLiveSession(sess);
        setActiveDomain(sess.domain);
        TempBoxStore.updateState((s) => {
          const liveMb: Mailbox = {
            id: 'mb_live_session',
            address: sess!.address,
            username: sess!.username,
            domain: sess!.domain,
            lifetimeTier: '24h',
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            createdAt: new Date().toISOString(),
            isCustom: false,
            unreadCount: 0,
          };
          s.mailboxes = [liveMb, ...s.mailboxes.filter((m: Mailbox) => m.id !== liveMb.id && !m.address.includes('tempbox.io'))];
          s.activeMailboxId = liveMb.id;
          return s;
        });
        syncState();
      }
    }

    setupLiveInbox();
    return () => { active = false; };
  }, []);

  // 2. Real-time Polling Loop for Live Messages (every 2.5 seconds)
  useEffect(() => {
    if (!liveSession) return;

    let previousIds = new Set<string>();

    const poll = async () => {
      try {
        setIsCheckingMail(true);
        const msgs = await RealTempMailService.fetchMessages(liveSession);
        setLastSyncText(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));

        const brandNew = msgs.filter((m) => !previousIds.has(m.id));
        if (previousIds.size > 0 && brandNew.length > 0) {
          playNotificationSound();
          const latestOtp = brandNew[0].extractedOtp;
          showToast(latestOtp ? `🔑 OTP Code Received: ${latestOtp}` : `📬 New Email: ${brandNew[0].subject}`);
        }

        previousIds = new Set(msgs.map((m) => m.id));

        if (msgs.length > 0) {
          TempBoxStore.updateState((s) => {
            const existingIds = new Set(s.messages.map((m: EmailMessage) => m.id));
            const newOnes = msgs.filter((m) => !existingIds.has(m.id));
            if (newOnes.length > 0) {
              s.messages = [...newOnes, ...s.messages];
              const targetMb = s.mailboxes.find((m: Mailbox) => m.address.toLowerCase() === liveSession.address.toLowerCase());
              if (targetMb) targetMb.unreadCount += newOnes.length;
            }
            return s;
          });
          syncState();
        }
      } catch (err) {
        // quiet poll
      } finally {
        setIsCheckingMail(false);
      }
    };

    poll();
    const interval = setInterval(poll, 2500);
    return () => clearInterval(interval);
  }, [liveSession?.address, liveSession?.sidToken, liveSession?.mailTmToken]);

  const activeMailbox = state.mailboxes.find((m: Mailbox) => m.id === state.activeMailboxId) || state.mailboxes[0];
  const mailboxMessages = state.messages.filter((msg: EmailMessage) => {
    if (!activeMailbox) return true;
    const mbAddr = activeMailbox.address.toLowerCase();
    const msgTo = msg.toAddress.toLowerCase();
    if (msg.mailboxId === activeMailbox.id) return true;
    if (msgTo === mbAddr) return true;
    if (msgTo.includes(activeMailbox.username.toLowerCase())) return true;
    if (liveSession && (msgTo === liveSession.address.toLowerCase() || msg.mailboxId === 'real_inbox')) return true;
    return false;
  });

  const activePhoneNumber: PhoneNumber =
    state.phoneNumbers.find((p: PhoneNumber) => p.id === activePhoneNumberId) ||
    state.phoneNumbers[0] || {
      id: 'num_fallback',
      number: '+1 (415) 802-3921',
      countryCode: 'US',
      countryName: 'United States',
      flag: '🇺🇸',
      provider: 'mock',
      status: 'ACTIVE',
      rentedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      creditsCost: 0,
      receivedSmsQty: 1,
      refundIssued: false,
    };

  const phoneSmsMessages = state.smsMessages.filter((s: SmsMessage) =>
    activePhoneNumber ? s.phoneNumberId === activePhoneNumber.id : true
  );

  // 3. Real-time Heartbeat for Admin Panel (Tracks live users, tab, mailbox, number)
  useEffect(() => {
    const reportHeartbeat = () => {
      TempBoxStore.updateUserHeartbeat({
        deviceId: state.user.deviceId,
        tab: activeTab,
        activeMailbox: activeMailbox?.address,
        activeNumber: activePhoneNumber?.number,
      });
    };
    reportHeartbeat();
    const interval = setInterval(reportHeartbeat, 4000);
    return () => clearInterval(interval);
  }, [state.user.deviceId, activeTab, activeMailbox?.address, activePhoneNumber?.number]);

  // 4. Real-time background SMS traffic simulation (Temp Number works just like Temp Mail)
  useEffect(() => {
    if (!autoSmsTraffic || !activePhoneNumber) return;
    const interval = setInterval(() => {
      const newSms = RealTempNumberService.simulatePeriodicTraffic(activePhoneNumber.id);
      if (newSms) {
        syncState();
        setPhoneNotification({
          sender: newSms.senderName || newSms.fromNumber,
          from: newSms.fromNumber,
          text: newSms.text,
          otp: newSms.extractedOtp || undefined,
        });
        showToast(`📨 New SMS received on ${activePhoneNumber.number} from ${newSms.senderName || newSms.fromNumber}!`);
        setTimeout(() => setPhoneNotification(null), 8000);
      }
    }, 32000);
    return () => clearInterval(interval);
  }, [autoSmsTraffic, activePhoneNumber?.id]);

  // 5. Auto-deliver SMS verification code after user copies phone number (5s countdown)
  useEffect(() => {
    if (smsCountdown === null) return;
    if (smsCountdown > 0) {
      const timer = setTimeout(() => {
        setSmsCountdown((c) => (c !== null && c > 1 ? c - 1 : 0));
      }, 1000);
      return () => clearTimeout(timer);
    }
    if (smsCountdown === 0 && activePhoneNumber) {
      const svc = selectedOtpService || 'WhatsApp';
      RealTempNumberService.requestVerificationCode(activePhoneNumber.id, svc).then((sms) => {
        syncState();
        if (sms) {
          setPhoneNotification({
            sender: sms.senderName || sms.fromNumber,
            from: sms.fromNumber,
            text: sms.text,
            otp: sms.extractedOtp || undefined,
          });
          showToast(`⚡ Verification code arrived from ${sms.senderName || sms.fromNumber}: ${sms.extractedOtp || ''}`);
          setTimeout(() => setPhoneNotification(null), 8000);
        }
      });
      setSmsCountdown(null);
      setIsWaitingForSms(false);
    }
  }, [smsCountdown, activePhoneNumber?.id, selectedOtpService]);

  const handleCopy = (text: string, label: string = 'Copied') => {
    navigator.clipboard.writeText(text);
    setCopiedAddress(true);
    showToast(`${label} copied! You can paste it on any website.`);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleCopyNumber = (numStr: string, serviceName: string = 'WhatsApp') => {
    navigator.clipboard.writeText(numStr);
    setCopiedNumber(numStr);
    setSelectedOtpService(serviceName);
    setIsWaitingForSms(true);
    setSmsCountdown(5);
    showToast(`Phone number ${numStr} copied! Auto-listening for verification SMS (arriving in 5s)...`);
    setTimeout(() => setCopiedNumber(null), 2500);
  };

  const handleInstantFetchCode = async (serviceName: string) => {
    if (!activePhoneNumber) return;
    showToast(`Requesting ${serviceName} verification code on ${activePhoneNumber.number}...`);
    const sms = await RealTempNumberService.requestVerificationCode(activePhoneNumber.id, serviceName);
    syncState();
    if (sms) {
      setPhoneNotification({
        sender: sms.senderName || sms.fromNumber,
        from: sms.fromNumber,
        text: sms.text,
        otp: sms.extractedOtp || undefined,
      });
      showToast(`Verification code received: ${sms.extractedOtp}`);
      setTimeout(() => setPhoneNotification(null), 8000);
    }
  };

  // Instant Manual Refresh
  const handleManualRefresh = async () => {
    if (!liveSession) {
      showToast('Checking for mail...');
      return;
    }
    setIsCheckingMail(true);
    try {
      const msgs = await RealTempMailService.fetchMessages(liveSession);
      setLastSyncText(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      if (msgs.length > 0) {
        TempBoxStore.updateState((s) => {
          const existingIds = new Set(s.messages.map((m: EmailMessage) => m.id));
          const newOnes = msgs.filter((m) => !existingIds.has(m.id));
          if (newOnes.length > 0) {
            playNotificationSound();
            s.messages = [...newOnes, ...s.messages];
          }
          return s;
        });
        syncState();
        showToast(`Inbox refreshed: ${msgs.length} messages found`);
      } else {
        showToast('Inbox is up to date (no new messages yet)');
      }
    } catch {
      showToast('Checked for mail');
    } finally {
      setIsCheckingMail(false);
    }
  };

  // Instant Change Address
  const handleChangeAddress = async (domainToUse?: string) => {
    setIsCheckingMail(true);
    try {
      const targetDomain = domainToUse || activeDomain;
      const newSess = await RealTempMailService.initOrCreateSession(undefined, targetDomain);
      setLiveSession(newSess);
      setActiveDomain(newSess.domain);

      TempBoxStore.updateState((s) => {
        const liveMb: Mailbox = {
          id: 'mb_live_session',
          address: newSess.address,
          username: newSess.username,
          domain: newSess.domain,
          lifetimeTier: '24h',
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          isCustom: false,
          unreadCount: 0,
        };
        s.mailboxes = [liveMb, ...s.mailboxes.filter((m: Mailbox) => m.id !== liveMb.id)];
        s.activeMailboxId = liveMb.id;
        return s;
      });
      syncState();
      showToast(`New email activated: ${newSess.address}`);
    } catch (e: any) {
      const fallback = TempBoxStore.createMailbox(undefined, domainToUse || activeDomain);
      syncState();
      showToast(`Created fallback inbox: ${fallback.address}`);
    } finally {
      setIsCheckingMail(false);
    }
  };

  const handleCreateMailbox = async (username?: string, domain?: string, duration?: '10m' | '1h' | '24h' | '7d') => {
    setIsCheckingMail(true);
    const tier = duration || '24h';
    try {
      const newSess = await RealTempMailService.initOrCreateSession(username, domain);
      setLiveSession(newSess);
      setActiveDomain(newSess.domain);

      TempBoxStore.updateState((s) => {
        const liveMb: Mailbox = {
          id: 'mb_live_session',
          address: newSess.address,
          username: newSess.username,
          domain: newSess.domain,
          lifetimeTier: tier,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          isCustom: !!username,
          unreadCount: 0,
        };
        s.mailboxes = [liveMb, ...s.mailboxes.filter((m: Mailbox) => m.id !== liveMb.id)];
        s.activeMailboxId = liveMb.id;
        return s;
      });
      syncState();
      showToast(`Custom inbox created: ${newSess.address}`);
    } catch {
      const mb = TempBoxStore.createMailbox(username, domain, tier);
      syncState();
      showToast(`Created mailbox: ${mb.address}`);
    } finally {
      setIsCheckingMail(false);
      setShowGenerateModal(false);
    }
  };

  const handleExtendMailbox = (id: string) => {
    TempBoxStore.extendMailbox(id);
    syncState();
    showToast('Extended mailbox duration +24 hours');
  };

  const handleRentNumber = (item: typeof AVAILABLE_PHONE_CATALOG[0], duration: '20m' | '24h' | '7d' | '30d') => {
    const res = TempBoxStore.rentNumber(item, duration);
    syncState();
    setShowRentModal(false);
    if (res.success && res.number) {
      showToast(`Rented phone line ${res.number.number} successfully!`);
      setSelectedPhoneNumber(res.number);
      setActiveTab('numbers');
    } else if (res.error) {
      showToast(res.error);
    }
  };

  const handleRenewNumber = (id: string) => {
    const res = TempBoxStore.renewNumber(id);
    if (!res.success) {
      showToast(res.error || 'Insufficient credits to renew line');
      setShowCreditsModal(true);
      return;
    }
    syncState();
    showToast('Renewed line for +24 hours');
  };

  const handleReleaseNumber = (id: string) => {
    TempBoxStore.releaseNumber(id);
    syncState();
    setSelectedPhoneNumber(null);
    showToast('Number released. If zero SMS were received, credits have been auto-refunded!');
  };

  // Inbound simulation
  const handleInboundEmail = (params: any) => {
    const msg = TempBoxStore.receiveEmail(params);
    syncState();
    if (msg) {
      playNotificationSound();
      showToast(`New email received: ${msg.subject}`);
    }
  };

  const handleInboundSms = (phoneNumberId: string, fromNumber: string, senderName: string, text: string) => {
    const sms = TempBoxStore.receiveSms(phoneNumberId, fromNumber, senderName, text);
    syncState();
    if (sms) {
      playNotificationSound();
      setPhoneNotification({
        sender: senderName || fromNumber,
        from: fromNumber,
        text,
        otp: sms.extractedOtp || undefined,
      });
      showToast(`New SMS from ${senderName || fromNumber}!`);
      setTimeout(() => setPhoneNotification(null), 6000);
    }
  };

  const handleSimulatePresetSms = (service: 'whatsapp' | 'telegram' | 'google' | 'instagram' | 'uber' | 'netflix' | 'amazon' | 'twitter') => {
    if (!activePhoneNumber) return;
    const testCode = Math.floor(100000 + Math.random() * 900000).toString();
    switch (service) {
      case 'whatsapp':
        handleInboundSms(
          activePhoneNumber.id,
          '+1 (800) 555-0199',
          'WhatsApp',
          `Your WhatsApp security verification code is ${testCode}. Do not share this code with anyone.`
        );
        break;
      case 'telegram':
        handleInboundSms(
          activePhoneNumber.id,
          '42777',
          'Telegram',
          `Telegram code: ${testCode}. You can also tap this link to log in.`
        );
        break;
      case 'google':
        handleInboundSms(
          activePhoneNumber.id,
          '22000',
          'Google',
          `G-${testCode} is your Google verification code.`
        );
        break;
      case 'instagram':
        handleInboundSms(
          activePhoneNumber.id,
          '+1 (650) 543-4800',
          'Instagram',
          `${testCode} is your Instagram security code. Do not share.`
        );
        break;
      case 'uber':
        handleInboundSms(
          activePhoneNumber.id,
          '+1 (415) 800-4820',
          'Uber',
          `Your Uber verification code is ${testCode.slice(0, 4)}. Never share this code with anyone.`
        );
        break;
      case 'netflix':
        handleInboundSms(
          activePhoneNumber.id,
          '888-638',
          'Netflix',
          `Netflix verification code: ${testCode}. Enter this code on your screen to finish signing in.`
        );
        break;
      case 'amazon':
        handleInboundSms(
          activePhoneNumber.id,
          'AMAZON',
          'Amazon',
          `${testCode} is your Amazon OTP. Do not share it with anyone.`
        );
        break;
      case 'twitter':
        handleInboundSms(
          activePhoneNumber.id,
          '40404',
          'X (Twitter)',
          `Your X confirmation code is ${testCode}.`
        );
        break;
    }
  };

  const handleChangePhoneNumber = (countryCode: string = activePhoneCountry) => {
    const newNum = TempBoxStore.generateOrSwitchNumber(countryCode, activePhoneNumber?.number);
    syncState();
    setActivePhoneNumberId(newNum.id);
    setActivePhoneCountry(newNum.countryCode);
    showToast(`Activated new ${newNum.countryName} line: ${newNum.number}`);
  };

  const handleSelectCountry = (code: string) => {
    setActivePhoneCountry(code);
    const newNum = TempBoxStore.generateOrSwitchNumber(code, activePhoneNumber?.number);
    syncState();
    setActivePhoneNumberId(newNum.id);
    showToast(`Switched to ${newNum.countryName}: ${newNum.number}`);
  };

  const handleClearSms = () => {
    if (activePhoneNumber) {
      TempBoxStore.clearSms(activePhoneNumber.id);
      syncState();
      showToast('All SMS cleared for this phone line');
    }
  };

  const handleDeleteSms = (smsId: string) => {
    TempBoxStore.deleteSms(smsId);
    syncState();
    showToast('SMS message deleted');
  };

  const handleSimulateCustomSms = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!activePhoneNumber) return;
    if (!customSmsForm.text.trim()) {
      showToast('Please type an SMS message to receive');
      return;
    }
    handleInboundSms(
      activePhoneNumber.id,
      customSmsForm.from || '+1 (800) 555-0199',
      customSmsForm.sender || 'Service',
      customSmsForm.text
    );
    setShowCustomSmsModal(false);
  };

  // Latest OTP message check across BOTH email and SMS
  const latestEmailOtp = mailboxMessages.find((m: EmailMessage) => m.extractedOtp);
  const latestSmsOtp = state.smsMessages.find((s: SmsMessage) => s.extractedOtp);

  let latestDetectedOtp: { code: string; sender: string; time: string; type: 'email' | 'sms' } | null = null;
  if (latestEmailOtp && latestSmsOtp) {
    if (new Date(latestEmailOtp.receivedAt).getTime() >= new Date(latestSmsOtp.receivedAt).getTime()) {
      latestDetectedOtp = {
        code: latestEmailOtp.extractedOtp!,
        sender: latestEmailOtp.fromName || latestEmailOtp.fromAddress || 'Email Verification',
        time: latestEmailOtp.receivedAt,
        type: 'email',
      };
    } else {
      latestDetectedOtp = {
        code: latestSmsOtp.extractedOtp!,
        sender: latestSmsOtp.senderName || latestSmsOtp.fromNumber || 'SMS Verification',
        time: latestSmsOtp.receivedAt,
        type: 'sms',
      };
    }
  } else if (latestEmailOtp) {
    latestDetectedOtp = {
      code: latestEmailOtp.extractedOtp!,
      sender: latestEmailOtp.fromName || latestEmailOtp.fromAddress || 'Email Verification',
      time: latestEmailOtp.receivedAt,
      type: 'email',
    };
  } else if (latestSmsOtp) {
    latestDetectedOtp = {
      code: latestSmsOtp.extractedOtp!,
      sender: latestSmsOtp.senderName || latestSmsOtp.fromNumber || 'SMS Verification',
      time: latestSmsOtp.receivedAt,
      type: 'sms',
    };
  }

  const latestOtpMessage = latestEmailOtp;

  const handlePurchaseCredits = (amount: number, description: string) => {
    TempBoxStore.addCredits(amount, description);
    syncState();
    showToast(`Added ${amount} credits to your account!`);
  };

  const handleResetAccount = () => {
    if (window.confirm && !window.confirm('Are you sure you want to purge all account data?')) {
      return;
    }
    const fresh = TempBoxStore.resetEntireAccount();
    setState(fresh);
    showToast('All local data, mailboxes, and SMS lines have been purged.');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-blue-500/20 selection:text-blue-700">

      {/* TOP HEADER BAR (WHITE & BLUE) */}
      <header className="border-b border-blue-100 bg-white/95 backdrop-blur-md sticky top-0 z-40 px-4 sm:px-6 py-3.5 shadow-xs">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          
          {/* BRAND */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('email')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight text-slate-900">TempBox</span>
                <span className="text-[10px] bg-blue-50 border border-blue-200 text-blue-700 font-mono px-2 py-0.5 rounded-full font-bold">
                  100% Free
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">Disposable Email &amp; SMS Verification Codes</p>
            </div>
          </div>

          {/* DESKTOP CENTER NAVIGATION TABS */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/90 p-1 rounded-xl border border-slate-200/80">
            <button
              onClick={() => setActiveTab('email')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'email'
                  ? 'bg-white text-blue-700 shadow-xs border border-blue-100'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Mail className="w-3.5 h-3.5 text-blue-600" />
              <span>Temp Mail</span>
              {mailboxMessages.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-blue-600 text-white font-mono">
                  {mailboxMessages.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('numbers')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'numbers'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              <Phone className={`w-3.5 h-3.5 ${activeTab === 'numbers' ? 'text-white' : 'text-blue-600'}`} />
              <span>Temp Number</span>
              {state.phoneNumbers.length > 0 && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  activeTab === 'numbers' ? 'bg-white text-blue-700' : 'bg-blue-100 text-blue-700'
                }`}>
                  {state.phoneNumbers.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-white text-blue-700 shadow-xs border border-blue-100'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <SettingsIcon className="w-3.5 h-3.5 text-slate-500" />
              <span>Settings &amp; Privacy</span>
            </button>
          </nav>

          {/* RIGHT ACTION BUTTONS */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* DEDICATED TEMP NUMBER BUTTON */}
            <button
              onClick={() => setActiveTab('numbers')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-xs cursor-pointer ${
                activeTab === 'numbers'
                  ? 'bg-blue-600 text-white shadow-blue-600/30'
                  : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200'
              }`}
              title="Open Temporary Phone Numbers for SMS OTP verification"
            >
              <Phone className="w-3.5 h-3.5 text-current" />
              <span>Temp Number</span>
            </button>

            {/* CREDITS PILL */}
            <button
              onClick={() => setShowCreditsModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 hover:bg-amber-100 transition-all text-xs font-semibold shadow-2xs cursor-pointer"
              title="Your Credit Wallet"
            >
              <Coins className="w-3.5 h-3.5 text-amber-600" />
              <span className="font-mono">{state.user.credits}</span>
              <span className="hidden lg:inline text-amber-700 font-medium">Credits</span>
            </button>

            {/* TEST INBOUND SIMULATOR */}
            <button
              onClick={() => setShowWebhookModal(true)}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 transition-all text-xs font-semibold cursor-pointer"
              title="Test real-time incoming verification code email/SMS"
            >
              <Send className="w-3.5 h-3.5 text-blue-600" />
              <span>Test Inbound</span>
            </button>

            {/* ANDROID APK / INSTALL APP BUTTON */}
            <button
              onClick={() => setShowAndroidModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold text-xs transition-all shadow-2xs cursor-pointer active:scale-95"
              title="Download Android APK / Install App"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Android APK</span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-1.5 py-0.2 rounded-full">
                APK
              </span>
            </button>

          </div>
        </div>

        {/* MOBILE NAVIGATION BAR (BELOW HEADER ON SMALL SCREENS) */}
        <div className="flex md:hidden items-center justify-between border-t border-slate-100 pt-2.5 mt-2.5 max-w-6xl mx-auto gap-1">
          <button
            onClick={() => setActiveTab('email')}
            className={`flex-1 py-1.5 flex items-center justify-center gap-1.5 text-xs font-bold rounded-lg cursor-pointer ${
              activeTab === 'email' ? 'bg-blue-50 text-blue-700 font-extrabold' : 'text-slate-600'
            }`}
          >
            <Mail className="w-4 h-4 text-blue-600" />
            <span>Temp Mail</span>
            {mailboxMessages.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-blue-600 text-white font-mono">
                {mailboxMessages.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('numbers')}
            className={`flex-1 py-1.5 flex items-center justify-center gap-1.5 text-xs font-bold rounded-lg cursor-pointer ${
              activeTab === 'numbers' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600'
            }`}
          >
            <Phone className={`w-4 h-4 ${activeTab === 'numbers' ? 'text-white' : 'text-blue-600'}`} />
            <span>Temp Number</span>
            {state.phoneNumbers.length > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                activeTab === 'numbers' ? 'bg-white text-blue-700' : 'bg-blue-100 text-blue-700'
              }`}>
                {state.phoneNumbers.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex-1 py-1.5 flex items-center justify-center gap-1.5 text-xs font-bold rounded-lg cursor-pointer ${
              activeTab === 'settings' ? 'bg-blue-50 text-blue-700 font-extrabold' : 'text-slate-600'
            }`}
          >
            <SettingsIcon className="w-4 h-4 text-slate-500" />
            <span>Settings</span>
          </button>

          <button
            onClick={() => setShowAndroidModal(true)}
            className="px-2 py-1.5 flex items-center justify-center gap-1 text-xs font-bold rounded-lg text-emerald-800 bg-emerald-100/90 border border-emerald-300 cursor-pointer"
            title="Download Android APK"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
            <span>APK</span>
          </button>
        </div>
      </header>

      {/* FLOATING TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed top-18 right-4 z-50 bg-blue-900 border border-blue-400 text-white px-4 py-3 rounded-xl text-xs font-bold shadow-xl flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4 text-blue-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* REALISTIC INCOMING PHONE SMS BANNER */}
      {phoneNotification && (
        <div className="fixed top-18 left-1/2 -translate-x-1/2 z-50 max-w-md w-[92%] bg-slate-900/95 backdrop-blur-md text-white border border-blue-400/60 rounded-2xl p-3.5 shadow-2xl flex items-start gap-3 animate-fade-in">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-[11px] text-blue-300 font-semibold mb-0.5">
              <span>{phoneNotification.sender} • SMS to {activePhoneNumber?.number}</span>
              <span>now</span>
            </div>
            <div className="text-xs font-medium text-slate-100 line-clamp-2">
              {phoneNotification.text}
            </div>
            {phoneNotification.otp && (
              <div className="mt-2 flex items-center gap-2">
                <span className="font-mono text-xs font-bold bg-blue-500/30 text-blue-200 px-2 py-0.5 rounded border border-blue-400/40">
                  CODE: {phoneNotification.otp}
                </span>
                <button
                  onClick={() => handleCopy(phoneNotification.otp!, 'OTP Code')}
                  className="px-2.5 py-1 rounded-md bg-blue-600 hover:bg-blue-500 text-[11px] font-bold text-white transition-colors cursor-pointer"
                >
                  Copy Code
                </button>
              </div>
            )}
          </div>
          <button
            onClick={() => setPhoneNotification(null)}
            className="text-slate-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* MAIN APPLICATION VIEWPORT (NO MOBILE SHAPE / BEZEL) */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col space-y-6">

        {/* -------------------- TAB 1: TEMP MAIL -------------------- */}
        {activeTab === 'email' && (
          <div className="space-y-6">
            
            {/* LIVE STATUS BAR */}
            <div className="bg-blue-50/90 border border-blue-200/90 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-600"></span>
                </span>
                <span className="font-bold text-xs sm:text-sm text-blue-900">Live Inbound Delivery Active</span>
                <span className="text-[11px] bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full font-mono font-bold">
                  MX: {activeMailbox?.domain || 'maxxspace.com'}
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-500">
                <span className="hidden sm:inline font-mono text-[11px]">Last checked: {lastSyncText}</span>
                <button
                  onClick={handleManualRefresh}
                  disabled={isCheckingMail}
                  className="px-2.5 py-1 rounded-lg bg-white hover:bg-blue-100/70 border border-blue-200 text-blue-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                  title="Refresh Inbox"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isCheckingMail ? 'animate-spin' : ''}`} />
                  <span>{isCheckingMail ? 'Checking...' : 'Check Server'}</span>
                </button>
              </div>
            </div>

            {/* MAIN DISPOSABLE EMAIL HERO CARD */}
            {activeMailbox ? (
              <div className="bg-white border-2 border-blue-200 rounded-3xl p-5 sm:p-7 shadow-lg shadow-blue-500/5 space-y-5">
                
                {/* CARD HEADER */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-extrabold text-blue-950 uppercase tracking-wider block">
                        Your Disposable Email Address
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Use this address to receive verification codes and activation links
                      </span>
                    </div>
                  </div>
                  <CountdownBadge
                    expiresAt={activeMailbox.expiresAt}
                    onExtend={() => handleExtendMailbox(activeMailbox.id)}
                  />
                </div>

                {/* ADDRESS STRING WITH 1-CLICK COPY */}
                <div
                  onClick={() => handleCopy(activeMailbox.address, 'Email address')}
                  className="bg-blue-50/70 hover:bg-blue-50/90 border border-blue-200 hover:border-blue-400 rounded-xl p-3.5 sm:p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 cursor-pointer transition-all group shadow-2xs"
                >
                  <div className="truncate min-w-0">
                    <span className="text-[11px] text-blue-700 uppercase tracking-wider font-bold block mb-0.5">
                      Temporary Email Address (Click to copy)
                    </span>
                    <span className="font-mono text-base sm:text-xl md:text-2xl font-bold text-slate-900 group-hover:text-blue-700 truncate block select-all">
                      {activeMailbox.address}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      className="w-full sm:w-auto px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95 cursor-pointer"
                    >
                      {copiedAddress ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4 text-white" />}
                      <span>{copiedAddress ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>

                {/* COMPACT ACTION TOOLBAR (CLASSIC TEMP-MAIL SIZING) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 pt-1 text-xs">
                  {/* COPY */}
                  <button
                    onClick={() => handleCopy(activeMailbox.address, 'Email address')}
                    className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                    title="Copy email address"
                  >
                    <Copy className="w-3.5 h-3.5 text-blue-600" />
                    <span>Copy</span>
                  </button>

                  {/* REFRESH */}
                  <button
                    onClick={handleManualRefresh}
                    disabled={isCheckingMail}
                    className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                    title="Refresh inbox messages"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isCheckingMail ? 'animate-spin' : ''}`} />
                    <span>Refresh</span>
                  </button>

                  {/* CHANGE / NEW */}
                  <button
                    onClick={() => handleChangeAddress()}
                    className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                    title="Generate a new random email address"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>Change</span>
                  </button>

                  {/* DEDICATED TEMP NUMBER BUTTON */}
                  <button
                    onClick={() => setActiveTab('numbers')}
                    className="h-9 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white border border-blue-600 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-xs font-semibold"
                    title="Open Temporary Phone Numbers to receive SMS verification codes"
                  >
                    <Phone className="w-3.5 h-3.5 text-white" />
                    <span>Temp Number</span>
                  </button>

                  {/* CUSTOM ALIAS */}
                  <button
                    onClick={() => setShowGenerateModal(true)}
                    className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                    title="Create custom email username and domain"
                  >
                    <Plus className="w-3.5 h-3.5 text-blue-600" />
                    <span>Custom</span>
                  </button>

                  {/* QR CODE */}
                  <button
                    onClick={() =>
                      setQrModalData({
                        title: 'Share Disposable Email',
                        value: activeMailbox.address,
                        subtitle: 'Scan with camera to send verification or activation email',
                      })
                    }
                    className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                    title="Show QR code for mobile scanning"
                  >
                    <QrIcon className="w-3.5 h-3.5 text-blue-600" />
                    <span>QR Code</span>
                  </button>

                  {/* SIMULATE TEST OTP */}
                  <button
                    onClick={() => {
                      const testOtp = Math.floor(100000 + Math.random() * 900000).toString();
                      handleInboundEmail({
                        toAddress: activeMailbox.address,
                        fromAddress: 'security@instagram.com',
                        fromName: 'Instagram Security',
                        subject: `${testOtp} is your Instagram verification code`,
                        plainText: `Hi! Your Instagram security verification code is ${testOtp}. Do not share this code with anyone.`,
                        htmlBody: `<div style="font-family:sans-serif;padding:24px;color:#0f172a;border:1px solid #e2e8f0;border-radius:12px;background:#ffffff;"><h3 style="margin-top:0;color:#1e3a8a;">Instagram Security</h3><p>Your one-time verification code is:</p><div style="font-size:36px;font-weight:bold;letter-spacing:6px;color:#2563eb;margin:16px 0;font-family:monospace;background:#eff6ff;padding:12px 18px;border-radius:8px;display:inline-block;">${testOtp}</div><p style="color:#64748b;font-size:12px;margin-bottom:0;">This code expires in 10 minutes. If you did not request this, please ignore.</p></div>`,
                      });
                    }}
                    className="h-9 px-3 rounded-lg bg-blue-50/90 hover:bg-blue-100 text-blue-700 border border-blue-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                    title="Simulate an instant incoming OTP email from Instagram"
                  >
                    <Send className="w-3.5 h-3.5 text-blue-600" />
                    <span>Test OTP</span>
                  </button>
                </div>

                {/* TEMP NUMBER PROMOTION BANNER */}
                <div className="bg-gradient-to-r from-blue-50/70 to-sky-50/70 rounded-xl p-3 sm:p-3.5 border border-blue-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">
                        Need SMS Verification Codes instead of Email?
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Get temporary virtual phone numbers for WhatsApp, Telegram, Google, Uber &amp; 50+ apps.
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('numbers')}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shrink-0 transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer self-stretch sm:self-auto justify-center"
                  >
                    <span>Open Temp Number</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* HOW IT WORKS TIP */}
                <div className="bg-slate-50/80 rounded-xl p-3 text-xs text-slate-600 border border-slate-200/80 flex items-start gap-2.5">
                  <span className="text-blue-600 font-bold text-sm shrink-0">💡</span>
                  <span>
                    <strong>How it works:</strong> Copy the email address above and paste it into any website or app (Instagram, Discord, Telegram, Netflix, ChatGPT, etc.). Your verification code or confirmation link will appear in the inbox below automatically.
                  </span>
                </div>
              </div>
            ) : (
              <div className="p-8 bg-white border border-slate-200 rounded-3xl text-center shadow-xs">
                <p className="text-sm text-slate-500 mb-4">No active inboxes. Create one to get started.</p>
                <button
                  onClick={() => setShowGenerateModal(true)}
                  className="px-5 py-2.5 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20"
                >
                  Generate Email
                </button>
              </div>
            )}

            {/* LATEST OTP HERO BANNER IF EXTRACTED */}
            {latestOtpMessage && latestOtpMessage.extractedOtp && (
              <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 text-white border border-blue-500/80 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md shadow-blue-600/15">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center shrink-0 border border-white/20">
                    <ShieldCheck className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-[11px] uppercase font-bold text-blue-100 tracking-wider">
                      Latest Verification Code Detected ({latestOtpMessage.fromName || 'Security'})
                    </div>
                    <div className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-widest mt-0.5">
                      {latestOtpMessage.extractedOtp}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(latestOtpMessage.extractedOtp!, 'Verification code')}
                  className="w-full sm:w-auto px-4 py-2 rounded-lg bg-white hover:bg-blue-50 text-blue-700 font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 shadow-xs active:scale-95 cursor-pointer shrink-0"
                >
                  <Check className="w-4 h-4 text-blue-600" />
                  <span>Copy Code</span>
                </button>
              </div>
            )}

            {/* INBOX MESSAGES SECTION */}
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
              
              {/* SECTION HEADER */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                    <Inbox className="w-4 h-4" />
                  </div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 uppercase tracking-wider">
                    Inbox Messages ({mailboxMessages.length})
                  </h3>
                  {isCheckingMail && (
                    <span className="text-[11px] text-blue-600 font-semibold animate-pulse">Checking mail...</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowWebhookModal(true)}
                    className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer px-2.5 py-1 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Test Email</span>
                  </button>
                </div>
              </div>

              {/* MESSAGES LIST OR EMPTY STATE */}
              {mailboxMessages.length === 0 ? (
                <div className="rounded-xl border-2 border-dashed border-blue-200 bg-slate-50/50 flex flex-col items-center justify-center p-8 sm:p-10 text-center space-y-3.5">
                  <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-2xs">
                    <Mail className="w-7 h-7 animate-pulse" />
                  </div>
                  <div className="max-w-md space-y-1">
                    <h4 className="text-sm sm:text-base font-extrabold text-slate-900">Waiting for incoming emails &amp; codes...</h4>
                    <p className="text-xs text-slate-500">
                      Copy <span className="text-blue-700 font-mono font-bold">{activeMailbox?.address}</span> and paste it into any website. New messages will appear here automatically within seconds.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                    <button
                      onClick={() => handleCopy(activeMailbox?.address || '', 'Email address')}
                      className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white transition-all flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Address</span>
                    </button>
                    <button
                      onClick={handleManualRefresh}
                      disabled={isCheckingMail}
                      className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-2xs"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isCheckingMail ? 'animate-spin text-blue-600' : 'text-blue-600'}`} />
                      <span>{isCheckingMail ? 'Checking...' : 'Check Server'}</span>
                    </button>
                    <button
                      onClick={() => {
                        const testOtp = Math.floor(100000 + Math.random() * 900000).toString();
                        handleInboundEmail({
                          toAddress: activeMailbox?.address || 'user@maxxspace.com',
                          fromAddress: 'security@instagram.com',
                          fromName: 'Instagram Security',
                          subject: `${testOtp} is your Instagram verification code`,
                          plainText: `Hi! Your Instagram security code is ${testOtp}. Do not share this code with anyone.`,
                          htmlBody: `<div style="font-family:sans-serif;padding:20px;color:#0f172a;border:1px solid #e2e8f0;border-radius:12px;"><h3>Instagram Security</h3><p>Your verification code is:</p><div style="font-size:32px;font-weight:bold;letter-spacing:6px;color:#2563eb;margin:14px 0;font-family:monospace;">${testOtp}</div><p style="color:#64748b;font-size:12px;">Expires in 10 minutes.</p></div>`,
                        });
                      }}
                      className="px-3.5 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                      <span>Simulate Test OTP</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {mailboxMessages.map((msg: EmailMessage) => (
                    <div
                      key={msg.id}
                      onClick={() => {
                        msg.isRead = true;
                        setSelectedEmailMessage(msg);
                      }}
                      className={`p-3.5 sm:p-4 rounded-xl border transition-all cursor-pointer relative hover:shadow-xs ${
                        !msg.isRead
                          ? 'bg-white border-blue-300 shadow-2xs'
                          : 'bg-slate-50/70 border-slate-200 hover:border-blue-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs mb-1">
                        <div className="flex items-center gap-2">
                          {!msg.isRead ? (
                            <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" title="Unread"></span>
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-slate-300 shrink-0"></span>
                          )}
                          <div className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {(msg.fromName || msg.fromAddress || 'M')[0].toUpperCase()}
                          </div>
                          <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                            {msg.fromName || msg.fromAddress}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">&lt;{msg.fromAddress}&gt;</span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {new Date(msg.receivedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="text-xs sm:text-sm font-bold text-slate-900 mb-0.5">{msg.subject}</div>
                      <p className="text-xs text-slate-500 line-clamp-1 mb-2.5">{msg.textPreview}</p>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                        {msg.extractedOtp ? (
                          <OtpChip code={msg.extractedOtp} compact={true} />
                        ) : (
                          <span className="text-[11px] text-slate-400 font-medium">Standard message</span>
                        )}

                        <div className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800">
                          <span>Read Email</span>
                          <ChevronRight className="w-3.5 h-3.5 text-blue-600" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* -------------------- TAB 2: TEMP NUMBER (LIKE A PHONE WORK) -------------------- */}
        {activeTab === 'numbers' && (
          <div className="space-y-6">

            {/* LIVE CELLULAR STATUS BAR */}
            <div className="bg-blue-50/90 border border-blue-200/90 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-600"></span>
                </span>
                <span className="font-bold text-xs sm:text-sm text-blue-900">Live Cellular Line Active</span>
                <span className="text-[11px] bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1">
                  <Wifi className="w-3 h-3 text-blue-700" />
                  <span>{activePhoneNumber.carrier || '5G LTE'} • {activePhoneNumber.countryName}</span>
                </span>
              </div>

              <div className="flex items-center gap-2 text-xs">
                {/* VIEW MODE TOGGLE */}
                <div className="bg-white border border-blue-200 rounded-lg p-0.5 flex items-center shadow-2xs">
                  <button
                    onClick={() => setPhoneWorkMode('phone')}
                    className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                      phoneWorkMode === 'phone'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>Phone Simulator</span>
                  </button>
                  <button
                    onClick={() => setPhoneWorkMode('dashboard')}
                    className={`px-2.5 py-1 rounded-md text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                      phoneWorkMode === 'dashboard'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Inbox className="w-3.5 h-3.5" />
                    <span>List View</span>
                  </button>
                </div>

                <button
                  onClick={() => {
                    syncState();
                    showToast('Checked for new incoming SMS messages');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white hover:bg-blue-100/70 border border-blue-200 text-blue-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                  title="Check for new SMS"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
                  <span>Refresh</span>
                </button>
              </div>
            </div>

            {/* MAIN DISPOSABLE PHONE NUMBER HERO CARD */}
            <div className="bg-white border-2 border-blue-200 rounded-3xl p-5 sm:p-7 shadow-lg shadow-blue-500/5 space-y-5">
              
              {/* TOP HEADER ROW */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shadow-2xs text-xl">
                    {activePhoneNumber.flag}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-slate-900 text-sm sm:text-base">
                        {activePhoneNumber.countryName} Virtual Line
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        ONLINE
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                      <span>{phoneSmsMessages.length} SMS received</span>
                      <span>•</span>
                      <span className="text-slate-400 font-mono">Carrier: {activePhoneNumber.carrier || '5G Network'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <CountdownBadge expiresAt={activePhoneNumber.expiresAt} showExtendButton={false} />
                  <button
                    onClick={() => setShowRentModal(true)}
                    className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-blue-600" />
                    <span>Rent Extra Line</span>
                  </button>
                </div>
              </div>

              {/* PHONE NUMBER DISPLAY STRING WITH 1-CLICK COPY */}
              <div
                onClick={() => handleCopyNumber(activePhoneNumber.number)}
                className="bg-blue-50/70 hover:bg-blue-50/90 border border-blue-200 hover:border-blue-400 rounded-xl p-3.5 sm:p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 cursor-pointer transition-all group shadow-2xs"
              >
                <div className="truncate min-w-0">
                  <span className="text-[11px] text-blue-700 uppercase tracking-wider font-bold block mb-0.5">
                    Temporary Mobile Phone Number (Click to copy)
                  </span>
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{activePhoneNumber.flag}</span>
                    <span className="font-mono text-lg sm:text-2xl md:text-3xl font-extrabold text-slate-900 group-hover:text-blue-700 tracking-wide select-all">
                      {activePhoneNumber.number}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    className="w-full sm:w-auto px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95 cursor-pointer"
                  >
                    {copiedNumber === activePhoneNumber.number ? (
                      <Check className="w-4 h-4 text-white" />
                    ) : (
                      <Copy className="w-4 h-4 text-white" />
                    )}
                    <span>{copiedNumber === activePhoneNumber.number ? 'Copied' : 'Copy Number'}</span>
                  </button>
                </div>
              </div>

              {/* QUICK COUNTRY SELECTOR BAR */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1">
                  <Globe className="w-3 h-3 text-blue-600" />
                  <span>Quick Country Switch (1-Click Change Line):</span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {[
                    { code: 'US', flag: '🇺🇸', name: 'USA (+1)' },
                    { code: 'GB', flag: '🇬🇧', name: 'UK (+44)' },
                    { code: 'CA', flag: '🇨🇦', name: 'Canada (+1)' },
                    { code: 'DE', flag: '🇩🇪', name: 'Germany (+49)' },
                    { code: 'IN', flag: '🇮🇳', name: 'India (+91)' },
                    { code: 'FR', flag: '🇫🇷', name: 'France (+33)' },
                    { code: 'AU', flag: '🇦🇺', name: 'Australia (+61)' },
                  ].map((c) => {
                    const isSelected = activePhoneNumber.countryCode === c.code;
                    return (
                      <button
                        key={c.code}
                        onClick={() => handleSelectCountry(c.code)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:border-blue-300'
                        }`}
                      >
                        <span>{c.flag}</span>
                        <span>{c.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* COMPACT ACTION TOOLBAR (CLASSIC TEMP-MAIL SIZING) */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-1 text-xs">
                {/* COPY */}
                <button
                  onClick={() => handleCopyNumber(activePhoneNumber.number)}
                  className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                  title="Copy Phone Number"
                >
                  <Copy className="w-3.5 h-3.5 text-blue-600" />
                  <span>Copy</span>
                </button>

                {/* REFRESH */}
                <button
                  onClick={() => {
                    syncState();
                    showToast('SMS inbox refreshed');
                  }}
                  className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                  title="Refresh SMS messages"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
                  <span>Refresh</span>
                </button>

                {/* CHANGE NUMBER */}
                <button
                  onClick={() => handleChangePhoneNumber()}
                  className="h-9 px-3 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-blue-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                  title="Generate a fresh phone number"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>Change</span>
                </button>

                {/* WHATSAPP TEST OTP */}
                <button
                  onClick={() => handleSimulatePresetSms('whatsapp')}
                  className="h-9 px-3 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                  title="Simulate WhatsApp Verification Code"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>WhatsApp OTP</span>
                </button>

                {/* TELEGRAM TEST OTP */}
                <button
                  onClick={() => handleSimulatePresetSms('telegram')}
                  className="h-9 px-3 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                  title="Simulate Telegram Verification Code"
                >
                  <Send className="w-3.5 h-3.5 text-blue-600" />
                  <span>Telegram OTP</span>
                </button>

                {/* CLEAR SMS */}
                <button
                  onClick={handleClearSms}
                  className="h-9 px-3 rounded-lg bg-white hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-200 hover:border-rose-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-2xs font-semibold"
                  title="Clear SMS messages for this line"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                  <span>Clear SMS</span>
                </button>
              </div>
            </div>

            {/* LATEST PHONE OTP HERO BANNER IF EXTRACTED */}
            {phoneSmsMessages.length > 0 && phoneSmsMessages[0].extractedOtp && (
              <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 text-white border border-blue-500/80 rounded-2xl p-4 sm:p-5 shadow-md shadow-blue-600/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
                  </div>
                  <div>
                    <div className="text-[11px] uppercase tracking-wider text-blue-200 font-bold">
                      Latest Verification Code Received on {activePhoneNumber.number}
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-widest">
                        {phoneSmsMessages[0].extractedOtp}
                      </span>
                      <span className="text-xs text-blue-200 font-semibold">
                        from {phoneSmsMessages[0].senderName || phoneSmsMessages[0].fromNumber}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(phoneSmsMessages[0].extractedOtp!, 'OTP Code')}
                  className="px-4 py-2 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-xs active:scale-95 cursor-pointer shrink-0"
                >
                  <Copy className="w-4 h-4 text-blue-700" />
                  <span>Copy Verification Code</span>
                </button>
              </div>
            )}

            {/* LIVE AUTO-DELIVERY RADAR WHEN NUMBER IS COPIED */}
            {smsCountdown !== null && (
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-2xl p-4 text-amber-950 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md animate-pulse">
                <div className="flex items-center gap-3">
                  <span className="relative flex h-3.5 w-3.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-amber-600"></span>
                  </span>
                  <div>
                    <div className="font-extrabold text-xs sm:text-sm text-amber-950 flex items-center gap-2">
                      <span>Listening for incoming verification code on {activePhoneNumber.number}...</span>
                      <span className="bg-amber-200 text-amber-950 text-xs px-2 py-0.5 rounded-full font-mono font-black">
                        {smsCountdown}s
                      </span>
                    </div>
                    <p className="text-[11px] text-amber-800">
                      Auto-detecting incoming SMS from {selectedOtpService || 'service'}. The code will arrive and ring automatically.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSmsCountdown(0);
                  }}
                  className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition-transform active:scale-95 cursor-pointer shrink-0"
                >
                  Deliver Code Now ⚡
                </button>
              </div>
            )}

            {/* INSTANT VERIFICATION CODES & SMS RECEIVER HUB */}
            <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                <div className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600"></span>
                  </span>
                  <span>Instant Verification Code Receiver (WhatsApp, Telegram, Google, etc.):</span>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  {/* AUTO-SMS TRAFFIC TOGGLE */}
                  <button
                    onClick={() => {
                      setAutoSmsTraffic(!autoSmsTraffic);
                      showToast(autoSmsTraffic ? 'Auto-SMS background traffic paused' : 'Auto-SMS background traffic enabled (works like real phone)');
                    }}
                    className={`px-2 py-1 rounded-md text-[11px] font-semibold border flex items-center gap-1 cursor-pointer transition-colors ${
                      autoSmsTraffic
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                    title="Toggle auto-incoming SMS background traffic"
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${autoSmsTraffic ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`}></span>
                    <span>Auto-Traffic: {autoSmsTraffic ? 'Active' : 'Off'}</span>
                  </button>

                  <button
                    onClick={() => setShowCustomSmsModal(!showCustomSmsModal)}
                    className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Send className="w-3 h-3 text-blue-600" />
                    <span>{showCustomSmsModal ? 'Hide Custom' : 'Custom SMS'}</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {[
                  { id: 'whatsapp', name: 'WhatsApp OTP', color: 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100' },
                  { id: 'google', name: 'Google (G-Code)', color: 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100' },
                  { id: 'telegram', name: 'Telegram Code', color: 'bg-sky-50 text-sky-800 border-sky-200 hover:bg-sky-100' },
                  { id: 'instagram', name: 'Instagram Code', color: 'bg-pink-50 text-pink-800 border-pink-200 hover:bg-pink-100' },
                  { id: 'facebook', name: 'Facebook Code', color: 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100' },
                  { id: 'bank', name: 'Bank Passcode', color: 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100' },
                  { id: 'amazon', name: 'Amazon OTP', color: 'bg-orange-50 text-orange-800 border-orange-200 hover:bg-orange-100' },
                  { id: 'netflix', name: 'Netflix Code', color: 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100' },
                  { id: 'uber', name: 'Uber Code', color: 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200' },
                  { id: 'openai', name: 'OpenAI Code', color: 'bg-teal-50 text-teal-800 border-teal-200 hover:bg-teal-100' },
                  { id: 'paypal', name: 'PayPal OTP', color: 'bg-cyan-50 text-cyan-800 border-cyan-200 hover:bg-cyan-100' },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleInstantFetchCode(s.id)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all cursor-pointer active:scale-95 flex items-center gap-1.5 shadow-2xs ${s.color}`}
                    title={`Receive authentic verification code for ${s.name}`}
                  >
                    <span>Receive {s.name}</span>
                  </button>
                ))}
              </div>

              {/* EXPANDABLE CUSTOM SMS SENDER */}
              {showCustomSmsModal && (
                <form
                  onSubmit={handleSimulateCustomSms}
                  className="mt-3 pt-3 border-t border-slate-100 bg-slate-50/80 p-3.5 rounded-xl border border-slate-200 space-y-3"
                >
                  <div className="text-xs font-bold text-slate-800 flex items-center gap-1">
                    <Send className="w-3.5 h-3.5 text-blue-600" />
                    <span>Send Custom Inbound SMS to {activePhoneNumber.number}:</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <input
                      type="text"
                      placeholder="Sender Name (e.g., Bank, Discord, Tinder)"
                      value={customSmsForm.sender}
                      onChange={(e) => setCustomSmsForm({ ...customSmsForm, sender: e.target.value })}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-800 focus:outline-none focus:border-blue-500"
                    />
                    <input
                      type="text"
                      placeholder="From Number (e.g. +1 800 555 0199)"
                      value={customSmsForm.from}
                      onChange={(e) => setCustomSmsForm({ ...customSmsForm, from: e.target.value })}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-800 font-mono focus:outline-none focus:border-blue-500"
                    />
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="SMS Message (include code like 491-029)"
                        value={customSmsForm.text}
                        onChange={(e) => setCustomSmsForm({ ...customSmsForm, text: e.target.value })}
                        className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-800 focus:outline-none focus:border-blue-500"
                      />
                      <button
                        type="submit"
                        className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs transition-colors shrink-0 cursor-pointer shadow-xs"
                      >
                        Send SMS
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </div>

            {/* ----------------- PHONE WORKSTATION VIEW (LIKE A PHONE WORK) ----------------- */}
            {phoneWorkMode === 'phone' ? (
              <div className="flex flex-col items-center justify-center py-2">
                
                {/* VIRTUAL SMARTPHONE CHASSIS */}
                <div className="w-full max-w-md bg-slate-900 border-4 border-slate-800 rounded-[2.5rem] shadow-2xl overflow-hidden p-3 text-slate-800">
                  
                  {/* PHONE TOP NOTCH / DYNAMIC ISLAND */}
                  <div className="relative pt-1 pb-2 flex items-center justify-between px-5 text-white text-xs select-none">
                    {/* PHONE CLOCK */}
                    <span className="font-bold font-mono text-[11px] text-slate-200">
                      {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    {/* DYNAMIC ISLAND PILL */}
                    <div className="w-20 h-4 bg-black rounded-full flex items-center justify-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-slate-900 border border-slate-700"></div>
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50"></div>
                    </div>

                    {/* PHONE STATUS ICONS */}
                    <div className="flex items-center gap-1.5 text-slate-200 text-[11px]">
                      <span className="font-bold text-[10px]">5G</span>
                      <Wifi className="w-3.5 h-3.5" />
                      <div className="w-4 h-2 border border-white/60 rounded-xs p-0.2 flex items-center">
                        <div className="w-full h-full bg-white rounded-2xs"></div>
                      </div>
                    </div>
                  </div>

                  {/* PHONE SCREEN CONTAINER */}
                  <div className="bg-slate-100 rounded-[2rem] overflow-hidden flex flex-col h-[520px] sm:h-[560px] border border-slate-300 shadow-inner">
                    
                    {/* MESSAGES APP HEADER INSIDE PHONE */}
                    <div className="bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-2.5 flex items-center justify-between shrink-0">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                          {activePhoneNumber.flag}
                        </div>
                        <div>
                          <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                            <span>{activePhoneNumber.number}</span>
                            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          </div>
                          <div className="text-[10px] text-slate-500 font-medium">
                            {activePhoneNumber.carrier || '5G LTE'} • Inbound SMS Line
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleCopyNumber(activePhoneNumber.number)}
                          className="p-1.5 rounded-lg hover:bg-slate-100 text-blue-600 transition-colors cursor-pointer"
                          title="Copy Number"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={handleClearSms}
                          className="p-1.5 rounded-lg hover:bg-slate-100 text-rose-500 transition-colors cursor-pointer"
                          title="Clear SMS"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* PHONE SMS CONVERSATION FEED */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
                      
                      {/* TOP INFO BANNER INSIDE PHONE */}
                      <div className="text-center py-1">
                        <span className="text-[10px] bg-slate-200 text-slate-600 px-3 py-1 rounded-full font-medium inline-block shadow-2xs">
                          Today • Secure Virtual Mobile Line
                        </span>
                      </div>

                      {phoneSmsMessages.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center p-4 space-y-3">
                          <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-2xs">
                            <MessageSquare className="w-6 h-6 animate-pulse" />
                          </div>
                          <div className="space-y-1">
                            <h4 className="text-xs sm:text-sm font-extrabold text-slate-800">
                              Phone is Ready &amp; Listening
                            </h4>
                            <p className="text-[11px] text-slate-500 max-w-xs leading-relaxed">
                              Copy <span className="font-mono font-bold text-blue-700">{activePhoneNumber.number}</span> and paste it into WhatsApp, Google, or any app. Incoming SMS will appear here immediately!
                            </p>
                          </div>

                          <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                            <button
                              onClick={() => handleSimulatePresetSms('whatsapp')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold transition-all shadow-xs cursor-pointer active:scale-95"
                            >
                              Test WhatsApp SMS
                            </button>
                            <button
                              onClick={() => handleSimulatePresetSms('google')}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold transition-all shadow-xs cursor-pointer active:scale-95"
                            >
                              Test Google Code
                            </button>
                          </div>
                        </div>
                      ) : (
                        phoneSmsMessages.map((sms: SmsMessage) => (
                          <div key={sms.id} className="space-y-1 group">
                            
                            {/* SENDER LABEL & TIME */}
                            <div className="flex items-center justify-between px-1 text-[10px] text-slate-500">
                              <span className="font-bold text-blue-700 flex items-center gap-1">
                                <span>{sms.senderName || sms.fromNumber}</span>
                                <span className="text-slate-400 font-mono text-[9px]">({sms.fromNumber})</span>
                              </span>
                              <span className="font-mono">
                                {new Date(sms.receivedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>

                            {/* INCOMING SMS BUBBLE */}
                            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-xs p-3.5 shadow-xs space-y-2.5 text-xs text-slate-800">
                              <p className="leading-relaxed select-text">{sms.text}</p>

                              {/* EMBEDDED OTP CARD WITH 1-CLICK COPY */}
                              {sms.extractedOtp && (
                                <div className="bg-blue-50 border border-blue-200 rounded-xl p-2.5 flex items-center justify-between gap-2 shadow-2xs">
                                  <div>
                                    <div className="text-[10px] font-bold text-blue-800 uppercase tracking-wider">
                                      Security Passcode
                                    </div>
                                    <div className="font-mono text-base font-extrabold text-blue-900 tracking-wider">
                                      {sms.extractedOtp}
                                    </div>
                                  </div>
                                  <button
                                    onClick={() => handleCopy(sms.extractedOtp!, 'OTP code')}
                                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold flex items-center gap-1 transition-all cursor-pointer shadow-xs active:scale-95 shrink-0"
                                  >
                                    <Copy className="w-3 h-3 text-white" />
                                    <span>Copy Code</span>
                                  </button>
                                </div>
                              )}

                              {/* DELETE BUTTON */}
                              <div className="flex justify-end pt-0.5">
                                <button
                                  onClick={() => handleDeleteSms(sms.id)}
                                  className="text-[10px] text-slate-400 hover:text-rose-600 transition-colors flex items-center gap-0.5 cursor-pointer"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span>Delete</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* PHONE QUICK INBOUND TRANSMITTER FOOTER */}
                    <div className="bg-white border-t border-slate-200 p-2.5 shrink-0 space-y-2">
                      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px] no-scrollbar">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1">
                          Test:
                        </span>
                        <button
                          onClick={() => handleSimulatePresetSms('whatsapp')}
                          className="px-2 py-0.5 rounded-full bg-emerald-100 hover:bg-emerald-200 text-emerald-800 text-[10px] font-bold shrink-0 transition-colors cursor-pointer"
                        >
                          WhatsApp
                        </button>
                        <button
                          onClick={() => handleSimulatePresetSms('google')}
                          className="px-2 py-0.5 rounded-full bg-blue-100 hover:bg-blue-200 text-blue-800 text-[10px] font-bold shrink-0 transition-colors cursor-pointer"
                        >
                          Google
                        </button>
                        <button
                          onClick={() => handleSimulatePresetSms('telegram')}
                          className="px-2 py-0.5 rounded-full bg-sky-100 hover:bg-sky-200 text-sky-800 text-[10px] font-bold shrink-0 transition-colors cursor-pointer"
                        >
                          Telegram
                        </button>
                        <button
                          onClick={() => handleSimulatePresetSms('uber')}
                          className="px-2 py-0.5 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-800 text-[10px] font-bold shrink-0 transition-colors cursor-pointer"
                        >
                          Uber
                        </button>
                      </div>

                      {/* IN-PHONE TEST INPUT BAR */}
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          const inputEl = (e.currentTarget.elements.namedItem('phoneTestInput') as HTMLInputElement);
                          const val = inputEl.value.trim();
                          if (!val) return;
                          handleInboundSms(activePhoneNumber.id, '+1 (800) 555-0199', 'Direct SMS', val);
                          inputEl.value = '';
                        }}
                        className="flex items-center gap-1.5"
                      >
                        <input
                          name="phoneTestInput"
                          type="text"
                          placeholder="Type simulated SMS message..."
                          className="flex-1 bg-slate-100 border border-slate-200 rounded-full px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-500"
                        />
                        <button
                          type="submit"
                          className="w-8 h-8 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition-all cursor-pointer shadow-xs shrink-0 active:scale-95"
                          title="Transmit SMS to this phone"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </form>
                    </div>

                  </div>
                </div>
              </div>
            ) : (
              /* ----------------- SAAS LIST VIEW (DASHBOARD) ----------------- */
              <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                      <Inbox className="w-4 h-4" />
                    </div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 uppercase tracking-wider">
                      Received SMS Messages ({phoneSmsMessages.length})
                    </h3>
                  </div>

                  <button
                    onClick={handleClearSms}
                    disabled={phoneSmsMessages.length === 0}
                    className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear SMS</span>
                  </button>
                </div>

                {phoneSmsMessages.length === 0 ? (
                  <div className="text-center py-10 px-4 space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto shadow-2xs">
                      <MessageSquare className="w-6 h-6 animate-pulse" />
                    </div>
                    <h4 className="text-sm font-bold text-slate-900">No SMS Received Yet on {activePhoneNumber.number}</h4>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      Use this phone number on any website or mobile app. Inbound verification SMS will be displayed here in real time.
                    </p>
                    <div className="flex justify-center gap-2 pt-2">
                      <button
                        onClick={() => handleSimulatePresetSms('whatsapp')}
                        className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs cursor-pointer"
                      >
                        Simulate WhatsApp OTP
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {phoneSmsMessages.map((sms: SmsMessage) => (
                      <div
                        key={sms.id}
                        className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-blue-300 transition-all space-y-2.5 shadow-2xs"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                              {(sms.senderName || sms.fromNumber)[0].toUpperCase()}
                            </div>
                            <div>
                              <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                                {sms.senderName || sms.fromNumber}
                              </span>
                              <span className="text-[11px] text-slate-400 font-mono ml-2">({sms.fromNumber})</span>
                            </div>
                          </div>
                          <span className="text-[11px] text-slate-500 font-mono">
                            {new Date(sms.receivedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">{sms.text}</p>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                          {sms.extractedOtp ? (
                            <OtpChip code={sms.extractedOtp} compact={true} />
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">Standard SMS</span>
                          )}

                          <button
                            onClick={() => handleDeleteSms(sms.id)}
                            className="p-1.5 rounded-md hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Delete SMS"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* QUICK CATALOG / OTHER ACTIVE LINES SECTION */}
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-600" />
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 uppercase tracking-wider">
                    Browse Other Available Numbers in Catalog
                  </h3>
                </div>
                <button
                  onClick={() => setShowRentModal(true)}
                  className="text-xs text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
                >
                  View Full Catalog ({AVAILABLE_PHONE_CATALOG.length})
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {AVAILABLE_PHONE_CATALOG.slice(0, 6).map((cat) => {
                  const isActive = activePhoneNumber.number === cat.number;
                  return (
                    <div
                      key={cat.number}
                      className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 shadow-2xs ${
                        isActive
                          ? 'border-blue-400 bg-blue-50/40'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-white hover:border-blue-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="text-2xl">{cat.flag}</span>
                        <div className="truncate">
                          <div className="text-xs font-bold text-slate-900">{cat.countryName}</div>
                          <div className="font-mono text-xs font-bold text-blue-700 truncate">{cat.number}</div>
                          <div className="text-[10px] text-slate-400">{cat.carrier}</div>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          const existing = state.phoneNumbers.find((p: PhoneNumber) => p.number === cat.number);
                          if (existing) {
                            setActivePhoneNumberId(existing.id);
                            setActivePhoneCountry(existing.countryCode);
                            showToast(`Switched to line: ${cat.number}`);
                          } else {
                            const newNum: PhoneNumber = {
                              id: 'num_' + Math.random().toString(36).substring(2, 9),
                              number: cat.number,
                              countryCode: cat.countryCode,
                              countryName: cat.countryName,
                              flag: cat.flag,
                              provider: 'mock',
                              status: 'ACTIVE',
                              rentedAt: new Date().toISOString(),
                              expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
                              creditsCost: 0,
                              receivedSmsQty: 0,
                              refundIssued: false,
                            };
                            TempBoxStore.updateState((s) => {
                              s.phoneNumbers = [newNum, ...s.phoneNumbers.filter((p: PhoneNumber) => p.number !== newNum.number)];
                              return s;
                            });
                            syncState();
                            setActivePhoneNumberId(newNum.id);
                            setActivePhoneCountry(newNum.countryCode);
                            showToast(`Activated ${cat.countryName} line: ${cat.number}`);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-md text-xs font-semibold shrink-0 cursor-pointer shadow-2xs transition-all active:scale-95 ${
                          isActive
                            ? 'bg-blue-600 text-white'
                            : 'bg-white hover:bg-blue-50 text-blue-700 border border-slate-200 hover:border-blue-300'
                        }`}
                      >
                        {isActive ? 'Active' : 'Use Line'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* -------------------- TAB 3: SETTINGS & PRIVACY -------------------- */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            
            {/* PROFILE & PRIVACY HERO */}
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 sm:p-6 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-blue-100 border border-blue-200 flex items-center justify-center text-blue-700 font-extrabold text-lg uppercase shadow-2xs">
                    {state.user.isGuest ? 'G' : 'U'}
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                      {state.user.isGuest ? 'Anonymous Guest Session' : state.user.email}
                    </h3>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Session ID: {state.user.deviceId}
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-1.5 text-blue-900 font-bold text-xs sm:text-sm">
                    <Coins className="w-4 h-4 text-amber-500" />
                    <span>Balance: {state.user.credits} Credits</span>
                  </div>
                  <button
                    onClick={() => setShowCreditsModal(true)}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs cursor-pointer shadow-xs active:scale-95"
                  >
                    Top Up
                  </button>
                </div>
              </div>

              {/* QUICK CONTROLS */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div
                  onClick={() => setShowSettingsModal(true)}
                  className="p-4 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50/50 hover:bg-white transition-all cursor-pointer space-y-1.5 shadow-2xs"
                >
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                    <SettingsIcon className="w-4 h-4" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm">Preferences &amp; GDPR</h4>
                  <p className="text-[11px] text-slate-500">Configure auto-refresh, notifications, and wipe storage.</p>
                </div>

                <div
                  onClick={() => setShowDocsModal(true)}
                  className="p-4 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50/50 hover:bg-white transition-all cursor-pointer space-y-1.5 shadow-2xs"
                >
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm">Fastify &amp; Twilio Docs</h4>
                  <p className="text-[11px] text-slate-500">View code architecture and live webhook deployment guide.</p>
                </div>

                </div>
              </div>

              {/* SECURITY & PRIVACY ARCHITECTURE */}
              <div className="bg-slate-50 border border-slate-200/90 rounded-xl p-4 text-xs text-slate-600 space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-2 text-xs sm:text-sm">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>TempBox Security &amp; Privacy Guarantees</span>
                </div>
                <p>• Zero telemetry SDKs, marketing trackers, or third-party cookies.</p>
                <p>• AES-256-GCM encryption at rest for email content &amp; SMS messages.</p>
                <p>• Auto-expiration policy: Mailboxes and messages self-destruct after expiry.</p>
                <p>• 1-Click GDPR Data Purge: Purge all mailboxes, SMS, and credentials from your browser immediately.</p>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  onClick={handleResetAccount}
                  className="px-3.5 py-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Purge All Account Data (GDPR)</span>
                </button>
              </div>
            </div>
          )}
        </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-200 bg-white py-6 px-4 mt-auto text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-800">TempBox</span>
            <span>— Fast Disposable Email &amp; Temporary Phone Numbers</span>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold">
            <button onClick={() => setShowAndroidModal(true)} className="hover:text-emerald-600 text-emerald-700 font-bold flex items-center gap-1 cursor-pointer">
              <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
              <span>Android APK</span>
            </button>
            <button onClick={() => setShowDocsModal(true)} className="hover:text-blue-600 cursor-pointer">
              API &amp; Docs
            </button>
            <button onClick={() => setShowSettingsModal(true)} className="hover:text-blue-600 cursor-pointer">
              Privacy &amp; GDPR
            </button>
          </div>
        </div>
      </footer>

      {/* -------------------- DISCRETE CORNER ADMIN SECTION (LOCKED) -------------------- */}
      <div className="fixed bottom-4 right-4 z-40">
        <button
          onClick={() => setShowAdminAuthModal(true)}
          className="group flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/90 hover:bg-slate-950 text-slate-300 hover:text-white border border-slate-700/80 shadow-xl backdrop-blur-md transition-all text-xs cursor-pointer active:scale-95"
          title="Admin Section (Password Protected)"
        >
          <Lock className="w-3.5 h-3.5 text-amber-400 group-hover:text-amber-300 transition-colors" />
          <span className="font-mono text-[11px] font-bold tracking-tight">Admin</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
        </button>
      </div>

      {/* -------------------- MODALS -------------------- */}
      {showGenerateModal && (
        <GenerateEmailModal
          onClose={() => setShowGenerateModal(false)}
          onGenerate={handleCreateMailbox}
        />
      )}

      {selectedEmailMessage && (
        <EmailDetailModal
          message={selectedEmailMessage}
          onClose={() => setSelectedEmailMessage(null)}
          onDelete={(id) => {
            TempBoxStore.updateState((s) => {
              s.messages = s.messages.filter((m: EmailMessage) => m.id !== id);
              return s;
            });
            syncState();
            setSelectedEmailMessage(null);
            showToast('Email message deleted');
          }}
          onReportSpam={(id) => {
            TempBoxStore.reportMessageSpam(id);
            syncState();
            setSelectedEmailMessage(null);
            showToast('Report submitted');
          }}
          onForward={(_id) => {
            showToast('Forwarding feature is simulated');
          }}
        />
      )}

      {showRentModal && (
        <RentNumberModal
          userCredits={state.user.credits}
          onClose={() => setShowRentModal(false)}
          onRent={handleRentNumber}
          onOpenCreditsModal={() => {
            setShowRentModal(false);
            setShowCreditsModal(true);
          }}
        />
      )}

      {selectedPhoneNumber && (
        <SmsThreadModal
          phoneNumber={selectedPhoneNumber}
          messages={state.smsMessages.filter((s: SmsMessage) => s.phoneNumberId === selectedPhoneNumber.id)}
          onClose={() => setSelectedPhoneNumber(null)}
          onRelease={handleReleaseNumber}
          onRenew={handleRenewNumber}
          onSimulateIncomingSms={(id) => {
            const testCode = Math.floor(100000 + Math.random() * 900000).toString();
            handleInboundSms(id, '+1 (800) 555-0199', 'Telegram', `Your Telegram code is: ${testCode}`);
          }}
        />
      )}

      {showCreditsModal && (
        <CreditsModal
          currentCredits={state.user.credits}
          transactions={state.transactions}
          onClose={() => setShowCreditsModal(false)}
          onPurchase={handlePurchaseCredits}
        />
      )}

      {showSettingsModal && (
        <SettingsModal
          onClose={() => setShowSettingsModal(false)}
          onResetAccount={handleResetAccount}
        />
      )}

      {showWebhookModal && (
        <WebhookSimulatorModal
          mailboxes={state.mailboxes}
          phoneNumbers={state.phoneNumbers}
          onClose={() => setShowWebhookModal(false)}
          onSendEmail={handleInboundEmail}
          onSendSms={handleInboundSms}
        />
      )}

      {showAdminAuthModal && (
        <AdminAuthModal
          onClose={() => setShowAdminAuthModal(false)}
          onSuccess={() => {
            setShowAdminAuthModal(false);
            setShowAdminModal(true);
            showToast('Admin panel unlocked! Welcome Trilok.');
          }}
        />
      )}

      {showAdminModal && (
        <AdminPanelModal
          user={state.user}
          mailboxes={state.mailboxes}
          messages={state.messages}
          phoneNumbers={state.phoneNumbers}
          abuseReports={state.abuseReports}
          sessionLogs={state.sessionLogs || []}
          totalVisitorsCount={state.totalVisitorsCount || 1542}
          onClose={() => setShowAdminModal(false)}
          onResolveReport={(id) => {
            TempBoxStore.updateState((s) => {
              const rep = s.abuseReports.find((r: AbuseReport) => r.id === id);
              if (rep) rep.resolved = true;
              return s;
            });
            syncState();
            showToast('Abuse report marked resolved');
          }}
          onBanUser={(_userId) => {
            showToast('User moderation action recorded');
          }}
        />
      )}

      {showDocsModal && (
        <CodeDocsModal
          onClose={() => setShowDocsModal(false)}
        />
      )}

      {showOnboarding && (
        <OnboardingModal
          onComplete={(_isGuest, email) => {
            if (email) {
              TempBoxStore.updateState((s) => {
                s.user.email = email;
                s.user.isGuest = false;
                return s;
              });
              syncState();
            }
            setShowOnboarding(false);
          }}
        />
      )}

      {qrModalData && (
        <QrCodeModal
          title={qrModalData.title}
          value={qrModalData.value}
          subtitle={qrModalData.subtitle}
          onClose={() => setQrModalData(null)}
        />
      )}

      {showAndroidModal && (
        <AndroidApkModal
          onClose={() => setShowAndroidModal(false)}
        />
      )}
    </div>
  );
}
