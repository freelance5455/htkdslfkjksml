import { useEffect, useRef, useState } from "react";

const WORLD_WIDTH = 1000;
const WORLD_HEIGHT = 640;

type Screen = "ready" | "playing" | "paused" | "gameover";

type Star = {
  x: number;
  y: number;
  size: number;
  flicker: number;
  depth: number;
};

type Core = {
  x: number;
  y: number;
  radius: number;
  vy: number;
  phase: number;
};

type Rock = {
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  rotation: number;
  spin: number;
  points: number[];
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
};

type Game = {
  ship: { x: number; y: number; vx: number; vy: number; angle: number; invulnerable: number };
  cores: Core[];
  rocks: Rock[];
  particles: Particle[];
  score: number;
  combo: number;
  comboClock: number;
  hull: number;
  elapsed: number;
  rockClock: number;
  coreClock: number;
};

type Hud = {
  score: number;
  combo: number;
  hull: number;
  elapsed: number;
};

const randomBetween = (min: number, max: number) => Math.random() * (max - min) + min;

function createStars() {
  return Array.from({ length: 132 }, () => ({
    x: randomBetween(0, WORLD_WIDTH),
    y: randomBetween(0, WORLD_HEIGHT),
    size: randomBetween(0.45, 1.85),
    flicker: randomBetween(0, Math.PI * 2),
    depth: randomBetween(0.35, 1),
  }));
}

function createGame(): Game {
  return {
    ship: { x: WORLD_WIDTH / 2, y: WORLD_HEIGHT - 112, vx: 0, vy: 0, angle: -Math.PI / 2, invulnerable: 0 },
    cores: [],
    rocks: [],
    particles: [],
    score: 0,
    combo: 0,
    comboClock: 0,
    hull: 3,
    elapsed: 0,
    rockClock: 0.75,
    coreClock: 1.1,
  };
}

function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  const remaining = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${remaining}`;
}

function LineIcon({ name, className = "" }: { name: "pause" | "play" | "restart" | "sound"; className?: string }) {
  if (name === "pause") {
    return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M8 5v14M16 5v14" strokeLinecap="round" /></svg>;
  }
  if (name === "play") {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="m8 5 11 7-11 7V5Z" /></svg>;
  }
  if (name === "restart") {
    return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M20 11a8 8 0 1 0 2 5.3" strokeLinecap="round" /><path d="M20 4v7h-7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M5 10v4h4l5 4V6l-5 4H5Z" strokeLinecap="round" strokeLinejoin="round" /><path d="m18 10 3 4m0-4-3 4" strokeLinecap="round" /></svg>;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const screenRef = useRef<Screen>("ready");
  const gameRef = useRef<Game>(createGame());
  const starsRef = useRef<Star[]>(createStars());
  const keysRef = useRef(new Set<string>());
  const pointerRef = useRef<{ x: number; y: number } | null>(null);
  const lastHudUpdate = useRef(0);
  const [screen, setScreen] = useState<Screen>("ready");
  const [hud, setHud] = useState<Hud>({ score: 0, combo: 0, hull: 3, elapsed: 0 });
  const [highScore, setHighScore] = useState(() => {
    try {
      return Number(window.localStorage.getItem("starward-high-score")) || 0;
    } catch {
      return 0;
    }
  });

  const updateScreen = (nextScreen: Screen) => {
    screenRef.current = nextScreen;
    setScreen(nextScreen);
  };

  const publishHud = (force = false) => {
    const now = performance.now();
    if (!force && now - lastHudUpdate.current < 90) return;
    lastHudUpdate.current = now;
    const game = gameRef.current;
    setHud({ score: Math.round(game.score), combo: game.combo, hull: game.hull, elapsed: game.elapsed });
  };

  const startGame = () => {
    gameRef.current = createGame();
    pointerRef.current = null;
    publishHud(true);
    updateScreen("playing");
  };

  const pauseGame = () => {
    if (screenRef.current === "playing") updateScreen("paused");
    if (screenRef.current === "paused") updateScreen("playing");
  };

  const finishGame = () => {
    const score = Math.round(gameRef.current.score);
    if (score > highScore) {
      setHighScore(score);
      try {
        window.localStorage.setItem("starward-high-score", String(score));
      } catch {
        // The game remains playable when storage is disabled.
      }
    }
    publishHud(true);
    updateScreen("gameover");
  };

  const addBurst = (x: number, y: number, color: string, amount: number, force = 1) => {
    const particles = gameRef.current.particles;
    for (let i = 0; i < amount; i += 1) {
      const angle = randomBetween(0, Math.PI * 2);
      const speed = randomBetween(44, 160) * force;
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: randomBetween(0.3, 0.78),
        maxLife: 0.78,
        size: randomBetween(1.2, 3.8),
        color,
      });
    }
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", "w", "a", "s", "d", " "].includes(key)) {
        event.preventDefault();
      }
      keysRef.current.add(key);
      if (key === "p" || key === "escape") {
        if (screenRef.current === "playing" || screenRef.current === "paused") pauseGame();
      }
      if (key === "enter" && (screenRef.current === "ready" || screenRef.current === "gameover")) startGame();
    };
    const onKeyUp = (event: KeyboardEvent) => keysRef.current.delete(event.key.toLowerCase());
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    let frameId = 0;
    let lastFrame = performance.now();
    let dpr = 1;

    const resizeCanvas = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = WORLD_WIDTH * dpr;
      canvas.height = WORLD_HEIGHT * dpr;
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const spawnRock = (game: Game) => {
      const radius = randomBetween(16, 34);
      const points = Array.from({ length: 9 }, () => randomBetween(0.72, 1.18));
      game.rocks.push({
        x: randomBetween(48, WORLD_WIDTH - 48),
        y: -radius - 24,
        radius,
        vx: randomBetween(-30, 30),
        vy: 105 + Math.min(game.elapsed * 2.7, 108) + radius * 0.55,
        rotation: randomBetween(0, Math.PI * 2),
        spin: randomBetween(-1.65, 1.65),
        points,
      });
    };

    const spawnCore = (game: Game) => {
      game.cores.push({
        x: randomBetween(70, WORLD_WIDTH - 70),
        y: -28,
        radius: randomBetween(9, 12),
        vy: 96 + Math.min(game.elapsed * 1.45, 74),
        phase: randomBetween(0, Math.PI * 2),
      });
    };

    const tick = (dt: number) => {
      const game = gameRef.current;
      const ship = game.ship;
      game.elapsed += dt;
      game.comboClock -= dt;
      if (game.comboClock <= 0) game.combo = 0;
      ship.invulnerable = Math.max(0, ship.invulnerable - dt);

      let ax = 0;
      let ay = 0;
      const keys = keysRef.current;
      if (keys.has("arrowleft") || keys.has("a")) ax -= 820;
      if (keys.has("arrowright") || keys.has("d")) ax += 820;
      if (keys.has("arrowup") || keys.has("w")) ay -= 820;
      if (keys.has("arrowdown") || keys.has("s")) ay += 820;

      const pointer = pointerRef.current;
      if (pointer) {
        ax += (pointer.x - ship.x) * 5.5;
        ay += (pointer.y - ship.y) * 5.5;
      }

      ship.vx += ax * dt;
      ship.vy += ay * dt;
      const speed = Math.hypot(ship.vx, ship.vy);
      const maxSpeed = pointer ? 460 : 360;
      if (speed > maxSpeed) {
        ship.vx = (ship.vx / speed) * maxSpeed;
        ship.vy = (ship.vy / speed) * maxSpeed;
      }
      ship.vx *= Math.pow(0.0009, dt);
      ship.vy *= Math.pow(0.0009, dt);
      ship.x = Math.max(34, Math.min(WORLD_WIDTH - 34, ship.x + ship.vx * dt));
      ship.y = Math.max(48, Math.min(WORLD_HEIGHT - 34, ship.y + ship.vy * dt));
      if (speed > 12) ship.angle = Math.atan2(ship.vy, ship.vx) + Math.PI / 2;

      game.rockClock -= dt;
      if (game.rockClock <= 0) {
        spawnRock(game);
        game.rockClock = Math.max(0.34, randomBetween(0.6, 1.02) - game.elapsed * 0.0075);
      }
      game.coreClock -= dt;
      if (game.coreClock <= 0) {
        spawnCore(game);
        game.coreClock = randomBetween(0.72, 1.32);
      }

      game.rocks.forEach((rock) => {
        rock.x += rock.vx * dt;
        rock.y += rock.vy * dt;
        rock.rotation += rock.spin * dt;
      });
      game.cores.forEach((core) => {
        core.y += core.vy * dt;
        core.x += Math.sin(game.elapsed * 2.5 + core.phase) * 22 * dt;
      });
      game.particles.forEach((particle) => {
        particle.x += particle.vx * dt;
        particle.y += particle.vy * dt;
        particle.vx *= Math.pow(0.025, dt);
        particle.vy *= Math.pow(0.025, dt);
        particle.life -= dt;
      });

      game.cores = game.cores.filter((core) => {
        const distance = Math.hypot(core.x - ship.x, core.y - ship.y);
        if (distance < core.radius + 23) {
          game.combo = Math.min(game.combo + 1, 7);
          game.comboClock = 2.3;
          game.score += 12 * game.combo;
          addBurst(core.x, core.y, "#6fffe9", 13, 0.8);
          return false;
        }
        return core.y < WORLD_HEIGHT + 45;
      });

      game.rocks = game.rocks.filter((rock) => {
        const distance = Math.hypot(rock.x - ship.x, rock.y - ship.y);
        if (ship.invulnerable <= 0 && distance < rock.radius + 19) {
          ship.invulnerable = 1.25;
          game.hull -= 1;
          game.combo = 0;
          addBurst(ship.x, ship.y, "#ffad7a", 32, 1.75);
          if (game.hull <= 0) finishGame();
          return false;
        }
        return rock.y < WORLD_HEIGHT + rock.radius + 35 && rock.x > -80 && rock.x < WORLD_WIDTH + 80;
      });
      game.particles = game.particles.filter((particle) => particle.life > 0);
      publishHud();
    };

    const drawShip = (game: Game, time: number) => {
      const { ship } = game;
      const flicker = 9 + Math.sin(time * 0.022) * 4 + Math.min(Math.hypot(ship.vx, ship.vy) / 25, 13);
      context.save();
      context.translate(ship.x, ship.y);
      context.rotate(ship.angle);
      if (ship.invulnerable > 0 && Math.floor(time / 95) % 2 === 0) context.globalAlpha = 0.35;

      const flame = context.createLinearGradient(0, 19, 0, 19 + flicker);
      flame.addColorStop(0, "#fff5bd");
      flame.addColorStop(0.45, "#5df4de");
      flame.addColorStop(1, "rgba(93,244,222,0)");
      context.fillStyle = flame;
      context.beginPath();
      context.moveTo(-7, 18);
      context.lineTo(0, 19 + flicker);
      context.lineTo(7, 18);
      context.closePath();
      context.fill();

      context.shadowColor = "#73ffe8";
      context.shadowBlur = 18;
      context.fillStyle = "#d8fff6";
      context.beginPath();
      context.moveTo(0, -25);
      context.lineTo(17, 17);
      context.lineTo(5, 13);
      context.lineTo(0, 20);
      context.lineTo(-5, 13);
      context.lineTo(-17, 17);
      context.closePath();
      context.fill();
      context.shadowBlur = 0;
      context.fillStyle = "#112c42";
      context.beginPath();
      context.moveTo(0, -17);
      context.lineTo(6, 5);
      context.lineTo(0, 10);
      context.lineTo(-6, 5);
      context.closePath();
      context.fill();
      context.strokeStyle = "#75f8e2";
      context.lineWidth = 1.2;
      context.stroke();
      context.restore();
    };

    const draw = (time: number) => {
      const game = gameRef.current;
      context.clearRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
      const space = context.createLinearGradient(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
      space.addColorStop(0, "#071326");
      space.addColorStop(0.52, "#050b17");
      space.addColorStop(1, "#10091d");
      context.fillStyle = space;
      context.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

      const haze = context.createRadialGradient(WORLD_WIDTH * 0.78, WORLD_HEIGHT * 0.04, 0, WORLD_WIDTH * 0.78, WORLD_HEIGHT * 0.04, 480);
      haze.addColorStop(0, "rgba(103, 57, 195, .22)");
      haze.addColorStop(0.48, "rgba(23, 118, 165, .075)");
      haze.addColorStop(1, "rgba(2, 7, 17, 0)");
      context.fillStyle = haze;
      context.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

      starsRef.current.forEach((star) => {
        const glow = 0.52 + Math.sin(time * 0.0018 * star.depth + star.flicker) * 0.32;
        context.fillStyle = `rgba(201, 236, 255, ${glow})`;
        context.fillRect(star.x, star.y, star.size, star.size);
      });

      context.strokeStyle = "rgba(110, 199, 230, .065)";
      context.lineWidth = 1;
      for (let y = 74; y < WORLD_HEIGHT; y += 74) {
        context.beginPath();
        context.moveTo(0, y + Math.sin(time * 0.0007 + y) * 4);
        context.lineTo(WORLD_WIDTH, y + Math.sin(time * 0.0007 + y) * 4);
        context.stroke();
      }

      game.cores.forEach((core) => {
        const pulse = 1 + Math.sin(time * 0.005 + core.phase) * 0.14;
        context.save();
        context.translate(core.x, core.y);
        context.rotate(Math.PI / 4 + time * 0.0009);
        context.shadowColor = "#61ffe3";
        context.shadowBlur = 22;
        context.fillStyle = "#a1fff0";
        context.fillRect(-core.radius * pulse, -core.radius * pulse, core.radius * 2 * pulse, core.radius * 2 * pulse);
        context.shadowBlur = 0;
        context.fillStyle = "#eafffb";
        context.fillRect(-core.radius * 0.4, -core.radius * 0.4, core.radius * 0.8, core.radius * 0.8);
        context.restore();
      });

      game.rocks.forEach((rock) => {
        context.save();
        context.translate(rock.x, rock.y);
        context.rotate(rock.rotation);
        context.beginPath();
        rock.points.forEach((point, index) => {
          const angle = (Math.PI * 2 * index) / rock.points.length;
          const radius = rock.radius * point;
          const x = Math.cos(angle) * radius;
          const y = Math.sin(angle) * radius;
          if (index === 0) context.moveTo(x, y);
          else context.lineTo(x, y);
        });
        context.closePath();
        const rockGradient = context.createLinearGradient(-rock.radius, -rock.radius, rock.radius, rock.radius);
        rockGradient.addColorStop(0, "#7d87a9");
        rockGradient.addColorStop(0.55, "#434967");
        rockGradient.addColorStop(1, "#202640");
        context.fillStyle = rockGradient;
        context.fill();
        context.strokeStyle = "rgba(178, 205, 255, .32)";
        context.lineWidth = 1.1;
        context.stroke();
        context.restore();
      });

      game.particles.forEach((particle) => {
        const alpha = Math.max(0, particle.life / particle.maxLife);
        context.globalAlpha = alpha;
        context.fillStyle = particle.color;
        context.fillRect(particle.x - particle.size / 2, particle.y - particle.size / 2, particle.size, particle.size);
      });
      context.globalAlpha = 1;
      drawShip(game, time);

      const vignette = context.createRadialGradient(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_HEIGHT * 0.14, WORLD_WIDTH / 2, WORLD_HEIGHT / 2, WORLD_WIDTH * 0.7);
      vignette.addColorStop(0.6, "rgba(0,0,0,0)");
      vignette.addColorStop(1, "rgba(0,0,0,.42)");
      context.fillStyle = vignette;
      context.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    };

    const frame = (time: number) => {
      const dt = Math.min((time - lastFrame) / 1000, 0.035);
      lastFrame = time;
      if (screenRef.current === "playing") tick(dt);
      draw(time);
      frameId = requestAnimationFrame(frame);
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);
    frameId = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", resizeCanvas);
    };
  }, [highScore]);

  const setPointerPosition = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (screenRef.current !== "playing") return;
    const bounds = event.currentTarget.getBoundingClientRect();
    pointerRef.current = {
      x: ((event.clientX - bounds.left) / bounds.width) * WORLD_WIDTH,
      y: ((event.clientY - bounds.top) / bounds.height) * WORLD_HEIGHT,
    };
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#040814] px-4 py-4 text-slate-100 sm:px-7 sm:py-6">
      <div className="mx-auto flex w-full max-w-[1180px] items-center justify-between border-b border-white/10 pb-4 sm:pb-5">
        <div className="flex items-center gap-3">
          <div className="grid h-8 w-8 place-items-center border border-cyan-200/50 bg-cyan-200/10 text-[11px] font-black tracking-tighter text-cyan-100 shadow-[0_0_22px_rgba(91,243,224,.22)]">S</div>
          <div>
            <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-cyan-200/65">Lumen Field</p>
            <h1 className="font-display text-xl font-semibold uppercase leading-none tracking-[0.17em] text-white sm:text-2xl">Starward</h1>
          </div>
        </div>
        <div className="hidden items-center gap-7 font-mono text-[10px] uppercase tracking-[0.2em] text-slate-400 sm:flex">
          <span>Collect light</span>
          <span className="text-slate-600">/</span>
          <span>Outrun stone</span>
        </div>
        <div aria-label="Sound muted" title="Sound muted" className="grid h-9 w-9 place-items-center border border-white/10 text-slate-400">
          <LineIcon name="sound" className="h-4 w-4" />
        </div>
      </div>

      <section className="mx-auto mt-5 w-full" style={{ width: "min(1180px, 100%, calc((100vh - 156px) * 1.5625))" }}>
        <div className="relative aspect-[25/16] overflow-hidden border border-cyan-100/15 bg-[#071020] shadow-[0_28px_90px_rgba(0,0,0,.48)]">
          <canvas
            ref={canvasRef}
            aria-label="Starward game field. Use arrow keys, WASD, or drag to steer the ship."
            className="h-full w-full touch-none"
            onPointerDown={(event) => {
              event.currentTarget.setPointerCapture(event.pointerId);
              setPointerPosition(event);
            }}
            onPointerMove={(event) => {
              if (pointerRef.current) setPointerPosition(event);
            }}
            onPointerUp={() => { pointerRef.current = null; }}
            onPointerCancel={() => { pointerRef.current = null; }}
          />

          <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-4 sm:p-5">
            <div>
              <p className="font-mono text-[8px] uppercase tracking-[0.28em] text-cyan-100/60">Run score</p>
              <p className="mt-1 font-mono text-2xl font-semibold tracking-tight text-white sm:text-3xl">{hud.score.toString().padStart(5, "0")}</p>
              {hud.combo > 1 && <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-cyan-200">x{hud.combo} light chain</p>}
            </div>
            <div className="flex items-start gap-3 sm:gap-5">
              <div className="text-right">
                <p className="font-mono text-[8px] uppercase tracking-[0.24em] text-slate-400">Hull</p>
                <div className="mt-2 flex justify-end gap-1">
                  {[0, 1, 2].map((segment) => <span key={segment} className={`h-1 w-5 sm:w-7 ${segment < hud.hull ? "bg-cyan-200 shadow-[0_0_9px_rgba(103,255,230,.7)]" : "bg-white/15"}`} />)}
                </div>
              </div>
              <div className="text-right">
                <p className="font-mono text-[8px] uppercase tracking-[0.24em] text-slate-400">Drift</p>
                <p className="mt-1 font-mono text-sm text-slate-200">{formatTime(hud.elapsed)}</p>
              </div>
            </div>
          </div>

          {screen === "playing" && (
            <button onClick={pauseGame} className="absolute bottom-4 right-4 grid h-9 w-9 place-items-center border border-white/15 bg-[#071020]/50 text-slate-300 backdrop-blur transition hover:border-cyan-200/50 hover:text-white sm:bottom-5 sm:right-5" aria-label="Pause game">
              <LineIcon name="pause" className="h-4 w-4" />
            </button>
          )}

          {screen !== "playing" && (
            <div className="absolute inset-0 grid place-items-center bg-[#030711]/35 px-5 text-center backdrop-blur-[2px]">
              {screen === "ready" && (
                <div className="animate-rise">
                  <p className="font-mono text-[10px] uppercase tracking-[0.38em] text-cyan-200">Light is moving</p>
                  <h2 className="mt-3 font-display text-4xl font-semibold uppercase tracking-[0.09em] text-white sm:text-6xl">Enter the field</h2>
                  <p className="mx-auto mt-4 max-w-sm text-sm leading-6 text-slate-300 sm:text-base">Gather Lumen cores, steer clear of the falling stone, and make your longest drift.</p>
                  <button onClick={startGame} className="group mt-7 inline-flex items-center gap-3 bg-cyan-200 px-5 py-3 font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-[#071523] transition hover:bg-white">
                    <LineIcon name="play" className="h-4 w-4 transition group-hover:translate-x-0.5" />
                    Start run
                  </button>
                  <p className="mt-4 font-mono text-[9px] uppercase tracking-[0.18em] text-slate-400">Arrows / WASD / drag to steer</p>
                </div>
              )}
              {screen === "paused" && (
                <div className="animate-rise">
                  <p className="font-mono text-[10px] uppercase tracking-[0.38em] text-cyan-200">Signal held</p>
                  <h2 className="mt-3 font-display text-5xl font-semibold uppercase tracking-[0.12em] text-white">Paused</h2>
                  <button onClick={pauseGame} className="group mt-7 inline-flex items-center gap-3 bg-cyan-200 px-5 py-3 font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-[#071523] transition hover:bg-white">
                    <LineIcon name="play" className="h-4 w-4" />
                    Resume run
                  </button>
                  <p className="mt-4 font-mono text-[9px] uppercase tracking-[0.18em] text-slate-400">Press P or Escape to continue</p>
                </div>
              )}
              {screen === "gameover" && (
                <div className="animate-rise">
                  <p className="font-mono text-[10px] uppercase tracking-[0.38em] text-[#ffb18a]">Hull depleted</p>
                  <h2 className="mt-3 font-display text-5xl font-semibold uppercase tracking-[0.1em] text-white">Drift complete</h2>
                  <p className="mt-4 font-mono text-sm uppercase tracking-[0.17em] text-slate-300">{hud.score.toString().padStart(5, "0")} lumen secured</p>
                  <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.15em] text-cyan-200/70">Best signal: {highScore.toString().padStart(5, "0")}</p>
                  <button onClick={startGame} className="group mt-7 inline-flex items-center gap-3 bg-cyan-200 px-5 py-3 font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-[#071523] transition hover:bg-white">
                    <LineIcon name="restart" className="h-4 w-4 transition group-hover:-rotate-45" />
                    Fly again
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-3 flex items-center justify-between font-mono text-[9px] uppercase tracking-[0.16em] text-slate-500">
          <p>Core: +12. Chain them before the signal fades.</p>
          <p className="hidden sm:block">Press P to pause</p>
        </div>
      </section>
    </main>
  );
}