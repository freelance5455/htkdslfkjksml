import React, { useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Logo } from './components/Logo.js';
import { LandingPage } from './pages/LandingPage.js';
import {
  LoginPage,
  SignUpPage,
  VerifyEmailPage,
  ForgotPasswordPage,
  ResetPasswordPage,
} from './pages/AuthPages.js';
import { ChatDashboard } from './pages/ChatDashboard.js';
import {
  ProfilePage,
  EditProfilePage,
  VoiceSettingsPage,
  PersonalizationSettingsPage,
  AppearanceSettingsPage,
  AISettingsPage,
  NotificationsSettingsPage,
  PrivacySecurityPage,
  ChangePasswordPage,
} from './pages/SettingsPages.js';
import { AboutPage, HelpSupportPage, NotFoundPage } from './pages/HelpAndAboutPages.js';
import { AdminPanelPage } from './pages/AdminPanel.js';
import { Loader2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, loading, currentPage, setCurrentPage } = useAuth();

  // Initial routing decision when loading completes
  useEffect(() => {
    if (!loading && currentPage === 'splash') {
      if (user) {
        setCurrentPage('chat');
      } else {
        setCurrentPage('landing');
      }
    }
  }, [loading, currentPage, user]);

  // If loading or splash screen
  if (loading || currentPage === 'splash') {
    return (
      <div className="min-h-screen w-screen flex flex-col items-center justify-between p-6 bg-slate-950 text-white select-none">
        <div />
        <div className="flex flex-col items-center text-center space-y-6 animate-in fade-in zoom-in-95 duration-500">
          <div className="relative">
            <Logo size="xl" showText={false} />
            <div className="absolute -inset-4 bg-indigo-500/20 rounded-full blur-xl animate-pulse pointer-events-none" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              AI Pocket Chat
            </h1>
            <p className="text-xs text-slate-400 font-medium tracking-wide">
              Your Smart AI Assistant, Anywhere.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-indigo-400 font-semibold pt-2">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
            <span>Initializing secure session...</span>
          </div>
        </div>

        <div className="text-center space-y-1">
          <p className="text-xs font-semibold text-slate-300">
            OWNER NAME: Ali ABDULLAH
          </p>
          <p className="text-[10px] text-slate-500">
            © 2026 AI Pocket Chat • All Rights Reserved.
          </p>
        </div>
      </div>
    );
  }

  // Page Routing
  switch (currentPage) {
    case 'landing':
      return <LandingPage />;

    case 'login':
      return <LoginPage />;

    case 'signup':
      return <SignUpPage />;

    case 'verify-email':
      return <VerifyEmailPage />;

    case 'forgot-password':
      return <ForgotPasswordPage />;

    case 'reset-password':
      return <ResetPasswordPage />;

    case 'chat':
      // Guard: if user is not logged in, take to login
      if (!user) {
        return <LoginPage />;
      }
      return <ChatDashboard />;

    case 'profile':
      if (!user) return <LoginPage />;
      return <ProfilePage />;

    case 'edit-profile':
      if (!user) return <LoginPage />;
      return <EditProfilePage />;

    case 'voice-settings':
      if (!user) return <LoginPage />;
      return <VoiceSettingsPage />;

    case 'personalization-settings':
      if (!user) return <LoginPage />;
      return <PersonalizationSettingsPage />;

    case 'appearance-settings':
      if (!user) return <LoginPage />;
      return <AppearanceSettingsPage />;

    case 'ai-settings':
      if (!user) return <LoginPage />;
      return <AISettingsPage />;

    case 'notifications-settings':
      if (!user) return <LoginPage />;
      return <NotificationsSettingsPage />;

    case 'privacy-security':
      if (!user) return <LoginPage />;
      return <PrivacySecurityPage />;

    case 'change-password':
      if (!user) return <LoginPage />;
      return <ChangePasswordPage />;

    case 'about':
      return <AboutPage />;

    case 'help-support':
      return <HelpSupportPage />;

    case 'admin':
      return <AdminPanelPage />;

    default:
      return <NotFoundPage />;
  }
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
