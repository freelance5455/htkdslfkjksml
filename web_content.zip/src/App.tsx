import { useEffect, useRef } from "react";
import Phaser from "phaser";
import { GameScene } from "./game/GameScene";
import { GAME_H, GAME_W, IS_LOW_END } from "./game/constants";

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);

  useEffect(() => {
    if (!containerRef.current || gameRef.current) return;

    const game = new Phaser.Game({
      type: Phaser.AUTO, // WebGL с фолбэком на Canvas для старых Android
      parent: containerRef.current,
      backgroundColor: "#121a33",
      width: GAME_W,
      height: GAME_H,
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
      render: {
        antialias: !IS_LOW_END,
        antialiasGL: !IS_LOW_END,
        powerPreference: "high-performance",
        roundPixels: false,
        pixelArt: false,
      },
      fps: {
        smoothStep: true,
      },
      disableContextMenu: true,
      scene: [GameScene],
    });
    gameRef.current = game;

    // пауза рендера, когда вкладка/приложение свёрнуты — экономия батареи
    const onVisibility = () => {
      if (document.hidden) {
        game.loop.sleep();
      } else {
        game.loop.wake();
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      game.destroy(true);
      gameRef.current = null;
    };
  }, []);

  return (
    <div
      id="game-container"
      ref={containerRef}
      style={{
        width: "100%",
        height: "100%",
        background: "#121a33",
        overflow: "hidden",
      }}
    />
  );
}
