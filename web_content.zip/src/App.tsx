/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { VideoProvider, useVideo } from './context/VideoContext';
import { Navbar } from './components/Navbar';
import { BillboardHero } from './components/BillboardHero';
import { VideoRow } from './components/VideoRow';
import { Top10Row } from './components/Top10Row';
import { VideoCard } from './components/VideoCard';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { VideoDetailModal } from './components/VideoDetailModal';
import { UploadModal } from './components/UploadModal';
import { Footer } from './components/Footer';
import { ProfileSelectionScreen } from './components/ProfileSelectionScreen';
import { YouTubeWatchView } from './components/YouTubeWatchView';
import { AuthModal } from './components/AuthModal';
import {
  Upload,
  Film,
  Sparkles,
  Bookmark,
  CheckCircle,
  HardDrive,
  Search,
  Shield,
} from 'lucide-react';

const MainContent: React.FC = () => {
  const {
    videos,
    filteredVideos,
    isLoading,
    searchQuery,
    setSearchQuery,
    activeTab,
    myList,
    watchHistory,
    currentProfile,
    isSelectingProfile,
    setIsUploadModalOpen,
    youtubeVideo,
    setYoutubeVideo,
    isAuthModalOpen,
    setIsAuthModalOpen,
    setActiveVideo,
    language,
  } = useVideo();

  // If user is watching in YouTube View, render the YouTube Watch Stage!
  if (youtubeVideo) {
    return (
      <YouTubeWatchView
        video={youtubeVideo}
        onClose={() => setYoutubeVideo(null)}
        onOpenNetflixPlayer={(v) => {
          setYoutubeVideo(null);
          setActiveVideo(v);
        }}
      />
    );
  }

  // If user is choosing profile, show the Netflix Profile Selection Screen!
  if (isSelectingProfile || !currentProfile) {
    return <ProfileSelectionScreen />;
  }

  // Create lookup for watch history
  const progressMap = watchHistory.reduce<Record<string, { currentTime: number; duration: number }>>(
    (acc, curr) => {
      acc[curr.videoId] = { currentTime: curr.currentTime, duration: curr.duration };
      return acc;
    },
    {}
  );

  // Use filteredVideos (respects Kids profile restrictions)
  const displayVideos = filteredVideos;

  // Group videos for rows with deduplication
  const continueWatchingVideos = Array.from(
    new Map(
      watchHistory
        .map((h) => displayVideos.find((v) => v.id === h.videoId))
        .filter((v): v is (typeof displayVideos)[0] => Boolean(v))
        .map((v) => [v.id, v])
    ).values()
  );

  const uploadedVideos = displayVideos.filter((v) => v.isUploaded);
  const trendingVideos = displayVideos.filter((v) => v.matchScore >= 95);
  const actionVideos = displayVideos.filter((v) => v.category === 'action' || v.tags.includes('Action'));
  const scifiVideos = displayVideos.filter((v) => v.category === 'scifi' || v.tags.includes('Sci-Fi'));
  const actionAndScifiVideos = Array.from(
    new Map([...scifiVideos, ...actionVideos].map((v) => [v.id, v])).values()
  );
  const comedyVideos = displayVideos.filter((v) => v.category === 'comedy');
  const documentaryVideos = displayVideos.filter((v) => v.category === 'documentary');
  const seriesVideos = displayVideos.filter((v) => v.category === 'series');
  const moviesVideos = displayVideos.filter((v) => v.category !== 'series');
  const myListVideos = displayVideos.filter((v) => myList.includes(v.id));

  // Search Results
  const searchResults = searchQuery
    ? displayVideos.filter(
        (v) =>
          v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (v.cast && v.cast.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase())))
      )
    : [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#141414] flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 border-4 border-[#E50914] border-t-transparent rounded-full animate-spin" />
        <p className="text-white font-extrabold tracking-widest text-lg animate-pulse uppercase">
          CINESTREAM
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white flex flex-col selection:bg-red-600 selection:text-white">
      {/* Navigation Header */}
      <Navbar />

      {/* Main Body */}
      <main className="flex-1">
        {/* Search Results Mode */}
        {searchQuery ? (
          <div className="pt-24 sm:pt-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl sm:text-3xl font-extrabold">
                  {language === 'ur' ? 'تلاش کے نتائج:' : 'Search Results for:'}{' '}
                  <span className="text-red-500 font-bold">"{searchQuery}"</span>
                </h2>
                <p className="text-zinc-400 text-xs sm:text-sm mt-1">
                  Found {searchResults.length} matching titles
                </p>
              </div>
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-zinc-400 hover:text-white underline cursor-pointer"
              >
                Clear Search
              </button>
            </div>

            {searchResults.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {searchResults.map((video) => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 space-y-4">
                <Search className="w-12 h-12 text-zinc-600 mx-auto" />
                <h3 className="text-xl font-bold text-zinc-300">No matches found</h3>
                <p className="text-zinc-500 text-sm max-w-md mx-auto">
                  Try searching for titles like "Tears of Steel", "Sintel", "Bunny", or genres like "Action", "Sci-Fi".
                </p>
              </div>
            )}
          </div>
        ) : activeTab === 'uploaded' ? (
          /* Community Uploads Dedicated Tab */
          <div className="pt-24 sm:pt-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/60 p-6 rounded-lg border border-white/5">
              <div className="space-y-1">
                <h2 className="text-2xl sm:text-3xl font-black flex items-center space-x-2">
                  <HardDrive className="w-6 h-6 text-[#E50914]" />
                  <span>{language === 'ur' ? 'اپلوڈ شدہ ویڈیوز' : 'Community Uploads Hub'}</span>
                </h2>
                <p className="text-zinc-400 text-xs sm:text-sm">
                  {language === 'ur'
                    ? 'آپ کی اپلوڈ کردہ تمام ویڈیوز یہاں محفوظ ہیں اور براہ راست چلائی جا سکتی ہیں'
                    : 'All user-uploaded videos persisted in database with full HTTP 206 range seeking'}
                </p>
              </div>

              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="px-5 py-2.5 rounded bg-[#E50914] hover:bg-red-700 text-white font-bold text-sm flex items-center justify-center space-x-2 shadow-lg shadow-red-900/40 cursor-pointer self-start sm:self-auto"
              >
                <Upload className="w-4 h-4" />
                <span>{language === 'ur' ? 'نئی ویڈیو اپلوڈ کریں' : 'Upload New Video'}</span>
              </button>
            </div>

            {uploadedVideos.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {uploadedVideos.map((video) => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-zinc-900/30 rounded-lg border border-dashed border-zinc-700 p-8 space-y-4">
                <Film className="w-12 h-12 text-zinc-600 mx-auto" />
                <h3 className="text-lg font-bold text-zinc-300">
                  {language === 'ur' ? 'ابھی تک کوئی ویڈیو اپلوڈ نہیں ہوئی' : 'No user videos uploaded yet'}
                </h3>
                <p className="text-zinc-500 text-xs sm:text-sm max-w-sm mx-auto">
                  Click the upload button to add your own MP4 or WebM videos and watch them stream in Netflix style!
                </p>
                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="px-4 py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Upload First Video
                </button>
              </div>
            )}
          </div>
        ) : activeTab === 'my-list' ? (
          /* My List Dedicated Tab */
          <div className="pt-24 sm:pt-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black flex items-center space-x-2">
                <Bookmark className="w-6 h-6 text-emerald-400" />
                <span>{language === 'ur' ? 'میری لسٹ' : 'My Watchlist'}</span>
              </h2>
              <p className="text-zinc-400 text-xs sm:text-sm mt-1">
                {myListVideos.length} titles saved to {currentProfile.name}'s list
              </p>
            </div>

            {myListVideos.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {myListVideos.map((video) => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 space-y-3">
                <Bookmark className="w-12 h-12 text-zinc-600 mx-auto" />
                <h3 className="text-lg font-bold text-zinc-300">Your Watchlist is empty</h3>
                <p className="text-zinc-500 text-xs sm:text-sm">
                  Add movies and shows to your list by clicking the "+" button on any video.
                </p>
              </div>
            )}
          </div>
        ) : activeTab === 'movies' ? (
          /* Movies Filtered Tab */
          <>
            <BillboardHero featuredVideo={moviesVideos[0]} />
            <div className="relative -mt-16 sm:-mt-24 z-20 space-y-2">
              <VideoRow title="Action & Sci-Fi Blockbusters" videos={actionVideos} />
              <VideoRow title="Top Rated Movies" videos={moviesVideos} />
              <VideoRow title="Animated & Family" videos={comedyVideos} />
              <VideoRow title="Documentaries & Nature" videos={documentaryVideos} />
            </div>
          </>
        ) : activeTab === 'series' ? (
          /* Series Filtered Tab */
          <>
            <BillboardHero featuredVideo={seriesVideos[0] || videos[1]} />
            <div className="relative -mt-16 sm:-mt-24 z-20 space-y-2">
              <VideoRow title="Trending Series" videos={seriesVideos.length ? seriesVideos : videos} />
              <Top10Row title="Top 10 Series Today" videos={videos} />
              <VideoRow title="Documentary Series" videos={documentaryVideos} />
            </div>
          </>
        ) : (
          /* Home Tab - Full Netflix Experience */
          <>
            {/* Cinematic Billboard Hero */}
            <BillboardHero />

            {/* Overlapping Content Rows */}
            <div className="relative -mt-14 sm:-mt-24 lg:-mt-32 z-20 space-y-2 pb-12">
              {/* Continue Watching Row (if user has progress) */}
              {continueWatchingVideos.length > 0 && (
                <VideoRow
                  title={
                    language === 'ur'
                      ? `${currentProfile.name} کے لیے دیکھنا جاری رکھیں`
                      : `Continue Watching for ${currentProfile.name}`
                  }
                  videos={continueWatchingVideos}
                  progressMap={progressMap}
                />
              )}

              {/* Uploaded by Community Row (High Priority if user uploaded any) */}
              {uploadedVideos.length > 0 && (
                <VideoRow
                  title={
                    language === 'ur'
                      ? 'کمیونٹی کی اپلوڈ کردہ ویڈیوز'
                      : 'Uploaded by Community & You'
                  }
                  videos={uploadedVideos}
                />
              )}

              {/* Trending Now */}
              <VideoRow
                title={language === 'ur' ? 'اس وقت ٹرینڈنگ' : 'Trending Now'}
                videos={trendingVideos}
              />

              {/* Netflix Iconic Top 10 Today Row */}
              <Top10Row
                title={language === 'ur' ? 'آج کی ٹاپ 10 فلمیں اور شوز' : 'Top 10 Titles Today'}
                videos={displayVideos}
              />

              {/* Action & Sci-Fi Blockbusters */}
              <VideoRow
                title={language === 'ur' ? 'ایکشن اور سائنس فکشن' : 'Action & Sci-Fi Blockbusters'}
                videos={actionAndScifiVideos}
              />

              {/* Comedy & Animated Originals */}
              <VideoRow
                title={language === 'ur' ? 'اینیمیشن اور کامیڈی' : 'Animation & Comedy Originals'}
                videos={comedyVideos}
              />

              {/* Docuseries & Expeditions */}
              <VideoRow
                title={language === 'ur' ? 'دستاویزی فلمیں اور مہمات' : 'Documentaries & Expeditions'}
                videos={documentaryVideos}
              />

              {/* My List Row on Home */}
              {myListVideos.length > 0 && (
                <VideoRow
                  title={language === 'ur' ? 'میری لسٹ' : 'My List'}
                  videos={myListVideos}
                />
              )}
            </div>
          </>
        )}
      </main>

      {/* Video Player Modal (Fullscreen Playback) */}
      <VideoPlayerModal />

      {/* Video Detail Info Modal */}
      <VideoDetailModal />

      {/* Video Upload Studio Modal */}
      <UploadModal />

      {/* Authentication Login & Sign Up Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <VideoProvider>
      <MainContent />
    </VideoProvider>
  );
}
