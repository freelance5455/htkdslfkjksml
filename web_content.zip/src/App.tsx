import { useEffect, useRef, useState } from "react";
import { engine } from "./game/engine";
import { startAutosave, ui, useStore } from "./game/store";
import { Hud, Overlays } from "./ui/Hud";
import { Screens } from "./ui/Screens";

let autosaveOn = false;

export default function App() {
  const ref = useRef<HTMLCanvasElement>(null);
  const [err, setErr] = useState("");
  useStore();
  useEffect(() => {
    if (!ref.current) return;
    try {
      engine.start(ref.current);
      if (!autosaveOn) {
        autosaveOn = true;
        startAutosave();
      }
    } catch (e) {
      console.error(e);
      setErr(String((e as Error)?.message || e));
    }
  }, []);
  if (err)
    return (
      <div className="grid h-full place-items-center p-6 text-center">
        <div className="panel rounded-3xl p-6">
          <h1 className="head text-3xl" style={{ color: "var(--gold)" }}>3D graphics unavailable</h1>
          <p className="mt-2 text-sm" style={{ color: "var(--mut)" }}>Deep Dig needs WebGL. Please enable hardware acceleration or try another browser.</p>
          <p className="mt-2 text-xs opacity-60">{err}</p>
        </div>
      </div>
    );
  return (
    <>
      <canvas ref={ref} className="game" />
      {ui.screen !== "menu" && <Hud />}
      <Overlays />
      <Screens />
    </>
  );
}
