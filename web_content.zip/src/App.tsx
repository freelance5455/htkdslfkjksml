import { useCallback, useDeferredValue, useEffect, useMemo, useState } from 'react';
import Splash from './components/Splash';
import HadithCard from './components/HadithCard';
import { DB, Hadith, TierMode, getNorm, loadDB, matnOf, normalizeAr, passMasoom, passTier } from './data/db';

type View = { type: 'home' } | { type: 'topic'; topic: number } | { type: 'saved' };

const MASOOM_CHIPS: { id: number | null; label: string }[] = [
  { id: null, label: 'الكل' },
  { id: 0, label: 'النبي محمد ﷺ' },
  { id: 1, label: 'الإمام علي (ع)' },
  { id: 2, label: 'السيدة فاطمة (ع)' },
  { id: 3, label: 'الإمام الحسن (ع)' },
  { id: 4, label: 'الإمام الحسين (ع)' },
  { id: 5, label: 'الإمام السجاد (ع)' },
  { id: 6, label: 'الإمام الباقر (ع)' },
  { id: 7, label: 'الإمام الصادق (ع)' },
  { id: 8, label: 'الإمام الكاظم (ع)' },
  { id: 9, label: 'الإمام الرضا (ع)' },
  { id: 10, label: 'الإمام الجواد (ع)' },
  { id: 11, label: 'الإمام الهادي (ع)' },
  { id: 12, label: 'الإمام العسكري (ع)' },
  { id: 13, label: 'الإمام المهدي (عج)' },
  { id: 14, label: 'أبو الحسن (ع)' },
];

const TIER_OPTIONS: { id: TierMode; label: string }[] = [
  { id: 'sahih', label: 'صحيح' },
  { id: 'plus', label: 'صحيح وما في حكمه' },
  { id: 'all', label: 'كل المعتبر' },
];

const PAGE = 25;
const ls = {
  get<T>(k: string, d: T): T {
    try {
      const v = localStorage.getItem(k);
      return v ? (JSON.parse(v) as T) : d;
    } catch {
      return d;
    }
  },
  set(k: string, v: unknown) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch {
      /* ignore */
    }
  },
};

const fmt = (n: number) => n.toLocaleString('ar-EG');

export default function App() {
  const [db, setDb] = useState<DB | null>(null);
  const [error, setError] = useState('');
  const [splashVisible, setSplashVisible] = useState(true);
  const [splashFading, setSplashFading] = useState(false);

  const [view, setView] = useState<View>({ type: 'home' });
  const [query, setQuery] = useState('');
  const [masoom, setMasoom] = useState<number | null>(null);
  const [tier, setTier] = useState<TierMode>(() => ls.get<TierMode>('tier', 'sahih'));
  const [fontSize, setFontSize] = useState<number>(() => ls.get('fs', 22));
  const [saved, setSaved] = useState<string[]>(() => ls.get<string[]>('saved', []));
  const [showAbout, setShowAbout] = useState(false);
  const [limit, setLimit] = useState(PAGE);

  const deferredQuery = useDeferredValue(query);

  // Load the embedded database + keep splash for at least 2 seconds
  useEffect(() => {
    const t0 = Date.now();
    loadDB()
      .then((d) => {
        setDb(d);
        const wait = Math.max(0, 2000 - (Date.now() - t0));
        setTimeout(() => {
          setSplashFading(true);
          setTimeout(() => setSplashVisible(false), 700);
        }, wait);
      })
      .catch((e) => setError(String(e)));
  }, []);

  useEffect(() => ls.set('tier', tier), [tier]);
  useEffect(() => ls.set('fs', fontSize), [fontSize]);
  useEffect(() => ls.set('saved', saved), [saved]);

  useEffect(() => {
    const onPop = () => setView({ type: 'home' });
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const open = useCallback((v: View) => {
    history.pushState({}, '');
    setView(v);
    setLimit(PAGE);
    window.scrollTo({ top: 0 });
  }, []);
  const goHome = useCallback(() => {
    if (history.state !== null && (history.state as object) && Object.keys(history.state).length === 0) history.back();
    else setView({ type: 'home' });
  }, []);

  const toggleSave = useCallback((key: string) => {
    setSaved((s) => (s.includes(key) ? s.filter((k) => k !== key) : [...s, key]));
  }, []);

  // Hadiths allowed by the grade filter
  const byTier = useMemo(() => (db ? db.hadiths.filter((h) => passTier(h, tier)) : []), [db, tier]);
  const base = useMemo(() => byTier.filter((h) => passMasoom(h, masoom)), [byTier, masoom]);

  const topicCounts = useMemo(() => {
    const c = new Array(db?.meta.topics.length ?? 0).fill(0);
    for (const h of base) for (const t of h.topics) c[t]++;
    return c as number[];
  }, [base, db]);

  const masoomCounts = useMemo(() => {
    const m = new Map<number | null, number>();
    m.set(null, byTier.length);
    for (const h of byTier) {
      const ids = new Set<number>([h.speaker, ...h.quoted]);
      ids.forEach((i) => m.set(i, (m.get(i) ?? 0) + 1));
    }
    return m;
  }, [byTier]);

  const searching = deferredQuery.trim().length > 0 && view.type === 'home';

  const list: Hadith[] = useMemo(() => {
    if (!db) return [];
    if (view.type === 'saved') return db.hadiths.filter((h) => saved.includes(h.key));
    if (searching) {
      const terms = normalizeAr(deferredQuery.trim()).split(' ').filter(Boolean);
      return base.filter((h) => {
        const n = getNorm(h);
        return terms.every((t) => n.includes(t));
      });
    }
    if (view.type === 'topic') return base.filter((h) => h.topics.includes(view.topic));
    return [];
  }, [db, view, searching, deferredQuery, base, saved]);

  // Hadith of the day (short, clear, strictly sahih)
  const daily = useMemo(() => {
    if (!db) return null;
    const pool = db.hadiths.filter((h) => h.tier === 3 && h.split > 0 && matnOf(h).length > 50 && matnOf(h).length < 320);
    if (!pool.length) return null;
    const day = Math.floor(Date.now() / 86400000);
    return pool[(day * 7919) % pool.length];
  }, [db]);

  if (error) {
    return (
      <div dir="rtl" className="p-6 text-red-700">
        تعذر تحميل قاعدة الأحاديث: {error}
      </div>
    );
  }

  const topics = db?.meta.topics ?? [];
  const showList = view.type !== 'home' || searching;
  const title =
    view.type === 'saved' ? 'الأحاديث المحفوظة' : searching ? 'نتائج البحث' : view.type === 'topic' ? topics[view.topic]?.name : '';

  return (
    <div dir="rtl" className="min-h-screen pb-24 text-stone-900">
      {splashVisible && <Splash fading={splashFading} />}

      {db && (
        <>
          {/* ---------- Header ---------- */}
          <header className="sticky top-0 z-30 bg-gradient-to-b from-emerald-950 to-emerald-900 text-white shadow-lg">
            <div className="mx-auto max-w-3xl px-4 pt-3 pb-3">
              <div className="flex items-center gap-2">
                {view.type !== 'home' && (
                  <button onClick={goHome} className="rounded-full bg-white/10 w-9 h-9 text-lg active:bg-white/20" aria-label="رجوع">
                    ➜
                  </button>
                )}
                <div className="flex-1 min-w-0">
                  <h1 className="text-lg font-extrabold text-amber-300 truncate" style={{ fontFamily: '"Amiri","Noto Naskh Arabic",serif' }}>
                    {showList && !searching ? title : 'الأحاديث الصحيحة'}
                  </h1>
                  <p className="text-[11px] text-emerald-100/80 truncate">
                    {showList
                      ? `${fmt(list.length)} حديث`
                      : `${fmt(base.length)} حديث عن النبي ﷺ وأهل بيته (ع) • بدون إنترنت`}
                  </p>
                </div>
                {showList && (
                  <div className="flex items-center gap-1">
                    <button onClick={() => setFontSize((f) => Math.max(16, f - 2))} className="w-9 h-9 rounded-full bg-white/10 text-sm font-bold active:bg-white/20">
                      أ-
                    </button>
                    <button onClick={() => setFontSize((f) => Math.min(40, f + 2))} className="w-9 h-9 rounded-full bg-white/10 text-lg font-bold active:bg-white/20">
                      أ+
                    </button>
                  </div>
                )}
                <button onClick={() => setShowAbout(true)} className="w-9 h-9 rounded-full bg-white/10 text-base active:bg-white/20" aria-label="عن التطبيق">
                  ℹ
                </button>
              </div>

              {view.type !== 'saved' && (
                <div className="relative mt-3">
                  <input
                    value={query}
                    onChange={(e) => {
                      setQuery(e.target.value);
                      setLimit(PAGE);
                    }}
                    placeholder="ابحث في الأحاديث… (مثال: الصدقة، الجار، الصبر)"
                    className="w-full rounded-xl bg-white text-stone-900 placeholder-stone-400 px-4 py-2.5 text-[15px] outline-none focus:ring-2 focus:ring-amber-400"
                    enterKeyHint="search"
                  />
                  {query && (
                    <button
                      onClick={() => setQuery('')}
                      className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-stone-200 text-stone-600 text-sm"
                    >
                      ✕
                    </button>
                  )}
                </div>
              )}
            </div>
          </header>

          <main className="mx-auto max-w-3xl px-4 pt-4">
            {/* ---------- Filters ---------- */}
            {view.type !== 'saved' && (
              <section className="mb-4 space-y-3">
                <div>
                  <div className="text-xs font-bold text-stone-500 mb-1.5">درجة السند</div>
                  <div className="grid grid-cols-3 gap-1 rounded-xl bg-stone-200/70 p-1">
                    {TIER_OPTIONS.map((o) => (
                      <button
                        key={o.id}
                        onClick={() => {
                          setTier(o.id);
                          setLimit(PAGE);
                        }}
                        className={`rounded-lg py-2 text-[13px] font-bold transition ${
                          tier === o.id ? 'bg-emerald-800 text-white shadow' : 'text-stone-600'
                        }`}
                      >
                        {o.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-xs font-bold text-stone-500 mb-1.5">المعصوم</div>
                  <div className="flex gap-2 overflow-x-auto pb-1 -mx-4 px-4">
                    {MASOOM_CHIPS.map((c) => {
                      const cnt = masoomCounts.get(c.id) ?? 0;
                      const active = masoom === c.id;
                      return (
                        <button
                          key={String(c.id)}
                          onClick={() => {
                            setMasoom(c.id);
                            setLimit(PAGE);
                          }}
                          className={`shrink-0 rounded-full border px-3.5 py-1.5 text-[13px] font-bold transition ${
                            active
                              ? 'bg-amber-500 border-amber-500 text-white shadow'
                              : 'bg-white border-stone-300 text-stone-700'
                          }`}
                        >
                          {c.label} <span className={active ? 'text-white/80' : 'text-stone-400'}>{fmt(cnt)}</span>
                        </button>
                      );
                    })}
                  </div>
                  {masoom === 2 && (
                    <p className="text-[11px] text-stone-500 mt-1">يشمل ما ورد عن السيدة فاطمة (ع) وما ورد فيها.</p>
                  )}
                  {masoom === 13 && (
                    <p className="text-[11px] text-stone-500 mt-1">يشمل ما ورد عن الإمام المهدي (عج) وما ورد في القائم وغيبته.</p>
                  )}
                </div>
              </section>
            )}

            {/* ---------- Home ---------- */}
            {!showList && (
              <>
                {daily && (
                  <section className="mb-5">
                    <h2 className="text-sm font-extrabold text-emerald-900 mb-2">✦ حديث اليوم</h2>
                    <HadithCard h={daily} meta={db.meta} fontSize={fontSize} saved={saved.includes(daily.key)} onToggleSave={toggleSave} />
                  </section>
                )}

                <h2 className="text-base font-extrabold text-emerald-900 mb-3">اختر الموضوع</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {topics.map((t, i) => (
                    <button
                      key={t.id}
                      disabled={topicCounts[i] === 0}
                      onClick={() => open({ type: 'topic', topic: i })}
                      className="group rounded-2xl bg-white border border-emerald-900/10 shadow-sm p-3.5 text-right active:scale-[0.98] active:bg-emerald-50 transition disabled:opacity-40"
                    >
                      <div className="text-3xl mb-1.5">{t.icon}</div>
                      <div className="text-[14px] font-extrabold text-emerald-950 leading-snug min-h-[2.6em]">{t.name}</div>
                      <div className="mt-1 text-xs font-bold text-amber-700">{fmt(topicCounts[i])} حديث</div>
                    </button>
                  ))}
                </div>
              </>
            )}

            {/* ---------- List ---------- */}
            {showList && (
              <>
                {list.length === 0 ? (
                  <div className="text-center py-16 text-stone-500">
                    <div className="text-5xl mb-3">{view.type === 'saved' ? '☆' : '🔍'}</div>
                    {view.type === 'saved' ? 'لم تحفظ أي حديث بعد.' : 'لا توجد أحاديث مطابقة. جرّب تغيير الفلتر أو كلمة البحث.'}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {list.slice(0, limit).map((h) => (
                      <HadithCard
                        key={h.key}
                        h={h}
                        meta={db.meta}
                        fontSize={fontSize}
                        saved={saved.includes(h.key)}
                        onToggleSave={toggleSave}
                      />
                    ))}
                    {limit < list.length && (
                      <button
                        onClick={() => setLimit((l) => l + PAGE)}
                        className="w-full rounded-2xl bg-emerald-800 text-white py-3.5 font-extrabold active:bg-emerald-900"
                      >
                        عرض المزيد ({fmt(list.length - limit)} متبقٍ)
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </main>

          {/* ---------- Bottom bar ---------- */}
          <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/95 backdrop-blur border-t border-stone-200">
            <div className="mx-auto max-w-3xl grid grid-cols-2">
              <button
                onClick={() => {
                  setQuery('');
                  if (view.type !== 'home') goHome();
                }}
                className={`py-3 text-sm font-extrabold ${view.type !== 'saved' ? 'text-emerald-800' : 'text-stone-500'}`}
              >
                🏠 المواضيع
              </button>
              <button
                onClick={() => (view.type === 'saved' ? undefined : open({ type: 'saved' }))}
                className={`py-3 text-sm font-extrabold ${view.type === 'saved' ? 'text-emerald-800' : 'text-stone-500'}`}
              >
                ★ المحفوظات ({fmt(saved.length)})
              </button>
            </div>
          </nav>

          {showAbout && <About db={db} onClose={() => setShowAbout(false)} />}
        </>
      )}
    </div>
  );
}

function About({ db, onClose }: { db: DB; onClose: () => void }) {
  const c = [0, 0, 0, 0];
  db.hadiths.forEach((h) => c[h.tier]++);
  return (
    <div className="fixed inset-0 z-40 bg-black/60 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div
        className="bg-white w-full max-w-lg max-h-[85vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-extrabold text-emerald-900">عن التطبيق</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-stone-100">
            ✕
          </button>
        </div>
        <div className="space-y-3 text-[14px] leading-7 text-stone-700">
          <p>
            يضم التطبيق <b>{fmt(db.hadiths.length)}</b> حديثًا مخزّنة داخل التطبيق ويعمل بالكامل <b>بدون إنترنت</b>، مأخوذة من
            الكافي، ومن لا يحضره الفقيه، وتهذيب الأحكام، والخصال، وعيون أخبار الرضا (ع)، ومعجم الأحاديث المعتبرة.
          </p>
          <div className="rounded-xl bg-emerald-50 p-3">
            <div>✅ سند صحيح: <b>{fmt(c[3])}</b></div>
            <div>☑️ في حكم الصحيح (حسن كالصحيح / موثق كالصحيح): <b>{fmt(c[2])}</b></div>
            <div>📗 سند معتبر (حسن / موثق / معتبر): <b>{fmt(c[1])}</b></div>
          </div>
          <p>
            <b>درجة كل حديث</b> منقولة من تصنيف العلماء المذكور تحت كل حديث (المجلسي في «مرآة العقول»، الغفاري، النجفي، المحسني)،
            وهي لا تُخترع داخل التطبيق. بياناتها من مشروع «الثقلين» (thaqalayn.net).
          </p>
          <p>
            الافتراضي يعرض <b>«صحيح»</b> فقط. يمكنك التوسعة إلى «صحيح وما في حكمه» أو «كل المعتبر» من أزرار درجة السند.
          </p>
          <p>
            تصنيف المواضيع وتحديد المعصوم القائل يتمان آليًا من عنوان الباب ومن صيغة السند، وقد يخطئ أحيانًا؛ ويمكنك دائمًا فتح
            «السند» لمراجعته. للأحكام الشرعية يُرجع إلى المرجع المقلَّد.
          </p>
          <p className="text-stone-500 text-xs">لم يُدرج «نهج البلاغة» لأن نصوصه غير مسندة فلا تُصنَّف بدرجات السند.</p>
        </div>
      </div>
    </div>
  );
}
