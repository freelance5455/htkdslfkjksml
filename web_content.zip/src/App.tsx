import { useState } from 'react';
import type { Era } from './game/data';
import type { EndInfo } from './game/game';
import { MainScreen, FacScreen, HostScreen, JoinScreen, SettingsScreen, DevScreen, HowScreen, EndScreen, type StartParams } from './ui/Screens';
import { GameScreen } from './ui/GameScreen';

export default function App() {
  const [scr, setScr] = useState('main'); const [mode, setMode] = useState('ai'); const [era, setEra] = useState<Era>('anc');
  const [params, setParams] = useState<StartParams | null>(null); const [end, setEnd] = useState<EndInfo | null>(null); const [n, setN] = useState(0);
  const menu = () => { setParams(null); setEnd(null); setScr('main'); };
  const start = (p: StartParams) => { setParams(p); setN(x => x + 1); setScr('game'); };
  if (scr === 'game' && params) return <GameScreen key={n} params={params} onEnd={e => { setEnd(e); setScr('end'); }} onQuit={menu} />;
  if (scr === 'end' && end) return <EndScreen win={end.win} text={end.text} stats={end.stats} onMenu={menu} />;
  if (scr === 'fac') return <FacScreen era={era} onStart={start} onBack={() => setScr('main')} />;
  if (scr === 'host') return <HostScreen era={era} onStart={start} onBack={() => setScr('main')} />;
  if (scr === 'join') return <JoinScreen onStart={start} onBack={() => setScr('main')} />;
  if (scr === 'set') return <SettingsScreen onBack={() => setScr('main')} />;
  if (scr === 'dev') return <DevScreen onBack={() => setScr('main')} />;
  if (scr === 'how') return <HowScreen onBack={() => setScr('main')} />;
  return <MainScreen mode={mode} setMode={setMode} pickEra={e => { setEra(e); setScr(mode === 'host' ? 'host' : 'fac'); }} go={setScr} />;
}
