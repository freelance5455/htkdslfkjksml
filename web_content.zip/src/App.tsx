/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  FileText,
  UploadCloud,
  ArrowUp,
  ArrowDown,
  Trash2,
  Download,
  CheckCircle,
  Eye,
  Share2,
  FilePlus,
  Smartphone,
  Laptop,
  Tablet,
  X,
  Layers,
  Sparkles,
  Code,
  Check,
  AlertCircle,
  RotateCcw,
  ArrowDownAZ,
  ExternalLink,
} from 'lucide-react';
import { PdfFileItem, PhoneDeviceType } from './types';
import {
  formatFileSize,
  getPdfPageCount,
  mergePdfFiles,
  createSamplePdf,
} from './utils/pdfMerger';
import { generateStandaloneSingleHtml } from './utils/exportSingleHtml';

export default function App() {
  const [files, setFiles] = useState<PdfFileItem[]>([]);
  const [outputFileName, setOutputFileName] = useState<string>('ملف_مدمج_شامل');
  const [isMerging, setIsMerging] = useState<boolean>(false);
  const [mergeProgress, setMergeProgress] = useState<number>(0);
  const [progressStatus, setProgressStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Success result state
  const [mergedResult, setMergedResult] = useState<{
    blob: Blob;
    url: string;
    totalPages: number;
    fileName: string;
    size: number;
  } | null>(null);

  // Preview Modal
  const [previewItem, setPreviewItem] = useState<{ url: string; title: string } | null>(null);

  // Phone Screen Simulator view mode for previewing phone sizes
  const [deviceFrame, setDeviceFrame] = useState<PhoneDeviceType>('responsive');
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [showSingleHtmlCopied, setShowSingleHtmlCopied] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const addMoreInputRef = useRef<HTMLInputElement>(null);

  // Total statistics
  const totalPagesCount = files.reduce((acc, f) => acc + (f.pageCount || 0), 0);
  const totalSizeBytes = files.reduce((acc, f) => acc + f.size, 0);

  // Cleanup object URLs to avoid memory leaks
  useEffect(() => {
    return () => {
      files.forEach((f) => {
        if (f.previewUrl) URL.revokeObjectURL(f.previewUrl);
      });
      if (mergedResult?.url) {
        URL.revokeObjectURL(mergedResult.url);
      }
    };
  }, [files, mergedResult]);

  // Handle file uploads
  const handleFileSelect = async (selectedFiles: FileList | null) => {
    if (!selectedFiles || selectedFiles.length === 0) return;
    setErrorMessage(null);

    const newItems: PdfFileItem[] = [];
    const filesArray = Array.from(selectedFiles);

    for (const file of filesArray) {
      if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
        continue;
      }

      const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const previewUrl = URL.createObjectURL(file);

      newItems.push({
        id,
        file,
        name: file.name.replace(/\.[^/.]+$/, ''), // strip extension for cleaner display
        size: file.size,
        pageCount: 1, // temporary until read
        status: 'loading',
        previewUrl,
      });
    }

    if (newItems.length === 0) {
      setErrorMessage('يرجى اختيار ملفات بتنسيق PDF صالحة');
      return;
    }

    // Append to existing files
    setFiles((prev) => [...prev, ...newItems]);

    // Read page counts asynchronously
    for (const item of newItems) {
      try {
        const pages = await getPdfPageCount(item.file);
        setFiles((current) =>
          current.map((f) => (f.id === item.id ? { ...f, pageCount: pages, status: 'ready' } : f))
        );
      } catch {
        setFiles((current) =>
          current.map((f) => (f.id === item.id ? { ...f, status: 'ready' } : f))
        );
      }
    }
  };

  // Load sample PDFs for instant testing without manual file selection
  const loadSampleFiles = async () => {
    setErrorMessage(null);
    try {
      const sample1 = await createSamplePdf('المستند_الأول_مقدمة', { r: 0.25, g: 0.35, b: 0.85 }, 2);
      const sample2 = await createSamplePdf('المستند_الثاني_التقرير', { r: 0.1, g: 0.65, b: 0.5 }, 3);
      const sample3 = await createSamplePdf('المستند_الثالث_المرفقات', { r: 0.85, g: 0.35, b: 0.2 }, 1);

      const dt = new DataTransfer();
      dt.items.add(sample1);
      dt.items.add(sample2);
      dt.items.add(sample3);

      await handleFileSelect(dt.files);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage('تعذر إنشاء الملفات التجريبية: ' + msg);
    }
  };

  // Move item up in sequence
  const moveUp = (index: number) => {
    if (index <= 0) return;
    setFiles((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[index - 1];
      updated[index - 1] = temp;
      return updated;
    });
  };

  // Move item down in sequence
  const moveDown = (index: number) => {
    if (index >= files.length - 1) return;
    setFiles((prev) => {
      const updated = [...prev];
      const temp = updated[index];
      updated[index] = updated[index + 1];
      updated[index + 1] = temp;
      return updated;
    });
  };

  // Remove single file
  const removeFile = (id: string) => {
    setFiles((prev) => {
      const item = prev.find((f) => f.id === id);
      if (item?.previewUrl) URL.revokeObjectURL(item.previewUrl);
      return prev.filter((f) => f.id !== id);
    });
  };

  // Reverse list order
  const reverseOrder = () => {
    setFiles((prev) => [...prev].reverse());
  };

  // Sort alphabetically
  const sortAlphabetical = () => {
    setFiles((prev) =>
      [...prev].sort((a, b) => a.name.localeCompare(b.name, 'ar', { numeric: true }))
    );
  };

  // Clear all files
  const clearAllFiles = () => {
    files.forEach((f) => {
      if (f.previewUrl) URL.revokeObjectURL(f.previewUrl);
    });
    setFiles([]);
    setMergedResult(null);
    setErrorMessage(null);
  };

  // Perform PDF merge
  const handleMerge = async () => {
    if (files.length === 0) return;
    setIsMerging(true);
    setErrorMessage(null);
    setMergeProgress(0);

    try {
      const result = await mergePdfFiles(files, (progress, statusText) => {
        setMergeProgress(progress);
        setProgressStatus(statusText);
      });

      const cleanName = (outputFileName.trim() || 'ملف_مدمج').replace(/\.pdf$/i, '');
      const finalFileName = `${cleanName}.pdf`;

      setMergedResult({
        blob: result.blob,
        url: result.url,
        totalPages: result.totalPages,
        fileName: finalFileName,
        size: result.blob.size,
      });

      // Automatically trigger download for phone convenience
      triggerDownload(result.url, finalFileName);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage(msg);
    } finally {
      setIsMerging(false);
    }
  };

  // Trigger file download helper
  const triggerDownload = (url: string, name: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Native mobile share API
  const handleShare = async () => {
    if (!mergedResult) return;
    if (navigator.share) {
      try {
        const file = new File([mergedResult.blob], mergedResult.fileName, {
          type: 'application/pdf',
        });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: mergedResult.fileName,
            text: 'ملف PDF مدمج جاهز للتنزيل والقراءة',
            files: [file],
          });
        } else {
          await navigator.share({
            title: mergedResult.fileName,
            url: window.location.href,
          });
        }
      } catch (err) {
        console.log('Share canceled or not supported:', err);
      }
    } else {
      triggerDownload(mergedResult.url, mergedResult.fileName);
    }
  };

  // Download Standalone Single HTML file
  const handleDownloadStandaloneHtml = () => {
    const htmlCode = generateStandaloneSingleHtml();
    const blob = new Blob([htmlCode], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    triggerDownload(url, 'PDF_Merger_Single_File.html');
    URL.revokeObjectURL(url);
    setShowSingleHtmlCopied(true);
    setTimeout(() => setShowSingleHtmlCopied(false), 4000);
  };

  // Quick filename presets
  const namePresets = [
    'ملف_مدمج_شامل',
    'أوراق_معاملة_رسمية',
    'تقرير_نهائي_موحد',
    'شهادات_ومستندات',
    `دمج_${new Date().toISOString().slice(0, 10)}`,
  ];

  // Simulator dimensions
  const getFrameStyle = () => {
    switch (deviceFrame) {
      case 'iphone-16':
        return 'w-[393px] min-h-[852px] rounded-[44px] shadow-2xl border-[10px] border-slate-900 overflow-hidden my-6';
      case 'galaxy-s24':
        return 'w-[360px] min-h-[780px] rounded-[36px] shadow-2xl border-[8px] border-slate-800 overflow-hidden my-6';
      case 'iphone-se':
        return 'w-[375px] min-h-[667px] rounded-[32px] shadow-2xl border-[8px] border-slate-700 overflow-hidden my-6';
      case 'responsive':
      default:
        return 'w-full max-w-lg min-h-screen';
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col items-center justify-start selection:bg-indigo-500 selection:text-white pb-28 md:pb-12">
      {/* Top Bar Simulator & Device Selector for desktop/testing */}
      <div className="w-full bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between shadow-sm sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold shadow-md shadow-indigo-600/30">
            <Layers className="w-5 h-5" />
          </div>
          <span className="font-bold text-sm sm:text-base tracking-tight">دمج PDF للهواتف</span>
        </div>

        {/* Device size switchers (Responsive vs Phone Presets) */}
        <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl text-xs">
          <button
            onClick={() => setDeviceFrame('responsive')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              deviceFrame === 'responsive'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="عرض كامل الشاشة المتجاوب"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">متجاوب</span>
          </button>
          <button
            onClick={() => setDeviceFrame('iphone-16')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              deviceFrame === 'iphone-16'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="حجم هاتف iPhone 16 (393px)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">393px</span>
          </button>
          <button
            onClick={() => setDeviceFrame('galaxy-s24')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all ${
              deviceFrame === 'galaxy-s24'
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="حجم هاتف Galaxy S24 (360px)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">360px</span>
          </button>
        </div>

        {/* Standalone HTML Button */}
        <button
          onClick={handleDownloadStandaloneHtml}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold border border-slate-700 transition-colors"
          title="تحميل كملف HTML مستقل يعمل بدون خادم"
        >
          <Code className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden md:inline">ملف HTML مستقل</span>
          <Download className="w-3 h-3" />
        </button>
      </div>

      {/* Standalone HTML Download Toast */}
      {showSingleHtmlCopied && (
        <div className="fixed top-14 z-50 bg-emerald-700 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs animate-bounce">
          <Check className="w-4 h-4" />
          <span>تم تنزيل نسخة HTML المستقلة! يمكنك فتحها على هاتفك بدون إنترنت.</span>
        </div>
      )}

      {/* Main Container / Phone Simulator Container */}
      <div className={`transition-all duration-300 bg-white flex flex-col ${getFrameStyle()}`}>
        {/* Mobile Header Zone */}
        <div className="bg-gradient-to-b from-indigo-50/70 to-white px-4 pt-5 pb-4 border-b border-slate-100">
          <div className="flex items-center justify-between mb-1">
            <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span className="p-1.5 bg-indigo-600 text-white rounded-xl shadow-sm">
                <FileText className="w-5 h-5" />
              </span>
              دمج ملفات PDF
            </h1>

            {files.length > 0 && (
              <button
                onClick={clearAllFiles}
                className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2.5 py-1.5 rounded-lg hover:bg-rose-50 transition-colors flex items-center gap-1 min-h-[36px]"
              >
                <Trash2 className="w-3.5 h-3.5" />
                مسح الكل
              </button>
            )}
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            رتّب تسلسل ملفاتك بالأسهم، وأعد تسمية الملف المدمج، ثم نزّله مباشرة على هاتفك بكل خصوصية
            وسرعة.
          </p>
        </div>

        {/* Content Area */}
        <div className="p-4 flex-1 flex flex-col gap-4">
          {/* Error Message Display */}
          {errorMessage && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 px-3.5 py-2.5 rounded-2xl text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <div className="flex-1">{errorMessage}</div>
              <button
                onClick={() => setErrorMessage(null)}
                className="text-rose-400 hover:text-rose-600 min-h-[24px] min-w-[24px] flex items-center justify-center"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Upload Area / Dropzone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragOver(true);
            }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragOver(false);
              handleFileSelect(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-3xl p-6 text-center cursor-pointer transition-all ${
              isDragOver
                ? 'border-indigo-600 bg-indigo-50/60 scale-[0.99]'
                : 'border-slate-300 hover:border-indigo-400 bg-slate-50/70 hover:bg-indigo-50/20'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="application/pdf"
              className="hidden"
              onChange={(e) => handleFileSelect(e.target.files)}
            />

            <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-3 shadow-inner">
              <UploadCloud className="w-7 h-7" />
            </div>

            <div className="font-bold text-sm sm:text-base text-slate-800 mb-1">
              اختر ملفات PDF من هاتفك
            </div>
            <div className="text-xs text-slate-500 mb-4 max-w-xs mx-auto">
              اضغط هنا لاختيار عدة ملفات، أو اسحب الملفات وأفلتها هنا
            </div>

            <div className="inline-flex items-center gap-2 bg-indigo-600 text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-600/20 active:scale-95 transition-transform min-h-[44px]">
              <FilePlus className="w-4 h-4" />
              تصفح ملفات الهاتف
            </div>

            {/* Quick Demo Button */}
            {files.length === 0 && (
              <div className="mt-4 pt-3 border-t border-slate-200/60 flex justify-center">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    loadSampleFiles();
                  }}
                  className="text-xs text-indigo-700 hover:text-indigo-800 font-semibold bg-white border border-indigo-200 px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 shadow-sm active:scale-95 min-h-[38px]"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  تجربة بـ 3 ملفات عينات جاهزة
                </button>
              </div>
            )}
          </div>

          {/* Files List & Reordering Zone */}
          {files.length > 0 && (
            <div className="flex flex-col gap-3">
              {/* Controls bar */}
              <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-2xl border border-slate-200/80">
                <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <span>تسلسل الملفات:</span>
                  <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-md font-mono">
                    {files.length} ملفات
                  </span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-500">{totalPagesCount} صفحة</span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={reverseOrder}
                    className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-300 text-xs font-medium flex items-center gap-1 min-h-[36px] px-2 shadow-xs transition-colors"
                    title="عكس تسلسل الملفات"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">عكس</span>
                  </button>

                  <button
                    onClick={sortAlphabetical}
                    className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-300 text-xs font-medium flex items-center gap-1 min-h-[36px] px-2 shadow-xs transition-colors"
                    title="ترتيب أبجدي حسب الاسم"
                  >
                    <ArrowDownAZ className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">أ-ي</span>
                  </button>

                  <button
                    onClick={() => addMoreInputRef.current?.click()}
                    className="p-1.5 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 text-xs font-bold flex items-center gap-1 min-h-[36px] px-2.5 transition-colors"
                    title="إضافة ملفات أخرى"
                  >
                    <FilePlus className="w-3.5 h-3.5" />
                    <span>+ إضافة</span>
                  </button>
                  <input
                    ref={addMoreInputRef}
                    type="file"
                    multiple
                    accept="application/pdf"
                    className="hidden"
                    onChange={(e) => handleFileSelect(e.target.files)}
                  />
                </div>
              </div>

              {/* Reorder instructions hint */}
              <div className="text-[11px] text-slate-500 px-1 flex items-center gap-1">
                <span>💡 استخدم الأسهم</span>
                <span className="font-semibold text-slate-700">▲ و ▼</span>
                <span>لتغيير ترتيب أي ملف في المستند النهائي المدمج</span>
              </div>

              {/* List of files with sequence cards */}
              <div className="flex flex-col gap-2">
                {files.map((item, index) => {
                  const isFirst = index === 0;
                  const isLast = index === files.length - 1;

                  return (
                    <div
                      key={item.id}
                      className="bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl p-3 flex items-center gap-2.5 shadow-xs transition-all"
                    >
                      {/* Order Sequence Badge */}
                      <div className="w-7 h-7 rounded-xl bg-slate-900 text-white text-xs font-bold font-mono flex items-center justify-center shrink-0 shadow-xs">
                        {index + 1}
                      </div>

                      {/* File Icon & Info */}
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-xs sm:text-sm text-slate-800 truncate" dir="auto">
                          {item.name}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                          <span className="font-medium text-indigo-600 bg-indigo-50 px-1.5 py-0.2 rounded">
                            {item.pageCount} {item.pageCount === 1 ? 'صفحة' : 'صفحات'}
                          </span>
                          <span>·</span>
                          <span className="font-mono">{formatFileSize(item.size)}</span>
                        </div>
                      </div>

                      {/* Action & Reorder Buttons (Sized for thumb touch: min-h 44px hit areas) */}
                      <div className="flex items-center gap-1 shrink-0">
                        {/* Preview button */}
                        {item.previewUrl && (
                          <button
                            type="button"
                            onClick={() =>
                              setPreviewItem({ url: item.previewUrl!, title: item.name })
                            }
                            className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 flex items-center justify-center transition-colors min-w-[36px]"
                            title="معاينة هذا الملف"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        )}

                        {/* Move Up */}
                        <button
                          type="button"
                          onClick={() => moveUp(index)}
                          disabled={isFirst}
                          className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all min-w-[36px] ${
                            isFirst
                              ? 'text-slate-300 bg-slate-50 cursor-not-allowed'
                              : 'text-slate-700 bg-slate-100 hover:bg-indigo-100 hover:text-indigo-700 active:scale-90 shadow-xs'
                          }`}
                          title="تحريك للأعلى في التسلسل"
                        >
                          <ArrowUp className="w-4 h-4" />
                        </button>

                        {/* Move Down */}
                        <button
                          type="button"
                          onClick={() => moveDown(index)}
                          disabled={isLast}
                          className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all min-w-[36px] ${
                            isLast
                              ? 'text-slate-300 bg-slate-50 cursor-not-allowed'
                              : 'text-slate-700 bg-slate-100 hover:bg-indigo-100 hover:text-indigo-700 active:scale-90 shadow-xs'
                          }`}
                          title="تحريك للأسفل في التسلسل"
                        >
                          <ArrowDown className="w-4 h-4" />
                        </button>

                        {/* Remove */}
                        <button
                          type="button"
                          onClick={() => removeFile(item.id)}
                          className="w-9 h-9 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center transition-all active:scale-90 min-w-[36px]"
                          title="حذف من القائمة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Output File Renaming Section */}
              <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 mt-2 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <label htmlFor="filename-input" className="text-xs font-bold text-slate-800">
                    إعادة تسمية الملف الناتج:
                  </label>
                  <span className="text-[11px] text-slate-400">تلقائياً بصيغة .pdf</span>
                </div>

                <div className="flex items-center bg-white border border-slate-300 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-100 rounded-2xl overflow-hidden shadow-inner">
                  <input
                    id="filename-input"
                    type="text"
                    value={outputFileName}
                    onChange={(e) => setOutputFileName(e.target.value)}
                    placeholder="اكتب اسم الملف المدمج هنا"
                    className="flex-1 px-3.5 py-2.5 text-sm outline-none text-slate-800 font-semibold bg-transparent"
                    dir="auto"
                  />
                  <div className="bg-slate-100 text-slate-500 px-3 py-2.5 text-xs font-mono font-bold border-r border-slate-200 select-none">
                    .pdf
                  </div>
                </div>

                {/* Preset Suggestions */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {namePresets.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setOutputFileName(preset)}
                      className={`text-[11px] px-2.5 py-1 rounded-xl transition-colors font-medium ${
                        outputFileName === preset
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white border border-slate-200 text-slate-600 hover:border-indigo-300'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Merged Success Banner */}
              {mergedResult && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-4 mt-2 text-emerald-900 shadow-sm flex flex-col gap-3 animate-fade-in">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                      <CheckCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-emerald-950">
                        تم دمج الملفات بنجاح!
                      </div>
                      <div className="text-xs text-emerald-700">
                        {mergedResult.fileName} ({mergedResult.totalPages} صفحة ·{' '}
                        {formatFileSize(mergedResult.size)})
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() =>
                        triggerDownload(mergedResult.url, mergedResult.fileName)
                      }
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all min-h-[44px]"
                    >
                      <Download className="w-4 h-4" />
                      تنزيل الملف
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setPreviewItem({
                          url: mergedResult.url,
                          title: mergedResult.fileName,
                        })
                      }
                      className="bg-white hover:bg-emerald-100/50 text-emerald-800 border border-emerald-300 text-xs font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 active:scale-95 transition-all min-h-[44px]"
                    >
                      <Eye className="w-4 h-4" />
                      معاينة النتيجة
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleShare}
                    className="w-full bg-emerald-100 hover:bg-emerald-200/70 text-emerald-900 text-xs font-semibold py-2 rounded-xl flex items-center justify-center gap-1.5 transition-colors min-h-[38px]"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    مشاركة الملف (واتساب / التطبيقات)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Mobile Ergonomic Sticky Bottom Bar (Thumb Zone) */}
        {files.length > 0 && (
          <div className="sticky bottom-0 bg-white/95 backdrop-blur-md border-t border-slate-200 px-4 py-3 pb-safe shadow-lg z-30 flex flex-col gap-2">
            {/* Progress bar during merge */}
            {isMerging && (
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-indigo-600 h-full transition-all duration-300"
                  style={{ width: `${mergeProgress}%` }}
                />
              </div>
            )}

            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={isMerging}
                onClick={handleMerge}
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-bold text-sm sm:text-base py-3.5 px-4 rounded-2xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 active:scale-[0.98] transition-all min-h-[48px]"
              >
                {isMerging ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>{progressStatus || 'جاري دمج الصفحات...'}</span>
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5" />
                    <span>دمج وتنزيل الملف ({files.length} ملفات)</span>
                  </>
                )}
              </button>
            </div>

            <div className="text-center text-[11px] text-slate-400">
              إجمالي الصفحات: {totalPagesCount} · الحجم التقريبي: {formatFileSize(totalSizeBytes)}
            </div>
          </div>
        )}
      </div>

      {/* PDF Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-6">
          <div className="bg-white rounded-3xl w-full max-w-2xl h-[85vh] flex flex-col overflow-hidden shadow-2xl">
            {/* Modal Header */}
            <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between">
              <div className="font-bold text-sm truncate flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                <span className="truncate">{previewItem.title}</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewItem.url}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1"
                  title="فتح في نافذة جديدة"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => setPreviewItem(null)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 min-h-[32px] min-w-[32px] flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body iframe */}
            <div className="flex-1 bg-slate-100 relative">
              <iframe
                src={`${previewItem.url}#toolbar=0`}
                className="w-full h-full border-none"
                title={previewItem.title}
              />
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-white border-t border-slate-200 flex justify-between items-center">
              <span className="text-xs text-slate-500">معاينة المستند عبر المتصفح</span>
              <button
                onClick={() => setPreviewItem(null)}
                className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
