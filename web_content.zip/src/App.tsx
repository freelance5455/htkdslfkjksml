import React, { useState, useEffect } from 'react';
import { WorkoutProvider, useWorkout } from './context/WorkoutContext';
import { Navigation, TabType } from './components/Navigation';
import { HomeView } from './components/views/HomeView';
import { WorkoutsView } from './components/views/WorkoutsView';
import { ExercisesView } from './components/views/ExercisesView';
import { SkillsView } from './components/views/SkillsView';
import { ProgressView } from './components/views/ProgressView';
import { ProfileView } from './components/views/ProfileView';
import { ActiveWorkoutView } from './components/ActiveWorkoutView';
import { RestTimerModal } from './components/RestTimerModal';
import { NotificationBanner } from './components/NotificationBanner';
import { LevelUpConfettiOverlay } from './components/LevelUpConfettiOverlay';
import { Timer, Play, Sparkles, Sun, Moon } from 'lucide-react';
import { playPopSound, playConfettiPopSound } from './utils/audio';

const AppContent: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [targetSkillId, setTargetSkillId] = useState<string | null>(null);
  const [isThemeSwitching, setIsThemeSwitching] = useState(false);

  const {
    startRestTimer,
    user,
    theme,
    toggleTheme,
    activeWorkout,
    setIsWorkoutModalOpen,
    isTimerRunning,
    setIsTimerModalOpen,
    levelUpTierNotification,
    dismissLevelUpTierNotification
  } = useWorkout();

  // Global listener so every pop animation (badgePop, habitCheckPop, toastPopIn, modals) plays a synthesized pop cue
  useEffect(() => {
    if (!user.soundEnabled) return;
    let lastPopTime = 0;

    const handleAnimationStart = (e: AnimationEvent) => {
      const now = performance.now();
      if (now - lastPopTime < 55) return; // debounce simultaneous particles
      const name = e.animationName || '';
      if (name === 'badgePop' || name === 'toastPopIn') {
        lastPopTime = now;
        playPopSound('bright');
      } else if (name === 'habitCheckPop') {
        lastPopTime = now;
        playPopSound('habit');
      } else if (name === 'themeIconSpinIn') {
        lastPopTime = now;
        playPopSound(theme === 'light' ? 'theme-light' : 'theme-dark');
      } else if (name.includes('enter') || name.includes('zoom') || name.includes('fade')) {
        lastPopTime = now;
        playPopSound('soft');
      }
    };

    window.addEventListener('animationstart', handleAnimationStart);
    return () => window.removeEventListener('animationstart', handleAnimationStart);
  }, [user.soundEnabled, theme]);

  const handleThemeToggleClick = () => {
    setIsThemeSwitching(true);
    if (user.soundEnabled) {
      playPopSound(theme === 'light' ? 'theme-dark' : 'theme-light');
    }
    toggleTheme();
    window.setTimeout(() => setIsThemeSwitching(false), 600);
  };

  const handleSelectTab = (tab: TabType) => {
    if (tab !== currentTab && user.soundEnabled) {
      playPopSound('soft');
    }
    setCurrentTab(tab);
  };

  const handleOpenSkillsWithTarget = (skillId?: string) => {
    if (user.soundEnabled) playPopSound('bright');
    if (skillId) setTargetSkillId(skillId);
    setCurrentTab('skills');
  };

  return (
    <div className="min-h-screen bg-[#0a0b0e] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200 transition-colors duration-200">
      {/* Top Mobile Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#0a0b0e]/90 backdrop-blur-md border-b border-neutral-900/80 px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          {/* Brand Mark */}
          <button
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-1.5 group text-left"
          >
            <span className="font-heading font-extrabold text-xl text-white tracking-tight flex items-center">
              LIFT<span className="text-cyan-400">BODY</span>
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 group-hover:scale-125 transition-transform" />
          </button>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2">
            {/* Outdoor High-Contrast Light / Dark Mode Toggle with Smooth Rotation & Glow */}
            <button
              onClick={handleThemeToggleClick}
              className={`relative overflow-hidden px-2.5 py-1.5 text-xs font-semibold rounded-xl border transition-all duration-300 flex items-center gap-1.5 active:scale-95 group ${
                theme === 'light'
                  ? 'bg-amber-400/20 text-amber-700 border-amber-400/70 theme-toggle-glow-light'
                  : 'bg-neutral-900/90 text-slate-200 border-cyan-500/35 hover:border-cyan-400/60 hover:text-white theme-toggle-glow-dark'
              }`}
              title={
                theme === 'light'
                  ? 'Switch to Dark Mode'
                  : 'Switch to High-Contrast Light Mode for Outdoor Visibility'
              }
              aria-label="Toggle Theme"
            >
              {/* Subtle Ambient Radial Glow Backdrop */}
              <span
                className={`absolute inset-0 pointer-events-none transition-opacity duration-500 ${
                  theme === 'light'
                    ? 'bg-gradient-to-r from-amber-400/25 via-yellow-300/15 to-transparent opacity-100'
                    : 'bg-gradient-to-r from-cyan-500/20 via-sky-400/10 to-transparent opacity-90'
                }`}
              />

              {/* Switching Ripple Burst Ring */}
              {isThemeSwitching && (
                <span
                  className={`absolute inset-0 rounded-xl pointer-events-none border-2 animate-theme-glow-ring ${
                    theme === 'light' ? 'border-amber-400' : 'border-cyan-400'
                  }`}
                />
              )}

              {/* Dual-Layered Smooth Rotating Icon Container */}
              <span className="relative w-4 h-4 flex items-center justify-center shrink-0">
                <Sun
                  key={`sun-${theme}`}
                  className={`w-3.5 h-3.5 text-amber-500 fill-amber-400 drop-shadow-[0_0_6px_rgba(245,158,11,0.8)] transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${
                    theme === 'light'
                      ? 'rotate-0 scale-100 opacity-100 animate-theme-icon-spin group-hover:rotate-45'
                      : 'rotate-180 scale-0 opacity-0 absolute'
                  }`}
                />
                <Moon
                  key={`moon-${theme}`}
                  className={`w-3.5 h-3.5 text-cyan-400 fill-cyan-400/20 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)] transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${
                    theme === 'dark'
                      ? 'rotate-0 scale-100 opacity-100 animate-theme-icon-spin group-hover:-rotate-12'
                      : '-rotate-180 scale-0 opacity-0 absolute'
                  }`}
                />
              </span>

              <span className="relative z-10 hidden sm:inline tracking-tight">
                {theme === 'light' ? 'Outdoor Light' : 'Dark'}
              </span>
            </button>

            {/* Skills Shortcut Tab */}
            <button
              onClick={() => setCurrentTab('skills')}
              className={`px-2.5 py-1.5 text-xs font-semibold rounded-xl border transition-all flex items-center gap-1 ${
                currentTab === 'skills'
                  ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40'
                  : 'bg-neutral-900/80 text-slate-300 border-neutral-800 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Skills</span>
            </button>

            {/* Rest Timer Button */}
            <button
              onClick={() => (isTimerRunning ? setIsTimerModalOpen(true) : startRestTimer(user.defaultRestTimeSec))}
              className={`p-2 rounded-xl transition-colors ${
                isTimerRunning
                  ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-400'
                  : 'bg-neutral-900/80 border border-neutral-800 text-slate-300 hover:text-cyan-400'
              }`}
              title="Rest Timer"
            >
              <Timer className={`w-4 h-4 ${isTimerRunning ? 'animate-pulse' : ''}`} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-lg mx-auto px-4 py-3">
        {currentTab === 'home' && (
          <HomeView
            onNavigate={handleSelectTab}
            onOpenSkillDetails={handleOpenSkillsWithTarget}
          />
        )}
        {currentTab === 'workouts' && <WorkoutsView />}
        {currentTab === 'exercises' && <ExercisesView />}
        {currentTab === 'skills' && <SkillsView initialSkillId={targetSkillId} />}
        {currentTab === 'progress' && (
          <ProgressView
            onNavigate={handleSelectTab}
            onOpenSkills={handleOpenSkillsWithTarget}
          />
        )}
        {currentTab === 'profile' && <ProfileView />}
      </main>

      {/* Bottom Sticky Navigation */}
      <Navigation
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
      />

      {/* Active Workout Screen / Modal */}
      <ActiveWorkoutView />

      {/* Rest Timer Modal */}
      <RestTimerModal />

      {/* Notification Toast Banners for PRs and Achievements */}
      <NotificationBanner />

      {/* Subtle 'Level Up' Confetti Animation Overlay for First Workout in a New Difficulty Tier */}
      <LevelUpConfettiOverlay
        tier={levelUpTierNotification}
        onDismiss={dismissLevelUpTierNotification}
      />
    </div>
  );
};

export default function App() {
  return (
    <WorkoutProvider>
      <AppContent />
    </WorkoutProvider>
  );
}
