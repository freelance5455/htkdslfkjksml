import { useCallback, useMemo, useRef, useState } from "react";
import { GameView, Controls } from "./components/GameView";
import { HUD, MapOverlay } from "./components/HUD";
import { SettingsPanel } from "./components/SettingsPanel";
import { StartScreen } from "./components/StartScreen";
import type { Game, GameCallbacks, Settings, UIState, InvState } from "./game/Game";
import { Hotbar, InventoryPanel } from "./components/Inventory";
import { initAudio } from "./game/sfx";

const SETTINGS_KEY = "terras-ametista-settings";

function defaultSettings(): Settings {
  const coarse = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;
  const base: Settings = { sensitivity: 1, invertY: false, quality: coarse ? "media" : "alta", dayLength: 600, showFps: false };
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...base, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return base;
}

interface Toast { id: number; msg: string }

export default function App() {
  const [phase, setPhase] = useState<"menu" | "loading" | "playing">("menu");
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [ui, setUi] = useState<UIState | null>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [dialog, setDialog] = useState<{ title: string; text: string } | null>(null);
  const [fade, setFade] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [running, setRunning] = useState(false);
  const [inv, setInv] = useState<InvState | null>(null);
  const [showInv, setShowInv] = useState(false);
  const [hurt, setHurt] = useState(0);
  const toastId = useRef(0);

  const pushToast = useCallback((msg: string) => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const callbacks: GameCallbacks = useMemo(
    () => ({
      onState: (s) => setUi(s),
      onToast: pushToast,
      onDialog: (title, text) => setDialog({ title, text }),
      onFade: (v) => setFade(v),
      onToggleMap: () => setShowMap((m) => !m),
      onInventory: (s) => setInv(s),
      onHurt: () => setHurt((h) => h + 1),
      onToggleInventory: () => setShowInv((v) => !v),
    }),
    [pushToast]
  );

  const changeSettings = (s: Settings) => {
    setSettings(s);
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* ignore */ }
  };

  const start = () => {
    setPhase("loading");
    initAudio();
    try {
      if (window.matchMedia?.("(pointer: coarse)").matches && !document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().then(() => {
          (screen.orientation as any)?.lock?.("landscape").catch(() => {});
        }).catch(() => {});
      }
    } catch { /* ignore */ }
  };

  const toMenu = () => {
    setShowSettings(false);
    setShowMap(false);
    setShowInv(false);
    setInv(null);
    setGame(null);
    setUi(null);
    setPhase("menu");
  };

  return (
    <div className="fixed inset-0 overflow-hidden bg-black font-pixel text-white select-none">
      {phase !== "menu" && (
        <GameView
          settings={settings}
          callbacks={callbacks}
          onReady={(g) => setGame(g)}
          onLoadingDone={() => setPhase("playing")}
        />
      )}

      {phase === "playing" && (
        <>
          <Controls
            game={game}
            interactLabel={ui?.interact ?? null}
            running={running}
            onRunToggle={() => setRunning((r) => !r)}
            panorama={ui?.panorama ?? null}
          />
          <HUD ui={ui} game={game} onOpenMap={() => setShowMap(true)} onOpenSettings={() => setShowSettings(true)} showFps={settings.showFps} />
          <Hotbar game={game} inv={inv} onOpenInventory={() => setShowInv(true)} />

          {/* damage vignette */}
          {hurt > 0 && (
            <div
              key={hurt}
              className="hurt-flash pointer-events-none absolute inset-0 z-[35]"
              style={{ boxShadow: "inset 0 0 90px 30px rgba(200,20,40,0.65)" }}
            />
          )}
          {ui && ui.hp < ui.maxHp * 0.25 && (
            <div className="pointer-events-none absolute inset-0 z-[34] animate-pulse" style={{ boxShadow: "inset 0 0 70px 10px rgba(160,10,30,0.45)" }} />
          )}

          {showInv && game && inv && (
            <InventoryPanel game={game} inv={inv} hp={ui?.hp ?? 100} maxHp={ui?.maxHp ?? 100} onClose={() => setShowInv(false)} />
          )}

          <div className="pointer-events-none absolute inset-x-0 top-24 z-40 flex flex-col items-center gap-2 sm:top-6">
            {toasts.map((t) => (
              <div key={t.id} className="pixel-panel toast-in px-4 py-2 text-center text-sm text-amber-100">{t.msg}</div>
            ))}
          </div>

          {dialog && (
            <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/40 p-4 sm:items-center" onClick={() => setDialog(null)}>
              <div className="pixel-panel w-full max-w-lg p-4" onClick={(e) => e.stopPropagation()}>
                <div className="mb-2 text-sm uppercase tracking-widest text-fuchsia-300">{dialog.title}</div>
                <p className="mb-4 text-sm leading-relaxed text-white/90">{dialog.text}</p>
                <button onClick={() => setDialog(null)} className="pixel-btn w-full bg-fuchsia-600 py-2 text-sm">Continuar</button>
              </div>
            </div>
          )}

          {showMap && game && <MapOverlay game={game} ui={ui} onClose={() => setShowMap(false)} />}
          {showSettings && (
            <SettingsPanel
              settings={settings}
              onChange={changeSettings}
              onClose={() => setShowSettings(false)}
              hour={ui?.hour ?? 9}
              onSetHour={(h) => game?.setHour(h)}
              onReset={() => { game?.resetProgress(); pushToast("Progresso reiniciado."); }}
              onMenu={toMenu}
            />
          )}
        </>
      )}

      <div className={`pointer-events-none absolute inset-0 z-[55] bg-black transition-opacity duration-300 ${fade ? "opacity-100" : "opacity-0"}`} />

      {phase !== "playing" && <StartScreen onStart={start} loading={phase === "loading"} />}
    </div>
  );
}
