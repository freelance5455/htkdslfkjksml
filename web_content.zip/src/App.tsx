import { useEffect, useState } from 'react';
import { api } from '@appdeploy/client';
import {
  Bot,
  Image as ImageIcon,
  Video,
  BookOpen,
  Plus,
  Send,
  Download,
  Sparkles,
  Menu,
  X,
  MessageCircle,
  ChevronDown,
  LoaderCircle,
  Copy,
  Check,
} from 'lucide-react';

type Message = { role: 'user' | 'assistant'; content: string };
type Chat = { id: number; title: string; messages: Message[] };
type GalleryItem = { id: string; type: 'image' | 'video'; title: string; src: string; downloadName: string };

function readableApiError(value: unknown, fallback: string) {
  const err = value as { response?: { data?: unknown }; data?: unknown; message?: string } | null;
  const payload = err?.response?.data ?? err?.data;
  if (typeof payload === 'string' && payload.trim()) return payload;
  if (payload && typeof payload === 'object') {
    const data = payload as { error?: unknown; message?: unknown; detail?: unknown };
    for (const candidate of [data.message, data.error, data.detail]) {
      if (typeof candidate === 'string' && candidate.trim()) return candidate;
      if (candidate && typeof candidate === 'object' && 'message' in candidate && typeof (candidate as { message?: unknown }).message === 'string') return (candidate as { message: string }).message;
    }
  }
  if (err?.message && !/request failed with status code 503/i.test(err.message)) return err.message;
  return err?.message || fallback;
}

async function optimizeImageForVideo(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext('2d');
  if (!context) throw new Error('This browser could not prepare the image.');
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('Could not compress the image.')), 'image/jpeg', 0.82));
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('Could not read the compressed image.'));
    reader.onerror = () => reject(new Error('Could not prepare the image for video generation.'));
    reader.readAsDataURL(blob);
  });
}

function App() {
  const [customLogo, setCustomLogo] = useState<string>(() => {
    try { return localStorage.getItem('pretixbot-custom-logo') || '/resources/pretixbot-logo.jpg'; } catch { return '/resources/pretixbot-logo.jpg'; }
  });
  const [mode, setMode] = useState<'chat' | 'image' | 'video' | 'gallery'>('chat');
  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    try {
      const saved = localStorage.getItem('nova-ai-gallery');
      const parsed = saved ? JSON.parse(saved) as GalleryItem[] : [];
      return Array.isArray(parsed) ? parsed.filter(item => item && (item.type === 'image' || item.type === 'video') && typeof item.src === 'string' && typeof item.downloadName === 'string') : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('nova-ai-gallery', JSON.stringify(gallery));
    } catch {
      setNotice('Your gallery could not be saved in browser storage. Download important images to keep a copy.');
    }
  }, [gallery]);
  const [chats, setChats] = useState<Chat[]>([
    { id: 1, title: 'New conversation', messages: [] },
  ]);
  const [activeId, setActiveId] = useState(1);
  const [prompt, setPrompt] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [duration, setDuration] = useState('10');
  const [videoProvider, setVideoProvider] = useState<'runway' | 'luma'>('luma');
  const [imageResult, setImageResult] = useState('');
  const [videoResult, setVideoResult] = useState('');
  const [videoProgress, setVideoProgress] = useState(0);
  const [videoSourceImage, setVideoSourceImage] = useState('');
  const [videoRatio, setVideoRatio] = useState<'16:9' | '9:16'>('16:9');
  const [videoCostAcknowledged, setVideoCostAcknowledged] = useState(false);
  const [copied, setCopied] = useState(-1);
  const active = chats.find(c => c.id === activeId) || chats[0];
  const updateMessages = (messages: Message[]) =>
    setChats(prev =>
      prev.map(c =>
        c.id === activeId
          ? {
              ...c,
              messages,
              title:
                c.messages.length === 0 && messages[0]
                  ? messages[0].content.slice(0, 32)
                  : c.title,
            }
          : c
      )
    );
  const handleLogoUpload = async (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) { setNotice('Choose an image file for your logo.'); return; }
    if (file.size > 10 * 1024 * 1024) { setNotice('Choose a logo image smaller than 10 MB.'); return; }
    try {
      const bitmap = await createImageBitmap(file);
      const scale = Math.min(1, 512 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      const context = canvas.getContext('2d');
      if (!context) throw new Error('Could not prepare that image.');
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close();
      const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
      try { localStorage.setItem('pretixbot-custom-logo', dataUrl); } catch { throw new Error('The logo could not be saved in browser storage. Try a smaller image.'); }
      setCustomLogo(dataUrl);
      setNotice('Logo added! It will appear in PretixBot on this browser.');
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Could not upload that logo. Try another image.');
    }
  };

  const newChat = () => {
    const id = Date.now();
    setChats(prev => [
      { id, title: 'New conversation', messages: [] },
      ...prev,
    ]);
    setActiveId(id);
    setMode('chat');
    setPrompt('');
    setNotice('');
    setMobileMenu(false);
  };

  const sendChat = async () => {
    const question = prompt.trim();
    if (!question || busy) return;
    const history = [
      ...active.messages,
      { role: 'user' as const, content: question },
    ];
    updateMessages(history);
    setPrompt('');
    setBusy(true);
    setNotice('');
    try {
      const response = await api.post('/api/chat', { messages: history });
      const answer = String(
        response.data?.answer ||
          'I could not create an answer this time. Please try again.'
      );
      updateMessages([...history, { role: 'assistant', content: answer }]);
    } catch (e) {
      updateMessages([
        ...history,
        {
          role: 'assistant',
          content:
            'I could not connect to the AI service right now. Please try again in a moment.',
        },
      ]);
    } finally {
      setBusy(false);
    }
  };

  const generateImage = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true);
    setNotice('');
    setImageResult('');
    try {
      const response = await api.post('/api/pixelster/image', { prompt: prompt.trim(), ratio: '16:9' });
      if (response.data?.imageUrl && String(response.data.imageUrl).startsWith('https://')) {
        const src = String(response.data.imageUrl);
        const item: GalleryItem = { id: `${Date.now()}-${Math.random()}`, type: 'image', title: prompt.trim(), src, downloadName: `pretixbot-image-${Date.now()}.png` };
        setImageResult(src);
        setGallery(prev => [item, ...prev]);
      } else {
        setNotice('The image service returned no image. Please try another prompt.');
      }
    } catch (e) {
      setNotice(e instanceof Error && e.message ? e.message : 'Image generation failed. Check the Google AI key, model access, and quota/billing, then try again.');
    } finally {
      setBusy(false);
    }
  };

  const generateVideo = async () => {
    if (!prompt.trim() || busy) return;
    setBusy(true);
    setVideoResult('');
    setVideoProgress(8);
    let stage: 'starting-image' | 'animation' = videoSourceImage ? 'animation' : 'starting-image';
    setNotice(videoSourceImage
      ? 'Preparing your image for animation. This may take a little while.'
      : 'Step 1 of 2: creating a starting image from your prompt.');
    try {
      let generatedImageUrl = '';
      if (!videoSourceImage) {
        const framePrompt = 'Create one clear, high-quality starting frame for a video based on this scene. Preserve the requested subject and visual style and compose it for natural animation. If visible words are requested, include them in the scene: ' + prompt.trim();
        const frameResponse = await api.post('/api/pixelster/image', {
          prompt: framePrompt.slice(0, 1800),
          ratio: videoRatio,
        });
        generatedImageUrl = String(frameResponse.data?.imageUrl || '');
        if (!generatedImageUrl.startsWith('https://')) throw new Error('The starting-image service did not return an image link.');
        setVideoProgress(40);
        setNotice('Step 2 of 2: starting image ready. Animating it into a video now; the video server may take a few minutes.');
        stage = 'animation';
      }
      const response = await api.post('/api/pixelster/video', {
        prompt: prompt.trim(),
        ...(videoSourceImage ? { imageBase64: videoSourceImage } : { imageUrl: generatedImageUrl }),
        ratio: videoRatio,
        duration: Number(duration),
      });
      const src = String(response.data?.videoUrl || '');
      if (!src.startsWith('https://')) throw new Error('The video service did not return a video link.');
      const item: GalleryItem = { id: `${Date.now()}-${Math.random()}`, type: 'video', title: prompt.trim(), src, downloadName: `pretixbot-video-${Date.now()}.mp4` };
      setVideoResult(src);
      setGallery(prev => [item, ...prev]);
      setVideoProgress(100);
      setNotice('Your video is ready. Use Save to device to download it, or Save to Photos/Gallery to choose a compatible Android app.');
    } catch (e) {
      const message = readableApiError(e, 'Video generation failed. Try another image or prompt.');
      if (/network error|failed to fetch|timeout|timed out/i.test(message)) {
        setNotice(stage === 'starting-image'
          ? 'The connection to the starting-image service failed. Your internet may be fine; please retry in a moment.'
          : 'The starting image is ready, but the video server connection dropped or took too long. This can happen when the video service is busy. Try again, or choose a shorter 5-second video.');
      } else {
        setNotice(message);
      }
    } finally {
      setBusy(false);
    }
  };

  const saveToGallery = async (src: string, filename: string) => {
    setNotice('Preparing the video for Android sharing...');
    try {
      const response = await fetch(src);
      if (!response.ok) throw new Error('The media host did not allow file sharing.');
      const blob = await response.blob();
      const file = new File([blob], filename, { type: blob.type || (filename.endsWith('.mp4') ? 'video/mp4' : 'image/png') });
      if (!navigator.share || !navigator.canShare || !navigator.canShare({ files: [file] })) {
        throw new Error('File sharing is not supported in this browser.');
      }
      await navigator.share({ files: [file], title: 'PretixBot creation' });
      setNotice('Choose Photos, Gallery, or Files in the Android share menu to save a copy.');
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      const link = document.createElement('a');
      link.href = src;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      link.remove();
      setNotice('Android opened the media link instead. Use the browser menu to download the MP4, then open Downloads and move/save it in your Photos or Gallery app.');
    }
  };

  const saveToDevice = async (src: string, filename: string) => {
    setNotice('Preparing your download...');
    try {
      const response = await fetch(src);
      if (!response.ok) throw new Error('The media server did not allow a direct download.');
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
      setNotice('Download started. On Android, check Downloads or your Photos/Gallery app.');
    } catch {
      const link = document.createElement('a');
      link.href = src;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      link.remove();
      setNotice('The image opened separately because the image host blocked direct downloading. Long-press the image and choose Download image or Save image.');
    }
  };

  const copyText = async (value: string, index: number) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(index);
      setTimeout(() => setCopied(-1), 1400);
    } catch {
      setNotice('Copy is unavailable in this browser.');
    }
  };

  return (
    <div className="shell">
      {mobileMenu && (
        <button
          className="scrim"
          aria-label="Close menu"
          onClick={() => setMobileMenu(false)}
        />
      )}
      <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-mark">
            <img src={customLogo} alt="pretixbot logo" />
          </div>
          <div>
            <strong>pretixbot</strong>
            <span>AI ASSISTANT</span>
          </div>
          <button
            className="icon-btn close-menu"
            onClick={() => setMobileMenu(false)}
            aria-label="Close menu"
          >
            <X size={19} />
          </button>
        </div>
        <button className="new-chat" onClick={newChat}>
          <Plus size={18} /> New chat <span>⌘ K</span>
        </button>
        <div className="nav-label">WORKSPACE</div>
        <button
          className={`nav-item ${mode === 'chat' ? 'selected' : ''}`}
          onClick={() => {
            setMode('chat');
            setMobileMenu(false);
          }}
        >
          <MessageCircle size={18} /> AI Chat
        </button>
        <button
          className={`nav-item ${mode === 'image' ? 'selected' : ''}`}
          onClick={() => {
            setMode('image');
            setPrompt('');
            setNotice('');
            setMobileMenu(false);
          }}
        >
          <ImageIcon size={18} /> Create image{' '}
          <span className="nav-tag">AI</span>
        </button>
        <button
          className={`nav-item ${mode === 'video' ? 'selected' : ''}`}
          onClick={() => {
            setMode('video');
            setPrompt('');
            setNotice('');
            setMobileMenu(false);
          }}
        >
          <Video size={18} /> Video studio{' '}
          <span className="nav-tag muted">BETA</span>
        </button>
        <button className={`nav-item ${mode === 'gallery' ? 'selected' : ''}`} onClick={() => { setMode('gallery'); setNotice(''); setMobileMenu(false); }}>
          <ImageIcon size={18} /> My Gallery <span className="nav-tag">{gallery.length}</span>
        </button>
        <div className="nav-label history-label">RECENT CHATS</div>
        <div className="chat-list">
          {chats.map(c => (
            <button
              key={c.id}
              className={`history-item ${activeId === c.id && mode === 'chat' ? 'history-active' : ''}`}
              onClick={() => {
                setActiveId(c.id);
                setMode('chat');
                setMobileMenu(false);
              }}
            >
              <MessageCircle size={15} />
              <span>{c.title}</span>
            </button>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="free-card">
            <div className="free-icon">
              <Sparkles size={17} />
            </div>
            <div>
              <strong>Made for curiosity</strong>
              <p>Ask anything. Learn anything.</p>
            </div>
          </div>
          <div className="profile-row">
            <div className="avatar"><img src={customLogo} alt="pretixbot logo" /></div>
            <div>
              <strong>pretixbot</strong>
              <span>AI workspace</span>
            </div>
            <ChevronDown size={16} />
          </div>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <button
            className="icon-btn menu-toggle"
            onClick={() => setMobileMenu(true)}
            aria-label="Open menu"
          >
            <Menu size={21} />
          </button>
          <div className="crumb">
            pretixbot <span>/</span>{' '}
            <strong>
              {mode === 'chat'
                ? 'AI Chat'
                : mode === 'image'
                  ? 'Create image'
                  : mode === 'video'
                    ? 'Video studio'
                    : 'My Gallery'}
            </strong>
          </div>
          <div className="top-actions">
            <span className="online-dot"></span>
            <span className="online-text">AI workspace</span>
            <button className="top-new" onClick={newChat}>
              <Plus size={16} /> New chat
            </button>
          </div>
        </header>
        {mode === 'chat' && (
          <section
            className={`chat-view ${active.messages.length ? 'has-messages' : ''}`}
          >
            {active.messages.length === 0 ? (
              <div className="welcome">
                <div className="welcome-icon">
                  <Sparkles size={27} />
                </div>
                <div className="eyebrow">YOUR AI COMPANION</div>
                <h1>
                  What can I help you
                  <br />
                  <span>figure out today?</span>
                </h1>
                <p>
                  Ask questions, explore ideas, solve problems and learn
                  something new.
                </p>
                <div className="suggestions">
                  <button
                    onClick={() =>
                      setPrompt(
                        'Explain a difficult science topic in simple words'
                      )
                    }
                  >
                    <span className="suggestion-icon purple">
                      <BookOpen size={18} />
                    </span>
                    <span>
                      <b>Learn something</b>
                      <small>Explain a hard science topic</small>
                    </span>
                    <span className="suggest-arrow">↗</span>
                  </button>
                  <button
                    onClick={() =>
                      setPrompt(
                        'Help me solve this math problem step by step: '
                      )
                    }
                  >
                    <span className="suggestion-icon blue">∑</span>
                    <span>
                      <b>Solve a problem</b>
                      <small>Math, homework and reasoning</small>
                    </span>
                    <span className="suggest-arrow">↗</span>
                  </button>
                  <button
                    onClick={() =>
                      setPrompt('Give me creative ideas for a short story')
                    }
                  >
                    <span className="suggestion-icon peach">
                      <Sparkles size={18} />
                    </span>
                    <span>
                      <b>Get creative</b>
                      <small>Ideas, writing and inspiration</small>
                    </span>
                    <span className="suggest-arrow">↗</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="messages">
                {active.messages.map((m, i) => (
                  <div className={`message ${m.role}`} key={i}>
                    <div className={`message-avatar ${m.role}`}>
                      {m.role === 'assistant' ? <Sparkles size={16} /> : 'Y'}
                    </div>
                    <div className="message-body">
                      <div className="message-name">
                        {m.role === 'assistant' ? 'pretixbot' : 'You'}
                      </div>
                      <div className="message-text">{m.content}</div>
                      {m.role === 'assistant' && (
                        <button
                          className="copy-btn"
                          onClick={() => copyText(m.content, i)}
                        >
                          {copied === i ? (
                            <Check size={14} />
                          ) : (
                            <Copy size={14} />
                          )}{' '}
                          {copied === i ? 'Copied' : 'Copy answer'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {busy && (
                  <div className="message assistant">
                    <div className="message-avatar assistant">
                      <Sparkles size={16} />
                    </div>
                    <div className="message-body">
                      <div className="message-name">pretixbot</div>
                      <div className="typing">
                        <i></i>
                        <i></i>
                        <i></i>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
            <div className="composer-wrap">
              <div className="composer">
                <textarea
                  value={prompt}
                  onChange={e => setPrompt(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendChat();
                    }
                  }}
                  placeholder="Ask anything..."
                  rows={2}
                  aria-label="Ask pretixbot anything"
                />
                <div className="composer-bottom">
                  <div className="composer-hint">
                    <Sparkles size={14} /> AI can make mistakes. Check important
                    answers.
                  </div>
                  <button
                    className="send-btn"
                    disabled={!prompt.trim() || busy}
                    onClick={sendChat}
                    aria-label="Send message"
                  >
                    {busy ? (
                      <LoaderCircle className="spin" size={17} />
                    ) : (
                      <Send size={17} />
                    )}
                  </button>
                </div>
              </div>
              <div className="composer-foot">
                Free to use · No coins or premium tiers in this interface
              </div>
            </div>
          </section>
        )}
        {mode === 'image' && (
          <section className="tool-view">
            <div className="tool-heading">
              <div className="tool-symbol image-symbol">
                <ImageIcon size={23} />
              </div>
              <div>
                <div className="eyebrow">IMAGE GENERATOR</div>
                <h1>Imagine it. Create it.</h1>
                <p>
                  Describe the picture you want and let AI bring it to life.
                </p>
              </div>
            </div>
            <div className="tool-panel">
              <label htmlFor="image-prompt">Describe your image</label>
              <textarea
                id="image-prompt"
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder="A dreamy futuristic city above the clouds at sunset, cinematic lighting..."
                rows={4}
              />
              <div className="prompt-tip">
                <Sparkles size={15} /> Tip: mention the subject, style, colors
                and lighting.
              </div>
              <button
                className="primary-btn"
                disabled={!prompt.trim() || busy}
                onClick={generateImage}
              >
                {busy ? (
                  <>
                    <LoaderCircle size={18} className="spin" /> Creating your
                    image...
                  </>
                ) : (
                  <>
                    <Sparkles size={18} /> Generate image
                  </>
                )}
              </button>
              {notice && <div className="notice error-notice">{notice}</div>}
            </div>
            {imageResult && (
              <div className="result-panel">
                <div className="result-head">
                  <strong>Your creation</strong>
                  <button className="download-btn" onClick={() => saveToDevice(imageResult, `pretixbot-image-${Date.now()}.png`)}>
                    <Download size={16} /> Save to device
                  </button>
                </div>
                <img
                  className="generated-image"
                  src={imageResult}
                  alt="AI generated from your prompt"
                />
                <p className="tool-note">This picture was also added to My Gallery.</p>
              </div>
            )}
            <div className="tool-note">
              Image creation uses an AI model. Availability can vary. No coin
              balance is shown in this app.
            </div>
          </section>
        )}
        {mode === 'gallery' && (
          <section className="tool-view">
            <div className="tool-heading">
              <div className="tool-symbol image-symbol"><ImageIcon size={23} /></div>
              <div><div className="eyebrow">YOUR CREATIONS</div><h1>My Gallery</h1><p>Watch your videos, view your AI pictures, and save them to your device.</p></div>
            </div>
            {gallery.length === 0 ? (
              <div className="tool-panel gallery-empty">
                <div className="status-icon"><ImageIcon size={22} /></div><h2>Your gallery is empty</h2>
                <p>Create AI pictures here. Create a real AI video from the Video Studio. Videos you generate will appear here.</p>
                <div className="gallery-actions"><button className="secondary-btn" onClick={() => { setMode('image'); setPrompt(''); }}>Create image</button><button className="primary-btn" onClick={() => { setMode('video'); setPrompt(''); }}>Make a video</button></div>
              </div>
            ) : (
              <div className="gallery-grid">{gallery.map(item => (
                <article className="gallery-card" key={item.id}>
                  {item.type === 'image' ? <img className="gallery-media" src={item.src} alt={item.title} /> : <video className="gallery-media" src={item.src} controls playsInline preload="metadata" />}
                  <div className="gallery-card-body"><span className="gallery-kind">{item.type === 'image' ? 'AI PICTURE' : 'VIDEO'}</span><p className="gallery-title">{item.title}</p><button className="download-btn" onClick={() => saveToDevice(item.src, item.downloadName)}><Download size={16} /> Save to device</button><button className="secondary-btn" onClick={() => saveToGallery(item.src, item.downloadName)}>Save to Photos/Gallery</button></div>
                </article>
              ))}</div>
            )}
            <div className="tool-note">Your image and video links are kept in this browser's My Gallery when storage is available. Use Save to device to download media, or Save to Photos/Gallery to open Android's share menu and choose a compatible app. A website cannot silently write files directly into Android's Gallery.</div>
          </section>
        )}
        {mode === 'video' && (
          <section className="tool-view">
            <div className="tool-heading">
              <div className="tool-symbol video-symbol">
                <Video size={23} />
              </div>
              <div>
                <div className="eyebrow">VIDEO STUDIO</div>
                <h1>Turn your ideas into motion</h1>
                <p>Describe a scene to create a video from text, or add a photo if you want to guide the result.</p>
              </div>
            </div>
            <div className="tool-panel">
              <label htmlFor="video-prompt">
                What should happen in your video?
              </label>
              <textarea
                id="video-prompt"
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder="A cinematic chase through a neon city in the rain..."
                rows={4}
              />
              <label className="duration-label" htmlFor="video-source">Source image (optional)</label>
              <p className="tool-note">No photo needed. Without one, PretixBot first creates a starting image from your prompt, then asks the video service to animate it. Try humans, animals, visible words, anime, 2D cartoons, 3D scenes, or choreographed action. Results depend on the AI services.</p>
              <input id="video-source" type="file" accept="image/png,image/jpeg,image/webp" onChange={e => {
                const file = e.target.files?.[0];
                if (!file) return;
                if (file.size > 3.5 * 1024 * 1024) {
                  setNotice('Choose an image smaller than 3.5 MB.');
                  e.target.value = '';
                  return;
                }
                setNotice('Preparing a smaller image for the video service...');
                optimizeImageForVideo(file).then(dataUrl => {
                  setVideoSourceImage(dataUrl);
                  setNotice('Image ready. Add a motion prompt and generate your video.');
                }).catch(err => setNotice(err instanceof Error ? err.message : 'Could not prepare that image. Try another JPG or PNG.'));
              }} />
              {videoSourceImage && <img className="generated-image" src={videoSourceImage} alt="Selected source for video" />}
              <label className="duration-label" htmlFor="video-duration">Video duration</label>
              <select id="video-duration" className="provider-select" value={duration} onChange={e => setDuration(e.target.value)}>
                {['5', '10', '15', '20'].map(d => <option key={d} value={d}>{d} seconds</option>)}
              </select>
              <label className="duration-label" htmlFor="video-ratio">Video shape</label>
              <select id="video-ratio" className="provider-select" value={videoRatio} onChange={e => setVideoRatio(e.target.value === '9:16' ? '9:16' : '16:9')}>
                <option value="16:9">Landscape (16:9)</option>
                <option value="9:16">Portrait / Reels (9:16)</option>
              </select>
              <div className="video-status">
                <div className="status-icon"><Video size={18} /></div>
                <div>
                  <strong>Text-to-video and photo animation</strong>
                  <p>Describe both the scene and the movement. For example: “A 3D orange cat runs across a rooftop, leaps over a gap, and lands as the camera follows.” External service limits and availability may apply.</p>
                </div>
              </div>
              <button className="primary-btn" disabled={!prompt.trim() || busy} onClick={generateVideo}>
                {busy ? <><LoaderCircle size={18} className="spin" /> Creating video...</> : <><Video size={18} /> Generate video</>}
              </button>
              {busy && <div className="video-progress"><div className="video-progress-fill" style={{ width: `${videoProgress}%` }} /></div>}
              {notice && <div className="notice">{notice}</div>}
              {videoResult && <div className="result-panel"><div className="result-head"><strong>Your video</strong><div className="gallery-actions"><button className="download-btn" onClick={() => saveToDevice(videoResult, `pretixbot-video-${duration}s.mp4`)}><Download size={16} /> Save to device</button><button className="secondary-btn" onClick={() => saveToGallery(videoResult, `pretixbot-video-${duration}s.mp4`)}>Save to Photos/Gallery</button></div></div><video className="generated-image" src={videoResult} controls playsInline /><p className="tool-note">You can also find this video in My Gallery.</p><button className="secondary-btn" onClick={() => setMode('gallery')}>Open My Gallery</button></div>
            }</div>
            <div className="tool-note">
              Text-only requests use a generated starting image before animation; uploaded photos can still be used instead. This depends on two external services, so a provider outage or fair-use limit can still prevent a video from being created. Save the MP4 to your device because remote video links may not remain available forever.
            </div>
          </section>
        )}
        <footer className="footer">
          <span>pretixbot</span>
          <span>
            Built for curious minds <span className="footer-star">✦</span>
          </span>
        </footer>
      </main>
    </div>
  );
}

export default App;
