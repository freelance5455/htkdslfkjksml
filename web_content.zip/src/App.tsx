import { useState, useEffect } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { StartScreen } from './components/StartScreen';
import { VictoryModal } from './components/VictoryModal';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { HighScoresModal } from './components/HighScoresModal';
import { LandscapeNotice } from './components/LandscapeNotice';
import { GameDifficulty, GameState, GameStats, HighScoreRecord } from './types/game';

const HIGH_SCORES_KEY = 'chasing_chicken_high_scores_v1';

export function App() {
  const [gameState, setGameState] = useState<GameState>('menu');
  const [difficulty, setDifficulty] = useState<GameDifficulty>('normal');
  const [finalStats, setFinalStats] = useState<GameStats>({
    timeElapsed: 0,
    chaseCount: 0,
    hidesUsed: 0,
    laddersUsed: 0,
    crystalsCollected: 0,
    totalCrystals: 3,
    difficulty: 'normal',
    score: 0,
  });

  const [isPaused, setIsPaused] = useState(false);
  const [showHowToPlay, setShowHowToPlay] = useState(false);
  const [showHighScores, setShowHighScores] = useState(false);
  const [highScores, setHighScores] = useState<HighScoreRecord[]>([]);
  const [gameKey, setGameKey] = useState<number>(1); // used to force fresh game instance

  // Load high scores
  useEffect(() => {
    try {
      const saved = localStorage.getItem(HIGH_SCORES_KEY);
      if (saved) {
        setHighScores(JSON.parse(saved));
      }
    } catch {
      // Ignore local storage error
    }
  }, []);

  const saveHighScore = (stats: GameStats) => {
    try {
      const newRecord: HighScoreRecord = {
        id: `${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        timeSeconds: stats.timeElapsed,
        difficulty: stats.difficulty,
        score: stats.score,
      };

      const updated = [...highScores, newRecord]
        .sort((a, b) => b.score - a.score)
        .slice(0, 10);

      setHighScores(updated);
      localStorage.setItem(HIGH_SCORES_KEY, JSON.stringify(updated));
    } catch {
      // Local storage fallback
    }
  };

  const handleClearHighScores = () => {
    setHighScores([]);
    try {
      localStorage.removeItem(HIGH_SCORES_KEY);
    } catch {
      // Fallback
    }
  };

  const handleStartGame = (selectedDiff: GameDifficulty) => {
    setDifficulty(selectedDiff);
    setGameState('playing');
    setIsPaused(false);
    setGameKey((prev) => prev + 1);
  };

  const handleReplay = () => {
    setGameState('playing');
    setIsPaused(false);
    setGameKey((prev) => prev + 1);
  };

  const handleRetry = () => {
    setGameState('playing');
    setIsPaused(false);
    setGameKey((prev) => prev + 1);
  };

  const handleGameOver = (stats: GameStats) => {
    setFinalStats(stats);
    setGameState('gameover');
  };

  const handleVictory = (stats: GameStats) => {
    setFinalStats(stats);
    setGameState('victory');
    saveHighScore(stats);
  };

  const handleTogglePause = () => {
    if (gameState === 'playing') {
      setIsPaused((prev) => !prev);
    }
  };

  return (
    <main className="w-screen h-screen bg-[#060911] flex flex-col items-center justify-center p-0 m-0 select-none overflow-hidden relative">
      <LandscapeNotice />

      {/* Main Full-Screen Portrait 9:16 Game Container */}
      <div className="relative w-full h-full max-w-[calc(100vh*9/16)] max-h-screen aspect-[9/16] flex items-center justify-center shadow-2xl overflow-hidden bg-slate-950 border-0 sm:border sm:border-slate-800/80">
        {/* Active Game Canvas (always mounts fresh when gameKey changes) */}
        {gameState !== 'menu' && (
          <GameCanvas
            key={gameKey}
            difficulty={difficulty}
            isPaused={isPaused}
            onGameOver={handleGameOver}
            onVictory={handleVictory}
            onTogglePause={handleTogglePause}
          />
        )}

        {/* Start Screen Menu */}
        {gameState === 'menu' && (
          <StartScreen
            onStart={handleStartGame}
            selectedDifficulty={difficulty}
            onSelectDifficulty={setDifficulty}
            onOpenHowToPlay={() => setShowHowToPlay(true)}
            onOpenHighScores={() => setShowHighScores(true)}
          />
        )}

        {/* Victory Modal */}
        {gameState === 'victory' && (
          <VictoryModal
            stats={finalStats}
            onReplay={handleReplay}
            onBackToMenu={() => setGameState('menu')}
          />
        )}

        {/* Game Over Modal */}
        {gameState === 'gameover' && (
          <GameOverModal
            stats={finalStats}
            onRetry={handleRetry}
            onBackToMenu={() => setGameState('menu')}
          />
        )}

        {/* Pause Modal */}
        {isPaused && gameState === 'playing' && (
          <PauseModal
            onResume={() => setIsPaused(false)}
            onRestart={handleRetry}
            onMainMenu={() => {
              setIsPaused(false);
              setGameState('menu');
            }}
          />
        )}

        {/* How to Play Overlay */}
        {showHowToPlay && (
          <HowToPlayModal onClose={() => setShowHowToPlay(false)} />
        )}

        {/* High Scores Overlay */}
        {showHighScores && (
          <HighScoresModal
            scores={highScores}
            onClose={() => setShowHighScores(false)}
            onClear={handleClearHighScores}
          />
        )}
      </div>
    </main>
  );
}

export default App;
