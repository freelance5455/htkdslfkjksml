/**
 * JARVIS AI - TELEFONNI 100% BOSHQARISH BILAN SHAXSIY YORDAMCHI
 * Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
 * Server: Express CORS-Free Proxy + Groq LLaMA 3.3 70B (5 ta kalit) + Gemini Fallback
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Send,
  Camera,
  Flashlight,
  Settings,
  Code,
  Download,
  Volume2,
  MapPin,
  Vibrate,
  Eye,
  CheckCircle2,
  ShieldAlert,
  ShieldCheck,
  Lock,
  Unlock,
  AlertTriangle,
  Sparkles,
  Radio,
} from 'lucide-react';
import { SystemHud } from './components/SystemHud';
import { JarvisCore } from './components/JarvisCore';
import { CameraModal } from './components/CameraModal';
import { TorchOverlay } from './components/TorchOverlay';
import { SettingsModal } from './components/SettingsModal';
import { CodeViewerModal } from './components/CodeViewerModal';
import { PermissionsBanner } from './components/PermissionsBanner';
import { groqService, ChatMessage } from './services/groqService';
import { deviceService, DeviceActionType } from './services/deviceService';
import { voiceHistoryService } from './services/voiceHistoryService';
import { downloadJarvisFullZip } from './services/zipExporter';

export default function App() {
  // Ruxsatlar holati (Ilova ishga tushishi bilan so'raladi va funksiyalarni band qiladi)
  const [isPermissionsGranted, setIsPermissionsGranted] = useState<boolean>(false);
  const [permissionsDetail, setPermissionsDetail] = useState<{
    mic: boolean;
    camera: boolean;
    gps: boolean;
  }>({ mic: false, camera: false, gps: false });
  const [isRequestingPermissions, setIsRequestingPermissions] = useState<boolean>(false);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  // Chat va tizim holatlari
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content:
        'Assalomu alaykum, Sir! Men sizning shaxsiy sun\'iy intellekt yordamchingiz Jarvisman. Telefoningiz datchiklari (Mikrofon, Kamera, Chiroq, GPS, Vibratsiya) va sun\'iy intellekt tizimi to\'liq quvvatda xizmatingizda. Qanday buyruq berasiz, Sir?',
      timestamp: new Date(),
      keyIndexUsed: 1,
      durationMs: 80,
      engineUsed: 'Jarvis Core',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [coreStatus, setCoreStatus] = useState<'idle' | 'listening' | 'speaking' | 'thinking'>('idle');
  const [isTTSActive, setIsTTSActive] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [isContinuousMode, setIsContinuousMode] = useState(false);
  const [activeKeyIndex, setActiveKeyIndex] = useState(0);

  // Modallar va datchiklar holati
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCodeViewerOpen, setIsCodeViewerOpen] = useState(false);
  const [isTorchActive, setIsTorchActive] = useState(false);
  const [isHardwareTorch, setIsHardwareTorch] = useState(true);
  const [isWakeLockActive, setIsWakeLockActive] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  /**
   * RASMIY ANDROID/WEB RUXSATLARINI SO'RASH VA FUNKSIYALARNI BOSHQARISH FUNKSIYASI
   * Ilova ochilishi bilanoq avtomatik chaqiriladi.
   * Mikrofon va Kamera ruxsatlari olinmaguncha barcha funksiyalar band qilinadi.
   */
  const requestPermissions = async (): Promise<boolean> => {
    setIsRequestingPermissions(true);
    setPermissionError(null);

    const status = { mic: false, camera: false, gps: false };

    try {
      // 1. Mikrofon uchun rasmiy ruxsatni so'rash
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          status.mic = true;
          audioStream.getTracks().forEach((track) => track.stop());
        } catch (audioErr: any) {
          console.warn("Mikrofon ruxsati berilmadi:", audioErr);
          status.mic = false;
        }

        // 2. Kamera uchun rasmiy ruxsatni so'rash
        try {
          const videoStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' },
          });
          status.camera = true;
          videoStream.getTracks().forEach((track) => track.stop());
        } catch (videoErr: any) {
          console.warn("Kamera ruxsati berilmadi:", videoErr);
          status.camera = false;
        }
      }

      // 3. GPS / Joylashuv ruxsati (Ixtiyoriy qo'shimcha datchik)
      try {
        if ('geolocation' in navigator) {
          await new Promise((resolve) => {
            navigator.geolocation.getCurrentPosition(
              () => {
                status.gps = true;
                resolve(true);
              },
              () => {
                status.gps = false;
                resolve(false);
              },
              { timeout: 3500 }
            );
          });
        }
      } catch (gpsErr) {
        status.gps = false;
      }

      setPermissionsDetail(status);

      // Agar mikrofon yoki kamera ruxsatlari olingan bo'lsa
      if (status.mic || status.camera) {
        setIsPermissionsGranted(true);
        deviceService.vibrate([150, 70, 150]);
        showToast("Ruxsatlar muvaffaqiyatli berildi, Sir! Tizim faollashtirildi.");

        if (isTTSActive) {
          deviceService.speak("Barcha tizim ruxsatlari muvaffaqiyatli faollashtirildi, Sir. Jarvis to'liq xizmatingizda!");
        }
        return true;
      } else {
        setIsPermissionsGranted(false);
        setPermissionError("Mikrofon va kamera ruxsatlari berilmadi, Sir. Iltimos brauzer ruxsat oynasidan 'Ruxsat berish' (Allow) tugmasini bosing.");
        return false;
      }
    } catch (generalErr: any) {
      console.error("Ruxsat so'rashda xatolik:", generalErr);
      setPermissionError(generalErr.message || "Tizim ruxsatlarini olishda xatolik yuz berdi.");
      setIsPermissionsGranted(false);
      return false;
    } finally {
      setIsRequestingPermissions(false);
    }
  };

  // ILOVA ISHGA TUSHISHI BILAN AVTOMATIK RUXSAT SO'ROVI
  useEffect(() => {
    requestPermissions();
  }, []);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, coreStatus]);

  const showToast = (text: string) => {
    setToastMessage(text);
    setTimeout(() => setToastMessage(null), 3500);
  };

  /**
   * Qurilma buyruqlarini bajarish
   */
  const executeDeviceAction = async (action: DeviceActionType, confirmationText: string) => {
    if (!isPermissionsGranted) {
      showToast("Avval mikrofon va kamera ruxsatlarini berishingiz kerak, Sir!");
      return;
    }

    deviceService.vibrate(80);
    let extraDetail = '';

    switch (action) {
      case 'open_camera':
      case 'take_photo':
        setIsCameraOpen(true);
        break;

      case 'turn_on_torch':
        const onRes = await deviceService.toggleTorch(true);
        setIsTorchActive(true);
        setIsHardwareTorch(onRes.isHardware);
        break;

      case 'turn_off_torch':
        await deviceService.toggleTorch(false);
        setIsTorchActive(false);
        break;

      case 'vibrate_device':
        deviceService.vibrate([200, 100, 200, 100, 300]);
        extraDetail = " (Vibratsiya ishga tushirildi)";
        break;

      case 'get_gps_location':
        try {
          const loc = await deviceService.getGeolocation();
          extraDetail = `\n📍 Sizning koordinatalaringiz: ${loc.text}\n🗺️ Google Xaritalar: https://www.google.com/maps?q=${loc.latitude},${loc.longitude}`;
        } catch (e: any) {
          extraDetail = `\n⚠️ GPS xatosi: ${e.message}`;
        }
        break;

      case 'make_call':
        deviceService.makePhoneCall('');
        extraDetail = " (Telefon terish ochildi)";
        break;

      case 'wake_lock':
        const wl = await deviceService.setWakeLock(!isWakeLockActive);
        setIsWakeLockActive(wl);
        extraDetail = wl ? " (Ekran doim yoniq turadi)" : " (Ekran odatiy rejimga qaytdi)";
        break;

      case 'start_continuous':
        await startContinuousMode();
        break;

      case 'stop_continuous':
        stopContinuousMode();
        break;

      case 'open_settings':
        setIsSettingsOpen(true);
        break;

      case 'open_code_viewer':
        setIsCodeViewerOpen(true);
        break;

      case 'download_zip':
        handleDownloadZip();
        break;

      case 'system_status':
        const hw = deviceService.getHardwareInfo();
        const bat = await deviceService.getBatteryInfo();
        extraDetail = `\n🔋 Batareya: ${bat ? `${bat.level}% (${bat.charging ? 'Zaryadlanmoqda' : 'Avtonom'})` : 'Aniqlanmadi'}\n📱 Ekran: ${hw.screenResolution}\n⚙️ CPU: ${hw.cpuCores || '8'} yadro\n🌐 Tarmoq: ${hw.online ? 'Online' : 'Offline'}`;
        break;

      default:
        break;
    }

    const fullText = confirmationText + extraDetail;

    const assistantMsg: ChatMessage = {
      id: `action-${Date.now()}`,
      role: 'assistant',
      content: fullText,
      timestamp: new Date(),
      actionTriggered: action,
    };
    setMessages((prev) => [...prev, assistantMsg]);

    if (isTTSActive) {
      setCoreStatus('speaking');
      deviceService.speak(fullText, () => {
        if (deviceService.getIsContinuousListening()) {
          setCoreStatus('listening');
        } else {
          setCoreStatus('idle');
        }
      });
    }
  };

  /**
   * Xabar yuborish
   */
  const handleSendMessage = async (textToSend?: string) => {
    if (!isPermissionsGranted) {
      showToast("Funksiyalar bloklangan. Iltimos avval ruxsat bering, Sir!");
      return;
    }

    const text = (textToSend || inputPrompt).trim();
    if (!text || coreStatus === 'thinking') return;

    setInputPrompt('');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);

    const { action, confirmationText } = deviceService.parseDeviceCommand(text);

    // Ovozli / matnli buyruqni lokal xotira (localStorage) tarixiga yozish
    voiceHistoryService.addCommand(text, action !== 'none' ? action : undefined);

    if (action !== 'none') {
      await executeDeviceAction(action, confirmationText);
      return;
    }

    setCoreStatus('thinking');

    try {
      const history = messages.slice(-6).map((m) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      }));

      const res = await groqService.sendMessage(text, history);

      setActiveKeyIndex(res.keyIndexUsed - 1);
      deviceService.vibrate(60);

      const assistantMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: res.content,
        timestamp: new Date(),
        keyIndexUsed: res.keyIndexUsed,
        durationMs: res.durationMs,
        engineUsed: res.engine,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      if (isTTSActive) {
        setCoreStatus('speaking');
        deviceService.speak(res.content, () => {
          if (deviceService.getIsContinuousListening()) {
            setCoreStatus('listening');
          } else {
            setCoreStatus('idle');
          }
        });
      } else {
        if (deviceService.getIsContinuousListening()) {
          setCoreStatus('listening');
        } else {
          setCoreStatus('idle');
        }
      }
    } catch (err: any) {
      console.error("Xatolik:", err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: `Sir, so'rovni bajarishda uzilish bo'ldi: ${err.message || "AI server javob bermadi"}.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMsg]);
      
      if (deviceService.getIsContinuousListening()) {
        setCoreStatus('listening');
      } else {
        setCoreStatus('idle');
      }

      if (isTTSActive) {
        deviceService.speak(errorMsg.content);
      }
    }
  };

  /**
   * DOIMIY TINGLASH REJIMI (Continuous / Hands-Free Mode)
   * Mikrofon to'xtovsiz ishlaydi va har bir aytilgan gapni avtomatik ravishda Jarvisga jo'natadi.
   */
  const startContinuousMode = async () => {
    if (!isPermissionsGranted) {
      const ok = await requestPermissions();
      if (!ok) return;
    }

    if (isListening) {
      deviceService.stopListening();
      setIsListening(false);
    }

    setIsContinuousMode(true);
    setCoreStatus('listening');
    showToast("Doimiy tinglash rejimi faollashdi, Sir (Hands-Free)!");

    await deviceService.startContinuousListening(
      (transcript, isFinal) => {
        setInputPrompt(transcript);
        if (isFinal && transcript.trim().length > 1) {
          handleSendMessage(transcript.trim());
        }
      },
      (error) => {
        showToast(error);
        setIsContinuousMode(false);
        setCoreStatus('idle');
      }
    );
  };

  const stopContinuousMode = () => {
    deviceService.stopContinuousListening();
    setIsContinuousMode(false);
    setCoreStatus('idle');
    showToast("Doimiy tinglash to'xtatildi, Sir.");
  };

  const handleToggleContinuousMode = async () => {
    if (isContinuousMode) {
      stopContinuousMode();
    } else {
      await startContinuousMode();
    }
  };

  /**
   * Ovozli yozib olish (Mikrofon - bittalik buyruq yoki doimiy rejimni o'chirish)
   */
  const handleToggleVoice = async () => {
    if (!isPermissionsGranted) {
      requestPermissions();
      return;
    }

    // Agar doimiy tinglash faol bo'lsa, mikrofon tugmasi orqali to'xtatish
    if (isContinuousMode) {
      stopContinuousMode();
      return;
    }

    if (isListening) {
      deviceService.stopListening();
      setIsListening(false);
      setCoreStatus('idle');
    } else {
      setIsListening(true);
      setCoreStatus('listening');

      await deviceService.startListening(
        (transcript, isFinal) => {
          setInputPrompt(transcript);
          if (isFinal) {
            handleSendMessage(transcript);
          }
        },
        (error) => {
          showToast(error);
          setIsListening(false);
          setCoreStatus('idle');
        },
        () => {
          setIsListening(false);
          if (coreStatus === 'listening') {
            setCoreStatus('idle');
          }
        }
      );
    }
  };

  /**
   * Chiroqni yoqish / o'chirish
   */
  const handleToggleTorch = async () => {
    if (!isPermissionsGranted) {
      requestPermissions();
      return;
    }
    const res = await deviceService.toggleTorch();
    setIsTorchActive(res.newState);
    setIsHardwareTorch(res.isHardware);
    showToast(res.newState ? "Chiroq yoqildi, Sir" : "Chiroq o'chirildi, Sir");
  };

  /**
   * ZIP arxiv yuklab olish
   */
  const handleDownloadZip = async () => {
    showToast("ZIP to'plami tayyorlanmoqda, Sir...");
    const ok = await downloadJarvisFullZip();
    if (ok) {
      showToast("jarvis-ai-muhammadrizo-full-source.zip yuklandi!");
    } else {
      showToast("ZIP yuklashda xatolik yuz berdi");
    }
  };

  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-100 overflow-hidden font-sans select-none relative">
      {/* 1. Yuqori HUD Paneli */}
      <SystemHud
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenCodeViewer={() => setIsCodeViewerOpen(true)}
        onDownloadZip={handleDownloadZip}
        activeKeyIndex={activeKeyIndex}
      />

      {/* Ruxsatlar Banneri (Ruxsat holati ko'rsatkichi) */}
      <PermissionsBanner
        onPermissionGranted={() => {
          setIsPermissionsGranted(true);
          showToast("Barcha ruxsatlar faollashtirildi, Sir!");
        }}
      />

      {/* Ekran Chirog'i (Torch Overlay) */}
      <TorchOverlay
        isActive={isTorchActive}
        onTurnOff={() => {
          deviceService.toggleTorch(false);
          setIsTorchActive(false);
        }}
        isHardware={isHardwareTorch}
      />

      {/* =========================================================================
          RUXSAT BERILMAGUNCHA FUNKSIYALARNI BAND QILUVCHI EKRAN (PERMISSION GATE)
          ========================================================================= */}
      {!isPermissionsGranted && (
        <div className="absolute inset-0 z-40 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-md bg-slate-950 border-2 border-cyan-500/60 rounded-2xl p-6 shadow-[0_0_50px_rgba(6,182,212,0.3)] text-center space-y-5">
            {/* Qulf va Yadro belgisi */}
            <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border border-dashed border-cyan-400 animate-spin-slow" />
              <div className="w-14 h-14 rounded-full bg-cyan-950/80 border border-cyan-400 flex items-center justify-center shadow-[0_0_25px_rgba(6,182,212,0.5)]">
                <Lock className="w-7 h-7 text-cyan-400" />
              </div>
            </div>

            <div>
              <h2 className="font-display text-lg font-bold text-cyan-300 tracking-wider uppercase">
                Xavfsizlik Protokoli // Ruxsatlar Talab Qilinadi
              </h2>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Sir, Jarvis telefoningizning apparat datchiklarini (Mikrofon, Kamera, Chiroq, GPS) to'liq boshqara olishi uchun rasmiy tizim ruxsatlari berilishi shart.
              </p>
            </div>

            {/* Datchiklar holati ro'yxati */}
            <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800 space-y-2 text-left font-mono text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <Mic className="w-4 h-4 text-cyan-400" />
                  <span>Mikrofon datchigi (Ovozli boshqaruv)</span>
                </div>
                <span className={permissionsDetail.mic ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                  {permissionsDetail.mic ? 'RUXSAT BERILDI' : 'KUTILMOQDA'}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <Camera className="w-4 h-4 text-cyan-400" />
                  <span>Optik sensor (Kamera & Chiroq)</span>
                </div>
                <span className={permissionsDetail.camera ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                  {permissionsDetail.camera ? 'RUXSAT BERILDI' : 'KUTILMOQDA'}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <span>GPS / Joylashuv datchigi</span>
                </div>
                <span className={permissionsDetail.gps ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                  {permissionsDetail.gps ? 'RUXSAT BERILDI' : 'IXTIYORIY'}
                </span>
              </div>
            </div>

            {permissionError && (
              <div className="flex items-center gap-2 p-2.5 bg-rose-950/40 border border-rose-500/40 rounded-lg text-rose-300 text-xs text-left">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{permissionError}</span>
              </div>
            )}

            {/* Ruxsat berish asosiy tugmasi */}
            <button
              onClick={requestPermissions}
              disabled={isRequestingPermissions}
              className="w-full py-3.5 px-4 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-display font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-[0_0_25px_rgba(6,182,212,0.5)] disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
            >
              <Unlock className="w-4 h-4" />
              <span>
                {isRequestingPermissions
                  ? "Tizim ruxsatlari so'ralmoqda..."
                  : "Rasmiy Ruxsatlarni Berish (Mikrofon & Kamera)"}
              </span>
            </button>
            <p className="text-[10px] text-slate-500">
              * Tugmani bosganingizda ekranda "Ruxsat berish" (Allow) oynasi chiqadi, Sir.
            </p>
          </div>
        </div>
      )}

      {/* Asosiy Ish Maydoni (Ruxsat berilganda to'liq faol, aks holda band) */}
      <div className={`flex-1 flex flex-col max-w-4xl w-full mx-auto overflow-hidden relative ${!isPermissionsGranted ? 'opacity-30 pointer-events-none' : ''}`}>
        
        {/* Markaziy Reaktiv Yadro (Arc Reactor) va Visualizer */}
        <div className="shrink-0 pt-2 pb-1 border-b border-cyan-500/10 bg-gradient-to-b from-slate-950/40 to-slate-950/90 flex flex-col items-center">
          <JarvisCore status={coreStatus} onCoreClick={handleToggleVoice} />

          {/* Doimiy tinglash indikatori */}
          {isContinuousMode && (
            <div className="mt-1 mb-2 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-500/60 shadow-[0_0_15px_rgba(244,63,94,0.4)] animate-pulse">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              <span className="text-[10px] font-mono font-bold tracking-wider text-rose-300 uppercase">
                DOIMIY TINGLASH FAOL (HANDS-FREE)
              </span>
              <button
                type="button"
                onClick={stopContinuousMode}
                className="text-[10px] px-1.5 py-0.5 rounded bg-rose-900/60 hover:bg-rose-800 text-rose-200 transition-colors cursor-pointer font-sans"
              >
                To'xtatish
              </button>
            </div>
          )}
        </div>

        {/* Chat Xabarlari Oqimi */}
        <main className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} animate-fadeIn`}
              >
                {/* Metadata */}
                <div className="flex items-center gap-2 mb-1 text-[11px] font-mono text-slate-400 px-1">
                  <span className={isUser ? 'text-slate-300 font-semibold' : 'text-cyan-400 font-bold'}>
                    {isUser ? 'Siz (Sir)' : 'Jarvis AI'}
                  </span>
                  <span>·</span>
                  <span>
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {msg.engineUsed && !isUser && (
                    <>
                      <span>·</span>
                      <span className="text-cyan-500 font-mono">{msg.engineUsed}</span>
                    </>
                  )}
                  {msg.keyIndexUsed !== undefined && !isUser && msg.keyIndexUsed < 90 && (
                    <>
                      <span>·</span>
                      <span className="text-cyan-400 font-mono">Kalit #{msg.keyIndexUsed}</span>
                    </>
                  )}
                  {msg.durationMs !== undefined && !isUser && (
                    <>
                      <span>·</span>
                      <span className="text-slate-500 font-mono">{msg.durationMs}ms</span>
                    </>
                  )}
                </div>

                {/* Xabar Tanasi */}
                <div
                  className={`max-w-[85%] sm:max-w-[80%] rounded-xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                    isUser
                      ? 'bg-cyan-600/20 border border-cyan-500/40 text-cyan-50 rounded-tr-none'
                      : 'bg-slate-900/90 border border-cyan-500/30 text-slate-100 rounded-tl-none border-l-2 border-l-cyan-400'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>

                  {/* Ovozli o'qish */}
                  {!isUser && (
                    <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                      <button
                        onClick={() => {
                          setCoreStatus('speaking');
                          deviceService.speak(msg.content, () => setCoreStatus('idle'));
                        }}
                        className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Ovozli eshitish</span>
                      </button>

                      {msg.actionTriggered && (
                        <span className="text-cyan-500 font-mono">
                          Datchik: {msg.actionTriggered}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          <div ref={chatBottomRef} />
        </main>

        {/* Tezkor Qurilma Boshqaruv Tugmalari (100% Telefon Boshqaruvi) */}
        <div className="shrink-0 px-4 py-2 bg-slate-950/80 border-t border-cyan-500/10 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {/* Doimiy tinglash (Hands-Free) tugmasi */}
          <button
            onClick={handleToggleContinuousMode}
            disabled={!isPermissionsGranted}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-all shrink-0 cursor-pointer disabled:opacity-40 ${
              isContinuousMode
                ? 'bg-rose-950/80 border-rose-500 text-rose-200 shadow-[0_0_15px_rgba(244,63,94,0.6)] font-bold'
                : 'bg-slate-900 border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400'
            }`}
            title="Mikrofon doimo ochiq turadi va har bir gapni avtomatik Jarvisga yuboradi"
          >
            <Radio className={`w-3.5 h-3.5 ${isContinuousMode ? 'text-rose-400 animate-pulse' : 'text-cyan-400'}`} />
            <span>{isContinuousMode ? "Doimiy tinglash: FAOL" : "Doimiy tinglash"}</span>
          </button>

          <button
            onClick={() => setIsCameraOpen(true)}
            disabled={!isPermissionsGranted}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400 text-xs transition-colors shrink-0 disabled:opacity-40"
          >
            <Camera className="w-3.5 h-3.5 text-cyan-400" />
            <span>Kamerani och</span>
          </button>

          <button
            onClick={handleToggleTorch}
            disabled={!isPermissionsGranted}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors shrink-0 disabled:opacity-40 ${
              isTorchActive
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-slate-900 border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400'
            }`}
          >
            <Flashlight className="w-3.5 h-3.5 text-amber-400" />
            <span>{isTorchActive ? "Chiroqni o'chirish" : "Chiroqni yoqish"}</span>
          </button>

          <button
            onClick={() => executeDeviceAction('get_gps_location', "GPS orqali joylashuvingiz aniqlandi, Sir.")}
            disabled={!isPermissionsGranted}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400 text-xs transition-colors shrink-0 disabled:opacity-40"
          >
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <span>GPS Joylashuv</span>
          </button>

          <button
            onClick={() => executeDeviceAction('vibrate_device', "Haptik vibratsiya signali berildi, Sir.")}
            disabled={!isPermissionsGranted}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400 text-xs transition-colors shrink-0 disabled:opacity-40"
          >
            <Vibrate className="w-3.5 h-3.5 text-cyan-400" />
            <span>Vibratsiya</span>
          </button>

          <button
            onClick={() => executeDeviceAction('wake_lock', "Ekran rejimi o'zgartirildi, Sir.")}
            disabled={!isPermissionsGranted}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors shrink-0 disabled:opacity-40 ${
              isWakeLockActive
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'bg-slate-900 border-cyan-500/30 text-slate-200 hover:text-cyan-300'
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isWakeLockActive ? "Ekran uyg'oq" : "Ekran o'chmasin"}</span>
          </button>

          <button
            onClick={handleDownloadZip}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400 text-xs transition-colors shrink-0"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>APK uchun ZIP</span>
          </button>

          <button
            onClick={() => setIsCodeViewerOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-slate-200 hover:text-cyan-300 hover:border-cyan-400 text-xs transition-colors shrink-0"
          >
            <Code className="w-3.5 h-3.5 text-cyan-400" />
            <span>server.py kodi</span>
          </button>
        </div>

        {/* Kiritish Paneli (Matnli & Ovozli) */}
        <footer className="shrink-0 p-3 sm:p-4 bg-slate-900/90 border-t border-cyan-500/20 backdrop-blur-md">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            {/* Ovozli tugma (Mikrofon) */}
            <button
              type="button"
              onClick={handleToggleVoice}
              disabled={!isPermissionsGranted}
              className={`p-3 rounded-xl border transition-all shrink-0 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                isListening
                  ? 'bg-rose-600 border-rose-500 text-white animate-pulse shadow-[0_0_25px_rgba(225,29,72,0.9)]'
                  : 'bg-slate-950 border-cyan-500/40 text-cyan-400 hover:bg-slate-800 hover:border-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
              }`}
              title={isListening ? "Tinglashni to'xtatish" : "Ovoz orqali buyruq berish (Mikrofon)"}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Matn maydoni */}
            <div className="relative flex-1">
              <input
                type="text"
                disabled={!isPermissionsGranted}
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                placeholder={
                  isPermissionsGranted
                    ? "Sir, menga buyruq bering ('kamerani och', 'chiroqni yoq', 'gps')..."
                    : "Iltimos avval ruxsat bering, Sir..."
                }
                className="w-full bg-slate-950 border border-cyan-500/30 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-400 focus:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              />
            </div>

            {/* Yuborish tugmasi */}
            <button
              type="submit"
              disabled={!isPermissionsGranted || !inputPrompt.trim() || coreStatus === 'thinking'}
              className="p-3 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 text-slate-950 font-bold rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] shrink-0 cursor-pointer disabled:cursor-not-allowed"
              title="Yuborish"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </footer>
      </div>

      {/* Modallar */}
      <CameraModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onPhotoCaptured={() => {
          showToast("Surat saqlandi, Sir!");
        }}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        isTTSActive={isTTSActive}
        onToggleTTS={(val) => setIsTTSActive(val)}
        isContinuousMode={isContinuousMode}
        onToggleContinuousMode={handleToggleContinuousMode}
        onOpenCodeViewer={() => setIsCodeViewerOpen(true)}
        onDownloadZip={handleDownloadZip}
        onApiKeyUpdated={() => {
          showToast("Yangi API kaliti sozlandi, Sir!");
        }}
        onSelectCommand={(cmd) => {
          handleSendMessage(cmd);
          showToast(`Buyruq bajarilmoqda: "${cmd}"`);
        }}
      />

      <CodeViewerModal
        isOpen={isCodeViewerOpen}
        onClose={() => setIsCodeViewerOpen(false)}
        onDownloadZip={handleDownloadZip}
      />

      {/* Toast Bildirishnoma */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-cyan-950/95 border border-cyan-400 text-cyan-200 px-4 py-2 rounded-xl text-xs font-mono shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
