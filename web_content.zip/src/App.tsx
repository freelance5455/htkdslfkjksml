import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DeviceFrame } from './components/common/DeviceFrame';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { SosModal } from './components/common/SosModal';
import { AuthModal } from './components/common/AuthModal';
import { HomeScreen } from './components/screens/HomeScreen';
import { UserRole } from './types';
import { Smartphone, ShieldAlert, Sparkles, UserCheck, ShieldCheck, Crown } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { role, switchRoleQuickly, setIsSosOpen, setIsAuthOpen } = useApp();

  const roleOptions: { id: UserRole; label: string; icon: string; badge: string }[] = [
    { id: 'customer', label: 'Customer', icon: '🛍️', badge: 'Order & Book' },
    { id: 'provider', label: 'Provider', icon: '👨‍🔧', badge: 'Electrician / Salon' },
    { id: 'delivery', label: 'Delivery', icon: '🛵', badge: 'Rider & Live GPS' },
    { id: 'admin', label: 'Admin', icon: '👑', badge: 'Commission & Rules' }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center py-4 px-2 sm:px-4">
      {/* Top Demo Toolbar: Role Switcher & Branding */}
      <header className="w-full max-w-5xl mb-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-3 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950 font-black text-lg flex items-center justify-center shadow-md">
            A
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-black text-white tracking-wide">AllJi</h1>
              <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.2 rounded-md">
                SUPER APP
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Sab Kuch, Ek Hi Jagah</p>
          </div>
        </div>

        {/* 1-Click Role Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2 hidden sm:inline-block">
            View As:
          </span>
          {roleOptions.map(r => (
            <button
              key={r.id}
              id={`switch-role-${r.id}`}
              onClick={() => switchRoleQuickly(r.id)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                role === r.id
                  ? 'bg-amber-500 text-slate-950 shadow-md font-black scale-102'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <span>{r.icon}</span>
              <span>{r.label}</span>
            </button>
          ))}
        </div>

        {/* Right action shortcuts */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAuthOpen(true)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-400 border border-slate-700 transition-colors flex items-center gap-1"
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Accounts</span>
          </button>

          <button
            onClick={() => setIsSosOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/40 text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-red-500" />
            <span>SOS</span>
          </button>
        </div>
      </header>

      {/* Main Mobile Device Container */}
      <DeviceFrame>
        <div className="relative min-h-full flex flex-col bg-slate-50">
          <Header />
          <main className="flex-1">
            <HomeScreen />
          </main>
          <BottomNav />
        </div>
      </DeviceFrame>

      {/* Global Modals */}
      <SosModal />
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
