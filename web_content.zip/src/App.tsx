import React, { useState, useEffect } from 'react';
import { GlassHeader } from './components/GlassHeader';
import { PipelineStatus, PipelineStep } from './components/PipelineStatus';
import { InputScreen } from './components/InputScreen';
import { ScriptStudio } from './components/ScriptStudio';
import { VideoPlayerPreview } from './components/VideoPlayerPreview';
import { SavedAdsDrawer } from './components/SavedAdsDrawer';
import { ProductInput, UgcAdProject, SearchInsights, UgcScript } from './types';
import { auth, db, handleFirestoreError, OperationType, testConnection } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, onSnapshot, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { ArrowLeft, Sparkles, Video, RefreshCw } from 'lucide-react';
import { PRESET_PRODUCTS } from './data/presets';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [pipelineStep, setPipelineStep] = useState<PipelineStep>('idle');
  const [pipelineError, setPipelineError] = useState<string | null>(null);
  const [currentProject, setCurrentProject] = useState<UgcAdProject | null>(null);
  const [voiceName, setVoiceName] = useState<string>('Kore');
  const [avatarType, setAvatarType] = useState<string>('maya_genz');
  const [isRegenerating, setIsRegenerating] = useState<boolean>(false);
  const [isVoicing, setIsVoicing] = useState<boolean>(false);
  const [savedAds, setSavedAds] = useState<UgcAdProject[]>([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [activeView, setActiveView] = useState<'create' | 'studio'>('create');

  // Test connection to Firestore on mount
  useEffect(() => {
    testConnection();
  }, []);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // Load Saved Ads from Firestore if authenticated
  useEffect(() => {
    if (!user) {
      // Fallback local storage
      try {
        const local = localStorage.getItem('ugc_saved_ads');
        if (local) setSavedAds(JSON.parse(local));
      } catch (e) {
        // ignore
      }
      return;
    }

    const path = `users/${user.uid}/ads`;
    const unsubscribe = onSnapshot(
      collection(db, 'users', user.uid, 'ads'),
      (snapshot) => {
        const ads: UgcAdProject[] = [];
        snapshot.forEach((d) => {
          ads.push(d.data() as UgcAdProject);
        });
        setSavedAds(ads.sort((a, b) => b.createdAt - a.createdAt));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, path);
      }
    );

    return () => unsubscribe();
  }, [user]);

  // Helper to persist ad to Firestore
  const persistAd = async (ad: UgcAdProject) => {
    // Local backup
    try {
      const existing = JSON.parse(localStorage.getItem('ugc_saved_ads') || '[]');
      const filtered = existing.filter((item: UgcAdProject) => item.id !== ad.id);
      localStorage.setItem('ugc_saved_ads', JSON.stringify([ad, ...filtered]));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }

    if (!user) return;
    const path = `users/${user.uid}/ads/${ad.id}`;
    try {
      await setDoc(doc(db, 'users', user.uid, 'ads', ad.id), {
        id: ad.id,
        userId: user.uid,
        productName: ad.productName,
        productUrl: ad.productUrl || '',
        category: ad.category,
        productImage: ad.productImage || '',
        searchInsights: ad.searchInsights,
        script: ad.script,
        voiceName: ad.voiceName,
        avatarType: ad.avatarType,
        audioBase64: ad.audioBase64 || '',
        status: ad.status,
        scriptHook: ad.script.hook.verbal,
        scriptDemo: ad.script.demo.verbal,
        scriptCta: ad.script.cta.verbal,
        createdAt: ad.createdAt,
        updatedAt: Date.now(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  // Delete Ad
  const handleDeleteAd = async (adId: string) => {
    // Update local state
    setSavedAds((prev) => prev.filter((a) => a.id !== adId));
    try {
      const existing = JSON.parse(localStorage.getItem('ugc_saved_ads') || '[]');
      localStorage.setItem(
        'ugc_saved_ads',
        JSON.stringify(existing.filter((a: UgcAdProject) => a.id !== adId))
      );
    } catch (e) {}

    if (user) {
      const path = `users/${user.uid}/ads/${adId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'ads', adId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, path);
      }
    }
  };

  // Main Multi-Agent Generation Workflow
  const handleGenerateAd = async (input: ProductInput) => {
    try {
      setPipelineError(null);
      setActiveView('create');

      // STAGE 1: Search & Scrape Engine (Search Grounding)
      setPipelineStep('grounding');
      const groundRes = await fetch('/api/search-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: input.name,
          productUrl: input.url,
          category: input.category,
        }),
      });

      if (!groundRes.ok) {
        const errData = await groundRes.json();
        throw new Error(errData.error || 'Failed to search product online');
      }

      const insights: SearchInsights = await groundRes.json();

      // STAGE 2: UGC Script & 16-Second Pacing Generator
      setPipelineStep('scripting');
      const scriptRes = await fetch('/api/generate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: insights.productName || input.name,
          brand: insights.brand,
          hookStyle: input.hookStyle,
          persona: input.persona,
          tone: input.tone,
          benefits: insights.keyBenefits,
          targetAudience: insights.targetAudience,
          offer: input.offer,
        }),
      });

      if (!scriptRes.ok) {
        const errData = await scriptRes.json();
        throw new Error(errData.error || 'Failed to generate 16s UGC script');
      }

      const script: UgcScript = await scriptRes.json();

      // STAGE 3: Realistic Narrator Audio using Gemini TTS
      setPipelineStep('voicing');
      const chosenVoice = voiceName || script.avatarRecommendation?.suggestedVoice || 'Kore';
      let audioBase64 = '';

      try {
        const ttsRes = await fetch('/api/generate-tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: script.fullScript,
            voiceName: chosenVoice,
            style: 'Energetic, fast-paced TikTok viral creator selling e-commerce product',
          }),
        });

        if (ttsRes.ok) {
          const ttsData = await ttsRes.json();
          audioBase64 = ttsData.audioBase64;
        }
      } catch (ttsErr) {
        console.warn('TTS step warning:', ttsErr);
      }

      // STAGE 4: 9:16 Video Synthesis & Compositor
      setPipelineStep('synthesizing');

      // Build product image: use uploaded image, or preset image, or fallback
      const prodImg =
        input.images?.[0] ||
        PRESET_PRODUCTS.find((p) => p.name === input.name)?.imageUrl ||
        'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=720&q=80';

      const projectId = `ugc_${Date.now()}`;
      const project: UgcAdProject = {
        id: projectId,
        userId: user?.uid || 'guest',
        productName: insights.productName || input.name,
        productUrl: input.url,
        category: input.category,
        productImage: prodImg,
        searchInsights: insights,
        script: script,
        voiceName: chosenVoice,
        avatarType: avatarType,
        audioBase64: audioBase64,
        status: 'ready',
        createdAt: Date.now(),
      };

      setCurrentProject(project);
      persistAd(project);

      setPipelineStep('completed');
      setActiveView('studio');
    } catch (err: any) {
      console.error('Generation pipeline error:', err);
      setPipelineError(err.message || 'Error occurred during generation');
      setPipelineStep('error');
    }
  };

  // Re-generate script with different angle
  const handleRegenerateScript = async () => {
    if (!currentProject) return;
    try {
      setIsRegenerating(true);
      const res = await fetch('/api/generate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: currentProject.productName,
          brand: currentProject.searchInsights.brand,
          hookStyle: 'Curiosity Secret',
          persona: 'High-energy creator',
          benefits: currentProject.searchInsights.keyBenefits,
          targetAudience: currentProject.searchInsights.targetAudience,
        }),
      });

      if (res.ok) {
        const newScript: UgcScript = await res.json();
        // Automatically re-synthesize TTS for new script
        const ttsRes = await fetch('/api/generate-tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: newScript.fullScript,
            voiceName: voiceName,
          }),
        });

        let newAudio = currentProject.audioBase64;
        if (ttsRes.ok) {
          const ttsData = await ttsRes.json();
          newAudio = ttsData.audioBase64;
        }

        const updated = {
          ...currentProject,
          script: newScript,
          audioBase64: newAudio,
        };
        setCurrentProject(updated);
        persistAd(updated);
      }
    } catch (err) {
      console.error('Regenerate script error:', err);
    } finally {
      setIsRegenerating(false);
    }
  };

  // Re-synthesize voice
  const handleResynthesizeVoice = async (customText?: string) => {
    if (!currentProject) return;
    try {
      setIsVoicing(true);
      const textToVoice = customText || currentProject.script.fullScript;
      const res = await fetch('/api/generate-tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToVoice,
          voiceName: voiceName,
          style: 'Excited, punchy TikTok creator',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const updated = {
          ...currentProject,
          voiceName: voiceName,
          audioBase64: data.audioBase64,
        };
        setCurrentProject(updated);
        persistAd(updated);
      }
    } catch (err) {
      console.error('Resynthesize voice error:', err);
    } finally {
      setIsVoicing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080811] text-slate-100 flex flex-col selection:bg-cyan-500/30">
      {/* Header with Android status bar, Branding & Firebase Google Auth */}
      <GlassHeader
        onOpenSaved={() => setIsDrawerOpen(true)}
        savedCount={savedAds.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:py-8 space-y-6">
        {/* Pipeline Status Indicator (When active) */}
        <PipelineStatus currentStep={pipelineStep} error={pipelineError} />

        {/* View Switcher / Breadcrumb if an ad is ready */}
        {currentProject && (
          <div className="flex items-center justify-between pb-2">
            <button
              onClick={() => setActiveView(activeView === 'create' ? 'studio' : 'create')}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-xs font-semibold text-slate-300 border border-white/10 transition-all active:scale-95"
            >
              {activeView === 'studio' ? (
                <>
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Create Another Ad</span>
                </>
              ) : (
                <>
                  <Video className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Return to Studio: {currentProject.productName}</span>
                </>
              )}
            </button>

            <span className="text-xs text-slate-400 font-mono hidden sm:inline">
              Active Project: <span className="text-cyan-300 font-bold">{currentProject.productName}</span>
            </span>
          </div>
        )}

        {/* VIEW 1: Input Screen (Create Mode) */}
        {activeView === 'create' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-8">
              <InputScreen
                onSubmit={handleGenerateAd}
                isLoading={pipelineStep !== 'idle' && pipelineStep !== 'completed' && pipelineStep !== 'error'}
              />
            </div>

            {/* Side Preview / Explainer Card */}
            <div className="lg:col-span-4 space-y-4">
              <div className="glass-panel rounded-3xl p-5 border border-white/10">
                <div className="flex items-center gap-2 mb-3">
                  <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Why 16-Second Ads?</h3>
                    <p className="text-[11px] text-slate-400">Optimized for TikTok & Reels Algorithms</p>
                  </div>
                </div>

                <div className="space-y-3 text-xs text-slate-300">
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
                    <p className="font-bold text-amber-300">0 - 3s: Visual & Verbal Hook</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Pattern interrupt to stop mindless scrolling. Curated via Gemini Search Grounding.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                    <p className="font-bold text-cyan-300">3 - 12s: Fast-Paced Demo</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Shows the product in action, highlights 2 key benefits, solves viewer frustration.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                    <p className="font-bold text-emerald-300">12 - 16s: Urgency & CTA</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Discount codes, limited stock urgency, and clear tap-to-buy directions.
                    </p>
                  </div>
                </div>
              </div>

              {/* Engine Badge */}
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06] text-center">
                <p className="text-[11px] text-slate-400">
                  Powered by <span className="text-slate-200 font-semibold">Gemini 3.8 Search Grounding</span> &{' '}
                  <span className="text-pink-300 font-semibold">gemini-3.8-flash-tts</span>
                </p>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: Studio & 9:16 Video Player Preview Mode */}
        {activeView === 'studio' && currentProject && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Script Editor, TTS Voices, Avatars */}
            <div className="lg:col-span-7">
              <ScriptStudio
                script={currentProject.script}
                insights={currentProject.searchInsights}
                voiceName={voiceName}
                avatarType={avatarType}
                onVoiceChange={(v) => {
                  setVoiceName(v);
                  // Resynthesize voice automatically
                  setTimeout(() => handleResynthesizeVoice(), 50);
                }}
                onAvatarChange={(a) => {
                  setAvatarType(a);
                  setCurrentProject({ ...currentProject, avatarType: a });
                }}
                onRegenerateScript={handleRegenerateScript}
                onResynthesizeVoice={handleResynthesizeVoice}
                isRegenerating={isRegenerating}
                isVoicing={isVoicing}
                onScriptUpdate={(newScript) => {
                  const updated = { ...currentProject, script: newScript };
                  setCurrentProject(updated);
                  persistAd(updated);
                }}
              />
            </div>

            {/* Right Column: 9:16 Vertical Video Player Preview & Export */}
            <div className="lg:col-span-5 sticky top-20">
              <VideoPlayerPreview
                script={currentProject.script}
                insights={currentProject.searchInsights}
                productImage={currentProject.productImage}
                avatarType={avatarType}
                audioBase64={currentProject.audioBase64}
                onRegenerateScript={handleRegenerateScript}
                isRegenerating={isRegenerating}
              />
            </div>
          </div>
        )}
      </main>

      {/* Saved Ads Drawer (Firestore Persistent Storage) */}
      <SavedAdsDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        savedAds={savedAds}
        user={user}
        onSelectAd={(ad) => {
          setCurrentProject(ad);
          setVoiceName(ad.voiceName);
          setAvatarType(ad.avatarType);
          setActiveView('studio');
        }}
        onDeleteAd={handleDeleteAd}
      />
    </div>
  );
}
