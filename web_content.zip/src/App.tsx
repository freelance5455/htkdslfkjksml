import React, { useState } from 'react';
import { GameProvider, useGame } from './context/GameContext.tsx';
import { TopHUD } from './components/TopHUD.tsx';
import { NavCollapsible } from './components/NavCollapsible.tsx';
import { Zone1Field } from './components/Zone1Field.tsx';
import { Zone2Coop } from './components/Zone2Coop.tsx';
import { Zone3Pond } from './components/Zone3Pond.tsx';
import { Zone4Orchard } from './components/Zone4Orchard.tsx';
import { Zone5BreedingLab } from './components/Zone5BreedingLab.tsx';
import { Zone6Workshop } from './components/Zone6Workshop.tsx';
import { Zone7Port } from './components/Zone7Port.tsx';
import { InventoryModal } from './components/InventoryModal.tsx';
import { AlmanacModal } from './components/AlmanacModal.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { LevelUpModal } from './components/LevelUpModal.tsx';
import { OfflineReportModal } from './components/OfflineReportModal.tsx';

const GameMain: React.FC = () => {
  const { activeZone } = useGame();

  const [inventoryOpen, setInventoryOpen] = useState(false);
  const [almanacOpen, setAlmanacOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col selection:bg-amber-500 selection:text-stone-950">
      {/* 1. Top HUD Fixed */}
      <TopHUD
        onOpenInventory={() => setInventoryOpen(true)}
        onOpenAlmanac={() => setAlmanacOpen(true)}
        onOpenSettings={() => setSettingsOpen(true)}
      />

      {/* 2. Collapsible 7-Zone Navigation */}
      <NavCollapsible />

      {/* 3. Main Play Area with 120px Bottom Padding */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 pb-[120px]">
        {activeZone === 1 && <Zone1Field />}
        {activeZone === 2 && <Zone2Coop />}
        {activeZone === 3 && <Zone3Pond />}
        {activeZone === 4 && <Zone4Orchard />}
        {activeZone === 5 && <Zone5BreedingLab />}
        {activeZone === 6 && <Zone6Workshop />}
        {activeZone === 7 && <Zone7Port />}
      </main>

      {/* Modals */}
      <InventoryModal isOpen={inventoryOpen} onClose={() => setInventoryOpen(false)} />
      <AlmanacModal isOpen={almanacOpen} onClose={() => setAlmanacOpen(false)} />
      <SettingsModal isOpen={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <LevelUpModal />
      <OfflineReportModal />
    </div>
  );
};

export default function App() {
  return (
    <GameProvider>
      <GameMain />
    </GameProvider>
  );
}
