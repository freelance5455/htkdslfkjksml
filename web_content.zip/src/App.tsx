/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header, ChatMode } from './components/Header';
import { ChatMessage, Message } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { EmptyState } from './components/EmptyState';
import { Sidebar, ChatSession } from './components/Sidebar';
import { playSound } from './utils/soundEffects';

const STORAGE_KEY_SESSIONS = 'gpt6_sessions_v1';
const STORAGE_KEY_MESSAGES = 'gpt6_messages_v1';
const STORAGE_KEY_SOUND = 'gpt6_sound_muted';

const INITIAL_BOT_MESSAGE: Message = {
  id: 'msg-init-1',
  role: 'assistant',
  content: 'Bonjour ! Je suis GPT-6. Comment puis-je t\'aider ?',
  timestamp: Date.now(),
  model: 'GPT-6 Quantum Core',
};

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('default-session');
  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>({});
  const [currentMode, setCurrentMode] = useState<ChatMode>('standard');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [streamingContent, setStreamingContent] = useState<string>('');
  const [streamingStartTime, setStreamingStartTime] = useState<number | null>(null);
  const [soundMuted, setSoundMuted] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [inputPrefill, setInputPrefill] = useState<string>('');
  const [serverStatus, setServerStatus] = useState<any>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Load saved state on mount
  useEffect(() => {
    try {
      const savedSound = localStorage.getItem(STORAGE_KEY_SOUND);
      if (savedSound !== null) {
        setSoundMuted(savedSound === 'true');
      }

      const savedSessions = localStorage.getItem(STORAGE_KEY_SESSIONS);
      const savedMessages = localStorage.getItem(STORAGE_KEY_MESSAGES);

      if (savedSessions && savedMessages) {
        const parsedSessions: ChatSession[] = JSON.parse(savedSessions);
        const parsedMessages: Record<string, Message[]> = JSON.parse(savedMessages);

        if (parsedSessions.length > 0) {
          setSessions(parsedSessions);
          setCurrentSessionId(parsedSessions[0].id);
          setMessagesMap(parsedMessages);
          return;
        }
      }

      // Default initial session
      const defaultSession: ChatSession = {
        id: 'session-main',
        title: 'Nouvelle conversation',
        createdAt: Date.now(),
        messageCount: 1,
      };
      setSessions([defaultSession]);
      setCurrentSessionId('session-main');
      setMessagesMap({
        'session-main': [INITIAL_BOT_MESSAGE],
      });
    } catch (e) {
      console.error('Failed to load storage state:', e);
    }
  }, []);

  // Sync to localStorage
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem(STORAGE_KEY_SESSIONS, JSON.stringify(sessions));
      localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(messagesMap));
    }
  }, [sessions, messagesMap]);

  // Fetch server status
  useEffect(() => {
    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => setServerStatus(data))
      .catch((err) => console.log('Status endpoint notice:', err));
  }, []);

  const currentMessages = messagesMap[currentSessionId] || [];

  // Scroll to bottom on updates
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMessages, streamingContent]);

  const toggleSound = () => {
    const newVal = !soundMuted;
    setSoundMuted(newVal);
    localStorage.setItem(STORAGE_KEY_SOUND, String(newVal));
  };

  // Start new chat session
  const handleNewSession = () => {
    const newId = `session-${Date.now()}`;
    const newSession: ChatSession = {
      id: newId,
      title: 'Nouvelle conversation',
      createdAt: Date.now(),
      messageCount: 1,
    };
    setSessions((prev) => [newSession, ...prev]);
    setCurrentSessionId(newId);
    setMessagesMap((prev) => ({
      ...prev,
      [newId]: [INITIAL_BOT_MESSAGE],
    }));
  };

  // Delete chat session
  const handleDeleteSession = (id: string) => {
    const updatedSessions = sessions.filter((s) => s.id !== id);
    const updatedMessages = { ...messagesMap };
    delete updatedMessages[id];

    if (updatedSessions.length === 0) {
      const resetSession: ChatSession = {
        id: `session-${Date.now()}`,
        title: 'Nouvelle conversation',
        createdAt: Date.now(),
        messageCount: 1,
      };
      setSessions([resetSession]);
      setCurrentSessionId(resetSession.id);
      setMessagesMap({ [resetSession.id]: [INITIAL_BOT_MESSAGE] });
    } else {
      setSessions(updatedSessions);
      if (currentSessionId === id) {
        setCurrentSessionId(updatedSessions[0].id);
      }
      setMessagesMap(updatedMessages);
    }
  };

  // Clear current chat
  const handleClearChat = () => {
    if (confirm('Voulez-vous effacer les messages de cette conversation ?')) {
      setMessagesMap((prev) => ({
        ...prev,
        [currentSessionId]: [INITIAL_BOT_MESSAGE],
      }));
    }
  };

  // Export current chat
  const handleExportChat = () => {
    const msgs = currentMessages;
    let md = `# Conversation GPT-6\n*Date : ${new Date().toLocaleString()}*\n\n---\n\n`;
    msgs.forEach((m) => {
      const author = m.role === 'user' ? 'Vous' : 'GPT-6';
      md += `### ${author} (${new Date(m.timestamp).toLocaleTimeString()})\n\n${m.content}\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gpt6-conversation-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Send message to server with streaming SSE
  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isGenerating) return;

    const userMsgId = `usr-${Date.now()}`;
    const userMessage: Message = {
      id: userMsgId,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const newMessages = [...currentMessages, userMessage];

    // Update conversation title if first message
    if (currentMessages.length <= 1) {
      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSessionId
            ? { ...s, title: text.slice(0, 32) + (text.length > 32 ? '...' : '') }
            : s
        )
      );
    }

    setMessagesMap((prev) => ({
      ...prev,
      [currentSessionId]: newMessages,
    }));

    setIsGenerating(true);
    setStreamingContent('');
    const startTime = Date.now();
    setStreamingStartTime(startTime);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          mode: currentMode,
          language: 'fr',
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error('Erreur de réponse du serveur');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunkText = decoder.decode(value, { stream: true });
        const lines = chunkText.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.substring(6));
              if (data.text) {
                accumulated += data.text;
                setStreamingContent(accumulated);
              }
            } catch {
              // Ignore non-json lines
            }
          }
        }
      }

      // Finish streaming
      const latency = Date.now() - startTime;
      const botMessage: Message = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: accumulated || 'Je suis à votre écoute.',
        timestamp: Date.now(),
        latencyMs: latency,
        model: 'GPT-6 Quantum Core',
      };

      setMessagesMap((prev) => ({
        ...prev,
        [currentSessionId]: [...newMessages, botMessage],
      }));

      playSound('receive', soundMuted);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Error during generation:', err);
        const errorMessage: Message = {
          id: `bot-err-${Date.now()}`,
          role: 'assistant',
          content: 'Une interruption réseau est survenue. Veuillez réessayer votre demande.',
          timestamp: Date.now(),
        };
        setMessagesMap((prev) => ({
          ...prev,
          [currentSessionId]: [...newMessages, errorMessage],
        }));
      }
    } finally {
      setIsGenerating(false);
      setStreamingContent('');
      setStreamingStartTime(null);
      abortControllerRef.current = null;
    }
  };

  const handleStopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      if (streamingContent) {
        const botMessage: Message = {
          id: `bot-${Date.now()}`,
          role: 'assistant',
          content: streamingContent,
          timestamp: Date.now(),
          latencyMs: streamingStartTime ? Date.now() - streamingStartTime : undefined,
        };
        setMessagesMap((prev) => ({
          ...prev,
          [currentSessionId]: [...currentMessages, botMessage],
        }));
      }
      setIsGenerating(false);
      setStreamingContent('');
      setStreamingStartTime(null);
    }
  };

  const handleRegenerate = () => {
    if (isGenerating || currentMessages.length < 2) return;
    const lastUserIdx = [...currentMessages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserIdx === -1) return;

    const actualIdx = currentMessages.length - 1 - lastUserIdx;
    const lastUserText = currentMessages[actualIdx].content;

    // Remove everything from actualIdx + 1
    const pruned = currentMessages.slice(0, actualIdx);
    setMessagesMap((prev) => ({
      ...prev,
      [currentSessionId]: pruned,
    }));

    handleSendMessage(lastUserText);
  };

  const handleEdit = (content: string) => {
    setInputPrefill(content);
  };

  const handleSelectPrompt = (prompt: string) => {
    setInputPrefill(prompt);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0f19] text-slate-100 overflow-hidden font-sans">
      {/* Background ambient lighting */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-40">
        <div className="absolute -top-32 left-1/4 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -right-32 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 left-1/3 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl" />
      </div>

      {/* Top Navigation */}
      <Header
        currentMode={currentMode}
        onSelectMode={setCurrentMode}
        soundMuted={soundMuted}
        onToggleSound={toggleSound}
        onNewChat={handleNewSession}
        onClearChat={handleClearChat}
        onOpenSidebar={() => setIsSidebarOpen(true)}
        onExportChat={handleExportChat}
        hasMessages={currentMessages.length > 1}
        isGenerating={isGenerating}
      />

      {/* Sidebar Drawer */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        onSelectPrompt={handleSelectPrompt}
        soundMuted={soundMuted}
        serverStatus={serverStatus}
      />

      {/* Chat Viewport (id="chat" as defined in user's original HTML) */}
      <main
        id="chat"
        ref={chatContainerRef}
        className="relative z-10 flex-1 overflow-y-auto px-2 sm:px-6 py-4 space-y-4 max-w-5xl mx-auto w-full"
      >
        {currentMessages.length === 1 && currentMessages[0].id === 'msg-init-1' ? (
          <EmptyState onSelectPrompt={handleSelectPrompt} soundMuted={soundMuted} />
        ) : (
          <div className="space-y-4 py-2">
            {currentMessages.map((msg, index) => (
              <ChatMessage
                key={msg.id || index}
                message={msg}
                soundMuted={soundMuted}
                onRegenerate={
                  index === currentMessages.length - 1 && msg.role === 'assistant'
                    ? handleRegenerate
                    : undefined
                }
                onEdit={msg.role === 'user' ? handleEdit : undefined}
              />
            ))}

            {/* Currently streaming message */}
            {isGenerating && streamingContent && (
              <ChatMessage
                message={{
                  id: 'streaming-assistant',
                  role: 'assistant',
                  content: streamingContent,
                  timestamp: Date.now(),
                  model: 'GPT-6 Quantum Neural',
                }}
                isStreaming={true}
                soundMuted={soundMuted}
              />
            )}

            {/* Thinking indicator before first token */}
            {isGenerating && !streamingContent && (
              <div className="flex items-center gap-3 px-4 py-3 text-cyan-400 text-sm animate-pulse">
                <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-cyan-950/60 border border-cyan-500/30">
                  <span className="text-base">🤖</span>
                </div>
                <div className="flex items-center gap-1.5 font-mono text-xs">
                  <span>GPT-6 réfléchit</span>
                  <span className="animate-bounce">.</span>
                  <span className="animate-bounce delay-100">.</span>
                  <span className="animate-bounce delay-200">.</span>
                </div>
              </div>
            )}
          </div>
        )}

        <div ref={chatEndRef} className="h-4" />
      </main>

      {/* Input Area */}
      <footer className="relative z-20 shrink-0">
        <ChatInput
          onSendMessage={handleSendMessage}
          isGenerating={isGenerating}
          onStopGenerating={handleStopGenerating}
          soundMuted={soundMuted}
          initialValue={inputPrefill}
        />
      </footer>
    </div>
  );
}
