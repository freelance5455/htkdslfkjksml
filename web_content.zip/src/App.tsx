import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Chess } from 'chess.js';
import Board, { ARROW_COLORS, type ArrowSpec } from './components/Board';
import EvalBar from './components/EvalBar';
import SettingsPanel from './components/SettingsPanel';
import SearchWorker from './engine/worker?worker&inline';
import type { WorkerRequest, WorkerResponse, SanLine } from './engine/worker';
import type { SearchParams } from './engine/search';
import { MATE } from './engine/search';
import { pickMove } from './engine/pick';
import {
  DEFAULT_SETTINGS,
  MAX_ELO,
  clampElo,
  matchesElo,
  settingsForElo,
  type Settings,
} from './engine/settings';

type Mode = 'white' | 'black' | 'analysis';
interface GameMove {
  from: string;
  to: string;
  promotion?: string;
  san: string;
}
interface InfoState {
  ply: number;
  turn: 'w' | 'b';
  depth: number;
  nodes: number;
  timeMs: number;
  lines: SanLine[];
}

const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const STORE_KEY = 'chess-engine-settings-v2';

function loadStored(): { settings: Settings; elo: number } {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return { settings: { ...DEFAULT_SETTINGS, ...p.settings }, elo: clampElo(p.elo ?? 1500) };
    }
  } catch {
    /* ignore */
  }
  return { settings: DEFAULT_SETTINGS, elo: 1500 };
}

function fmtNodes(n: number) {
  return n >= 1e6 ? `${(n / 1e6).toFixed(2)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(0)}k` : String(n);
}

function scoreText(cp: number): string {
  if (Math.abs(cp) > MATE - 1000) {
    const m = Math.ceil((MATE - Math.abs(cp)) / 2);
    return `${cp > 0 ? '+' : '-'}M${m}`;
  }
  return `${cp > 0 ? '+' : ''}${(cp / 100).toFixed(2)}`;
}

export default function App() {
  const stored = useMemo(loadStored, []);
  const [settings, setSettings] = useState<Settings>(stored.settings);
  const [elo, setElo] = useState<number>(stored.elo);
  const [eloInput, setEloInput] = useState(String(stored.elo));
  const [eloNote, setEloNote] = useState('');
  const [mode, setMode] = useState<Mode>('white');
  const [moves, setMoves] = useState<GameMove[]>([]);
  const [flipped, setFlipped] = useState(false);
  const [tab, setTab] = useState<'game' | 'settings'>('game');
  const [info, setInfo] = useState<InfoState | null>(null);
  const [thinking, setThinking] = useState(false);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem(STORE_KEY, JSON.stringify({ settings, elo }));
  }, [settings, elo]);

  const patch = useCallback((p: Partial<Settings>) => setSettings((s) => ({ ...s, ...p })), []);

  const chess = useMemo(() => {
    const c = new Chess();
    for (const m of moves) c.move({ from: m.from, to: m.to, promotion: m.promotion });
    return c;
  }, [moves]);

  const turn = chess.turn();
  const checkmate = chess.isCheckmate();
  const over = chess.isGameOver();
  const engineColor = mode === 'white' ? 'b' : mode === 'black' ? 'w' : null;
  const engineTurn = !over && engineColor === turn;
  const humanCanMove = !over && !engineTurn;

  const status = useMemo(() => {
    if (checkmate) return `Мат! Победили ${turn === 'w' ? 'чёрные' : 'белые'}`;
    if (chess.isStalemate()) return 'Пат — ничья';
    if (chess.isInsufficientMaterial()) return 'Ничья: недостаточно материала';
    if (chess.isThreefoldRepetition()) return 'Ничья: троекратное повторение';
    if (chess.isDraw()) return 'Ничья по правилу 50 ходов';
    return `Ход ${turn === 'w' ? 'белых' : 'чёрных'}${chess.inCheck() ? ' — шах!' : ''}`;
  }, [chess, checkmate, turn]);

  const playMove = useCallback((from: string, to: string, promotion: string | undefined, ply: number) => {
    setMoves((prev) => {
      if (prev.length !== ply) return prev;
      const c = new Chess();
      for (const m of prev) c.move({ from: m.from, to: m.to, promotion: m.promotion });
      try {
        const mv = c.move({ from, to, promotion });
        return [...prev, { from, to, promotion: mv.promotion, san: mv.san }];
      } catch {
        return prev;
      }
    });
  }, []);

  // ---- поиск: ход движка и/или анализ для стрелок и шкалы ----
  const engineSig = JSON.stringify([
    settings.depth,
    settings.timeMs,
    settings.quiescence,
    settings.qDepth,
    settings.useTT,
    settings.checkExt,
    settings.nullMove,
    settings.lmr,
    settings.usePST,
    settings.bishopPair,
    settings.pawnStructure,
    settings.rookFiles,
    settings.candidates,
    settings.analysisDepth,
    settings.analysisTimeMs,
    settings.arrows,
    settings.showEval,
  ]);

  useEffect(() => {
    setThinking(false);
    if (over) return;
    const s = settingsRef.current;
    const analysis = s.showEval || s.arrows > 0;
    if (!engineTurn && !analysis) return;

    const evalFlags = {
      usePST: s.usePST,
      bishopPair: s.bishopPair,
      pawnStructure: s.pawnStructure,
      rookFiles: s.rookFiles,
    };
    const params: SearchParams = engineTurn
      ? {
          ...evalFlags,
          depth: s.depth,
          timeMs: s.timeMs,
          quiescence: s.quiescence,
          qDepth: s.qDepth,
          useTT: s.useTT,
          checkExt: s.checkExt,
          nullMove: s.nullMove,
          lmr: s.lmr,
          multiPV: Math.max(1, s.candidates, s.arrows),
        }
      : {
          ...evalFlags,
          depth: s.analysisDepth,
          timeMs: s.analysisTimeMs,
          quiescence: true,
          qDepth: 10,
          useTT: true,
          checkExt: true,
          nullMove: true,
          lmr: true,
          multiPV: Math.max(1, s.arrows),
        };

    const ply = moves.length;
    const t = turn;
    const started = Date.now();
    const worker = new SearchWorker();
    let timer: ReturnType<typeof setTimeout> | undefined;
    setThinking(true);
    worker.onmessage = (ev: MessageEvent<WorkerResponse>) => {
      const m = ev.data;
      if (m.type === 'info') {
        setInfo({ ply, turn: t, ...m.info });
      } else {
        setThinking(false);
        if (engineTurn && m.info) {
          const line = pickMove(m.info.lines, s, ply);
          const wait = Math.max(0, 450 - (Date.now() - started));
          timer = setTimeout(
            () => playMove(line.uci.slice(0, 2), line.uci.slice(2, 4), line.uci[4], ply),
            wait,
          );
        }
      }
    };
    const req: WorkerRequest = { id: ply, startFen: START_FEN, moves: moves.map((x) => x.from + x.to + (x.promotion ?? '')), params };
    worker.postMessage(req);
    return () => {
      worker.terminate();
      if (timer) clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moves, mode, engineSig, over]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [moves.length]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if (e.key === 'f' || e.key === 'F' || e.key === 'а' || e.key === 'А') setFlipped((f) => !f);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  const newGame = (m: Mode) => {
    setMode(m);
    setMoves([]);
    setInfo(null);
    if (settings.autoFlip) setFlipped(m === 'black');
  };

  const undo = () => {
    if (!moves.length) return;
    let n = 1;
    if (engineColor) n = engineTurn ? 1 : 2;
    setInfo(null);
    setMoves((m) => m.slice(0, Math.max(0, m.length - n)));
  };

  const applyElo = () => {
    const raw = parseInt(eloInput, 10);
    if (Number.isNaN(raw)) {
      setEloNote('Введите число');
      return;
    }
    const v = clampElo(raw);
    setEloInput(String(v));
    setElo(v);
    setSettings((s) => ({ ...s, ...settingsForElo(v) }));
    setEloNote(raw > MAX_ELO ? `Максимум ${MAX_ELO} — выставлено ${v}` : `Настройки подобраны под Эло ${v}`);
  };

  // ---- оценка для шкалы ----
  let pawns: number | null = null;
  let mate: number | null = null;
  if (checkmate) {
    mate = 0;
  } else if (over) {
    pawns = 0;
  } else if (info && info.lines.length) {
    const sign = info.turn === 'w' ? 1 : -1;
    const cp = info.lines[0].score;
    if (Math.abs(cp) > MATE - 1000) mate = sign * (cp > 0 ? 1 : -1) * Math.ceil((MATE - Math.abs(cp)) / 2);
    else pawns = (cp * sign) / 100;
  }

  const arrowsOn = settings.arrows > 0 && humanCanMove && info && info.ply === moves.length;
  const arrowLines =
    arrowsOn && info
      ? info.lines.filter((l) => l.score >= info.lines[0].score - 300).slice(0, settings.arrows)
      : [];
  const arrows: ArrowSpec[] = arrowLines.map((l, i) => ({ from: l.uci.slice(0, 2), to: l.uci.slice(2, 4), rank: i }));

  const lastMove = moves.length ? moves[moves.length - 1] : null;
  const topIsBlack = !flipped;
  const engineLabel = `Движок · Эло ${elo}${matchesElo(settings, elo) ? '' : '*'}`;
  const label = (color: 'w' | 'b') => {
    if (mode === 'analysis') return color === 'w' ? 'Белые' : 'Чёрные';
    return color === engineColor ? engineLabel : 'Вы';
  };

  const pairs: { n: number; w?: GameMove; b?: GameMove }[] = [];
  moves.forEach((m, i) => {
    if (i % 2 === 0) pairs.push({ n: i / 2 + 1, w: m });
    else pairs[pairs.length - 1].b = m;
  });

  const playerStrip = (color: 'w' | 'b') => (
    <div className="flex h-7 items-center gap-2 px-1 text-sm text-zinc-300">
      <span className={`inline-block h-3 w-3 rounded-sm ring-1 ring-zinc-500 ${color === 'w' ? 'bg-zinc-100' : 'bg-zinc-900'}`} />
      <span className="font-medium">{label(color)}</span>
      {!over && turn === color && (
        <span className="ml-1 flex items-center gap-1.5 text-xs text-emerald-400">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
          {engineTurn && thinking ? 'думает…' : 'ход'}
        </span>
      )}
    </div>
  );

  const btn =
    'rounded-lg bg-zinc-800 px-3 py-2 text-xs font-medium text-zinc-100 ring-1 ring-white/5 transition hover:bg-zinc-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40';

  return (
    <div className="board-vars min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto flex max-w-[1250px] flex-col items-center gap-4 px-3 py-3 lg:flex-row lg:items-start lg:justify-center lg:gap-6 lg:py-4">
        {/* ----- доска ----- */}
        <section className="flex flex-col">
          <div className="flex gap-2">
            {settings.showEval ? (
              <div className="flex flex-col">
                <div className="h-7" />
                <EvalBar pawns={pawns} mate={mate} whiteWon={turn === 'b'} flipped={flipped} />
              </div>
            ) : null}
            <div className="flex flex-col">
              {playerStrip(topIsBlack ? 'b' : 'w')}
              <Board
                chess={chess}
                flipped={flipped}
                theme={settings.theme}
                lastMove={lastMove}
                arrows={arrows}
                showCoords={settings.showCoords}
                showLegal={settings.showLegal}
                showLastMove={settings.showLastMove}
                interactive={humanCanMove}
                onMove={(f, t, p) => playMove(f, t, p, moves.length)}
              />
              {playerStrip(topIsBlack ? 'w' : 'b')}
            </div>
          </div>
        </section>

        {/* ----- панель ----- */}
        <aside className="flex w-full max-w-[640px] flex-col gap-2 lg:h-[calc(var(--bs)+3.5rem)] lg:w-[400px]">
          <div className="rounded-xl bg-zinc-900 p-2.5 ring-1 ring-white/5">
            <div className="flex items-center gap-2">
              <div className="flex min-w-0 flex-1 items-center gap-2">
                <span className="text-lg">♞</span>
                <div className="min-w-0 leading-tight">
                  <div className="truncate text-sm font-semibold">Шахматный движок</div>
                  <div className="truncate text-[10px] text-zinc-500">alpha-beta · 0x88 · web worker</div>
                </div>
              </div>
              <label className="flex items-center gap-1.5 text-xs text-zinc-400" title={`Подобрать настройки под Эло (макс. ${MAX_ELO})`}>
                Эло
                <input
                  value={eloInput}
                  inputMode="numeric"
                  maxLength={4}
                  onChange={(e) => {
                    setEloInput(e.target.value.replace(/\D/g, '').slice(0, 4));
                    setEloNote('');
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && applyElo()}
                  className="w-14 rounded-md bg-zinc-800 px-2 py-1.5 text-center font-mono text-sm text-emerald-300 outline-none ring-1 ring-white/10 focus:ring-emerald-500"
                  placeholder="1500"
                />
              </label>
              <button onClick={applyElo} className="rounded-md bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white transition hover:bg-emerald-500">
                OK
              </button>
            </div>
            {eloNote && <div className="mt-1.5 text-[11px] text-emerald-400">{eloNote}</div>}
          </div>

          <div className="grid grid-cols-2 gap-1 rounded-xl bg-zinc-900 p-1 ring-1 ring-white/5">
            {(
              [
                ['game', 'Игра'],
                ['settings', 'Настройки'],
              ] as const
            ).map(([id, name]) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`rounded-lg py-1.5 text-sm font-medium transition ${
                  tab === id ? 'bg-zinc-700 text-white' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {name}
              </button>
            ))}
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto pr-1 lg:pr-1.5">
            {tab === 'settings' ? (
              <SettingsPanel s={settings} set={patch} />
            ) : (
              <div className="space-y-2">
                <div
                  className={`rounded-xl px-3 py-2.5 text-sm font-semibold ring-1 ${
                    over ? 'bg-amber-500/10 text-amber-300 ring-amber-500/30' : 'bg-zinc-900 text-zinc-100 ring-white/5'
                  }`}
                >
                  {status}
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  {(
                    [
                      ['white', 'Белыми'],
                      ['black', 'Чёрными'],
                      ['analysis', 'Анализ'],
                    ] as const
                  ).map(([m, name]) => (
                    <button
                      key={m}
                      onClick={() => newGame(m)}
                      className={`${btn} ${mode === m ? '!bg-emerald-600/90 !ring-emerald-400/40' : ''}`}
                      title="Начать новую партию"
                    >
                      {name}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  <button className={btn} onClick={() => setFlipped((f) => !f)} title="Горячая клавиша: F">
                    ⇅ Развернуть доску
                  </button>
                  <button className={btn} onClick={undo} disabled={!moves.length}>
                    ↶ Отменить ход
                  </button>
                  <button
                    className={btn}
                    disabled={!arrowLines.length}
                    onClick={() => {
                      const l = arrowLines[0];
                      if (l) playMove(l.uci.slice(0, 2), l.uci.slice(2, 4), l.uci[4], moves.length);
                    }}
                  >
                    ★ Лучший ход
                  </button>
                  <button
                    className={btn}
                    onClick={() => patch({ arrows: settings.arrows > 0 ? 0 : 3 })}
                  >
                    {settings.arrows > 0 ? '➚ Скрыть стрелки' : '➚ Показать стрелки'}
                  </button>
                </div>

                {/* анализ */}
                <div className="rounded-xl bg-zinc-900 p-3 ring-1 ring-white/5">
                  <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-emerald-400/90">
                    <span>Анализ</span>
                    <span className="font-mono normal-case text-zinc-500">
                      {info ? `глуб. ${info.depth} · ${fmtNodes(info.nodes)} узлов${info.timeMs > 20 ? ` · ${fmtNodes(Math.round((info.nodes / info.timeMs) * 1000))}/с` : ''}` : '—'}
                      {thinking ? ' …' : ''}
                    </span>
                  </div>
                  {info && info.ply === moves.length && info.lines.length ? (
                    <div className="space-y-1">
                      {info.lines.slice(0, Math.max(1, settings.arrows, engineTurn ? 1 : 0)).map((l, i) => (
                        <div key={l.uci} className="flex items-start gap-2 text-xs">
                          <span className="mt-0.5 h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: ARROW_COLORS[i % 5] }} />
                          <span
                            className="w-14 shrink-0 font-mono font-semibold"
                            style={{ color: (info.turn === 'w' ? l.score : -l.score) >= 0 ? '#e4e4e7' : '#a1a1aa' }}
                          >
                            {scoreText(info.turn === 'w' ? l.score : -l.score)}
                          </span>
                          <span className="min-w-0 font-mono text-zinc-300">
                            {l.san.slice(0, 7).join(' ')}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-zinc-500">
                      {over ? 'Партия окончена' : settings.arrows === 0 && !settings.showEval ? 'Анализ отключён в настройках' : 'Идёт расчёт…'}
                    </div>
                  )}
                </div>

                {/* ходы */}
                <div className="rounded-xl bg-zinc-900 p-3 ring-1 ring-white/5">
                  <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-emerald-400/90">Ходы</div>
                  <div ref={listRef} className="max-h-40 overflow-y-auto font-mono text-xs">
                    {pairs.length === 0 && <div className="text-zinc-500">Партия ещё не начата</div>}
                    {pairs.map((p) => (
                      <div key={p.n} className="grid grid-cols-[2rem_1fr_1fr] gap-1 rounded px-1 py-0.5 odd:bg-white/[0.03]">
                        <span className="text-zinc-500">{p.n}.</span>
                        <span>{p.w?.san}</span>
                        <span>{p.b?.san}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
