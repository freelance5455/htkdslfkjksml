/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Track, Playlist, AudioFormat } from './types/audio';
import { createDefaultTracks } from './services/proceduralAudio';
import { audioEngine } from './services/audioEngine';
import {
  saveTrackToDB,
  getAllTracksFromDB,
  savePlaylistsToDB,
  getPlaylistsFromDB,
  getSettings,
  saveSettings,
} from './services/musicStorage';
import { Header } from './components/Header';
import { PlayerView } from './components/PlayerView';
import { LibraryView } from './components/LibraryView';
import { PlaylistsView } from './components/PlaylistsView';
import { DSPStudio } from './components/DSPStudio';
import { SearchView } from './components/SearchView';
import { WidgetSimulator } from './components/WidgetSimulator';
import { MiniPlayerBar } from './components/MiniPlayerBar';
import { SleepTimerModal } from './components/SleepTimerModal';
import { AddToPlaylistModal } from './components/AddToPlaylistModal';

export default function App() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'all' | 'one'>('all');

  // Real-time Beat & Rhythm State
  const [bpm, setBpm] = useState(120);
  const [isBeat, setIsBeat] = useState(false);
  const [beatStrength, setBeatStrength] = useState(0);

  // Active view tab
  const [activeTab, setActiveTab] = useState<
    'player' | 'library' | 'playlists' | 'dsp' | 'search' | 'widgets'
  >('player');

  // Modals
  const [isSleepModalOpen, setIsSleepModalOpen] = useState(false);
  const [sleepRemaining, setSleepRemaining] = useState<number | null>(null);
  const [playlistModalTrack, setPlaylistModalTrack] = useState<Track | null>(null);

  const tracksRef = useRef<Track[]>(tracks);
  tracksRef.current = tracks;
  const currentTrackRef = useRef<Track | null>(currentTrack);
  currentTrackRef.current = currentTrack;
  const isShuffleRef = useRef(isShuffle);
  isShuffleRef.current = isShuffle;
  const repeatModeRef = useRef(repeatMode);
  repeatModeRef.current = repeatMode;

  // Initialize tracks & playlists on first mount
  useEffect(() => {
    let isMounted = true;

    async function initData() {
      try {
        const storedTracks = await getAllTracksFromDB();
        let loadedTracks = storedTracks;

        if (storedTracks.length === 0) {
          // Generate high-fidelity procedural demo tracks
          const defaultTracks = await createDefaultTracks();
          if (isMounted) {
            setTracks(defaultTracks);
            for (const t of defaultTracks) {
              await saveTrackToDB(t);
            }
            loadedTracks = defaultTracks;
          }
        } else if (isMounted) {
          setTracks(storedTracks);
        }

        // Initialize playlists
        const storedPlaylists = await getPlaylistsFromDB();
        if (storedPlaylists.length === 0 && loadedTracks.length > 0) {
          const defaultPlaylists: Playlist[] = [
            {
              id: 'favorites',
              name: 'Favoritos Hi-Fi',
              description: 'Canciones destacadas con audio de alta fidelidad',
              trackIds: loadedTracks.filter((t) => t.isFavorite).map((t) => t.id),
              createdAt: Date.now(),
            },
            {
              id: 'relax',
              name: 'Relax / Nocturno',
              description: 'Melodías suaves para desconectar y escuchar de noche',
              trackIds: loadedTracks.filter((t) => t.format === 'flac' || t.title.includes('Aurora') || t.title.includes('Lights')).map((t) => t.id),
              createdAt: Date.now(),
            },
          ];
          if (isMounted) {
            setPlaylists(defaultPlaylists);
            await savePlaylistsToDB(defaultPlaylists);
          }
        } else if (isMounted) {
          setPlaylists(storedPlaylists);
        }

        // Auto-select first track
        if (loadedTracks.length > 0 && isMounted) {
          setCurrentTrack(loadedTracks[0]);
          audioEngine.loadTrack(loadedTracks[0], false);
        }
      } catch (err) {
        console.error('Initialization error:', err);
      }
    }

    initData();

    // Volume restore
    audioEngine.setVolume(volume);

    // Audio Engine callbacks
    audioEngine.onTimeUpdate((curr, dur) => {
      setCurrentTime(curr);
      setDuration(dur);
    });

    audioEngine.onPlayStateChange((playing) => {
      setIsPlaying(playing);
    });

    audioEngine.onTrackEnd(() => {
      handleNextTrackAuto();
    });

    // Rhythm state polling animation loop
    let animId: number;
    const pollRhythm = () => {
      const state = audioEngine.getRhythmState();
      setBpm(state.bpm);
      setIsBeat(state.isBeat);
      setBeatStrength(state.beatStrength);
      setSleepRemaining(audioEngine.getSleepTimerRemaining());
      animId = requestAnimationFrame(pollRhythm);
    };
    animId = requestAnimationFrame(pollRhythm);

    return () => {
      isMounted = false;
      cancelAnimationFrame(animId);
      audioEngine.destroy();
    };
  }, []);

  const handleNextTrackAuto = () => {
    const trackList = tracksRef.current;
    const current = currentTrackRef.current;
    const repMode = repeatModeRef.current;
    const shuffle = isShuffleRef.current;

    if (!current || trackList.length === 0) return;

    if (repMode === 'one') {
      audioEngine.seek(0);
      audioEngine.play();
      return;
    }

    if (shuffle) {
      const nextIdx = Math.floor(Math.random() * trackList.length);
      const nextTrack = trackList[nextIdx];
      playTrack(nextTrack);
      return;
    }

    const currentIdx = trackList.findIndex((t) => t.id === current.id);
    if (currentIdx !== -1 && currentIdx < trackList.length - 1) {
      playTrack(trackList[currentIdx + 1]);
    } else if (repMode === 'all') {
      playTrack(trackList[0]);
    }
  };

  const playTrack = async (track: Track) => {
    setCurrentTrack(track);
    await audioEngine.loadTrack(track, true);
    setIsPlaying(true);
  };

  const togglePlay = () => {
    if (!currentTrack && tracks.length > 0) {
      playTrack(tracks[0]);
      return;
    }
    audioEngine.togglePlay();
  };

  const handleNext = () => {
    const list = tracks;
    if (list.length === 0) return;
    if (isShuffle) {
      const randIdx = Math.floor(Math.random() * list.length);
      playTrack(list[randIdx]);
      return;
    }
    const idx = list.findIndex((t) => t.id === currentTrack?.id);
    const nextIdx = (idx + 1) % list.length;
    playTrack(list[nextIdx]);
  };

  const handlePrev = () => {
    const list = tracks;
    if (list.length === 0) return;
    if (currentTime > 3) {
      audioEngine.seek(0);
      return;
    }
    const idx = list.findIndex((t) => t.id === currentTrack?.id);
    const prevIdx = (idx - 1 + list.length) % list.length;
    playTrack(list[prevIdx]);
  };

  const handleSeek = (seconds: number) => {
    audioEngine.seek(seconds);
    setCurrentTime(seconds);
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    audioEngine.setVolume(vol);
  };

  const handleToggleFavorite = (trackId: string) => {
    const updated = tracks.map((t) => {
      if (t.id === trackId) {
        return { ...t, isFavorite: !t.isFavorite };
      }
      return t;
    });
    setTracks(updated);
    const target = updated.find((t) => t.id === trackId);
    if (target) saveTrackToDB(target);

    // Sync with favorites playlist
    setPlaylists((prev) => {
      const favList = prev.find((p) => p.id === 'favorites');
      if (!favList) return prev;
      const isFav = target?.isFavorite;
      let newIds = favList.trackIds;
      if (isFav && !newIds.includes(trackId)) {
        newIds = [...newIds, trackId];
      } else if (!isFav) {
        newIds = newIds.filter((id) => id !== trackId);
      }
      const updatedPlaylists = prev.map((p) =>
        p.id === 'favorites' ? { ...p, trackIds: newIds } : p
      );
      savePlaylistsToDB(updatedPlaylists);
      return updatedPlaylists;
    });
  };

  // User imports audio files or directories (MP3, OGG, WAV, FLAC, M4A)
  const handleImportFiles = async (fileList: FileList) => {
    const newTracks: Track[] = [];

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const name = file.name;
      const lower = name.toLowerCase();

      let format: AudioFormat = 'unknown';
      if (lower.endsWith('.mp3')) format = 'mp3';
      else if (lower.endsWith('.ogg')) format = 'ogg';
      else if (lower.endsWith('.wav')) format = 'wav';
      else if (lower.endsWith('.flac')) format = 'flac';
      else if (lower.endsWith('.m4a') || lower.endsWith('.aac')) format = 'm4a';
      else continue; // skip non-audio

      const url = URL.createObjectURL(file);
      const relativePath = file.webkitRelativePath || '';
      let folderPath = 'Mis Archivos';
      if (relativePath.includes('/')) {
        const parts = relativePath.split('/');
        parts.pop(); // remove filename
        folderPath = parts.join('/');
      }

      // Title & Artist parsing from filename (e.g., "Artist - Song.mp3" or "Song.mp3")
      let title = name.replace(/\.[^/.]+$/, '');
      let artist = 'Artista Desconocido';
      if (title.includes(' - ')) {
        const split = title.split(' - ');
        artist = split[0].trim();
        title = split[1].trim();
      }

      // Guess sample rate from format
      const sampleRate = format === 'flac' ? 96000 : 48000;
      const bitDepth = format === 'flac' ? 24 : 16;

      const track: Track = {
        id: `import-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 6)}`,
        title,
        artist,
        album: folderPath,
        duration: 180, // Default duration placeholder until loaded
        url,
        blob: file,
        coverUrl: '/icon.svg',
        format,
        sampleRate,
        bitDepth,
        fileSize: file.size,
        folderPath,
        dateAdded: Date.now(),
        isFavorite: false,
      };

      newTracks.push(track);
      await saveTrackToDB(track);
    }

    if (newTracks.length > 0) {
      setTracks((prev) => [...newTracks, ...prev]);
      if (!currentTrack) {
        playTrack(newTracks[0]);
      }
    }
  };

  // Playlists management
  const handleCreatePlaylist = (name: string, description?: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      name,
      description,
      trackIds: [],
      createdAt: Date.now(),
    };
    const updated = [...playlists, newPl];
    setPlaylists(updated);
    savePlaylistsToDB(updated);
  };

  const handleDeletePlaylist = (id: string) => {
    const updated = playlists.filter((p) => p.id !== id);
    setPlaylists(updated);
    savePlaylistsToDB(updated);
  };

  const handleToggleTrackInPlaylist = (playlistId: string, trackId: string) => {
    const updated = playlists.map((p) => {
      if (p.id === playlistId) {
        const exists = p.trackIds.includes(trackId);
        return {
          ...p,
          trackIds: exists
            ? p.trackIds.filter((id) => id !== trackId)
            : [...p.trackIds, trackId],
        };
      }
      return p;
    });
    setPlaylists(updated);
    savePlaylistsToDB(updated);
  };

  const handleRemoveTrackFromPlaylist = (playlistId: string, trackId: string) => {
    const updated = playlists.map((p) => {
      if (p.id === playlistId) {
        return {
          ...p,
          trackIds: p.trackIds.filter((id) => id !== trackId),
        };
      }
      return p;
    });
    setPlaylists(updated);
    savePlaylistsToDB(updated);
  };

  return (
    <div className="min-h-screen bg-[#090a0f] text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-white">
      {/* Top Header complying with Top Bar Contract */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenSleepTimer={() => setIsSleepModalOpen(true)}
        sleepRemaining={sleepRemaining}
        onOpenWidgetSim={() => setActiveTab('widgets')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 pb-28">
        {activeTab === 'player' && (
          <PlayerView
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            volume={volume}
            isShuffle={isShuffle}
            repeatMode={repeatMode}
            bpm={bpm}
            isBeat={isBeat}
            beatStrength={beatStrength}
            reactiveVisualFx={audioEngine.getDSPSettings().reactiveVisualFx}
            onTogglePlay={togglePlay}
            onNext={handleNext}
            onPrev={handlePrev}
            onSeek={handleSeek}
            onVolumeChange={handleVolumeChange}
            onToggleShuffle={() => setIsShuffle(!isShuffle)}
            onCycleRepeat={() =>
              setRepeatMode((prev) =>
                prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off'
              )
            }
            onToggleFavorite={handleToggleFavorite}
            onOpenDSP={() => setActiveTab('dsp')}
            onOpenSleepTimer={() => setIsSleepModalOpen(true)}
          />
        )}

        {activeTab === 'library' && (
          <LibraryView
            tracks={tracks}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onPlayTrack={playTrack}
            onTogglePlay={togglePlay}
            onToggleFavorite={handleToggleFavorite}
            onImportFiles={handleImportFiles}
            onOpenPlaylistModal={(track) => setPlaylistModalTrack(track)}
          />
        )}

        {activeTab === 'playlists' && (
          <PlaylistsView
            playlists={playlists}
            tracks={tracks}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onPlayTrack={playTrack}
            onCreatePlaylist={handleCreatePlaylist}
            onDeletePlaylist={handleDeletePlaylist}
            onRemoveTrackFromPlaylist={handleRemoveTrackFromPlaylist}
          />
        )}

        {activeTab === 'dsp' && (
          <DSPStudio bpm={bpm} isBeat={isBeat} beatStrength={beatStrength} />
        )}

        {activeTab === 'search' && (
          <SearchView
            tracks={tracks}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onPlayTrack={playTrack}
          />
        )}

        {activeTab === 'widgets' && (
          <WidgetSimulator
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            bpm={bpm}
            isBeat={isBeat}
            onTogglePlay={togglePlay}
            onNext={handleNext}
            onPrev={handlePrev}
            onSeek={handleSeek}
          />
        )}
      </main>

      {/* Mini Player Bar at bottom when outside 'player' tab */}
      {activeTab !== 'player' && (
        <MiniPlayerBar
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          isBeat={isBeat}
          bpm={bpm}
          onTogglePlay={togglePlay}
          onNext={handleNext}
          onPrev={handlePrev}
          onExpand={() => setActiveTab('player')}
          onOpenDSP={() => setActiveTab('dsp')}
        />
      )}

      {/* Modals */}
      <SleepTimerModal
        isOpen={isSleepModalOpen}
        onClose={() => setIsSleepModalOpen(false)}
        remainingSeconds={sleepRemaining}
      />

      <AddToPlaylistModal
        track={playlistModalTrack}
        playlists={playlists}
        isOpen={!!playlistModalTrack}
        onClose={() => setPlaylistModalTrack(null)}
        onAddToPlaylist={handleToggleTrackInPlaylist}
        onCreatePlaylist={handleCreatePlaylist}
      />
    </div>
  );
}
