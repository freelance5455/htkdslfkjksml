/* ============================================
   plix_ai studio — Main App
   Single-page application with client-side routing
   ============================================ */

import { useState, useEffect, useCallback } from 'react';
import type { PageId } from './types';
import Sidebar from './components/Sidebar';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import Convert from './pages/Convert';
import DevTools from './pages/DevTools';
import Settings from './pages/Settings';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('landing');

  // --- Keyboard shortcuts ---
  const handleKeyboard = useCallback((e: KeyboardEvent) => {
    // Don't trigger shortcuts when typing in inputs
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) {
      return;
    }

    if (e.key === '1' && !e.metaKey && !e.ctrlKey) {
      e.preventDefault();
      setCurrentPage('dashboard');
    } else if (e.key === '2' && !e.metaKey && !e.ctrlKey) {
      e.preventDefault();
      setCurrentPage('convert');
    } else if (e.key === '3' && !e.metaKey && !e.ctrlKey) {
      e.preventDefault();
      setCurrentPage('devtools');
    } else if (e.key === '4' && !e.metaKey && !e.ctrlKey) {
      e.preventDefault();
      setCurrentPage('settings');
    } else if (e.key === '0' && !e.metaKey && !e.ctrlKey) {
      e.preventDefault();
      setCurrentPage('landing');
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyboard);
    return () => window.removeEventListener('keydown', handleKeyboard);
  }, [handleKeyboard]);

  // --- Scroll to top on page change ---
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // --- Render page ---
  function renderPage() {
    switch (currentPage) {
      case 'landing':
        return <Landing onNavigate={setCurrentPage} />;
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'convert':
        return <Convert onNavigate={setCurrentPage} />;
      case 'devtools':
        return <DevTools onNavigate={setCurrentPage} />;
      case 'settings':
        return <Settings onNavigate={setCurrentPage} />;
      default:
        return <Landing onNavigate={setCurrentPage} />;
    }
  }

  const isLanding = currentPage === 'landing';

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100">
      {/* Sidebar */}
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />

      {/* Main content area */}
      <main
        className={`transition-all duration-200 ${
          isLanding ? '' : 'ml-0 md:ml-56'
        }`}
      >
        <div className={`${isLanding ? '' : 'px-4 sm:px-6 lg:px-8 py-6 pt-14 md:pt-6 max-w-6xl mx-auto'}`}>
          {renderPage()}
        </div>
      </main>

      {/* Demo mode overlay badge (top-right) */}
      {!isLanding && (
        <div className="fixed top-4 right-4 z-10 hide-mobile">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full surface-1 border border-subtle shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
            <span className="text-[10px] text-stone-400 uppercase tracking-wider font-medium">Demo Mode</span>
          </div>
        </div>
      )}
    </div>
  );
}