import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { WelcomeScreen } from './components/WelcomeScreen';
import { MessageItem } from './components/MessageItem';
import { ChatInput } from './components/ChatInput';
import { QuizModal } from './components/QuizModal';
import { FlashcardsModal } from './components/FlashcardsModal';
import { ConfirmModal } from './components/ConfirmModal';
import { SubscriptionPage } from './components/SubscriptionPage';
import { ToastContainer, ToastMessage } from './components/Toast';
import { ChatSession, ChatMessage, TutorPersonaId, TeachingMode, AcademicLevel } from './types';
import { TUTOR_PERSONAS } from './utils/tutor-prompts';

const STORAGE_KEY = 'ai_tutor_sessions_v1';

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse saved sessions', e);
    }
    return [];
  });

  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    return sessions.length > 0 ? sessions[0].id : null;
  });

  const [currentPersona, setCurrentPersona] = useState<TutorPersonaId>('general');
  const [teachingMode, setTeachingMode] = useState<TeachingMode>('direct');
  const [level, setLevel] = useState<AcademicLevel>('high_school');

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [subscriptionPageOpen, setSubscriptionPageOpen] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);

  // Modals & Feedback
  const [quizModalOpen, setQuizModalOpen] = useState(false);
  const [quizTopic, setQuizTopic] = useState('');
  const [flashcardsModalOpen, setFlashcardsModalOpen] = useState(false);
  const [flashcardsTopic, setFlashcardsTopic] = useState('');
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const addToast = (text: string, type: ToastMessage['type'] = 'success') => {
    const newToast: ToastMessage = {
      id: 'toast_' + Date.now() + Math.random(),
      type,
      text,
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Save sessions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save sessions to localStorage', e);
    }
  }, [sessions]);

  // Sync active session persona, mode, and level
  const activeSession = sessions.find((s) => s.id === activeSessionId) || null;

  useEffect(() => {
    if (activeSession) {
      setCurrentPersona(activeSession.persona);
      setTeachingMode(activeSession.teachingMode);
      setLevel(activeSession.level);
    }
  }, [activeSessionId]);

  // Scroll to bottom on new messages
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeSession?.messages.length, isStreaming]);

  // Start new conversation
  const handleNewChat = (personaId?: TutorPersonaId) => {
    const chosenPersona = personaId || currentPersona;

    // If active session is already empty, just update its persona
    if (activeSession && activeSession.messages.length === 0) {
      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeSession.id ? { ...s, persona: chosenPersona } : s
        )
      );
      setCurrentPersona(chosenPersona);
      setSidebarOpen(false);
      addToast(`Ready to learn with ${TUTOR_PERSONAS[chosenPersona].name}`, 'info');
      return;
    }

    const newSession: ChatSession = {
      id: 'session_' + Date.now(),
      title: 'New Conversation',
      persona: chosenPersona,
      teachingMode,
      level,
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setCurrentPersona(chosenPersona);
    setSidebarOpen(false);
    addToast(`New chat started: ${TUTOR_PERSONAS[chosenPersona].name}`, 'info');
  };

  // Switch persona
  const handleSelectPersona = (personaId: TutorPersonaId) => {
    setCurrentPersona(personaId);
    const personaName = TUTOR_PERSONAS[personaId].name;

    // If current session already has messages, create a fresh chat with this tutor
    if (activeSession && activeSession.messages.length > 0) {
      handleNewChat(personaId);
    } else if (activeSession) {
      setSessions((prev) =>
        prev.map((s) => (s.id === activeSession.id ? { ...s, persona: personaId } : s))
      );
      addToast(`Switched to ${personaName}`, 'info');
    } else {
      addToast(`Selected ${personaName}`, 'info');
    }
  };

  // Switch teaching mode
  const handleChangeTeachingMode = (mode: TeachingMode) => {
    setTeachingMode(mode);
    const modeLabel = mode === 'socratic' ? 'Socratic Guidance' : mode === 'quiz_prep' ? 'Quiz Prep' : 'Direct Breakdown';
    if (activeSession) {
      setSessions((prev) =>
        prev.map((s) => (s.id === activeSession.id ? { ...s, teachingMode: mode } : s))
      );
    }
    addToast(`Teaching mode set to ${modeLabel}`, 'info');
  };

  // Switch academic level
  const handleChangeLevel = (newLevel: AcademicLevel) => {
    setLevel(newLevel);
    if (activeSession) {
      setSessions((prev) =>
        prev.map((s) => (s.id === activeSession.id ? { ...s, level: newLevel } : s))
      );
    }
    addToast(`Target level set to ${newLevel.replace('_', ' ')}`, 'info');
  };

  // Rename session
  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle } : s))
    );
    addToast('Chat renamed', 'success');
  };

  // Delete session
  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (activeSessionId === id) {
        setActiveSessionId(filtered.length > 0 ? filtered[0].id : null);
      }
      return filtered;
    });
    addToast('Conversation removed', 'info');
  };

  // Request clear all conversations
  const handleClearAllClick = () => {
    if (sessions.length === 0) {
      addToast('No conversation history to clear.', 'info');
      return;
    }
    setConfirmClearOpen(true);
  };

  const handleConfirmClearAll = () => {
    setSessions([]);
    setActiveSessionId(null);
    setConfirmClearOpen(false);
    addToast('All conversation history has been cleared.', 'info');
  };

  // Stop streaming
  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);

    if (activeSessionId) {
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== activeSessionId) return s;
          const updated = [...s.messages];
          if (updated.length > 0) {
            updated[updated.length - 1] = {
              ...updated[updated.length - 1],
              isStreaming: false,
            };
          }
          return { ...s, messages: updated };
        })
      );
    }
    addToast('Tutor generation paused.', 'info');
  };

  // Send message
  const handleSendMessage = async (text: string) => {
    // Abort any active prior stream
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    let targetSessionId = activeSessionId;
    let targetMessages: ChatMessage[] = [];

    const userMessage: ChatMessage = {
      id: 'msg_' + Date.now(),
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    const assistantPlaceholderId = 'msg_' + (Date.now() + 1);
    const assistantPlaceholder: ChatMessage = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: new Date().toISOString(),
      persona: currentPersona,
      isStreaming: true,
    };

    if (!activeSession || !targetSessionId) {
      const newSession: ChatSession = {
        id: 'session_' + Date.now(),
        title: text.slice(0, 36) + (text.length > 36 ? '...' : ''),
        persona: currentPersona,
        teachingMode,
        level,
        messages: [userMessage, assistantPlaceholder],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      targetSessionId = newSession.id;
      targetMessages = [userMessage];
      setSessions((prev) => [newSession, ...prev]);
      setActiveSessionId(newSession.id);
    } else {
      targetMessages = [...activeSession.messages, userMessage];
      const shouldUpdateTitle = activeSession.messages.length === 0;

      setSessions((prev) =>
        prev.map((s) =>
          s.id === targetSessionId
            ? {
                ...s,
                title: shouldUpdateTitle
                  ? text.slice(0, 36) + (text.length > 36 ? '...' : '')
                  : s.title,
                messages: [...targetMessages, assistantPlaceholder],
                updatedAt: new Date().toISOString(),
              }
            : s
        )
      );
    }

    setIsStreaming(true);
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortController.signal,
        body: JSON.stringify({
          messages: targetMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          persona: currentPersona,
          teachingMode,
          level,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'Server responded with error');
      }

      if (!response.body) {
        throw new Error('ReadableStream not supported by browser.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulated = '';
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const dataStr = trimmed.substring(5).trim();

          if (dataStr === '[DONE]') break;

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.text) {
              accumulated += parsed.text;

              setSessions((prev) =>
                prev.map((s) => {
                  if (s.id !== targetSessionId) return s;
                  const msgs = [...s.messages];
                  const lastIdx = msgs.length - 1;
                  if (lastIdx >= 0) {
                    msgs[lastIdx] = {
                      ...msgs[lastIdx],
                      content: accumulated,
                    };
                  }
                  return { ...s, messages: msgs };
                })
              );
            }
          } catch (e) {
            // Partial chunk
          }
        }
      }

      // Finalize message
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== targetSessionId) return s;
          const msgs = [...s.messages];
          const lastIdx = msgs.length - 1;
          if (lastIdx >= 0) {
            msgs[lastIdx] = {
              ...msgs[lastIdx],
              content: accumulated || "I'm here to help. Could you please rephrase your question?",
              isStreaming: false,
            };
          }
          return { ...s, messages: msgs, updatedAt: new Date().toISOString() };
        })
      );
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Chat error:', err);
        setSessions((prev) =>
          prev.map((s) => {
            if (s.id !== targetSessionId) return s;
            const msgs = [...s.messages];
            const lastIdx = msgs.length - 1;
            if (lastIdx >= 0) {
              msgs[lastIdx] = {
                ...msgs[lastIdx],
                content:
                  msgs[lastIdx].content +
                  `\n\n⚠️ *I couldn't reach the tutoring engine right now. Please check your connection and try again.*`,
                isStreaming: false,
              };
            }
            return { ...s, messages: msgs };
          })
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  // Export Study Notes
  const handleExportNotes = () => {
    if (!activeSession || activeSession.messages.length === 0) {
      addToast('Start a conversation to export your study notes.', 'info');
      return;
    }

    const personaInfo = TUTOR_PERSONAS[activeSession.persona] || TUTOR_PERSONAS.general;
    let markdown = `# MindSparq Study Session: ${activeSession.title}\n`;
    markdown += `**Tutor Persona:** ${personaInfo.name} | **Level:** ${activeSession.level} | **Date:** ${new Date().toLocaleDateString()}\n\n---\n\n`;

    activeSession.messages.forEach((msg) => {
      const speaker = msg.role === 'user' ? '👤 Student' : `🎓 Tutor (${personaInfo.name})`;
      markdown += `### ${speaker} (${new Date(msg.timestamp).toLocaleTimeString()})\n\n${msg.content}\n\n---\n\n`;
    });

    // Copy to clipboard
    navigator.clipboard?.writeText(markdown).catch(() => {});

    // Also download file
    try {
      const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `MindSparq_${activeSession.title.replace(/[^a-zA-Z0-9]/g, '_')}.md`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      // Handled via clipboard fallback
    }

    addToast('Study notes copied to clipboard & downloaded!', 'success');
  };

  const handleOpenQuizWithTopic = (topic: string) => {
    setQuizTopic(topic);
    setQuizModalOpen(true);
  };

  const currentMessages = activeSession?.messages || [];

  return (
    <div className="h-screen flex overflow-hidden bg-white text-slate-900 font-sans antialiased">
      {/* Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        sessions={sessions}
        activeSessionId={activeSessionId}
        currentPersona={currentPersona}
        onSelectSession={(id) => {
          setActiveSessionId(id);
          setSidebarOpen(false);
        }}
        onNewChat={handleNewChat}
        onSelectPersona={handleSelectPersona}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onClearAll={handleClearAllClick}
        onOpenQuiz={() => {
          setQuizTopic('');
          setQuizModalOpen(true);
          setSidebarOpen(false);
        }}
        onOpenFlashcards={() => {
          setFlashcardsTopic('');
          setFlashcardsModalOpen(true);
          setSidebarOpen(false);
        }}
        onOpenPlans={() => setSubscriptionPageOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full bg-white relative overflow-hidden">
        {subscriptionPageOpen ? (
          <SubscriptionPage onBack={() => setSubscriptionPageOpen(false)} />
        ) : (
          <>
        {/* Header */}
        <Header
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          currentPersona={currentPersona}
          teachingMode={teachingMode}
          level={level}
          onChangeTeachingMode={handleChangeTeachingMode}
          onChangeLevel={handleChangeLevel}
          onNewChat={() => handleNewChat()}
          onExportNotes={handleExportNotes}
          hasMessages={currentMessages.length > 0}
        />

        {/* Chat / Messages Stream */}
        <div
          id="chat-container"
          className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 max-w-4xl w-full mx-auto"
        >
          {currentMessages.length === 0 ? (
            <WelcomeScreen
              currentPersona={currentPersona}
              onSelectPrompt={(text) => handleSendMessage(text)}
              onSelectPersona={handleSelectPersona}
            />
          ) : (
            <div id="messages-list" className="space-y-4">
              {currentMessages.map((msg) => (
                <MessageItem
                  key={msg.id}
                  message={msg}
                  onQuickFollowUp={(prompt) => handleSendMessage(prompt)}
                  onGenerateQuizFromTopic={handleOpenQuizWithTopic}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Bar */}
        <ChatInput
          onSendMessage={handleSendMessage}
          onStopStreaming={handleStopStreaming}
          isStreaming={isStreaming}
        />
          </>
        )}
      </main>

      {/* Interactive Practice Quiz Arena */}
      <QuizModal
        isOpen={quizModalOpen}
        onClose={() => setQuizModalOpen(false)}
        initialTopic={quizTopic}
        currentPersona={currentPersona}
        currentLevel={level}
      />

      {/* Interactive Flashcards Study Deck */}
      <FlashcardsModal
        isOpen={flashcardsModalOpen}
        onClose={() => setFlashcardsModalOpen(false)}
        initialTopic={flashcardsTopic}
      />

      {/* In-app Confirmation Modal (No window.confirm) */}
      <ConfirmModal
        isOpen={confirmClearOpen}
        title="Clear All Conversations?"
        message="This will delete your entire chat history and practice sessions. This action cannot be undone."
        confirmLabel="Clear History"
        cancelLabel="Cancel"
        onConfirm={handleConfirmClearAll}
        onCancel={() => setConfirmClearOpen(false)}
      />

      {/* In-App Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
