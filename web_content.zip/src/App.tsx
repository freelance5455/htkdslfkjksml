import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { StorySettingsBar } from './components/StorySettingsBar';
import { SceneAnalysisCard } from './components/SceneAnalysisCard';
import { StoryManuscript } from './components/StoryManuscript';
import { AudioNarrator } from './components/AudioNarrator';
import { GhostwriterChat } from './components/GhostwriterChat';
import { StoryAnalysisData, SamplePreset } from './types';
import { Sparkles, Bot, AlertCircle, BookOpen } from 'lucide-react';

export default function App() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');

  // Creative direction controls
  const [genre, setGenre] = useState<string>('Speculative Fiction');
  const [tone, setTone] = useState<string>('Atmospheric & Evocative');
  const [pov, setPov] = useState<string>('Third Person Limited');
  const [hookType, setHookType] = useState<string>('Atmospheric Immersion');
  const [userPrompt, setUserPrompt] = useState<string>('');

  // Analysis & Story State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisData, setAnalysisData] = useState<StoryAnalysisData | null>(null);
  const [currentStory, setCurrentStory] = useState<string>('');
  const [originalOpening, setOriginalOpening] = useState<string>('');
  const [modelUsed, setModelUsed] = useState<string>('gemini-4-argon');
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Continuation & Chat UI
  const [isContinuing, setIsContinuing] = useState<boolean>(false);
  const [chatOpen, setChatOpen] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  // Handle image selection
  const handleImageSelected = (base64Data: string, mimeType: string, preset?: SamplePreset) => {
    setImagePreview(base64Data);
    setImageBase64(base64Data);
    setImageMime(mimeType);
    setGeneralError(null);

    if (preset) {
      if (preset.genre) setGenre(preset.genre);
      if (preset.tone) setTone(preset.tone);
      if (preset.promptHint) setUserPrompt(preset.promptHint);
    }
  };

  const handleClearImage = () => {
    setImagePreview(null);
    setImageBase64(null);
  };

  const handleReset = () => {
    if (confirm('Start a fresh story studio session? All current story drafts will be cleared.')) {
      setImagePreview(null);
      setImageBase64(null);
      setAnalysisData(null);
      setCurrentStory('');
      setOriginalOpening('');
      setUserPrompt('');
      setGeneralError(null);
    }
  };

  // Trigger Gemini Vision & Ghostwriting API
  const handleGenerateStory = async () => {
    if (!imageBase64) {
      setGeneralError('Please upload an initial image or pick one from the inspiration gallery.');
      return;
    }

    setIsAnalyzing(true);
    setGeneralError(null);

    try {
      const res = await fetch('/api/analyze-and-write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imageBase64,
          mimeType: imageMime,
          genre: genre,
          tone: tone,
          pov: pov,
          hookType: hookType,
          userPrompt: userPrompt,
        }),
      });

      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.error || 'Failed to analyze scene and generate story');
      }

      const data: StoryAnalysisData = result.data;
      setAnalysisData(data);
      setCurrentStory(data.openingParagraph);
      setOriginalOpening(data.openingParagraph);
      if (result.modelUsed) {
        setModelUsed(result.modelUsed);
      }
    } catch (err: any) {
      console.error('Analysis error:', err);
      setGeneralError(err.message || 'Failed to analyze scene. Please check your image or network.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Continue story seamlessly using chat endpoint
  const handleRequestContinuation = async () => {
    if (!currentStory) return;

    setIsContinuing(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            {
              role: 'user',
              text: `Continue the story directly with the next paragraph. Maintain the same tense, atmospheric density, and sensory momentum without repeating what came before. Return only the next story paragraph.`,
            },
          ],
          complexity: 'general',
          roleInstruction:
            'You are continuing the existing literary manuscript seamlessly. Provide only the continuation paragraph.',
          storyContext: {
            storyTitle: analysisData?.storyTitle || 'Untitled',
            genre: genre,
            mood: tone,
            currentStory: currentStory,
            worldLore: analysisData?.worldLore,
            sensoryPalette: analysisData?.sensoryPalette,
          },
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Continuation failed');

      if (data.message) {
        const appended = `${currentStory}\n\n${data.message.trim()}`;
        setCurrentStory(appended);
      }
    } catch (err: any) {
      console.error('Continuation error:', err);
      alert('Could not generate continuation: ' + err.message);
    } finally {
      setIsContinuing(false);
    }
  };

  // Append text from chat to manuscript
  const handleAppendFromChat = (textToAppend: string) => {
    setCurrentStory((prev) => (prev ? `${prev}\n\n${textToAppend.trim()}` : textToAppend.trim()));
  };

  // Copy story
  const handleCopyStory = () => {
    if (!currentStory) return;
    navigator.clipboard.writeText(currentStory);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download markdown
  const handleDownloadStory = () => {
    if (!currentStory) return;
    const title = analysisData?.storyTitle || 'Story Opening';
    const content = `# ${title}\n\n**Genre**: ${genre} | **Mood**: ${tone}\n**Implied Era**: ${analysisData?.sceneBreakdown.historicalEra || 'Unknown'}\n\n---\n\n${currentStory}\n\n---\n\n*Ghostwritten with Aetheria Studio using Gemini Vision & Speech models.*`;

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      {/* Ambient background glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-amber-500/10 blur-[120px] animate-ambient-glow" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 rounded-full bg-emerald-500/5 blur-[140px]" />
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 rounded-full bg-purple-500/5 blur-[120px]" />
      </div>

      {/* Main Navigation Header */}
      <Header
        onReset={handleReset}
        onCopyStory={handleCopyStory}
        copied={copied}
        hasStory={Boolean(currentStory)}
        onToggleChat={() => setChatOpen(!chatOpen)}
        chatOpen={chatOpen}
        hasAudio={Boolean(currentStory)}
        onDownloadStory={handleDownloadStory}
      />

      {/* Workspace Container */}
      <main className="relative z-10 flex-1 max-w-7xl mx-auto w-full px-4 lg:px-8 py-6 sm:py-8 space-y-8">
        {/* Error notification banner */}
        {generalError && (
          <div className="p-4 rounded-2xl bg-red-950/50 border border-red-800/80 text-red-200 text-xs sm:text-sm flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{generalError}</span>
            </div>
            <button
              onClick={() => setGeneralError(null)}
              className="text-xs text-red-400 hover:text-red-200 underline"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* 1. Stage: Source Scene & Creative Direction */}
        <section className="space-y-4">
          <ImageUploader
            imagePreview={imagePreview}
            onImageSelected={handleImageSelected}
            onClearImage={handleClearImage}
            isAnalyzing={isAnalyzing}
          />

          <StorySettingsBar
            genre={genre}
            setGenre={setGenre}
            tone={tone}
            setTone={setTone}
            pov={pov}
            setPov={setPov}
            hookType={hookType}
            setHookType={setHookType}
            userPrompt={userPrompt}
            setUserPrompt={setUserPrompt}
            onGenerate={handleGenerateStory}
            isAnalyzing={isAnalyzing}
            disabled={!imageBase64}
          />
        </section>

        {/* 2. Stage: Story Results & Co-author Studio */}
        {analysisData && (
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-fadeIn">
            {/* Left Column (Manuscript, Audio Narrator, Scene Lore) */}
            <div className={`${chatOpen ? 'lg:col-span-7 xl:col-span-8' : 'lg:col-span-12'} space-y-6`}>
              {/* Story Manuscript Editor */}
              <StoryManuscript
                title={analysisData.storyTitle}
                storyText={currentStory}
                originalOpening={originalOpening}
                onUpdateStory={setCurrentStory}
                alternativeHooks={analysisData.alternativeHooks}
                onRequestContinuation={handleRequestContinuation}
                isContinuing={isContinuing}
              />

              {/* Expressive Audio Narrator (gemini-3.8-flash-tts) */}
              <AudioNarrator storyText={currentStory} />

              {/* Deep Scene Analysis Card */}
              <SceneAnalysisCard analysis={analysisData} modelUsed={modelUsed} />
            </div>

            {/* Right Column: Co-Author Multi-Turn Chatbot */}
            {chatOpen && (
              <div className="lg:col-span-5 xl:col-span-4 sticky top-20 h-[640px] sm:h-[720px] transition-all">
                <GhostwriterChat
                  storyContext={{
                    storyTitle: analysisData.storyTitle,
                    genre: genre,
                    mood: tone,
                    currentStory: currentStory,
                    worldLore: analysisData.worldLore,
                    sensoryPalette: analysisData.sensoryPalette,
                  }}
                  onAppendToStory={handleAppendFromChat}
                  onClose={() => setChatOpen(false)}
                />
              </div>
            )}
          </section>
        )}

        {/* Empty state guidance when no analysis has run yet */}
        {!analysisData && !isAnalyzing && imagePreview && (
          <div className="p-8 rounded-2xl border border-stone-800/80 bg-stone-900/40 text-center space-y-3 max-w-xl mx-auto">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
              <Sparkles className="w-6 h-6" />
            </div>
            <h4 className="font-display font-semibold text-stone-200 text-lg">
              Scene Ready for Vision Dissection
            </h4>
            <p className="text-xs sm:text-sm text-stone-400 leading-relaxed">
              Your image has been framed. Click <strong>"Analyze Scene & Ghostwrite Opening"</strong> above to decipher the lighting, hidden tensions, and craft the opening tale.
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-stone-800/80 bg-stone-950/80 backdrop-blur-sm py-4 px-4 text-center text-xs text-stone-500">
        <p className="flex items-center justify-center gap-1.5 flex-wrap">
          <span>Aetheria Studio</span>
          <span>•</span>
          <span>Vision & Story Intelligence powered by Gemini</span>
          <span>•</span>
          <span className="text-stone-400">gemini-4-argon & gemini-3.8-flash-tts</span>
        </p>
      </footer>
    </div>
  );
}
