import React, { useState, useEffect } from 'react';
import { 
  Product, 
  SaleTransaction, 
  StoreSettings, 
  ActiveTab 
} from './types';
import { 
  getStoredInventory, 
  saveStoredInventory, 
  getStoredSales, 
  saveStoredSales, 
  getStoredSettings, 
  saveStoredSettings, 
  INITIAL_PRODUCTS 
} from './utils/storage';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { SaleTerminalView } from './components/SaleTerminalView';
import { RegisterProductView } from './components/RegisterProductView';
import { InventoryView } from './components/InventoryView';
import { SalesHistoryView } from './components/SalesHistoryView';
import { SettingsView } from './components/SettingsView';
import { ReceiptModal } from './components/ReceiptModal';
import { BarcodeTagModal } from './components/BarcodeTagModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [inventory, setInventory] = useState<Product[]>([]);
  const [sales, setSales] = useState<SaleTransaction[]>([]);
  const [settings, setSettings] = useState<StoreSettings>(getStoredSettings());

  // Modals
  const [selectedReceipt, setSelectedReceipt] = useState<SaleTransaction | null>(null);
  const [selectedBarcodeProduct, setSelectedBarcodeProduct] = useState<Product | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Toast / notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Initialize data on mount
  useEffect(() => {
    const loadedInventory = getStoredInventory();
    const loadedSales = getStoredSales();
    const loadedSettings = getStoredSettings();

    setInventory(loadedInventory);
    setSales(loadedSales);
    setSettings(loadedSettings);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Inventory modifications
  const handleInventoryUpdate = (newInventory: Product[]) => {
    setInventory(newInventory);
    saveStoredInventory(newInventory);
  };

  const handleSaveProduct = (product: Product) => {
    const existingIndex = inventory.findIndex(p => p.id === product.id || p.code === product.code);
    let updated: Product[];

    if (existingIndex >= 0) {
      updated = [...inventory];
      updated[existingIndex] = product;
      showToast(`Updated product "${product.name}"`);
    } else {
      updated = [product, ...inventory];
      showToast(`Registered new product "${product.name}"`);
    }

    handleInventoryUpdate(updated);
    setEditingProduct(null);
    setActiveTab('inventory');
  };

  const handleDeleteProduct = (productId: string) => {
    const updated = inventory.filter(p => p.id !== productId);
    handleInventoryUpdate(updated);
    showToast('Product deleted from inventory');
  };

  const handleUpdateStock = (productId: string, newStock: number) => {
    const updated = inventory.map(p =>
      p.id === productId ? { ...p, stock: newStock } : p
    );
    handleInventoryUpdate(updated);
    showToast('Stock quantity updated');
  };

  const handleQuickRestock = (productId: string, amount: number) => {
    const target = inventory.find(p => p.id === productId);
    if (!target) return;
    const nextStock = target.stock + amount;
    handleUpdateStock(productId, nextStock);
    showToast(`Restocked +${amount} units for ${target.name}`);
  };

  // Sales modifications
  const handleSaleComplete = (newSale: SaleTransaction) => {
    const updatedSales = [...sales, newSale];
    setSales(updatedSales);
    saveStoredSales(updatedSales);
    setSelectedReceipt(newSale);
    showToast(`Sale completed! Receipt ${newSale.receiptNumber}`);
  };

  // Void / Refund sale
  const handleRefund = (saleId: string) => {
    const targetSale = sales.find(s => s.id === saleId);
    if (!targetSale || targetSale.status === 'refunded') return;

    // Restore stock
    const updatedInventory = inventory.map(prod => {
      const saleItem = targetSale.items.find(i => i.productId === prod.id || i.code === prod.code);
      if (saleItem) {
        return {
          ...prod,
          stock: prod.stock + saleItem.quantity
        };
      }
      return prod;
    });

    const updatedSales = sales.map(s =>
      s.id === saleId ? { ...s, status: 'refunded' as const } : s
    );

    handleInventoryUpdate(updatedInventory);
    setSales(updatedSales);
    saveStoredSales(updatedSales);

    if (selectedReceipt?.id === saleId) {
      setSelectedReceipt({ ...selectedReceipt, status: 'refunded' });
    }

    showToast(`Transaction ${targetSale.receiptNumber} refunded & stock restored.`);
  };

  // Settings
  const handleUpdateSettings = (newSettings: StoreSettings) => {
    setSettings(newSettings);
    saveStoredSettings(newSettings);
    showToast('Settings saved successfully');
  };

  // Utilities: Sample data & reset
  const handleLoadSampleData = () => {
    handleInventoryUpdate(INITIAL_PRODUCTS);
    showToast('Sample products loaded successfully!');
  };

  const handleResetData = () => {
    if (confirm('Are you sure you want to completely erase all products and sales logs?')) {
      handleInventoryUpdate([]);
      setSales([]);
      saveStoredSales([]);
      showToast('Store inventory and sales logs reset');
    }
  };

  const handleRestoreBackup = (backup: { settings?: StoreSettings; inventory?: Product[]; sales?: SaleTransaction[] }) => {
    if (backup.settings) handleUpdateSettings(backup.settings);
    if (backup.inventory) handleInventoryUpdate(backup.inventory);
    if (backup.sales) {
      setSales(backup.sales);
      saveStoredSales(backup.sales);
    }
    showToast('Store backup restored!');
  };

  const handleStartTestRun = () => {
    if (inventory.length === 0) {
      handleInventoryUpdate(INITIAL_PRODUCTS);
    }
    setActiveTab('sale');
    showToast('Test Run: Sale terminal ready!');
  };

  const lowStockCount = inventory.filter(i => i.stock <= i.minStock).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-24 md:pb-12">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={0}
        lowStockCount={lowStockCount}
        settings={settings}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            inventory={inventory}
            sales={sales}
            settings={settings}
            setActiveTab={setActiveTab}
            onOpenReceipt={setSelectedReceipt}
            onQuickRestock={handleQuickRestock}
          />
        )}

        {activeTab === 'sale' && (
          <SaleTerminalView
            inventory={inventory}
            settings={settings}
            onSaleComplete={handleSaleComplete}
            onInventoryUpdate={handleInventoryUpdate}
          />
        )}

        {activeTab === 'register' && (
          <RegisterProductView
            initialProduct={editingProduct}
            settings={settings}
            onSaveProduct={handleSaveProduct}
            onOpenBarcodeModal={setSelectedBarcodeProduct}
            onCancelEdit={() => {
              setEditingProduct(null);
              setActiveTab('inventory');
            }}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            inventory={inventory}
            settings={settings}
            onEditProduct={(product) => {
              setEditingProduct(product);
              setActiveTab('register');
            }}
            onDeleteProduct={handleDeleteProduct}
            onUpdateStock={handleUpdateStock}
            onOpenBarcodeModal={setSelectedBarcodeProduct}
            onImportProducts={(imported) => {
              const combined = [...imported, ...inventory];
              // deduplicate by code
              const uniqueMap = new Map<string, Product>();
              combined.forEach(p => uniqueMap.set(p.code, p));
              handleInventoryUpdate(Array.from(uniqueMap.values()));
            }}
            onNavigateToRegister={() => {
              setEditingProduct(null);
              setActiveTab('register');
            }}
          />
        )}

        {activeTab === 'history' && (
          <SalesHistoryView
            sales={sales}
            settings={settings}
            onOpenReceipt={setSelectedReceipt}
            onRefund={handleRefund}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            inventory={inventory}
            sales={sales}
            onUpdateSettings={handleUpdateSettings}
            onLoadSampleData={handleLoadSampleData}
            onResetData={handleResetData}
            onRestoreBackup={handleRestoreBackup}
          />
        )}
      </main>

      {/* Transaction Receipt Modal */}
      {selectedReceipt && (
        <ReceiptModal
          sale={selectedReceipt}
          settings={settings}
          onClose={() => setSelectedReceipt(null)}
          onRefund={handleRefund}
          onNavigateToSettings={() => setActiveTab('settings')}
        />
      )}

      {/* Barcode Tag Modal */}
      {selectedBarcodeProduct && (
        <BarcodeTagModal
          product={selectedBarcodeProduct}
          settings={settings}
          onClose={() => setSelectedBarcodeProduct(null)}
        />
      )}

      {/* Offline Status Indicator */}
      <OfflineIndicator />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 md:bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500/30 text-cyan-200 px-4 py-2.5 rounded-2xl shadow-xl shadow-cyan-950/50 text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
