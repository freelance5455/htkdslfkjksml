import { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  BookOpen,
  ClipboardList,
  CreditCard,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  PlusCircle,
  Settings,
  Shield,
  ShoppingBag,
  TrendingUp,
  Users,
  Wallet,
} from 'lucide-react';
import { apiRequest, setAuthToken } from './api.ts';
import { AdminWorkspace, type AdminTab } from './components/AdminWorkspace.tsx';
import { AuthScreen } from './components/AuthScreen.tsx';
import { CustomerWorkspace, type CustomerTab } from './components/CustomerWorkspace.tsx';
import { DeploymentGuideModal } from './components/DeploymentGuideModal.tsx';
import type { ServiceItem, UpiConfig, UserProfile } from './types.ts';
import { formatInrExact } from './utils/format.ts';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [paymentMode, setPaymentMode] = useState<'upi_direct' | 'razorpay'>('upi_direct');
  const [upiConfig, setUpiConfig] = useState<UpiConfig>({
    merchantUpiId: 'socialboost@okaxis',
    merchantName: 'SOCIAL BOOST',
    upiDirectEnabled: true,
  });

  const [customerTab, setCustomerTab] = useState<CustomerTab>('overview');
  const [adminTab, setAdminTab] = useState<AdminTab>('overview');
  const [deployGuideOpen, setDeployGuideOpen] = useState(false);

  const loadServices = useCallback(async () => {
    try {
      const res = await apiRequest<{
        services: ServiceItem[];
        paymentMode: 'upi_direct' | 'razorpay';
        upiConfig?: UpiConfig;
      }>('/api/services');
      setServices(res.services);
      setPaymentMode(res.paymentMode);
      if (res.upiConfig) {
        setUpiConfig(res.upiConfig);
      }
    } catch {
      // ignore transient startup errors
    }
  }, []);

  useEffect(() => {
    Promise.all([
      apiRequest<{ user: UserProfile | null }>('/api/auth/me')
        .then((res) => setUser(res.user))
        .catch(() => setUser(null)),
      loadServices(),
    ]).finally(() => setAuthChecked(true));
  }, [loadServices]);

  const handleLogout = async () => {
    await apiRequest('/api/auth/logout', { method: 'POST' }).catch(() => undefined);
    setAuthToken(null);
    setUser(null);
    setCustomerTab('overview');
    setAdminTab('overview');
  };

  const handleAuthExpired = useCallback(() => {
    setAuthToken(null);
    setUser(null);
  }, []);

  const handleBalanceSync = useCallback((walletBalancePaise: number) => {
    setUser((prev) => (prev ? { ...prev, walletBalancePaise } : prev));
  }, []);

  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex items-center gap-3 text-sm text-slate-200">
          <div className="h-8 w-8 rounded-xl btn-gradient-primary flex items-center justify-center shadow-lg shadow-fuchsia-500/25">
            <TrendingUp className="h-4 w-4 text-white" />
          </div>
          <span className="font-semibold text-gradient-aurora">Loading SOCIAL BOOST...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <AuthScreen
          services={services}
          paymentMode={paymentMode}
          onAuthenticated={(loggedInUser) => {
            setUser(loggedInUser);
            loadServices();
          }}
          onOpenDeployGuide={() => setDeployGuideOpen(true)}
        />
        <DeploymentGuideModal open={deployGuideOpen} onClose={() => setDeployGuideOpen(false)} />
      </>
    );
  }

  const isAdmin = user.accountType === 'admin';

  const customerNavItems: Array<{ id: CustomerTab; label: string; shortLabel: string; icon: typeof LayoutDashboard }> = [
    { id: 'overview', label: 'Dashboard', shortLabel: 'Home', icon: LayoutDashboard },
    { id: 'order', label: 'Order Now', shortLabel: 'Order', icon: PlusCircle },
    { id: 'orders', label: 'My Orders', shortLabel: 'Orders', icon: ShoppingBag },
    { id: 'wallet', label: 'Wallet & Ledger', shortLabel: 'Wallet', icon: Wallet },
    { id: 'support', label: 'Support', shortLabel: 'Help', icon: HelpCircle },
  ];

  const adminNavItems: Array<{ id: AdminTab; label: string; shortLabel: string; icon: typeof LayoutDashboard }> = [
    { id: 'overview', label: 'Revenue & Overview', shortLabel: 'Revenue', icon: LayoutDashboard },
    { id: 'orders', label: 'All Orders', shortLabel: 'Orders', icon: ClipboardList },
    { id: 'services', label: 'Services & Pricing', shortLabel: 'Services', icon: Settings },
    { id: 'customers', label: 'Customers', shortLabel: 'Users', icon: Users },
    { id: 'payments', label: 'Payments & Refunds', shortLabel: 'Payments', icon: CreditCard },
    { id: 'support', label: 'Support Desk', shortLabel: 'Support', icon: HelpCircle },
    { id: 'audit', label: 'Audit Logs', shortLabel: 'Audit', icon: Activity },
  ];

  return (
    <div className="min-h-screen text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 bg-[#0c0d24]/90 backdrop-blur-xl border-r border-white/12">
        <div className="h-16 px-5 flex items-center gap-2.5 border-b border-white/10">
          <div className="h-8 w-8 rounded-lg btn-gradient-primary flex items-center justify-center shrink-0 shadow-md shadow-fuchsia-500/20">
            <TrendingUp className="h-4 w-4 text-white" />
          </div>
          <span className="text-sm font-extrabold tracking-tight text-gradient-aurora whitespace-nowrap">
            SOCIAL BOOST
          </span>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {!isAdmin
            ? customerNavItems.map((item) => {
                const Icon = item.icon;
                const active = customerTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setCustomerTab(item.id)}
                    className={`w-full min-h-[44px] px-3.5 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer whitespace-nowrap ${
                      active
                        ? 'btn-gradient-primary text-white shadow-md shadow-violet-600/25'
                        : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                    }`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-white' : 'text-cyan-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })
            : adminNavItems.map((item) => {
                const Icon = item.icon;
                const active = adminTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setAdminTab(item.id)}
                    className={`w-full min-h-[44px] px-3.5 rounded-xl text-xs font-semibold flex items-center gap-3 transition-all cursor-pointer whitespace-nowrap ${
                      active
                        ? 'btn-gradient-primary text-white shadow-md shadow-violet-600/25'
                        : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                    }`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-white' : 'text-fuchsia-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}

          <div className="pt-4 mt-4 border-t border-white/10">
            <button
              type="button"
              onClick={() => setDeployGuideOpen(true)}
              className="w-full min-h-[44px] px-3.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-white/[0.06] flex items-center gap-3 cursor-pointer whitespace-nowrap"
            >
              <BookOpen className="h-4 w-4 shrink-0 text-amber-400" />
              <span>Deploy & APK Guide</span>
            </button>
          </div>
        </nav>

        <div className="p-4 border-t border-white/10 space-y-3">
          <div className="text-xs">
            <div className="font-semibold text-white truncate">{user.name}</div>
            <div className="text-[11px] text-cyan-300/80 truncate">{user.email}</div>
            {!isAdmin && (
              <div className="text-[11px] font-mono font-semibold text-gradient-ocean mt-1">
                Balance: {formatInrExact(user.walletBalancePaise)}
              </div>
            )}
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full min-h-[40px] px-3 rounded-xl border border-white/12 bg-white/[0.05] hover:bg-white/[0.1] text-xs font-medium text-slate-200 flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5 text-rose-400" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 md:pl-64 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 h-[52px] md:h-16 bg-[#0a0b22]/85 backdrop-blur-xl border-b border-white/10 px-4 sm:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="md:hidden h-7 w-7 rounded-lg btn-gradient-primary flex items-center justify-center shrink-0">
              <TrendingUp className="h-3.5 w-3.5 text-white" />
            </div>
            <span className="text-sm font-extrabold text-gradient-aurora truncate">
              {isAdmin ? 'Admin Console' : 'SOCIAL BOOST'}
            </span>
            <span className="hidden sm:inline text-slate-500">/</span>
            <span className="hidden sm:inline text-xs font-medium text-cyan-300 whitespace-nowrap">
              {isAdmin
                ? adminNavItems.find((i) => i.id === adminTab)?.label
                : customerNavItems.find((i) => i.id === customerTab)?.label}
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {isAdmin && (
              <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-medium text-fuchsia-300 whitespace-nowrap">
                <Shield className="h-3.5 w-3.5" />
                <span>Admin Protected</span>
              </span>
            )}
            {!isAdmin && (
              <button
                type="button"
                onClick={() => setCustomerTab('wallet')}
                className="min-h-[36px] px-3 rounded-lg sb-surface-inner text-xs font-mono font-bold text-emerald-300 whitespace-nowrap cursor-pointer"
              >
                {formatInrExact(user.walletBalancePaise)}
              </button>
            )}
            <button
              type="button"
              onClick={() => setDeployGuideOpen(true)}
              className="md:hidden min-h-[36px] px-2.5 rounded-lg bg-white/[0.06] text-xs text-amber-300 cursor-pointer"
              aria-label="Deployment and APK Guide"
            >
              <BookOpen className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="md:hidden min-h-[36px] px-2.5 rounded-lg bg-white/[0.06] text-xs text-rose-300 cursor-pointer"
              aria-label="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>

        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6">
          {!isAdmin ? (
            <CustomerWorkspace
              user={user}
              services={services}
              paymentMode={paymentMode}
              upiConfig={upiConfig}
              activeTab={customerTab}
              onChangeTab={setCustomerTab}
              onBalanceSync={handleBalanceSync}
              onAuthExpired={handleAuthExpired}
            />
          ) : (
            <AdminWorkspace
              user={user}
              activeTab={adminTab}
              onChangeTab={setAdminTab}
              onServicesChanged={loadServices}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Thumb-Zone Tab Bar (60px height) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-[60px] pb-safe bg-[#0b0c24]/95 backdrop-blur-xl border-t border-white/12"
      >
        <div className="grid h-full items-center grid-cols-5">
          {(!isAdmin ? customerNavItems : adminNavItems.slice(0, 5)).map((item) => {
            const Icon = item.icon;
            const active = !isAdmin ? customerTab === item.id : adminTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  if (!isAdmin) {
                    setCustomerTab(item.id as CustomerTab);
                  } else {
                    setAdminTab(item.id as AdminTab);
                  }
                }}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                  active ? 'text-cyan-300' : 'text-slate-400'
                }`}
              >
                <Icon className={`h-[19px] w-[19px] ${active ? 'text-fuchsia-400' : ''}`} />
                <span className="text-[10px] font-semibold tracking-tight whitespace-nowrap">
                  {item.shortLabel}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      <DeploymentGuideModal open={deployGuideOpen} isAdmin={isAdmin} onClose={() => setDeployGuideOpen(false)} />
    </div>
  );
}
