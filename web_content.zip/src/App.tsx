import { useCallback, useEffect, useRef, useState } from "react";
import { ChatPage } from "./components/ChatPage";
import { ConfirmDialog } from "./components/ConfirmDialog";
import { HistoryPage } from "./components/HistoryPage";
import { PrivacyAboutPage } from "./components/PrivacyAboutPage";
import { SettingsPage } from "./components/SettingsPage";
import { Sidebar } from "./components/Sidebar";
import { TopBar } from "./components/TopBar";
import { WelcomePage } from "./components/WelcomePage";
import type {
  AppPage,
  AppSettings,
  ChatMessage,
  ChatSession,
  ImageAttachment,
  ServerHealth,
  UserProfile,
} from "./types/chat";
import {
  DEMO_USER,
  deriveChatTitle,
  generateId,
  hasCompletedOnboarding,
  loadChats,
  loadSettings,
  loadUser,
  markOnboardingCompleted,
  saveChats,
  saveSettings,
  saveUser,
} from "./utils/storage";

export default function App() {
  const [chats, setChats] = useState<ChatSession[]>(() => loadChats());
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [user, setUser] = useState<UserProfile>(() => loadUser());

  const [currentPage, setCurrentPage] = useState<AppPage>(() => {
    const existingChats = loadChats();
    if (!hasCompletedOnboarding() && existingChats.length === 0) {
      return "welcome";
    }
    return "chat";
  });

  const [activeChatId, setActiveChatId] = useState<string | null>(() => {
    const existingChats = loadChats();
    return existingChats.length > 0 ? existingChats[0].id : null;
  });

  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth >= 1024;
    }
    return true;
  });

  const [health, setHealth] = useState<ServerHealth | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  const [chatToDelete, setChatToDelete] = useState<ChatSession | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  const [systemPrefersDark, setSystemPrefersDark] = useState<boolean>(() => {
    if (typeof window !== "undefined" && window.matchMedia) {
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync system dark mode listener
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const listener = (e: MediaQueryListEvent) => setSystemPrefersDark(e.matches);
    mq.addEventListener("change", listener);
    return () => mq.removeEventListener("change", listener);
  }, []);

  const resolvedDark =
    settings.theme === "dark" ||
    (settings.theme === "system" && systemPrefersDark);

  // Apply .dark class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (resolvedDark) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [resolvedDark]);

  // Persist settings and chats
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveChats(chats);
  }, [chats]);

  // Fetch server health (AI configuration & Google Sign-In availability)
  useEffect(() => {
    let active = true;
    fetch("/api/health")
      .then((res) => res.json())
      .then((data: ServerHealth) => {
        if (active) setHealth(data);
      })
      .catch(() => {
        if (active) {
          setHealth({
            aiConfigured: false,
            googleAuthConfigured: false,
            googleClientId: null,
            model: "gemini-4-hydrogen",
          });
        }
      });
    return () => {
      active = false;
    };
  }, []);

  const activeChat = chats.find((c) => c.id === activeChatId) || null;

  const stopStreaming = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
  }, []);

  const streamResponseForChat = useCallback(
    async (
      targetChatId: string,
      historyForApi: ChatMessage[],
      assistantMessageId: string
    ) => {
      stopStreaming();

      const controller = new AbortController();
      abortControllerRef.current = controller;
      setIsStreaming(true);
      setErrorBanner(null);

      const updateAssistantMessage = (
        updater: (msg: ChatMessage) => ChatMessage
      ) => {
        setChats((prev) =>
          prev.map((chat) => {
            if (chat.id !== targetChatId) return chat;
            return {
              ...chat,
              updatedAt: Date.now(),
              messages: chat.messages.map((m) =>
                m.id === assistantMessageId ? updater(m) : m
              ),
            };
          })
        );
      };

      try {
        const payload = {
          languagePreference: settings.language,
          messages: historyForApi.map((m) => ({
            role: m.role,
            text: m.text,
            image: m.image
              ? {
                  mimeType: m.image.mimeType,
                  data: m.image.data,
                }
              : undefined,
          })),
        };

        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: controller.signal,
        });

        const contentType = response.headers.get("content-type") || "";

        if (!response.ok || !contentType.includes("text/event-stream")) {
          let errorMessage =
            "Could not get a response from MIH.AI. Please try again.";
          try {
            const errJson = await response.json();
            if (errJson?.message) {
              errorMessage = errJson.message;
            }
          } catch {
            // Keep default message
          }
          updateAssistantMessage((m) => ({ ...m, error: errorMessage }));
          setErrorBanner(errorMessage);
          setIsStreaming(false);
          abortControllerRef.current = null;
          return;
        }

        const reader = response.body?.getReader();
        if (!reader) {
          throw new Error("Streaming response unavailable.");
        }

        const decoder = new TextDecoder();
        let buffer = "";
        let receivedAnyDelta = false;
        let receivedError = false;

        const processSseBlock = (rawEvent: string) => {
          const lines = rawEvent.split("\n");
          for (const line of lines) {
            if (!line.startsWith("data:")) continue;
            const jsonStr = line.slice(5).trim();
            if (!jsonStr) continue;
            try {
              const evt = JSON.parse(jsonStr) as {
                type: "delta" | "done" | "error";
                text?: string;
                message?: string;
              };
              if (evt.type === "delta" && evt.text) {
                receivedAnyDelta = true;
                updateAssistantMessage((m) => ({
                  ...m,
                  text: m.text + evt.text,
                }));
              } else if (evt.type === "error") {
                receivedError = true;
                const errMsg =
                  evt.message || "The AI service encountered an error.";
                updateAssistantMessage((m) => ({ ...m, error: errMsg }));
                setErrorBanner(errMsg);
              }
            } catch {
              // Ignore malformed SSE line
            }
          }
        };

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");
          const events = buffer.split("\n\n");
          buffer = events.pop() || "";

          for (const rawEvent of events) {
            processSseBlock(rawEvent);
          }
        }

        if (buffer.trim()) {
          processSseBlock(buffer);
        }

        if (!receivedAnyDelta && !receivedError) {
          const emptyMsg =
            "MIH.AI did not receive a response from the AI service. Please try again.";
          updateAssistantMessage((m) => (m.text ? m : { ...m, error: emptyMsg }));
          setErrorBanner(emptyMsg);
        }
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") {
          // User stopped generation; keep whatever partial text streamed
        } else {
          const msg =
            err instanceof Error && err.message
              ? `Network error: ${err.message}`
              : "Network connection lost while waiting for MIH.AI.";
          updateAssistantMessage((m) =>
            m.text ? m : { ...m, error: msg }
          );
          setErrorBanner(msg);
        }
      } finally {
        setIsStreaming(false);
        if (abortControllerRef.current === controller) {
          abortControllerRef.current = null;
        }
      }
    },
    [settings.language, stopStreaming]
  );

  const handleSendMessage = useCallback(
    (text: string, image?: ImageAttachment) => {
      if (isStreaming) return;
      const now = Date.now();

      const userMessage: ChatMessage = {
        id: generateId(),
        role: "user",
        text,
        image: image
          ? {
              mimeType: image.mimeType,
              data: image.data,
              name: image.name,
            }
          : undefined,
        createdAt: now,
      };

      const assistantPlaceholder: ChatMessage = {
        id: generateId(),
        role: "model",
        text: "",
        createdAt: now + 1,
      };

      let targetChatId = activeChat?.id || null;
      let historyForApi: ChatMessage[] = [];

      if (!targetChatId) {
        const newChat: ChatSession = {
          id: generateId(),
          title: deriveChatTitle(text, Boolean(image)),
          messages: [userMessage, assistantPlaceholder],
          createdAt: now,
          updatedAt: now,
        };
        targetChatId = newChat.id;
        historyForApi = [userMessage];
        setChats((prev) => [newChat, ...prev]);
        setActiveChatId(newChat.id);
      } else {
        const currentMessages = activeChat?.messages || [];
        historyForApi = [...currentMessages, userMessage];
        setChats((prev) =>
          prev
            .map((chat) => {
              if (chat.id !== targetChatId) return chat;
              const isFirstTurn = chat.messages.length === 0;
              return {
                ...chat,
                title: isFirstTurn
                  ? deriveChatTitle(text, Boolean(image))
                  : chat.title,
                messages: [...chat.messages, userMessage, assistantPlaceholder],
                updatedAt: now,
              };
            })
            .sort((a, b) => b.updatedAt - a.updatedAt)
        );
      }

      setCurrentPage("chat");
      markOnboardingCompleted();
      streamResponseForChat(
        targetChatId,
        historyForApi,
        assistantPlaceholder.id
      );
    },
    [activeChat, isStreaming, streamResponseForChat]
  );

  const handleRegenerateLast = useCallback(() => {
    if (!activeChat || isStreaming) return;

    const msgs = activeChat.messages;
    if (msgs.length === 0) return;

    // Remove trailing model message(s) back to the last user message
    let cutIndex = msgs.length - 1;
    while (cutIndex >= 0 && msgs[cutIndex].role === "model") {
      cutIndex--;
    }
    if (cutIndex < 0) return;

    const baseHistory = msgs.slice(0, cutIndex + 1);
    const newAssistantMsg: ChatMessage = {
      id: generateId(),
      role: "model",
      text: "",
      createdAt: Date.now(),
    };

    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChat.id
          ? {
              ...c,
              messages: [...baseHistory, newAssistantMsg],
              updatedAt: Date.now(),
            }
          : c
      )
    );

    streamResponseForChat(activeChat.id, baseHistory, newAssistantMsg.id);
  }, [activeChat, isStreaming, streamResponseForChat]);

  const handleNewChat = useCallback(() => {
    stopStreaming();
    setErrorBanner(null);
    setActiveChatId(null);
    setCurrentPage("chat");
    markOnboardingCompleted();
  }, [stopStreaming]);

  const handleSelectChat = useCallback(
    (chatId: string) => {
      stopStreaming();
      setErrorBanner(null);
      setActiveChatId(chatId);
      setCurrentPage("chat");
    },
    [stopStreaming]
  );

  const handleRenameChat = useCallback((chatId: string, newTitle: string) => {
    setChats((prev) =>
      prev.map((c) => (c.id === chatId ? { ...c, title: newTitle } : c))
    );
  }, []);

  const handleConfirmDeleteChat = useCallback(() => {
    if (!chatToDelete) return;
    if (activeChatId === chatToDelete.id) {
      stopStreaming();
      setActiveChatId(null);
    }
    setChats((prev) => prev.filter((c) => c.id !== chatToDelete.id));
    setChatToDelete(null);
  }, [activeChatId, chatToDelete, stopStreaming]);

  const handleConfirmClearHistory = useCallback(() => {
    stopStreaming();
    setChats([]);
    setActiveChatId(null);
    setConfirmClearAll(false);
  }, [stopStreaming]);

  const handleToggleTheme = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      theme: resolvedDark ? "light" : "dark",
    }));
  }, [resolvedDark]);

  const handleSignInGoogleUser = useCallback((googleUser: UserProfile) => {
    setUser(googleUser);
    saveUser(googleUser);
  }, []);

  const handleSignOut = useCallback(() => {
    setUser(DEMO_USER);
    saveUser(DEMO_USER);
  }, []);

  return (
    <div className="h-dvh w-full flex overflow-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        currentPage={currentPage}
        onNavigate={(page) => setCurrentPage(page)}
        chats={chats}
        activeChatId={activeChatId}
        onSelectChat={handleSelectChat}
        onNewChat={handleNewChat}
        onRenameChat={handleRenameChat}
        onRequestDeleteChat={(chat) => setChatToDelete(chat)}
        user={user}
      />

      <div className="flex-1 flex flex-col min-w-0 h-full">
        <TopBar
          sidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
          currentPage={currentPage}
          activeChatTitle={activeChat?.title || null}
          onNewChat={handleNewChat}
          theme={settings.theme}
          resolvedDark={resolvedDark}
          onToggleTheme={handleToggleTheme}
          onNavigateChat={() => setCurrentPage("chat")}
        />

        {currentPage === "welcome" && (
          <WelcomePage
            health={health}
            user={user}
            onStartChat={() => {
              markOnboardingCompleted();
              setCurrentPage("chat");
            }}
            onOpenAbout={() => setCurrentPage("about")}
            onOpenSettings={() => setCurrentPage("settings")}
          />
        )}

        {currentPage === "chat" && (
          <ChatPage
            messages={activeChat?.messages || []}
            isStreaming={isStreaming}
            errorBanner={errorBanner}
            onDismissError={() => setErrorBanner(null)}
            health={health}
            language={settings.language}
            onSendMessage={handleSendMessage}
            onStopStreaming={stopStreaming}
            onRegenerateLast={handleRegenerateLast}
            onNewChat={handleNewChat}
            onOpenAbout={() => setCurrentPage("about")}
          />
        )}

        {currentPage === "history" && (
          <HistoryPage
            chats={chats}
            onSelectChat={handleSelectChat}
            onNewChat={handleNewChat}
            onRenameChat={handleRenameChat}
            onRequestDeleteChat={(chat) => setChatToDelete(chat)}
            onOpenPrivacy={() => setCurrentPage("about")}
          />
        )}

        {currentPage === "settings" && (
          <SettingsPage
            settings={settings}
            onUpdateSettings={setSettings}
            chatCount={chats.length}
            onRequestClearHistory={() => setConfirmClearAll(true)}
            health={health}
            user={user}
            onSignInGoogleUser={handleSignInGoogleUser}
            onSignOut={handleSignOut}
            onNavigate={(page) => setCurrentPage(page)}
          />
        )}

        {currentPage === "about" && (
          <PrivacyAboutPage
            health={health}
            onBackToChat={() => setCurrentPage("chat")}
          />
        )}
      </div>

      {/* Delete Single Chat Confirmation */}
      <ConfirmDialog
        open={Boolean(chatToDelete)}
        title="Delete conversation?"
        description={
          chatToDelete
            ? `This will permanently delete "${chatToDelete.title}" from your local chat history.`
            : ""
        }
        confirmLabel="Delete Chat"
        destructive
        onConfirm={handleConfirmDeleteChat}
        onCancel={() => setChatToDelete(null)}
      />

      {/* Clear All History Confirmation */}
      <ConfirmDialog
        open={confirmClearAll}
        title="Clear all chat history?"
        description="All saved conversations and attached photos will be removed from this browser. This action cannot be undone."
        confirmLabel="Clear All"
        destructive
        onConfirm={handleConfirmClearHistory}
        onCancel={() => setConfirmClearAll(false)}
      />
    </div>
  );
}
