/**
 * HELENA - Assistente de Campo & Atlas Anatômico Veterinário 3D
 * 2 Cérebros (Gemini + Groq) com regra de consenso e fallback "1 cérebro"
 */

import React, { useState, useEffect, useCallback } from 'react';
import { HelenaRing } from './components/HelenaRing';
import { SubtleMenu } from './components/SubtleMenu';
import { VeterinaryImageModal } from './components/VeterinaryImageModal';
import { LibraryModal } from './components/LibraryModal';
import { AdminModal } from './components/AdminModal';
import { SettingsModal } from './components/SettingsModal';
import { HistoryModal } from './components/HistoryModal';
import { FilesModal } from './components/FilesModal';
import { DiseasesModal } from './components/DiseasesModal';
import { NewsSourcePopup, NewsSourceInfo } from './components/NewsSourcePopup';
import { 
  OwnerLoginModal, 
  ChangePasswordModal, 
  verifyOwnerCredentials 
} from './components/AuthModals';
import { 
  RingState, 
  ActiveModal, 
  AppSettings 
} from './types';
import { 
  loadSettings, 
  saveSettings, 
  isUserAuthenticated, 
  setAuthenticated,
  getStoredPasswordHash 
} from './services/storage';
import { helenaVoice } from './services/voice';
import { askBrainsWithConsensus } from './services/brains';
import { MessageSquare, Send, Lock } from 'lucide-react';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(loadSettings);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(isUserAuthenticated);
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState<boolean>(false);
  const [isFirstAccessModal, setIsFirstAccessModal] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const [ringState, setRingState] = useState<RingState>('repouso');
  const [activeModal, setActiveModal] = useState<ActiveModal>('none');
  const [libraryQuery, setLibraryQuery] = useState<string>('');
  const [subtleStatus, setSubtleStatus] = useState<string>('');
  const [isMicListening, setIsMicListening] = useState<boolean>(false);

  // Discrete text chat input (alternative to voice)
  const [showTextInput, setShowTextInput] = useState<boolean>(false);
  const [textQuery, setTextQuery] = useState<string>('');

  // News and information source popup
  const [newsSource, setNewsSource] = useState<NewsSourceInfo | null>(null);

  // Update voice engine configuration on settings change
  useEffect(() => {
    helenaVoice.updateConfig(
      settings.wakeWord,
      settings.speechRate,
      settings.speechMuted
    );
  }, [settings]);

  // Handle voice or text question processing
  const handleProcessQuery = useCallback(async (query: string) => {
    if (!query.trim()) return;

    // Check for voice command to open 3D model ("Helena, mostre o coração do cavalo", "mostre [modelo]")
    const matchShowModel = query.match(/(?:mostre|abrir|abra|ver|veja|mostra)\s+(?:o|a|os|as)?\s*(.+)/i);
    if (matchShowModel && matchShowModel[1]) {
      const modelTerm = matchShowModel[1].replace(/[?.!]/g, '').trim();
      setRingState('falando');
      setSubtleStatus(`Abrindo modelo: ${modelTerm}`);
      helenaVoice.speak(`Abrindo o modelo de ${modelTerm} na biblioteca anatômica.`, () => {
        setRingState('repouso');
        setLibraryQuery(modelTerm);
        setActiveModal('library');
      });
      return;
    }

    // Check for voice command to open diseases library ("Helena, abra doenças", "mostre as doenças", "patologias veterinárias")
    const matchDiseases = query.match(/(?:doen[cç]a|patologia|guia cl[ií]nico)/i);
    if (matchDiseases) {
      setRingState('falando');
      setSubtleStatus('Abrindo guia de doenças');
      helenaVoice.speak('Abrindo o guia clínico de doenças e patologias veterinárias.', () => {
        setRingState('repouso');
        setActiveModal('diseases');
      });
      return;
    }

    setRingState('pensando');
    setSubtleStatus('Consultando 2 cérebros...');

    try {
      const result = await askBrainsWithConsensus(query, settings);

      if (result.isSingleBrainFallback) {
        setSubtleStatus('1 cérebro');
      } else if (result.hasConsensus) {
        setSubtleStatus('Consenso atingido (2 cérebros)');
      } else {
        setSubtleStatus('Divergência explicada');
      }

      setRingState('falando');
      helenaVoice.speak(result.consensusText, () => {
        setRingState('repouso');
        setTimeout(() => setSubtleStatus(''), 5000);

        // Open news or source popup if present
        if (result.sourceInfo && result.sourceInfo.url) {
          setNewsSource({
            url: result.sourceInfo.url,
            title: result.sourceInfo.title,
            query,
            snippet: result.sourceInfo.snippet,
          });
        }
      });
    } catch (err: any) {
      console.error('Query processing error:', err);
      setRingState('falando');
      helenaVoice.speak('Tive uma dificuldade ao consultar as respostas. Verifique suas chaves na aba Admin.', () => {
        setRingState('repouso');
      });
    }
  }, [settings]);

  // Setup Voice Service Callbacks
  useEffect(() => {
    helenaVoice.setCallbacks({
      onWakeWordDetected: (word) => {
        setRingState('ouvindo');
        setSubtleStatus(`HELENA ouvindo...`);
      },
      onListeningResult: (transcript) => {
        handleProcessQuery(transcript);
      },
      onSpeechStart: () => {
        setRingState('falando');
      },
      onSpeechEnd: () => {
        setRingState('repouso');
      },
      onError: (err) => {
        console.warn('Voice error:', err);
      },
    });
  }, [handleProcessQuery]);

  // Toggle Continuous Microphone Listening
  const toggleListening = () => {
    if (isMicListening) {
      helenaVoice.stopListening();
      setIsMicListening(false);
      setSubtleStatus('');
    } else {
      const started = helenaVoice.startListening();
      if (started) {
        setIsMicListening(true);
        setSubtleStatus(`Diga "${settings.wakeWord}" para falar`);
        setTimeout(() => setSubtleStatus(''), 4000);
      }
    }
  };

  // Toggle Mute
  const toggleMute = () => {
    const updated = !settings.speechMuted;
    const newSettings = { ...settings, speechMuted: updated };
    setSettings(newSettings);
    saveSettings(newSettings);
    if (updated) {
      helenaVoice.stopSpeaking();
    }
  };

  // Save Settings from Admin
  const handleSaveSettings = (updated: AppSettings) => {
    setSettings(updated);
    saveSettings(updated);
  };

  // Login handler
  const handleAttemptLogin = async (email: string, pass: string) => {
    setLoginError(null);
    const isValid = await verifyOwnerCredentials(pass);
    if (isValid) {
      setIsAuthenticated(true);
      setAuthenticated(true);
      if (activeModal === 'login') {
        setActiveModal('admin');
      }

      // Check if this is first access
      const hasChangedPass = Boolean(getStoredPasswordHash());
      if (!hasChangedPass) {
        setIsFirstAccessModal(true);
        setShowPasswordChangeModal(true);
      }
    } else {
      setLoginError('Senha de acesso incorreta para o proprietário.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAuthenticated(false);
    setActiveModal('none');
  };

  const handlePasswordChangedSuccessfully = () => {
    setShowPasswordChangeModal(false);
    setIsFirstAccessModal(false);
    const updated = { ...settings, isPasswordChanged: true };
    setSettings(updated);
    saveSettings(updated);
  };

  return (
    <div className="relative w-screen h-[100dvh] bg-black text-[#CDEBD8] overflow-hidden select-none font-sans">
      {/* Background & Central Neon Green Ring */}
      <HelenaRing
        state={ringState}
        onStateChange={setRingState}
        subtleStatusText={subtleStatus}
        isPaused={activeModal !== 'none'}
      />

      {/* Subtle Top Right Navigation Menu */}
      <SubtleMenu
        onOpenModal={(modal) => setActiveModal(modal)}
        isListening={isMicListening}
        onToggleListening={toggleListening}
        isMuted={settings.speechMuted}
        onToggleMute={toggleMute}
      />

      {/* Discrete Floating Text Input Toggle (top left subtle pill) */}
      <div className="fixed top-4 left-4 z-30 opacity-20 hover:opacity-100 transition-opacity">
        <button
          onClick={() => setShowTextInput(!showTextInput)}
          className="p-2.5 rounded-full bg-black/40 border border-[#14502D] text-[#2FD16F] hover:text-white transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center backdrop-blur-sm cursor-pointer"
          title="Digitar pergunta para a HELENA"
        >
          <MessageSquare className="w-4 h-4" />
        </button>
      </div>

      {/* Discrete Floating Text Query Bar */}
      {showTextInput && (
        <div className="fixed top-16 left-4 z-30 w-72 max-w-[80vw] animate-fade-in">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!textQuery.trim()) return;
              handleProcessQuery(textQuery);
              setTextQuery('');
              setShowTextInput(false);
            }}
            className="flex items-center space-x-1.5 p-1.5 bg-black/90 border border-[#14502D] rounded-xl shadow-xl backdrop-blur-md"
          >
            <input
              type="text"
              value={textQuery}
              onChange={(e) => setTextQuery(e.target.value)}
              placeholder="Perguntar à HELENA..."
              className="flex-1 px-3 py-1.5 text-xs bg-transparent text-white placeholder-[#CDEBD8]/40 focus:outline-none min-h-[36px]"
              autoFocus
            />
            <button
              type="submit"
              className="p-2 bg-[#0E7A3D] hover:bg-[#17B35A] text-white rounded-lg transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}

      {/* Botão Oculto da Aba Admin (Canto Inferior Direito da Tela - Opacidade 10% que acende ao passar o dedo/cursor) */}
      <div className="fixed bottom-2.5 right-2.5 z-40 opacity-10 hover:opacity-100 focus-within:opacity-100 transition-opacity duration-300">
        <button
          onClick={() => setActiveModal('admin')}
          className="p-2 rounded-full bg-black/70 border border-[#14502D] hover:border-[#2FD16F] text-[#2FD16F] hover:text-white transition-all shadow-xl backdrop-blur-md cursor-pointer min-h-[38px] min-w-[38px] flex items-center justify-center"
          title="Painel Admin Oculto (Ajustar Chaves API & Modelos)"
          aria-label="Painel Admin Oculto"
        >
          <Lock className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Modals */}
      <DiseasesModal
        isOpen={activeModal === 'diseases'}
        onClose={() => setActiveModal('none')}
        onSpeak={(text) => helenaVoice.speak(text)}
      />

      <VeterinaryImageModal
        isOpen={activeModal === 'image'}
        onClose={() => setActiveModal('none')}
        settings={settings}
        onSpeak={(text) => helenaVoice.speak(text)}
      />

      <LibraryModal
        isOpen={activeModal === 'library'}
        onClose={() => {
          setActiveModal('none');
          setLibraryQuery('');
        }}
        settings={settings}
        initialQuery={libraryQuery}
      />

      <AdminModal
        settings={settings}
        isOpen={activeModal === 'admin'}
        onClose={() => setActiveModal('none')}
        onSaveSettings={handleSaveSettings}
        onChangePassword={() => setShowPasswordChangeModal(true)}
        onLogout={handleLogout}
      />

      <SettingsModal
        settings={settings}
        isOpen={activeModal === 'settings'}
        onClose={() => setActiveModal('none')}
        onUpdateSettings={(partial) => {
          const updated = { ...settings, ...partial };
          setSettings(updated);
          saveSettings(updated);
        }}
      />

      <HistoryModal
        isOpen={activeModal === 'history'}
        onClose={() => setActiveModal('none')}
      />

      <FilesModal
        settings={settings}
        isOpen={activeModal === 'files'}
        onClose={() => setActiveModal('none')}
        onModelReceived={() => setActiveModal('library')}
      />

      {/* Pop-up Automático com Site da Notícia ou Informação */}
      <NewsSourcePopup
        source={newsSource}
        isOpen={Boolean(newsSource)}
        onClose={() => setNewsSource(null)}
      />

      {/* Password Change Modal */}
      <ChangePasswordModal
        isOpen={showPasswordChangeModal}
        isFirstAccess={isFirstAccessModal}
        onSuccess={handlePasswordChangedSuccessfully}
        onCancel={() => setShowPasswordChangeModal(false)}
      />
    </div>
  );
}
