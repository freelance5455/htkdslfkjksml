/**
 * Sales & Logistics Pro 2026 - Mobile Application Engine
 * Pure Offline Native React + IndexedDB + PWA
 */

import React, { useEffect, useState, useTransition } from 'react';
import {
  Customer,
  Product,
  Visit,
  Invoice,
  InvoiceItem,
  ReturnRecord,
  TreasuryMove,
  PaymentRecord,
  getAll,
  getById,
  putItem,
  deleteItem,
  seedInitialDataIfNeeded,
  getGroups,
  isDayClosed as checkDayClosed,
  logChange,
  exportDatabaseBackup,
  importDatabaseBackup,
  generateUID,
} from './db/indexedDB';
import {
  CartItem,
  calcInvoice,
  allocatePaymentToInvoices,
  getTodayDateString,
  getArabicDayName,
  formatMoney,
} from './utils/calc';
import { sound } from './utils/sound';
import {
  printInvoiceReceipt,
  printPaymentReceipt,
  printReportDocument,
  printVanInventoryReport,
  printMainInventoryReport,
  printGeneralReport,
} from './utils/printer';

import { MobileHeader } from './components/MobileHeader';
import { BottomNav, ActiveTab } from './components/BottomNav';
import { SidebarDrawer } from './components/SidebarDrawer';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { CustomerCardModal } from './components/CustomerCardModal';
import { PaymentModal } from './components/PaymentModal';
import { ReturnModal } from './components/ReturnModal';
import { CustomerEditModal } from './components/CustomerEditModal';
import { ProductModal } from './components/ProductModal';
import { VanLoadModal } from './components/VanLoadModal';

import { DashboardView } from './views/DashboardView';
import { VisitsView } from './views/VisitsView';
import { InvoiceView } from './views/InvoiceView';
import { InventoryView } from './views/InventoryView';
import { TreasuryView } from './views/TreasuryView';
import { ReturnsView } from './views/ReturnsView';
import { DayCloseView } from './views/DayCloseView';
import { ReportsView } from './views/ReportsView';
import { DebtView } from './views/DebtView';
import { SettingsView } from './views/SettingsView';

export default function App() {
  const [isPending, startTransition] = useTransition();

  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Connectivity & Sync
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  // Route Day
  const todayDate = getTodayDateString();
  const [selectedDay, setSelectedDay] = useState<string>(() => {
    const todayName = getArabicDayName(todayDate);
    return todayName === 'الجمعة' ? 'السبت' : todayName;
  });

  // Data Stores
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [visits, setVisits] = useState<Visit[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [returns, setReturns] = useState<ReturnRecord[]>([]);
  const [treasuryMoves, setTreasuryMoves] = useState<TreasuryMove[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [vanInventory, setVanInventory] = useState<Map<string, number>>(new Map());
  const [mainInventory, setMainInventory] = useState<Map<string, number>>(new Map());
  const [groups, setGroups] = useState<string[]>([]);
  const [settings, setSettings] = useState<Record<string, string | number>>({});
  const [isTodayClosed, setIsTodayClosed] = useState(false);

  // Cart & POS State
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);

  // Modals
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [activeCustomerCard, setActiveCustomerCard] = useState<Customer | null>(null);
  const [paymentCustomer, setPaymentCustomer] = useState<Customer | null>(null);
  const [returnCustomer, setReturnCustomer] = useState<Customer | null>(null);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isCustomerEditOpen, setIsCustomerEditOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isVanLoadOpen, setIsVanLoadOpen] = useState(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2800);
  };

  // Initialize DB and load all stores
  const refreshAllData = async () => {
    const prods = await getAll<Product>('products');
    const custs = await getAll<Customer>('customers');
    const vis = await getAll<Visit>('visits');
    const invs = await getAll<Invoice>('invoices');
    const invItems = await getAll<InvoiceItem>('invoiceItems');
    const rets = await getAll<ReturnRecord>('returns');
    const moves = await getAll<TreasuryMove>('treasuryMoves');
    const pays = await getAll<PaymentRecord>('payments');
    const van = await getAll<{ productId: string; qty: number }>('vanInventory');
    const main = await getAll<{ productId: string; qty: number }>('mainInventory');
    const grps = await getGroups();
    const settList = await getAll<{ key: string; value: string | number }>('settings');
    const closed = await checkDayClosed(todayDate);

    const settMap: Record<string, string | number> = {};
    settList.forEach((s) => {
      settMap[s.key] = s.value;
    });

    const vanMap = new Map<string, number>();
    van.forEach((v) => vanMap.set(v.productId, v.qty));

    const mainMap = new Map<string, number>();
    main.forEach((m) => mainMap.set(m.productId, m.qty));

    const pendingLogs = (await getAll<{ synced: boolean }>('changeLog')).filter((l) => !l.synced);

    setProducts(prods);
    setCustomers(custs);
    setVisits(vis);
    setInvoices(invs);
    setInvoiceItems(invItems);
    setReturns(rets);
    setTreasuryMoves(moves);
    setPayments(pays);
    setVanInventory(vanMap);
    setMainInventory(mainMap);
    setGroups(grps);
    setSettings(settMap);
    setIsTodayClosed(closed);
    setPendingCount(pendingLogs.length);

    // Keep selectedCustomer updated if open
    if (selectedCustomer) {
      const refreshed = custs.find((c) => c.id === selectedCustomer.id);
      if (refreshed) setSelectedCustomer(refreshed);
    }
  };

  useEffect(() => {
    const init = async () => {
      try {
        await seedInitialDataIfNeeded();
        await refreshAllData();
      } catch (err) {
        console.error('Initialization error', err);
      }
    };
    init();

    // Online / Offline listeners
    const handleOnline = () => {
      setIsOnline(true);
      showToast('أنت متصل بالإنترنت الآن');
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast('وضع عدم الاتصال (Offline) - البيانات محفوظة ومتاحة محلياً بالكامل');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Register Service Worker if supported
    if ('serviceWorker' in navigator && process.env.NODE_ENV !== 'development') {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync action
  const handleSync = async () => {
    if (!navigator.onLine) {
      showToast('أنت غير متصل بالإنترنت حالياً — البيانات محفوظة بأمان محلياً');
      return;
    }
    setIsSyncing(true);
    try {
      const logs = await getAll<{ id: string; synced: boolean }>('changeLog');
      for (const log of logs) {
        if (!log.synced) {
          log.synced = true;
          await putItem('changeLog', log);
        }
      }
      await refreshAllData();
      sound.playSuccess();
      showToast('تمت مزامنة كافة العمليات والتعديلات بنجاح');
    } catch {
      showToast('حدث خطأ أثناء المزامنة');
    } finally {
      setIsSyncing(false);
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    const stock = vanInventory.get(product.id) || 0;
    const existing = cart.find((i) => i.productId === product.id);
    const curQty = existing?.qty || 0;

    if (curQty + 1 > stock) {
      showToast(`الرصيد المتاح في السيارة لهذا الصنف هو ${stock} فقط`);
      sound.playError();
      return;
    }

    if (existing) {
      setCart((prev) =>
        prev.map((i) => (i.productId === product.id ? { ...i, qty: i.qty + 1 } : i))
      );
    } else {
      setCart((prev) => [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          price: product.price,
          qty: 1,
          itemDiscount: 0,
        },
      ]);
    }
    sound.playBarcodeBeep();
  };

  const handleUpdateQty = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveFromCart(index);
      return;
    }
    const item = cart[index];
    const stock = vanInventory.get(item.productId) || 0;
    if (newQty > stock) {
      showToast(`الكمية المطلوبة تتجاوز رصيد السيارة (${stock})`);
      sound.playError();
      return;
    }
    setCart((prev) =>
      prev.map((it, idx) => (idx === index ? { ...it, qty: newQty } : it))
    );
  };

  const handleUpdateDiscount = (index: number, discount: number) => {
    setCart((prev) =>
      prev.map((it, idx) => (idx === index ? { ...it, itemDiscount: Math.max(0, discount) } : it))
    );
  };

  const handleRemoveFromCart = (index: number) => {
    setCart((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Commit invoice & print
  const handleCommitInvoice = async (payType: string, paidAmount: number) => {
    if (!selectedCustomer) throw new Error('يرجى اختيار العميل أولاً');
    if (cart.length === 0) throw new Error('السلة فارغة');

    const monthlyDiscountRate = Number(settings.monthlyDiscountRate) || 0;
    const totals = calcInvoice(cart, monthlyDiscountRate);
    const invoiceId = `INV-${Date.now()}`;
    const nowIso = new Date().toISOString();

    const remaining = Math.max(0, Math.round((totals.grandTotal - paidAmount) * 100) / 100);
    const effectivePayType = remaining > 0 ? (paidAmount > 0 ? 'جزئي' : 'آجل') : 'كاش';

    const invoice: Invoice = {
      id: invoiceId,
      invoiceNo: invoiceId,
      customerId: selectedCustomer.id,
      customerName: selectedCustomer.name,
      date: nowIso,
      payType: effectivePayType as any,
      requestedPayType: payType,
      subtotal: totals.subtotal,
      monthlyDiscountRate: totals.monthlyDiscountRate,
      monthlyDiscountValue: totals.monthlyDiscountValue,
      grandTotal: totals.grandTotal,
      paidAmount,
      remainingAmount: remaining,
      syncStatus: 'pending',
    };

    // Save invoice & items
    await putItem('invoices', invoice);
    const itemsCreated: InvoiceItem[] = [];
    for (const item of totals.lines) {
      const invItem: InvoiceItem = {
        id: generateUID('ITEM'),
        invoiceId,
        productId: item.productId,
        name: item.name,
        price: item.price,
        qty: item.qty,
        itemDiscount: item.itemDiscount,
        lineTotal: item.lineTotal,
      };
      await putItem('invoiceItems', invItem);
      itemsCreated.push(invItem);

      // Decrement van stock
      const curStock = vanInventory.get(item.productId) || 0;
      await putItem('vanInventory', {
        productId: item.productId,
        qty: Math.max(0, curStock - item.qty),
      });
    }

    // Update customer balance if debt
    if (remaining > 0) {
      const updatedCust = {
        ...selectedCustomer,
        balance: Number(selectedCustomer.balance || 0) + remaining,
        lastVisit: todayDate,
      };
      await putItem('customers', updatedCust);
      setSelectedCustomer(updatedCust);
    }

    // Record cash in treasury if paid > 0
    if (paidAmount > 0) {
      const move: TreasuryMove = {
        id: generateUID('TR'),
        date: nowIso,
        type: 'إيراد',
        amount: paidAmount,
        notes: `تحصيل فاتورة ${invoiceId} - ${selectedCustomer.name}`,
      };
      await putItem('treasuryMoves', move);

      const payRecord: PaymentRecord = {
        id: generateUID('PAY'),
        customerId: selectedCustomer.id,
        customerName: selectedCustomer.name,
        invoiceId,
        date: nowIso,
        amount: paidAmount,
        notes: 'دفعة نقدية عند إصدار الفاتورة',
      };
      await putItem('payments', payRecord);
    }

    // Log for sync
    await logChange('invoices', 'add', invoice);

    // Print 80mm thermal receipt
    printInvoiceReceipt(invoice, itemsCreated, {
      companyName: String(settings.companyName || 'شركة المبيعات والتوزيع'),
      companyPhone: String(settings.companyPhone || ''),
      companyAddress: String(settings.companyAddress || ''),
      taxNo: String(settings.taxNo || ''),
      receiptFooter: String(settings.receiptFooter || 'شكراً لتعاملكم معنا'),
    });

    setCart([]);
    await refreshAllData();
    showToast(
      remaining > 0
        ? `تم اعتماد الفاتورة بنجاح والمتبقي ${formatMoney(remaining)} ج.م آجل`
        : 'تم اعتماد الفاتورة وتحصيلها نقداً بالكامل'
    );
  };

  // Payment confirmation & receipt printing
  const handleConfirmPayment = async (
    customerId: string,
    amount: number,
    notes: string,
    shouldPrint = true
  ) => {
    const cust = customers.find((c) => c.id === customerId);
    if (!cust) throw new Error('العميل غير موجود');

    const nowIso = new Date().toISOString();
    const remainingAfter = Math.max(0, Number(cust.balance || 0) - amount);
    const updatedCust: Customer = {
      ...cust,
      balance: remainingAfter,
      lastVisit: todayDate,
    };
    await putItem('customers', updatedCust);

    // Allocate payment across unpaid invoices FIFO
    const unpaidInvoices = invoices
      .filter((i) => i.customerId === customerId && i.remainingAmount > 0)
      .sort((a, b) => a.date.localeCompare(b.date));

    const { updatedInvoices } = allocatePaymentToInvoices(unpaidInvoices, amount);
    for (const inv of updatedInvoices) {
      await putItem('invoices', inv);
    }

    // Treasury income
    await putItem('treasuryMoves', {
      id: generateUID('TR'),
      date: nowIso,
      type: 'إيراد',
      amount,
      notes: `تحصيل من العميل: ${cust.name}`,
    });

    // Payment record
    const pRecord: PaymentRecord = {
      id: generateUID('PAY'),
      customerId,
      customerName: cust.name,
      date: nowIso,
      amount,
      notes: notes || 'تحصيل نقدي من الحساب',
    };
    await putItem('payments', pRecord);
    await logChange('payments', 'add', pRecord);

    // Print receipt if requested
    if (shouldPrint) {
      printPaymentReceipt(pRecord, remainingAfter, {
        companyName: String(settings.companyName || 'شركة المبيعات والتوزيع'),
        companyPhone: String(settings.companyPhone || ''),
        companyAddress: String(settings.companyAddress || ''),
        taxNo: String(settings.taxNo || ''),
        receiptFooter: String(settings.receiptFooter || 'شكراً لتعاملكم معنا'),
      });
    }

    await refreshAllData();
    showToast(`تم تسجيل تحصيل ${formatMoney(amount)} ج.م وتحديث الخزنة والمديونية`);
  };

  // Print existing collection receipt
  const handlePrintExistingPayment = (payment: PaymentRecord, customer: Customer) => {
    printPaymentReceipt(payment, Number(customer.balance || 0), {
      companyName: String(settings.companyName || 'شركة المبيعات والتوزيع'),
      companyPhone: String(settings.companyPhone || ''),
      companyAddress: String(settings.companyAddress || ''),
      taxNo: String(settings.taxNo || ''),
      receiptFooter: String(settings.receiptFooter || 'شكراً لتعاملكم معنا'),
    });
  };

  // Return confirmation
  const handleConfirmReturn = async (data: {
    customerId: string;
    productId: string;
    qty: number;
    price: number;
    amount: number;
    type: string;
    destination: string;
    refundType: string;
    invoiceNo: string;
    reason: string;
  }) => {
    const cust = customers.find((c) => c.id === data.customerId);
    if (!cust) throw new Error('العميل غير موجود');

    const returnId = `RET-${Date.now()}`;
    const nowIso = new Date().toISOString();

    const record: ReturnRecord = {
      id: returnId,
      returnNo: returnId,
      customerId: cust.id,
      customerName: cust.name,
      date: nowIso,
      amount: data.amount,
      invoiceNo: data.invoiceNo,
      reason: data.reason,
      type: data.type,
      destination: data.destination,
      productId: data.productId,
      qty: data.qty,
      refundType: data.refundType,
      syncStatus: 'pending',
    };

    await putItem('returns', record);

    // Refund handling
    if (data.refundType === 'آجل') {
      const updatedCust = {
        ...cust,
        balance: Math.max(0, Number(cust.balance || 0) - data.amount),
      };
      await putItem('customers', updatedCust);
    } else {
      await putItem('treasuryMoves', {
        id: generateUID('TR'),
        date: nowIso,
        type: 'مصروف',
        amount: data.amount,
        notes: `رد نقدي لمرتجع ${returnId} - ${cust.name}`,
      });
    }

    // Stock replenishment if sound item
    if (data.type === 'سليم') {
      if (data.destination === 'السيارة') {
        const curVan = vanInventory.get(data.productId) || 0;
        await putItem('vanInventory', { productId: data.productId, qty: curVan + data.qty });
      } else {
        const curMain = mainInventory.get(data.productId) || 0;
        await putItem('mainInventory', {
          productId: data.productId,
          qty: curMain + data.qty,
          updatedAt: nowIso,
        });
      }
    }

    await logChange('returns', 'add', record);
    await refreshAllData();
    showToast(`تم اعتماد المرتجع بقيمة ${formatMoney(data.amount)} ج.م بنجاح`);
  };

  // Save / Update Customer
  const handleSaveCustomer = async (cust: Customer) => {
    await putItem('customers', cust);
    await logChange('customers', cust.id ? 'update' : 'add', cust);
    await refreshAllData();
    showToast(`تم حفظ بيانات العميل: ${cust.name}`);
  };

  // Save / Update Product
  const handleSaveProduct = async (prod: Product) => {
    await putItem('products', prod);
    if (!vanInventory.has(prod.id)) {
      await putItem('vanInventory', { productId: prod.id, qty: 0 });
    }
    if (!mainInventory.has(prod.id)) {
      await putItem('mainInventory', { productId: prod.id, qty: 0, updatedAt: new Date().toISOString() });
    }
    await logChange('products', 'save', prod);
    await refreshAllData();
    showToast(`تم حفظ الصنف: ${prod.name}`);
  };

  // Load goods from Main Warehouse to Van
  const handleConfirmVanLoad = async (productId: string, qty: number) => {
    const curMain = mainInventory.get(productId) || 0;
    const curVan = vanInventory.get(productId) || 0;
    if (qty > curMain) throw new Error('الكمية غير متاحة بالمخزن');

    await putItem('mainInventory', { productId, qty: curMain - qty, updatedAt: new Date().toISOString() });
    await putItem('vanInventory', { productId, qty: curVan + qty });

    await putItem('vanLoadRequests', {
      id: generateUID('LOAD'),
      date: new Date().toISOString(),
      productId,
      qty,
      status: 'تم التحميل',
    });

    await refreshAllData();
    showToast(`تم تحميل ${qty} قطعة إلى حمولة السيارة بنجاح`);
  };

  // Update Main Stock
  const handleUpdateMainStock = async (productId: string, qty: number) => {
    await putItem('mainInventory', { productId, qty, updatedAt: new Date().toISOString() });
    await refreshAllData();
    showToast('تم تحديث رصيد المخزن الرئيسي');
  };

  // Save Settings
  const handleSaveSettings = async (
    newSettings: Record<string, string | number>,
    newGroups: string[]
  ) => {
    for (const [key, value] of Object.entries(newSettings)) {
      await putItem('settings', { key, value });
    }
    for (let i = 0; i < newGroups.length; i++) {
      await putItem('settings', { key: `group${i + 1}`, value: newGroups[i] });
    }
    await refreshAllData();
    showToast('تم حفظ كافة الإعدادات والمجموعات');
  };

  // Add Expense
  const handleAddExpense = async (amount: number, notes: string) => {
    const move: TreasuryMove = {
      id: generateUID('TR'),
      date: new Date().toISOString(),
      type: 'مصروف',
      amount,
      notes,
    };
    await putItem('treasuryMoves', move);
    await logChange('treasuryMoves', 'add', move);
    await refreshAllData();
    showToast(`تم تسجيل مصروف بقيمة ${formatMoney(amount)} ج.م`);
  };

  // Close Business Day
  const handleCloseBusinessDay = async () => {
    const todayInvs = invoices.filter((i) => i.date?.slice(0, 10) === todayDate);
    const todayRets = returns.filter((r) => r.date?.slice(0, 10) === todayDate);
    const todayV = visits.filter((v) => v.date === todayDate);

    const closeObj = {
      date: todayDate,
      closed: true,
      closedAt: new Date().toISOString(),
      sales: todayInvs.reduce((a, i) => a + Number(i.grandTotal || 0), 0),
      returns: todayRets.reduce((a, r) => a + Number(r.amount || 0), 0),
      visits: todayV.length,
    };

    await putItem('dayClosings', closeObj);
    await logChange('dayClosings', 'DAY_CLOSE', closeObj);
    await refreshAllData();
    showToast('تم إغلاق اليوم البيعي وقفل العمليات بنجاح');
  };

  // Reopen Business Day
  const handleReopenBusinessDay = async () => {
    await deleteItem('dayClosings', todayDate);
    await refreshAllData();
    showToast('تمت إعادة فتح اليوم البيعي');
  };

  // Save GPS for customer
  const handleSaveGPS = (customer: Customer) => {
    if (!navigator.geolocation) {
      showToast('خاصية الموقع غير مدعومة بجهازك');
      sound.playError();
      return;
    }
    showToast('جاري تحديد موقع العميل عبر GPS...');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const updated: Customer = {
          ...customer,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          locationAccuracy: Math.round(pos.coords.accuracy || 0),
          locationSavedAt: new Date().toISOString(),
        };
        await putItem('customers', updated);
        await logChange('customers', 'gps', updated);
        await refreshAllData();
        sound.playSuccess();
        showToast(`تم حفظ موقع العميل (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`);
      },
      () => {
        sound.playError();
        showToast('تعذر التقاط الموقع. تأكد من السماح بالوصول وتشغيل GPS');
      },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  };

  // Navigate GPS
  const handleNavigateGPS = (customer: Customer) => {
    if (customer.lat && customer.lng) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${customer.lat},${customer.lng}`, '_blank');
    } else if (customer.address) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(customer.address)}`, '_blank');
    } else {
      showToast('لا يوجد موقع أو عنوان مسجل لهذا العميل');
      sound.playError();
    }
  };

  // Log Visit Status
  const handleLogVisit = async (customer: Customer, status: string, notes = '') => {
    const visit: Visit = {
      id: generateUID('VIS'),
      customerId: customer.id,
      customerName: customer.name,
      date: todayDate,
      status,
      notes,
      timestamp: new Date().toISOString(),
    };
    await putItem('visits', visit);

    const updatedCust: Customer = {
      ...customer,
      lastVisit: todayDate,
    };
    await putItem('customers', updatedCust);
    await logChange('visits', 'add', visit);
    await refreshAllData();
    showToast(`تم تسجيل الزيارة (${status})`);
  };

  // Barcode Scan handler
  const handleBarcodeScanned = (scannedCode: string) => {
    const clean = scannedCode.trim().toLowerCase();
    const found = products.find(
      (p) => p.barcode?.toLowerCase() === clean || p.code?.toLowerCase() === clean
    );

    if (found) {
      handleAddToCart(found);
      showToast(`تم مسح وإضافة: ${found.name}`);
      setActiveTab('invoice');
    } else {
      sound.playError();
      showToast(`لم يتم العثور على صنف بالباركود: ${scannedCode}`);
    }
  };

  // Print Single Invoice Receipt (80mm)
  const handlePrintExistingInvoice = (invoice: Invoice) => {
    const items = invoiceItems.filter((i) => i.invoiceId === invoice.id);
    printInvoiceReceipt(invoice, items, {
      companyName: String(settings.companyName || 'شركة البركة للتوزيع واللوجستيات'),
      companyPhone: String(settings.companyPhone || ''),
      companyAddress: String(settings.companyAddress || ''),
      taxNo: String(settings.taxNo || ''),
      receiptFooter: String(settings.receiptFooter || 'شكراً لتعاملكم معنا'),
    });
  };

  // Comprehensive Report Print Engine
  const handlePrintReport = (type: string, date: string) => {
    printGeneralReport(
      type,
      date,
      {
        invoices,
        invoiceItems,
        payments,
        returns,
        visits,
        customers,
        products,
        treasuryMoves,
      },
      {
        companyName: String(settings.companyName || 'شركة البركة للتوزيع واللوجستيات'),
        companyPhone: String(settings.companyPhone || ''),
        companyAddress: String(settings.companyAddress || ''),
        taxNo: String(settings.taxNo || ''),
        receiptFooter: String(settings.receiptFooter || 'شكراً لتعاملكم معنا'),
      }
    );
  };

  // Test Print
  const handleTestPrint = () => {
    printReportDocument(
      'اختبار جاهزية الطابعة الحرارية',
      'Sales & Logistics Pro 2026',
      `
      <div style="text-align:center; padding:10px;">
        <p>إذا كنت ترى هذه الصفحة المطبوعة بوضوح، فإن الطابعة متصلة وجاهزة 100%!</p>
        <p>التاريخ: ${new Date().toLocaleString('ar-EG')}</p>
        <p>مندوب سيارة: VAN-9902</p>
      </div>
    `
    );
  };

  // Export JSON Backup
  const handleExportBackup = async () => {
    try {
      const json = await exportDatabaseBackup();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `SalesPro-Backup-${todayDate}.json`;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        URL.revokeObjectURL(url);
        a.remove();
      }, 1000);
      sound.playSuccess();
      showToast('تم تصدير النسخة الاحتياطية بنجاح');
    } catch {
      showToast('فشل تصدير النسخة الاحتياطية');
    }
  };

  // Import JSON Backup
  const handleImportBackup = async (file: File) => {
    try {
      const text = await file.text();
      await importDatabaseBackup(text);
      await refreshAllData();
      sound.playSuccess();
      showToast('تمت استعادة كافة البيانات بنجاح!');
    } catch {
      sound.playError();
      showToast('ملف النسخة الاحتياطية غير صالح');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-slate-950 font-sans">
      {/* Sticky Top Header */}
      <MobileHeader
        onOpenDrawer={() => setIsDrawerOpen(true)}
        isOnline={isOnline}
        pendingCount={pendingCount}
        onSync={handleSync}
        isSyncing={isSyncing}
        selectedDay={selectedDay}
      />

      {/* Main View Router */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3.5 pt-2">
        {activeTab === 'dashboard' && (
          <DashboardView
            invoices={invoices}
            visits={visits}
            customers={customers}
            treasuryMoves={treasuryMoves}
            dailyTarget={Number(settings.dailyTarget) || 15000}
            selectedDay={selectedDay}
            onNavigate={(t) => setActiveTab(t)}
            onOpenCustomer={(c) => {
              setActiveCustomerCard(c);
            }}
            onPrintInvoice={handlePrintExistingInvoice}
          />
        )}

        {activeTab === 'visits' && (
          <VisitsView
            customers={customers}
            selectedDay={selectedDay}
            onSelectDay={(d) => setSelectedDay(d)}
            onOpenCustomer={(c) => setActiveCustomerCard(c)}
            onQuickInvoice={(c) => {
              setSelectedCustomer(c);
              setActiveTab('invoice');
            }}
            onPayment={(c) => setPaymentCustomer(c)}
            onReturn={(c) => setReturnCustomer(c)}
            onNewCustomer={() => {
              setEditingCustomer(null);
              setIsCustomerEditOpen(true);
            }}
            onSaveGPS={handleSaveGPS}
            onNavigateGPS={handleNavigateGPS}
          />
        )}

        {activeTab === 'invoice' && (
          <InvoiceView
            customers={customers}
            selectedCustomer={selectedCustomer}
            onSelectCustomer={(c) => setSelectedCustomer(c)}
            products={products}
            vanInventory={vanInventory}
            groups={groups}
            cart={cart}
            monthlyDiscountRate={Number(settings.monthlyDiscountRate) || 0}
            onAddToCart={handleAddToCart}
            onUpdateQty={handleUpdateQty}
            onUpdateDiscount={handleUpdateDiscount}
            onRemoveFromCart={handleRemoveFromCart}
            onClearCart={handleClearCart}
            onOpenScanner={() => setIsScannerOpen(true)}
            onCommitInvoice={handleCommitInvoice}
            isDayClosed={isTodayClosed}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            viewMode="inventory"
            products={products}
            vanInventory={vanInventory}
            mainInventory={mainInventory}
            groups={groups}
            vanSafetyThreshold={Number(settings.vanSafetyThreshold) || 15}
            onOpenLoadModal={() => setIsVanLoadOpen(true)}
            onOpenProductModal={(p) => {
              setEditingProduct(p || null);
              setIsProductModalOpen(true);
            }}
            onUpdateMainStock={handleUpdateMainStock}
            onAddToCart={handleAddToCart}
            onPrintStock={(type) => {
              if (type === 'van') {
                printVanInventoryReport(products, vanInventory, Number(settings.vanSafetyThreshold) || 15, {
                  companyName: String(settings.companyName || 'شركة البركة للتوزيع واللوجستيات'),
                  companyPhone: String(settings.companyPhone || ''),
                });
              } else {
                printMainInventoryReport(products, mainInventory, {
                  companyName: String(settings.companyName || 'شركة البركة للتوزيع واللوجستيات'),
                  companyPhone: String(settings.companyPhone || ''),
                });
              }
            }}
          />
        )}

        {activeTab === 'treasury' && (
          <TreasuryView
            treasuryMoves={treasuryMoves}
            onAddExpense={handleAddExpense}
          />
        )}

        {activeTab === 'returns' && (
          <ReturnsView
            returns={returns}
            products={products}
            customers={customers}
            onOpenReturnModal={() => {
              if (customers.length > 0) setReturnCustomer(customers[0]);
            }}
          />
        )}

        {activeTab === 'day-close' && (
          <DayCloseView
            isClosed={isTodayClosed}
            invoices={invoices}
            returns={returns}
            visits={visits}
            treasuryMoves={treasuryMoves}
            onCloseBusinessDay={handleCloseBusinessDay}
            onReopenBusinessDay={handleReopenBusinessDay}
            onPrintDailySummary={() => handlePrintReport('daily', todayDate)}
          />
        )}

        {activeTab === 'debt' && (
          <DebtView
            customers={customers}
            invoices={invoices}
            payments={payments}
            selectedDay={selectedDay}
            onSelectDay={(d) => setSelectedDay(d)}
            onPayment={(c) => setPaymentCustomer(c)}
            onQuickInvoice={(c) => {
              setSelectedCustomer(c);
              setActiveTab('invoice');
            }}
            onPrintExistingPayment={handlePrintExistingPayment}
            onPrintDebtReport={() => handlePrintReport('debt', todayDate)}
          />
        )}

        {(activeTab === 'reports' || activeTab === 'profit') && (
          <ReportsView
            invoices={invoices}
            invoiceItems={invoiceItems}
            payments={payments}
            returns={returns}
            visits={visits}
            customers={customers}
            products={products}
            treasuryMoves={treasuryMoves}
            onPrintReport={handlePrintReport}
            onPrintInvoice={handlePrintExistingInvoice}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            groups={groups}
            onSaveSettings={handleSaveSettings}
            onExportBackup={handleExportBackup}
            onImportBackup={handleImportBackup}
            onTestPrint={handleTestPrint}
          />
        )}

        {activeTab === 'products' && (
          <InventoryView
            viewMode="products"
            products={products}
            vanInventory={vanInventory}
            mainInventory={mainInventory}
            groups={groups}
            vanSafetyThreshold={Number(settings.vanSafetyThreshold) || 15}
            onOpenLoadModal={() => setIsVanLoadOpen(true)}
            onOpenProductModal={(p) => {
              setEditingProduct(p || null);
              setIsProductModalOpen(true);
            }}
            onUpdateMainStock={handleUpdateMainStock}
            onAddToCart={handleAddToCart}
            onPrintStock={(type) => {
              if (type === 'van') {
                printVanInventoryReport(products, vanInventory, Number(settings.vanSafetyThreshold) || 15, {
                  companyName: String(settings.companyName || 'شركة البركة للتوزيع واللوجستيات'),
                  companyPhone: String(settings.companyPhone || ''),
                });
              } else {
                printMainInventoryReport(products, mainInventory, {
                  companyName: String(settings.companyName || 'شركة البركة للتوزيع واللوجستيات'),
                  companyPhone: String(settings.companyPhone || ''),
                });
              }
            }}
          />
        )}

        {activeTab === 'more' && (
          <div className="space-y-3 pb-24 pt-2">
            <h2 className="text-sm font-bold text-slate-300 px-1">المزيد من الخيارات والأدوات</h2>
            <div className="grid grid-cols-2 gap-2.5">
              {/* Highlighted Debt & Collections Shortcut */}
              <button
                onClick={() => setActiveTab('debt')}
                className="col-span-2 p-3.5 bg-gradient-to-r from-rose-950/60 via-slate-900 to-slate-900 hover:from-rose-950/80 hover:to-slate-850 border border-rose-500/40 rounded-3xl text-right flex items-center justify-between active:scale-95 transition shadow-lg"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">💳</span>
                  <div>
                    <span className="font-bold text-white text-xs block">الآجل والتحصيل (المديونيات والسداد)</span>
                    <span className="text-[10px] text-rose-300">متابعة مديونيات العملاء والتسديد المباشر</span>
                  </div>
                </div>
                <div className="font-mono font-bold text-rose-400 text-xs sm:text-sm bg-rose-500/10 border border-rose-500/20 px-2.5 py-1 rounded-xl">
                  {formatMoney(customers.reduce((a, c) => a + Number(c.balance || 0), 0))} ج.م ←
                </div>
              </button>

              <button
                onClick={() => setActiveTab('treasury')}
                className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-3xl text-right flex flex-col gap-1 active:scale-95 transition"
              >
                <span className="text-xl">💰</span>
                <span className="font-bold text-white text-xs">الخزنة والمقبوضات</span>
                <span className="text-[10px] text-slate-400">حركة النقدية والمصروفات</span>
              </button>

              <button
                onClick={() => setActiveTab('returns')}
                className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-3xl text-right flex flex-col gap-1 active:scale-95 transition"
              >
                <span className="text-xl">↩️</span>
                <span className="font-bold text-white text-xs">المرتجعات المتطورة</span>
                <span className="text-[10px] text-slate-400">سليم، تالف، وهوالك</span>
              </button>

              <button
                onClick={() => setActiveTab('day-close')}
                className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-3xl text-right flex flex-col gap-1 active:scale-95 transition"
              >
                <span className="text-xl">🔒</span>
                <span className="font-bold text-white text-xs">إغلاق اليوم البيعي</span>
                <span className="text-[10px] text-slate-400">مطابقة النقدية وجرد السيارة</span>
              </button>

              <button
                onClick={() => setActiveTab('reports')}
                className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-3xl text-right flex flex-col gap-1 active:scale-95 transition"
              >
                <span className="text-xl">📈</span>
                <span className="font-bold text-white text-xs">التقارير اليومية</span>
                <span className="text-[10px] text-slate-400">المبيعات، التحصيل، والأرباح</span>
              </button>

              <button
                onClick={() => setActiveTab('products')}
                className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-3xl text-right flex flex-col gap-1 active:scale-95 transition"
              >
                <span className="text-xl">📦</span>
                <span className="font-bold text-white text-xs">دليل المنتجات</span>
                <span className="text-[10px] text-slate-400">الأسعار والباركود</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-3xl text-right flex flex-col gap-1 active:scale-95 transition"
              >
                <span className="text-xl">⚙️</span>
                <span className="font-bold text-white text-xs">الإعدادات والنسخ</span>
                <span className="text-[10px] text-slate-400">تخصيص الفاتورة والطباعة</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Thumb Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        cartCount={cart.reduce((a, i) => a + i.qty, 0)}
      />

      {/* Sidebar Drawer Menu */}
      <SidebarDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={(tab) => setActiveTab(tab)}
        activeTab={activeTab}
      />

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleBarcodeScanned}
      />

      {/* Customer Card Sheet */}
      <CustomerCardModal
        customer={activeCustomerCard}
        visits={visits.filter((v) => v.customerId === activeCustomerCard?.id)}
        isOpen={!!activeCustomerCard}
        onClose={() => setActiveCustomerCard(null)}
        onQuickInvoice={(cust) => {
          setSelectedCustomer(cust);
          setActiveTab('invoice');
        }}
        onPayment={(cust) => setPaymentCustomer(cust)}
        onReturn={(cust) => setReturnCustomer(cust)}
        onEdit={(cust) => {
          setEditingCustomer(cust);
          setIsCustomerEditOpen(true);
        }}
        onSaveGPS={handleSaveGPS}
        onNavigateGPS={handleNavigateGPS}
        onLogVisit={handleLogVisit}
      />

      {/* Payment Cash Modal */}
      <PaymentModal
        customer={paymentCustomer}
        isOpen={!!paymentCustomer}
        onClose={() => setPaymentCustomer(null)}
        onConfirm={handleConfirmPayment}
      />

      {/* Advanced Return Modal */}
      <ReturnModal
        customer={returnCustomer}
        products={products}
        isOpen={!!returnCustomer}
        onClose={() => setReturnCustomer(null)}
        onConfirm={handleConfirmReturn}
      />

      {/* Customer Add / Edit Modal */}
      <CustomerEditModal
        customer={editingCustomer}
        isOpen={isCustomerEditOpen}
        onClose={() => {
          setIsCustomerEditOpen(false);
          setEditingCustomer(null);
        }}
        onSave={handleSaveCustomer}
      />

      {/* Product Add / Edit Modal */}
      <ProductModal
        product={editingProduct}
        groups={groups}
        isOpen={isProductModalOpen}
        onClose={() => {
          setIsProductModalOpen(false);
          setEditingProduct(null);
        }}
        onSave={handleSaveProduct}
      />

      {/* Van Load from Warehouse Modal */}
      <VanLoadModal
        products={products}
        groups={groups}
        mainInventory={mainInventory}
        vanInventory={vanInventory}
        isOpen={isVanLoadOpen}
        onClose={() => setIsVanLoadOpen(false)}
        onConfirm={handleConfirmVanLoad}
      />

      {/* Non-intrusive Toast */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-amber-500/40 text-amber-300 font-bold px-4 py-2.5 rounded-2xl shadow-2xl text-xs flex items-center gap-2 max-w-[90vw] text-center animate-fade-in">
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
