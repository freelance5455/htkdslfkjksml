/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  MessageSquare,
  Mic,
  Brain,
  Image as ImageIcon,
  FileText,
  Globe,
  GraduationCap,
  Languages,
  Code2,
  CheckSquare,
  Volume2,
  Settings,
  Send,
  Paperclip,
  Sparkles,
  BookOpen,
  Star,
  Menu,
  X,
  Download,
  LogIn,
  AlertCircle,
  Trash2,
  HelpCircle,
  GitBranch,
  TrendingUp,
  BookOpenCheck,
} from 'lucide-react';
import type {
  ChatMessage,
  LearningAnalytics,
  MemoryCategory,
  ModuleId,
  PersonalMemory,
  PracticeAttempt,
  StudyProgressRecord,
  SupportedLanguage,
  TaskCategory,
  TaskPriority,
  UserTask,
  VoiceProfileId,
} from './types';
import {
  VOICE_PROFILES,
  calculateLevelFromXP,
  getRelevantMemories,
  sanitizeChatMessage,
} from './utils/rajuEngine';
import {
  auth,
  db,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  serverTimestamp,
  getDocs,
  signInWithPopup,
  googleProvider,
  firebaseSignOut,
  onAuthStateChanged,
  handleFirestoreError,
  OperationType,
  formatTimestamp,
  User,
} from './firebase';
import { useOnlineStatus, usePWAInstall } from './hooks/usePWAInstall';
import { LotusOrb } from './components/LotusOrb';
import { LiveVoiceModule } from './components/LiveVoiceModule';
import { MemoryModule } from './components/MemoryModule';
import {
  ImageAnalyzerModule,
  PdfReaderModule,
  WebResearchModule,
} from './components/ImagePdfResearchModules';
import {
  JapaneseLearningModule,
  StudyAssistantModule,
} from './components/StudyAndJapaneseModules';
import {
  CodingLabModule,
  TaskManagerModule,
  VoiceStudioModule,
} from './components/CodingVoiceTasksModules';
import { SettingsAndArchitectureModule } from './components/SettingsAndArchitectureModule';
import { SmartQuestionGeneratorModule } from './components/SmartQuestionGenerator';
import { VisualDiagramEngineModule } from './components/VisualDiagramEngine';
import { JapaneseTutorModule } from './components/JapaneseTutorModule';
import { ProgressDashboardModule } from './components/ProgressDashboardModule';

const PRACTICE_ATTEMPTS_STORAGE_KEY = 'raju_ai_practice_attempts_v1';
const LEARNING_ANALYTICS_STORAGE_KEY = 'raju_ai_learning_analytics_v1';

function getTodayDateString(): string {
  return new Date().toISOString().slice(0, 10);
}

function getDefaultAnalytics(): LearningAnalytics {
  return {
    dailyMinutes: 1,
    streakDays: 1,
    lastActiveDate: getTodayDateString(),
    masteredKanji: [],
    learnedVocabCount: 12,
  };
}

const INITIAL_MEMORIES: PersonalMemory[] = [
  {
    id: 'mem_seed_1',
    ownerId: 'local_user',
    title: 'CUET UG & JLPT N5 Preparation Goal',
    content: 'Preparing for CUET Biology, Physics, Chemistry, General Test, and Japanese JLPT N5.',
    category: 'Study Goal',
    userConsented: true,
    createdAt: '2026-11-12T10:00:00Z',
    updatedAt: '2026-11-12T10:00:00Z',
  },
  {
    id: 'mem_seed_2',
    ownerId: 'local_user',
    title: 'Multilingual Explanation Preference',
    content: 'Prefers clear explanations in English with Hindi and Japanese examples where helpful.',
    category: 'Language',
    userConsented: true,
    createdAt: '2026-11-12T10:05:00Z',
    updatedAt: '2026-11-12T10:05:00Z',
  },
];

const INITIAL_TASKS: UserTask[] = [
  {
    id: 'task_seed_1',
    ownerId: 'local_user',
    title: 'Complete CUET Biology Molecular Basis of Inheritance MCQs',
    category: 'Study',
    priority: 'High',
    dueDate: '2026-11-14',
    completed: false,
    createdAt: '2026-11-12T09:00:00Z',
    updatedAt: '2026-11-12T09:00:00Z',
  },
  {
    id: 'task_seed_2',
    ownerId: 'local_user',
    title: 'Practice 25 Hiragana & Katakana Stroke Order Characters',
    category: 'Japanese',
    priority: 'High',
    dueDate: '2026-11-15',
    completed: true,
    createdAt: '2026-11-12T09:30:00Z',
    updatedAt: '2026-11-12T09:30:00Z',
  },
  {
    id: 'task_seed_3',
    ownerId: 'local_user',
    title: 'Review React + TypeScript Full-Stack Architecture in Coding Lab',
    category: 'Coding',
    priority: 'Medium',
    dueDate: '2026-11-16',
    completed: false,
    createdAt: '2026-11-12T10:00:00Z',
    updatedAt: '2026-11-12T10:00:00Z',
  },
];

const NAV_ITEMS: Array<{ id: ModuleId; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'chat', label: 'AI Chat', icon: MessageSquare },
  { id: 'voice', label: 'Live Voice', icon: Mic },
  { id: 'memory', label: 'My Memory', icon: Brain },
  { id: 'image', label: 'Image Analyzer', icon: ImageIcon },
  { id: 'pdf', label: 'PDF Reader', icon: FileText },
  { id: 'research', label: 'Web Research', icon: Globe },
  { id: 'study', label: 'Study Assistant', icon: GraduationCap },
  { id: 'questions', label: 'Smart Questions', icon: HelpCircle },
  { id: 'japanese', label: 'Japanese Learning', icon: Languages },
  { id: 'diagrams', label: 'Visual Diagrams', icon: GitBranch },
  { id: 'tutor', label: 'AI Japanese Tutor', icon: BookOpenCheck },
  { id: 'progress', label: 'Progress Dashboard', icon: TrendingUp },
  { id: 'coding', label: 'Coding Lab', icon: Code2 },
  { id: 'tasks', label: 'Task Manager', icon: CheckSquare },
  { id: 'voice-studio', label: 'Voice Studio', icon: Volume2 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export default function App() {
  const [activeModule, setActiveModule] = useState<ModuleId>('chat');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // User & Auth state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [displayName, setDisplayName] = useState('Raju');
  const [language, setLanguage] = useState<SupportedLanguage>('English');
  const [selectedVoice, setSelectedVoice] = useState<VoiceProfileId>('Natural Female');
  const [thinkingLevel, setThinkingLevel] = useState<'LOW' | 'HIGH' | 'XHIGH'>('HIGH');
  const [memoryConsent, setMemoryConsent] = useState<boolean>(true);
  const [xp, setXp] = useState<number>(2937); // Starts at Level 12 (75%) matching reference design

  // App Data State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [memories, setMemories] = useState<PersonalMemory[]>(INITIAL_MEMORIES);
  const [tasks, setTasks] = useState<UserTask[]>(INITIAL_TASKS);
  const [studyProgress, setStudyProgress] = useState<StudyProgressRecord[]>([]);
  const [attempts, setAttempts] = useState<PracticeAttempt[]>(() => {
    try {
      const raw = localStorage.getItem(PRACTICE_ATTEMPTS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed as PracticeAttempt[];
      }
    } catch {
      // ignore localStorage read errors
    }
    return [];
  });
  const [analytics, setAnalytics] = useState<LearningAnalytics>(() => {
    const today = getTodayDateString();
    try {
      const raw = localStorage.getItem(LEARNING_ANALYTICS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as LearningAnalytics;
        if (parsed && typeof parsed.dailyMinutes === 'number') {
          if (parsed.lastActiveDate !== today) {
            const prevDate = new Date(parsed.lastActiveDate);
            const curDate = new Date(today);
            const diffDays = Math.round((curDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
            return {
              dailyMinutes: 1,
              streakDays: diffDays === 1 ? (parsed.streakDays || 1) + 1 : 1,
              lastActiveDate: today,
              masteredKanji: Array.isArray(parsed.masteredKanji) ? parsed.masteredKanji : [],
              learnedVocabCount: typeof parsed.learnedVocabCount === 'number' ? parsed.learnedVocabCount : 12,
            };
          }
          return {
            ...parsed,
            masteredKanji: Array.isArray(parsed.masteredKanji) ? parsed.masteredKanji : [],
            learnedVocabCount: typeof parsed.learnedVocabCount === 'number' ? parsed.learnedVocabCount : 12,
          };
        }
      }
    } catch {
      // ignore localStorage read errors
    }
    return getDefaultAnalytics();
  });
  const [revisionTopic, setRevisionTopic] = useState<string | null>(null);

  // Chat Composer State
  const [chatInput, setChatInput] = useState('');
  const [isStreamingChat, setIsStreamingChat] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const [attachedFile, setAttachedFile] = useState<{
    name: string;
    mimeType: string;
    data: string;
  } | null>(null);

  // Token & Usage Monitoring
  const [totalTokensUsed, setTotalTokensUsed] = useState<number>(0);
  const [totalRequestsCount, setTotalRequestsCount] = useState<number>(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const isOnline = useOnlineStatus();
  const { isInstallable, isInstalled, install } = usePWAInstall();

  // Persist practice attempts & learning analytics
  useEffect(() => {
    try {
      localStorage.setItem(PRACTICE_ATTEMPTS_STORAGE_KEY, JSON.stringify(attempts.slice(0, 200)));
    } catch {
      // ignore quota errors
    }
  }, [attempts]);

  useEffect(() => {
    try {
      localStorage.setItem(LEARNING_ANALYTICS_STORAGE_KEY, JSON.stringify(analytics));
    } catch {
      // ignore quota errors
    }
  }, [analytics]);

  // Track active daily learning time
  useEffect(() => {
    const timer = window.setInterval(() => {
      const today = getTodayDateString();
      setAnalytics((prev) => {
        if (prev.lastActiveDate !== today) {
          return {
            ...prev,
            dailyMinutes: 1,
            streakDays: prev.streakDays + 1,
            lastActiveDate: today,
          };
        }
        return {
          ...prev,
          dailyMinutes: prev.dailyMinutes + 1,
        };
      });
    }, 60000);
    return () => window.clearInterval(timer);
  }, []);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      setAuthReady(true);
      if (user) {
        setDisplayName(user.displayName || user.email?.split('@')[0] || 'Raju');
        // Ensure /users/{uid} document exists
        const userRef = doc(db, 'users', user.uid);
        try {
          const snap = await getDoc(userRef);
          if (!snap.exists()) {
            await setDoc(userRef, {
              uid: user.uid,
              displayName: (user.displayName || 'Raju').slice(0, 100),
              preferredLanguage: 'English',
              preferredVoice: 'Natural Female',
              memoryConsent: true,
              xp: 2937,
              level: 12,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          } else {
            const data = snap.data();
            if (data.displayName) setDisplayName(data.displayName);
            if (data.preferredLanguage) setLanguage(data.preferredLanguage as SupportedLanguage);
            if (data.preferredVoice) setSelectedVoice(data.preferredVoice as VoiceProfileId);
            if (typeof data.memoryConsent === 'boolean') setMemoryConsent(data.memoryConsent);
            if (typeof data.xp === 'number') setXp(data.xp);
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, `users/${user.uid}`);
        }
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to Firestore collections when authenticated
  useEffect(() => {
    if (!authReady || !currentUser) return;
    const uid = currentUser.uid;

    const convQuery = query(collection(db, 'conversations'), where('ownerId', '==', uid));
    const unsubConv = onSnapshot(
      convQuery,
      (snap) => {
        const list: ChatMessage[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: d.id,
              ownerId: data.ownerId,
              sessionId: data.sessionId,
              role: data.role,
              content: data.content,
              module: data.module,
              language: data.language,
              createdAt: formatTimestamp(data.createdAt),
            };
          })
          .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        setMessages(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'conversations')
    );

    const memQuery = query(collection(db, 'memories'), where('ownerId', '==', uid));
    const unsubMem = onSnapshot(
      memQuery,
      (snap) => {
        const list: PersonalMemory[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            ownerId: data.ownerId,
            title: data.title,
            content: data.content,
            category: data.category,
            userConsented: data.userConsented,
            createdAt: formatTimestamp(data.createdAt),
            updatedAt: formatTimestamp(data.updatedAt),
          };
        });
        if (list.length > 0) setMemories(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'memories')
    );

    const taskQuery = query(collection(db, 'tasks'), where('ownerId', '==', uid));
    const unsubTasks = onSnapshot(
      taskQuery,
      (snap) => {
        const list: UserTask[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            ownerId: data.ownerId,
            title: data.title,
            category: data.category,
            priority: data.priority,
            dueDate: data.dueDate,
            completed: data.completed,
            createdAt: formatTimestamp(data.createdAt),
            updatedAt: formatTimestamp(data.updatedAt),
          };
        });
        if (list.length > 0) setTasks(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'tasks')
    );

    const progQuery = query(collection(db, 'study_progress'), where('ownerId', '==', uid));
    const unsubProg = onSnapshot(
      progQuery,
      (snap) => {
        const list: StudyProgressRecord[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            ownerId: data.ownerId,
            subject: data.subject,
            topic: data.topic,
            score: data.score,
            totalQuestions: data.totalQuestions,
            masteryLevel: data.masteryLevel,
            updatedAt: formatTimestamp(data.updatedAt),
          };
        });
        setStudyProgress(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'study_progress')
    );

    return () => {
      unsubConv();
      unsubMem();
      unsubTasks();
      unsubProg();
    };
  }, [authReady, currentUser]);

  const handleEarnXp = async (amount: number) => {
    const nextXp = xp + amount;
    setXp(nextXp);
    if (currentUser) {
      const nextLvl = calculateLevelFromXP(nextXp).level;
      try {
        await updateDoc(doc(db, 'users', currentUser.uid), {
          xp: nextXp,
          level: nextLvl,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
      }
    }
  };

  const handleRecordTokens = (tokens: number) => {
    setTotalTokensUsed((prev) => prev + tokens);
    setTotalRequestsCount((prev) => prev + 1);
  };

  const handleSignInGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setChatError(err instanceof Error ? err.message : 'Google Sign-In was cancelled or failed.');
    }
  };

  const handleSignOut = async () => {
    await firebaseSignOut(auth);
  };

  // Chat Attachment Handler
  const handleFileAttach = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const res = String(reader.result || '');
      const base64 = res.split(',')[1] || '';
      setAttachedFile({
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        data: base64,
      });
    };
    reader.readAsDataURL(file);
  };

  // Send AI Chat Message (Streaming SSE with Gemini 4 Hydrogen)
  const sendChatMessage = async (rawPrompt?: string) => {
    const textToSend = sanitizeChatMessage(rawPrompt !== undefined ? rawPrompt : chatInput);
    if (!textToSend && !attachedFile) return;

    setChatError(null);
    if (rawPrompt === undefined) setChatInput('');

    const userMsgId = `msg_${Date.now()}_u`;
    const assistantMsgId = `msg_${Date.now() + 1}_a`;
    const ownerId = currentUser?.uid || 'local_user';

    const userMsg: ChatMessage = {
      id: userMsgId,
      ownerId,
      sessionId: 'main_session',
      role: 'user',
      content: textToSend || `Attached file: ${attachedFile?.name}`,
      module: 'chat',
      language,
      createdAt: new Date().toISOString(),
      attachmentName: attachedFile?.name,
    };

    const placeholderAssistant: ChatMessage = {
      id: assistantMsgId,
      ownerId,
      sessionId: 'main_session',
      role: 'assistant',
      content: '',
      module: 'chat',
      language,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg, placeholderAssistant]);
    setIsStreamingChat(true);

    const currentAttachment = attachedFile;
    setAttachedFile(null);

    if (currentUser) {
      try {
        await setDoc(doc(db, 'conversations', userMsgId), {
          ownerId: currentUser.uid,
          sessionId: 'main_session',
          role: 'user',
          content: userMsg.content,
          module: 'chat',
          language,
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `conversations/${userMsgId}`);
      }
    }

    try {
      const relevantMemories = memoryConsent ? getRelevantMemories(memories, textToSend) : [];
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          messages: messages.slice(-10).map((m) => ({ role: m.role, content: m.content })),
          language,
          memories: relevantMemories.map((m) => ({
            title: m.title,
            content: m.content,
            category: m.category,
          })),
          thinkingLevel,
          stream: true,
          attachment: currentAttachment,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Gemini API returned HTTP ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let streamTokens = 0;

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunkStr = decoder.decode(value, { stream: true });
          const lines = chunkStr.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const payload = JSON.parse(line.slice(6));
                if (payload.text) {
                  accumulatedText += payload.text;
                  setMessages((prev) =>
                    prev.map((m) =>
                      m.id === assistantMsgId ? { ...m, content: accumulatedText } : m
                    )
                  );
                }
                if (payload.totalTokens) {
                  streamTokens = payload.totalTokens;
                }
              } catch {
                // ignore partial SSE line
              }
            }
          }
        }
      }

      if (streamTokens > 0) handleRecordTokens(streamTokens);
      else handleRecordTokens(Math.ceil((textToSend.length + accumulatedText.length) / 4));

      await handleEarnXp(10);

      if (currentUser && accumulatedText.trim()) {
        try {
          await setDoc(doc(db, 'conversations', assistantMsgId), {
            ownerId: currentUser.uid,
            sessionId: 'main_session',
            role: 'assistant',
            content: accumulatedText.slice(0, 20000),
            module: 'chat',
            language,
            createdAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, `conversations/${assistantMsgId}`);
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to communicate with Gemini 4 Hydrogen.';
      setChatError(message);
      setMessages((prev) => prev.filter((m) => m.id !== assistantMsgId));
    } finally {
      setIsStreamingChat(false);
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }
  };

  // Memory CRUD Handlers
  const handleAddMemory = async (mem: {
    title: string;
    content: string;
    category: MemoryCategory;
    userConsented: true;
  }) => {
    const id = `mem_${Date.now()}`;
    const now = new Date().toISOString();
    const newMem: PersonalMemory = {
      id,
      ownerId: currentUser?.uid || 'local_user',
      ...mem,
      createdAt: now,
      updatedAt: now,
    };
    setMemories((prev) => [newMem, ...prev]);
    await handleEarnXp(15);

    if (currentUser) {
      try {
        await setDoc(doc(db, 'memories', id), {
          ownerId: currentUser.uid,
          title: mem.title,
          content: mem.content,
          category: mem.category,
          userConsented: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `memories/${id}`);
      }
    }
  };

  const handleUpdateMemory = async (
    id: string,
    updates: { title: string; content: string; category: MemoryCategory }
  ) => {
    const now = new Date().toISOString();
    setMemories((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updates, updatedAt: now } : m))
    );
    if (currentUser) {
      try {
        await updateDoc(doc(db, 'memories', id), {
          ...updates,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `memories/${id}`);
      }
    }
  };

  const handleDeleteMemory = async (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
    if (currentUser) {
      try {
        await deleteDoc(doc(db, 'memories', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `memories/${id}`);
      }
    }
  };

  const handleClearConversationHistory = async () => {
    setMessages([]);
    if (currentUser) {
      try {
        const q = query(collection(db, 'conversations'), where('ownerId', '==', currentUser.uid));
        const snap = await getDocs(q);
        for (const d of snap.docs) {
          await deleteDoc(doc(db, 'conversations', d.id));
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, 'conversations');
      }
    }
  };

  // Task CRUD Handlers
  const handleAddTask = async (task: {
    title: string;
    category: TaskCategory;
    priority: TaskPriority;
    dueDate: string;
  }) => {
    const id = `task_${Date.now()}`;
    const now = new Date().toISOString();
    const newTask: UserTask = {
      id,
      ownerId: currentUser?.uid || 'local_user',
      ...task,
      completed: false,
      createdAt: now,
      updatedAt: now,
    };
    setTasks((prev) => [newTask, ...prev]);
    await handleEarnXp(10);

    if (currentUser) {
      try {
        await setDoc(doc(db, 'tasks', id), {
          ownerId: currentUser.uid,
          ...task,
          completed: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `tasks/${id}`);
      }
    }
  };

  const handleToggleTask = async (id: string, completed: boolean) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed, updatedAt: new Date().toISOString() } : t))
    );
    if (completed) await handleEarnXp(20);

    if (currentUser) {
      try {
        await updateDoc(doc(db, 'tasks', id), {
          completed,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `tasks/${id}`);
      }
    }
  };

  const handleDeleteTask = async (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    if (currentUser) {
      try {
        await deleteDoc(doc(db, 'tasks', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `tasks/${id}`);
      }
    }
  };

  // Study Progress Handler
  const handleSaveStudyProgress = async (record: {
    subject: string;
    topic: string;
    score: number;
    totalQuestions: number;
    masteryLevel: 'Beginner' | 'Intermediate' | 'Advanced' | 'Mastered';
  }) => {
    const id = `prog_${Date.now()}`;
    const newRec: StudyProgressRecord = {
      id,
      ownerId: currentUser?.uid || 'local_user',
      ...record,
      updatedAt: new Date().toISOString(),
    };
    setStudyProgress((prev) => [newRec, ...prev]);

    if (currentUser) {
      try {
        await setDoc(doc(db, 'study_progress', id), {
          ownerId: currentUser.uid,
          ...record,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `study_progress/${id}`);
      }
    }
  };

  // Export Personal Data as JSON
  const handleExportPersonalData = () => {
    const payload = {
      platform: 'RAJU AI',
      exportedAt: new Date().toISOString(),
      profile: {
        displayName,
        email: currentUser?.email || 'local_guest',
        preferredLanguage: language,
        preferredVoice: selectedVoice,
        xp,
        level: calculateLevelFromXP(xp).level,
      },
      memories,
      tasks,
      studyProgress,
      conversations: messages,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `raju_ai_personal_data_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRecordAttempt = (attempt: PracticeAttempt) => {
    setAttempts((prev) => [attempt, ...prev].slice(0, 200));
  };

  const handleToggleMasteredKanji = (kanji: string) => {
    setAnalytics((prev) => {
      const exists = prev.masteredKanji.includes(kanji);
      const nextList = exists
        ? prev.masteredKanji.filter((k) => k !== kanji)
        : [...prev.masteredKanji, kanji];
      return {
        ...prev,
        masteredKanji: nextList,
      };
    });
  };

  const handleLearnVocab = (count = 1) => {
    setAnalytics((prev) => ({
      ...prev,
      learnedVocabCount: prev.learnedVocabCount + count,
    }));
  };

  const handleDeleteAllUserData = async () => {
    await handleClearConversationHistory();
    setMemories([]);
    setTasks([]);
    setStudyProgress([]);
    setAttempts([]);
    setAnalytics(getDefaultAnalytics());
    try {
      localStorage.removeItem(PRACTICE_ATTEMPTS_STORAGE_KEY);
      localStorage.removeItem(LEARNING_ANALYTICS_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const levelInfo = calculateLevelFromXP(xp);

  const quickActionPrompts = [
    {
      label: 'Ask anything...',
      prompt: 'Explain how quantum computing differs from classical computing with an intuitive everyday analogy.',
      icon: Sparkles,
    },
    {
      label: 'Study Help',
      prompt: 'Create a 5-point CUET Biology revision summary on DNA Replication and Transcription.',
      icon: BookOpen,
    },
    {
      label: 'Learn Japanese',
      prompt: 'Teach me 5 essential Japanese greetings with Hiragana, Romaji, English, and Hindi meanings.',
      icon: Languages,
    },
    {
      label: 'Create with AI',
      prompt: 'Design a clean full-stack architecture for a real-time collaborative study app.',
      icon: Code2,
    },
  ];

  const quickToolsGrid: Array<{
    id: ModuleId;
    title: string;
    icon: React.ComponentType<{ className?: string }>;
    accent: string;
  }> = [
    { id: 'voice', title: 'Voice Assistant', icon: Mic, accent: 'text-cyan-400' },
    { id: 'pdf', title: 'PDF Reader', icon: FileText, accent: 'text-rose-400' },
    { id: 'image', title: 'Image Analyzer', icon: ImageIcon, accent: 'text-sky-400' },
    { id: 'research', title: 'Web Research', icon: Globe, accent: 'text-blue-400' },
    { id: 'coding', title: 'Coding Lab', icon: Code2, accent: 'text-indigo-400' },
    { id: 'study', title: 'Study Mode', icon: GraduationCap, accent: 'text-purple-400' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#060919] text-slate-100">
      {/* Offline Banner */}
      {!isOnline && (
        <div className="bg-amber-600/90 text-white text-xs font-medium px-4 py-1.5 text-center">
          Offline Mode — Cached interface & local study data are available. Live Gemini API calls will resume when online.
        </div>
      )}

      {/* Top Navigation Bar (Strict 3-Zone Contract) */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5 bg-[#070B20]/95 backdrop-blur-md border-b border-slate-800/80">
        {/* Zone 1: Brand Title */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setMobileMenuOpen((o) => !o)}
            aria-label="Toggle navigation menu"
            className="lg:hidden p-2 rounded-xl bg-[#0B102B] border border-slate-800 text-slate-200"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('chat')}
            className="flex items-center gap-2.5 text-xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-400 to-purple-400 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <img src="/icon.svg" alt="" className="w-8 h-8 rounded-lg" />
            RAJU AI
          </button>
        </div>

        {/* Zone 2: 5 Single-Line Navigation Links */}
        <nav aria-label="Primary top navigation" className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            type="button"
            onClick={() => setActiveModule('chat')}
            className={`hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'chat' ? 'text-cyan-300 underline underline-offset-8' : ''
            }`}
          >
            AI Chat
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('voice')}
            className={`hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'voice' ? 'text-cyan-300 underline underline-offset-8' : ''
            }`}
          >
            Live Voice
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('memory')}
            className={`hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'memory' ? 'text-cyan-300 underline underline-offset-8' : ''
            }`}
          >
            Memory
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('study')}
            className={`hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'study' ? 'text-cyan-300 underline underline-offset-8' : ''
            }`}
          >
            Study
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('japanese')}
            className={`hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'japanese' ? 'text-cyan-300 underline underline-offset-8' : ''
            }`}
          >
            Japanese
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          {isInstallable && !isInstalled ? (
            <button
              type="button"
              onClick={install}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Install App
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setActiveModule('voice')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-[0_0_20px_rgba(0,210,255,0.3)] transition whitespace-nowrap shrink-0"
            >
              <Mic className="w-3.5 h-3.5" />
              Start Voice Chat
            </button>
          )}
        </div>
      </header>

      {/* Main Workspace Layout: Sidebar + Content Viewport */}
      <div className="flex-1 flex relative max-w-[1600px] w-full mx-auto">
        {/* Left Sidebar Navigation (Desktop Permanent, Mobile Drawer) */}
        <aside
          aria-label="Module navigation sidebar"
          className={`${
            mobileMenuOpen ? 'fixed inset-y-0 left-0 z-40 w-64 bg-[#070B20] pt-16' : 'hidden'
          } lg:block lg:w-60 shrink-0 border-r border-slate-800/80 bg-[#070B20]/70 p-3.5 flex flex-col justify-between`}
        >
          <div className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveModule(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-600/90 to-indigo-600/90 text-white shadow-[0_0_20px_rgba(59,130,246,0.35)] border border-cyan-400/40'
                      : 'text-slate-400 hover:text-white hover:bg-[#0D1438]/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-cyan-200' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Account & Level Summary Footer in Sidebar */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 space-y-3">
            <div className="px-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">{displayName}</span>
                <span className="font-mono text-cyan-300 tabular-nums">
                  Lv.{levelInfo.level} · {levelInfo.progressPercent}%
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Talk • Learn • Create • Explore
              </p>
            </div>

            {!currentUser && (
              <button
                type="button"
                onClick={handleSignInGoogle}
                className="w-full py-2 px-3 rounded-xl bg-[#0B102B] border border-slate-700 hover:border-cyan-400 text-xs font-semibold text-cyan-300 flex items-center justify-center gap-1.5 transition"
              >
                <LogIn className="w-3.5 h-3.5" />
                Sync Account
              </button>
            )}
          </div>
        </aside>

        {/* Main Content Viewport */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-7 overflow-y-auto">
          {activeModule === 'chat' && (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-stretch">
              {/* Center AI Orb & Chat Stage (8 cols on XL) */}
              <div className="xl:col-span-8 flex flex-col justify-between rounded-2xl bg-[#090E26]/90 border border-slate-800/90 p-5 sm:p-7 min-h-[640px]">
                {/* Top Language & Model Context Bar inside Workspace */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800/70">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400">
                    <span className="font-semibold text-cyan-300 whitespace-nowrap">Powered by Gemini 4 Hydrogen</span>
                    <span aria-hidden="true">·</span>
                    <span className="whitespace-nowrap">Voice: {selectedVoice}</span>
                  </div>

                  <div className="flex items-center gap-1 p-1 rounded-xl bg-[#060919] border border-slate-800 max-w-full overflow-x-auto">
                    {(['Hindi', 'English', 'Hinglish', 'Japanese'] as SupportedLanguage[]).map((lang) => (
                      <button
                        key={lang}
                        type="button"
                        onClick={() => setLanguage(lang)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition whitespace-nowrap shrink-0 ${
                          language === lang
                            ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {lang}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Central Hero Orb or Active Chat Thread */}
                {messages.length === 0 ? (
                  <div className="my-auto py-8 flex flex-col items-center text-center space-y-5">
                    <LotusOrb
                      size="lg"
                      state={isStreamingChat ? 'thinking' : 'idle'}
                      onClick={() => setActiveModule('voice')}
                      label="Activate RAJU AI Live Voice"
                    />

                    <div className="space-y-1.5 max-w-xl">
                      <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight text-balance">
                        Hello, welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-purple-400">RAJU AI</span>
                      </h1>
                      <p className="text-sm text-slate-300">
                        Your Smart AI Companion for a Better Tomorrow
                      </p>
                    </div>

                    {/* Quick Prompt Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
                      {quickActionPrompts.map((item) => {
                        const Icon = item.icon;
                        return (
                          <button
                            key={item.label}
                            type="button"
                            onClick={() => sendChatMessage(item.prompt)}
                            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0E163B]/90 hover:bg-[#162052] border border-slate-700/80 hover:border-cyan-400/60 text-xs font-medium text-slate-100 transition whitespace-nowrap shrink-0"
                          >
                            <Icon className="w-3.5 h-3.5 text-cyan-400" />
                            {item.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 overflow-y-auto py-4 space-y-4 max-h-[460px] pr-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400">
                        Conversation History ({messages.length} messages)
                      </span>
                      <button
                        type="button"
                        onClick={handleClearConversationHistory}
                        className="text-xs text-slate-400 hover:text-rose-300 flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Clear Chat
                      </button>
                    </div>

                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed ${
                            msg.role === 'user'
                              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
                              : 'bg-[#060919]/90 border border-slate-800 text-slate-100'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-4 text-[11px] opacity-75 mb-1">
                            <span className="font-semibold">
                              {msg.role === 'user' ? displayName : 'RAJU AI (Gemini 4 Hydrogen)'}
                            </span>
                            <span className="font-mono tabular-nums">
                              {msg.createdAt.slice(11, 16) || 'Now'}
                            </span>
                          </div>
                          {msg.attachmentName && (
                            <p className="text-xs text-cyan-200 mb-1.5 font-mono">
                              Attached: {msg.attachmentName}
                            </p>
                          )}
                          <div className="whitespace-pre-wrap">
                            {msg.content || (isStreamingChat ? 'Thinking...' : '')}
                          </div>
                        </div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                )}

                {chatError && (
                  <div
                    role="alert"
                    className="mb-3 p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{chatError}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setChatError(null)}
                      className="text-xs underline shrink-0"
                    >
                      Dismiss
                    </button>
                  </div>
                )}

                {/* Multimodal Message Composer Bar */}
                <div className="pt-3 border-t border-slate-800/80 space-y-2">
                  {attachedFile && (
                    <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-indigo-950/60 border border-indigo-500/40 text-xs text-cyan-200">
                      <span>Attached: {attachedFile.name}</span>
                      <button
                        type="button"
                        onClick={() => setAttachedFile(null)}
                        className="text-rose-300 hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  )}

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      sendChatMessage();
                    }}
                    className="flex items-center gap-2 p-2 rounded-2xl bg-[#060919] border border-slate-700/90 focus-within:border-cyan-400"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*,.pdf,.txt"
                      onChange={handleFileAttach}
                      className="hidden"
                    />

                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder={`Type your message in ${language}...`}
                      aria-label="Type your message here"
                      className="flex-1 min-w-0 bg-transparent px-2 sm:px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none"
                    />

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      aria-label="Attach document or image"
                      className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800/70 transition shrink-0"
                    >
                      <Paperclip className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveModule('image')}
                      aria-label="Open Image Analyzer"
                      className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800/70 transition shrink-0"
                    >
                      <ImageIcon className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveModule('voice')}
                      aria-label="Open Live Voice Assistant"
                      className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800/70 transition shrink-0"
                    >
                      <Mic className="w-4 h-4" />
                    </button>

                    <button
                      type="submit"
                      disabled={isStreamingChat}
                      aria-label="Send message"
                      className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white transition disabled:opacity-50 shrink-0"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              </div>

              {/* Right Column: Quick Tools Grid, Your Progress & 5 Voice Profiles (4 cols on XL) */}
              <div className="xl:col-span-4 flex flex-col justify-between gap-5">
                {/* Quick Tools Card */}
                <div className="p-5 rounded-2xl bg-[#090E26]/90 border border-slate-800/90 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-base font-bold text-white">Quick Tools</h2>
                    <button
                      type="button"
                      onClick={() => setActiveModule('study')}
                      className="text-xs font-medium text-cyan-300 hover:underline"
                    >
                      See All →
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {quickToolsGrid.map((tool) => {
                      const Icon = tool.icon;
                      return (
                        <button
                          key={tool.id}
                          type="button"
                          onClick={() => setActiveModule(tool.id)}
                          className="p-4 rounded-xl bg-[#0E163B]/80 hover:bg-[#152050] border border-slate-800 hover:border-cyan-400/50 flex flex-col items-center text-center gap-2 transition group"
                        >
                          <div className="p-2.5 rounded-xl bg-[#060919] border border-slate-800 group-hover:border-cyan-400/40">
                            <Icon className={`w-5 h-5 ${tool.accent}`} />
                          </div>
                          <span className="text-xs font-semibold text-slate-100">{tool.title}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Your Progress Card */}
                <div className="p-5 rounded-2xl bg-[#090E26]/90 border border-slate-800/90 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-sm font-bold text-white">Your Progress</h2>
                      <p className="text-xs text-slate-400 mt-0.5 font-mono tabular-nums">
                        Level {levelInfo.level} · {xp.toLocaleString()} XP
                      </p>
                    </div>
                    <div className="p-2 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-300">
                      <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-2.5 rounded-full bg-[#060919] overflow-hidden border border-slate-800">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 rounded-full transition-all duration-300"
                        style={{ width: `${levelInfo.progressPercent}%` }}
                      />
                    </div>
                    <span className="text-xs font-mono tabular-nums text-cyan-300 font-semibold">
                      {levelInfo.progressPercent}%
                    </span>
                  </div>
                </div>

                {/* 6 Voice Personalities Bar */}
                <div className="p-5 rounded-2xl bg-[#090E26]/90 border border-slate-800/90 space-y-3">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-bold text-white">6 Voice Personalities</h2>
                    <button
                      type="button"
                      onClick={() => setActiveModule('voice-studio')}
                      className="text-xs font-medium text-cyan-300 hover:underline"
                    >
                      Voice Studio →
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {VOICE_PROFILES.map((vp) => {
                      const active = selectedVoice === vp.id;
                      return (
                        <button
                          key={vp.id}
                          type="button"
                          onClick={() => setSelectedVoice(vp.id)}
                          className={`p-2 rounded-xl border text-center transition flex flex-col items-center gap-1 ${
                            active
                              ? 'bg-indigo-950/90 border-cyan-400 text-white'
                              : 'bg-[#060919]/80 border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          <Volume2 className={`w-4 h-4 ${active ? 'text-cyan-300' : 'text-slate-500'}`} />
                          <span className="text-[10px] font-semibold leading-tight line-clamp-2">
                            {vp.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'voice' && (
            <LiveVoiceModule
              language={language}
              onLanguageChange={setLanguage}
              selectedVoice={selectedVoice}
              onVoiceChange={setSelectedVoice}
              onEarnXp={handleEarnXp}
            />
          )}

          {activeModule === 'memory' && (
            <MemoryModule
              memories={memories}
              memoryConsentEnabled={memoryConsent}
              onToggleGlobalConsent={setMemoryConsent}
              onAddMemory={handleAddMemory}
              onUpdateMemory={handleUpdateMemory}
              onDeleteMemory={handleDeleteMemory}
              onClearConversationHistory={handleClearConversationHistory}
              onExportPersonalData={handleExportPersonalData}
            />
          )}

          {activeModule === 'image' && (
            <ImageAnalyzerModule
              language={language}
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'pdf' && (
            <PdfReaderModule
              language={language}
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'research' && (
            <WebResearchModule
              language={language}
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'study' && (
            <StudyAssistantModule
              language={language}
              progressRecords={studyProgress}
              onSaveProgress={handleSaveStudyProgress}
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'questions' && (
            <SmartQuestionGeneratorModule
              language={language}
              attempts={attempts}
              initialRevisionTopic={revisionTopic}
              onRecordAttempt={handleRecordAttempt}
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'japanese' && (
            <JapaneseLearningModule
              onEarnXp={handleEarnXp}
              masteredKanji={analytics.masteredKanji}
              onToggleMasteredKanji={handleToggleMasteredKanji}
              onLearnVocab={handleLearnVocab}
              onOpenVisualDiagrams={() => setActiveModule('diagrams')}
            />
          )}

          {activeModule === 'diagrams' && (
            <VisualDiagramEngineModule onEarnXp={handleEarnXp} />
          )}

          {activeModule === 'tutor' && (
            <JapaneseTutorModule
              selectedVoice={selectedVoice}
              onVoiceChange={setSelectedVoice}
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'progress' && (
            <ProgressDashboardModule
              xp={xp}
              level={levelInfo.level}
              analytics={analytics}
              attempts={attempts}
              studyProgress={studyProgress}
              onStartWeakRevision={(topic) => {
                setRevisionTopic(topic);
                setActiveModule('questions');
              }}
              onOpenKanji={() => setActiveModule('japanese')}
            />
          )}

          {activeModule === 'coding' && (
            <CodingLabModule
              onEarnXp={handleEarnXp}
              onRecordTokens={handleRecordTokens}
            />
          )}

          {activeModule === 'tasks' && (
            <TaskManagerModule
              tasks={tasks}
              onAddTask={handleAddTask}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
            />
          )}

          {activeModule === 'voice-studio' && (
            <VoiceStudioModule
              selectedVoice={selectedVoice}
              onVoiceChange={setSelectedVoice}
              language={language}
              onEarnXp={handleEarnXp}
            />
          )}

          {activeModule === 'settings' && (
            <SettingsAndArchitectureModule
              userEmail={currentUser?.email || null}
              displayName={displayName}
              onUpdateDisplayName={setDisplayName}
              language={language}
              onLanguageChange={setLanguage}
              selectedVoice={selectedVoice}
              onVoiceChange={setSelectedVoice}
              thinkingLevel={thinkingLevel}
              onThinkingLevelChange={setThinkingLevel}
              memoryConsent={memoryConsent}
              onToggleMemoryConsent={setMemoryConsent}
              totalTokensUsed={totalTokensUsed}
              totalRequestsCount={totalRequestsCount}
              onSignInGoogle={handleSignInGoogle}
              onSignOut={handleSignOut}
              onExportPersonalData={handleExportPersonalData}
              onDeleteAllUserData={handleDeleteAllUserData}
            />
          )}
        </main>
      </div>
    </div>
  );
}
