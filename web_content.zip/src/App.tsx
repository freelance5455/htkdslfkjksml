import { useCallback, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { DisplayPanel } from './components/DisplayPanel';
import { HistoryPanel } from './components/HistoryPanel';
import { RegularKeypad } from './components/RegularKeypad';
import { ScientificKeypad } from './components/ScientificKeypad';
import { TopBar } from './components/TopBar';
import type { AngleMode, CalculatorMode, HistoryItem } from './types/calculator';
import {
  addToMemory,
  applyReciprocalInExpression,
  deleteLastToken,
  evaluateExpression,
  evaluatePreview,
  subtractFromMemory,
  toggleSignInExpression,
} from './utils/mathEngine';

const STORAGE_KEYS = {
  theme: 'calc-studio-theme',
  mode: 'calc-studio-mode',
  angle: 'calc-studio-angle',
  history: 'calc-studio-history',
  memory: 'calc-studio-memory',
} as const;

function getInitialTheme(): boolean {
  if (typeof document !== 'undefined') {
    return document.documentElement.classList.contains('dark');
  }
  return false;
}

function getInitialMode(): CalculatorMode {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.mode);
    if (saved === 'regular' || saved === 'scientific') return saved;
  } catch {
    // ignore storage errors
  }
  return 'regular';
}

function getInitialAngle(): AngleMode {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.angle);
    if (saved === 'DEG' || saved === 'RAD') return saved;
  } catch {
    // ignore storage errors
  }
  return 'DEG';
}

function getInitialHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.history);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore storage errors
  }
  return [];
}

function getInitialMemory(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.memory);
    if (saved) return saved;
  } catch {
    // ignore storage errors
  }
  return '0';
}

function toDisplayNeg(raw: string): string {
  return raw.replace(/-/g, '−');
}

export default function App() {
  const [isDark, setIsDark] = useState<boolean>(getInitialTheme);
  const [mode, setMode] = useState<CalculatorMode>(getInitialMode);
  const [angleMode, setAngleMode] = useState<AngleMode>(getInitialAngle);
  const [expression, setExpression] = useState<string>('');
  const [historyExpression, setHistoryExpression] = useState<string>('');
  const [evaluatedRaw, setEvaluatedRaw] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>(getInitialHistory);
  const [memoryValue, setMemoryValue] = useState<string>(getInitialMemory);
  const [forceScientific, setForceScientific] = useState<boolean>(false);
  const [showFraction, setShowFraction] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  // Sync dark mode class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(STORAGE_KEYS.theme, isDark ? 'dark' : 'light');
    } catch {
      // ignore
    }
  }, [isDark]);

  // Persist preferences & history offline
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.mode, mode);
    } catch {
      // ignore
    }
  }, [mode]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.angle, angleMode);
    } catch {
      // ignore
    }
  }, [angleMode]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.history, JSON.stringify(history));
    } catch {
      // ignore
    }
  }, [history]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.memory, memoryValue);
    } catch {
      // ignore
    }
  }, [memoryValue]);

  // Live preview calculation while typing
  const preview = useMemo(() => {
    if (error || evaluatedRaw !== null || !expression) return null;
    return evaluatePreview(expression, angleMode);
  }, [expression, angleMode, error, evaluatedRaw]);

  const handleClear = useCallback(() => {
    setExpression('');
    setHistoryExpression('');
    setEvaluatedRaw(null);
    setError(null);
    setShowFraction(false);
  }, []);

  const handleBackspace = useCallback(() => {
    if (error) {
      setError(null);
      setEvaluatedRaw(null);
      return;
    }
    if (evaluatedRaw !== null) {
      // Allow editing the evaluated result directly
      const editable = toDisplayNeg(evaluatedRaw);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression(deleteLastToken(editable));
      return;
    }
    setExpression((prev) => deleteLastToken(prev));
  }, [error, evaluatedRaw]);

  const handleDigit = useCallback(
    (digit: string) => {
      if (error || evaluatedRaw !== null) {
        setError(null);
        setEvaluatedRaw(null);
        setHistoryExpression('');
        setShowFraction(false);
        setExpression(digit);
        return;
      }

      setExpression((prev) => {
        if (prev === '0') return digit;
        // Prevent redundant leading zeros after an operator/paren
        if (/(?:[+\-−×÷^(/]|mod)0$/.test(prev)) {
          return prev.slice(0, -1) + digit;
        }
        return prev + digit;
      });
    },
    [error, evaluatedRaw]
  );

  const handleDecimal = useCallback(() => {
    if (error || evaluatedRaw !== null) {
      setError(null);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression('0.');
      return;
    }

    setExpression((prev) => {
      if (!prev) return '0.';
      // Check trailing number token for existing decimal or scientific exponent
      const match = prev.match(/([0-9.E+-]+)$/);
      if (match) {
        const segment = match[1];
        // Cannot put decimal inside exponent or twice in same number
        if (segment.includes('.') || segment.includes('E')) {
          return prev;
        }
        if (/[0-9]$/.test(prev)) {
          return prev + '.';
        }
      }
      return prev + '0.';
    });
  }, [error, evaluatedRaw]);

  const handleOperator = useCallback(
    (op: '+' | '−' | '×' | '÷') => {
      if (error) {
        setError(null);
        setEvaluatedRaw(null);
        if (op === '−') {
          setExpression('−');
        } else {
          setExpression('');
        }
        return;
      }

      if (evaluatedRaw !== null) {
        const base = toDisplayNeg(evaluatedRaw);
        setEvaluatedRaw(null);
        setHistoryExpression('');
        setShowFraction(false);
        setExpression(`${base}${op}`);
        return;
      }

      setExpression((prev) => {
        if (!prev) {
          return op === '−' ? '−' : `0${op}`;
        }
        if (prev === '−') {
          return op === '−' ? '−' : '';
        }
        // Allow unary minus after E, (, ×, ÷, ^, mod
        if (op === '−' && /(?:[×÷^(/E]|mod)$/.test(prev)) {
          return prev + '−';
        }
        // Do not place binary operators right after '(' or incomplete 'E'
        if (/(?:\(|E[+\-−]?)$/.test(prev)) {
          return prev;
        }
        // Replace trailing binary operator cleanly
        if (prev.endsWith('mod')) {
          return prev.slice(0, -3) + op;
        }
        if (/[+−×÷^/]$/.test(prev)) {
          // If preceded by another operator (e.g. ×−), replace both
          if (prev.length >= 2 && /[×÷^(/]−$/.test(prev)) {
            return prev.slice(0, -2) + op;
          }
          return prev.slice(0, -1) + op;
        }
        return prev + op;
      });
    },
    [error, evaluatedRaw]
  );

  const handleInsertBinary = useCallback(
    (op: '^' | 'mod' | '/') => {
      if (error) {
        setError(null);
        setEvaluatedRaw(null);
        setExpression('');
        return;
      }

      if (evaluatedRaw !== null) {
        const base = toDisplayNeg(evaluatedRaw);
        const wrapped = evaluatedRaw.startsWith('-') && op === '^' ? `(${base})` : base;
        setEvaluatedRaw(null);
        setHistoryExpression('');
        setShowFraction(false);
        setExpression(`${wrapped}${op}`);
        return;
      }

      setExpression((prev) => {
        if (!prev) return `0${op}`;
        if (/(?:\(|E[+\-−]?)$/.test(prev)) return prev;
        if (prev.endsWith('mod')) {
          return prev.slice(0, -3) + op;
        }
        if (/[+−×÷^/]$/.test(prev)) {
          if (prev.length >= 2 && /[×÷^(/]−$/.test(prev)) {
            return prev.slice(0, -2) + op;
          }
          return prev.slice(0, -1) + op;
        }
        return prev + op;
      });
    },
    [error, evaluatedRaw]
  );

  const handlePercent = useCallback(() => {
    if (error) return;
    if (evaluatedRaw !== null) {
      const base = toDisplayNeg(evaluatedRaw);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression(`${base}%`);
      return;
    }
    setExpression((prev) => {
      if (!prev || /(?:[+−×÷^(/E]|mod)$/.test(prev)) return prev;
      return prev + '%';
    });
  }, [error, evaluatedRaw]);

  const handleToggleSign = useCallback(() => {
    if (error) {
      setError(null);
      setExpression('−');
      return;
    }
    if (evaluatedRaw !== null) {
      const negated = evaluatedRaw.startsWith('-')
        ? evaluatedRaw.slice(1)
        : evaluatedRaw === '0'
          ? '0'
          : `−${evaluatedRaw}`;
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression(negated);
      return;
    }
    setExpression((prev) => {
      // If typing scientific exponent like 2.5E, toggle minus sign on exponent
      if (prev.endsWith('E')) return prev + '−';
      if (prev.endsWith('E−') || prev.endsWith('E-')) return prev.slice(0, -1);
      return toggleSignInExpression(prev);
    });
  }, [error, evaluatedRaw]);

  const handleInsertFunc = useCallback(
    (fnToken: string) => {
      if (error || evaluatedRaw !== null) {
        setError(null);
        setEvaluatedRaw(null);
        setHistoryExpression('');
        setShowFraction(false);
        setExpression(fnToken);
        return;
      }
      setExpression((prev) => {
        if (prev.endsWith('E') || prev.endsWith('E−')) return prev;
        return prev + fnToken;
      });
    },
    [error, evaluatedRaw]
  );

  const handleInsertConst = useCallback(
    (constSymbol: 'π' | 'e') => {
      if (error || evaluatedRaw !== null) {
        setError(null);
        setEvaluatedRaw(null);
        setHistoryExpression('');
        setShowFraction(false);
        setExpression(constSymbol);
        return;
      }
      setExpression((prev) => {
        if (prev.endsWith('E') || prev.endsWith('E−')) return prev;
        return prev + constSymbol;
      });
    },
    [error, evaluatedRaw]
  );

  const handleInsertPostfix = useCallback(
    (postfix: '²' | '³' | '!') => {
      if (error) return;
      if (evaluatedRaw !== null) {
        const base = toDisplayNeg(evaluatedRaw);
        const target = evaluatedRaw.startsWith('-') ? `(${base})` : base;
        setEvaluatedRaw(null);
        setHistoryExpression('');
        setShowFraction(false);
        setExpression(`${target}${postfix}`);
        return;
      }
      setExpression((prev) => {
        if (!prev || /(?:[+−×÷^(/E]|mod)$/.test(prev)) return prev;
        return prev + postfix;
      });
    },
    [error, evaluatedRaw]
  );

  const handleInsertParen = useCallback(
    (paren: '(' | ')') => {
      if (paren === '(') {
        if (error || evaluatedRaw !== null) {
          setError(null);
          setEvaluatedRaw(null);
          setHistoryExpression('');
          setShowFraction(false);
          setExpression('(');
          return;
        }
        setExpression((prev) => prev + '(');
        return;
      }

      // Closing parenthesis ')'
      if (error || evaluatedRaw !== null) return;
      setExpression((prev) => {
        let openCount = 0;
        for (const ch of prev) {
          if (ch === '(') openCount++;
          else if (ch === ')') openCount = Math.max(0, openCount - 1);
        }
        if (openCount === 0) return prev;
        if (/(?:[+−×÷^(/E]|mod)$/.test(prev)) return prev;
        return prev + ')';
      });
    },
    [error, evaluatedRaw]
  );

  const handleReciprocal = useCallback(() => {
    if (error) return;
    if (evaluatedRaw !== null) {
      const base = toDisplayNeg(evaluatedRaw);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression(`(1÷${evaluatedRaw.startsWith('-') ? `(${base})` : base})`);
      return;
    }
    setExpression((prev) => applyReciprocalInExpression(prev));
  }, [error, evaluatedRaw]);

  const handleInsertExpNotation = useCallback(() => {
    if (error) return;
    if (evaluatedRaw !== null) {
      const base = toDisplayNeg(evaluatedRaw);
      if (base.includes('E')) return;
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression(`${base}E`);
      return;
    }
    setExpression((prev) => {
      if (!prev || !/[0-9]$/.test(prev)) return prev;
      // Check if current number already has 'E'
      const match = prev.match(/([0-9.E+-]+)$/);
      if (match && match[1].includes('E')) return prev;
      return prev + 'E';
    });
  }, [error, evaluatedRaw]);

  const handlePowerOfTen = useCallback(() => {
    if (error || evaluatedRaw !== null) {
      setError(null);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression('10^(');
      return;
    }
    setExpression((prev) => prev + '10^(');
  }, [error, evaluatedRaw]);

  const handleExpOfE = useCallback(() => {
    if (error || evaluatedRaw !== null) {
      setError(null);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression('e^(');
      return;
    }
    setExpression((prev) => prev + 'e^(');
  }, [error, evaluatedRaw]);

  const handleEquals = useCallback(() => {
    if (error) return;
    if (!expression) {
      setEvaluatedRaw('0');
      return;
    }
    if (evaluatedRaw !== null) return;

    const result = evaluateExpression(expression, angleMode);
    if (!result.ok) {
      setError(result.error);
      setEvaluatedRaw(null);
      return;
    }

    setHistoryExpression(expression);
    setEvaluatedRaw(result.rawString);

    const newItem: HistoryItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      expression,
      result: result.rawString,
      rawResult: result.rawString,
      mode,
      angleMode,
      timestamp: Date.now(),
    };
    setHistory((prev) => [newItem, ...prev].slice(0, 100));
  }, [angleMode, error, evaluatedRaw, expression, mode]);

  // Memory Operations
  const getActiveNumericRaw = useCallback((): string | null => {
    if (error) return null;
    if (evaluatedRaw !== null) return evaluatedRaw;
    if (!expression) return '0';
    const res = evaluateExpression(expression, angleMode);
    return res.ok ? res.rawString : null;
  }, [angleMode, error, evaluatedRaw, expression]);

  const handleMemoryClear = useCallback(() => {
    setMemoryValue('0');
  }, []);

  const handleMemoryRecall = useCallback(() => {
    const memDisplay = toDisplayNeg(memoryValue);
    if (error || evaluatedRaw !== null || !expression) {
      setError(null);
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setShowFraction(false);
      setExpression(memDisplay);
      return;
    }
    setExpression((prev) => {
      if (memoryValue.startsWith('-') && !prev.endsWith('(')) {
        return prev + `(${memDisplay})`;
      }
      return prev + memDisplay;
    });
  }, [error, evaluatedRaw, expression, memoryValue]);

  const handleMemoryAdd = useCallback(() => {
    const val = getActiveNumericRaw();
    if (val === null) return;
    setMemoryValue((prev) => addToMemory(prev, val));
  }, [getActiveNumericRaw]);

  const handleMemorySubtract = useCallback(() => {
    const val = getActiveNumericRaw();
    if (val === null) return;
    setMemoryValue((prev) => subtractFromMemory(prev, val));
  }, [getActiveNumericRaw]);

  const handleSelectHistory = useCallback((item: HistoryItem, loadExpression = false) => {
    setError(null);
    setShowFraction(false);
    if (loadExpression) {
      setEvaluatedRaw(null);
      setHistoryExpression('');
      setExpression(item.expression);
    } else {
      setHistoryExpression(item.expression);
      setEvaluatedRaw(item.rawResult);
      setExpression(toDisplayNeg(item.rawResult));
    }
    setIsHistoryOpen(false);
  }, []);

  const handleClearHistory = useCallback(() => {
    setHistory([]);
  }, []);

  // Physical Keyboard Support
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;

      const key = e.key;
      if (/^[0-9]$/.test(key)) {
        e.preventDefault();
        handleDigit(key);
      } else if (key === '.') {
        e.preventDefault();
        handleDecimal();
      } else if (key === '+') {
        e.preventDefault();
        handleOperator('+');
      } else if (key === '-') {
        e.preventDefault();
        handleOperator('−');
      } else if (key === '*') {
        e.preventDefault();
        handleOperator('×');
      } else if (key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (key === '%') {
        e.preventDefault();
        handlePercent();
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (key === 'Escape' || key === 'Delete') {
        e.preventDefault();
        handleClear();
      } else if (key === '^' && mode === 'scientific') {
        e.preventDefault();
        handleInsertBinary('^');
      } else if (key === '(' && mode === 'scientific') {
        e.preventDefault();
        handleInsertParen('(');
      } else if (key === ')' && mode === 'scientific') {
        e.preventDefault();
        handleInsertParen(')');
      } else if (key === '!' && mode === 'scientific') {
        e.preventDefault();
        handleInsertPostfix('!');
      } else if (key === 'p' && mode === 'scientific') {
        e.preventDefault();
        handleInsertConst('π');
      } else if (key === 'e' && mode === 'scientific') {
        e.preventDefault();
        handleInsertConst('e');
      } else if (key === 'E' && mode === 'scientific') {
        e.preventDefault();
        handleInsertExpNotation();
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    handleBackspace,
    handleClear,
    handleDecimal,
    handleDigit,
    handleEquals,
    handleInsertBinary,
    handleInsertConst,
    handleInsertExpNotation,
    handleInsertParen,
    handleInsertPostfix,
    handleOperator,
    handlePercent,
    mode,
  ]);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-[100dvh] flex flex-col bg-[#F4F6F9] dark:bg-[#0D1015] text-zinc-900 dark:text-zinc-100 transition-colors">
        <TopBar
          mode={mode}
          onModeChange={setMode}
          isDark={isDark}
          onToggleTheme={() => setIsDark((d) => !d)}
          onOpenHistory={() => setIsHistoryOpen(true)}
          historyCount={history.length}
        />

        {/* Main Workspace: Responsive Mobile Full-Width & Desktop 2-Column Studio */}
        <main className="flex-1 w-full max-w-6xl mx-auto px-3 sm:px-6 py-3 sm:py-6 flex items-stretch justify-center">
          <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Calculator Surface (Primary Focal Anchor) */}
            <section
              aria-label="Calculator"
              className="lg:col-span-7 xl:col-span-8 w-full max-w-[480px] mx-auto lg:max-w-none bg-white dark:bg-[#161B22] border border-zinc-200/80 dark:border-zinc-800/80 rounded-3xl p-3.5 sm:p-5 shadow-sm flex flex-col gap-3 sm:gap-4"
            >
              <DisplayPanel
                mode={mode}
                angleMode={angleMode}
                expression={expression}
                historyExpression={historyExpression}
                evaluatedRaw={evaluatedRaw}
                previewRaw={preview ? preview.rawString : null}
                error={error}
                memoryValue={memoryValue}
                forceScientific={forceScientific}
                showFraction={showFraction}
                onToggleFraction={() => setShowFraction((f) => !f)}
                onToggleAngleMode={() =>
                  setAngleMode((a) => (a === 'DEG' ? 'RAD' : 'DEG'))
                }
              />

              <AnimatePresence mode="wait" initial={false}>
                {mode === 'regular' ? (
                  <motion.div
                    key="regular-pad"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <RegularKeypad
                      onDigit={handleDigit}
                      onDecimal={handleDecimal}
                      onOperator={handleOperator}
                      onPercent={handlePercent}
                      onToggleSign={handleToggleSign}
                      onClear={handleClear}
                      onBackspace={handleBackspace}
                      onEquals={handleEquals}
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="scientific-pad"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <ScientificKeypad
                      angleMode={angleMode}
                      forceScientific={forceScientific}
                      hasMemory={memoryValue !== '0' && memoryValue !== ''}
                      onToggleAngleMode={() =>
                        setAngleMode((a) => (a === 'DEG' ? 'RAD' : 'DEG'))
                      }
                      onToggleScientificNotation={() =>
                        setForceScientific((s) => !s)
                      }
                      onMemoryClear={handleMemoryClear}
                      onMemoryRecall={handleMemoryRecall}
                      onMemoryAdd={handleMemoryAdd}
                      onMemorySubtract={handleMemorySubtract}
                      onInsertFunc={handleInsertFunc}
                      onInsertConst={handleInsertConst}
                      onInsertPostfix={handleInsertPostfix}
                      onInsertBinary={handleInsertBinary}
                      onInsertParen={handleInsertParen}
                      onReciprocal={handleReciprocal}
                      onInsertExpNotation={handleInsertExpNotation}
                      onPowerOfTen={handlePowerOfTen}
                      onExpOfE={handleExpOfE}
                      onDigit={handleDigit}
                      onDecimal={handleDecimal}
                      onOperator={handleOperator}
                      onPercent={handlePercent}
                      onToggleSign={handleToggleSign}
                      onClear={handleClear}
                      onBackspace={handleBackspace}
                      onEquals={handleEquals}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </section>

            {/* Desktop Docked History Panel */}
            <aside
              aria-label="Calculation History"
              className="hidden lg:flex lg:col-span-5 xl:col-span-4 flex-col bg-white dark:bg-[#161B22] border border-zinc-200/80 dark:border-zinc-800/80 rounded-3xl shadow-sm h-[620px] sticky top-20 overflow-hidden"
            >
              <HistoryPanel
                history={history}
                forceScientific={forceScientific}
                onSelectHistory={handleSelectHistory}
                onClearHistory={handleClearHistory}
              />
            </aside>
          </div>
        </main>

        {/* Mobile Slide-Up History Drawer */}
        <AnimatePresence>
          {isHistoryOpen && (
            <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.16 }}
                onClick={() => setIsHistoryOpen(false)}
                className="absolute inset-0 bg-black/50 backdrop-blur-xs"
              />
              <motion.div
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                className="relative w-full max-h-[78dvh] bg-white dark:bg-[#161B22] rounded-t-3xl border-t border-zinc-200 dark:border-zinc-800 shadow-2xl flex flex-col overflow-hidden"
              >
                <div className="w-10 h-1.5 rounded-full bg-zinc-300 dark:bg-zinc-700 mx-auto mt-3 shrink-0" />
                <div className="flex-1 overflow-hidden flex flex-col">
                  <HistoryPanel
                    history={history}
                    forceScientific={forceScientific}
                    onSelectHistory={handleSelectHistory}
                    onClearHistory={handleClearHistory}
                    onClose={() => setIsHistoryOpen(false)}
                    isDrawer
                  />
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
