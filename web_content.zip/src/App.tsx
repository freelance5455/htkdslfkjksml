import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  UserPlus,
  RotateCcw,
  ArrowRightLeft,
  Settings as SettingsIcon,
  History,
  Volume2,
  VolumeX,
  Trophy,
  AlertOctagon,
  Flame,
  Flag,
  Share2,
  Check,
} from 'lucide-react';

import {
  Player,
  BallColor,
  ScoreMode,
  MatchSettings,
  ShotRecord,
  GameSnapshot,
} from './types';
import {
  SNOOKER_BALLS,
  INITIAL_PLAYERS,
  INITIAL_SETTINGS,
  toPersianDigits,
  calculateRemainingPoints,
  calculateSnookersNeeded,
} from './utils/snooker';
import { soundEngine } from './utils/audio';

import { BallButton } from './components/BallButton';
import { PlayerCard } from './components/PlayerCard';
import { TableOverview } from './components/TableOverview';
import { FoulModal } from './components/FoulModal';
import { ShotHistoryModal } from './components/ShotHistoryModal';
import { SettingsModal } from './components/SettingsModal';
import { AddPlayerModal, EditPlayerModal, FrameWinnerModal } from './components/PlayerModals';

const STORAGE_KEY = 'snooker_pro_match_state_v1';

export default function App() {
  // --- Core State ---
  const [players, setPlayers] = useState<Player[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.players) && parsed.players.length > 0) {
          return parsed.players;
        }
      }
    } catch {}
    return INITIAL_PLAYERS;
  });

  const [activePlayerId, setActivePlayerId] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.activePlayerId) return parsed.activePlayerId;
      }
    } catch {}
    return 1;
  });

  const [currentMode, setCurrentMode] = useState<ScoreMode>('hit');

  const [settings, setSettings] = useState<MatchSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.settings) return parsed.settings;
      }
    } catch {}
    return INITIAL_SETTINGS;
  });

  const [historyLogs, setHistoryLogs] = useState<ShotRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.historyLogs)) return parsed.historyLogs;
      }
    } catch {}
    return [];
  });

  // Undo stack
  const [undoStack, setUndoStack] = useState<GameSnapshot[]>([]);

  // Modals state
  const [isFoulModalOpen, setIsFoulModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAddPlayerModalOpen, setIsAddPlayerModalOpen] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [frameWinner, setFrameWinner] = useState<Player | null>(null);
  const [copiedShare, setCopiedShare] = useState(false);

  // Sync sound setting to engine
  useEffect(() => {
    soundEngine.enabled = settings.soundEnabled;
  }, [settings.soundEnabled]);

  // Persist state to LocalStorage
  useEffect(() => {
    try {
      const snapshot: GameSnapshot = {
        players,
        activePlayerId,
        currentMode,
        settings,
        historyLogs,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
    } catch {}
  }, [players, activePlayerId, currentMode, settings, historyLogs]);

  // Active Player reference
  const activePlayer = useMemo(() => {
    return players.find((p) => p.id === activePlayerId) || players[0];
  }, [players, activePlayerId]);

  // Sorted Players for Leaderboard ranking
  const sortedPlayers = useMemo(() => {
    return [...players].sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.highestBreak - a.highestBreak;
    });
  }, [players]);

  // Push snapshot to undo stack before mutation
  const pushSnapshot = () => {
    setUndoStack((prev) => [
      ...prev.slice(-20), // keep up to 20 snapshots
      {
        players: JSON.parse(JSON.stringify(players)),
        activePlayerId,
        currentMode,
        settings: { ...settings },
        historyLogs: [...historyLogs],
      },
    ]);
  };

  // Handle Undo
  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const last = undoStack[undoStack.length - 1];
    setUndoStack((prev) => prev.slice(0, -1));

    setPlayers(last.players);
    setActivePlayerId(last.activePlayerId);
    setCurrentMode(last.currentMode);
    setSettings(last.settings);
    setHistoryLogs(last.historyLogs);

    soundEngine.playBallHit(1);
  };

  // Ball click handler
  const handleBallClick = (ballId: BallColor) => {
    if (!activePlayer) return;
    pushSnapshot();

    const ball = SNOOKER_BALLS[ballId];
    const points = ballId === 'red' ? settings.redValue : ball.points;
    const isHit = currentMode === 'hit';

    // If red is pocketed, decrement remaining reds
    let newRemainingReds = settings.remainingReds;
    if (ballId === 'red' && isHit && settings.remainingReds > 0) {
      newRemainingReds = Math.max(0, settings.remainingReds - 1);
      setSettings((prev) => ({ ...prev, remainingReds: newRemainingReds }));
    }

    // Play tactile sound
    if (isHit) {
      soundEngine.playBallHit(points);
    } else {
      soundEngine.playFoul();
    }

    const prevBreak = activePlayer.currentBreak;
    let nextBreak = prevBreak;

    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id !== activePlayer.id) return p;

        if (isHit) {
          nextBreak = p.currentBreak + points;
          const newScore = p.score + points;
          const newHits = p.hits + 1;
          const newHighBreak = Math.max(p.highestBreak, nextBreak);
          const newMatchHighBreak = Math.max(p.matchHighestBreak, nextBreak);

          // Milestone fanfare sound on century or 50 break
          if (nextBreak >= 50 && prevBreak < 50) {
            soundEngine.playCelebration();
          }

          return {
            ...p,
            score: newScore,
            hits: newHits,
            currentBreak: nextBreak,
            highestBreak: newHighBreak,
            matchHighestBreak: newMatchHighBreak,
          };
        } else {
          // Miss: Deduct score or reset break
          nextBreak = 0;
          const newScore = p.score - points;
          return {
            ...p,
            score: newScore,
            misses: p.misses + 1,
            currentBreak: 0,
          };
        }
      })
    );

    // Record Shot Log
    const newLog: ShotRecord = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now(),
      playerId: activePlayer.id,
      playerName: activePlayer.name,
      ballId,
      ballName: ball.faName,
      points,
      mode: currentMode,
      isFoul: false,
      breakScoreBefore: prevBreak,
      breakScoreAfter: nextBreak,
    };

    setHistoryLogs((prev) => [...prev, newLog]);
  };

  // Next Turn Action
  const handleNextTurn = () => {
    if (players.length === 0) return;
    pushSnapshot();
    soundEngine.playTurnSwitch();

    // Reset current active player break
    setPlayers((prev) =>
      prev.map((p) => (p.id === activePlayerId ? { ...p, currentBreak: 0 } : p))
    );

    // Cycle to next player
    const currentIndex = players.findIndex((p) => p.id === activePlayerId);
    const nextIndex = (currentIndex + 1) % players.length;
    setActivePlayerId(players[nextIndex].id);
  };

  // Commit Foul Action
  const handleCommitFoul = (points: number, reason: string, awardToOpponentId?: number) => {
    if (!activePlayer) return;
    pushSnapshot();
    soundEngine.playFoul();

    const opponent = players.find((p) => p.id === awardToOpponentId);

    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id === activePlayer.id) {
          // Offending player: loses current break and records miss/foul
          const newScore = awardToOpponentId ? p.score : p.score - points;
          return {
            ...p,
            score: newScore,
            misses: p.misses + 1,
            currentBreak: 0,
          };
        }
        if (awardToOpponentId && p.id === awardToOpponentId) {
          // Opponent gets foul penalty points
          return {
            ...p,
            score: p.score + points,
          };
        }
        return p;
      })
    );

    // Record Log
    const newLog: ShotRecord = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now(),
      playerId: activePlayer.id,
      playerName: activePlayer.name,
      ballName: 'خطا',
      points,
      mode: 'foul',
      isFoul: true,
      foulReason: reason,
      opponentAwardedId: opponent?.id,
      opponentAwardedName: opponent?.name,
      breakScoreBefore: activePlayer.currentBreak,
      breakScoreAfter: 0,
    };
    setHistoryLogs((prev) => [...prev, newLog]);

    // In snooker, after a foul the turn typically passes to the next player
    const currentIndex = players.findIndex((p) => p.id === activePlayerId);
    const nextIndex = (currentIndex + 1) % players.length;
    setActivePlayerId(players[nextIndex].id);
  };

  // Remaining Reds adjustment
  const handleUpdateReds = (delta: number) => {
    setSettings((prev) => {
      const next = Math.max(0, Math.min(prev.totalReds, prev.remainingReds + delta));
      return { ...prev, remainingReds: next };
    });
  };

  // Reset Frame
  const handleResetFrame = () => {
    pushSnapshot();
    setPlayers((prev) =>
      prev.map((p) => ({
        ...p,
        score: 0,
        hits: 0,
        misses: 0,
        highestBreak: 0,
        currentBreak: 0,
      }))
    );
    setSettings((prev) => ({
      ...prev,
      remainingReds: prev.totalReds,
    }));
    soundEngine.playPocket();
  };

  // Conclude Frame / Award to Leader
  const handleFinishFrame = () => {
    const leader = sortedPlayers[0];
    if (!leader) return;
    soundEngine.playCelebration();
    setFrameWinner(leader);
  };

  // Advance to Next Frame
  const handleProceedNextFrame = () => {
    if (!frameWinner) return;
    pushSnapshot();

    setPlayers((prev) =>
      prev.map((p) => {
        const isWinner = p.id === frameWinner.id;
        return {
          ...p,
          score: 0,
          hits: 0,
          misses: 0,
          highestBreak: 0,
          currentBreak: 0,
          framesWon: isWinner ? p.framesWon + 1 : p.framesWon,
        };
      })
    );

    setSettings((prev) => ({
      ...prev,
      currentFrame: prev.currentFrame + 1,
      remainingReds: prev.totalReds,
    }));

    setFrameWinner(null);
  };

  // Reset Full Match
  const handleResetMatch = () => {
    pushSnapshot();
    setPlayers((prev) =>
      prev.map((p) => ({
        ...p,
        score: 0,
        framesWon: 0,
        hits: 0,
        misses: 0,
        highestBreak: 0,
        currentBreak: 0,
        matchHighestBreak: 0,
      }))
    );
    setSettings((prev) => ({
      ...prev,
      currentFrame: 1,
      remainingReds: prev.totalReds,
    }));
    setHistoryLogs([]);
    soundEngine.playPocket();
  };

  // Add new player
  const handleAddPlayer = (name: string) => {
    pushSnapshot();
    const newId = Date.now();
    const newPlayer: Player = {
      id: newId,
      name,
      score: 0,
      framesWon: 0,
      hits: 0,
      misses: 0,
      highestBreak: 0,
      currentBreak: 0,
      matchHighestBreak: 0,
    };
    setPlayers((prev) => [...prev, newPlayer]);
    soundEngine.playTurnSwitch();
  };

  // Edit player name
  const handleSavePlayerName = (id: number, newName: string) => {
    pushSnapshot();
    setPlayers((prev) =>
      prev.map((p) => (p.id === id ? { ...p, name: newName } : p))
    );
  };

  // Share / Copy Results summary
  const handleShareSummary = () => {
    const leader = sortedPlayers[0];
    const text = `🎱 نتیجه بازی اسنوکر پرو:
${players
  .map(
    (p, i) =>
      `#${i + 1} ${p.name}: ${p.score} امتیاز (${p.framesWon} فریم) | بریک برتر: ${p.highestBreak}`
  )
  .join('\n')}
🏆 پیشتاز: ${leader ? leader.name : '-'}`;

    navigator.clipboard.writeText(text).then(() => {
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    });
  };

  // Calculate Snookers required for trailer
  const remainingPoints = calculateRemainingPoints(settings.remainingReds, settings.redValue);
  const leaderScore = sortedPlayers[0]?.score || 0;

  return (
    <div
      id="snooker-app"
      dir="rtl"
      className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col justify-between max-w-2xl mx-auto px-3 py-3 sm:px-4 sm:py-4 select-none pb-24 md:pb-6"
    >
      {/* Top Application Bar */}
      <header className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20 font-black text-lg">
            🎱
          </div>
          <div>
            <h1 className="font-extrabold text-base sm:text-lg text-white tracking-tight flex items-center gap-1.5">
              <span>اسنوکر پرو</span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                LIVE
              </span>
            </h1>
            <p className="text-[11px] text-slate-400">رتبه‌بندی پویا و ثبت بریک‌های زنده</p>
          </div>
        </div>

        {/* Quick Toolbar Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Sound Toggle */}
          <button
            type="button"
            onClick={() =>
              setSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))
            }
            aria-label="تغییر وضعیت صدا"
            className="p-2 text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors cursor-pointer"
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {/* History modal trigger */}
          <button
            type="button"
            onClick={() => setIsHistoryModalOpen(true)}
            aria-label="تاریخچه ضربات"
            className="p-2 text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors relative cursor-pointer"
          >
            <History className="w-4 h-4" />
            {historyLogs.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 text-[9px] font-bold rounded-full flex items-center justify-center text-white">
                {historyLogs.length > 9 ? '+۹' : toPersianDigits(historyLogs.length)}
              </span>
            )}
          </button>

          {/* Share / Copy Summary */}
          <button
            type="button"
            onClick={handleShareSummary}
            aria-label="کپی یا اشتراک‌گذاری نتیجه"
            className="p-2 text-slate-400 hover:text-emerald-400 bg-slate-900/80 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors cursor-pointer"
          >
            {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
          </button>

          {/* Settings modal trigger */}
          <button
            type="button"
            onClick={() => setIsSettingsModalOpen(true)}
            aria-label="تنظیمات مسابقه"
            className="p-2 text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors cursor-pointer"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>

          {/* Add Player Button */}
          <button
            type="button"
            onClick={() => setIsAddPlayerModalOpen(true)}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-2.5 sm:px-3 py-1.5 rounded-xl font-bold text-xs shadow-md shadow-blue-600/30 transition-all cursor-pointer mr-1"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">افزودن بازیکن</span>
          </button>
        </div>
      </header>

      {/* Table Overview: Frame status, Remaining Reds, Remaining Points, Snookers Needed */}
      <TableOverview
        settings={settings}
        players={players}
        activePlayer={activePlayer}
        onUpdateReds={handleUpdateReds}
      />

      {/* Players Leaderboard Container */}
      <section className="flex-1 mb-3 overflow-y-auto space-y-2.5 pr-0.5 max-h-[36vh] sm:max-h-[38vh]">
        <div className="flex items-center justify-between px-1">
          <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
            <Trophy className="w-3 h-3 text-amber-400" />
            <span>جدول رده‌بندی زنده (مرتب‌سازی خودکار)</span>
          </span>
          <span className="text-[11px] text-slate-500">برای تغییر نوبت، روی بازیکن کلیک کنید</span>
        </div>

        <div className="space-y-2">
          {sortedPlayers.map((player, index) => {
            const isTrailer = index > 0;
            const snookers = isTrailer
              ? calculateSnookersNeeded(leaderScore, player.score, remainingPoints)
              : 0;

            return (
              <PlayerCard
                key={player.id}
                player={player}
                rank={index + 1}
                isActive={player.id === activePlayerId}
                onSelect={() => {
                  if (player.id !== activePlayerId) {
                    setActivePlayerId(player.id);
                    soundEngine.playTurnSwitch();
                  }
                }}
                onEdit={(e) => {
                  e.stopPropagation();
                  setEditingPlayer(player);
                }}
                isLeader={index === 0}
                snookersNeeded={snookers}
              />
            );
          })}
        </div>
      </section>

      {/* Interactive Controls Panel */}
      <section className="bg-slate-900/90 border border-slate-800/90 backdrop-blur-md rounded-3xl p-3 sm:p-4 shadow-2xl relative z-20">
        {/* Active Player Cue Banner */}
        <div className="flex items-center justify-between bg-slate-950/70 border border-slate-800/80 px-3.5 py-2 rounded-2xl mb-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs text-slate-400">نوبت ضربه:</span>
            <strong className="text-sm font-black text-white">{activePlayer?.name}</strong>
          </div>

          <div className="flex items-center gap-2">
            {activePlayer?.currentBreak > 0 && (
              <div className="flex items-center gap-1 text-xs font-black text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-full">
                <Flame className="w-3 h-3 text-amber-400 animate-pulse" />
                <span>بریک فعلی: {toPersianDigits(activePlayer.currentBreak)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Mode Selector Toggle: Hit (+) vs Miss (-) vs Foul */}
        <div className="grid grid-cols-3 gap-1.5 sm:gap-2 mb-3">
          <button
            type="button"
            onClick={() => setCurrentMode('hit')}
            className={`py-2 px-1 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-1 border cursor-pointer ${
              currentMode === 'hit'
                ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-600/30'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <span>✅ پاکت (+)</span>
          </button>

          <button
            type="button"
            onClick={() => setCurrentMode('miss')}
            className={`py-2 px-1 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-1 border cursor-pointer ${
              currentMode === 'miss'
                ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-600/30'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <span>❌ عدم پاکت (-)</span>
          </button>

          <button
            type="button"
            onClick={() => setIsFoulModalOpen(true)}
            className="py-2 px-1 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-1 border bg-slate-950/60 text-amber-300 border-slate-800 hover:bg-amber-950/40 hover:border-amber-600/40 cursor-pointer"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
            <span>ثبت خطا (Foul)</span>
          </button>
        </div>

        {/* Balls Grid with 3D Spheres */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-3">
          {/* Red Ball */}
          <BallButton
            ball={SNOOKER_BALLS.red}
            points={settings.redValue}
            mode={currentMode}
            onClick={() => handleBallClick('red')}
            disabled={settings.remainingReds <= 0 && settings.ruleMode === 'official'}
            className="col-span-2 sm:col-span-1"
          />

          {/* Yellow */}
          <BallButton
            ball={SNOOKER_BALLS.yellow}
            points={SNOOKER_BALLS.yellow.points}
            mode={currentMode}
            onClick={() => handleBallClick('yellow')}
          />

          {/* Green */}
          <BallButton
            ball={SNOOKER_BALLS.green}
            points={SNOOKER_BALLS.green.points}
            mode={currentMode}
            onClick={() => handleBallClick('green')}
          />

          {/* Brown */}
          <BallButton
            ball={SNOOKER_BALLS.brown}
            points={SNOOKER_BALLS.brown.points}
            mode={currentMode}
            onClick={() => handleBallClick('brown')}
          />

          {/* Blue */}
          <BallButton
            ball={SNOOKER_BALLS.blue}
            points={SNOOKER_BALLS.blue.points}
            mode={currentMode}
            onClick={() => handleBallClick('blue')}
          />

          {/* Pink */}
          <BallButton
            ball={SNOOKER_BALLS.pink}
            points={SNOOKER_BALLS.pink.points}
            mode={currentMode}
            onClick={() => handleBallClick('pink')}
          />

          {/* Black */}
          <BallButton
            ball={SNOOKER_BALLS.black}
            points={SNOOKER_BALLS.black.points}
            mode={currentMode}
            onClick={() => handleBallClick('black')}
          />
        </div>

        {/* Sub-Actions: Next Turn, Undo, Conclude Frame */}
        <div className="grid grid-cols-3 gap-2">
          {/* Next Turn Button */}
          <button
            type="button"
            onClick={handleNextTurn}
            className="py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-blue-600/25 transition-all cursor-pointer active:scale-95"
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>نوبت بعدی ➔</span>
          </button>

          {/* Undo Button */}
          <button
            type="button"
            onClick={handleUndo}
            disabled={undoStack.length === 0}
            className="py-3 bg-slate-800 hover:bg-slate-750 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 font-bold rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-1.5 border border-slate-700/80 transition-all cursor-pointer active:scale-95"
          >
            <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
            <span>بازگشت (Undo)</span>
          </button>

          {/* End / Reset Frame */}
          <button
            type="button"
            onClick={handleFinishFrame}
            className="py-3 bg-slate-800 hover:bg-emerald-950/60 text-emerald-400 hover:text-emerald-300 font-bold rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-1.5 border border-slate-700/80 transition-all cursor-pointer active:scale-95"
          >
            <Flag className="w-3.5 h-3.5" />
            <span>پایان فریم</span>
          </button>
        </div>
      </section>

      {/* Modals */}
      <AnimatePresence>
        {isFoulModalOpen && (
          <FoulModal
            isOpen={isFoulModalOpen}
            onClose={() => setIsFoulModalOpen(false)}
            activePlayer={activePlayer}
            otherPlayers={players.filter((p) => p.id !== activePlayer.id)}
            onCommitFoul={handleCommitFoul}
          />
        )}

        {isHistoryModalOpen && (
          <ShotHistoryModal
            isOpen={isHistoryModalOpen}
            onClose={() => setIsHistoryModalOpen(false)}
            historyLogs={historyLogs}
            onUndo={handleUndo}
            canUndo={undoStack.length > 0}
          />
        )}

        {isSettingsModalOpen && (
          <SettingsModal
            isOpen={isSettingsModalOpen}
            onClose={() => setIsSettingsModalOpen(false)}
            settings={settings}
            onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
            onResetFrame={handleResetFrame}
            onResetMatch={handleResetMatch}
          />
        )}

        {isAddPlayerModalOpen && (
          <AddPlayerModal
            isOpen={isAddPlayerModalOpen}
            onClose={() => setIsAddPlayerModalOpen(false)}
            onAdd={handleAddPlayer}
            playerCount={players.length}
          />
        )}

        {editingPlayer && (
          <EditPlayerModal
            isOpen={!!editingPlayer}
            onClose={() => setEditingPlayer(null)}
            player={editingPlayer}
            onSave={handleSavePlayerName}
          />
        )}

        {frameWinner && (
          <FrameWinnerModal
            isOpen={!!frameWinner}
            onClose={() => setFrameWinner(null)}
            winner={frameWinner}
            frameNumber={settings.currentFrame}
            players={players}
            onNextFrame={handleProceedNextFrame}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
