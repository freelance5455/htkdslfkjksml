/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab } from './types';
import { SplashSignboard } from './components/SplashSignboard';
import { Navbar } from './components/Navbar';
import { BottomTabBar } from './components/BottomTabBar';
import { HomeDashboard } from './components/HomeDashboard';
import { CallScreenWake } from './components/CallScreenWake';
import { AudioFixer } from './components/AudioFixer';
import { ShopServices } from './components/ShopServices';
import { SensorsDiagnostic } from './components/SensorsDiagnostic';
import { InstallModal } from './components/InstallModal';
import { ShieldCheck, Heart, Sparkles, Smartphone } from 'lucide-react';

export default function App() {
  // Opening Billboard Ad state: triggers for 4 seconds on initial launch
  const [showOpeningAd, setShowOpeningAd] = useState<boolean>(true);
  const [showInstallModal, setShowInstallModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');

  // Auto-scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-red-600 selection:text-white pb-20 md:pb-8">
      {/* 4-Second Opening Storefront Billboard Ad */}
      {showOpeningAd && (
        <SplashSignboard onComplete={() => setShowOpeningAd(false)} />
      )}

      {/* PWA Install Modal */}
      <InstallModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
      />

      {/* Top Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenBillboard={() => setShowOpeningAd(true)}
        onOpenInstallModal={() => setShowInstallModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'home' && (
          <HomeDashboard
            setActiveTab={setActiveTab}
            onOpenBillboard={() => setShowOpeningAd(true)}
            onOpenInstallModal={() => setShowInstallModal(true)}
          />
        )}

        {activeTab === 'screen' && <CallScreenWake />}

        {activeTab === 'audio' && <AudioFixer />}

        {activeTab === 'services' && (
          <ShopServices onShowSplash={() => setShowOpeningAd(true)} />
        )}

        {activeTab === 'diagnostics' && <SensorsDiagnostic />}
      </main>

      {/* Bottom Thumb-Friendly Tab Bar for Mobile Devices */}
      <BottomTabBar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Quiet Technical Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-200">ScreenSound Fixer</span>
            <span aria-hidden="true">·</span>
            <span>العجردي لصيانة وبرمجة الجوال</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>يعمل بدون إنترنت (Offline Ready)</span>
            <span aria-hidden="true">·</span>
            <span>متوافق مع Android 8.1+</span>
            <span aria-hidden="true">·</span>
            <span>حفظ الإعدادات محلياً</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
