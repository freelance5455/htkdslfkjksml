/**
 * SPR - Sahil Powerful Run
 * Main Application Entry & 3D Runner Orchestrator
 */

import React, { useEffect, useRef, useState } from 'react';
import { GameEngine } from './game/scenes/GameEngine';
import { MenuScreen } from './components/MenuScreen';
import { HUD } from './components/HUD';
import { ShopModal } from './components/ShopModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { SettingsModal } from './components/SettingsModal';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { HelpModal } from './components/HelpModal';
import { AndroidAppModal } from './components/AndroidAppModal';
import { MissionsModal } from './components/MissionsModal';
import { SpinModal } from './components/SpinModal';
import { FreeCoinsModal } from './components/FreeCoinsModal';
import { RemoveAdsModal } from './components/RemoveAdsModal';
import { FreeChestModal } from './components/FreeChestModal';
import { LoadingScreen } from './components/LoadingScreen';
import { ReviveModal } from './components/ReviveModal';
import { AboutModal } from './components/AboutModal';
import { saveManager } from './game/storage/SaveManager';
import { soundManager } from './game/audio/SoundManager';
import { PowerUpType } from './game/constants';
import { useOrientation } from './hooks/useOrientation';

type AppState = 'menu' | 'playing' | 'paused' | 'revive' | 'game_over';
type ActiveModal =
  | 'none'
  | 'shop'
  | 'daily_reward'
  | 'leaderboard'
  | 'settings'
  | 'help'
  | 'about'
  | 'android_app'
  | 'missions'
  | 'spin'
  | 'free_coins'
  | 'remove_ads'
  | 'free_chest';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);

  // App & Loading State
  const [isLoadingActive, setIsLoadingActive] = useState<boolean>(true);
  const [appState, setAppState] = useState<AppState>('menu');
  const [activeModal, setActiveModal] = useState<ActiveModal>('none');
  const [coins, setCoins] = useState<number>(saveManager.getCoins());
  const [diamonds, setDiamonds] = useState<number>(saveManager.getDiamonds());
  const [highScore, setHighScore] = useState<number>(saveManager.getSaveData().highScore);
  const [gameIconButtons, setGameIconButtons] = useState<boolean>(saveManager.getGameIconButtons());

  // In-Game Real-Time Stats
  const [score, setScore] = useState<number>(0);
  const [distance, setDistance] = useState<number>(0);
  const [sessionCoins, setSessionCoins] = useState<number>(0);
  const [speed, setSpeed] = useState<number>(20);
  const [dangerWarning, setDangerWarning] = useState<boolean>(false);
  const [isSkating, setIsSkating] = useState<boolean>(false);
  const [skateboardTimer, setSkateboardTimer] = useState<number>(0);
  const [activePowerUps, setActivePowerUps] = useState<Record<PowerUpType, number>>({
    magnet: 0,
    rocket: 0,
    shield: 0,
    doubleCoins: 0,
    speedBoost: 0,
  });

  // Game Over Run Result State
  const [gameOverResult, setGameOverResult] = useState<{
    finalScore: number;
    distance: number;
    coinsEarned: number;
    isNewHigh: boolean;
  } | null>(null);

  // High score real-time surpassed notification banner state
  const [newHighScoreNotice, setNewHighScoreNotice] = useState<number | null>(null);

  // Revive visual banner notification state ("💎 -1 REVIVED! KEEP RUNNING!")
  const [revivedNotice, setRevivedNotice] = useState<boolean>(false);
  const [reviveCount, setReviveCount] = useState<number>(0);

  // Shop Active Tab State ('characters' or 'skateboards')
  const [shopTab, setShopTab] = useState<'characters' | 'skateboards'>('characters');

  // Responsive Orientation Detection
  const isPortrait = useOrientation();

  // Cross-device auto-pause when incoming phone call, app minimized or tab switched
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && appState === 'playing') {
        gameEngineRef.current?.pauseGame();
        setAppState('paused');
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [appState]);

  // Hardware & browser back-button sensible navigation without page reloads
  useEffect(() => {
    const handlePopState = () => {
      if (activeModal !== 'none') {
        setActiveModal('none');
        window.history.pushState({ spr: true }, '');
      } else if (appState === 'playing') {
        gameEngineRef.current?.pauseGame();
        setAppState('paused');
        window.history.pushState({ spr: true }, '');
      } else if (appState === 'paused' || appState === 'game_over') {
        handleReturnHome();
        window.history.pushState({ spr: true }, '');
      }
    };

    window.history.pushState({ spr: true }, '');
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [activeModal, appState]);

  // Initialize 3D Game Engine once
  useEffect(() => {
    if (!canvasRef.current) return;

    const engine = new GameEngine(canvasRef.current, {
      onScoreUpdate: (s, d, c, spd) => {
        setScore(s);
        setDistance(d);
        setSessionCoins(c);
        setSpeed(spd);
      },
      onPowerUpUpdate: (powerUps) => {
        setActivePowerUps(powerUps);
      },
      onSkateboardUpdate: (skating, sec) => {
        setIsSkating(skating);
        setSkateboardTimer(sec);
      },
      onDangerWarning: () => {
        setDangerWarning(true);
        setTimeout(() => setDangerWarning(false), 2500);
      },
      onNewHighScore: (newScore) => {
        setNewHighScoreNotice(newScore);
        setHighScore(newScore);
        soundManager.playPowerupSound();
        setTimeout(() => setNewHighScoreNotice(null), 4500);
      },
      onRequestRevive: (currentScore, dist, currentCoins, count) => {
        setScore(currentScore);
        setDistance(dist);
        setSessionCoins(currentCoins);
        setDiamonds(saveManager.getDiamonds());
        setReviveCount(count);
        setAppState('revive');
      },
      onGameOver: (finalScore, dist, coinsEarned, isNewHigh) => {
        setNewHighScoreNotice(null);
        setGameOverResult({
          finalScore,
          distance: dist,
          coinsEarned,
          isNewHigh,
        });
        setCoins(saveManager.getCoins());
        setHighScore(saveManager.getSaveData().highScore);
        setAppState('game_over');
      },
    });

    gameEngineRef.current = engine;

    return () => {
      engine.destroy();
    };
  }, []);

  // --- ACTIONS ---
  const handleStartGame = () => {
    soundManager.unlockAudio();
    soundManager.startMusic();
    setReviveCount(0);
    setAppState('playing');
    setActiveModal('none');
    setDangerWarning(false);
    setNewHighScoreNotice(null);
    gameEngineRef.current?.start();
  };

  const handlePauseGame = () => {
    soundManager.pauseMusic();
    gameEngineRef.current?.togglePause();
    setAppState('paused');
  };

  const handleResumeGame = () => {
    soundManager.resumeMusic();
    gameEngineRef.current?.togglePause();
    setAppState('playing');
  };

  const handleRestartGame = () => {
    soundManager.unlockAudio();
    soundManager.startMusic();
    setReviveCount(0);
    setAppState('playing');
    setActiveModal('none');
    setDangerWarning(false);
    setNewHighScoreNotice(null);
    gameEngineRef.current?.start();
  };

  const handleReviveRun = () => {
    if (saveManager.getDiamonds() < 1) return;
    const ok = saveManager.spendDiamonds(1);
    if (!ok) return;
    soundManager.continueMusic();
    setDiamonds(saveManager.getDiamonds());
    setAppState('playing');
    setRevivedNotice(true);
    setTimeout(() => setRevivedNotice(false), 3200);
    gameEngineRef.current?.revivePlayer();
  };

  const handleDeclineRevive = () => {
    soundManager.fadeOutMusic(600);
    gameEngineRef.current?.declineRevive();
  };

  const handleReturnHome = () => {
    soundManager.stopMusic();
    setReviveCount(0);
    gameEngineRef.current?.enterHomeMode();
    setAppState('menu');
    setActiveModal('none');
    setDangerWarning(false);
    setNewHighScoreNotice(null);
    setCoins(saveManager.getCoins());
    setDiamonds(saveManager.getDiamonds());
    setHighScore(saveManager.getSaveData().highScore);
  };

  const handleCharacterSelected = (charId: number) => {
    gameEngineRef.current?.setCharacter(charId);
    if (appState === 'menu') {
      gameEngineRef.current?.enterHomeMode();
    }
  };

  const handleSkateboardEquipped = (boardId: number) => {
    gameEngineRef.current?.setEquippedSkateboard(boardId);
    if (appState === 'menu') {
      gameEngineRef.current?.enterHomeMode();
    }
  };

  return (
    <main className="relative w-full h-screen overflow-hidden bg-[#05080c] font-sans">
      {/* Background Fullscreen 3D WebGL Canvas */}
      <canvas
        ref={canvasRef}
        id="spr-3d-canvas"
        className="absolute inset-0 w-full h-full block z-0 cursor-grab active:cursor-grabbing"
      />

      {/* 15-Second Full-Screen Loading Screen on Launch */}
      {isLoadingActive && (
        <LoadingScreen onComplete={() => setIsLoadingActive(false)} />
      )}

      {/* Main Menu State */}
      {appState === 'menu' && (
        <MenuScreen
          onPlay={handleStartGame}
          onOpenShop={(tab) => {
            setShopTab(tab || 'characters');
            setActiveModal('shop');
          }}
          onOpenDailyReward={() => setActiveModal('daily_reward')}
          onOpenLeaderboard={() => setActiveModal('leaderboard')}
          onOpenSettings={() => setActiveModal('settings')}
          onOpenHelp={() => setActiveModal('help')}
          onOpenAbout={() => setActiveModal('about')}
          onOpenAndroidApp={() => setActiveModal('android_app')}
          onOpenMissions={() => setActiveModal('missions')}
          onOpenSpin={() => setActiveModal('spin')}
          onOpenFreeCoins={() => setActiveModal('free_coins')}
          onOpenRemoveAds={() => setActiveModal('remove_ads')}
          onOpenFreeChest={() => setActiveModal('free_chest')}
          coins={coins}
          diamonds={diamonds}
        />
      )}

      {/* In-Game HUD State */}
      {appState === 'playing' && (
        <>
          <HUD
            score={score}
            distance={distance}
            coins={sessionCoins}
            diamonds={diamonds}
            highScore={highScore}
            speed={speed}
            activePowerUps={activePowerUps}
            dangerWarningActive={dangerWarning}
            isSkating={isSkating}
            skateboardTimer={skateboardTimer}
            newHighScoreNotice={newHighScoreNotice}
            showControlButtons={gameIconButtons}
            onPause={handlePauseGame}
            onSwipeLeft={() => gameEngineRef.current?.swipeLeft()}
            onSwipeRight={() => gameEngineRef.current?.swipeRight()}
            onSwipeUp={() => gameEngineRef.current?.swipeUp()}
            onSwipeDown={() => gameEngineRef.current?.swipeDown()}
            onToggleSkateboard={() => gameEngineRef.current?.toggleSkateboard()}
          />

          {/* Revived Visual Banner Effect ("💎 -1 REVIVED! KEEP RUNNING!") */}
          {revivedNotice && (
            <div className="absolute top-20 sm:top-24 left-1/2 -translate-x-1/2 z-40 pointer-events-none animate-bounce">
              <div className="flex flex-col items-center px-6 py-2.5 sm:px-8 sm:py-3 bg-gradient-to-r from-cyan-600 via-sky-500 to-cyan-600 border-2 border-cyan-100 rounded-2xl shadow-[0_0_40px_rgba(6,182,212,0.95)] backdrop-blur text-center ring-4 ring-cyan-400/60">
                <div className="text-xs sm:text-sm font-black tracking-widest text-cyan-100 uppercase font-display">
                  💎 -1 DIAMOND
                </div>
                <div className="text-2xl sm:text-3xl font-black text-white font-display tracking-wider drop-shadow -mt-0.5">
                  REVIVED! KEEP RUNNING!
                </div>
                <div className="text-[11px] sm:text-xs font-bold text-cyan-200 mt-0.5 flex items-center gap-1">
                  🛡️ 3s Invincibility Shield Active
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Pause Modal */}
      {appState === 'paused' && (
        <PauseModal
          onResume={handleResumeGame}
          onRestart={handleRestartGame}
          onHome={handleReturnHome}
        />
      )}

      {/* Revive Modal (Offline 1-Diamond Revive System, max 3 per run) */}
      {appState === 'revive' && (
        <ReviveModal
          score={score}
          distance={distance}
          diamonds={diamonds}
          reviveCount={reviveCount}
          onRevive={handleReviveRun}
          onDecline={handleDeclineRevive}
        />
      )}

      {/* Game Over Modal */}
      {appState === 'game_over' && gameOverResult && (
        <GameOverModal
          finalScore={gameOverResult.finalScore}
          distance={gameOverResult.distance}
          coinsEarned={gameOverResult.coinsEarned}
          isNewHigh={gameOverResult.isNewHigh}
          highScore={highScore}
          onRestart={handleRestartGame}
          onHome={handleReturnHome}
        />
      )}

      {/* Modals triggered from Menu or HUD */}
      {activeModal === 'shop' && (
        <ShopModal
          onClose={() => {
            setActiveModal('none');
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
          coins={coins}
          onCoinsChange={(newCoins) => setCoins(newCoins)}
          onCharacterSelected={handleCharacterSelected}
          onSkateboardEquipped={handleSkateboardEquipped}
          initialTab={shopTab}
          isPortrait={isPortrait}
          onHome={handleReturnHome}
          onOpenSettings={() => setActiveModal('settings')}
          onOpenLeaderboard={() => setActiveModal('leaderboard')}
          onOpenDailyReward={() => setActiveModal('daily_reward')}
          onOpenAbout={() => setActiveModal('about')}
        />
      )}

      {activeModal === 'daily_reward' && (
        <DailyRewardModal
          onClose={() => {
            setActiveModal('none');
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
          onCoinsChange={(newCoins) => setCoins(newCoins)}
        />
      )}

      {activeModal === 'missions' && (
        <MissionsModal
          onClose={() => {
            setActiveModal('none');
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
          onClaimReward={() => {
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
        />
      )}

      {activeModal === 'spin' && (
        <SpinModal
          onClose={() => {
            setActiveModal('none');
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
          onRewardClaimed={() => {
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
        />
      )}

      {activeModal === 'free_coins' && (
        <FreeCoinsModal
          onClose={() => {
            setActiveModal('none');
            setCoins(saveManager.getCoins());
          }}
          onRewardClaimed={() => {
            setCoins(saveManager.getCoins());
          }}
        />
      )}

      {activeModal === 'remove_ads' && (
        <RemoveAdsModal onClose={() => setActiveModal('none')} />
      )}

      {activeModal === 'free_chest' && (
        <FreeChestModal
          onClose={() => {
            setActiveModal('none');
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
          onRewardClaimed={() => {
            setCoins(saveManager.getCoins());
            setDiamonds(saveManager.getDiamonds());
          }}
        />
      )}

      {activeModal === 'leaderboard' && (
        <LeaderboardModal onClose={() => setActiveModal('none')} />
      )}

      {activeModal === 'settings' && (
        <SettingsModal
          onClose={() => setActiveModal('none')}
          onOpenAndroidApp={() => setActiveModal('android_app')}
          onOpenAbout={() => setActiveModal('about')}
          gameIconButtons={gameIconButtons}
          onToggleGameIconButtons={(enabled) => setGameIconButtons(enabled)}
        />
      )}

      {activeModal === 'help' && (
        <HelpModal onClose={() => setActiveModal('none')} />
      )}

      {activeModal === 'about' && (
        <AboutModal onClose={() => setActiveModal('none')} />
      )}

      {activeModal === 'android_app' && (
        <AndroidAppModal onClose={() => setActiveModal('none')} />
      )}
    </main>
  );
}
