import React, { useEffect, useMemo, useState } from 'react';
import {
  AttendanceLog,
  Fighter,
  FightNotice,
  INITIAL_ATTENDANCE,
  INITIAL_CLASSES,
  INITIAL_FIGHTERS,
  INITIAL_INVOICES,
  INITIAL_NOTICES,
  InvoiceRecord,
  MatClass,
} from './data/dcaData';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { APKBuilderModal } from './components/APKBuilderModal';
import { MobileAPKApp } from './components/MobileAPKApp';

type NavTab =
  | 'dashboard'
  | 'members'
  | 'memberships'
  | 'payments-and-invoices'
  | 'schedule-and-classes'
  | 'broadcast-and-notifications'
  | 'announcements'
  | 'analytics-and-reports'
  | 'system-settings';

const NAV_ITEMS: { id: NavTab; label: string; shortLabel: string; icon: string }[] = [
  { id: 'dashboard', label: 'Dashboard', shortLabel: 'Dashboard', icon: 'sports_mma' },
  { id: 'members', label: 'Members & Batches', shortLabel: 'Members', icon: 'groups' },
  { id: 'memberships', label: 'Memberships & Passes', shortLabel: 'Passes', icon: 'badge' },
  { id: 'payments-and-invoices', label: 'Billing & Records', shortLabel: 'Billing', icon: 'receipt_long' },
  { id: 'schedule-and-classes', label: 'Class & Training Schedule', shortLabel: 'Schedule', icon: 'fitness_center' },
  { id: 'broadcast-and-notifications', label: 'Announcements & SMS', shortLabel: 'SMS', icon: 'campaign' },
  { id: 'announcements', label: 'Events & Notices', shortLabel: 'Events', icon: 'feed' },
  { id: 'analytics-and-reports', label: 'Member Reports & Analytics', shortLabel: 'Reports', icon: 'insights' },
  { id: 'system-settings', label: 'Facility Settings', shortLabel: 'Settings', icon: 'settings' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [rosterFilter, setRosterFilter] = useState<'all' | 'active' | 'expiring' | 'lapsed'>('all');
  const [dateRangeMode, setDateRangeMode] = useState<'30d' | 'ytd'>('30d');
  const [isAPKModalOpen, setIsAPKModalOpen] = useState(false);
  const [isMobilePreview, setIsMobilePreview] = useState(false);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Persisted State for Offline PWA Operation
  const [fighters, setFighters] = useState<Fighter[]>(() => {
    try {
      const saved = localStorage.getItem('dca_fighters_v1');
      return saved ? JSON.parse(saved) : INITIAL_FIGHTERS;
    } catch {
      return INITIAL_FIGHTERS;
    }
  });

  const [classes, setClasses] = useState<MatClass[]>(() => {
    try {
      const saved = localStorage.getItem('dca_classes_v1');
      return saved ? JSON.parse(saved) : INITIAL_CLASSES;
    } catch {
      return INITIAL_CLASSES;
    }
  });

  const [attendanceLogs, setAttendanceLogs] = useState<AttendanceLog[]>(() => {
    try {
      const saved = localStorage.getItem('dca_attendance_v1');
      return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
    } catch {
      return INITIAL_ATTENDANCE;
    }
  });

  const [invoices, setInvoices] = useState<InvoiceRecord[]>(() => {
    try {
      const saved = localStorage.getItem('dca_invoices_v1');
      return saved ? JSON.parse(saved) : INITIAL_INVOICES;
    } catch {
      return INITIAL_INVOICES;
    }
  });

  const [notices, setNotices] = useState<FightNotice[]>(() => {
    try {
      const saved = localStorage.getItem('dca_notices_v1');
      return saved ? JSON.parse(saved) : INITIAL_NOTICES;
    } catch {
      return INITIAL_NOTICES;
    }
  });

  // Broadcast composer state
  const [broadcastAudience, setBroadcastAudience] = useState('Expiring Camp Passes (≤ 30 Days)');
  const [broadcastChannel, setBroadcastChannel] = useState<'WhatsApp + SMS' | 'Android Push + SMS'>('WhatsApp + SMS');
  const [broadcastMessage, setBroadcastMessage] = useState(
    'DELHI COMBAT ACADEMY HQ: Your current Fight Camp Pass expires within 7 days. Renew at the Rohini Sector 14 front desk or via the DCA Ops Android App to maintain sparring & cage clearance.'
  );

  // Gate & Turnstile Config State
  const [turnstilesArmed, setTurnstilesArmed] = useState(true);
  const [biometricStrictMode, setBiometricStrictMode] = useState(true);
  const [safetyCapLimit, setSafetyCapLimit] = useState(105);
  const [dailyPin, setDailyPin] = useState('7419');

  const handleRegenerateDailyPin = () => {
    const nextPin = Math.floor(1000 + Math.random() * 9000).toString();
    setDailyPin(nextPin);
    showToast(`Emergency Rotation: Today's Daily PIN updated to #${nextPin}`);
    return nextPin;
  };

  // New Fighter Form State
  const [newFighterName, setNewFighterName] = useState('');
  const [newFighterDiscipline, setNewFighterDiscipline] = useState('Pro MMA Fight Camp');
  const [newFighterWeight, setNewFighterWeight] = useState('Welterweight (77 kg)');
  const [newFighterPhone, setNewFighterPhone] = useState('+91 98110 ');
  const [newFighterTier, setNewFighterTier] = useState('Pro Octagon Pass');

  useEffect(() => {
    try {
      localStorage.setItem('dca_fighters_v1', JSON.stringify(fighters));
    } catch {
      // ignore storage quota errors
    }
  }, [fighters]);

  useEffect(() => {
    try {
      localStorage.setItem('dca_classes_v1', JSON.stringify(classes));
    } catch {
      // ignore
    }
  }, [classes]);

  useEffect(() => {
    try {
      localStorage.setItem('dca_attendance_v1', JSON.stringify(attendanceLogs));
    } catch {
      // ignore
    }
  }, [attendanceLogs]);

  useEffect(() => {
    try {
      localStorage.setItem('dca_invoices_v1', JSON.stringify(invoices));
    } catch {
      // ignore
    }
  }, [invoices]);

  useEffect(() => {
    try {
      localStorage.setItem('dca_notices_v1', JSON.stringify(notices));
    } catch {
      // ignore
    }
  }, [notices]);

  // Keyboard shortcut Cmd/Ctrl + K to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const input = document.getElementById('dca-global-search') as HTMLInputElement | null;
        input?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // Filtered fighters based on search & status filter
  const filteredFighters = useMemo(() => {
    return fighters.filter((f) => {
      const matchesQuery =
        !searchQuery.trim() ||
        f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.tagId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.weightClass.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.discipline.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.rfid.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesQuery) return false;
      if (rosterFilter === 'active') return f.status === 'Active';
      if (rosterFilter === 'expiring')
        return f.status === 'Critical' || f.status === 'Overdue Soon' || f.status === 'Expiring';
      if (rosterFilter === 'lapsed') return f.status === 'Lapsed';
      return true;
    });
  }, [fighters, searchQuery, rosterFilter]);

  const handleMatCheckIn = (fighter: Fighter) => {
    const newLog: AttendanceLog = {
      id: `a-${Date.now()}`,
      fighterName: fighter.name,
      tagId: fighter.tagId,
      timeAgo: 'Just now',
      method: fighter.biometricVerified ? 'Biometrics' : 'Security PIN',
      gateNode: fighter.biometricVerified ? 'Face ID • Mat Gate 1' : 'Dojang West Keypad #2',
      rosterNote: `Verified · ${fighter.weightClass.split(' ')[0]} Roster`,
      icon: fighter.biometricVerified ? 'face' : 'pin',
    };
    setAttendanceLogs((prev) => [newLog, ...prev.slice(0, 11)]);
    setFighters((prev) =>
      prev.map((item) =>
        item.id === fighter.id ? { ...item, lastCheckIn: 'Just now • Mat Gate 1' } : item
      )
    );
    showToast(`Mat Check-In verified for ${fighter.name} (${fighter.tagId})`);
  };

  const handleRenewPass = (fighter: Fighter) => {
    setFighters((prev) =>
      prev.map((item) =>
        item.id === fighter.id
          ? {
              ...item,
              status: 'Active',
              daysRemaining: 90,
              expiryDate: 'Jan 10',
              feeBalance: 0,
              medicalClearance: 'Cleared',
            }
          : item
      )
    );
    const newInv: InvoiceRecord = {
      id: `inv-${Date.now()}`,
      invoiceNo: `DCA-INV-${Math.floor(2600 + Math.random() * 900)}`,
      fighterName: fighter.name,
      tagId: fighter.tagId,
      planName: `${fighter.campTier} (90-Day Renewal)`,
      amount: fighter.feeBalance > 0 ? fighter.feeBalance : 14500,
      date: 'Oct 11, 2025',
      method: 'UPI / QR',
      status: 'Paid',
    };
    setInvoices((prev) => [newInv, ...prev]);
    showToast(`Renewed 90-day camp pass for ${fighter.name}`);
  };

  const handleRegisterFighter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFighterName.trim()) return;
    const parts = newFighterName.trim().split(' ');
    const initials =
      parts.length > 1
        ? `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase()
        : newFighterName.slice(0, 2).toUpperCase();
    const randomTag = `DCA-${Math.floor(1000 + Math.random() * 8999)}`;
    const created: Fighter = {
      id: `f-${Date.now()}`,
      tagId: randomTag,
      name: newFighterName.trim(),
      initials,
      discipline: newFighterDiscipline,
      weightClass: newFighterWeight,
      campTier: newFighterTier,
      expiryDate: 'Jan 11',
      daysRemaining: 90,
      status: 'Active',
      phone: newFighterPhone,
      rfid: `RF-${Math.floor(1000 + Math.random() * 8999)}-X`,
      biometricVerified: true,
      medicalClearance: 'Cleared',
      boutRecord: '1-0-0 (Amateur)',
      lastCheckIn: 'Just now • Intake Desk',
      feeBalance: 0,
    };
    setFighters((prev) => [created, ...prev]);
    setNewFighterName('');
    setIsRegisterModalOpen(false);
    showToast(`Enrolled ${created.name} (${created.tagId}) onto active camp roster`);
  };

  const handleExportRosterCSV = () => {
    const headers = ['Tag ID', 'Fighter Name', 'Discipline', 'Weight Class', 'Camp Tier', 'Status', 'Expiry Date', 'Days Left', 'Fee Balance (INR)'];
    const rows = fighters.map((f) => [
      f.tagId,
      `"${f.name}"`,
      `"${f.discipline}"`,
      `"${f.weightClass}"`,
      `"${f.campTier}"`,
      f.status,
      f.expiryDate,
      f.daysRemaining,
      f.feeBalance,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'delhi-combat-academy-roster.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Exported Delhi Combat Academy fighter roster CSV');
  };

  const totalOnMats = 68 + (attendanceLogs.length - INITIAL_ATTENDANCE.length);
  const matCapacityPct = Math.min(100, Math.round((totalOnMats / 120) * 100));

  if (isMobilePreview) {
    return (
      <>
        <MobileAPKApp
          dailyPin={dailyPin}
          onRegeneratePin={handleRegenerateDailyPin}
          classes={classes}
          fighters={fighters}
          onCheckInSuccess={(method, memberName) => {
            const target = fighters.find((f) => f.name === memberName) || fighters[0];
            if (target) {
              const newLog: AttendanceLog = {
                id: `a-${Date.now()}`,
                fighterName: target.name,
                tagId: target.tagId,
                timeAgo: 'Just now',
                method: method.includes('PIN') ? 'Security PIN' : 'Biometrics',
                gateNode: method.includes('PIN')
                  ? `Daily PIN (#${dailyPin}) • Gate #2`
                  : 'Face ID • Mat Gate 1',
                rosterNote: `Verified • ${target.weightClass}`,
                icon: method.includes('PIN') ? 'pin' : 'face',
              };
              setAttendanceLogs((prev) => [newLog, ...prev.slice(0, 11)]);
            }
          }}
          onOpenAPKStudio={() => setIsAPKModalOpen(true)}
          onSwitchToDesktopPortal={() => setIsMobilePreview(false)}
        />
        <APKBuilderModal
          isOpen={isAPKModalOpen}
          onClose={() => setIsAPKModalOpen(false)}
          isMobilePreview={isMobilePreview}
          onToggleMobilePreview={() => setIsMobilePreview(!isMobilePreview)}
        />
        <OfflineIndicator />
      </>
    );
  }

  return (
    <div
      className={`min-h-screen bg-[#0b0d12] text-[#e2e2e9] transition-all ${
        isMobilePreview ? 'py-6 px-4 flex flex-col items-center justify-start bg-[#06070a]' : ''
      }`}
    >
      {/* Top Android Mobile Simulator Bar when in Mobile APK Preview mode */}
      {isMobilePreview && (
        <div className="w-full max-w-[420px] mb-3 flex items-center justify-between px-4 py-2.5 rounded-xl bg-[#16181f] border border-[#ff2a2a]/40">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff2a2a] text-[18px]">smartphone</span>
            <span className="font-headline text-xs uppercase font-bold tracking-wider text-white">
              Android APK Viewport (412 × 915px)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAPKModalOpen(true)}
              className="px-2.5 py-1 rounded bg-[#ff2a2a] text-white font-headline text-[11px] uppercase font-bold cursor-pointer"
            >
              Export APK
            </button>
            <button
              onClick={() => setIsMobilePreview(false)}
              className="px-2.5 py-1 rounded bg-[#262932] text-[#c9bfc0] hover:text-white font-headline text-[11px] uppercase font-semibold cursor-pointer"
            >
              Desktop HQ
            </button>
          </div>
        </div>
      )}

      {/* Main Responsive Shell Wrapper */}
      <div
        className={
          isMobilePreview
            ? 'w-full max-w-[420px] h-[860px] rounded-[36px] border-[6px] border-[#262932] bg-[#0b0d12] shadow-[0_24px_80px_rgba(0,0,0,0.85)] overflow-y-auto relative flex flex-col justify-between'
            : 'w-full min-h-screen'
        }
      >
        {/* Desktop Sidebar Navigation (Hidden on mobile or inside Mobile Simulator) */}
        {!isMobilePreview && (
          <aside className="hidden lg:flex fixed left-0 top-0 h-full w-64 bg-[#0c0e13] z-40 flex-col justify-between border-r border-[#4a3836]/35">
            <div className="flex flex-col">
              {/* Brand Zone */}
              <div className="h-16 px-5 flex items-center justify-between bg-[#0c0e13] border-b border-[#4a3836]/25">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="flex items-center gap-3 text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-lg bg-[#ff2a2a]/15 border border-[#ff2a2a]/50 flex items-center justify-center text-[#ff2a2a] font-headline font-bold text-base shrink-0">
                    DCA
                  </div>
                  <span className="font-headline text-[17px] uppercase tracking-wider text-white font-bold">
                    DELHI COMBAT
                  </span>
                </button>
              </div>

              {/* Navigation Items */}
              <div className="px-3 py-4">
                <div className="px-3 pb-2 text-[#8e8281] text-[11px] font-medium">
                  HQ Operations
                </div>
                <nav className="flex flex-col gap-1">
                  {NAV_ITEMS.map((item) => {
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id)}
                        className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg font-headline text-sm transition-all text-left cursor-pointer whitespace-nowrap ${
                          isActive
                            ? 'bg-[#ff2a2a] text-white font-bold shadow-[0_0_20px_-4px_rgba(255,42,42,0.55)]'
                            : 'text-[#c9bfc0] hover:bg-[#262932] hover:text-white'
                        }`}
                      >
                        <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                        <span className="truncate">{item.label}</span>
                      </button>
                    );
                  })}
                </nav>
              </div>
            </div>

            {/* Bottom APK Builder Trigger & Facility Gate Control */}
            <div className="p-3 flex flex-col gap-2.5">
              <button
                onClick={() => setIsAPKModalOpen(true)}
                className="w-full p-3 rounded-lg bg-[#16181f] hover:bg-[#1e2028] border border-[#ff2a2a]/40 flex items-center justify-between text-left transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[#ff2a2a] text-[20px]">android</span>
                  <div className="flex flex-col">
                    <span className="font-headline text-xs uppercase font-bold text-white tracking-wider">
                      Android APK Studio
                    </span>
                    <span className="text-[11px] text-[#8e8281]">Build TWA / Install App</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[#8e8281] text-[16px]">chevron_right</span>
              </button>

              <div className="p-3.5 rounded-lg bg-[#16181f] border border-[#4a3836]/35 flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#8e8281]">Facility Gate / Turnstiles</span>
                  <span
                    className={`h-2 w-2 rounded-full ${
                      turnstilesArmed ? 'bg-[#ff2a2a] animate-pulse' : 'bg-[#8e8281]'
                    }`}
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#e2e2e9]">Main Dojang &amp; Cage</span>
                  <button
                    onClick={() => {
                      setTurnstilesArmed(!turnstilesArmed);
                      showToast(
                        !turnstilesArmed
                          ? 'Main Dojang & Cage Turnstiles Armed'
                          : 'Turnstiles switched to Manual Standby'
                      );
                    }}
                    className="text-[#ff2a2a] font-headline font-bold tracking-wider uppercase cursor-pointer hover:underline"
                  >
                    {turnstilesArmed ? 'ARMED & LIVE' : 'STANDBY'}
                  </button>
                </div>
              </div>
            </div>
          </aside>
        )}

        {/* Main Content Viewport */}
        <div className={isMobilePreview ? 'w-full pb-20' : 'lg:pl-64'}>
          {/* Top Navigation Bar */}
          <header
            className={`${
              isMobilePreview
                ? 'sticky top-0 z-30 h-14 px-4'
                : 'sticky lg:fixed top-0 lg:left-64 right-0 h-16 px-4 sm:px-6 z-30'
            } bg-[#0c0e13]/95 backdrop-blur-xl flex items-center justify-between border-b border-[#4a3836]/30 gap-3`}
          >
            {/* Left: Search Input */}
            <div className="flex items-center gap-3 flex-1 max-w-xl">
              {isMobilePreview && (
                <div className="w-8 h-8 rounded-lg bg-[#ff2a2a] flex items-center justify-center font-headline font-bold text-xs text-white shrink-0">
                  DCA
                </div>
              )}
              <div className="relative w-full flex items-center">
                <span className="material-symbols-outlined absolute left-3 text-[#8e8281] text-[18px]">
                  search
                </span>
                <input
                  id="dca-global-search"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    if (activeTab !== 'dashboard' && activeTab !== 'members') {
                      setActiveTab('members');
                    }
                  }}
                  className="w-full h-9 sm:h-10 pl-9 pr-12 rounded-lg bg-[#16181f] border border-[#4a3836]/40 text-[#e2e2e9] text-xs sm:text-sm placeholder:text-[#8e8281] focus:outline-none focus:border-[#ff2a2a] transition-all"
                  placeholder={
                    isMobilePreview
                      ? 'Search members...'
                      : 'Search members ⌘K'
                  }
                  type="text"
                />
                {!isMobilePreview && (
                  <div className="absolute right-2.5 flex items-center pointer-events-none">
                    <kbd className="px-1.5 py-0.5 rounded bg-[#262932] border border-[#4a3836]/40 font-mono-num text-[10px] text-[#c9bfc0]">
                      ⌘K
                    </kbd>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Actions & APK Install */}
            <div className="flex items-center gap-2.5 shrink-0">
              {!isMobilePreview && (
                <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#16181f] border border-[#4a3836]/35 text-xs">
                  <span className="h-2 w-2 rounded-full bg-[#ff2a2a] animate-ping" />
                  <span className="text-white font-bold font-mono-num">{totalOnMats} / 120</span>
                  <span className="text-[#8e8281]">Members in Academy</span>
                  <span className="text-[#8e8281]">·</span>
                  <span className="text-[#ff2a2a] font-bold font-mono-num">{matCapacityPct}% Capacity</span>
                </div>
              )}

              {/* In-App PWA / APK Install Button */}
              <PWAInstallButton
                compact={isMobilePreview}
                onOpenAPKStudio={() => setIsAPKModalOpen(true)}
              />

              {!isMobilePreview && (
                <button
                  onClick={() => setIsMobilePreview(true)}
                  className="hidden md:flex items-center gap-1.5 h-10 px-3 rounded-lg bg-[#16181f] hover:bg-[#262932] border border-[#4a3836]/40 text-[#c9bfc0] hover:text-white font-headline text-xs uppercase font-semibold tracking-wider transition-colors cursor-pointer whitespace-nowrap"
                  title="Preview Android Mobile App Screen"
                >
                  <span className="material-symbols-outlined text-[18px] text-[#ff6b4a]">
                    smartphone
                  </span>
                  <span>Mobile View</span>
                </button>
              )}

              <button
                onClick={() => setIsRegisterModalOpen(true)}
                className={`flex items-center gap-1.5 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline uppercase font-bold tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                  isMobilePreview ? 'h-9 px-3 text-xs' : 'h-10 px-4 text-sm'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">person_add</span>
                <span>{isMobilePreview ? '+ Member' : '+ Register Member'}</span>
              </button>

              {!isMobilePreview && (
                <div className="hidden sm:flex items-center gap-3 pl-2 border-l border-[#4a3836]/35">
                  <div className="flex flex-col text-right">
                    <span className="font-headline text-sm text-white leading-tight font-bold tracking-wide">
                      Coach Vikram Rathore
                    </span>
                    <span className="text-[11px] text-[#ff2a2a] font-medium">
                      Head Coach &amp; Manager
                    </span>
                  </div>
                  <div className="w-9 h-9 rounded-full bg-[#262932] border border-[#ff2a2a]/50 flex items-center justify-center font-headline font-bold text-xs text-white">
                    VR
                  </div>
                </div>
              )}
            </div>
          </header>

          {/* Main Workspace Container */}
          <main
            className={`${
              isMobilePreview ? 'px-3.5 pt-3 pb-6' : 'w-full pt-4 lg:pt-20 px-4 sm:px-6 pb-16'
            }`}
          >
            {/* Top Command Banner */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-3 flex-wrap">
                  <h1
                    className={`font-headline text-white tracking-tight uppercase font-bold ${
                      isMobilePreview ? 'text-xl' : 'text-2xl sm:text-3xl lg:text-4xl'
                    }`}
                  >
                    Delhi Combat Academy · Dashboard
                  </h1>
                  <span className="text-xs text-[#ff2a2a] font-medium">
                    · Live Facility Attendance Online
                  </span>
                </div>
                <p className="text-xs text-[#8e8281]">
                  Rohini Sector 14 HQ · MMA Cage, Boxing Ring, Muay Thai Deck · Live Synced 8s ago
                </p>
              </div>

              {/* Header Action Controls */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setDateRangeMode(dateRangeMode === '30d' ? 'ytd' : '30d')}
                  className="flex items-center gap-2 h-9 sm:h-10 px-3.5 rounded-lg bg-[#16181f] border border-[#4a3836]/40 text-[#e2e2e9] hover:bg-[#262932] transition-colors font-headline text-xs uppercase font-semibold cursor-pointer whitespace-nowrap"
                >
                  <span className="material-symbols-outlined text-[17px] text-[#ff2a2a]">
                    calendar_today
                  </span>
                  <span>
                    {dateRangeMode === '30d'
                      ? 'October 2025 · Last 30 Days'
                      : 'This Quarter (Q4 2025) · Year to Date'}
                  </span>
                </button>

                <a
                  href="/Delhi-Combat-Academy.apk"
                  download="Delhi-Combat-Academy.apk"
                  className="flex items-center gap-1.5 h-9 sm:h-10 px-4 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white transition-all font-headline text-xs uppercase font-bold tracking-wider cursor-pointer whitespace-nowrap shadow-[0_0_20px_-4px_rgba(255,42,42,0.65)]"
                >
                  <span className="material-symbols-outlined text-[18px]">android</span>
                  <span>Download Signed .APK</span>
                </a>

                <a
                  href="/Delhi-Combat-Academy-Signed-APK-Bundle.zip"
                  download="Delhi-Combat-Academy-Signed-APK-Bundle.zip"
                  className="flex items-center gap-1.5 h-9 sm:h-10 px-3.5 rounded-lg bg-[#262932] border border-[#ff2a2a]/50 hover:bg-[#31343f] text-white transition-all font-headline text-xs uppercase font-bold cursor-pointer whitespace-nowrap"
                >
                  <span className="material-symbols-outlined text-[17px] text-[#ff2a2a]">
                    folder_zip
                  </span>
                  <span>Play Store Bundle (.ZIP)</span>
                </a>

                <button
                  onClick={() => setIsRegisterModalOpen(true)}
                  className="flex items-center gap-1.5 h-9 sm:h-10 px-4 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold tracking-wider transition-all cursor-pointer whitespace-nowrap"
                >
                  <span className="material-symbols-outlined text-[18px]">sports_martial_arts</span>
                  <span>+ New Member</span>
                </button>
              </div>
            </div>

            {/* Horizontal Section Switcher for Tablet/Desktop or Quick Sub-view */}
            {!isMobilePreview && (
              <div className="flex lg:hidden items-center gap-1.5 overflow-x-auto pb-4">
                {NAV_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`px-3 py-2 rounded-lg font-headline text-xs uppercase whitespace-nowrap cursor-pointer ${
                      activeTab === item.id
                        ? 'bg-[#ff2a2a] text-white font-bold'
                        : 'bg-[#16181f] text-[#c9bfc0]'
                    }`}
                  >
                    {item.shortLabel}
                  </button>
                ))}
              </div>
            )}

            {/* VIEW 1: COMMAND DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="flex flex-col gap-6">
                {/* 6 KPI Metric Cards */}
                <div
                  className={`grid gap-3.5 ${
                    isMobilePreview
                      ? 'grid-cols-2'
                      : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6'
                  }`}
                >
                  {/* Card 1 */}
                  <div className="flex flex-col justify-between p-4 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#8e8281] font-medium">Total Members</span>
                      <span className="material-symbols-outlined text-[#ff2a2a] text-[19px]">
                        sports_mma
                      </span>
                    </div>
                    <div className="my-2 font-headline text-3xl sm:text-4xl font-bold text-white tabular-nums">
                      {(1421 + fighters.length).toLocaleString()}
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#8e8281]">
                      <span className="text-[#ff2a2a] font-mono-num font-semibold">+14.2%</span>
                      <span>New registrations</span>
                    </div>
                  </div>

                  {/* Card 2 */}
                  <div className="flex flex-col justify-between p-4 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#8e8281] font-medium">Active Members</span>
                      <span className="material-symbols-outlined text-[#ff2a2a] text-[19px]">
                        verified_user
                      </span>
                    </div>
                    <div className="my-2 font-headline text-3xl sm:text-4xl font-bold text-white tabular-nums">
                      1,284
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#8e8281]">
                      <span className="text-[#ff2a2a] font-mono-num font-semibold">90% Active</span>
                      <span>Biometric Sync</span>
                    </div>
                  </div>

                  {/* Card 3 */}
                  <div className="flex flex-col justify-between p-4 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#ffb77f] font-medium">Expiring (30 Days)</span>
                      <span className="material-symbols-outlined text-[#ff6b4a] text-[19px]">
                        timelapse
                      </span>
                    </div>
                    <div className="my-2 font-headline text-3xl sm:text-4xl font-bold text-[#ffb77f] tabular-nums">
                      64
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#ff6b4a]">Membership</span>
                      <button
                        onClick={() => setActiveTab('broadcast-and-notifications')}
                        className="font-headline text-xs text-[#ff2a2a] hover:underline uppercase font-bold cursor-pointer"
                      >
                        Bulk SMS
                      </button>
                    </div>
                  </div>

                  {/* Card 4 */}
                  <div className="flex flex-col justify-between p-4 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#ff5449] font-medium">Expired Memberships</span>
                      <span className="material-symbols-outlined text-[#ff5449] text-[19px]">
                        dangerous
                      </span>
                    </div>
                    <div className="my-2 font-headline text-3xl sm:text-4xl font-bold text-[#ff5449] tabular-nums">
                      48
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#ff5449]">
                      <span>Renewal Required</span>
                      <span className="font-mono-num">Action</span>
                    </div>
                  </div>

                  {/* Card 5 */}
                  <div className="flex flex-col justify-between p-4 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#8e8281] font-medium">
                        Today&apos;s Attendance
                      </span>
                      <span className="material-symbols-outlined text-[#ff2a2a] text-[19px]">
                        how_to_reg
                      </span>
                    </div>
                    <div className="my-2 font-headline text-3xl sm:text-4xl font-bold text-white tabular-nums">
                      {138 + attendanceLogs.length}
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#8e8281]">
                      <span className="text-[#ff2a2a] font-mono-num font-semibold">
                        92% Biometric
                      </span>
                      <span>8% Security PIN</span>
                    </div>
                  </div>

                  {/* Card 6 */}
                  <div className="flex flex-col justify-between p-4 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#ff2a2a] font-medium">Entrance Gates</span>
                      <span className="material-symbols-outlined text-[#ff2a2a] text-[19px]">
                        sensors
                      </span>
                    </div>
                    <div className="my-2 font-headline text-2xl sm:text-3xl text-[#ff2a2a] uppercase font-bold tracking-wide">
                      {turnstilesArmed ? 'SYNCHRONIZED' : 'MANUAL'}
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#8e8281]">
                      <span className="text-[#ff2a2a] font-mono-num font-semibold">
                        4/4 Gates Live
                      </span>
                      <span className="font-mono-num">0.4s Verification</span>
                    </div>
                  </div>
                </div>

                {/* Visual Analytics & Charts Section */}
                <div
                  className={`grid grid-cols-1 ${
                    isMobilePreview ? 'gap-4' : 'xl:grid-cols-12 gap-6'
                  }`}
                >
                  {/* Revenue & Membership Growth SVG Chart */}
                  <div
                    className={`${
                      isMobilePreview ? '' : 'xl:col-span-8'
                    } flex flex-col p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#4a3836]/25">
                      <div className="flex flex-col">
                        <h2 className="font-headline text-xl text-white tracking-wide uppercase font-bold">
                          Academy Revenue &amp; Attendance Trends
                        </h2>
                        <span className="text-xs text-[#8e8281]">
                          YTD Academy Revenue:{' '}
                          <strong className="text-white font-mono-num">
                            {dateRangeMode === '30d' ? '₹6.84 Crore' : '₹8.12 Crore'}
                          </strong>{' '}
                          · Avg Member LTV:{' '}
                          <strong className="text-white font-mono-num">₹68,400</strong>
                        </span>
                      </div>
                      <div className="flex items-center gap-4 flex-wrap text-xs text-[#c9bfc0]">
                        <div className="flex items-center gap-1.5">
                          <span className="w-3 h-3 rounded-sm bg-[#ff2a2a]" />
                          <span>Regular Memberships</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-3 h-3 rounded-sm bg-[#31343f]" />
                          <span>Personal Training &amp; Workshops</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-3 h-1 bg-[#ff6b4a] rounded-full" />
                          <span className="text-[#ff6b4a] font-semibold">Daily Check-Ins</span>
                        </div>
                      </div>
                    </div>

                    {/* Responsive SVG Chart */}
                    <div className="w-full h-56 sm:h-64 mt-3 relative">
                      <svg
                        className="w-full h-full overflow-visible"
                        preserveAspectRatio="none"
                        viewBox="0 0 700 240"
                      >
                        <defs>
                          <linearGradient id="dcaRedGrad" x1="0" x2="0" y1="0" y2="1">
                            <stop offset="0%" stopColor="#ff2a2a" stopOpacity="0.95" />
                            <stop offset="100%" stopColor="#b31212" stopOpacity="0.25" />
                          </linearGradient>
                          <linearGradient id="ptBarGrad" x1="0" x2="0" y1="0" y2="1">
                            <stop offset="0%" stopColor="#4a4d55" stopOpacity="0.85" />
                            <stop offset="100%" stopColor="#1c2028" stopOpacity="0.4" />
                          </linearGradient>
                          <linearGradient id="lineGlow" x1="0" x2="1" y1="0" y2="0">
                            <stop offset="0%" stopColor="#ff6b4a" stopOpacity="0.9" />
                            <stop offset="100%" stopColor="#ff2a2a" stopOpacity="1" />
                          </linearGradient>
                        </defs>
                        <line stroke="#22252e" strokeDasharray="3,3" x1="0" x2="700" y1="20" y2="20" />
                        <line stroke="#22252e" strokeDasharray="3,3" x1="0" x2="700" y1="75" y2="75" />
                        <line stroke="#22252e" strokeDasharray="3,3" x1="0" x2="700" y1="130" y2="130" />
                        <line stroke="#22252e" strokeDasharray="3,3" x1="0" x2="700" y1="185" y2="185" />

                        <rect fill="url(#dcaRedGrad)" height="95" rx="3" width="28" x="40" y="105" />
                        <rect fill="url(#ptBarGrad)" height="55" rx="2" width="16" x="72" y="145" />

                        <rect fill="url(#dcaRedGrad)" height="105" rx="3" width="28" x="150" y="95" />
                        <rect fill="url(#ptBarGrad)" height="65" rx="2" width="16" x="182" y="135" />

                        <rect fill="url(#dcaRedGrad)" height="120" rx="3" width="28" x="260" y="80" />
                        <rect fill="url(#ptBarGrad)" height="75" rx="2" width="16" x="292" y="125" />

                        <rect fill="url(#dcaRedGrad)" height="130" rx="3" width="28" x="370" y="70" />
                        <rect fill="url(#ptBarGrad)" height="85" rx="2" width="16" x="402" y="115" />

                        <rect fill="url(#dcaRedGrad)" height="145" rx="3" width="28" x="480" y="55" />
                        <rect fill="url(#ptBarGrad)" height="95" rx="2" width="16" x="512" y="105" />

                        <rect fill="#ff2a2a" height="165" rx="3" width="28" x="590" y="35" />
                        <rect fill="#ff6b4a" height="110" opacity="0.75" rx="2" width="16" x="622" y="90" />

                        <path
                          d="M 54 125 Q 164 110, 274 95 T 494 65 T 604 42"
                          fill="none"
                          stroke="url(#lineGlow)"
                          strokeLinecap="round"
                          strokeWidth="3"
                        />
                        <circle cx="54" cy="125" fill="#111318" r="4" stroke="#ff6b4a" strokeWidth="2" />
                        <circle cx="164" cy="110" fill="#111318" r="4" stroke="#ff6b4a" strokeWidth="2" />
                        <circle cx="274" cy="95" fill="#111318" r="4" stroke="#ff6b4a" strokeWidth="2" />
                        <circle cx="384" cy="85" fill="#111318" r="4" stroke="#ff6b4a" strokeWidth="2" />
                        <circle cx="494" cy="65" fill="#111318" r="4" stroke="#ff6b4a" strokeWidth="2" />
                        <circle cx="604" cy="42" fill="#ff2a2a" r="5" stroke="#ffffff" strokeWidth="2" />
                        <line stroke="#33353a" strokeWidth="1.5" x1="0" x2="700" y1="200" y2="200" />
                      </svg>
                      <div className="flex justify-between px-4 pt-2 font-mono-num text-[11px] text-[#8e8281]">
                        <span>May &apos;25</span>
                        <span>Jun &apos;25</span>
                        <span>Jul &apos;25</span>
                        <span>Aug &apos;25</span>
                        <span>Sep &apos;25</span>
                        <span className="text-[#ff2a2a] font-bold">Oct &apos;25</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#4a3836]/25 flex items-center justify-between flex-wrap gap-2 text-[#c9bfc0] text-xs">
                      <span>
                        Projected fight camp close at{' '}
                        <strong className="text-white font-mono-num">₹91.4 Lakh</strong> with
                        national amateur tournament registrations.
                      </span>
                      <button
                        onClick={() => setActiveTab('payments-and-invoices')}
                        className="font-headline text-xs text-[#ff2a2a] hover:underline flex items-center gap-1 uppercase font-bold cursor-pointer"
                      >
                        <span>Detailed Financial Breakdown</span>
                        <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                      </button>
                    </div>
                  </div>

                  {/* Roster Status Distribution */}
                  <div
                    className={`${
                      isMobilePreview ? '' : 'xl:col-span-4'
                    } flex flex-col justify-between p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30`}
                  >
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center justify-between">
                        <h2 className="font-headline text-xl text-white tracking-wide uppercase font-bold">
                          Member Status Breakdown
                        </h2>
                        <span className="material-symbols-outlined text-[#ff2a2a] text-[19px]">
                          donut_large
                        </span>
                      </div>
                      <span className="text-xs text-[#8e8281]">
                        Active memberships across adult, teen &amp; youth batches
                      </span>
                    </div>

                    <div className="py-4 flex items-center justify-around gap-4">
                      <div className="relative w-32 h-32 sm:w-36 sm:h-36 flex items-center justify-center">
                        <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                          <circle cx="50" cy="50" fill="none" r="38" stroke="#1e2028" strokeWidth="12" />
                          <circle
                            cx="50"
                            cy="50"
                            fill="none"
                            r="38"
                            stroke="#ff2a2a"
                            strokeDasharray="238.7"
                            strokeDashoffset="52.5"
                            strokeLinecap="round"
                            strokeWidth="12"
                          />
                          <circle
                            cx="50"
                            cy="50"
                            fill="none"
                            r="38"
                            stroke="#ffb77f"
                            strokeDasharray="238.7"
                            strokeDashoffset="205"
                            strokeLinecap="round"
                            strokeWidth="12"
                          />
                        </svg>
                        <div className="absolute flex flex-col items-center justify-center text-center">
                          <span className="font-headline text-2xl font-bold text-white leading-none tabular-nums">
                            1.4k
                          </span>
                          <span className="text-[10px] text-[#8e8281] uppercase mt-1 font-bold">
                            Members
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2.5 text-xs">
                        <div>
                          <div className="text-[#ff2a2a] font-semibold">Active Members (78%)</div>
                          <div className="font-headline text-sm text-white font-bold tabular-nums">
                            1,114
                          </div>
                        </div>
                        <div>
                          <div className="text-[#ff6b4a] font-semibold">Expiring Soon (14%)</div>
                          <div className="font-headline text-sm text-white font-bold tabular-nums">
                            200
                          </div>
                        </div>
                        <div>
                          <div className="text-[#ff5449] font-semibold">Lapsed / On Hold (8%)</div>
                          <div className="font-headline text-sm text-white font-bold tabular-nums">
                            114
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-[#1e2028] border border-[#ff2a2a]/35 flex flex-col gap-3">
                      <div className="flex flex-col">
                        <span className="font-headline text-sm font-bold text-white uppercase tracking-wide">
                          14 Memberships Expire in ≤ 7 Days
                        </span>
                        <span className="text-xs text-[#8e8281] mt-0.5">
                          Send renewal reminders to ensure members don&apos;t miss upcoming training sessions.
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          showToast('Sent WhatsApp & SMS renewal reminders to 14 expiring members');
                        }}
                        className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[16px]">send</span>
                        <span>Send WhatsApp &amp; SMS Reminders</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Operations Center (Fighter Expiry Attention Queue & Live Schedule) */}
                <div
                  className={`grid grid-cols-1 ${
                    isMobilePreview ? 'gap-4' : 'xl:grid-cols-12 gap-6'
                  }`}
                >
                  {/* Left: Fighter Attention Queue */}
                  <div
                    className={`${
                      isMobilePreview ? '' : 'xl:col-span-7'
                    } flex flex-col p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30`}
                  >
                    <div className="flex items-center justify-between pb-4 border-b border-[#4a3836]/25">
                      <div className="flex flex-col">
                        <h2 className="font-headline text-lg text-white tracking-wide uppercase font-bold">
                          Upcoming Membership Expiries
                        </h2>
                        <span className="text-xs text-[#8e8281]">
                          Members needing membership renewals or pass updates
                        </span>
                      </div>
                      <button
                        onClick={() => setActiveTab('members')}
                        className="text-xs font-headline uppercase text-[#ff2a2a] hover:underline font-bold cursor-pointer"
                      >
                        Priority Deadlines →
                      </button>
                    </div>

                    <div className="flex flex-col divide-y divide-[#4a3836]/25 mt-2">
                      {fighters.slice(0, 4).map((fighter) => (
                        <div
                          key={fighter.id}
                          className="flex flex-col sm:flex-row sm:items-center justify-between py-3.5 gap-3"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-9 h-9 rounded-full bg-[#1e2028] border border-[#ff2a2a]/40 flex items-center justify-center font-headline text-sm text-[#ff2a2a] font-bold shrink-0">
                              {fighter.initials}
                            </div>
                            <div className="flex flex-col min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-headline text-sm text-white truncate font-bold uppercase">
                                  {fighter.name}
                                </span>
                                <span className="font-mono-num text-xs text-[#8e8281]">
                                  · {fighter.tagId}
                                </span>
                              </div>
                              <span className="text-xs text-[#8e8281] truncate">
                                {fighter.discipline} · {fighter.weightClass}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                            <div className="flex flex-col text-left sm:text-right font-mono-num">
                              <span className="text-xs text-white font-bold">
                                {fighter.expiryDate}
                              </span>
                              <span
                                className={`text-[11px] ${
                                  fighter.daysRemaining <= 3
                                    ? 'text-[#ff5449]'
                                    : fighter.daysRemaining <= 10
                                    ? 'text-[#ffb77f]'
                                    : 'text-[#8e8281]'
                                }`}
                              >
                                {fighter.daysRemaining}d left · {fighter.status}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleMatCheckIn(fighter)}
                                className="px-3 py-1.5 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold tracking-wide transition-colors cursor-pointer whitespace-nowrap"
                              >
                                Mat Check-In
                              </button>
                              {fighter.daysRemaining <= 10 && (
                                <button
                                  onClick={() => handleRenewPass(fighter)}
                                  className="px-3 py-1.5 rounded-lg bg-[#262932] hover:bg-[#31343f] text-white font-headline text-xs uppercase font-semibold transition-colors cursor-pointer whitespace-nowrap"
                                >
                                  Renew
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 pt-3 flex items-center justify-between border-t border-[#4a3836]/25 text-xs">
                      <button
                        onClick={() => {
                          setRosterFilter('expiring');
                          setActiveTab('members');
                        }}
                        className="font-headline text-xs text-[#ff2a2a] hover:underline flex items-center gap-1 uppercase font-bold cursor-pointer"
                      >
                        <span>View all 64 expiring memberships</span>
                        <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
                      </button>
                      <span className="text-[#8e8281] hidden sm:inline">
                        Automated membership reminders trigger daily at 09:00 IST
                      </span>
                    </div>
                  </div>

                  {/* Right: Today's Class Schedule */}
                  <div
                    className={`${
                      isMobilePreview ? '' : 'xl:col-span-5'
                    } flex flex-col p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30 justify-between`}
                  >
                    <div>
                      <div className="flex items-center justify-between pb-3 border-b border-[#4a3836]/25">
                        <div className="flex flex-col">
                          <h2 className="font-headline text-lg text-white tracking-wide uppercase font-bold">
                            Today&apos;s Class Schedule
                          </h2>
                          <span className="text-xs text-[#8e8281]">
                            Tuesday · Studio 1, Boxing Ring &amp; Mats
                          </span>
                        </div>
                        <button
                          onClick={() => setActiveTab('schedule-and-classes')}
                          className="text-xs font-headline uppercase text-[#ff2a2a] hover:underline font-bold cursor-pointer"
                        >
                          Manage
                        </button>
                      </div>

                      {/* Real-Time Facility Gauge */}
                      <div className="p-4 rounded-xl bg-[#1e2028] border border-[#4a3836]/30 my-3.5">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-headline text-sm text-white font-bold tabular-nums">
                              {totalOnMats} / 120
                            </span>
                            <span className="text-xs text-[#8e8281]">Members in Academy</span>
                          </div>
                          <span className="font-mono-num text-xs text-[#ff2a2a] font-bold">
                            {matCapacityPct}% Peak Load
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-[#262932] overflow-hidden flex">
                          <div
                            className="h-full bg-[#ff2a2a] transition-all duration-300"
                            style={{ width: `${matCapacityPct}%` }}
                          />
                        </div>
                        <div className="flex justify-between font-mono-num text-[10px] text-[#8e8281] mt-1.5">
                          <span>Open Mats (Warmups)</span>
                          <span>Safety Cap: {safetyCapLimit}</span>
                          <span>Max Capacity: 120</span>
                        </div>
                      </div>

                      {/* Class Timeline */}
                      <div className="flex flex-col gap-2">
                        {classes.map((cls) => (
                          <div
                            key={cls.id}
                            className={`flex items-center justify-between p-2.5 rounded-lg border ${
                              cls.status === 'Live Sparring'
                                ? 'bg-[#262932]/90 border-[#ff2a2a]/50'
                                : 'bg-[#1e2028]/60 border-[#4a3836]/25'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <span
                                className={`font-mono-num text-xs w-16 shrink-0 ${
                                  cls.status === 'Live Sparring'
                                    ? 'text-[#ff2a2a] font-bold'
                                    : 'text-[#8e8281]'
                                }`}
                              >
                                {cls.time}
                              </span>
                              <div className="flex flex-col min-w-0">
                                <span className="font-headline text-sm text-white uppercase font-bold truncate">
                                  {cls.title}
                                </span>
                                <span className="text-xs text-[#8e8281] truncate">
                                  {cls.coach} · {cls.zone}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2.5 shrink-0 font-mono-num text-xs">
                              <span className="text-[#c9bfc0]">
                                {cls.enrolled}/{cls.capacity}
                              </span>
                              <span
                                className={`text-[11px] font-semibold ${
                                  cls.status === 'Live Sparring'
                                    ? 'text-[#ff2a2a]'
                                    : 'text-[#8e8281]'
                                }`}
                              >
                                {cls.status === 'Live Sparring' ? 'In Session' : cls.status}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4">
                      <button
                        onClick={() => setActiveTab('schedule-and-classes')}
                        className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#1e2028] hover:bg-[#262932] border border-[#4a3836]/40 text-white font-headline text-xs uppercase font-bold tracking-wider transition-colors cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[17px]">calendar_month</span>
                        <span>Manage Class Schedule</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Live Member Attendance Log */}
                <div className="flex flex-col p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                  <div className="flex items-center justify-between pb-4 border-b border-[#4a3836]/25">
                    <div className="flex flex-col">
                      <h2 className="font-headline text-lg text-white tracking-wide uppercase font-bold">
                        Live Member Attendance Log
                      </h2>
                      <span className="text-xs text-[#8e8281]">
                        Real-time check-ins via biometrics and security PIN at academy entry gates
                      </span>
                    </div>
                    <span className="text-xs font-mono-num text-[#ff2a2a] font-semibold">
                      System Active
                    </span>
                  </div>

                  <div
                    className={`grid gap-4 mt-3 ${
                      isMobilePreview
                        ? 'grid-cols-1'
                        : 'grid-cols-1 md:grid-cols-2 xl:grid-cols-4'
                    }`}
                  >
                    {attendanceLogs.slice(0, 4).map((log) => (
                      <div
                        key={log.id}
                        className="flex flex-col justify-between p-4 rounded-xl bg-[#1e2028]/70 border border-[#4a3836]/25"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="p-2 rounded-lg bg-[#ff2a2a]/15 text-[#ff2a2a]">
                            <span className="material-symbols-outlined text-[20px]">
                              {log.icon}
                            </span>
                          </div>
                          <span className="font-mono-num text-[11px] text-[#8e8281]">
                            {log.timeAgo}
                          </span>
                        </div>
                        <div className="my-3 flex flex-col">
                          <span className="font-headline text-sm text-white font-bold uppercase">
                            {log.fighterName}
                          </span>
                          <span className="text-xs text-[#8e8281] mt-0.5">
                            Checked in via {log.method}
                          </span>
                          <span className="font-headline text-sm text-[#ff2a2a] font-bold mt-2">
                            {log.gateNode}
                          </span>
                        </div>
                        <span className="text-[11px] text-[#c9bfc0]">{log.rosterNote}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* VIEW 2: FIGHTERS & CAMP ROSTER */}
            {activeTab === 'members' && (
              <div className="flex flex-col gap-4 p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#4a3836]/25">
                  <div>
                    <h2 className="font-headline text-xl text-white uppercase font-bold tracking-wide">
                      Fighters &amp; Camp Roster ({filteredFighters.length})
                    </h2>
                    <p className="text-xs text-[#8e8281]">
                      Biometric turnstile credentials, bout records, weight classes &amp; medical clearances
                    </p>
                  </div>
                  {/* Interactive Segmented Filter Controls */}
                  <div className="flex items-center gap-1 p-1 rounded-lg bg-[#0c0e13] border border-[#4a3836]/40">
                    {(['all', 'active', 'expiring', 'lapsed'] as const).map((fKey) => (
                      <button
                        key={fKey}
                        onClick={() => setRosterFilter(fKey)}
                        className={`px-3 py-1.5 rounded-md text-xs font-headline uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap ${
                          rosterFilter === fKey
                            ? 'bg-[#ff2a2a] text-white font-bold'
                            : 'text-[#8e8281] hover:text-white'
                        }`}
                      >
                        {fKey}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-[#4a3836]/30 text-[11px] text-[#8e8281] uppercase font-mono-num">
                        <th className="py-3 px-3">Fighter / Tag</th>
                        <th className="py-3 px-3">Discipline &amp; Weight</th>
                        <th className="py-3 px-3">Record</th>
                        <th className="py-3 px-3">Medical</th>
                        <th className="py-3 px-3 text-right">Expiry</th>
                        <th className="py-3 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#4a3836]/20 text-xs">
                      {filteredFighters.map((fighter) => (
                        <tr key={fighter.id} className="hover:bg-[#1e2028]/60 transition-colors">
                          <td className="py-3 px-3">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-[#1e2028] border border-[#ff2a2a]/40 flex items-center justify-center font-headline font-bold text-xs text-[#ff2a2a] shrink-0">
                                {fighter.initials}
                              </div>
                              <div>
                                <div className="font-headline text-sm font-bold uppercase text-white">
                                  {fighter.name}
                                </div>
                                <div className="font-mono-num text-[11px] text-[#8e8281]">
                                  {fighter.tagId} · {fighter.rfid}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-3">
                            <div className="text-white font-medium">{fighter.discipline}</div>
                            <div className="text-[#8e8281]">{fighter.weightClass}</div>
                          </td>
                          <td className="py-3 px-3 font-mono-num text-[#c9bfc0]">
                            {fighter.boutRecord}
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={
                                fighter.medicalClearance === 'Cleared'
                                  ? 'text-[#e2e2e9]'
                                  : 'text-[#ff6b4a] font-semibold'
                              }
                            >
                              {fighter.medicalClearance}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right font-mono-num">
                            <div className="text-white font-bold">{fighter.expiryDate}</div>
                            <div
                              className={
                                fighter.daysRemaining <= 3
                                  ? 'text-[#ff5449]'
                                  : fighter.daysRemaining <= 10
                                  ? 'text-[#ffb77f]'
                                  : 'text-[#8e8281]'
                              }
                            >
                              {fighter.daysRemaining}d · {fighter.status}
                            </div>
                          </td>
                          <td className="py-3 px-3 text-right">
                            <div className="inline-flex items-center gap-1.5">
                              <button
                                onClick={() => handleMatCheckIn(fighter)}
                                className="px-2.5 py-1.5 rounded bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold cursor-pointer whitespace-nowrap"
                              >
                                Check-In
                              </button>
                              <button
                                onClick={() => handleRenewPass(fighter)}
                                className="px-2.5 py-1.5 rounded bg-[#262932] hover:bg-[#31343f] text-white font-headline text-xs uppercase font-semibold cursor-pointer whitespace-nowrap"
                              >
                                Renew
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* VIEW 3: FIGHT CAMP PASSES */}
            {activeTab === 'memberships' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {[
                  {
                    tier: 'Pro Octagon Fight Camp',
                    audience: 'For professional & national amateur roster athletes',
                    price: '₹24,500',
                    cadence: 'per quarter (90 days)',
                    metrics: 'Unlimited Cage, Muay Thai, Boxing, Strength & Recovery Bay + Biometric Gate Access',
                    enrolled: '412 Active Fighters',
                  },
                  {
                    tier: 'Striker Elite Camp Pass',
                    audience: 'For Muay Thai, Kickboxing & Boxing Heavy Hands specialists',
                    price: '₹14,500',
                    cadence: 'per quarter (90 days)',
                    metrics: 'Daily Heavy Bag, Pad Work, Friday Technical Sparring & Ring Access',
                    enrolled: '586 Active Fighters',
                  },
                  {
                    tier: 'Grappler Unlimited (BJJ & Wrestling)',
                    audience: 'For Gi / No-Gi Brazilian Jiu-Jitsu & Freestyle Wrestling',
                    price: '₹32,000',
                    cadence: 'per 6 months (180 days)',
                    metrics: 'All Dojang Mat Sessions, Open Mat Drilling & Tournament Coaching',
                    enrolled: '286 Active Fighters',
                  },
                ].map((plan) => (
                  <div
                    key={plan.tier}
                    className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/35 flex flex-col justify-between gap-4"
                  >
                    <div className="flex flex-col gap-2">
                      <span className="text-xs text-[#ff2a2a] font-medium">{plan.audience}</span>
                      <h3 className="font-headline text-xl text-white uppercase font-bold">
                        {plan.tier}
                      </h3>
                      <div className="flex items-baseline gap-2 my-1">
                        <span className="font-headline text-3xl text-white font-bold tabular-nums">
                          {plan.price}
                        </span>
                        <span className="text-xs text-[#8e8281]">{plan.cadence}</span>
                      </div>
                      <p className="text-xs text-[#c9bfc0] leading-relaxed">{plan.metrics}</p>
                    </div>
                    <div className="pt-3 border-t border-[#4a3836]/25 flex items-center justify-between">
                      <span className="font-mono-num text-xs text-[#8e8281]">{plan.enrolled}</span>
                      <button
                        onClick={() => {
                          setNewFighterTier(plan.tier);
                          setIsRegisterModalOpen(true);
                        }}
                        className="px-3.5 py-2 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold cursor-pointer"
                      >
                        Assign Pass
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* VIEW 4: PAYMENTS & LEDGER */}
            {activeTab === 'payments-and-invoices' && (
              <div className="flex flex-col gap-4 p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                <div className="flex items-center justify-between pb-4 border-b border-[#4a3836]/25">
                  <div>
                    <h2 className="font-headline text-xl text-white uppercase font-bold">
                      Payments &amp; Financial Ledger
                    </h2>
                    <p className="text-xs text-[#8e8281]">
                      GST-compliant fight camp invoices, UPI collections &amp; pending dues
                    </p>
                  </div>
                  <span className="font-mono-num text-sm text-white font-bold">
                    Oct Collection: ₹85,40,000
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-[#4a3836]/30 text-[11px] text-[#8e8281] uppercase font-mono-num">
                        <th className="py-3 px-3">Invoice #</th>
                        <th className="py-3 px-3">Fighter</th>
                        <th className="py-3 px-3">Camp Package</th>
                        <th className="py-3 px-3">Method</th>
                        <th className="py-3 px-3 text-right">Amount</th>
                        <th className="py-3 px-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#4a3836]/20 text-xs">
                      {invoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-[#1e2028]/60">
                          <td className="py-3 px-3 font-mono-num text-white">{inv.invoiceNo}</td>
                          <td className="py-3 px-3">
                            <span className="font-bold text-white">{inv.fighterName}</span>{' '}
                            <span className="font-mono-num text-[#8e8281]">· {inv.tagId}</span>
                          </td>
                          <td className="py-3 px-3 text-[#c9bfc0]">{inv.planName}</td>
                          <td className="py-3 px-3 text-[#8e8281]">{inv.method}</td>
                          <td className="py-3 px-3 text-right font-mono-num text-white font-bold">
                            ₹{inv.amount.toLocaleString('en-IN')}
                          </td>
                          <td className="py-3 px-3 text-right font-mono-num">
                            {inv.status === 'Paid' ? (
                              <span className="text-[#e2e2e9]">Paid</span>
                            ) : (
                              <button
                                onClick={() => {
                                  setInvoices((prev) =>
                                    prev.map((item) =>
                                      item.id === inv.id ? { ...item, status: 'Paid' } : item
                                    )
                                  );
                                  showToast(`Marked ${inv.invoiceNo} as Paid`);
                                }}
                                className="text-[#ff2a2a] hover:underline font-bold cursor-pointer"
                              >
                                {inv.status} · Collect
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* VIEW 5: MAT & CAGE SCHEDULE */}
            {activeTab === 'schedule-and-classes' && (
              <div className="flex flex-col gap-4 p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                <div className="flex items-center justify-between pb-4 border-b border-[#4a3836]/25">
                  <div>
                    <h2 className="font-headline text-xl text-white uppercase font-bold">
                      Master Mat &amp; Octagon Cage Schedule
                    </h2>
                    <p className="text-xs text-[#8e8281]">
                      Manage sparring caps, coach assignments &amp; live session check-ins
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {classes.map((cls) => (
                    <div
                      key={cls.id}
                      className="p-4 rounded-xl bg-[#1e2028] border border-[#4a3836]/35 flex flex-col justify-between gap-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-mono-num text-xs text-[#ff2a2a] font-bold">
                            {cls.time} · {cls.zone}
                          </span>
                          <h3 className="font-headline text-lg text-white uppercase font-bold mt-0.5">
                            {cls.title}
                          </h3>
                          <span className="text-xs text-[#8e8281]">{cls.coach}</span>
                        </div>
                        <span className="font-mono-num text-xs text-white font-bold">
                          {cls.enrolled}/{cls.capacity} Fighters
                        </span>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-[#4a3836]/25">
                        <span className="text-xs text-[#c9bfc0]">{cls.status}</span>
                        <button
                          onClick={() => {
                            if (cls.enrolled < cls.capacity) {
                              setClasses((prev) =>
                                prev.map((c) =>
                                  c.id === cls.id ? { ...c, enrolled: c.enrolled + 1 } : c
                                )
                              );
                              showToast(`Added +1 fighter to ${cls.title}`);
                            } else {
                              showToast(`${cls.title} is at full safety capacity`);
                            }
                          }}
                          className="px-3 py-1.5 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold cursor-pointer"
                        >
                          + Check-In Spot
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* VIEW 6: CAMP BROADCAST & ALERTS */}
            {activeTab === 'broadcast-and-notifications' && (
              <div className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30 max-w-2xl flex flex-col gap-4">
                <div>
                  <h2 className="font-headline text-xl text-white uppercase font-bold">
                    Camp Broadcast &amp; Automated Alerts
                  </h2>
                  <p className="text-xs text-[#8e8281]">
                    Dispatch instant WhatsApp, SMS, and Android APK push alerts to roster segments
                  </p>
                </div>

                <label className="flex flex-col gap-1">
                  <span className="text-xs text-[#8e8281]">Target Fighter Segment</span>
                  <select
                    value={broadcastAudience}
                    onChange={(e) => setBroadcastAudience(e.target.value)}
                    className="h-10 px-3 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs text-white"
                  >
                    <option>Expiring Camp Passes (≤ 30 Days) — 64 Fighters</option>
                    <option>All Active Fight Camp Roster — 1,284 Fighters</option>
                    <option>Pro MMA Fight Squad — 86 Fighters</option>
                    <option>Pending Medical Clearance — 48 Fighters</option>
                  </select>
                </label>

                <div className="flex flex-col gap-1">
                  <span className="text-xs text-[#8e8281]">Delivery Channel</span>
                  <div className="flex gap-2">
                    {(['WhatsApp + SMS', 'Android Push + SMS'] as const).map((ch) => (
                      <button
                        key={ch}
                        type="button"
                        onClick={() => setBroadcastChannel(ch)}
                        className={`px-3.5 py-2 rounded-lg text-xs font-headline uppercase cursor-pointer ${
                          broadcastChannel === ch
                            ? 'bg-[#ff2a2a] text-white font-bold'
                            : 'bg-[#0c0e13] text-[#8e8281]'
                        }`}
                      >
                        {ch}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="flex flex-col gap-1">
                  <span className="text-xs text-[#8e8281]">Broadcast Message Payload</span>
                  <textarea
                    rows={4}
                    value={broadcastMessage}
                    onChange={(e) => setBroadcastMessage(e.target.value)}
                    className="p-3 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs text-white leading-relaxed"
                  />
                </label>

                <button
                  onClick={() =>
                    showToast(`Broadcast dispatched via ${broadcastChannel} to ${broadcastAudience}`)
                  }
                  className="h-10 px-5 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold tracking-wider cursor-pointer self-start"
                >
                  Dispatch Camp Broadcast Now
                </button>
              </div>
            )}

            {/* VIEW 7: FIGHT NIGHT NOTICES */}
            {activeTab === 'announcements' && (
              <div className="flex flex-col gap-4">
                {notices.map((notice) => (
                  <div
                    key={notice.id}
                    className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30 flex flex-col gap-2"
                  >
                    <div className="flex items-center justify-between text-xs text-[#8e8281]">
                      <span className="text-[#ff2a2a] font-semibold">
                        {notice.category} · {notice.date}
                      </span>
                      <span className="font-mono-num">
                        {notice.acknowledgedCount} Fighters Acknowledged
                      </span>
                    </div>
                    <h3 className="font-headline text-lg text-white uppercase font-bold">
                      {notice.title}
                    </h3>
                    <p className="text-xs text-[#c9bfc0] leading-relaxed">{notice.description}</p>
                    <div className="pt-2 flex items-center justify-between text-xs text-[#8e8281]">
                      <span>Posted by {notice.author}</span>
                      <button
                        onClick={() => {
                          setNotices((prev) =>
                            prev.map((n) =>
                              n.id === notice.id
                                ? { ...n, acknowledgedCount: n.acknowledgedCount + 1 }
                                : n
                            )
                          );
                          showToast('Notice acknowledgment recorded');
                        }}
                        className="text-[#ff2a2a] font-headline uppercase font-bold hover:underline cursor-pointer"
                      >
                        + Acknowledge Notice
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* VIEW 8: FIGHTER STATS & REVENUE */}
            {activeTab === 'analytics-and-reports' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                  <span className="text-xs text-[#8e8281]">Bout Win Rate (2025 Season)</span>
                  <div className="font-headline text-4xl text-white font-bold my-2 tabular-nums">
                    78.4%
                  </div>
                  <p className="text-xs text-[#c9bfc0]">
                    62 victories across 79 sanctioned Pro &amp; Amateur bouts in North India circuit
                  </p>
                </div>
                <div className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                  <span className="text-xs text-[#8e8281]">90-Day Camp Retention</span>
                  <div className="font-headline text-4xl text-white font-bold my-2 tabular-nums">
                    91.6%
                  </div>
                  <p className="text-xs text-[#c9bfc0]">
                    Biometric turnstile streak tracking boosted morning session adherence by +18%
                  </p>
                </div>
                <div className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30">
                  <span className="text-xs text-[#8e8281]">Android App Active Athletes</span>
                  <div className="font-headline text-4xl text-[#ff2a2a] font-bold my-2 tabular-nums">
                    1,190
                  </div>
                  <p className="text-xs text-[#c9bfc0]">
                    83% of enrolled fighters check in via Android WebAPK &amp; NFC Wristband
                  </p>
                </div>
              </div>
            )}

            {/* VIEW 9: DCA CAGE CONFIG */}
            {activeTab === 'system-settings' && (
              <div className="p-5 rounded-xl bg-[#16181f] border border-[#4a3836]/30 max-w-2xl flex flex-col gap-4">
                <div>
                  <h2 className="font-headline text-xl text-white uppercase font-bold">
                    DCA Cage &amp; Biometric Turnstile Configuration
                  </h2>
                  <p className="text-xs text-[#8e8281]">
                    Rohini Sector 14 HQ Hardware Nodes &amp; Android APK Packaging Controls
                  </p>
                </div>

                <div className="flex items-center justify-between py-3 border-b border-[#4a3836]/25">
                  <div>
                    <div className="text-sm font-semibold text-white">
                      Today&apos;s Daily Rotating Club PIN (Auto 00:00 IST)
                    </div>
                    <div className="text-xs text-[#8e8281]">
                      Active 4-digit fallback PIN for members inside the 50m GPS perimeter:{' '}
                      <strong className="text-[#ff2a2a] font-mono-num">#{dailyPin}</strong>
                    </div>
                  </div>
                  <button
                    onClick={handleRegenerateDailyPin}
                    className="px-3.5 py-1.5 rounded-lg bg-[#262932] hover:bg-[#ff2a2a] text-white font-headline text-xs uppercase font-bold cursor-pointer transition-colors"
                  >
                    Regenerate PIN
                  </button>
                </div>

                <div className="flex items-center justify-between py-3 border-b border-[#4a3836]/25">
                  <div>
                    <div className="text-sm font-semibold text-white">
                      Main Dojang &amp; Cage Turnstile Solenoids
                    </div>
                    <div className="text-xs text-[#8e8281]">
                      Automatically lock turnstile gates when fighter pass is lapsed
                    </div>
                  </div>
                  <button
                    onClick={() => setTurnstilesArmed(!turnstilesArmed)}
                    className={`px-3.5 py-1.5 rounded-lg font-headline text-xs uppercase font-bold cursor-pointer ${
                      turnstilesArmed ? 'bg-[#ff2a2a] text-white' : 'bg-[#262932] text-[#8e8281]'
                    }`}
                  >
                    {turnstilesArmed ? 'Armed' : 'Disarmed'}
                  </button>
                </div>

                <div className="flex items-center justify-between py-3 border-b border-[#4a3836]/25">
                  <div>
                    <div className="text-sm font-semibold text-white">
                      Strict Biometric + Medical Verification
                    </div>
                    <div className="text-xs text-[#8e8281]">
                      Require annual bloodwork &amp; ophthalmology sign-off for Cage sparring
                    </div>
                  </div>
                  <button
                    onClick={() => setBiometricStrictMode(!biometricStrictMode)}
                    className={`px-3.5 py-1.5 rounded-lg font-headline text-xs uppercase font-bold cursor-pointer ${
                      biometricStrictMode
                        ? 'bg-[#ff2a2a] text-white'
                        : 'bg-[#262932] text-[#8e8281]'
                    }`}
                  >
                    {biometricStrictMode ? 'Enabled' : 'Bypass'}
                  </button>
                </div>

                <div className="flex items-center justify-between py-3">
                  <div>
                    <div className="text-sm font-semibold text-white">
                      Mat Floor Safety Capacity Alert Limit
                    </div>
                    <div className="text-xs text-[#8e8281]">
                      Current threshold: {safetyCapLimit} fighters on mats
                    </div>
                  </div>
                  <input
                    type="number"
                    value={safetyCapLimit}
                    onChange={(e) => setSafetyCapLimit(Number(e.target.value) || 105)}
                    className="w-20 h-9 px-2.5 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs font-mono-num text-white text-right"
                  />
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setIsAPKModalOpen(true)}
                    className="flex items-center gap-2 h-10 px-4 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold tracking-wider cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px]">android</span>
                    <span>Open Android APK Build Studio</span>
                  </button>
                </div>
              </div>
            )}
          </main>
        </div>

        {/* Fixed Bottom Thumb-Zone Navigation Bar (Shown in Mobile APK Preview & Mobile Screens) */}
        <nav
          className={`${
            isMobilePreview
              ? 'sticky bottom-0 left-0 right-0'
              : 'lg:hidden fixed bottom-0 left-0 right-0'
          } z-40 h-16 bg-[#0c0e13]/95 backdrop-blur-md border-t border-[#4a3836]/40 grid grid-cols-5 items-center px-1`}
        >
          {[
            { id: 'dashboard' as NavTab, label: 'Command', icon: 'sports_mma' },
            { id: 'members' as NavTab, label: 'Roster', icon: 'groups' },
            { id: 'schedule-and-classes' as NavTab, label: 'Schedule', icon: 'fitness_center' },
            { id: 'payments-and-invoices' as NavTab, label: 'Ledger', icon: 'receipt_long' },
          ].map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer ${
                  active ? 'text-[#ff2a2a]' : 'text-[#8e8281] hover:text-white'
                }`}
              >
                <span className="material-symbols-outlined text-[21px]">{tab.icon}</span>
                <span className="text-[10px] font-medium tracking-tight mt-0.5">{tab.label}</span>
              </button>
            );
          })}
          <button
            onClick={() => setIsAPKModalOpen(true)}
            className="min-h-[44px] flex flex-col items-center justify-center text-[#ff6b4a] hover:text-white cursor-pointer"
          >
            <span className="material-symbols-outlined text-[21px]">android</span>
            <span className="text-[10px] font-medium tracking-tight mt-0.5">APK</span>
          </button>
        </nav>
      </div>

      {/* Register Fighter Modal */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-xl bg-[#16181f] border border-[#4a3836]/60 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#4a3836]/30">
              <h3 className="font-headline text-lg font-bold uppercase text-white">
                Register New Fighter Intake
              </h3>
              <button
                onClick={() => setIsRegisterModalOpen(false)}
                className="text-[#8e8281] hover:text-white cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>
            <form onSubmit={handleRegisterFighter} className="mt-4 flex flex-col gap-3.5">
              <label className="flex flex-col gap-1">
                <span className="text-xs text-[#8e8281]">Fighter Full Name</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Arjun Beniwal"
                  value={newFighterName}
                  onChange={(e) => setNewFighterName(e.target.value)}
                  className="h-10 px-3 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs text-white focus:outline-none focus:border-[#ff2a2a]"
                />
              </label>
              <label className="flex flex-col gap-1">
                <span className="text-xs text-[#8e8281]">Combat Discipline</span>
                <select
                  value={newFighterDiscipline}
                  onChange={(e) => setNewFighterDiscipline(e.target.value)}
                  className="h-10 px-3 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs text-white"
                >
                  <option>Pro MMA Fight Camp</option>
                  <option>Muay Thai Intensive</option>
                  <option>Boxing Heavy Hands</option>
                  <option>BJJ Gi &amp; No-Gi Squad</option>
                  <option>Freestyle Wrestling &amp; MMA</option>
                </select>
              </label>
              <label className="flex flex-col gap-1">
                <span className="text-xs text-[#8e8281]">Official Weight Class</span>
                <select
                  value={newFighterWeight}
                  onChange={(e) => setNewFighterWeight(e.target.value)}
                  className="h-10 px-3 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs text-white"
                >
                  <option>Flyweight (57 kg)</option>
                  <option>Bantamweight (61 kg)</option>
                  <option>Featherweight (66 kg)</option>
                  <option>Lightweight (70 kg)</option>
                  <option>Welterweight (77 kg)</option>
                  <option>Middleweight (84 kg)</option>
                  <option>Heavyweight (93+ kg)</option>
                </select>
              </label>
              <label className="flex flex-col gap-1">
                <span className="text-xs text-[#8e8281]">WhatsApp / Mobile Number</span>
                <input
                  type="text"
                  value={newFighterPhone}
                  onChange={(e) => setNewFighterPhone(e.target.value)}
                  className="h-10 px-3 rounded-lg bg-[#0c0e13] border border-[#4a3836]/50 text-xs font-mono-num text-white"
                />
              </label>
              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 h-10 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-xs uppercase font-bold tracking-wider cursor-pointer"
                >
                  Enroll &amp; Issue RFID
                </button>
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-4 h-10 rounded-lg bg-[#262932] text-white font-headline text-xs uppercase font-semibold cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Android APK Builder & Exporter Modal */}
      <APKBuilderModal
        isOpen={isAPKModalOpen}
        onClose={() => setIsAPKModalOpen(false)}
        isMobilePreview={isMobilePreview}
        onToggleMobilePreview={() => setIsMobilePreview(!isMobilePreview)}
      />

      {/* Toast Feedback Banner */}
      {toastMessage && (
        <div className="fixed bottom-20 lg:bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-lg bg-[#16181f] border border-[#ff2a2a] px-4 py-3 text-xs font-medium text-white shadow-2xl">
          <span className="material-symbols-outlined text-[#ff2a2a] text-[18px]">check_circle</span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Offline Status Indicator */}
      <OfflineIndicator />
    </div>
  );
}
