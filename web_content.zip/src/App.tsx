/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Arrow, AuthUser, GameSettings, Level, LevelProgress, UserProgress } from './types/game';
import { getLevel, getDifficultyForLevel } from './game/generator';
import { isArrowPathClear, getHintArrow } from './game/solver';
import { sounds } from './audio/soundManager';
import { loadLocalProgress, saveLocalProgress, DEFAULT_SETTINGS } from './services/storage';
import { syncService, SyncStatus } from './services/firebaseSync';
import { GameBoard } from './components/GameBoard';
import { LevelSelectModal } from './components/LevelSelectModal';
import { SettingsModal } from './components/SettingsModal';
import { AuthModal } from './components/AuthModal';
import { AndroidSimulatorFrame } from './components/AndroidSimulatorFrame';
import { AndroidProjectInspector } from './components/AndroidProjectInspector';
import {
  Heart,
  RotateCcw,
  Lightbulb,
  Pause,
  Play,
  Grid,
  Settings,
  Smartphone,
  Maximize2,
  Code2,
  Star,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Volume2,
  VolumeX,
  Download,
} from 'lucide-react';
import { downloadAndroidProjectZip } from './services/projectDownloader';

type ScreenState = 'TITLE' | 'PLAYING';

export default function App() {
  // Game & User Progress
  const [progress, setProgress] = useState<UserProgress>(loadLocalProgress());
  const [currentLevelId, setCurrentLevelId] = useState<number>(progress.currentLevel);
  const [levelData, setLevelData] = useState<Level>(() => getLevel(progress.currentLevel));
  const [activeArrows, setActiveArrows] = useState<Arrow[]>(levelData.arrows);

  // Gameplay State
  const [screen, setScreen] = useState<ScreenState>('TITLE');
  const [lives, setLives] = useState<number>(3);
  const [moves, setMoves] = useState<number>(0);
  const [seconds, setSeconds] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isWon, setIsWon] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [earnedStars, setEarnedStars] = useState<number>(0);

  // Device & Layout Options
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(false);

  // Authentication & Sync
  const [authUser, setAuthUser] = useState<AuthUser | null>(syncService.getUser());
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    isOnline: true,
    isSyncing: false,
    lastSyncedAt: null,
    pendingChanges: false,
    error: null,
  });

  // Modals & Downloads
  const [showLevelSelect, setShowLevelSelect] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showAuth, setShowAuth] = useState<boolean>(false);
  const [showInspector, setShowInspector] = useState<boolean>(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState<boolean>(false);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);

  const handleDownloadProject = async () => {
    setIsDownloadingZip(true);
    setDownloadToast('Preparing Android Studio project (.ZIP)...');
    try {
      await downloadAndroidProjectZip((msg) => setDownloadToast(msg));
      setDownloadToast('✓ ArrowEscape-Android-Project.zip ready! Download started.');
      setTimeout(() => setDownloadToast(null), 4500);
    } catch (e) {
      setDownloadToast('Failed to generate ZIP. Please try again.');
      setTimeout(() => setDownloadToast(null), 3000);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const timerRef = useRef<number | null>(null);

  // Subscriptions
  useEffect(() => {
    const unsubSync = syncService.subscribeStatus(setSyncStatus);
    const unsubAuth = syncService.subscribeAuth(setAuthUser);
    return () => {
      unsubSync();
      unsubAuth();
    };
  }, []);

  // Sync sound settings with audio manager
  useEffect(() => {
    sounds.setMuted(!progress.settings.soundEnabled);
  }, [progress.settings.soundEnabled]);

  // Load new level
  const loadLevel = useCallback((lvlId: number) => {
    const clampedId = Math.max(1, Math.min(1000, lvlId));
    const newLvl = getLevel(clampedId);
    setCurrentLevelId(clampedId);
    setLevelData(newLvl);
    setActiveArrows(newLvl.arrows.map((a) => ({ ...a })));
    setLives(3);
    setMoves(0);
    setSeconds(0);
    setIsPaused(false);
    setIsWon(false);
    setIsGameOver(false);
    setEarnedStars(0);
  }, []);

  // Timer loop
  useEffect(() => {
    if (screen === 'PLAYING' && !isPaused && !isWon && !isGameOver) {
      timerRef.current = window.setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [screen, isPaused, isWon, isGameOver]);

  // Handle arrow interaction
  const handleArrowClick = useCallback(
    (arrow: Arrow) => {
      if (isWon || isGameOver || isPaused || arrow.isEscaping) return;

      sounds.playClick();
      setMoves((m) => m + 1);

      const canEscape = isArrowPathClear(
        arrow,
        activeArrows,
        levelData.gridRows,
        levelData.gridCols
      );

      if (canEscape) {
        // Valid Escape!
        sounds.playEscape();

        const remainingAfterThis = activeArrows.filter(
          (a) => !a.isEscaping && a.id !== arrow.id
        ).length;

        // 1. Immediately set isEscaping: true so remaining count decrements instantly
        setActiveArrows((prev) =>
          prev.map((a) =>
            a.id === arrow.id ? { ...a, isEscaping: true, isHinted: false } : a
          )
        );

        // 2. Victory check when the last arrow escapes
        if (remainingAfterThis === 0) {
          setTimeout(() => {
            sounds.playLevelWin();
            setIsWon(true);

            // Calculate star rating (3 lives = 3 stars, 2 lives = 2 stars, 1 life = 1 star)
            const stars = lives === 3 ? 3 : lives === 2 ? 2 : 1;
            setEarnedStars(stars);

            // Save progress
            const completedLevelData: LevelProgress = {
              stars,
              bestTimeSec: seconds,
              bestMoves: moves + 1,
              completedAt: new Date().toISOString(),
            };

            const nextLevelId = Math.min(1000, currentLevelId + 1);
            const updatedProgress: UserProgress = {
              ...progress,
              currentLevel: Math.max(progress.currentLevel, nextLevelId),
              completedLevels: {
                ...progress.completedLevels,
                [currentLevelId]: completedLevelData,
              },
              totalStars:
                Object.values({
                  ...progress.completedLevels,
                  [currentLevelId]: completedLevelData,
                }).reduce((sum, item) => sum + item.stars, 0),
              lastUpdated: new Date().toISOString(),
            };

            setProgress(updatedProgress);
            saveLocalProgress(updatedProgress);
            syncService.syncProgress(updatedProgress);
          }, 360);
        } else {
          // Remove from memory after smooth flight animation completes
          setTimeout(() => {
            setActiveArrows((current) => current.filter((a) => a.id !== arrow.id));
          }, 450);
        }
      } else {
        // Collision / Blocked Move
        sounds.playBlocked();

        // Subtle invalid shake feedback (arrow stays on the board)
        setActiveArrows((prev) =>
          prev.map((a) => (a.id === arrow.id ? { ...a, isInvalid: true } : a))
        );
        setTimeout(() => {
          setActiveArrows((prev) =>
            prev.map((a) => (a.id === arrow.id ? { ...a, isInvalid: false } : a))
          );
        }, 340);

        // Deduct 1 life
        setLives((prevLives) => {
          const nextLives = prevLives - 1;
          if (nextLives <= 0) {
            sounds.playLifeLost();
            setIsGameOver(true);
            return 0;
          }
          sounds.playLifeLost();
          return nextLives;
        });
      }
    },
    [
      isWon,
      isGameOver,
      isPaused,
      activeArrows,
      levelData.gridRows,
      levelData.gridCols,
      lives,
      currentLevelId,
      progress,
      seconds,
      moves,
    ]
  );

  // Request Hint
  const handleHint = () => {
    if (isWon || isGameOver || isPaused) return;
    const hint = getHintArrow(activeArrows, levelData.gridRows, levelData.gridCols);
    if (hint) {
      sounds.playHint();
      setActiveArrows((prev) =>
        prev.map((a) => ({
          ...a,
          isHinted: a.id === hint.id,
        }))
      );
    }
  };

  // Restart Level
  const handleRestart = () => {
    sounds.playClick();
    loadLevel(currentLevelId);
  };

  // Advance to Next Level
  const handleNextLevel = () => {
    sounds.playClick();
    loadLevel(currentLevelId + 1);
  };

  // Start Playing from Title
  const handleStartGame = () => {
    sounds.playClick();
    loadLevel(currentLevelId);
    setScreen('PLAYING');
  };

  // Update Settings
  const handleUpdateSettings = (newSettings: Partial<GameSettings>) => {
    const updated = {
      ...progress,
      settings: { ...progress.settings, ...newSettings },
    };
    setProgress(updated);
    saveLocalProgress(updated);
  };

  // Keyboard shortcut listener for start & pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === ' ' || e.key === 'Enter') {
        if (screen === 'TITLE') {
          handleStartGame();
        }
      } else if (e.key === 'Escape') {
        if (screen === 'PLAYING') {
          setIsPaused((p) => !p);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screen]);

  const totalArrows = levelData.arrows.length;
  const remainingCount = activeArrows.filter((a) => !a.isEscaping).length;
  const escapedCount = totalArrows - remainingCount;
  const progressPercent = totalArrows > 0 ? Math.round((escapedCount / totalArrows) * 100) : 0;

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans selection:bg-neutral-800">
      {/* Top Global Utility Bar */}
      <header className="w-full border-b border-[#1c1c1c] bg-[#080808] px-4 py-2.5 flex items-center justify-between z-40 select-none">
        <div className="flex items-center gap-3">
          <div
            onClick={() => setScreen('TITLE')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-6 h-6 rounded-md bg-white text-black font-extrabold flex items-center justify-center text-xs group-hover:scale-105 transition-transform">
              ↗
            </div>
            <span className="font-extrabold tracking-wider text-sm text-white">
              ARROW ESCAPE
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-neutral-400 pl-3 border-l border-[#222222]">
            <span>1000 Solvable Levels</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-neutral-300">
              Level {currentLevelId} ({totalArrows} Arrows)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Download Android App Zip CTA */}
          <button
            onClick={handleDownloadProject}
            disabled={isDownloadingZip}
            className="px-2.5 py-1.5 text-xs bg-white text-black font-bold hover:bg-neutral-200 border border-white rounded-lg transition-all flex items-center gap-1.5 font-mono shadow-sm cursor-pointer disabled:opacity-60"
            title="Download complete ready-to-run Android Studio project (.zip)"
          >
            <Download className="w-3.5 h-3.5 text-black" />
            <span className="hidden sm:inline">
              {isDownloadingZip ? 'Zipping...' : 'Download App (.ZIP)'}
            </span>
            <span className="sm:hidden">
              {isDownloadingZip ? '...' : '.ZIP'}
            </span>
          </button>

          {/* Android Project Inspector CTA */}
          <button
            onClick={() => setShowInspector(true)}
            className="px-2.5 py-1.5 text-xs bg-[#141414] hover:bg-[#202020] text-neutral-200 border border-[#2a2a2a] rounded-lg transition-colors flex items-center gap-1.5 font-mono cursor-pointer"
            title="Inspect & Browse Kotlin Jetpack Compose Project"
          >
            <Code2 className="w-3.5 h-3.5 text-white" />
            <span className="hidden md:inline">Source Files</span>
          </button>

          {/* Quick Theme Switcher (Paper Minimalist vs OLED) */}
          <button
            onClick={() =>
              handleUpdateSettings({
                contrastTheme:
                  progress.settings.contrastTheme === 'paper_light'
                    ? 'pure_black'
                    : 'paper_light',
              })
            }
            className={`px-2.5 py-1.5 text-xs rounded-lg border font-mono transition-colors flex items-center gap-1.5 cursor-pointer ${
              progress.settings.contrastTheme === 'paper_light'
                ? 'bg-white text-black border-white font-bold'
                : 'bg-[#141414] text-neutral-300 border-[#2a2a2a] hover:bg-[#202020]'
            }`}
            title="Toggle Theme: Paper White (Screenshot style) vs OLED Pure Black"
          >
            <span className="text-[11px]">
              {progress.settings.contrastTheme === 'paper_light' ? 'Paper' : 'OLED'}
            </span>
          </button>

          {/* Toggle Phone Simulator Bezel */}
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className={`p-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
              isPhoneFrame
                ? 'bg-white text-black border-white'
                : 'bg-[#141414] text-neutral-300 border-[#2a2a2a] hover:bg-[#202020]'
            }`}
            title={isPhoneFrame ? 'Switch to Fullscreen View' : 'Switch to Android Phone Simulator'}
          >
            {isPhoneFrame ? (
              <Maximize2 className="w-4 h-4" />
            ) : (
              <Smartphone className="w-4 h-4" />
            )}
          </button>

          {/* Quick Sound Toggle */}
          <button
            onClick={() =>
              handleUpdateSettings({ soundEnabled: !progress.settings.soundEnabled })
            }
            className="p-1.5 rounded-lg bg-[#141414] hover:bg-[#202020] text-neutral-300 border border-[#2a2a2a] transition-colors cursor-pointer"
            title={progress.settings.soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
          >
            {progress.settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-white" />
            ) : (
              <VolumeX className="w-4 h-4 text-neutral-500" />
            )}
          </button>

          {/* Auth / Account indicator */}
          <button
            onClick={() => setShowAuth(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[#141414] hover:bg-[#202020] border border-[#2a2a2a] rounded-lg text-xs transition-colors cursor-pointer"
          >
            {authUser && !authUser.isGuest ? (
              <>
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="max-w-[100px] truncate text-white">
                  {authUser.displayName || 'Connected'}
                </span>
              </>
            ) : (
              <>
                <div className="w-2 h-2 rounded-full bg-neutral-500" />
                <span className="text-neutral-400">Guest</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Download Status Toast Notification */}
      {downloadToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-white text-black font-mono text-xs font-bold rounded-xl shadow-2xl border border-neutral-300 flex items-center gap-2.5">
          <Download className="w-4 h-4 animate-bounce text-black" />
          <span>{downloadToast}</span>
        </div>
      )}

      {/* Main View Area (wrapped in simulated Android phone frame if toggled) */}
      <AndroidSimulatorFrame isSimulatedDevice={isPhoneFrame}>
        {screen === 'TITLE' ? (
          /* ================= TITLE SCREEN ================= */
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center select-none animate-fadeIn">
            {/* Minimalist Geometric Header */}
            <div className="space-y-3 mb-8">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-[#0f0f0f] border border-[#262626] flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.08)]">
                <div className="grid grid-cols-2 gap-1.5 text-white">
                  <div className="w-3 h-3 border-t-2 border-r-2 border-white transform rotate-0" />
                  <div className="w-3 h-3 border-t-2 border-r-2 border-white transform rotate-90" />
                  <div className="w-3 h-3 border-t-2 border-r-2 border-white transform -rotate-90" />
                  <div className="w-3 h-3 border-t-2 border-r-2 border-white transform rotate-180" />
                </div>
              </div>

              <h1 className="text-3xl sm:text-4xl font-extrabold tracking-widest text-white">
                ARROW ESCAPE
              </h1>

              <div className="flex items-center justify-center gap-2 text-xs font-mono text-neutral-400">
                <span>1000 SOLVABLE PUZZLES</span>
                <span aria-hidden="true">·</span>
                <span>2–5 MIN TARGET PLAYTIME</span>
              </div>
            </div>

            {/* Current Player Status Card */}
            <div className="w-full max-w-sm mb-6 p-4 rounded-xl bg-[#0d0d0d] border border-[#222222] text-left">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-mono text-neutral-500 uppercase tracking-wider">
                  Progress Overview
                </span>
                <span className="text-xs font-mono text-neutral-300">
                  {Object.keys(progress.completedLevels).length} / 1000 Completed
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <div>
                  <div className="text-2xl font-bold font-mono text-white">
                    LEVEL {progress.currentLevel}
                  </div>
                  <div className="text-xs text-neutral-400 mt-0.5">
                    {totalArrows} Arrows · {levelData.difficulty} Tier · ~2–5 Min Target Playtime
                  </div>
                </div>
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#181818] border border-[#2e2e2e] rounded-lg">
                  <Star className="w-3.5 h-3.5 fill-white text-white" />
                  <span className="font-mono text-xs font-bold text-white">
                    {progress.totalStars} ★
                  </span>
                </div>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="w-full max-w-sm space-y-2.5">
              <button
                onClick={handleStartGame}
                className="w-full py-4 bg-white hover:bg-neutral-200 text-black font-extrabold rounded-xl text-sm transition-all shadow-[0_10px_30px_rgba(255,255,255,0.15)] flex items-center justify-center gap-2 tracking-wide active:scale-[0.99] cursor-pointer"
              >
                <Play className="w-4 h-4 fill-black text-black" />
                <span>PLAY LEVEL {progress.currentLevel} ({totalArrows} ARROWS)</span>
              </button>

              <button
                onClick={handleDownloadProject}
                disabled={isDownloadingZip}
                className="w-full py-3 bg-[#111111] hover:bg-[#1a1a1a] text-white border border-[#2a2a2a] hover:border-white font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer font-mono disabled:opacity-60"
              >
                <Download className="w-3.5 h-3.5" />
                <span>
                  {isDownloadingZip ? 'PACKAGING ANDROID PROJECT...' : 'DOWNLOAD ANDROID STUDIO PROJECT (.ZIP)'}
                </span>
              </button>

              <button
                onClick={() => setShowLevelSelect(true)}
                className="w-full py-3 bg-[#111111] hover:bg-[#1a1a1a] text-white border border-[#2a2a2a] hover:border-neutral-500 font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Grid className="w-3.5 h-3.5" />
                <span>SELECT LEVEL (1 - 1000)</span>
              </button>

              <div className="grid grid-cols-2 gap-2.5 pt-1">
                <button
                  onClick={() => setShowSettings(true)}
                  className="py-2.5 px-3 bg-[#0c0c0c] hover:bg-[#161616] text-neutral-300 border border-[#222222] rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>Settings &amp; Sync</span>
                </button>

                <button
                  onClick={() => setShowInspector(true)}
                  className="py-2.5 px-3 bg-[#0c0c0c] hover:bg-[#161616] text-neutral-300 border border-[#222222] rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer font-mono"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Android Src</span>
                </button>
              </div>
            </div>

            {/* Flat Control Hints */}
            <div className="mt-8 text-neutral-500 text-xs font-mono">
              Press <span className="text-neutral-300">Space</span> or{' '}
              <span className="text-neutral-300">Enter</span> to Start · Tap arrows with clear path
            </div>
          </div>
        ) : (
          /* ================= PLAYING GAME SCREEN ================= */
          <div className="flex-1 flex flex-col justify-between p-3 sm:p-5 max-w-lg mx-auto w-full select-none animate-fadeIn">
            {/* In-Game HUD Header with Remaining Counter & Progress Bar */}
            <div className="w-full flex flex-col gap-2.5 pb-3 border-b border-[#1c1c1c]">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-base font-bold tracking-tight text-white">
                      LEVEL {currentLevelId}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#181818] border border-[#2a2a2a] text-neutral-400 uppercase">
                      {levelData.difficulty}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-neutral-400 mt-0.5 flex items-center gap-2">
                    <span className="text-white font-bold">{remainingCount} Arrows Remaining</span>
                    <span>·</span>
                    <span className="text-neutral-300">{formatTimer(seconds)}</span>
                    <span>·</span>
                    <span className="text-neutral-500">{moves} moves</span>
                  </div>
                </div>

                {/* Lives indicators */}
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3].map((heartIndex) => (
                    <Heart
                      key={heartIndex}
                      className={`w-5 h-5 transition-transform duration-200 ${
                        heartIndex <= lives
                          ? 'fill-white text-white scale-100'
                          : 'text-neutral-700 stroke-[1.5] scale-90'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Real-time Level Progress Bar */}
              <div className="w-full space-y-1">
                <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400">
                  <span>Level Progress ({escapedCount} / {totalArrows} Escaped)</span>
                  <span className="text-white font-bold">{progressPercent}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#141414] rounded-full overflow-hidden border border-[#242424]">
                  <div
                    className="h-full bg-white transition-all duration-300 ease-out"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Center Puzzle Arena */}
            <div className="my-auto py-2">
              <GameBoard
                gridRows={levelData.gridRows}
                gridCols={levelData.gridCols}
                arrows={activeArrows}
                onArrowClick={handleArrowClick}
                isPaused={isPaused}
                animationSpeed={progress.settings.animationSpeed}
                theme={progress.settings.contrastTheme}
              />
            </div>

            {/* Bottom Controls Cluster */}
            <div className="w-full pt-3 border-t border-[#1c1c1c] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleHint}
                  disabled={isPaused || isWon || isGameOver}
                  className="px-3 py-2 bg-[#121212] hover:bg-[#1e1e1e] active:scale-95 text-neutral-200 border border-[#2a2a2a] rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                  title="Reveal next escapable arrow"
                >
                  <Lightbulb className="w-4 h-4 text-white" />
                  <span>Hint</span>
                </button>

                <button
                  onClick={handleRestart}
                  disabled={isWon}
                  className="p-2 bg-[#121212] hover:bg-[#1e1e1e] active:scale-95 text-neutral-200 border border-[#2a2a2a] rounded-xl transition-all cursor-pointer"
                  title="Restart level"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowLevelSelect(true)}
                  className="p-2 bg-[#121212] hover:bg-[#1e1e1e] text-neutral-200 border border-[#2a2a2a] rounded-xl transition-all cursor-pointer"
                  title="Browse Levels"
                >
                  <Grid className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsPaused(!isPaused)}
                  className="px-3 py-2 bg-[#121212] hover:bg-[#1e1e1e] text-neutral-200 border border-[#2a2a2a] rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  <span>{isPaused ? 'Resume' : 'Pause'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </AndroidSimulatorFrame>

      {/* ================= VICTORY MODAL ================= */}
      {isWon && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-sm bg-[#0c0c0c] border border-[#282828] rounded-2xl p-6 text-center shadow-2xl space-y-5 animate-scaleUp">
            <div className="w-14 h-14 mx-auto rounded-full bg-white text-black flex items-center justify-center shadow-[0_0_25px_rgba(255,255,255,0.4)]">
              <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-black tracking-wide text-white">
                LEVEL {currentLevelId} CLEARED!
              </h2>
              <p className="text-xs text-neutral-400">All {totalArrows} arrows escaped successfully!</p>
            </div>

            {/* Stars */}
            <div className="flex items-center justify-center gap-2 py-1">
              {[1, 2, 3].map((s) => (
                <Star
                  key={s}
                  className={`w-7 h-7 transition-all ${
                    s <= earnedStars
                      ? 'fill-white text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.6)]'
                      : 'text-neutral-700'
                  }`}
                />
              ))}
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-2 gap-2 p-3 bg-[#141414] border border-[#242424] rounded-xl text-xs font-mono">
              <div>
                <span className="text-neutral-500">Moves: </span>
                <span className="text-white font-bold">{moves}</span>
              </div>
              <div>
                <span className="text-neutral-500">Time: </span>
                <span className="text-white font-bold">{formatTimer(seconds)}</span>
              </div>
            </div>

            {/* Actions: CONTINUE button to open the next level */}
            <div className="space-y-2 pt-2">
              <button
                onClick={handleNextLevel}
                className="w-full py-3.5 bg-white hover:bg-neutral-200 text-black font-extrabold rounded-xl text-xs tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <span>CONTINUE TO LEVEL {currentLevelId + 1}</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setScreen('TITLE')}
                className="w-full py-2.5 bg-[#141414] hover:bg-[#1e1e1e] text-neutral-300 border border-[#2a2a2a] rounded-xl text-xs font-medium transition-colors cursor-pointer"
              >
                Back to Title
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= GAME OVER MODAL ================= */}
      {isGameOver && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-sm bg-[#0c0c0c] border border-red-950/50 rounded-2xl p-6 text-center shadow-2xl space-y-5">
            <div className="w-14 h-14 mx-auto rounded-full bg-neutral-900 border border-neutral-700 flex items-center justify-center text-neutral-400">
              <Heart className="w-7 h-7 stroke-[2]" />
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-black tracking-wide text-white">
                OUT OF LIVES
              </h2>
              <p className="text-xs text-neutral-400">
                You hit blocked paths 3 times. Observe arrow directions carefully!
              </p>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-2">
              <button
                onClick={handleRestart}
                className="w-full py-3.5 bg-white hover:bg-neutral-200 text-black font-extrabold rounded-xl text-xs tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>TRY AGAIN</span>
              </button>

              <button
                onClick={() => setScreen('TITLE')}
                className="w-full py-2.5 bg-[#141414] hover:bg-[#1e1e1e] text-neutral-300 border border-[#2a2a2a] rounded-xl text-xs font-medium transition-colors cursor-pointer"
              >
                Back to Title
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= PAUSE MODAL ================= */}
      {isPaused && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-sm bg-[#0c0c0c] border border-[#282828] rounded-2xl p-6 text-center shadow-2xl space-y-4">
            <h2 className="text-lg font-black tracking-widest text-white">GAME PAUSED</h2>
            <p className="text-xs text-neutral-400">Level {currentLevelId} in progress</p>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => setIsPaused(false)}
                className="w-full py-3 bg-white hover:bg-neutral-200 text-black font-bold rounded-xl text-xs tracking-wide transition-all cursor-pointer"
              >
                RESUME
              </button>

              <button
                onClick={handleRestart}
                className="w-full py-2.5 bg-[#141414] hover:bg-[#1e1e1e] text-white border border-[#2a2a2a] rounded-xl text-xs transition-colors cursor-pointer"
              >
                Restart Level
              </button>

              <button
                onClick={() => {
                  setIsPaused(false);
                  setScreen('TITLE');
                }}
                className="w-full py-2.5 bg-[#141414] hover:bg-[#1e1e1e] text-neutral-400 border border-[#2a2a2a] rounded-xl text-xs transition-colors cursor-pointer"
              >
                Quit to Title
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Level Select Modal (1000 levels) */}
      <LevelSelectModal
        isOpen={showLevelSelect}
        onClose={() => setShowLevelSelect(false)}
        currentUnlockedLevel={progress.currentLevel}
        completedLevels={progress.completedLevels}
        onSelectLevel={(lvlId) => {
          loadLevel(lvlId);
          setScreen('PLAYING');
        }}
      />

      {/* Settings & Sync Modal */}
      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        settings={progress.settings}
        onUpdateSettings={handleUpdateSettings}
        authUser={authUser}
        syncStatus={syncStatus}
        onManualSync={() => syncService.syncProgress(progress)}
        onOpenAuth={() => {
          setShowSettings(false);
          setShowAuth(true);
        }}
      />

      {/* Auth & Google Sign-In Modal */}
      <AuthModal
        isOpen={showAuth}
        onClose={() => setShowAuth(false)}
        authUser={authUser}
        onAuthSuccess={() => {
          const fresh = loadLocalProgress();
          setProgress(fresh);
        }}
      />

      {/* Android Native Source Code & 1-Click ZIP Inspector */}
      <AndroidProjectInspector
        isOpen={showInspector}
        onClose={() => setShowInspector(false)}
      />
    </div>
  );
}
