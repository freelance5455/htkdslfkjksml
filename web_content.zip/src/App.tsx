import { useCallback, useEffect, useRef, useState } from 'react';
import { Engine, clearSave } from './game/engine';
import { HOTBAR, DEFS, makeIcons } from './game/blocks';
import { Joystick } from './components/Joystick';
import { HoldButton } from './components/HoldButton';
import { Hotbar } from './components/Hotbar';
import { cn } from './utils/cn';

type Phase = 'loading' | 'title' | 'playing' | 'paused';

interface LookState {
  id: number;
  x: number;
  y: number;
  sx: number;
  sy: number;
  t: number;
  moved: boolean;
  breaking: boolean;
  timer: number;
}

const pixelTitle =
  '[text-shadow:3px_3px_0_#3a3a3a,6px_6px_0_rgba(0,0,0,0.35)] tracking-[0.12em] font-black font-mono';

function menuBtn(extra = '') {
  return cn(
    'w-full max-w-xs border-4 border-black bg-neutral-400 px-6 py-3 font-mono text-lg font-bold uppercase tracking-wider text-white',
    'shadow-[inset_-4px_-4px_0_#555,inset_4px_4px_0_#e5e5e5] [text-shadow:2px_2px_0_#3a3a3a]',
    'active:bg-neutral-500 disabled:opacity-60',
    extra,
  );
}

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const lookRef = useRef<LookState | null>(null);

  const [phase, setPhase] = useState<Phase>('loading');
  const [progress, setProgress] = useState(0);
  const [slot, setSlot] = useState(0);
  const [flying, setFlying] = useState(false);
  const [icons, setIcons] = useState<Record<number, string>>({});
  const [info, setInfo] = useState('');
  const [label, setLabel] = useState('');
  const [webglError, setWebglError] = useState(false);

  // engine lifecycle
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    let engine: Engine;
    try {
      engine = new Engine(mount, { onSlot: setSlot, onFly: setFlying });
    } catch (err) {
      console.error(err);
      setWebglError(true);
      return;
    }
    engineRef.current = engine;
    setIcons(makeIcons(engine.atlasCanvas));
    let alive = true;
    engine.init((p) => alive && setProgress(p)).then(() => {
      if (alive) setPhase('title');
    });
    return () => {
      alive = false;
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // running flag + autosave on pause
  useEffect(() => {
    const e = engineRef.current;
    if (!e) return;
    e.running = phase === 'playing';
    if (phase !== 'playing') {
      e.input.x = 0;
      e.input.y = 0;
      e.input.jump = false;
      e.input.down = false;
      e.setBreaking(false);
      e.save();
    }
  }, [phase]);

  // auto-pause when app goes to background
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) setPhase((p) => (p === 'playing' ? 'paused' : p));
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  // HUD info polling
  useEffect(() => {
    if (phase !== 'playing') return;
    const id = setInterval(() => {
      const e = engineRef.current;
      if (!e) return;
      const i = e.getInfo();
      setInfo(`${i.fps} FPS  X:${i.x.toFixed(0)} Y:${i.y.toFixed(0)} Z:${i.z.toFixed(0)}`);
    }, 400);
    return () => clearInterval(id);
  }, [phase]);

  // block name label
  useEffect(() => {
    setLabel(DEFS[HOTBAR[slot]].name);
    const t = setTimeout(() => setLabel(''), 1400);
    return () => clearTimeout(t);
  }, [slot]);

  const goFullscreen = useCallback(async () => {
    try {
      const el = document.documentElement;
      if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen();
      const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
      await o?.lock?.('landscape');
    } catch {
      /* not supported */
    }
  }, []);

  const play = () => {
    goFullscreen();
    setPhase('playing');
  };

  const newWorld = () => {
    if (!window.confirm('Создать новый мир? Текущий мир будет удалён.')) return;
    clearSave();
    window.location.reload();
  };

  // ---------- look / tap layer ----------
  const onLookDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const eng = engineRef.current;
    if (!eng) return;
    if (e.pointerType === 'mouse') {
      if (document.pointerLockElement !== e.currentTarget) {
        e.currentTarget.requestPointerLock?.();
        return;
      }
      if (e.button === 0) eng.setBreaking(true);
      else if (e.button === 2) eng.placeBlock();
      return;
    }
    if (lookRef.current) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const st: LookState = {
      id: e.pointerId,
      x: e.clientX,
      y: e.clientY,
      sx: e.clientX,
      sy: e.clientY,
      t: performance.now(),
      moved: false,
      breaking: false,
      timer: 0,
    };
    st.timer = window.setTimeout(() => {
      if (lookRef.current === st && !st.moved) {
        st.breaking = true;
        eng.setBreaking(true);
      }
    }, 320);
    lookRef.current = st;
  };

  const onLookMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const eng = engineRef.current;
    if (!eng) return;
    if (e.pointerType === 'mouse') {
      if (document.pointerLockElement === e.currentTarget) eng.look(e.movementX, e.movementY);
      return;
    }
    const st = lookRef.current;
    if (!st || st.id !== e.pointerId) return;
    eng.look(e.clientX - st.x, e.clientY - st.y);
    st.x = e.clientX;
    st.y = e.clientY;
    if (!st.moved && Math.hypot(st.x - st.sx, st.y - st.sy) > 12) st.moved = true;
  };

  const onLookUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const eng = engineRef.current;
    if (!eng) return;
    if (e.pointerType === 'mouse') {
      if (e.button === 0) eng.setBreaking(false);
      return;
    }
    const st = lookRef.current;
    if (!st || st.id !== e.pointerId) return;
    window.clearTimeout(st.timer);
    lookRef.current = null;
    if (st.breaking) eng.setBreaking(false);
    else if (!st.moved && performance.now() - st.t < 320 && e.type === 'pointerup') eng.placeBlock();
  };

  const eng = () => engineRef.current;
  const playing = phase === 'playing';

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-sky-300 text-white">
      {/* 3D canvas */}
      <div ref={mountRef} className="absolute inset-0" />

      {/* look / tap area */}
      {playing && (
        <div
          className="absolute inset-0 z-10 touch-none"
          onPointerDown={onLookDown}
          onPointerMove={onLookMove}
          onPointerUp={onLookUp}
          onPointerCancel={onLookUp}
          onContextMenu={(e) => e.preventDefault()}
        />
      )}

      {/* HUD */}
      {playing && (
        <>
          {/* crosshair */}
          <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 h-6 w-6 -translate-x-1/2 -translate-y-1/2">
            <div className="absolute left-0 top-1/2 h-[2px] w-full -translate-y-1/2 bg-white mix-blend-difference" />
            <div className="absolute left-1/2 top-0 h-full w-[2px] -translate-x-1/2 bg-white mix-blend-difference" />
          </div>

          {/* top bar */}
          <div
            className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between p-2"
            style={{
              paddingTop: 'max(8px, env(safe-area-inset-top))',
              paddingLeft: 'max(8px, env(safe-area-inset-left))',
              paddingRight: 'max(8px, env(safe-area-inset-right))',
            }}
          >
            <div className="rounded bg-black/35 px-2 py-1 font-mono text-[11px] leading-tight text-white/90">
              {info}
            </div>
            <div className="pointer-events-auto flex gap-2">
              <HoldButton
                label="Полёт"
                active={flying}
                className="h-10 w-10 text-lg"
                onDown={() => eng()?.toggleFly()}
              >
                🕊
              </HoldButton>
              <HoldButton label="Полный экран" className="h-10 w-10 text-lg" onDown={goFullscreen}>
                ⛶
              </HoldButton>
              <HoldButton label="Пауза" className="h-10 w-10 text-base font-black" onDown={() => setPhase('paused')}>
                II
              </HoldButton>
            </div>
          </div>

          {/* block name */}
          <div
            className={cn(
              'pointer-events-none absolute inset-x-0 z-30 text-center font-mono text-sm font-bold [text-shadow:2px_2px_0_#000] transition-opacity duration-300',
              label ? 'opacity-100' : 'opacity-0',
            )}
            style={{ bottom: 'calc(max(10px, env(safe-area-inset-bottom)) + min(8.2vw, 42px) + 22px)' }}
          >
            {label}
          </div>

          {/* hotbar */}
          <div
            className="absolute inset-x-0 z-30 flex justify-center"
            style={{ bottom: 'max(8px, env(safe-area-inset-bottom))' }}
          >
            <Hotbar icons={icons} slot={slot} onSelect={(i) => eng()?.setSlot(i)} />
          </div>

          {/* joystick */}
          <div
            className="absolute z-30"
            style={{
              left: 'max(20px, env(safe-area-inset-left))',
              bottom: 'calc(max(8px, env(safe-area-inset-bottom)) + min(8.2vw, 42px) + 24px)',
            }}
          >
            <Joystick
              onChange={(x, y) => {
                const e = eng();
                if (e) {
                  e.input.x = x;
                  e.input.y = y;
                }
              }}
            />
          </div>

          {/* action buttons */}
          <div
            className="absolute z-30 h-[190px] w-[190px]"
            style={{
              right: 'max(14px, env(safe-area-inset-right))',
              bottom: 'calc(max(8px, env(safe-area-inset-bottom)) + min(8.2vw, 42px) + 20px)',
            }}
          >
            <HoldButton
              label="Прыжок"
              className="absolute bottom-0 right-0 h-[78px] w-[78px] text-3xl"
              onDown={() => {
                const e = eng();
                if (!e) return;
                e.pressJump();
                e.input.jump = true;
              }}
              onUp={() => {
                const e = eng();
                if (e) e.input.jump = false;
              }}
            >
              ▲
            </HoldButton>
            <HoldButton
              label="Поставить блок"
              className="absolute bottom-3 right-[90px] h-[60px] w-[60px] text-2xl"
              onDown={() => eng()?.placeBlock()}
            >
              🧱
            </HoldButton>
            <HoldButton
              label="Сломать блок"
              className="absolute bottom-[92px] right-3 h-[62px] w-[62px] text-2xl"
              onDown={() => eng()?.setBreaking(true)}
              onUp={() => eng()?.setBreaking(false)}
            >
              ⛏
            </HoldButton>
            {flying && (
              <HoldButton
                label="Вниз"
                className="absolute bottom-[96px] right-[88px] h-[48px] w-[48px] text-xl"
                onDown={() => {
                  const e = eng();
                  if (e) e.input.down = true;
                }}
                onUp={() => {
                  const e = eng();
                  if (e) e.input.down = false;
                }}
              >
                ▼
              </HoldButton>
            )}
          </div>
        </>
      )}

      {/* title / loading */}
      {(phase === 'loading' || phase === 'title') && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-4 overflow-y-auto bg-gradient-to-b from-black/50 via-black/30 to-black/60 px-4 py-4">
          <h1 className={cn('text-center text-5xl text-neutral-200 sm:text-7xl', pixelTitle)}>MINICRAFT</h1>
          <p className="font-mono text-xs uppercase tracking-widest text-yellow-300 [text-shadow:2px_2px_0_#000]">
            Построй свой блочный мир
          </p>

          {webglError ? (
            <p className="max-w-xs text-center font-mono text-sm text-red-300">
              WebGL недоступен на этом устройстве/браузере.
            </p>
          ) : phase === 'loading' ? (
            <div className="w-full max-w-xs">
              <div className="h-5 border-4 border-black bg-neutral-800 p-[2px]">
                <div className="h-full bg-green-500 transition-[width]" style={{ width: `${Math.round(progress * 100)}%` }} />
              </div>
              <p className="mt-2 text-center font-mono text-xs uppercase tracking-wider text-white/80">
                Генерация мира… {Math.round(progress * 100)}%
              </p>
            </div>
          ) : (
            <button type="button" className={menuBtn()} onClick={play}>
              Играть
            </button>
          )}

          <div className="grid max-w-md grid-cols-1 gap-x-6 gap-y-1 rounded border-2 border-black/60 bg-black/50 p-3 font-mono text-[11px] leading-snug text-white/90 sm:grid-cols-2">
            <span>🕹 Левый джойстик — ходить</span>
            <span>👆 Тянуть по экрану — смотреть</span>
            <span>👆 Короткий тап — поставить блок</span>
            <span>✋ Удержание — ломать блок</span>
            <span>▲ Прыжок (двойной — полёт)</span>
            <span>🧱 / ⛏ Кнопки поставить / сломать</span>
            <span className="sm:col-span-2 text-white/60">ПК: WASD, пробел, мышь (клик), F — полёт, 1–0 — блоки</span>
          </div>
          <p className="text-center font-mono text-[10px] text-white/60 portrait:block landscape:hidden">
            📱 Для удобства поверните телефон горизонтально
          </p>
        </div>
      )}

      {/* pause */}
      {phase === 'paused' && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-3 overflow-y-auto bg-black/55 px-4 py-4">
          <h2 className={cn('mb-2 text-4xl text-neutral-200', pixelTitle)}>ПАУЗА</h2>
          <button type="button" className={menuBtn()} onClick={() => { goFullscreen(); setPhase('playing'); }}>
            Продолжить
          </button>
          <button type="button" className={menuBtn()} onClick={goFullscreen}>
            Полный экран
          </button>
          <button type="button" className={menuBtn('bg-red-700')} onClick={newWorld}>
            Новый мир
          </button>
        </div>
      )}
    </div>
  );
}
