import { useEffect, useMemo, useState } from 'react';
import { Fish as FishIcon, BookOpen, ShoppingBag, Coins, Waves, Search, RotateCcw, Anchor } from 'lucide-react';

type Fish = { id:number; name:string; rarity:string; value:number; color:string; habitat:string };
type Save = { coins:number; rod:number; caught:number[]; total:number; location:number };

const names = [
  'Pond Minnow','Bluegill','Golden Koi','River Bass','Moon Jelly','Crown Carp','Creek Chub','Sunfish','Silver Shiner','Mudskipper',
  'Redbreast Perch','Stone Loach','Pond Smelt','Daisy Dace','Pebble Goby','Willow Roach','Speckled Rudd','Amber Trout','Moss Catfish','Pine Pike',
  'Brook Trout','Glass Perch','Copper Barbel','Reedfish','Bluefin Bream','Marsh Gar','Spotted Tench','River Eel','Emerald Carp','Silver Salmon',
  'Mossback Bass','Silt Sturgeon','Crimson Shad','Rainfin Trout','Dusky Pike','River Snapper','Sapphire Roach','Longnose Gar','Willow Walleye','Thunder Catfish',
  'Coral Grouper','Tide Runner','Pearl Snapper','Lanternfish','Reef Angelfish','Velvet Ray','Moonray Koi','Ghost Mackerel','Jade Lionfish','Starry Flounder',
  'Sunset Marlin','Deepwater Eel','Opal Swordfish','Blue Comet Tuna','Abyss Crabfish','Stormfin Shark','Aurora Salmon','Crown Seahorse','Phantom Sturgeon','Celestial Coelacanth'
];
const colors = ['#75b9c9','#6fa4d9','#efb94f','#78ba91','#b9a1e9','#e88483','#db9567','#8ac4b7','#9aafda','#d2bd7d','#5e9fc0','#9bbd80'];
const rarities = ['Common','Uncommon','Rare','Epic','Legendary','Mythic'];
const habitats = ['Willow Pond','Mossy River','Moonlit Cove'];
const fishList: Fish[] = names.map((name,i) => ({
  id:i+1, name,
  rarity: i<10?'Common':i<24?'Uncommon':i<38?'Rare':i<48?'Epic':i<56?'Legendary':'Mythic',
  value: i<10?10+i*2:i<24?55+(i-10)*3:i<38?155+(i-24)*4:i<48?349+(i-38)*6:i<56?622+(i-48)*8:1184+(i-56)*12,
  color:colors[i%colors.length], habitat:habitats[Math.floor(i/20)]
}));
const rodNames = ['Twig Rod','Bamboo Rod','Reef Caster','Starfin Rod','Copper Creek','Willow Whip','Marsh Runner','Riverglass','Stormline','Coral Drift','Moonwake','Sapphire Reach','Tidebreaker','Emberfin','Glacier Pike','Aurora Reel','Leviathan','Tempest Crown','Abyss Walker','Mythic Current'];
const rodPrices = [0,80,150,260,400,580,800,1080,1400,1800,2300,2900,3600,4500,5600,7000,8700,10800,13400,16600];
const rodDescriptions = ['A simple starter rod for quiet ponds.','Light, flexible and easy to handle.','A sturdy rod for stronger currents.','A balanced all-rounder for longer casts.','A dependable upgrade with a smoother reel.','Springy wood helps control lively fish.','Built for reeds, weeds and tight spaces.','A fine tip for feeling delicate bites.','Extra backbone for heavy river fish.','A saltwater rod with a forgiving flex.','Sensitive enough for deep-water nibbles.','Long casts and a reliable drag.','Made for choppy water and stubborn catches.','A fast action rod for quick hook sets.','Firm and steady when the fight gets rough.','Precision gear for rare species.','A powerful rod for trophy-sized fish.','Premium balance with serious lifting power.','Designed for the deepest fishing grounds.','The finest rod in the Dinpel collection.'];
const defaultSave: Save = {coins:35,rod:0,caught:[],total:0,location:0};
function loadSave(): Save {
  try { const v=localStorage.getItem('dinpel-save-v1'); if(v) return {...defaultSave,...JSON.parse(v)}; } catch {}
  return defaultSave;
}

function FishSprite({fish, silhouette=false}:{fish:Fish;silhouette?:boolean}) {
  const c = silhouette ? '#8ea39a' : fish.color;
  const shade = silhouette ? '#738a7e' : '#315e59';
  return <svg className="fish-art" viewBox="0 0 90 56" role="img" aria-label={silhouette?'Undiscovered fish':fish.name} shapeRendering="crispEdges">
    <path d="M22 28L5 10L7 28L5 46Z" fill={shade}/>
    <path d="M22 20L36 8L59 12L72 23L72 33L59 44L36 48L22 36Z" fill={c} stroke={shade} strokeWidth="3"/>
    <path d="M40 13L48 3L57 14Z" fill={silhouette?'#9fb1a6':'#f5d48b'} stroke={shade} strokeWidth="2"/>
    <path d="M42 43L51 53L59 42Z" fill={silhouette?'#9fb1a6':'#f5d48b'} stroke={shade} strokeWidth="2"/>
    <rect x="58" y="20" width="6" height="6" fill={shade}/><rect x="59" y="20" width="2" height="2" fill="#fff8e8"/>
    <path d="M31 23L38 28L31 33" fill="none" stroke={silhouette?'#8ea39a':'#f8e8b8'} strokeWidth="2"/>
  </svg>;
}

export default function App() {
  const [save,setSave] = useState<Save>(loadSave);
  const [phase,setPhase] = useState<'ready'|'waiting'|'bite'|'reeling'|'caught'>('ready');
  const [progress,setProgress] = useState(0);
  const [current,setCurrent] = useState<Fish|null>(null);
  const [message,setMessage] = useState('The water is calm. Cast your line!');
  const [tab,setTab] = useState<'book'|'shop'>('book');
  const [query,setQuery] = useState('');
  const [rarity,setRarity] = useState('All');
  const [notice,setNotice] = useState('');
  const rod = save.rod;
  const locationFish = fishList.filter(f=>habitats.indexOf(f.habitat)===save.location);
  const caughtSet = new Set(save.caught);
  useEffect(()=>{localStorage.setItem('dinpel-save-v1',JSON.stringify(save));},[save]);
  useEffect(()=>{
    if(phase!=='waiting') return;
    const timer=window.setTimeout(()=>{
      const pool=locationFish.slice(0,Math.min(locationFish.length,5+rod*2));
      const fish=pool[Math.floor(Math.random()*pool.length)] || fishList[0];
      setCurrent(fish); setPhase('bite'); setMessage('A bite! Tap Reel to bring it in.');
    },1500+Math.random()*1800);
    return ()=>window.clearTimeout(timer);
  },[phase,rod,save.location]);

  const filtered = useMemo(()=>fishList.filter(f=>
    (rarity==='All'||f.rarity===rarity) &&
    (f.name.toLowerCase().includes(query.toLowerCase())||f.habitat.toLowerCase().includes(query.toLowerCase()))
  ),[query,rarity]);

  function cast() {
    if(phase==='waiting'||phase==='bite'||phase==='reeling') return;
    setCurrent(null); setProgress(0); setPhase('waiting'); setMessage('Line out… watch the bobber.');
  }
  function reel() {
    if(phase==='bite'){setPhase('reeling');setProgress(Math.min(100,25+rod*2.3));setMessage('Keep reeling!');return;}
    if(phase==='reeling'){
      const next=Math.min(100,progress+14+rod*1.5);
      setProgress(next);
      if(next>=100 && current){
        setSave(s=>({...s,coins:s.coins+current.value,caught:Array.from(new Set([...s.caught,current.id])),total:s.total+1}));
        setPhase('caught');setMessage(`${current.name} landed! +${current.value} coins`);setNotice(`New catch: ${current.name}`);
      }
    }
  }
  function buyRod(i:number) {
    if(i<=save.rod){setNotice('You already own this rod or a better one.');return;}
    if(i!==save.rod+1){setNotice('Unlock the rods in order to keep progressing.');return;}
    if(save.coins<rodPrices[i]){setNotice('Not enough coins yet. Keep fishing!');return;}
    setSave(s=>({...s,coins:s.coins-rodPrices[i],rod:i}));
    setNotice(`${rodNames[i]} unlocked!`);
  }
  function unlockLocation(i:number) {
    const cost=[0,450,1800][i];
    if(i<=save.location){setNotice('This location is already unlocked.');return;}
    if(i!==save.location+1){setNotice('Explore locations in order.');return;}
    if(save.rod<([0,5,10][i]||0)){setNotice(`Upgrade your rod to power ${[0,5,10][i]} first.`);return;}
    if(save.coins<cost){setNotice('Not enough coins for this location.');return;}
    setSave(s=>({...s,coins:s.coins-cost,location:i}));setNotice(`${habitats[i]} unlocked!`);
  }
  function reset(){if(confirm('Reset all progress and start over?')){setSave(defaultSave);setPhase('ready');setProgress(0);setCurrent(null);setMessage('The water is calm. Cast your line!');setNotice('Progress reset.');}}

  return <main className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Anchor size={23}/></div><div><div className="brand-title">DINPEL <span>FISHING</span></div><div className="brand-sub">A little escape by the water</div></div></div>
      <div className="wallet"><Coins size={20}/><strong>{save.coins.toLocaleString()}</strong><span>coins</span></div>
    </header>

    <section className={`hero location-${save.location}`}>
      <div className="sky"><span className="sun-disc"/><span className="cloud cloud-a"/><span className="cloud cloud-b"/></div>
      <div className="distant-hills"><span/><span/><span/></div>
      <div className="tree tree-a"/><div className="tree tree-b"/>
      <div className="hero-copy"><span className="eyebrow"><Waves size={14}/> LOCATION {save.location+1} OF 3</span><h1>{habitats[save.location]}</h1><p>{['A peaceful pond for your first catches.','Follow the river to find stronger fish.','Rare deep-water species glow beneath the moon.'][save.location]}</p></div>
      <div className="water"><div className="ripples ripple-a"/><div className="ripples ripple-b"/><div className="bobber" style={{left:phase==='ready'?'68%':phase==='waiting'?'58%':'62%'}}/><div className="line" style={{left:phase==='ready'?'68%':phase==='waiting'?'58%':'62%'}}/></div>
      <div className="shore"><div className="angler"><div className="head"/><div className="body"/><div className="arm"/></div><div className="dock"/></div>
      <div className="weather"><span>☀</span> Good fishing weather</div>
    </section>

    <section className="stats">
      <div className="stat"><span className="stat-icon mint"><FishIcon size={18}/></span><div><strong>{save.total}</strong><small>Fish caught</small></div></div>
      <div className="stat"><span className="stat-icon gold"><BookOpen size={18}/></span><div><strong>{save.caught.length}<em>/60</em></strong><small>Fish discovered</small></div></div>
      <div className="stat"><span className="stat-icon blue"><Anchor size={18}/></span><div><strong>{rod+1}<em>/20</em></strong><small>Rod level</small></div></div>
    </section>

    <section className="game-grid">
      <div className="panel fishing-panel">
        <div className="panel-heading"><div><span className="eyebrow">YOUR SPOT</span><h2>Ready to fish?</h2></div><span className={`status ${phase}`}>{phase==='ready'?'READY':phase==='waiting'?'WAITING':phase==='bite'?'BITE!':phase==='reeling'?'REELING':'LANDED'}</span></div>
        <div className="current-rod"><div className="rod-icon">╱</div><div><strong>{rodNames[rod]}</strong><small>Power {rod+1} · {rodDescriptions[rod]}</small></div></div>
        <p className="game-message">{message}</p>
        {phase==='reeling'&&<div className="progress-wrap"><div className="progress-label"><span>Reel tension</span><strong>{Math.round(progress)}%</strong></div><div className="progress-track"><div style={{width:`${progress}%`}}/></div></div>}
        {current&&phase!=='ready'&&phase!=='waiting'&&<div className="catch-preview"><FishSprite fish={current}/><div><strong>{current.name}</strong><small>{current.rarity} · worth {current.value} coins</small></div></div>}
        <div className="action-row">
          {phase==='ready'||phase==='caught'?<button className="primary" onClick={cast}><Waves size={18}/> Cast line</button>:phase==='waiting'?<button className="primary" disabled><span className="spinner"/> Waiting for a bite…</button>:<button className="primary" onClick={reel}><Anchor size={18}/>{phase==='bite'?'Reel in!':'Keep reeling'}</button>}
          {phase==='reeling'&&<button className="secondary" onClick={()=>{setPhase('ready');setCurrent(null);setMessage('The fish got away. Try another cast!')}}>Let go</button>}
        </div>
        <p className="helper">Tip: stronger rods can attract more valuable fish.</p>
      </div>

      <div className="panel location-panel">
        <div className="panel-heading"><div><span className="eyebrow">EXPLORE</span><h2>Fishing spots</h2></div><span className="tiny-count">3 places</span></div>
        {habitats.map((h,i)=><div className={`location-row ${save.location===i?'selected':''}`} key={h}>
          <div className={`location-thumb thumb-${i}`}><Waves size={22}/></div><div className="location-info"><strong>{h}</strong><small>{['Common catches','River favourites','Rare deep-water fish'][i]}</small></div>
          {i<=save.location?<button className={save.location===i?'current-btn':'small-btn'} onClick={()=>{setSave(s=>({...s,location:i}));setNotice(`${h} selected.`)}}>{save.location===i?'Here':'Visit'}</button>:<button className="small-btn" onClick={()=>unlockLocation(i)}>{[0,450,1800][i].toLocaleString()} <Coins size={12}/></button>}
        </div>)}
      </div>
    </section>

    <section className="panel collection-panel">
      <div className="collection-head"><div><span className="eyebrow">YOUR JOURNAL</span><h2>Collection & gear</h2></div><div className="tabs"><button className={tab==='book'?'active':''} onClick={()=>setTab('book')}><BookOpen size={15}/> Fish book</button><button className={tab==='shop'?'active':''} onClick={()=>setTab('shop')}><ShoppingBag size={15}/> Rod shop</button></div></div>
      {tab==='book'?<>
        <div className="collection-tools"><label className="search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search fish or habitat…"/></label><select value={rarity} onChange={e=>setRarity(e.target.value)}>{['All',...rarities].map(r=><option key={r}>{r}</option>)}</select></div>
        <div className="fish-grid">{filtered.map(f=>{const known=caughtSet.has(f.id);return <article className={`fish-card ${known?'known':'unknown'}`} key={f.id}><div className="fish-illustration"><FishSprite fish={f} silhouette={!known}/>{known&&<span className={`rarity-dot rarity-${f.rarity.toLowerCase()}`}/>}</div><div className="fish-card-name">{known?f.name:'??????'}</div><small>{known?f.rarity:f.habitat}</small>{known&&<b>{f.value} <Coins size={11}/></b>}</article>})}</div>
        <p className="collection-foot">{save.caught.length} of 60 species discovered · Fish in your current waters to fill the journal.</p>
      </>:<div className="rod-grid">{rodNames.map((name,i)=>{const owned=i<=save.rod;return <article className={`rod-card ${owned?'owned':''}`} key={name}><div className={`rod-art rod-${i%5}`}>╱<span>⌁</span></div><div className="rod-details"><strong>{name}</strong><small>Power {i+1} · {rodDescriptions[i]}</small><div className="rod-buy-row">{owned?<span className="owned-label">✓ {i===save.rod?'Equipped':'Owned'}</span>:<span className="price"><Coins size={12}/>{rodPrices[i].toLocaleString()}</span>}{!owned&&<button disabled={i!==save.rod+1||save.coins<rodPrices[i]} onClick={()=>buyRod(i)}>{i===save.rod+1?'Unlock':'Locked'}</button>}</div></div></article>})}</div>}
    </section>
    <footer><span>DINPEL FISHING</span><span>Made for slow afternoons.</span><button className="reset" onClick={reset}><RotateCcw size={13}/> Reset progress</button></footer>
    {notice&&<button className="toast" onClick={()=>setNotice('')}>{notice}<span>×</span></button>}
  </main>;
}