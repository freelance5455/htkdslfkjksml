import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { AppProvider, useApp } from './context/AppContext';
import { AuditLogView } from './components/AuditLogView';
import { BackupRestoreView } from './components/BackupRestoreView';
import { CommitteeView } from './components/CommitteeView';
import { CustomModuleView } from './components/CustomModuleView';
import { DashboardView } from './components/DashboardView';
import { Header } from './components/Header';
import { LoanView } from './components/LoanView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { RecycleBinView } from './components/RecycleBinView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { Sidebar } from './components/Sidebar';

const AppShell: React.FC = () => {
  const { loading, error, activeRoute, toastMessage, snapshot } = useApp();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white font-display font-bold flex items-center justify-center mx-auto">
            SU
          </div>
          <p className="text-sm font-medium text-slate-600">Loading IndexedDB workspace...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="max-w-md rounded-xl border border-red-200 bg-white p-6 text-center space-y-2">
          <AlertCircle className="w-8 h-8 text-red-600 mx-auto" aria-hidden="true" />
          <h1 className="font-display text-base font-bold text-slate-900">Storage Error</h1>
          <p className="text-sm text-slate-600">{error}</p>
        </div>
      </div>
    );
  }

  const renderMain = () => {
    if (activeRoute === 'dashboard') return <DashboardView />;
    if (activeRoute === 'loans') return <LoanView />;
    if (activeRoute === 'committees') return <CommitteeView />;
    if (activeRoute === 'reports') return <ReportsView />;
    if (activeRoute === 'settings') return <SettingsView />;
    if (activeRoute === 'backup') return <BackupRestoreView />;
    if (activeRoute === 'recycle-bin') return <RecycleBinView />;
    if (activeRoute === 'audit-log') return <AuditLogView />;
    if (activeRoute.startsWith('module:')) {
      return <CustomModuleView moduleId={activeRoute.replace('module:', '')} />;
    }
    return <DashboardView />;
  };

  return (
    <div
      className="min-h-screen flex"
      style={{
        backgroundColor: snapshot.settings.theme.backgroundColor,
        color: snapshot.settings.theme.textColor,
      }}
    >
      <Sidebar mobileOpen={mobileNavOpen} onCloseMobile={() => setMobileNavOpen(false)} />

      <div className="flex-1 min-w-0 flex flex-col">
        <Header onOpenMobileNav={() => setMobileNavOpen(true)} />
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {renderMain()}
        </main>
      </div>

      {/* Toast Feedback */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className={`fixed bottom-4 right-4 z-50 max-w-sm rounded-xl px-4 py-3 shadow-xl border text-xs font-semibold flex items-start gap-2.5 no-print ${
            toastMessage.type === 'error'
              ? 'bg-red-600 text-white border-red-700'
              : toastMessage.type === 'info'
                ? 'bg-slate-900 text-white border-slate-800'
                : 'bg-emerald-700 text-white border-emerald-800'
          }`}
        >
          {toastMessage.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : toastMessage.type === 'info' ? (
            <Info className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          )}
          <span className="whitespace-pre-line">{toastMessage.text}</span>
        </div>
      )}

      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
