import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Navigation } from "./components/Navigation";
import { SmartChat } from "./components/SmartChat";
import { VoiceCommand } from "./components/VoiceCommand";
import { ImageStudio } from "./components/ImageStudio";
import { MediaEditor } from "./components/MediaEditor";
import { ContentStudio } from "./components/ContentStudio";
import { MemoryAndPrivacy } from "./components/MemoryAndPrivacy";
import { AboutModal } from "./components/AboutModal";
import { TabType, Language, UserMemory, GeneratedImageItem } from "./types";
import { loadUserMemory, saveUserMemory, loadSavedImages, saveImages } from "./utils/storage";

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>("chat");
  const [language, setLanguage] = useState<Language>("bn");
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [isAboutOpen, setIsAboutOpen] = useState<boolean>(false);

  const [memory, setMemory] = useState<UserMemory>(() => loadUserMemory());
  const [savedImages, setSavedImages] = useState<GeneratedImageItem[]>(() => loadSavedImages());
  const [editorInitialImage, setEditorInitialImage] = useState<string | undefined>(undefined);

  // Monitor real network online/offline events
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const handleUpdateMemory = (updated: UserMemory) => {
    setMemory(updated);
    saveUserMemory(updated);
  };

  const handleSaveImage = (item: GeneratedImageItem) => {
    const updated = [item, ...savedImages.filter((img) => img.id !== item.id)];
    setSavedImages(updated);
    saveImages(updated);
  };

  const handleSelectForEdit = (imageUrl: string) => {
    setEditorInitialImage(imageUrl);
    setCurrentTab("editor");
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col selection:bg-indigo-500/30 selection:text-indigo-200 relative overflow-x-hidden font-sans">
      {/* Ambient background glow orbs */}
      <div className="fixed top-0 left-1/4 -z-10 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed bottom-1/4 right-1/4 -z-10 w-[450px] h-[450px] bg-cyan-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Header */}
      <Header
        language={language}
        onLanguageChange={setLanguage}
        isOffline={isOffline}
        onToggleOffline={() => setIsOffline((prev) => !prev)}
        onOpenAbout={() => setIsAboutOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full flex flex-col">
        {currentTab === "chat" && (
          <SmartChat
            language={language}
            memory={memory}
            isOffline={isOffline}
          />
        )}

        {currentTab === "voice" && (
          <VoiceCommand
            language={language}
            memory={memory}
            isOffline={isOffline}
          />
        )}

        {currentTab === "image" && (
          <ImageStudio
            onSelectForEdit={handleSelectForEdit}
            savedImages={savedImages}
            onSaveImage={handleSaveImage}
          />
        )}

        {currentTab === "editor" && (
          <MediaEditor initialImageUrl={editorInitialImage} />
        )}

        {currentTab === "content" && (
          <ContentStudio language={language} />
        )}

        {currentTab === "memory" && (
          <MemoryAndPrivacy
            memory={memory}
            onUpdateMemory={handleUpdateMemory}
          />
        )}
      </main>

      {/* One-handed ergonomic bottom navigation */}
      <Navigation
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        voiceListening={currentTab === "voice"}
      />

      {/* About & Privacy Modal */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
      />
    </div>
  );
}
