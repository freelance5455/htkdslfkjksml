import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, type GameStats } from './game/engine';
import { audio } from './game/audio';
import {
  type HighScore,
  loadHighScores,
  qualifies,
  insertHighScore,
  getLastName,
  setLastName,
  formatTime,
} from './game/highscores';
import { cn } from './utils/cn';

type Screen = 'start' | 'playing' | 'paused' | 'gameover';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>('start');
  const screenRef = useRef<Screen>('start');
  const [stats, setStats] = useState<GameStats | null>(null);
  const [scores, setScores] = useState<HighScore[]>(() => loadHighScores());
  const [newIndex, setNewIndex] = useState<number>(-1);
  const [pendingEntry, setPendingEntry] = useState(false);
  const [name, setName] = useState(() => getLastName());
  const [muted, setMuted] = useState(audio.muted);
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    screenRef.current = screen;
  }, [screen]);

  // Boot the engine once
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas, {
      onGameOver: (s) => {
        setStats(s);
        const list = loadHighScores();
        if (qualifies(list, s.score)) {
          setPendingEntry(true);
          setNewIndex(-1);
        } else {
          setPendingEntry(false);
          setNewIndex(-1);
        }
        setScreen('gameover');
      },
      onPauseChange: (p) => setScreen(p ? 'paused' : 'playing'),
    });
    gameRef.current = game;
    const touchDetect = () => setIsTouch(true);
    window.addEventListener('touchstart', touchDetect, { once: true, passive: true });
    if (window.matchMedia('(pointer: coarse)').matches) setIsTouch(true);
    return () => {
      game.destroy();
      window.removeEventListener('touchstart', touchDetect);
    };
  }, []);

  const startGame = useCallback(() => {
    audio.unlock();
    audio.ui();
    setPendingEntry(false);
    setNewIndex(-1);
    setScreen('playing');
    gameRef.current?.start();
  }, []);

  const quitToMenu = useCallback(() => {
    audio.ui();
    gameRef.current?.stop();
    setScores(loadHighScores());
    setScreen('start');
  }, []);

  const submitScore = useCallback(() => {
    if (!stats) return;
    const clean = (name.trim().toUpperCase().slice(0, 10) || 'ACE');
    setLastName(clean);
    setName(clean);
    const res = insertHighScore(loadHighScores(), {
      name: clean,
      score: stats.score,
      kills: stats.kills,
      headshots: stats.headshots,
      time: stats.time,
      date: Date.now(),
    });
    setScores(res.list);
    setNewIndex(res.index);
    setPendingEntry(false);
    audio.ui();
  }, [name, stats]);

  // Global keyboard shortcuts for menus
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = screenRef.current;
      const k = e.key.toLowerCase();
      if (s === 'start' && (k === 'enter' || k === ' ')) {
        e.preventDefault();
        startGame();
      } else if (s === 'gameover') {
        if (pendingEntry) {
          if (k === 'enter') submitScore();
          return;
        }
        if (k === 'enter' || k === ' ' || k === 'r') {
          e.preventDefault();
          startGame();
        }
      } else if (s === 'paused' && k === 'r') {
        startGame();
      }
      if (k === 'm') setMuted(audio.muted);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [startGame, submitScore, pendingEntry]);

  const toggleMute = () => {
    audio.unlock();
    audio.setMuted(!audio.muted);
    setMuted(audio.muted);
  };

  const best = scores.length ? scores[0].score : 0;

  return (
    <div className="relative h-dvh w-screen overflow-hidden bg-[#05080a] text-[#dfe8d8] select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" style={{ cursor: screen === 'playing' ? 'none' : 'default' }} />

      {/* In-game chrome */}
      {screen === 'playing' && (
        <>
          <button
            onClick={() => gameRef.current?.setPaused(true)}
            className="absolute top-[72px] right-4 z-10 flex h-10 w-10 items-center justify-center rounded-md border border-[#9dff7a]/30 bg-black/40 text-[#9dff7a] backdrop-blur-sm active:scale-95 sm:top-20"
            aria-label="Pause"
          >
            <span className="flex gap-1">
              <span className="block h-4 w-1.5 bg-current" />
              <span className="block h-4 w-1.5 bg-current" />
            </span>
          </button>
          {isTouch && (
            <>
              <button
                onPointerDown={(e) => {
                  e.preventDefault();
                  gameRef.current?.fire();
                }}
                className="absolute right-5 bottom-24 z-10 flex h-24 w-24 items-center justify-center rounded-full border-4 border-[#ff3b4a]/70 bg-[#b3121f]/50 font-[Black_Ops_One,Impact,sans-serif] text-lg tracking-widest text-white shadow-[0_0_30px_rgba(255,59,74,0.4)] backdrop-blur-sm active:scale-90 active:bg-[#ff3b4a]/70"
                aria-label="Fire"
              >
                FIRE
              </button>
              <button
                onPointerDown={(e) => {
                  e.preventDefault();
                  gameRef.current?.reload();
                }}
                className="absolute right-[136px] bottom-[116px] z-10 flex h-14 w-14 items-center justify-center rounded-full border-2 border-[#ffb648]/70 bg-black/50 font-[Black_Ops_One,Impact,sans-serif] text-[11px] tracking-wider text-[#ffb648] backdrop-blur-sm active:scale-90"
                aria-label="Reload"
              >
                RLD
              </button>
            </>
          )}
        </>
      )}

      {/* START */}
      {screen === 'start' && (
        <Overlay>
          <div className="flex w-full max-w-3xl flex-col items-center gap-6 px-5 py-8 md:flex-row md:items-start md:gap-10">
            <div className="flex flex-1 flex-col items-center text-center md:items-start md:text-left">
              <div className="mb-2 font-mono text-xs tracking-[0.4em] text-[#9dff7a]/70">SECTOR 7 • NIGHT WATCH</div>
              <h1 className="font-[Black_Ops_One,Impact,sans-serif] text-5xl leading-none tracking-wide text-[#9dff7a] drop-shadow-[0_0_18px_rgba(157,255,122,0.45)] sm:text-6xl md:text-7xl">
                DEAD
                <br />
                <span className="text-[#ff3b4a] drop-shadow-[0_0_18px_rgba(255,59,74,0.5)]">ZONE</span>
              </h1>
              <div className="mt-1 font-[Black_Ops_One,Impact,sans-serif] text-xl tracking-[0.3em] text-[#ffb648]">SNIPER</div>
              <p className="mt-4 max-w-sm text-sm text-[#dfe8d8]/70">
                Hold the line from the tower. Headshots pay double, long shots pay extra, and chaining kills multiplies everything. Don&apos;t let them reach you.
              </p>

              <button
                onClick={startGame}
                className="group mt-6 rounded-md border-2 border-[#9dff7a] bg-[#9dff7a]/10 px-10 py-3 font-[Black_Ops_One,Impact,sans-serif] text-2xl tracking-[0.2em] text-[#9dff7a] shadow-[0_0_30px_rgba(157,255,122,0.25)] transition hover:bg-[#9dff7a] hover:text-[#05080a] active:scale-95"
              >
                DEPLOY
              </button>
              <div className="mt-2 font-mono text-[11px] text-[#dfe8d8]/40">press ENTER or SPACE</div>

              <div className="mt-6 grid w-full max-w-sm grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[11px] text-[#dfe8d8]/70 sm:text-xs">
                <Ctl k="MOUSE / WASD" v="aim" />
                <Ctl k="CLICK / SPACE" v="fire" />
                <Ctl k="SHIFT" v="steady aim" />
                <Ctl k="R" v="reload" />
                <Ctl k="DRAG + TAP" v="touch aim/fire" />
                <Ctl k="ESC / P" v="pause" />
              </div>

              <button onClick={toggleMute} className="mt-4 font-mono text-xs text-[#dfe8d8]/50 underline-offset-4 hover:text-[#9dff7a] hover:underline">
                {muted ? '🔇 SOUND OFF' : '🔊 SOUND ON'} (M)
              </button>
            </div>

            <div className="w-full max-w-sm md:w-72">
              <ScoreTable scores={scores} highlight={-1} />
              {best > 0 && (
                <div className="mt-3 text-center font-mono text-xs text-[#ffb648]/80">
                  PERSONAL BEST: <span className="text-[#ffb648]">{best.toLocaleString()}</span>
                </div>
              )}
            </div>
          </div>
        </Overlay>
      )}

      {/* PAUSED */}
      {screen === 'paused' && (
        <Overlay dim>
          <div className="flex flex-col items-center gap-5 px-6 text-center">
            <h2 className="font-[Black_Ops_One,Impact,sans-serif] text-5xl tracking-[0.2em] text-[#ffb648]">PAUSED</h2>
            <div className="font-mono text-sm text-[#dfe8d8]/60">
              SCORE {gameRef.current?.score.toLocaleString() ?? 0} • KILLS {gameRef.current?.kills ?? 0}
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Btn primary onClick={() => gameRef.current?.setPaused(false)}>
                RESUME
              </Btn>
              <Btn onClick={startGame}>RESTART (R)</Btn>
              <Btn onClick={quitToMenu}>QUIT</Btn>
            </div>
            <button onClick={toggleMute} className="font-mono text-xs text-[#dfe8d8]/50 hover:text-[#9dff7a]">
              {muted ? '🔇 SOUND OFF' : '🔊 SOUND ON'} (M)
            </button>
          </div>
        </Overlay>
      )}

      {/* GAME OVER */}
      {screen === 'gameover' && stats && (
        <Overlay dim>
          <div className="flex w-full max-w-3xl flex-col items-center gap-6 px-5 py-6 md:flex-row md:items-start md:gap-10">
            <div className="flex flex-1 flex-col items-center text-center md:items-start md:text-left">
              <div className="font-mono text-xs tracking-[0.4em] text-[#ff3b4a]/80">POSITION OVERRUN</div>
              <h2 className="font-[Black_Ops_One,Impact,sans-serif] text-5xl leading-none tracking-wide text-[#ff3b4a] drop-shadow-[0_0_18px_rgba(255,59,74,0.5)] sm:text-6xl">
                KIA
              </h2>
              <div className="mt-4 font-mono text-xs text-[#9dff7a]/70">FINAL SCORE</div>
              <div className="font-[Black_Ops_One,Impact,sans-serif] text-5xl text-[#9dff7a] drop-shadow-[0_0_14px_rgba(157,255,122,0.5)]">
                {stats.score.toLocaleString()}
              </div>
              {newIndex === 0 && <div className="mt-1 animate-pulse font-mono text-sm text-[#ffb648]">★ NEW HIGH SCORE ★</div>}

              <div className="mt-4 grid grid-cols-3 gap-x-6 gap-y-2 font-mono text-xs sm:grid-cols-5">
                <Stat label="KILLS" v={stats.kills} />
                <Stat label="HEADSHOTS" v={stats.headshots} />
                <Stat label="ACCURACY" v={`${stats.accuracy}%`} />
                <Stat label="BEST COMBO" v={stats.maxCombo} />
                <Stat label="SURVIVED" v={formatTime(stats.time)} />
              </div>

              {pendingEntry ? (
                <div className="mt-5 flex w-full max-w-xs flex-col gap-2">
                  <label className="font-mono text-xs text-[#ffb648]">YOU MADE THE BOARD — ENTER CALLSIGN</label>
                  <div className="flex gap-2">
                    <input
                      autoFocus
                      value={name}
                      maxLength={10}
                      onChange={(e) => setName(e.target.value.toUpperCase())}
                      onKeyDown={(e) => e.key === 'Enter' && submitScore()}
                      className="min-w-0 flex-1 rounded border border-[#9dff7a]/40 bg-black/50 px-3 py-2 font-mono text-lg tracking-widest text-[#9dff7a] uppercase outline-none focus:border-[#9dff7a]"
                    />
                    <Btn primary onClick={submitScore}>
                      SAVE
                    </Btn>
                  </div>
                </div>
              ) : (
                <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                  <Btn primary onClick={startGame}>
                    REDEPLOY
                  </Btn>
                  <Btn onClick={quitToMenu}>MENU</Btn>
                </div>
              )}
              {!pendingEntry && <div className="mt-2 font-mono text-[11px] text-[#dfe8d8]/40">ENTER / SPACE / R to restart instantly</div>}
            </div>
            <div className="w-full max-w-sm md:w-72">
              <ScoreTable scores={scores} highlight={newIndex} />
            </div>
          </div>
        </Overlay>
      )}
    </div>
  );
}

function Overlay({ children, dim }: { children: React.ReactNode; dim?: boolean }) {
  return (
    <div
      className={cn(
        'absolute inset-0 z-20 flex items-center justify-center overflow-y-auto',
        dim ? 'bg-[#05080a]/70 backdrop-blur-[2px]' : 'bg-[radial-gradient(ellipse_at_center,rgba(10,20,14,0.82),rgba(5,8,10,0.96))]',
      )}
    >
      <div className="pointer-events-none absolute inset-0 opacity-[0.07] [background:repeating-linear-gradient(0deg,transparent_0_3px,#9dff7a_3px_4px)]" />
      <div className="relative w-full">{children}</div>
    </div>
  );
}

function Btn({ children, onClick, primary }: { children: React.ReactNode; onClick: () => void; primary?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-md border-2 px-6 py-2.5 font-[Black_Ops_One,Impact,sans-serif] text-base tracking-[0.15em] transition active:scale-95',
        primary
          ? 'border-[#9dff7a] bg-[#9dff7a]/10 text-[#9dff7a] shadow-[0_0_24px_rgba(157,255,122,0.25)] hover:bg-[#9dff7a] hover:text-[#05080a]'
          : 'border-[#dfe8d8]/30 text-[#dfe8d8]/80 hover:border-[#dfe8d8] hover:text-white',
      )}
    >
      {children}
    </button>
  );
}

function Ctl({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-2 border-b border-[#dfe8d8]/10 pb-1">
      <span className="text-[#ffb648]">{k}</span>
      <span className="text-[#dfe8d8]/60">{v}</span>
    </div>
  );
}

function Stat({ label, v }: { label: string; v: number | string }) {
  return (
    <div>
      <div className="text-[10px] text-[#dfe8d8]/50">{label}</div>
      <div className="text-lg text-[#dfe8d8]">{v}</div>
    </div>
  );
}

function ScoreTable({ scores, highlight }: { scores: HighScore[]; highlight: number }) {
  return (
    <div className="rounded-lg border border-[#9dff7a]/25 bg-black/40 p-3 backdrop-blur-sm">
      <div className="mb-2 flex items-center justify-between font-[Black_Ops_One,Impact,sans-serif] text-sm tracking-[0.25em] text-[#ffb648]">
        <span>TOP SNIPERS</span>
        <span className="font-mono text-[10px] tracking-normal text-[#dfe8d8]/40">LOCAL</span>
      </div>
      {scores.length === 0 ? (
        <div className="py-6 text-center font-mono text-xs text-[#dfe8d8]/40">No records yet. Be the first.</div>
      ) : (
        <table className="w-full font-mono text-xs">
          <thead>
            <tr className="text-[10px] text-[#dfe8d8]/40">
              <th className="pb-1 text-left font-normal">#</th>
              <th className="pb-1 text-left font-normal">NAME</th>
              <th className="pb-1 text-right font-normal">SCORE</th>
              <th className="hidden pb-1 text-right font-normal sm:table-cell">HS</th>
              <th className="pb-1 text-right font-normal">TIME</th>
            </tr>
          </thead>
          <tbody>
            {scores.map((s, i) => (
              <tr
                key={s.date + s.name + i}
                className={cn(
                  'border-t border-[#dfe8d8]/8',
                  i === highlight ? 'bg-[#ffb648]/15 text-[#ffb648]' : i === 0 ? 'text-[#9dff7a]' : 'text-[#dfe8d8]/80',
                )}
              >
                <td className="py-1">{i + 1}</td>
                <td className="py-1 truncate">{s.name}</td>
                <td className="py-1 text-right">{s.score.toLocaleString()}</td>
                <td className="hidden py-1 text-right sm:table-cell">{s.headshots}</td>
                <td className="py-1 text-right">{formatTime(s.time)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
