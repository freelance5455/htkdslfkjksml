import { useState, useEffect, useRef, useCallback } from 'react';
import { GameEngine } from './game/engine';
import { GameCanvas } from './components/GameCanvas';
import { HUD } from './components/HUD';
import { MobileControls } from './components/MobileControls';
import { InventoryModal } from './components/InventoryModal';
import { CraftingModal } from './components/CraftingModal';
import { BuildingModal } from './components/BuildingModal';
import { SkillTreeModal } from './components/SkillTreeModal';
import { GameOverModal } from './components/GameOverModal';
import { AssetAuditModal } from './components/AssetAuditModal';
import { RotateDeviceModal } from './components/RotateDeviceModal';
import { sounds } from './game/audio';
import { hasSavedGameInStorage } from './game/save';
import { Play, RotateCcw, Info, Volume2, ShieldCheck, Sparkles } from 'lucide-react';

export default function App() {
  const engineRef = useRef<GameEngine | null>(null);
  const [, setTickCounter] = useState(0);

  // Modals state
  const [isPlaying, setIsPlaying] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [showCrafting, setShowCrafting] = useState(false);
  const [showBuilding, setShowBuilding] = useState(false);
  const [showSkillTree, setShowSkillTree] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const [showAssetAudit, setShowAssetAudit] = useState(false);
  const [showHelpGuide, setShowHelpGuide] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [hasSave, setHasSave] = useState(false);
  const [isPortrait, setIsPortrait] = useState(false);
  const [dismissRotateWarning, setDismissRotateWarning] = useState(false);

  // Orientation detector for mobile landscape recommendation
  useEffect(() => {
    const checkOrientation = () => {
      const isTouchOrMobile = window.innerWidth <= 850 || 'ontouchstart' in window;
      const portrait = window.innerHeight > window.innerWidth && isTouchOrMobile;
      setIsPortrait(portrait);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  // Initialize GameEngine
  if (!engineRef.current) {
    engineRef.current = new GameEngine();
  }
  const engine = engineRef.current;

  // Check saved game presence on mount
  useEffect(() => {
    setHasSave(hasSavedGameInStorage());
  }, []);

  // Sync state changes from game ticks
  useEffect(() => {
    const interval = setInterval(() => {
      // Force React re-render of HUD elements (e.g. survival meters, time, inventory)
      setTickCounter((prev) => prev + 1);

      // Check if chest was opened via interaction
      if (engine.activeOpenChest && !showInventory) {
        setShowInventory(true);
      }
    }, 150);

    engine.onGameOver = () => {
      setShowGameOver(true);
    };

    return () => clearInterval(interval);
  }, [engine, showInventory]);

  // Keyboard controls listener
  useEffect(() => {
    const pressedKeys = new Set<string>();

    const updateMovement = () => {
      let vx = 0;
      let vy = 0;
      if (pressedKeys.has('KeyW') || pressedKeys.has('ArrowUp')) vy -= 1;
      if (pressedKeys.has('KeyS') || pressedKeys.has('ArrowDown')) vy += 1;
      if (pressedKeys.has('KeyA') || pressedKeys.has('ArrowLeft')) vx -= 1;
      if (pressedKeys.has('KeyD') || pressedKeys.has('ArrowRight')) vx += 1;

      // Normalize diagonal movement
      if (vx !== 0 && vy !== 0) {
        vx *= 0.7071;
        vy *= 0.7071;
      }
      engine.setPlayerVelocity(vx, vy);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying) return;

      // Hotbar selection keys 1..5
      if (['Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5'].includes(e.code)) {
        const slotIdx = parseInt(e.code.replace('Digit', '')) - 1;
        engine.selectHotbarSlot(slotIdx);
        return;
      }

      // Action shortcuts
      if (e.code === 'Space') {
        e.preventDefault();
        engine.attack();
        return;
      }
      if (e.code === 'KeyQ' || e.code === 'KeyZ') {
        e.preventDefault();
        engine.dodge();
        return;
      }
      if (e.code === 'KeyK') {
        e.preventDefault();
        setShowSkillTree((prev) => !prev);
        return;
      }
      if (e.code === 'KeyE') {
        e.preventDefault();
        engine.interact();
        return;
      }
      if (e.code === 'KeyF') {
        e.preventDefault();
        engine.useCurrentItem();
        return;
      }
      if (e.code === 'KeyI' || e.code === 'Tab') {
        e.preventDefault();
        setShowInventory((prev) => !prev);
        return;
      }
      if (e.code === 'KeyC') {
        e.preventDefault();
        setShowCrafting((prev) => !prev);
        return;
      }
      if (e.code === 'KeyB') {
        e.preventDefault();
        setShowBuilding((prev) => !prev);
        return;
      }
      if (e.code === 'Escape') {
        e.preventDefault();
        if (engine.activeBuildingGhost) {
          engine.activeBuildingGhost = null;
        } else {
          setShowInventory(false);
          setShowCrafting(false);
          setShowBuilding(false);
          setShowSkillTree(false);
          setShowAssetAudit(false);
          setShowHelpGuide(false);
        }
        return;
      }

      // Sprint key (Shift)
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        engine.setSprinting(true);
        updateMovement();
      }

      // Movement keys
      if (['KeyW', 'KeyS', 'KeyA', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        pressedKeys.add(e.code);
        updateMovement();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        engine.setSprinting(false);
        updateMovement();
      }
      if (pressedKeys.has(e.code)) {
        pressedKeys.delete(e.code);
        updateMovement();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [engine, isPlaying]);

  // Periodic Auto-Save every 45 seconds
  useEffect(() => {
    if (!isPlaying) return;
    const saveTimer = setInterval(() => {
      if (!engine.player.isDead) {
        engine.saveCurrentGame();
        setHasSave(true);
      }
    }, 45000);

    return () => clearInterval(saveTimer);
  }, [engine, isPlaying]);

  const handleStartNewGame = useCallback(() => {
    engineRef.current = new GameEngine();
    setIsPlaying(true);
    setShowGameOver(false);
    sounds.playClick();
  }, []);

  const handleResumeGame = useCallback(() => {
    if (engine.loadSavedGame()) {
      setIsPlaying(true);
      setShowGameOver(false);
      sounds.playClick();
    }
  }, [engine]);

  const handleManualSave = useCallback(() => {
    const success = engine.saveCurrentGame();
    if (success) {
      setHasSave(true);
      sounds.playBuild();
      engine.activeNotification = {
        title: 'تم حفظ اللعبة!',
        desc: 'تم حفظ موقعك والموارد والمباني بنجاح في المتصفح.',
        icon: 'save',
        timer: 140,
      };
    }
  }, [engine]);

  const handleToggleMute = useCallback(() => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  }, []);

  return (
    <div
      dir="rtl"
      className="relative w-screen h-screen overflow-hidden bg-neutral-950 font-['Tajawal',sans-serif] select-none"
    >
      {/* 1. Main Pixel Art Game Viewport Canvas */}
      <GameCanvas engine={engine} />

      {/* 2. In-Game Heads-Up Display (HUD) */}
      {isPlaying && !showGameOver && (
        <>
          <HUD
            engine={engine}
            onOpenInventory={() => setShowInventory(true)}
            onOpenCrafting={() => setShowCrafting(true)}
            onOpenBuilding={() => setShowBuilding(true)}
            onOpenSkillTree={() => setShowSkillTree(true)}
            onOpenAssetAudit={() => setShowAssetAudit(true)}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onManualSave={handleManualSave}
          />

          {/* Mobile On-Screen Virtual Controls */}
          <MobileControls
            engine={engine}
            onOpenInventory={() => setShowInventory(true)}
            onOpenCrafting={() => setShowCrafting(true)}
            onOpenBuilding={() => setShowBuilding(true)}
            onOpenSkillTree={() => setShowSkillTree(true)}
          />
        </>
      )}

      {/* 3. Welcome / Main Start Menu Screen */}
      {!isPlaying && !showGameOver && (
        <div className="fixed inset-0 z-40 bg-black/85 flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-neutral-900/95 border-2 border-amber-600/90 rounded-3xl p-6 sm:p-8 text-white shadow-2xl flex flex-col items-center gap-5 text-center">
            {/* Title & Badge */}
            <div className="flex flex-col items-center gap-2">
              <span className="px-3 py-1 bg-amber-950/80 border border-amber-500/60 rounded-full text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>لعبة البقاء والاستكشاف الكاملة — Offline 100%</span>
              </span>

              <h1 className="text-2xl sm:text-3xl font-black text-amber-400 font-['Press_Start_2P',monospace] tracking-wider mt-1">
                PIXEL SURVIVAL
              </h1>
              <span className="text-base sm:text-lg font-bold text-neutral-200">آخر يوم — صراع البقاء في البرية</span>
            </div>

            {/* Visual Feature Tags */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full text-xs text-neutral-300">
              <div className="bg-neutral-950/80 border border-neutral-800 p-2 rounded-xl flex flex-col items-center">
                <span className="text-base text-emerald-400">TREE</span>
                <span className="font-bold">قطع الخشب</span>
              </div>
              <div className="bg-neutral-950/80 border border-neutral-800 p-2 rounded-xl flex flex-col items-center">
                <span className="text-base text-slate-300">ORE</span>
                <span className="font-bold">تعدين الحجر</span>
              </div>
              <div className="bg-neutral-950/80 border border-neutral-800 p-2 rounded-xl flex flex-col items-center">
                <span className="text-base text-amber-300">BUILD</span>
                <span className="font-bold">صناعة وبناء</span>
              </div>
              <div className="bg-neutral-950/80 border border-neutral-800 p-2 rounded-xl flex flex-col items-center">
                <span className="text-base text-red-300">COMBAT</span>
                <span className="font-bold">قتال الوحوش</span>
              </div>
            </div>

            {/* Menu Buttons */}
            <div className="flex flex-col gap-2.5 w-full mt-2">
              <button
                id="btn-new-game"
                onClick={handleStartNewGame}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-95 text-neutral-950 font-black text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-xl cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>بدء مغامرة جديدة</span>
              </button>

              {hasSave && (
                <button
                  id="btn-resume-game"
                  onClick={handleResumeGame}
                  className="w-full py-3 bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-amber-300 border border-amber-600/60 font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>استئناف اللعبة المحفوظة</span>
                </button>
              )}

              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  id="btn-open-guide"
                  onClick={() => setShowHelpGuide(true)}
                  className="py-2.5 bg-neutral-950/80 hover:bg-neutral-800 border border-neutral-700 rounded-xl text-xs text-neutral-300 font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Info className="w-3.5 h-3.5 text-cyan-400" />
                  <span>طريقة اللعب والتحكم</span>
                </button>

                <button
                  id="btn-menu-asset-audit"
                  onClick={() => setShowAssetAudit(true)}
                  className="py-2.5 bg-neutral-950/80 hover:bg-neutral-800 border border-neutral-700 rounded-xl text-xs text-neutral-300 font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>فحص الأصول المسجلة</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Controls & Help Guide Modal */}
      {showHelpGuide && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-neutral-900 border-2 border-cyan-600 rounded-2xl p-5 text-white flex flex-col gap-4">
            <h3 className="text-base font-bold text-cyan-300 flex items-center gap-2 border-b border-neutral-800 pb-2">
              <Info className="w-4 h-4" />
              <span>دليل التحكم وطريقة اللعب</span>
            </h3>

            <div className="flex flex-col gap-3 text-xs text-neutral-300 leading-relaxed max-h-[60vh] overflow-y-auto pr-1">
              <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col gap-1.5">
                <span className="font-bold text-amber-300">التحكم على الكمبيوتر:</span>
                <p>• الحركة: مفاتيح W, A, S, D أو الأسهم (مع Shift للركض السريع)</p>
                <p>• الهجوم والقطع: زر المسافة (Space) أو النقر بالماوس</p>
                <p>• المراوغة والتدحرج السريع: مفتاح Q أو Z (تفادي الأضرار)</p>
                <p>• شجرة المهارات والترقيات: مفتاح K</p>
                <p>• التفاعل وفتح الأبواب والصناديق: مفتاح E</p>
                <p>• أكل الطعام: مفتاح F</p>
                <p>• الحقيبة: مفتاح I أو Tab</p>
                <p>• الصناعة: مفتاح C | البناء: مفتاح B</p>
                <p>• الأرقام 1 إلى 5: التبديل السريع بين أدوات الحزام</p>
              </div>

              <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col gap-1.5">
                <span className="font-bold text-cyan-300">التحكم على الهاتف (Landscape الأفقي):</span>
                <p>• عصا التحكم الافتراضية (Joystick) في أسفل اليسار لتوجيه الحركة بسلاسة.</p>
                <p>• أزرار الهجوم، المراوغة، التفاعل، والأكل في أسفل اليمين.</p>
                <p>• شريط المهارات والحقيبة والصناعة متاح في الأعلى لسهولة الوصول.</p>
              </div>

              <div className="bg-neutral-950/80 p-3 rounded-xl border border-neutral-800 flex flex-col gap-1.5">
                <span className="font-bold text-emerald-300">نصائح النجاة والتقدم:</span>
                <p>1. قاتل الكائنات واجمع الموارد لكسب نقاط الخبرة (XP) وتطوير مهاراتك من شجرة المهارات.</p>
                <p>2. استكشف الخريطة لاكتشاف معالم الآثار والينابيع والمواقع الغامضة (POIs).</p>
                <p>3. استخدم حركة التدحرج (Dodge) لتفادي ضربات الوحوش الشرسة مثل الدببة والذئاب.</p>
                <p>4. انتبه لحالة الطقس كالعواصف والضباب التي قد تؤثر على مدى الرؤية وحركة الحيوانات.</p>
              </div>
            </div>

            <button
              onClick={() => setShowHelpGuide(false)}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              فهمت، عودة للقائمة
            </button>
          </div>
        </div>
      )}

      {/* 5. Inventory Modal */}
      {showInventory && (
        <InventoryModal
          engine={engine}
          onClose={() => {
            setShowInventory(false);
            if (engine.activeOpenChest) engine.activeOpenChest = null;
          }}
        />
      )}

      {/* 6. Crafting Modal */}
      {showCrafting && (
        <CraftingModal
          engine={engine}
          onClose={() => setShowCrafting(false)}
        />
      )}

      {/* 7. Building Modal */}
      {showBuilding && (
        <BuildingModal
          engine={engine}
          onClose={() => setShowBuilding(false)}
        />
      )}

      {/* 8. Skill Tree Modal */}
      {showSkillTree && (
        <SkillTreeModal
          engine={engine}
          onClose={() => setShowSkillTree(false)}
        />
      )}

      {/* 9. Asset Audit Modal */}
      {showAssetAudit && (
        <AssetAuditModal
          engine={engine}
          onClose={() => setShowAssetAudit(false)}
        />
      )}

      {/* 9. Game Over Modal */}
      {showGameOver && (
        <GameOverModal
          engine={engine}
          onRestart={handleStartNewGame}
        />
      )}

      {/* 10. Landscape / Rotate Device Recommendation Screen */}
      {isPortrait && !dismissRotateWarning && (
        <RotateDeviceModal onDismiss={() => setDismissRotateWarning(true)} />
      )}
    </div>
  );
}
