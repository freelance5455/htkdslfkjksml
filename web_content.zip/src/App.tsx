/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { ConnectionCard } from './components/ConnectionCard';
import { TrafficGraph } from './components/TrafficGraph';
import { WorldMapVisual } from './components/WorldMapVisual';
import { LeakTestCard } from './components/LeakTestCard';
import { ServerListModal } from './components/ServerListModal';
import { SpeedTestModal } from './components/SpeedTestModal';
import { SettingsModal } from './components/SettingsModal';
import { LogsModal } from './components/LogsModal';
import { AndroidApkModal } from './components/AndroidApkModal';
import { SERVERS_LIST, USER_ORIGINAL_NETWORK } from './data/servers';
import { ConnectionStatus, VpnServer, VpnSettings, TrafficStats, LogEntry } from './types/vpn';
import { Language, TRANSLATIONS } from './translations';
import { Shield, Globe, Gauge, Lock, Settings, Terminal, Zap, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState(true);

  // Language state (default to Bengali 'bn' per user request)
  const [language, setLanguage] = useState<Language>('bn');
  const t = TRANSLATIONS[language];

  // Active view tab
  const [activeTab, setActiveTab] = useState('dashboard');

  // Connection states
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [currentServer, setCurrentServer] = useState<VpnServer>(SERVERS_LIST[1]); // Default to Bangladesh / Dhaka or Singapore
  const [favorites, setFavorites] = useState<string[]>(['bd-dha-01', 'sg-sin-01']);

  // Settings
  const [settings, setSettings] = useState<VpnSettings>({
    protocol: 'wireguard',
    killSwitch: true,
    dnsProtection: 'cloudflare',
    autoConnectOnWifi: true,
    blockAdsAndMalware: true,
    splitTunneling: false,
    splitTunnelApps: ['banking']
  });

  // Telemetry & Traffic
  const [stats, setStats] = useState<TrafficStats>({
    downloadSpeed: 0,
    uploadSpeed: 0,
    totalDownloaded: 142.5,
    totalUploaded: 38.2,
    sessionTime: 0
  });

  const [trafficHistory, setTrafficHistory] = useState<{ down: number; up: number }[]>([
    { down: 12, up: 4 },
    { down: 18, up: 6 },
    { down: 25, up: 9 },
    { down: 34, up: 14 },
    { down: 28, up: 11 },
  ]);

  // System Logs
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 'log-1',
      timestamp: '02:48:10',
      level: 'info',
      message: 'ShieldVPN Engine initialized. Core kernel module loaded.'
    },
    {
      id: 'log-2',
      timestamp: '02:48:11',
      level: 'info',
      message: `Local interface bound to ${USER_ORIGINAL_NETWORK.ip} (${USER_ORIGINAL_NETWORK.isp})`
    }
  ]);

  // Modals
  const [isServerModalOpen, setIsServerModalOpen] = useState(false);
  const [isSpeedTestOpen, setIsSpeedTestOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLogsOpen, setIsLogsOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // Sync theme to root DOM
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Fastest server finder
  const fastestServer = SERVERS_LIST.reduce((min, s) => s.ping < min.ping ? s : min, SERVERS_LIST[0]);

  // Log helper
  const addLog = (message: string, level: LogEntry['level'] = 'info') => {
    const now = new Date();
    const timestamp = now.toTimeString().split(' ')[0];
    setLogs(prev => [
      ...prev,
      {
        id: `log-${Date.now()}-${Math.random()}`,
        timestamp,
        level,
        message
      }
    ]);
  };

  // Connect / Disconnect workflow
  const handleToggleConnect = () => {
    if (status === 'connected') {
      // Disconnecting
      setStatus('disconnecting');
      addLog(`Initiating graceful tunnel teardown for ${currentServer.city}...`, 'warn');

      setTimeout(() => {
        setStatus('disconnected');
        setStats(prev => ({ ...prev, downloadSpeed: 0, uploadSpeed: 0 }));
        addLog(`Tunnel interface wg0 removed. Default routing restored to ${USER_ORIGINAL_NETWORK.ip}`, 'info');
      }, 700);

    } else if (status === 'disconnected') {
      // Connecting
      setStatus('connecting');
      addLog(`Connecting to node ${currentServer.city} (${currentServer.ip}:51820) via ${settings.protocol.toUpperCase()}...`, 'info');
      addLog('Generating ephemeral Curve25519 keypair and authenticating peer...', 'info');

      setTimeout(() => {
        addLog('Handshake response verified. Session symmetric AEAD key agreed.', 'info');
      }, 600);

      setTimeout(() => {
        setStatus('connected');
        addLog(`[SECURED] Virtual IP ${currentServer.ip} assigned. Kill Switch armed. DNS set to 1.1.1.1.`, 'success');
      }, 1300);
    }
  };

  // Real-time telemetry interval while connected
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (status === 'connected') {
      interval = setInterval(() => {
        setStats(prev => {
          // Dynamic realistic speed based on server load and ping
          const baseDown = Math.max(15, (120 - currentServer.ping * 0.3) * (1 - currentServer.load / 300));
          const jitter = (Math.random() - 0.5) * 8;
          const currentDown = Math.max(5, baseDown + jitter);
          const currentUp = Math.max(2, currentDown * 0.45 + (Math.random() - 0.5) * 4);

          // Add to history
          setTrafficHistory(h => {
            const next = [...h.slice(-24), { down: currentDown, up: currentUp }];
            return next;
          });

          return {
            ...prev,
            downloadSpeed: currentDown,
            uploadSpeed: currentUp,
            totalDownloaded: prev.totalDownloaded + (currentDown / 1024),
            totalUploaded: prev.totalUploaded + (currentUp / 1024),
            sessionTime: prev.sessionTime + 1
          };
        });
      }, 1000);
    } else {
      setStats(prev => ({ ...prev, downloadSpeed: 0, uploadSpeed: 0 }));
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [status, currentServer]);

  // Favorites toggle
  const handleToggleFavorite = (serverId: string) => {
    setFavorites(prev =>
      prev.includes(serverId) ? prev.filter(id => id !== serverId) : [...prev, serverId]
    );
  };

  // Select server
  const handleSelectServer = (server: VpnServer) => {
    if (server.id === currentServer.id) return;
    
    if (status === 'connected') {
      addLog(`Server switched to ${server.city} (${server.ip}). Seamlessly renegotiating cryptokey tunnel...`, 'info');
      setCurrentServer(server);
      setTimeout(() => {
        addLog(`Route switched to ${server.city} [${server.ping}ms].`, 'success');
      }, 600);
    } else {
      setCurrentServer(server);
      addLog(`Target server updated to ${server.city}, ${server.country}`, 'info');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-indigo-500 selection:text-white">
      {/* Top Bar */}
      <Navbar
        language={language}
        onLanguageChange={setLanguage}
        isDark={isDark}
        onToggleTheme={() => setIsDark(!isDark)}
        status={status}
        activeTab={activeTab}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'servers') setIsServerModalOpen(true);
          if (tab === 'speedtest') setIsSpeedTestOpen(true);
          if (tab === 'settings') setIsSettingsOpen(true);
          if (tab === 'audit') {
            const el = document.getElementById('privacy-audit-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
        
        {/* Quick Notification / Safety Banner if Kill Switch is active */}
        {settings.killSwitch && (
          <div className="w-full bg-slate-900 dark:bg-slate-900/60 text-white px-4 py-2.5 rounded-2xl border border-slate-800 flex items-center justify-between text-xs shadow-sm">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>
                <strong>{t.killSwitch} {t.killSwitchActive}:</strong> {language === 'bn' ? 'সংযোগ বিচ্ছিন্ন হলেও আপনার ইন্টারনেট ট্র্যাফিক উন্মুক্ত হবে না।' : 'Non-VPN packet leakage is blocked at kernel level.'}
              </span>
            </div>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="text-indigo-400 hover:text-indigo-300 font-semibold underline shrink-0 ml-2"
            >
              {t.settings}
            </button>
          </div>
        )}

        {/* Primary 2-Column Split: Connection Shield (Left) + World Map & Traffic Monitor (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left Column: Tactile Connection Card (5 cols on desktop) */}
          <div className="lg:col-span-5 flex flex-col">
            <ConnectionCard
              status={status}
              currentServer={currentServer}
              fastestServer={fastestServer}
              settings={settings}
              sessionTime={stats.sessionTime}
              language={language}
              onToggleConnect={handleToggleConnect}
              onOpenServerModal={() => setIsServerModalOpen(true)}
              onSelectFastestServer={() => handleSelectServer(fastestServer)}
            />
          </div>

          {/* Right Column: World Map Visual & Live Bandwidth Telemetry (7 cols on desktop) */}
          <div className="lg:col-span-7 flex flex-col gap-6 justify-between">
            {/* World Map Encrypted Tunnel Routing Visualizer */}
            <WorldMapVisual
              currentServer={currentServer}
              status={status}
              allServers={SERVERS_LIST}
              onSelectServer={handleSelectServer}
            />

            {/* Real-time Bandwidth Telemetry & Waveform Graph */}
            <TrafficGraph
              stats={stats}
              history={trafficHistory}
              status={status}
              language={language}
            />
          </div>

        </div>

        {/* Secondary Grid: Security & Leak Shield Audit + Quick Utility Hub */}
        <div id="privacy-audit-section" className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
          
          {/* Security & Leak Shield Audit (7 cols) */}
          <div className="lg:col-span-7">
            <LeakTestCard
              status={status}
              currentServer={currentServer}
              language={language}
            />
          </div>

          {/* Quick Utility Tools Hub (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>{language === 'bn' ? 'ভিপিএন টুলস ও ডায়াগনস্টিক' : 'VPN Tools & Diagnostics'}</span>
                </h3>
                <span className="text-xs text-slate-400">All tools ready</span>
              </div>

              <div className="space-y-2.5">
                {/* 1. Server List Explorer */}
                <button
                  onClick={() => setIsServerModalOpen(true)}
                  className="w-full p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-left transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                      <Globe className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        {t.selectServerTitle}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {SERVERS_LIST.length} global locations · {favorites.length} favorites
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* 2. Speed Test Tool */}
                <button
                  onClick={() => setIsSpeedTestOpen(true)}
                  className="w-full p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-left transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                      <Gauge className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                        {t.speedTestTitle}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Benchmark Ping, Jitter, Download & Upload
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* 3. System Connection Logs */}
                <button
                  onClick={() => setIsLogsOpen(true)}
                  className="w-full p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-left transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center">
                      <Terminal className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        {t.logsTitle}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {logs.length} events logged · WireGuard kernel output
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* 4. VPN Settings & Protocols */}
                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-full p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-left transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                      <Settings className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                        {t.settingsTitle}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Protocol: {settings.protocol.toUpperCase()} · DNS: {settings.dnsProtection}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* 5. Android APK & Mobile App */}
                <button
                  onClick={() => setIsApkModalOpen(true)}
                  className="w-full p-3.5 rounded-2xl bg-emerald-500/10 hover:bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-between text-left transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-sm">
                      📱
                    </div>
                    <div>
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300 group-hover:underline">
                        {language === 'bn' ? 'অ্যান্ড্রয়েড APK ও মোবাইল অ্যাপ' : 'Android APK & Mobile App'}
                      </div>
                      <div className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80">
                        {language === 'bn' ? 'ফোনে ১-ক্লিক ইনস্টল বা APK ফাইল তৈরি' : '1-Click Install or Generate .APK'}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            {/* Quick Tip Box */}
            <div className="mt-4 p-3 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 text-[11px] text-indigo-900 dark:text-indigo-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <span>{t.quickConnectTip}</span>
            </div>
          </div>

        </div>

      </main>

      {/* Clean Footer */}
      <footer className="w-full border-t border-slate-200 dark:border-slate-800 py-6 mt-12 bg-white/50 dark:bg-slate-900/50 text-xs text-slate-500 dark:text-slate-400 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-indigo-500" />
            <span className="font-bold text-slate-900 dark:text-slate-200">ShieldVPN</span>
            <span>·</span>
            <span>Zero Log Policy</span>
            <span>·</span>
            <span>AES-256-GCM & ChaCha20</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Client v2.4.0</span>
            <span>·</span>
            <span>All systems nominal</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ServerListModal
        isOpen={isServerModalOpen}
        onClose={() => setIsServerModalOpen(false)}
        servers={SERVERS_LIST}
        currentServer={currentServer}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
        onSelectServer={handleSelectServer}
        language={language}
      />

      <SpeedTestModal
        isOpen={isSpeedTestOpen}
        onClose={() => setIsSpeedTestOpen(false)}
        server={currentServer}
        language={language}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => {
          setSettings(newSettings);
          addLog(`VPN settings updated: Protocol ${newSettings.protocol.toUpperCase()}, Kill Switch ${newSettings.killSwitch ? 'Enabled' : 'Disabled'}, DNS ${newSettings.dnsProtection}`, 'info');
        }}
        language={language}
      />

      <LogsModal
        isOpen={isLogsOpen}
        onClose={() => setIsLogsOpen(false)}
        logs={logs}
        onClearLogs={() => setLogs([])}
        server={currentServer}
        settings={settings}
        language={language}
      />

      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
        language={language}
      />
    </div>
  );
}
