/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Headphones,
  Smartphone,
  Monitor,
  Download,
  Sparkles,
  Radio,
  Sliders,
  Disc,
} from 'lucide-react';
import { audioEngine } from './services/audioEngine';
import { INITIAL_TRACKS } from './data/tracks';
import { Track, VisualizerMode, EQState } from './types';
import { LiveWaveformCanvas } from './components/LiveWaveformCanvas';
import { TurntableDisc } from './components/TurntableDisc';
import { DJMixerControls } from './components/DJMixerControls';
import { DJSoundboard } from './components/DJSoundboard';
import { MusicPlayerBar } from './components/MusicPlayerBar';
import { PlaylistDrawer } from './components/PlaylistDrawer';
import { FullStageVisualizer } from './components/FullStageVisualizer';
import { AIDJArtStudio } from './components/AIDJArtStudio';
import { AndroidAPKExportModal } from './components/AndroidAPKExportModal';
import { SplashScreen } from './components/SplashScreen';
import { AndroidFrameWrapper } from './components/AndroidFrameWrapper';

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [tracks, setTracks] = useState<Track[]>(INITIAL_TRACKS);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [isLooping, setIsLooping] = useState(false);
  const [isShuffling, setIsShuffling] = useState(false);
  const [visualizerMode, setVisualizerMode] = useState<VisualizerMode>('waveform');
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isAIStudioOpen, setIsAIStudioOpen] = useState(false);
  const [isAPKModalOpen, setIsAPKModalOpen] = useState(false);
  const [stageBackdropUrl, setStageBackdropUrl] = useState<string | null>(null);
  const [isMicActive, setIsMicActive] = useState(false);

  const [eq, setEQ] = useState<EQState>({
    low: 0,
    mid: 0,
    high: 0,
    filter: 0,
  });
  const [crossfader, setCrossfader] = useState(0);

  const currentTrack = tracks[currentTrackIndex] || tracks[0];

  // Handle Play/Pause
  const handlePlayPause = useCallback(async () => {
    audioEngine.ensureContext();
    if (isPlaying) {
      audioEngine.pause();
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      await audioEngine.playTrack(
        currentTrack,
        (time) => setCurrentTime(time),
        () => handleNextTrack()
      );
    }
  }, [isPlaying, currentTrack]);

  // Handle Next Track
  const handleNextTrack = useCallback(() => {
    let nextIdx = 0;
    if (isShuffling) {
      nextIdx = Math.floor(Math.random() * tracks.length);
    } else {
      nextIdx = (currentTrackIndex + 1) % tracks.length;
    }
    setCurrentTrackIndex(nextIdx);
    setCurrentTime(0);

    const nextTrack = tracks[nextIdx];
    if (isPlaying) {
      audioEngine.playTrack(
        nextTrack,
        (time) => setCurrentTime(time),
        () => handleNextTrack()
      );
    }
  }, [currentTrackIndex, tracks, isShuffling, isPlaying]);

  // Handle Prev Track
  const handlePrevTrack = useCallback(() => {
    const prevIdx = (currentTrackIndex - 1 + tracks.length) % tracks.length;
    setCurrentTrackIndex(prevIdx);
    setCurrentTime(0);

    const prevTrack = tracks[prevIdx];
    if (isPlaying) {
      audioEngine.playTrack(
        prevTrack,
        (time) => setCurrentTime(time),
        () => handleNextTrack()
      );
    }
  }, [currentTrackIndex, tracks, isPlaying, handleNextTrack]);

  // Seek time
  const handleSeek = (seconds: number) => {
    setCurrentTime(seconds);
    audioEngine.seek(seconds);
  };

  // Change volume
  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    audioEngine.setVolume(vol);
  };

  // Change Pitch / Playback Rate
  const handlePlaybackRateChange = (rate: number) => {
    setPlaybackRate(rate);
    audioEngine.setPlaybackRate(rate);
  };

  // Select a track from playlist
  const handleSelectTrack = (track: Track) => {
    const idx = tracks.findIndex((t) => t.id === track.id);
    if (idx !== -1) {
      setCurrentTrackIndex(idx);
      setCurrentTime(0);
      setIsPlaying(true);
      audioEngine.playTrack(
        track,
        (time) => setCurrentTime(time),
        () => handleNextTrack()
      );
    }
  };

  // Import custom audio
  const handleImportTrack = (newTrack: Track) => {
    setTracks((prev) => [newTrack, ...prev]);
  };

  // Live Microphone toggle
  const handleToggleMic = async () => {
    if (isMicActive) {
      audioEngine.disableMicrophone();
      setIsMicActive(false);
    } else {
      const success = await audioEngine.enableMicrophone();
      if (success) {
        setIsMicActive(true);
      }
    }
  };

  // Start Audio Engine from Splash Screen
  const handleStartApp = () => {
    audioEngine.ensureContext();
    setHasStarted(true);
    // Automatically start playing first track for instant music & visualizer feedback!
    setIsPlaying(true);
    audioEngine.playTrack(
      currentTrack,
      (time) => setCurrentTime(time),
      () => handleNextTrack()
    );
  };

  // Apply AI Generated Cover to active vinyl
  const handleApplyCover = (url: string) => {
    setTracks((prev) =>
      prev.map((t, i) => (i === currentTrackIndex ? { ...t, coverUrl: url } : t))
    );
  };

  // Apply AI Generated Backdrop to visualizer stage
  const handleApplyBackdrop = (url: string) => {
    setStageBackdropUrl(url);
  };

  if (!hasStarted) {
    return <SplashScreen onStart={handleStartApp} />;
  }

  return (
    <AndroidFrameWrapper
      isPhoneFrame={isPhoneFrame}
      onToggleFrame={() => setIsPhoneFrame(!isPhoneFrame)}
    >
      <div className="relative min-h-screen bg-[#06060a] text-white flex flex-col justify-between selection:bg-cyan-500 selection:text-black">
        
        {/* Subtle Neon Stage Background Glow */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          {stageBackdropUrl ? (
            <div
              className="absolute inset-0 bg-cover bg-center opacity-25 mix-blend-screen scale-105"
              style={{ backgroundImage: `url(${stageBackdropUrl})` }}
            />
          ) : (
            <>
              <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-cyan-600/15 blur-[120px]" />
              <div className="absolute top-1/3 -right-32 w-96 h-96 rounded-full bg-purple-600/15 blur-[120px]" />
              <div className="absolute -bottom-32 left-1/3 w-96 h-96 rounded-full bg-pink-600/15 blur-[120px]" />
            </>
          )}
        </div>

        {/* Top App Header & Controls */}
        <header className="relative z-10 px-4 py-3 bg-[#0a0b14]/90 backdrop-blur-md border-b border-cyan-500/25 flex items-center justify-between gap-2">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-400 to-purple-600 p-0.5 shadow-[0_0_15px_#00f0ff] flex items-center justify-center">
              <div className="w-full h-full rounded-[10px] bg-black flex items-center justify-center">
                <Headphones className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm sm:text-base font-black font-dj tracking-widest text-white uppercase drop-shadow-[0_0_10px_rgba(0,240,255,0.7)]">
                  DJ SUNNY MUSIC
                </h1>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              </div>
              <p className="text-[9px] font-mono text-cyan-300/80 tracking-wider">
                ANDROID DJ ANIMATION STUDIO
              </p>
            </div>
          </div>

          {/* Top Actions: AI Studio, Export APK, Viewport Toggle */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* AI Art Studio Button */}
            <button
              onClick={() => setIsAIStudioOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-600/90 hover:bg-purple-600 text-white text-[11px] font-bold font-dj uppercase shadow-[0_0_10px_#b026ff] active:scale-95 transition-all"
              title="Generate Custom DJ Album Art & Visuals"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span className="hidden sm:inline">AI ART STUDIO</span>
            </button>

            {/* Export Android APK Modal Trigger */}
            <button
              onClick={() => setIsAPKModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-black text-[11px] font-extrabold font-dj uppercase shadow-[0_0_12px_rgba(16,185,129,0.5)] active:scale-95 transition-all"
              title="Export as Android APK / Native Code"
            >
              <Download className="w-3.5 h-3.5" />
              <span>EXPORT APK</span>
            </button>

            {/* Toggle Phone Frame Simulation vs Full View */}
            <button
              onClick={() => setIsPhoneFrame(!isPhoneFrame)}
              className="p-1.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-700 active:scale-95 transition-all"
              title={isPhoneFrame ? 'Switch to Wide Stage View' : 'Switch to Android Phone View'}
            >
              {isPhoneFrame ? <Monitor className="w-4 h-4 text-cyan-400" /> : <Smartphone className="w-4 h-4 text-purple-400" />}
            </button>

          </div>
        </header>

        {/* Main Content Layout */}
        <main className="relative z-10 flex-1 p-3 sm:p-5 max-w-7xl mx-auto w-full space-y-4">
          
          {/* Section 1: Live Real-Time Waveform & Soundbars Animation */}
          <div className="w-full">
            <LiveWaveformCanvas
              mode={visualizerMode}
              isPlaying={isPlaying}
              className="w-full h-36 sm:h-48 shadow-[0_0_30px_rgba(0,240,255,0.15)]"
            />
          </div>

          {/* Section 2: DJ Performance Stage: Turntable Disc & DJ Mixer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
            
            {/* Turntable Vinyl Deck (Lg columns 1-6) */}
            <div className="lg:col-span-6 flex flex-col items-center">
              <TurntableDisc
                isPlaying={isPlaying}
                coverUrl={currentTrack.coverUrl}
                playbackRate={playbackRate}
                onRateChange={handlePlaybackRateChange}
                trackTitle={currentTrack.title}
              />
            </div>

            {/* DJ Mixer & 3-Band Equalizer (Lg columns 7-12) */}
            <div className="lg:col-span-6">
              <DJMixerControls
                eq={eq}
                onEQChange={setEQ}
                crossfader={crossfader}
                onCrossfaderChange={setCrossfader}
                bpm={currentTrack.bpm}
              />
            </div>

          </div>

          {/* Section 3: DJ Sampler & Sound Trigger Pads */}
          <div className="w-full">
            <DJSoundboard />
          </div>

          {/* Section 4: DJ Playlist & Audio Import Drawer */}
          <div className="w-full">
            <PlaylistDrawer
              tracks={tracks}
              currentTrack={currentTrack}
              isPlaying={isPlaying}
              onSelectTrack={handleSelectTrack}
              onImportTrack={handleImportTrack}
              isMicActive={isMicActive}
              onToggleMic={handleToggleMic}
              onOpenAIStudio={() => setIsAIStudioOpen(true)}
            />
          </div>

        </main>

        {/* Section 5: Bottom Music Player Bar */}
        <footer className="relative z-20 sticky bottom-0 p-3 sm:p-4 bg-[#070810]/95 backdrop-blur-lg border-t border-cyan-500/25">
          <div className="max-w-7xl mx-auto w-full">
            <MusicPlayerBar
              currentTrack={currentTrack}
              isPlaying={isPlaying}
              onPlayPause={handlePlayPause}
              onNext={handleNextTrack}
              onPrev={handlePrevTrack}
              currentTime={currentTime}
              duration={currentTrack.duration}
              onSeek={handleSeek}
              volume={volume}
              onVolumeChange={handleVolumeChange}
              isLooping={isLooping}
              onToggleLoop={() => setIsLooping(!isLooping)}
              isShuffling={isShuffling}
              onToggleShuffle={() => setIsShuffling(!isShuffling)}
              visualizerMode={visualizerMode}
              onVisualizerModeChange={setVisualizerMode}
              onToggleFullScreen={() => setIsFullScreen(true)}
              isFullScreen={isFullScreen}
            />
          </div>
        </footer>

        {/* Full Stage Visualizer Modal */}
        {isFullScreen && (
          <FullStageVisualizer
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onPlayPause={handlePlayPause}
            onNext={handleNextTrack}
            onPrev={handlePrevTrack}
            visualizerMode={visualizerMode}
            onVisualizerModeChange={setVisualizerMode}
            onClose={() => setIsFullScreen(false)}
            backdropUrl={stageBackdropUrl}
            onOpenAIStudio={() => setIsAIStudioOpen(true)}
          />
        )}

        {/* AI Art Studio Modal */}
        <AIDJArtStudio
          isOpen={isAIStudioOpen}
          onClose={() => setIsAIStudioOpen(false)}
          onApplyCover={handleApplyCover}
          onApplyBackdrop={handleApplyBackdrop}
        />

        {/* Android APK Export & Native Code Modal */}
        <AndroidAPKExportModal
          isOpen={isAPKModalOpen}
          onClose={() => setIsAPKModalOpen(false)}
        />

      </div>
    </AndroidFrameWrapper>
  );
}
