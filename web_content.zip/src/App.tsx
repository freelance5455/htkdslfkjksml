import { useState, useEffect, useRef, useCallback } from 'react';
import { registerPlugin, Capacitor } from '@capacitor/core';
import { AppLauncher } from '@capacitor/app-launcher';
import { Preferences } from '@capacitor/preferences';
import {
  Search, Settings, Wifi, Bluetooth, Plane, Battery, Sun,
  Camera, Grid3X3, Trash2, Plus, ChevronRight,
  Play, Pause, SkipForward, RotateCcw, Smartphone, MessageSquare,
  Mail, MapPin, Calculator, Calendar, Clock3, Film, Gamepad2, Music2,
  Zap, Menu, X, AppWindow, Sparkles, Star, Globe, CloudSun,
  Video, WifiOff, BluetoothOff, Music4
} from 'lucide-react';

/* ================================================================
   DATA & CONFIG
   ================================================================ */

interface AppInfo {
  id: string;
  name: string;
  packageName?: string;
  category: string;
  iconColor: string;
  iconBg: string;
  installed: boolean;
  system?: boolean;
}

interface LauncherNativePlugin {
  launchPackage(options: { packageName: string }): Promise<{ completed: boolean }>;
  openHomeSettings(): Promise<{ completed: boolean }>;
  isDefaultHome(): Promise<{ value: boolean }>;
  getInstalledApps(): Promise<{ apps: Array<{ packageName: string; name: string }> }>;
}

const LauncherNative = registerPlugin<LauncherNativePlugin>('LauncherNative');

const CATEGORIES = [
  'Social', 'Entertainment', 'Games', 'Productivity', 'Communication',
  'Photography', 'Finance', 'Shopping', 'Tools', 'Travel', 'Health', 'Utilities'
];

const ICON_MAP: Record<string, React.ReactNode> = {
  'chrome': <Globe className="w-6 h-6" />,
  'gmail': <Mail className="w-6 h-6" />,
  'youtube': <Video className="w-6 h-6" />,
  'maps': <MapPin className="w-6 h-6" />,
  'photos': <Camera className="w-6 h-6" />,
  'music': <Music2 className="w-6 h-6" />,
  'settings': <Settings className="w-6 h-6" />,
  'calendar': <Calendar className="w-6 h-6" />,
  'calculator': <Calculator className="w-6 h-6" />,
  'clock': <Clock3 className="w-6 h-6" />,
  'messages': <MessageSquare className="w-6 h-6" />,
  'phone': <Smartphone className="w-6 h-6" />,
  'playstore': <AppWindow className="w-6 h-6" />,
  'netflix': <Film className="w-6 h-6" />,
  'spotify': <Music4 className="w-6 h-6" />,
  'twitter': <MessageSquare className="w-6 h-6" />,
  'instagram': <Camera className="w-6 h-6" />,
  'whatsapp': <MessageSquare className="w-6 h-6" />,
  'facebook': <MessageSquare className="w-6 h-6" />,
  'snapchat': <Camera className="w-6 h-6" />,
  'tiktok': <Video className="w-6 h-6" />,
  'amazon': <ShoppingCartIcon />,
  'banking': <CreditCardIcon />,
  'gamecenter': <GamepadIcon />,
  'weather': <CloudSun className="w-6 h-6" />,
  'default': <AppWindow className="w-6 h-6" />
};

function ShoppingCartIcon() { return <Grid3X3 className="w-6 h-6" />; }
function CreditCardIcon() { return <Zap className="w-6 h-6" />; }
function GamepadIcon() { return <Gamepad2 className="w-6 h-6" />; }

const DEFAULT_APPS: AppInfo[] = [
  { id: 'chrome', name: 'Chrome', packageName: 'com.android.chrome', category: 'Tools', iconColor: '#34c759', iconBg: '#e8f5e9', installed: true },
  { id: 'gmail', name: 'Gmail', packageName: 'com.google.android.gm', category: 'Communication', iconColor: '#ea4335', iconBg: '#ffebee', installed: true },
  { id: 'youtube', name: 'YouTube', packageName: 'com.google.android.youtube', category: 'Entertainment', iconColor: '#ff3b30', iconBg: '#ffebee', installed: true },
  { id: 'maps', name: 'Maps', packageName: 'com.google.android.apps.maps', category: 'Travel', iconColor: '#4285f4', iconBg: '#e8f0fe', installed: true },
  { id: 'photos', name: 'Photos', packageName: 'com.google.android.apps.photos', category: 'Photography', iconColor: '#fbbc05', iconBg: '#fff8e1', installed: true },
  { id: 'music', name: 'Music', packageName: 'com.google.android.music', category: 'Entertainment', iconColor: '#ff9500', iconBg: '#fff3e0', installed: true },
  { id: 'settings', name: 'Settings', packageName: 'com.android.settings', category: 'Utilities', iconColor: '#8e8e93', iconBg: '#f5f5f7', installed: true, system: true },
  { id: 'calendar', name: 'Calendar', packageName: 'com.google.android.calendar', category: 'Productivity', iconColor: '#ff3b30', iconBg: '#ffebee', installed: true },
  { id: 'calculator', name: 'Calculator', packageName: 'com.android.calculator2', category: 'Utilities', iconColor: '#ff9500', iconBg: '#fff3e0', installed: true, system: true },
  { id: 'clock', name: 'Clock', packageName: 'com.google.android.deskclock', category: 'Utilities', iconColor: '#5856d6', iconBg: '#f0efff', installed: true, system: true },
  { id: 'messages', name: 'Messages', packageName: 'com.google.android.apps.messaging', category: 'Communication', iconColor: '#007aff', iconBg: '#e3f2fd', installed: true },
  { id: 'phone', name: 'Phone', packageName: 'com.android.dialer', category: 'Communication', iconColor: '#34c759', iconBg: '#e8f5e9', installed: true, system: true },
  { id: 'playstore', name: 'Play Store', packageName: 'com.android.vending', category: 'Tools', iconColor: '#4285f4', iconBg: '#e8f0fe', installed: true },
  { id: 'netflix', name: 'Netflix', packageName: 'com.netflix.mediaclient', category: 'Entertainment', iconColor: '#e50914', iconBg: '#ffebee', installed: true },
  { id: 'spotify', name: 'Spotify', packageName: 'com.spotify.music', category: 'Entertainment', iconColor: '#1db954', iconBg: '#e8f5e9', installed: true },
  { id: 'whatsapp', name: 'WhatsApp', packageName: 'com.whatsapp', category: 'Communication', iconColor: '#25d366', iconBg: '#e8f5e9', installed: true },
  { id: 'instagram', name: 'Instagram', packageName: 'com.instagram.android', category: 'Social', iconColor: '#e1306c', iconBg: '#fce4ec', installed: true },
  { id: 'twitter', name: 'Twitter', packageName: 'com.twitter.android', category: 'Social', iconColor: '#1da1f2', iconBg: '#e3f2fd', installed: true },
  { id: 'snapchat', name: 'Snapchat', packageName: 'com.snapchat.android', category: 'Social', iconColor: '#fffc00', iconBg: '#fffde7', installed: true },
  { id: 'tiktok', name: 'TikTok', packageName: 'com.zhiliaoapp.musically', category: 'Social', iconColor: '#ff0050', iconBg: '#ffebee', installed: true },
  { id: 'amazon', name: 'Amazon', packageName: 'com.amazon.mShop.android.shopping', category: 'Shopping', iconColor: '#ff9900', iconBg: '#fff3e0', installed: true },
  { id: 'banking', name: 'Banking', packageName: 'com.bank.app', category: 'Finance', iconColor: '#4caf50', iconBg: '#e8f5e9', installed: true },
  { id: 'weather', name: 'Weather', packageName: 'com.android.weather', category: 'Utilities', iconColor: '#00bcd4', iconBg: '#e0f7fa', installed: true },
];

/* ================================================================
   MAIN APP COMPONENT
   ================================================================ */

export default function App() {
  const [step, setStep] = useState(0); // 0=welcome, 1=setup, 2=home
  const [darkMode, setDarkMode] = useState(true);
  const [wallpaper, setWallpaper] = useState('/wallpaper-dark.jpg');
  const [showSettings, setShowSettings] = useState(false);
  const [showLibrary, setShowLibrary] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [folderOpen, setFolderOpen] = useState<string | null>(null);
  const [folderApps, setFolderApps] = useState<Record<string, AppInfo[]>>({});
  const [folderName, setFolderName] = useState<Record<string, string>>({ 'folder-1': 'Social' });
  const [editingFolder, setEditingFolder] = useState<string | null>(null);
  const [newFolderName, setNewFolderName] = useState('');
  const [dynamicIslandOpen, setDynamicIslandOpen] = useState(true);
  const [mediaPlaying, setMediaPlaying] = useState(true);
  const [showControlCenter, setShowControlCenter] = useState(false);
  const [wifiOn, setWifiOn] = useState(true);
  const [bluetoothOn, setBluetoothOn] = useState(true);
  const [airplaneOn, setAirplaneOn] = useState(false);
  const [brightness, setBrightness] = useState(70);
  const [volume, setVolume] = useState(60);
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [nativeApps, setNativeApps] = useState<Array<{ packageName: string; name: string }>>([]);
  const [isHomeScreen, setIsHomeScreen] = useState(false);

  const [pages, setPages] = useState<AppInfo[][]>([
    DEFAULT_APPS.slice(0, 20),
    DEFAULT_APPS.slice(20, 32),
  ]);
  const [dockApps] = useState<AppInfo[]>([
    DEFAULT_APPS[0], DEFAULT_APPS[1], DEFAULT_APPS[2], DEFAULT_APPS[13]
  ]);

  const touchStartX = useRef(0);
  const touchStartY = useRef(0);
  const touchStartTime = useRef(0);
  const pageRef = useRef<HTMLDivElement>(null);

  // Dynamic Island state
  const [islandEvent, setIslandEvent] = useState<'media' | 'call' | 'timer' | 'battery' | 'idle'>('media');
  const [islandExpanded, setIslandExpanded] = useState(false);

  // Force dark/light theme based on selection
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  // Restore setup and discover real Android apps when running natively.
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const saved = await Preferences.get({ key: 'launcher_setup_complete' });
        if (active && saved.value === 'true') {
          setShowOnboarding(false);
          setIsHomeScreen(true);
        }
      } catch {}

      if (Capacitor.getPlatform() === 'android' && Capacitor.isPluginAvailable('LauncherNative')) {
        try {
          const result = await LauncherNative.getInstalledApps();
          if (active) setNativeApps(result.apps || []);
        } catch {}
      }
    })();
    return () => { active = false; };
  }, []);

  // Onboarding complete
  const finishSetup = async () => {
    try { await Preferences.set({ key: 'launcher_setup_complete', value: 'true' }); } catch {}
    setShowOnboarding(false);
    setIsHomeScreen(true);
  };

  const openHomeSettings = useCallback(async () => {
    if (Capacitor.getPlatform() === 'android' && Capacitor.isPluginAvailable('LauncherNative')) {
      try { await LauncherNative.openHomeSettings(); return; } catch {}
    }
    alert('Open Android Settings → Apps → Default apps → Home app, then select iPhone Launcher Pro.');
  }, []);

  // Handle swipe for pages
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    touchStartTime.current = Date.now();
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    const dy = e.changedTouches[0].clientY - touchStartY.current;
    const dt = Date.now() - touchStartTime.current;

    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 60 && dt < 400) {
      if (dx > 0 && currentPage > 0) setCurrentPage(p => p - 1);
      else if (dx < 0 && currentPage < pages.length - 1) setCurrentPage(p => p + 1);
    }
    if (dy > 80 && Math.abs(dy) > Math.abs(dx) && dt < 300) {
      setShowSearch(s => !s);
    }
  };

  const openApp = useCallback(async (app: AppInfo) => {
    setShowSearch(false);
    setFolderOpen(null);

    if (app.system && app.id === 'settings') {
      setShowSettings(s => !s);
      return;
    }

    const packageName = app.packageName;
    if (!packageName) return;

    try {
      if (Capacitor.getPlatform() === 'android' && Capacitor.isPluginAvailable('LauncherNative')) {
        const result = await LauncherNative.launchPackage({ packageName });
        if (result.completed) return;
      }

      if (Capacitor.isPluginAvailable('AppLauncher')) {
        const result = await AppLauncher.openUrl({ url: packageName });
        if (result.completed) return;
      }

      window.location.href = `intent://#Intent;package=${packageName};end`;
    } catch {
      alert(`${app.name} is not installed or could not be opened on this device.`);
    }
  }, []);

  const createFolder = () => {
    const id = `folder-${Date.now()}`;
    setFolderOpen(id);
    setFolderApps(prev => ({ ...prev, [id]: [DEFAULT_APPS[14]] }));
    setFolderName(prev => ({ ...prev, [id]: 'New Folder' }));
    setEditingFolder(id);
    setNewFolderName('New Folder');
  };

  const renameFolder = (id: string) => {
    setFolderName(prev => ({ ...prev, [id]: newFolderName }));
    setEditingFolder(null);
  };

  const addToFolder = (folderId: string, app: AppInfo) => {
    setFolderApps(prev => ({ ...prev, [folderId]: [...(prev[folderId] || []), app] }));
  };

  const removeFromFolder = (folderId: string, appId: string) => {
    setFolderApps(prev => ({ ...prev, [folderId]: prev[folderId].filter(a => a.id !== appId) }));
  };

  const deleteFolder = (folderId: string) => {
    setFolderApps(prev => {
      const updated = { ...prev };
      delete updated[folderId];
      return updated;
    });
    setFolderName(prev => {
      const updated = { ...prev };
      delete updated[folderId];
      return updated;
    });
    setFolderOpen(null);
  };

  const filteredApps = DEFAULT_APPS.filter(app =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.category.toLowerCase().includes(searchQuery.toLowerCase())
  ).filter(app => !searchQuery || app.installed);

  const libraryApps = DEFAULT_APPS.filter(a => a.installed);

  // Onboarding screens
  if (showOnboarding) {
    return (
      <OnboardingFlow
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        wallpaper={wallpaper}
        setWallpaper={setWallpaper}
        finishSetup={finishSetup}
        openDefaultLauncher={openHomeSettings}
      />
    );
  }

  // Main launcher screen
  return (
    <div
      className="relative w-full h-screen overflow-hidden select-none"
      style={{
        backgroundImage: `url(${wallpaper})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}
    >
      {/* Dark overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/10 to-black/60 z-0" />

      {/* Status Bar */}
      <StatusBar
        wifiOn={wifiOn}
        bluetoothOn={bluetoothOn}
        airplaneOn={airplaneOn}
        darkMode={darkMode}
        onSettings={() => setShowSettings(true)}
      />

      {/* Dynamic Island */}
      <DynamicIsland
        event={islandEvent}
        expanded={islandExpanded}
        setExpanded={setIslandExpanded}
        mediaPlaying={mediaPlaying}
        setMediaPlaying={setMediaPlaying}
        openApp={openApp}
      />

      {/* Main Content */}
      <main
        ref={pageRef}
        className="relative z-10 h-full pt-14 pb-28 px-5"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* App Grid Pages */}
        <div className="flex gap-5 h-full overflow-hidden">
          {pages.map((pageApps, pageIdx) => (
            <PageGrid
              key={pageIdx}
              apps={pageApps}
              index={pageIdx}
              currentPage={currentPage}
              folderOpen={folderOpen}
              setFolderOpen={setFolderOpen}
              folderApps={folderApps}
              folderName={folderName}
              openApp={openApp}
              addToFolder={addToFolder}
              removeFromFolder={removeFromFolder}
              editingFolder={editingFolder}
              setEditingFolder={setEditingFolder}
              newFolderName={newFolderName}
              setNewFolderName={setNewFolderName}
              renameFolder={renameFolder}
              deleteFolder={deleteFolder}
              createFolder={createFolder}
              darkMode={darkMode}
            />
          ))}
        </div>

        {/* Page Indicators */}
        <PageIndicators total={pages.length} current={currentPage} />
      </main>

      {/* Dock */}
      <Dock apps={dockApps} openApp={openApp} darkMode={darkMode} />

      {/* Search Overlay */}
      <SearchOverlay
        open={showSearch}
        query={searchQuery}
        setQuery={setSearchQuery}
        results={filteredApps}
        openApp={openApp}
        close={() => setShowSearch(false)}
      />

      {/* App Library */}
      <AppLibraryOverlay
        open={showLibrary}
        apps={libraryApps}
        openApp={openApp}
        close={() => setShowLibrary(false)}
      />

      {/* Settings */}
      <SettingsOverlay
        open={showSettings}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        close={() => setShowSettings(false)}
        openLibrary={() => { setShowLibrary(true); setShowSettings(false); }}
        openDefaultLauncher={openHomeSettings}
      />

      {/* Control Center */}
      <ControlCenter
        open={showControlCenter}
        wifiOn={wifiOn}
        setWifiOn={setWifiOn}
        bluetoothOn={bluetoothOn}
        setBluetoothOn={setBluetoothOn}
        airplaneOn={airplaneOn}
        setAirplaneOn={setAirplaneOn}
        brightness={brightness}
        setBrightness={setBrightness}
        volume={volume}
        setVolume={setVolume}
        openApp={openApp}
        close={() => setShowControlCenter(false)}
        darkMode={darkMode}
      />

      {/* Bottom Action Bar for Library / Search */}
      <BottomActions
        onSearch={() => setShowSearch(true)}
        onLibrary={() => setShowLibrary(true)}
        onControl={() => setShowControlCenter(c => !c)}
      />
    </div>
  );
}

/* ================================================================
   ONBOARDING FLOW
   ================================================================ */

function OnboardingFlow({ darkMode, setDarkMode, wallpaper, setWallpaper, finishSetup, openDefaultLauncher }: {
  darkMode: boolean;
  setDarkMode: (v: boolean) => void;
  wallpaper: string;
  setWallpaper: (v: string) => void;
  finishSetup: () => void;
  openDefaultLauncher: () => void;
}) {
  const [current, setCurrent] = useState(0);
  const steps = [
    { title: 'Welcome to iPhone Launcher Pro', desc: 'Your premium Android launcher experience starts here.', action: () => setCurrent(1) },
    { title: 'Real Default Launcher', desc: 'This launcher responds to Android HOME intent and can become your default Home app.', action: () => setCurrent(2) },
    { title: 'Permissions', desc: 'The launcher needs access to discover your installed apps and manage notifications through legitimate Android APIs.', action: () => setCurrent(3) },
    { title: 'Set Default', desc: 'Choose this as your Home app so pressing Home always returns here.', action: null },
    { title: 'Wallpaper & Theme', desc: 'Personalize your home screen with beautiful wallpapers and light or dark themes.', action: () => setCurrent(5) },
    { title: 'Dynamic Island', desc: 'Enable dynamic notifications for media, calls, and system events.', action: () => setCurrent(6) },
    { title: 'All Set!', desc: 'Your launcher is ready. Press Home to return anytime.', action: finishSetup },
  ];

  const step = steps[current];
  if (!step) return null;

  const openAndroidHomeSettings = async () => {
    await openDefaultLauncher();
    setCurrent(4);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-b from-iphone-black via-[#0a0a14] to-iphone-black flex flex-col items-center justify-center p-8 text-center animate-fade-in">
      <div className="absolute inset-0 z-0">
        <img src={wallpaper} alt="" className="w-full h-full object-cover opacity-40" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/30 z-0" />

      <div className="relative z-10 max-w-md space-y-8 animate-fade-in-up">
        <div className="w-24 h-24 mx-auto rounded-[2.5rem] bg-gradient-to-br from-violet-500 via-indigo-500 to-blue-600 shadow-2xl shadow-indigo-500/20 flex items-center justify-center">
          <Sparkles className="w-12 h-12 text-white" />
        </div>

        <h1 className="text-4xl font-extrabold tracking-tight text-white leading-tight">{step.title}</h1>
        <p className="text-lg text-white/70 leading-relaxed">{step.desc}</p>

        <div className="flex justify-center gap-2 mt-6">
          {steps.map((_, i) => (
            <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === current ? 'w-8 bg-white' : 'w-2 bg-white/20'}`} />
          ))}
        </div>

        <div className="pt-6 space-y-3">
          {current === 3 && (
            <button
              onClick={openAndroidHomeSettings}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-500 to-indigo-500 text-white font-semibold text-lg shadow-xl shadow-blue-500/20 hover:scale-[1.02] transition-transform active:scale-[0.98]"
            >
              Set as Default Launcher
            </button>
          )}
          {current === 4 && (
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => { setWallpaper('/wallpaper-dark.jpg'); setDarkMode(true); setCurrent(5); }}
                className="py-6 rounded-2xl border border-white/10 bg-white/5 text-white font-medium hover:bg-white/10 transition-colors"
              >
                Dark
              </button>
              <button
                onClick={() => { setWallpaper('/wallpaper-light.jpg'); setDarkMode(false); setCurrent(5); }}
                className="py-6 rounded-2xl border border-white/10 bg-white/5 text-white font-medium hover:bg-white/10 transition-colors"
              >
                Light
              </button>
            </div>
          )}
          {current !== 3 && current !== 4 && (
            <button
              onClick={() => step.action ? step.action() : setCurrent(0)}
              className="w-full py-4 rounded-2xl bg-white text-black font-semibold text-lg shadow-xl hover:scale-[1.02] transition-transform active:scale-[0.98]"
            >
              {current === steps.length - 1 ? 'Finish Setup' : 'Continue'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ================================================================
   STATUS BAR
   ================================================================ */

function StatusBar({ wifiOn, bluetoothOn, airplaneOn, darkMode, onSettings }: {
  wifiOn: boolean;
  bluetoothOn: boolean;
  airplaneOn: boolean;
  darkMode: boolean;
  onSettings: () => void;
}) {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 px-6 pt-3 pb-2 flex justify-between items-center">
      <div className="flex items-center gap-2 text-xs font-medium text-white/90 drop-shadow-sm">
        <span>9:41</span>
      </div>
      <div className="flex items-center gap-3 text-white/90 drop-shadow-sm">
        {airplaneOn ? <Plane className="w-3.5 h-3.5" /> : (
          <>
            {wifiOn ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
            {bluetoothOn ? <Bluetooth className="w-3.5 h-3.5" /> : <BluetoothOff className="w-3.5 h-3.5" />}
          </>
        )}
        <Battery className="w-4 h-4" />
        <span className="text-[10px] font-semibold">92%</span>
      </div>
    </div>
  );
}

/* ================================================================
   DYNAMIC ISLAND
   ================================================================ */

function DynamicIsland({ event, expanded, setExpanded, mediaPlaying, setMediaPlaying, openApp }: {
  event: string;
  expanded: boolean;
  setExpanded: (v: boolean) => void;
  mediaPlaying: boolean;
  setMediaPlaying: (v: boolean) => void;
  openApp: (a: AppInfo) => void;
}) {
  const [timeLeft, setTimeLeft] = useState(42);

  useEffect(() => {
    if (event === 'timer' && expanded) {
      const t = setInterval(() => setTimeLeft(p => Math.max(0, p - 1)), 1000);
      return () => clearInterval(t);
    }
  }, [event, expanded]);

  if (!expanded) {
    return (
      <button
        onClick={() => setExpanded(true)}
        className="absolute top-3 left-1/2 -translate-x-1/2 z-40 w-[120px] h-[36px] rounded-[999px] bg-black/70 backdrop-blur-xl border border-white/10 flex items-center justify-center gap-2 shadow-xl shadow-black/30 hover:scale-105 transition-transform"
      >
        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
        <span className="text-[10px] font-semibold text-white truncate">Now Playing</span>
      </button>
    );
  }

  return (
    <div
      className="absolute top-3 left-1/2 -translate-x-1/2 z-40 w-[340px] h-[110px] rounded-[36px] bg-black/70 backdrop-blur-2xl border border-white/10 shadow-2xl shadow-black/40 overflow-hidden animate-scale-in"
    >
      <button onClick={() => setExpanded(false)} className="absolute top-3 right-3 z-10 p-1 hover:bg-white/10 rounded-full">
        <X className="w-3 h-3 text-white/70" />
      </button>

      <div className="flex items-center h-full px-5 gap-4">
        <div className="w-16 h-16 rounded-xl overflow-hidden shadow-lg shadow-black/20 shrink-0 bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
          <Music2 className="w-7 h-7 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] text-white/50 font-medium">SONG • Apple Music</p>
          <h3 className="text-base font-bold text-white truncate">Midnight Rain</h3>
          <p className="text-xs text-white/60 truncate">Taylor Swift</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setMediaPlaying(!mediaPlaying)} className="p-2 hover:bg-white/10 rounded-full">
            {mediaPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
          </button>
          <button onClick={() => openApp(DEFAULT_APPS[5])} className="p-2 hover:bg-white/10 rounded-full">
            <SkipForward className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================================================================
   PAGE GRID
   ================================================================ */

function PageGrid({ apps, index, currentPage, folderOpen, setFolderOpen, folderApps, folderName, openApp, addToFolder, removeFromFolder, editingFolder, setEditingFolder, newFolderName, setNewFolderName, renameFolder, deleteFolder, createFolder, darkMode }: {
  apps: AppInfo[];
  index: number;
  currentPage: number;
  folderOpen: string | null;
  setFolderOpen: (v: string | null) => void;
  folderApps: Record<string, AppInfo[]>;
  folderName: Record<string, string>;
  openApp: (a: AppInfo) => void;
  addToFolder: (id: string, app: AppInfo) => void;
  removeFromFolder: (folderId: string, appId: string) => void;
  editingFolder: string | null;
  setEditingFolder: (v: string | null) => void;
  newFolderName: string;
  setNewFolderName: (v: string) => void;
  renameFolder: (id: string) => void;
  deleteFolder: (id: string) => void;
  createFolder: () => void;
  darkMode: boolean;
}) {
  const isActive = index === currentPage;
  return (
    <div
      className={`w-full h-full shrink-0 transition-opacity duration-300 ${isActive ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      style={{
        position: 'absolute',
        left: `${index * 100}%`,
        top: 0,
        width: '100%',
        height: '100%',
        transform: `translateX(${-currentPage * 100}%)`,
        transition: 'transform 0.35s cubic-bezier(0.32, 0.72, 0, 1)',
      }}
    >
      <div className="grid grid-cols-4 gap-4 gap-y-6 h-full content-start pt-4">
        {apps.map(app => (
          <AppIcon
            key={app.id}
            app={app}
            folderOpen={folderOpen}
            setFolderOpen={setFolderOpen}
            folderApps={folderApps}
            folderName={folderName}
            openApp={openApp}
            addToFolder={addToFolder}
            removeFromFolder={removeFromFolder}
            editingFolder={editingFolder}
            setEditingFolder={setEditingFolder}
            newFolderName={newFolderName}
            setNewFolderName={setNewFolderName}
            renameFolder={renameFolder}
            deleteFolder={deleteFolder}
            createFolder={createFolder}
            darkMode={darkMode}
          />
        ))}
      </div>
    </div>
  );
}

/* ================================================================
   APP ICON / FOLDER COMPONENT
   ================================================================ */

function AppIcon({ app, folderOpen, setFolderOpen, folderApps, folderName, openApp, addToFolder, removeFromFolder, editingFolder, setEditingFolder, newFolderName, setNewFolderName, renameFolder, deleteFolder, createFolder, darkMode }: any) {
  const folderId = app.id.startsWith('folder') ? app.id : null;
  const folderAppIds = folderId ? (folderApps[folderId] || []) : [];
  const folderAppName = folderId ? (folderName[folderId] || 'Folder') : null;

  const isFolder = !!folderId;

  if (folderOpen && folderOpen !== app.id) return null;

  if (isFolder && folderOpen === app.id) {
    return (
      <div className="w-16 h-[110px] relative animate-scale-in">
        <button
          onClick={() => setFolderOpen(null)}
          className="absolute -top-2 -right-2 z-20 p-1 bg-white/20 rounded-full hover:bg-white/30 backdrop-blur-md"
        >
          <X className="w-3 h-3 text-white" />
        </button>

        <div className="glass-panel rounded-[2rem] p-3 w-full h-full flex flex-col items-center gap-2 shadow-2xl shadow-black/20">
          <div className="flex items-center justify-between w-full">
            <h4 className="text-[9px] font-bold text-white/90">{folderAppName}</h4>
            {editingFolder === app.id ? (
              <button onClick={() => renameFolder(app.id)} className="text-[8px] text-blue-400 hover:text-blue-300">Done</button>
            ) : (
              <button onClick={() => { setEditingFolder(app.id); setNewFolderName(folderAppName || ''); }} className="text-[8px] text-white/40 hover:text-white">Edit</button>
            )}
          </div>
          {editingFolder === app.id && (
            <input
              value={newFolderName}
              onChange={e => setNewFolderName(e.target.value)}
              className="w-full bg-white/10 rounded-lg px-2 py-1 text-[10px] text-white outline-none border border-white/10 focus:border-blue-400"
              autoFocus
              onKeyDown={e => e.key === 'Enter' && renameFolder(app.id)}
            />
          )}
          <div className="grid grid-cols-3 gap-2 w-full flex-1">
            {folderAppIds.map((fApp: AppInfo) => (
              <button key={fApp.id} onClick={() => { openApp(fApp); setFolderOpen(null); }} className="aspect-square rounded-xl bg-gradient-to-br from-white/5 to-white/10 flex items-center justify-center hover:scale-110 transition-transform shadow-inner shadow-white/5">
                <AppColorIcon name={fApp.name} color={fApp.iconColor} />
              </button>
            ))}
            <button onClick={() => addToFolder(app.id, DEFAULT_APPS[Math.floor(Math.random() * DEFAULT_APPS.length)])} className="aspect-square rounded-xl border border-dashed border-white/20 flex items-center justify-center hover:bg-white/5 hover:border-white/30 transition-colors">
              <Plus className="w-4 h-4 text-white/40" />
            </button>
          </div>
          <button onClick={() => deleteFolder(app.id)} className="w-full mt-1 py-1 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[9px] flex items-center justify-center gap-1 transition-colors">
            <Trash2 className="w-3 h-3" /> Remove
          </button>
        </div>
      </div>
    );
  }

  return (
    <button
      onClick={() => {
        if (isFolder) {
          setFolderOpen(app.id);
        } else {
          openApp(app);
        }
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        if (!isFolder) {
          createFolder();
        }
      }}
      className="flex flex-col items-center gap-1 w-16 group focus:outline-none"
    >
      <div
        className="w-14 h-14 rounded-[1.6rem] flex items-center justify-center shadow-xl shadow-black/25 transition-transform duration-200 group-hover:scale-105 active:scale-95 relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${app.iconBg || '#1c1c1e'}, ${darkMode ? '#0a0a0c' : '#f5f5f7'})` }}
      >
        <AppColorIcon name={app.name} color={app.iconColor} />
      </div>
      <span className="text-[10px] font-medium text-white/90 drop-shadow-md text-center leading-tight w-16 truncate">
        {isFolder ? folderAppName : app.name}
      </span>
    </button>
  );
}

function AppColorIcon({ name, color }: { name: string; color: string }) {
  const IconComponent = (ICON_MAP[name.toLowerCase()] || ICON_MAP['default']) as React.ReactElement;
  return (
    <div
      className="w-9 h-9 rounded-[0.9rem] flex items-center justify-center shadow-inner shadow-black/10"
      style={{ backgroundColor: color, color: '#fff' }}
    >
      {IconComponent}
    </div>
  );
}

/* ================================================================
   PAGE INDICATORS
   ================================================================ */

function PageIndicators({ total, current }: { total: number; current: number }) {
  return (
    <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-30 flex gap-1.5">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={`h-1.5 rounded-full transition-all duration-300 ${i === current ? 'w-5 bg-white' : 'w-1.5 bg-white/20'}`}
        />
      ))}
    </div>
  );
}

/* ================================================================
   DOCK
   ================================================================ */

function Dock({ apps, openApp, darkMode }: { apps: AppInfo[]; openApp: (a: AppInfo) => void; darkMode: boolean }) {
  return (
    <div className="fixed bottom-5 left-4 right-4 z-30 flex justify-center">
      <div className="dock-glass rounded-[2.5rem] px-4 py-2 flex items-center gap-5 shadow-2xl shadow-black/30">
        {apps.map(app => (
          <button
            key={app.id}
            onClick={() => openApp(app)}
            className="w-12 h-12 rounded-[1.4rem] flex items-center justify-center shadow-lg shadow-black/20 hover:scale-110 active:scale-95 transition-transform"
            style={{ background: `linear-gradient(135deg, ${app.iconBg}, ${darkMode ? '#0a0a0c' : '#e8e8ed'})` }}
          >
            <AppColorIcon name={app.name} color={app.iconColor} />
          </button>
        ))}
      </div>
    </div>
  );
}

/* ================================================================
   SEARCH OVERLAY
   ================================================================ */

function SearchOverlay({ open, query, setQuery, results, openApp, close }: any) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex flex-col pt-20 px-6 animate-fade-in">
      <button onClick={close} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-full">
        <X className="w-6 h-6 text-white/80" />
      </button>
      <div className="max-w-md mx-auto w-full space-y-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
          <input
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search apps, folders..."
            className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white/10 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-white/30 focus:bg-white/15 transition-colors text-lg"
          />
        </div>
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-white/30 uppercase tracking-wider">Results</h3>
          <div className="grid grid-cols-4 gap-4">
            {results.map((app: AppInfo) => (
              <button key={app.id} onClick={() => { openApp(app); close(); }} className="flex flex-col items-center gap-2 p-2 rounded-2xl hover:bg-white/5 transition-colors">
                <div className="w-14 h-14 rounded-[1.2rem] flex items-center justify-center shadow-lg" style={{ background: `linear-gradient(135deg, ${app.iconBg}, #0a0a0c)` }}>
                  <AppColorIcon name={app.name} color={app.iconColor} />
                </div>
                <span className="text-[10px] text-white/80 font-medium truncate w-full text-center">{app.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================================================================
   APP LIBRARY OVERLAY
   ================================================================ */

function AppLibraryOverlay({ open, apps, openApp, close }: any) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-iphone-black/95 to-black/95 backdrop-blur-xl flex flex-col pt-16 px-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-extrabold text-white">App Library</h2>
        <button onClick={close} className="p-2 hover:bg-white/10 rounded-full">
          <X className="w-6 h-6 text-white/70" />
        </button>
      </div>
      <div className="overflow-y-auto flex-1 space-y-8 pb-8">
        {CATEGORIES.map(cat => (
          <div key={cat}>
            <h3 className="text-xs font-bold text-white/30 uppercase tracking-widest mb-3">{cat}</h3>
            <div className="grid grid-cols-4 gap-4">
              {apps.filter((a: AppInfo) => a.category === cat || (cat === 'Utilities' && !CATEGORIES.includes(a.category))).map((app: AppInfo) => (
                <button key={app.id} onClick={() => { openApp(app); close(); }} className="flex flex-col items-center gap-2 p-2 rounded-2xl hover:bg-white/5 transition-colors">
                  <div className="w-12 h-12 rounded-[1rem] flex items-center justify-center shadow-lg" style={{ background: `linear-gradient(135deg, ${app.iconBg}, #0a0a0c)` }}>
                    <AppColorIcon name={app.name} color={app.iconColor} />
                  </div>
                  <span className="text-[9px] text-white/70 truncate w-full text-center">{app.name}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================
   SETTINGS OVERLAY
   ================================================================ */

function SettingsOverlay({ open, darkMode, setDarkMode, close, openLibrary, openDefaultLauncher }: any) {
  if (!open) return null;
  const items = [
    { label: 'Home Screen Layout', desc: 'Grid, list, or custom' },
    { label: 'Icon Size', desc: 'Small, medium, large' },
    { label: 'App Labels', desc: 'Show or hide' },
    { label: 'Dock Settings', desc: 'Apps and appearance' },
    { label: 'Wallpaper', desc: 'Choose background' },
    { label: 'Widgets', desc: 'Add and manage' },
    { label: 'Light / Dark Mode', desc: darkMode ? 'Dark' : 'Light' },
    { label: 'Animation Settings', desc: 'Speed and effects' },
    { label: 'Dynamic Island', desc: 'Notifications and events' },
    { label: 'Search Settings', desc: 'Results and suggestions' },
    { label: 'App Library', desc: 'Categories and organization' },
    { label: 'Notification Settings', desc: 'Permissions' },
    { label: 'About', desc: 'Version 1.0.0' },
    { label: 'Privacy', desc: 'Data and permissions' },
    { label: 'Reset Launcher Settings', desc: 'Restore defaults' },
  ];
  return (
    <div className="fixed inset-0 z-[60] bg-gradient-to-b from-iphone-black/95 to-black/95 backdrop-blur-2xl flex flex-col pt-16 px-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-extrabold text-white">Settings</h2>
        <button onClick={close} className="p-2 hover:bg-white/10 rounded-full">
          <X className="w-6 h-6 text-white/70" />
        </button>
      </div>
      <div className="overflow-y-auto flex-1 space-y-1 pb-8">
        <div className="rounded-3xl glass-panel p-1 mb-4">
          <button onClick={openDefaultLauncher} className="w-full text-left px-4 py-4 rounded-2xl bg-gradient-to-r from-violet-600/20 to-indigo-600/20 hover:from-violet-600/30 hover:to-indigo-600/30 border border-violet-400/20">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Default Launcher</h3>
                <p className="text-[11px] text-white/50">Change default Home app</p>
              </div>
              <ChevronRight className="w-4 h-4 text-violet-400" />
            </div>
          </button>
        </div>
        {items.map(item => (
          <button key={item.label} onClick={() => {
            if (item.label === 'Light / Dark Mode') setDarkMode(!darkMode);
            if (item.label === 'App Library') openLibrary();
          }} className="w-full text-left px-4 py-3.5 rounded-2xl hover:bg-white/5 transition-colors flex items-center justify-between group">
            <div>
              <h3 className="text-sm font-medium text-white/90">{item.label}</h3>
              <p className="text-[11px] text-white/40">{item.desc}</p>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-white/20 group-hover:text-white/40 transition-colors" />
          </button>
        ))}
      </div>
    </div>
  );
}

/* ================================================================
   CONTROL CENTER
   ================================================================ */

function ControlCenter({ open, wifiOn, setWifiOn, bluetoothOn, setBluetoothOn, airplaneOn, setAirplaneOn, brightness, setBrightness, volume, setVolume, openApp, close, darkMode }: any) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] bg-gradient-to-b from-black/90 via-black/80 to-black/70 backdrop-blur-3xl flex flex-col pt-14 px-6 animate-slideUp">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-extrabold text-white">Control Center</h2>
        <button onClick={close} className="p-2 hover:bg-white/10 rounded-full">
          <X className="w-6 h-6 text-white/70" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <ControlTile active={wifiOn} onClick={() => setWifiOn(!wifiOn)} icon={<Wifi className="w-5 h-5" />} label="Wi-Fi" />
        <ControlTile active={bluetoothOn} onClick={() => setBluetoothOn(!bluetoothOn)} icon={<Bluetooth className="w-5 h-5" />} label="Bluetooth" />
        <ControlTile active={airplaneOn} onClick={() => setAirplaneOn(!airplaneOn)} icon={<Plane className="w-5 h-5" />} label="Airplane" />
        <ControlTile active={false} onClick={() => alert('Opens Android Brightness settings')} icon={<Sun className="w-5 h-5" />} label="Brightness" />
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-[10px] text-white/40 mb-1.5">
            <span>Brightness</span><span>{brightness}%</span>
          </div>
          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-white rounded-full transition-all" style={{ width: `${brightness}%` }} />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-[10px] text-white/40 mb-1.5">
            <span>Volume</span><span>{volume}%</span>
          </div>
          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-white rounded-full transition-all" style={{ width: `${volume}%` }} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 mt-6">
        <ControlTile active={false} onClick={() => alert('Flashlight toggled via native API')} icon={<Zap className="w-5 h-5" />} label="Flash" />
        <ControlTile active={false} onClick={() => alert('Rotation lock toggled')} icon={<RotateCcw className="w-5 h-5" />} label="Rotate" />
        <ControlTile active={false} onClick={() => alert('Battery saver toggled')} icon={<Battery className="w-5 h-5" />} label="Battery" />
        <ControlTile active={false} onClick={() => alert('Media controls')} icon={<Music2 className="w-5 h-5" />} label="Music" />
      </div>
    </div>
  );
}

function ControlTile({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-2 p-4 rounded-3xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors">
      <div className={`p-3 rounded-2xl ${active ? 'bg-blue-500/20 text-blue-400' : 'bg-white/10 text-white/70'}`}>
        {icon}
      </div>
      <span className="text-[10px] font-medium text-white/60">{label}</span>
    </button>
  );
}

/* ================================================================
   BOTTOM ACTIONS
   ================================================================ */

function BottomActions({ onSearch, onLibrary, onControl }: { onSearch: () => void; onLibrary: () => void; onControl: () => void }) {
  return (
    <div className="fixed bottom-28 left-0 right-0 z-20 flex justify-center gap-6">
      <button onClick={onSearch} className="p-3 rounded-full bg-white/5 backdrop-blur-md border border-white/10 hover:bg-white/10 hover:scale-110 transition-all shadow-lg shadow-black/20">
        <Search className="w-5 h-5 text-white/80" />
      </button>
      <button onClick={onLibrary} className="p-3 rounded-full bg-white/5 backdrop-blur-md border border-white/10 hover:bg-white/10 hover:scale-110 transition-all shadow-lg shadow-black/20">
        <Grid3X3 className="w-5 h-5 text-white/80" />
      </button>
      <button onClick={onControl} className="p-3 rounded-full bg-white/5 backdrop-blur-md border border-white/10 hover:bg-white/10 hover:scale-110 transition-all shadow-lg shadow-black/20">
        <Menu className="w-5 h-5 text-white/80" />
      </button>
    </div>
  );
}
