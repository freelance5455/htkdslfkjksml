import { useCallback, useEffect, useRef, useState } from 'react';
import { BodycamGameEngine } from './game/engine';
import { BodycamSettings, GameHudState } from './game/types';
import { BodycamOverlay } from './components/BodycamOverlay';
import { BriefingModal } from './components/BriefingModal';
import { MobileControls } from './components/MobileControls';

const INITIAL_SETTINGS: BodycamSettings = {
  opticalMode: 'standard',
  lightingMood: 'flare_night',
  distortion: 0.45,
  grain: 0.42,
  aberration: 0.45,
  exposure: 1.15,
  flashlightOn: true,
  audioEnabled: true,
  mouseSensitivity: 1.0,
};

const INITIAL_HUD: GameHudState = {
  phase: 'briefing',
  health: 100,
  maxHealth: 100,
  ammo: 15,
  magSize: 15,
  reserveAmmo: 75,
  isReloading: false,
  isAiming: false,
  isSprinting: false,
  isCrouching: false,
  flashlightOn: true,
  flashlightBattery: 100,
  drivesCollected: 0,
  totalDrives: 3,
  hostilesNeutralized: 0,
  totalHostiles: 4,
  extractionReady: false,
  nearbyPrompt: null,
  currentZone: 'Staging Approach Trench',
  hitMarkerTimer: 0,
  damageFlashTimer: 0,
  elapsedSeconds: 0,
  pointerLocked: false,
  statusBanner: null,
};

function detectTouchDevice(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia?.('(pointer: coarse)').matches ||
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0
  );
}

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BodycamGameEngine | null>(null);

  const [settings, setSettings] = useState<BodycamSettings>(INITIAL_SETTINGS);
  const [hud, setHud] = useState<GameHudState>(INITIAL_HUD);
  const [mobileControlsEnabled, setMobileControlsEnabled] = useState<boolean>(detectTouchDevice);
  const [webglError, setWebglError] = useState(false);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    try {
      const engine = new BodycamGameEngine(
        mount,
        INITIAL_SETTINGS,
        (nextHud) => setHud(nextHud),
        () => setWebglError(true),
      );
      engineRef.current = engine;

      return () => {
        engine.dispose();
        engineRef.current = null;
      };
    } catch {
      setWebglError(true);
    }
  }, []);

  const handleUpdateSettings = useCallback((partial: Partial<BodycamSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial };
      engineRef.current?.updateSettings(partial);
      return next;
    });
  }, []);

  const handleToggleMobileControls = useCallback(() => {
    setMobileControlsEnabled((prev) => !prev);
  }, []);

  const handleStart = useCallback(() => {
    engineRef.current?.startMission();
  }, []);

  const handleResume = useCallback(() => {
    engineRef.current?.resumeMission();
  }, []);

  const handleRestart = useCallback(() => {
    engineRef.current?.restartMission();
  }, []);

  const handlePause = useCallback(() => {
    engineRef.current?.pauseMission();
  }, []);

  const handleLockPointer = useCallback(() => {
    engineRef.current?.requestLock();
  }, []);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-zinc-950">
      {/* Isolated WebGL Mount Container */}
      <div ref={canvasMountRef} className="fixed inset-0 h-full w-full" />

      {webglError && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-zinc-950 p-6 text-center">
          <div className="max-w-md rounded border border-zinc-800 bg-zinc-900 p-6">
            <h2 className="font-display text-2xl font-bold text-white">
              3D Viewport Unavailable
            </h2>
            <p className="mt-2 text-sm text-zinc-400">
              Hardware or WebGL rendering context could not be initialized in this browser session.
            </p>
          </div>
        </div>
      )}

      {/* Bodycam HUD & Collapsible Bottom Optical Dock */}
      <BodycamOverlay
        hud={hud}
        settings={settings}
        mobileControlsEnabled={mobileControlsEnabled}
        onToggleMobileControls={handleToggleMobileControls}
        onUpdateSettings={handleUpdateSettings}
        onPause={handlePause}
        onLockPointer={handleLockPointer}
      />

      {/* Multi-Touch Mobile Controls Overlay */}
      {mobileControlsEnabled && (
        <MobileControls
          hud={hud}
          onMove={(x, y, sprint) => engineRef.current?.setTouchMove(x, y, sprint)}
          onLook={(dx, dy) => engineRef.current?.addTouchLook(dx, dy)}
          onFire={() => engineRef.current?.triggerTouchFire()}
          onToggleAim={() => engineRef.current?.toggleTouchAim()}
          onReload={() => engineRef.current?.triggerTouchReload()}
          onInteract={() => engineRef.current?.triggerTouchInteract()}
          onToggleFlashlight={() => {
            engineRef.current?.toggleFlashlight();
            setSettings((prev) => ({ ...prev, flashlightOn: !prev.flashlightOn }));
          }}
          onToggleCrouch={() => engineRef.current?.toggleCrouch()}
        />
      )}

      {/* Mission Briefing / Pause / Extraction Overlay */}
      <BriefingModal
        hud={hud}
        settings={settings}
        mobileControlsEnabled={mobileControlsEnabled}
        onToggleMobileControls={handleToggleMobileControls}
        onUpdateSettings={handleUpdateSettings}
        onStart={handleStart}
        onResume={handleResume}
        onRestart={handleRestart}
      />
    </div>
  );
}
