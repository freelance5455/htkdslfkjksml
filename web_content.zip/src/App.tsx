import React, { useState, useEffect } from 'react';
import { SIMSlot, TelecomOperator, CNICRecord, SendingEntry, ReplyEntry, Language } from './types';
import { loadSavedState, saveState, clearAllStorage } from './utils/storage';
import { generatePTA668Reply } from './utils/cnic';
import { sounds } from './utils/audio';
import { Header } from './components/Header';
import { TopBar } from './components/TopBar';
import { SimCard } from './components/SimCard';
import { CnicCard } from './components/CnicCard';
import { SmsRequestCard } from './components/SmsRequestCard';
import { SendingMonitorCard } from './components/SendingMonitorCard';
import { ReplyMonitorCard } from './components/ReplyMonitorCard';
import { DataManagementCard } from './components/DataManagementCard';
import { WhatsAppCard } from './components/WhatsAppCard';
import { Footer } from './components/Footer';
import { ToastContainer, ToastMessage } from './components/Toast';

export default function App() {
  const [initialData] = useState(() => loadSavedState());

  const [records, setRecords] = useState<CNICRecord[]>(initialData.records);
  const [sending, setSending] = useState<SendingEntry[]>(initialData.sending);
  const [replies, setReplies] = useState<ReplyEntry[]>(initialData.replies);
  const [selectedSim, setSelectedSim] = useState<SIMSlot>(initialData.selectedSim);
  const [operator, setOperator] = useState<TelecomOperator>('Jazz');
  const [selectedIndex, setSelectedIndex] = useState<number>(() => {
    return initialData.records.length > 0 ? 0 : -1;
  });
  const [language, setLanguage] = useState<Language>(initialData.language);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(initialData.soundEnabled);
  const [animationEnabled, setAnimationEnabled] = useState<boolean>(initialData.animationEnabled);
  const [sendStatusText, setSendStatusText] = useState<string>('SYSTEM READY');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sound sync
  useEffect(() => {
    sounds.setEnabled(soundEnabled);
    saveState({ soundEnabled });
  }, [soundEnabled]);

  // Animation sync
  useEffect(() => {
    saveState({ animationEnabled });
  }, [animationEnabled]);

  // Language & document direction sync
  useEffect(() => {
    saveState({ language });
    if (typeof document !== 'undefined') {
      document.documentElement.lang = language;
      document.documentElement.dir = language === 'ur' ? 'rtl' : 'ltr';
    }
  }, [language]);

  // Persistence of core lists
  useEffect(() => {
    saveState({
      records,
      sending,
      replies,
      selectedSim,
    });
  }, [records, sending, replies, selectedSim]);

  // Show Toast helper
  const showToast = (message: string, type: 'success' | 'warning' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Add CNIC
  const handleAddRecord = (record: CNICRecord) => {
    setRecords((prev) => {
      const next = [...prev, record];
      setSelectedIndex(next.length - 1);
      return next;
    });
  };

  // Delete individual record
  const handleDeleteRecord = (id: string) => {
    setRecords((prev) => {
      const filtered = prev.filter((r) => r.id !== id);
      if (selectedIndex >= filtered.length) {
        setSelectedIndex(filtered.length - 1);
      }
      return filtered;
    });
    showToast(language === 'ur' ? 'ریکارڈ حذف کر دیا گیا' : 'Record removed', 'info');
  };

  // Select Record
  const handleSelectRecord = (index: number) => {
    setSelectedIndex(index);
  };

  // SMS Request (PTA 668)
  const handleSendRequest = () => {
    if (selectedIndex < 0 || !records[selectedIndex]) return;

    const currentRecord = records[selectedIndex];
    const timestamp = new Date().toLocaleTimeString();

    // Mark record status as 'Demo'
    setRecords((prev) =>
      prev.map((r, i) => (i === selectedIndex ? { ...r, status: 'Demo' } : r))
    );

    // Add to Sending history
    const sendEntry: SendingEntry = {
      id: `send-${Date.now()}`,
      cnic: currentRecord.cnic,
      sim: `${selectedSim} (${operator})`,
      destination: '668',
      time: timestamp,
      status: 'Demo only',
      rawTime: Date.now(),
    };
    setSending((prev) => [sendEntry, ...prev]);

    setSendStatusText('DEMO REQUEST RECORDED');

    // Simulate authentic PTA 668 SMS reply
    const ptaReply = generatePTA668Reply(currentRecord.cnic);
    const newReply: ReplyEntry = {
      id: `reply-${Date.now()}`,
      cnic: currentRecord.cnic,
      time: timestamp,
      sim: `${selectedSim} (${operator})`,
      rawText: ptaReply.rawText,
      parsedBreakdown: ptaReply.breakdown,
    };

    setReplies((prev) => [newReply, ...prev]);
  };

  // Direct manual simulation for active record
  const handleSimulateReply = () => {
    if (selectedIndex < 0 || !records[selectedIndex]) return;
    const targetCnic = records[selectedIndex].cnic;
    const ptaReply = generatePTA668Reply(targetCnic);
    const newReply: ReplyEntry = {
      id: `reply-manual-${Date.now()}`,
      cnic: targetCnic,
      time: new Date().toLocaleTimeString(),
      sim: `${selectedSim} (${operator})`,
      rawText: ptaReply.rawText,
      parsedBreakdown: ptaReply.breakdown,
    };
    setReplies((prev) => [newReply, ...prev]);
    showToast(
      language === 'ur'
        ? `CNIC ${targetCnic} کے لیے 668 جوابی پیغام موصول ہو گیا`
        : `668 PTA response parsed for CNIC ${targetCnic}`,
      'success'
    );
  };

  // Clear Sending history
  const handleClearHistory = () => {
    setSending([]);
    showToast(language === 'ur' ? 'ارسال کی تاریخ صاف کر دی گئی' : 'Sending history cleared', 'info');
  };

  // Delete all data
  const handleDeleteAll = () => {
    clearAllStorage();
    setRecords([]);
    setSending([]);
    setReplies([]);
    setSelectedIndex(-1);
    setSendStatusText('SYSTEM READY');
  };

  const selectedRecord = selectedIndex >= 0 && records[selectedIndex] ? records[selectedIndex] : null;

  return (
    <div className={`min-h-screen bg-radial from-[#1e3b66] via-[#091122] to-[#040813] text-white selection:bg-cyan-400 selection:text-black ${language === 'ur' ? 'font-urdu' : ''}`}>
      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Header with 3D Logo and controls */}
      <Header
        language={language}
        onLanguageChange={setLanguage}
        soundEnabled={soundEnabled}
        onSoundToggle={() => setSoundEnabled(!soundEnabled)}
        animationEnabled={animationEnabled}
        onAnimationToggle={() => setAnimationEnabled(!animationEnabled)}
      />

      {/* Real-time Top Clock & Date Bar */}
      <TopBar language={language} />

      {/* Main Container */}
      <main className="max-w-[680px] mx-auto p-3 sm:p-5 space-y-4">
        {/* SIM Selection Card */}
        <SimCard
          selectedSim={selectedSim}
          onSimChange={setSelectedSim}
          operator={operator}
          onOperatorChange={setOperator}
          language={language}
        />

        {/* CNIC Entry & Records Card */}
        <CnicCard
          records={records}
          selectedIndex={selectedIndex}
          onSelectRecord={handleSelectRecord}
          onAddRecord={handleAddRecord}
          onDeleteRecord={handleDeleteRecord}
          selectedSim={selectedSim}
          operator={operator}
          language={language}
          onShowToast={showToast}
        />

        {/* 668 SMS Request Card */}
        <SmsRequestCard
          selectedSim={selectedSim}
          operator={operator}
          selectedRecord={selectedRecord}
          onSendRequest={handleSendRequest}
          sendStatusText={sendStatusText}
          language={language}
          onShowToast={showToast}
        />

        {/* Sending Monitor & History Card */}
        <SendingMonitorCard
          records={records}
          sending={sending}
          onClearHistory={handleClearHistory}
          language={language}
        />

        {/* Reply Monitor Card */}
        <ReplyMonitorCard
          replies={replies}
          onSimulateReplyForSelected={handleSimulateReply}
          hasSelectedCnic={Boolean(selectedRecord)}
          language={language}
          onShowToast={showToast}
        />

        {/* Data Management Card */}
        <DataManagementCard
          records={records}
          sending={sending}
          replies={replies}
          onDeleteAll={handleDeleteAll}
          language={language}
          onShowToast={showToast}
        />

        {/* 24/7 WhatsApp Support Card */}
        <WhatsAppCard
          language={language}
          onShowToast={showToast}
        />
      </main>

      {/* Footer */}
      <Footer language={language} />
    </div>
  );
}
