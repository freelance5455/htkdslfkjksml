/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ConverterView } from './components/ConverterView';
import { HistoryView } from './components/HistoryView';
import { AboutView } from './components/AboutView';
import { BottomNav } from './components/BottomNav';
import { SettingsModal } from './components/SettingsModal';
import { ActiveTab, AppSettings, ConversionRecord } from './types';

const STORAGE_KEY_HISTORY = 'jaswanth_time_converter_history';
const STORAGE_KEY_SETTINGS = 'jaswanth_time_converter_settings';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('converter');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [presetToLoad, setPresetToLoad] = useState<ConversionRecord | null>(null);

  // Settings state with local storage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          use24Hour: parsed.use24Hour ?? false,
          showKillzones: parsed.showKillzones ?? true,
          audioTick: parsed.audioTick ?? false,
          autoSaveHistory: parsed.autoSaveHistory ?? true,
        };
      }
    } catch {
      // Ignore
    }
    return {
      use24Hour: false,
      showKillzones: true,
      audioTick: false,
      autoSaveHistory: true,
    };
  });

  // History state with local storage
  const [history, setHistory] = useState<ConversionRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Ignore
    }
    return [];
  });

  // Save settings changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch {
      // Ignore
    }
  }, [settings]);

  // Save history changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(history));
    } catch {
      // Ignore
    }
  }, [history]);

  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const handleSaveRecord = (record: ConversionRecord) => {
    if (!settings.autoSaveHistory) return;
    setHistory((prev) => {
      // Avoid duplicate consecutive entries with identical times
      const isDuplicate = prev.length > 0 && 
        prev[0].nyDateFormatted === record.nyDateFormatted && 
        prev[0].nyTimeFormatted === record.nyTimeFormatted;
      if (isDuplicate) return prev;
      return [record, ...prev.slice(0, 49)]; // Keep latest 50
    });
  };

  const handleDeleteRecord = (id: string) => {
    setHistory((prev) => prev.filter((r) => r.id !== id));
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleLoadRecord = (record: ConversionRecord) => {
    setPresetToLoad(record);
    setActiveTab('converter');
  };

  return (
    <div className="min-h-screen bg-[#f5f7fa] text-slate-900 font-sans flex flex-col justify-between">
      {/* Mobile container centered on larger screens */}
      <div className="w-full max-w-md mx-auto px-4 pt-3 pb-6 flex-1 flex flex-col">
        {/* Header */}
        <Header onOpenSettings={() => setIsSettingsOpen(true)} />

        {/* Dynamic Tab Content */}
        <main className="flex-1 mt-1">
          {activeTab === 'converter' && (
            <ConverterView
              settings={settings}
              onSaveRecord={handleSaveRecord}
              presetToLoad={presetToLoad}
              onClearPreset={() => setPresetToLoad(null)}
            />
          )}

          {activeTab === 'history' && (
            <HistoryView
              history={history}
              onLoadRecord={handleLoadRecord}
              onDeleteRecord={handleDeleteRecord}
              onClearHistory={handleClearHistory}
            />
          )}

          {activeTab === 'about' && <AboutView />}
        </main>
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onClearHistory={handleClearHistory}
        onClose={() => setIsSettingsOpen(false)}
        historyCount={history.length}
      />

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        historyCount={history.length}
      />
    </div>
  );
}
