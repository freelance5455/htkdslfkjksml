import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { StoreProvider, useStore } from './context/StoreContext';
import { Navbar } from './components/layout/Navbar';
import { AdminDashboard } from './pages/AdminDashboard';
import { StudentDashboard } from './pages/StudentDashboard';
import { TestAttemptPage } from './pages/TestAttempt';
import { AnalysisReport } from './pages/AnalysisReport';

const AppContent = () => {
  const { role } = useStore();

  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      <Navbar />
      <main className="p-4 sm:p-6 lg:p-8">
        <Routes>
          <Route 
            path="/" 
            element={role === 'admin' ? <AdminDashboard /> : <StudentDashboard />} 
          />
          <Route path="/attempt/:id" element={<TestAttemptPage />} />
          <Route path="/analysis/:id" element={<AnalysisReport />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <Router>
        <AppContent />
      </Router>
    </StoreProvider>
  );
}
