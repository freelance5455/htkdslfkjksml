import { useCallback, useEffect, useRef, useState } from "react";
import {
  DEFAULT_KEYMAP,
  DEFAULT_SETTINGS,
  Game,
  prettyKey,
  type Action,
  type GameSettings,
  type GameState,
} from "./game/engine";
import type { BuildKind } from "./game/builds";
import type { ItemDef } from "./game/items";
import { installPanelTextures } from "./game/textures";
import Title from "./ui/Title";
import Hud from "./ui/Hud";
import Store from "./ui/Store";
import SettingsPanel from "./ui/Settings";

type Panel = "none" | "store" | "settings" | "pause" | "help";

const EMPTY_STATE: GameState = {
  health: 100,
  armour: 0,
  coins: 12000,
  ammo: 240,
  rockets: 12,
  slot: 3,
  hotbar: ["block:3", "block:8", "block:9", "sword", "rifle", "bazooka", "armour", "", ""],
  vehicle: null,
  speed: 0,
  altitude: 40,
  flying: false,
  fps: 60,
  x: 64,
  y: 40,
  z: 64,
  dead: false,
  messages: [],
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [screen, setScreen] = useState<"title" | "loading" | "game">("title");
  const [panel, setPanel] = useState<Panel>("none");
  const [state, setState] = useState<GameState>(EMPTY_STATE);
  const [ready, setReady] = useState(false);
  const [locked, setLocked] = useState(false);
  const [coins, setCoins] = useState(12000);
  const [owned, setOwned] = useState<string[]>(() => load<string[]>("vc.owned", []));
  const [keymap, setKeymap] = useState<Record<Action, string>>(() =>
    load("vc.keymap", { ...DEFAULT_KEYMAP }),
  );
  const [settings, setSettings] = useState<GameSettings>(() =>
    load("vc.settings", { ...DEFAULT_SETTINGS }),
  );

  const containerRef = useRef<HTMLDivElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  const isTouch =
    typeof window !== "undefined" &&
    (("ontouchstart" in window && window.innerWidth < 1100) || navigator.maxTouchPoints > 1);

  useEffect(() => installPanelTextures(), []);
  useEffect(() => {
    const onChange = () => setLocked(!!document.pointerLockElement);
    document.addEventListener("pointerlockchange", onChange);
    return () => document.removeEventListener("pointerlockchange", onChange);
  }, []);
  useEffect(() => localStorage.setItem("vc.owned", JSON.stringify(owned)), [owned]);
  useEffect(() => localStorage.setItem("vc.keymap", JSON.stringify(keymap)), [keymap]);
  useEffect(() => localStorage.setItem("vc.settings", JSON.stringify(settings)), [settings]);

  /* ---------------- engine lifecycle ---------------- */
  useEffect(() => {
    if (screen !== "loading") return;
    const el = containerRef.current;
    if (!el) return;
    const timer = window.setTimeout(() => {
      const game = new Game(el, {
        keymap,
        settings,
        onState: (s) => {
          setState(s);
          setCoins(s.coins);
        },
        onPause: (reason) => {
          const g = gameRef.current;
          if (g) {
            g.setPaused(true);
            if (document.pointerLockElement) document.exitPointerLock();
          }
          setPanel(reason);
        },
      });
      gameRef.current = game;
      game.setCoins(coins);
      setReady(true);
      setScreen("game");
      game.requestLock();
    }, 80);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen]);

  useEffect(() => {
    return () => {
      gameRef.current?.dispose();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    gameRef.current?.setKeymap(keymap);
  }, [keymap]);
  useEffect(() => {
    gameRef.current?.setSettings(settings);
  }, [settings]);

  /* ---------------- panel open/close ---------------- */
  const openPanel = useCallback((p: Panel) => {
    setPanel(p);
    const g = gameRef.current;
    if (g) {
      g.setPaused(true);
      if (document.pointerLockElement) document.exitPointerLock();
    }
  }, []);

  const closePanel = useCallback(() => {
    setPanel("none");
    const g = gameRef.current;
    if (g) {
      g.setPaused(false);
      g.requestLock();
    }
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Escape") return;
      if (document.querySelector('[data-rebinding="true"]')) return;
      if (panel !== "none") closePanel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [panel, closePanel]);

  /* ---------------- store ---------------- */
  const handleBuy = (item: ItemDef) => {
    const g = gameRef.current;
    const repeatable = item.action === "give" && item.category !== "armour";
    const alreadyOwned = owned.includes(item.id);
    const cost = alreadyOwned && !repeatable ? 0 : item.price;

    if (cost > 0) {
      if (g) {
        if (!g.spend(cost)) return;
      } else {
        if (coins < cost) return;
        setCoins((c) => c - cost);
      }
      setOwned((prev) => (prev.includes(item.id) ? prev : [...prev, item.id]));
    }

    if (!g) return;

    if (item.action === "give") {
      g.give(item.id);
    } else if (item.action === "equip") {
      if (item.payload === "armour") {
        g.give("armour");
        g.heal();
      } else {
        g.give(item.payload);
      }
    } else if (item.action === "spawn") {
      g.spawnVehicle(item.payload as "car" | "bus" | "truck" | "plane");
    } else if (item.action === "build") {
      g.buildAt(item.payload as BuildKind);
    }
    if (item.action === "spawn" || item.action === "build") closePanel();
  };

  const changeKey = (action: Action, code: string) => {
    if ((action as string) === "__reset__") {
      setKeymap({ ...DEFAULT_KEYMAP });
      return;
    }
    setKeymap((prev) => {
      const next = { ...prev };
      for (const k of Object.keys(next)) {
        if (next[k as Action] === code) next[k as Action] = "";
      }
      next[action] = code;
      return next;
    });
  };

  const startGame = () => {
    setScreen("loading");
    setPanel("none");
  };

  const quitToTitle = () => {
    gameRef.current?.dispose();
    gameRef.current = null;
    setReady(false);
    setPanel("none");
    setScreen("title");
  };

  const showGame = screen !== "title";

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0e0b08]">
      {showGame && (
        <div
          ref={containerRef}
          className="absolute inset-0"
          style={{ cursor: !ready ? "default" : locked ? "none" : "crosshair" }}
        />
      )}

      {/* ---------------- world HUD ---------------- */}
      {showGame && ready && panel === "none" && (
        <Hud
          state={state}
          hudScale={settings.hudScale}
          showDebug={settings.showDebug}
          isTouch={isTouch}
          onSlot={(i) => gameRef.current?.setSlot(i)}
          onTouchKey={(a, down) => gameRef.current?.setVirtualKey(a, down)}
          onLook={(dx, dy) => gameRef.current?.lookDelta(dx, dy)}
        />
      )}

      {/* ---------------- loading ---------------- */}
      {screen === "loading" && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#0e0b08]">
          <div className="font-title text-lg text-white mc-shadow">GENERATING WORLD</div>
          <div className="mt-6 h-4 w-[260px] border-2 border-black bg-[#1c1c1c]">
            <div className="blink h-full w-2/3 bg-[#7ec850]" />
          </div>
          <div className="mt-4 text-[9px] tracking-[0.28em] text-[#b7ada0]">
            CARVING TERRAIN · PLANTING TREES · MESHING CHUNKS
          </div>
        </div>
      )}

      {/* ---------------- title ---------------- */}
      {screen === "title" && (
        <Title
          onPlay={startGame}
          onStore={() => openPanel("store")}
          onSettings={() => openPanel("settings")}
          onHelp={() => openPanel("help")}
        />
      )}

      {/* ---------------- pause ---------------- */}
      {panel === "pause" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#0e0b08]/78 p-4">
          <div className="mc-panel snap-in w-full max-w-[420px] p-8 text-center">
            <div className="text-[9px] tracking-[0.32em] text-[#b7ada0]">GAME PAUSED</div>
            <h2 className="font-title mt-3 text-xl text-white mc-shadow">VOXELCRAFT</h2>
            <div className="mt-8 flex flex-col gap-3">
              <button className="mc-btn mc-btn--grass py-3" onClick={closePanel}>
                BACK TO GAME
              </button>
              <button className="mc-btn py-3" onClick={() => openPanel("store")}>
                STORE
              </button>
              <button className="mc-btn py-3" onClick={() => openPanel("settings")}>
                SETTINGS
              </button>
              <button className="mc-btn py-3" onClick={() => openPanel("help")}>
                HOW TO PLAY
              </button>
              <button className="mc-btn mc-btn--danger py-3" onClick={quitToTitle}>
                QUIT TO TITLE
              </button>
            </div>
            <div className="mt-6 text-[9px] leading-[2] tracking-[0.18em] text-[#b7ada0]">
              {prettyKey(keymap.store)} STORE · {prettyKey(keymap.settings)} SETTINGS ·{" "}
              {prettyKey(keymap.interact)} DRIVE · {prettyKey(keymap.fly)} FLY
            </div>
          </div>
        </div>
      )}

      {/* ---------------- help ---------------- */}
      {panel === "help" && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#0e0b08]/82 p-4">
          <div className="mc-panel snap-in max-h-[86vh] w-full max-w-[720px] overflow-y-auto p-7 mc-scroll">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[9px] tracking-[0.32em] text-[#b7ada0]">
                  FIELD MANUAL · EDITION 1.0
                </div>
                <h2 className="font-title mt-3 text-lg text-white mc-shadow">HOW TO PLAY</h2>
              </div>
              <button className="mc-btn" onClick={closePanel}>
                ✕ CLOSE
              </button>
            </div>

            <div className="mt-6 grid gap-2 sm:grid-cols-2">
              {[
                ["Move", `${prettyKey(keymap.forward)} ${prettyKey(keymap.left)} ${prettyKey(keymap.backward)} ${prettyKey(keymap.right)}`],
                ["Jump / Swim", prettyKey(keymap.jump)],
                ["Sprint", prettyKey(keymap.sprint)],
                ["Toggle Fly", prettyKey(keymap.fly)],
                ["Break / Fire", `${prettyKey(keymap.attack)} (mouse)`],
                ["Place block", `${prettyKey(keymap.use)} (mouse)`],
                ["Drive / exit vehicle", prettyKey(keymap.interact)],
                ["Open store", prettyKey(keymap.store)],
                ["Settings", prettyKey(keymap.settings)],
                ["Debug overlay", prettyKey(keymap.debug)],
              ].map(([label, keys]) => (
                <div
                  key={label}
                  className="mc-panel--stone mc-panel flex items-center justify-between px-3 py-2"
                >
                  <span className="text-[10px] text-[#e6e0d7]">{label}</span>
                  <span className="text-[10px] text-[#ffffa0] mc-shadow-sm">{keys}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 space-y-3 text-[10px] leading-[2.1] text-[#b7ada0]">
              <p>
                <span className="text-[#7ec850]">VEHICLES.</span> Buy a car, bus, truck or plane in
                the Store — it spawns nine blocks in front of you. Walk up to it and press{" "}
                <span className="text-[#ffffa0]">{prettyKey(keymap.interact)}</span> to drive.
                Vehicles follow the terrain, so the highway preset is the best place to open the
                throttle. In a plane, {prettyKey(keymap.jump)} climbs and {prettyKey(keymap.sneak)}{" "}
                descends.
              </p>
              <p>
                <span className="text-[#7ec850]">WEAPONS.</span> The diamond sword breaks any block
                in one hit. The assault rifle is hitscan with tracer, muzzle flash and recoil — hold
                to fire. The bazooka launches a rocket that carves a real four-block crater out of
                the terrain and shakes the camera.
              </p>
              <p>
                <span className="text-[#7ec850]">BUILD PRESETS.</span> The mansion, bungalow and
                highway are written into the voxel world block by block, so you can walk straight in
                and keep building on top of them.
              </p>
              <p>
                <span className="text-[#7ec850]">CONTROLS.</span> Every button is rebindable in
                Settings, alongside mouse sensitivity, field of view, render scale and HUD scale.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- store / settings ---------------- */}
      {panel === "store" && (
        <Store
          coins={gameRef.current && ready ? state.coins : coins}
          owned={owned}
          onBuy={handleBuy}
          onClose={closePanel}
        />
      )}
      {panel === "settings" && (
        <SettingsPanel
          keymap={keymap}
          settings={settings}
          onChangeKey={changeKey}
          onChangeSettings={setSettings}
          onClose={closePanel}
        />
      )}

      {/* ---------------- corner shortcut ---------------- */}
      {showGame && ready && panel === "none" && (
        <button
          className="mc-btn absolute right-3 top-28 z-20 px-3 py-2 text-[10px]"
          onClick={() => openPanel("store")}
        >
          STORE
        </button>
      )}
    </div>
  );
}
