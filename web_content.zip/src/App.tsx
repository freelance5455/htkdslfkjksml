/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Trophy,
  Zap,
  TrendingUp,
  Award,
  BookOpen,
  User,
  Shield,
  Layers,
  Flame,
  History,
  MoreHorizontal,
  X,
} from 'lucide-react';
import type {
  AppState,
  Player,
  Category,
  Season,
  DailyRecord,
  WeeklyResult,
  HistoricalRank,
} from './types/index.ts';
import {
  getSaoPauloDateString,
  getSaoPauloWeekRange,
  calculateWeeklyRanking,
  calculateHistoricalRankings,
} from './utils/garrafoesLogic.ts';

import { Header } from './components/Header.tsx';
import { WelcomeModal } from './components/WelcomeModal.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { AttemptRecorder } from './components/AttemptRecorder.tsx';
import { WeeklyRankingView } from './components/WeeklyRankingView.tsx';
import { AllTimeRankingView } from './components/AllTimeRankingView.tsx';
import { PlayerProfileView } from './components/PlayerProfileView.tsx';
import { AchievementsGallery } from './components/AchievementsGallery.tsx';
import { TrickCatalogView } from './components/TrickCatalogView.tsx';
import { GroupManagementView } from './components/GroupManagementView.tsx';
import { AuditCorrectionModal } from './components/AuditCorrectionModal.tsx';
import { SeasonDetailModal } from './components/SeasonDetailModal.tsx';

type Tab =
  | 'painel'
  | 'registrar'
  | 'ranking'
  | 'historico'
  | 'perfil'
  | 'conquistas'
  | 'manobras'
  | 'gestao';

export default function App() {
  const [state, setState] = useState<AppState | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('painel');
  const [activePlayerId, setActivePlayerId] = useState<string | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('cat-200g');
  const [isWelcomeOpen, setIsWelcomeOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [correctionRecord, setCorrectionRecord] = useState<DailyRecord | null>(null);
  const [isCorrectionOpen, setIsCorrectionOpen] = useState(false);
  const [inspectSeason, setInspectSeason] = useState<Season | null>(null);
  const [inspectedPlayerId, setInspectedPlayerId] = useState<string | null>(null);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Fetch state from server
  const fetchState = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = await res.json();
        if (data.state) {
          setState(data.state);
        }
      }
    } catch (err) {
      console.error('Error fetching state:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  // On mount: load saved player & fetch state
  useEffect(() => {
    const savedPlayerId = localStorage.getItem('garrafoes_player_id');
    if (savedPlayerId) {
      setActivePlayerId(savedPlayerId);
    } else {
      setIsWelcomeOpen(true);
    }

    fetchState();
    // Periodic refresh every 15s to keep shared data synced
    const interval = setInterval(fetchState, 15000);
    return () => clearInterval(interval);
  }, []);

  const activePlayer = useMemo(() => {
    if (!state || !activePlayerId) return null;
    return state.players.find((p) => p.id === activePlayerId) || null;
  }, [state, activePlayerId]);

  const currentSeason = useMemo(() => {
    if (!state) return null;
    return state.seasons.find((s) => s.id === state.currentSeasonId) || state.seasons[state.seasons.length - 1];
  }, [state]);

  const closedSeasons = useMemo(() => {
    if (!state) return [];
    return state.seasons.filter((s) => s.status === 'closed');
  }, [state]);

  const todayDateStr = useMemo(() => {
    return getSaoPauloDateString();
  }, []);

  // Compute live weekly rankings for current season across all categories
  const currentWeeklyRankings = useMemo(() => {
    if (!state || !currentSeason) return {};
    const map: Record<string, WeeklyResult[]> = {};

    for (const cat of state.categories) {
      const playersInput = state.players.map((p) => {
        const records = state.dailyRecords.filter(
          (r) =>
            r.playerId === p.id &&
            r.categoryId === cat.id &&
            r.localDate >= currentSeason.startDate &&
            r.localDate <= currentSeason.endDate
        );
        return {
          playerId: p.id,
          records,
        };
      });

      map[cat.id] = calculateWeeklyRanking(currentSeason.id, cat.id, playersInput);
    }
    return map;
  }, [state, currentSeason]);

  // Compute historical rankings across closed seasons
  const historicalRankings = useMemo(() => {
    if (!state) return [];
    const playerIds = state.players.map((p) => p.id);
    return calculateHistoricalRankings(closedSeasons, selectedCategoryId, playerIds);
  }, [state, closedSeasons, selectedCategoryId]);

  const handleSelectPlayer = (player: Player) => {
    setActivePlayerId(player.id);
    localStorage.setItem('garrafoes_player_id', player.id);
    setIsWelcomeOpen(false);
    if (player.role === 'admin') {
      setIsAdmin(true);
    }
    showToast(`Bem-vindo, ${player.name}!`);
  };

  const handleSaveAttempt = async (count: number): Promise<boolean> => {
    if (!activePlayer) return false;
    try {
      const res = await fetch('/api/attempts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          playerId: activePlayer.id,
          categoryId: selectedCategoryId,
          count,
          localDate: todayDateStr,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        await fetchState();
        if (data.improved) {
          showToast(`Novo recorde diário de hoje: ${data.dailyRecord.bestStreak} acertos!`);
        } else {
          showToast(`Tentativa de ${count} registrada. Recorde diário mantido: ${data.dailyRecord.bestStreak}.`);
        }
        return true;
      } else {
        const err = await res.json();
        showToast(err.error || 'Erro ao registrar tentativa.');
        return false;
      }
    } catch (e) {
      console.error(e);
      showToast('Falha na conexão ao salvar tentativa.');
      return false;
    }
  };

  const handleSubmitCorrection = async (data: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/records/correct', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (res.ok) {
        await fetchState();
        showToast('Registro corrigido e registrado na auditoria com sucesso!');
        return true;
      } else {
        const err = await res.json();
        alert(err.error || 'Erro ao submeter correção.');
        return false;
      }
    } catch (e) {
      console.error(e);
      alert('Falha na conexão.');
      return false;
    }
  };

  const handleCreateTrick = async (data: any): Promise<boolean> => {
    if (!activePlayer) return false;
    try {
      const res = await fetch('/api/tricks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          authorId: activePlayer.id,
        }),
      });

      if (res.ok) {
        await fetchState();
        showToast('Rascunho de manobra criado! Valide 5 acertos para liberar no catálogo.');
        return true;
      } else {
        const err = await res.json();
        alert(err.error || 'Erro ao propor manobra.');
        return false;
      }
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleExecuteTrick = async (trickId: string) => {
    if (!activePlayer) return;
    try {
      const res = await fetch(`/api/tricks/${trickId}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerId: activePlayer.id }),
      });
      if (res.ok) {
        const data = await res.json();
        await fetchState();
        showToast(`+1 acerto registrado! Total pessoal: ${data.count}`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePublishTrick = async (trickId: string): Promise<boolean> => {
    if (!activePlayer) return false;
    try {
      const res = await fetch(`/api/tricks/${trickId}/publish`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ authorId: activePlayer.id }),
      });
      if (res.ok) {
        await fetchState();
        showToast('Parabéns! Manobra validada e publicada com sucesso no catálogo oficial!');
        return true;
      } else {
        const err = await res.json();
        alert(err.error || 'Erro ao publicar.');
        return false;
      }
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleUpdatePlayerPhoto = async (playerId: string, avatarUrl: string) => {
    try {
      const res = await fetch(`/api/players/${playerId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ avatarUrl }),
      });
      if (res.ok) {
        await fetchState();
        showToast('Foto de perfil atualizada!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddCategory = async (data: any): Promise<boolean> => {
    if (!activePlayer) return false;
    try {
      const res = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          createdBy: activePlayer.id,
        }),
      });

      if (res.ok) {
        await fetchState();
        showToast('Categoria adicionada ao sistema!');
        return true;
      } else {
        const err = await res.json();
        alert(err.error || 'Erro ao adicionar categoria.');
        return false;
      }
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleToggleCategoryStatus = async (catId: string, status: 'active' | 'archived'): Promise<boolean> => {
    try {
      const res = await fetch(`/api/categories/${catId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, adminId: activePlayer?.id }),
      });
      if (res.ok) {
        await fetchState();
        showToast(`Status da categoria atualizado para ${status === 'active' ? 'Ativa' : 'Arquivada'}.`);
        return true;
      } else {
        const err = await res.json();
        alert(err.error || 'Erro ao atualizar status.');
        return false;
      }
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleCloseSeason = async (reason: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/seasons/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: activePlayer?.id, reason }),
      });
      if (res.ok) {
        await fetchState();
        showToast('Temporada encerrada com sucesso! Campeões condecorados e nova semana iniciada.');
        return true;
      } else {
        const err = await res.json();
        alert(err.error || 'Erro ao encerrar temporada.');
        return false;
      }
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleResetDemoData = async () => {
    if (!window.confirm('Restaurar dados de teste com histórico completo dos 6 jogadores?')) return;
    try {
      const res = await fetch('/api/backup/reset-demo', { method: 'POST' });
      if (res.ok) {
        await fetchState();
        showToast('Dados de demonstração restaurados com sucesso!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (!state) {
    return (
      <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-4 text-center">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4 animate-pulse">
          <Trophy className="w-6 h-6" />
        </div>
        <h1 className="text-xl font-black text-white tracking-widest font-mono-numbers">
          GARRAFÕES
        </h1>
        <p className="text-xs text-neutral-400 mt-1">Carregando dados da competição...</p>
      </div>
    );
  }

  // Active view player for profile inspection
  const profilePlayer = inspectedPlayerId
    ? state.players.find((p) => p.id === inspectedPlayerId) || activePlayer || state.players[0]
    : activePlayer || state.players[0];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col pb-20 sm:pb-8 selection:bg-emerald-500 selection:text-neutral-950">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-neutral-900 border border-emerald-500/50 text-emerald-300 text-xs font-bold shadow-2xl flex items-center gap-2 animate-bounce">
          <Zap className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        activePlayer={activePlayer}
        onSwitchPlayer={() => setIsWelcomeOpen(true)}
        onRefresh={fetchState}
        isRefreshing={isRefreshing}
        isAdmin={isAdmin}
        onToggleAdmin={() => setIsAdmin(!isAdmin)}
      />

      {/* Main Container */}
      <main className="max-w-5xl mx-auto px-4 py-6 w-full flex-1">
        {/* Desktop Navigation Tabs */}
        <nav className="hidden sm:flex items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded-2xl mb-6">
          <button
            onClick={() => setActiveTab('painel')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'painel'
                ? 'bg-neutral-800 text-white border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Trophy className="w-4 h-4 text-emerald-400" />
            <span>Painel</span>
          </button>

          <button
            onClick={() => setActiveTab('registrar')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'registrar'
                ? 'bg-emerald-500 text-neutral-950 shadow-md shadow-emerald-950'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>Registrar Sequência</span>
          </button>

          <button
            onClick={() => setActiveTab('ranking')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'ranking'
                ? 'bg-neutral-800 text-white border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Ranking Semanal</span>
          </button>

          <button
            onClick={() => setActiveTab('historico')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'historico'
                ? 'bg-neutral-800 text-white border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <History className="w-4 h-4 text-neutral-400" />
            <span>Todos os Tempos</span>
          </button>

          <button
            onClick={() => setActiveTab('conquistas')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'conquistas'
                ? 'bg-neutral-800 text-white border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Award className="w-4 h-4 text-purple-400" />
            <span>Conquistas</span>
          </button>

          <button
            onClick={() => {
              setInspectedPlayerId(activePlayer?.id || null);
              setActiveTab('perfil');
            }}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'perfil'
                ? 'bg-neutral-800 text-white border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <User className="w-4 h-4 text-blue-400" />
            <span>Meu Perfil</span>
          </button>

          <button
            onClick={() => setActiveTab('manobras')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'manobras'
                ? 'bg-neutral-800 text-white border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span>Manobras</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveTab('gestao')}
              className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ml-auto ${
                activeTab === 'gestao'
                  ? 'bg-amber-950/80 text-amber-300 border border-amber-600/60'
                  : 'text-amber-500/70 hover:text-amber-400'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Gestão</span>
            </button>
          )}
        </nav>

        {/* View Routing */}
        {activeTab === 'painel' && currentSeason && activePlayer && (
          <DashboardView
            activePlayer={activePlayer}
            currentSeason={currentSeason}
            categories={state.categories}
            weeklyRanking={currentWeeklyRankings}
            dailyRecords={state.dailyRecords}
            todayDateStr={todayDateStr}
            onNavigate={(tab) => setActiveTab(tab)}
            onSelectCategory={(catId) => setSelectedCategoryId(catId)}
          />
        )}

        {activeTab === 'registrar' && activePlayer && (
          <AttemptRecorder
            activePlayer={activePlayer}
            categories={state.categories}
            selectedCategoryId={selectedCategoryId}
            onSelectCategory={setSelectedCategoryId}
            dailyRecords={state.dailyRecords}
            todayDateStr={todayDateStr}
            onSaveAttempt={handleSaveAttempt}
            onOpenCorrection={(rec) => {
              setCorrectionRecord(rec);
              setIsCorrectionOpen(true);
            }}
          />
        )}

        {activeTab === 'ranking' && currentSeason && (
          <WeeklyRankingView
            categories={state.categories}
            selectedCategoryId={selectedCategoryId}
            onSelectCategory={setSelectedCategoryId}
            players={state.players}
            rankingResults={currentWeeklyRankings[selectedCategoryId] || []}
            season={currentSeason}
            onOpenPlayerProfile={(pId) => {
              setInspectedPlayerId(pId);
              setActiveTab('perfil');
            }}
          />
        )}

        {activeTab === 'historico' && (
          <AllTimeRankingView
            categories={state.categories}
            selectedCategoryId={selectedCategoryId}
            onSelectCategory={setSelectedCategoryId}
            players={state.players}
            historicalRankings={historicalRankings}
            closedSeasons={closedSeasons}
            onOpenPlayerProfile={(pId) => {
              setInspectedPlayerId(pId);
              setActiveTab('perfil');
            }}
            onSelectPastSeasonDetail={(s) => setInspectSeason(s)}
          />
        )}

        {activeTab === 'perfil' && profilePlayer && (
          <PlayerProfileView
            player={profilePlayer}
            categories={state.categories}
            seasons={state.seasons}
            dailyRecords={state.dailyRecords}
            state={state}
            onUpdatePhoto={handleUpdatePlayerPhoto}
            onNavigateToAchievements={(pId) => {
              setInspectedPlayerId(pId);
              setActiveTab('conquistas');
            }}
            onSelectPastSeasonDetail={(s) => setInspectSeason(s)}
          />
        )}

        {activeTab === 'conquistas' && (
          <AchievementsGallery
            players={state.players}
            selectedPlayerId={inspectedPlayerId || activePlayer?.id || state.players[0].id}
            onSelectPlayer={(id) => setInspectedPlayerId(id)}
            state={state}
          />
        )}

        {activeTab === 'manobras' && activePlayer && (
          <TrickCatalogView
            tricks={state.tricks}
            players={state.players}
            activePlayer={activePlayer}
            categories={state.categories}
            isAdmin={isAdmin}
            onCreateTrick={handleCreateTrick}
            onExecuteTrick={handleExecuteTrick}
            onPublishTrick={handlePublishTrick}
            onArchiveTrick={async (trickId, reason) => {
              await fetch(`/api/tricks/${trickId}/status`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'archived', adminId: activePlayer.id, reason }),
              });
              await fetchState();
            }}
          />
        )}

        {activeTab === 'gestao' && currentSeason && activePlayer && (
          <GroupManagementView
            categories={state.categories}
            currentSeason={currentSeason}
            auditLogs={state.auditLogs}
            activePlayer={activePlayer}
            isAdmin={isAdmin}
            onAddCategory={handleAddCategory}
            onToggleCategoryStatus={handleToggleCategoryStatus}
            onCloseCurrentSeason={handleCloseSeason}
            onResetDemoData={handleResetDemoData}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar (Ergonomic for one-handed operation) */}
      <nav className="sm:hidden fixed bottom-0 inset-x-0 z-40 bg-neutral-900/95 backdrop-blur-md border-t border-neutral-800 px-3 py-2 flex items-center justify-around">
        <button
          onClick={() => setActiveTab('painel')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'painel' ? 'text-emerald-400' : 'text-neutral-400'
          }`}
        >
          <Trophy className="w-5 h-5" />
          <span>Início</span>
        </button>

        <button
          onClick={() => setActiveTab('registrar')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-[10px] font-black ${
            activeTab === 'registrar'
              ? 'bg-emerald-500 text-neutral-950 shadow-lg shadow-emerald-950 scale-105'
              : 'text-emerald-400 bg-emerald-950/40 border border-emerald-800/60'
          }`}
        >
          <Zap className="w-5 h-5 fill-current" />
          <span>+1 Registrar</span>
        </button>

        <button
          onClick={() => setActiveTab('ranking')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'ranking' ? 'text-emerald-400' : 'text-neutral-400'
          }`}
        >
          <TrendingUp className="w-5 h-5" />
          <span>Ranking</span>
        </button>

        <button
          onClick={() => setActiveTab('conquistas')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'conquistas' ? 'text-purple-400' : 'text-neutral-400'
          }`}
        >
          <Award className="w-5 h-5" />
          <span>Conquistas</span>
        </button>

        <button
          onClick={() => setShowMoreMenu(true)}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            ['perfil', 'manobras', 'historico', 'gestao'].includes(activeTab)
              ? 'text-emerald-400'
              : 'text-neutral-400'
          }`}
        >
          <MoreHorizontal className="w-5 h-5" />
          <span>Mais</span>
        </button>
      </nav>

      {/* Mobile More Sheet */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-950/80 backdrop-blur-md sm:hidden">
          <div className="w-full bg-neutral-900 border-t border-neutral-800 rounded-t-3xl p-5 space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                Menu de Navegação
              </span>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setInspectedPlayerId(activePlayer?.id || null);
                  setActiveTab('perfil');
                  setShowMoreMenu(false);
                }}
                className="p-3 rounded-xl bg-neutral-800/80 text-left flex items-center gap-2.5"
              >
                <User className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-white">Meu Perfil</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('manobras');
                  setShowMoreMenu(false);
                }}
                className="p-3 rounded-xl bg-neutral-800/80 text-left flex items-center gap-2.5"
              >
                <BookOpen className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-white">Manobras</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('historico');
                  setShowMoreMenu(false);
                }}
                className="p-3 rounded-xl bg-neutral-800/80 text-left flex items-center gap-2.5"
              >
                <History className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white">Todos os Tempos</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('gestao');
                  setShowMoreMenu(false);
                }}
                className="p-3 rounded-xl bg-neutral-800/80 text-left flex items-center gap-2.5"
              >
                <Shield className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-white">Gestão do Grupo</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Welcome / Switch Player Modal */}
      <WelcomeModal
        isOpen={isWelcomeOpen}
        players={state.players}
        activePlayerId={activePlayerId}
        onSelectPlayer={handleSelectPlayer}
        onClose={activePlayerId ? () => setIsWelcomeOpen(false) : undefined}
        onUpdatePlayerPhoto={handleUpdatePlayerPhoto}
      />

      {/* Audit Correction Modal */}
      <AuditCorrectionModal
        isOpen={isCorrectionOpen}
        onClose={() => setIsCorrectionOpen(false)}
        record={correctionRecord}
        activePlayer={activePlayer || state.players[0]}
        categories={state.categories.filter((c) => c.status === 'active')}
        todayDateStr={todayDateStr}
        onSubmitCorrection={handleSubmitCorrection}
      />

      {/* Past Season Detail Modal */}
      <SeasonDetailModal
        season={inspectSeason}
        onClose={() => setInspectSeason(null)}
        players={state.players}
        categories={state.categories}
      />
    </div>
  );
}
