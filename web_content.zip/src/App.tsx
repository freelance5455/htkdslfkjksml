import React, { useState } from 'react';
import { 
  Tv, Radio, Wifi, Bluetooth, Layers, FolderTree, BookOpen, 
  Sparkles, Download, Smartphone, Zap, Shield, HelpCircle,
  PlusCircle, RefreshCw, Activity, CheckCircle
} from 'lucide-react';
import { InteractiveRemote } from './components/InteractiveRemote';
import { IrSignalVisualizer } from './components/IrSignalVisualizer';
import { SunplusLab } from './components/SunplusLab';
import { WifiDriversLab } from './components/WifiDriversLab';
import { BluetoothHidLab } from './components/BluetoothHidLab';
import { AndroidProjectExplorer } from './components/AndroidProjectExplorer';
import { ArchitectureDocs } from './components/ArchitectureDocs';
import { INITIAL_DEVICES } from './data/defaultIrDatabase';
import { IrPatternResult, RemoteDevice, RemoteKey } from './types/remote';
import { IrEncoder } from './services/irEncoder';

export default function App() {
  const [activeTab, setActiveTab] = useState<'remote' | 'sunplus' | 'wifi' | 'bluetooth' | 'project' | 'architecture'>('remote');
  const [devices, setDevices] = useState<RemoteDevice[]>(INITIAL_DEVICES);
  const [currentDevice, setCurrentDevice] = useState<RemoteDevice>(INITIAL_DEVICES[0]);
  const [lastSignal, setLastSignal] = useState<IrPatternResult | null>(null);
  const [lastCommandDesc, setLastCommandDesc] = useState<string>('جاهز للإرسال');
  const [showAddModal, setShowAddModal] = useState(false);

  // New device wizard state
  const [newDevName, setNewDevName] = useState('');
  const [newDevBrand, setNewDevBrand] = useState('Sunplus');
  const [newDevType, setNewDevType] = useState<'RECEIVER' | 'TV'>('RECEIVER');
  const [newDevConn, setNewDevConn] = useState<'IR' | 'WIFI' | 'BLUETOOTH'>('IR');

  const handleSignalEmitted = (signal: IrPatternResult, key: RemoteKey, desc: string) => {
    setLastSignal(signal);
    setLastCommandDesc(`${key}: ${desc}`);
  };

  const handleAddDevice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDevName) return;

    const newDevice: RemoteDevice = {
      id: `dev-${Date.now()}`,
      name: newDevName,
      brand: newDevBrand,
      model: `${newDevBrand} Custom`,
      type: newDevType,
      connectionType: newDevConn,
      irProtocol: newDevConn === 'IR' ? (newDevBrand === 'Sunplus' ? 'SUNPLUS' : 'NEC') : undefined,
      customAddress: newDevBrand === 'Sunplus' ? 0x00FF : 0x00,
      isFavorite: false,
    };

    setDevices([newDevice, ...devices]);
    setCurrentDevice(newDevice);
    setShowAddModal(false);
    setNewDevName('');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Logo & title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-cyan-500/20">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-white text-base tracking-tight">Universal Remote Pro</h1>
                <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] px-2 py-0.5 rounded-full font-mono">
                  Android & Kotlin Studio
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                ريموت شامل للشاشات الذكية وأجهزة صن بلص (IR • Wi-Fi • Bluetooth HID)
              </p>
            </div>
          </div>

          {/* Device and status badge */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
              <span className="text-slate-400">الجهاز النشط:</span>
              <span className="font-semibold text-cyan-400">{currentDevice.name}</span>
              <span className={`w-2 h-2 rounded-full ${
                currentDevice.connectionType === 'IR' ? 'bg-amber-400' :
                currentDevice.connectionType === 'WIFI' ? 'bg-emerald-400' : 'bg-blue-400'
              }`}></span>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-all active:scale-95"
            >
              <PlusCircle className="w-4 h-4 text-cyan-400" />
              <span>إضافة جهاز</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 overflow-x-auto scrollbar-none border-t border-slate-800/60">
          <div className="flex gap-2 py-2 text-xs font-medium">
            <button
              onClick={() => setActiveTab('remote')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'remote'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>الريموت التفاعلي وراسم النبضات</span>
            </button>

            <button
              onClick={() => setActiveTab('sunplus')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'sunplus'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Radio className="w-4 h-4" />
              <span>مختبر معالجات صن بلص (Sunplus Lab)</span>
            </button>

            <button
              onClick={() => setActiveTab('wifi')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'wifi'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Wifi className="w-4 h-4" />
              <span>مشغلات الواي فاي (Smart TV IP)</span>
            </button>

            <button
              onClick={() => setActiveTab('bluetooth')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'bluetooth'
                  ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-500/20'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <Bluetooth className="w-4 h-4" />
              <span>البلوتوث (HID Remote Profile)</span>
            </button>

            <button
              onClick={() => setActiveTab('project')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'project'
                  ? 'bg-purple-600 text-white font-bold shadow-md shadow-purple-500/20'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <FolderTree className="w-4 h-4" />
              <span>مستكشف كود مشروع أندرويد (.ZIP)</span>
            </button>

            <button
              onClick={() => setActiveTab('architecture')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'architecture'
                  ? 'bg-slate-700 text-white font-bold'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>المعمارية والملاحظات الهندسية</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {activeTab === 'remote' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Interactive Virtual Remote Control (5 cols) */}
            <div className="lg:col-span-5 flex justify-center">
              <InteractiveRemote
                currentDevice={currentDevice}
                onSignalEmitted={handleSignalEmitted}
                onDeviceChange={setCurrentDevice}
                devices={devices}
              />
            </div>

            {/* Oscilloscope and Signal Inspector (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              {/* Last executed command banner */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 block">آخر أمر تم تنفيذه:</span>
                  <span className="font-mono text-xs font-bold text-cyan-400">
                    {lastCommandDesc}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>تم التوليد بنجاح</span>
                </div>
              </div>

              {/* Signal Oscilloscope */}
              <IrSignalVisualizer signal={lastSignal} lastCommandName={lastCommandDesc.split(':')[0]} />

              {/* Quick Tech Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                  <span className="text-cyan-400 text-xs font-bold block mb-1">ConsumerIrManager</span>
                  <p className="text-[11px] text-slate-400">
                    بث مباشر عبر <code className="font-mono text-slate-300">transmit(freq, pattern)</code> مع فحص توفر الحساس في الهاتف.
                  </p>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                  <span className="text-amber-400 text-xs font-bold block mb-1">دعم Sunplus المتخصص</span>
                  <p className="text-[11px] text-slate-400">
                    معالجة بروتوكول NEC Extended بتردد 38kHz وأكواد عميل 0x00FF و 0xBF40 مع وضع صيد الأكواد.
                  </p>
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                  <span className="text-purple-400 text-xs font-bold block mb-1">معمارية Clean Architecture</span>
                  <p className="text-[11px] text-slate-400">
                    فصل طبقات النقل عبر <code className="font-mono text-slate-300">RemoteTransport</code> و Room Database و Hilt.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'sunplus' && (
          <SunplusLab onTestSignal={(sig, name) => handleSignalEmitted(sig, 'POWER', name)} />
        )}

        {activeTab === 'wifi' && (
          <WifiDriversLab />
        )}

        {activeTab === 'bluetooth' && (
          <BluetoothHidLab />
        )}

        {activeTab === 'project' && (
          <AndroidProjectExplorer />
        )}

        {activeTab === 'architecture' && (
          <ArchitectureDocs />
        )}
      </main>

      {/* Add Device Modal Dialog */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="font-bold text-white text-base mb-1">معالج إضافة جهاز جديد (Add Device Wizard)</h3>
            <p className="text-xs text-slate-400 mb-4">
              أدخل بيانات الشاشة أو جهاز الريسيفر وطريقة الاتصال:
            </p>

            <form onSubmit={handleAddDevice} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">اسم الجهاز</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: ريسيفر سيناتور الصالة"
                  value={newDevName}
                  onChange={(e) => setNewDevName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">الماركة / المعالج</label>
                  <select
                    value={newDevBrand}
                    onChange={(e) => setNewDevBrand(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                  >
                    <option value="Sunplus">Sunplus (صن بلص)</option>
                    <option value="LG">LG (إل جي webOS / NetCast)</option>
                    <option value="Toshiba">Toshiba (توشيبا العربي / Smart)</option>
                    <option value="Samsung">Samsung (سامسونج)</option>
                    <option value="Sony">Sony (سوني)</option>
                    <option value="TCL">TCL / Hisense</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">نوع الجهاز</label>
                  <select
                    value={newDevType}
                    onChange={(e) => setNewDevType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                  >
                    <option value="RECEIVER">ريسيفر ستلايت (Receiver)</option>
                    <option value="TV">شاشة ذكية (Smart TV)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">تقنية الاتصال</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'IR', label: 'الأشعة تحت الحمراء (IR)' },
                    { id: 'WIFI', label: 'واي فاي (Wi-Fi)' },
                    { id: 'BLUETOOTH', label: 'بلوتوث (HID)' },
                  ].map((conn) => (
                    <button
                      type="button"
                      key={conn.id}
                      onClick={() => setNewDevConn(conn.id as any)}
                      className={`p-2 rounded-xl text-[11px] font-semibold border transition-all ${
                        newDevConn === conn.id
                          ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {conn.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl text-xs font-bold"
                >
                  حفظ وإضافة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-4 px-4 text-center text-xs text-slate-500">
        <p>Universal Remote Pro • معمارية Clean Architecture + Kotlin Jetpack Compose • يدعم Sunplus, Samsung, LG, Sony</p>
      </footer>
    </div>
  );
}
