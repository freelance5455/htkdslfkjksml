import { useCallback, useEffect, useState } from "react";
import { AppProvider, type PageId, type TabId } from "./context";
import { DemoModal, LoginModal, PageModal, TrialModal } from "./components/overlays";
import {
  Benefits,
  FAQ,
  Features,
  FinalCta,
  Footer,
  Grain,
  Hero,
  MobileTrialBar,
  Navbar,
  Pricing,
  ScrollProgress,
  Showcase,
  SkipLink,
  SocialProof,
  Testimonials,
} from "./components/sections";

const pageNames: Record<PageId, string> = {
  about: "About",
  customers: "Customers",
  careers: "Careers",
  press: "Press",
  docs: "Docs",
  blog: "Journal",
  security: "Security",
  status: "Status",
  changelog: "Changelog",
  privacy: "Privacy",
  terms: "Terms",
  dpa: "DPA",
};

export default function App() {
  const [overlay, setOverlay] = useState<"trial" | "login" | "demo" | "page" | null>(null);
  const [page, setPage] = useState<PageId>("about");
  const [showcase, setShowcase] = useState<TabId>("composer");
  const [menuOpen, setMenuOpen] = useState(false);
  const [trialEmail, setTrialEmail] = useState("");
  const [trialPlan, setTrialPlan] = useState("Team");
  const [trialNonce, setTrialNonce] = useState(0);

  const openTrial = useCallback((opts?: { email?: string; plan?: string }) => {
    setTrialEmail(opts?.email ?? "");
    setTrialPlan(opts?.plan ?? "Team");
    setMenuOpen(false);
    setOverlay("trial");
    setTrialNonce((value) => value + 1);
  }, []);

  const openLogin = useCallback(() => {
    setMenuOpen(false);
    setOverlay("login");
  }, []);

  const openDemo = useCallback(() => {
    setMenuOpen(false);
    setOverlay("demo");
  }, []);

  const openPage = useCallback((id: PageId) => {
    setPage(id);
    setMenuOpen(false);
    setOverlay("page");
  }, []);

  const closeOverlay = useCallback(() => setOverlay(null), []);

  useEffect(() => {
    document.body.style.overflow = menuOpen || overlay ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen, overlay]);

  useEffect(() => {
    const base = "Nexus AI — The AI teammate for remote developers";
    if (overlay === "page") document.title = `${pageNames[page]} · Nexus AI`;
    else if (overlay === "trial") document.title = "Start a free trial · Nexus AI";
    else if (overlay === "login") document.title = "Log in · Nexus AI";
    else if (overlay === "demo") document.title = "Product tour · Nexus AI";
    else document.title = base;
  }, [overlay, page]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (overlay || menuOpen) return;
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (event.target as HTMLElement | null)?.isContentEditable) return;
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.key.toLowerCase() === "t") openTrial();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen, openTrial, overlay]);

  return (
    <AppProvider
      value={{
        openTrial,
        openLogin,
        openDemo,
        openPage,
        closeOverlay,
        showcase,
        setShowcase,
        menuOpen,
        setMenuOpen,
        trialEmail,
        trialPlan,
        trialNonce,
        page,
        overlay,
      }}
    >
      <div id="top" className="relative min-h-screen bg-ink text-paper">
        <Grain />
        <SkipLink />
        <ScrollProgress />
        <Navbar />
        <main id="main">
          <Hero />
          <SocialProof />
          <Features />
          <Showcase />
          <Benefits />
          <Testimonials />
          <Pricing />
          <FAQ />
          <FinalCta />
        </main>
        <Footer />
        <MobileTrialBar />
        {overlay === "trial" ? <TrialModal key={trialNonce} /> : null}
        {overlay === "login" ? <LoginModal /> : null}
        {overlay === "demo" ? <DemoModal /> : null}
        {overlay === "page" ? <PageModal /> : null}
      </div>
    </AppProvider>
  );
}
