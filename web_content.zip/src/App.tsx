import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  CalendarEvent,
  Reminder,
  Contact,
  AndroidApp,
  DeviceSettings,
  LogEntry,
  JarvisAction,
  MemoryItem,
} from './types/jarvis';
import {
  DEFAULT_CONTACTS,
  DEFAULT_APPS,
  getInitialEvents,
  getInitialReminders,
  addCalendarEvent,
  modifyCalendarEvent,
  deleteCalendarEvent,
  addReminderItem,
  modifyReminderItem,
  deleteReminderItem,
  checkUpcomingNotifications,
  parseLocalJarvisCommand,
  formatTimeDisplay,
} from './utils/jarvisEngine';
import { hardwareBridge } from './utils/hardwareBridge';
import { jarvisSpeech } from './utils/speech';
import {
  loadMemoriesFromStorage,
  saveMemory,
  updateMemory,
  deleteMemory,
  clearAllMemories,
  generateUrduGreeting,
  parseMemoryCommand,
  getMemoriesRecord,
} from './utils/memoryManager';

import { ArcReactorVisualizer } from './components/ArcReactorVisualizer';
import { SmartMemoryDeck } from './components/SmartMemoryDeck';
import { AndroidQuickSettings } from './components/AndroidQuickSettings';
import { AppLauncher } from './components/AppLauncher';
import { VoiceCommandBar } from './components/VoiceCommandBar';
import { AndroidBridgeModal } from './components/AndroidBridgeModal';
import { PWAInstallButton } from './components/PWAInstallButton';

import {
  Cpu,
  Brain,
  Shield,
  Smartphone,
  Sliders,
  LayoutGrid,
  History,
  Volume2,
  VolumeX,
  Radio,
  Sparkles,
  Phone,
  PhoneOff,
  ShieldCheck,
} from 'lucide-react';

export default function App() {
  // Main state
  const [events, setEvents] = useState<CalendarEvent[]>(() => getInitialEvents());
  const [reminders, setReminders] = useState<Reminder[]>(() => getInitialReminders());
  const [contacts, setContacts] = useState<Contact[]>(DEFAULT_CONTACTS);
  const [apps, setApps] = useState<AndroidApp[]>(DEFAULT_APPS);

  const [settings, setSettings] = useState<DeviceSettings>({
    flashlight: false,
    vibrate: true,
    soundMode: 'normal',
    nightMode: false,
    batterySaver: false,
    dnd: false,
    voiceFeedback: true,
    continuousListening: false,
    volume: 85,
    brightness: 90,
  });

  const [activeCall, setActiveCall] = useState<{
    contactName: string;
    phoneNumber: string;
    startTime: number;
    isEncrypted: boolean;
  } | null>(null);

  const [activityLog, setActivityLog] = useState<LogEntry[]>([
    {
      id: 'log-1',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      command: 'System Boot',
      response: 'J.A.R.V.I.S. Android Operating Core initialized. All systems nominal.',
      actionType: 'GENERAL_RESPONSE',
    },
  ]);

  const [memories, setMemories] = useState<MemoryItem[]>(() => loadMemoriesFromStorage());

  const [lastSpeech, setLastSpeech] = useState<string>(() =>
    generateUrduGreeting(loadMemoriesFromStorage())
  );

  const [activeSection, setActiveSection] = useState<'all' | 'memory' | 'controls' | 'apps' | 'log'>('all');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [showBridgeModal, setShowBridgeModal] = useState(false);
  const [notificationPermissionGranted, setNotificationPermissionGranted] = useState(false);

  // Time display
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Check notification permission on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationPermissionGranted(Notification.permission === 'granted');
    }
  }, []);

  // Setup speech service callbacks
  useEffect(() => {
    jarvisSpeech.setCallbacks({
      onListeningChange: (listening) => setIsListening(listening),
      onSpeakingChange: (speaking) => setIsSpeaking(speaking),
      onTranscript: (transcript, isFinal) => {
        setLiveTranscript(transcript);
        if (isFinal && transcript.trim().length > 1) {
          executeCommand(transcript.trim());
          setLiveTranscript('');
        }
      },
      onError: (err) => {
        console.warn('Speech service notice:', err);
      },
    });
  }, []);

  // Proactive Predictive Notifications & Event Watcher Loop
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const { dueEvents, dueReminders } = checkUpcomingNotifications(events, reminders, now, 15);

      if (dueEvents.length > 0) {
        dueEvents.forEach((evt) => {
          const alertMsg = `Upcoming Event: "${evt.title}" starts at ${formatTimeDisplay(evt.startTime)}.`;
          hardwareBridge.sendDeviceNotification('Upcoming Event', alertMsg);
          if (settings.voiceFeedback) {
            jarvisSpeech.speak(`Sir, notice for your calendar: ${evt.title} begins shortly.`);
          }
        });
        // Mark as notified so we don't repeat
        setEvents((prev) =>
          prev.map((e) => (dueEvents.some((de) => de.id === e.id) ? { ...e, notified: true } : e))
        );
      }

      if (dueReminders.length > 0) {
        dueReminders.forEach((rem) => {
          const alertMsg = `Task Reminder: "${rem.title}".`;
          hardwareBridge.sendDeviceNotification('Task Due', alertMsg);
          if (settings.voiceFeedback) {
            jarvisSpeech.speak(`Sir, reminder alert: ${rem.title}.`);
          }
        });
        setReminders((prev) =>
          prev.map((r) => (dueReminders.some((dr) => dr.id === r.id) ? { ...r, notified: true } : r))
        );
      }
    }, 12000);

    return () => clearInterval(interval);
  }, [events, reminders, settings.voiceFeedback]);

  // Execute an action and dispatch appropriate side effects
  const applyJarvisAction = useCallback(
    (action: JarvisAction, speechText: string, rawPrompt: string) => {
      setLastSpeech(speechText);

      // Play audio response if enabled
      if (settings.voiceFeedback) {
        jarvisSpeech.speak(speechText);
      }
      hardwareBridge.playJarvisTone('ack');
      if (settings.vibrate) {
        hardwareBridge.vibrateSuccess();
      }

      // Add to activity log
      setActivityLog((prev) => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          command: rawPrompt,
          response: speechText,
          actionType: action.type,
        },
        ...prev.slice(0, 24),
      ]);

      const payload = action.payload || {};

      switch (action.type) {
        case 'ADD_EVENT': {
          const { updatedEvents } = addCalendarEvent(events, {
            title: payload.title || 'New Meeting',
            startTime: payload.startTime || new Date(Date.now() + 3600000).toISOString(),
            endTime: payload.endTime,
            location: payload.location,
            category: payload.category,
            priority: payload.priority,
          });
          setEvents(updatedEvents);
          break;
        }

        case 'MODIFY_EVENT': {
          const { updatedEvents } = modifyCalendarEvent(
            events,
            payload.targetQuery || '',
            payload.updatedFields || {}
          );
          setEvents(updatedEvents);
          break;
        }

        case 'DELETE_EVENT': {
          const { updatedEvents } = deleteCalendarEvent(events, payload.targetQuery || '');
          setEvents(updatedEvents);
          break;
        }

        case 'ADD_REMINDER': {
          const { updatedReminders } = addReminderItem(reminders, {
            title: payload.title || 'General Task',
            dueTime: payload.dueTime,
            priority: payload.priority,
            category: payload.category,
          });
          setReminders(updatedReminders);
          break;
        }

        case 'MODIFY_REMINDER': {
          const { updatedReminders } = modifyReminderItem(
            reminders,
            payload.targetQuery || '',
            {
              completed: payload.completed !== undefined ? payload.completed : true,
              ...(payload.updatedFields || {}),
            }
          );
          setReminders(updatedReminders);
          break;
        }

        case 'DELETE_REMINDER': {
          const { updatedReminders } = deleteReminderItem(reminders, payload.targetQuery || '');
          setReminders(updatedReminders);
          break;
        }

        case 'MAKE_CALL': {
          const contactName = payload.contactName || 'Encrypted Channel';
          const phoneNumber = payload.phoneNumber || '+1-310-555-0101';
          setActiveCall({
            contactName,
            phoneNumber,
            startTime: Date.now(),
            isEncrypted: true,
          });
          hardwareBridge.playJarvisTone('call');
          break;
        }

        case 'SEND_MESSAGE': {
          const contactName = payload.contactName || 'Contact';
          const phoneNumber = payload.phoneNumber || '';
          const message = payload.message || '';
          const app = payload.app || 'whatsapp';

          if (app === 'whatsapp') {
            const cleanPhone = phoneNumber.replace(/[^\d]/g, '');
            const whatsappUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message)}`;
            hardwareBridge.launchAndroidApp(whatsappUrl, whatsappUrl);
          } else {
            const smsUrl = `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;
            hardwareBridge.launchAndroidApp(smsUrl, smsUrl);
          }
          break;
        }

        case 'OPEN_APP': {
          const targetApp = payload.app as AndroidApp;
          if (targetApp) {
            hardwareBridge.launchAndroidApp(targetApp.intentUrl, targetApp.webFallback);
          }
          break;
        }

        case 'TOGGLE_SETTING': {
          const setting = payload.setting as keyof DeviceSettings;
          const val = payload.value;
          if (setting === 'flashlight') {
            const next = typeof val === 'boolean' ? val : !settings.flashlight;
            hardwareBridge.setFlashlight(next);
            setSettings((s) => ({ ...s, flashlight: next }));
          } else if (setting === 'soundMode') {
            setSettings((s) => ({ ...s, soundMode: val || 'normal' }));
          } else if (setting === 'batterySaver') {
            const next = typeof val === 'boolean' ? val : !settings.batterySaver;
            setSettings((s) => ({ ...s, batterySaver: next }));
          } else if (setting === 'vibrate') {
            const next = typeof val === 'boolean' ? val : !settings.vibrate;
            setSettings((s) => ({ ...s, vibrate: next }));
          } else if (setting === 'dnd') {
            const next = typeof val === 'boolean' ? val : !settings.dnd;
            setSettings((s) => ({ ...s, dnd: next }));
          }
          break;
        }

        case 'STORE_MEMORY': {
          const { updatedMemories } = saveMemory(memories, payload.key, payload.value, payload.label);
          setMemories(updatedMemories);
          break;
        }

        case 'UPDATE_MEMORY': {
          const { updatedMemories } = updateMemory(memories, payload.key, payload.value);
          setMemories(updatedMemories);
          break;
        }

        case 'DELETE_MEMORY': {
          const { updatedMemories } = deleteMemory(memories, payload.key);
          setMemories(updatedMemories);
          break;
        }

        case 'CLEAR_MEMORY': {
          const updatedMemories = clearAllMemories();
          setMemories(updatedMemories);
          break;
        }

        case 'BRIEFING': {
          // Already spoke briefing summary
          break;
        }

        default:
          break;
      }
    },
    [events, reminders, settings, memories]
  );

  // Main command handler: calls /api/jarvis (Gemini 3.8 Flash), falls back to local engine
  const executeCommand = async (rawPrompt: string) => {
    hardwareBridge.playJarvisTone('wake');

    // 1. Check Smart Memory command locally first (instant offline & predictable response)
    const memoryResult = parseMemoryCommand(rawPrompt, memories);
    if (memoryResult) {
      applyJarvisAction(memoryResult.action, memoryResult.speechText, rawPrompt);
      return;
    }

    // Context for AI
    const context = {
      currentTime: new Date().toISOString(),
      events,
      reminders,
      contacts,
      apps,
      settings,
      memories: getMemoriesRecord(memories),
    };

    try {
      const response = await fetch('/api/jarvis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: rawPrompt, context }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data && !data.fallback && data.speechText && data.action) {
          applyJarvisAction(data.action, data.speechText, rawPrompt);
          return;
        }
      }
    } catch {
      // Backend request failed, use local parser
    }

    // Local deterministic parser fallback
    const localResult = parseLocalJarvisCommand(rawPrompt, context);
    applyJarvisAction(localResult.action, localResult.speechText, rawPrompt);
  };

  // Toggle voice listening
  const handleToggleListening = () => {
    if (isListening) {
      jarvisSpeech.stopListening();
    } else {
      hardwareBridge.playJarvisTone('wake');
      jarvisSpeech.startListening(false);
    }
  };

  // Direct phone call trigger
  const handleInitiateCall = (contactName: string, phoneNumber: string) => {
    applyJarvisAction(
      {
        type: 'MAKE_CALL',
        payload: { contactName, phoneNumber },
      },
      `Establishing encrypted cellular link with ${contactName}, Sir.`,
      `Call ${contactName}`
    );
  };

  // Send message trigger
  const handleSendMessage = (
    contactName: string,
    phoneNumber: string,
    message: string,
    app: 'sms' | 'whatsapp'
  ) => {
    applyJarvisAction(
      {
        type: 'SEND_MESSAGE',
        payload: { contactName, phoneNumber, message, app },
      },
      `Dispatching ${app.toUpperCase()} payload to ${contactName}.`,
      `Send message to ${contactName}`
    );
  };

  // Request notifications
  const handleRequestNotifications = async () => {
    const granted = await hardwareBridge.requestNotificationPermission();
    setNotificationPermissionGranted(granted);
    if (granted) {
      hardwareBridge.sendDeviceNotification('Protocol Activated', 'Jarvis lockscreen alerts are now active.');
      jarvisSpeech.speak('Notification permissions granted, Sir. I will alert you to upcoming tasks.');
    }
  };

  const handleTestNotification = () => {
    hardwareBridge.sendDeviceNotification('Tactical Alert', 'Test alert from Jarvis OS. Audio and haptic circuits verified.');
    jarvisSpeech.speak('Test notification dispatched, Sir. All sensory systems operational.');
  };

  return (
    <div
      className={`min-h-screen text-slate-100 flex flex-col justify-between selection:bg-cyan-500/30 ${
        settings.nightMode ? 'bg-black' : 'bg-gray-950'
      }`}
    >
      {/* Top Futuristic Android OS Status Bar */}
      <header className="sticky top-0 z-30 bg-gray-950/80 backdrop-blur-md border-b border-cyan-500/30 px-3 sm:px-6 py-2.5">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
          {/* Logo & Clock */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-400 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.5)]">
              <span className="font-orbitron font-extrabold text-cyan-300 text-xs">J</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-orbitron font-bold text-sm tracking-wider text-slate-100">
                  JARVIS
                </span>
                <span className="text-[10px] font-mono-code px-1.5 py-0.2 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-400">
                  ANDROID OS
                </span>
              </div>
              <span className="text-[10px] font-mono-code text-slate-400 whitespace-nowrap">
                {currentTime.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })} //{' '}
                <span className="text-cyan-300 font-bold">
                  {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              </span>
            </div>
          </div>

          {/* Android Controls & PWA Install */}
          <div className="flex items-center gap-2">
            <PWAInstallButton />

            <button
              onClick={() => setShowBridgeModal(true)}
              aria-label="Android OS integration guide"
              className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-cyan-500 text-slate-400 hover:text-cyan-300 text-xs font-mono-code transition"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android Bridge</span>
            </button>

            <button
              onClick={() => {
                const next = !settings.voiceFeedback;
                setSettings((s) => ({ ...s, voiceFeedback: next }));
                if (!next) jarvisSpeech.stopSpeaking();
              }}
              aria-label={settings.voiceFeedback ? 'Mute voice' : 'Enable voice'}
              className={`p-2 rounded-lg border transition ${
                settings.voiceFeedback
                  ? 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300'
                  : 'bg-gray-900 border-gray-800 text-slate-500'
              }`}
            >
              {settings.voiceFeedback ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main OS Viewport */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-3 sm:p-6 pb-36 space-y-6">
        {/* Core Arc Reactor & Subtitle HUD */}
        <section className="flex flex-col items-center justify-center text-center pt-2">
          <ArcReactorVisualizer
            isListening={isListening}
            isSpeaking={isSpeaking}
            onReactorClick={handleToggleListening}
            statusText={isListening ? 'RECEIVING VOICE AUDIO' : 'ONLINE // STANDALONE READY'}
          />

          {/* Subtitle Dialogue HUD */}
          <div className="w-full max-w-2xl mt-3 p-3.5 rounded-2xl bg-gray-900/80 border border-cyan-500/40 backdrop-blur-md shadow-xl relative overflow-hidden group">
            <div className="flex items-center justify-between text-[11px] font-mono-code text-cyan-400 mb-1 border-b border-gray-800 pb-1">
              <span className="flex items-center gap-1.5 uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                J.A.R.V.I.S. VOCAL INTERFACE:
              </span>
              <span className="text-slate-500 text-[10px]">TAP REACTOR TO SPEAK</span>
            </div>
            <p className="text-sm font-rajdhani font-semibold text-slate-100 sm:text-base leading-snug tracking-wide">
              "{lastSpeech}"
            </p>
          </div>
        </section>

        {/* Section Navigation Tabs */}
        <nav aria-label="System navigation tabs" className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: 'All Systems', icon: Cpu },
            { id: 'memory', label: 'Hafiza (Memory)', icon: Brain },
            { id: 'controls', label: 'Device Deck', icon: Sliders },
            { id: 'apps', label: 'App Matrix', icon: LayoutGrid },
            { id: 'log', label: 'Telemetry Stream', icon: History },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSection === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSection(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold font-orbitron uppercase tracking-wider transition-all shrink-0 ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-gray-950 shadow-md shadow-cyan-500/30'
                    : 'bg-gray-900/90 border border-gray-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* In-Call Holographic Overlay */}
        {activeCall && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pb-24 sm:pb-8 bg-gray-950/90 backdrop-blur-md overflow-y-auto">
            <div className="w-full max-w-sm bg-gray-900 border-2 border-cyan-500 rounded-3xl p-5 sm:p-6 text-center shadow-2xl shadow-cyan-900/60 relative overflow-hidden my-auto">
              <div className="flex items-center justify-between mb-4">
                <span className="flex items-center gap-1.5 text-xs font-mono-code text-cyan-400 uppercase tracking-widest">
                  <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
                  COMMS ACTIVE
                </span>
                <span className="flex items-center gap-1 text-[11px] font-mono-code text-emerald-400 border border-emerald-500/40 bg-emerald-950/40 px-2 py-0.5 rounded-full">
                  <ShieldCheck className="w-3 h-3" />
                  ENCRYPTED
                </span>
              </div>
              <div className="relative my-6 flex justify-center">
                <div className="w-24 h-24 rounded-full bg-cyan-950 border-2 border-cyan-400 flex items-center justify-center font-orbitron text-2xl font-bold text-cyan-200 animate-pulse">
                  {activeCall.contactName.slice(0, 2).toUpperCase()}
                </div>
                <div className="absolute inset-0 rounded-full border border-cyan-500/30 animate-ping pointer-events-none" />
              </div>
              <h3 className="font-orbitron text-xl font-bold text-slate-100">
                {activeCall.contactName}
              </h3>
              <p className="text-xs font-mono-code text-cyan-400 mt-1">
                {activeCall.phoneNumber}
              </p>
              <div className="grid grid-cols-2 gap-3 my-6">
                <button
                  onClick={() => {
                    window.location.href = `tel:${activeCall.phoneNumber}`;
                  }}
                  className="p-3 rounded-2xl bg-gray-950 text-emerald-400 border border-gray-800 hover:border-emerald-500 flex flex-col items-center justify-center gap-1 text-xs font-mono-code transition"
                >
                  <Phone className="w-5 h-5" />
                  <span>Native Dial</span>
                </button>
                <button
                  onClick={() => {
                    setActiveCall(null);
                    hardwareBridge.playJarvisTone('complete');
                    setLastSpeech('Comms channel terminated.');
                  }}
                  className="p-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold font-orbitron text-xs uppercase tracking-wider flex flex-col items-center justify-center gap-1 shadow-lg shadow-red-600/40 transition"
                >
                  <PhoneOff className="w-5 h-5" />
                  <span>End Call</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 1. Smart Memory Deck (Hafiza) */}
        {(activeSection === 'all' || activeSection === 'memory') && (
          <SmartMemoryDeck
            memories={memories}
            onSaveMemory={(key, value, label) => {
              const { updatedMemories, item } = saveMemory(memories, key, value, label);
              setMemories(updatedMemories);
              applyJarvisAction(
                { type: 'STORE_MEMORY', payload: item },
                `Theek hai, mai ne yaad rakh liya hai ke ${item.label || item.key}: ${item.value} hai.`,
                `Save ${item.key}`
              );
            }}
            onUpdateMemory={(key, value) => {
              const { updatedMemories, item } = updateMemory(memories, key, value);
              setMemories(updatedMemories);
              if (item) {
                applyJarvisAction(
                  { type: 'UPDATE_MEMORY', payload: item },
                  `Aapka record update kar diya gaya hai. Ab ${item.label || item.key}: ${item.value} hai.`,
                  `Update ${key}`
                );
              }
            }}
            onDeleteMemory={(key) => {
              const { updatedMemories, deleted } = deleteMemory(memories, key);
              setMemories(updatedMemories);
              if (deleted) {
                applyJarvisAction(
                  { type: 'DELETE_MEMORY', payload: { key } },
                  `Theek hai, mai ne ${deleted.label || key} apni memory se mita diya hai.`,
                  `Delete ${key}`
                );
              }
            }}
            onClearMemories={() => {
              const updatedMemories = clearAllMemories();
              setMemories(updatedMemories);
              applyJarvisAction(
                { type: 'CLEAR_MEMORY', payload: {} },
                `Ji behtar, saari stored memory clear kar di gayi hai.`,
                `Clear memory`
              );
            }}
            onVoiceCommandExecute={executeCommand}
          />
        )}

        {/* 3. Android Device Control Deck */}
        {(activeSection === 'all' || activeSection === 'controls') && (
          <AndroidQuickSettings
            settings={settings}
            onUpdateSettings={(updates) => setSettings((s) => ({ ...s, ...updates }))}
            onVoiceAnnounce={(msg) => {
              setLastSpeech(msg);
              if (settings.voiceFeedback) jarvisSpeech.speak(msg);
            }}
          />
        )}

        {/* 4. Android App Launcher Matrix */}
        {(activeSection === 'all' || activeSection === 'apps') && (
          <AppLauncher
            apps={apps}
            onOpenApp={(app) => {
              applyJarvisAction(
                { type: 'OPEN_APP', payload: { app } },
                `Launching ${app.name} on Android device.`,
                `Open ${app.name}`
              );
            }}
            onAddCustomApp={(newApp) => {
              setApps((prev) => [newApp, ...prev]);
              applyJarvisAction(
                { type: 'GENERAL_RESPONSE' },
                `Registered ${newApp.name} in your app matrix, Sir.`,
                `Add app ${newApp.name}`
              );
            }}
          />
        )}

        {/* 5. Telemetry Activity Log */}
        {(activeSection === 'all' || activeSection === 'log') && (
          <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl">
            <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-lg bg-cyan-950 text-cyan-400">
                  <History className="w-4 h-4" />
                </span>
                <h3 className="font-orbitron text-sm font-bold text-slate-100 uppercase tracking-wider">
                  Jarvis Action & Telemetry Stream
                </h3>
              </div>
              <button
                onClick={() =>
                  setActivityLog([
                    {
                      id: `log-${Date.now()}`,
                      timestamp: new Date().toLocaleTimeString(),
                      command: 'Telemetry Cleared',
                      response: 'Log history reset.',
                      actionType: 'GENERAL_RESPONSE',
                    },
                  ])
                }
                className="text-xs font-mono-code text-slate-500 hover:text-cyan-300 transition"
              >
                Clear Log
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto font-mono-code text-xs">
              {activityLog.map((log) => (
                <div
                  key={log.id}
                  className="p-2.5 rounded-lg bg-gray-950/80 border border-gray-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5"
                >
                  <div className="flex items-start sm:items-center gap-2">
                    <span className="text-[10px] text-cyan-500/80 shrink-0">
                      [{log.timestamp}]
                    </span>
                    <span className="text-slate-300 font-semibold">
                      "{log.command}"
                    </span>
                    <span className="text-slate-500 hidden sm:inline">➔</span>
                    <span className="text-slate-400 text-[11px] truncate max-w-md">
                      {log.response}
                    </span>
                  </div>
                  <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-gray-900 border border-gray-700 text-cyan-400 shrink-0 self-start sm:self-auto">
                    {log.actionType}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Persistent Voice Command Dock at Bottom */}
      <VoiceCommandBar
        isListening={isListening}
        isSpeaking={isSpeaking}
        voiceFeedbackEnabled={settings.voiceFeedback}
        liveTranscript={liveTranscript}
        onToggleListening={handleToggleListening}
        onSubmitCommand={executeCommand}
        onToggleVoiceFeedback={() => {
          const next = !settings.voiceFeedback;
          setSettings((s) => ({ ...s, voiceFeedback: next }));
          if (!next) jarvisSpeech.stopSpeaking();
        }}
      />

      {/* Android Bridge Guide Modal */}
      <AndroidBridgeModal
        isOpen={showBridgeModal}
        onClose={() => setShowBridgeModal(false)}
      />
    </div>
  );
}
