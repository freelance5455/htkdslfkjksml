import React, { useState, useEffect, useMemo } from "react";
import {
  Plus,
  Sparkles,
  StickyNote,
  Shield,
  BookOpen,
  Settings as SettingsIcon,
  Search,
  Filter,
  Trash2,
  Lock,
  Lightbulb,
  Image as ImageIcon,
  Network,
  User,
  CheckCircle2,
  Send,
  FileText,
  ArrowLeft,
  X
} from "lucide-react";
import {
  Note,
  TrashItem,
  Flashcard,
  VaultMetadata,
  ActiveTab,
  SortOption,
  FilterOption,
  ThemeAccent,
  ViewLayout,
  ImageClip,
  SectionItem,
  UserProfile,
  SyncedNoteRecord,
  ArchivedDocument,
  UIThemeStyle,
} from "./types";
import {
  getStoredNotes,
  saveNotes,
  getStoredTrash,
  saveTrash,
  getStoredFlashcards,
  saveFlashcards,
  getThemePreference,
  saveThemePreference,
  getThemeAccentPreference,
  saveThemeAccentPreference,
  getViewLayoutPreference,
  saveViewLayoutPreference,
  getStoredClips,
  saveClips,
  getStoredSections,
  saveSections,
  getStoredUserProfile,
  saveUserProfile,
  getStoredSyncLogs,
  saveSyncLogs,
  hydrateNotesFromIndexedDB,
  getStoredVaultRecord,
  saveVaultRecord,
  getStoredMenuOrder,
  saveStoredMenuOrder,
  getStoredUIThemeStyle,
  saveStoredUIThemeStyle,
  DEFAULT_CATEGORIES
} from "./utils/storage";
import { UI_THEME_STYLE_CONFIGS } from "./utils/theme";
import {
  autoCategorizeNotes,
  synchronizeCategories,
  autoCategorizeSingleNoteWithAI,
  batchCategorizeNotesWithAI
} from "./utils/categorizer";
import { saveVaultPayload } from "./utils/crypto";

// Sub-components
import { Header } from "./components/Header";
import { CategoryChips } from "./components/CategoryChips";
import { NoteCard } from "./components/NoteCard";
import { NoteModal } from "./components/NoteModal";
import { VaultView } from "./components/VaultView";
import { StudyView } from "./components/StudyView";
import { SettingsView } from "./components/SettingsView";
import { TrashModal } from "./components/TrashModal";
import { NewCardModal } from "./components/NewCardModal";
import { AIChatModal } from "./components/AIChatModal";
import { TipsView } from "./components/TipsView";
import { ElementsLibraryDrawer } from "./components/ElementsLibraryDrawer";
import { getStoredElements, saveStoredElements } from "./utils/elementsLibrary";
import { ElementSnippet } from "./types";
import { FramePreset } from "./utils/frames";
import { MindMapView } from "./components/MindMapView";
import { ProfileView } from "./components/ProfileView";
import { SectionManagerModal } from "./components/SectionManagerModal";
import { InfographicModal } from "./components/InfographicModal";
import { KanbanBoardView } from "./components/views/KanbanBoardView";
import { TimelineFeedView } from "./components/views/TimelineFeedView";
import { MindMapCanvasView } from "./components/views/MindMapCanvasView";
import { CompactStripView } from "./components/views/CompactStripView";
import { processOfflineQueue, enqueueOfflineAction, categorizeNoteLocally } from "./utils/offlineQueue";
import { DocumentCenterView } from "./components/DocumentCenterView";
import { DocumentHubModal } from "./components/DocumentHubModal";
import { CommandPalette } from "./components/CommandPalette";
import { RadialMenu } from "./components/RadialMenu";
import { DynamicNavigationBar } from "./components/DynamicNavigationBar";
import { computeLayoutSafePadding } from "./utils/navBarConfig";
import { CreateMenuModal } from "./components/CreateMenuModal";
import { ColorNoteImportModal } from "./components/ColorNoteImportModal";
import { IntegratedStrategicPKMView } from "./components/IntegratedStrategicPKMView";
import { EnterprisePKMDashboard } from "./components/ThemeCardComponents";
import { ThemeStateController } from "./utils/themeStateController";
import { NoteFlowThemeStyle } from "./utils/themeTokens";
import { isColorNoteFile } from "./utils/colorNoteParser";
import { applyThemeAccentToDocument } from "./utils/theme";
import { matchNoteWithSearch } from "./utils/search";
import { GlobalStateProvider, useGlobalState } from "./context/GlobalContext";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { AuthModal } from "./components/AuthModal";

function NoteFlowApp() {
  // Central Global State (Single Source of Truth)
  const {
    state,
    setDarkMode,
    setThemeAccent,
    setUiThemeStyle,
    updateMenuOrder,
    reorderSections,
    updateProfile: handleUpdateProfileState,
  } = useGlobalState();

  const darkMode = state.darkMode;
  const themeAccent = state.themeAccent;
  const uiThemeStyle = state.uiThemeStyle;
  const sections = state.sections;
  const menuOrder = state.menuOrder;
  const userProfile = state.profile;

  // Global Auth Modal state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<"login" | "register" | "forgot">("login");

  // Dynamic layout safe area insets calculated from navBarConfig
  const layoutSafePadding = computeLayoutSafePadding(state.navBarConfig, state.scaleConfig.uiScale);

  const [viewLayout, setViewLayout] = useState<ViewLayout>(getViewLayoutPreference);

  useEffect(() => {
    saveViewLayoutPreference(viewLayout);
  }, [viewLayout]);

  // Core Data States
  const [notes, setNotes] = useState<Note[]>(getStoredNotes);
  const [trash, setTrash] = useState<TrashItem[]>(getStoredTrash);
  const [flashcards, setFlashcards] = useState<Flashcard[]>(getStoredFlashcards);
  const [imageClips, setImageClips] = useState<ElementSnippet[]>(() => {
    const el = getStoredElements();
    if (el && el.length > 0) return el;
    return getStoredClips() as unknown as ElementSnippet[];
  });

  // Selected Section Filter (Tümü, Kişisel, İş, vb.)
  const [selectedSection, setSelectedSection] = useState<string>("Tümü");

  // Archived Documents (Storage Layer for uploaded raw files & ColorNote .bin backups)
  const [archivedDocuments, setArchivedDocuments] = useState<ArchivedDocument[]>(() => {
    try {
      const raw = localStorage.getItem("noteflow_archived_docs");
      if (raw) return JSON.parse(raw);
    } catch {}
    return [
      {
        id: "arch-colornote-init",
        name: "DOC-20260919-WA0000.bin",
        size: 986112,
        mime: "application/octet-stream",
        uploadedAt: "2026-09-19T04:15:00.000Z",
        sourceType: "bin",
        extractedCount: 8,
        status: "extracted" as const,
      }
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem("noteflow_archived_docs", JSON.stringify(archivedDocuments));
    } catch {}
  }, [archivedDocuments]);

  const handleArchiveDocument = (doc: ArchivedDocument) => {
    setArchivedDocuments((prev) => {
      const exists = prev.some((d) => d.name === doc.name && d.size === doc.size);
      if (exists) return prev;
      return [doc, ...prev];
    });
  };

  const handleDeleteArchivedDocument = (id: string) => {
    setArchivedDocuments((prev) => prev.filter((d) => d.id !== id));
  };

  // User Profile & Sync States
  const [syncLogs, setSyncLogs] = useState<SyncedNoteRecord[]>(getStoredSyncLogs);

  const handleUpdateUiThemeStyle = (style: UIThemeStyle) => {
    setUiThemeStyle(style);
  };

  const handleUpdateMenuOrder = (newOrder: ActiveTab[]) => {
    updateMenuOrder(newOrder);
  };

  // Navigation & Filter States
  const [activeTab, setActiveTab] = useState<ActiveTab>("home");
  const [isRadialMenuOpen, setIsRadialMenuOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("Tümü");
  const [categories, setCategories] = useState<string[]>(DEFAULT_CATEGORIES);
  const [sortOption, setSortOption] = useState<SortOption>("updated");
  const [filterOption, setFilterOption] = useState<FilterOption>("all");

  // Modal & Drawer States
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [isNoteModalOpen, setIsNoteModalOpen] = useState<boolean>(false);
  const [showTrashModal, setShowTrashModal] = useState<boolean>(false);
  const [showNewCardModal, setShowNewCardModal] = useState<boolean>(false);
  const [showAIChatModal, setShowAIChatModal] = useState<boolean>(false);
  const [isImageGalleryOpen, setIsImageGalleryOpen] = useState<boolean>(false);
  const [pendingImageInsert, setPendingImageInsert] = useState<string | null>(null);
  const [pendingFrameInsert, setPendingFrameInsert] = useState<FramePreset | null>(null);
  const [isSectionManagerOpen, setIsSectionManagerOpen] = useState<boolean>(false);
  const [infographicNote, setInfographicNote] = useState<Note | null>(null);
  const [isDocumentHubOpen, setIsDocumentHubOpen] = useState<boolean>(false);
  const [documentHubDefaultNote, setDocumentHubDefaultNote] = useState<Note | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isCreateMenuOpen, setIsCreateMenuOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Vault/Kasa States
  const [isVaultOpen, setIsVaultOpen] = useState<boolean>(false);
  const [vaultRecord, setVaultRecord] = useState<VaultMetadata | null>(getStoredVaultRecord);
  const [isVaultUnlocked, setIsVaultUnlocked] = useState<boolean>(false);
  const [rawVaultKey, setRawVaultKey] = useState<Uint8Array | null>(null);
  const [vaultNotes, setVaultNotes] = useState<Note[]>([]);

  // ColorNote (.BIN) Decryption & Import States
  const [isColorNoteModalOpen, setIsColorNoteModalOpen] = useState<boolean>(false);
  const [colorNoteFilePending, setColorNoteFilePending] = useState<{ name: string; size: number; base64: string } | null>(null);
  const colorNoteInputRef = React.useRef<HTMLInputElement | null>(null);

  const handleOpenColorNoteFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setColorNoteFilePending({
        name: file.name,
        size: file.size,
        base64,
      });
      setIsColorNoteModalOpen(true);
    };
    reader.readAsDataURL(file);
  };

  const handleColorNoteFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleOpenColorNoteFile(files[0]);
    }
    e.target.value = "";
  };

  // Global + Creation Action Dispatcher (NoteSync Style)
  const handleSelectCreateAction = (actionKey: string) => {
    switch (actionKey) {
      case "colornote_import":
        if (colorNoteInputRef.current) {
          colorNoteInputRef.current.click();
        }
        break;
      case "new_note":
        setEditingNote(null);
        setIsNoteModalOpen(true);
        break;
      case "new_task_note":
        setEditingNote({
          id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          title: "Yapılacaklar & Görev Listesi",
          content: "• Öncelikli eylemleri tamamla\n• Takvimi ve notları gözden geçir",
          category: selectedSection === "Tümü" ? "Görevler" : selectedSection,
          tags: ["#görev", "#plan"],
          pinned: false,
          favorite: false,
          tasks: [
            { id: `t-${Date.now()}-1`, text: "İlk öncelikli eylem maddesi", completed: false },
            { id: `t-${Date.now()}-2`, text: "Gözden geçirme ve takip", completed: false },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        setIsNoteModalOpen(true);
        break;
      case "new_audio":
        setEditingNote({
          id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          title: "Sesli Not Kaydı",
          content: "",
          category: selectedSection === "Tümü" ? "Genel" : selectedSection,
          tags: ["#sesli"],
          pinned: false,
          favorite: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        setIsNoteModalOpen(true);
        break;
      case "ai_chat":
        setShowAIChatModal(true);
        break;
      case "ai_mindmap":
        setActiveTab("mindmap");
        break;
      case "new_section":
        setIsSectionManagerOpen(true);
        break;
      case "document_hub":
        setDocumentHubDefaultNote(null);
        setIsDocumentHubOpen(true);
        break;
      case "frame_studio":
        setIsImageGalleryOpen(true);
        break;
      case "new_flashcard":
        setShowNewCardModal(true);
        break;
      case "open_vault":
        setIsVaultOpen(true);
        break;
      default:
        setEditingNote(null);
        setIsNoteModalOpen(true);
        break;
    }
  };

  // Global Keyboard Shortcuts (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);


  // Quick Note Capture Handler
  const handleQuickCapture = (noteDraft: Partial<Note>) => {
    const newNote: Note = {
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: noteDraft.title || "Hızlı Not",
      content: noteDraft.content || "",
      category: noteDraft.category || "Genel",
      tags: noteDraft.tags || ["#hızlı"],
      pinned: false,
      favorite: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      tasks: noteDraft.tasks,
    };
    setNotes((prev) => [newNote, ...prev]);
    setToastMessage("✓ Hızlı not kaydedildi.");
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Universal Document Import Handler (Extraction Pipeline)
  const handleImportNotes = (newItems: Array<Partial<Note>>) => {
    const created: Note[] = newItems.map((item) => ({
      title: item.title || "İçe Aktarılan Not",
      content: item.content || "",
      htmlContent: item.htmlContent,
      category: item.category || "Genel",
      tags: item.tags && item.tags.length > 0 ? item.tags : ["#aktarim"],
      pinned: item.pinned ?? false,
      favorite: item.favorite ?? false,
      tasks: item.tasks || [],
      color: item.color || "amber",
      isVault: Boolean(item.isVault),
      sourceDocument: item.sourceDocument,
      attachments: item.attachments || [],
      id: item.id || `note-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: item.createdAt || new Date().toISOString(),
      updatedAt: item.updatedAt || new Date().toISOString(),
    }));

    setNotes((prev) => [...created, ...prev]);
    setViewLayout("grid");
    setSortOption("updated");
    setActiveTab("home");
    setToastMessage(`✓ ${created.length} adet bağımsız ColorNote/belge kartı 3'lü ızgara düzenine eklendi!`);
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Synchronize dynamic categories from existing notes and custom sections
  useEffect(() => {
    const extractedFromNotes = notes.map((n) => n.category).filter(Boolean);
    const extractedFromSections = sections.map((s) => s.name).filter(Boolean);
    const combined = Array.from(new Set([...DEFAULT_CATEGORIES, ...extractedFromSections, ...extractedFromNotes]));
    setCategories(combined);
  }, [notes, sections]);

  // Background hydration from IndexedDB for high-capacity notes & attachments
  useEffect(() => {
    hydrateNotesFromIndexedDB()
      .then((idbNotes) => {
        if (idbNotes && idbNotes.length > 0) {
          setNotes((currentNotes) => {
            const idbMap = new Map(idbNotes.map((n) => [n.id, n]));
            let hasChanges = false;
            const updated = currentNotes.map((c) => {
              const fromIdb = idbMap.get(c.id);
              if (!fromIdb) return c;
              if (fromIdb.attachments && fromIdb.attachments.length > 0) {
                const attMap = new Map(fromIdb.attachments.map((a) => [a.id, a]));
                const currentAtts = c.attachments || [];
                const needsHydration = currentAtts.some(
                  (a) => !a.data && attMap.has(a.id) && !!attMap.get(a.id)?.data
                );
                if (needsHydration) {
                  hasChanges = true;
                  return {
                    ...c,
                    attachments: currentAtts.map((a) => (a.data ? a : attMap.get(a.id) || a)),
                  };
                }
              }
              return c;
            });

            const currentIds = new Set(currentNotes.map((n) => n.id));
            const missing = idbNotes.filter((n) => !currentIds.has(n.id));
            if (missing.length > 0) {
              hasChanges = true;
              return [...updated, ...missing];
            }

            return hasChanges ? updated : currentNotes;
          });
        }
      })
      .catch((err) => {
        console.warn("IndexedDB notes hydration skipped:", err);
      });
  }, []);

  // Persistence effects
  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  useEffect(() => {
    saveTrash(trash);
  }, [trash]);

  useEffect(() => {
    saveFlashcards(flashcards);
  }, [flashcards]);

  useEffect(() => {
    saveClips(imageClips);
  }, [imageClips]);

  useEffect(() => {
    saveSections(sections);
  }, [sections]);

  useEffect(() => {
    saveUserProfile(userProfile);
  }, [userProfile]);

  useEffect(() => {
    saveSyncLogs(syncLogs);
  }, [syncLogs]);

  // Autonomous Vault Sweep: When vault is unlocked, sweep any public notes marked as isVault: true, encrypt them, and merge them into the secure vault storage.
  useEffect(() => {
    if (isVaultUnlocked && vaultRecord && rawVaultKey) {
      const publicVaultNotes = notes.filter((n) => n.isVault);
      if (publicVaultNotes.length > 0) {
        const sweep = async () => {
          const updatedVaultNotes = [...publicVaultNotes, ...vaultNotes];
          // Remove duplicates if any
          const uniqueVaultNotes = Array.from(new Map(updatedVaultNotes.map((n) => [n.id, n])).values());
          try {
            const updatedRecord = await saveVaultPayload(vaultRecord, uniqueVaultNotes, rawVaultKey);
            setVaultRecord(updatedRecord);
            saveVaultRecord(updatedRecord);
            setVaultNotes(uniqueVaultNotes);
            
            // Remove from public notes
            const remainingPublicNotes = notes.filter((n) => !n.isVault);
            setNotes(remainingPublicNotes);
            saveNotes(remainingPublicNotes);
            
            setToastMessage(`🔒 Otonom Koruma: ${publicVaultNotes.length} adet hassas not AES-256 ile şifrelendi ve Kasaya taşındı!`);
            setTimeout(() => setToastMessage(null), 4000);
          } catch (err) {
            console.error("Auto Sweep encryption failed:", err);
          }
        };
        sweep();
      }
    }
  }, [isVaultUnlocked, vaultRecord, rawVaultKey, notes, vaultNotes]);

  // Background Sync Processor for Offline Queue & Cloud Escalation
  useEffect(() => {
    const triggerBackgroundSync = async () => {
      if (navigator.onLine) {
        await processOfflineQueue(async (action) => {
          if (action.type === "save_note" || action.type === "categorize") {
            const noteData = action.payload as Note;
            if (noteData && noteData.title) {
              try {
                const aiResult = await autoCategorizeSingleNoteWithAI(noteData, categories);
                if (aiResult && aiResult.category && aiResult.category !== noteData.category) {
                  const newCat = aiResult.category;
                  setNotes((prev) =>
                    prev.map((n) => (n.id === noteData.id ? { ...n, category: newCat } : n))
                  );
                }
              } catch (e) {
                console.warn("Background AI scan skipped for note:", noteData.id);
              }
            }
          }
        });
      }
    };

    window.addEventListener("online", triggerBackgroundSync);
    triggerBackgroundSync();

    return () => {
      window.removeEventListener("online", triggerBackgroundSync);
    };
  }, [categories]);

  // Handle section management
  const handleSaveSections = (updated: SectionItem[]) => {
    reorderSections(updated);
  };

  // Handle profile updates
  const handleUpdateProfile = (updated: UserProfile) => {
    handleUpdateProfileState(updated);
    setToastMessage("✓ Profil ve senkronizasyon ayarları güncellendi.");
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Handle Note Auto Sync Dispatch
  const handleSyncNote = async (note: Note) => {
    try {
      setToastMessage(`"${note.title || "Not"}" ${userProfile.email} ve kanallara senkronize ediliyor...`);
      const res = await fetch("/api/sync/dispatch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          noteId: note.id,
          title: note.title || "Başlıksız Not",
          content: note.content,
          profile: userProfile,
          targetChannels: ["email", "cloud"],
        }),
      });

      const data = await res.json();
      const newRecord: SyncedNoteRecord = {
        id: `sync-${Date.now()}`,
        noteId: note.id,
        noteTitle: note.title || "Başlıksız Not",
        destination: `Gmail (${userProfile.email || "enes02erdm@gmail.com"})`,
        channelType: "email",
        status: "success",
        timestamp: new Date().toISOString(),
        details: data.message || "Otomatik bulut ve e-posta senkronizasyonu tamamlandı.",
      };

      const updated = [newRecord, ...syncLogs];
      setSyncLogs(updated);
      saveSyncLogs(updated);
      setToastMessage(`✓ "${note.title || "Not"}" başarıyla ${userProfile.email} adresine kaydedildi!`);
      setTimeout(() => setToastMessage(null), 4000);
    } catch (err) {
      console.warn("Sync dispatch network fallback:", err);
      const fallbackRecord: SyncedNoteRecord = {
        id: `sync-${Date.now()}`,
        noteId: note.id,
        noteTitle: note.title || "Başlıksız Not",
        destination: `Yerel Kayıt (${userProfile.email || "Profil"})`,
        channelType: "email",
        status: "success",
        timestamp: new Date().toISOString(),
        details: "Profil senkronizasyon kaydına başarıyla eklendi.",
      };
      const updated = [fallbackRecord, ...syncLogs];
      setSyncLogs(updated);
      saveSyncLogs(updated);
      setToastMessage(`✓ "${note.title || "Not"}" ${userProfile.email} profiline kaydedildi.`);
      setTimeout(() => setToastMessage(null), 4000);
    }
  };

  const handleAddSyncLog = (log: Omit<SyncedNoteRecord, "id">) => {
    const newLog: SyncedNoteRecord = {
      ...log,
      id: `sync-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    const updated = [newLog, ...syncLogs];
    setSyncLogs(updated);
    saveSyncLogs(updated);
  };

  const handleClearSyncLogs = () => {
    setSyncLogs([]);
    saveSyncLogs([]);
    setToastMessage("Senkronizasyon kayıtları temizlendi.");
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Note CRUD Actions
  const handleSaveNote = async (savedNote: Note, isVaultDestination: boolean) => {
    // Apply offline local rule categorization if necessary
    let noteToSave = { ...savedNote };
    if (!navigator.onLine && (!noteToSave.category || noteToSave.category === "Genel" || noteToSave.category === "Kişisel")) {
      const localRes = categorizeNoteLocally(noteToSave.title, noteToSave.content);
      noteToSave.category = localRes.category;
    }

    if (isVaultDestination || noteToSave.isVault) {
      noteToSave.isVault = true;
      if (isVaultUnlocked && vaultRecord && rawVaultKey) {
        // Vault is unlocked, immediately encrypt and save in Vault storage
        const updatedVaultNotes = [noteToSave, ...vaultNotes.filter((n) => n.id !== noteToSave.id)];
        setVaultNotes(updatedVaultNotes);
        try {
          const updatedRecord = await saveVaultPayload(vaultRecord, updatedVaultNotes, rawVaultKey);
          setVaultRecord(updatedRecord);
          saveVaultRecord(updatedRecord);
          setToastMessage("✓ Hassas not askeri düzeyde (AES-256) şifrelenip Kasaya kaydedildi!");
        } catch (err) {
          console.error("Kasa şifreleme hatası:", err);
          setToastMessage("⚠️ Kasa şifreleme işlemi başarısız oldu.");
        }
      } else {
        // Vault is locked/setup needed. Save temporarily as hidden note, and prompt to unlock
        const existingIdx = notes.findIndex((n) => n.id === noteToSave.id);
        if (existingIdx >= 0) {
          const updated = [...notes];
          updated[existingIdx] = noteToSave;
          setNotes(updated);
        } else {
          setNotes([noteToSave, ...notes]);
        }
        setIsVaultOpen(true);
        setToastMessage("🔒 Otonom Koruma: Not geçici olarak gizlendi. Şifrelemek için şifrenizi girin.");
      }
    } else {
      const existingIdx = notes.findIndex((n) => n.id === noteToSave.id);
      if (existingIdx >= 0) {
        const updated = [...notes];
        updated[existingIdx] = { ...noteToSave, isVault: false };
        setNotes(updated);
        if (!navigator.onLine) {
          enqueueOfflineAction("save_note", noteToSave.id, noteToSave);
        }
      } else {
        setNotes([{ ...noteToSave, isVault: false }, ...notes]);
        if (!navigator.onLine) {
          enqueueOfflineAction("save_note", noteToSave.id, noteToSave);
        }
      }
    }

    setIsNoteModalOpen(false);
    setEditingNote(null);
  };

  const handleTogglePin = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)));
  };

  const handleToggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, favorite: !n.favorite } : n)));
  };

  const handleDeleteToTrash = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const noteToDelete = notes.find((n) => n.id === id);
    if (noteToDelete) {
      setNotes((prev) => prev.filter((n) => n.id !== id));
      const trashItem: TrashItem = {
        ...noteToDelete,
        deletedAt: new Date().toISOString(),
        originalVault: false,
      };
      setTrash((prev) => [trashItem, ...prev]);
    }
  };

  // Change a note's category/section manually (Human-in-the-loop override)
  const handleChangeNoteCategory = (noteId: string, newCategory: string) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === noteId
          ? {
              ...n,
              category: newCategory,
              aiCategoryReason: `Kullanıcı manuel olarak "${newCategory}" kategorisine atadı.`,
              updatedAt: new Date().toISOString(),
            }
          : n
      )
    );
    // Auto add category to categories if not already present
    setCategories((prev) => (prev.includes(newCategory) ? prev : [...prev, newCategory]));
    setToastMessage(`✓ Not "${newCategory}" bölümüne taşındı.`);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // AI-Powered Single Note Semantic Auto-Categorization
  const handleAutoCategorizeSingleNote = async (note: Note) => {
    setToastMessage(`✨ Yapay zeka "${note.title || "Not"}" içeriğini anlamsal olarak analiz ediyor...`);
    try {
      const result = await autoCategorizeSingleNoteWithAI(note, categories);
      if (result.category) {
        setNotes((prev) =>
          prev.map((n) =>
            n.id === note.id
              ? {
                  ...n,
                  category: result.category,
                  tags: result.tags,
                  aiCategorized: true,
                  aiCategoryReason: result.reason,
                  aiCategoryConfidence: result.confidence,
                  updatedAt: new Date().toISOString(),
                }
              : n
          )
        );
        setCategories((prev) => (prev.includes(result.category) ? prev : [...prev, result.category]));
        setToastMessage(`✓ "${note.title || "Not"}" → "${result.category}" kategorisine taşındı! (${result.reason})`);
      }
    } catch (err) {
      console.error(err);
      setToastMessage("Anlamsal kategorizasyon yapılamadı.");
    } finally {
      setTimeout(() => setToastMessage(null), 4000);
    }
  };

  // Auto-organize all notes into categories based on deep AI semantic analysis
  const handleAutoOrganizeCategories = async () => {
    setToastMessage(`✨ Yapay Zeka (Semantik Analiz) ${notes.length} adet notu derinlemesine inceliyor...`);
    try {
      const { updatedNotes, reclassifiedCount } = await batchCategorizeNotesWithAI(
        notes,
        categories,
        (processed, total) => {
          setToastMessage(`✨ Semantik Analiz: ${processed}/${total} not sınıflandırıldı...`);
        }
      );
      setNotes(updatedNotes);
      saveNotes(updatedNotes);
      const syncedCats = synchronizeCategories(categories, updatedNotes);
      setCategories(syncedCats);
      setToastMessage(`✨ Yapay Zeka: ${reclassifiedCount} adet not derin anlamsal kavrayış ile kategorilendi!`);
    } catch (err) {
      console.warn("AI Batch failed, falling back to local rule engine", err);
      const { updatedNotes, reclassifiedCount } = autoCategorizeNotes(notes, true);
      setNotes(updatedNotes);
      saveNotes(updatedNotes);
      setToastMessage(`✨ ${reclassifiedCount} adet not içeriklerine göre bölümlere ayrıldı.`);
    } finally {
      setTimeout(() => setToastMessage(null), 4000);
    }
  };

  // Remove custom category
  const handleRemoveCategory = (catName: string) => {
    setCategories((prev) => prev.filter((c) => c !== catName));
    if (selectedCategory === catName) {
      setSelectedCategory("Tümü");
    }
  };

  // Trash Operations
  const handleRestoreFromTrash = (id: string) => {
    const item = trash.find((t) => t.id === id);
    if (!item) return;

    setTrash((prev) => prev.filter((t) => t.id !== id));

    const restoredNote: Note = {
      id: item.id,
      title: item.title,
      content: item.content,
      category: item.category,
      tags: item.tags || [],
      pinned: item.pinned,
      favorite: item.favorite,
      color: item.color,
      reminder: item.reminder,
      attachments: item.attachments,
      tasks: item.tasks,
      audioNotes: item.audioNotes,
      isVault: !!item.originalVault,
      createdAt: item.createdAt,
      updatedAt: new Date().toISOString(),
    };

    setNotes((prev) => [restoredNote, ...prev]);
  };

  const handleDeleteForever = (id: string) => {
    setTrash((prev) => prev.filter((t) => t.id !== id));
  };

  const handleEmptyTrash = () => {
    setTrash([]);
  };

  // Elements & Stickers Library Operations (Goodnotes & Notability style)
  const handleSaveImageClip = (element: ElementSnippet) => {
    setImageClips((prev) => {
      const updated = [element, ...prev.filter((e) => e.id !== element.id)];
      saveStoredElements(updated);
      return updated;
    });
  };

  const handleDeleteImageClip = (id: string) => {
    setImageClips((prev) => {
      const updated = prev.filter((e) => e.id !== id);
      saveStoredElements(updated);
      return updated;
    });
  };

  const handleInsertClipIntoNote = (elementOrData: ElementSnippet | string, size?: "small" | "medium" | "large") => {
    const dataUrl = typeof elementOrData === "string" ? elementOrData : elementOrData.data;
    if (!isNoteModalOpen) {
      // Create new note with this element
      const name = typeof elementOrData === "string" ? "Öğeli Yeni Not" : elementOrData.name || "Öğeli Yeni Not";
      setEditingNote({
        id: `note-${Date.now()}`,
        title: name,
        content: "",
        category: "Kişisel",
        tags: ["#öğeler", "#çıkartma"],
        pinned: false,
        favorite: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      setIsNoteModalOpen(true);
    }
    setPendingImageInsert(dataUrl);
    setToastMessage("✓ Öğe nota başarıyla eklendi!");
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleApplyFrameToEditor = (frame: FramePreset) => {
    if (!isNoteModalOpen) {
      setEditingNote({
        id: `note-${Date.now()}`,
        title: `${frame.name} Notu`,
        content: frame.getHtml("Not içeriğini buraya yazın...", `${frame.name} Notu`),
        category: "Kişisel",
        tags: ["#çerçeve"],
        pinned: false,
        favorite: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      setIsNoteModalOpen(true);
    } else {
      setPendingFrameInsert(frame);
    }
    setToastMessage(`✓ '${frame.name}' çerçevesi nota uygulandı!`);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Reset entire app data
  const handleResetAllData = () => {
    localStorage.clear();
    setNotes([]);
    setTrash([]);
    setFlashcards([]);
    setImageClips([]);
    window.location.reload();
  };

  // Import full JSON backup
  const handleImportBackup = (data: any) => {
    if (!data) return;
    if (Array.isArray(data.notes)) {
      setNotes(data.notes);
      saveNotes(data.notes);
    }
    if (Array.isArray(data.trash)) {
      setTrash(data.trash);
      saveTrash(data.trash);
    }
    if (Array.isArray(data.flashcards)) {
      setFlashcards(data.flashcards);
      saveFlashcards(data.flashcards);
    }
  };

  // Import custom single document (TXT, CSV, HTML, MD)
  const handleImportCustomDocument = (title: string, content: string, category: string) => {
    const newNote: Note = {
      id: `note-import-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title || "İçe Aktarılan Belge",
      content,
      category: category || "İçe Aktarılan",
      tags: ["#aktarılan"],
      pinned: false,
      favorite: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setNotes((prev) => [newNote, ...prev]);
  };

  // Filter and Sort Public Notes
  const filteredNotes = useMemo(() => {
    return notes
      .filter((note) => {
        // Vault filter: Never show vault notes in standard views
        if (note.isVault) return false;

        // Turkish-aware and field-comprehensive search filter
        if (searchQuery.trim()) {
          if (!matchNoteWithSearch(note, searchQuery)) return false;
        }

        // Section filter
        if (selectedSection !== "Tümü" && note.category !== selectedSection) {
          return false;
        }

        // Category filter
        if (selectedCategory !== "Tümü" && note.category !== selectedCategory) {
          return false;
        }

        // Quick filter
        if (filterOption === "favorites" && !note.favorite) return false;
        if (filterOption === "reminders" && !note.reminder) return false;
        if (filterOption === "tasks" && (!note.tasks || note.tasks.length === 0)) return false;

        return true;
      })
      .sort((a, b) => {
        // Pinned notes always float to top
        if (a.pinned !== b.pinned) {
          return a.pinned ? -1 : 1;
        }

        if (sortOption === "newest") {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        } else if (sortOption === "oldest") {
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        } else if (sortOption === "alphabetical") {
          return a.title.localeCompare(b.title, "tr-TR");
        } else if (sortOption === "color") {
          return (a.color || "amber").localeCompare(b.color || "amber", "tr-TR");
        } else {
          // Default: 'updated' (Modified Time Descending - ColorNote style)
          return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
        }
      });
  }, [notes, searchQuery, selectedCategory, selectedSection, filterOption, sortOption]);

  // Counts by category
  const countsByCategory = useMemo(() => {
    const nonVaultNotes = notes.filter((n) => !n.isVault);
    const counts: Record<string, number> = { Tümü: nonVaultNotes.length };
    categories.forEach((cat) => {
      if (cat !== "Tümü") {
        counts[cat] = nonVaultNotes.filter((n) => n.category === cat).length;
      }
    });
    return counts;
  }, [notes, categories]);

  const currentThemeStyle = UI_THEME_STYLE_CONFIGS[uiThemeStyle] || UI_THEME_STYLE_CONFIGS.minimalist;

  return (
    <div className={`min-h-screen flex flex-col transition-colors pb-28 sm:pb-36 accent-${themeAccent} ${currentThemeStyle.bgClass}`}>
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white dark:bg-teal-600 dark:text-white px-4 py-2 rounded-2xl shadow-xl border border-slate-700/50 dark:border-teal-400 text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-3">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-white shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Global Top Header with Layout Switcher, Gallery button, and Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        themeAccent={themeAccent}
        setThemeAccent={setThemeAccent}
        onOpenDocumentHub={() => {
          setDocumentHubDefaultNote(null);
          setIsDocumentHubOpen(true);
        }}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        sortOption={sortOption}
        setSortOption={setSortOption}
        filterOption={filterOption}
        setFilterOption={setFilterOption}
        viewLayout={viewLayout}
        setViewLayout={setViewLayout}
        onOpenNewNote={() => {
          setEditingNote(null);
          setIsNoteModalOpen(true);
        }}
        onOpenCreateMenu={() => setIsCreateMenuOpen(true)}
        onOpenTrash={() => setShowTrashModal(true)}
        onOpenSideGallery={() => setIsImageGalleryOpen(true)}
        clipsCount={imageClips.length}
        totalNotesCount={notes.filter((n) => !n.isVault).length}
        vaultNotesCount={vaultNotes.length}
        trashCount={trash.length}
        sections={sections}
        selectedSection={selectedSection}
        onSelectSection={(sec) => {
          setSelectedSection(sec);
          if (sec !== "Tümü") {
            setSelectedCategory("Tümü");
          }
        }}
        onOpenSectionManager={() => setIsSectionManagerOpen(true)}
        profile={userProfile}
        onSecretVaultTrigger={() => setIsVaultOpen(true)}
        isVaultUnlocked={isVaultUnlocked}
        onOpenAuthModal={() => {
          setAuthModalMode("login");
          setIsAuthModalOpen(true);
        }}
      />

      {/* Main Container View depending on activeTab with dynamic Safe Insets */}
      <main
        className="flex-1 w-full max-w-6xl mx-auto px-3 sm:px-4 py-2 sm:py-4 transition-all duration-300"
        style={layoutSafePadding.inlineStyle}
      >
        {/* TAB 1: HOME NOTES */}
        {activeTab === "home" && (
          uiThemeStyle === "circadian_pkm" ? (
            <IntegratedStrategicPKMView
              notes={notes}
              onOpenNote={(n) => {
                setEditingNote(n);
                setIsNoteModalOpen(true);
              }}
              onOpenNewNote={() => {
                setEditingNote(null);
                setIsNoteModalOpen(true);
              }}
              onQuickCapture={handleQuickCapture}
              onSwitchToTheme={(style) => handleUpdateUiThemeStyle(style)}
              onOpenThemeSettings={() => setActiveTab("profile")}
            />
          ) : uiThemeStyle === "enterprise_pkm" ? (
            <div className="space-y-6">
              <EnterprisePKMDashboard
                notes={notes}
                onOpenNote={(n) => {
                  const fullNote = notes.find((item) => item.id === n.id);
                  if (fullNote) setEditingNote(fullNote);
                  setIsNoteModalOpen(true);
                }}
              />
            </div>
          ) : (
            <div className="space-y-3 sm:space-y-4">
            {/* Category Chips Bar */}
            <CategoryChips
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                if (cat !== "Tümü") {
                  setSelectedSection("Tümü");
                }
              }}
              onAddCategory={(newCat) => setCategories((prev) => [...prev, newCat])}
              onRemoveCategory={handleRemoveCategory}
              onAutoOrganize={handleAutoOrganizeCategories}
              countsByCategory={countsByCategory}
            />

            {/* Note Cards Rendered According to viewLayout (Grid, List, Compact) */}
            {filteredNotes.length === 0 ? (
              <div className="text-center py-20 px-4 bg-white dark:bg-slate-900/60 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 shadow-xs">
                <StickyNote className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-200 mb-1">
                  {searchQuery ? "Aramanıza Uygun Not Bulunamadı" : "Henüz Not Eklenmemiş"}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-5 max-w-sm mx-auto">
                  {searchQuery
                    ? "Arama kriterlerinizi değiştirmeyi veya filtreleri temizlemeyi deneyin."
                    : "Yeni bir fikir, yapılacaklar listesi veya zengin not oluşturmak için ＋ butonuna dokunun."}
                </p>
                <button
                  onClick={() => {
                    setEditingNote(null);
                    setIsNoteModalOpen(true);
                  }}
                  className="px-5 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white rounded-2xl text-xs font-bold shadow-md shadow-teal-500/20 active:scale-95 transition-all inline-flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>İlk Notunuzu Oluşturun</span>
                </button>
              </div>
            ) : viewLayout === "kanban" ? (
              <KanbanBoardView
                notes={filteredNotes}
                categories={categories}
                onOpenNote={(n) => {
                  setEditingNote(n);
                  setIsNoteModalOpen(true);
                }}
                onOpenNewNoteInCategory={(cat) => {
                  setEditingNote({
                    id: `note-${Date.now()}`,
                    title: "",
                    content: "",
                    category: cat,
                    tags: [],
                    pinned: false,
                    favorite: false,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString(),
                  });
                  setIsNoteModalOpen(true);
                }}
                onChangeCategory={(noteId, newCat) => handleChangeNoteCategory(noteId, newCat)}
                onDeleteNote={handleDeleteToTrash}
                onToggleFavorite={handleToggleFavorite}
                onTogglePin={handleTogglePin}
              />
            ) : viewLayout === "timeline" ? (
              <TimelineFeedView
                notes={filteredNotes}
                onOpenNote={(n) => {
                  setEditingNote(n);
                  setIsNoteModalOpen(true);
                }}
                onToggleFavorite={handleToggleFavorite}
                onTogglePin={handleTogglePin}
                onDeleteNote={handleDeleteToTrash}
                onTagClick={(tag) => setSearchQuery(tag)}
              />
            ) : viewLayout === "mindmap_canvas" ? (
              <MindMapCanvasView
                notes={filteredNotes}
                categories={categories}
                onOpenNote={(n) => {
                  setEditingNote(n);
                  setIsNoteModalOpen(true);
                }}
                onOpenNewNoteInCategory={(cat) => {
                  setEditingNote({
                    id: `note-${Date.now()}`,
                    title: "",
                    content: "",
                    category: cat,
                    tags: [],
                    pinned: false,
                    favorite: false,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString(),
                  });
                  setIsNoteModalOpen(true);
                }}
              />
            ) : viewLayout === "compact_strip" ? (
              <CompactStripView
                notes={filteredNotes}
                onOpenNote={(n) => {
                  setEditingNote(n);
                  setIsNoteModalOpen(true);
                }}
                onToggleFavorite={handleToggleFavorite}
                onTogglePin={handleTogglePin}
                onDeleteNote={handleDeleteToTrash}
                onTagClick={(tag) => setSearchQuery(tag)}
              />
            ) : (
              <div
                className={
                  viewLayout === "grid"
                    ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4"
                    : viewLayout === "largeGrid"
                    ? "grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-5"
                    : viewLayout === "list"
                    ? "flex flex-col gap-1.5"
                    : "flex flex-col gap-2.5 sm:gap-3"
                }
              >
                {filteredNotes.map((note) => (
                  <NoteCard
                    key={note.id}
                    note={note}
                    viewLayout={viewLayout}
                    categories={categories}
                    onChangeCategory={(noteId, newCat) => handleChangeNoteCategory(noteId, newCat)}
                    onAutoCategorizeNote={handleAutoCategorizeSingleNote}
                    onOpen={(n) => {
                      setEditingNote(n);
                      setIsNoteModalOpen(true);
                    }}
                    onTogglePin={handleTogglePin}
                    onToggleFavorite={handleToggleFavorite}
                    onDelete={handleDeleteToTrash}
                    onTagClick={(tag) => setSearchQuery(tag)}
                    onOpenInfographic={(n, e) => {
                      e.stopPropagation();
                      setInfographicNote(n);
                    }}
                    onSyncNote={(n, e) => {
                      e.stopPropagation();
                      handleSyncNote(n);
                    }}
                    onExportNote={(n, e) => {
                      e.stopPropagation();
                      setDocumentHubDefaultNote(n);
                      setIsDocumentHubOpen(true);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
          )
        )}

        {/* TAB 2: UNIVERSAL DOCUMENT HUB & EXPORTS */}
        {activeTab === "docs" && (
          <DocumentCenterView
            notes={notes}
            sections={sections}
            themeAccent={themeAccent}
            archivedDocuments={archivedDocuments}
            onArchiveDocument={handleArchiveDocument}
            onDeleteArchivedDocument={handleDeleteArchivedDocument}
            onImportNotes={handleImportNotes}
            onNavigateToNotes={() => setActiveTab("home")}
            onOpenColorNoteDecoder={(fileData) => {
              if (fileData) {
                setColorNoteFilePending(fileData);
              }
              setIsColorNoteModalOpen(true);
            }}
            onOpenNote={(n) => {
              setEditingNote(n);
              setIsNoteModalOpen(true);
            }}
          />
        )}

        {/* TAB 3: MIND MAP / BİLGİ HARİTASI */}
        {activeTab === "mindmap" && (
          <MindMapView
            notes={notes}
            sections={sections}
            onOpenNote={(n) => {
              setEditingNote(n);
              setIsNoteModalOpen(true);
            }}
            onOpenInfographic={(n) => setInfographicNote(n)}
            selectedSection={selectedSection}
            onSelectSection={(sec) => setSelectedSection(sec)}
            profile={userProfile}
            onOpenProfile={() => setActiveTab("profile")}
          />
        )}



        {/* TAB 4: STUDY & FLASHCARDS */}
        {activeTab === "study" && (
          <StudyView
            flashcards={flashcards}
            notes={notes}
            onUpdateFlashcards={(updated) => setFlashcards(updated)}
            onOpenNewCardModal={() => setShowNewCardModal(true)}
          />
        )}

        {/* TAB: DEDICATED SECURE VAULT VIEW (KASA MENÜSÜ) */}
        {activeTab === "vault" && (
          <div className="max-w-4xl mx-auto px-1 sm:px-4 py-2 animate-in fade-in duration-200">
            <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50 dark:bg-slate-900/50">
                <span className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2 select-none">
                  <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Akıllı Güvenli Kasa (Smart Stealth Vault)</span>
                </span>
                <button
                  onClick={() => setActiveTab("home")}
                  className="px-3 py-1.5 rounded-xl hover:bg-slate-200/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Notlara Dön</span>
                </button>
              </div>
              <VaultView
                isVaultUnlocked={isVaultUnlocked}
                setIsVaultUnlocked={setIsVaultUnlocked}
                vaultRecord={vaultRecord}
                setVaultRecord={(record) => {
                  setVaultRecord(record);
                  saveVaultRecord(record);
                }}
                rawVaultKey={rawVaultKey}
                setRawVaultKey={setRawVaultKey}
                vaultNotes={vaultNotes}
                setVaultNotes={setVaultNotes}
                themeAccent={themeAccent}
                workspaceNotes={notes}
                onMigrateNotesToVault={async (notesToMigrate) => {
                  const migratedIds = new Set(notesToMigrate.map((n) => n.id));
                  const remaining = notes.filter((n) => !migratedIds.has(n.id));
                  setNotes(remaining);
                  saveNotes(remaining);
                }}
                onClose={() => setActiveTab("home")}
              />
            </div>
          </div>
        )}

        {/* TAB 5: PROFILE & SOCIAL / EMAIL SYNC & VAULT REGISTRATION */}
        {activeTab === "profile" && (
          <ProfileView
            profile={userProfile}
            onUpdateProfile={handleUpdateProfile}
            syncLogs={syncLogs}
            onAddSyncLog={handleAddSyncLog}
            onClearSyncLogs={handleClearSyncLogs}
            notes={notes}
            onOpenNote={(n) => {
              setEditingNote(n);
              setIsNoteModalOpen(true);
            }}
            vaultRecord={vaultRecord}
            setVaultRecord={(rec) => {
              setVaultRecord(rec);
              saveVaultRecord(rec);
            }}
            vaultNotes={vaultNotes}
            isVaultUnlocked={isVaultUnlocked}
            onOpenVault={() => {
              setActiveTab("vault");
              setIsVaultOpen(true);
            }}
            rawVaultKey={rawVaultKey}
            onNavigateToVaultTab={() => {
              setActiveTab("vault");
            }}
            themeAccent={themeAccent}
            onChangeThemeAccent={setThemeAccent}
            darkMode={darkMode}
            onToggleDarkMode={() => setDarkMode(!darkMode)}
            uiThemeStyle={uiThemeStyle}
            onChangeUiThemeStyle={handleUpdateUiThemeStyle}
            menuOrder={menuOrder}
            onUpdateMenuOrder={handleUpdateMenuOrder}
            onImportNotes={(newNotes) => {
              const formatted: Note[] = newNotes.map((n, idx) => ({
                ...n,
                id: `note-import-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              }));
              setNotes((prev) => [...formatted, ...prev]);
            }}
            flashcards={flashcards}
            onUpdateFlashcards={(cards) => {
              setFlashcards(cards);
              saveFlashcards(cards);
            }}
            onOpenNewCardModal={() => setShowNewCardModal(true)}
            trash={trash}
            onOpenTrash={() => setShowTrashModal(true)}
            onResetAllData={handleResetAllData}
            onImportBackup={handleImportBackup}
          />
        )}

        {/* TAB 6: TIPS & TRICKS GUIDE */}
        {activeTab === "tips" && (
          <TipsView
            onOpenNewNote={() => {
              setEditingNote(null);
              setIsNoteModalOpen(true);
            }}
            onOpenVault={() => setActiveTab("home")}
            onOpenStudy={() => setActiveTab("study")}
            onOpenSettings={() => setActiveTab("settings")}
            onOpenGallery={() => setIsImageGalleryOpen(true)}
          />
        )}

        {/* TAB 7: SETTINGS & UNIVERSAL EXPORTS */}
        {activeTab === "settings" && (
          <SettingsView
            notes={notes}
            trash={trash}
            flashcards={flashcards}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            themeAccent={themeAccent}
            setThemeAccent={setThemeAccent}
            onOpenTrash={() => setShowTrashModal(true)}
            onOpenDocumentHub={() => {
              setDocumentHubDefaultNote(null);
              setIsDocumentHubOpen(true);
            }}
            onImportBackup={handleImportBackup}
            onImportCustomDocument={handleImportCustomDocument}
            onResetAllData={handleResetAllData}
          />
        )}
      </main>

      {/* Dynamic Customizable Navigation Bar / Floating Dock */}
      <DynamicNavigationBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCreateMenu={() => setIsCreateMenuOpen(true)}
        onQuickNoteCreate={() => {
          setEditingNote(null);
          setIsNoteModalOpen(true);
        }}
        onOpenAIChat={() => setShowAIChatModal(true)}
        onOpenSideGallery={() => setIsImageGalleryOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenVault={() => setIsVaultOpen(true)}
        totalNotesCount={notes.filter((n) => !n.isVault).length}
        vaultNotesCount={vaultNotes.length}
        isVaultUnlocked={isVaultUnlocked}
        themeAccent={themeAccent}
        profile={userProfile}
        menuOrder={menuOrder}
      />



      {/* Dynamic Sections Manager Modal */}
      {isSectionManagerOpen && (
        <SectionManagerModal
          sections={sections}
          onSaveSections={handleSaveSections}
          onClose={() => setIsSectionManagerOpen(false)}
          onSelectSection={(sec) => {
            setSelectedSection(sec);
            setIsSectionManagerOpen(false);
          }}
        />
      )}

      {/* AI Infographic Summary Modal */}
      {infographicNote && (
        <InfographicModal
          note={infographicNote}
          onClose={() => setInfographicNote(null)}
        />
      )}

      {/* Note Editor Modal with Word-like Rich Text & Box/Photo Snapshot */}
      {isNoteModalOpen && (
        <NoteModal
          note={editingNote}
          categories={categories}
          isVaultOpen={false}
          onSave={handleSaveNote}
          onClose={() => {
            setIsNoteModalOpen(false);
            setEditingNote(null);
            setPendingImageInsert(null);
            setPendingFrameInsert(null);
          }}
          onAddFlashcardsFromNote={(newCards) => {
            const formatted: Flashcard[] = newCards.map((c) => ({
              id: `fc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              question: c.question,
              answer: c.answer,
              mastered: false,
            }));
            setFlashcards((prev) => [...prev, ...formatted]);
          }}
          onSaveImageClip={handleSaveImageClip}
          onOpenSideGallery={() => setIsImageGalleryOpen((prev) => !prev)}
          isSideGalleryOpen={isImageGalleryOpen}
          pendingImageInsert={pendingImageInsert}
          onClearPendingImageInsert={() => setPendingImageInsert(null)}
          pendingFrameInsert={pendingFrameInsert}
          onClearPendingFrameInsert={() => setPendingFrameInsert(null)}
          profile={userProfile}
          onOpenProfile={() => setActiveTab("profile")}
        />
      )}

      {/* Create Action Menu Modal (NoteSync Center Style) */}
      <CreateMenuModal
        isOpen={isCreateMenuOpen}
        onClose={() => setIsCreateMenuOpen(false)}
        onSelectAction={handleSelectCreateAction}
        themeAccent={themeAccent}
        profile={userProfile}
      />

      {/* Goodnotes & Notability Style Elements & Custom Stickers Library Drawer */}
      <ElementsLibraryDrawer
        isOpen={isImageGalleryOpen}
        onClose={() => setIsImageGalleryOpen(false)}
        onToggle={() => setIsImageGalleryOpen((prev) => !prev)}
        elements={imageClips}
        onAddElement={handleSaveImageClip}
        onDeleteElement={handleDeleteImageClip}
        onInsertIntoNote={handleInsertClipIntoNote}
        isNoteEditorOpen={isNoteModalOpen}
        themeAccent={themeAccent}
      />

      {/* Trash Modal */}
      {showTrashModal && (
        <TrashModal
          trash={trash}
          onRestore={handleRestoreFromTrash}
          onDeleteForever={handleDeleteForever}
          onEmptyTrash={handleEmptyTrash}
          onClose={() => setShowTrashModal(false)}
        />
      )}

      {/* New Flashcard Modal */}
      {showNewCardModal && (
        <NewCardModal
          onSaveCard={(card) => setFlashcards((prev) => [card, ...prev])}
          onClose={() => setShowNewCardModal(false)}
        />
      )}

      {/* AI Assistant Chat Modal */}
      {showAIChatModal && (
        <AIChatModal
          notes={notes}
          profile={userProfile}
          onUpdateProfile={handleUpdateProfile}
          onOpenProfile={() => {
            setShowAIChatModal(false);
            setActiveTab("profile");
          }}
          onClose={() => setShowAIChatModal(false)}
        />
      )}

      {/* Universal Document & File Hub Modal */}
      <DocumentHubModal
        isOpen={isDocumentHubOpen}
        onClose={() => {
          setIsDocumentHubOpen(false);
          setDocumentHubDefaultNote(null);
        }}
        notes={notes}
        sections={sections}
        themeAccent={themeAccent}
        defaultNote={documentHubDefaultNote}
        onImportNotes={handleImportNotes}
      />

      {/* ColorNote (.BIN) Decryption & Note Extraction Modal */}
      <input
        type="file"
        ref={colorNoteInputRef}
        onChange={handleColorNoteFileSelected}
        accept=".bin,.dat,.backup,application/octet-stream,*"
        className="hidden"
      />

      {isColorNoteModalOpen && colorNoteFilePending && (
        <ColorNoteImportModal
          isOpen={isColorNoteModalOpen}
          onClose={() => {
            setIsColorNoteModalOpen(false);
            setColorNoteFilePending(null);
          }}
          fileData={colorNoteFilePending}
          sections={sections}
          themeAccent={themeAccent}
          onImportNotes={(newColorNotes) => {
            const created: Note[] = newColorNotes.map((cn) => ({
              id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
              title: cn.title || "ColorNote Notu",
              content: cn.content,
              category: cn.category || "ColorNote Notları",
              tags: cn.tags && cn.tags.length > 0 ? cn.tags : ["#ColorNote"],
              pinned: cn.pinned || false,
              favorite: cn.favorite || false,
              tasks: cn.tasks || [],
              color: cn.color || "amber",
              isVault: Boolean(cn.isVault),
              createdAt: cn.createdAt || new Date().toISOString(),
              updatedAt: cn.updatedAt || new Date().toISOString(),
            }));

            // Ensure category exists
            const importedCategories = Array.from(new Set(created.map((c) => c.category)));
            setCategories((prev) => Array.from(new Set([...prev, ...importedCategories])));

            // Add newly created individual notes
            setNotes((prev) => [...created, ...prev]);

            // Switch to 3-column Grid View and home tab with updated sorting
            setViewLayout("grid");
            setActiveTab("home");
            setSortOption("updated");

            setToastMessage(`✓ ${created.length} adet bağımsız ColorNote notu 3'lü ızgara düzeninde çalışma alanınıza eklendi!`);
            setTimeout(() => setToastMessage(null), 4000);
          }}
        />
      )}

      {/* Global Spotlight Command Palette (Cmd+K / Ctrl+K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        notes={notes}
        sections={sections}
        onOpenNote={(note) => {
          setEditingNote(note);
          setIsNoteModalOpen(true);
        }}
        onNewNote={() => {
          setEditingNote(null);
          setIsNoteModalOpen(true);
        }}
        onOpenDocumentHub={() => {
          setDocumentHubDefaultNote(null);
          setIsDocumentHubOpen(true);
        }}
        onOpenAIChat={() => setShowAIChatModal(true)}
        onOpenSideGallery={() => setIsImageGalleryOpen(true)}
        onOpenTrash={() => setShowTrashModal(true)}
        onOpenMindMap={() => setActiveTab("mindmap")}
        onOpenVault={() => setIsVaultOpen(true)}
        onOpenStudy={() => setActiveTab("study")}
        onOpenProfile={() => setActiveTab("profile")}
        onOpenSettings={() => setActiveTab("settings")}
        onOpenTips={() => setActiveTab("tips")}
        onSelectCategory={(cat: string) => {
          setSelectedCategory(cat);
          setActiveTab("home");
        }}
        onSelectSection={(sec: string) => {
          setSelectedSection(sec);
          setActiveTab("home");
        }}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onChangeThemeAccent={(acc: ThemeAccent) => setThemeAccent(acc)}
        themeAccent={themeAccent}
      />

      {/* RadialMenu is contextually triggered exclusively inside RichTextEditor.tsx */}

      {/* Vault / Kasa Modal */}
      {isVaultOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md overflow-y-auto p-4 sm:p-6 md:p-10 animate-in fade-in duration-200">
          <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50 dark:bg-slate-900/50">
              <span className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2 select-none">
                <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Akıllı Güvenli Kasa (Smart Stealth Vault)</span>
              </span>
              <button
                onClick={() => setIsVaultOpen(false)}
                className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <VaultView
                isVaultUnlocked={isVaultUnlocked}
                setIsVaultUnlocked={setIsVaultUnlocked}
                vaultRecord={vaultRecord}
                setVaultRecord={(record) => {
                  setVaultRecord(record);
                  saveVaultRecord(record);
                }}
                rawVaultKey={rawVaultKey}
                setRawVaultKey={setRawVaultKey}
                vaultNotes={vaultNotes}
                setVaultNotes={setVaultNotes}
                themeAccent={themeAccent}
                workspaceNotes={notes}
                onMigrateNotesToVault={async (notesToMigrate) => {
                  const migratedIds = new Set(notesToMigrate.map((n) => n.id));
                  const remaining = notes.filter((n) => !migratedIds.has(n.id));
                  setNotes(remaining);
                  saveNotes(remaining);
                }}
                onClose={() => setIsVaultOpen(false)}
              />
            </div>
          </div>
        </div>
      )}

      {/* Global Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentProfile={userProfile}
        initialMode={authModalMode}
        onSuccess={(updated) => {
          handleUpdateProfileState(updated);
          setToastMessage(`✓ Hoş geldiniz, ${updated.name}! Tüm yapay zeka araçları aktif edildi.`);
          setTimeout(() => setToastMessage(null), 3500);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <GlobalStateProvider>
        <NoteFlowApp />
      </GlobalStateProvider>
    </ErrorBoundary>
  );
}
