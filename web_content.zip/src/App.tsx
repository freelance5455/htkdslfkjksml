import { useState, useEffect, useCallback } from "react";

// =====================================================
// TYPES & DATA
// =====================================================

interface Question {
  text: string;
  answers: string[];
}

const questions: Question[] = [
  {
    text: "Perfect evening tumhare liye kya hai? 🌙",
    answers: ["🌆 Long drive", "☕ Chai + baatein", "🎬 Movie night", "🌃 Bas shanti"],
  },
  {
    text: "Agar tumhe ek surprise mile to? 🎁",
    answers: ["🌹 Flowers", "🍫 Chocolate", "🧸 Cute teddy", "🤫 Secret surprise"],
  },
  {
    text: "Tumhara mood instantly kis cheez se achha hota hai? ✨",
    answers: ["😂 Funny baatein", "🎵 Music", "🍕 Favourite food", "🫶 Someone special"],
  },
  {
    text: "Ek din ke liye superpower mile to? 🦸‍♀️",
    answers: ["🪽 Fly karna", "⏳ Time travel", "🧠 Mind read", "✨ Magic"],
  },
];

// =====================================================
// SCREEN TRANSITION WRAPPER
// =====================================================

function ScreenTransition({ children, screenKey }: { children: React.ReactNode; screenKey: number }) {
  return (
    <div
      key={screenKey}
      className="animate-screen-in w-full flex flex-col items-center justify-center min-h-screen px-6 py-10"
    >
      {children}
    </div>
  );
}

// =====================================================
// REUSABLE COMPONENTS
// =====================================================

function PinkButton({ text, onClick }: { text: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full max-w-xs h-14 rounded-full bg-[#FF3EA5] hover:bg-[#ff5cb5] active:scale-95 transition-all duration-200 text-white text-base font-bold shadow-lg shadow-pink-500/30 hover:shadow-pink-500/50"
    >
      {text}
    </button>
  );
}

function AnswerButton({ text, onClick }: { text: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full max-w-xs py-4 px-5 rounded-2xl bg-white/10 hover:bg-white/20 active:scale-[0.97] transition-all duration-200 text-white text-base font-medium text-left border border-white/5"
    >
      {text}
    </button>
  );
}

// =====================================================
// SCREEN 0: START SCREEN
// =====================================================

function StartScreen({ onStart }: { onStart: () => void }) {
  return (
    <ScreenTransition screenKey={0}>
      <div className="text-8xl animate-bounce-slow">💗</div>
      <div className="mt-3" />
      <h1 className="text-white text-5xl sm:text-6xl font-black tracking-tight">SADIYA</h1>
      <p className="text-[#FF7BCB] text-base mt-1">has entered the app...</p>
      <div className="mt-10" />
      <p className="text-[#FF4B9D] text-sm font-bold tracking-widest">⚠️ WARNING ⚠️</p>
      <div className="mt-3" />
      <h2 className="text-white text-4xl sm:text-5xl font-black">DON'T TOUCH</h2>
      <p className="text-gray-400 text-sm mt-1">Seriously.</p>
      <div className="mt-9" />
      <PinkButton text="DON'T TOUCH 😈" onClick={onStart} />
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 1: DON'T TOUCH BUTTON
// =====================================================

function DontTouchScreen({ onTouch }: { onTouch: () => void }) {
  return (
    <ScreenTransition screenKey={1}>
      <div className="text-7xl">👁️</div>
      <div className="mt-4" />
      <h2 className="text-white text-3xl sm:text-4xl font-black">SADIYA...</h2>
      <div className="mt-2" />
      <p className="text-[#FF3E91] text-lg font-bold">I'M SERIOUS.</p>
      <div className="mt-8" />
      <button
        onClick={onTouch}
        className="w-52 h-52 rounded-full bg-[#1D071B] border-4 border-[#FF65BC]/30 flex items-center justify-center animate-pulse-button hover:border-[#FF65BC]/60 transition-colors duration-300"
      >
        <span className="text-[#FF65BC] text-2xl sm:text-3xl font-black text-center leading-tight">
          DON'T
          <br />
          TOUCH
        </span>
      </button>
      <div className="mt-7" />
      <p className="text-gray-500 text-xs text-center max-w-xs">
        Touch karogi to jo hoga uski responsibility meri nahi 😈
      </p>
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 2: SCARE SCREEN
// =====================================================

function ScareScreen({ scare }: { scare: boolean }) {
  return (
    <ScreenTransition screenKey={2}>
      <div className={`text-8xl sm:text-9xl transition-transform duration-300 ${scare ? "animate-scare-shake" : ""}`}>
        {scare ? "👁️" : "😈"}
      </div>
      <div className="mt-4" />
      <h2 className="text-white text-3xl font-black tracking-wide">I TOLD YOU...</h2>
      <div className="mt-2" />
      <p className="text-[#FF4FAF] text-xl font-bold">DON'T TOUCH 😭</p>
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 3: INTRO
// =====================================================

function IntroScreen({ onNext }: { onNext: () => void }) {
  return (
    <ScreenTransition screenKey={3}>
      <div className="text-7xl">😌</div>
      <div className="mt-4" />
      <h2 className="text-white text-3xl font-bold">Achha Sadiya...</h2>
      <p className="text-gray-300 text-base mt-2 text-center max-w-xs">
        Ab jab itni door aa hi gayi ho...
      </p>
      <div className="mt-7" />
      <p className="text-[#FF8BD7] text-lg font-bold">Ek chhota sa game kheloge? 👀</p>
      <div className="mt-8" />
      <PinkButton text="CHALO 😈" onClick={onNext} />
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 4: QUESTIONS / VIBE CHECK
// =====================================================

function QuestionScreen({
  questionIndex,
  onAnswer,
}: {
  questionIndex: number;
  onAnswer: (answer: string) => void;
}) {
  const q = questions[questionIndex];

  return (
    <ScreenTransition screenKey={4}>
      <p className="text-[#FF67C3] text-xs font-bold tracking-widest">SADIYA'S VIBE CHECK 💗</p>
      <div className="mt-4" />
      <p className="text-gray-400 text-sm">
        {questionIndex + 1} / {questions.length}
      </p>
      {/* Progress bar */}
      <div className="w-full max-w-xs mt-4 h-1.5 rounded-full bg-white/10 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#FF3EA5] to-[#FF8BD7] transition-all duration-500"
          style={{ width: `${((questionIndex + 1) / questions.length) * 100}%` }}
        />
      </div>
      <div className="mt-6" />
      <h2 className="text-white text-2xl sm:text-3xl font-bold text-center max-w-xs leading-snug">
        {q.text}
      </h2>
      <div className="mt-7" />
      <div className="flex flex-col gap-2.5 items-center w-full">
        {q.answers.map((answer) => (
          <AnswerButton key={answer} text={answer} onClick={() => onAnswer(answer)} />
        ))}
      </div>
      <div className="mt-4" />
      <p className="text-gray-500 text-xs">Koi right ya wrong answer nahi hai 😌</p>
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 5: REACTION
// =====================================================

function ReactionScreen({ onNext }: { onNext: () => void }) {
  return (
    <ScreenTransition screenKey={5}>
      <div className="text-6xl sm:text-7xl">HMMM... 👀</div>
      <div className="mt-4" />
      <h2 className="text-white text-2xl sm:text-3xl font-bold text-center max-w-xs">
        Interesting choices, Sadiya...
      </h2>
      <div className="mt-4" />
      <p className="text-[#FF8BD7] text-base text-center max-w-xs">
        Tumhari choices kaafi cute hain 😌💗
      </p>
      <div className="mt-8" />
      <PinkButton text="AB EK SECRET HAI 🔐" onClick={onNext} />
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 6: SECRET
// =====================================================

function SecretScreen({ onNext }: { onNext: () => void }) {
  return (
    <ScreenTransition screenKey={6}>
      <div className="text-7xl animate-bounce-slow">🔐</div>
      <div className="mt-3" />
      <h2 className="text-white text-3xl font-black tracking-wide">SECRET LEVEL</h2>
      <div className="mt-4" />
      <p className="text-[#FF7CCB] text-lg">Sadiya, ek baat bataun?</p>
      <div className="mt-7" />
      <div className="w-full max-w-xs rounded-3xl bg-white/10 backdrop-blur-sm border border-white/10 p-6">
        <p className="text-white text-base leading-relaxed text-center whitespace-pre-line">
          {"Tumhare liye ye app banana tha...\n\nkyunki simple message bhejna bahut normal hota. 😌\n\nThoda effort toh banta hai ❤️"}
        </p>
      </div>
      <div className="mt-8" />
      <PinkButton text="LAST SURPRISE 🎁" onClick={onNext} />
    </ScreenTransition>
  );
}

// =====================================================
// SCREEN 7: FINAL
// =====================================================

function FinalScreen({ onReplay }: { onReplay: () => void }) {
  return (
    <ScreenTransition screenKey={7}>
      <div className="text-8xl animate-bounce-slow">🎁</div>
      <div className="mt-3" />
      <h1 className="text-[#FF65BE] text-4xl sm:text-5xl font-black tracking-tight">FOR SADIYA</h1>
      <div className="mt-5" />
      <p className="text-white text-lg text-center max-w-xs leading-relaxed">
        Kuch logon ke liye
        <br />
        app banaya nahi jaata...
      </p>
      <div className="mt-3" />
      <p className="text-[#FF9DDA] text-xl font-bold text-center max-w-xs leading-relaxed">
        app banane ka mann ho jaata hai. ❤️
      </p>
      <div className="mt-7" />
      <p className="text-gray-300 text-sm text-center">Bas hamesha aise hi smile karti rehna. ✨</p>
      <div className="mt-9" />
      <PinkButton text="REPLAY 😈" onClick={onReplay} />
    </ScreenTransition>
  );
}

// =====================================================
// MAIN APP
// =====================================================

export default function App() {
  const [page, setPage] = useState(0);
  const [question, setQuestion] = useState(0);
  const [scare, setScare] = useState(false);

  // Scare screen auto-advance
  useEffect(() => {
    if (page === 2) {
      setScare(true);
      const timer = setTimeout(() => {
        setScare(false);
        setPage(3);
      }, 1700);
      return () => clearTimeout(timer);
    }
  }, [page]);

  const handleAnswer = useCallback(
    (_answer: string) => {
      if (question < questions.length - 1) {
        setQuestion((q) => q + 1);
      } else {
        setPage(5);
      }
    },
    [question]
  );

  const handleReplay = useCallback(() => {
    setQuestion(0);
    setPage(0);
  }, []);

  // Floating hearts background
  const hearts = Array.from({ length: 15 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 8,
    duration: 6 + Math.random() * 6,
    size: 12 + Math.random() * 16,
    opacity: 0.08 + Math.random() * 0.12,
  }));

  return (
    <div
      className="min-h-screen w-full overflow-hidden relative"
      style={{
        background: "linear-gradient(180deg, #09030D 0%, #210B29 50%, #09030D 100%)",
      }}
    >
      {/* Floating hearts background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {hearts.map((h) => (
          <span
            key={h.id}
            className="absolute animate-float-up"
            style={{
              left: `${h.left}%`,
              bottom: "-5%",
              fontSize: `${h.size}px`,
              opacity: h.opacity,
              animationDelay: `${h.delay}s`,
              animationDuration: `${h.duration}s`,
            }}
          >
            💗
          </span>
        ))}
      </div>

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center">
        {page === 0 && <StartScreen onStart={() => setPage(1)} />}
        {page === 1 && (
          <DontTouchScreen
            onTouch={() => {
              setScare(true);
              setPage(2);
            }}
          />
        )}
        {page === 2 && <ScareScreen scare={scare} />}
        {page === 3 && <IntroScreen onNext={() => setPage(4)} />}
        {page === 4 && <QuestionScreen questionIndex={question} onAnswer={handleAnswer} />}
        {page === 5 && <ReactionScreen onNext={() => setPage(6)} />}
        {page === 6 && <SecretScreen onNext={() => setPage(7)} />}
        {page === 7 && <FinalScreen onReplay={handleReplay} />}
      </div>
    </div>
  );
}
