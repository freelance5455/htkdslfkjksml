import { useEffect, useRef, useState } from 'react';
import { Play, Pause, RotateCcw, Coins, Gem, Trophy, ShoppingBag, Volume2, VolumeX, Zap } from 'lucide-react';

type Skin = { id:string; name:string; price:number; gems?:boolean; color:string; damage:number; rate:number; description:string };
type MapTheme = { id:string; name:string; price:number; bg:string; grid:string; accent:string };
const skins: Skin[] = [
  {id:'a1_tank',name:'A1 Battle Tank',price:0,color:'#22c55e',damage:1,rate:1,description:'Reliable starter tank.'},
  {id:'bazooka_heavy',name:'Heavy Bazooka RPG',price:15000,color:'#f97316',damage:1.8,rate:1.4,description:'Heavy explosive power.'},
  {id:'energy_bow',name:'Cyber Energy Bow',price:30000,color:'#06b6d4',damage:1.3,rate:.75,description:'Twin kinetic shots.'},
  {id:'finger_gun',name:'Meme Finger Gun',price:50000,color:'#f59e0b',damage:2.2,rate:.6,description:'A legendary meme blaster.'},
  {id:'cyber_tank',name:'Neon Cyber Tank',price:120000,color:'#a855f7',damage:2.5,rate:.7,description:'Twin neon energy coils.'},
  {id:'quantum_blaster',name:'Quantum Ray Cannon',price:250000,color:'#3b82f6',damage:3.2,rate:.5,description:'Triple-beam technology.'},
  {id:'golden_emperor',name:'Golden Emperor Tank',price:200,gems:true,color:'#eab308',damage:4.5,rate:.45,description:'A golden champion tank.'}
];
const maps: MapTheme[] = [
  {id:'blueprint',name:'Teal Blueprint',price:0,bg:'#042f2e',grid:'rgba(20,184,166,.24)',accent:'#14b8a6'},
  {id:'amber_desert',name:'Amber Desert',price:10000,bg:'#451a03',grid:'rgba(245,158,11,.22)',accent:'#f59e0b'},
  {id:'neon_crimson',name:'Crimson Arena',price:25000,bg:'#450a0a',grid:'rgba(239,68,68,.25)',accent:'#ef4444'},
  {id:'emerald_matrix',name:'Emerald Matrix',price:50000,bg:'#022c22',grid:'rgba(16,185,129,.22)',accent:'#10b981'},
  {id:'royal_violet',name:'Royal Violet',price:75000,bg:'#2e1065',grid:'rgba(168,85,247,.25)',accent:'#a855f7'},
  {id:'cosmic_galaxy',name:'Cosmic Galaxy',price:150000,bg:'#030712',grid:'rgba(56,189,248,.25)',accent:'#38bdf8'}
];
type Profile = {name:string;coins:number;gems:number;level:number;best:number;skin:string;map:string;unlockedSkins:string[];unlockedMaps:string[];sound:boolean};
const initial: Profile = {name:'GalaxyCommander',coins:5000,gems:50,level:1,best:0,skin:'a1_tank',map:'blueprint',unlockedSkins:['a1_tank'],unlockedMaps:['blueprint'],sound:true};
const load = ():Profile => { try { return {...initial,...JSON.parse(localStorage.getItem('galaxy-shooter-profile')||'{}')}; } catch { return initial; } };

export default function App() {
  const [profile,setProfile] = useState<Profile>(load);
  const [screen,setScreen] = useState<'home'|'game'|'shop'|'leaderboard'>('home');
  const [playing,setPlaying] = useState(false);
  const [score,setScore] = useState(0);
  const [health,setHealth] = useState(100);
  const [notice,setNotice] = useState('Break the crates. Collect coins. Reach the next level!');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<{boxes:{x:number;y:number;hp:number;value:number}[];bullets:{x:number;y:number}[];last:number;frame:number;raf:number;pointer:number}>({boxes:[],bullets:[],last:0,frame:0,raf:0,pointer:0});
  const skin = skins.find(s=>s.id===profile.skin) || skins[0];
  const map = maps.find(m=>m.id===profile.map) || maps[0];

  useEffect(()=>{localStorage.setItem('galaxy-shooter-profile',JSON.stringify(profile));},[profile]);
  useEffect(()=>{
    if(screen!=='game') return;
    const canvas=canvasRef.current; if(!canvas) return;
    const ctx=canvas.getContext('2d'); if(!ctx) return;
    const g=gameRef.current;
    const resize=()=>{const dpr=Math.min(window.devicePixelRatio||1,2);const w=canvas.clientWidth,h=canvas.clientHeight;canvas.width=w*dpr;canvas.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);};
    resize(); window.addEventListener('resize',resize);
    const spawn=()=>{const w=canvas.clientWidth;g.boxes.push({x:24+Math.random()*(w-80),y:-42,hp:2+Math.floor(profile.level/3),value:10+Math.floor(Math.random()*30)});};
    const loop=(time:number)=>{
      const w=canvas.clientWidth,h=canvas.clientHeight;
      ctx.clearRect(0,0,w,h);ctx.fillStyle=map.bg;ctx.fillRect(0,0,w,h);
      ctx.strokeStyle=map.grid;ctx.lineWidth=1;
      for(let x=0;x<w;x+=32){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
      for(let y=0;y<h;y+=32){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
      if(playing){
        const dt=Math.min((time-g.last)/16||1,2);g.frame+=dt;
        if(g.frame>42){spawn();g.frame=0;}
        if(time-g.last>90) g.bullets.push({x:w/2,y:h-80});
        g.bullets=g.bullets.filter(b=>b.y>-20);
        g.bullets.forEach(b=>{b.y-=9*dt;ctx.fillStyle=skin.color;ctx.shadowColor=skin.color;ctx.shadowBlur=12;ctx.fillRect(b.x-3,b.y-10,6,14);ctx.shadowBlur=0;});
        g.boxes.forEach(box=>{box.y+=.8*dt;ctx.fillStyle='#172b3c';ctx.fillRect(box.x,box.y,42,42);ctx.strokeStyle=map.accent;ctx.lineWidth=2;ctx.strokeRect(box.x,box.y,42,42);ctx.fillStyle='#fff';ctx.font='bold 13px sans-serif';ctx.textAlign='center';ctx.fillText(String(box.hp),box.x+21,box.y+26);});
        for(let i=g.boxes.length-1;i>=0;i--){const b=g.boxes[i];const hit=g.bullets.findIndex(p=>p.x>b.x&&p.x<b.x+42&&p.y>b.y&&p.y<b.y+42);if(hit>=0){g.bullets.splice(hit,1);b.hp-=skin.damage;if(b.hp<=0){g.boxes.splice(i,1);setScore(s=>s+1);setProfile(p=>({...p,coins:p.coins+b.value}));}}else if(b.y>h-112){g.boxes.splice(i,1);setHealth(v=>Math.max(0,v-8));}}
        if(health<=0){setPlaying(false);setNotice('Tank damaged! Restart to try again.');}
      }
      // Tank
      ctx.fillStyle=skin.color;ctx.fillRect(w/2-24,h-78,48,34);ctx.fillRect(w/2-8,h-99,16,28);ctx.fillStyle='#0b1722';ctx.fillRect(w/2-31,h-73,8,27);ctx.fillRect(w/2+23,h-73,8,27);
      ctx.fillStyle='#d9f99d';ctx.fillRect(w/2-5,h-95,10,17);
      g.last=time;g.raf=requestAnimationFrame(loop);
    };
    g.raf=requestAnimationFrame(loop);
    return ()=>{cancelAnimationFrame(g.raf);window.removeEventListener('resize',resize);};
  },[screen,playing,profile.level,skin,map,health]);

  const start=()=>{gameRef.current.boxes=[];gameRef.current.bullets=[];setScore(0);setHealth(100);setNotice('Keep the crates away from your tank!');setScreen('game');setPlaying(true);};
  const buySkin=(s:Skin)=>{if(profile.unlockedSkins.includes(s.id)){setProfile(p=>({...p,skin:s.id}));setNotice(`${s.name} equipped!`);return;}const can=s.gems?profile.gems>=s.price:profile.coins>=s.price;if(!can){setNotice('Not enough currency yet. Play to earn more!');return;}setProfile(p=>({...p,coins:p.coins-(s.gems?0:s.price),gems:p.gems-(s.gems?s.price:0),unlockedSkins:[...p.unlockedSkins,s.id],skin:s.id}));setNotice(`${s.name} unlocked!`);};
  const buyMap=(m:MapTheme)=>{if(profile.unlockedMaps.includes(m.id)){setProfile(p=>({...p,map:m.id}));return;}if(profile.coins<m.price){setNotice('Not enough coins. Keep playing!');return;}setProfile(p=>({...p,coins:p.coins-m.price,unlockedMaps:[...p.unlockedMaps,m.id],map:m.id}));};
  const finish=()=>{setPlaying(false);setProfile(p=>({...p,best:Math.max(p.best,score),level:p.level+1,coins:p.coins+100}));setNotice('Level cleared! +100 bonus coins.');setScreen('home');};
  return <div className="app" style={{'--accent':map.accent} as React.CSSProperties}>
    <header><div className="brand"><div className="logo">✦</div><div><b>GALAXY SHOOTER</b><small>TANK WARS</small></div></div><div className="wallet"><span><Coins size={16}/>{profile.coins.toLocaleString()}</span><span><Gem size={16}/>{profile.gems}</span></div></header>
    <main>
      {screen==='home'&&<section className="hero">
        <div className="eyebrow">✦ ARCADE BATTLE • SEASON 01</div><h1>COMMAND<br/><em>YOUR GALAXY</em></h1><p>Blast through crates, collect rewards and build the ultimate tank.</p>
        <div className="tank-show" style={{'--tank':skin.color} as React.CSSProperties}><div className="tank-barrel"/><div className="tank-body"/><div className="tank-track"/></div>
        <div className="stats"><div><small>CURRENT LEVEL</small><b>{profile.level}</b></div><div><small>BEST SCORE</small><b>{profile.best}</b></div><div><small>EQUIPPED</small><b className="small-stat">{skin.name}</b></div></div>
        <button className="primary" onClick={start}><Play fill="currentColor"/> PLAY NOW</button>
        <div className="nav-grid"><button onClick={()=>setScreen('shop')}><ShoppingBag/> ARMORY</button><button onClick={()=>setScreen('leaderboard')}><Trophy/> LEADERBOARD</button></div>
        <p className="notice">{notice}</p>
      </section>}
      {screen==='game'&&<section className="game-screen">
        <div className="game-top"><button onClick={()=>setPlaying(!playing)}>{playing?<Pause/>:<Play/>}{playing?'PAUSE':'RESUME'}</button><div>LEVEL {profile.level} · SCORE {score}</div><div className="hp">HP {health}%</div></div>
        <canvas ref={canvasRef} className="game-canvas"/>
        <div className="game-bottom"><span>🪙 Coins are added when crates break</span><button onClick={finish}>END RUN</button></div>
      </section>}
      {screen==='shop'&&<section className="shop-screen"><div className="section-head"><div><small>LOADOUT CUSTOMIZATION</small><h2>THE ARMORY</h2></div><button className="back" onClick={()=>setScreen('home')}>← BACK</button></div><h3>WEAPON SKINS</h3><div className="cards">{skins.map(s=><article className={`item ${profile.skin===s.id?'selected':''}`} key={s.id}><div className="weapon-icon" style={{'--tank':s.color} as React.CSSProperties}>▰</div><b>{s.name}</b><p>{s.description}</p><small>DMG ×{s.damage} · RATE ×{s.rate}</small><button onClick={()=>buySkin(s)}>{profile.skin===s.id?'EQUIPPED':profile.unlockedSkins.includes(s.id)?'EQUIP':`${s.price.toLocaleString()} ${s.gems?'GEMS':'COINS'}`}</button></article>)}</div><h3>ARENA MAPS</h3><div className="cards maps">{maps.map(m=><article className={`item map-item ${profile.map===m.id?'selected':''}`} key={m.id}><div className="map-preview" style={{backgroundColor:m.bg,backgroundImage:`linear-gradient(${m.grid} 1px,transparent 1px),linear-gradient(90deg,${m.grid} 1px,transparent 1px)`}}/><b>{m.name}</b><button onClick={()=>buyMap(m)}>{profile.map===m.id?'EQUIPPED':profile.unlockedMaps.includes(m.id)?'EQUIP':`${m.price.toLocaleString()} COINS`}</button></article>)}</div><p className="notice">{notice}</p></section>}
      {screen==='leaderboard'&&<section className="shop-screen"><div className="section-head"><div><small>TOP COMMANDERS</small><h2>LEADERBOARD</h2></div><button className="back" onClick={()=>setScreen('home')}>← BACK</button></div><div className="leader"><span>🥇</span><b>Abhigyan (Creator)</b><strong>LEVEL 1000</strong></div><div className="leader"><span>🥈</span><b>Shivansh (Co-Creator)</b><strong>LEVEL 1000</strong></div><div className="leader"><span>🥉</span><b>{profile.name} (You)</b><strong>LEVEL {profile.level}</strong></div><p className="notice">Local demo leaderboard. Online rankings require a backend service.</p></section>}
    </main>
    <footer><span>GALAXY SHOOTER © 2026</span><button onClick={()=>setProfile(p=>({...p,sound:!p.sound}))}>{profile.sound?<Volume2 size={16}/>:<VolumeX size={16}/>} SOUND</button><button onClick={()=>{localStorage.removeItem('galaxy-shooter-profile');setProfile(initial);setNotice('Progress reset.');}}><RotateCcw size={15}/> RESET</button><span><Zap size={14}/> BUILD YOUR LEGACY</span></footer>
  </div>;
}