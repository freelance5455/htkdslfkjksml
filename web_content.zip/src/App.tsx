import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Play, Pause, Settings, Volume2, VolumeX, RotateCcw, Home, Skull, Crown,
  ChevronLeft, ChevronRight, ArrowBigUp, Crosshair, Zap, Sword, Wind, Layers,
  Bomb, MoveRight, CornerUpRight, Heart, HeartPulse, Shield, ShieldPlus,
  Footprints, Magnet, Snowflake, Bot, Orbit, CircleDot, Wrench, Share2,
  Crosshair as CrosshairIcon, Flame, Trophy, Gamepad2, Sparkles, Activity,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Game } from './game/engine';
import type { Hud, EndStats } from './game/engine';
import { RARITY_COLORS, loadHigh } from './game/data';
import type { ChoiceDef, Rarity, UpgradeDef } from './game/data';
import { spriteURL } from './game/pixel';

/* ------- icon mapping for upgrades ------- */
const ICONS: Record<string, LucideIcon> = {
  dmg: Sword, rof: Zap, pspeed: Wind, shots: Layers, crit: CrosshairIcon,
  critd: Flame, pierce: MoveRight, expl: Bomb, chain: Share2, ricochet: CornerUpRight,
  maxhp: Heart, heal: HeartPulse, speed: Footprints, def: Shield, shield: ShieldPlus,
  regen: Activity, magnet: Magnet, freeze: Snowflake, drone: Bot, orbit: Orbit,
  mines: CircleDot, turret: Wrench,
};
const RARITY_LABEL: Record<Rarity, string> = { common: 'COMMON', rare: 'RARE', epic: 'EPIC', legendary: 'LEGENDARY' };

/* cached sprite data-urls */
const iconCache = new Map<string, string>();
function icon(name: string, scale = 2): string {
  let s = iconCache.get(name);
  if (!s) { s = spriteURL(name, 0, scale); iconCache.set(name, s); }
  return s;
}

interface Settings { music: number; sfx: number; muted: boolean; }
function loadSettings(): Settings {
  try { const s = localStorage.getItem('ms_settings'); if (s) return JSON.parse(s); } catch { /* */ }
  return { music: 0.6, sfx: 0.8, muted: false };
}

type Overlay = 'none' | 'pause' | 'levelup' | 'choice' | 'over' | 'win';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<'menu' | 'game'>('menu');
  const [runId, setRunId] = useState(0);
  const [overlay, setOverlay] = useState<Overlay>('none');
  const [hud, setHud] = useState<Hud | null>(null);
  const [levelUpOpts, setLevelUpOpts] = useState<UpgradeDef[]>([]);
  const [weaponOpts, setWeaponOpts] = useState<ChoiceDef[]>([]);
  const [endStats, setEndStats] = useState<EndStats | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const high = useMemo(() => loadHigh(), [screen, overlay]);
  const isTouch = useMemo(() => typeof window !== 'undefined' && (matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window), []);

  const applySettings = (s: Settings) => {
    setSettings(s);
    try { localStorage.setItem('ms_settings', JSON.stringify(s)); } catch { /* */ }
    gameRef.current?.audio.setVolumes(s.music, s.sfx, s.muted);
  };

  /* spin up the game when entering the game screen */
  useEffect(() => {
    if (screen !== 'game' || !canvasRef.current) return;
    setOverlay('none');
    const g = new Game(canvasRef.current, {
      hud: (h) => setHud(h),
      levelUp: (opts) => { setLevelUpOpts(opts); setOverlay('levelup'); },
      weaponChoice: (opts) => { setWeaponOpts(opts); setOverlay('choice'); },
      pause: (p) => setOverlay(p ? 'pause' : 'none'),
      gameOver: (s) => { setEndStats(s); setOverlay('over'); },
      win: (s) => { setEndStats(s); setOverlay('win'); },
    }, loadSettings());
    gameRef.current = g;
    g.start();
    return () => { g.destroy(); gameRef.current = null; };
  }, [screen, runId]);

  const startGame = () => {
    try { document.fonts?.load('12px "Press Start 2P"'); document.fonts?.load('20px "VT323"'); } catch { /* */ }
    setScreen('game'); setRunId(r => r + 1);
  };
  const quitToMenu = () => { setOverlay('none'); setScreen('menu'); };
  const restart = () => { setOverlay('none'); setRunId(r => r + 1); };
  const clickSfx = () => gameRef.current?.audio.sfx('click');

  const touch = (k: 'left' | 'right' | 'jump' | 'fire' | 'dash') => ({
    onPointerDown: (e: React.PointerEvent) => { e.preventDefault(); gameRef.current?.setTouch(k, true); },
    onPointerUp: () => gameRef.current?.setTouch(k, false),
    onPointerLeave: () => gameRef.current?.setTouch(k, false),
    onPointerCancel: () => gameRef.current?.setTouch(k, false),
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
  });

  /* =================== MENU =================== */
  if (screen === 'menu') {
    return (
      <div className="screen-bg">
        <Stars />
        <div className="relative z-10 flex min-h-dvh flex-col items-center justify-center gap-6 px-4 py-8">
          {/* floating meme friends */}
          <img src={icon('potato', 3)} alt="" className="floaty pointer-events-none absolute left-[8%] top-[16%] w-16 sm:w-24" />
          <img src={icon('chicken', 3)} alt="" className="floaty2 pointer-events-none absolute right-[10%] top-[14%] w-14 sm:w-20" />
          <img src={icon('derpycat', 3)} alt="" className="floaty pointer-events-none absolute left-[16%] bottom-[18%] w-16 sm:w-24" style={{ animationDelay: '-1.2s' }} />
          <img src={icon('toilet', 3)} alt="" className="floaty2 pointer-events-none absolute right-[14%] bottom-[22%] w-14 sm:w-20" style={{ animationDelay: '-0.6s' }} />

          <div className="text-center">
            <div className="pix-font text-[10px] tracking-widest text-[#4dd0e1] sm:text-xs">A TOTALLY SERIOUS SURVIVAL RPG</div>
            <h1 className="pix-font title-glow mt-4 text-4xl leading-tight text-[#ffd23f] sm:text-6xl">
              MEME
            </h1>
            <h1 className="pix-font title-glow2 mt-2 bg-gradient-to-b from-[#7dff6a] to-[#2ca84f] bg-clip-text text-3xl text-transparent sm:text-5xl">
              SURVIVORS
            </h1>
          </div>

          <img src={icon('hero', 4)} alt="hero" className="floaty w-20 sm:w-28" />

          {high && (
            <div className="pix-panel flex items-center gap-3 px-4 py-2">
              <Trophy size={16} className="text-[#ffd23f]" />
              <span className="pix-font text-[9px] text-[#9fb2c8] sm:text-[10px]">
                BEST: STAGE {high.stage} · WAVE {high.wave} · {high.kills} KILLS
              </span>
            </div>
          )}

          <div className="flex flex-col items-center gap-3 sm:flex-row">
            <button className="pix-btn pix-btn-green" onClick={() => { startGame(); }}>
              <Play size={16} /> START MISSION
            </button>
            <button className="pix-btn" onClick={() => setShowSettings(true)}>
              <Settings size={16} /> SETTINGS
            </button>
          </div>

          <div className="pix-panel pix-body max-w-md px-5 py-3 text-center text-lg leading-tight text-[#9fb2c8]">
            <span className="text-[#4dd0e1]">A / D</span> move · <span className="text-[#4dd0e1]">SPACE</span> jump ·{' '}
            <span className="text-[#4dd0e1]">CLICK / J</span> shoot · <span className="text-[#4dd0e1]">E</span> dash ·{' '}
            <span className="text-[#4dd0e1]">ESC</span> pause
            <div className="mt-1 text-[#6b7a99]">Survive 10 waves per stage. Absorb the XP. Become the meme.</div>
          </div>
        </div>
        {showSettings && <SettingsModal settings={settings} onChange={applySettings} onClose={() => setShowSettings(false)} />}
      </div>
    );
  }

  /* =================== GAME =================== */
  return (
    <div className="screen-bg">
      <div className="relative z-10 flex min-h-dvh items-center justify-center p-2">
        <div className="relative" style={{ width: 'min(100%, calc((100dvh - 8px) * 16 / 9))' }}>
          <canvas
            ref={canvasRef}
            width={960}
            height={540}
            className="pix-canvas block aspect-[16/9] w-full rounded-md"
            onContextMenu={(e) => e.preventDefault()}
          />
          <div className="scanlines pointer-events-none absolute inset-0 rounded-md" />

          {/* ---------- HUD ---------- */}
          {hud && (
            <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3">
              <div className="flex items-start justify-between gap-2">
                {/* HP + shield + dash */}
                <div className="flex flex-col gap-1.5">
                  <div className="pix-bar w-44 sm:w-56">
                    <div className="pix-bar-fill bg-[#ff4d6d]" style={{ width: `${(hud.hp / hud.maxHp) * 100}%` }} />
                    <span className="pix-bar-label">{hud.hp}/{hud.maxHp}</span>
                  </div>
                  {hud.shieldMax > 0 && (
                    <div className="pix-bar h-2.5 w-36 sm:w-44">
                      <div className="pix-bar-fill bg-[#4dd0e1]" style={{ width: `${(hud.shield / hud.shieldMax) * 100}%` }} />
                    </div>
                  )}
                  <div className={`pix-chip w-fit ${hud.dashReady ? 'text-[#9df2ff]' : 'text-[#4a5578]'}`}>
                    <Zap size={11} /> DASH
                  </div>
                </div>
                {/* stage + wave + kills / boss bar */}
                <div className="flex flex-col items-center gap-1.5">
                  <div className="pix-chip">{hud.stageName}</div>
                  <div className="pix-chip text-[#ffd23f]">WAVE {hud.wave}/10 · {hud.kills} KILLS</div>
                  {hud.boss && (
                    <div className="mt-1 w-56 sm:w-80">
                      <div className="pix-font mb-1 text-center text-[9px] text-[#ff5d5d] sm:text-[10px]">{hud.boss.name}</div>
                      <div className="pix-bar h-3.5">
                        <div className="pix-bar-fill bg-[#ff3b3b]" style={{ width: `${Math.max(0, (hud.boss.hp / hud.boss.max) * 100)}%` }} />
                      </div>
                    </div>
                  )}
                </div>
                {/* weapon + buttons */}
                <div className="pointer-events-auto flex items-center gap-2">
                  <div className="pix-panel flex items-center gap-2 px-2 py-1.5">
                    <img src={icon('gun_' + hud.weaponId, 2)} alt="" className="h-6" style={{ imageRendering: 'pixelated' }} />
                    <span className="pix-font text-[8px] text-[#ffd23f]">Lv{hud.weaponLv}</span>
                  </div>
                  <button className="pix-iconbtn" onClick={() => { applySettings({ ...settings, muted: !settings.muted }); clickSfx(); }}>
                    {settings.muted ? <VolumeX size={15} /> : <Volume2 size={15} />}
                  </button>
                  <button className="pix-iconbtn" onClick={() => { gameRef.current?.togglePause(); }}>
                    <Pause size={15} />
                  </button>
                </div>
              </div>
              {/* XP bar */}
              <div className="flex items-center gap-2">
                <div className="pix-chip shrink-0 text-[#7dff6a]">LV {hud.level}</div>
                <div className="pix-bar h-4 flex-1">
                  <div className="pix-bar-fill bg-[#7dff6a] transition-all duration-150" style={{ width: `${Math.min(100, (hud.xp / hud.xpNeed) * 100)}%` }} />
                  <span className="pix-bar-label">{hud.xp}/{hud.xpNeed} XP</span>
                </div>
              </div>
            </div>
          )}

          {/* desktop hints */}
          {!isTouch && overlay === 'none' && (
            <div className="pix-body pointer-events-none absolute bottom-8 right-3 text-right text-base text-[#9fb2c866]">
              A/D move · SPACE jump · CLICK shoot · E dash
            </div>
          )}

          {/* ---------- touch controls ---------- */}
          {isTouch && (overlay === 'none' || overlay === 'pause') && (
            <>
              <div className="absolute bottom-16 left-3 flex gap-3">
                <button className="touch-btn" {...touch('left')}><ChevronLeft size={30} /></button>
                <button className="touch-btn" {...touch('right')}><ChevronRight size={30} /></button>
              </div>
              <div className="absolute bottom-16 right-3 flex items-end gap-3">
                <button className="touch-btn small" {...touch('dash')}><Zap size={22} /></button>
                <button className="touch-btn" {...touch('jump')}><ArrowBigUp size={30} /></button>
                <button className="touch-btn fire" {...touch('fire')}><Crosshair size={30} /></button>
              </div>
            </>
          )}

          {/* ---------- overlays ---------- */}
          {overlay === 'pause' && (
            <Modal>
              <h2 className="pix-font text-lg text-[#ffd23f]">PAUSED</h2>
              <div className="flex flex-col gap-2.5">
                <button className="pix-btn pix-btn-green" onClick={() => { clickSfx(); gameRef.current?.togglePause(); }}><Play size={15} /> RESUME</button>
                <button className="pix-btn" onClick={() => { clickSfx(); setShowSettings(true); }}><Settings size={15} /> SETTINGS</button>
                <button className="pix-btn" onClick={() => { clickSfx(); restart(); }}><RotateCcw size={15} /> RESTART RUN</button>
                <button className="pix-btn pix-btn-red" onClick={() => { clickSfx(); quitToMenu(); }}><Home size={15} /> MAIN MENU</button>
              </div>
            </Modal>
          )}

          {overlay === 'levelup' && (
            <Modal>
              <div className="flex items-center justify-center gap-2">
                <Sparkles size={18} className="text-[#ffd23f]" />
                <h2 className="pix-font text-base text-[#7dff6a] sm:text-lg">LEVEL UP!</h2>
                <Sparkles size={18} className="text-[#ffd23f]" />
              </div>
              <div className="pix-body text-lg text-[#9fb2c8]">Choose one upgrade</div>
              <div className="flex flex-col gap-3 sm:flex-row">
                {levelUpOpts.map((u) => {
                  const Icon = ICONS[u.icon] || Sword;
                  const col = RARITY_COLORS[u.rarity];
                  return (
                    <button
                      key={u.id}
                      className="up-card"
                      style={{ borderColor: col, boxShadow: `0 0 18px ${col}44, inset 0 0 12px ${col}22` }}
                      onClick={() => {
                        const g = gameRef.current; if (!g) return;
                        g.chooseUpgrade(u.id);
                        if (g.modal === 'none') setOverlay('none');
                      }}
                    >
                      <span className="pix-font text-[8px]" style={{ color: col }}>{RARITY_LABEL[u.rarity]}</span>
                      <Icon size={34} style={{ color: col }} />
                      <span className="pix-font text-[10px] text-white">{u.name}</span>
                      <span className="pix-body text-lg leading-tight text-[#9fb2c8]">{u.desc}</span>
                    </button>
                  );
                })}
              </div>
            </Modal>
          )}

          {overlay === 'choice' && (
            <Modal>
              <div className="flex items-center justify-center gap-2">
                <Crown size={18} className="text-[#ffd23f]" />
                <h2 className="pix-font text-base text-[#ffd23f] sm:text-lg">BOSS LOOT!</h2>
                <Crown size={18} className="text-[#ffd23f]" />
              </div>
              <div className="pix-body text-lg text-[#9fb2c8]">Pick your reward for the next stage</div>
              <div className="flex flex-col gap-3 sm:flex-row">
                {weaponOpts.map((c) => {
                  const col = RARITY_COLORS[c.rarity];
                  return (
                    <button
                      key={c.id}
                      className="up-card"
                      style={{ borderColor: col, boxShadow: `0 0 18px ${col}44, inset 0 0 12px ${col}22` }}
                      onClick={() => {
                        const g = gameRef.current; if (!g) return;
                        g.chooseWeapon(c.id);
                        if (g.modal === 'none') setOverlay('none');
                      }}
                    >
                      <span className="pix-font text-[8px]" style={{ color: col }}>{RARITY_LABEL[c.rarity]}</span>
                      {c.weaponId
                        ? <img src={icon('gun_' + c.weaponId, 2)} alt="" className="h-9" style={{ imageRendering: 'pixelated' }} />
                        : <HeartPulse size={34} style={{ color: col }} />}
                      <span className="pix-font text-[10px] text-white">{c.name}</span>
                      <span className="pix-body text-lg leading-tight text-[#9fb2c8]">{c.desc}</span>
                    </button>
                  );
                })}
              </div>
            </Modal>
          )}

          {(overlay === 'over' || overlay === 'win') && endStats && (
            <Modal>
              {overlay === 'win' ? (
                <>
                  <Crown size={40} className="mx-auto text-[#ffd23f]" />
                  <h2 className="pix-font text-lg text-[#ffd23f] sm:text-xl">MEMEVERSE SAVED!</h2>
                  <p className="pix-body text-xl text-[#7dff6a]">You defeated every boss. The memes rest in peace... for now.</p>
                </>
              ) : (
                <>
                  <Skull size={40} className="mx-auto text-[#ff5d5d]" />
                  <h2 className="pix-font text-lg text-[#ff5d5d] sm:text-xl">YOU GOT MEMED</h2>
                </>
              )}
              <div className="pix-panel grid grid-cols-2 gap-x-8 gap-y-2 px-6 py-3">
                <Stat k="STAGE" v={String(endStats.stage)} />
                <Stat k="WAVE" v={String(endStats.wave)} />
                <Stat k="KILLS" v={String(endStats.kills)} />
                <Stat k="LEVEL" v={String(endStats.level)} />
                <Stat k="SCORE" v={String(endStats.score)} />
                <Stat k="TIME" v={`${Math.floor(endStats.time / 60)}:${String(Math.floor(endStats.time % 60)).padStart(2, '0')}`} />
              </div>
              <div className="flex gap-3">
                <button className="pix-btn pix-btn-green" onClick={() => { clickSfx(); restart(); }}><RotateCcw size={15} /> RUN IT BACK</button>
                <button className="pix-btn" onClick={() => { clickSfx(); quitToMenu(); }}><Home size={15} /> MENU</button>
              </div>
            </Modal>
          )}

          {showSettings && (
            <SettingsModal settings={settings} onChange={applySettings} onClose={() => setShowSettings(false)} />
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="pix-font text-[9px] text-[#9fb2c8]">{k}</span>
      <span className="pix-font text-[10px] text-white">{v}</span>
    </div>
  );
}

function Modal({ children }: { children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center rounded-md bg-[#0a0d1fd9] p-3 backdrop-blur-[2px]">
      <div className="pix-panel modal-pop flex max-h-full flex-col items-center gap-3 overflow-y-auto px-5 py-4 sm:px-8 sm:py-5">
        {children}
      </div>
    </div>
  );
}

function SettingsModal({ settings, onChange, onClose }: { settings: Settings; onChange: (s: Settings) => void; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0a0d1fd9] p-4" onClick={onClose}>
      <div className="pix-panel flex w-full max-w-xs flex-col gap-4 px-6 py-5" onClick={(e) => e.stopPropagation()}>
        <h2 className="pix-font text-center text-sm text-[#4dd0e1]">SETTINGS</h2>
        <label className="pix-body text-xl text-[#9fb2c8]">
          MUSIC
          <input type="range" min={0} max={1} step={0.05} value={settings.music}
            className="mt-1 w-full accent-[#4dd0e1]"
            onChange={(e) => onChange({ ...settings, music: parseFloat(e.target.value) })} />
        </label>
        <label className="pix-body text-xl text-[#9fb2c8]">
          SOUND FX
          <input type="range" min={0} max={1} step={0.05} value={settings.sfx}
            className="mt-1 w-full accent-[#7dff6a]"
            onChange={(e) => onChange({ ...settings, sfx: parseFloat(e.target.value) })} />
        </label>
        <button className="pix-btn" onClick={() => onChange({ ...settings, muted: !settings.muted })}>
          {settings.muted ? <VolumeX size={15} /> : <Volume2 size={15} />} {settings.muted ? 'UNMUTE' : 'MUTE ALL'}
        </button>
        <button className="pix-btn pix-btn-green" onClick={onClose}><Gamepad2 size={15} /> DONE</button>
      </div>
    </div>
  );
}

/* twinkling CSS stars for menu */
function Stars() {
  const stars = useMemo(() => Array.from({ length: 60 }, (_, i) => ({
    id: i, x: Math.random() * 100, y: Math.random() * 100,
    s: Math.random() * 2 + 1, d: Math.random() * 3,
  })), []);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {stars.map((s) => (
        <div key={s.id} className="star" style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s * 2, height: s.s * 2, animationDelay: `${s.d}s` }} />
      ))}
    </div>
  );
}
