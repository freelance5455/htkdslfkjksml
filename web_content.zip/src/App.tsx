import React, { Component, ErrorInfo, ReactNode, useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import {
  ArrowLeft,
  Bell,
  Bookmark,
  BookOpen,
  Download,
  Home,
  LogOut,
  ShieldAlert,
  ShieldCheck,
  User as UserIcon,
} from 'lucide-react';
import { AdminPanel } from './components/AdminPanel';
import { AnimatedLessonPlayer } from './components/AnimatedLessonPlayer';
import { AuthScreen } from './components/AuthScreen';
import { ClassChangeReportModal } from './components/ClassChangeReportModal';
import { DashboardHome } from './components/DashboardHome';
import {
  AnnouncementsView,
  DownloadsView,
  ProfileView,
  SavedNotesView,
} from './components/LibraryViews';
import { Logo } from './components/Logo';
import { NoteReaderModal } from './components/NoteReaderModal';
import { ClassSelectionScreen, LanguageSelectionScreen } from './components/OnboardingScreens';
import { QuizPlayerModal } from './components/QuizPlayerModal';
import { SplashScreen } from './components/SplashScreen';
import { SubjectDetailView } from './components/SubjectDetailView';
import { SubjectsGridView } from './components/SubjectsGridView';
import {
  findBuiltInNoteById,
  findBuiltInVideoById,
  getSubjectById,
} from './data/curriculum';
import { auth, authPersistenceReady, db, testFirestoreConnection } from './lib/firebase';
import {
  createAnnouncement,
  createCustomLesson,
  createCustomSubject,
  createQuiz,
  deleteAnnouncement,
  deleteCustomLesson,
  deleteCustomSubject,
  deleteQuiz,
  ensureStudentProfile,
  lockInitialStudentClass,
  recordNoteDownload,
  recordRecentNote,
  removeDownloadRecord,
  removeSavedNote,
  reviewClassChangeReport,
  saveNoteBookmark,
  saveQuizAttempt,
  submitClassChangeReport,
  subscribeAllClassReportsAdmin,
  subscribeAllQuizAttemptsAdmin,
  subscribeAllStudentsAdmin,
  subscribeAnnouncements,
  subscribeCustomLessons,
  subscribeCustomSubjects,
  subscribeDownloads,
  subscribeQuizzes,
  subscribeRecentNotes,
  subscribeSavedNotes,
  subscribeStudentClassReports,
  subscribeStudentProfile,
  subscribeStudentQuizAttempts,
  subscribeVideoHistory,
  toggleCompletedNote,
  toggleCompletedVideo,
  updateStudentDisplayName,
  updateStudentLanguage,
  upsertVideoProgress,
  verifyServerAdminRole,
} from './services/firestoreService';
import {
  Announcement,
  AppScreen,
  ChapterNote,
  ChapterVideo,
  ClassChangeReport,
  ClassLevel,
  CustomLesson,
  CustomSubject,
  LanguageCode,
  NoteDownloadRecord,
  Quiz,
  QuizAttempt,
  RecentNoteRecord,
  SavedNoteRecord,
  StudentPrivateContact,
  StudentProfile,
  Subject,
  VideoHistoryRecord,
} from './types/edutoon';
import { resolveWorkspaceAccess } from './utils/authHelpers';
import { generateChapterPdf } from './utils/pdfGenerator';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

class ErrorBoundary extends Component<{ children: ReactNode }, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Application boundary caught error:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F6F8FC] flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white rounded-3xl border border-slate-200 p-6 text-center space-y-4">
            <Logo size="md" className="mx-auto" />
            <h1 className="font-display text-xl font-bold text-slate-900">
              Something went wrong
            </h1>
            <p className="text-sm text-slate-600 break-words">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="min-h-[44px] px-5 rounded-xl bg-sky-600 text-white text-sm font-semibold cursor-pointer"
            >
              Reload EduToon Education
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function detectAdminEntryFromUrl(): 'student' | 'admin' {
  if (typeof window === 'undefined') return 'student';
  const hash = window.location.hash.toLowerCase();
  const path = window.location.pathname.toLowerCase();
  if (hash === '#admin' || hash.startsWith('#/admin') || path === '/admin' || path.startsWith('/admin/')) {
    return 'admin';
  }
  return 'student';
}

function EduToonAppShell() {
  const [showSplash, setShowSplash] = useState(true);
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [adminCheckStatus, setAdminCheckStatus] = useState<
    'idle' | 'checking' | 'authorized' | 'denied'
  >('idle');
  const [entryIntent, setEntryIntent] = useState<'student' | 'admin'>(() =>
    detectAdminEntryFromUrl()
  );
  const [adminWorkspacePreference, setAdminWorkspacePreference] = useState<'admin' | 'student'>(
    'admin'
  );

  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [privateContact, setPrivateContact] = useState<StudentPrivateContact | null>(null);
  const [savedNotes, setSavedNotes] = useState<SavedNoteRecord[]>([]);
  const [downloads, setDownloads] = useState<NoteDownloadRecord[]>([]);
  const [recentNotes, setRecentNotes] = useState<RecentNoteRecord[]>([]);
  const [videoHistory, setVideoHistory] = useState<VideoHistoryRecord[]>([]);
  const [studentReports, setStudentReports] = useState<ClassChangeReport[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [customLessons, setCustomLessons] = useState<CustomLesson[]>([]);
  const [customSubjects, setCustomSubjects] = useState<CustomSubject[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [studentQuizAttempts, setStudentQuizAttempts] = useState<QuizAttempt[]>([]);

  // Admin datasets (populated ONLY when server-verified Admin is authenticated)
  const [adminReports, setAdminReports] = useState<ClassChangeReport[]>([]);
  const [adminStudents, setAdminStudents] = useState<StudentProfile[]>([]);
  const [adminQuizAttempts, setAdminQuizAttempts] = useState<QuizAttempt[]>([]);

  // Student Navigation & modals
  const [screen, setScreen] = useState<AppScreen>('home');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('math');
  const [activeNote, setActiveNote] = useState<ChapterNote | null>(null);
  const [activeVideo, setActiveVideo] = useState<ChapterVideo | null>(null);
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [showClassChangeModal, setShowClassChangeModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3200);
  }, []);

  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // Auth listener + automatic server-side role verification after Google Sign-In
  useEffect(() => {
    let unsub: (() => void) | undefined;
    let active = true;

    authPersistenceReady.finally(() => {
      if (!active) return;
      unsub = onAuthStateChanged(auth, async (fbUser) => {
        setUser(fbUser);
        if (fbUser) {
          setAdminCheckStatus('checking');
          try {
            const verifiedAdmin = await verifyServerAdminRole(fbUser);
            if (!active) return;
            setAdminCheckStatus(verifiedAdmin ? 'authorized' : 'denied');
          } catch {
            if (!active) return;
            setAdminCheckStatus('denied');
          }
        } else {
          setAdminCheckStatus('idle');
          setProfile(null);
          setPrivateContact(null);
          setSavedNotes([]);
          setDownloads([]);
          setRecentNotes([]);
          setVideoHistory([]);
          setStudentReports([]);
          setAnnouncements([]);
          setCustomLessons([]);
          setCustomSubjects([]);
          setQuizzes([]);
          setStudentQuizAttempts([]);
          setAdminReports([]);
          setAdminStudents([]);
          setAdminQuizAttempts([]);
        }
        if (active) setAuthReady(true);
      });
    });

    return () => {
      active = false;
      if (unsub) unsub();
    };
  }, []);

  const destination = resolveWorkspaceAccess({
    isAuthenticated: Boolean(user),
    adminCheckStatus,
    entryIntent,
    adminWorkspacePreference,
  });
  const isVerifiedStudentSession =
    destination === 'student-dashboard-only' ||
    destination === 'student-dashboard-with-admin-nav';
  const isVerifiedAdminSession = destination === 'admin-dashboard';
  const canNavigateToAdmin = destination === 'student-dashboard-with-admin-nav';

  // Initialize Student Profile ONLY after role check confirms Student (never for Admin)
  useEffect(() => {
    if (!authReady || !user || !isVerifiedStudentSession) return;
    let active = true;

    (async () => {
      try {
        await ensureStudentProfile(user);
        const contactSnap = await getDoc(doc(db, 'users', user.uid, 'private', 'contact'));
        if (active && contactSnap.exists()) {
          setPrivateContact(contactSnap.data() as StudentPrivateContact);
        }
      } catch (err) {
        console.error('Error initializing student profile:', err);
      }
    })();

    return () => {
      active = false;
    };
  }, [authReady, user, isVerifiedStudentSession]);

  // Subscribe to student-owned collections ONLY when confirmed Student
  useEffect(() => {
    if (!authReady || !user || !isVerifiedStudentSession) return;

    const unsubs = [
      subscribeStudentProfile(user.uid, setProfile),
      subscribeSavedNotes(user.uid, setSavedNotes),
      subscribeDownloads(user.uid, setDownloads),
      subscribeRecentNotes(user.uid, setRecentNotes),
      subscribeVideoHistory(user.uid, setVideoHistory),
      subscribeStudentClassReports(user.uid, setStudentReports),
      subscribeStudentQuizAttempts(user.uid, setStudentQuizAttempts),
    ];

    return () => {
      unsubs.forEach((u) => u());
    };
  }, [authReady, user, isVerifiedStudentSession]);

  // Subscribe to class-scoped announcements, lessons, subjects & quizzes for Students
  useEffect(() => {
    if (!authReady || !user || !isVerifiedStudentSession || !profile) return;

    const unsubAnn = subscribeAnnouncements(profile.selectedClass, false, setAnnouncements);
    const unsubLessons = subscribeCustomLessons(profile.selectedClass, false, setCustomLessons);
    const unsubSubjects = subscribeCustomSubjects(profile.selectedClass, false, setCustomSubjects);
    const unsubQuizzes = subscribeQuizzes(profile.selectedClass, false, setQuizzes);

    return () => {
      unsubAnn();
      unsubLessons();
      unsubSubjects();
      unsubQuizzes();
    };
  }, [authReady, user, isVerifiedStudentSession, profile?.selectedClass]);

  // Admin subscriptions: ONLY active when server-verified Admin role is confirmed
  useEffect(() => {
    if (!authReady || !user || !isVerifiedAdminSession) {
      setAdminReports([]);
      setAdminStudents([]);
      setAdminQuizAttempts([]);
      return;
    }
    const unsubReports = subscribeAllClassReportsAdmin(setAdminReports);
    const unsubStudents = subscribeAllStudentsAdmin(setAdminStudents);
    const unsubAttempts = subscribeAllQuizAttemptsAdmin(setAdminQuizAttempts);
    const unsubAnn = subscribeAnnouncements(0, true, setAnnouncements);
    const unsubLessons = subscribeCustomLessons(0, true, setCustomLessons);
    const unsubSubjects = subscribeCustomSubjects(0, true, setCustomSubjects);
    const unsubQuizzes = subscribeQuizzes(0, true, setQuizzes);
    return () => {
      unsubReports();
      unsubStudents();
      unsubAttempts();
      unsubAnn();
      unsubLessons();
      unsubSubjects();
      unsubQuizzes();
    };
  }, [authReady, user, isVerifiedAdminSession]);

  const resolveNoteById = useCallback(
    (noteId: string, classLevel: number, subjectId: string, lang: LanguageCode): ChapterNote | undefined => {
      if (noteId.startsWith('custom_')) {
        const rawId = noteId.replace(/^custom_/, '');
        const custom = customLessons.find((l) => l.id === rawId && l.type === 'note');
        if (custom) {
          return {
            id: `custom_${custom.id}`,
            subjectId: custom.subjectId,
            classLevel: custom.classLevel,
            language: custom.language,
            chapterNumber: custom.chapterNumber,
            title: custom.title,
            summary: custom.summary,
            readTimeMinutes: 5,
            sections: [{ heading: 'Study Material', body: custom.content }],
            practiceQuestion: {
              question: 'Summarize the key points from this lesson.',
              answer: custom.summary,
            },
            isCustom: true,
            mediaUrl: custom.mediaUrl || undefined,
          };
        }
      }
      return (
        findBuiltInNoteById(noteId) || {
          id: noteId,
          subjectId,
          classLevel: (classLevel || 1) as ClassLevel,
          language: lang,
          chapterNumber: 1,
          title: 'Chapter Study Note',
          summary: 'EduToon Education chapter revision guide.',
          readTimeMinutes: 4,
          sections: [{ heading: 'Overview', body: 'Open the subject page for full chapter details.' }],
          practiceQuestion: { question: 'Review key concepts.', answer: 'Completed.' },
        }
      );
    },
    [customLessons]
  );

  const resolveVideoById = useCallback(
    (videoId: string): ChapterVideo | undefined => {
      if (videoId.startsWith('custom_')) {
        const rawId = videoId.replace(/^custom_/, '');
        const custom = customLessons.find((l) => l.id === rawId && l.type === 'video');
        if (custom) {
          return {
            id: `custom_${custom.id}`,
            subjectId: custom.subjectId,
            classLevel: custom.classLevel,
            language: custom.language,
            chapterNumber: custom.chapterNumber,
            title: custom.title,
            summary: custom.summary,
            durationLabel: custom.durationLabel || '5:00 min',
            durationSec: 45,
            mediaUrl: custom.mediaUrl || undefined,
            isCustom: true,
            scenes: [
              {
                id: 'custom-1',
                title: custom.title,
                caption: custom.content,
                visualKind: 'grammar',
                highlightValue: `Ch ${custom.chapterNumber}`,
                durationSec: 45,
              },
            ],
          };
        }
      }
      return findBuiltInVideoById(videoId);
    },
    [customLessons]
  );

  const resolveSubjectByIdForClass = useCallback(
    (cls: ClassLevel, subjectId: string): Subject | undefined => {
      const builtIn = getSubjectById(cls, subjectId);
      if (builtIn) return builtIn;
      const custom = customSubjects.find(
        (cs) => cs.slug === subjectId && cs.minClass <= cls && cs.maxClass >= cls
      );
      if (custom) {
        return {
          id: custom.slug,
          classLevel: cls,
          titleEn: custom.titleEn,
          titleHi: custom.titleHi,
          descriptionEn: custom.descriptionEn,
          descriptionHi: custom.descriptionHi,
          accentHex: custom.accentHex,
          iconKey: custom.iconKey,
        };
      }
      return undefined;
    },
    [customSubjects]
  );

  const handleOpenNote = async (note: ChapterNote) => {
    setActiveNote(note);
    if (user) {
      await recordRecentNote(user.uid, note);
    }
  };

  const handleDownloadNote = async (note: ChapterNote) => {
    const subject = resolveSubjectByIdForClass(note.classLevel, note.subjectId);
    const subjectTitle =
      note.language === 'hi'
        ? subject?.titleHi || note.subjectId
        : subject?.titleEn || note.subjectId;
    const fileName = await generateChapterPdf(note, subjectTitle);
    if (user) {
      await recordNoteDownload(user.uid, note, fileName);
    }
    showToast(`Downloaded ${fileName}`);
  };

  const handleToggleSaveNote = async (note: ChapterNote) => {
    if (!user) return;
    const isSaved = savedNotes.some((s) => s.noteId === note.id);
    if (isSaved) {
      await removeSavedNote(user.uid, note.id);
      showToast('Removed from Saved Notes');
    } else {
      await saveNoteBookmark(user.uid, note);
      showToast('Saved to your Bookmarks');
    }
  };

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#070E24] flex flex-col items-center justify-center text-white gap-4">
        <Logo size="lg" glow />
        <p className="text-sm text-sky-200 font-medium">Loading EduToon Education...</p>
      </div>
    );
  }

  // 1. Single Google Login Screen with Separate Admin Panel Entry
  if (!user || destination === 'require-auth') {
    return (
      <AuthScreen
        onAuthenticated={() => {}}
        onSelectEntryIntent={(intent) => {
          setEntryIntent(intent);
          if (intent === 'admin') {
            setAdminWorkspacePreference('admin');
          }
        }}
      />
    );
  }

  // 2. Role Verification Transition
  if (destination === 'checking-role') {
    return (
      <div className="min-h-screen bg-[#070E24] flex flex-col items-center justify-center text-white gap-4">
        <Logo size="lg" glow />
        <p className="text-sm text-sky-200 font-medium">
          Verifying account access...
        </p>
      </div>
    );
  }

  // 3. Unauthorized Admin Panel Attempt Guard
  if (destination === 'deny-admin-entry') {
    return (
      <div className="min-h-screen bg-[#060C1D] text-white flex items-center justify-center px-4 py-8">
        <div className="max-w-md w-full rounded-3xl bg-[#0D1633] border border-red-500/40 p-6 sm:p-8 text-center space-y-5 shadow-[0_24px_60px_rgba(2,6,23,0.7)]">
          <Logo size="lg" glow className="mx-auto" />
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-red-300 uppercase tracking-wider">
            <ShieldAlert className="h-4 w-4" />
            <span>Admin Access Required</span>
          </div>
          <h1 className="font-display text-2xl font-bold text-white">
            Not Authorized for Admin Panel
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Your Google account ({user.email || 'Student Account'}) does not have server-verified
            Administrator privileges. Student accounts only have access to the Student Dashboard.
          </p>
          <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-700 text-[11px] font-mono-num text-slate-300 break-all">
            Signed-in UID: {user.uid}
          </div>
          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              onClick={() => {
                setEntryIntent('student');
                if (typeof window !== 'undefined' && window.location.hash.toLowerCase().includes('admin')) {
                  window.location.hash = '';
                }
              }}
              className="w-full min-h-[46px] px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Open Student Dashboard</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                await signOut(auth);
                setAdminCheckStatus('idle');
                setEntryIntent('student');
                if (typeof window !== 'undefined' && window.location.hash.toLowerCase().includes('admin')) {
                  window.location.hash = '';
                }
              }}
              className="w-full min-h-[44px] px-4 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 4. Separate Verified Admin Dashboard (ONLY shown to server-authorized Admin accounts)
  if (destination === 'admin-dashboard') {
    return (
      <>
        <AdminPanel
          adminUid={user.uid}
          adminEmail={user.email || user.phoneNumber || 'Verified Administrator'}
          reports={adminReports}
          announcements={announcements}
          customLessons={customLessons}
          customSubjects={customSubjects}
          quizzes={quizzes}
          quizAttempts={adminQuizAttempts}
          students={adminStudents}
          onReviewReport={async (report, decision, adminNote) => {
            await reviewClassChangeReport({
              report,
              decision,
              adminNote,
              reviewerUid: user.uid,
            });
            showToast(`Report ${decision}`);
          }}
          onCreateAnnouncement={async (params) => {
            await createAnnouncement({
              ...params,
              authorId: user.uid,
              authorName: user.displayName || 'EduToon Admin',
            });
            showToast('Announcement published');
          }}
          onDeleteAnnouncement={async (id) => {
            await deleteAnnouncement(id);
            showToast('Announcement deleted');
          }}
          onCreateCustomLesson={async (params) => {
            await createCustomLesson({
              ...params,
              authorId: user.uid,
            });
            showToast('Study material published');
          }}
          onDeleteCustomLesson={async (id) => {
            await deleteCustomLesson(id);
            showToast('Lesson removed');
          }}
          onCreateCustomSubject={async (params) => {
            await createCustomSubject({
              ...params,
              authorId: user.uid,
            });
            showToast('Custom subject created');
          }}
          onDeleteCustomSubject={async (id) => {
            await deleteCustomSubject(id);
            showToast('Custom subject removed');
          }}
          onCreateQuiz={async (params) => {
            await createQuiz({
              ...params,
              authorId: user.uid,
            });
            showToast('Chapter quiz published');
          }}
          onDeleteQuiz={async (id) => {
            await deleteQuiz(id);
            showToast('Quiz deleted');
          }}
          onOpenStudentView={() => {
            setEntryIntent('student');
            setAdminWorkspacePreference('student');
            if (typeof window !== 'undefined' && window.location.hash.toLowerCase().includes('admin')) {
              window.location.hash = '';
            }
          }}
          onSignOut={async () => {
            await signOut(auth);
            setAdminCheckStatus('idle');
            setEntryIntent('student');
            setAdminWorkspacePreference('admin');
            if (typeof window !== 'undefined' && window.location.hash.toLowerCase().includes('admin')) {
              window.location.hash = '';
            }
          }}
        />
        {toastMessage && (
          <div
            role="status"
            className="fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl bg-slate-900 text-white text-xs sm:text-sm font-semibold shadow-lg"
          >
            {toastMessage}
          </div>
        )}
      </>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-[#F6F8FC] flex flex-col items-center justify-center gap-4 p-6">
        <Logo size="lg" />
        <p className="text-sm font-medium text-slate-600">Setting up your student profile...</p>
      </div>
    );
  }

  if (!profile.language) {
    return (
      <LanguageSelectionScreen
        studentName={profile.displayName}
        initialLanguage={profile.language}
        onSelectLanguage={async (lang) => {
          await updateStudentLanguage(user.uid, lang);
        }}
      />
    );
  }

  if (!profile.classLocked || profile.selectedClass < 1 || profile.selectedClass > 10) {
    return (
      <ClassSelectionScreen
        language={profile.language}
        onLockClass={async (cls) => {
          await lockInitialStudentClass(user.uid, cls);
        }}
      />
    );
  }

  // 3. Dedicated Student Dashboard (zero Admin controls, zero Admin UI)
  const classLevel = profile.selectedClass as ClassLevel;
  const language = profile.language as LanguageCode;
  const isHi = language === 'hi';
  const activeSubject = resolveSubjectByIdForClass(classLevel, selectedSubjectId);

  const navItems: { id: AppScreen; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: isHi ? 'होम' : 'Home', icon: <Home className="h-5 w-5" /> },
    { id: 'subjects', label: isHi ? 'विषय' : 'Subjects', icon: <BookOpen className="h-5 w-5" /> },
    { id: 'saved', label: isHi ? 'सेव' : 'Saved', icon: <Bookmark className="h-5 w-5" /> },
    { id: 'downloads', label: isHi ? 'डाउनलोड' : 'Downloads', icon: <Download className="h-5 w-5" /> },
    { id: 'profile', label: isHi ? 'प्रोफ़ाइल' : 'Profile', icon: <UserIcon className="h-5 w-5" /> },
  ];

  const activeVideoHistory = activeVideo
    ? videoHistory.find((v) => v.videoId === activeVideo.id)
    : undefined;

  return (
    <div className="min-h-screen bg-[#F6F8FC] text-slate-900 flex flex-col lg:flex-row">
      {/* Desktop Left Navigation Rail (Student Only) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white border-r border-slate-200 px-4 py-6 justify-between z-30">
        <div className="space-y-6">
          <div className="flex items-center gap-3 px-2">
            <Logo size="sm" />
            <div className="min-w-0">
              <p className="font-display text-base font-bold text-slate-900 truncate">
                EduToon Education
              </p>
              <p className="text-[11px] font-medium text-sky-700 truncate">
                {isHi ? `कक्षा ${classLevel}` : `Class ${classLevel}`} ·{' '}
                {isHi ? 'हिंदी' : 'English'}
              </p>
            </div>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => {
              const active =
                screen === item.id || (screen === 'subject-detail' && item.id === 'subjects');
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setScreen(item.id)}
                  className={`w-full min-h-[44px] px-3.5 rounded-xl flex items-center gap-3 text-sm font-semibold transition-colors cursor-pointer ${
                    active
                      ? 'bg-sky-50 text-sky-800'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}

            <button
              type="button"
              onClick={() => setScreen('announcements')}
              className={`w-full min-h-[44px] px-3.5 rounded-xl flex items-center justify-between text-sm font-semibold transition-colors cursor-pointer ${
                screen === 'announcements'
                  ? 'bg-sky-50 text-sky-800'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <span className="flex items-center gap-3">
                <Bell className="h-5 w-5" />
                <span>{isHi ? 'सूचनाएँ' : 'Announcements'}</span>
              </span>
              {announcements.length > 0 && (
                <span className="text-xs font-mono-num text-sky-700">{announcements.length}</span>
              )}
            </button>

            {canNavigateToAdmin && (
              <button
                type="button"
                onClick={() => setAdminWorkspacePreference('admin')}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#0B132B] hover:bg-[#131F47] text-white flex items-center gap-3 text-sm font-semibold transition-colors cursor-pointer mt-2"
              >
                <ShieldCheck className="h-5 w-5 text-sky-400" />
                <span>Admin Dashboard</span>
              </button>
            )}
          </nav>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
          <p className="font-semibold text-slate-900 truncate">{profile.displayName}</p>
          <p className="mt-0.5">Session {profile.academicSession}</p>
        </div>
      </aside>

      {/* Mobile Compact Sticky Top Bar (52px) */}
      <header className="lg:hidden sticky top-0 z-30 h-[52px] bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => setScreen('home')}
          className="flex items-center gap-2.5 min-w-0 cursor-pointer"
        >
          <Logo size="xs" />
          <span className="font-display text-sm font-bold text-slate-900 truncate">
            EduToon Education
          </span>
        </button>

        <div className="flex items-center gap-1.5 shrink-0">
          {canNavigateToAdmin && (
            <button
              type="button"
              onClick={() => setAdminWorkspacePreference('admin')}
              className="min-h-[36px] px-2.5 rounded-xl bg-[#0B132B] text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-sky-400" />
              <span>Admin</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setScreen('announcements')}
            aria-label="Announcements"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-700 hover:bg-slate-100 relative cursor-pointer"
          >
            <Bell className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 lg:pl-64 pb-20 lg:pb-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-7">
          {screen === 'home' && (
            <DashboardHome
              profile={profile}
              recentNotes={recentNotes}
              videoHistory={videoHistory}
              savedNotes={savedNotes}
              downloads={downloads}
              announcements={announcements}
              customSubjects={customSubjects}
              onSelectSubject={(subId) => {
                setSelectedSubjectId(subId);
                setScreen('subject-detail');
              }}
              onNavigate={setScreen}
              onOpenRecentNote={(rec) => {
                const note = resolveNoteById(
                  rec.noteId,
                  rec.classLevel,
                  rec.subjectId,
                  rec.language
                );
                if (note) handleOpenNote(note);
              }}
              onOpenRecentVideo={(rec) => {
                const vid = resolveVideoById(rec.videoId);
                if (vid) setActiveVideo(vid);
              }}
              onOpenClassChangeModal={() => setShowClassChangeModal(true)}
            />
          )}

          {screen === 'subjects' && (
            <SubjectsGridView
              classLevel={classLevel}
              defaultLanguage={language}
              customSubjects={customSubjects}
              onSelectSubject={(subId) => {
                setSelectedSubjectId(subId);
                setScreen('subject-detail');
              }}
            />
          )}

          {screen === 'subject-detail' && activeSubject && (
            <SubjectDetailView
              subject={activeSubject}
              classLevel={classLevel}
              defaultLanguage={language}
              customLessons={customLessons}
              quizzes={quizzes}
              quizAttempts={studentQuizAttempts}
              savedNotes={savedNotes}
              completedNoteIds={profile.completedNoteIds}
              completedVideoIds={profile.completedVideoIds}
              videoHistory={videoHistory}
              onBack={() => setScreen('subjects')}
              onOpenNote={handleOpenNote}
              onDownloadNote={handleDownloadNote}
              onToggleSaveNote={handleToggleSaveNote}
              onOpenVideo={(vid) => setActiveVideo(vid)}
              onOpenQuiz={(qz) => setActiveQuiz(qz)}
            />
          )}

          {screen === 'saved' && (
            <SavedNotesView
              language={language}
              savedNotes={savedNotes}
              onOpenNoteById={(noteId, cls, subId, lang) => {
                const note = resolveNoteById(noteId, cls, subId, lang);
                if (note) handleOpenNote(note);
              }}
              onRemoveSaved={(noteId) => removeSavedNote(user.uid, noteId)}
            />
          )}

          {screen === 'downloads' && (
            <DownloadsView
              language={language}
              downloads={downloads}
              onRedownloadPdf={async (item) => {
                const note = resolveNoteById(
                  item.noteId,
                  item.classLevel,
                  item.subjectId,
                  item.language
                );
                if (note) await handleDownloadNote(note);
              }}
              onOpenNoteById={(noteId, cls, subId, lang) => {
                const note = resolveNoteById(noteId, cls, subId, lang);
                if (note) handleOpenNote(note);
              }}
              onRemoveDownload={(noteId) => removeDownloadRecord(user.uid, noteId)}
            />
          )}

          {screen === 'announcements' && (
            <AnnouncementsView language={language} announcements={announcements} />
          )}

          {screen === 'profile' && (
            <ProfileView
              profile={profile}
              email={privateContact?.email || user.email || ''}
              phoneNumber={privateContact?.phoneNumber || user.phoneNumber || ''}
              reports={studentReports}
              onUpdateName={(name) => updateStudentDisplayName(user.uid, name)}
              onSwitchLanguage={async (lang) => {
                await updateStudentLanguage(user.uid, lang);
                showToast(lang === 'hi' ? 'भाषा हिंदी चुनी गई' : 'Language switched to English');
              }}
              onOpenClassChangeModal={() => setShowClassChangeModal(true)}
              onOpenAdminDashboard={
                canNavigateToAdmin ? () => setAdminWorkspacePreference('admin') : undefined
              }
              onSignOut={async () => {
                await signOut(auth);
                setScreen('home');
                setEntryIntent('student');
                setAdminWorkspacePreference('admin');
              }}
            />
          )}
        </div>
      </main>

      {/* Mobile Android-style Fixed Bottom Navigation Bar (60px) */}
      <nav
        aria-label="Primary mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
      >
        <div className="grid grid-cols-5 h-[60px] items-center">
          {navItems.map((item) => {
            const active =
              screen === item.id || (screen === 'subject-detail' && item.id === 'subjects');
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setScreen(item.id)}
                className={`h-full flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors ${
                  active ? 'text-sky-700' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {item.icon}
                <span className="text-[10px] font-semibold tracking-tight">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Modals */}
      {activeNote && (
        <NoteReaderModal
          note={activeNote}
          subjectName={
            activeNote.language === 'hi'
              ? resolveSubjectByIdForClass(activeNote.classLevel, activeNote.subjectId)?.titleHi ||
                activeNote.subjectId
              : resolveSubjectByIdForClass(activeNote.classLevel, activeNote.subjectId)?.titleEn ||
                activeNote.subjectId
          }
          isSaved={savedNotes.some((s) => s.noteId === activeNote.id)}
          isCompleted={profile.completedNoteIds.includes(activeNote.id)}
          language={language}
          onToggleSave={() => handleToggleSaveNote(activeNote)}
          onDownloadPdf={() => handleDownloadNote(activeNote)}
          onToggleCompleted={async () => {
            await toggleCompletedNote(user.uid, activeNote.id, profile.completedNoteIds);
            showToast('Updated chapter progress');
          }}
          onClose={() => setActiveNote(null)}
        />
      )}

      {activeVideo && (
        <AnimatedLessonPlayer
          video={activeVideo}
          subjectName={
            activeVideo.language === 'hi'
              ? resolveSubjectByIdForClass(activeVideo.classLevel, activeVideo.subjectId)
                  ?.titleHi || activeVideo.subjectId
              : resolveSubjectByIdForClass(activeVideo.classLevel, activeVideo.subjectId)
                  ?.titleEn || activeVideo.subjectId
          }
          initialProgress={activeVideoHistory?.progressPercent || 0}
          isCompleted={profile.completedVideoIds.includes(activeVideo.id)}
          language={language}
          onSaveProgress={(pct, completed) => {
            upsertVideoProgress(user.uid, activeVideo, pct, completed);
          }}
          onToggleCompleted={async () => {
            const wasDone = profile.completedVideoIds.includes(activeVideo.id);
            await toggleCompletedVideo(user.uid, activeVideo.id, profile.completedVideoIds);
            await upsertVideoProgress(
              user.uid,
              activeVideo,
              wasDone ? activeVideoHistory?.progressPercent || 50 : 100,
              !wasDone
            );
            showToast(!wasDone ? 'Video marked completed' : 'Video completion removed');
          }}
          onClose={() => setActiveVideo(null)}
        />
      )}

      {activeQuiz && (
        <QuizPlayerModal
          quiz={activeQuiz}
          subjectName={
            activeQuiz.language === 'hi'
              ? resolveSubjectByIdForClass(activeQuiz.classLevel, activeQuiz.subjectId)
                  ?.titleHi || activeQuiz.subjectId
              : resolveSubjectByIdForClass(activeQuiz.classLevel, activeQuiz.subjectId)
                  ?.titleEn || activeQuiz.subjectId
          }
          language={language}
          previousAttempt={studentQuizAttempts.find((a) => a.quizId === activeQuiz.id)}
          onSubmitQuiz={async (score) => {
            await saveQuizAttempt({
              studentId: user.uid,
              quiz: activeQuiz,
              score,
            });
            showToast('Quiz score recorded');
          }}
          onClose={() => setActiveQuiz(null)}
        />
      )}

      {showClassChangeModal && (
        <ClassChangeReportModal
          currentClass={classLevel}
          studentName={profile.displayName}
          language={language}
          reports={studentReports}
          onSubmitReport={async (requestedClass, reason) => {
            await submitClassChangeReport({
              studentId: user.uid,
              studentName: profile.displayName,
              currentClass: classLevel,
              requestedClass,
              reason,
            });
          }}
          onClose={() => setShowClassChangeModal(false)}
        />
      )}

      {/* Subtle Toast */}
      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-20 lg:bottom-6 right-4 sm:right-6 z-50 px-4 py-3 rounded-2xl bg-slate-900 text-white text-xs sm:text-sm font-semibold shadow-lg"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <EduToonAppShell />
    </ErrorBoundary>
  );
}
