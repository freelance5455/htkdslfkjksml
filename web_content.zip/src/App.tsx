import { useEffect, useRef } from "react";
import { useGame } from "./game/useGame";
import { sfx } from "./game/audio";
import { INGREDIENTS, type IngId } from "./game/data";

sfx.loadMuted();
import { PlayScreen } from "./components/PlayScreen";
import { GameOverScreen, PauseOverlay, ReadyOverlay, ShopScreen, StartScreen } from "./components/Screens";

export default function App() {
  const g = useGame();
  const s = g.s;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const shakeRef = useRef<HTMLDivElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);

  /* attach canvas / shake / flash surfaces */
  useEffect(() => {
    sfx.loadMuted();
    g.attachCanvas(canvasRef.current);
    g.attachShake(shakeRef.current);
    g.attachFlash(flashRef.current);
    const onResize = () => {
      g.parts.resize();
      g.derive();
      g.mark();
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    const ro = new ResizeObserver(onResize);
    if (canvasRef.current) ro.observe(canvasRef.current);
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      ro.disconnect();
    };
  }, [g]);

  /* press feedback that survives touch preventDefault */
  useEffect(() => {
    let held: HTMLElement | null = null;
    const down = (e: PointerEvent) => {
      const t = (e.target as HTMLElement | null)?.closest?.(".btn3d") as HTMLElement | null;
      if (t && !t.hasAttribute("disabled")) {
        held = t;
        t.classList.add("pressed");
      }
    };
    const up = () => {
      held?.classList.remove("pressed");
      held = null;
    };
    const ctx = (e: Event) => e.preventDefault();
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("pointerup", up, true);
    document.addEventListener("pointercancel", up, true);
    document.addEventListener("contextmenu", ctx);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("pointerup", up, true);
      document.removeEventListener("pointercancel", up, true);
      document.removeEventListener("contextmenu", ctx);
    };
  }, []);

  /* keyboard controls */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const k = e.key.toLowerCase();
      const ph = g.s.phase;

      const primary = () => {
        sfx.init();
        if (ph === "menu") {
          sfx.click();
          g.startRun();
        } else if (ph === "ready") g.skipReady();
        else if (ph === "playing") g.serveBest();
        else if (ph === "paused") g.togglePause();
        else if (ph === "shop") g.nextDay();
        else if (ph === "gameover") {
          sfx.click();
          g.startRun();
        }
      };

      if (k === " " || k === "spacebar" || k === "enter") {
        e.preventDefault();
        if (e.repeat) return;
        primary();
        return;
      }
      if (k === "escape" || k === "p") {
        e.preventDefault();
        g.togglePause();
        return;
      }
      if (k === "m") {
        sfx.init();
        sfx.setMuted(!sfx.muted);
        g.mark();
        return;
      }
      if (k === "r" && ph !== "playing") {
        e.preventDefault();
        sfx.init();
        sfx.click();
        g.startRun();
        return;
      }
      if (ph !== "playing") return;
      if (k === "x" || k === "backspace" || k === "delete") {
        e.preventDefault();
        g.trash();
        return;
      }
      const slot = ["q", "w", "e", "r", "t"].indexOf(k);
      if (slot >= 0) {
        e.preventDefault();
        g.serveBySlot(slot);
        return;
      }
      if (e.repeat) return;
      if (/^[0-9]$/.test(k)) {
        e.preventDefault();
        const ing = INGREDIENTS.find((i) => i.key === k);
        if (ing) g.tapIng(ing.id as IngId);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [g]);

  /* auto-pause when the tab / app goes away */
  useEffect(() => {
    const onHide = () => {
      if (document.hidden && g.s.phase === "playing") g.togglePause(true);
    };
    document.addEventListener("visibilitychange", onHide);
    return () => document.removeEventListener("visibilitychange", onHide);
  }, [g]);

  const paused = s.phase === "paused";

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-ink font-body text-cream">
      <div ref={shakeRef} className={`absolute inset-0 will-change-transform ${paused ? "paused-anim" : ""}`}>
        {s.phase === "menu" ? <StartScreen g={g} /> : <PlayScreen g={g} />}
      </div>

      <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 z-30 h-full w-full" />
      <div ref={flashRef} className="pointer-events-none absolute inset-0 z-40 opacity-0 mix-blend-screen" />

      {s.phase === "ready" && <ReadyOverlay g={g} />}
      {paused && <PauseOverlay g={g} />}
      {s.phase === "shop" && <ShopScreen g={g} />}
      {s.phase === "gameover" && <GameOverScreen g={g} />}

      {/* safe-area spacers for notched phones */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-50 h-[env(safe-area-inset-top)]" />
    </div>
  );
}
