import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { AdminDashboard } from './views/AdminDashboard';
import { ClientManagementView } from './views/ClientManagementView';
import { ProjectManagementView } from './views/ProjectManagementView';
import { TaskManagementView } from './views/TaskManagementView';
import { ProjectDetailView } from './views/ProjectDetailView';
import { ClientPortalView } from './views/ClientPortalView';
import { EmployeePortalView } from './views/EmployeePortalView';
import { DocumentsView } from './views/DocumentsView';
import { ReportsView } from './views/ReportsView';
import { EmployeesView } from './views/EmployeesView';
import { ViewEmployeeView } from './views/ViewEmployeeView';
import { ClientImportView } from './views/ClientImportView';
import { SettingsView } from './views/SettingsView';
import { CreateProjectModal } from './components/CreateProjectModal';
import { TaskModal } from './components/TaskModal';
import { ZohoBooksImportModal } from './components/ZohoBooksImportModal';
import { PersonaSwitcherModal } from './components/PersonaSwitcherModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Task, Project } from './types';
import phoenixEmblem from './assets/images/phoenix_company_emblem_1791972033084.jpg';

const MainContent: React.FC = () => {
  const { activeView, setActiveView, currentUser } = useApp();

  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [taskDefaultProjectId, setTaskDefaultProjectId] = useState<string | undefined>(undefined);
  const [isZohoModalOpen, setIsZohoModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isPersonaModalOpen, setIsPersonaModalOpen] = useState(false);

  const handleOpenNewProject = () => {
    setProjectToEdit(null);
    setIsNewProjectModalOpen(true);
  };

  const handleEditProject = (project: Project) => {
    setProjectToEdit(project);
    setIsNewProjectModalOpen(true);
  };

  const handleOpenNewTaskModal = (projectId?: string) => {
    setTaskToEdit(null);
    setTaskDefaultProjectId(projectId);
    setIsTaskModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setTaskToEdit(task);
    setTaskDefaultProjectId(task.projectId);
    setIsTaskModalOpen(true);
  };

  const handleOpenNewClient = () => {
    setActiveView('clients');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col selection:bg-red-500 selection:text-white">
      {/* Top Bar with Three-Zone Contract */}
      <Header 
        onOpenNewProjectModal={handleOpenNewProject}
        onOpenZohoModal={() => setIsZohoModalOpen(true)}
        onOpenNewTaskModal={() => handleOpenNewTaskModal()}
        onOpenPersonaModal={() => setIsPersonaModalOpen(true)}
        mobileMenuOpen={isMobileMenuOpen}
        setMobileMenuOpen={setIsMobileMenuOpen}
      />

      {/* Main Container Viewport (optimized for mobile touch spacing & desktop 1440px) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8 pb-28 md:pb-8">
        {activeView === 'dashboard' && (
          <AdminDashboard
            onOpenNewProjectModal={handleOpenNewProject}
            onOpenNewClientModal={handleOpenNewClient}
            onOpenNewTaskModal={() => handleOpenNewTaskModal()}
            onOpenZohoModal={() => setIsZohoModalOpen(true)}
            onEditProject={handleEditProject}
          />
        )}

        {activeView === 'clients' && (
          <ClientManagementView
            onOpenZohoModal={() => setIsZohoModalOpen(true)}
          />
        )}

        {activeView === 'projects' && (
          <ProjectManagementView
            onOpenNewProjectModal={handleOpenNewProject}
            onEditProject={handleEditProject}
          />
        )}

        {activeView === 'tasks' && (
          <TaskManagementView
            onOpenNewTaskModal={handleOpenNewTaskModal}
            onEditTask={handleEditTask}
          />
        )}

        {activeView === 'project-detail' && (
          <ProjectDetailView />
        )}

        {activeView === 'client-portal' && (
          <ClientPortalView />
        )}

        {activeView === 'employee-portal' && (
          <EmployeePortalView />
        )}

        {activeView === 'documents' && (
          <DocumentsView />
        )}

        {activeView === 'reports' && (
          <ReportsView />
        )}

        {activeView === 'employees' && (
          <EmployeesView />
        )}

        {activeView === 'view-employee' && (
          <ViewEmployeeView />
        )}

        {activeView === 'client-import' && (
          <ClientImportView />
        )}

        {activeView === 'settings' && (
          <SettingsView />
        )}
      </main>

      {/* Quiet Corporate Footer adhering to Anti-Slop Rules */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img 
              src={phoenixEmblem} 
              alt="Phoenix Fire Safety" 
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded object-cover shadow-xs" 
            />
            <span className="font-semibold text-slate-800">
              Phoenix Fire Safety Equipments Pvt. Ltd.
            </span>
            <span className="text-slate-300">·</span>
            <span>Chennai, Tamil Nadu, India</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span>IS 3844 / NBC 2016 Compliant</span>
            <span className="text-slate-300">·</span>
            <span>Zoho Books Connected</span>
            <span className="text-slate-300">·</span>
            <span>© {new Date().getFullYear()} All Rights Reserved</span>
          </div>
        </div>
      </footer>

      {/* Floating Mobile Bottom Navigation Bar */}
      <MobileBottomNav 
        onOpenMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* Global Modals */}
      <CreateProjectModal
        isOpen={isNewProjectModalOpen}
        onClose={() => {
          setIsNewProjectModalOpen(false);
          setProjectToEdit(null);
        }}
        projectToEdit={projectToEdit}
      />

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setTaskToEdit(null);
          setTaskDefaultProjectId(undefined);
        }}
        taskToEdit={taskToEdit}
        defaultProjectId={taskDefaultProjectId}
      />

      <ZohoBooksImportModal
        isOpen={isZohoModalOpen}
        onClose={() => setIsZohoModalOpen(false)}
      />

      <PersonaSwitcherModal
        isOpen={isPersonaModalOpen}
        onClose={() => setIsPersonaModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
