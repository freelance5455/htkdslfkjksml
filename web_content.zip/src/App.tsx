import { useEffect, useRef, useState } from "react";
import Landing, { type LandingPanel } from "@/components/Landing";
import Hud, { type HudToast, type WaveNotice } from "@/components/Hud";
import WorldCanvas, { type WorldCanvasHandle } from "@/components/WorldCanvas";
import { AndroidAppModal, ControlsModal, FieldGuideModal, HowToModal, LoadoutModal, RecordsModal } from "@/components/Modals";
import { PauseOverlay, ResultsOverlay, type HuntOutcome } from "@/components/GameOverlays";
import { isAndroid, isNativeApp, isStandalone, type BeforeInstallPromptEvent } from "@/pwa";
import { App as NativeApp } from "@capacitor/app";
import {
  DEFAULT_LOADOUT,
  MISSION,
  readControls,
  readRecords,
  WAVES,
  writeControls,
  writeRecord,
  type ControlSettings,
  type HuntRecord,
  type Loadout,
  type MapId,
  type SpeciesKey,
} from "@/data";
import type { ShotResult, TargetInfo } from "@/game/world";
import { sound } from "@/game/audio";

type Screen = "camp" | "hunt";
type Panel = LandingPanel | "pause" | "results" | null;

interface HuntState {
  ammo: number;
  reserve: number;
  reloading: boolean;
  score: number;
  harvested: number;
  shots: number;
  hits: number;
  longestShot: number;
  bag: Partial<Record<SpeciesKey, number>>;
  timeLeft: number;
  waveIndex: number;
  waveTimeLeft: number;
  waveHarvested: number;
  wavesCleared: number;
  waveBonus: number;
}

function freshHunt(loadout: Loadout): HuntState {
  return {
    ammo: loadout.magazine,
    reserve: loadout.reserve,
    reloading: false,
    score: 0,
    harvested: 0,
    shots: 0,
    hits: 0,
    longestShot: 0,
    bag: {},
    timeLeft: MISSION.time,
    waveIndex: 0,
    waveTimeLeft: WAVES[0].duration,
    waveHarvested: 0,
    wavesCleared: 0,
    waveBonus: 0,
  };
}

export default function App() {
  const worldRef = useRef<WorldCanvasHandle>(null);
  const [screen, setScreen] = useState<Screen>("camp");
  const [panel, setPanel] = useState<Panel>(null);
  const [panelBack, setPanelBack] = useState<Panel>(null);
  const [loadout, setLoadout] = useState<Loadout>(DEFAULT_LOADOUT);
  const [muted, setMuted] = useState(false);
  const [records, setRecords] = useState<HuntRecord[]>(() => readRecords());
  const [controls, setControls] = useState<ControlSettings>(() => readControls());
  const [mapPreview, setMapPreview] = useState<MapId | null>(null);
  const [hunt, setHunt] = useState<HuntState>(() => freshHunt(DEFAULT_LOADOUT));
  const [target, setTarget] = useState<TargetInfo | null>(null);
  const [heading, setHeading] = useState(0);
  const [spotted, setSpotted] = useState<SpeciesKey[]>([]);
  const [aiming, setAiming] = useState(false);
  const [toast, setToast] = useState<HudToast | null>(null);
  const [waveNotice, setWaveNotice] = useState<WaveNotice | null>(null);
  const [hitMarker, setHitMarker] = useState(0);
  const [outcome, setOutcome] = useState<HuntOutcome | null>(null);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(() => isStandalone());
  const [androidDevice] = useState(() => isAndroid());
  const [nativeApp] = useState(() => isNativeApp());

  const previewMap = mapPreview;

  const huntRef = useRef(hunt);
  huntRef.current = hunt;
  const outcomeRef = useRef(false);
  const transitionRef = useRef(false);
  const runId = useRef(0);
  const toastId = useRef(0);
  const noticeId = useRef(0);
  const loadoutRef = useRef(loadout);
  loadoutRef.current = loadout;
  const controlsRef = useRef(controls);
  controlsRef.current = controls;

  const paused = screen === "hunt" && panel !== null;
  const mode = screen === "hunt" ? "hunting" : "landing";

  const openPanel = (next: Panel, back: Panel = null) => {
    setPanelBack(back);
    setPanel(next);
    sound.ui();
  };

  const closePanel = () => {
    setMapPreview(null);
    setPanel(panelBack);
    setPanelBack(null);
  };

  const chooseMap = (id: MapId) => {
    setMapPreview(id);
    worldRef.current?.setMap(id);
  };

  const installApp = async () => {
    if (installed || nativeApp) return;
    if (!installPrompt) {
      sound.ui();
      return;
    }
    try {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === "accepted") {
        setInstalled(true);
      }
    } catch {
      /* the browser may cancel the prompt */
    } finally {
      setInstallPrompt(null);
    }
  };

  const clearTransient = () => {
    setTarget(null);
    setSpotted([]);
    setAiming(false);
    setToast(null);
    setWaveNotice(null);
  };

  const showDrive = (index: number) => {
    const wave = WAVES[index];
    noticeId.current += 1;
    setWaveNotice({
      id: noticeId.current,
      title: wave.name,
      subtitle: wave.subtitle,
      tone: "wave",
    });
  };

  const launchDrive = (index: number) => {
    const wave = WAVES[index];
    setHunt((prev) => ({ ...prev, waveIndex: index, waveTimeLeft: wave.duration, waveHarvested: 0 }));
    worldRef.current?.beginWave(index, wave.population);
    showDrive(index);
  };

  const startHunt = () => {
    sound.unlock();
    sound.startAmbient();
    runId.current += 1;
    outcomeRef.current = false;
    transitionRef.current = false;
    setOutcome(null);
    setPanel(null);
    setPanelBack(null);
    clearTransient();
    setHeading(0);
    setHunt(freshHunt(loadoutRef.current));
    setScreen("hunt");
    worldRef.current?.setLoadout({
      id: loadoutRef.current.id,
      magazine: loadoutRef.current.magazine,
      reserve: loadoutRef.current.reserve,
      zoomFov: loadoutRef.current.zoomFov,
    });
    worldRef.current?.setLookSensitivity(controlsRef.current.sensitivity);
    worldRef.current?.setInfiniteAmmo(controlsRef.current.infiniteAmmo);
    worldRef.current?.setMap(controlsRef.current.map);
    worldRef.current?.resetHunt();
    worldRef.current?.beginWave(0, WAVES[0].population);
    showDrive(0);
    sound.ui();
  };

  const restartHunt = () => {
    runId.current += 1;
    outcomeRef.current = false;
    transitionRef.current = false;
    setOutcome(null);
    setPanel(null);
    setPanelBack(null);
    clearTransient();
    setHunt(freshHunt(loadoutRef.current));
    worldRef.current?.setInfiniteAmmo(controlsRef.current.infiniteAmmo);
    worldRef.current?.setMap(controlsRef.current.map);
    worldRef.current?.resetHunt();
    worldRef.current?.beginWave(0, WAVES[0].population);
    showDrive(0);
    sound.ui();
  };

  const returnToCamp = () => {
    runId.current += 1;
    outcomeRef.current = false;
    transitionRef.current = false;
    setOutcome(null);
    setScreen("camp");
    setPanel(null);
    setPanelBack(null);
    clearTransient();
    setHunt(freshHunt(loadoutRef.current));
    worldRef.current?.resetHunt();
    sound.ui();
  };

  const toggleMute = () => {
    setMuted((value) => {
      const next = !value;
      sound.setMuted(next);
      return next;
    });
  };

  const pushToast = (title: string, subtitle: string, tone: HudToast["tone"]) => {
    toastId.current += 1;
    setToast({ id: toastId.current, title, subtitle, tone });
  };

  const handleShot = (result: ShotResult) => {
    const current = huntRef.current;
    const wave = WAVES[current.waveIndex];
    setHunt((prev) => {
      const hit = result.hit ? 1 : 0;
      const bag = { ...prev.bag };
      if (result.hit && result.species) bag[result.species] = (bag[result.species] ?? 0) + 1;
      return {
        ...prev,
        shots: prev.shots + 1,
        hits: prev.hits + hit,
        harvested: prev.harvested + hit,
        waveHarvested: prev.waveHarvested + hit,
        score: prev.score + (result.points ?? 0),
        longestShot: result.hit ? Math.max(prev.longestShot, result.distance ?? 0) : prev.longestShot,
        bag,
      };
    });
    if (result.hit) {
      sound.hit();
      setHitMarker((value) => value + 1);
      pushToast(
        `${result.speciesName ?? "Animal"} harvested`,
        `${result.points ?? 0} pts · ${Math.round(result.distance ?? 0)} m${result.headshot ? " · vital shot" : ""}`,
        "success",
      );
      if (current.waveHarvested + 1 === wave.quota) {
        noticeId.current += 1;
        setWaveNotice({
          id: noticeId.current,
          title: "Drive quota met",
          subtitle: `+${wave.bonus} bonus secured · keep hunting until the drive ends`,
          tone: "cleared",
        });
      }
    } else {
      sound.miss();
    }
  };

  const handleEmpty = () => {
    sound.dry();
    pushToast("Magazine empty", "Press R or tap reload before the next opportunity", "empty");
  };

  const handleWorldReload = (active: boolean) => {
    setHunt((prev) => ({ ...prev, reloading: active }));
    if (active) sound.reload();
  };

  const manualReload = () => {
    if (hunt.reloading) return;
    if (controls.infiniteAmmo) {
      pushToast("Unlimited ammunition", "The magazine stays topped up · no reload needed", "info");
      return;
    }
    if (hunt.ammo >= loadout.magazine) {
      pushToast("Magazine is full", `${hunt.ammo} rounds ready`, "info");
      return;
    }
    if (hunt.reserve <= 0) {
      pushToast("No reserve rounds", "Make the remaining shots count", "empty");
      return;
    }
    worldRef.current?.reload();
  };

  const toggleAim = () => {
    worldRef.current?.toggleAim();
  };

  const equipLoadout = (next: Loadout) => {
    setLoadout(next);
    pushToast(`${next.name} equipped`, `${next.calibre} · ${next.magazine}-round magazine`, "info");
  };

  const updateControls = (next: ControlSettings) => {
    setControls(next);
    setMapPreview(next.map);
    worldRef.current?.setLookSensitivity(next.sensitivity);
    worldRef.current?.setInfiniteAmmo(next.infiniteAmmo);
    worldRef.current?.setMap(next.map);
    writeControls(next);
    sound.ui();
  };

  const finalizeHunt = (completed: boolean) => {
    if (outcomeRef.current) return;
    outcomeRef.current = true;
    const current = huntRef.current;
    const accuracy = current.shots > 0 ? (current.hits / current.shots) * 100 : 0;
    const objectives = [
      { label: "Clear three of five drives", met: current.wavesCleared >= 3, bonus: 250 },
      { label: "Make a shot beyond 150 m", met: current.longestShot >= 150, bonus: 150 },
      { label: "Finish with accuracy above 50%", met: current.shots > 0 && accuracy > 50, bonus: 100 },
    ];
    const bonus = objectives.reduce((sum, objective) => sum + (objective.met ? objective.bonus : 0), 0);
    const data: HuntOutcome = {
      completed,
      score: current.score,
      harvested: current.harvested,
      shots: current.shots,
      hits: current.hits,
      accuracy,
      longestShot: current.longestShot,
      bag: current.bag,
      timeLeft: current.timeLeft,
      objectives,
      bonus,
      wavesCleared: current.wavesCleared,
      waveBonus: current.waveBonus,
    };
    setOutcome(data);
    setPanel("results");
    setPanelBack(null);
    setWaveNotice(null);
    const record: HuntRecord = {
      id: `${Date.now()}`,
      date: new Date().toISOString(),
      score: current.score + bonus,
      harvested: current.harvested,
      shots: current.shots,
      hits: current.hits,
      accuracy,
      bestDistance: current.longestShot,
      loadout: loadoutRef.current.name,
      completed,
    };
    setRecords(writeRecord(record));
    sound.complete(completed);
  };

  /* assignment timer + drive clock */
  useEffect(() => {
    if (screen !== "hunt" || panel !== null) return;
    const interval = window.setInterval(() => {
      setHunt((prev) => {
        if (prev.timeLeft <= 0) return prev;
        return {
          ...prev,
          timeLeft: Math.max(0, prev.timeLeft - 1),
          waveTimeLeft: Math.max(0, prev.waveTimeLeft - 1),
        };
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [screen, panel]);

  /* drive director */
  useEffect(() => {
    if (screen !== "hunt" || panel !== null || outcomeRef.current) return;
    if (hunt.waveTimeLeft > 0 || transitionRef.current) return;
    transitionRef.current = true;
    const current = huntRef.current;
    const wave = WAVES[current.waveIndex];
    const cleared = current.waveHarvested >= wave.quota;
    const nextIndex = current.waveIndex + 1;
    const wavesClearedAfter = current.wavesCleared + (cleared ? 1 : 0);
    const run = runId.current;

    setHunt((prev) => ({
      ...prev,
      score: prev.score + (cleared ? wave.bonus : 0),
      wavesCleared: prev.wavesCleared + (cleared ? 1 : 0),
      waveBonus: prev.waveBonus + (cleared ? wave.bonus : 0),
    }));

    if (nextIndex >= WAVES.length) {
      noticeId.current += 1;
      setWaveNotice({
        id: noticeId.current,
        title: cleared ? "Last drive cleared" : "Last light falls",
        subtitle: cleared ? `+${wave.bonus} drive bonus · tallying your morning` : "The herd moves off the ridge · tallying your morning",
        tone: "final",
      });
      window.setTimeout(() => {
        if (run !== runId.current || outcomeRef.current) return;
        transitionRef.current = false;
        finalizeHunt(wavesClearedAfter >= 3);
      }, 2800);
      return;
    }

    noticeId.current += 1;
    setWaveNotice({
      id: noticeId.current,
      title: cleared ? `${wave.name} cleared` : `${wave.name} ends`,
      subtitle: cleared ? `+${wave.bonus} drive bonus · the next herd is already moving` : "Quota missed · reposition and read the wind",
      tone: "cleared",
    });
    window.setTimeout(() => {
      if (run !== runId.current || outcomeRef.current) return;
      transitionRef.current = false;
      launchDrive(nextIndex);
    }, 2800);
    // finalize/launch read the latest state through refs
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, hunt.waveTimeLeft, panel]);

  /* overall light runs out */
  useEffect(() => {
    if (screen !== "hunt" || panel !== null || outcomeRef.current) return;
    if (hunt.timeLeft <= 0) finalizeHunt(huntRef.current.wavesCleared >= 3);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen, hunt.timeLeft, panel]);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(null), 4300);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  useEffect(() => {
    if (!waveNotice) return;
    const timeout = window.setTimeout(() => setWaveNotice(null), 4200);
    return () => window.clearTimeout(timeout);
  }, [waveNotice]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.code !== "Escape") return;
      if (panel === "pause") {
        setPanel(null);
      } else if (panel === null && screen === "hunt" && !outcomeRef.current) {
        setPanel("pause");
        sound.ui();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [panel, screen]);

  useEffect(() => {
    sound.setMuted(muted);
  }, [muted]);

  useEffect(() => {
    const world = worldRef.current;
    if (!world) return;
    world.setLookSensitivity(controls.sensitivity);
    world.setInfiniteAmmo(controls.infiniteAmmo);
  }, [controls.sensitivity, controls.infiniteAmmo]);

  /* revert any in-dialog map preview when the controls panel closes */
  useEffect(() => {
    if (panel === "controls" || panel === "howto") return;
    setMapPreview(null);
    worldRef.current?.setMap(controls.map);
  }, [panel, controls.map]);

  /* native Android hardware back button */
  useEffect(() => {
    if (!nativeApp) return;
    let disposed = false;
    let handle: { remove: () => Promise<void> } | undefined;
    NativeApp.addListener("backButton", () => {
      if (panel === "results") return;
      if (panel !== null) {
        setPanel(panelBack);
        setPanelBack(null);
        return;
      }
      if (screen === "hunt" && !outcomeRef.current) {
        setPanel("pause");
        return;
      }
      void NativeApp.exitApp();
    }).then((listener) => {
      if (disposed) void listener.remove();
      else handle = listener;
    });
    return () => {
      disposed = true;
      void handle?.remove();
    };
  }, [nativeApp, panel, panelBack, screen]);

  /* pause the drive whenever the Android app leaves the foreground */
  useEffect(() => {
    if (!nativeApp) return;
    let disposed = false;
    let handle: { remove: () => Promise<void> } | undefined;
    NativeApp.addListener("appStateChange", ({ isActive }) => {
      if (!isActive) {
        setPanel((current) => (screen === "hunt" && current === null ? "pause" : current));
      }
    }).then((listener) => {
      if (disposed) void listener.remove();
      else handle = listener;
    });
    return () => {
      disposed = true;
      void handle?.remove();
    };
  }, [nativeApp, screen]);

  /* capture the native Android install prompt */
  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setInstallPrompt(null);
    };
    const media = window.matchMedia("(display-mode: standalone)");
    const onDisplayChange = () => setInstalled(isStandalone());
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    media.addEventListener?.("change", onDisplayChange);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
      media.removeEventListener?.("change", onDisplayChange);
    };
  }, []);

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-bark-950">
      <WorldCanvas
        ref={worldRef}
        mode={mode}
        paused={paused}
        loadout={loadout}
        callbacks={{
          onAmmo: (ammo, reserve) => setHunt((prev) => ({ ...prev, ammo, reserve })),
          onReload: handleWorldReload,
          onShot: handleShot,
          onEmpty: handleEmpty,
          onTarget: setTarget,
          onHeading: setHeading,
          onAim: setAiming,
          onSpotted: setSpotted,
          onFlash: () => sound.shot(),
        }}
      />

      <div className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(4,8,6,0.34)_100%)]" />
      <div className="pointer-events-none absolute inset-0 z-[1] grain" />

      {screen === "camp" && (
        <Landing
          loadout={loadout}
          records={records}
          muted={muted}
          controls={controls}
          installed={installed || nativeApp}
          canInstall={!!installPrompt}
          onToggleMute={toggleMute}
          onStart={startHunt}
          onOpen={(next) => openPanel(next)}
          onSelectMap={(id) => updateControls({ ...controls, map: id })}
        />
      )}

      {screen === "hunt" && (
        <Hud
          loadout={loadout}
          timeLeft={hunt.timeLeft}
          ammo={hunt.ammo}
          reserve={hunt.reserve}
          reloading={hunt.reloading}
          aiming={aiming}
          target={target}
          heading={heading}
          spotted={spotted}
          bag={hunt.bag}
          harvested={hunt.harvested}
          score={hunt.score}
          shots={hunt.shots}
          hits={hunt.hits}
          toast={toast}
          hitMarker={hitMarker}
          muted={muted}
          infiniteAmmo={controls.infiniteAmmo}
          waveIndex={hunt.waveIndex}
          waveTimeLeft={hunt.waveTimeLeft}
          waveHarvested={hunt.waveHarvested}
          wavesCleared={hunt.wavesCleared}
          waveNotice={waveNotice}
          controlsLayout={controls.layout}
          mapId={controls.map}
          onPause={() => openPanel("pause")}
          onFire={() => worldRef.current?.fire()}
          onReload={manualReload}
          onToggleAim={toggleAim}
          onToggleMute={toggleMute}
          onOpenGuide={() => openPanel("guide")}
          onMoveAxes={(x, y) => worldRef.current?.setMoveAxes(x, y)}
        />
      )}

      {panel === "guide" && <FieldGuideModal onClose={closePanel} />}
      {panel === "records" && <RecordsModal records={records} onClose={closePanel} />}
      {panel === "android" && (
        <AndroidAppModal
          installed={installed || nativeApp}
          canInstall={!!installPrompt}
          native={nativeApp}
          android={androidDevice}
          onInstall={installApp}
          onControls={() => openPanel("controls", "android")}
          onStart={() => {
            setPanel(null);
            startHunt();
          }}
          onClose={closePanel}
        />
      )}
      {panel === "controls" && (
        <ControlsModal
          settings={controls}
          preview={previewMap}
          onPreview={chooseMap}
          onChange={updateControls}
          onClose={() => {
            setControls((current) => {
              writeControls(current);
              return current;
            });
            closePanel();
          }}
        />
      )}
      {panel === "howto" && (
        <HowToModal
          onClose={closePanel}
          onControls={() => openPanel("controls", "howto")}
          onStart={() => {
            setPanel(null);
            startHunt();
          }}
        />
      )}
      {panel === "loadout" && <LoadoutModal current={loadout} onEquip={equipLoadout} onClose={closePanel} />}

      {panel === "pause" && screen === "hunt" && (
        <PauseOverlay
          loadout={loadout}
          harvested={hunt.harvested}
          score={hunt.score}
          timeLeft={hunt.timeLeft}
          shots={hunt.shots}
          hits={hunt.hits}
          muted={muted}
          waveIndex={hunt.waveIndex}
          wavesCleared={hunt.wavesCleared}
          controls={controls}
          onResume={() => setPanel(null)}
          onGuide={() => openPanel("guide", "pause")}
          onLoadout={() => openPanel("loadout", "pause")}
          onControls={() => openPanel("controls", "pause")}
          onRestart={restartHunt}
          onQuit={returnToCamp}
          onToggleMute={toggleMute}
        />
      )}

      {panel === "results" && outcome && (
        <ResultsOverlay
          outcome={outcome}
          loadout={loadout}
          onReplay={restartHunt}
          onCamp={returnToCamp}
          onRecords={() => openPanel("records", "results")}
        />
      )}
    </div>
  );
}
