import { useEffect, useState } from "react";
import TvLo3 from "./app/TvLo3";
import Landing from "./landing/Landing";

export default function App() {
  const [view, setView] = useState<"app" | "info">(() =>
    typeof window !== "undefined" && window.location.hash === "#info" ? "info" : "app"
  );

  useEffect(() => {
    const onHash = () => setView(window.location.hash === "#info" ? "info" : "app");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const openInfo = () => {
    window.location.hash = "info";
    setView("info");
    window.scrollTo({ top: 0 });
  };
  const openApp = () => {
    window.location.hash = "";
    setView("app");
    window.scrollTo({ top: 0 });
  };

  return view === "app" ? <TvLo3 onOpenInfo={openInfo} /> : <Landing onOpenApp={openApp} />;
}
