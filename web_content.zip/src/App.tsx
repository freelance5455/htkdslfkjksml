/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Search,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  FastForward,
  ChevronDown,
  ArrowLeft,
  Plus,
  Trash2,
  X,
  AlertCircle,
  Loader2,
  Film,
  Upload,
  Link as LinkIcon,
  Layers,
  ChevronRight,
  ListVideo,
  Check,
} from 'lucide-react';

interface Episode {
  id: string;
  episodeNumber: number;
  title: string;
  link: string;
  description?: string;
}

interface Season {
  id: string;
  seasonNumber: number;
  title?: string;
  episodes: Episode[];
}

interface Anime {
  id: string;
  title: string;
  description: string;
  poster: string;
  genres?: string[];
  createdAt: number;
  seasons: Season[];
}

interface ResolveResult {
  success: boolean;
  provider?: string;
  type: 'stream' | 'direct' | 'embed_fallback';
  stream_url?: string;
  proxy_url?: string;
  embed_url?: string;
  title?: string;
}

const SECRET_CODE = '8421459082hiteshYS';

export default function App() {
  // Navigation & Catalog
  const [animes, setAnimes] = useState<Anime[]>([]);
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [selectedSeasonNumber, setSelectedSeasonNumber] = useState<number>(1);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [appliedSearch, setAppliedSearch] = useState('');
  const [isLoadingFeed, setIsLoadingFeed] = useState(true);

  // Secret Admin Studio
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminMode, setAdminMode] = useState<'add-anime' | 'edit-anime'>('add-anime');
  const [adminAnimeSearch, setAdminAnimeSearch] = useState('');
  const [adminSelectedAnimeId, setAdminSelectedAnimeId] = useState<string>('');
  const [adminSelectedSeasonId, setAdminSelectedSeasonId] = useState<string>('');

  // Add Anime Form State
  const [newAnimeTitle, setNewAnimeTitle] = useState('');
  const [newAnimeDesc, setNewAnimeDesc] = useState('');
  const [newAnimePoster, setNewAnimePoster] = useState('');

  // Add Episode Form State (NO thumbnail needed!)
  const [newEpNumber, setNewEpNumber] = useState<number>(1);
  const [newEpTitle, setNewEpTitle] = useState('');
  const [newEpLink, setNewEpLink] = useState('');

  // Add Season Form State
  const [newSeasonTitle, setNewSeasonTitle] = useState('');

  // Status & loaders
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [adminMsg, setAdminMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Video Player state
  const [streamData, setStreamData] = useState<ResolveResult | null>(null);
  const [isResolving, setIsResolving] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [bufferedProgress, setBufferedProgress] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const hideTimerRef = useRef<NodeJS.Timeout | null>(null);
  const posterFileRef = useRef<HTMLInputElement | null>(null);

  // Load Anime Catalog from backend
  const fetchAnimes = async () => {
    try {
      setIsLoadingFeed(true);
      const res = await fetch('/api/animes');
      const data = await res.json();
      if (data?.success && Array.isArray(data.animes)) {
        setAnimes(data.animes);
        if (data.animes.length > 0 && !adminSelectedAnimeId) {
          setAdminSelectedAnimeId(data.animes[0].id);
          if (data.animes[0].seasons?.length > 0) {
            setAdminSelectedSeasonId(data.animes[0].seasons[0].id);
          }
        }
      }
    } catch (err) {
      console.error('Failed to load anime feed:', err);
    } finally {
      setIsLoadingFeed(false);
    }
  };

  useEffect(() => {
    fetchAnimes();
  }, []);

  // Update selected anime if list updates
  useEffect(() => {
    if (selectedAnime) {
      const updated = animes.find((a) => a.id === selectedAnime.id);
      if (updated) setSelectedAnime(updated);
    }
  }, [animes]);

  // Handle Search Submission (normal search OR secret code)
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = searchQuery.trim();

    if (clean === SECRET_CODE) {
      setSearchQuery('');
      setAppliedSearch('');
      setIsAdminOpen(true);
      setAdminMsg(null);
      return;
    }

    setAppliedSearch(clean);
  };

  // Resolve episode stream when selected
  useEffect(() => {
    if (!selectedEpisode) {
      setStreamData(null);
      setIsPlaying(false);
      return;
    }

    let isMounted = true;
    setIsResolving(true);
    setStreamData(null);
    setCurrentTime(0);
    setDuration(0);
    setBufferedProgress(0);

    const resolveStream = async () => {
      try {
        const res = await fetch(`/api/resolve?url=${encodeURIComponent(selectedEpisode.link)}`);
        const data: ResolveResult = await res.json();
        if (isMounted) {
          setStreamData(data);
          setIsResolving(false);
        }
      } catch {
        if (isMounted) {
          setStreamData({
            success: true,
            type: 'stream',
            stream_url: selectedEpisode.link,
            proxy_url: `/api/proxy-stream?url=${encodeURIComponent(selectedEpisode.link)}`,
          });
          setIsResolving(false);
        }
      }
    };

    resolveStream();
    playerContainerRef.current?.scrollIntoView({ behavior: 'smooth' });

    return () => {
      isMounted = false;
    };
  }, [selectedEpisode]);

  // Progressive buffer chunk update
  const updateBuffer = () => {
    if (videoRef.current && videoRef.current.duration > 0) {
      const buf = videoRef.current.buffered;
      if (buf.length > 0) {
        for (let i = 0; i < buf.length; i++) {
          if (buf.start(i) <= videoRef.current.currentTime && videoRef.current.currentTime <= buf.end(i)) {
            const pct = (buf.end(i) / videoRef.current.duration) * 100;
            setBufferedProgress(Math.min(100, Math.max(pct, (videoRef.current.currentTime / videoRef.current.duration) * 100)));
            return;
          }
        }
        const lastEnd = buf.end(buf.length - 1);
        setBufferedProgress((lastEnd / videoRef.current.duration) * 100);
      }
    }
  };

  // Auto-hide controls during playback
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    if (isPlaying) {
      hideTimerRef.current = setTimeout(() => {
        setShowControls(false);
        setShowSpeedMenu(false);
      }, 2600);
    }
  }, [isPlaying]);

  useEffect(() => {
    const onMove = () => resetHideTimer();
    window.addEventListener('mousemove', onMove);
    window.addEventListener('touchstart', onMove);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('touchstart', onMove);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [resetHideTimer]);

  // Video controls
  const togglePlayPause = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
    resetHideTimer();
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
    }
  };

  const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    const next = !isMuted;
    setIsMuted(next);
    videoRef.current.muted = next;
    if (!next && volume === 0) {
      setVolume(0.5);
      videoRef.current.volume = 0.5;
    }
  };

  const toggleFullscreen = () => {
    if (!playerContainerRef.current) return;
    if (!document.fullscreenElement) {
      playerContainerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleSpeed = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
    setShowSpeedMenu(false);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeys = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;

      if (e.code === 'Space' || e.key === 'k') {
        e.preventDefault();
        togglePlayPause();
      } else if (e.key === 'f' || e.key === 'F') {
        e.preventDefault();
        toggleFullscreen();
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        toggleMute();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (videoRef.current) videoRef.current.currentTime = Math.min(videoRef.current.duration, videoRef.current.currentTime + 10);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (videoRef.current) videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10);
      }
    };

    window.addEventListener('keydown', handleKeys);
    return () => window.removeEventListener('keydown', handleKeys);
  }, [isPlaying, volume, isMuted]);

  // Gallery poster upload for Anime (main grid)
  const handlePosterUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const res = evt.target?.result as string;
        if (res) {
          setNewAnimePoster(res);
          setAdminMsg({ type: 'success', text: 'Poster gallery se select ho gaya!' });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Admin: Create Anime
  const handleCreateAnime = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnimeTitle.trim()) {
      setAdminMsg({ type: 'error', text: 'Anime title zaroori hai.' });
      return;
    }
    if (!newAnimePoster.trim()) {
      setAdminMsg({ type: 'error', text: 'Kripya gallery se anime ka thumbnail / poster zaroor dalein.' });
      return;
    }

    setIsSubmitting(true);
    setAdminMsg(null);

    try {
      const res = await fetch('/api/animes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          secretCode: SECRET_CODE,
          title: newAnimeTitle.trim(),
          description: newAnimeDesc.trim(),
          poster: newAnimePoster.trim(),
        }),
      });

      const data = await res.json();
      if (data?.success && data.anime) {
        setAnimes((prev) => [data.anime, ...prev]);
        setAdminSelectedAnimeId(data.anime.id);
        if (data.anime.seasons?.length > 0) {
          setAdminSelectedSeasonId(data.anime.seasons[0].id);
        }
        setAdminMsg({ type: 'success', text: `"${data.anime.title}" successfully add ho gaya!` });
        setNewAnimeTitle('');
        setNewAnimeDesc('');
        setNewAnimePoster('');
        setAdminMode('edit-anime');
      } else {
        setAdminMsg({ type: 'error', text: data.error || 'Anime add nahi ho saka.' });
      }
    } catch {
      setAdminMsg({ type: 'error', text: 'Network error. Phir se koshish karein.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Admin: Add Season to selected Anime
  const handleAddSeason = async () => {
    if (!adminSelectedAnimeId) return;
    setIsSubmitting(true);
    setAdminMsg(null);

    try {
      const currentAnime = animes.find((a) => a.id === adminSelectedAnimeId);
      const nextNum = (currentAnime?.seasons?.length || 0) + 1;

      const res = await fetch(`/api/animes/${adminSelectedAnimeId}/seasons`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          secretCode: SECRET_CODE,
          seasonNumber: nextNum,
          title: newSeasonTitle.trim() || `Season ${nextNum}`,
        }),
      });

      const data = await res.json();
      if (data?.success && data.season) {
        setAnimes((prev) =>
          prev.map((a) => (a.id === adminSelectedAnimeId ? { ...a, seasons: [...(a.seasons || []), data.season] } : a))
        );
        setAdminSelectedSeasonId(data.season.id);
        setNewSeasonTitle('');
        setAdminMsg({ type: 'success', text: `Season ${nextNum} add ho gaya!` });
      }
    } catch {
      setAdminMsg({ type: 'error', text: 'Season add nahi ho saka.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Admin: Add Episode to Selected Season (NO thumbnail!)
  const handleAddEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminSelectedAnimeId || !adminSelectedSeasonId) {
      setAdminMsg({ type: 'error', text: 'Kripya Anime aur Season select karein.' });
      return;
    }
    if (!newEpLink.trim()) {
      setAdminMsg({ type: 'error', text: 'Episode ka video/pCloud link zaroori hai.' });
      return;
    }

    setIsSubmitting(true);
    setAdminMsg(null);

    try {
      const currentAnime = animes.find((a) => a.id === adminSelectedAnimeId);
      const currentSeason = currentAnime?.seasons?.find((s) => s.id === adminSelectedSeasonId);
      const nextEpNum = newEpNumber || (currentSeason?.episodes?.length || 0) + 1;

      const res = await fetch(`/api/animes/${adminSelectedAnimeId}/seasons/${adminSelectedSeasonId}/episodes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          secretCode: SECRET_CODE,
          episodeNumber: nextEpNum,
          title: newEpTitle.trim() || `Episode ${nextEpNum}`,
          link: newEpLink.trim(),
        }),
      });

      const data = await res.json();
      if (data?.success && data.episode) {
        setAnimes((prev) =>
          prev.map((a) => {
            if (a.id !== adminSelectedAnimeId) return a;
            return {
              ...a,
              seasons: a.seasons.map((s) => {
                if (s.id !== adminSelectedSeasonId) return s;
                return { ...s, episodes: [...(s.episodes || []), data.episode] };
              }),
            };
          })
        );
        setAdminMsg({ type: 'success', text: `Episode ${nextEpNum} add ho gaya!` });
        setNewEpLink('');
        setNewEpTitle('');
        setNewEpNumber(nextEpNum + 1);
      } else {
        setAdminMsg({ type: 'error', text: data.error || 'Episode add nahi ho saka.' });
      }
    } catch {
      setAdminMsg({ type: 'error', text: 'Network error. Phir try karein.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Admin: Delete Episode (No window.confirm to avoid iframe blocker)
  const handleDeleteEpisode = async (animeId: string, seasonId: string, epId: string) => {
    try {
      const res = await fetch(`/api/animes/${animeId}/seasons/${seasonId}/episodes/${epId}`, {
        method: 'DELETE',
        headers: { 'x-secret-code': SECRET_CODE },
      });
      const data = await res.json();
      if (data?.success) {
        setAnimes((prev) =>
          prev.map((a) => {
            if (a.id !== animeId) return a;
            return {
              ...a,
              seasons: a.seasons.map((s) => {
                if (s.id !== seasonId) return s;
                return { ...s, episodes: s.episodes.filter((e) => e.id !== epId) };
              }),
            };
          })
        );
        if (selectedEpisode?.id === epId) {
          setSelectedEpisode(null);
        }
        setAdminMsg({ type: 'success', text: 'Episode delete ho gaya!' });
        fetchAnimes();
      } else {
        setAdminMsg({ type: 'error', text: data?.error || 'Episode delete nahi ho saka.' });
      }
    } catch (err) {
      console.error('Failed to delete episode:', err);
      setAdminMsg({ type: 'error', text: 'Episode delete karne mein error aaya.' });
    }
  };

  // Admin: Delete Season
  const handleDeleteSeason = async (animeId: string, seasonId: string) => {
    try {
      const res = await fetch(`/api/animes/${animeId}/seasons/${seasonId}`, {
        method: 'DELETE',
        headers: { 'x-secret-code': SECRET_CODE },
      });
      const data = await res.json();
      if (data?.success) {
        setAnimes((prev) =>
          prev.map((a) => {
            if (a.id !== animeId) return a;
            return {
              ...a,
              seasons: a.seasons.filter((s) => s.id !== seasonId),
            };
          })
        );
        // Switch to remaining season
        const currentA = animes.find((a) => a.id === animeId);
        const remaining = currentA?.seasons.filter((s) => s.id !== seasonId);
        if (remaining && remaining.length > 0) {
          setAdminSelectedSeasonId(remaining[0].id);
        } else {
          setAdminSelectedSeasonId('');
        }
        setAdminMsg({ type: 'success', text: 'Season delete ho gaya!' });
        fetchAnimes();
      } else {
        setAdminMsg({ type: 'error', text: data?.error || 'Season delete nahi ho saka.' });
      }
    } catch (err) {
      console.error('Failed to delete season:', err);
      setAdminMsg({ type: 'error', text: 'Season delete karne mein error aaya.' });
    }
  };

  // Admin: Delete Anime
  const handleDeleteAnime = async (animeId: string) => {
    try {
      const res = await fetch(`/api/animes/${animeId}`, {
        method: 'DELETE',
        headers: { 'x-secret-code': SECRET_CODE },
      });
      const data = await res.json();
      if (data?.success) {
        setAnimes((prev) => prev.filter((a) => a.id !== animeId));
        if (selectedAnime?.id === animeId) {
          setSelectedAnime(null);
          setSelectedEpisode(null);
        }
        setAdminSelectedAnimeId('');
        setAdminMsg({ type: 'success', text: 'Anime delete ho gaya!' });
        fetchAnimes();
      } else {
        setAdminMsg({ type: 'error', text: data?.error || 'Anime delete nahi ho saka.' });
      }
    } catch (err) {
      console.error('Failed to delete anime:', err);
      setAdminMsg({ type: 'error', text: 'Anime delete karne mein error aaya.' });
    }
  };

  // Filtered Anime List for Catalog
  const filteredAnimes = animes.filter((a) => {
    return !appliedSearch || a.title.toLowerCase().includes(appliedSearch.toLowerCase());
  });

  // Filtered animes in the Admin Search Bar
  const adminFilteredAnimes = animes.filter((a) =>
    !adminAnimeSearch || a.title.toLowerCase().includes(adminAnimeSearch.toLowerCase())
  );

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Current active season in details view
  const currentSeason =
    selectedAnime?.seasons?.find((s) => s.seasonNumber === selectedSeasonNumber) ||
    selectedAnime?.seasons?.[0];

  // Currently selected anime in admin panel
  const adminActiveAnime = animes.find((a) => a.id === adminSelectedAnimeId);
  const adminActiveSeason =
    adminActiveAnime?.seasons?.find((s) => s.id === adminSelectedSeasonId) ||
    adminActiveAnime?.seasons?.[0];

  return (
    <div className="min-h-screen bg-[#0d0d0d] text-white flex flex-col font-sans">
      {/* 1. TOP HEADER (Simple & Clean) */}
      <header className="sticky top-0 z-40 bg-[#0d0d0d]/95 backdrop-blur-md border-b border-[#202020] px-4 md:px-6 py-2.5 flex items-center justify-between gap-4">
        {/* Brand */}
        <div
          onClick={() => {
            setSelectedAnime(null);
            setSelectedEpisode(null);
            setAppliedSearch('');
          }}
          className="flex items-center gap-2.5 cursor-pointer group select-none shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-md shadow-red-900/40 group-hover:bg-red-500 transition-colors">
            <Play className="w-4 h-4 fill-white ml-0.5" />
          </div>
          <span className="text-lg font-bold tracking-tight text-white">
            AniStream
          </span>
        </div>

        {/* Center Search (Secret code 8421459082hiteshYS opens admin studio) */}
        <form onSubmit={handleSearchSubmit} className="flex-1 max-w-xl mx-auto flex items-center">
          <div className="relative flex-1 flex items-center bg-[#151515] border border-[#2d2d2d] rounded-full focus-within:border-red-600 px-4 py-1.5 transition-colors">
            <Search className="w-4 h-4 text-zinc-400 mr-2 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search anime..."
              className="w-full bg-transparent text-sm text-white placeholder-zinc-500 focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-zinc-400 hover:text-white p-0.5"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <button
            type="submit"
            className="ml-2 bg-[#202020] hover:bg-[#282828] border border-[#303030] rounded-full p-2 text-zinc-300 hover:text-white transition-colors"
            title="Search"
          >
            <Search className="w-4 h-4" />
          </button>
        </form>

        {/* Right Avatar */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-red-600 to-amber-600 flex items-center justify-center text-xs font-bold text-white shadow-sm">
            U
          </div>
        </div>
      </header>

      {/* 2. BODY CONTENT: EITHER ANIME DETAILS / WATCH VIEW OR HOME CATALOG */}
      {selectedAnime ? (
        /* ================= ANIME DETAIL & EPISODES VIEW ================= */
        <main className="flex-1 max-w-[1400px] w-full mx-auto px-4 md:px-6 py-4 flex flex-col space-y-6">
          {/* Back button */}
          <button
            onClick={() => {
              setSelectedAnime(null);
              setSelectedEpisode(null);
            }}
            className="self-start inline-flex items-center gap-2 text-xs font-medium text-zinc-400 hover:text-white bg-[#1c1c1c] hover:bg-[#252525] px-3.5 py-1.5 rounded-full transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>All Animes</span>
          </button>

          {/* ACTIVE VIDEO PLAYER SECTION (When an episode is chosen) */}
          {selectedEpisode && (
            <div className="space-y-3">
              <div
                ref={playerContainerRef}
                className="relative w-full aspect-video max-h-[70vh] mx-auto bg-black rounded-2xl overflow-hidden shadow-2xl flex items-center justify-center group select-none"
              >
                {isResolving ? (
                  <div className="flex flex-col items-center gap-2 text-zinc-400">
                    <Loader2 className="w-8 h-8 animate-spin text-red-500" />
                    <span className="text-xs font-medium">Episode video load ho rahi hai...</span>
                  </div>
                ) : streamData?.type === 'embed_fallback' && streamData.embed_url ? (
                  <iframe
                    src={streamData.embed_url}
                    title={selectedEpisode.title}
                    className="w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                    allowFullScreen
                  />
                ) : (
                  <video
                    ref={videoRef}
                    src={streamData?.proxy_url || streamData?.stream_url || selectedEpisode.link}
                    className="w-full h-full object-contain cursor-pointer"
                    autoPlay
                    playsInline
                    onClick={togglePlayPause}
                    onTimeUpdate={() => {
                      if (videoRef.current) {
                        setCurrentTime(videoRef.current.currentTime);
                        updateBuffer();
                      }
                    }}
                    onProgress={updateBuffer}
                    onLoadedMetadata={() => {
                      if (videoRef.current) {
                        setDuration(videoRef.current.duration);
                        updateBuffer();
                      }
                    }}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                  />
                )}

                {/* Overlaid Controls */}
                {streamData?.type !== 'embed_fallback' && (
                  <div
                    className={`absolute inset-0 flex flex-col justify-between p-4 bg-gradient-to-t from-black/90 via-transparent to-black/40 transition-opacity duration-300 ${
                      showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
                    }`}
                  >
                    <div className="text-xs font-semibold text-zinc-300 truncate">
                      {selectedAnime.title} — {selectedEpisode.title}
                    </div>

                    {/* Bottom Scrubber & Buttons */}
                    <div className="flex flex-col gap-2">
                      {/* Progressive Scrubber (YouTube style) */}
                      <div className="relative w-full h-2 hover:h-2.5 bg-zinc-800/90 rounded-lg overflow-hidden transition-all flex items-center group/scrub">
                        {/* Progressive buffer chunk */}
                        <div
                          className="absolute top-0 bottom-0 left-0 bg-zinc-500/70 rounded-lg pointer-events-none transition-all duration-300"
                          style={{ width: `${bufferedProgress}%` }}
                        />
                        {/* Played progress */}
                        <div
                          className="absolute top-0 bottom-0 left-0 bg-red-600 rounded-lg pointer-events-none"
                          style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
                        />
                        <input
                          type="range"
                          min={0}
                          max={duration || 100}
                          step={0.1}
                          value={currentTime}
                          onChange={handleSeek}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                      </div>

                      {/* Control buttons */}
                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-3">
                          <button onClick={togglePlayPause} className="p-1.5 text-white hover:text-red-500">
                            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
                          </button>
                          <button
                            onClick={() => {
                              if (videoRef.current) videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10);
                            }}
                            className="p-1 text-zinc-300 hover:text-white"
                            title="Rewind 10s"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (videoRef.current) videoRef.current.currentTime = Math.min(videoRef.current.duration, videoRef.current.currentTime + 10);
                            }}
                            className="p-1 text-zinc-300 hover:text-white"
                            title="Forward 10s"
                          >
                            <FastForward className="w-4 h-4" />
                          </button>
                          <div className="flex items-center gap-2">
                            <button onClick={toggleMute} className="p-1 text-zinc-300 hover:text-white">
                              {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                            </button>
                            <input
                              type="range"
                              min={0}
                              max={1}
                              step={0.05}
                              value={isMuted ? 0 : volume}
                              onChange={handleVolume}
                              className="w-16 h-1 bg-zinc-700 accent-white rounded cursor-pointer"
                            />
                          </div>

                          {/* Full Duration Display */}
                          <span className="text-xs text-zinc-200 font-medium tabular-nums select-none">
                            {formatTime(currentTime)} / {formatTime(duration)}
                          </span>
                        </div>

                        {/* Right: Speed & Fullscreen */}
                        <div className="flex items-center gap-2">
                          <div className="relative">
                            <button
                              onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                              className="px-2 py-1 text-xs text-zinc-300 hover:text-white flex items-center gap-0.5"
                            >
                              <span>{playbackRate}x</span>
                              <ChevronDown className="w-3 h-3" />
                            </button>
                            {showSpeedMenu && (
                              <div className="absolute bottom-8 right-0 bg-[#222222] border border-[#333333] rounded-lg shadow-2xl py-1 w-20 z-50">
                                {[0.5, 0.75, 1, 1.25, 1.5, 2].map((s) => (
                                  <button
                                    key={s}
                                    onClick={() => handleSpeed(s)}
                                    className={`w-full px-3 py-1.5 text-xs text-left ${
                                      playbackRate === s ? 'bg-red-600 text-white font-bold' : 'text-zinc-300 hover:bg-[#333333]'
                                    }`}
                                  >
                                    {s}x
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                          <button onClick={toggleFullscreen} className="p-1.5 text-white hover:text-red-500">
                            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Currently Playing Episode Bar */}
              <div className="flex items-center justify-between bg-[#151515] p-3 rounded-xl border border-[#242424]">
                <div>
                  <h3 className="text-sm font-bold text-white">{selectedEpisode.title}</h3>
                  <p className="text-xs text-zinc-400">
                    {selectedAnime.title} · {currentSeason?.title || `Season ${selectedSeasonNumber}`}
                  </p>
                </div>
                {/* Next Episode button */}
                {currentSeason && (
                  <div className="flex gap-2">
                    {(() => {
                      const epIdx = currentSeason.episodes.findIndex((e) => e.id === selectedEpisode.id);
                      const nextEp = currentSeason.episodes[epIdx + 1];
                      return nextEp ? (
                        <button
                          onClick={() => setSelectedEpisode(nextEp)}
                          className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
                        >
                          <span>Next Episode</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      ) : null;
                    })()}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ANIME DETAILS BANNER */}
          <div className="flex flex-col sm:flex-row gap-5 bg-[#141414] border border-[#222222] p-5 rounded-2xl items-center sm:items-start">
            <div className="w-32 sm:w-40 aspect-[2/3] rounded-xl overflow-hidden bg-zinc-900 shrink-0 shadow-xl border border-[#2a2a2a]">
              <img src={selectedAnime.poster} alt={selectedAnime.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 flex flex-col justify-center space-y-2 text-center sm:text-left">
              <h1 className="text-2xl font-extrabold text-white tracking-tight">{selectedAnime.title}</h1>
              {selectedAnime.description && (
                <p className="text-xs text-zinc-300 leading-relaxed max-w-2xl">{selectedAnime.description}</p>
              )}
              <div className="text-xs text-zinc-400 flex items-center justify-center sm:justify-start gap-2 pt-1 font-medium">
                <span>{selectedAnime.seasons?.length || 1} Seasons</span>
                <span>·</span>
                <span>
                  {selectedAnime.seasons?.reduce((acc, s) => acc + (s.episodes?.length || 0), 0) || 0} Total Episodes
                </span>
              </div>
            </div>
          </div>

          {/* SEASONS & EPISODES (NO THUMBNAILS - ONLY CLEAN SEASON & EPISODES) */}
          <div className="space-y-4">
            {/* Season Selector Tabs (Default Season 1 selected) */}
            <div className="flex items-center justify-between border-b border-[#242424] pb-3">
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
                {selectedAnime.seasons?.map((season) => (
                  <button
                    key={season.id}
                    onClick={() => setSelectedSeasonNumber(season.seasonNumber)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                      selectedSeasonNumber === season.seasonNumber
                        ? 'bg-red-600 text-white shadow-lg shadow-red-950/50 scale-105'
                        : 'bg-[#1e1e1e] text-zinc-300 hover:bg-[#282828] hover:text-white'
                    }`}
                  >
                    {season.title || `Season ${season.seasonNumber}`}
                  </button>
                ))}
              </div>
              <span className="text-xs text-zinc-400">
                {currentSeason?.episodes?.length || 0} Episodes
              </span>
            </div>

            {/* Clean Episode List (No thumbnails - only episode numbers and titles!) */}
            {!currentSeason || currentSeason.episodes.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-zinc-500 bg-[#141414] rounded-2xl border border-[#222222]">
                <ListVideo className="w-10 h-10 mb-2 text-zinc-600" />
                <p className="text-sm font-semibold text-zinc-300">Is Season ke episodes jald hi add honge</p>
                <p className="text-xs text-zinc-500">Admin code search karke episodes add karein.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {currentSeason.episodes.map((ep) => {
                  const isCurrent = selectedEpisode?.id === ep.id;
                  return (
                    <div
                      key={ep.id}
                      onClick={() => setSelectedEpisode(ep)}
                      className={`group cursor-pointer p-3.5 bg-[#141414] border rounded-xl flex items-center justify-between gap-3 transition-all ${
                        isCurrent
                          ? 'border-red-600 bg-[#1c1414] ring-1 ring-red-600/40'
                          : 'border-[#222222] hover:border-zinc-700 hover:bg-[#1a1a1a]'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Clean Episode Number Badge */}
                        <div
                          className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                            isCurrent
                              ? 'bg-red-600 text-white shadow'
                              : 'bg-[#222222] text-zinc-300 group-hover:bg-red-600 group-hover:text-white'
                          }`}
                        >
                          {ep.episodeNumber}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-white truncate group-hover:text-red-400 transition-colors">
                            {ep.title}
                          </h4>
                          <p className="text-[10px] text-zinc-400 mt-0.5">pCloud Streaming</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-xs font-semibold text-red-500 shrink-0">
                        <Play className="w-3.5 h-3.5 fill-red-500" />
                        <span className="text-[11px]">Play</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </main>
      ) : (
        /* ================= ANIME CATALOG GRID (HOME) ================= */
        <main className="flex-1 max-w-[1400px] w-full mx-auto px-4 md:px-6 py-6 flex flex-col space-y-6">
          {appliedSearch && (
            <div className="flex items-center gap-2 text-xs text-zinc-300">
              <span>Search result for: &quot;{appliedSearch}&quot;</span>
              <button onClick={() => setAppliedSearch('')} className="text-red-400 underline">
                Clear
              </button>
            </div>
          )}

          {/* Anime Grid (Only Anime has thumbnail) */}
          {isLoadingFeed ? (
            <div className="flex flex-col items-center justify-center min-h-[40vh] gap-3 text-zinc-400">
              <Loader2 className="w-8 h-8 animate-spin text-red-500" />
              <span className="text-xs">Anime library load ho rahi hai...</span>
            </div>
          ) : filteredAnimes.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[50vh] gap-3 text-zinc-400 bg-[#121212] border border-[#222222] rounded-2xl p-8">
              <Film className="w-12 h-12 text-zinc-600 mb-1" />
              <p className="text-base font-bold text-zinc-200">Abhi koi anime add nahi hua hai</p>
              <p className="text-xs text-zinc-500 text-center max-w-sm">
                Aap search bar mein apna secret code daal kar pehla anime aur uske seasons/episodes add kar sakte hain.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {filteredAnimes.map((anime) => {
                const totalEps = anime.seasons?.reduce((acc, s) => acc + (s.episodes?.length || 0), 0) || 0;
                return (
                  <div
                    key={anime.id}
                    onClick={() => {
                      setSelectedAnime(anime);
                      setSelectedSeasonNumber(1);
                      if (anime.seasons?.[0]?.episodes?.[0]) {
                        setSelectedEpisode(anime.seasons[0].episodes[0]);
                      } else {
                        setSelectedEpisode(null);
                      }
                    }}
                    className="flex flex-col group cursor-pointer"
                  >
                    {/* Poster Card (Vertical Aspect Ratio 2/3) */}
                    <div className="relative aspect-[2/3] w-full rounded-xl overflow-hidden bg-zinc-900 border border-[#222222] group-hover:border-red-600/70 shadow-lg transition-all duration-300">
                      <img
                        src={anime.poster}
                        alt={anime.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {/* Seasons tag */}
                      <div className="absolute top-2 left-2 bg-black/85 backdrop-blur-sm px-2 py-0.5 rounded text-[10px] font-bold text-white">
                        {anime.seasons?.length || 1} Seasons
                      </div>
                      {/* Play hover */}
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <div className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg">
                          <Play className="w-4 h-4 fill-white ml-0.5" />
                        </div>
                      </div>
                    </div>

                    {/* Anime Title & Metadata */}
                    <div className="mt-2">
                      <h3 className="text-xs font-bold text-white line-clamp-1 group-hover:text-red-400 transition-colors">
                        {anime.title}
                      </h3>
                      <p className="text-[11px] text-zinc-400 mt-0.5">{totalEps} Episodes</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      )}

      {/* 3. SECRET ADMIN ANIME STUDIO (Triggered ONLY by entering 8421459082hiteshYS in search) */}
      {isAdminOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-[#2d2d2d] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
            {/* Header */}
            <div className="sticky top-0 bg-[#141414] border-b border-[#252525] px-6 py-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-xs">
                  <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">Anime Creator Studio</h2>
                  <p className="text-xs text-zinc-400">Add animes, seasons & pCloud episodes</p>
                </div>
              </div>
              <button
                onClick={() => setIsAdminOpen(false)}
                className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-[#202020]"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sub-tabs: Add Anime vs Edit Anime */}
            <div className="px-6 pt-3 flex gap-2 border-b border-[#252525]">
              <button
                onClick={() => setAdminMode('add-anime')}
                className={`pb-2.5 text-xs font-bold px-2 border-b-2 transition-colors ${
                  adminMode === 'add-anime'
                    ? 'border-red-600 text-white'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                + Add New Anime
              </button>
              <button
                onClick={() => setAdminMode('edit-anime')}
                className={`pb-2.5 text-xs font-bold px-2 border-b-2 transition-colors ${
                  adminMode === 'edit-anime'
                    ? 'border-red-600 text-white'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                ✏️ Edit Anime & Add Episodes
              </button>
            </div>

            {/* Notification alert */}
            {adminMsg && (
              <div
                className={`mx-6 mt-4 flex items-center gap-2 text-xs px-4 py-2.5 rounded-lg ${
                  adminMsg.type === 'success'
                    ? 'bg-emerald-950/50 border border-emerald-800 text-emerald-300'
                    : 'bg-red-950/50 border border-red-800 text-red-300'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{adminMsg.text}</span>
              </div>
            )}

            {/* TAB 1: ADD NEW ANIME */}
            {adminMode === 'add-anime' ? (
              <form onSubmit={handleCreateAnime} className="p-6 space-y-4">
                {/* Title */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-zinc-300">Anime Name / Title</label>
                  <input
                    type="text"
                    value={newAnimeTitle}
                    onChange={(e) => setNewAnimeTitle(e.target.value)}
                    placeholder="e.g. Naruto Shippuden, Attack on Titan..."
                    className="w-full bg-[#1b1b1b] border border-[#303030] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                    required
                  />
                </div>

                {/* Poster from Gallery (ONLY FOR ANIME CARD) */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-zinc-300">
                    Anime Poster Thumbnail (Main Grid Ke Liye)
                  </label>

                  {/* Hidden Native File Input */}
                  <input
                    ref={posterFileRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePosterUpload}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => posterFileRef.current?.click()}
                    className="w-full flex items-center justify-center gap-2 py-3.5 px-4 border border-dashed border-[#444444] hover:border-red-500 rounded-xl bg-[#1b1b1b] hover:bg-[#222222] text-zinc-200 hover:text-white transition-all text-xs font-semibold cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-red-500" />
                    <span>Device / Phone Gallery se Poster Photo Dalein</span>
                  </button>

                  {/* Poster Preview */}
                  {newAnimePoster && (
                    <div className="relative aspect-[2/3] w-28 mx-auto rounded-lg overflow-hidden border border-[#333333] shadow-md">
                      <img src={newAnimePoster} alt="Poster preview" className="w-full h-full object-cover" />
                    </div>
                  )}

                  {/* Or Custom URL */}
                  <input
                    type="text"
                    value={newAnimePoster}
                    onChange={(e) => setNewAnimePoster(e.target.value)}
                    placeholder="Ya image ka URL yahan paste karein..."
                    className="w-full bg-[#1b1b1b] border border-[#303030] rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                  />
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-zinc-300">Storyline / Description (Optional)</label>
                  <textarea
                    value={newAnimeDesc}
                    onChange={(e) => setNewAnimeDesc(e.target.value)}
                    placeholder="Short storyline ya details likhein..."
                    rows={3}
                    className="w-full bg-[#1b1b1b] border border-[#303030] rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                  />
                </div>

                {/* Submit button */}
                <div className="pt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsAdminOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-zinc-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-red-600 hover:bg-red-500 active:scale-95 text-white px-6 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-lg shadow-red-950/40"
                  >
                    {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    <span>Save Anime</span>
                  </button>
                </div>
              </form>
            ) : (
              /* TAB 2: EDIT ANIME, ADD SEASONS & EPISODES WITH ANIME SEARCH BAR */
              <div className="p-6 space-y-6">
                {/* 1. INTERACTIVE ANIME SEARCH BAR (NOT HTML SELECT) */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-zinc-300">
                    Existing Anime Search Karein
                  </label>
                  <div className="relative">
                    <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={adminAnimeSearch}
                      onChange={(e) => setAdminAnimeSearch(e.target.value)}
                      placeholder="Type anime name to search & select..."
                      className="w-full bg-[#1b1b1b] border border-[#333333] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                    />
                  </div>

                  {/* Matching Animes List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto pt-1">
                    {adminFilteredAnimes.length === 0 ? (
                      <p className="text-xs text-zinc-500 col-span-2 italic py-2">
                        {animes.length === 0 ? 'Pehle "+ Add New Anime" se koi anime add karein.' : 'Koi matching anime nahi mila.'}
                      </p>
                    ) : (
                      adminFilteredAnimes.map((a) => (
                        <div
                          key={a.id}
                          onClick={() => {
                            setAdminSelectedAnimeId(a.id);
                            if (a.seasons?.length) {
                              setAdminSelectedSeasonId(a.seasons[0].id);
                            }
                          }}
                          className={`flex items-center gap-2.5 p-2 rounded-xl border cursor-pointer transition-all ${
                            adminSelectedAnimeId === a.id
                              ? 'border-red-600 bg-[#251515]'
                              : 'border-[#282828] bg-[#181818] hover:bg-[#202020]'
                          }`}
                        >
                          <img src={a.poster} alt={a.title} className="w-8 aspect-[2/3] object-cover rounded" />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold text-white truncate">{a.title}</p>
                            <p className="text-[10px] text-zinc-400">{a.seasons?.length || 1} Seasons</p>
                          </div>
                          {adminSelectedAnimeId === a.id && (
                            <Check className="w-4 h-4 text-red-500 shrink-0" />
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {adminActiveAnime && (
                  <>
                    {/* Active Selected Anime Badge */}
                    <div className="flex items-center justify-between p-3 bg-[#1e1e1e] border border-[#2e2e2e] rounded-xl">
                      <div className="flex items-center gap-3">
                        <img
                          src={adminActiveAnime.poster}
                          alt={adminActiveAnime.title}
                          className="w-10 aspect-[2/3] object-cover rounded-md"
                        />
                        <div>
                          <p className="text-xs font-bold text-white">{adminActiveAnime.title}</p>
                          <p className="text-[11px] text-zinc-400">{adminActiveAnime.seasons?.length || 0} Seasons</p>
                        </div>
                      </div>
                      <span className="text-[11px] text-emerald-400 font-semibold">Active Selected</span>
                    </div>

                    {/* 2. Season Management Strip */}
                    <div className="p-4 bg-[#181818] rounded-xl border border-[#282828] space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <span className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Layers className="w-4 h-4 text-red-500" />
                          <span>Seasons ({adminActiveAnime.seasons?.length || 0})</span>
                        </span>
                        {/* Quick Season Adder */}
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            value={newSeasonTitle}
                            onChange={(e) => setNewSeasonTitle(e.target.value)}
                            placeholder={`Season ${(adminActiveAnime.seasons?.length || 0) + 1}`}
                            className="bg-[#121212] border border-[#333] rounded-lg px-2.5 py-1 text-xs text-white placeholder-zinc-500 focus:outline-none w-28"
                          />
                          <button
                            type="button"
                            onClick={handleAddSeason}
                            disabled={isSubmitting}
                            className="bg-zinc-800 hover:bg-zinc-700 text-white px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" />
                            <span>Add Season</span>
                          </button>
                        </div>
                      </div>

                      {/* Select Season Tabs with individual Delete button */}
                      <div className="flex gap-2 overflow-x-auto pt-1 items-center">
                        {adminActiveAnime.seasons?.map((s) => (
                          <div
                            key={s.id}
                            className={`flex items-center rounded-lg text-xs font-semibold overflow-hidden border shrink-0 ${
                              adminSelectedSeasonId === s.id
                                ? 'bg-red-600 text-white border-red-500 shadow'
                                : 'bg-[#121212] text-zinc-400 border-[#282828] hover:text-white'
                            }`}
                          >
                            <button
                              type="button"
                              onClick={() => setAdminSelectedSeasonId(s.id)}
                              className="px-3 py-1.5 flex items-center gap-1.5"
                            >
                              <span>{s.title || `Season ${s.seasonNumber}`}</span>
                              <span className="text-[10px] opacity-75">({s.episodes?.length || 0})</span>
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteSeason(adminActiveAnime.id, s.id);
                              }}
                              className="px-2 py-1.5 hover:bg-black/40 text-white/70 hover:text-white border-l border-white/20 transition-colors"
                              title={`Delete ${s.title || `Season ${s.seasonNumber}`}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>

                      {/* Active Season Banner with explicit Delete Season button */}
                      {adminActiveSeason && (
                        <div className="flex items-center justify-between pt-1 border-t border-[#222222]">
                          <span className="text-[11px] text-zinc-400">
                            Selected: <b className="text-white">{adminActiveSeason.title || `Season ${adminActiveSeason.seasonNumber}`}</b> ({adminActiveSeason.episodes?.length || 0} episodes)
                          </span>
                          <button
                            type="button"
                            onClick={() => handleDeleteSeason(adminActiveAnime.id, adminActiveSeason.id)}
                            className="px-2.5 py-1 bg-red-950/40 hover:bg-red-900/60 border border-red-800/60 text-red-300 hover:text-white rounded-lg flex items-center gap-1.5 transition-colors text-xs font-semibold cursor-pointer"
                            title="Delete this Season"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete This Season</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* 3. Add Episode to Season Form (NO THUMBNAIL INPUT!) */}
                    <form onSubmit={handleAddEpisode} className="p-4 bg-[#181818] rounded-xl border border-[#282828] space-y-3">
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Play className="w-3.5 h-3.5 text-red-500 fill-red-500" />
                        <span>
                          Add Episode to {adminActiveSeason?.title || 'Selected Season'}
                        </span>
                      </h4>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[11px] font-semibold text-zinc-400">Episode Number</label>
                          <input
                            type="number"
                            min={1}
                            value={newEpNumber}
                            onChange={(e) => setNewEpNumber(Number(e.target.value))}
                            className="w-full bg-[#121212] border border-[#333] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-red-500"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[11px] font-semibold text-zinc-400">Episode Title</label>
                          <input
                            type="text"
                            value={newEpTitle}
                            onChange={(e) => setNewEpTitle(e.target.value)}
                            placeholder="e.g. Episode 1: The Beginning"
                            className="w-full bg-[#121212] border border-[#333] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-red-500"
                          />
                        </div>
                      </div>

                      {/* Video Link */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-zinc-400 flex items-center gap-1">
                          <LinkIcon className="w-3 h-3 text-red-400" />
                          <span>pCloud Link ya Direct Video Stream</span>
                        </label>
                        <input
                          type="text"
                          value={newEpLink}
                          onChange={(e) => setNewEpLink(e.target.value)}
                          placeholder="https://u.pcloud.link/publink/show?code=... ya direct video link"
                          className="w-full bg-[#121212] border border-[#333] rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-red-600 hover:bg-red-500 active:scale-95 text-white py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow"
                      >
                        {isSubmitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                        <span>Save Episode to Season</span>
                      </button>
                    </form>

                    {/* 4. Current Episodes in this Season (With Delete) */}
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-zinc-300">
                        Episodes in {adminActiveSeason?.title || 'this season'}:
                      </span>
                      {(!adminActiveSeason || adminActiveSeason.episodes.length === 0) ? (
                        <p className="text-xs text-zinc-500 italic">Abhi is season mein koi episode nahi hai.</p>
                      ) : (
                        <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                          {adminActiveSeason.episodes.map((ep) => (
                            <div
                              key={ep.id}
                              className="flex items-center justify-between p-2.5 bg-[#181818] border border-[#2a2a2a] rounded-xl text-xs"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <span className="w-6 h-6 rounded bg-red-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0">
                                  {ep.episodeNumber}
                                </span>
                                <div className="min-w-0">
                                  <p className="font-semibold text-white truncate">{ep.title}</p>
                                  <p className="text-[10px] text-zinc-400 truncate">{ep.link}</p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteEpisode(adminActiveAnime.id, adminActiveSeason.id, ep.id);
                                }}
                                className="px-2.5 py-1 bg-red-950/40 hover:bg-red-900/60 border border-red-800/60 text-red-300 hover:text-white rounded-lg flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer text-xs font-semibold"
                                title="Delete episode"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Delete</span>
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Danger Zone: Delete Anime */}
                    <div className="pt-2 border-t border-[#252525] flex justify-between items-center">
                      <span className="text-[11px] text-zinc-500">Anime ko poori tarah hatana ho:</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteAnime(adminActiveAnime.id)}
                        className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 font-semibold"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete &quot;{adminActiveAnime.title}&quot;</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
