import { Canvas } from "@react-three/fiber";
import { useEffect } from "react";
import GameScene from "./game/GameScene";
import Hud from "./components/Hud";
import Screens from "./components/Screens";
import TouchControls from "./components/TouchControls";
import { resumeAudio, startEngine } from "./game/audio";
import { attachInput, resetInput } from "./game/input";
import { startRun, world } from "./game/world";

export default function App() {
  useEffect(() => {
    const cleanup = attachInput((action) => {
      if (action === "confirm") {
        if (world.phase === "menu" || world.phase === "gameover") {
          resetInput();
          resumeAudio();
          startEngine();
          startRun();
        }
      }
    });
    return cleanup;
  }, []);

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-[#05060f] text-white select-none">
      <Canvas
        dpr={[1, 1.8]}
        gl={{ antialias: true, powerPreference: "high-performance" }}
        camera={{ position: [0, 4.2, 11], fov: 62, near: 0.1, far: 900 }}
      >
        <GameScene />
      </Canvas>

      <Hud />
      <Screens />
      <TouchControls />

      {/* cinematic overlays */}
      <div className="pointer-events-none absolute inset-0 z-10 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(2,3,10,0.65)_100%)]" />
      <div className="pointer-events-none absolute inset-0 z-10 opacity-[0.06] bg-[repeating-linear-gradient(to_bottom,rgba(255,255,255,0.6)_0px,rgba(255,255,255,0.6)_1px,transparent_1px,transparent_3px)]" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-24 bg-gradient-to-t from-black/60 to-transparent" />
    </div>
  );
}
