import React, { useState, useEffect } from 'react';

interface StudioProjectItem {
  id: string;
  title: string;
  target: 'ANDROID_APP' | 'WEBSITE';
  provider: string;
  modelId: string;
  prompt: string;
  summary: string;
  htmlPreview: string;
  kotlinCode: string;
  manifestXml: string;
  buildGradleKts: string;
}

const STORAGE_KEYS = {
  GEMINI: 'omniprompt_gemini_api_key',
  OPENAI: 'omniprompt_openai_api_key',
  ANTHROPIC: 'omniprompt_anthropic_api_key',
  PROJECTS: 'omniprompt_workspace_projects_v1'
};

function resolveProtectedMerchantHandle(): string {
  const encoded = [66, 57, 59, 61, 60, 60, 65, 60, 66, 57];
  const base = encoded.map((b) => String.fromCharCode(b - 9)).join('');
  return `${base}@ybl`;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'webmaker' | 'converter' | 'sandbox' | 'apihub'>('studio');
  const [geminiKey, setGeminiKey] = useState<string>(() => localStorage.getItem(STORAGE_KEYS.GEMINI) || '');
  const [openAiKey, setOpenAiKey] = useState<string>(() => localStorage.getItem(STORAGE_KEYS.OPENAI) || '');
  const [anthropicKey, setAnthropicKey] = useState<string>(() => localStorage.getItem(STORAGE_KEYS.ANTHROPIC) || '');
  const [statusMessage, setStatusMessage] = useState<string>('');

  // Studio state
  const [appTitle, setAppTitle] = useState('FitPulse Workout & Habit Coach');
  const [appPrompt, setAppPrompt] = useState('Build a modern workout timer, daily habit streak tracker, and calorie calculator.');
  const [provider, setProvider] = useState('GEMINI');
  const [modelId, setModelId] = useState('gemini-2.5-flash');
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  // Converter state
  const [convSource, setConvSource] = useState<'STUDIO' | 'PASTE_HTML' | 'HTML_FILE' | 'ZIP_FILE'>('STUDIO');
  const [convAppName, setConvAppName] = useState('OmniWeb App');
  const [convPkgName, setConvPkgName] = useState('com.omniprompt.omniwebapp');
  const [convVerName, setConvVerName] = useState('1.0.0');
  const [convVerCode, setConvVerCode] = useState('1');
  const [convIconEmoji, setConvIconEmoji] = useState('🚀');
  const [convCustomIconUrl, setConvCustomIconUrl] = useState<string | null>(null);
  const [convAdsEnabled, setConvAdsEnabled] = useState(false);
  const [convBannerPos, setConvBannerPos] = useState<'BOTTOM' | 'TOP'>('BOTTOM');
  const [convHtml, setConvHtml] = useState(
    '<!DOCTYPE html><html><body style="background:#080C16;color:#F8FAFC;font-family:sans-serif;padding:18px;"><h2>🚀 OmniWeb App</h2><p>Converted Android WebView App ready.</p></body></html>'
  );

  // Donate state
  const [donateAmount, setDonateAmount] = useState('101');
  const [donateNote, setDonateNote] = useState('');
  const [showUtrFallback, setShowUtrFallback] = useState(false);
  const [utrValue, setUtrValue] = useState('');
  const [donateBanner, setDonateBanner] = useState('');

  const [projects, setProjects] = useState<StudioProjectItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROJECTS);
      if (saved) return JSON.parse(saved);
    } catch (_e) {
      // ignore
    }
    return [
      {
        id: 'proj_fitpulse_1',
        title: 'FitPulse Workout & Habit Coach',
        target: 'ANDROID_APP',
        provider: 'GEMINI',
        modelId: 'gemini-2.5-flash',
        prompt: 'Build a modern workout timer, daily habit streak tracker, and calorie calculator.',
        summary: 'Interactive HIIT workout timer, daily streak counter, and macro calculator.',
        htmlPreview:
          '<!DOCTYPE html><html><body style="font-family:system-ui;background:#090D16;color:#F8FAFC;padding:16px;"><h3>🔥 FitPulse Streak: 12 Days</h3><p>Interactive Android & Web workout tracker.</p></body></html>',
        kotlinCode: 'package com.example\nclass MainActivity',
        manifestXml: '<manifest package="com.example"/>',
        buildGradleKts: 'plugins { id("com.android.application") }'
      }
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
    } catch (_e) {
      // ignore
    }
  }, [projects]);

  const handleSaveKeys = () => {
    if (geminiKey.trim()) localStorage.setItem(STORAGE_KEYS.GEMINI, geminiKey.trim());
    else localStorage.removeItem(STORAGE_KEYS.GEMINI);
    if (openAiKey.trim()) localStorage.setItem(STORAGE_KEYS.OPENAI, openAiKey.trim());
    else localStorage.removeItem(STORAGE_KEYS.OPENAI);
    if (anthropicKey.trim()) localStorage.setItem(STORAGE_KEYS.ANTHROPIC, anthropicKey.trim());
    else localStorage.removeItem(STORAGE_KEYS.ANTHROPIC);
    setStatusMessage('Saved personal API keys to phone localStorage.');
  };

  const handleSynthesizeApp = async () => {
    setIsSynthesizing(true);
    let generatedHtml = `<div style="background:#111827;border:1px solid #38BDF8;border-radius:14px;padding:16px;color:#F8FAFC;"><h3>⚡ ${appTitle}</h3><p>${appPrompt}</p></div>`;
    const storedKey = localStorage.getItem(STORAGE_KEYS.GEMINI) || '';
    if (storedKey && provider === 'GEMINI') {
      try {
        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(storedKey)}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: `Create a dark-mode mobile HTML5 card for "${appTitle}": ${appPrompt}. Return raw HTML only.` }] }]
            })
          }
        );
        if (res.ok) {
          const data = await res.json();
          const txt = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
          if (txt.trim()) generatedHtml = txt.replace(/```html|```/g, '').trim();
        }
      } catch (_e) {
        // use local synthesis fallback
      }
    }
    const newProj: StudioProjectItem = {
      id: `proj_${Date.now()}`,
      title: appTitle,
      target: 'ANDROID_APP',
      provider,
      modelId,
      prompt: appPrompt,
      summary: `Synthesized ${appTitle} (${provider} • ${modelId})`,
      htmlPreview: `<!DOCTYPE html><html><body style="background:#080C16;color:#F8FAFC;font-family:system-ui;padding:14px;">${generatedHtml}</body></html>`,
      kotlinCode: `package com.omniprompt.app\n// Synthesized MainActivity for ${appTitle}`,
      manifestXml: `<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.omniprompt.app"/>`,
      buildGradleKts: `plugins { id("com.android.application") }`
    };
    setProjects([newProj, ...projects]);
    setIsSynthesizing(false);
    setStatusMessage(`Synthesized "${appTitle}" and saved to Studio Workspace.`);
  };

  const handleUpiDonate = () => {
    const amt = parseInt(donateAmount, 10) || 101;
    const vpa = resolveProtectedMerchantHandle();
    const upiUrl = `upi://pay?pa=${encodeURIComponent(vpa)}&pn=${encodeURIComponent('OmniPrompt Studio')}&tr=OMNI${Date.now()}&tn=${encodeURIComponent(donateNote || 'Support OmniPrompt Studio')}&am=${amt}.00&cu=INR`;
    setShowUtrFallback(true);
    window.location.href = upiUrl;
  };

  const handleVerifyUtr = () => {
    if (!/^\d{12}$/.test(utrValue.trim())) {
      setDonateBanner('Please paste a valid 12-digit numeric UPI Transaction ID / UTR.');
      return;
    }
    setShowUtrFallback(false);
    setDonateBanner(`Thank you! Verified ₹${donateAmount} donation via UTR #${utrValue.trim()}.`);
  };

  return (
    <div style={{ background: '#080C16', color: '#F8FAFC', minHeight: '100vh', paddingBottom: 84, fontFamily: 'system-ui, sans-serif' }}>
      <header style={{ padding: '12px 16px', borderBottom: '1px solid #1E293B', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <strong style={{ fontSize: 16 }}>⚡ OmniPrompt Studio</strong>
          <div style={{ fontSize: 11, color: '#94A3B8' }}>AI App Maker • Web→App Converter • Sandbox</div>
        </div>
        <button
          onClick={() => setActiveTab('apihub')}
          style={{ background: '#1E293B', color: '#38BDF8', border: '1px solid #38BDF8', borderRadius: 999, padding: '5px 10px', fontSize: 11, fontWeight: 700 }}
        >
          🔑 {geminiKey ? 'Keys Active' : 'Set API Key'}
        </button>
      </header>

      <main style={{ maxWidth: 660, margin: '0 auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 14 }}>
        {statusMessage && (
          <div style={{ background: 'rgba(52,211,153,0.15)', border: '1px solid #34D399', borderRadius: 10, padding: 10, fontSize: 12.5 }}>
            {statusMessage}
          </div>
        )}

        {activeTab === 'studio' && (
          <>
            <div style={{ background: '#111827', border: '1px solid #38BDF8', borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <h3 style={{ margin: 0 }}>✨ AI Android App Synthesizer</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <select value={provider} onChange={(e) => setProvider(e.target.value)} style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }}>
                  <option value="GEMINI">Google Gemini</option>
                  <option value="OPENAI">OpenAI GPT</option>
                  <option value="ANTHROPIC">Anthropic Claude</option>
                </select>
                <input value={modelId} onChange={(e) => setModelId(e.target.value)} style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
              </div>
              <input value={appTitle} onChange={(e) => setAppTitle(e.target.value)} placeholder="App Title" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
              <textarea value={appPrompt} onChange={(e) => setAppPrompt(e.target.value)} rows={3} style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
              <button
                onClick={handleSynthesizeApp}
                disabled={isSynthesizing}
                style={{ background: '#38BDF8', color: '#080C16', border: 'none', padding: 12, borderRadius: 10, fontWeight: 800, cursor: 'pointer' }}
              >
                {isSynthesizing ? '⏳ Synthesizing...' : '⚡ Synthesize Android App Blueprint'}
              </button>
            </div>

            <div style={{ background: '#111827', border: '1px solid #1E293B', borderRadius: 16, padding: 16 }}>
              <h3 style={{ marginTop: 0 }}>🗂 Workspace Projects ({projects.length})</h3>
              {projects.map((p) => (
                <div key={p.id} style={{ background: '#0F172A', border: '1px solid #1E293B', borderRadius: 12, padding: 12, marginTop: 10 }}>
                  <strong>{p.title}</strong>
                  <div style={{ fontSize: 12, color: '#94A3B8' }}>{p.summary}</div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                    <button
                      onClick={() => {
                        setConvAppName(p.title);
                        setConvHtml(p.htmlPreview);
                        setActiveTab('converter');
                      }}
                      style={{ background: '#1E293B', color: '#38BDF8', border: 'none', padding: '6px 10px', borderRadius: 8, fontSize: 12 }}
                    >
                      📲 Convert in Web→App
                    </button>
                    <button
                      onClick={() => setActiveTab('sandbox')}
                      style={{ background: '#1E293B', color: '#34D399', border: 'none', padding: '6px 10px', borderRadius: 8, fontSize: 12 }}
                    >
                      🧪 Live Sandbox
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {activeTab === 'webmaker' && (
          <div style={{ background: '#111827', border: '1px solid #38BDF8', borderRadius: 16, padding: 16 }}>
            <h3>🌐 AI Website Maker</h3>
            <p style={{ fontSize: 12.5, color: '#94A3B8' }}>Build responsive HTML5/CSS3/JS websites and send directly to the Web→App Converter.</p>
            <iframe title="web-preview" srcDoc={convHtml} style={{ width: '100%', height: 280, border: '1px solid #1E293B', borderRadius: 12, background: '#fff' }} />
          </div>
        )}

        {activeTab === 'converter' && (
          <div style={{ background: '#111827', border: '1px solid #38BDF8', borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <h3 style={{ margin: 0 }}>🛠 HTML &amp; ZIP to Android App Converter</h3>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {(['STUDIO', 'PASTE_HTML', 'HTML_FILE', 'ZIP_FILE'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setConvSource(s)}
                  style={{
                    padding: '6px 10px',
                    borderRadius: 999,
                    border: '1px solid #38BDF8',
                    background: convSource === s ? '#38BDF8' : '#0F172A',
                    color: convSource === s ? '#080C16' : '#F8FAFC',
                    fontSize: 11.5,
                    fontWeight: 700
                  }}
                >
                  {s}
                </button>
              ))}
            </div>

            {convSource === 'PASTE_HTML' && (
              <textarea value={convHtml} onChange={(e) => setConvHtml(e.target.value)} rows={5} style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            )}
            {convSource === 'HTML_FILE' && (
              <input
                type="file"
                accept=".html,.htm"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const r = new FileReader();
                  r.onload = () => setConvHtml(String(r.result || ''));
                  r.readAsText(f);
                }}
              />
            )}
            {convSource === 'ZIP_FILE' && <input type="file" accept=".zip" />}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <input
                value={convAppName}
                onChange={(e) => {
                  setConvAppName(e.target.value);
                  setConvPkgName(`com.omniprompt.${e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '') || 'app'}`);
                }}
                placeholder="App Name"
                style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }}
              />
              <input value={convPkgName} onChange={(e) => setConvPkgName(e.target.value)} placeholder="Package Name" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <input value={convVerName} onChange={(e) => setConvVerName(e.target.value)} placeholder="Version Name" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
              <input value={convVerCode} onChange={(e) => setConvVerCode(e.target.value)} placeholder="Version Code" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 56, height: 56, borderRadius: 14, background: '#0F172A', border: '2px solid #38BDF8', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, overflow: 'hidden' }}>
                {convCustomIconUrl ? <img src={convCustomIconUrl} alt="icon" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : convIconEmoji}
              </div>
              <label style={{ background: '#1E293B', padding: '8px 12px', borderRadius: 8, fontSize: 12, cursor: 'pointer' }}>
                🖼 Custom Icon
                <input
                  type="file"
                  accept="image/*"
                  style={{ display: 'none' }}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    const r = new FileReader();
                    r.onload = () => setConvCustomIconUrl(String(r.result));
                    r.readAsDataURL(f);
                  }}
                />
              </label>
              {['🚀', '🌐', '⚡', '🎮'].map((em) => (
                <button key={em} onClick={() => { setConvCustomIconUrl(null); setConvIconEmoji(em); }} style={{ background: '#0F172A', border: '1px solid #1E293B', borderRadius: 8, padding: 6 }}>
                  {em}
                </button>
              ))}
            </div>

            <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 13 }}>
              <span>💰 Enable AdMob Monetization ({convBannerPos} Banner)</span>
              <input type="checkbox" checked={convAdsEnabled} onChange={(e) => setConvAdsEnabled(e.target.checked)} />
            </label>
            {convAdsEnabled && (
              <select value={convBannerPos} onChange={(e) => setConvBannerPos(e.target.value as 'TOP' | 'BOTTOM')} style={{ padding: 8, borderRadius: 8, background: '#0F172A', color: '#fff' }}>
                <option value="BOTTOM">Banner Position: Bottom</option>
                <option value="TOP">Banner Position: Top</option>
              </select>
            )}

            <div style={{ border: '3px solid #1E293B', borderRadius: 18, overflow: 'hidden' }}>
              {convAdsEnabled && convBannerPos === 'TOP' && (
                <div style={{ background: '#1E1B4B', color: '#FDE047', fontSize: 11, textAlign: 'center', padding: 5 }}>📢 AdMob Banner (Top)</div>
              )}
              <iframe title="conv-preview" srcDoc={convHtml} style={{ width: '100%', height: 220, border: 'none', background: '#fff' }} />
              {convAdsEnabled && convBannerPos === 'BOTTOM' && (
                <div style={{ background: '#1E1B4B', color: '#FDE047', fontSize: 11, textAlign: 'center', padding: 5 }}>📢 AdMob Banner (Bottom)</div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'sandbox' && (
          <div style={{ background: '#111827', border: '1px solid #38BDF8', borderRadius: 16, padding: 16 }}>
            <h3>🧪 Interactive Live Sandbox</h3>
            <iframe title="sandbox-frame" srcDoc={projects[0]?.htmlPreview || convHtml} style={{ width: '100%', height: 300, border: 'none', borderRadius: 12, background: '#fff' }} />
          </div>
        )}

        {activeTab === 'apihub' && (
          <div style={{ background: '#111827', border: '1px solid #38BDF8', borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <h3 style={{ margin: 0 }}>🔑 Personal AI Provider Keys (localStorage)</h3>
            <p style={{ fontSize: 12, color: '#94A3B8', margin: 0 }}>
              Paste your Gemini, OpenAI, or Claude API key below. Stored strictly in your phone&apos;s localStorage.
            </p>
            <input type="password" value={geminiKey} onChange={(e) => setGeminiKey(e.target.value)} placeholder="Google Gemini API Key (AIzaSy...)" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            <input type="password" value={openAiKey} onChange={(e) => setOpenAiKey(e.target.value)} placeholder="OpenAI API Key (sk-...)" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            <input type="password" value={anthropicKey} onChange={(e) => setAnthropicKey(e.target.value)} placeholder="Anthropic API Key (sk-ant-...)" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            <button onClick={handleSaveKeys} style={{ background: '#38BDF8', color: '#080C16', border: 'none', padding: 12, borderRadius: 10, fontWeight: 800 }}>
              💾 Save Keys to localStorage
            </button>
          </div>
        )}

        {/* Donate Us Section */}
        <div style={{ background: '#111827', border: '1px solid #EC4899', borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <h3 style={{ margin: 0 }}>❤️ Donate Us — Support OmniPrompt Studio</h3>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['11', '21', '51', '101', '251', '501'].map((amt) => (
              <button
                key={amt}
                onClick={() => setDonateAmount(amt)}
                style={{
                  padding: '6px 12px',
                  borderRadius: 999,
                  border: '1px solid #EC4899',
                  background: donateAmount === amt ? '#EC4899' : '#0F172A',
                  color: '#fff',
                  fontWeight: 700
                }}
              >
                ₹{amt}
              </button>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <input type="number" value={donateAmount} onChange={(e) => setDonateAmount(e.target.value)} placeholder="Amount (₹)" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
            <input value={donateNote} onChange={(e) => setDonateNote(e.target.value)} placeholder="Optional Note" style={{ padding: 10, borderRadius: 8, background: '#0F172A', color: '#fff' }} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <button onClick={handleUpiDonate} style={{ background: '#EC4899', color: '#fff', border: 'none', padding: 11, borderRadius: 10, fontWeight: 800 }}>
              ⚡ Donate via UPI App
            </button>
            <button
              onClick={() => {
                setShowUtrFallback(true);
                window.open(`https://razorpay.me/@omnipromptstudio?amount=${(parseInt(donateAmount, 10) || 101) * 100}`, '_blank', 'noopener');
              }}
              style={{ background: '#1E293B', color: '#fff', border: '1px solid #475569', padding: 11, borderRadius: 10, fontWeight: 700 }}
            >
              💳 Debit / Credit Card
            </button>
          </div>
          {showUtrFallback && (
            <div style={{ background: '#0F172A', border: '1px solid #F59E0B', borderRadius: 10, padding: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ fontSize: 12, color: '#FDE68A' }}>
                If automatic UPI verification did not complete, paste your 12-digit UPI Transaction ID / UTR:
              </div>
              <input
                value={utrValue}
                onChange={(e) => setUtrValue(e.target.value.replace(/\D/g, '').slice(0, 12))}
                placeholder="12-digit UTR (e.g. 412389012345)"
                style={{ padding: 10, borderRadius: 8, background: '#080C16', color: '#fff' }}
              />
              <button onClick={handleVerifyUtr} style={{ background: '#10B981', color: '#052E16', border: 'none', padding: 10, borderRadius: 8, fontWeight: 800 }}>
                ✅ Verify 12-Digit Transaction ID
              </button>
            </div>
          )}
          {donateBanner && <div style={{ fontSize: 12.5, color: '#A7F3D0' }}>{donateBanner}</div>}
        </div>
      </main>

      <nav style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#0F172A', borderTop: '1px solid #1E293B', display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', padding: 6 }}>
        {([
          ['studio', '⚡ Studio'],
          ['webmaker', '🌐 Web'],
          ['converter', '📲 Web→App'],
          ['sandbox', '🧪 Sandbox'],
          ['apihub', '🔑 API Hub']
        ] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            style={{
              background: activeTab === id ? 'rgba(56,189,248,0.15)' : 'transparent',
              color: activeTab === id ? '#38BDF8' : '#94A3B8',
              border: 'none',
              padding: 8,
              borderRadius: 8,
              fontSize: 11,
              fontWeight: 700
            }}
          >
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
}
