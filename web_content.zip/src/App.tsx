import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  FileCode2,
  Menu,
  MessageSquare,
  Paperclip,
  Phone,
  RotateCcw,
  Send,
  Square,
  Video,
  X,
} from 'lucide-react';
import { MarkdownCodeView } from './components/MarkdownCodeView';
import { VoiceCallView } from './components/VoiceCallView';
import { HistoryDrawer } from './components/HistoryDrawer';
import { OnboardingSetup } from './components/OnboardingSetup';
import { NexcodeLogo } from './components/NexcodeLogo';
import {
  computeRmsLevel,
  downsampleTo16kPcm16Base64,
  pcm16Base64ToAudioBuffer,
} from './utils/audioUtils';
import { robustCopyToClipboard } from './utils/clipboardUtils';
import { prepareMediaAttachment } from './utils/mediaUtils';
import {
  getNativeAndroidCapabilities,
  isNativeAndroidCameraAvailable,
  isNativeAndroidScreenShareAvailable,
  pauseNativeAndroidScreenShare,
  requestNativeAndroidCameraFrameNow,
  requestNativeAndroidFrameNow,
  requestNativeOverlayPermission,
  resumeNativeAndroidScreenShare,
  startNativeAndroidCamera,
  startNativeAndroidScreenShare,
  stopNativeAndroidCamera,
  stopNativeAndroidScreenShare,
  switchNativeAndroidCameraLens,
} from './utils/androidBridge';
import type {
  ChatMessage,
  ClipboardSnippet,
  HistorySession,
  MediaAttachment,
  PermissionStatusMap,
  ScreenShareSource,
  ScreenShareStatus,
  WorkspaceTab,
} from './types';

const STORAGE_KEYS = {
  SESSIONS: 'nexcode_history_sessions_v1',
  LANGUAGE: 'nexcode_preferred_language_v1',
  ONBOARDED: 'nexcode_onboarding_done_v1',
};

const safeStorageGet = (key: string): string | null => {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
};

const safeStorageSet = (key: string, value: string): void => {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Ignore restricted storage errors
  }
};

export default function App() {
  const [onboarded, setOnboarded] = useState<boolean>(() => {
    return safeStorageGet(STORAGE_KEYS.ONBOARDED) === 'true';
  });
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('chat');
  const [language, setLanguage] = useState<string>(() => {
    return safeStorageGet(STORAGE_KEYS.LANGUAGE) || 'English';
  });
  const [assistantSpeaking, setAssistantSpeaking] = useState(false);

  const [historyOpen, setHistoryOpen] = useState(false);
  const [screenImagePreviewUrl, setScreenImagePreviewUrl] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<PermissionStatusMap>({
    microphone: 'prompt',
    screenShare: 'idle',
    clipboard: 'prompt',
    overlayPiP: 'unsupported',
  });

  // Toast feedback
  const [toast, setToast] = useState<{
    message: string;
    copyText?: string;
    copyLabel?: string;
  } | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const showToast = useCallback(
    (message: string, copyAction?: { text: string; label: string }) => {
      setToast({
        message,
        copyText: copyAction?.text,
        copyLabel: copyAction?.label,
      });
      if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
      toastTimerRef.current = window.setTimeout(() => setToast(null), 4000);
    },
    []
  );

  // Chat state
  const [sessionId, setSessionId] = useState<string>(() => `sess-${Date.now()}`);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [pendingAttachment, setPendingAttachment] = useState<MediaAttachment | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // History
  const [sessions, setSessions] = useState<HistorySession[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
      return raw ? (JSON.parse(raw) as HistorySession[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    safeStorageSet(STORAGE_KEYS.LANGUAGE, language);
  }, [language]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions.slice(0, 40)));
    } catch {
      // Ignore storage quota errors
    }
  }, [sessions]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, chatLoading]);

  useEffect(() => {
    if (navigator.permissions) {
      navigator.permissions
        .query({ name: 'microphone' as PermissionName })
        .then((res) => {
          setPermissions((prev) => ({
            ...prev,
            microphone:
              res.state === 'granted' ? 'granted' : res.state === 'denied' ? 'denied' : 'prompt',
          }));
        })
        .catch(() => {});
    }
  }, []);

  const copyToSystemClipboard = useCallback(
    async (text: string, label = 'Snippet', auto = false) => {
      const result = await robustCopyToClipboard(text);
      if (result.ok) {
        setPermissions((prev) => ({ ...prev, clipboard: 'granted' }));
        showToast(auto ? `Added "${label}" to clipboard` : `Copied "${label}"`);
      } else {
        showToast(`"${label}" ready — tap Copy`, { text, label });
      }
      return result.ok;
    },
    [showToast]
  );

  const recordClipboardSnippet = useCallback(
    async (item: { title: string; language: string; code: string }, auto = false) => {
      const copiedOk = auto
        ? await copyToSystemClipboard(item.code, item.title, true)
        : false;
      const snippet: ClipboardSnippet = {
        id: `clip-${Date.now()}`,
        title: item.title,
        language: item.language,
        code: item.code,
        createdAt: Date.now(),
        autoCopied: copiedOk,
      };
      return snippet;
    },
    [copyToSystemClipboard]
  );

  // Live Call refs & state
  const [callLanguage, setCallLanguage] = useState<string>('English');
  const callLanguageRef = useRef<string>('English');
  const [callTranscript, setCallTranscript] = useState<ChatMessage[]>([]);
  const callTranscriptRef = useRef<ChatMessage[]>([]);
  const userTranscriptSwitchBufRef = useRef<string>('');
  const wsRef = useRef<WebSocket | null>(null);

  const appendCallTranscript = useCallback((role: 'user' | 'assistant', chunkText: string) => {
    if (!chunkText) return;
    setCallTranscript((prev) => {
      const last = prev[prev.length - 1];
      let next: ChatMessage[];
      if (last && last.role === role && Date.now() - last.timestamp < 8000) {
        next = [
          ...prev.slice(0, -1),
          { ...last, text: `${last.text}${last.text.endsWith(' ') ? '' : ' '}${chunkText}`.trim() },
        ];
      } else {
        next = [
          ...prev,
          {
            id: `ct-${Date.now()}-${Math.random()}`,
            role,
            text: chunkText.trim(),
            timestamp: Date.now(),
          },
        ];
      }
      callTranscriptRef.current = next;
      return next;
    });
  }, []);

  // Screen Sharing & Fast Camera Vision State
  const [visualMode, setVisualMode] = useState<'none' | 'screen' | 'camera'>('none');
  const [screenShareSource, setScreenShareSource] = useState<ScreenShareSource>('none');
  const screenShareSourceRef = useRef<ScreenShareSource>('none');
  const [screenShareStatus, setScreenShareStatus] = useState<ScreenShareStatus>('idle');
  const screenShareStatusRef = useRef<ScreenShareStatus>('idle');
  const [screenShareError, setScreenShareError] = useState<string | null>(null);
  const [visionFrameCount, setVisionFrameCount] = useState<number>(0);
  const [lastVisionTimestamp, setLastVisionTimestamp] = useState<number | null>(null);
  const [nativeAndroidAvailable] = useState<boolean>(() => isNativeAndroidScreenShareAvailable());
  const [nativeCameraXAvailable] = useState<boolean>(() => isNativeAndroidCameraAvailable());
  const [nativeOverlayGranted, setNativeOverlayGranted] = useState<boolean>(() => {
    return Boolean(getNativeAndroidCapabilities()?.overlayPermission);
  });

  const screenStreamRef = useRef<MediaStream | null>(null);
  const latestScreenFrameRef = useRef<string | null>(null);
  const callScreenVideoRef = useRef<HTMLVideoElement | null>(null);
  const hiddenCaptureVideoRef = useRef<HTMLVideoElement | null>(null);
  const cameraFacingRef = useRef<'environment' | 'user'>('environment');

  const syncShareMeta = useCallback((source: ScreenShareSource, status: ScreenShareStatus) => {
    screenShareSourceRef.current = source;
    screenShareStatusRef.current = status;
    setScreenShareSource(source);
    setScreenShareStatus(status);
  }, []);

  const captureScreenFrameBase64 = useCallback((): string | null => {
    if (
      screenShareSourceRef.current === 'android_mediaprojection' ||
      screenShareSourceRef.current === 'android_camerax'
    ) {
      return null;
    }
    const video =
      hiddenCaptureVideoRef.current &&
      hiddenCaptureVideoRef.current.readyState >= 2 &&
      hiddenCaptureVideoRef.current.videoWidth > 0
        ? hiddenCaptureVideoRef.current
        : callScreenVideoRef.current;

    if (!video || video.readyState < 2 || video.videoWidth === 0) {
      return null;
    }
    const maxW = 960;
    const scale = Math.min(1, maxW / video.videoWidth);
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
    const base64 = dataUrl.split(',')[1] || null;
    if (base64) {
      latestScreenFrameRef.current = base64;
    }
    return base64;
  }, []);

  const stopVisualShare = useCallback(
    (notifyNative = true) => {
      if (notifyNative) {
        if (screenShareSourceRef.current === 'android_mediaprojection') {
          stopNativeAndroidScreenShare();
        } else if (screenShareSourceRef.current === 'android_camerax') {
          stopNativeAndroidCamera();
        }
      }
      screenStreamRef.current?.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
      latestScreenFrameRef.current = null;

      if (callScreenVideoRef.current) {
        callScreenVideoRef.current.srcObject = null;
        callScreenVideoRef.current.removeAttribute('src');
      }
      if (hiddenCaptureVideoRef.current) {
        hiddenCaptureVideoRef.current.srcObject = null;
        hiddenCaptureVideoRef.current.removeAttribute('src');
      }
      setScreenImagePreviewUrl(null);
      setVisualMode('none');
      syncShareMeta('none', 'idle');
      setVisionFrameCount(0);
      setLastVisionTimestamp(null);
      setPermissions((prev) => ({
        ...prev,
        screenShare: 'idle',
      }));
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'screen_state', state: 'stopped' }));
      }
    },
    [syncShareMeta]
  );

  // Wire Native Android MediaProjection + CameraX WebView Bridge Callbacks
  useEffect(() => {
    if (!nativeAndroidAvailable) return;

    window.__onAndroidScreenFrame = (base64Jpeg: string, width: number, height: number, ts: number) => {
      if (!base64Jpeg) return;
      latestScreenFrameRef.current = base64Jpeg;
      setScreenImagePreviewUrl(`data:image/jpeg;base64,${base64Jpeg}`);

      if (
        screenShareStatusRef.current !== 'paused' &&
        wsRef.current?.readyState === WebSocket.OPEN
      ) {
        wsRef.current.send(
          JSON.stringify({
            type: 'video',
            data: base64Jpeg,
            source: 'android_mediaprojection',
            width,
            height,
            ts,
          })
        );
      }
    };

    window.__onAndroidScreenState = (payload) => {
      if (payload.status === 'requesting') {
        syncShareMeta('android_mediaprojection', 'requesting');
        setScreenShareError(null);
      } else if (payload.status === 'active') {
        setVisualMode('screen');
        syncShareMeta('android_mediaprojection', 'active');
        setScreenShareError(null);
        setPermissions((prev) => ({ ...prev, screenShare: 'active' }));
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              type: 'screen_state',
              state: 'active',
              source: 'android_mediaprojection',
            })
          );
        }
        if (payload.message) {
          showToast(payload.message);
        }
      } else if (payload.status === 'paused') {
        syncShareMeta('android_mediaprojection', 'paused');
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              type: 'screen_state',
              state: 'paused',
              source: 'android_mediaprojection',
            })
          );
        }
        showToast('Screen sharing paused');
      } else if (payload.status === 'stopped') {
        stopVisualShare(false);
        if (payload.message) {
          showToast(payload.message);
        }
      } else if (payload.status === 'error') {
        syncShareMeta('none', 'error');
        setScreenShareError(payload.message || 'Android screen sharing failed.');
      }
    };

    window.__onAndroidScreenError = (message: string) => {
      syncShareMeta('none', 'error');
      setScreenShareError(message || 'Could not capture Android screen.');
      setVisualMode('none');
    };

    window.__onAndroidCapabilities = (caps) => {
      setNativeOverlayGranted(Boolean(caps.overlayPermission));
    };

    window.__onAndroidCameraFrame = (
      base64Jpeg: string,
      width: number,
      height: number,
      ts: number,
      forAiVision = true
    ) => {
      if (!base64Jpeg) return;
      latestScreenFrameRef.current = base64Jpeg;
      setScreenImagePreviewUrl(`data:image/jpeg;base64,${base64Jpeg}`);
      if (forAiVision && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'video',
            data: base64Jpeg,
            source: 'android_camerax',
            width,
            height,
            ts,
          })
        );
      }
    };

    window.__onAndroidCameraState = (payload) => {
      if (payload.status === 'active') {
        setVisualMode('camera');
        syncShareMeta('android_camerax', 'active');
        setScreenShareError(null);
        setPermissions((prev) => ({ ...prev, screenShare: 'active' }));
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              type: 'screen_state',
              state: 'active',
              source: 'android_camerax',
            })
          );
        }
      } else if (payload.status === 'stopped') {
        stopVisualShare(false);
      } else if (payload.status === 'error') {
        syncShareMeta('none', 'error');
        setScreenShareError(payload.message || 'CameraX failed to start.');
        setVisualMode('none');
      }
    };

    window.__onAndroidCameraError = (msg: string) => {
      syncShareMeta('none', 'error');
      setScreenShareError(msg || 'Camera error on Android.');
      setVisualMode('none');
    };

    return () => {
      window.__onAndroidScreenFrame = undefined;
      window.__onAndroidScreenState = undefined;
      window.__onAndroidScreenError = undefined;
      window.__onAndroidCapabilities = undefined;
      window.__onAndroidCameraFrame = undefined;
      window.__onAndroidCameraState = undefined;
      window.__onAndroidCameraError = undefined;
    };
  }, [nativeAndroidAvailable, showToast, stopVisualShare, syncShareMeta]);

  const bindVideoPreviewElement = useCallback(
    (videoEl: HTMLVideoElement | null, stream: MediaStream | null) => {
      if (!videoEl) return;
      videoEl.muted = true;
      videoEl.playsInline = true;
      videoEl.autoplay = true;

      if (stream) {
        if (videoEl.srcObject !== stream) {
          videoEl.removeAttribute('src');
          videoEl.srcObject = stream;
        }
      } else {
        videoEl.srcObject = null;
        videoEl.removeAttribute('src');
        return;
      }

      const tryPlay = () => {
        void videoEl.play().catch(() => {});
      };
      if (videoEl.readyState >= 1) {
        tryPlay();
      } else {
        videoEl.onloadedmetadata = tryPlay;
      }
    },
    []
  );

  const attachMediaStreamToPreviews = useCallback(
    (stream: MediaStream, mode: 'camera', source: ScreenShareSource, label: string) => {
      if (screenShareSourceRef.current === 'android_mediaprojection') {
        stopNativeAndroidScreenShare();
      } else if (screenShareSourceRef.current === 'android_camerax') {
        stopNativeAndroidCamera();
      }
      screenStreamRef.current?.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = stream;
      setScreenImagePreviewUrl(null);
      setScreenShareError(null);

      bindVideoPreviewElement(callScreenVideoRef.current, stream);
      bindVideoPreviewElement(hiddenCaptureVideoRef.current, stream);

      setVisualMode(mode);
      syncShareMeta(source, 'active');
      setPermissions((prev) => ({ ...prev, screenShare: 'active' }));
      showToast(label);

      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'screen_state', state: 'active', source }));
      }

      window.setTimeout(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          const frame = captureScreenFrameBase64();
          if (frame) {
            wsRef.current.send(
              JSON.stringify({ type: 'video', data: frame, source, ts: Date.now() })
            );
          }
        }
      }, 280);

      const primaryTrack = stream.getVideoTracks()[0];
      if (primaryTrack) {
        primaryTrack.onended = () => {
          stopVisualShare();
        };
      }
    },
    [bindVideoPreviewElement, captureScreenFrameBase64, showToast, stopVisualShare, syncShareMeta]
  );

  const startCameraShare = useCallback(
    async (facingOverride?: 'environment' | 'user') => {
      if (visualMode === 'screen') {
        stopVisualShare();
      }

      const targetFacing = facingOverride || cameraFacingRef.current;

      if (isNativeAndroidCameraAvailable()) {
        syncShareMeta('android_camerax', 'requesting');
        startNativeAndroidCamera(targetFacing === 'environment');
        return;
      }

      if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
        showToast('Camera is unavailable on this device.');
        return;
      }

      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: targetFacing }, width: { ideal: 960 } },
            audio: false,
          });
        } catch (constraintErr: unknown) {
          if (
            constraintErr instanceof Error &&
            (constraintErr.name === 'OverconstrainedError' || constraintErr.name === 'TypeError')
          ) {
            stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          } else {
            throw constraintErr;
          }
        }
        attachMediaStreamToPreviews(stream, 'camera', 'camera', 'Cam started');
      } catch {
        showToast('Please allow Camera access in your browser/app settings.');
      }
    },
    [attachMediaStreamToPreviews, showToast, stopVisualShare, syncShareMeta, visualMode]
  );

  const switchCameraLens = useCallback(() => {
    const nextFacing: 'environment' | 'user' =
      cameraFacingRef.current === 'environment' ? 'user' : 'environment';
    cameraFacingRef.current = nextFacing;

    if (screenShareSourceRef.current === 'android_camerax') {
      switchNativeAndroidCameraLens();
      return;
    }
    if (visualMode === 'camera') {
      void startCameraShare(nextFacing);
    }
  }, [startCameraShare, visualMode]);

  const startScreenShare = useCallback(() => {
    setScreenShareError(null);
    if (visualMode === 'camera') {
      stopVisualShare();
    }

    if (isNativeAndroidScreenShareAvailable()) {
      syncShareMeta('android_mediaprojection', 'requesting');
      startNativeAndroidScreenShare(950);
      return;
    }

    syncShareMeta('none', 'error');
    setScreenShareError(
      'Full Android screen sharing requires running inside the compiled Android APK (/android) with native MediaProjection. Browser previews cannot capture other apps like WhatsApp, Roblox, or Chrome.'
    );
  }, [stopVisualShare, syncShareMeta, visualMode]);

  const togglePauseScreenShare = useCallback(() => {
    if (visualMode !== 'screen') return;
    if (screenShareSourceRef.current !== 'android_mediaprojection') return;

    if (screenShareStatusRef.current === 'paused') {
      resumeNativeAndroidScreenShare();
    } else {
      pauseNativeAndroidScreenShare();
    }
  }, [visualMode]);

  const toggleScreenShare = useCallback(() => {
    if (visualMode === 'screen') {
      stopVisualShare();
    } else {
      startScreenShare();
    }
  }, [visualMode, startScreenShare, stopVisualShare]);

  const toggleCamera = useCallback(() => {
    if (visualMode === 'camera') {
      stopVisualShare();
    } else {
      void startCameraShare();
    }
  }, [visualMode, startCameraShare, stopVisualShare]);

  // Media & source file attachment handler
  const handleSelectMediaFile = useCallback(
    async (file: File) => {
      try {
        const prepared = await prepareMediaAttachment(file);
        setPendingAttachment(prepared);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Could not attach media file.';
        showToast(msg);
      }
    },
    [showToast]
  );

  // Global Ctrl+V screenshot paste
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of Array.from(items)) {
        if (item.type.startsWith('image/')) {
          const file = item.getAsFile();
          if (file) {
            e.preventDefault();
            void handleSelectMediaFile(file);
            break;
          }
        }
      }
    };
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [handleSelectMediaFile]);

  const persistSession = useCallback(
    (
      id: string,
      type: HistorySession['type'],
      msgs: ChatMessage[],
      lang: string,
      durationSeconds?: number
    ) => {
      if (msgs.length === 0) return;
      const firstUser = msgs.find((m) => m.role === 'user');
      const fallbackTitle =
        firstUser?.text?.slice(0, 56) ||
        firstUser?.attachmentName ||
        (type === 'call' ? 'Voice Call Session' : 'Chat Session');
      setSessions((prev) => {
        const existingIdx = prev.findIndex((s) => s.id === id);
        const existing = existingIdx >= 0 ? prev[existingIdx] : null;
        const updated: HistorySession = {
          id,
          type,
          title: existing?.title || fallbackTitle,
          language: lang,
          updatedAt: Date.now(),
          messages: msgs,
          durationSeconds,
        };
        if (existingIdx >= 0) {
          const copy = [...prev];
          copy[existingIdx] = updated;
          return copy;
        }
        return [updated, ...prev];
      });
    },
    []
  );

  const detectRequestedLanguage = (text: string): string | null => {
    const clean = text.trim();
    if (!clean) return null;
    const hasSwitchIntent =
      /\b(speak|talk|reply|answer|switch|change|use|baat|bat|bolo|bol|kaho|kah|zaban|zubaan|zabaan|language|mein|main|me|in|to)\b/i.test(
        clean
      ) || /[\u0600-\u06FF\u0900-\u097F]/.test(clean);
    if (!hasSwitchIntent) return null;

    const patterns: Array<{ name: string; regex: RegExp }> = [
      { name: 'Roman Urdu', regex: /\broman\s*urdu\b/i },
      { name: 'Urdu', regex: /\b(urdu|اُردو|اردو)\b/i },
      { name: 'Hindi', regex: /\b(hindi|हिन्दी|हिंदी)\b/i },
      { name: 'Punjabi', regex: /\b(punjabi|پنجابی|ਪੰਜਾਬੀ)\b/i },
      { name: 'Pashto', regex: /\b(pashto|pushto|پښتو)\b/i },
      { name: 'Arabic', regex: /\b(arabic|arabi|العربية|عربي)\b/i },
      { name: 'Turkish', regex: /\b(turkish)\b/i },
      { name: 'Spanish', regex: /\b(spanish|español|espanol)\b/i },
      { name: 'French', regex: /\b(french|français|francais)\b/i },
      { name: 'German', regex: /\b(german|deutsch)\b/i },
      { name: 'Japanese', regex: /\b(japanese|nihongo)\b/i },
      { name: 'Chinese', regex: /\b(chinese|mandarin)\b/i },
      { name: 'Korean', regex: /\b(korean)\b/i },
      { name: 'Bengali', regex: /\b(bengali|bangla)\b/i },
      { name: 'English', regex: /\b(english|angrezi|angrazi)\b/i },
    ];

    for (const item of patterns) {
      if (item.regex.test(clean)) return item.name;
    }
    return null;
  };

  const stopChatGeneration = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setChatLoading(false);
  }, []);

  const executeChatRequest = useCallback(
    async (
      conversationHistory: ChatMessage[],
      attachmentToSend: MediaAttachment | null,
      effectiveLanguage: string
    ) => {
      setChatLoading(true);

      const controller = new AbortController();
      abortControllerRef.current = controller;

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            messages: conversationHistory.map((m) => ({ role: m.role, text: m.text })),
            language: effectiveLanguage,
            thinkingDepth: 'HIGH',
            attachment: attachmentToSend
              ? {
                  mimeType: attachmentToSend.mimeType,
                  data: attachmentToSend.data,
                  name: attachmentToSend.name,
                  kind: attachmentToSend.kind,
                }
              : null,
            screenFrame:
              screenShareStatusRef.current === 'active'
                ? latestScreenFrameRef.current || captureScreenFrameBase64()
                : null,
            autoAnalyzeMedia: Boolean(attachmentToSend),
          }),
        });

        const rawText = await res.text();
        let data: {
          reply?: string;
          clipboardItem?: { title: string; language: string; code: string } | null;
          error?: string;
        } = {};
        try {
          data = rawText ? (JSON.parse(rawText) as typeof data) : {};
        } catch {
          throw new Error(
            res.ok
              ? 'Invalid response from server.'
              : `Server error (${res.status}). Please try again.`
          );
        }

        if (!res.ok || data.error) {
          throw new Error(data.error || 'Could not reach NEXCODE AI.');
        }

        let createdSnippet: ClipboardSnippet | undefined;
        if (data.clipboardItem && data.clipboardItem.code) {
          createdSnippet = await recordClipboardSnippet(data.clipboardItem, false);
        }

        const assistantMsg: ChatMessage = {
          id: `a-${Date.now()}`,
          role: 'assistant',
          text: data.reply || 'Here is what I found.',
          timestamp: Date.now(),
          clipboardSnippet: createdSnippet,
        };

        const finalMessages = [...conversationHistory, assistantMsg];
        setMessages(finalMessages);

        const sessionType: HistorySession['type'] = attachmentToSend ? 'media' : 'chat';
        persistSession(sessionId, sessionType, finalMessages, effectiveLanguage);
      } catch (err: unknown) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          setMessages((prev) => [
            ...prev,
            { id: `s-${Date.now()}`, role: 'assistant', text: 'Stopped.', timestamp: Date.now() },
          ]);
        } else {
          const msg = err instanceof Error ? err.message : 'Something went wrong.';
          setMessages((prev) => [
            ...prev,
            {
              id: `e-${Date.now()}`,
              role: 'assistant',
              text: `Error: ${msg}`,
              timestamp: Date.now(),
            },
          ]);
        }
      } finally {
        abortControllerRef.current = null;
        setChatLoading(false);
      }
    },
    [captureScreenFrameBase64, persistSession, recordClipboardSnippet, sessionId]
  );

  const sendChatMessage = useCallback(
    async (rawText: string) => {
      const trimmed = rawText.trim();
      const attachmentToSend = pendingAttachment;

      if (!trimmed && !attachmentToSend) return;

      const requestedLang = detectRequestedLanguage(trimmed);
      const effectiveLanguage = requestedLang || language;
      if (requestedLang && requestedLang !== language) {
        setLanguage(requestedLang);
      }

      const userMsg: ChatMessage = {
        id: `u-${Date.now()}`,
        role: 'user',
        text: trimmed || `Analyze ${attachmentToSend?.kind}: ${attachmentToSend?.name}`,
        timestamp: Date.now(),
        attachmentName: attachmentToSend?.name,
        attachmentPreviewUrl: attachmentToSend?.previewUrl || undefined,
        attachmentKind: attachmentToSend?.kind,
      };

      const nextMessages = [...messages, userMsg];
      setMessages(nextMessages);
      setChatInput('');
      setPendingAttachment(null);
      await executeChatRequest(nextMessages, attachmentToSend, effectiveLanguage);
    },
    [executeChatRequest, language, messages, pendingAttachment]
  );

  const handleRegenerateLastResponse = useCallback(async () => {
    if (chatLoading || messages.length === 0) return;
    let lastUserIdx = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'user') {
        lastUserIdx = i;
        break;
      }
    }
    if (lastUserIdx === -1) return;
    const trimmedHistory = messages.slice(0, lastUserIdx + 1);
    setMessages(trimmedHistory);
    await executeChatRequest(trimmedHistory, null, language);
  }, [chatLoading, executeChatRequest, language, messages]);

  // --- Resilient Gemini Live Voice Call ---
  const [callActive, setCallActive] = useState(false);
  const [callConnecting, setCallConnecting] = useState(false);
  const [reconnectAttempt, setReconnectAttempt] = useState(0);
  const [muted, setMuted] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const mutedRef = useRef(false);
  const [callDuration, setCallDuration] = useState(0);
  const callDurationRef = useRef(0);
  const callSessionIdRef = useRef<string>(`call-${Date.now()}`);

  const micStreamRef = useRef<MediaStream | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const silentGainRef = useRef<GainNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeAudioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const callTimerRef = useRef<number | null>(null);
  const screenIntervalRef = useRef<number | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const userEndedCallRef = useRef<boolean>(false);

  useEffect(() => {
    mutedRef.current = muted;
  }, [muted]);

  useEffect(() => {
    callDurationRef.current = callDuration;
  }, [callDuration]);

  const clearPlaybackQueue = useCallback(() => {
    activeAudioSourcesRef.current.forEach((src) => {
      try {
        src.stop();
      } catch {
        // ignore
      }
    });
    activeAudioSourcesRef.current.clear();
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
    setAssistantSpeaking(false);
  }, []);

  const teardownCallMedia = useCallback(() => {
    if (reconnectTimerRef.current) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    if (callTimerRef.current) {
      window.clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    if (screenIntervalRef.current) {
      window.clearInterval(screenIntervalRef.current);
      screenIntervalRef.current = null;
    }
    clearPlaybackQueue();

    processorRef.current?.disconnect();
    processorRef.current = null;
    silentGainRef.current?.disconnect();
    silentGainRef.current = null;
    micStreamRef.current?.getTracks().forEach((t) => t.stop());
    micStreamRef.current = null;
    inputAudioCtxRef.current?.close().catch(() => {});
    inputAudioCtxRef.current = null;
    outputAudioCtxRef.current?.close().catch(() => {});
    outputAudioCtxRef.current = null;

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, [clearPlaybackQueue]);

  useEffect(() => {
    if (visualMode === 'camera' && screenStreamRef.current) {
      bindVideoPreviewElement(callScreenVideoRef.current, screenStreamRef.current);
      bindVideoPreviewElement(hiddenCaptureVideoRef.current, screenStreamRef.current);
    }
  }, [visualMode, activeTab, callActive, callConnecting, bindVideoPreviewElement]);

  useEffect(() => {
    if (callTranscript.length > 0 && (callActive || callConnecting)) {
      persistSession(
        callSessionIdRef.current,
        'call',
        callTranscript,
        callLanguageRef.current,
        callDurationRef.current
      );
    }
  }, [callTranscript, callActive, callConnecting, persistSession]);

  const endVoiceCall = useCallback(() => {
    userEndedCallRef.current = true;
    userTranscriptSwitchBufRef.current = '';
    teardownCallMedia();
    stopVisualShare();

    if (callTranscriptRef.current.length > 0) {
      persistSession(
        callSessionIdRef.current,
        'call',
        callTranscriptRef.current,
        callLanguageRef.current,
        callDurationRef.current
      );
    }

    setCallActive(false);
    setCallConnecting(false);
    setReconnectAttempt(0);
    setMuted(false);
    setMicLevel(0);
    setAssistantSpeaking(false);
  }, [persistSession, stopVisualShare, teardownCallMedia]);

  const openCallSocket = useCallback(
    (attempt: number) => {
      if (userEndedCallRef.current) return;

      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const initialLang = callLanguageRef.current || 'English';
      const ws = new WebSocket(
        `${proto}//${window.location.host}/api/live?lang=${encodeURIComponent(initialLang)}`
      );
      wsRef.current = ws;
      let readyReceived = false;

      ws.onopen = () => {
        if (!inputAudioCtxRef.current || !micStreamRef.current) return;
        const inputCtx = inputAudioCtxRef.current;

        processorRef.current?.disconnect();
        silentGainRef.current?.disconnect();

        const source = inputCtx.createMediaStreamSource(micStreamRef.current);
        const processor = inputCtx.createScriptProcessor(4096, 1, 1);
        const silentGain = inputCtx.createGain();
        silentGain.gain.value = 0;

        processorRef.current = processor;
        silentGainRef.current = silentGain;

        source.connect(processor);
        processor.connect(silentGain);
        silentGain.connect(inputCtx.destination);

        processor.onaudioprocess = (e) => {
          const samples = e.inputBuffer.getChannelData(0);
          setMicLevel(mutedRef.current ? 0 : computeRmsLevel(samples));
          if (mutedRef.current || ws.readyState !== WebSocket.OPEN) return;

          const base64 = downsampleTo16kPcm16Base64(samples, inputCtx.sampleRate);
          ws.send(JSON.stringify({ type: 'audio', data: base64 }));
        };

        if (screenIntervalRef.current) window.clearInterval(screenIntervalRef.current);
        screenIntervalRef.current = window.setInterval(() => {
          if (ws.readyState !== WebSocket.OPEN) return;
          if (screenShareStatusRef.current !== 'active') return;
          const frame = captureScreenFrameBase64();
          if (frame) {
            ws.send(
              JSON.stringify({
                type: 'video',
                data: frame,
                source: screenShareSourceRef.current,
                ts: Date.now(),
              })
            );
          }
        }, 750);
      };

      ws.onmessage = async (event) => {
        let msg: {
          type: string;
          data?: string;
          text?: string;
          language?: string;
          error?: string;
          frameCount?: number;
          receivedAt?: number;
          item?: { title: string; language: string; code: string };
        };
        try {
          msg = JSON.parse(event.data as string) as typeof msg;
        } catch {
          return;
        }

        if (msg.type === 'ready') {
          readyReceived = true;
          setCallConnecting(false);
          setCallActive(true);
          setReconnectAttempt(0);
          setAssistantSpeaking(false);

          if (!callTimerRef.current) {
            callTimerRef.current = window.setInterval(() => {
              setCallDuration((d) => d + 1);
            }, 1000);
          }

          if (screenShareStatusRef.current === 'active') {
            ws.send(
              JSON.stringify({
                type: 'screen_state',
                state: 'active',
                source: screenShareSourceRef.current,
              })
            );
            if (latestScreenFrameRef.current) {
              ws.send(
                JSON.stringify({
                  type: 'video',
                  data: latestScreenFrameRef.current,
                  source: screenShareSourceRef.current,
                  ts: Date.now(),
                })
              );
            }
            if (screenShareSourceRef.current === 'android_mediaprojection') {
              requestNativeAndroidFrameNow();
            } else if (screenShareSourceRef.current === 'android_camerax') {
              requestNativeAndroidCameraFrameNow();
            }
          }

          if (attempt === 0) {
            ws.send(
              JSON.stringify({
                type: 'text',
                text: 'Hi! I just joined our NEXCODE AI voice call. Greet me warmly in English in one short friendly sentence and ask what I want to code or share today.',
              })
            );
          }
        } else if (msg.type === 'visionAck' && typeof msg.frameCount === 'number') {
          setVisionFrameCount(msg.frameCount);
          if (typeof msg.receivedAt === 'number') {
            setLastVisionTimestamp(msg.receivedAt);
          }
        } else if (msg.type === 'audio' && msg.data && outputAudioCtxRef.current) {
          setAssistantSpeaking(true);
          const ctx = outputAudioCtxRef.current;
          if (ctx.state === 'suspended') {
            await ctx.resume().catch(() => {});
          }
          const buffer = pcm16Base64ToAudioBuffer(ctx, msg.data, 24000);
          const source = ctx.createBufferSource();
          source.buffer = buffer;
          source.connect(ctx.destination);
          const startAt = Math.max(ctx.currentTime, nextStartTimeRef.current);
          source.start(startAt);
          nextStartTimeRef.current = startAt + buffer.duration;
          activeAudioSourcesRef.current.add(source);
          source.onended = () => {
            activeAudioSourcesRef.current.delete(source);
            if (activeAudioSourcesRef.current.size === 0) {
              setAssistantSpeaking(false);
            }
          };
        } else if (msg.type === 'interrupted') {
          clearPlaybackQueue();
        } else if (msg.type === 'inputTranscript' && msg.text) {
          appendCallTranscript('user', msg.text);
          userTranscriptSwitchBufRef.current = `${userTranscriptSwitchBufRef.current} ${msg.text}`.slice(-240);
          const detected = detectRequestedLanguage(userTranscriptSwitchBufRef.current);
          if (detected && detected.toLowerCase() !== callLanguageRef.current.toLowerCase()) {
            userTranscriptSwitchBufRef.current = '';
            setCallLanguage(detected);
            callLanguageRef.current = detected;
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'set_language', language: detected }));
            }
          }
        } else if (msg.type === 'outputTranscript' && msg.text) {
          appendCallTranscript('assistant', msg.text);
        } else if (msg.type === 'languageChanged' && msg.language) {
          userTranscriptSwitchBufRef.current = '';
          setCallLanguage(msg.language);
          callLanguageRef.current = msg.language;
          showToast(`Language: ${msg.language}`);
        } else if (msg.type === 'turnComplete') {
          userTranscriptSwitchBufRef.current = '';
        } else if (msg.type === 'clipboardItem' && msg.item) {
          await recordClipboardSnippet(msg.item, true);
        } else if (msg.type === 'error') {
          showToast(msg.error || 'Voice connection interrupted.');
        }
      };

      const scheduleReconnect = () => {
        if (userEndedCallRef.current) return;
        if (attempt < 3) {
          const nextAttempt = attempt + 1;
          const backoffMs = 1000 * Math.pow(2, attempt);
          setCallConnecting(true);
          setReconnectAttempt(nextAttempt);
          reconnectTimerRef.current = window.setTimeout(() => {
            openCallSocket(nextAttempt);
          }, backoffMs);
        } else {
          showToast('Voice call disconnected.');
          endVoiceCall();
        }
      };

      ws.onclose = () => {
        if (!userEndedCallRef.current && (readyReceived || attempt < 3)) {
          scheduleReconnect();
        }
      };

      ws.onerror = () => {
        // Handled by onclose backoff
      };
    },
    [
      appendCallTranscript,
      captureScreenFrameBase64,
      clearPlaybackQueue,
      endVoiceCall,
      recordClipboardSnippet,
      showToast,
    ]
  );

  const startVoiceCall = useCallback(async () => {
    if (callActive || callConnecting) return;

    userEndedCallRef.current = false;
    userTranscriptSwitchBufRef.current = '';
    setCallLanguage('English');
    callLanguageRef.current = 'English';
    setCallConnecting(true);
    setReconnectAttempt(0);
    setCallDuration(0);
    setCallTranscript([]);
    callTranscriptRef.current = [];
    callSessionIdRef.current = `call-${Date.now()}`;
    setAssistantSpeaking(false);

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const createAudioCtx = (sampleRate: number) => {
        try {
          return new AudioCtx({ sampleRate });
        } catch {
          return new AudioCtx();
        }
      };
      const inputCtx = createAudioCtx(16000);
      const outputCtx = createAudioCtx(24000);
      inputAudioCtxRef.current = inputCtx;
      outputAudioCtxRef.current = outputCtx;
      nextStartTimeRef.current = outputCtx.currentTime;
      void inputCtx.resume();
      void outputCtx.resume();

      const micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
        },
      });
      micStreamRef.current = micStream;
      setPermissions((prev) => ({ ...prev, microphone: 'granted' }));

      if (inputCtx.state === 'suspended') await inputCtx.resume();
      if (outputCtx.state === 'suspended') await outputCtx.resume();

      openCallSocket(0);
    } catch {
      setPermissions((prev) => ({ ...prev, microphone: 'denied' }));
      showToast('Microphone permission is required for calls.');
      endVoiceCall();
    }
  }, [callActive, callConnecting, endVoiceCall, openCallSocket, showToast]);

  const changeCallLanguage = useCallback((nextLang: string) => {
    setCallLanguage(nextLang);
    callLanguageRef.current = nextLang;
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'set_language', language: nextLang }));
    }
  }, []);

  const sendCallText = useCallback(
    (text: string) => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        if (screenShareStatusRef.current === 'active') {
          if (screenShareSourceRef.current === 'android_mediaprojection') {
            requestNativeAndroidFrameNow();
          } else if (screenShareSourceRef.current === 'android_camerax') {
            requestNativeAndroidCameraFrameNow();
          } else if (screenShareSourceRef.current === 'camera') {
            const fresh = captureScreenFrameBase64();
            if (fresh) {
              wsRef.current.send(
                JSON.stringify({ type: 'video', data: fresh, source: 'camera', ts: Date.now() })
              );
            }
          }
        }
        const detected = detectRequestedLanguage(text);
        if (detected && detected.toLowerCase() !== callLanguageRef.current.toLowerCase()) {
          setCallLanguage(detected);
          callLanguageRef.current = detected;
          wsRef.current.send(JSON.stringify({ type: 'set_language', language: detected }));
        }
        wsRef.current.send(JSON.stringify({ type: 'text', text }));
        appendCallTranscript('user', text);
      }
    },
    [appendCallTranscript, captureScreenFrameBase64]
  );

  const attachCallMedia = useCallback(
    async (file: File) => {
      try {
        const prepared = await prepareMediaAttachment(file);
        if (wsRef.current?.readyState === WebSocket.OPEN && prepared.kind !== 'code') {
          wsRef.current.send(
            JSON.stringify({
              type: 'media',
              mimeType: prepared.mimeType,
              data: prepared.data,
              text: `I just attached a ${prepared.kind} (${prepared.name}). Inspect it carefully and tell me what it is, any bug or problem, and the solution.`,
            })
          );
          appendCallTranscript('user', `Attached ${prepared.kind}: ${prepared.name}`);
          showToast(`Sent ${prepared.kind} to call — assistant is inspecting it`);
        } else {
          setPendingAttachment(prepared);
          setActiveTab('chat');
          void sendChatMessage(`Analyze this ${prepared.kind}: ${prepared.name}`);
        }
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Could not send media.';
        showToast(msg);
      }
    },
    [appendCallTranscript, sendChatMessage, showToast]
  );

  // Onboarding Permission Actions
  const requestMicPermission = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach((t) => t.stop());
      setPermissions((prev) => ({ ...prev, microphone: 'granted' }));
      showToast('Microphone enabled');
    } catch {
      setPermissions((prev) => ({ ...prev, microphone: 'denied' }));
      showToast('Microphone blocked in browser/app settings.');
    }
  };

  const requestClipboardPermission = async () => {
    const ok = await copyToSystemClipboard('Ready', 'Clipboard', false);
    if (!ok) {
      setPermissions((prev) => ({ ...prev, clipboard: 'denied' }));
    }
  };

  const requestCameraPermission = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      s.getTracks().forEach((t) => t.stop());
      setPermissions((prev) => ({ ...prev, screenShare: 'granted' }));
      showToast('Camera permission allowed');
    } catch {
      setPermissions((prev) => ({ ...prev, screenShare: 'denied' }));
      showToast('Camera blocked in browser/app settings.');
    }
  };

  const handleCompleteOnboarding = async () => {
    if (permissions.microphone !== 'granted' && navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
        stream.getTracks().forEach((t) => t.stop());
        setPermissions((prev) => ({
          ...prev,
          microphone: 'granted',
          screenShare: 'granted',
        }));
      } catch {
        // Proceed even if browser/device blocks combined prompt
      }
    }
    safeStorageSet(STORAGE_KEYS.ONBOARDED, 'true');
    setOnboarded(true);
    setActiveTab('chat');
  };

  const handleNewChatSession = () => {
    setSessionId(`sess-${Date.now()}`);
    setMessages([]);
    setPendingAttachment(null);
    setActiveTab('chat');
  };

  const handleLoadSession = (s: HistorySession) => {
    setSessionId(s.id);
    setLanguage(s.language);
    setMessages(s.messages);
    setActiveTab('chat');
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, title: newTitle } : s)));
  };

  if (!onboarded) {
    return (
      <>
        <OnboardingSetup
          language={language}
          onChangeLanguage={setLanguage}
          permissions={permissions}
          onRequestMicrophone={() => void requestMicPermission()}
          onRequestClipboard={() => void requestClipboardPermission()}
          onRequestScreenOrCamera={() => void requestCameraPermission()}
          onRequestAllAndContinue={() => void handleCompleteOnboarding()}
        />
        {toast && (
          <div
            role="status"
            className="fixed bottom-5 right-5 z-50 rounded-lg bg-zinc-900 border border-zinc-700 text-zinc-100 px-4 py-2.5 text-xs font-medium shadow-2xl"
          >
            {toast.message}
          </div>
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col">
      <video
        ref={hiddenCaptureVideoRef}
        autoPlay
        muted
        playsInline
        className="fixed -left-[9999px] top-0 w-16 h-16 opacity-0 pointer-events-none"
      />

      {/* Minimal Header: History + Chat | Call */}
      <header className="bg-black/95 backdrop-blur-md border-b border-zinc-900 sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setHistoryOpen(true)}
              className="p-2 -ml-2 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-900 transition-colors cursor-pointer"
              title="History"
              aria-label="Open History"
            >
              <Menu className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('chat')}
              className="flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            >
              <NexcodeLogo size={26} />
              <span className="text-sm font-bold tracking-tight text-white">NEXCODE AI</span>
            </button>
          </div>

          <nav className="flex items-center gap-2" aria-label="Primary navigation">
            <button
              type="button"
              onClick={() => setActiveTab('chat')}
              className={`inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'chat'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
                  : 'border border-zinc-800 bg-zinc-950 text-zinc-300 hover:bg-zinc-900 hover:text-white'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Chat</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('call')}
              className={`inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'call'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
                  : 'border border-zinc-800 bg-zinc-950 text-zinc-300 hover:bg-zinc-900 hover:text-white'
              }`}
            >
              <Phone className="w-4 h-4" />
              <span>Call</span>
            </button>
          </nav>
        </div>
      </header>

      {/* History Drawer */}
      <HistoryDrawer
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        activeSessionId={sessionId}
        sessions={sessions}
        onNewChat={handleNewChatSession}
        onSelectSession={handleLoadSession}
        onRenameSession={handleRenameSession}
        onDeleteSession={(id) => setSessions((prev) => prev.filter((s) => s.id !== id))}
        onClearAll={() => setSessions([])}
      />

      {/* Main Content Area: Chat or Call */}
      <main className="flex-1 w-full max-w-4xl mx-auto flex flex-col min-h-0">
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col justify-between w-full h-[calc(100vh-57px)]">
            <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center px-4 gap-3">
                  <NexcodeLogo size={44} />
                  <p className="text-sm font-medium text-zinc-200">NEXCODE AI Chat</p>
                  <p className="text-xs text-zinc-500 max-w-md leading-relaxed">
                    Ask any question, generate or debug code, attach photos, videos, or source
                    files, or switch to Call for live voice and screen sharing.
                  </p>
                </div>
              )}

              {messages.map((msg, idx) => {
                const isLastAssistant =
                  msg.role === 'assistant' && idx === messages.length - 1 && !chatLoading;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[90%] rounded-2xl px-4 py-3 ${
                        msg.role === 'user'
                          ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
                          : 'bg-zinc-950 border border-zinc-800 text-zinc-100'
                      }`}
                    >
                      {msg.attachmentPreviewUrl && (
                        <div className="mb-2.5">
                          {msg.attachmentKind === 'video' ? (
                            <video
                              src={msg.attachmentPreviewUrl}
                              controls
                              className="max-h-52 rounded-lg border border-black/30"
                            />
                          ) : (
                            <img
                              src={msg.attachmentPreviewUrl}
                              alt={msg.attachmentName || 'Attached image'}
                              className="max-h-60 rounded-lg border border-black/30 object-contain"
                            />
                          )}
                        </div>
                      )}

                      {msg.attachmentKind === 'code' && msg.attachmentName && (
                        <div className="mb-2 inline-flex items-center gap-1.5 text-xs text-cyan-100/90 font-mono">
                          <FileCode2 className="w-3.5 h-3.5" />
                          <span>{msg.attachmentName}</span>
                        </div>
                      )}

                      {msg.role === 'assistant' ? (
                        <MarkdownCodeView
                          text={msg.text}
                          onCopyCode={(code, label) => void copyToSystemClipboard(code, label)}
                        />
                      ) : (
                        <p className="text-[14.5px] leading-relaxed whitespace-pre-wrap">
                          {msg.text}
                        </p>
                      )}

                      {msg.clipboardSnippet && (
                        <div className="mt-3 pt-2.5 border-t border-zinc-800 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-medium">
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>
                              {msg.clipboardSnippet.autoCopied
                                ? `Added "${msg.clipboardSnippet.title}" to clipboard`
                                : `${msg.clipboardSnippet.title} ready`}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              void copyToSystemClipboard(
                                msg.clipboardSnippet!.code,
                                msg.clipboardSnippet!.title
                              )
                            }
                            className="px-3 py-1 rounded bg-zinc-900 border border-zinc-700 text-xs font-medium text-cyan-400 hover:bg-zinc-800 cursor-pointer"
                          >
                            Copy
                          </button>
                        </div>
                      )}

                      {isLastAssistant && (
                        <div className="mt-2.5 pt-2 border-t border-zinc-900 flex items-center justify-end">
                          <button
                            type="button"
                            onClick={() => void handleRegenerateLastResponse()}
                            className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-cyan-300 transition-colors cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Regenerate</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {chatLoading && (
                <div className="flex items-start">
                  <div className="rounded-2xl border border-zinc-800 bg-zinc-950 px-4 py-3 text-sm text-zinc-400">
                    Thinking...
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {pendingAttachment && (
              <div className="mx-4 mb-2 px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {pendingAttachment.kind === 'video' ? (
                    <Video className="w-5 h-5 text-blue-400 shrink-0" />
                  ) : pendingAttachment.kind === 'code' ? (
                    <FileCode2 className="w-5 h-5 text-cyan-400 shrink-0" />
                  ) : (
                    <img
                      src={pendingAttachment.previewUrl}
                      alt={pendingAttachment.name}
                      className="w-10 h-10 rounded border border-zinc-800 object-cover shrink-0"
                    />
                  )}
                  <span className="text-xs text-zinc-200 truncate">{pendingAttachment.name}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setPendingAttachment(null)}
                  className="p-1 rounded text-zinc-400 hover:text-white cursor-pointer"
                  aria-label="Remove attachment"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!chatLoading) void sendChatMessage(chatInput);
              }}
              className="p-4 border-t border-zinc-900 bg-black"
            >
              <div className="flex items-end gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/*,.html,.css,.js,.jsx,.ts,.tsx,.py,.java,.kt,.c,.cpp,.cs,.php,.sql,.dart,.xml,.json,.lua,.swift,.md,.txt"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void handleSelectMediaFile(file);
                    e.target.value = '';
                  }}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-zinc-800 bg-zinc-950 text-zinc-300 hover:bg-zinc-900 transition-colors cursor-pointer shrink-0"
                  title="Attach photo, video, or source code file"
                  aria-label="Attach photo, video, or source file"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                <textarea
                  rows={1}
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      if (!chatLoading) void sendChatMessage(chatInput);
                    }
                  }}
                  placeholder="Ask NEXCODE AI anything or paste a screenshot..."
                  className="flex-1 resize-none rounded-xl border border-zinc-800 bg-zinc-950 px-4 py-3 text-sm text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-cyan-500"
                />

                {chatLoading ? (
                  <button
                    type="button"
                    onClick={stopChatGeneration}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-red-600 hover:bg-red-700 text-white transition-colors cursor-pointer shrink-0"
                    title="Stop"
                    aria-label="Stop response"
                  >
                    <Square className="w-4 h-4 fill-current" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={!chatInput.trim() && !pendingAttachment}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-110 disabled:opacity-40 text-white transition-all cursor-pointer shrink-0"
                    title="Send"
                    aria-label="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

        {activeTab === 'call' && (
          <div className="flex-1 flex flex-col justify-center p-4 w-full">
            <VoiceCallView
              callActive={callActive}
              callConnecting={callConnecting}
              reconnectAttempt={reconnectAttempt}
              muted={muted}
              micLevel={micLevel}
              durationSeconds={callDuration}
              assistantSpeaking={assistantSpeaking}
              callLanguage={callLanguage}
              visualMode={visualMode}
              screenShareSource={screenShareSource}
              screenShareStatus={screenShareStatus}
              screenShareError={screenShareError}
              visionFrameCount={visionFrameCount}
              lastVisionTimestamp={lastVisionTimestamp}
              nativeAndroidAvailable={nativeAndroidAvailable}
              nativeCameraXAvailable={nativeCameraXAvailable}
              nativeOverlayGranted={nativeOverlayGranted}
              screenImagePreviewUrl={screenImagePreviewUrl}
              screenPreviewRef={callScreenVideoRef}
              callTranscript={callTranscript}
              onStartCall={startVoiceCall}
              onEndCall={endVoiceCall}
              onToggleMute={() => setMuted((m) => !m)}
              onChangeCallLanguage={changeCallLanguage}
              onToggleScreenShare={toggleScreenShare}
              onTogglePauseScreenShare={togglePauseScreenShare}
              onRequestOverlayIndicator={requestNativeOverlayPermission}
              onDismissScreenShareError={() => setScreenShareError(null)}
              onToggleCamera={toggleCamera}
              onSwitchCameraLens={switchCameraLens}
              onAttachCallMedia={(file) => void attachCallMedia(file)}
              onSendCallText={sendCallText}
            />
          </div>
        )}
      </main>

      {/* Toast Notification */}
      {toast && (
        <div
          role="status"
          className="fixed bottom-5 right-4 z-50 rounded-lg bg-zinc-900 border border-zinc-700 text-zinc-100 px-3.5 py-2 text-xs font-medium shadow-2xl flex items-center gap-2.5 max-w-xs"
        >
          <span className="flex-1">{toast.message}</span>
          {toast.copyText && (
            <button
              type="button"
              onClick={() => {
                void copyToSystemClipboard(toast.copyText!, toast.copyLabel || 'Snippet', false);
              }}
              className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium shrink-0 cursor-pointer"
            >
              Copy
            </button>
          )}
          <button
            type="button"
            onClick={() => setToast(null)}
            className="text-zinc-400 hover:text-white cursor-pointer shrink-0"
            aria-label="Dismiss notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
