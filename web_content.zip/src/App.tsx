import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Heart,
  Search,
  Shuffle,
  X,
} from "lucide-react";
import { FlowerCard } from "./components/FlowerCard";
import { FlowerDetailModal } from "./components/FlowerDetailModal";
import {
  FLOWERS_CATALOG,
  POPULAR_SEARCH_SUGGESTIONS,
  filterAndSearchFlowers,
} from "./data/flowersCatalog";
import { fetchFlowerMedia } from "./hooks/useFlowerMedia";
import {
  ALL_CATEGORIES,
  ALL_COLORS,
  FALLBACK_IMAGES_BY_CATEGORY,
  type FlowerCategory,
  type FlowerColor,
  type FlowerEntry,
} from "./types/flower";

const HERO_IMAGE = "/src/assets/images/hero_floral_gift_1795169659687.jpg";
const PAGE_SIZE = 24;
const FAVORITES_STORAGE_KEY = "aybjanova_nuriya_favorite_flowers_v1";

export default function App() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<
    "Barchasi" | FlowerCategory
  >("Barchasi");
  const [selectedColor, setSelectedColor] = useState<
    "Barcha ranglar" | FlowerColor
  >("Barcha ranglar");
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [activeFlower, setActiveFlower] = useState<FlowerEntry | null>(null);
  const [isLookingUpExternal, setIsLookingUpExternal] = useState(false);
  const [externalLookupError, setExternalLookupError] = useState<string | null>(
    null
  );

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(FAVORITES_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  const catalogSectionRef = useRef<HTMLElement | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
    } catch {
      // Ignore storage errors
    }
  }, [favorites]);

  const favoriteSet = useMemo(() => new Set(favorites), [favorites]);

  const matchedFlowers = useMemo(() => {
    const base = filterAndSearchFlowers(
      searchQuery,
      selectedCategory,
      selectedColor
    );
    if (!showFavoritesOnly) return base;
    return base.filter((f) => favoriteSet.has(f.id));
  }, [
    searchQuery,
    selectedCategory,
    selectedColor,
    showFavoritesOnly,
    favoriteSet,
  ]);

  const totalPages = Math.max(1, Math.ceil(matchedFlowers.length / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);

  const paginatedFlowers = useMemo(() => {
    const start = (safePage - 1) * PAGE_SIZE;
    return matchedFlowers.slice(start, start + PAGE_SIZE);
  }, [matchedFlowers, safePage]);

  useEffect(() => {
    setCurrentPage(1);
    setExternalLookupError(null);
  }, [searchQuery, selectedCategory, selectedColor, showFavoritesOnly]);

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const scrollToCatalog = () => {
    catalogSectionRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleHeroSearchSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmed = searchQuery.trim();
    if (!trimmed) {
      scrollToCatalog();
      return;
    }

    if (matchedFlowers.length > 0) {
      // Open the top exact match directly if user hit Enter, and scroll catalog into view
      scrollToCatalog();
      if (matchedFlowers.length === 1) {
        setActiveFlower(matchedFlowers[0]);
      }
      return;
    }

    await handleExternalFlowerLookup(trimmed);
  };

  const handleExternalFlowerLookup = async (queryText: string) => {
    const trimmed = queryText.trim();
    if (!trimmed) return;

    setIsLookingUpExternal(true);
    setExternalLookupError(null);
    try {
      const media = await fetchFlowerMedia(trimmed, trimmed, trimmed);
      if (media.extract || media.imageUrl) {
        const dynamicFlower: FlowerEntry = {
          id: `live-${trimmed.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
          uzName: media.wikiTitle || trimmed,
          enName: media.wikiTitle || trimmed,
          latinName: trimmed,
          wikiQuery: media.wikiTitle || trimmed,
          family: "Botanik qidiruv natijasi",
          category: "Bog‘ gullari",
          color: "Aralash",
          season: "Turli fasllarda",
          origin: "Jahon florasi",
          fragrance: "Tabiiy gul ifori",
          meaning: "Tabiat mo‘jizasi va go‘zallik timsoli",
          care: "Yorug‘lik, mo‘tadil namlik va unumdor tuproqda yaxshi rivojlanadi.",
          description:
            media.extract ||
            `${trimmed} — jahon florasiga mansub o‘simlik va gul turi.`,
          fallbackImage: FALLBACK_IMAGES_BY_CATEGORY["Bog‘ gullari"],
        };
        setActiveFlower(dynamicFlower);
      } else {
        setExternalLookupError(
          `«${trimmed}» bo‘yicha ma’lumot topilmadi. Boshqa gul nomini yozib ko‘ring.`
        );
      }
    } catch {
      setExternalLookupError(
        "Qidiruv vaqtida xatolik yuz berdi. Iltimos, qayta urinib ko‘ring."
      );
    } finally {
      setIsLookingUpExternal(false);
    }
  };

  const handleRandomSurprise = () => {
    const pool =
      matchedFlowers.length > 0 ? matchedFlowers : FLOWERS_CATALOG;
    const randomIndex = Math.floor(Math.random() * pool.length);
    setActiveFlower(pool[randomIndex]);
  };

  const handleResetFilters = () => {
    setSearchQuery("");
    setSelectedCategory("Barchasi");
    setSelectedColor("Barcha ranglar");
    setShowFavoritesOnly(false);
    setExternalLookupError(null);
  };

  const handlePageChange = (nextPage: number) => {
    setCurrentPage(nextPage);
    catalogSectionRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-[#FDF9F8] text-[#2B1D22]">
      {/* Strict 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 border-b border-[#EFE3E6] bg-[#FDF9F8]/95 backdrop-blur-xs">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-4 py-4 sm:px-6">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#bosh-sahifa"
            className="font-display text-2xl font-semibold tracking-tight text-[#2B1D22] whitespace-nowrap shrink-0"
          >
            Gulzor Ensiklopediyasi
          </a>

          {/* Zone 2: 4 Single-line Nav Links */}
          <nav
            aria-label="Asosiy menyu"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-[#5C444C]"
          >
            <a
              href="#bosh-sahifa"
              className="transition-colors hover:text-[#9D3C56] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Bosh sahifa
            </a>
            <a
              href="#gullar-katalogi"
              onClick={() => setShowFavoritesOnly(false)}
              className="transition-colors hover:text-[#9D3C56] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Gullar katalogi
            </a>
            <a
              href="#kategoriyalar"
              className="transition-colors hover:text-[#9D3C56] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Kategoriyalar
            </a>
            <button
              type="button"
              onClick={() => {
                setShowFavoritesOnly(true);
                scrollToCatalog();
              }}
              className="transition-colors hover:text-[#9D3C56] hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Sevimlilar ({favorites.length})
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleRandomSurprise}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-[#9D3C56] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#822D44] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] focus-visible:ring-offset-2"
            >
              <Shuffle className="h-3.5 w-3.5" />
              <span>Tasodifiy gul</span>
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Gift Dedication & Instant Search */}
        <section
          id="bosh-sahifa"
          className="mx-auto max-w-6xl px-4 pt-8 pb-10 sm:px-6 lg:pt-12 lg:pb-14"
        >
          <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12 lg:gap-10">
            {/* Left Column: Gift Heading, Owner Name, Search */}
            <div className="flex flex-col justify-center lg:col-span-7">
              <p className="text-xs font-medium tracking-wide text-[#8C6470]">
                <span>{FLOWERS_CATALOG.length.toLocaleString("fr-FR")} xil gul ensiklopediyasi</span>
                <span aria-hidden="true" className="mx-2">
                  ·
                </span>
                <span>O‘zbek va lotin tillarida</span>
              </p>

              <h1 className="mt-3 font-display text-5xl font-semibold leading-[1.05] tracking-tight text-[#2B1D22] text-balance sm:text-6xl lg:text-[4.25rem]">
                Bu mendan senga sovga
              </h1>

              {/* Prominent Eye-catching Owner Line with Beautiful Font & Emoji */}
              <p className="mt-5 font-display text-2xl font-semibold italic leading-snug text-[#9D3C56] sm:text-3xl lg:text-[2.15rem]">
                🌸 ilova egasi: Aybjanova Nuriya 💐
              </p>

              <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-[#5C444C]">
                Istalgan gulning nomini qidiruvga yozing — uning haqiqiy rasmi,
                botanik tavsifi, ramziy ma’nosi, kelib chiqishi va parvarish
                sirlari bir zumda qarshingizda ochiladi.
              </p>

              {/* Prominent Instant Search Form */}
              <form
                onSubmit={handleHeroSearchSubmit}
                className="mt-7 max-w-xl"
                role="search"
                aria-label="Gul nomini qidirish"
              >
                <div className="flex flex-col gap-2.5 sm:flex-row">
                  <div className="relative flex-1">
                    <Search
                      className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8C6470]"
                      aria-hidden="true"
                    />
                    <input
                      ref={searchInputRef}
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Gul nomini yozing... (masalan: Atirgul, Lola, Pion)"
                      className="h-12 w-full rounded-lg border border-[#DEC6CD] bg-white pl-10 pr-10 text-sm text-[#2B1D22] placeholder:text-[#9D7B85] focus:border-[#9D3C56] focus:outline-none focus:ring-2 focus:ring-[#9D3C56]/20"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery("")}
                        aria-label="Qidiruvni tozalash"
                        className="absolute right-2.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-[#8C6470] hover:bg-[#F6ECEF] hover:text-[#2B1D22]"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <button
                    type="submit"
                    className="inline-flex h-12 items-center justify-center rounded-lg bg-[#9D3C56] px-6 text-sm font-semibold text-white transition-colors hover:bg-[#822D44] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] focus-visible:ring-offset-2"
                  >
                    Gulni topish
                  </button>
                </div>
              </form>

              {/* Quick Search Suggestions */}
              <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2 text-xs text-[#7B5A64]">
                <span className="font-medium text-[#8C6470]">
                  Tez tanlash:
                </span>
                {POPULAR_SEARCH_SUGGESTIONS.map((term) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() => {
                      setSearchQuery(term);
                      scrollToCatalog();
                    }}
                    className={`underline-offset-4 transition-colors hover:text-[#9D3C56] hover:underline whitespace-nowrap shrink-0 ${
                      searchQuery.toLowerCase() === term.toLowerCase()
                        ? "font-semibold text-[#9D3C56] underline"
                        : ""
                    }`}
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>

            {/* Right Column: Editorial Floral Bouquet Visual */}
            <div className="lg:col-span-5">
              <div className="h-full overflow-hidden rounded-2xl border border-[#EFE3E6] bg-white p-2.5">
                <div className="aspect-[4/3] w-full overflow-hidden rounded-xl lg:aspect-auto lg:h-full">
                  <img
                    src={HERO_IMAGE}
                    alt="Nafis pion va bog‘ atirgullaridan tuzilgan sovg‘a guldastasi"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 4-Column Quiet Botanical Overview Strip */}
          <div className="mt-10 grid grid-cols-2 divide-y divide-[#EFE3E6] rounded-xl border border-[#EFE3E6] bg-white sm:grid-cols-4 sm:divide-x sm:divide-y-0">
            <div className="px-5 py-4">
              <p className="font-display text-2xl font-semibold text-[#2B1D22] tabular-nums sm:text-3xl">
                {FLOWERS_CATALOG.length.toLocaleString("fr-FR")}+
              </p>
              <p className="mt-0.5 text-xs text-[#7B5A64]">
                Noyob va mashhur gul turlari
              </p>
            </div>
            <div className="px-5 py-4">
              <p className="font-display text-2xl font-semibold text-[#2B1D22] tabular-nums sm:text-3xl">
                7
              </p>
              <p className="mt-0.5 text-xs text-[#7B5A64]">
                Botanik kategoriya va bo‘limlar
              </p>
            </div>
            <div className="px-5 py-4">
              <p className="font-display text-2xl font-semibold text-[#2B1D22] tabular-nums sm:text-3xl">
                8
              </p>
              <p className="mt-0.5 text-xs text-[#7B5A64]">
                Rang palitrasi bo‘yicha saralash
              </p>
            </div>
            <div className="px-5 py-4">
              <p className="font-display text-2xl font-semibold text-[#9D3C56] tabular-nums sm:text-3xl">
                {favorites.length}
              </p>
              <p className="mt-0.5 text-xs text-[#7B5A64]">
                Saqlangan sevimli gullaringiz
              </p>
            </div>
          </div>
        </section>

        {/* Catalog & Interactive Filter Section */}
        <section
          id="gullar-katalogi"
          ref={catalogSectionRef}
          className="mx-auto max-w-6xl border-t border-[#EFE3E6] px-4 py-10 sm:px-6 lg:py-14"
        >
          <div id="kategoriyalar" className="flex flex-col gap-6">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div>
                <h2 className="font-display text-3xl font-semibold text-[#2B1D22] sm:text-4xl">
                  Gullar Katalogi
                </h2>
                <p className="mt-1 text-sm text-[#6E4F58] tabular-nums">
                  {matchedFlowers.length.toLocaleString("fr-FR")} ta gul topildi
                  {searchQuery ? ` · «${searchQuery}» bo‘yicha` : ""}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowFavoritesOnly((prev) => !prev)}
                  className={`inline-flex min-h-[40px] items-center gap-2 rounded-lg border px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] ${
                    showFavoritesOnly
                      ? "border-[#9D3C56] bg-[#9D3C56] text-white"
                      : "border-[#DEC6CD] bg-white text-[#4A2F38] hover:border-[#9D3C56] hover:text-[#9D3C56]"
                  }`}
                >
                  <Heart
                    className="h-3.5 w-3.5"
                    fill={showFavoritesOnly ? "currentColor" : "none"}
                  />
                  <span>Faqat sevimlilar ({favorites.length})</span>
                </button>

                {(searchQuery ||
                  selectedCategory !== "Barchasi" ||
                  selectedColor !== "Barcha ranglar" ||
                  showFavoritesOnly) && (
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-[#EFE3E6] bg-white px-3.5 py-2 text-xs font-medium text-[#6E4F58] transition-colors hover:text-[#2B1D22] whitespace-nowrap shrink-0"
                  >
                    <X className="h-3.5 w-3.5" />
                    <span>Filtrlarni tozalash</span>
                  </button>
                )}
              </div>
            </div>

            {/* Category Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-[#EFE3E6] bg-white p-1.5">
              {ALL_CATEGORIES.map((category) => {
                const active = selectedCategory === category;
                return (
                  <button
                    key={category}
                    type="button"
                    onClick={() => setSelectedCategory(category)}
                    className={`rounded-lg px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] ${
                      active
                        ? "bg-[#9D3C56] text-white"
                        : "text-[#5C444C] hover:bg-[#FDF4F6] hover:text-[#9D3C56]"
                    }`}
                  >
                    {category}
                  </button>
                );
              })}
            </div>

            {/* Color Filter Tabs */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="font-medium text-[#8C6470]">Rangi bo‘yicha:</span>
              <div className="flex flex-wrap items-center gap-1.5">
                {ALL_COLORS.map((color) => {
                  const active = selectedColor === color;
                  return (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setSelectedColor(color)}
                      className={`rounded-md border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] ${
                        active
                          ? "border-[#9D3C56] bg-[#F9ECEF] text-[#9D3C56]"
                          : "border-[#EFE3E6] bg-white text-[#5C444C] hover:border-[#DEC6CD] hover:text-[#2B1D22]"
                      }`}
                    >
                      {color}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Empty State + Live External Lookup */}
          {paginatedFlowers.length === 0 ? (
            <div className="mt-10 rounded-2xl border border-[#EFE3E6] bg-white p-10 text-center">
              <p className="font-display text-2xl font-semibold text-[#2B1D22]">
                {showFavoritesOnly
                  ? "Hozircha sevimli gullaringiz ro‘yxati bo‘sh"
                  : `«${searchQuery}» bo‘yicha katalogda natija topilmadi`}
              </p>
              <p className="mx-auto mt-2 max-w-md text-sm text-[#6E4F58]">
                {showFavoritesOnly
                  ? "Yoqqan gul kartochkasidagi yurakcha belgisini bosib, shaxsiy to‘plamingizni yig‘ishingiz mumkin."
                  : "Gul nomini o‘zbekcha, inglizcha yoki lotincha yozib ko‘ring yoxud jahon botanika bazasidan qidiring."}
              </p>

              {externalLookupError && (
                <p className="mt-3 text-xs font-medium text-[#9D3C56]">
                  {externalLookupError}
                </p>
              )}

              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                {!showFavoritesOnly && searchQuery.trim() && (
                  <button
                    type="button"
                    disabled={isLookingUpExternal}
                    onClick={() => handleExternalFlowerLookup(searchQuery)}
                    className="inline-flex min-h-[42px] items-center justify-center rounded-lg bg-[#9D3C56] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#822D44] disabled:opacity-60"
                  >
                    {isLookingUpExternal
                      ? "Qidirilmoqda..."
                      : `«${searchQuery}» ni jahon bazasidan topish`}
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="inline-flex min-h-[42px] items-center justify-center rounded-lg border border-[#DEC6CD] bg-white px-5 py-2.5 text-sm font-medium text-[#2B1D22] hover:border-[#9D3C56]"
                >
                  Barcha gullarni ko‘rsatish
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* 3-Column Desktop Grid */}
              <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {paginatedFlowers.map((flower) => (
                  <FlowerCard
                    key={flower.id}
                    flower={flower}
                    isFavorite={favoriteSet.has(flower.id)}
                    onToggleFavorite={toggleFavorite}
                    onSelect={setActiveFlower}
                  />
                ))}
              </div>

              {/* Clean Pagination Controls */}
              {totalPages > 1 && (
                <nav
                  aria-label="Sahifalar"
                  className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-[#EFE3E6] pt-6"
                >
                  <p className="text-xs text-[#6E4F58] tabular-nums">
                    Sahifa {safePage} / {totalPages} (Jami:{" "}
                    {matchedFlowers.length.toLocaleString("fr-FR")} ta gul)
                  </p>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={safePage <= 1}
                      onClick={() => handlePageChange(safePage - 1)}
                      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-[#DEC6CD] bg-white px-3.5 py-2 text-xs font-medium text-[#2B1D22] transition-colors hover:border-[#9D3C56] hover:text-[#9D3C56] disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      <ChevronLeft className="h-4 w-4" />
                      <span>Oldingi</span>
                    </button>

                    <div className="hidden items-center gap-1 sm:flex">
                      {Array.from({ length: totalPages }, (_, idx) => idx + 1)
                        .filter((page) => {
                          if (totalPages <= 7) return true;
                          if (page === 1 || page === totalPages) return true;
                          return Math.abs(page - safePage) <= 1;
                        })
                        .map((page, index, arr) => {
                          const prevPage = arr[index - 1];
                          const showEllipsis =
                            prevPage !== undefined && page - prevPage > 1;

                          return (
                            <span key={page} className="flex items-center gap-1">
                              {showEllipsis && (
                                <span className="px-1.5 text-xs text-[#8C6470]">
                                  ...
                                </span>
                              )}
                              <button
                                type="button"
                                onClick={() => handlePageChange(page)}
                                aria-current={
                                  page === safePage ? "page" : undefined
                                }
                                className={`h-9 min-w-[36px] rounded-lg px-2.5 text-xs font-medium tabular-nums transition-colors ${
                                  page === safePage
                                    ? "bg-[#9D3C56] text-white"
                                    : "border border-[#EFE3E6] bg-white text-[#5C444C] hover:border-[#DEC6CD] hover:text-[#2B1D22]"
                                }`}
                              >
                                {page}
                              </button>
                            </span>
                          );
                        })}
                    </div>

                    <button
                      type="button"
                      disabled={safePage >= totalPages}
                      onClick={() => handlePageChange(safePage + 1)}
                      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-[#DEC6CD] bg-white px-3.5 py-2 text-xs font-medium text-[#2B1D22] transition-colors hover:border-[#9D3C56] hover:text-[#9D3C56] disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      <span>Keyingi</span>
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                </nav>
              )}
            </>
          )}
        </section>
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-[#EFE3E6] bg-white py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 text-center sm:flex-row sm:px-6 sm:text-left">
          <div>
            <p className="font-display text-xl font-semibold text-[#2B1D22]">
              Bu mendan senga sovga
            </p>
            <p className="mt-0.5 font-display text-lg font-medium italic text-[#9D3C56]">
              🌸 ilova egasi: Aybjanova Nuriya 💐
            </p>
          </div>
          <p className="text-xs text-[#7B5A64]">
            {FLOWERS_CATALOG.length.toLocaleString("fr-FR")} dan ortiq gullar
            ensiklopediyasi · 2026
          </p>
        </div>
      </footer>

      {/* Flower Detail Modal */}
      <FlowerDetailModal
        flower={activeFlower}
        isFavorite={activeFlower ? favoriteSet.has(activeFlower.id) : false}
        onToggleFavorite={toggleFavorite}
        onClose={() => setActiveFlower(null)}
      />
    </div>
  );
}
