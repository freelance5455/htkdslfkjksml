import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Check, Copy, Download, Mic, Trash2 } from 'lucide-react';
import {
  AUTO_DETECT_LANGUAGE,
  findLanguageByCode,
  resolveEffectiveOutputLanguage,
  SAME_AS_SPEAKING_CODE,
} from './constants/languages';
import { useLiveDictation } from './hooks/useLiveDictation';
import {
  enhanceWrittenText,
  finalizeSegment,
  translateWrittenText,
} from './services/geminiApiClient';
import { buildCleanPlainText } from './utils/formatting';
import { LanguageBar } from './components/LanguageBar';
import { LiveDictationPanel } from './components/LiveDictationPanel';
import { WrittenSheet } from './components/WrittenSheet';

const WRITTEN_TEXT_STORAGE_KEY = 'sk_voice_written_text_v1';

export default function App() {
  const [speakingCode, setSpeakingCode] = useState<string>('ur-PK');
  const [outputCode, setOutputCode] = useState<string>(SAME_AS_SPEAKING_CODE);
  const [writtenText, setWrittenText] = useState<string>(() => {
    try {
      return localStorage.getItem(WRITTEN_TEXT_STORAGE_KEY) ?? '';
    } catch {
      return '';
    }
  });

  const [isCommittingNext, setIsCommittingNext] = useState(false);
  const [isTranslatingSheet, setIsTranslatingSheet] = useState(false);
  const [isEnhancingSheet, setIsEnhancingSheet] = useState(false);
  const [justEnhanced, setJustEnhanced] = useState(false);
  const [copied, setCopied] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const {
    liveState,
    permissionDenied,
    startListening,
    stopListening,
    consumeCurrentDraft,
    setDraftTranslatedText,
    clearError,
    dismissPermissionModal,
  } = useLiveDictation();

  const translationRequestIdRef = useRef(0);

  // Persist only the user's plain written text locally (zero audio files ever)
  useEffect(() => {
    try {
      localStorage.setItem(WRITTEN_TEXT_STORAGE_KEY, writtenText);
    } catch {
      // Ignore quota errors
    }
  }, [writtenText]);

  const effectiveOutputLang = resolveEffectiveOutputLanguage(
    speakingCode,
    outputCode
  );
  const isTranslatingMode =
    outputCode !== SAME_AS_SPEAKING_CODE &&
    effectiveOutputLang.code !== speakingCode;

  const combinedLiveRaw = [liveState.liveRawText, liveState.interimRawText]
    .filter(Boolean)
    .join(' ')
    .trim();

  // Live preview shown at the bottom of the Written Text sheet while speaking
  const livePreviewForSheet = isTranslatingMode
    ? liveState.liveTranslatedText || combinedLiveRaw
    : combinedLiveRaw;

  const runAutoTranslate = useCallback(
    async (
      nextSpeakingCode: string,
      nextOutputCode: string,
      currentWritten: string,
      currentDraftRaw: string
    ) => {
      const targetLang = resolveEffectiveOutputLanguage(
        nextSpeakingCode,
        nextOutputCode
      );
      const reqId = ++translationRequestIdRef.current;

      if (!currentWritten.trim() && !currentDraftRaw.trim()) {
        return;
      }

      setIsTranslatingSheet(true);
      setNotice(null);

      try {
        if (currentWritten.trim()) {
          const translatedDoc = await translateWrittenText({
            text: currentWritten,
            targetLangName: targetLang.englishName,
            targetLangCode: targetLang.code,
          });
          if (translationRequestIdRef.current === reqId) {
            setWrittenText(translatedDoc);
          }
        }

        if (currentDraftRaw.trim()) {
          const translatedDraft = await translateWrittenText({
            text: currentDraftRaw,
            targetLangName: targetLang.englishName,
            targetLangCode: targetLang.code,
          });
          if (translationRequestIdRef.current === reqId) {
            setDraftTranslatedText(translatedDraft);
          }
        }
      } catch (err) {
        if (translationRequestIdRef.current === reqId) {
          const msg =
            err instanceof Error ? err.message : 'Unable to translate right now.';
          setNotice(msg);
        }
      } finally {
        if (translationRequestIdRef.current === reqId) {
          setIsTranslatingSheet(false);
        }
      }
    },
    [setDraftTranslatedText]
  );

  const handleSpeakingChange = useCallback(
    async (nextCode: string) => {
      setSpeakingCode(nextCode);
      setNotice(null);
      if (liveState.isListening) {
        await startListening(nextCode, outputCode, true);
      }
    },
    [liveState.isListening, outputCode, startListening]
  );

  const handleOutputChange = useCallback(
    async (nextOutputCode: string) => {
      setOutputCode(nextOutputCode);
      setNotice(null);

      if (liveState.isListening) {
        await startListening(speakingCode, nextOutputCode, true);
      }

      // Automatically translate any existing written text & live draft into the newly selected language
      await runAutoTranslate(
        speakingCode,
        nextOutputCode,
        writtenText,
        combinedLiveRaw
      );
    },
    [
      combinedLiveRaw,
      liveState.isListening,
      runAutoTranslate,
      speakingCode,
      startListening,
      writtenText,
    ]
  );

  const handleSwapLanguages = useCallback(async () => {
    let nextSpeaking = speakingCode;
    let nextOutput = outputCode;

    if (speakingCode === AUTO_DETECT_LANGUAGE.code) {
      nextSpeaking = outputCode === SAME_AS_SPEAKING_CODE ? 'ur-PK' : outputCode;
      nextOutput = 'en-US';
    } else {
      const resolvedOut =
        outputCode === SAME_AS_SPEAKING_CODE ? speakingCode : outputCode;
      nextSpeaking = resolvedOut;
      nextOutput = speakingCode;
    }

    setSpeakingCode(nextSpeaking);
    setOutputCode(nextOutput);
    setNotice(null);

    if (liveState.isListening) {
      await startListening(nextSpeaking, nextOutput, true);
    }

    await runAutoTranslate(
      nextSpeaking,
      nextOutput,
      writtenText,
      combinedLiveRaw
    );
  }, [
    combinedLiveRaw,
    liveState.isListening,
    outputCode,
    runAutoTranslate,
    speakingCode,
    startListening,
    writtenText,
  ]);

  const commitDraftToSheet = useCallback(
    async (rawText: string, liveTranslatedFallback: string) => {
      const cleanedRaw = rawText.trim();
      if (!cleanedRaw) return;

      const speakingLang = findLanguageByCode(speakingCode);
      const targetLang = resolveEffectiveOutputLanguage(speakingCode, outputCode);

      setIsCommittingNext(true);
      setNotice(null);

      try {
        const polished = await finalizeSegment({
          rawText: cleanedRaw,
          speakingLangName: speakingLang.englishName,
          speakingLangCode: speakingCode,
          outputLangName: targetLang.englishName,
          outputLangCode: outputCode === SAME_AS_SPEAKING_CODE ? 'same' : targetLang.code,
        });

        const textToAppend = polished || liveTranslatedFallback || cleanedRaw;
        setWrittenText((prev) =>
          prev.trim() ? `${prev.trim()}\n\n${textToAppend}` : textToAppend
        );
      } catch {
        const fallbackText =
          isTranslatingMode && liveTranslatedFallback
            ? liveTranslatedFallback
            : cleanedRaw;
        setWrittenText((prev) =>
          prev.trim() ? `${prev.trim()}\n\n${fallbackText}` : fallbackText
        );
      } finally {
        setIsCommittingNext(false);
      }
    },
    [isTranslatingMode, outputCode, speakingCode]
  );

  // "Next" button: cleanly places & polishes/translates the current live block below while keeping mic running
  const handleNext = useCallback(async () => {
    const { rawText, translatedText } = consumeCurrentDraft();
    if (!rawText) return;
    await commitDraftToSheet(rawText, translatedText);
  }, [commitDraftToSheet, consumeCurrentDraft]);

  const handleToggleListening = useCallback(async () => {
    setNotice(null);
    if (liveState.isListening) {
      const { rawText, translatedText } = stopListening();
      if (rawText) {
        consumeCurrentDraft();
        await commitDraftToSheet(rawText, translatedText);
      }
    } else {
      await startListening(speakingCode, outputCode, false);
    }
  }, [
    commitDraftToSheet,
    consumeCurrentDraft,
    liveState.isListening,
    outputCode,
    speakingCode,
    startListening,
    stopListening,
  ]);

  const handleCopyAll = useCallback(async () => {
    const cleanText = buildCleanPlainText(writtenText, livePreviewForSheet);
    if (!cleanText) return;

    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(cleanText);
      } else {
        const helper = document.createElement('textarea');
        helper.value = cleanText;
        helper.setAttribute('readonly', '');
        helper.style.position = 'fixed';
        helper.style.opacity = '0';
        document.body.appendChild(helper);
        helper.select();
        document.execCommand('copy');
        document.body.removeChild(helper);
      }
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setNotice('Clipboard access unavailable in this browser.');
    }
  }, [livePreviewForSheet, writtenText]);

  const handleDownloadTxt = useCallback(() => {
    const cleanText = buildCleanPlainText(writtenText, livePreviewForSheet);
    if (!cleanText) return;

    try {
      const now = new Date();
      const stamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(
        2,
        '0'
      )}-${String(now.getDate()).padStart(2, '0')}_${String(
        now.getHours()
      ).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}`;
      const filename = `sk-voice-${stamp}.txt`;

      // UTF-8 BOM guarantees clean Urdu, Arabic, Hindi, and English display across Android/Windows/iOS
      const blob = new Blob([`\uFEFF${cleanText}`], {
        type: 'text/plain;charset=utf-8',
      });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);

      setDownloaded(true);
      window.setTimeout(() => setDownloaded(false), 1800);
    } catch {
      setNotice('Unable to download .txt file in this browser.');
    }
  }, [livePreviewForSheet, writtenText]);

  const handleEnhanceText = useCallback(async () => {
    const cleaned = writtenText.trim();
    if (!cleaned || isEnhancingSheet) return;

    const targetLang = resolveEffectiveOutputLanguage(speakingCode, outputCode);
    setIsEnhancingSheet(true);
    setJustEnhanced(false);
    setNotice(null);

    try {
      const enhanced = await enhanceWrittenText({
        text: cleaned,
        languageName: targetLang.englishName,
        languageCode: targetLang.code,
      });
      setWrittenText(enhanced);
      setJustEnhanced(true);
      window.setTimeout(() => setJustEnhanced(false), 2000);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Unable to enhance text right now.';
      setNotice(msg);
    } finally {
      setIsEnhancingSheet(false);
    }
  }, [isEnhancingSheet, outputCode, speakingCode, writtenText]);

  const handleClearAll = useCallback(() => {
    consumeCurrentDraft();
    setWrittenText('');
    setJustEnhanced(false);
    setNotice(null);
  }, [consumeCurrentDraft]);

  const hasAnyText = Boolean(writtenText.trim() || livePreviewForSheet.trim());

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900">
      {/* Crisp Pure-White Header */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-2.5 shrink-0">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 text-white shadow-xs">
              <Mic className="h-4 w-4" aria-hidden="true" />
            </span>
            <span className="text-base font-semibold tracking-tight text-slate-900 whitespace-nowrap">
              Sk Voice
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopyAll}
              disabled={!hasAnyText}
              aria-label="Copy clean text"
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 whitespace-nowrap transition-colors hover:bg-slate-50 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Copy</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleDownloadTxt}
              disabled={!hasAnyText}
              aria-label="Download clean text as .txt file"
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 whitespace-nowrap transition-colors hover:border-blue-200 hover:bg-blue-50/60 hover:text-blue-700 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {downloaded ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                  <span>Saved</span>
                </>
              ) : (
                <>
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>.TXT</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleClearAll}
              disabled={!hasAnyText}
              aria-label="Clear written text"
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-500 whitespace-nowrap transition-colors hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span className="hidden sm:inline">Clear</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Airy Pure-White Dictation Workspace */}
      <main className="mx-auto max-w-5xl space-y-4 px-4 py-5 sm:px-6 sm:py-7">
        {(notice || liveState.errorMessage) && (
          <div
            role="alert"
            className="flex items-center justify-between gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700"
          >
            <span>{notice || liveState.errorMessage}</span>
            <button
              type="button"
              onClick={() => {
                setNotice(null);
                clearError();
              }}
              className="min-h-[36px] shrink-0 rounded-lg px-2 text-xs font-semibold underline hover:opacity-80"
            >
              Dismiss
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12 lg:items-stretch lg:gap-6">
          {/* Left / Top Column: Languages + Live Voice Capture & Next */}
          <div className="flex flex-col gap-4 lg:col-span-5">
            <LanguageBar
              speakingCode={speakingCode}
              outputCode={outputCode}
              isTranslating={isTranslatingSheet}
              onSpeakingChange={handleSpeakingChange}
              onOutputChange={handleOutputChange}
              onSwap={handleSwapLanguages}
            />

            <LiveDictationPanel
              liveState={liveState}
              speakingCode={speakingCode}
              outputCode={outputCode}
              isCommittingNext={isCommittingNext}
              onToggleListening={handleToggleListening}
              onNext={handleNext}
            />
          </div>

          {/* Right / Bottom Column: Clean Written Text Sheet */}
          <div className="lg:col-span-7">
            <WrittenSheet
              writtenText={writtenText}
              livePreviewText={livePreviewForSheet}
              speakingCode={speakingCode}
              outputCode={outputCode}
              isTranslatingSheet={isTranslatingSheet}
              isCommittingNext={isCommittingNext}
              isEnhancingSheet={isEnhancingSheet}
              justEnhanced={justEnhanced}
              copied={copied}
              downloaded={downloaded}
              onWrittenTextChange={setWrittenText}
              onEnhanceText={handleEnhanceText}
              onCopyText={handleCopyAll}
              onDownloadTxt={handleDownloadTxt}
            />
          </div>
        </div>
      </main>

      {/* Microphone Permission Modal */}
      {permissionDenied && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="mic-permission-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/35 p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
            <div className="mb-3 flex items-center gap-2.5 text-rose-600">
              <AlertCircle className="h-5 w-5" aria-hidden="true" />
              <h2
                id="mic-permission-title"
                className="text-base font-semibold text-slate-900"
              >
                Microphone Access Required
              </h2>
            </div>
            <p className="text-sm leading-relaxed text-slate-600">
              Allow microphone permission in your browser settings to speak and write
              text live. No audio files are ever recorded or saved.
            </p>
            <div className="mt-5 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={dismissPermissionModal}
                className="min-h-[44px] rounded-xl border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  dismissPermissionModal();
                  startListening(speakingCode, outputCode, false);
                }}
                className="min-h-[44px] rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
              >
                Retry Microphone
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
