import React, { useState, useEffect, useMemo } from 'react';
import {
  Product,
  CartItem,
  Order,
  StoreSettings,
  AppLanguage,
  OrderStatus
} from './types';
import {
  getStoredProducts,
  saveProducts,
  getStoredOrders,
  saveOrder,
  updateOrderStatus,
  deleteOrder,
  getStoredSettings,
  saveSettings,
  getStoredCart,
  saveCart,
  getStoredLanguage,
  saveLanguage,
  formatPKR,
  generateWhatsAppOrderUrl
} from './utils/storage';
import { DEFAULT_PRODUCTS, DEFAULT_STORE_SETTINGS } from './data/defaultCatalog';

// Components
import { Header } from './components/Header';
import { CategoryFilter, CategoryFilterType } from './components/CategoryFilter';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { AdminPanel } from './components/AdminPanel';

// Icons
import {
  Search,
  MessageCircle,
  Phone,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Truck,
  CheckCircle2,
  XCircle,
  RotateCcw,
  SlidersHorizontal
} from 'lucide-react';

export default function App() {
  // Persistent State
  const [products, setProducts] = useState<Product[]>(getStoredProducts);
  const [orders, setOrders] = useState<Order[]>(getStoredOrders);
  const [settings, setSettings] = useState<StoreSettings>(getStoredSettings);
  const [cart, setCart] = useState<CartItem[]>(getStoredCart);
  const [language, setLanguage] = useState<AppLanguage>(getStoredLanguage);

  // UI State
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [customNotes, setCustomNotes] = useState('');

  const isUrdu = language === 'ur';

  // Synchronize cart changes to storage
  useEffect(() => {
    saveCart(cart);
  }, [cart]);

  // Synchronize language changes
  const toggleLanguage = () => {
    const nextLang = language === 'ur' ? 'en' : 'ur';
    setLanguage(nextLang);
    saveLanguage(nextLang);
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Cart Counts & Totals
  const totalCartCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  const totalCartPrice = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }, [cart]);

  // Products saving by Admin
  const handleSaveProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
    saveProducts(newProducts);
  };

  // Orders handling
  const handleOrderPlaced = (order: Order) => {
    saveOrder(order);
    setOrders(prev => [order, ...prev]);
    setLastPlacedOrder(order);
    setCart([]);
    setIsCheckoutOpen(false);
    setIsCartOpen(false);
    setCustomNotes('');

    // Automatically trigger WhatsApp direct send to Owais Bilal
    const whatsappUrl = generateWhatsAppOrderUrl(order, settings.whatsappNumber);
    try {
      window.open(whatsappUrl, '_blank');
    } catch (e) {
      // In case popup is blocked, the user has the big green button in the Success Modal
    }
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    const updated = updateOrderStatus(orderId, status);
    setOrders(updated);
  };

  const handleDeleteOrder = (orderId: string) => {
    const updated = deleteOrder(orderId);
    setOrders(updated);
  };

  const handleSaveSettings = (newSettings: StoreSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const handleResetCatalog = () => {
    setProducts(DEFAULT_PRODUCTS);
    saveProducts(DEFAULT_PRODUCTS);
    setSettings(DEFAULT_STORE_SETTINGS);
    saveSettings(DEFAULT_STORE_SETTINGS);
  };

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<CategoryFilterType, number> = {
      all: products.length,
      grocery: 0,
      general: 0,
      cosmetics: 0,
      pansar: 0,
      books: 0,
      offers: 0
    };

    products.forEach(p => {
      if (p.category in counts) {
        counts[p.category as CategoryFilterType]++;
      }
      if (p.originalPrice && p.originalPrice > p.price) {
        counts.offers++;
      }
    });

    return counts;
  }, [products]);

  // Filtered Products for customer view
  const displayProducts = useMemo(() => {
    return products.filter(product => {
      // Search Match
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        product.urduName.toLowerCase().includes(q) ||
        product.name.toLowerCase().includes(q) ||
        product.unit.toLowerCase().includes(q) ||
        (product.urduDescription && product.urduDescription.toLowerCase().includes(q)) ||
        (product.badge && product.badge.toLowerCase().includes(q));

      if (!matchesSearch) return false;

      // Category Match
      if (selectedCategory === 'all') return true;
      if (selectedCategory === 'offers') {
        return !!(product.originalPrice && product.originalPrice > product.price);
      }
      return product.category === selectedCategory;
    });
  }, [products, searchQuery, selectedCategory]);

  return (
    <div className={`min-h-screen bg-slate-100 flex flex-col font-sans ${isUrdu ? 'text-right' : 'text-left'}`}>
      {/* 1. Top Header */}
      <Header
        settings={settings}
        language={language}
        onLanguageToggle={toggleLanguage}
        cartCount={totalCartCount}
        cartTotal={totalCartPrice}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* 2. Hero Search Bar & Village Guarantee */}
      <section className="bg-emerald-800 text-white pb-4 px-3 sm:px-4 shadow-inner">
        <div className="max-w-7xl mx-auto">
          {/* Search Box */}
          <div className="relative max-w-2xl mx-auto mt-1">
            <Search className="w-5 h-5 text-emerald-300 absolute left-3.5 top-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isUrdu ? "سامان تلاش کریں (مثلاً: چاول، آٹا، لکس، شہد، کاپی...)" : "Search rice, flour, soap, honey, register..."}
              className="w-full bg-emerald-950/60 hover:bg-emerald-950/80 focus:bg-white focus:text-slate-900 focus:placeholder-slate-400 text-white placeholder-emerald-200/70 pl-11 pr-10 py-3 rounded-2xl border border-emerald-600/70 focus:border-white focus:outline-none focus:ring-4 focus:ring-emerald-400/30 text-sm font-medium transition shadow-md"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-emerald-200 hover:text-white p-0.5"
              >
                <XCircle className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Quick Village Delivery Highlights */}
          <div className="grid grid-cols-3 gap-2 max-w-2xl mx-auto mt-3 text-center text-[11px] sm:text-xs">
            <div className="bg-emerald-900/60 backdrop-blur-xs py-1.5 px-2 rounded-xl border border-emerald-700/50 flex items-center justify-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span className="font-medium truncate">{isUrdu ? 'دیہات میں ہوم ڈیلیوری' : 'Village Delivery'}</span>
            </div>
            <div className="bg-emerald-900/60 backdrop-blur-xs py-1.5 px-2 rounded-xl border border-emerald-700/50 flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="font-medium truncate">{isUrdu ? 'خالص اور اصلی سامان' : '100% Genuine'}</span>
            </div>
            <div className="bg-emerald-900/60 backdrop-blur-xs py-1.5 px-2 rounded-xl border border-emerald-700/50 flex items-center justify-center gap-1.5">
              <MessageCircle className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span className="font-medium truncate">{isUrdu ? 'فوری واٹس ایپ آرڈر' : 'WhatsApp Order'}</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Category Horizontal Filter Bar */}
      <CategoryFilter
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        language={language}
        categoryCounts={categoryCounts}
      />

      {/* 4. Main Products Catalog Grid */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5">
        {/* Category Header Title */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <span>
                {selectedCategory === 'all' && (isUrdu ? 'تمام دستیاب سامان' : 'All Available Items')}
                {selectedCategory === 'grocery' && (isUrdu ? '🛒 کریانہ، راشن اور مصالحہ جات' : '🛒 Grocery & Ration')}
                {selectedCategory === 'general' && (isUrdu ? '🏪 جنرل سٹور و گھریلو اشیاء' : '🏪 General Store')}
                {selectedCategory === 'cosmetics' && (isUrdu ? '💄 کاسمیٹکس و بیوٹی آئٹمز' : '💄 Cosmetics & Beauty')}
                {selectedCategory === 'pansar' && (isUrdu ? '🌿 پنسار، خالص شہد و دیسی جڑی بوٹیاں' : '🌿 Pansar Store & Herbs')}
                {selectedCategory === 'books' && (isUrdu ? '📚 بک ڈپو، کاپیاں، رجسٹر و اسٹیشنری' : '📚 Book Depot & Stationery')}
                {selectedCategory === 'offers' && (isUrdu ? '🏷️ خاص رعایتی قیمت والے سامان' : '🏷️ Special Discount Offers')}
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              {displayProducts.length} {isUrdu ? 'سامان موجود ہے' : 'products available'}
              {searchQuery && ` (تلاش: "${searchQuery}")`}
            </p>
          </div>

          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-emerald-700 font-bold hover:underline flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{isUrdu ? 'فلٹر ختم کریں' : 'Clear Search'}</span>
            </button>
          )}
        </div>

        {/* Product Cards Grid */}
        {displayProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 sm:p-12 text-center border border-slate-200 my-6 shadow-xs max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-800 text-base mb-1">
              {isUrdu ? 'کوئی سامان نہیں ملا' : 'No items match your search'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              {isUrdu 
                ? 'براہ کرم کوئی دوسرا نام تلاش کریں یا محمد اویس بلال کو واٹس ایپ پر لسٹ بھیج دیں'
                : 'Try another search term or contact Owais Bilal on WhatsApp directly'}
            </p>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                }}
                className="bg-emerald-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-xs hover:bg-emerald-800 transition"
              >
                {isUrdu ? 'تمام سامان دیکھیں' : 'View All Items'}
              </button>
              <a
                href={`https://wa.me/92${settings.whatsappNumber.replace(/\D/g, '').replace(/^0/, '')}?text=${encodeURIComponent('سلام علیکم اویس بھائی! مجھے سامان درکار ہے۔')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white border border-emerald-600 text-emerald-800 font-bold text-xs py-2 px-4 rounded-xl hover:bg-emerald-50 transition flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isUrdu ? 'اویس بلال کو واٹس ایپ کریں' : 'Contact Owais on WhatsApp'}</span>
              </a>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5 sm:gap-4">
            {displayProducts.map(product => {
              const inCartItem = cart.find(ci => ci.product.id === product.id);
              const qty = inCartItem ? inCartItem.quantity : 0;

              return (
                <ProductCard
                  key={product.id}
                  product={product}
                  quantityInCart={qty}
                  onAddToCart={handleAddToCart}
                  onUpdateQuantity={handleUpdateQuantity}
                  onViewDetails={setSelectedProductForDetail}
                  language={language}
                />
              );
            })}
          </div>
        )}
      </main>

      {/* 5. Village Customer Footer */}
      <footer className="bg-slate-900 text-slate-300 mt-12 border-t border-slate-800 pb-20 sm:pb-8">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Store & Owner Info */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-emerald-950 font-black flex items-center justify-center">
                  اویس
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">
                    {isUrdu ? settings.storeUrduName : settings.storeName}
                  </h3>
                  <p className="text-xs text-amber-400 font-semibold">
                    پروپرائیٹر: {settings.ownerName}
                  </p>
                </div>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed mt-2">
                {isUrdu
                  ? 'ہمارے گاؤں اور تمام قریبی دیہات کے لیے راشن، کریانہ، پنسار، کاسمیٹکس اور بک ڈپو کا مکمل سامان۔ گھر بیٹھے موبائل سے آرڈر کریں اور براہ راست واٹس ایپ پر ترسیل پائیں۔'
                  : 'Serving our village and surrounding areas with grocery, cosmetics, pansar, and stationery. Fast village delivery.'}
              </p>
            </div>

            {/* Direct Contact & WhatsApp */}
            <div className="space-y-2 text-xs">
              <h4 className="font-bold text-white text-sm mb-3">
                {isUrdu ? 'رابطہ و واٹس ایپ معلومات' : 'Contact & WhatsApp'}
              </h4>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-white font-mono font-bold text-sm">
                  {settings.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`https://wa.me/92${settings.whatsappNumber.replace(/\D/g, '').replace(/^0/, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white font-medium"
                >
                  {isUrdu ? 'واٹس ایپ: ' : 'WhatsApp: '} {settings.whatsappNumber}
                </a>
              </div>
              <p className="text-slate-400 text-[11px] mt-2">
                {isUrdu ? 'ڈیلیوری ایریا: ہمارا گاؤں، تمام چکس، ڈیرے اور قریبی دیہات' : 'Delivery: Village, all chaks, and surrounding farms'}
              </p>
            </div>

            {/* Admin & Security Link */}
            <div className="space-y-3">
              <h4 className="font-bold text-white text-sm">
                {isUrdu ? 'مالک کا مخصوص انتظام' : 'Store Management'}
              </h4>
              <p className="text-xs text-slate-400">
                {isUrdu
                  ? 'نیا سامان شامل کرنے اور آرڈرز دیکھنے کے لیے اویس بلال ایڈمن پینل کھولیں۔'
                  : 'Open the admin panel to add products and view customer orders.'}
              </p>
              <button
                onClick={() => setIsAdminOpen(true)}
                className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs border border-emerald-600 transition shadow-md active:scale-95"
              >
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>{isUrdu ? 'ایڈمن پینل لاگ ان (اویس بلال)' : 'Admin Panel Login'}</span>
              </button>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
            <div>
              © {new Date().getFullYear()} {settings.storeUrduName} • محمد اویس بلال 03017144300
            </div>
            <div className="flex items-center gap-2">
              <span>🇵🇰 پاکستان روپیہ (PKR)</span>
            </div>
          </div>
        </div>
      </footer>

      {/* 6. Mobile Bottom Sticky Navigation & Quick Checkout Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-3 py-2 shadow-xl sm:hidden">
        <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
          {/* Quick Call Owais Bilal */}
          <a
            href={`tel:${settings.phone}`}
            className="flex flex-col items-center justify-center p-1.5 text-slate-600 hover:text-emerald-700 transition"
          >
            <Phone className="w-5 h-5 text-emerald-700" />
            <span className="text-[10px] font-bold mt-0.5">{isUrdu ? 'فون کریں' : 'Call'}</span>
          </a>

          {/* Quick WhatsApp Chat */}
          <a
            href={`https://wa.me/92${settings.whatsappNumber.replace(/\D/g, '').replace(/^0/, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center p-1.5 text-slate-600 hover:text-emerald-700 transition"
          >
            <MessageCircle className="w-5 h-5 text-emerald-600" />
            <span className="text-[10px] font-bold mt-0.5">{isUrdu ? 'واٹس ایپ' : 'WhatsApp'}</span>
          </a>

          {/* Big Floating Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 px-3 rounded-2xl shadow-md flex items-center justify-between gap-2 transition active:scale-98"
          >
            <div className="flex items-center gap-1.5">
              <ShoppingBag className="w-4 h-4 text-amber-300" />
              <span className="text-xs">
                {totalCartCount > 0 ? `${totalCartCount} ${isUrdu ? 'سامان' : 'items'}` : (isUrdu ? 'شاپنگ تھیلا' : 'Cart')}
              </span>
            </div>
            <span className="font-black text-xs text-amber-300">
              {formatPKR(totalCartPrice, isUrdu)}
            </span>
          </button>

          {/* Admin Lock Button */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="flex flex-col items-center justify-center p-1.5 text-slate-600 hover:text-amber-600 transition"
            title="ایڈمن لاگ ان"
          >
            <ShieldCheck className="w-5 h-5 text-amber-600" />
            <span className="text-[10px] font-bold mt-0.5">{isUrdu ? 'ایڈمن' : 'Admin'}</span>
          </button>
        </div>
      </div>

      {/* 7. Modals and Drawers */}
      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProductForDetail}
        onClose={() => setSelectedProductForDetail(null)}
        quantityInCart={
          selectedProductForDetail
            ? (cart.find(ci => ci.product.id === selectedProductForDetail.id)?.quantity || 0)
            : 0
        }
        onAddToCart={handleAddToCart}
        onUpdateQuantity={handleUpdateQuantity}
        language={language}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        settings={settings}
        language={language}
        customNotes={customNotes}
        setCustomNotes={setCustomNotes}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        settings={settings}
        language={language}
        customNotes={customNotes}
        onOrderPlaced={handleOrderPlaced}
      />

      {/* Order Success Receipt Modal */}
      <OrderSuccessModal
        order={lastPlacedOrder}
        onClose={() => setLastPlacedOrder(null)}
        settings={settings}
        language={language}
      />

      {/* Admin Panel */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        products={products}
        orders={orders}
        settings={settings}
        onSaveProducts={handleSaveProducts}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        onDeleteOrder={handleDeleteOrder}
        onSaveSettings={handleSaveSettings}
        onResetCatalog={handleResetCatalog}
        language={language}
      />
    </div>
  );
}
