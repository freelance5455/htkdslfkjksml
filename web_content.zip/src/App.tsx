import React, { useState, useEffect } from 'react';
import { PhoneFrame } from './components/PhoneFrame';
import { ChatTab } from './components/ChatTab';
import { VoiceTab } from './components/VoiceTab';
import { PhoneToolsTab } from './components/PhoneToolsTab';
import { CryptoTab } from './components/CryptoTab';
import { MemoryTab } from './components/MemoryTab';
import { AndroidCodeTab } from './components/AndroidCodeTab';
import { AppStudioTab } from './components/AppStudioTab';
import { SettingsTab } from './components/SettingsTab';
import { SupportedLanguage, ActionProposal, UserMemory } from './types';
import { CheckCircle2, Brain } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('chat');
  const [language, setLanguage] = useState<SupportedLanguage>('roman_urdu');
  const [isForegroundActive, setIsForegroundActive] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isMemoryToast, setIsMemoryToast] = useState(false);
  const [isAPKModalOpen, setIsAPKModalOpen] = useState(false);

  // DOST Mind: User Memories
  const [memories, setMemories] = useState<UserMemory[]>(() => {
    const saved = localStorage.getItem('dost_mind_memories');
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'mem-1',
            category: 'Routine',
            fact: 'User subah 9:00 AM wake up karta hai aur pehle Bitcoin & crypto charts check karta hai.',
            learnedAt: Date.now() - 86400000 * 3,
          },
          {
            id: 'mem-2',
            category: 'Preference',
            fact: 'Trading preference: Bitcoin (BTC) aur Solana (SOL) par 1H aur 4H timeframes par strictly 2% risk limit ke sath kaam karta hai.',
            learnedAt: Date.now() - 86400000 * 2,
          },
          {
            id: 'mem-3',
            category: 'Goal',
            fact: 'Daily target: Disciplined demo risk management seekhna aur DOST AI se daily crypto market signals lena.',
            learnedAt: Date.now() - 86400000,
          },
          {
            id: 'mem-4',
            category: 'Personal',
            fact: 'Bole jaane wali zuban: Roman Urdu aur Urdu; DOST se direct, wafadar aur practical mashwaray chahta hai.',
            learnedAt: Date.now() - 3600000,
          },
        ];
  });

  const showToast = (msg: string, isMemory: boolean = false) => {
    setToastMessage(msg);
    setIsMemoryToast(isMemory);
    setTimeout(() => {
      setToastMessage(null);
      setIsMemoryToast(false);
    }, 4000);
  };

  const handleAddMemory = (category: UserMemory['category'], fact: string) => {
    const newMem: UserMemory = {
      id: `mem-${Date.now()}`,
      category,
      fact,
      learnedAt: Date.now(),
    };
    const updated = [newMem, ...memories];
    setMemories(updated);
    localStorage.setItem('dost_mind_memories', JSON.stringify(updated));
    showToast(`DOST Mind: Yaad Rakh Liya ("${fact.slice(0, 35)}...")`, true);
  };

  const handleDeleteMemory = (id: string) => {
    const updated = memories.filter((m) => m.id !== id);
    setMemories(updated);
    localStorage.setItem('dost_mind_memories', JSON.stringify(updated));
    showToast('Memory forgotten from DOST Mind');
  };

  const handleAutoLearnMemory = (fact: string) => {
    handleAddMemory('Preference', fact);
  };

  // Dispatch and execute action proposed by Gemini Brain
  const handleExecuteAction = (action: ActionProposal) => {
    switch (action.type) {
      case 'open_app': {
        const target = (action.target || '').toLowerCase();
        if (target === 'camera') {
          setActiveTab('phone_tools');
          showToast('Opened Camera Tool (WebRTC Stream)');
        } else if (target === 'youtube') {
          window.open('https://youtube.com', '_blank');
          showToast('Dispatched Intent: com.google.android.youtube');
        } else if (target === 'chrome') {
          window.open('https://google.com', '_blank');
          showToast('Dispatched Intent: com.android.chrome');
        } else if (target === 'settings') {
          setActiveTab('settings');
          showToast('Opened Android Settings');
        } else if (target === 'messages') {
          setActiveTab('phone_tools');
          showToast('Opened SMS Composer');
        } else if (target === 'maps' || target.includes('map')) {
          window.open('https://www.google.com/maps', '_blank');
          showToast('Dispatched Google Maps Live GPS Intent');
        } else if (target === 'calculator') {
          setActiveTab('phone_tools');
          showToast('Opened Calculator');
        } else {
          showToast(`Intent dispatched for ${target}`);
        }
        break;
      }
      case 'flashlight': {
        setActiveTab('phone_tools');
        showToast('⚡ Flashlight / Torch Controller Activated');
        break;
      }
      case 'vibrate': {
        if ('vibrate' in navigator) {
          navigator.vibrate([200, 100, 200]);
        }
        showToast('📳 Haptic Vibration Dispatched to Device');
        break;
      }
      case 'screen_wake': {
        setActiveTab('phone_tools');
        if ('wakeLock' in navigator) {
          (navigator as any).wakeLock.request('screen').then(() => {
            showToast('🔒 Screen Wake Lock Active (Display will stay awake)');
          }).catch(() => {
            showToast('Screen Wake Lock Toggled');
          });
        } else {
          showToast('Screen Wake Lock Toggled');
        }
        break;
      }
      case 'speaker_test': {
        try {
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          const ctx = new AudioContextClass();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.frequency.setValueAtTime(165, ctx.currentTime);
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 2.5);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 2.5);
          showToast('🔊 Playing 165Hz Speaker Water Eject Frequency');
        } catch {
          showToast('🔊 Speaker Water Ejection Frequency Triggered');
        }
        break;
      }
      case 'open_settings': {
        setActiveTab('phone_tools');
        showToast(`Dispatched Android Setting Intent: ${action.target || 'System Settings'}`);
        break;
      }
      case 'quick_tool': {
        setActiveTab('phone_tools');
        showToast(`Quick Tool Action: ${action.target || 'Toggled'}`);
        break;
      }
      case 'analyze_crypto':
      case 'daily_signals': {
        setActiveTab('crypto');
        showToast(`Opened Crypto Hub: ${action.target || 'Daily Signals'}`);
        break;
      }
      case 'send_sms': {
        setActiveTab('phone_tools');
        showToast(`SMS Composer prepared for ${action.recipient || 'recipient'}`);
        break;
      }
      case 'whatsapp_chat': {
        const phone = (action.recipient || '+923001234567').replace(/[^0-9]/g, '');
        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(action.message || 'Salam')}`, '_blank');
        showToast(`Dispatched WhatsApp intent for ${phone}`);
        break;
      }
      case 'set_alarm': {
        setActiveTab('phone_tools');
        showToast('Alarm Clock set via Intent.ACTION_SET_ALARM');
        break;
      }
      case 'calculator': {
        setActiveTab('phone_tools');
        showToast('Calculator tool opened');
        break;
      }
      case 'take_note': {
        setActiveTab('phone_tools');
        showToast('Note created in local storage');
        break;
      }
      case 'create_app':
      case 'run_code': {
        setActiveTab('app_studio');
        showToast(`⚡ Launching Generated App: ${action.appTitle || 'App Studio'}`);
        break;
      }
      case 'open_apk_modal':
      case 'download_apk': {
        setIsAPKModalOpen(true);
        showToast('📱 Opening APK & Mobile Installation Center');
        break;
      }
      default:
        showToast(`Action dispatched: ${action.type}`);
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-950 font-sans selection:bg-cyan-500/30">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-semibold animate-in fade-in slide-in-from-top-4 ${
            isMemoryToast
              ? 'bg-purple-950/95 border border-purple-500/60 text-purple-200'
              : 'bg-slate-900 border border-cyan-500/50 text-cyan-300'
          }`}
        >
          {isMemoryToast ? (
            <Brain className="w-4 h-4 text-purple-400 animate-pulse" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          )}
          <span>{toastMessage}</span>
        </div>
      )}

      <PhoneFrame
        activeTab={activeTab}
        onTabChange={setActiveTab}
        language={language}
        onLanguageChange={setLanguage}
        isForegroundActive={isForegroundActive}
        isAPKModalOpen={isAPKModalOpen}
        onOpenAPKModal={() => setIsAPKModalOpen(true)}
        onCloseAPKModal={() => setIsAPKModalOpen(false)}
        onToggleForeground={() => {
          setIsForegroundActive(!isForegroundActive);
          showToast(
            isForegroundActive
              ? 'Foreground Service Stopped'
              : 'Foreground Service Started (Persistent Notification Active)'
          );
        }}
      >
        {activeTab === 'chat' && (
          <ChatTab
            language={language}
            onExecuteAction={handleExecuteAction}
            onNavigateToTab={setActiveTab}
            memories={memories}
            onSaveMemory={handleAutoLearnMemory}
          />
        )}
        {activeTab === 'voice' && (
          <VoiceTab
            language={language}
            onExecuteAction={handleExecuteAction}
            isForegroundActive={isForegroundActive}
            memories={memories}
            onSaveMemory={handleAutoLearnMemory}
          />
        )}
        {activeTab === 'phone_tools' && <PhoneToolsTab language={language} />}
        {activeTab === 'crypto' && <CryptoTab language={language} />}
        {activeTab === 'memory' && (
          <MemoryTab
            memories={memories}
            onAddMemory={handleAddMemory}
            onDeleteMemory={handleDeleteMemory}
            language={language}
          />
        )}
        {activeTab === 'app_studio' && <AppStudioTab language={language} />}
        {activeTab === 'android_code' && (
          <AndroidCodeTab onOpenAPKModal={() => setIsAPKModalOpen(true)} />
        )}
        {activeTab === 'settings' && (
          <SettingsTab
            language={language}
            onLanguageChange={setLanguage}
            isForegroundActive={isForegroundActive}
            onToggleForeground={() => setIsForegroundActive(!isForegroundActive)}
            onOpenAPKModal={() => setIsAPKModalOpen(true)}
          />
        )}
      </PhoneFrame>
    </div>
  );
}
