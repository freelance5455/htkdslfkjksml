import React, { useEffect, useRef, useState } from 'react';
import {
  Backpack,
  Compass,
  Crown,
  Download,
  Eye,
  EyeOff,
  Hammer,
  RotateCw,
  ScrollText,
  Settings,
  Sparkles,
  User,
  Check,
  X,
} from 'lucide-react';
import { BUILDABLES } from './game/config/craftingAndBuilding';
import { ITEM_MAP } from './game/config/items';
import { SPELL_MAP } from './game/config/magic';
import { QUEST_MAP } from './game/config/questsAndNpcs';
import { GameEngine, HudSnapshot } from './game/GameEngine';
import {
  clearSavedGame,
  createNewSaveData,
  loadSavedGame,
  saveGameToDisk,
} from './game/save/SaveSystem';
import {
  ChatMessage,
  ElementType,
  GameSettings,
  PlayerAppearance,
  RegionId,
  RemotePlayer,
  SaveData,
  StructureType,
} from './game/types/gameTypes';
import { CharacterCustomizerModal, NpcDialogueModal, SystemAndOnlineModal } from './game/ui/CharacterAndSystemPanels';
import { Minimap } from './game/ui/Minimap';
import { RpgPanels } from './game/ui/RpgPanels';
import { TouchControls } from './game/ui/TouchControls';
import { usePWAInstall } from './game/ui/usePWAInstall';

type ModalType = null | 'inventory' | 'magic' | 'craft' | 'quests' | 'map' | 'character' | 'system' | 'npc' | 'ending';

interface ToastItem {
  id: number;
  text: string;
  tone: 'info' | 'warn' | 'epic';
}

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [saveData, setSaveData] = useState<SaveData>(() => loadSavedGame() || createNewSaveData());
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [modal, setModal] = useState<ModalType>(null);
  const [activeNpcId, setActiveNpcId] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [sprinting, setSprinting] = useState(false);
  const [zenHud, setZenHud] = useState(false);
  const [placingType, setPlacingType] = useState<StructureType | null>(null);

  const [mpStatus, setMpStatus] = useState<'offline' | 'connecting' | 'online'>('offline');
  const [mpRoom, setMpRoom] = useState('');
  const [remotePlayers, setRemotePlayers] = useState<RemotePlayer[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  const { isInstallable, isInstalled, install } = usePWAInstall();

  const pushToast = (text: string, tone: 'info' | 'warn' | 'epic' = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev.slice(-3), { id, text, tone }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  };

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const initial = loadSavedGame() || createNewSaveData();
    setSaveData(initial);

    const engine = new GameEngine(el, initial, {
      onHudUpdate: (snap) => setHud(snap),
      onStateChange: (data) => {
        setSaveData(data);
        saveGameToDisk(data);
      },
      onNotification: (msg, tone = 'info') => pushToast(msg, tone),
      onOpenNpc: (npcId) => {
        setActiveNpcId(npcId);
        setModal('npc');
      },
      onStoryEnding: () => setModal('ending'),
      onMultiplayerStatus: (status, roomCode, players) => {
        setMpStatus(status);
        if (roomCode) setMpRoom(roomCode);
        setRemotePlayers(players);
      },
      onChatMessage: (msg) => setChatMessages((prev) => [...prev.slice(-30), msg]),
    });

    engineRef.current = engine;

    const onKeyH = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if (e.code === 'KeyH') setZenHud((v) => !v);
    };
    window.addEventListener('keydown', onKeyH);

    return () => {
      window.removeEventListener('keydown', onKeyH);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const syncSave = (next: SaveData) => {
    if (engineRef.current) {
      engineRef.current.saveData = next;
    }
    setSaveData({ ...next });
    saveGameToDisk(next);
  };

  const handleEquipItem = (itemId: string) => {
    const item = ITEM_MAP[itemId];
    if (!item || !item.slot || !engineRef.current) return;
    const next = { ...engineRef.current.saveData };
    next.equipped = { ...next.equipped, [item.slot]: itemId };
    engineRef.current.saveData = next;
    engineRef.current.rebuildPlayerModel();
    syncSave(next);
    pushToast(`Equipped ${item.name}`);
  };

  const handleUseConsumable = (itemId: string) => {
    const item = ITEM_MAP[itemId];
    const eng = engineRef.current;
    if (!item || !eng) return;
    if (!eng.consumeItem(itemId, 1)) return;
    const s = eng.saveData.stats;
    if (item.healHp) s.hp = Math.min(s.maxHp, s.hp + item.healHp);
    if (item.healMana) s.mana = Math.min(s.maxMana, s.mana + item.healMana);
    if (item.restoreHunger) s.hunger = Math.min(s.maxHunger, s.hunger + item.restoreHunger);
    syncSave(eng.saveData);
    pushToast(`Used ${item.name}`);
  };

  const handleSelectSpell = (el: ElementType, spellId: string) => {
    const eng = engineRef.current;
    if (!eng) return;
    eng.saveData.selectedSpells = { ...eng.saveData.selectedSpells, [el]: spellId };
    syncSave(eng.saveData);
  };

  const handleUnlockOrUpgradeSpell = (spellId: string) => {
    const eng = engineRef.current;
    const sp = SPELL_MAP[spellId];
    if (!eng || !sp) return;
    const unlocked = eng.saveData.unlockedSpells.includes(spellId);
    if (!unlocked) {
      if (eng.saveData.stats.level < sp.unlockLevel) {
        pushToast(`Requires Level ${sp.unlockLevel}!`, 'warn');
        return;
      }
      if (eng.saveData.stats.skillPoints < 1) {
        pushToast('Requires 1 Skill Point!', 'warn');
        return;
      }
      eng.saveData.stats.skillPoints -= 1;
      eng.saveData.unlockedSpells.push(spellId);
      eng.saveData.spellLevels[spellId] = 1;
      eng.saveData.selectedSpells[sp.element] = spellId;
      pushToast(`Unlocked ${sp.name}!`, 'epic');
    } else {
      if (eng.saveData.stats.skillPoints < 1) {
        pushToast('Requires 1 Skill Point to upgrade!', 'warn');
        return;
      }
      eng.saveData.stats.skillPoints -= 1;
      eng.saveData.spellLevels[spellId] = (eng.saveData.spellLevels[spellId] || 1) + 1;
      pushToast(`Upgraded ${sp.name} to Lv.${eng.saveData.spellLevels[spellId]}!`, 'epic');
    }
    syncSave(eng.saveData);
  };

  const handleUpgradeSkill = (skillId: string) => {
    const eng = engineRef.current;
    if (!eng || eng.saveData.stats.skillPoints < 1) return;
    eng.saveData.stats.skillPoints -= 1;
    eng.saveData.skillRanks[skillId] = (eng.saveData.skillRanks[skillId] || 0) + 1;
    if (skillId === 'iron_skin') {
      eng.saveData.stats.maxHp += 25;
      eng.saveData.stats.hp += 25;
    } else if (skillId === 'arcane_reservoir') {
      eng.saveData.stats.maxMana += 25;
      eng.saveData.stats.mana += 25;
    } else if (skillId === 'windrunner') {
      eng.saveData.stats.maxStamina += 20;
    }
    syncSave(eng.saveData);
    pushToast('Skill trained!', 'epic');
  };

  const handleCraftRecipe = (recipeId: string) => {
    const eng = engineRef.current;
    if (!eng) return;
    import('./game/config/craftingAndBuilding').then(({ CRAFTING_RECIPES }) => {
      const rec = CRAFTING_RECIPES.find((r) => r.id === recipeId);
      if (!rec) return;
      for (const ing of rec.ingredients) {
        if (eng.getItemCount(ing.itemId) < ing.count) {
          pushToast('Missing crafting materials!', 'warn');
          return;
        }
      }
      for (const ing of rec.ingredients) eng.consumeItem(ing.itemId, ing.count);
      eng.addItem(rec.resultItemId, rec.resultCount);
      syncSave(eng.saveData);
      pushToast(`Crafted ${ITEM_MAP[rec.resultItemId]?.name} x${rec.resultCount}`, 'epic');
    });
  };

  const handleStartBuilding = (type: StructureType) => {
    const eng = engineRef.current;
    const def = BUILDABLES.find((b) => b.type === type);
    if (!eng || !def) return;
    for (const c of def.cost) {
      if (eng.getItemCount(c.itemId) < c.count) {
        pushToast('Not enough building resources!', 'warn');
        return;
      }
    }
    setPlacingType(type);
    eng.startBuilding(type);
    setModal(null);
  };

  const handleConfirmBuild = () => {
    const eng = engineRef.current;
    if (!eng || !placingType) return;
    const def = BUILDABLES.find((b) => b.type === placingType);
    if (!def) return;
    for (const c of def.cost) eng.consumeItem(c.itemId, c.count);
    eng.confirmPlacement();
    setPlacingType(null);
    pushToast(`Constructed ${def.name}!`, 'epic');
  };

  const handleAcceptQuest = (questId: string) => {
    const eng = engineRef.current;
    const q = QUEST_MAP[questId];
    if (!eng || !q || eng.saveData.quests[questId]) return;
    const counts: Record<string, number> = {};
    for (const obj of q.objectives) {
      counts[obj.id] = obj.targetType === 'collect_item' ? Math.min(obj.requiredCount, eng.getItemCount(obj.targetId)) : 0;
    }
    const completed = q.objectives.every((o) => counts[o.id] >= o.requiredCount);
    eng.saveData.quests[questId] = { questId, counts, completed, claimed: false };
    syncSave(eng.saveData);
    pushToast(`Accepted Quest: ${q.title}`);
  };

  const handleClaimQuest = (questId: string) => {
    const eng = engineRef.current;
    const q = QUEST_MAP[questId];
    const prog = eng?.saveData.quests[questId];
    if (!eng || !q || !prog || !prog.completed || prog.claimed) return;
    prog.claimed = true;
    eng.gainXp(q.xpReward);
    eng.saveData.stats.gold += q.goldReward;
    for (const itemId of q.itemRewards) eng.addItem(itemId, 1);
    syncSave(eng.saveData);
    pushToast(`Quest Completed! +${q.xpReward} XP, +${q.goldReward} Gold`, 'epic');
  };

  const handleBuyItem = (itemId: string) => {
    const eng = engineRef.current;
    const item = ITEM_MAP[itemId];
    if (!eng || !item || eng.saveData.stats.gold < item.value) return;
    eng.saveData.stats.gold -= item.value;
    eng.addItem(itemId, 1);
    syncSave(eng.saveData);
    pushToast(`Bought ${item.name}`);
  };

  const handleSellItem = (itemId: string) => {
    const eng = engineRef.current;
    const item = ITEM_MAP[itemId];
    if (!eng || !item || !eng.consumeItem(itemId, 1)) return;
    const g = Math.max(2, Math.floor(item.value * 0.55));
    eng.saveData.stats.gold += g;
    syncSave(eng.saveData);
    pushToast(`Sold ${item.name} (+${g} Gold)`);
  };

  const isTouchDevice =
    typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);
  const showTouchControls =
    saveData.settings.hudLayout.showTouchControls === 'always' ||
    (saveData.settings.hudLayout.showTouchControls === 'auto' && isTouchDevice);

  const computedStats = engineRef.current?.getComputedStats() || {
    atk: saveData.stats.baseStrength,
    def: saveData.stats.baseDefense,
    mag: saveData.stats.baseMagic,
    spd: saveData.stats.baseSpeed,
  };

  const formatTime = (t: number) => {
    const hr = Math.floor(t);
    const min = Math.floor((t - hr) * 60);
    return `${String(hr).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
  };

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#0b0f17]">
      {/* Dedicated WebGL Mount Container */}
      <div ref={mountRef} className="fixed inset-0 w-full h-full" />

      {/* Touch & Camera Control Layer */}
      {!modal && (
        <TouchControls
          visibleControls={!zenHud && showTouchControls}
          hudLayout={saveData.settings.hudLayout}
          selectedSpells={saveData.selectedSpells}
          spellCooldowns={hud?.spellCooldowns || {}}
          nearbyPrompt={hud?.nearbyPrompt || null}
          cameraMode={hud?.cameraMode || 'third'}
          sprinting={sprinting}
          onMove={(x, y) => engineRef.current?.setJoystickVector(x, y)}
          onLook={(dx, dy) => engineRef.current?.rotateCamera(dx, dy)}
          onAttack={() => engineRef.current?.performAttack()}
          onAttackHold={(active) => engineRef.current?.setAttackHeld(active)}
          onJump={() => engineRef.current?.jump()}
          onDodge={() => engineRef.current?.performDodge()}
          onInteract={() => engineRef.current?.interact()}
          onToggleSprint={() => {
            const next = !sprinting;
            setSprinting(next);
            engineRef.current?.setSprint(next);
          }}
          onToggleCamera={() => engineRef.current?.toggleCameraMode()}
          onCastElement={(el) => engineRef.current?.castElement(el)}
        />
      )}

      {/* Top HUD Bar */}
      {!zenHud && hud && (
        <div className="fixed top-3 left-3 right-3 z-20 flex items-start justify-between gap-3 pointer-events-none">
          {/* Top-Left Vitals & Region */}
          <div className="pointer-events-auto bg-[#0c121e]/90 border border-slate-700/70 rounded-xl px-3.5 py-2.5 shadow-xl w-56 sm:w-64 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-display font-bold text-amber-200 truncate">{saveData.appearance.name}</span>
              <span className="font-mono-num text-amber-300 font-semibold">Lv.{hud.stats.level}</span>
            </div>

            {/* HP */}
            <div className="space-y-1">
              <div className="h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-red-500 transition-all duration-150"
                  style={{ width: `${Math.max(0, Math.min(100, (hud.stats.hp / hud.stats.maxHp) * 100))}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] font-mono-num text-slate-300">
                <span>HP {Math.ceil(hud.stats.hp)}/{hud.stats.maxHp}</span>
                <span>MP {Math.floor(hud.stats.mana)}/{hud.stats.maxMana}</span>
              </div>
              <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-sky-500 transition-all duration-150"
                  style={{ width: `${Math.max(0, Math.min(100, (hud.stats.mana / hud.stats.maxMana) * 100))}%` }}
                />
              </div>
              <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-emerald-400 transition-all duration-150"
                  style={{ width: `${Math.max(0, Math.min(100, (hud.stats.stamina / hud.stats.maxStamina) * 100))}%` }}
                />
              </div>
              {saveData.settings.survivalMode && (
                <div className="flex items-center justify-between text-[10px] text-amber-200/80 font-mono-num">
                  <span>Hunger {Math.round(hud.stats.hunger)}%</span>
                  <span>XP {hud.stats.xp}/{hud.stats.xpToNext}</span>
                </div>
              )}
            </div>

            <div className="pt-1 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-300">
              <span className="truncate font-medium">{hud.regionName}</span>
              <span className="font-mono-num text-slate-400 shrink-0 ml-1">
                {formatTime(hud.timeOfDay)} · {hud.weather}
              </span>
            </div>
          </div>

          {/* Center-Top Active Boss or Target Creature/Enemy Health Bar */}
          {hud.activeBoss ? (
            <div className="hidden md:flex flex-col items-center bg-[#140e1a]/95 border border-purple-500/50 rounded-xl px-5 py-2.5 shadow-2xl w-80 pointer-events-none">
              <div className="text-xs font-display font-bold text-amber-200">
                {hud.activeBoss.name} — {hud.activeBoss.title}
              </div>
              <div className="w-full h-3 rounded-full bg-slate-900 border border-slate-700 overflow-hidden mt-1.5">
                <div
                  className="h-full bg-gradient-to-r from-rose-600 to-amber-500"
                  style={{ width: `${(hud.activeBoss.hp / hud.activeBoss.maxHp) * 100}%` }}
                />
              </div>
              <div className="w-full flex justify-between text-[10px] font-mono-num text-slate-300 mt-1">
                <span>{hud.activeBoss.locked ? 'Sealed (Defeat 7 Bosses)' : `Phase ${hud.activeBoss.phase}`}</span>
                <span>
                  {Math.ceil(hud.activeBoss.hp)} / {hud.activeBoss.maxHp}
                </span>
              </div>
            </div>
          ) : hud.targetEntity ? (
            <div className="hidden sm:flex flex-col items-center bg-[#0c121e]/92 border border-slate-600/70 rounded-xl px-4 py-2 shadow-xl w-64 pointer-events-none">
              <div className="w-full flex items-center justify-between text-xs gap-2">
                <span className="font-display font-bold text-slate-100 truncate">{hud.targetEntity.name}</span>
                <span
                  className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                    hud.targetEntity.kind === 'creature'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                      : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  {hud.targetEntity.kind === 'creature'
                    ? 'Creature'
                    : `Lv.${hud.targetEntity.level || 1}`}
                </span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-900 border border-slate-700 overflow-hidden mt-1.5">
                <div
                  className={`h-full transition-all duration-100 ${
                    hud.targetEntity.kind === 'creature'
                      ? 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                      : 'bg-gradient-to-r from-red-600 to-orange-400'
                  }`}
                  style={{
                    width: `${Math.max(0, Math.min(100, (hud.targetEntity.hp / Math.max(1, hud.targetEntity.maxHp)) * 100))}%`,
                  }}
                />
              </div>
              <div className="w-full flex justify-between text-[10px] font-mono-num text-slate-300 mt-1">
                <span>{hud.targetEntity.kind === 'creature' ? 'Peaceful' : 'Hostile'}</span>
                <span>
                  {Math.ceil(hud.targetEntity.hp)} / {hud.targetEntity.maxHp} HP
                </span>
              </div>
            </div>
          ) : null}

          {/* Top-Right Minimap & Menu Buttons */}
          <div className="pointer-events-auto flex items-start gap-2">
            <div className="flex flex-wrap justify-end gap-1.5 max-w-[200px] sm:max-w-none">
              <button
                type="button"
                onClick={() => setModal('inventory')}
                title="Inventory & Equipment"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 hover:border-amber-400/60 flex items-center gap-1.5 text-xs font-semibold"
              >
                <Backpack className="w-4 h-4 text-amber-300" />
                <span className="hidden lg:inline">Bag</span>
              </button>
              <button
                type="button"
                onClick={() => setModal('magic')}
                title="Elemental Magic & Skills"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 hover:border-sky-400/60 flex items-center gap-1.5 text-xs font-semibold"
              >
                <Sparkles className="w-4 h-4 text-sky-300" />
                <span className="hidden lg:inline">Magic</span>
              </button>
              <button
                type="button"
                onClick={() => setModal('craft')}
                title="Crafting & Building"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 hover:border-emerald-400/60 flex items-center gap-1.5 text-xs font-semibold"
              >
                <Hammer className="w-4 h-4 text-emerald-300" />
                <span className="hidden lg:inline">Craft</span>
              </button>
              <button
                type="button"
                onClick={() => setModal('quests')}
                title="Quests & Field Codex"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 hover:border-purple-400/60 flex items-center gap-1.5 text-xs font-semibold"
              >
                <ScrollText className="w-4 h-4 text-purple-300" />
                <span className="hidden lg:inline">Quests</span>
              </button>
              <button
                type="button"
                onClick={() => setModal('map')}
                title="World Map"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 hover:border-sky-400/60 flex items-center gap-1.5 text-xs font-semibold"
              >
                <Compass className="w-4 h-4 text-cyan-300" />
                <span className="hidden lg:inline">Map</span>
              </button>
              <button
                type="button"
                onClick={() => setModal('character')}
                title="Customize Hero"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 flex items-center gap-1.5 text-xs font-semibold"
              >
                <User className="w-4 h-4 text-rose-300" />
              </button>
              <button
                type="button"
                onClick={() => setModal('system')}
                title="Settings, Save & Online Co-op"
                className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-[#0c121e]/90 border border-slate-700/80 text-slate-100 flex items-center gap-1.5 text-xs font-semibold"
              >
                <Settings className="w-4 h-4 text-slate-300" />
              </button>
              {!isInstalled && isInstallable && (
                <button
                  type="button"
                  onClick={install}
                  title="Install App on Device"
                  className="min-w-[44px] min-h-[44px] px-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold flex items-center gap-1 text-xs"
                >
                  <Download className="w-4 h-4" />
                </button>
              )}
            </div>
            <Minimap hud={hud} onOpenMap={() => setModal('map')} />
          </div>
        </div>
      )}

      {/* Zen / Hide HUD Toggle (Bottom-Center) */}
      <div className="fixed bottom-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
        {placingType ? (
          <div className="flex items-center gap-2 bg-[#0c121e]/95 border border-sky-400/60 px-3 py-2 rounded-xl shadow-xl">
            <span className="text-xs font-semibold text-sky-200 capitalize">Placing {placingType}</span>
            <button
              type="button"
              onClick={() => engineRef.current?.rotateBuildPreview()}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-100 text-xs font-semibold flex items-center gap-1"
            >
              <RotateCw className="w-3.5 h-3.5" />
              Rotate
            </button>
            <button
              type="button"
              onClick={handleConfirmBuild}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold flex items-center gap-1"
            >
              <Check className="w-3.5 h-3.5" />
              Confirm
            </button>
            <button
              type="button"
              onClick={() => {
                engineRef.current?.startBuilding(null);
                setPlacingType(null);
              }}
              className="px-3 py-1.5 rounded-lg bg-red-700 text-white text-xs font-semibold flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              Cancel
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setZenHud((v) => !v)}
            title="Toggle HUD (H)"
            className="px-3 py-1.5 rounded-lg bg-[#0c121e]/85 border border-slate-700/70 text-[11px] text-slate-300 hover:text-white flex items-center gap-1.5"
          >
            {zenHud ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>{zenHud ? 'Show HUD' : 'Hide HUD'}</span>
            {!isTouchDevice && !zenHud && (
              <span className="hidden sm:inline text-slate-500 ml-1">
                · WASD Move · Drag Look · F Attack · 1-4 Spells · V Camera
              </span>
            )}
          </button>
        )}
      </div>

      {/* Toast Notifications */}
      <div className="fixed top-28 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1.5 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold shadow-lg border ${
              t.tone === 'epic'
                ? 'bg-amber-950/95 border-amber-400/60 text-amber-100'
                : t.tone === 'warn'
                  ? 'bg-red-950/95 border-red-400/60 text-red-100'
                  : 'bg-[#0e1420]/95 border-slate-600/60 text-slate-100'
            }`}
          >
            {t.text}
          </div>
        ))}
      </div>

      {/* Modals */}
      {(modal === 'inventory' || modal === 'magic' || modal === 'craft' || modal === 'quests' || modal === 'map') && (
        <RpgPanels
          activeTab={modal}
          saveData={saveData}
          playerPos={hud ? { x: hud.position.x, z: hud.position.z } : undefined}
          computedStats={computedStats}
          onClose={() => setModal(null)}
          onEquipItem={handleEquipItem}
          onUseConsumable={handleUseConsumable}
          onSelectSpell={handleSelectSpell}
          onUnlockOrUpgradeSpell={handleUnlockOrUpgradeSpell}
          onUpgradeSkill={handleUpgradeSkill}
          onCraftRecipe={handleCraftRecipe}
          onStartBuilding={handleStartBuilding}
          onClaimQuest={handleClaimQuest}
          onAcceptQuest={handleAcceptQuest}
          onTeleportRegion={(rid: RegionId) => engineRef.current?.teleportToRegion(rid)}
        />
      )}

      {modal === 'character' && (
        <CharacterCustomizerModal
          appearance={saveData.appearance}
          onSave={(a: PlayerAppearance) => engineRef.current?.updateAppearance(a)}
          onClose={() => setModal(null)}
        />
      )}

      {modal === 'npc' && activeNpcId && (
        <NpcDialogueModal
          npcId={activeNpcId}
          saveData={saveData}
          onBuyItem={handleBuyItem}
          onSellItem={handleSellItem}
          onAcceptQuest={handleAcceptQuest}
          onClaimQuest={handleClaimQuest}
          onClose={() => setModal(null)}
        />
      )}

      {modal === 'system' && (
        <SystemAndOnlineModal
          saveData={saveData}
          mpStatus={mpStatus}
          mpRoom={mpRoom}
          remotePlayers={remotePlayers}
          chatMessages={chatMessages}
          onUpdateSettings={(s: GameSettings) => {
            if (!engineRef.current) return;
            engineRef.current.saveData.settings = s;
            engineRef.current.applySettingsUpdate();
            syncSave(engineRef.current.saveData);
          }}
          onManualSave={() => {
            if (!engineRef.current) return;
            syncSave(engineRef.current.saveData);
            pushToast('Game saved locally!', 'epic');
          }}
          onResetSave={() => {
            clearSavedGame();
            window.location.reload();
          }}
          onConnectRoom={(roomCode: string) => {
            if (!engineRef.current) return;
            const d = engineRef.current.saveData;
            engineRef.current.mp.connect(roomCode, {
              name: d.appearance.name,
              x: hud?.position.x || 0,
              y: hud?.position.y || 2,
              z: hud?.position.z || 16,
              yaw: hud?.position.yaw || Math.PI,
              anim: 'idle',
              level: d.stats.level,
              hp: d.stats.hp,
              maxHp: d.stats.maxHp,
              hairColor: d.appearance.hairColor,
              skinColor: d.appearance.skinColor,
              armorColor: d.appearance.armorColor,
              weaponType: (d.equipped.weapon ? ITEM_MAP[d.equipped.weapon]?.weaponCategory : 'Sword') || 'Sword',
              mounted: hud?.isMounted || false,
            });
          }}
          onDisconnectRoom={() => engineRef.current?.mp.disconnect()}
          onSendChat={(text: string) => engineRef.current?.mp.sendChat(text)}
          onClose={() => setModal(null)}
        />
      )}

      {/* Story Victory Ending Modal */}
      {modal === 'ending' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/85 p-5">
          <div className="max-w-lg w-full rounded-2xl bg-[#111827] border border-amber-400/70 p-6 text-center space-y-4 shadow-2xl">
            <Crown className="w-12 h-12 text-amber-400 mx-auto" />
            <h2 className="font-display text-2xl font-bold text-amber-200">
              Sovereign of the Eight Realms!
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              You have vanquished the Lord of Darkness, claimed the Heart of Elements, and restored light across
              Oakhearth, the Iron Mountains, Ghost Swamp, Skeleton Ruins, Goblin Kingdom, Volcano Caldera, Frozen Peaks,
              and the Ancient Lands.
            </p>
            <p className="text-xs text-amber-300">
              Your legend continues! Keep exploring, building your kingdom, or hosting co-op adventures.
            </p>
            <button
              type="button"
              onClick={() => setModal(null)}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm"
            >
              Continue Free Roam
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
