/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  Activity,
  BookOpen,
  Bot,
  Brain,
  CheckCircle2,
  Compass,
  Cpu,
  Database,
  Folder,
  Globe,
  Layers,
  MessageSquare,
  Radio,
  Server,
  Shield,
  ShieldCheck,
  Sparkles,
  Terminal,
  Wrench,
  Zap,
} from 'lucide-react';

import { AgentsMonitor } from './components/AgentsMonitor.tsx';
import { ArchitectureDocs } from './components/ArchitectureDocs.tsx';
import { ChatConsole } from './components/ChatConsole.tsx';
import { CoreLoopVisualizer } from './components/CoreLoopVisualizer.tsx';
import { FounderAndVersionView } from './components/FounderAndVersionView.tsx';
import { FreeResourceExplorer } from './components/FreeResourceExplorer.tsx';
import { FilesWorkspace } from './components/FilesWorkspace.tsx';
import { MemoryExplorer } from './components/MemoryExplorer.tsx';
import { ModelConsole } from './components/ModelConsole.tsx';
import { OutcomeAuditAndSuite } from './components/OutcomeAuditAndSuite.tsx';
import { PermissionModal } from './components/PermissionModal.tsx';
import { SecurityConsole } from './components/SecurityConsole.tsx';
import { TaskInspector } from './components/TaskInspector.tsx';
import { ToolSkillEngine } from './components/ToolSkillEngine.tsx';
import { TopHud } from './components/TopHud.tsx';
import { VoiceSettingsModal } from './components/VoiceSettingsModal.tsx';
import { api } from './services/api.ts';
import {
  AgentInfo,
  AgentMessage,
  AuditLog,
  ChatMessage,
  ConversationItem,
  CoreLoopStage,
  MemoryEntry,
  PendingPermissionRequest,
  ProjectItem,
  SkillDefinition,
  SystemStatus,
  TaskItem,
  ToolDefinition,
  VoiceSettings,
} from './types.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('terminal');
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversations, setConversations] = useState<ConversationItem[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string>('conv_default');
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [activeTask, setActiveTask] = useState<TaskItem | null>(null);
  const [currentStage, setCurrentStage] = useState<CoreLoopStage | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  // Tools & Skills & Agents
  const [tools, setTools] = useState<ToolDefinition[]>([]);
  const [skills, setSkills] = useState<SkillDefinition[]>([]);
  const [agents, setAgents] = useState<AgentInfo[]>([]);
  const [recentAgentMessages, setRecentAgentMessages] = useState<AgentMessage[]>([]);

  // Memories & Security
  const [memories, setMemories] = useState<MemoryEntry[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [pendingRequests, setPendingRequests] = useState<PendingPermissionRequest[]>([]);

  // Voice synthesis & settings state
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(() => {
    try {
      const saved = localStorage.getItem('jarvis_voice_settings');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      enabled: false,
      rate: 1.0,
      pitch: 1.0,
      volume: 1.0,
      personality: 'PROFESSIONAL',
    };
  });
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);
  const [modalPendingTask, setModalPendingTask] = useState<TaskItem | null>(null);

  // Poll / Refresh Data
  const loadAllData = async () => {
    try {
      const [
        statusRes,
        convsRes,
        msgRes,
        tasksRes,
        toolsRes,
        skillsRes,
        agentsRes,
        memRes,
        auditRes,
        projectsRes,
      ] = await Promise.all([
        api.getStatus().catch(() => null),
        api.getConversations().catch(() => ({ conversations: [] })),
        api.getMessages(currentConversationId).catch(() => ({ messages: [] })),
        api.getTasks().catch(() => ({ tasks: [] })),
        api.getTools().catch(() => ({ tools: [] })),
        api.getSkills().catch(() => ({ skills: [] })),
        api.getAgents().catch(() => ({ agents: [], recentMessages: [] })),
        api.getMemories().catch(() => ({ memories: [] })),
        api.getSecurityAudit().catch(() => ({ auditLogs: [], pendingRequests: [] })),
        api.getProjects().catch(() => ({ projects: [] })),
      ]);

      if (statusRes) setStatus(statusRes);
      if (convsRes?.conversations) setConversations(convsRes.conversations);
      if (projectsRes?.projects) setProjects(projectsRes.projects);
      if (msgRes.messages) setMessages(msgRes.messages);
      if (tasksRes.tasks) {
        setTasks(tasksRes.tasks);
        // Check if any task is waiting permission
        const waiting = tasksRes.tasks.find((t: TaskItem) => t.status === 'WAITING_PERMISSION');
        if (waiting) {
          setModalPendingTask(waiting);
        }
      }
      if (toolsRes.tools) setTools(toolsRes.tools);
      if (skillsRes.skills) setSkills(skillsRes.skills);
      if (agentsRes.agents) setAgents(agentsRes.agents);
      if (agentsRes.recentMessages) setRecentAgentMessages(agentsRes.recentMessages);
      if (memRes.memories) setMemories(memRes.memories);
      if (auditRes.auditLogs) setAuditLogs(auditRes.auditLogs);
      if (auditRes.pendingRequests) setPendingRequests(auditRes.pendingRequests);
    } catch (err) {
      console.warn('Initial data load error:', err);
    }
  };

  useEffect(() => {
    loadAllData();

    // Setup Server-Sent Events (SSE) stream for real-time core loop updates
    let eventSource: EventSource | null = null;
    try {
      eventSource = api.createEventSource('/api/events');
      eventSource.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.stage) {
            setCurrentStage(data.stage);
          }
          if (data.type === 'SECURITY' && data.data?.pendingRequestId) {
            loadAllData();
          }
        } catch {
          // ignore keepalive parse
        }
      };
      eventSource.onerror = () => {
        // SSE transient error, browser reconnects automatically
      };
    } catch (sseErr) {
      console.warn('SSE connection unavailable, relying on standard polling:', sseErr);
    }

    return () => {
      eventSource?.close();
    };
  }, []);

  // Voice Speech Synthesis Handler
  const speakUtterance = (text: string, customSettings?: VoiceSettings) => {
    const s = customSettings || voiceSettings;
    if (!s.enabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel(); // Stop prior speech
      const cleaned = text.replace(/[*_#`\[\]]/g, '').slice(0, 300);
      const utterance = new SpeechSynthesisUtterance(cleaned);
      utterance.rate = s.rate;
      utterance.pitch = s.pitch;
      utterance.volume = s.volume;
      if (s.voiceURI) {
        const matchingVoice = window.speechSynthesis.getVoices().find((v) => v.voiceURI === s.voiceURI);
        if (matchingVoice) utterance.voice = matchingVoice;
      }
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Voice synthesis error:', e);
    }
  };

  const handleToggleVoice = () => {
    const nextEnabled = !voiceSettings.enabled;
    const updated = { ...voiceSettings, enabled: nextEnabled };
    setVoiceSettings(updated);
    try {
      localStorage.setItem('jarvis_voice_settings', JSON.stringify(updated));
    } catch {}
    if (nextEnabled) {
      speakUtterance('Voice response synthesis enabled.', { ...updated, enabled: true });
    }
  };

  const handleSaveVoiceSettings = (newSettings: VoiceSettings) => {
    setVoiceSettings(newSettings);
    try {
      localStorage.setItem('jarvis_voice_settings', JSON.stringify(newSettings));
    } catch {}
  };

  const handleTestVoice = (testSettings: VoiceSettings) => {
    speakUtterance('Greetings operator. JARVIS 5.1 voice synthesizer operational.', {
      ...testSettings,
      enabled: true,
    });
  };

  // Multi-Conversation Handlers
  const handleSelectConversation = async (convId: string) => {
    setCurrentConversationId(convId);
    try {
      const res = await api.getMessages(convId);
      if (res.messages) setMessages(res.messages);
    } catch (err) {
      console.warn('Failed to load messages for conversation:', err);
    }
  };

  const handleCreateConversation = async (title?: string, topic?: string, projectId?: string) => {
    try {
      const res = await api.createConversation(title, topic, projectId);
      if (res.success && res.conversation) {
        setCurrentConversationId(res.conversation.id);
        setMessages([]);
        await loadAllData();
      }
    } catch (err) {
      console.error('Failed to create conversation:', err);
    }
  };

  const handleCreateProject = async (name: string, description: string, contextBrief: string) => {
    try {
      const res = await api.createProject({ name, description, contextBrief });
      if (res.success && res.project) {
        setSelectedProjectId(res.project.id);
        await loadAllData();
      }
    } catch (err) {
      console.error('Failed to create project:', err);
    }
  };

  const handleUpdateProject = async (id: string, updates: Partial<ProjectItem>) => {
    try {
      await api.updateProject(id, updates);
      await loadAllData();
    } catch (err) {
      console.error('Failed to update project:', err);
    }
  };

  const handleDeleteProject = async (id: string, permanent = false) => {
    try {
      await api.deleteProject(id, permanent);
      if (selectedProjectId === id) {
        setSelectedProjectId(null);
      }
      await loadAllData();
    } catch (err) {
      console.error('Failed to delete project:', err);
    }
  };

  const handleRenameConversation = async (id: string, newTitle: string) => {
    try {
      await api.updateConversation(id, { title: newTitle });
      await loadAllData();
    } catch (err) {
      console.error('Failed to rename conversation:', err);
    }
  };

  const handleDeleteConversation = async (id: string) => {
    try {
      await api.deleteConversation(id);
      if (currentConversationId === id) {
        setCurrentConversationId('conv_default');
        const defaultMsgs = await api.getMessages('conv_default');
        setMessages(defaultMsgs.messages || []);
      }
      await loadAllData();
    } catch (err) {
      console.error('Failed to delete conversation:', err);
    }
  };

  // Chat Execution Handler
  const handleSendMessage = async (prompt: string) => {
    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: prompt,
      timestamp: new Date().toISOString(),
    };
    // Optimistically append user message immediately for instantaneous feedback
    setMessages((prev) => [...prev, userMsg]);
    setIsExecuting(true);
    setCurrentStage('PERCEIVE');

    try {
      const data = await api.sendChat(prompt, currentConversationId);

      if (data.success && data.message) {
        setMessages((prev) => [...prev, data.message]);
        setActiveTask(data.task);
        setSelectedTaskId(data.task.id);

        if (data.task.status === 'WAITING_PERMISSION') {
          setModalPendingTask(data.task);
        } else {
          speakUtterance(data.message.content);
        }
      } else {
        const errNotice: ChatMessage = {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: `Execution notice: ${data.error || 'Operation failed in JARVIS Core'}`,
          timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, errNotice]);
      }
    } catch (err: any) {
      console.error('Chat request failed:', err);
      const errNotice: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        content: `Execution error: ${err?.message || 'Failed to process task in JARVIS Core'}`,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errNotice]);
    } finally {
      setIsExecuting(false);
      setCurrentStage(null);
      loadAllData();
    }
  };

  // Permission Approval Handlers
  const handleApproveTask = async (taskId: string) => {
    try {
      const data = await api.approveTask(taskId);
      if (data.success) {
        setModalPendingTask(null);
        await loadAllData();
        speakUtterance('Authorization confirmed. Action executed successfully.');
      }
    } catch (err) {
      console.error('Approve failed:', err);
    }
  };

  const handleRejectTask = async (taskId: string, reason?: string) => {
    try {
      const data = await api.rejectTask(taskId, reason || 'Operator denied');
      if (data.success) {
        setModalPendingTask(null);
        await loadAllData();
      }
    } catch (err) {
      console.error('Reject failed:', err);
    }
  };

  // Memory Handlers
  const handleSaveMemory = async (entry: {
    key: string;
    content: string;
    type: string;
    importance: number;
    tags: string[];
  }) => {
    try {
      await api.saveMemory(entry as any);
      await loadAllData();
    } catch (err) {
      console.error('Save memory failed:', err);
    }
  };

  const handleDeleteMemory = async (id: string) => {
    try {
      await api.deleteMemory(id);
      await loadAllData();
    } catch (err) {
      console.error('Delete memory failed:', err);
    }
  };

  // Direct Tool Runner
  const handleExecuteToolDirect = async (toolName: string, parameters: Record<string, unknown>) => {
    return api.executeTool(toolName, parameters);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-sky-500 selection:text-white">
      {/* Top Telemetry & Health HUD */}
      <TopHud
        status={status}
        currentStage={currentStage}
        isVoiceActive={voiceSettings.enabled}
        onToggleVoice={handleToggleVoice}
        onOpenVoiceSettings={() => setIsVoiceModalOpen(true)}
        pendingApprovalsCount={pendingRequests.length}
        onOpenSecurity={() => setActiveTab('security')}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        memoryCount={memories.length}
      />

      <main className="max-w-7xl mx-auto px-4 py-4 space-y-4">
        {/* Real-time 11-Stage Core Loop Visualizer */}
        <CoreLoopVisualizer currentStage={currentStage} isExecuting={isExecuting} />

        {/* Master Navigation Bar matching Section F Specification */}
        <nav
          aria-label="Main system navigation"
          className="flex items-center gap-1.5 overflow-x-auto bg-slate-200/50 p-1.5 rounded-xl border border-slate-200 font-mono text-xs"
        >
          <button
            id="tab-terminal"
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'terminal'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Terminal className={`w-3.5 h-3.5 ${activeTab === 'terminal' ? 'text-sky-600' : 'text-slate-500'}`} />
            <span>CHAT / BRAIN</span>
          </button>

          <button
            id="tab-models"
            onClick={() => setActiveTab('models')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'models'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Brain className={`w-3.5 h-3.5 ${activeTab === 'models' ? 'text-sky-600' : 'text-slate-500'}`} />
            <span>MODELS / ROUTER</span>
          </button>

          <button
            id="tab-tasks"
            onClick={() => setActiveTab('tasks')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'tasks'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Layers className={`w-3.5 h-3.5 ${activeTab === 'tasks' ? 'text-purple-600' : 'text-slate-500'}`} />
            <span>ACTIONS / TASKS ({tasks.length})</span>
          </button>

          <button
            id="tab-agents"
            onClick={() => setActiveTab('agents')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'agents'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Bot className={`w-3.5 h-3.5 ${activeTab === 'agents' ? 'text-indigo-600' : 'text-slate-500'}`} />
            <span>AGENTS (6)</span>
          </button>

          <button
            id="tab-tools"
            onClick={() => setActiveTab('tools')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'tools'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Wrench className={`w-3.5 h-3.5 ${activeTab === 'tools' ? 'text-amber-600' : 'text-slate-500'}`} />
            <span>CAPABILITIES & TOOLS ({tools.length})</span>
          </button>

          <button
            id="tab-memory"
            onClick={() => setActiveTab('memory')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'memory'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Database className={`w-3.5 h-3.5 ${activeTab === 'memory' ? 'text-emerald-600' : 'text-slate-500'}`} />
            <span>MEMORY ({memories.length})</span>
          </button>

          <button
            id="tab-security"
            onClick={() => setActiveTab('security')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'security'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Shield className={`w-3.5 h-3.5 ${activeTab === 'security' ? 'text-rose-600' : 'text-slate-500'}`} />
            <span>SECURITY</span>
            {pendingRequests.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
            )}
          </button>

          <button
            id="tab-files"
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'files'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Folder className={`w-3.5 h-3.5 ${activeTab === 'files' ? 'text-amber-600' : 'text-slate-500'}`} />
            <span>FILES & DOCS</span>
          </button>

          <button
            id="tab-architecture"
            onClick={() => setActiveTab('architecture')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'architecture'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <BookOpen className={`w-3.5 h-3.5 ${activeTab === 'architecture' ? 'text-sky-600' : 'text-slate-500'}`} />
            <span>ARCHITECTURE</span>
          </button>

          <button
            id="tab-discovery"
            onClick={() => setActiveTab('discovery')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'discovery'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Globe className={`w-3.5 h-3.5 ${activeTab === 'discovery' ? 'text-emerald-600' : 'text-slate-500'}`} />
            <span>FREE DISCOVERY</span>
          </button>

          <button
            id="tab-audit"
            onClick={() => setActiveTab('audit')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'audit'
                ? 'bg-white border border-sky-300 text-sky-900 font-bold shadow-xs ring-1 ring-sky-200'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60 font-semibold'
            }`}
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${activeTab === 'audit' ? 'text-sky-600' : 'text-slate-600'}`} />
            <span>407 AUDIT &amp; SUITE</span>
          </button>

          <button
            id="tab-founder"
            onClick={() => setActiveTab('founder')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap ml-auto ${
              activeTab === 'founder'
                ? 'bg-white border border-slate-300/80 text-sky-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 font-medium'
            }`}
          >
            <Sparkles className={`w-3.5 h-3.5 ${activeTab === 'founder' ? 'text-purple-600' : 'text-slate-500'}`} />
            <span>FOUNDER &amp; VERSION</span>
          </button>
        </nav>

        {/* View Panes */}
        <section id="jarvis-active-view">
          {activeTab === 'terminal' && (
            <ChatConsole
              messages={messages}
              onSendMessage={handleSendMessage}
              isExecuting={isExecuting}
              activeTask={activeTask}
              currentStage={currentStage}
              onSelectTask={(id) => {
                setSelectedTaskId(id);
                setActiveTab('tasks');
              }}
              conversations={conversations}
              currentConversationId={currentConversationId}
              onSelectConversation={handleSelectConversation}
              onCreateConversation={handleCreateConversation}
              onRenameConversation={handleRenameConversation}
              onDeleteConversation={handleDeleteConversation}
              projects={projects}
              selectedProjectId={selectedProjectId}
              onSelectProject={setSelectedProjectId}
              onCreateProject={handleCreateProject}
              onUpdateProject={handleUpdateProject}
              onDeleteProject={handleDeleteProject}
              onRefreshData={loadAllData}
            />
          )}

          {activeTab === 'audit' && <OutcomeAuditAndSuite />}

          {activeTab === 'discovery' && <FreeResourceExplorer />}

          {activeTab === 'founder' && <FounderAndVersionView />}

          {activeTab === 'models' && (
            <ModelConsole hasGeminiApiKey={status?.hasGeminiApiKey} />
          )}

          {activeTab === 'tasks' && (
            <TaskInspector
              tasks={tasks}
              selectedTaskId={selectedTaskId}
              onSelectTask={setSelectedTaskId}
              onApproveTask={handleApproveTask}
              onRejectTask={handleRejectTask}
            />
          )}

          {activeTab === 'agents' && (
            <AgentsMonitor agents={agents} recentMessages={recentAgentMessages} />
          )}

          {activeTab === 'tools' && (
            <ToolSkillEngine
              tools={tools}
              skills={skills}
              onExecuteToolDirect={handleExecuteToolDirect}
            />
          )}

          {activeTab === 'memory' && (
            <MemoryExplorer
              memories={memories}
              onSaveMemory={handleSaveMemory}
              onDeleteMemory={handleDeleteMemory}
            />
          )}

          {activeTab === 'security' && (
            <SecurityConsole
              auditLogs={auditLogs}
              pendingRequests={pendingRequests}
              onApproveTask={handleApproveTask}
              onRejectTask={handleRejectTask}
            />
          )}

          {activeTab === 'files' && <FilesWorkspace />}

          {activeTab === 'architecture' && <ArchitectureDocs />}
        </section>
      </main>

      {/* Interactive Permission Challenge Modal */}
      {modalPendingTask && (
        <PermissionModal
          task={modalPendingTask}
          onApprove={handleApproveTask}
          onReject={handleRejectTask}
          onClose={() => setModalPendingTask(null)}
        />
      )}

      {/* Voice Experience Settings Modal */}
      <VoiceSettingsModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        settings={voiceSettings}
        onSaveSettings={handleSaveVoiceSettings}
        onTestVoice={handleTestVoice}
      />
    </div>
  );
}
