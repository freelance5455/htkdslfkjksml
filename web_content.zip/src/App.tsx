import { useState, useCallback } from "react";
import {
  VOCABULARY,
  QUIZ_QUESTIONS,
  GRAMMAR_ITEMS,
} from "./data/lesson8";

type Screen = "home" | "vocabulary" | "grammar" | "quiz" | "progress";
type GameMode = "flashcard" | "match";

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [score, setScore] = useState(0);
  const [xp, setXp] = useState(0);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [quizAnswered, setQuizAnswered] = useState<boolean | null>(null);
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [gameMode, setGameMode] = useState<GameMode>("flashcard");
  const [matchedWords, setMatchedWords] = useState<Set<number>>(new Set());
  const [selectedWordId, setSelectedWordId] = useState<number | null>(null);
  const [showCelebration, setShowCelebration] = useState(false);
  const [currentGrammarIndex, setCurrentGrammarIndex] = useState(0);

  const levelForXp = Math.floor(xp / 100) + 1;

  const handleAddXp = useCallback((amount: number) => {
    setXp((prev) => {
      const newXp = prev + amount;
      if (Math.floor(newXp / 100) > Math.floor(prev / 100)) {
        setShowCelebration(true);
        setTimeout(() => setShowCelebration(false), 2000);
      }
      return newXp;
    });
  }, []);

  const resetQuiz = () => {
    setCurrentQuizIndex(0);
    setQuizScore(0);
    setQuizAnswered(null);
    setSelectedQuizOption(null);
  };

  const resetMatch = () => {
    setMatchedWords(new Set());
    setSelectedWordId(null);
  };

  const handleMatchSelect = (wordId: number) => {
    if (selectedWordId === null) {
      setSelectedWordId(wordId);
    } else {
      if (selectedWordId === wordId) {
        setSelectedWordId(null);
      } else {
        const newMatched = new Set(matchedWords);
        newMatched.add(selectedWordId);
        newMatched.add(wordId);
        setMatchedWords(newMatched);
        setSelectedWordId(null);
        handleAddXp(10);
        setScore((prev) => prev + 10);
      }
    }
  };

  const wordsToMatch = VOCABULARY.slice(0, 6);
  const isWordMatched = (id: number) => matchedWords.has(id);
  const isWordSelected = (id: number) => selectedWordId === id;
  const allWordsMatched = matchedWords.size >= wordsToMatch.length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-[Tahoma,'Segoe UI',Arial,sans-serif] direction-rtl">
      <header className="bg-indigo-600 text-white p-4 shadow-lg sticky top-0 z-50">
        <div className="max-w-xl mx-auto flex justify-between items-center gap-4">
          <button
            onClick={() => {
              setScreen("home");
              resetQuiz();
              resetMatch();
            }}
            className="flex items-center gap-2 hover:opacity-80 transition"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span>بازگشت</span>
          </button>

          <div className="flex items-center gap-3 bg-indigo-500/30 rounded-full px-4 py-2 border border-white/20 backdrop-blur-sm">
            <div className="flex items-center gap-1 text-yellow-200 text-sm font-bold">
              <svg className="w-4 h-6" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.377 1.998-1.304 1.62l-2.825-1.153a1 1 0 00-1.175 0l-2.825 1.153c-.927.378-1.604-.699-1.304-1.62l1.07-3.292a1 1 0 00-.364-1.118L5.98 8.924c-.783-.57-.382-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              {score}
            </div>
            <div className="flex items-center gap-1 text-blue-100 text-sm font-bold">
              <svg className="w-4 h-6" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
              </svg>
              LV {levelForXp}
            </div>
          </div>

          <div className="text-right hidden md:block">
            <h1 className="text-lg font-bold tracking-tight">درس هفتم زبان انگلیسی</h1>
            <p className="text-xs text-indigo-100 opacity-90">دبیرستان متوسطه اول - پایه هفتم</p>
          </div>
        </div>
      </header>

      <main className="max-w-xl mx-auto py-8 px-4">
        {screen === "home" && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-8 text-white shadow-xl shadow-indigo-200/50 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-6">
                  <div className="bg-white/20 px-4 py-2 rounded-full backdrop-blur-sm text-xs font-medium">
                    unit 8 • lesson 8
                  </div>
                  <div className="text-4xl">🎓</div>
                </div>
                <h2 className="text-3xl font-bold mb-2">درباره درس</h2>
                <p className="text-indigo-100 text-lg opacity-90">
                  یادگیری کلمات جدید، زمان حال ساد و تمرینات تعاملی
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <button
                onClick={() => setScreen("vocabulary")}
                className="group relative bg-white p-6 rounded-2xl border-2 border-indigo-100 hover:border-indigo-300 hover:shadow-xl transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-full bg-indigo-50/50 transition group-hover:bg-indigo-100/50"></div>
                <div className="relative z-10">
                  <div className="text-4xl mb-4">📖</div>
                  <h3 className="text-xl font-bold text-indigo-800 group-hover:text-indigo-600 transition">کلمات مرور</h3>
                  <p className="text-sm text-slate-600 mt-2">
                    یادگیری ۱۵ کلمه جدید با تصاویر و تلفظ فارسی
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-indigo-600 text-sm font-medium">
                    <span>شروع یادگیری</span>
                    <svg className="w-4 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setScreen("grammar")}
                className="group relative bg-white p-6 rounded-2xl border-2 border-indigo-100 hover:border-indigo-300 hover:shadow-xl transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-full bg-indigo-50/50 transition group-hover:bg-indigo-100/50"></div>
                <div className="relative z-10">
                  <div className="text-4xl mb-4">📐</div>
                  <h3 className="text-xl font-bold text-indigo-800 group-hover:text-indigo-600 transition">قواعد زبان</h3>
                  <p className="text-sm text-slate-600 mt-2">
                    زمان حال ساد، حروف اضافه زمان و ترکیب فعل
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-indigo-600 text-sm font-medium">
                    <span>مشاهده قواعد</span>
                    <svg className="w-4 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <button
                onClick={() => {
                  setScreen("quiz");
                  resetQuiz();
                }}
                className="group relative bg-white p-6 rounded-2xl border-2 border-indigo-100 hover:border-indigo-300 hover:shadow-xl transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-full bg-indigo-50/50 transition group-hover:bg-indigo-100/50"></div>
                <div className="relative z-10">
                  <div className="text-4xl mb-4">🧠</div>
                  <h3 className="text-xl font-bold text-indigo-800 group-hover:text-indigo-600 transition">تست ocen</h3>
                  <p className="text-sm text-slate-600 mt-2">
                    ۸ سوال انتخاب چندگانه برای ارزیابی درک شما
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-indigo-600 text-sm font-medium">
                    <span>شروع تست</span>
                    <svg className="w-4 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setScreen("progress")}
                className="group relative bg-white p-6 rounded-2xl border-2 border-indigo-100 hover:border-indigo-300 hover:shadow-xl transition-all cursor-pointer overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-full bg-indigo-50/50 transition group-hover:bg-indigo-100/50"></div>
                <div className="relative z-10">
                  <div className="text-4xl mb-4">🏆</div>
                  <h3 className="text-xl font-bold text-indigo-800 group-hover:text-indigo-600 transition">پیشرفت</h3>
                  <p className="text-sm text-slate-600 mt-2">
                    نمرات، سطوح و امتیازهای کسب شده
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-indigo-600 text-sm font-medium">
                    <span>مشاهده پیشرفت</span>
                    <svg className="w-4 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </button>
            </div>
          </div>
        )}

        {screen === "vocabulary" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-indigo-800">📖 کلمات درس هفتم</h2>
              <div className="flex gap-2">
                <button
                  onClick={() => setGameMode("flashcard")}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    gameMode === "flashcard"
                      ? "bg-indigo-600 text-white shadow-lg"
                      : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  کارت فلش
                </button>
                <button
                  onClick={() => {
                    setGameMode("match");
                    resetMatch();
                  }}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    gameMode === "match"
                      ? "bg-indigo-600 text-white shadow-lg"
                      : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  بازی جست‌وجو
                </button>
              </div>
            </div>

            {gameMode === "flashcard" && (
              <div className="space-y-4">
                <div className="bg-white rounded-3xl p-8 shadow-lg border border-slate-100 text-center relative overflow-hidden group">
                  <div className="relative z-10">
                    <div className="text-8xl mb-6">{VOCABULARY[currentWordIndex].image}</div>
                    <h3 className="text-4xl font-bold text-indigo-800 mb-2">{VOCABULARY[currentWordIndex].en}</h3>
                    <div className="bg-slate-100 px-4 py-2 rounded-xl inline-block text-slate-600 font-mono text-lg mb-4">
                      {VOCABULARY[currentWordIndex].pronunciation}
                    </div>
                    <p className="text-xl text-slate-700 font-medium">{VOCABULARY[currentWordIndex].fa}</p>
                    <p className="text-sm text-slate-500 mt-4">
                      دسته‌بندی: {VOCABULARY[currentWordIndex].category}
                    </p>
                  </div>
                </div>

                <div className="flex justify-between gap-4">
                  <button
                    onClick={() => setCurrentWordIndex((i) => (i === 0 ? VOCABULARY.length - 1 : i - 1))}
                    className="flex-1 bg-white border-2 border-slate-200 rounded-xl py-4 flex items-center justify-center gap-2 hover:border-indigo-300 transition"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                    قبلی
                  </button>
                  <button
                    onClick={() => setCurrentWordIndex((i) => (i === VOCABULARY.length - 1 ? 0 : i + 1))}
                    className="flex-1 bg-indigo-600 text-white rounded-xl py-4 flex items-center justify-center gap-2 hover:bg-indigo-700 transition shadow-lg shadow-indigo-200"
                  >
                    بعدی
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>

                <div className="flex gap-2 overflow-x-auto pb-2">
                  {VOCABULARY.map((word, idx) => (
                    <button
                      key={word.id}
                      onClick={() => setCurrentWordIndex(idx)}
                      className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 border-2 transition ${
                        currentWordIndex === idx
                          ? "border-indigo-600 bg-indigo-100 text-indigo-700 font-bold"
                          : "border-slate-200 bg-white text-slate-600 hover:border-indigo-300"
                      }`}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {gameMode === "match" && (
              <div className="space-y-6">
                <div className="bg-white rounded-3xl p-6 shadow-lg border border-slate-100">
                  <p className="text-center text-slate-600 mb-6">
                    کلمات انگلیسی و فارسی را جفت کنید! هر جفت درست = ۱۰ امتیاز
                  </p>
                  <div className="grid md:grid-cols-3 gap-3">
                    {wordsToMatch.map((word) => (
                      <button
                        key={word.id}
                        onClick={() => handleMatchSelect(word.id)}
                        className={`w-full py-4 rounded-xl border-2 transition-all flex flex-col items-center justify-center gap-2 group ${
                          isWordMatched(word.id)
                            ? "bg-emerald-100 border-emerald-400 text-emerald-800 font-bold opacity-100"
                            : isWordSelected(word.id)
                              ? "bg-indigo-100 border-indigo-400 text-indigo-800 font-bold ring-2 ring-indigo-400"
                              : "bg-white border-slate-200 text-slate-700 hover:border-indigo-300 hover:shadow-md"
                        }`}
                      >
                        <span className="text-2xl">{word.image}</span>
                        <span className="text-sm font-semibold">{word.en}</span>
                        <span className="text-xs text-slate-500">{word.fa}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {allWordsMatched && (
                  <div className="bg-gradient-to-r from-emerald-400 to-teal-500 rounded-3xl p-8 text-white text-center shadow-lg shadow-emerald-200/50">
                    <div className="text-6xl mb-4">🎉</div>
                    <h3 className="text-2xl font-bold mb-2">تمام شد!</h3>
                    <p className="text-emerald-100">همه کلمات جفت شدند.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {screen === "grammar" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-indigo-800">📐 قواعد زبان - درس هفتم</h2>

            <div className="flex gap-2 overflow-x-auto pb-4">
              {GRAMMAR_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCurrentGrammarIndex(item.id - 1)}
                  className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                    currentGrammarIndex === item.id - 1
                      ? "bg-indigo-600 text-white shadow-lg"
                      : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  {item.title}
                </button>
              ))}
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg border border-slate-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xl shrink-0">
                  {currentGrammarIndex + 1}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-indigo-800 mb-1">
                    {GRAMMAR_ITEMS[currentGrammarIndex].title}
                  </h3>
                  <p className="text-slate-600 text-sm mb-4 italic">
                    {GRAMMAR_ITEMS[currentGrammarIndex].faTitle}
                  </p>
                  <div className="space-y-3">
                    <div className="flex gap-3">
                      <span className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600">
                        ق
                      </span>
                      <p className="text-slate-700 leading-relaxed">
                        {GRAMMAR_ITEMS[currentGrammarIndex].rule}
                      </p>
                    </div>
                    <div className="flex gap-3 mt-4 pt-4 border-t border-slate-50">
                      <span className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-xs font-bold text-indigo-700">
                        م
                      </span>
                      <p className="text-slate-700 leading-relaxed italic">
                        "{GRAMMAR_ITEMS[currentGrammarIndex].example}"
                        <br />
                        {GRAMMAR_ITEMS[currentGrammarIndex].faExample}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between gap-4">
              <button
                onClick={() => setCurrentGrammarIndex((i) => (i === 0 ? GRAMMAR_ITEMS.length - 1 : i - 1))}
                className="flex-1 bg-white border-2 border-slate-200 rounded-xl py-3 flex items-center justify-center gap-2 hover:border-indigo-300 transition"
              >
                قبلی
              </button>
              <button
                onClick={() => setCurrentGrammarIndex((i) => (i === GRAMMAR_ITEMS.length - 1 ? 0 : i + 1))}
                className="flex-1 bg-indigo-600 text-white rounded-xl py-3 flex items-center justify-center gap-2 hover:bg-indigo-700 transition shadow-lg shadow-indigo-200"
              >
                بعدی
              </button>
            </div>
          </div>
        )}

        {screen === "quiz" && (
          <div className="space-y-6">
            {currentQuizIndex < QUIZ_QUESTIONS.length ? (
              <div>
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-xl font-bold text-indigo-800">
                      سوال {currentQuizIndex + 1} از {QUIZ_QUESTIONS.length}
                    </h2>
                    <p className="text-sm text-slate-500">{QUIZ_QUESTIONS[currentQuizIndex].faQuestion}</p>
                  </div>
                  <div className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-bold">
                    {quizScore} نمره
                  </div>
                </div>

                <div className="w-full bg-white rounded-3xl p-6 shadow-lg border border-slate-100">
                  <div className="text-lg text-slate-800 font-medium mb-6 text-right">
                    {QUIZ_QUESTIONS[currentQuizIndex].question}
                  </div>

                  <div className="space-y-3">
                    {QUIZ_QUESTIONS[currentQuizIndex].options.map((opt, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          if (quizAnswered === null) {
                            setSelectedQuizOption(idx);
                            const isCorrect = idx === QUIZ_QUESTIONS[currentQuizIndex].correct;
                            setQuizAnswered(isCorrect);
                            if (isCorrect) {
                              setQuizScore((prev) => prev + 1);
                              handleAddXp(15);
                              setScore((prev) => prev + 15);
                            }
                          }
                        }}
                        className={`w-full py-4 px-4 rounded-xl text-right border-2 transition-all flex justify-between items-center ${
                          quizAnswered === null
                            ? "bg-white border-slate-200 text-slate-700 hover:border-indigo-300 hover:bg-slate-50"
                            : idx === QUIZ_QUESTIONS[currentQuizIndex].correct
                              ? "bg-emerald-50 border-emerald-400 text-emerald-800 shadow-lg shadow-emerald-100"
                              : idx === selectedQuizOption
                                ? "bg-rose-50 border-rose-400 text-rose-800 shadow-lg shadow-rose-100"
                                : "bg-white border-slate-200 text-slate-600"
                        }`}
                      >
                        <span>{String.fromCharCode(1576 + idx)}) {opt}</span>
                        {quizAnswered !== null && idx === QUIZ_QUESTIONS[currentQuizIndex].correct && (
                          <svg className="w-5 h-5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                        )}
                        {quizAnswered !== null && idx === selectedQuizOption && idx !== QUIZ_QUESTIONS[currentQuizIndex].correct && (
                          <svg className="w-5 h-5 text-rose-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 001.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                          </svg>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {quizAnswered !== null && (
                  <div className={`mt-4 p-4 rounded-xl text-center ${quizAnswered ? "bg-emerald-50 border border-emerald-200 text-emerald-800" : "bg-rose-50 border border-rose-200 text-rose-800"}`}>
                    {quizAnswered ? "درست است! ✅" : "نادرست است ❌"}
                    <p className="text-sm mt-2 text-slate-600">
                      {QUIZ_QUESTIONS[currentQuizIndex].explanation}
                    </p>
                  </div>
                )}

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={() => {
                      setCurrentQuizIndex((i) => i + 1);
                      setQuizAnswered(null);
                      setSelectedQuizOption(null);
                    }}
                    disabled={quizAnswered === null}
                    className={`px-8 py-3 rounded-xl text-white font-bold shadow-lg transition-all ${quizAnswered === null ? "bg-slate-400 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-700"}`}
                  >
                    {currentQuizIndex === QUIZ_QUESTIONS.length - 1 ? "نتیجه نهایی" : "سوال بعدی →"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-10 text-white text-center shadow-xl shadow-indigo-200/50">
                <div className="text-8xl mb-6">🏆</div>
                <h2 className="text-3xl font-bold mb-4">تست تمام شد!</h2>
                <p className="text-xl text-indigo-100 mb-8">
                  نمره شما: <span className="text-white font-black text-3xl">{quizScore} از {QUIZ_QUESTIONS.length}</span>
                </p>
                <div className="bg-white/20 rounded-2xl p-4 mb-8 backdrop-blur-sm inline-block">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-indigo-200">درصد پاسخ صحیح</span>
                    <span className="text-sm font-bold">{Math.round((quizScore / QUIZ_QUESTIONS.length) * 100)}%</span>
                  </div>
                  <div className="w-full bg-indigo-400/30 h-2 rounded-full overflow-hidden">
                    <div className="bg-white h-2 rounded-full" style={{ width: `${(quizScore / QUIZ_QUESTIONS.length) * 100}%` }}></div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setScreen("home");
                    resetQuiz();
                  }}
                  className="bg-white text-indigo-600 px-8 py-3 rounded-xl font-bold hover:bg-indigo-50 transition shadow-lg"
                >
                  بازگشت به صفحه اصلی
                </button>
              </div>
            )}
          </div>
        )}

        {screen === "progress" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-indigo-800">🏆 پیشرفت یادگیری</h2>

            <div className="bg-white rounded-3xl p-8 shadow-lg border border-slate-100">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-4 bg-indigo-50 rounded-2xl">
                  <div className="text-3xl font-bold text-indigo-600 mb-1">{score}</div>
                  <div className="text-sm text-slate-600">امتیاز کل</div>
                </div>
                <div className="text-center p-4 bg-indigo-50 rounded-2xl">
                  <div className="text-3xl font-bold text-indigo-600 mb-1">{levelForXp}</div>
                  <div className="text-sm text-slate-600">سطح فعلی</div>
                </div>
                <div className="text-center p-4 bg-indigo-50 rounded-2xl">
                  <div className="text-3xl font-bold text-indigo-600 mb-1">{xp}</div>
                  <div className="text-sm text-slate-600">امتیاز تجربه</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700">سطح بعدی</span>
                  <span className="text-sm text-slate-500">{((levelForXp) * 100 - xp)} امتیاز تا سطح بعدی</span>
                </div>
                <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full transition-all duration-700" style={{ width: `${Math.min((xp % 100) / 100 * 100, 100)}%` }}></div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-lg border border-slate-100">
              <h3 className="text-lg font-bold text-indigo-800 mb-4">دسته‌بندی کلمات</h3>
              <div className="grid md:grid-cols-3 gap-4">
                {["time", "food", "place", "action"].map((cat) => {
                  const catWords = VOCABULARY.filter((w) => w.category === cat);
                  const catFa = { time: "زمان", food: "غذا", place: "مکان", action: "اقدام" }[cat];
                  return (
                    <div key={cat} className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-center">
                      <div className="text-2xl mb-2">
                        {cat === "time" ? "☀️" : cat === "food" ? "🍱" : cat === "place" ? "🏫" : "⚽"}
                      </div>
                      <div className="text-sm font-bold text-indigo-700 mb-1">{catFa}</div>
                      <div className="text-xs text-slate-500">{catWords.length} کلمه</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="text-center mt-8">
              <button
                onClick={() => setScreen("home")}
                className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition shadow-lg"
              >
                بازگشت به منو
              </button>
            </div>
          </div>
        )}
      </main>

      {showCelebration && (
        <div className="fixed top-24 right-4 z-50 bg-emerald-500 text-white px-6 py-3 rounded-2xl shadow-2xl transform transition-all duration-300 flex items-center gap-3">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          سطح جدید رسید! 🎉
        </div>
      )}
    </div>
  );
}