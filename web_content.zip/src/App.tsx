import { useEffect, useMemo, useRef, useState } from "react";
import { buildPsd, REF_SIZE } from "./psd/buildPsd";
import type { BuildResult, Platform, SpecRow } from "./psd/buildPsd";

const PSD_FILE = "Africas_Business_Heroes_Dr_Gildas_ZODOME.psd";

const browserPlatform: Platform = {
  createCanvas: (w, h) => {
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    return c;
  },
  toPng: (c: HTMLCanvasElement) =>
    new Promise((resolve, reject) =>
      c.toBlob(async (b) => (b ? resolve(new Uint8Array(await b.arrayBuffer())) : reject(new Error("PNG"))), "image/png")
    ),
};

const loadImage = (file: File) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });

const download = (blob: Blob, name: string) => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
};

const kindStyle: Record<SpecRow["kind"], string> = {
  Groupe: "bg-amber-100 text-amber-800",
  Texte: "bg-sky-100 text-sky-800",
  "Forme vectorielle": "bg-emerald-100 text-emerald-800",
  "Objet dynamique": "bg-fuchsia-100 text-fuchsia-800",
  "Pixel / Effet": "bg-slate-200 text-slate-700",
};

export default function App() {
  const [size, setSize] = useState(REF_SIZE);
  const [portrait, setPortrait] = useState<HTMLImageElement | undefined>();
  const [background, setBackground] = useState<HTMLImageElement | undefined>();
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<BuildResult | null>(null);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<string>("Tous");
  const previewRef = useRef<HTMLCanvasElement>(null);

  const generate = async () => {
    setBusy(true);
    setError("");
    try {
      await document.fonts.load('800 40px "Plus Jakarta Sans"');
      await document.fonts.load('400 40px "Plus Jakarta Sans"');
      await document.fonts.load('700 40px "Plus Jakarta Sans"');
      await document.fonts.load('200 40px "Plus Jakarta Sans"');
      await document.fonts.load('italic 800 40px "Plus Jakarta Sans"');
      const r = await buildPsd(browserPlatform, size, { portrait, background });
      setResult(r);
      return r;
    } catch (e: any) {
      setError(e?.message ?? String(e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    generate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [size, portrait, background]);

  useEffect(() => {
    if (result && previewRef.current) {
      const c = previewRef.current;
      c.width = 900;
      c.height = 900;
      c.getContext("2d")!.drawImage(result.preview, 0, 0, 900, 900);
    }
  }, [result]);

  const groups = useMemo(() => (result ? ["Tous", ...Array.from(new Set(result.spec.map((s) => s.group)))] : ["Tous"]), [result]);
  const rows = result?.spec.filter((s) => filter === "Tous" || s.group === filter) ?? [];
  const stats = result
    ? {
        groupes: result.spec.filter((s) => s.kind === "Groupe").length,
        textes: result.spec.filter((s) => s.kind === "Texte").length,
        formes: result.spec.filter((s) => s.kind === "Forme vectorielle").length,
        objets: result.spec.filter((s) => s.kind === "Objet dynamique").length,
      }
    : null;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <header className="bg-gradient-to-br from-emerald-900 via-emerald-800 to-green-700 text-white">
        <div className="mx-auto max-w-7xl px-6 py-10">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-lime-300">Automatisation Photoshop · Reconstruction de visuel</p>
          <h1 className="mt-2 text-3xl font-extrabold md:text-4xl">Fichier PSD modifiable — « Il est venu à la rescousse de l'ananas bio béninois ! »</h1>
          <p className="mt-3 max-w-3xl text-emerald-50/90">
            Le PSD est reconstruit calque par calque : 6 groupes nommés en français, textes éditables, formes vectorielles, objets dynamiques
            remplaçables, 300 DPI, proportions carrées d'origine.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href={PSD_FILE}
              download
              className="rounded-xl bg-lime-400 px-6 py-3 font-bold text-emerald-950 shadow-lg transition hover:bg-lime-300"
            >
              ⬇ Télécharger le PSD ({REF_SIZE}×{REF_SIZE} px)
            </a>
            <button
              onClick={async () => result && download(new Blob([result.bytes as BlobPart]), `ABH_Dr_Gildas_ZODOME_${result.width}px.psd`)}
              disabled={!result || busy}
              className="rounded-xl border border-white/40 px-6 py-3 font-semibold transition hover:bg-white/10 disabled:opacity-50"
            >
              {busy ? "Génération…" : `⚙ PSD généré à l'instant (${size}×${size})`}
            </button>
            <button
              onClick={() =>
                result &&
                download(
                  new Blob([JSON.stringify({ largeur: result.width, hauteur: result.height, resolution: "300 DPI", mode: "RVB 8 bits", calques: result.spec }, null, 2)], {
                    type: "application/json",
                  }),
                  "specification_calques.json"
                )
              }
              className="rounded-xl border border-white/40 px-6 py-3 font-semibold transition hover:bg-white/10"
            >
              {"{ }"} Spécification JSON
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-8 px-6 py-10 lg:grid-cols-[480px_1fr]">
        <aside className="space-y-6">
          <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
            <canvas ref={previewRef} className="aspect-square w-full rounded-lg bg-slate-100" />
            <p className="mt-2 text-center text-xs text-slate-500">Aperçu du composite du PSD (placeholders pour logos, fond et portrait)</p>
          </div>

          <div className="space-y-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <h2 className="font-bold">Propriétés du document</h2>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
              <dt className="text-slate-500">Dimensions</dt>
              <dd className="font-semibold">{size} × {size} px (1:1)</dd>
              <dt className="text-slate-500">Résolution</dt>
              <dd className="font-semibold">300 PPI</dd>
              <dt className="text-slate-500">Mode</dt>
              <dd className="font-semibold">RVB 8 bits (usage digital)</dd>
              <dt className="text-slate-500">Police suggérée</dt>
              <dd className="font-semibold">Plus Jakarta Sans</dd>
            </dl>
            <label className="block text-sm">
              <span className="text-slate-500">Taille de sortie</span>
              <select
                value={size}
                onChange={(e) => setSize(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-3 py-2"
              >
                <option value={1932}>1932 × 1932 px (mesuré sur le visuel)</option>
                <option value={1080}>1080 × 1080 px (format Instagram)</option>
                <option value={2160}>2160 × 2160 px (haute définition)</option>
              </select>
            </label>
            <p className="rounded-lg bg-amber-50 p-3 text-xs text-amber-900">
              Pour une impression CMJN : ouvrir le PSD puis <b>Image › Mode › Couleurs CMJN</b>. Le format PSD généré par script
              est écrit en RVB ; la conversion conserve calques, textes et objets dynamiques.
            </p>
          </div>

          <div className="space-y-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <h2 className="font-bold">Injecter vos images dans les objets dynamiques</h2>
            <p className="text-xs text-slate-500">
              Mon outil ne peut pas extraire les pixels de la photo envoyée. Déposez ici vos fichiers sources : ils seront intégrés au PSD
              comme contenu des objets dynamiques (sinon, des placeholders sont utilisés).
            </p>
            {[
              { label: "Portrait détouré (IMG_Portrait_Expert_Detoure)", set: setPortrait, value: portrait },
              { label: "Photo d'arrière-plan (IMG_Fond_Pavillon_Kigali)", set: setBackground, value: background },
            ].map((f) => (
              <label key={f.label} className="block text-sm">
                <span className="font-medium">{f.label}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) f.set(await loadImage(file));
                  }}
                  className="mt-1 block w-full text-xs file:mr-3 file:rounded-lg file:border-0 file:bg-emerald-700 file:px-3 file:py-2 file:font-semibold file:text-white hover:file:bg-emerald-600"
                />
                {f.value && <span className="text-xs text-emerald-700">✓ image intégrée ({f.value.width}×{f.value.height})</span>}
              </label>
            ))}
          </div>
        </aside>

        <section className="min-w-0">
          {error && <div className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</div>}
          {stats && (
            <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                ["Groupes", stats.groupes],
                ["Calques de texte", stats.textes],
                ["Formes vectorielles", stats.formes],
                ["Objets dynamiques", stats.objets],
              ].map(([l, v]) => (
                <div key={l as string} className="rounded-xl bg-white p-4 text-center shadow-sm ring-1 ring-slate-200">
                  <div className="text-3xl font-extrabold text-emerald-700">{v}</div>
                  <div className="text-xs text-slate-500">{l}</div>
                </div>
              ))}
            </div>
          )}

          <div className="mb-4 flex flex-wrap items-center gap-2">
            <h2 className="mr-2 text-xl font-bold">Hiérarchie des calques</h2>
            {groups.map((g) => (
              <button
                key={g}
                onClick={() => setFilter(g)}
                className={`rounded-full px-3 py-1 text-xs font-semibold transition ${
                  filter === g ? "bg-emerald-700 text-white" : "bg-white text-slate-600 ring-1 ring-slate-300 hover:bg-slate-100"
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          <div className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
            <ul className="divide-y divide-slate-100">
              {rows.map((r, i) => (
                <li key={r.group + r.name + i} className={`flex gap-3 px-4 py-3 ${r.kind === "Groupe" ? "bg-amber-50/60" : "pl-8"}`}>
                  <span className="mt-0.5 text-lg">{r.kind === "Groupe" ? "📁" : r.kind === "Texte" ? "T" : r.kind === "Objet dynamique" ? "🔗" : r.kind === "Forme vectorielle" ? "◼" : "▨"}</span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <code className="break-all text-sm font-bold text-slate-900">{r.name}</code>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${kindStyle[r.kind]}`}>{r.kind}</span>
                    </div>
                    <p className="mt-1 text-xs leading-relaxed text-slate-600">{r.details}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-8 rounded-2xl bg-emerald-950 p-6 text-sm text-emerald-50">
            <h3 className="mb-2 text-lg font-bold text-lime-300">Palette extraite</h3>
            <div className="flex flex-wrap gap-3">
              {[
                ["#2F7D32", "Fond haut"],
                ["#0A5A2E", "Fond bas"],
                ["#0C7A45", "Bandeau titre"],
                ["#8DC63F", "Vert lime"],
                ["#6AA22B", "Bouton"],
                ["#0A5A33", "Disque portrait"],
                ["#F3EFC4", "Logo Heroes"],
                ["#FFFFFF", "Blanc"],
              ].map(([c, n]) => (
                <div key={c} className="flex items-center gap-2 rounded-lg bg-white/10 px-3 py-2">
                  <span className="h-5 w-5 rounded border border-white/40" style={{ background: c }} />
                  <span className="text-xs">{n} <b className="font-mono">{c}</b></span>
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-emerald-200/80">
              Astuce : double-cliquez la vignette d'un objet dynamique dans Photoshop pour remplacer l'image ; les textes sont de vrais calques
              « Type » (installez Plus Jakarta Sans pour un rendu identique ; sinon Photoshop proposera une police de substitution).
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}
