/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PoketSafeData, IncomeFrequency, ExpenseCategory, Transaction, Commitment, Loan, LoanCategory, InstallmentType } from './types/budget';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { TransactionsPage } from './components/TransactionsPage';
import { PaymentsPage } from './components/PaymentsPage';
import { SavingsPage } from './components/SavingsPage';
import { ProfilePage } from './components/ProfilePage';
import { BottomNavBar, NavTab } from './components/BottomNavBar';
import { CreateLoanModal } from './components/CreateLoanModal';

const STORAGE_KEY = 'poketsafe_fresh_empty_v2';

const INITIAL_DEFAULT_DATA: PoketSafeData = {
  currentMoney: 0,
  incomeFrequency: 'monthly',
  incomeAmount: 0,
  currency: 'RM',
  commitments: [],
  debts: [],
  savings: [],
  transactions: [],
  loans: [],
};

export default function App() {
  const [data, setData] = useState<PoketSafeData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_DEFAULT_DATA,
          ...parsed,
          incomeFrequency: parsed.incomeFrequency || 'monthly',
          incomeAmount: parsed.incomeAmount ?? parsed.monthlyIncome ?? 0,
          currency: 'RM',
        };
      }
    } catch (e) {
      console.error('Failed to load saved PoketSafe data', e);
    }
    return INITIAL_DEFAULT_DATA;
  });

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isLoanModalOpen, setIsLoanModalOpen] = useState(false);

  // Sync to local storage for genuine personal persistence
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save to local storage', e);
    }
  }, [data]);

  // Handlers
  const handleUpdateCurrentMoney = (amount: number) => {
    setData(prev => ({ ...prev, currentMoney: amount }));
  };

  const handleUpdateIncome = (amount: number, frequency: IncomeFrequency) => {
    setData(prev => ({ ...prev, incomeAmount: amount, incomeFrequency: frequency }));
  };

  const handleAddExpense = (title: string, amount: number, category: ExpenseCategory) => {
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      type: 'expense',
      title,
      amount,
      category,
      date: new Date().toISOString(),
    };
    setData(prev => ({
      ...prev,
      currentMoney: Math.max(0, prev.currentMoney - amount),
      transactions: [newTx, ...prev.transactions],
    }));
  };

  const handleAddIncome = (title: string, amount: number) => {
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      type: 'income',
      title,
      amount,
      category: 'other',
      date: new Date().toISOString(),
    };
    setData(prev => ({
      ...prev,
      currentMoney: prev.currentMoney + amount,
      transactions: [newTx, ...prev.transactions],
    }));
  };

  const handleAddCommitment = (name: string, amount: number, dueDate: string) => {
    const newComm = {
      id: `comm_${Date.now()}`,
      name,
      amount,
      dueDate,
      isPaidThisCycle: false,
    };
    setData(prev => ({
      ...prev,
      commitments: [...prev.commitments, newComm],
    }));
  };

  const handleToggleCommitment = (id: string) => {
    setData(prev => ({
      ...prev,
      commitments: prev.commitments.map(c =>
        c.id === id ? { ...c, isPaidThisCycle: !c.isPaidThisCycle } : c
      ),
    }));
  };

  const handleDeleteCommitment = (id: string) => {
    setData(prev => ({
      ...prev,
      commitments: prev.commitments.filter(c => c.id !== id),
    }));
  };

  const handleAddDebt = (person: string, amount: number, type: 'i_owe' | 'they_owe', reason: string) => {
    const newDebt = {
      id: `debt_${Date.now()}`,
      person,
      amount,
      type,
      reason,
      isSettled: false,
    };
    setData(prev => ({
      ...prev,
      debts: [...prev.debts, newDebt],
    }));
  };

  const handleToggleDebt = (id: string) => {
    setData(prev => ({
      ...prev,
      debts: prev.debts.map(d =>
        d.id === id ? { ...d, isSettled: !d.isSettled } : d
      ),
    }));
  };

  const handleDeleteDebt = (id: string) => {
    setData(prev => ({
      ...prev,
      debts: prev.debts.filter(d => d.id !== id),
    }));
  };

  const handleDeleteTransaction = (id: string) => {
    setData(prev => {
      const target = prev.transactions.find(t => t.id === id);
      const refunded = target && target.type === 'expense'
        ? prev.currentMoney + target.amount
        : prev.currentMoney;
      return {
        ...prev,
        currentMoney: refunded,
        transactions: prev.transactions.filter(t => t.id !== id),
      };
    });
  };

  const handleCreateSavingsGoal = (title: string, targetAmount: number) => {
    const newGoal = {
      id: `goal_${Date.now()}`,
      title,
      targetAmount,
      currentAmount: 0,
    };
    setData(prev => ({
      ...prev,
      savings: [...prev.savings, newGoal],
    }));
  };

  const handleAddMoneyToGoal = (goalId: string, amount: number) => {
    setData(prev => ({
      ...prev,
      savings: prev.savings.map(g =>
        g.id === goalId ? { ...g, currentAmount: g.currentAmount + amount } : g
      ),
    }));
  };

  const handleWithdrawFromGoal = (goalId: string, amount: number) => {
    setData(prev => ({
      ...prev,
      savings: prev.savings.map(g =>
        g.id === goalId ? { ...g, currentAmount: Math.max(0, g.currentAmount - amount) } : g
      ),
    }));
  };

  const handleDeleteGoal = (goalId: string) => {
    setData(prev => ({
      ...prev,
      savings: prev.savings.filter(g => g.id !== goalId),
    }));
  };

  const handleCreateLoan = (loanData: {
    name: string;
    totalAmount: number;
    durationMonths: number;
    monthlyPayment: number;
    category: LoanCategory;
    dueDate: string;
    installmentType: InstallmentType;
    additionalMonthlyCharge?: number;
    interestPercentage?: number;
    customNotes?: string;
  }) => {
    const newLoan: Loan = {
      id: `loan_${Date.now()}`,
      ...loanData,
      startDate: new Date().toISOString(),
      paidMonths: 0,
      isPaidThisCycle: false,
    };

    // Also automatically create a monthly commitment so Safe To Spend formula deducts it
    const linkedCommitment: Commitment = {
      id: `comm_loan_${newLoan.id}`,
      name: `${loanData.name} (${loanData.durationMonths}mo Installment)`,
      amount: loanData.monthlyPayment,
      dueDate: loanData.dueDate,
      isPaidThisCycle: false,
    };

    setData(prev => ({
      ...prev,
      loans: [...(prev.loans || []), newLoan],
      commitments: [...prev.commitments, linkedCommitment],
    }));
  };

  const handleDeleteLoan = (loanId: string) => {
    setData(prev => ({
      ...prev,
      loans: (prev.loans || []).filter(l => l.id !== loanId),
      commitments: prev.commitments.filter(c => c.id !== `comm_loan_${loanId}`),
    }));
  };

  const handleResetData = () => {
    setData(INITIAL_DEFAULT_DATA);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.warn('Storage removeItem failed', e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onQuickAdd={() => setActiveTab('transactions')}
      />

      {/* Main Content Area (Mobile-First Centered Container) */}
      <main className="flex-1 max-w-lg w-full mx-auto px-4 pt-4 pb-24">
        {activeTab === 'home' && (
          <HomeScreen
            data={data}
            onNavigate={setActiveTab}
            onQuickAddExpense={() => setActiveTab('transactions')}
            onUpdateCurrentMoney={handleUpdateCurrentMoney}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsPage
            data={data}
            onAddExpense={handleAddExpense}
            onAddIncome={handleAddIncome}
            onAddCommitment={handleAddCommitment}
            onAddDebt={handleAddDebt}
            onDeleteTransaction={handleDeleteTransaction}
            onOpenLoanModal={() => setIsLoanModalOpen(true)}
          />
        )}

        {activeTab === 'payments' && (
          <PaymentsPage
            data={data}
            onToggleCommitment={handleToggleCommitment}
            onDeleteCommitment={handleDeleteCommitment}
            onAddCommitment={handleAddCommitment}
            onToggleDebt={handleToggleDebt}
            onDeleteDebt={handleDeleteDebt}
            onAddDebt={handleAddDebt}
            onOpenLoanModal={() => setIsLoanModalOpen(true)}
            onDeleteLoan={handleDeleteLoan}
          />
        )}

        {activeTab === 'savings' && (
          <SavingsPage
            data={data}
            onCreateGoal={handleCreateSavingsGoal}
            onAddMoneyToGoal={handleAddMoneyToGoal}
            onWithdrawFromGoal={handleWithdrawFromGoal}
            onDeleteGoal={handleDeleteGoal}
          />
        )}

        {activeTab === 'profile' && (
          <ProfilePage
            data={data}
            onUpdateIncome={handleUpdateIncome}
            onUpdateCurrentMoney={handleUpdateCurrentMoney}
            onResetData={handleResetData}
          />
        )}
      </main>

      {/* 4-Tab Bottom Navigation */}
      <BottomNavBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
      />

      {/* Loan Creation Modal with Duration Templates */}
      <CreateLoanModal
        isOpen={isLoanModalOpen}
        onClose={() => setIsLoanModalOpen(false)}
        onCreateLoan={handleCreateLoan}
      />
    </div>
  );
}
